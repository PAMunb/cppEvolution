#### AUTO 


```{c}
const auto status = index.data(eMyMoney::Model::SplitReconcileFlagRole).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : actionInfos) {
    auto a = menu->addAction(Icons::get(info.icon), info.text, this, info.callback);
    a->setEnabled(info.enabled);
  }
```

#### AUTO 


```{c}
const auto idx = firstIndexById(item.id());
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("kbanking");
```

#### AUTO 


```{c}
auto days = startD.daysTo(QDate::currentDate());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto helper : qAsConst(amountEditCurrencyHelpers)) {
            helper->setCommodity(sec.tradingCurrency());
        }
```

#### AUTO 


```{c}
const auto idx = indexById(after.id());
```

#### AUTO 


```{c}
const auto file(MyMoneyFile::instance());
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotToggleReconciliationFlag(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id: qAsConst(openLedgers)) {
                auto thisId = id;
                openLedger(thisId.remove(QLatin1String("*")), id.endsWith(QLatin1String("*")));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        const auto account = MyMoneyFile::instance()->account(accountId);
        if (account.currencyId() != d->assetAccount.currencyId()) {
            /// @todo update price rate information
        }
        d->assetSplit.setAccountId(accountId);
        d->postdateChanged(d->ui->dateEdit->date());
        d->updateWidgetState();
    }
```

#### AUTO 


```{c}
const auto& subAccount
```

#### AUTO 


```{c}
const auto& security = MyMoneyFile::instance()->security(account.currencyId());
```

#### AUTO 


```{c}
auto fees = new KMyMoneyCategory(true, nullptr);
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(haveWidget("price"))
```

#### RANGE FOR STATEMENT 


```{c}
for (auto report : used_reports) {
                    QStringList tagIdList(report.tags());
                    for (const auto& tagId : tagIdList) {
                        if (d->tagInList(selectedTags, tagId)) {
                            report.removeReference(tagId);
                            if (!newTagId.isEmpty()) {
                                report.addTag(newTagId);
                            }
                        }
                    }
                    file->modifyReport(report); // modify the transaction in the MyMoney object
                }
```

#### AUTO 


```{c}
auto cnt = itemList.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& f : allErrorFrames) {
        if (f->editWidget() == editWidget) {
            return f;
        }
    }
```

#### AUTO 


```{c}
const auto enableOption = !(id.isEmpty() || id.endsWith('-'));
```

#### AUTO 


```{c}
auto payee = baseModel->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
auto amountWidget = dynamic_cast<AmountEdit*>(w)
```

#### AUTO 


```{c}
const auto indexes = q->selectionModel()->selectedIndexes();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const SplitModel* model) {
            const auto rows = model->rowCount();
            for (int row = 0; row < rows; ++row) {
                const auto idx = model->index(row, 0);
                if (!idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isZero()) {
                    return true;
                }
            }
            return false;
        }
```

#### AUTO 


```{c}
const auto acc = d->m_file->account(accStr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entry : list) {
      txt += QString("%1, ").arg(entry+1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account.accountList())
        this->account(sAccount);
```

#### AUTO 


```{c}
const auto& rep = static_cast<const MyMoneyReport&>(obj);
```

#### AUTO 


```{c}
const auto investmentsView = static_cast<KInvestmentView*>(viewBases[view]);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& baseAccount : d->defaults) {
    ++itemCount;
    // we have nothing to do for favorites
    if (baseAccount.groupType == eMyMoney::Account::Standard::Favorite)
      continue;
    const auto account = list.value(MyMoneyAccount::stdAccName(baseAccount.groupType));
    if (account.id() == MyMoneyAccount::stdAccName(baseAccount.groupType)) {
      const auto idx = indexById(account.id());
      static_cast<TreeItem<MyMoneyAccount>*>(idx.internalPointer())->dataRef() = account;
      itemCount += d->loadSubAccounts(idx, list);
    } else {
      qDebug() << "Baseaccount for" << MyMoneyAccount::stdAccName(baseAccount.groupType) << "not found in list";
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : pPlugins.storage) {
        if (chosenFileType == plugin->storageType()) {
            try {
                d->consistencyCheck(false);
                if (plugin->saveAs()) {
                    d->fileAction(eKMyMoney::FileAction::Saved);
                    d->m_storageInfo.type = plugin->storageType();
                    return true;
                }
            } catch (const MyMoneyException &e) {
                KMessageBox::detailedError(this, i18n("Failed to save your storage."), e.what());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : d->actions) {
    actionCollection()->removeAction(action);
  }
```

#### AUTO 


```{c}
auto tm = split.matchedTransaction();
```

#### AUTO 


```{c}
auto s = journalEntry.split();
```

#### AUTO 


```{c}
const auto view = qobject_cast<LedgerViewPage*>(d->ui->ledgerTab->widget(idx));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : journalEntry.transaction().splits()) {
          const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(sp.accountId());
          if (acc.isIncomeExpense()) {
            return false;
          }
        }
```

#### AUTO 


```{c}
auto acBasicAccount = makeAccount(QString("Basic Account"), eMyMoney::Account::Checkings, openingBalance, QDate(2016, 1, 1), acAsset);
```

#### AUTO 


```{c}
auto itb = list.find((*ita).parentAccountId());
```

#### AUTO 


```{c}
auto rc = Transaction::paintRegisterCellSetup(painter, option, index);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotMatchTransactions(); }
```

#### AUTO 


```{c}
const auto button = wizard()->button(QWizard::CustomButton2);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
    const auto menuType = d->updateDynamicActions();
    emit requestCustomContextMenu(menuType, viewport()->mapToGlobal(pos));
  }
```

#### AUTO 


```{c}
auto printCss = QString(m_css).replace("@media screen", "@media _screen").replace("@media print", "@media screen");
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    Q_D(LedgerFilter);
    d->lineEdit = nullptr;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accStr : account.accountList()) {
      const auto acc = d->m_file->account(accStr);

      auto item = new QStandardItem(acc.name());
      accountsItem->appendRow(item);
      item->setEditable(false);
      auto subaccountsStr = acc.accountList();
      // filter out stocks with zero balance if requested by user
      for (auto subaccStr = subaccountsStr.begin(); subaccStr != subaccountsStr.end();) {
        const auto subacc = d->m_file->account(*subaccStr);
        if (subacc.isInvest() && KMyMoneyGlobalSettings::hideZeroBalanceEquities() && subacc.balance().isZero())
          subaccStr = subaccountsStr.erase(subaccStr);
        else
          ++subaccStr;
      }

      // adding subaccounts (e.g. stocks under given investment account) belonging to given account
      d->loadSubaccounts(item, favoriteAccountsItem, subaccountsStr);
      const auto row = item->row();
      d->setAccountData(accountsItem, row, acc, d->m_columns);
      d->loadPreferredAccount(acc, accountsItem, row, favoriteAccountsItem);
    }
```

#### AUTO 


```{c}
const auto rows = q->rowCount(idx);
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(ui->m_tagsView);
```

#### AUTO 


```{c}
auto IImporter = qobject_cast<ImporterPlugin *>(plugin);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& subAccount : accountIds) {
        if (!_list.contains(subAccount) || _list.value(subAccount).parentAccountId() != (*ita).id()) {
          (*ita).removeAccountId(subAccount);
          qDebug() << "check account hierarchy:" << "removed" << subAccount << "from" << (*ita).id();
        }
      }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyAccountPrivate::getAttrName(static_cast<Account::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto accID = makeAccount("Easy", "123456789", eMyMoney::Account::Type::Investment, QDate(2017, 8, 1), file->asset().id());
```

#### AUTO 


```{c}
auto grp = KSharedConfig::openConfig()->group(d->configGroupName);
```

#### AUTO 


```{c}
auto p = baseWidget->mapToGlobal(QPoint());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt)
    {
        if (txt.isEmpty()) {
            d->ui->accountCombo->setSelected(QString());
        }
    }
```

#### AUTO 


```{c}
static const auto sqlDriverName(QStringLiteral("QSQLCIPHER"));
```

#### AUTO 


```{c}
const auto strIBAN = QStringLiteral("iban");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& it_s : splits) {
        bool isAdditionalCostSplit = true;
        MyMoneyAccount acc = file->account(it_s.accountId());
        // if it's the split that references the source/dest
        // of the money, we check if we borrow or loan money
        if (paymentAccountId.isEmpty()
                && acc.isAssetLiability() && !acc.isLoan()
                && it_s.value() != MyMoneyMoney::autoCalc) {
            if (it_s.value().isNegative()) {
                setField("lendButton", false);
                setField("borrowButton", true);
            } else {
                setField("lendButton", true);
                setField("borrowButton", false);
            }
            // we keep the amount of the full payment and subtract the
            // base payment later to get information about the additional payment
            addPayment = it_s.value();
            paymentAccountId = it_s.accountId();
            MyMoneyPayee payee;
            if (!it_s.payeeId().isEmpty()) {
                try {
                    payee = file->payee(it_s.payeeId());
                    setField("payeeEdit", payee.id());
                } catch (const MyMoneyException &) {
                    qWarning("Payee for schedule has been deleted");
                }
            }

            // remove this split with one that will be replaced
            // later and has a phony id
            d->m_additionalFeesTransaction.removeSplit(it_s);
            d->m_phonySplit.clearId();
            d->m_additionalFeesTransaction.addSplit(d->m_phonySplit);
            isAdditionalCostSplit = false;
        }

        if (it_s.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
            interestAccountId = it_s.accountId();
        }

        if (it_s.value() != MyMoneyMoney::autoCalc) {
            basePayment += it_s.value();
        } else {
            // remove the splits which should not show up
            // for additional fees
            d->m_additionalFeesTransaction.removeSplit(it_s);
            isAdditionalCostSplit = false;
        }

        if (isAdditionalCostSplit) {
            d->m_feeSplitModel.appendSplit(it_s);
        }
    }
```

#### AUTO 


```{c}
const auto idx = dlgSplitModel.index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : s.tagIdList())
      if (file->tag(tag).name().contains(d->m_text))
        return !d->m_invertText;
```

#### AUTO 


```{c}
auto tab = static_cast<Tab>(index);
```

#### AUTO 


```{c}
const auto isPayeeIdentifierValid = index.parent().isValid();
```

#### AUTO 


```{c}
auto budget = file->budgetsModel()->itemByIndex(idx);
```

#### AUTO 


```{c}
const auto alignment = QVariant(Qt::AlignRight | Qt::AlignVCenter);
```

#### AUTO 


```{c}
auto aC = kmymoney->actionCollection();
```

#### AUTO 


```{c}
const auto splitCount = d->m_splits.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& index : list)
      setData(index, QVariant(QIcon(account.accountPixmap(true))), Qt::DecorationRole);
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(payeeFilterActive);
```

#### AUTO 


```{c}
const auto user = m_file->userModel()->itemById(m_file->fixedKey(MyMoneyFile::UserID));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : selection) {
      auto baseIdx = baseModel->mapToBaseSource(idx);
      auto payee = baseModel->itemByIndex(baseIdx);
      if (!payee.id().isEmpty()) {
        payees.append(payee);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& it : checkableActions) {
            lutActions[it]->setCheckable(true);
            lutActions[it]->setEnabled(true);
        }
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnTransaction]);
```

#### AUTO 


```{c}
auto screenNr = QApplication::desktop()->screenNumber(baseWidget);
```

#### AUTO 


```{c}
auto key = PyString_FromString("transactions");
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("sqlstorage.rc");
```

#### AUTO 


```{c}
auto asset = new KMyMoneyCategory(false, nullptr);
```

#### AUTO 


```{c}
const auto& file
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyInstitutionPrivate *>(right.d_func());
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(haveWidget("amount"));
```

#### AUTO 


```{c}
auto i = (int)MyMoneyBudget::Attribute::ID;
```

#### AUTO 


```{c}
auto i = (int)Attribute::Payee::Name;
```

#### AUTO 


```{c}
const auto budgetName = indexes.first().data(eMyMoney::Model::BudgetNameRole).toString();
```

#### AUTO 


```{c}
auto a = menu->addAction(Icons::get(info.icon), info.text, this, info.callback);
```

#### AUTO 


```{c}
auto request = m_connector.statementRequest();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyInstitution::getElName(static_cast<MyMoneyInstitution::Element>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account_list) {
    if (transactionCount(sAccount) != 0)
      return false; // the current account has a transaction assigned
    if (!hasOnlyUnusedAccounts(account(sAccount).accountList(), level + 1))
      return false; // some sub-account has a transaction assigned
  }
```

#### AUTO 


```{c}
const auto totalAmount = d->currentActivity->totalAmount(d->stockSplit, d->feeSplitModel, d->interestSplitModel);
```

#### AUTO 


```{c}
const auto prevState = !toggled;
```

#### AUTO 


```{c}
const auto account = accountData.value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyTagPrivate *>(right.d_func());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto payee : selection) {
      payeeIds.append(payee.id());
    }
```

#### AUTO 


```{c}
const auto payee(exp.match(*it_n));
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneySplit& split : d->m_splits)
    changed |= split.replaceId(newId, oldId);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& data: plugins) {
    QJsonArray editorsArray = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].toArray();
    for(QJsonValue entry: editorsArray) {
      if (!entry.toObject()["OnlineTaskIds"].isNull()) {
        list.append(onlineJobAdministration::onlineJobEditOffer{
            data.fileName(),
            entry.toObject()["PluginKeyword"].toString(),
            KPluginMetaData::readTranslatedString(entry.toObject(), "Name")
          });
      }
    }
  }
```

#### AUTO 


```{c}
auto cnt2 = !ui->m_chargesEdit->value().isZero() + !ui->m_chargesCategoryEdit->selectedItem().isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotOpenAccount(); }
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(id);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto selectedTransaction : list) {
        for(const auto split : selectedTransaction.transaction().splits()) {
          const auto id = split.accountId();
          const auto acc = MyMoneyFile::instance()->account(id);
          if (acc.isClosed()) {
            closedAccount = acc.name();
            // we're done
            rc = false;
            break;
          }
        }
        if(!rc)
          break;
      }
```

#### AUTO 


```{c}
const auto  assetValue = data(assetList.front(), (int)Role::TotalValue);
```

#### AUTO 


```{c}
const auto splits = d->m_additionalFeesTransaction.splits();
```

#### AUTO 


```{c}
const auto list = MyMoneyFile::instance()->journalEntryIds(filter);
```

#### AUTO 


```{c}
auto st = csvImporter->unattendedImport(filename, debitCreditProfile);
```

#### AUTO 


```{c}
auto transaction = QSharedPointer<MyMoneyTransaction>(new MyMoneyTransaction(newTransaction));
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto parentAccountItem = accountItem->parent();
```

#### AUTO 


```{c}
const auto indexList = match(index(0, 0), Qt::UserRole, id, -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto i = (int)Payee::Element::Address;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    // update the actions in the views
    d->m_myMoneyView->updateActions(d->m_selections);
    emit selectionChanged(d->m_selections);
  }
```

#### AUTO 


```{c}
const auto rightData = sourceModel()->data(sourceModel()->index(right.row(), AccountsModel::Account, right.parent()), AccountsModel::AccountTotalValueRole);
```

#### AUTO 


```{c}
const auto curPrice = file->price((*asset_it).tradingCurrencyId(), file->baseCurrency().id(), QDate::currentDate());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            Q_D(KEditScheduleDlg);
            d->setupTabOrder();
            // set focus to first tab field once we return to event loop
            const auto tabOrder = property("kmm_currenttaborder").toStringList();
            if (!tabOrder.isEmpty()) {
                const auto focusWidget = findChild<QWidget*>(tabOrder.first());
                if (focusWidget) {
                    QMetaObject::invokeMethod(focusWidget, "setFocus", Qt::QueuedConnection);
                }
            }
        }
```

#### AUTO 


```{c}
const auto key = QString::fromLatin1("%1-%2-%3-%4").arg(year, month, day, id);
```

#### AUTO 


```{c}
const auto ixCol = d->m_columns.indexOf(column);
```

#### AUTO 


```{c}
auto i = (int)Budget::Attribute::ID;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int value) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        d->m_schedule.setNextDueDate(d->m_editor->postDate());
        d->setScheduleOccurrencePeriod();
        d->m_schedule.setOccurrenceMultiplier(d->ui->m_frequencyNoEdit->value());

        if (d->m_schedule.transactionsRemaining() != value) {
            QSignalBlocker blocked(d->ui->m_FinalPaymentEdit);
            d->ui->m_FinalPaymentEdit->setDate(d->m_schedule.dateAfter(value));
        }
    }
```

#### AUTO 


```{c}
const auto verticalOffset = q->verticalHeader()->offset();
```

#### AUTO 


```{c}
auto moduleName  = nativeScriptFileInfo.baseName().toLocal8Bit();
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const MyMoneySecurity& c1, const MyMoneySecurity& c2)
        {
          const bool c1Metal = c1.tradingSymbol().startsWith(QLatin1Char('X')) && metalSymbols.contains(c1.tradingSymbol());
          const bool c2Metal = c2.tradingSymbol().startsWith(QLatin1Char('X')) && metalSymbols.contains(c2.tradingSymbol());
          if (c1Metal ^ c2Metal)
            return c2Metal;

          return c1.name().compare(c2.name()) < 0;
        }
```

#### AUTO 


```{c}
auto accounts = document.createElement(elementName(Element::Institution::AccountIDS));
```

#### AUTO 


```{c}
const auto t = dynamic_cast<KMyMoneyRegister::Transaction*>(list[0]);
```

#### AUTO 


```{c}
auto defaultButton = button(QDialogButtonBox::RestoreDefaults);
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<KMyMoneyDateInput*>(d->m_editor->haveWidget("postdate"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &payeeIdentifier : payee.payeeIdentifiers())
        if (!payeeIdentifier.isNull())
            writePayeeIdentifier(payeeIdentifier, document, el);
```

#### AUTO 


```{c}
const auto lastColumn = model()->columnCount() - 1;
```

#### AUTO 


```{c}
auto i = (int)Attribute::Security::Name;
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("shares"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& row : qAsConst(qStack)) {
            if (!m_containsNonBaseCurrency && row[ctCurrency] != file->baseCurrency().id()) {
                m_containsNonBaseCurrency = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto verticalPosition = q->verticalHeader()->sectionPosition(idx.row());
```

#### AUTO 


```{c}
auto processedAccounts = 0;
```

#### AUTO 


```{c}
const auto& splitIdx
```

#### AUTO 


```{c}
auto ta = readTag(m_baseNode);
```

#### AUTO 


```{c}
const auto rows = model()->rowCount();
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.validityFilter;
```

#### AUTO 


```{c}
auto idx = tabOrder.indexOf(widgetName);
```

#### AUTO 


```{c}
const auto endDate = QDate::currentDate().addDays(d->previewPeriod);
```

#### AUTO 


```{c}
const auto dataVariant = model()->data(model()->index(indexes.front().row(), (int)eAccountsModel::Column::Account, indexes.front().parent()), (int)eAccountsModel::Role::Account);
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyKeyValueContainerPrivate *>(right.d_func());
```

#### AUTO 


```{c}
auto it = m_colTypeNum.constBegin();
```

#### AUTO 


```{c}
auto memo = dynamic_cast<KTextEdit*>(*it_w);
```

#### AUTO 


```{c}
const auto test = selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
const auto s0 = t.splitByAccount(account.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : accounts)
            d->ui->accountsList->addTopLevelItem(new QTreeWidgetItem(QStringList{account.id, account.name, account.balance.formatMoney(QString(), 2)}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : qAsConst(list)) {
    itemCount += item.splitCount();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account_list) {
        auto a = d->accountsModel.itemById(sAccount);
        //qDebug() << "Deleting account '"<< a.name() << "'";

        // first remove all sub-accounts
        if (!a.accountList().isEmpty()) {
            removeAccountList(a.accountList(), level + 1);

            // then remove account itself, but we first have to get
            // rid of the account list that is still stored in
            // the MyMoneyAccount object. Easiest way is to get a fresh copy.
            a = d->accountsModel.itemById(sAccount);
        }

        // make sure to remove the item from the cache
        removeAccount(a);
    }
```

#### AUTO 


```{c}
const auto reconciliationHistory(account.reconciliationHistory());
```

#### AUTO 


```{c}
const auto idx = index(startRow, 0, parent);
```

#### AUTO 


```{c}
const auto &kpartgui = QStringLiteral("file_import_ofx");
```

#### AUTO 


```{c}
auto accountMatched = !filter.accountFilter;
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        const auto col = columnAt(pos.x());
        const auto row = rowAt(pos.y());
        const auto idx = model()->index(row, col);
        if (idx.flags() & Qt::ItemIsSelectable) {
            const auto menuType = d->updateDynamicActions();
            emit requestCustomContextMenu(menuType, viewport()->mapToGlobal(pos));
        }
    }
```

#### AUTO 


```{c}
const auto afterIdEmpty = after.id().isEmpty();
```

#### AUTO 


```{c}
auto amount = -d->splitsSum();
```

#### AUTO 


```{c}
const auto prec = MyMoneyMoney::denomToPrec(securityIdx.data(eMyMoney::Model::SecuritySmallestAccountFractionRole).toInt());
```

#### AUTO 


```{c}
const auto accountsStr = account.accountList();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotGoToAccount(); }
```

#### AUTO 


```{c}
auto text = tooltips[iconIndex];
```

#### AUTO 


```{c}
const auto transactionId = args.at(1).toString();
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<AmountEdit*>(haveWidget("shares"));
```

#### AUTO 


```{c}
const auto curPrice = file->price((*account_it).tradingCurrencyId(), file->baseCurrency().id(), QDate::currentDate());
```

#### AUTO 


```{c}
const auto& widgetName
```

#### AUTO 


```{c}
auto account = m->account(MyMoneyAccount::stdAccName(eMyMoney::Account::Standard::Liability));
```

#### AUTO 


```{c}
auto index = Models::instance()->accountsModel()->accountById(view->accountId());
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const KPluginMetaData& data) {
        QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
        if (array.isArray())
            return (array.toVariant().toStringList().contains(name));
        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& comboBox : m_columnBoxes) {
        comboBox->setCurrentIndex(-1);
    }
```

#### AUTO 


```{c}
auto format(d->ui->dateEdit->displayFormat());
```

#### AUTO 


```{c}
const auto& splitId = journalEntry.split().id();
```

#### AUTO 


```{c}
auto val2 = PyList_GetItem(val, i);
```

#### AUTO 


```{c}
const auto indexes = match(start, eMyMoney::Model::SplitAccountIdRole, d->account.id(), -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : actionInfos) {
      auto a = new QAction(nullptr);
      // KActionCollection::addAction by name sets object name anyways,
      // so, as better alternative, set it here right from the start
      a->setObjectName(info.name);
      a->setText(info.text);
      if (info.icon != Icon::Empty) // no need to set empty icon
        a->setIcon(Icons::get(info.icon));
      a->setEnabled(false);
      lutActions.insert(info.action, a);  // store QAction's pointer for later processing
    }
```

#### AUTO 


```{c}
auto
        idx = file->currenciesModel()->indexById(security.tradingCurrency());
```

#### AUTO 


```{c}
auto b = payeesCount == 1 ? true : false;
```

#### AUTO 


```{c}
auto idx = model->mapFromBaseSource(d->m_renameProxyModel, baseIdx);
```

#### AUTO 


```{c}
auto objId = selected.indexes().front().data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto cnt = filter.matchingSplitsCount(journalEntry.transaction());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
      if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest))
        interestAccounts[split.accountId()] = true;
    }
```

#### AUTO 


```{c}
const auto sec = file->securitiesModel()->itemById(secId);
```

#### AUTO 


```{c}
const auto subtrees = QVector<QModelIndex> ({ model->favoriteIndex(), model->assetIndex(), model->liabilityIndex() });
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(AccountsProxyModel);
        d->m_filterComboBox = nullptr;
    }
```

#### AUTO 


```{c}
const auto startRow =
            m_q->model()->index(0, 0).data(eMyMoney::Model::Roles::IdRole).toString() == MyMoneyAccount::stdAccName(eMyMoney::Account::Standard::Favorite) ? 1
                                                                                                                                                           : 0;
```

#### AUTO 


```{c}
const auto topLeft = PayeesModel::index(index.row(), 0);
```

#### AUTO 


```{c}
const auto internalName = QStringLiteral("Profile-%1").arg(name);
```

#### AUTO 


```{c}
const auto acc = file->account(accId);
```

#### AUTO 


```{c}
auto rows = rowCount(parentIdx);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    if (isVisible()) {
      d->ui->m_filterContainer->show();
      d->ui->m_searchWidget->setFocus();
    }
  }
```

#### AUTO 


```{c}
const auto model = d->ui->m_frequencyEdit->model();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& actionInfo : actionInfos) {
      d->m_contextMenu->insertAction(nullptr, d->m_actions[actionInfo.id]);
    }
```

#### AUTO 


```{c}
const auto accountcurrency = MyMoneyFile::instance()->currency(currencyId);
```

#### AUTO 


```{c}
const auto baseIdx = BudgetsModel::mapToBaseSource( currentIdx );
```

#### AUTO 


```{c}
auto colNum = m_columns.indexOf(Column::Account);
```

#### AUTO 


```{c}
const auto tagsView = static_cast<KTagsView*>(viewBases[view]);
```

#### AUTO 


```{c}
auto itInstitution = static_cast<InstitutionsPrivate *>(d)->institutionItemFromId(this, id);
```

#### AUTO 


```{c}
auto cols = eMyMoney::Report::QueryColumn::Number | eMyMoney::Report::QueryColumn::Payee | eMyMoney::Report::QueryColumn::Category | eMyMoney::Report::QueryColumn::Balance;
```

#### AUTO 


```{c}
auto createSelectionRange = [&]() {
        if (startRow != -1) {
            selection.select(model()->index(startRow, 0), model()->index(lastRow, lastColumn));
            startRow = -1;
        }
    };
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyXmlContentHandler2::elementName(static_cast<Element::Budget>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto defaultTabOrder = QStringList{
        QLatin1String("accountCombo"),
        QLatin1String("dateEdit"),
        QLatin1String("creditDebitEdit"),
        QLatin1String("payeeEdit"),
        QLatin1String("numberEdit"),
        QLatin1String("categoryCombo"),
        QLatin1String("costCenterCombo"),
        QLatin1String("tagContainer"),
        QLatin1String("statusCombo"),
        QLatin1String("memoEdit"),
        QLatin1String("enterButton"),
        QLatin1String("cancelButton"),
    };
```

#### AUTO 


```{c}
auto transactions = d->m_selectedTransactions;
```

#### RANGE FOR STATEMENT 


```{c}
for (const MyMoneyPayee &payee : list) {
                        if (loanAccount.hasReferenceTo(payee.id())) {
                            usedAccounts.append(account);
                        }
                    }
```

#### AUTO 


```{c}
auto found = false;
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(_acc.id());
```

#### AUTO 


```{c}
const auto stockSplitCopy(d->stockSplit);
```

#### AUTO 


```{c}
auto cache = static_cast<QCache<QString, QRegularExpression>*>(sqlite3_user_data(context));
```

#### AUTO 


```{c}
const auto password = m_editPassword->text();
```

#### AUTO 


```{c}
auto focusWidget = topLevelWidget->focusWidget();
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::account(split.accountId());
```

#### AUTO 


```{c}
const auto curPrice = file->price(account.tradingCurrencyId(), file->baseCurrency().id(), forecastDate);
```

#### AUTO 


```{c}
const auto rightData = sourceModel()->data(right, AccountsModel::DisplayOrderRole);
```

#### AUTO 


```{c}
auto isCategory = false;
```

#### AUTO 


```{c}
const auto url = extractNodeText(doc, "institution/url");
```

#### AUTO 


```{c}
const auto acc = file->account(d->m_lastSelectedAccountID);
```

#### AUTO 


```{c}
const auto& fileType
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
                const auto accIdx = d->accountsModel.indexById(split.accountId());
                const auto name = accIdx.data(eMyMoney::Model::AccountFullHierarchyNameRole).toString();
                const auto acc = d->accountsModel.itemByIndex(accIdx);
                const auto security = MyMoneyFile::instance()->security(acc.currencyId());
                rc << i18n("    Account: %1, Amount: %2", name, MyMoneyUtils::formatMoney(split.shares(), security));
            }
```

#### AUTO 


```{c}
auto b = acc.isClosed() ? true : false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& index : list)
        setData(index, QVariant(QIcon(account.accountPixmap(false))), Qt::DecorationRole);
```

#### AUTO 


```{c}
auto proxyModel = d->ui->m_parentAccounts->proxyModel();
```

#### AUTO 


```{c}
const auto font = idx.data(Qt::FontRole).value<QFont>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& indicator) {
    m_profile->m_creditIndicator = indicator;
    emit completeChanged();
  }
```

#### AUTO 


```{c}
auto priceEdit = dynamic_cast<kMyMoneyEdit*>(haveWidget("price"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Menu type, const QPoint& pos) {
        if (pMenus.contains(type)) {
            pMenus[type]->exec(pos);
        } else
            qDebug() << "Context menu for type" << static_cast<int>(type) << " not found";
    }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyBudget::getElName(static_cast<MyMoneyBudget::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto delegate = d->delegateProxy->delegate(index);
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_creditCol)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : d->m_plugins.storage) {
      if (plugin->formatName().compare(QLatin1String("SQL")) == 0) {
        rc = plugin->save(d->m_fileName);
        pluginFound = true;
        break;
      }
    }
```

#### AUTO 


```{c}
const auto gap = static_cast<int>(qAbs(matchedSchedule.transaction().postDate().toJulianDay() - importedTransaction.postDate().toJulianDay()));
```

#### AUTO 


```{c}
auto delegate = availableDelegates.cbegin();
```

#### AUTO 


```{c}
const auto transactionId = (*it_t).transaction().id();
```

#### AUTO 


```{c}
const auto date = QDate::fromString(parts[0], Qt::ISODate);
```

#### AUTO 


```{c}
const auto index(cb->findText(cb->currentText()));
```

#### AUTO 


```{c}
const auto children = d->ui->m_accountTree->model()->rowCount(index);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KSearchTransactionDlg);
        d->search();
    }
```

#### AUTO 


```{c}
auto cat = dynamic_cast<KMyMoneyCategory*>(haveWidget(category));
```

#### AUTO 


```{c}
const auto html(re.match(_html));
```

#### AUTO 


```{c}
auto totalValue = MyMoneyFile::instance()->accountsModel()->balanceToValue(accountId, accountBalance(accountId)).first;
```

#### AUTO 


```{c}
auto adjustedName(name);
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::OnlineJob>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto count = m_file->payeesModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto favItem = d->itemFromAccountId(favoriteAccountsItem, account->id())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); ++i) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (d->tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &tmpl : wizard.templates())
      tmpl.importTemplate(progressCallback);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sConfigName : qAsConst(sConfigNames)) {
      const auto sOldConfigFilename = sOldMainConfigPath + sConfigName;
      const auto sNewConfigFilename = sMainConfigPath + configNamesChange.value(sConfigName, sConfigName);
      if (QFile::exists(sOldConfigFilename)) {
        if (QFile::copy(sOldConfigFilename, sNewConfigFilename))
          QFile::remove(sOldConfigFilename);
      }
    }
```

#### AUTO 


```{c}
const auto val = idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemById(objId);
```

#### AUTO 


```{c}
const auto metrics = QFontMetrics(font);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotCombineTransactions(); }
```

#### AUTO 


```{c}
const auto& homeView = static_cast<KHomeView*>(viewBases[View::Home]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &payeeIdentifier : payee.payeeIdentifiers())
    if (!payeeIdentifier.isNull())
      writePayeeIdentifier(payeeIdentifier, document, el);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
    auto accIdx = file->accountsModel()->indexById(splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString());
    const auto accountGroup = accIdx.data(eMyMoney::Model::AccountGroupRole).value<eMyMoney::Account::Type>();
    if (splitIdx.row() == idx.row()) {
      security = file->security(accIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString());
    } else if (accountGroup == eMyMoney::Account::Type::Expense) {
      feeSplitModel.appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
    } else if (accountGroup == eMyMoney::Account::Type::Income) {
        interestSplitModel.appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
    } else {
      if (!assetAccountSplitIdx.isValid()) { // first asset Account should be our requested brokerage account
        assetAccountSplitIdx = splitIdx;
      } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isNegative()) { // the rest (if present) is handled as fee or interest
        feeSplitModel.appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
      } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isPositive()) {
        interestSplitModel.appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
      }
    }
  }
```

#### AUTO 


```{c}
auto codec = QTextCodec::codecForName("Windows-1251");
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Report));
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->accountsModel()->itemById(s.accountId());
```

#### AUTO 


```{c}
auto widget = dynamic_cast<const AmountEdit*>(*it_w)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
                    if (split.id().compare(matchedSplit.id())) {
                        auto newSplit(split);
                        newSplit.setShares(-matchedSplit.shares());
                        newSplit.setValue(-matchedSplit.value());
                        t.modifySplit(newSplit);
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto elem = document.createElement(elementName(Element::Payee::Identifier));
```

#### AUTO 


```{c}
auto bal = balance();
```

#### AUTO 


```{c}
const auto list = match(index(0, 0), AccountsModel::AccountIdRole, QVariant(account.id()), -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto tag = file->tag((*it_s));
```

#### AUTO 


```{c}
const auto baseIdx = journalModel->indexById(journalEntryId);
```

#### AUTO 


```{c}
auto acc = wizard.account();
```

#### AUTO 


```{c}
auto bindValuesToQuery = [&]() {
      auto value = task.value().toString();
      if (value.isEmpty()) {
        value = QStringLiteral("0");
      }
      query.bindValue(":id", id);
      query.bindValue(":originAccount", task.responsibleAccount());
      query.bindValue(":value", value);
      query.bindValue(":purpose", task.purpose());
      query.bindValue(":endToEndReference", (task.endToEndReference().isEmpty()) ? QVariant() : QVariant::fromValue(task.endToEndReference()));
      query.bindValue(":beneficiaryName", task.beneficiaryTyped().ownerName());
      query.bindValue(":beneficiaryIban", task.beneficiaryTyped().electronicIban());
      query.bindValue(":beneficiaryBic", (task.beneficiaryTyped().storedBic().isEmpty()) ? QVariant() : QVariant::fromValue(task.beneficiaryTyped().storedBic()));
      query.bindValue(":textKey", task.textKey());
      query.bindValue(":subTextKey", task.subTextKey());
    };
```

#### AUTO 


```{c}
auto postDate = dynamic_cast<KMyMoneyDateInput*>(haveWidget("postdate"));
```

#### AUTO 


```{c}
auto acc = account((*its).accountId());
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<AmountEdit*>(d->m_editWidgets["deposit"]);
```

#### AUTO 


```{c}
auto b = tagsCount == 1 ? true : false;
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("kbanking.rc");
```

#### AUTO 


```{c}
const auto isNewFileNotSaved = m_storageInfo.isOpened && m_storageInfo.url.isEmpty();
```

#### AUTO 


```{c}
const auto dateValue = idx.data(eMyMoney::Model::AccountOnlineBalanceDateRole);
```

#### AUTO 


```{c}
auto account = itemByIndex(idx);
```

#### AUTO 


```{c}
const auto& payee
```

#### AUTO 


```{c}
const auto count = m_models->securitiesModel()->processItems(&writer);
```

#### AUTO 


```{c}
const auto index = m_comboBox->findData(payeeId, eMyMoney::Model::IdRole);
```

#### AUTO 


```{c}
const auto accountType = toKMyMoneyAccountType(type, 0);
```

#### AUTO 


```{c}
auto i = (int)Attribute::Account::ID;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& idx) {
        Q_D(KMyMoneyAccountTreeView);
        d->openIndex(idx);
    }
```

#### AUTO 


```{c}
const auto& task = dynamic_cast<const sepaOnlineTransferImpl &>(obj);
```

#### AUTO 


```{c}
auto acc = (*it).account();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& button : buttons) {
            button = nullptr;
        }
```

#### AUTO 


```{c}
auto tradingCurrency = m_file->currency(security.tradingCurrency());
```

#### AUTO 


```{c}
auto type = tmp.toInt(&bOK);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        Q_D(KEditScheduleDlg);
        if (d->m_schedule.nextDueDate() != date) {
            if (d->ui->m_endOptionsFrame->isEnabled()) {
                d->m_schedule.setNextDueDate(date);
                d->m_schedule.setStartDate(date);
                d->m_schedule.setOccurrenceMultiplier(d->ui->m_frequencyNoEdit->value());

                d->setScheduleOccurrencePeriod();

                d->m_schedule.setEndDate(d->ui->m_FinalPaymentEdit->date());
                d->updateTransactionsRemaining();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int logicalIndex, int oldSize, int newSize) {
        emit sectionResized(this, d->columnSelector->configGroupName(), logicalIndex, oldSize, newSize);
        QMetaObject::invokeMethod(this, "adjustDetailColumn", Qt::QueuedConnection, Q_ARG(int, viewport()->width()));
    }
```

#### AUTO 


```{c}
const auto value = 
		      MyMoneyFile::instance()->balance((*it).id(), QDate::currentDate());
```

#### AUTO 


```{c}
const auto instances = instanceList();
```

#### AUTO 


```{c}
const auto indeces = file->journalModel()->indexesByTransactionId(lastAddedTransactionId);
```

#### AUTO 


```{c}
const auto accountData = sourceModel()->data(index, AccountsModel::AccountRole);
```

#### AUTO 


```{c}
auto& acc = d->m_currentAccount;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
                    acc = MyMoneyFile::instance()->account(split.accountId());
                    if (split.id() != journalEntry.split().id()) {
                        if (!acc.isIncomeExpense()) {
                            // for stock accounts we show the portfolio account
                            if (acc.isInvest()) {
                                acc = MyMoneyFile::instance()->account(acc.parentAccountId());
                            }
                            break;
                        }
                    }
                }
```

#### AUTO 


```{c}
const auto baseIdx = journalModel->mapToBaseSource(idx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& currency : list) {
        if (!usedCurrencies.contains(currency.id())) {
            const auto item = new QTreeWidgetItem(ui->m_currencyList);
            item->setText(0, currency.name());
            item->setData(0, Qt::UserRole, QVariant::fromValue(currency));
            item->setData(0, Qt::DecorationRole, empty);
            item->setFlags(item->flags() | Qt::ItemIsEditable);
            item->setText(1, currency.id());
            item->setText(2, currency.tradingSymbol());
        }
    }
```

#### AUTO 


```{c}
const auto deleteItem = menu->addAction(Icons::get(Icons::Icon::EditRemove), i18nc("@item:inmenu Delete selected split(s)", "Delete"), q, [&]() {
            emit q->deleteSelectedSplits();
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : d->m_transaction.splits()) {
            if (split.id() == d->m_split.id()) {
                d->ui->dateEdit->setDate(d->m_transaction.postDate());

                const auto payeeId = split.payeeId();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(split.memo());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(split.number());
                d->ui->statusCombo->setCurrentIndex(static_cast<int>(split.reconcileFlag()));
                d->ui->tagContainer->loadTags(split.tagIdList());
            } else {
                d->splitModel.appendSplit(split);
                if (d->m_transaction.splitCount() == 2) {
                    const auto shares = split.shares();
                    // the following is only relevant for transactions with two splits
                    // in different currencies
                    const auto value = -transactionValue;
                    const auto idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(value), eMyMoney::Model::SplitValueRole);
                    if (!value.isZero()) {
                        d->price = shares / value;
                    }
                    // make sure to use a possible foreign currency value
                    // in case of income and expense categories.
                    // in this case, we also need to use the reciprocal of the price
                    if (d->isIncomeExpense(split.accountId())) {
                        amount = -shares;
                        if (!shares.isZero()) {
                            d->price = value / shares;
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto pBudget = dynamic_cast<KBudgetListItem*>(p);
```

#### AUTO 


```{c}
const auto view = qobject_cast<KMyMoneyViewBase*>(current->widget());
```

#### AUTO 


```{c}
auto nativeScriptFileInfo = QFileInfo(nativeScript->fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : actionInfos) {
      auto a = new QAction(this);
      // KActionCollection::addAction by name sets object name anyways,
      // so, as better alternative, set it here right from the start
      a->setObjectName(info.name);
      a->setText(info.text);
      if (info.icon != Icon::Empty) // no need to set empty icon
        a->setIcon(Icons::get(info.icon));
      a->setEnabled(false);
      lutActions.insert(info.action, a);  // store QAction's pointer for later processing
    }
```

#### AUTO 


```{c}
auto splits = t.splits();
```

#### AUTO 


```{c}
const auto idx = d->tabIdByAccountId(accountId);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->updateCaption();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &extension : desiredFileExtensions) {
    for (const auto &plugin : pPlugins.storage) {
      if (plugin->storageType() == extension) {
        fileExtensions += plugin->fileExtension() + QLatin1String(";;");
        break;
      }
    }
  }
```

#### AUTO 


```{c}
const auto amount = dynamic_cast<KMyMoneyEdit*>(haveWidget(*it_f));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KInstitutionsView);
        // only react if this is the current view
        if (isVisible()) {
            d->ui->m_filterContainer->show();
            d->ui->m_searchWidget->setFocus();
        }
    }
```

#### AUTO 


```{c}
auto selectedAccountName = d->m_currentAccount.name();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    // trigger update
    d->delayTimer.start(20);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& backend : backends)
    d->ui->backendsList->addTopLevelItem(new QTreeWidgetItem(QStringList{backend.name,
                                                                  backend.module}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
        updateNextObjectId(item.id());
        const auto idx = index(row, 0);
        static_cast<TreeItem<MyMoneyInstitution>*>(idx.internalPointer())->dataRef() = item;
        d->loadAccounts(idx, item.accountList());
        ++row;
    }
```

#### AUTO 


```{c}
const auto idx = file->journalModel()->indexById(journalEntryId);
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<kMyMoneyLineEdit*>(d->m_editor->haveWidget("number"));
```

#### AUTO 


```{c}
const auto pluginDatas = KPluginMetaData::findPlugins(QStringLiteral("kmymoney"));
```

#### AUTO 


```{c}
auto toInvAcc = file->account(accountId);
```

#### AUTO 


```{c}
const auto idx = file->accountsModel()->indexById(accId);
```

#### AUTO 


```{c}
const auto frequency =
        model->index(d->ui->m_frequencyEdit->currentIndex(), 0).data(eMyMoney::Model::ScheduleFrequencyRole).value<eMyMoney::Schedule::Occurrence>();
```

#### AUTO 


```{c}
auto strValue = QVariant(value.formatMoney(tradingCurrency.tradingSymbol(), prec));
```

#### AUTO 


```{c}
const auto institution = Models::instance()->institutionsModel()->data(index, (int)eAccountsModel::Role::Account).value<MyMoneyInstitution>();
```

#### AUTO 


```{c}
auto result = shareValue().abs();
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::baseModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto activityCombo = dynamic_cast<KMyMoneyActivityCombo*>(haveWidget("activity"));
```

#### AUTO 


```{c}
const auto& stPrice
```

#### AUTO 


```{c}
const auto accountId = action->data().toString();
```

#### AUTO 


```{c}
auto it_nc = d->m_forecastAccounts.constBegin();
```

#### AUTO 


```{c}
const auto oldKey = oldTransaction.uniqueSortKey();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            Q_D(KReportsView);
            d->ui.m_filterContainer->hide();
            d->ui.m_searchWidget->clear();
            d->ui.m_reportTabWidget->setFocus();
        }
```

#### AUTO 


```{c}
auto idx = MyMoneyFile::baseModel()->mapToBaseSource(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneySplit& split : d->m_splits)
        changed |= split.replaceId(newId, oldId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*transaction).splits()) {
        const JournalEntry journalEntry(QString("%1-%2").arg(key, split.id()), transaction, split);
        const auto newIdx = index(startRow, 0);
        static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer())->dataRef() = journalEntry;
        if (m_idToItemMapper) {
            m_idToItemMapper->insert(journalEntry.id(), static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer()));
        }
        ++startRow;
    }
```

#### AUTO 


```{c}
auto sec = d->currentSecurity();
```

#### AUTO 


```{c}
const auto split(journalEntry.split());
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
    }
```

#### AUTO 


```{c}
auto transaction = after.sharedtransactionPtr();
```

#### AUTO 


```{c}
const auto idx = list.at(row);
```

#### RANGE FOR STATEMENT 


```{c}
for(QJsonValue entry: editorsArray) {
            if (!entry.toObject()["OnlineTaskIds"].isNull()) {
                list.append(onlineJobAdministration::onlineJobEditOffer{
                    data.fileName(),
                    KPluginMetaData::readTranslatedString(entry.toObject(), "Name")
                });
            }
        }
```

#### AUTO 


```{c}
const auto  liabilityValue = data(liabilityList.front(), AccountsModel::AccountTotalValueRole);
```

#### AUTO 


```{c}
auto menu = dynamic_cast<QMenu*>(w)
```

#### AUTO 


```{c}
auto it_account = accts.constBegin();
```

#### AUTO 


```{c}
auto dlg = new KTagReassignDlg(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sec : securityList) {
        secBySymbol[sec.tradingSymbol()] = sec;
        secByName[sec.name()] = sec;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : transactionList) {
            QString defaultAction;
            QList<MyMoneySplit> splits = transaction.splits();
            QStringList accounts;

            // check if base commodity is set. if not, set baseCurrency
            if (transaction.commodity().isEmpty()) {
                qDebug() << Q_FUNC_INFO << " " << transaction.id() << " has no base currency";
                transaction.setCommodity(file->baseCurrency().id());
                file->modifyTransaction(transaction);
            }

            bool isLoan = false;
            // Determine default action
            if (transaction.splitCount() == 2) {
                // check for transfer
                int accountCount = 0;
                MyMoneyMoney val;
                foreach (const auto split, splits) {
                    auto acc = file->account(split.accountId());
                    if (acc.accountGroup() == eMyMoney::Account::Type::Asset //
                            || acc.accountGroup() == eMyMoney::Account::Type::Liability) {
                        val = split.value();
                        accountCount++;
                        if (acc.accountType() == eMyMoney::Account::Type::Loan //
                                || acc.accountType() == eMyMoney::Account::Type::AssetLoan)
                            isLoan = true;
                    } else
                        break;
                }
                if (accountCount == 2) {
                    if (isLoan)
                        defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Amortization);
                    else
                        defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer);
                } else {
                    if (val.isNegative())
                        defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal);
                    else
                        defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit);
                }
            }

            isLoan = false;
            foreach (const auto split, splits) {
                auto acc = file->account(split.accountId());
                MyMoneyMoney val = split.value();
                if (acc.accountGroup() == eMyMoney::Account::Type::Asset
                        || acc.accountGroup() == eMyMoney::Account::Type::Liability) {
                    if (!val.isPositive()) {
                        defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal);
                        break;
                    } else {
                        defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit);
                        break;
                    }
                }
            }

#if 0
            // Check for correct actions in transactions referencing credit cards
            bool needModify = false;
            // The action fields are actually not used anymore in the ledger view logic
            // so we might as well skip this whole thing here!
            for (it_s = splits.begin(); needModify == false && it_s != splits.end(); ++it_s) {
                auto acc = file->account((*it_s).accountId());
                MyMoneyMoney val = (*it_s).value();
                if (acc.accountType() == Account::Type::CreditCard) {
                    if (val < 0 && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal) && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer))
                        needModify = true;
                    if (val >= 0 && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit) && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer))
                        needModify = true;
                }
            }

            // (Ace) Extended the #endif down to cover this conditional, because as-written
            // it will ALWAYS be skipped.

            if (needModify == true) {
                for (it_s = splits.begin(); it_s != splits.end(); ++it_s) {
                    (*it_s).setAction(defaultAction);
                    transaction.modifySplit(*it_s);
                    file->modifyTransaction(transaction);
                }
                splits = transaction.splits();    // update local copy
                qDebug("Fixed credit card assignment in %s", transaction.id().data());
            }
#endif

            // Check for correct assignment of ActionInterest in all splits
            // and check if there are any duplicates in this transactions
            for (auto& split : splits) {
                MyMoneyAccount splitAccount = file->account(split.accountId());
                if (!accounts.contains(split.accountId())) {
                    accounts << split.accountId();
                }
                // if this split references an interest account, the action
                // must be of type ActionInterest
                if (interestAccounts.contains(split.accountId())) {
                    if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
                        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
                        split.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
                        transaction.modifySplit(split);
                        file->modifyTransaction(transaction);
                        qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
                    }
                    // if it does not reference an interest account, it must not be
                    // of type ActionInterest
                } else {
                    if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
                        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
                        split.setAction(defaultAction);
                        transaction.modifySplit(split);
                        file->modifyTransaction(transaction);
                        qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
                    }
                }

                // check that for splits referencing an account that has
                // the same currency as the transactions commodity the value
                // and shares field are the same.
                if (transaction.commodity() == splitAccount.currencyId()
                        && split.value() != split.shares()) {
                    qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
                    split.setShares(split.value());
                    transaction.modifySplit(split);
                    file->modifyTransaction(transaction);
                }

                // fix the shares and values to have the correct fraction
                if (!splitAccount.isInvest()) {
                    try {
                        int fract = splitAccount.fraction();
                        if (split.shares() != split.shares().convert(fract)) {
                            qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
                            split.setShares(split.shares().convert(fract));
                            split.setValue(split.value().convert(fract));
                            transaction.modifySplit(split);
                            file->modifyTransaction(transaction);
                        }
                    } catch (const MyMoneyException &) {
                        qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
                    }
                }
            }

            ++cnt;
            if (!(cnt % 10))
                q->slotStatusProgressBar(cnt);
        }
```

#### AUTO 


```{c}
auto cashflow = new KMyMoneyCashFlowCombo(d->m_account.accountGroup(), nullptr);
```

#### AUTO 


```{c}
auto cfgColumns = cfgGroup.readEntry("ColumnsSelection", QList<int>());
```

#### AUTO 


```{c}
auto environment = QProcessEnvironment::systemEnvironment();
```

#### AUTO 


```{c}
const auto jobIdx = indexes.first();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
    Q_D(KPayeesView);
    emit requestCustomContextMenu(eMenu::Menu::Transaction, d->ui->m_register->mapToGlobal(pos));
  }
```

#### AUTO 


```{c}
auto baseModel = MyMoneyFile::instance()->accountsModel();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        Q_D(KPayeesView);
        updateActions(d->m_selections);
        emit requestCustomContextMenu(eMenu::Menu::Payee, d->ui->m_payees->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto journalDelegate = new JournalDelegate(q);
```

#### AUTO 


```{c}
const auto startIdx = firstIndexById(after.transaction().id());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& text) {
            Q_D(KReportsView);
            const auto columns = d->ui.m_tocTreeWidget->columnCount();
            for (auto i = 0; i < d->ui.m_tocTreeWidget->topLevelItemCount(); ++i) {
                const auto toplevelItem = d->ui.m_tocTreeWidget->topLevelItem(i);
                bool hideTopLevel = true;
                for (auto j = 0; j < toplevelItem->childCount(); ++j) {
                    const auto reportItem = toplevelItem->child(j);
                    if (text.isEmpty()) {
                        reportItem->setHidden(false);
                        hideTopLevel = false;
                    } else {
                        reportItem->setHidden(true);
                        for (auto column = 0; column < columns; ++column) {
                            if (reportItem->text(column).contains(text, Qt::CaseInsensitive)) {
                                reportItem->setHidden(false);
                                hideTopLevel = false;
                                break;
                            }
                        }
                    }
                }
                toplevelItem->setHidden(hideTopLevel);
            }

            if (text.isEmpty()) {
                if (!d->expandStatesBeforeSearch.isEmpty()) {
                    d->restoreTocExpandState(d->expandStatesBeforeSearch);
                    d->expandStatesBeforeSearch.clear();
                }
            } else {
                if (d->expandStatesBeforeSearch.isEmpty()) {
                    d->expandStatesBeforeSearch = d->saveTocExpandState();
                }
                // show groups with matching reports as expanded
                for (auto i = 0; i < d->ui.m_tocTreeWidget->topLevelItemCount(); ++i) {
                    const auto toplevelItem = d->ui.m_tocTreeWidget->topLevelItem(i);
                    toplevelItem->setExpanded(!toplevelItem->isHidden());
                }
            }
        }
```

#### AUTO 


```{c}
auto feeAccountWidget = d->haveWidget<KMyMoneyCategory*>("fee-account");
```

#### AUTO 


```{c}
auto newname = i18n("Budget %1", date.year());
```

#### AUTO 


```{c}
const auto sec = currentSecurity();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : m_selections.selection(SelectedObjects::JournalEntry)) {
            const auto idx = file->journalModel()->indexById(journalEntryId);
            if (idx.data(eMyMoney::Model::TransactionIsImportedRole).toBool()) {
                if (toBeDeletedId.isEmpty()) {
                    toBeDeletedId = journalEntryId;
                } else {
                    // This is a second imported transaction, we still want to merge
                    remainingId = journalEntryId;
                }
            } else if (!idx.data(eMyMoney::Model::JournalSplitIsMatchedRole).toBool()) {
                if (remainingId.isEmpty()) {
                    remainingId = journalEntryId;
                } else {
                    toBeDeletedId = journalEntryId;
                }
            }
        }
```

#### AUTO 


```{c}
const auto& sourceTransaction = selectedSourceTransaction.transaction();
```

#### AUTO 


```{c}
const auto accounts = d->selections.selection(SelectedObjects::Account);
```

#### AUTO 


```{c}
auto profile = dynamic_cast<InvestmentProfile *>(m_profile);
```

#### AUTO 


```{c}
auto jobFlags = KIO::DefaultFlags | KIO::Overwrite;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (d->currentActivity) {
            d->stockSplit.setValue(d->currentActivity->valueAllShares().convert(d->transactionCurrency.smallestAccountFraction(), d->security.roundingMethod())
                                   * d->currentActivity->sharesFactor());
            if (d->currentActivity->type() != eMyMoney::Split::InvestmentTransactionType::SplitShares) {
                d->scheduleUpdateTotalAmount();
            }
            d->updateWidgetState();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint& pos) {
            Q_D(KInvestmentView);
            emit requestCustomContextMenu(eMenu::Menu::Security, d->ui->m_equitiesTree->viewport()->mapToGlobal(pos));
        }
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_categoryCol)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto model : specialJournalModels) {
        d->concatModel->addSourceModel(model);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& stock : stocksList) {
    if (!(KMyMoneyGlobalSettings::hideZeroBalanceEquities() && stock.balance().isZero()))
      d->loadInstitution(this, stock);
  }
```

#### AUTO 


```{c}
const auto id = query.value(0).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*it)->splits()) {
            const JournalEntry journalEntry(QString("%1-%2").arg(it.key(), split.id()), *it, split);
            const auto newIdx = index(row, 0);
            static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer())->dataRef() = journalEntry;
            if (m_idToItemMapper) {
                m_idToItemMapper->insert(journalEntry.id(), static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer()));
            }
            ++row;
        }
```

#### AUTO 


```{c}
auto acc = account(split.accountId());
```

#### AUTO 


```{c}
auto it_terms = 0;
```

#### AUTO 


```{c}
const auto lastUsedPostDate = KMyMoneySettings::lastUsedPostDate();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
                if (idx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
                    row = journalModel->mapFromBaseSource(model(), idx).row();
                    if (row != -1) {
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
        auto acc = d->accountsModel.itemById(split.accountId());
        if (!acc.id().isEmpty()) {
            if (acc.isInvest() && (split.investmentTransactionType() != eMyMoney::Split::InvestmentTransactionType::UnknownTransactionType)) {
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto institution = Models::instance()->institutionsModel()->itemByIndex(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : qAsConst(list)) {
        result[acc.id()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
    }
```

#### AUTO 


```{c}
const auto newIdx = index(row, 0);
```

#### AUTO 


```{c}
auto index = -1;
```

#### AUTO 


```{c}
auto visEColumns = d->m_equitiesProxyModel->getVisibleColumns();
```

#### AUTO 


```{c}
auto splits = document.createElement(d->getElName(Transaction::Element::Splits));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : list) {
            if (idx.data(eMyMoney::Model::SplitAccountIdRole).toString() == m_account.id()
                    && idx.data(eMyMoney::Model::JournalTransactionIdRole).toString().compare(transaction.id())) {
                WidgetHintFrame::show(ui->numberEdit, i18n("The check number <b>%1</b> has already been used in this account.", newNumber));
                rc = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
        itemCount += item.count();
    }
```

#### AUTO 


```{c}
const auto& comboBox
```

#### AUTO 


```{c}
const auto idx = sourceSplitModel->index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& it : actionShortcuts)
      aC->setDefaultShortcut(lutActions[it.first], it.second);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
            if (payeeInList(d->m_selectedPayees, split.payeeId())) {
              split.setPayeeId(payee_id);
              trans.modifySplit(split); // does not modify the list object 'splits'!
            }
          }
```

#### AUTO 


```{c}
const auto type = event->type();
```

#### AUTO 


```{c}
auto user3Button = new QPushButton;
```

#### AUTO 


```{c}
const auto hideFee = txt.isEmpty() || transactionTypesWithoutFee.contains(d->m_activity->type());
```

#### AUTO 


```{c}
auto t = dynamic_cast<KMyMoneyRegister::Transaction*>(focusItem())
```

#### AUTO 


```{c}
const auto leftModel = MyMoneyModelBase::baseModel(left);
```

#### AUTO 


```{c}
const auto account_name = QString::fromUtf8(data.account_name);
```

#### AUTO 


```{c}
const auto objId = baseIdx.data(eMyMoney::Model::IdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        adjustDetailColumn(viewport()->width());
    }
```

#### AUTO 


```{c}
const auto shares = s.shares().abs();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& current, const QModelIndex& previous) {
        Q_UNUSED(previous)
        Q_D(KPayeesView);
        d->m_selections.clearSelections(SelectedObjects::Transaction);
        d->m_selections.clearSelections(SelectedObjects::Account);
        d->m_selections.setSelection(SelectedObjects::Transaction, current.data(eMyMoney::Model::JournalTransactionIdRole).toString());
        d->m_selections.setSelection(SelectedObjects::Account, current.data(eMyMoney::Model::SplitAccountIdRole).toString());
        emit requestSelectionChange(d->m_selections);
    }
```

#### AUTO 


```{c}
const auto list = model->match(model->index(0, 0, parent->index()), AccountsModel::AccountIdRole, QVariant(accountId), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
auto i = (int)Transaction::Attribute::Name;
```

#### AUTO 


```{c}
const auto itemList = model->match(model->index(0, 0), Qt::UserRole, QVariant(securityId), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto it_t = list.first();
```

#### AUTO 


```{c}
const auto list = model->match(model->index(0, 0), (int)Role::ID, QVariant(institutionId), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
auto subaccountsStr = acc.accountList();
```

#### AUTO 


```{c}
auto creator = new payeeIdentifiers::nationalAccount();
```

#### AUTO 


```{c}
const auto nextChange(nextChangeExp.match(value("interest-nextchange")));
```

#### AUTO 


```{c}
auto institutionItem = static_cast<InstitutionsPrivate *>(d)->institutionItemFromId(this, institution->id());
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(_accId);
```

#### AUTO 


```{c}
const auto fontColor = KMyMoneySettings::schemeColor(accountValue.isNegative() ? SchemeColor::Negative : SchemeColor::Positive);
```

#### AUTO 


```{c}
auto interestAccountWidget = dynamic_cast<KMyMoneyCategory*>(haveWidget("interest-account"));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            query.bindValue(":id", obj.idString());
            query.bindValue(":iban", payeeIdentifier->electronicIban());
            const auto bic = payeeIdentifier->fullStoredBic();
            query.bindValue(":bic", (bic.isEmpty()) ? QVariant(QVariant::String) : bic);
            query.bindValue(":name", payeeIdentifier->ownerName());
            if (!query.exec()) { // krazy:exclude=crashy
                qWarning("Error while saving ibanbic data for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
                return false;
            }
            return true;
        }
```

#### AUTO 


```{c}
const auto defaultTabOrder = QStringList{
        QLatin1String("activityCombo"),
        QLatin1String("dateEdit"),
        QLatin1String("securityAccountCombo"),
        QLatin1String("sharesAmountEdit"),
        QLatin1String("securityAccountCombo"),
        QLatin1String("sharesAmountEdit"),
        QLatin1String("assetAccountCombo"),
        QLatin1String("priceAmountEdit"),
        QLatin1String("feesCombo"),
        QLatin1String("feesAmountEdit"),
        QLatin1String("interestCombo"),
        QLatin1String("interestAmountEdit"),
        QLatin1String("memoEdit"),
        QLatin1String("statusCombo"),
        QLatin1String("enterButton"),
        QLatin1String("cancelButton"),
    };
```

#### AUTO 


```{c}
auto accID = makeAccount("Easy", "123456789", MyMoneyAccount::Investment, QDate(2017, 8, 1), file->asset().id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : accounts)
      d->ui->accountsList->addTopLevelItem(new QTreeWidgetItem(QStringList{account.id,
                                                                    account.name,
                                                                    account.balance.formatMoney(QString(), 2)}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits)
    if (!d->m_accountList.contains(split.accountId()))
      throw MYMONEYEXCEPTION_CSTRING("bad account id");
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        d->executeContextMenu(pos);
    }
```

#### AUTO 


```{c}
auto header = QString(m_file.read(16));
```

#### AUTO 


```{c}
auto columns = d->m_columnSelector->columns();
```

#### AUTO 


```{c}
auto amountWidget = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["amount"])
```

#### AUTO 


```{c}
const auto baseModel = MyMoneyModelBase::baseModel(idx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
        if (split.id() == d->m_split.id()) {
            continue;
        }
        const auto rows = d->splitModel.rowCount();
        int row;
        for (row = 0; row < rows; ++row) {
            const QModelIndex index = d->splitModel.index(row, 0);
            if (index.data(eMyMoney::Model::IdRole).toString() == split.id()) {
                break;
            }
        }

        // if the split is not in the model, we get rid of it
        if (d->splitModel.rowCount() == row) {
            t.removeSplit(split);
        }
    }
```

#### AUTO 


```{c}
const auto count = items.count();
```

#### AUTO 


```{c}
const auto currencyId = (*it).transaction().commodity();
```

#### AUTO 


```{c}
auto requiredFields = new KMandatoryFieldGroup(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
          // create copy of transaction in current schedule
          auto trans = schedule.transaction();
          // create copy of lists of splits
          for (auto& split : trans.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); i++) {
              if (tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList);
            trans.modifySplit(split); // does not modify the list object 'splits'!
          } // for - Splits
          // store transaction in current schedule
          schedule.setTransaction(trans);
          file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
        }
```

#### AUTO 


```{c}
const auto &kpartgui = QStringLiteral("file_export_icalendar");
```

#### AUTO 


```{c}
auto appDir = appFullPath.left(lastDirSeparator + 1);
```

#### AUTO 


```{c}
auto number = dynamic_cast<KMyMoneyLineEdit*>(haveWidget("number"));
```

#### AUTO 


```{c}
auto nextDay = now.addDays(1);
```

#### AUTO 


```{c}
const auto testModel = model->baseModel(testIdx);
```

#### AUTO 


```{c}
const auto incomeList = match(index(0, 0),
                                AccountsModel::AccountIdRole,
                                MyMoneyFile::instance()->income().id(),
                                1,
                                Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
const auto lastIdx = index(rows - 1, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selected.indexes()) {
        d->m_selections.addSelection(SelectedObjects::Tag, idx.data(eMyMoney::Model::IdRole).toString());
    }
```

#### AUTO 


```{c}
auto payee5 = MyMoneyXmlContentHandler::readPayee(el);
```

#### AUTO 


```{c}
auto& plugins = ctnPlugins.standard;
```

#### AUTO 


```{c}
auto depositWidget = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["deposit"])
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemById(split.accountId());
```

#### AUTO 


```{c}
const auto childIndex = model->index(i, AccountsModel::Column::AccountName, index);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& from, const QModelIndex& to) {
            Q_D(KScheduledView);
            d->m_filterModel->invalidate();
        }
```

#### AUTO 


```{c}
auto caption = m_storageInfo.url.isEmpty() && m_myMoneyView && m_storageInfo.isOpened ? i18n("Untitled") : m_storageInfo.url.fileName();
```

#### AUTO 


```{c}
auto price = m_file->price(account.currencyId(), tradingCurrency.id());
```

#### AUTO 


```{c}
auto list = d->m_selectedTransactions;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& institution : institutionList)   // add all known institutions as top-level nodes
    d->addInstitutionItem(this, institution);
```

#### AUTO 


```{c}
const auto accountId
```

#### AUTO 


```{c}
auto newName(QFileDialog::getSaveFileName(this, QString(), QString(), QLatin1String("*.QIF")));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : splits) {
      split.clearId();
      d->m_transaction.addSplit(split);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto split : d->m_splits) {
    ids.unite(split.referencedObjects());
  }
```

#### AUTO 


```{c}
auto address = document.createElement(elementName(Element::Institution::Address));
```

#### AUTO 


```{c}
const auto warnLevel = MyMoneyUtils::transactionWarnLevel(selections.selection(SelectedObjects::JournalEntry));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : balanceChanges) {
    // if we notify about balance change we don't need to notify about value change
    // for the same account since a balance change implies a value change
    d->m_valueChangedSet.remove(id);
    emit balanceChanged(account(id));
  }
```

#### AUTO 


```{c}
const auto id = index.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->ui.m_reportTabWidget->widget(1))
```

#### AUTO 


```{c}
auto sec = MyMoneyFile::instance()->security(securityId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& button : toolButtons) {
        button->setIcon(Icons::get(Icons::Icon::EditClear));
    }
```

#### AUTO 


```{c}
auto accCol = d->m_mdlColumns->indexOf(eAccountsModel::Column::Account);
```

#### AUTO 


```{c}
auto acc = file->account(*it_n);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& institution : qAsConst(list)) {
        names << institution.name();
        if (institution.name() == name) {
            d->ui->ibanEdit->setEnabled(true);
            d->ui->accountNoEdit->setEnabled(true);
            d->ui->m_bicValue->setText(institution.value("bic"));
            search = name;
        }
    }
```

#### AUTO 


```{c}
const auto& b = splits.at(1).id().compare(split.id()) == 0 ? acc : file->account(splits.at(1).accountId());
```

#### AUTO 


```{c}
auto baseIdx = baseModel->indexById(id);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt)
            {
                if (txt.isEmpty()) {
                    d->ui->accountCombo->setSelected(QString());
                }
            }
```

#### AUTO 


```{c}
auto cat = file->account(s.accountId());
```

#### AUTO 


```{c}
auto escapeChar = [&](const QChar& d, const QChar& c) {
        if (c == d) {
            rc.append(QLatin1Char('\\'));
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&] { checkData(); }
```

#### AUTO 


```{c}
const auto rowCount = model->rowCount(index);
```

#### AUTO 


```{c}
auto checkValidInput = [&]() {
        const auto idx = model->index(ui->tagCombo->currentIndex(), 0);
        const auto validInput = (!idx.data(eMyMoney::Model::IdRole).toString().isEmpty() || ui->removeCheckBox->isChecked());
        ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(validInput);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt)
            {
                if (txt.isEmpty()) {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
        auto accIdx = file->accountsModel()->indexById(splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString());
        const auto accountGroup = accIdx.data(eMyMoney::Model::AccountGroupRole).value<eMyMoney::Account::Type>();
        if (splitIdx.row() == idx.row()) {
            security = file->security(accIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString());
        } else if (accountGroup == eMyMoney::Account::Type::Expense) {
            feeSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
        } else if (accountGroup == eMyMoney::Account::Type::Income) {
            interestSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
        } else {
            if (!assetAccountSplitIdx.isValid()) { // first asset Account should be our requested brokerage account
                assetAccountSplitIdx = splitIdx;
            } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isNegative()) { // the rest (if present) is handled as fee or interest
                feeSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
            } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isPositive()) {
                interestSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
            }
        }
    }
```

#### AUTO 


```{c}
const auto account = m_schedule.account();
```

#### AUTO 


```{c}
auto i = (int)MyMoneyTransaction::Attribute::Name;
```

#### AUTO 


```{c}
auto i = (int)Report::Element::Payee;
```

#### AUTO 


```{c}
const auto journalDelegate = qobject_cast<const JournalDelegate*>(delegate);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& institution : list) {
    const auto idx = index(row, 0);
    static_cast<TreeItem<MyMoneyInstitution>*>(idx.internalPointer())->dataRef() = institution;
    d->loadAccounts(idx, institution.accountList());
    ++row;
  }
```

#### AUTO 


```{c}
const auto rowTypeFromXML = stringToRowType(node.attribute(attributeName(Attribute::Report::RowType)));
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Split>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto newIdx = model->emptySplit();
```

#### LAMBDA EXPRESSION 


```{c}
[=] (bool) {delete m_currentPrinter; m_currentPrinter = nullptr;}
```

#### AUTO 


```{c}
auto tab = static_cast<eView::Investment::Tab>(d->ui->m_tab->currentIndex());
```

#### AUTO 


```{c}
const auto list = model()->match(model()->index(startRow, 0), eMyMoney::Model::Roles::IdRole,
                                     QVariant(id),
                                     1,
                                     Qt::MatchFlags(Qt::MatchExactly | Qt::MatchWrap | Qt::MatchRecursive));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accStr : account.accountList()) {
      const auto acc = d->m_file->account(accStr);

      auto item = new QStandardItem(acc.name());
      accountsItem->appendRow(item);
      item->setEditable(false);
      auto subaccountsStr = acc.accountList();
      // filter out stocks with zero balance if requested by user
      for (auto subaccStr = subaccountsStr.begin(); subaccStr != subaccountsStr.end();) {
        const auto subacc = d->m_file->account(*subaccStr);
        if (subacc.isInvest() && KMyMoneySettings::hideZeroBalanceEquities() && subacc.balance().isZero())
          subaccStr = subaccountsStr.erase(subaccStr);
        else
          ++subaccStr;
      }

      // adding subaccounts (e.g. stocks under given investment account) belonging to given account
      d->loadSubaccounts(item, favoriteAccountsItem, subaccountsStr);
      const auto row = item->row();
      d->setAccountData(accountsItem, row, acc, d->m_columns);
      d->loadPreferredAccount(acc, accountsItem, row, favoriteAccountsItem);
    }
```

#### AUTO 


```{c}
auto balance = MyMoneyFile::instance()->balance(d->m_reconciliationAccount.id(), d->m_endingBalanceDlg->statementDate());
```

#### AUTO 


```{c}
auto iter = costCenters.constBegin();
```

#### AUTO 


```{c}
const auto account = accountIdx.data(eMyMoney::Model::Roles::AccountFullNameRole).toString();
```

#### AUTO 


```{c}
const auto colTotalValue = m_columns.indexOf(Columns::TotalValue);
```

#### AUTO 


```{c}
auto intAmount = dynamic_cast<KMyMoneyEdit*>(haveWidget("interest-amount"))
```

#### AUTO 


```{c}
auto i = (int)onlineJob::Element::OnlineTask;
```

#### AUTO 


```{c}
const auto payee
```

#### AUTO 


```{c}
auto type = static_cast<eMyMoney::Security>(field("securityType").toInt());
```

#### AUTO 


```{c}
const auto idx = d->filterModel->index(0, 0);
```

#### AUTO 


```{c}
const auto idx = tradingCurrencyIndex(security);
```

#### AUTO 


```{c}
const auto incomeList = match(index(0, 0),
                                (int)Role::ID,
                                MyMoneyFile::instance()->income().id(),
                                1,
                                Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
const auto action = button->defaultAction();
```

#### AUTO 


```{c}
auto it = params.constBegin();
```

#### AUTO 


```{c}
const auto& transactionId
```

#### AUTO 


```{c}
auto validator = new AmountValidator(q);
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<KMyMoneyDateInput*>(d->m_editor->haveWidget("postdate"))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& onlineTaskIid : plugin->availableJobs(account.id())) {
          if (m_onlineTasks.contains(onlineTaskIid)) {
            return true;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : accounts) {
    const auto sacc = account(acc);
    if (sacc.name().compare(name) == 0)
      return sacc;
  }
```

#### AUTO 


```{c}
auto val = shares.abs();
```

#### AUTO 


```{c}
auto selectedProfile = ui->qifProfileCombo->itemText(idx);
```

#### AUTO 


```{c}
auto counterAccount = index.data(eMyMoney::Model::Roles::TransactionCounterAccountRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& index : indexList) {
    sortedList[index.row()] = index.row();
  }
```

#### AUTO 


```{c}
auto journalModel = MyMoneyFile::instance()->journalModel();
```

#### AUTO 


```{c}
const auto idx = MyMoneyFile::instance()->accountsModel()->indexById(selections.firstSelection(SelectedObjects::Account));
```

#### AUTO 


```{c}
auto commodityId = m_transaction.commodity();
```

#### AUTO 


```{c}
const auto item(exp.match(*it_s));
```

#### AUTO 


```{c}
auto tabOrderWidget = static_cast<TabOrderEditorInterface*>(editor->qt_metacast("TabOrderEditorInterface"));
```

#### AUTO 


```{c}
auto const gotoAccount = pActions[eMenu::Action::GoToAccount];
```

#### AUTO 


```{c}
const auto currency = file->currency(account.currencyId());
```

#### AUTO 


```{c}
const auto& transaction
```

#### AUTO 


```{c}
const auto payeesView = static_cast<KPayeesView*>(viewBases[view]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : qAsConst(balanceChangedSet)) {
            balances.insert(accountId, balanceCache.value(accountId));
            emit q->balanceChanged(accountId);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : list) {
        for (const auto& split : transaction.splits()) {
            if (!split.shares().isZero()) {
                if (acc.id() == split.accountId()) netIncome += split.value();
            }
        }
    }
```

#### AUTO 


```{c}
const auto accountGroup = static_cast<eMyMoney::Account::Type>(idx.data(eMyMoney::Model::AccountGroupRole).toInt());
```

#### AUTO 


```{c}
auto adjustDateSection = [&](int offset) {
        switch(d->m_dateEdit->currentSection()) {
        case QDateTimeEdit::DaySection:
            slotDateChosen(d->m_date.addDays(offset));
            break;
        case QDateTimeEdit::MonthSection:
            slotDateChosen(d->m_date.addMonths(offset));
            break;
        case QDateTimeEdit::YearSection:
            slotDateChosen(d->m_date.addYears(offset));
            break;
        default:
            break;
        }
    };
```

#### AUTO 


```{c}
const auto rows = d->model->rowCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : d->ui->m_tagsList->selectionModel()->selectedIndexes()) {
    baseIdx = model->mapToBaseSource(idx);
    const auto tag = model->itemByIndex(baseIdx);
    if (!tag.id().isEmpty()) {
      selectedTags.append(tag);
    }
  }
```

#### AUTO 


```{c}
const auto idx = ui->frequencyEdit->model()->index(row, 0);
```

#### AUTO 


```{c}
auto matcher = appExp.match(appId);
```

#### AUTO 


```{c}
auto postDate = dynamic_cast<KMyMoneyDateInput*>(d->m_editWidgets["postdate"]);
```

#### AUTO 


```{c}
const auto entry = model->itemByIndex(idx);
```

#### AUTO 


```{c}
auto thisId = id;
```

#### AUTO 


```{c}
const auto categoryId = splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @note add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      case eMyMoney::File::Object::Currency:
      case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
      case eMyMoney::File::Object::Transaction:
      case eMyMoney::File::Object::Price:
      case eMyMoney::File::Object::Parameter:
      case eMyMoney::File::Object::OnlineJob:
      case eMyMoney::File::Object::Report:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
auto logFile = QString::fromLatin1("%1/kmm-statement-%2.txt").arg(KMyMoneySettings::logPath(),
                       QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyy-MM-dd hh-mm-ss.zzz")));
```

#### AUTO 


```{c}
auto mult = 1;
```

#### AUTO 


```{c}
const auto cond2 = cond1 && MyMoneyFile::instance()->security(price.from()).isCurrency();
```

#### AUTO 


```{c}
auto accCol = m_mdlColumns->indexOf(AccountsModel::Account);
```

#### AUTO 


```{c}
const auto rows = splitModel->rowCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selected.indexes()) {
            if (idx.row() != lastRow) {
                lastRow = idx.row();
                selectedRows += lastRow;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : alwaysEnabled) {
            lutActions[action]->setEnabled(true);
        }
```

#### AUTO 


```{c}
const auto basemodel = MyMoneyFile::instance()->schedulesModel();
```

#### AUTO 


```{c}
auto cashflow = dynamic_cast<KMyMoneyCashFlowCombo*>(d->m_editWidgets["cashflow"]);
```

#### AUTO 


```{c}
auto it_p = d->m_onlinePlugins->constEnd();
```

#### AUTO 


```{c}
const auto idx = MyMoneyFile::baseModel()->mapFromBaseSource(m_renameProxyModel, baseIdx);
```

#### AUTO 


```{c}
auto transaction = readTransaction(nodeList.item(0).toElement(), false);
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(_originAccount);
```

#### AUTO 


```{c}
const auto institutionsModel = MyMoneyFile::instance()->institutionsModel();
```

#### AUTO 


```{c}
const auto matchingItem(exp.match(item->data(0, static_cast<int>(eWidgets::Selector::Role::Key)).toString().mid(1)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits)
    val += split.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selection) {
    const auto baseIdx = baseModel->mapToBaseSource(idx);
    const auto tag = baseModel->itemByIndex(baseIdx);
    if (!tag.id().isEmpty()) {
      tags.append(tag);
    }
  }
```

#### AUTO 


```{c}
const auto taskIid = idx.data(eMyMoney::Model::OnlineJobTaskIidRole).toString();
```

#### AUTO 


```{c}
const auto acc = dynamic_cast<const MyMoneyAccount * const>(obj);
```

#### AUTO 


```{c}
auto t = dynamic_cast<KMyMoneyRegister::Transaction*>(item)
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        checkData();
    }
```

#### AUTO 


```{c}
const auto idx = index.model()->index(row, 0);
```

#### AUTO 


```{c}
const auto count = m_file->securitiesModel()->processItems(&writer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : m_plugins.storage) {
              if (plugin->formatName().compare(QLatin1String("SQL")) == 0) {
                  rc = plugin->save(url);
                  pluginFound = true;
                  break;
                }
            }
```

#### AUTO 


```{c}
const auto prec = MyMoneyMoney::denomToPrec(file->security(securityID).pricePrecision());
```

#### AUTO 


```{c}
const auto valInstitution = childrenTotalValue(itInstitution, true);
```

#### AUTO 


```{c}
const auto baseIdx = model->indexById(tagId);
```

#### AUTO 


```{c}
auto plugins = findPlugins("kmymoney_plugins/onlinetasks", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
    });
```

#### AUTO 


```{c}
const auto accountType = static_cast<eMyMoney::Account::Type>(accountTypeValue.toInt());
```

#### AUTO 


```{c}
auto shareEdit = d->haveWidget<AmountEdit>("sharesAmountEdit")
```

#### AUTO 


```{c}
const auto backends = d->backendsWatcher.result();
```

#### AUTO 


```{c}
const auto filterString = QString::fromLatin1("%1%2%3").arg(completionStr).arg(QRegularExpression::escape(txt)).arg(completionStr);
```

#### CONST EXPRESSION 


```{c}
static constexpr char recoveryKeyId[] = "0xD2B08440";
```

#### AUTO 


```{c}
auto sharesWidget = dynamic_cast<KMyMoneyEdit*>(haveWidget("shares"));
```

#### AUTO 


```{c}
auto sign = bNegative ? QString::fromLatin1("-") : QString();
```

#### AUTO 


```{c}
const auto budgetAccount = d->m_budget.account(account.id());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto tag : qAsConst(m_tagLabelList)) {
      tags << tag->id();
    }
```

#### AUTO 


```{c}
auto tabbar = dynamic_cast<KMyMoneyTransactionForm::TabBar*>(haveWidget("tabbar"));
```

#### AUTO 


```{c}
const auto list = m_storage->onlineJobList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
    itemCount += item.count();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : m_plugins.storage) {
      if (plugin->formatName().compare(QLatin1String("SQL")) == 0) {
        rc = plugin->open(pStorage, url);
        pluginFound = true;
        break;
      }
    }
```

#### AUTO 


```{c}
const auto commodity = file->security(transaction.commodity());
```

#### AUTO 


```{c}
auto security = MyMoneyFile::instance()->security(d->currentEquity().currencyId());
```

#### AUTO 


```{c}
const auto tab = static_cast<eView::Investment::Tab>(index);
```

#### AUTO 


```{c}
auto dontLeavePage = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : qAsConst(fullBalanceRecalc)) {
                balanceCache[accountId] = MyMoneyMoney();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotFindTransaction(); }
```

#### AUTO 


```{c}
const auto dispIndex = index(idx.row(), JournalModel::Column::Balance);
```

#### AUTO 


```{c}
auto IData = qobject_cast<DataPlugin *>(plugin);
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("ofximporter");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : accountsList) {  // add account nodes under institution nodes...
    if (account.isInvest())                     // ...but wait with stocks until investment accounts appear
      stocksList.append(account);
    else
      d->loadInstitution(this, account);
  }
```

#### AUTO 


```{c}
auto i = (int)MyMoneySecurity::Attribute::Name;
```

#### AUTO 


```{c}
auto visSColumns = d->m_securitiesProxyModel->getVisibleColumns();
```

#### AUTO 


```{c}
auto end = costCenters.constEnd();
```

#### AUTO 


```{c}
auto htmlPart = new QTextDocument();
```

#### AUTO 


```{c}
auto secondAccName = filteredAccounts.at(i + 1).name();
```

#### AUTO 


```{c}
const auto key(keyExp.match(m_masterKeyCombo->currentText()));
```

#### AUTO 


```{c}
const auto onlineQuotesPage = new KSettingsOnlineQuotes();
```

#### AUTO 


```{c}
const auto accountID = childIdx.data(eMyMoney::Model::Roles::IdRole).toString();
```

#### AUTO 


```{c}
auto contextmenu = new QMenu(this);
```

#### AUTO 


```{c}
const auto& price = MyMoneyFile::instance()->price(security.id(), currency.id());
```

#### CONST EXPRESSION 


```{c}
static constexpr char recoveryKeyId2[] = "59B0F826D2B08440";
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
        if ((split.accountId() == taxId) || split.accountId() == categoryId) {
            splitModel.appendSplit(split);
        }
    }
```

#### AUTO 


```{c}
auto item = d->ui->lvEquityList->invisibleRootItem()->child(0);
```

#### AUTO 


```{c}
auto bindValuesToQuery = [&]() {
            auto value = task.value().toString();
            if (value.isEmpty()) {
                value = QStringLiteral("0");
            }
            query.bindValue(":id", id);
            query.bindValue(":originAccount", task.responsibleAccount());
            query.bindValue(":value", value);
            query.bindValue(":purpose", task.purpose());
            query.bindValue(":endToEndReference", (task.endToEndReference().isEmpty()) ? QVariant() : QVariant::fromValue(task.endToEndReference()));
            query.bindValue(":beneficiaryName", task.beneficiaryTyped().ownerName());
            query.bindValue(":beneficiaryIban", task.beneficiaryTyped().electronicIban());
            query.bindValue(":beneficiaryBic", (task.beneficiaryTyped().storedBic().isEmpty()) ? QVariant() : QVariant::fromValue(task.beneficiaryTyped().storedBic()));
            query.bindValue(":textKey", task.textKey());
            query.bindValue(":subTextKey", task.subTextKey());
        };
```

#### AUTO 


```{c}
const auto children = ui->m_accountTree->model()->rowCount(index);
```

#### AUTO 


```{c}
const auto yOffset(lineHeight * lineCount);
```

#### AUTO 


```{c}
const auto sec = file->security(acc.currencyId());
```

#### AUTO 


```{c}
const auto& onlineSettingsKvpValue = (*it_a).onlineBankingSettings().value(key);
```

#### AUTO 


```{c}
const auto childNode = node->child(i, (int)Column::Account);
```

#### AUTO 


```{c}
const auto& changes = d->m_changeSet;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
    d->m_selections.addSelection(SelectedObjects::OnlineJob, idx.data(eMyMoney::Model::IdRole).toString());
  }
```

#### AUTO 


```{c}
auto dlg = new KSettingsKMyMoney(this, "KMyMoney-Settings", KMyMoneySettings::self());
```

#### AUTO 


```{c}
auto msg =
        i18np("Do you really want to delete the selected transaction?",
            "Do you really want to delete all %1 selected transactions?",
            d->m_selections.selection(SelectedObjects::JournalEntry).count());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto split : selectedTransaction.transaction().splits()) {
          const auto id = split.accountId();
          const auto acc = MyMoneyFile::instance()->account(id);
          if (acc.isClosed()) {
            closedAccount = acc.name();
            // we're done
            rc = false;
            break;
          }
        }
```

#### AUTO 


```{c}
const auto journalEntry = static_cast<TreeItem<JournalEntry>*>(index(row, 0).internalPointer())->constDataRef();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
              // if the split is assigned to one of the selected payees, we need to modify it
              if (split.isMatched()) {
                auto tm = split.matchedTransaction();
                for (auto& sm : tm.splits()) {
                  if (payeeInList(list , sm.payeeId())) {
                    sm.setPayeeId(payee_id); // first modify payee in current split
                    // then modify the split in our local copy of the transaction list
                    tm.modifySplit(sm); // this does not modify the list object 'splits'!
                  }
                }
                split.addMatch(tm);
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
              if (payeeInList(list, split.payeeId())) {
                split.setPayeeId(payee_id); // first modify payee in current split
                // then modify the split in our local copy of the transaction list
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : acc.accountList()) {
    auto accountToMove = d->accountsModel.itemById(accountId);
    reparentAccount(accountToMove, newParent);
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, File::Object::Account, accountToMove.id());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : journalEntryIds) {
                const auto journalEntry = journalModel->itemById(journalEntryId);
                auto sp = journalEntry.split();

                // skip the ones that are not marked cleared
                if (sp.reconcileFlag() != eMyMoney::Split::State::Cleared)
                    continue;

                auto t = journalEntry.transaction();
                sp.setReconcileFlag(eMyMoney::Split::State::Reconciled);
                sp.setReconcileDate(endingBalanceDlg->statementDate());
                t.modifySplit(sp);

                // update the engine ...
                file->modifyTransaction(t);

                // ... and the list
                reconciledJournalEntryIds.append(journalEntryId);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& button : m_buttons) {
            if (button->isDown()) {
                createPayee();
                return;
            }
        }
```

#### AUTO 


```{c}
const auto rightModel = model->baseModel(right);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto category : categories) {
    MyMoneyAccount account;
    QString accountName;
    int displayOrder;

    switch (category) {
      case Account::Type::Asset:
        // Asset accounts
        account = d->m_file->asset();
        accountName = i18n("Asset accounts");
        displayOrder = 1;
        break;
      case Account::Type::Liability:
        // Liability accounts
        account = d->m_file->liability();
        accountName = i18n("Liability accounts");
        displayOrder = 2;
        break;
      case Account::Type::Income:
        // Income categories
        account = d->m_file->income();
        accountName = i18n("Income categories");
        displayOrder = 3;
        break;
      case Account::Type::Expense:
        // Expense categories
        account = d->m_file->expense();
        accountName = i18n("Expense categories");
        displayOrder = 4;
        break;
      case Account::Type::Equity:
        // Equity accounts
        account = d->m_file->equity();
        accountName = i18n("Equity accounts");
        displayOrder = 5;
        break;
      default:
        continue;
    }

    auto accountsItem = new QStandardItem(accountName);
    accountsItem->setEditable(false);
    rootItem->appendRow(accountsItem);

    {
      QMap<int, QVariant> itemData;
      itemData[Qt::DisplayRole] = accountName;
      itemData[(int)Role::FullName] = itemData[Qt::EditRole] = QVariant::fromValue(MyMoneyFile::instance()->accountToCategory(account.id(), true));
      itemData[Qt::FontRole] = font;
      itemData[(int)Role::DisplayOrder] = displayOrder;
      this->setItemData(accountsItem->index(), itemData);
    }

    // adding accounts (specific bank/investment accounts) belonging to given accounts category
    for (const auto& accStr : account.accountList()) {
      const auto acc = d->m_file->account(accStr);

      auto item = new QStandardItem(acc.name());
      accountsItem->appendRow(item);
      item->setEditable(false);
      auto subaccountsStr = acc.accountList();
      // filter out stocks with zero balance if requested by user
      for (auto subaccStr = subaccountsStr.begin(); subaccStr != subaccountsStr.end();) {
        const auto subacc = d->m_file->account(*subaccStr);
        if (subacc.isInvest() && KMyMoneyGlobalSettings::hideZeroBalanceEquities() && subacc.balance().isZero())
          subaccStr = subaccountsStr.erase(subaccStr);
        else
          ++subaccStr;
      }

      // adding subaccounts (e.g. stocks under given investment account) belonging to given account
      d->loadSubaccounts(item, favoriteAccountsItem, subaccountsStr);
      const auto row = item->row();
      d->setAccountData(accountsItem, row, acc, d->m_columns);
      d->loadPreferredAccount(acc, accountsItem, row, favoriteAccountsItem);
    }

    d->setAccountData(rootItem, accountsItem->row(), account, d->m_columns);
  }
```

#### AUTO 


```{c}
const auto acc = file->accountsModel()->itemById(accountId);
```

#### AUTO 


```{c}
const auto idColumn = static_cast<Column>(retAction->objectName().toInt());
```

#### AUTO 


```{c}
const auto & splits = t.splits();
```

#### AUTO 


```{c}
auto idx = file->accountsModel()->indexById(d->m_idInvAcc);
```

#### AUTO 


```{c}
const auto idx = firstIndexById(newTransaction.id());
```

#### AUTO 


```{c}
const auto paymentType = model->index(idx, 0).data(eMyMoney::Model::ScheduleFrequencyRole).value<eMyMoney::Schedule::Occurrence>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& frame : d->frameList) {
        enabled &= !frame->isErroneous();
        if (!enabled) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto accountId : account.accountList()) {
    this->account(accountId);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& file : qAsConst(files)) {
                const auto url = QUrl::fromUserInput(QString("%1/%2").arg(dir.canonicalPath(), file));
                MyMoneyTemplate tmpl;
                if (d->loadTemplate(url, tmpl)) {
                    d->model->addItem(tmpl, parentIdx);
                }
            }
```

#### AUTO 


```{c}
const auto list = model()->match(model()->index(startRow, 0), eMyMoney::Model::Roles::IdRole,
                                   QVariant(id),
                                   1,
                                   Qt::MatchFlags(Qt::MatchExactly | Qt::MatchWrap | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto idx = d->m_splitModel->index(row, 0);
```

#### AUTO 


```{c}
const auto lineHeight = opt.fontMetrics.lineSpacing();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &standardPath : QStandardPaths::standardLocations(QStandardPaths::AppDataLocation))
          qWarning() << standardPath;
```

#### AUTO 


```{c}
const auto amount = d->haveVisibleWidget<AmountEdit>(amountWidget);
```

#### AUTO 


```{c}
auto ctBasicExpense = makeAccount(QString("Basic Expense"), MyMoneyAccount::Expense, MyMoneyMoney(), QDate(2016, 1, 1), acExpense);
```

#### AUTO 


```{c}
const auto appdir = environment.value(QLatin1String("APPDIR"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& startIdx, const QModelIndex& endIdx) {
        // in case any of the columns that have influence on the summary changes, update it
        if (startIdx.column() <= JournalModel::Column::Balance && endIdx.column() >= JournalModel::Column::Reconciliation) {
            updateSummaryInformation();
        }
    }
```

#### AUTO 


```{c}
const auto& it_s
```

#### AUTO 


```{c}
auto pairElement = document.createElement(elementName(Element::KVP::Pair));
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
        const auto idx = d->ui->securityAccountCombo->model()->index(index, 0);
        if (idx.isValid()) {
            const auto accountId = idx.data(eMyMoney::Model::IdRole).toString();
            const auto securityId = idx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
            try {
                const auto file = MyMoneyFile::instance();
                const auto sec = file->security(securityId);

                d->stockSplit.setAccountId(accountId);
                d->setSecurity(sec);

                d->scheduleUpdateTotalAmount();

            } catch (MyMoneyException& e) {
                qDebug() << "Problem to find securityId" << accountId << "or" << securityId << "in InvestTransactionEditor::securityAccountChanged";
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (auto i = 0; i < tagIdList.size(); ++i) {
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (!newTagId.isEmpty()) {
                                    if (tagIdList.indexOf(newTagId) == -1) {
                                        tagIdList.append(newTagId);
                                    }
                                }
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList);
                        trans.modifySplit(split); // does not modify the list object 'splits'!
                    }
```

#### AUTO 


```{c}
const auto idAcc = itAcc->data(Role::EquityID).toString();
```

#### AUTO 


```{c}
auto sec = currentSecurity();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString txt) {
        // for some reason, txt sometimes contains the filter expression only
        // e.g. "*.xml" and in some others it contains the full text with
        // the filter expression appended in parenthesis e.g.
        // "KMyMoney files (*.xml)". The following logic extracts the
        // filter and sets the default suffix based on it.
        QRegularExpression filter(QStringLiteral("\\*\\.(?<extension>[a-z\\.]+)"));
        const auto match = filter.match(txt);
        if (match.hasMatch()) {
            dlg->setDefaultSuffix(match.captured(QStringLiteral("extension")));
        } else {
            dlg->setDefaultSuffix(QString());
        }

    }
```

#### AUTO 


```{c}
const auto widgetCount = dlg_d->m_widgetList.count();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
    d->updateDynamicActions();
    emit requestCustomContextMenu(eMenu::Menu::Transaction, viewport()->mapToGlobal(pos));
  }
```

#### AUTO 


```{c}
auto i = (int)OnlineJob::Attribute::Send;
```

#### AUTO 


```{c}
const auto bottomRight = BudgetsModel::index(index.row(), columnCount()-1);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotDeleteTransaction(); }
```

#### AUTO 


```{c}
auto payment = dynamic_cast<AmountEdit*>(d->m_editWidgets["payment"]);
```

#### AUTO 


```{c}
auto transactionAdded = reader->anyTransactionAdded();
```

#### AUTO 


```{c}
auto w = dynamic_cast<KTagContainer*>(haveWidget("tag"));
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(ui->m_payeesView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& index : list)
    removeRow(index.row(), index.parent());
```

#### AUTO 


```{c}
auto acc = file->account((*it_s).accountId());
```

#### AUTO 


```{c}
auto se = dynamic_cast<StdTransactionEditor*>(editor.data());
```

#### AUTO 


```{c}
const auto viewportHeight = q->viewport()->height();
```

#### AUTO 


```{c}
auto priceTreeItem = new KPriceTreeItem(d->ui->m_priceList);
```

#### AUTO 


```{c}
const auto &kpartgui = QStringLiteral("file_export_csv");
```

#### AUTO 


```{c}
auto topItem = item(i);
```

#### AUTO 


```{c}
const auto childIndex = model->index(i, (int)eAccountsModel::Column::Account, index);
```

#### AUTO 


```{c}
const auto journalEntry = MyMoneyFile::instance()->journalModel()->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto& splits = filter.matchingSplits(transaction);
```

#### AUTO 


```{c}
auto security = MyMoneyFile::instance()->currency(account.currencyId());
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<AmountEdit*>(haveWidget("deposit"));
```

#### AUTO 


```{c}
const auto list = idx.model()->match(idx.model()->index(0, 0), eMyMoney::Model::JournalTransactionIdRole,
                                         idx.data(eMyMoney::Model::JournalTransactionIdRole),
                                         -1,                         // all splits
                                         Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : actions)
            pActions[action]->setEnabled(m_storageInfo.isOpened);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        setStateFilter(static_cast<LedgerFilter::State>(idx));
    }
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("csvimporter");
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KEnterScheduleDlg);
        d->m_extendedReturnCode = eDialogs::ScheduleResultCode::Skip;
        accept();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : list) {
            if (payee.id() == id) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : m_valueChanges)
    emit valueChanged(account(id));
```

#### AUTO 


```{c}
const auto& baseAccount
```

#### AUTO 


```{c}
auto amount = d->haveWidget<AmountEdit*>("price")
```

#### AUTO 


```{c}
auto b = !selections.isEmpty(SelectedObjects::Budget);
```

#### AUTO 


```{c}
auto multiplier = node.attribute(attributeName(Attribute::Schedule::OccurrenceMultiplier), "1").toInt();
```

#### AUTO 


```{c}
const auto accountId = splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : qAsConst(d->actions)) {
        actionCollection()->removeAction(action);
    }
```

#### AUTO 


```{c}
auto& split
```

#### AUTO 


```{c}
const auto index = model->index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : list) {
      if(idx.data(eMyMoney::Model::SplitAccountIdRole).toString() == m_account.id()
      && idx.data(eMyMoney::Model::JournalTransactionIdRole).toString().compare(transaction.id())) {
        WidgetHintFrame::show(ui->numberEdit, i18n("The check number <b>%1</b> has already been used in this account.", newNumber));
        rc = false;
        break;
      }
    }
```

#### AUTO 


```{c}
const auto accountId = idx.data(eMyMoney::Model::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
        // turn on the global changed flag for model based objects
        switch(change.objectType()) {
        /// @note add new models here
        case eMyMoney::File::Object::Payee:
        case eMyMoney::File::Object::CostCenter:
        case eMyMoney::File::Object::Schedule:
        case eMyMoney::File::Object::Tag:
        case eMyMoney::File::Object::Security:
        case eMyMoney::File::Object::Currency:
        case eMyMoney::File::Object::Budget:
        case eMyMoney::File::Object::Account:
        case eMyMoney::File::Object::Institution:
        case eMyMoney::File::Object::Transaction:
        case eMyMoney::File::Object::Price:
        case eMyMoney::File::Object::Parameter:
        case eMyMoney::File::Object::OnlineJob:
        case eMyMoney::File::Object::Report:
        case eMyMoney::File::Object::BaseCurrency:
            changed = true;
            break;
        default:
            break;
        }

        switch (change.notificationMode()) {
        case File::Mode::Remove:
            emit objectRemoved(change.objectType(), change.id());
            // if there is a balance change recorded for this account remove it since the account itself will be removed
            // this can happen when deleting categories that have transactions and the reassign category feature was used
            d->m_balanceChangedSet.remove(change.id());
            break;
        case File::Mode::Add:
            if (!removedObjects.contains(change.id())) {
                emit objectAdded(change.objectType(), change.id());
            }
            break;
        case File::Mode::Modify:
            if (!removedObjects.contains(change.id())) {
                emit objectModified(change.objectType(), change.id());
            }
            break;
        }
    }
```

#### AUTO 


```{c}
auto const mdlInstitutions = Models::instance()->institutionsModel();
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_numberCol)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto delegate : delegates) {
      JournalDelegate* journalDelegate = qobject_cast<JournalDelegate*>(delegate);
      if(journalDelegate) {
        journalDelegate->setSingleLineRole(role);
      }
    }
```

#### AUTO 


```{c}
const auto &plugin = getIbanBicData()
```

#### AUTO 


```{c}
auto result = KMessageBox::questionYesNoCancel(this,
                                                            i18n("For <b>%1</b> on <b>%2</b> price <b>%3</b> already exists.<br>"
                                                                 "Do you want to replace it with <b>%4</b>?",
                                                                 storedPrice.from(), storedPrice.date().toString(Qt::ISODate),
                                                                 QString().setNum(storedPrice.rate(storedPrice.to()).toDouble(), 'g', 10),
                                                                 QString().setNum((*it).m_amount.toDouble(), 'g', 10)),
                                                            i18n("Price Already Exists"));
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("ofximporter.rc");
```

#### RANGE FOR STATEMENT 


```{c}
for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
            if (plugin->availableJobs(account.id()).contains(task->taskName()))
              return true;
          }
```

#### AUTO 


```{c}
auto remaining = file->journalModel()->itemById(remainingId);
```

#### AUTO 


```{c}
const auto count = m_models->schedulesModel()->processItems(&writer);
```

#### AUTO 


```{c}
const auto parentAccount = static_cast<TreeItem<MyMoneyAccount>*>(parent.internalPointer())->constDataRef();
```

#### AUTO 


```{c}
auto value = file->balance(acc.id(), QDate::currentDate());
```

#### AUTO 


```{c}
auto dToday = QDate::currentDate();
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<kMyMoneyEdit*>(d->m_editWidgets["deposit"]);
```

#### AUTO 


```{c}
auto row = 0;
```

#### AUTO 


```{c}
const auto sTransactionMoveMenu = QStringLiteral("transaction_move_menu");
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& plugin : plugins.standard) {
        plugin->updateConfiguration();
    }
```

#### AUTO 


```{c}
auto view = d->viewBases.value(idView, nullptr);
```

#### AUTO 


```{c}
const auto it_attr = attributes.item(i).toAttr();
```

#### AUTO 


```{c}
auto regexp = cache->object(pattern);
```

#### AUTO 


```{c}
const auto shares = split.shares();
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemByIndex(baseIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : transaction.splits()) {
      if (!result.contains(split.accountId())) {
        result[split.accountId()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
      }
      const auto flag = split.reconcileFlag();
      switch(flag) {
        case eMyMoney::Split::State::NotReconciled:
        case eMyMoney::Split::State::Cleared:
        case eMyMoney::Split::State::Reconciled:
        case eMyMoney::Split::State::Frozen:
          result[split.accountId()][(int)flag]++;
          break;
        default:
          break;
      }

    }
```

#### AUTO 


```{c}
auto amountShares = -splitDialog->transactionAmount();
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const KPluginMetaData& data) {
    QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
    if (array.isArray())
      return (array.toVariant().toStringList().contains(name));
    return false;
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    invalidateFilter();
  }
```

#### AUTO 


```{c}
const auto splitId = s.id();
```

#### AUTO 


```{c}
auto drivers = ui->listDrivers->selectedItems();
```

#### AUTO 


```{c}
auto value = m_split.value(m_transaction.commodity(), acc.currencyId());
```

#### AUTO 


```{c}
auto exp(_exp);
```

#### AUTO 


```{c}
const auto idView = KMyMoneySettings::startLastViewSelected() ?
                        static_cast<View>(KMyMoneySettings::lastViewSelected()) :
                        View::Home;
```

#### AUTO 


```{c}
const auto canClose = (canCloseAccount(acc) == KAccountsViewPrivate::AccountCanClose) ? true : false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sec : securityList) {
    secBySymbol[sec.tradingSymbol()] = sec;
    secByName[sec.name()] = sec;
  }
```

#### AUTO 


```{c}
auto file = MyMoneyFile::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotStartReconciliation(); }
```

#### AUTO 


```{c}
const auto& backend
```

#### AUTO 


```{c}
const auto id = QString::fromLatin1("%1 %2").arg(pair.first, pair.second);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : selections.selection(SelectedObjects::JournalEntry)) {
                    const auto idx = file->journalModel()->indexById(journalEntryId);
                    const auto indeces = file->journalModel()->indexesByTransactionId(idx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
                    switch (indeces.count()) {
                    case 0:
                        break;
                    case 1:
                        singleSplitTransactions++;
                        break;
                    default:
                        multipleSplitTransactions++;
                        break;
                    }
                    if (multipleSplitTransactions > 1) {
                        break;
                    }
                }
```

#### AUTO 


```{c}
const auto filterString = QString::fromLatin1("%1%2%3").arg(completionStr).arg(QRegExp::escape(txt)).arg(completionStr);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString txt) { dlg->setDefaultSuffix(txt.mid(2)); }
```

#### AUTO 


```{c}
auto currency = file->baseCurrency().id();
```

#### AUTO 


```{c}
const auto settings = LedgerViewSettings::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString txt) {
    // for some reason, txt sometimes contains the filter expression only
    // e.g. "*.xml" and in some others it contains the full text with
    // the filter expression appended in parenthesis e.g.
    // "KMyMoney files (*.xml)". The following logic extracts the
    // filter and sets the default suffix based on it.
    QRegularExpression filter(QStringLiteral("\\*\\.(?<extension>[a-z\\.]+)"));
    const auto match = filter.match(txt);
    if (match.hasMatch()) {
      dlg->setDefaultSuffix(match.captured(QStringLiteral("extension")));
    } else {
      dlg->setDefaultSuffix(QString());
    }

  }
```

#### AUTO 


```{c}
auto ld_library_path = environment.value(QLatin1String("LD_LIBRARY_PATH"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            const auto journalEntry = file->journalModel()->itemById(journalEntryId);
            if (!journalEntry.id().isEmpty()) {
                const auto t = journalEntry.transaction();
                switch (t.splitCount()) {
                    case 0:
                        break;
                    case 1:
                        singleSplitTransactions++;
                        break;
                    default:
                        selectedSourceTransaction = t;
                        selectedSourceSplitId = journalEntry.split().id();
                        multipleSplitTransactions++;
                        break;
                }
            }
        }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyAccount::getAttrName(static_cast<MyMoneyAccount::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto& transaction = journalEntry.transaction();
```

#### AUTO 


```{c}
const auto assetId = asset->selectedItem();
```

#### AUTO 


```{c}
auto type = eMyMoney::Payee::MatchType::Disabled;
```

#### AUTO 


```{c}
const auto splitId = split.value(QLatin1String("kmm-match-split"));
```

#### AUTO 


```{c}
auto index = splitModel.index(0, 0);
```

#### AUTO 


```{c}
auto it_pr = d->m_priceList.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const pageInfo& info : pageInfos) {
    auto a = new QAction(this);
    // KActionCollection::addAction by name sets object name anyways,
    // so, as better alternative, set it here right from the start
    a->setObjectName(QString::fromLatin1("ShowPage%1").arg(QString::number(pageCount++)));
    a->setText(info.text);
    a->setData(static_cast<int>(info.view));
    connect(a, &QAction::triggered, [this, a] { showPageAndFocus(static_cast<View>(a->data().toUInt())); } );
    lutActions.insert(info.action, a);  // store QAction's pointer for later processing
    if (!info.shortcut.isEmpty())
      a->setShortcut(info.shortcut);
  }
```

#### AUTO 


```{c}
const auto acc = Models::instance()->accountsModel()->itemByIndex(index);
```

#### AUTO 


```{c}
auto row = newIndex.row();
```

#### AUTO 


```{c}
const auto value = amountHelper->value();
```

#### AUTO 


```{c}
auto account = MyMoneyFile::instance()->account(sm.accountId());
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->ui.m_reportTabWidget->currentWidget())
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyTransactionPrivate::getAttrName(static_cast<Transaction::Attribute>(i)).isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& /* parent */, int first, int last) {
        Q_UNUSED(first)
        Q_UNUSED(last)

        Q_D(LedgerAccountFilter);
        // mark this view for sorting but don't actually start sorting
        // until we come back to the main event loop. This allows to collect
        // multiple row insertions into the model into a single sort run.
        // This is important during import of multiple transactions.
        if (!d->sortPending) {
            d->sortPending = true;
            // in case a recalc operation is pending, we turn it off
            // since we need to sort first. Once sorting is done,
            // the recalc will be triggered again
            d->balanceCalculationPending = false;
            QMetaObject::invokeMethod(this, &LedgerAccountFilter::sortView, Qt::QueuedConnection);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto view : views)
      if (viewBases.contains(view))
        viewBases[view]->slotSelectByObject(obj, eView::Intent::UpdateActions);
```

#### AUTO 


```{c}
const auto& item
```

#### AUTO 


```{c}
auto torig = dlg->transaction();
```

#### AUTO 


```{c}
auto i = (int)Attribute::Split::ID;
```

#### AUTO 


```{c}
const auto baseModel = MyMoneyFile::baseModel();
```

#### AUTO 


```{c}
auto row = index.row();
```

#### AUTO 


```{c}
auto feeAmountWidget = d->haveWidget<AmountEdit*>("fee-amount");
```

#### AUTO 


```{c}
auto moduleLocation = nativeScriptFileInfo.absolutePath().toLocal8Bit();
```

#### AUTO 


```{c}
const auto isBrokerageAccount = p.name().contains(i18n(" (Brokerage)"));
```

#### AUTO 


```{c}
const auto ids = selections.selection(SelectedObjects::Institution);
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(categoryFilterActive);
```

#### AUTO 


```{c}
const auto journalEntryIds = selections.selection(SelectedObjects::JournalEntry);
```

#### AUTO 


```{c}
auto bic = plugin->requestData(m_iban, eIBANBIC::DataType::iban2Bic).toString();
```

#### AUTO 


```{c}
auto deepcurrency = file->security(currencyId());
```

#### AUTO 


```{c}
const auto colTotalValue = m_columns.indexOf(Column::TotalValue);
```

#### AUTO 


```{c}
auto treeItem = d->ui->m_equitiesTree->currentIndex();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QSaveFile* qfile)
        {
            QTextStream stream(qfile);
            stream.setCodec("UTF-8");
            stream << m_doc.toString();
            stream.flush();
        }
```

#### AUTO 


```{c}
auto txt = i18n("Online Statement Balance: %1", balance.formatMoney(d->m_account.fraction()));
```

#### AUTO 


```{c}
auto delegate = const_cast<KMMStyledItemDelegate*>(d->findDelegate(index));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : accounts) {
    if (account(acc).name().compare(name) == 0)
      return true;
  }
```

#### AUTO 


```{c}
const auto commodity = MyMoneyFile::instance()->security(commodityId);
```

#### AUTO 


```{c}
const auto idx = indexById(currency.id());
```

#### AUTO 


```{c}
auto& button
```

#### AUTO 


```{c}
const auto account = ixAccount.data(AccountsModel::AccountRole).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
const auto price = item->data(0, Qt::UserRole).value<MyMoneyPrice>();
```

#### AUTO 


```{c}
auto shareEdit = d->haveWidget<AmountEdit*>("shares")
```

#### AUTO 


```{c}
auto it = refPlugins.cbegin();
```

#### AUTO 


```{c}
auto to   = ui->m_currency->security().id();
```

#### AUTO 


```{c}
const auto& el(nodeList.item(i).toElement());
```

#### AUTO 


```{c}
const auto checkMark = Icons::get(Icon::DialogOK);
```

#### AUTO 


```{c}
const auto list = m_file->scheduleList(QString(), Schedule::Type::Any, Schedule::Occurrence::Any, Schedule::PaymentType::Any,
                                              QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto i = (int)Attribute::Payee::ID;
```

#### AUTO 


```{c}
auto i = (int)Security::Attribute::Name;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sConfigName : qAsConst(sConfigNames)) {
            const QString sOldConfigFilename = sOldMainConfigPath + sConfigName;
            const QString sNewConfigFilename = sMainConfigPath + configNamesChange.value(sConfigName, sConfigName);
            if (QFile::exists(sOldConfigFilename)) {
                if (QFile::copy(sOldConfigFilename, sNewConfigFilename))
                    QFile::remove(sOldConfigFilename);
            }
        }
```

#### AUTO 


```{c}
auto item = dynamic_cast<KPayeeListItem*>(d->ui->m_payeesList->item(d->m_payeeRows.at(d->m_payeeRow)))
```

#### AUTO 


```{c}
const auto transactionFactor(MyMoneyMoney::ONE);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits) {
            if (needAccountMatch || needCategoryMatch) {
                auto removeSplit = true;
                if (d->m_considerCategory) {
                    switch (file->account(s.accountId()).accountGroup()) {
                    case eMyMoney::Account::Type::Income:
                    case eMyMoney::Account::Type::Expense:
                        isTransfer = false;
                        // check if the split references one of the categories in the list
                        if (needCategoryMatch) {
                            if (d->m_categories.isEmpty()) {
                                // we're looking for transactions with 'no' categories
                                d->m_matchingSplitsCount = 0;
                                matchingSplits.clear();
                                return matchingSplits;
                            } else if (d->m_categories.contains(s.accountId())) {
                                categoryMatched = true;
                                removeSplit = false;
                            }
                        }
                        break;

                    default:
                        // check if the split references one of the accounts in the list
                        if (!filter.testFlag(accountFilterActive)) {
                            removeSplit = false;
                        } else if (!d->m_accounts.isEmpty() &&
                                   d->m_accounts.contains(s.accountId())) {
                            accountMatched = true;
                            removeSplit = false;
                        }

                        break;
                    }

                } else {
                    if (!filter.testFlag(accountFilterActive)) {
                        removeSplit = false;
                    } else if (!d->m_accounts.isEmpty() &&
                               d->m_accounts.contains(s.accountId())) {
                        accountMatched = true;
                        removeSplit = false;
                    }
                }

                if (removeSplit)
                    continue;
            }

            // check if less frequent filters are active
            if (extendedFilter != 0) {
                const auto acc = file->account(s.accountId());
                if (!(matchAmount(s) && matchText(s, acc)))
                    continue;

                // Determine if this account is a category or an account
                auto isCategory = false;
                switch (acc.accountGroup()) {
                case eMyMoney::Account::Type::Income:
                case eMyMoney::Account::Type::Expense:
                    isCategory = true;
                default:
                    break;
                }

                bool includeSplit = d->m_considerCategorySplits || (!d->m_considerCategorySplits && !isCategory);
                if (includeSplit) {
                    // check the payee list
                    if (filter.testFlag(payeeFilterActive)) {
                        if (!d->m_payees.isEmpty()) {
                            if (s.payeeId().isEmpty() || !d->m_payees.contains(s.payeeId()))
                                continue;
                        } else if (!s.payeeId().isEmpty())
                            continue;
                    }

                    // check the tag list
                    if (filter.testFlag(tagFilterActive)) {
                        const auto tags = s.tagIdList();
                        if (!d->m_tags.isEmpty()) {
                            if (tags.isEmpty()) {
                                continue;
                            } else {
                                auto found = false;
                                for (const auto& tag : tags) {
                                    if (d->m_tags.contains(tag)) {
                                        found = true;
                                        break;
                                    }
                                }

                                if (!found)
                                    continue;
                            }
                        } else if (!tags.isEmpty())
                            continue;
                    }

                    // check the type list
                    if (filter.testFlag(typeFilterActive) &&
                            !d->m_types.isEmpty() &&
                            !d->m_types.contains(splitType(transaction, s, acc)))
                        continue;

                    // check the state list
                    if (filter.testFlag(stateFilterActive) &&
                            !d->m_states.isEmpty() &&
                            !d->m_states.contains(splitState(s)))
                        continue;

                    if (filter.testFlag(nrFilterActive) &&
                            ((!d->m_fromNr.isEmpty() && s.number() < d->m_fromNr) ||
                             (!d->m_toNr.isEmpty() && s.number() > d->m_toNr)))
                        continue;

                } else if (filter & (payeeFilterActive | tagFilterActive | typeFilterActive | stateFilterActive | nrFilterActive)) {
                    continue;
                }
            }
            if (d->m_reportAllSplits)
                matchingSplits.append(s);

            isMatchingSplitsEmpty = false;
        }
```

#### AUTO 


```{c}
auto postDate = d->m_editWidgets["postdate"] = new KMyMoneyDateInput;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) { validateSelectedColumn(col, Column::Amount); }
```

#### AUTO 


```{c}
const auto equityId = selections.firstSelection(SelectedObjects::Account);
```

#### AUTO 


```{c}
const auto count = m_file->reportsModel()->processItems(&writer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : selection) {
        payeeIds.append(payee.id());
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& actionInfo : actionInfos) {
            lutActions[actionInfo.action]->setToolTip(actionInfo.tip);
        }
```

#### AUTO 


```{c}
auto rc = idx.data(eMyMoney::Model::SplitMemoRole).toString().contains(d->filterString, Qt::CaseInsensitive);
```

#### AUTO 


```{c}
auto idx = index(row, 0, parent);
```

#### AUTO 


```{c}
const auto lastReconciliationDate = acc.lastReconciliationDate().toString(Qt::SystemLocaleShortDate).replace(QChar(' '), "&nbsp;");
```

#### AUTO 


```{c}
const auto rowIndeces =
                        MyMoneyFile::instance()->journalModel()->indexesByTransactionId(index.data(eMyMoney::Model::JournalTransactionIdRole).toString());
```

#### AUTO 


```{c}
const auto columns = header()->saveState();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @todo add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      // case eMyMoney::File::Object::Currency:
      // case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
      case eMyMoney::File::Object::Transaction:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
auto item = new QStandardItem(acc.name());
```

#### AUTO 


```{c}
const auto list = ui->m_payees->model()->match(ui->m_payees->model()->index(0, 0), eMyMoney::Model::IdRole,
                                         payeeId,
                                         -1,                         // all splits
                                         Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : newTransaction.splits()) {
        const JournalEntry journalEntry(QString("%1-%2").arg(oldKey, split.id()), transaction, split);
        const auto newIdx = index(row, 0);
        static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer())->dataRef() = journalEntry;
        if (m_idToItemMapper) {
            m_idToItemMapper->insert(journalEntry.id(), static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer()));
        }
        ++row;
    }
```

#### AUTO 


```{c}
auto priceEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("price"));
```

#### AUTO 


```{c}
const auto subIdx(q->index(row, 0, idx));
```

#### AUTO 


```{c}
const auto& name
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : journalEntries) {
                const auto idx = file->journalModel()->indexById(journalEntryId);
                const auto transactionId = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
                if (d->canBePrinted(accountId, transactionId)) {
                    d->printCheck(accountId, transactionId);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
        if (d->canBePrinted(accountId)) {
            for (const auto& transactionId : transactions) {
                if (d->canBePrinted(accountId, transactionId)) {
                    d->printCheck(accountId, transactionId);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto el = document.createElement(elementName(Element::Split::Split));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName: m_displayedPlugins) {
    KPluginMetaData pluginData{fileName};
    pluginDisabled(pluginData);
  }
```

#### AUTO 


```{c}
auto payee = MyMoneyPayee(fixedKey(MyMoneyFile::UserID), user);
```

#### AUTO 


```{c}
const auto postdate = postDate();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
          // create a copy of the splits list in the transaction
          // loop over all splits
          for (auto& split : transaction.splits()) {
            // if the split is assigned to one of the selected payees, we need to modify it
            if (payeeInList(d->m_selectedPayees, split.payeeId())) {
              split.setPayeeId(payee_id); // first modify payee in current split
              // then modify the split in our local copy of the transaction list
              transaction.modifySplit(split); // this does not modify the list object 'splits'!
            }
          } // for - Splits
          file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
        }
```

#### AUTO 


```{c}
auto isSuccessfull = false;
```

#### AUTO 


```{c}
auto cnt1 = !ui->m_interestEdit->value().isZero() + !ui->m_interestCategoryEdit->selectedItem().isEmpty();
```

#### AUTO 


```{c}
auto i = (int)MyMoneySchedule::Element::Payment;
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account((*it_s).accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : accounts)
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, MyMoneyFile::account(id));
```

#### AUTO 


```{c}
const auto idx = model->index(0, 0);
```

#### AUTO 


```{c}
const auto expenseValue = data(expenseList.front(), (int)Role::TotalValue);
```

#### AUTO 


```{c}
auto nativeScript = std::unique_ptr<QTemporaryFile>(QTemporaryFile::createNativeFile(scriptResourceName));
```

#### AUTO 


```{c}
auto child = file->account(*it);
```

#### AUTO 


```{c}
auto subaccStr = subaccountsStr.begin();
```

#### AUTO 


```{c}
const auto& view
```

#### AUTO 


```{c}
const auto origDueDate = schedule.nextDueDate();
```

#### AUTO 


```{c}
const auto enabled = MyMoneyUtils::transactionWarnLevel(selections.selection(SelectedObjects::JournalEntry)) < OneSplitFrozen;
```

#### AUTO 


```{c}
auto destRow = destIdx.row();
```

#### AUTO 


```{c}
const auto categoriesView = static_cast<KCategoriesView*>(viewBases[view]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : tList) {
        MyMoneyTransaction t = transaction;
        bool tChanged = false;
        QDate accountOpeningDate;
        QStringList accountList;
        if (!(t.value(QStringLiteral("kmm-matched-tx")).isEmpty() && t.value(QStringLiteral("kmm-match-split")).isEmpty())) {
            t.deletePair(QStringLiteral("kmm-matched-tx"));
            t.deletePair(QStringLiteral("kmm-match-split"));
            rc << i18n("  * Removed unused match information from transaction '%1'.", t.id());
            ++problemCount;
            tChanged = true;
        }

        const auto splits = t.splits();
        foreach (const auto split, splits) {
            bool sChanged = false;
            MyMoneySplit s = split;
            if (payeeConversionMap.find(split.payeeId()) != payeeConversionMap.end()) {
                s.setPayeeId(payeeConversionMap[s.payeeId()]);
                sChanged = true;
                rc << i18n("  * Payee id updated in split of transaction '%1'.", t.id());
                ++problemCount;
            }

            try {
                const auto acc = d->accountsModel.itemById(s.accountId());
                // compute the newest opening date of all accounts involved in the transaction
                // in case the newest opening date is newer than the transaction post date, do one
                // of the following:
                //
                // a) for category and stock accounts: update the opening date of the account
                // b) for account types where the user cannot modify the opening date through
                //    the UI issue a warning (for each account only once)
                // c) others will be caught later
                if (!acc.isIncomeExpense() && !acc.isInvest()) {
                    if (acc.openingDate() > t.postDate()) {
                        if (!accountOpeningDate.isValid() || acc.openingDate() > accountOpeningDate) {
                            accountOpeningDate = acc.openingDate();
                        }
                        accountList << this->accountToCategory(acc.id());
                        if (!supportedAccountTypes.contains(acc.accountType())
                                && !reportedUnsupportedAccounts.contains(acc.id())) {
                            rc << i18n("  * Opening date of Account '%1' cannot be changed to support transaction '%2' post date.",
                                       this->accountToCategory(acc.id()), t.id());
                            reportedUnsupportedAccounts << acc.id();
                            ++unfixedCount;
                        }
                    }
                } else {
                    if (acc.openingDate() > t.postDate()) {
                        rc << i18n("  * Transaction '%1' post date '%2' is older than opening date '%4' of account '%3'.",
                                   t.id(), t.postDate().toString(Qt::ISODate), this->accountToCategory(acc.id()), acc.openingDate().toString(Qt::ISODate));

                        rc << i18n("    Account opening date updated.");
                        MyMoneyAccount newAcc = acc;
                        newAcc.setOpeningDate(t.postDate());
                        this->modifyAccount(newAcc);
                        ++problemCount;
                    }
                }

                // make sure, that shares and value have the same number if they
                // represent the same currency.
                if (t.commodity() == acc.currencyId() && s.shares().reduce() != s.value().reduce()) {
                    // use the value as master if the transaction is balanced
                    if (t.splitSum().isZero()) {
                        s.setShares(s.value());
                        rc << i18n("  * shares set to value in split of transaction '%1'.", t.id());
                    } else {
                        s.setValue(s.shares());
                        rc << i18n("  * value set to shares in split of transaction '%1'.", t.id());
                    }
                    sChanged = true;
                    ++problemCount;
                }
            } catch (const MyMoneyException &) {
                rc << i18n("  * Split %2 in transaction '%1' contains a reference to invalid account %3. Please fix manually.", t.id(), split.id(), split.accountId());
                ++unfixedCount;
            }

            // make sure the interest splits are marked correct as such
            if (interestAccounts.find(s.accountId()) != interestAccounts.end()
                    && s.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
                s.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
                sChanged = true;
                rc << i18n("  * action marked as interest in split of transaction '%1'.", t.id());
                ++problemCount;
            }

            if (sChanged) {
                tChanged = true;
                t.modifySplit(s);
            }
        }

        // make sure that the transaction's post date is valid
        if (!t.postDate().isValid()) {
            tChanged = true;
            t.setPostDate(t.entryDate().isValid() ? t.entryDate() : QDate::currentDate());
            rc << i18n("  * Transaction '%1' has an invalid post date.", t.id());
            rc << i18n("    The post date was updated to '%1'.", QLocale().toString(t.postDate(), QLocale::ShortFormat));
            ++problemCount;
        }
        // check if the transaction's post date is after the opening date
        // of all accounts involved in the transaction. In case it is not,
        // issue a warning with the details about the transaction incl.
        // the account names and dates involved
        if (accountOpeningDate.isValid() && t.postDate() < accountOpeningDate) {
            QDate originalPostDate = t.postDate();
#if 0
            // for now we do not activate the logic to move the post date to a later
            // point in time. This could cause some severe trouble if you have lots
            // of ancient data collected with older versions of KMyMoney that did not
            // enforce certain conditions like we do now.
            t.setPostDate(accountOpeningDate);
            tChanged = true;
            // copy the price information for investments to the new date
            QList<MyMoneySplit>::const_iterator it_t;
            foreach (const auto split, t.splits()) {
                if ((split.action() != "Buy") &&
                        (split.action() != "Reinvest")) {
                    continue;
                }
                QString id = split.accountId();
                auto acc = this->account(id);
                MyMoneySecurity sec = this->security(acc.currencyId());
                MyMoneyPrice price(acc.currencyId(),
                                   sec.tradingCurrency(),
                                   t.postDate(),
                                   split.price(), "Transaction");
                this->addPrice(price);
                break;
            }
#endif
            rc << i18n("  * Transaction '%1' has a post date '%2' before one of the referenced account's opening date.", t.id(), QLocale().toString(originalPostDate, QLocale::ShortFormat));
            rc << i18n("    Referenced accounts: %1", accountList.join(","));
            rc << i18n("    The post date was not updated to '%1'.", QLocale().toString(accountOpeningDate, QLocale::ShortFormat));
            ++unfixedCount;
        }

        if (tChanged) {
            d->journalModel.modifyTransaction(t);
        }
    }
```

#### AUTO 


```{c}
const auto sp = journalEntry.split();
```

#### AUTO 


```{c}
const auto value =
                            MyMoneyFile::instance()->balance((*it).id(), QDate::currentDate());
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(s.accountId());
```

#### AUTO 


```{c}
const auto interest = d->haveVisibleWidget<AmountEdit>("interestAmountEdit");
```

#### AUTO 


```{c}
auto form = dynamic_cast<KMyMoneyTransactionForm::TransactionForm*>(d->m_form);
```

#### AUTO 


```{c}
const auto list = idx.model()->match(idx.model()->index(0, 0), eMyMoney::Model::JournalTransactionIdRole,
                                       idx.data(eMyMoney::Model::JournalTransactionIdRole),
                                       -1,                         // all splits
                                       Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : journalEntryIds) {
                const auto journalEntry = journalModel->itemById(journalEntryId);
                auto sp = journalEntry.split();

                // skip the ones that are not marked cleared
                if (sp.reconcileFlag() != eMyMoney::Split::State::Cleared)
                    continue;

                auto t = journalEntry.transaction();
                sp.setReconcileFlag(eMyMoney::Split::State::Reconciled);
                sp.setReconcileDate(endingBalanceDlg->statementDate());
                t.setImported(false);
                t.modifySplit(sp);

                // update the engine ...
                file->modifyTransaction(t);

                // ... and the list
                reconciledJournalEntryIds.append(journalEntryId);
            }
```

#### AUTO 


```{c}
const auto blocked = MyMoneyFile::instance()->blockSignals(true);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (isVisible()) {
            d->ui->m_filterContainer->show();
            d->ui->m_searchWidget->setFocus();
        }
    }
```

#### AUTO 


```{c}
const auto docType(kmyexp.match(txt));
```

#### AUTO 


```{c}
auto fees = new KMyMoneyCategory(0, true);
```

#### AUTO 


```{c}
const auto actionId = d->qActionToId(qobject_cast<QAction*>(sender()));
```

#### AUTO 


```{c}
auto grp =  KSharedConfig::openConfig()->group("SplitTransactionEditor");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
            // create copy of transaction in current schedule
            auto trans = schedule.transaction();
            // create copy of lists of splits
            for (auto& split : trans.splits()) {
              if (payeeInList(list, split.payeeId())) {
                split.setPayeeId(payee_id);
                trans.modifySplit(split); // does not modify the list object 'splits'!
              }
            } // for - Splits
            // store transaction in current schedule
            schedule.setTransaction(trans);
            file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
          }
```

#### AUTO 


```{c}
auto pluginResult = KPluginFactory::instantiatePlugin<KMyMoneyPlugin::onlineTaskFactory>(plugins.first(), onlineJobAdministration::instance());
```

#### AUTO 


```{c}
auto tabbar = dynamic_cast<KMyMoneyTransactionForm::TabBar*>(haveWidget("tabbar"))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : qAsConst(selection)) {
            const auto tmpl = model->itemByIndex(idx);
            hierarchy(tmpl.accountTree(), templateHierarchy);
        }
```

#### AUTO 


```{c}
const auto columnTypeFromXML = stringToColumnType(node.attribute(attributeName(Attribute::Report::ColumnType)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : selection) {
            auto baseIdx = baseModel->mapToBaseSource(idx);
            auto payee = baseModel->itemByIndex(baseIdx);
            if (!payee.id().isEmpty()) {
                payees.append(payee);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& w : d->widgetList) {
        w->setEnabled(enabled);
    }
```

#### AUTO 


```{c}
const auto leftData = sourceModel()->data(left, (int)Role::DisplayOrder);
```

#### AUTO 


```{c}
const auto list = file->institutionList();
```

#### AUTO 


```{c}
const auto& stock
```

#### AUTO 


```{c}
const auto payeeId = d->m_wizard->d_func()->m_generalLoanInfoPage->d_func()->ui->m_payee->selectedItem();
```

#### AUTO 


```{c}
auto item = d->ui->m_priceList->itemAt(p);
```

#### AUTO 


```{c}
auto identifierNodes = node.elementsByTagName(elementName(Element::Payee::Identifier));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
      if(selectedSplitRow == splitIdx.row()) {
        d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

        const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
        const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
        d->ui->payeeEdit->setCurrentIndex(d->payeesModel->mapFromSource(payeeIdx).row());

        d->ui->memoEdit->clear();
        d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
        d->ui->memoEdit->moveCursor(QTextCursor::Start);
        d->ui->memoEdit->ensureCursorVisible();

        // The calculator for the amount field can simply be added as an icon to the line edit widget.
        // See https://stackoverflow.com/questions/11381865/how-to-make-an-extra-icon-in-qlineedit-like-this howto do it
        d->ui->amountEditCredit->setText(splitIdx.data(eMyMoney::Model::JournalSplitPaymentRole).toString());
        d->ui->amountEditDebit->setText(splitIdx.data(eMyMoney::Model::JournalSplitDepositRole).toString());

        d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
        d->ui->statusCombo->setCurrentIndex(0); // default is not reconciled

        const QModelIndexList stList = d->statusModel.match(d->statusModel.index(0, 0), Qt::UserRole+1, splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
        if(!stList.isEmpty()) {
          d->ui->statusCombo->setCurrentIndex(stList.front().row());
        }
      } else {
        d->splitModel.addSplit(d->transaction, MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
      }
    }
```

#### AUTO 


```{c}
auto item = dynamic_cast<KPayeeListItem*>(*payeesIt)
```

#### AUTO 


```{c}
const auto index = model()->index(currentIndex().row(), (int)eAccountsModel::Column::Account, currentIndex().parent());
```

#### AUTO 


```{c}
auto i = (int)Report::Attribute::ID;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotDuplicateTransaction(true); }
```

#### AUTO 


```{c}
const auto selectedItemCount = d->ui->m_payees->selectionModel()->selectedIndexes().count();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyAccount::getElName(static_cast<MyMoneyAccount::Element>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : transactionList) {
    const char *defaultAction = 0;
    QList<MyMoneySplit> splits = transaction.splits();
    QStringList accounts;

    // check if base commodity is set. if not, set baseCurrency
    if (transaction.commodity().isEmpty()) {
      qDebug() << Q_FUNC_INFO << " " << transaction.id() << " has no base currency";
      transaction.setCommodity(file->baseCurrency().id());
      file->modifyTransaction(transaction);
    }

    bool isLoan = false;
    // Determine default action
    if (transaction.splitCount() == 2) {
      // check for transfer
      int accountCount = 0;
      MyMoneyMoney val;
      foreach (const auto split, splits) {
        auto acc = file->account(split.accountId());
        if (acc.accountGroup() == Account::Type::Asset
            || acc.accountGroup() == Account::Type::Liability) {
          val = split.value();
          accountCount++;
          if (acc.accountType() == Account::Type::Loan
              || acc.accountType() == Account::Type::AssetLoan)
            isLoan = true;
        } else
          break;
      }
      if (accountCount == 2) {
        if (isLoan)
          defaultAction = MyMoneySplit::ActionAmortization;
        else
          defaultAction = MyMoneySplit::ActionTransfer;
      } else {
        if (val.isNegative())
          defaultAction = MyMoneySplit::ActionWithdrawal;
        else
          defaultAction = MyMoneySplit::ActionDeposit;
      }
    }

    isLoan = false;
    foreach (const auto split, splits) {
      auto acc = file->account(split.accountId());
      MyMoneyMoney val = split.value();
      if (acc.accountGroup() == Account::Type::Asset
          || acc.accountGroup() == Account::Type::Liability) {
        if (!val.isPositive()) {
          defaultAction = MyMoneySplit::ActionWithdrawal;
          break;
        } else {
          defaultAction = MyMoneySplit::ActionDeposit;
          break;
        }
      }
    }

#if 0
    // Check for correct actions in transactions referencing credit cards
    bool needModify = false;
    // The action fields are actually not used anymore in the ledger view logic
    // so we might as well skip this whole thing here!
    for (it_s = splits.begin(); needModify == false && it_s != splits.end(); ++it_s) {
      auto acc = file->account((*it_s).accountId());
      MyMoneyMoney val = (*it_s).value();
      if (acc.accountType() == Account::Type::CreditCard) {
        if (val < 0 && (*it_s).action() != MyMoneySplit::ActionWithdrawal && (*it_s).action() != MyMoneySplit::ActionTransfer)
          needModify = true;
        if (val >= 0 && (*it_s).action() != MyMoneySplit::ActionDeposit && (*it_s).action() != MyMoneySplit::ActionTransfer)
          needModify = true;
      }
    }

    // (Ace) Extended the #endif down to cover this conditional, because as-written
    // it will ALWAYS be skipped.

    if (needModify == true) {
      for (it_s = splits.begin(); it_s != splits.end(); ++it_s) {
        (*it_s).setAction(defaultAction);
        transaction.modifySplit(*it_s);
        file->modifyTransaction(transaction);
      }
      splits = transaction.splits();    // update local copy
      qDebug("Fixed credit card assignment in %s", transaction.id().data());
    }
#endif

    // Check for correct assignment of ActionInterest in all splits
    // and check if there are any duplicates in this transactions
    for (auto& split : splits) {
      MyMoneyAccount splitAccount = file->account(split.accountId());
      if (!accounts.contains(split.accountId())) {
        accounts << split.accountId();
      }
      // if this split references an interest account, the action
      // must be of type ActionInterest
      if (interestAccounts.contains(split.accountId())) {
        if (split.action() != MyMoneySplit::ActionInterest) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
          split.setAction(MyMoneySplit::ActionInterest);
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
        // if it does not reference an interest account, it must not be
        // of type ActionInterest
      } else {
        if (split.action() == MyMoneySplit::ActionInterest) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
          split.setAction(defaultAction);
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
      }

      // check that for splits referencing an account that has
      // the same currency as the transactions commodity the value
      // and shares field are the same.
      if (transaction.commodity() == splitAccount.currencyId()
          && split.value() != split.shares()) {
        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
        split.setShares(split.value());
        transaction.modifySplit(split);
        file->modifyTransaction(transaction);
      }

      // fix the shares and values to have the correct fraction
      if (!splitAccount.isInvest()) {
        try {
          int fract = splitAccount.fraction();
          if (split.shares() != split.shares().convert(fract)) {
            qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
            split.setShares(split.shares().convert(fract));
            split.setValue(split.value().convert(fract));
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
          }
        } catch (const MyMoneyException &) {
          qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
        }
      }
    }

    ++cnt;
    if (!(cnt % 10))
      kmymoney->slotStatusProgressBar(cnt);
  }
```

#### AUTO 


```{c}
auto idx(_idx);
```

#### AUTO 


```{c}
auto extraColumnModel = new EquitiesModel(q);
```

#### AUTO 


```{c}
const auto &action
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &index : indexes) {
      if(showValuesInverted) {
        balance -= filterModel->data(index, (int)eLedgerModel::Role::SplitShares).value<MyMoneyMoney>();
      } else {
        balance += filterModel->data(index, (int)eLedgerModel::Role::SplitShares).value<MyMoneyMoney>();
      }
      const auto txt = balance.formatMoney(account.fraction());
      const auto dispIndex = filterModel->index(index.row(), (int)eLedgerModel::Column::Balance);
      filterModel->setData(dispIndex, txt, Qt::DisplayRole);
    }
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<kMyMoneyEdit*>(haveWidget("shares"));
```

#### AUTO 


```{c}
auto scheduleId = d->m_currentSchedule.id();
```

#### AUTO 


```{c}
auto filter = MyMoneyXmlContentHandler::readReport(subchild.toElement());
```

#### AUTO 


```{c}
const auto editor = qobject_cast<TransactionEditorBase*>(indexWidget(d->editIndex));
```

#### AUTO 


```{c}
auto security = m_file->security(account.currencyId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : qAsConst(accountIds)) {
        if (!isDatePostOpeningDate(date, accountId)) {
            const auto account = MyMoneyFile::instance()->account(accountId);
            WidgetHintFrame::show(ui->dateEdit, i18n("The posting date is prior to the opening date of account <b>%1</b>.", account.name()));
            rc = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto a = account(acc);
```

#### AUTO 


```{c}
auto grp = KSharedConfig::openConfig()->group(d->getConfGrpName(d->m_view));
```

#### AUTO 


```{c}
auto favoriteAccountsItem = new QStandardItem();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &split : transaction.splits())
    writeSplit(split, document, splitsElement);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        checkValidInput();
    }
```

#### AUTO 


```{c}
const auto pluginsPage = KMyMoneyPlugin::PluginLoader::instance()->pluginSelectorWidget();
```

#### AUTO 


```{c}
auto it = splitList.constBegin();
```

#### AUTO 


```{c}
auto writer = new MyMoneyStorageSql(MyMoneyFile::instance()->storage(), MyMoneyFile::instance(), url);
```

#### AUTO 


```{c}
const auto queryString = QString("SELECT %1, %2 from %3 left join %4 on %4.id = %3.transactionId where %3.txType = 'N' ORDER BY transactionId,splitId;").arg(ts.fullQualifiedColumnList(), t.fullQualifiedColumnList(), ts.name(), t.name());
```

#### AUTO 


```{c}
const auto acc = d->ui->m_accountTree->model()->data(index, (int)eAccountsModel::Role::Account).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto number = new kMyMoneyLineEdit;
```

#### AUTO 


```{c}
auto p = q->mapToGlobal(QPoint());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : indeces) {
            if (idx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == accountId) {
                selections.setSelection(SelectedObjects::JournalEntry, idx.data(eMyMoney::Model::IdRole).toString());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&, row](const auto column) {
      cell = node->child(row, column);      // try to get QStandardItem
      if (!cell) {                          // it may be uninitialized
        cell = new QStandardItem;           // so create one
        node->setChild(row, column, cell);  // and add it under the node
        cell->setEditable(false);           // and don't forget that it's non-editable
      }
    }
```

#### AUTO 


```{c}
auto fees = dynamic_cast<KMyMoneyCategory*>(haveWidget("fee-account"));
```

#### AUTO 


```{c}
auto cnt = list.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto split : transaction.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (int i = 0; i < tagIdList.size(); ++i) {
                            // if the split is assigned to one of the selected tags, we need to modify it
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (!newTagId.isEmpty()) {
                                    if (tagIdList.indexOf(newTagId) == -1) {
                                        tagIdList.append(newTagId);
                                    }
                                }
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList); // first modify tag list in current split
                        // then modify the split in our local copy of the transaction list
                        transaction.modifySplit(split); // this does not modify the list object 'splits'!
                    }
```

#### AUTO 


```{c}
auto payment = dynamic_cast<KMyMoneyEdit*>(haveWidget("payment"));
```

#### AUTO 


```{c}
const auto accountId = rowIndex.data(eMyMoney::Model::Roles::JournalSplitAccountIdRole).toString();
```

#### AUTO 


```{c}
const auto opts = conOpts.splitRef(QLatin1Char(';'));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : alwaysEnabled) {
      lutActions[action]->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto pyKey = PyUnicode_FromString(szKey);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            const auto journalEntry = file->journalModel()->itemById(journalEntryId);
            if (!journalEntry.id().isEmpty()) {
                auto t = journalEntry.transaction();
                if (!t.id().isEmpty()) {
                    // wipe out any reconciliation information
                    for (auto& split : t.splits()) {
                        split.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                        split.setReconcileDate(QDate());
                        split.setBankID(QString());
                    }
                    // clear invalid data
                    t.setEntryDate(QDate());
                    t.clearId();

                    if (reverse)
                        // reverse transaction
                        t.reverse();
                    else
                        // set the post date to today
                        t.setPostDate(QDate::currentDate());

                    file->addTransaction(t);
                    lastAddedTransactionId = t.id();
                }
            }
        }
```

#### AUTO 


```{c}
const auto reconciliationDate = index.data(eMyMoney::Model::TransactionPostDateRole).toDate();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& a : actionStates)
      pActions[a.first]->setEnabled(a.second);
```

#### AUTO 


```{c}
const auto action
```

#### AUTO 


```{c}
auto feeAccountWidget = d->haveWidget<KMyMoneyAccountCombo>("feesCombo");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                // we block sending out signals for the category combo here to avoid
                // calling NewTransactionEditorPrivate::categoryChanged which does not
                // work properly when loading the editor
                QSignalBlocker categoryComboBlocker(d->ui->categoryCombo);
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    // force the value of the second split to be the same as for the first
                    idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-amountValue), eMyMoney::Model::SplitValueRole);

                    // use the shares based on the second split
                    amountShares = -(splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>());

                    // adjust the commodity for the shares
                    const auto accountId = splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString();
                    const auto accountIdx = MyMoneyFile::instance()->accountsModel()->indexById(accountId);
                    const auto currencyId = accountIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
                    const auto currency = MyMoneyFile::instance()->currenciesModel()->itemById(currencyId);
                    d->ui->creditDebitEdit->setSharesCommodity(currency);
                }
            }
        }
```

#### AUTO 


```{c}
auto account = dynamic_cast<KMyMoneyCategory*>(haveWidget("account"))
```

#### AUTO 


```{c}
auto cnt = d->m_selections.selection(SelectedObjects::JournalEntry).count();
```

#### AUTO 


```{c}
const auto params = readKeyValuePairs("STORAGE", QString("")).pairs();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        KHelpClient::invokeHelp("details.schedules.intro");
    }
```

#### AUTO 


```{c}
const auto delegate = itemDelegate();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySplit::getAttrName(static_cast<MyMoneySplit::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto amount = d->m_split.shares();
```

#### AUTO 


```{c}
auto result = qMakePair(MyMoneyMoney(), true);
```

#### AUTO 


```{c}
auto hasIconsResource = false;
```

#### AUTO 


```{c}
const auto flag = idx.data(eMyMoney::Model::SplitReconcileFlagRole).value<eMyMoney::Split::State>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto category : categories) {
    MyMoneyAccount account;
    QString accountName;
    int displayOrder;

    switch (category) {
      case Account::Type::Asset:
        // Asset accounts
        account = d->m_file->asset();
        accountName = i18n("Asset accounts");
        displayOrder = 1;
        break;
      case Account::Type::Liability:
        // Liability accounts
        account = d->m_file->liability();
        accountName = i18n("Liability accounts");
        displayOrder = 2;
        break;
      case Account::Type::Income:
        // Income categories
        account = d->m_file->income();
        accountName = i18n("Income categories");
        displayOrder = 3;
        break;
      case Account::Type::Expense:
        // Expense categories
        account = d->m_file->expense();
        accountName = i18n("Expense categories");
        displayOrder = 4;
        break;
      case Account::Type::Equity:
        // Equity accounts
        account = d->m_file->equity();
        accountName = i18n("Equity accounts");
        displayOrder = 5;
        break;
      default:
        continue;
    }

    auto accountsItem = new QStandardItem(accountName);
    accountsItem->setEditable(false);
    rootItem->appendRow(accountsItem);

    {
      QMap<int, QVariant> itemData;
      itemData[Qt::DisplayRole] = accountName;
      itemData[(int)Role::FullName] = itemData[Qt::EditRole] = QVariant::fromValue(MyMoneyFile::instance()->accountToCategory(account.id(), true));
      itemData[Qt::FontRole] = font;
      itemData[(int)Role::DisplayOrder] = displayOrder;
      this->setItemData(accountsItem->index(), itemData);
    }

    // adding accounts (specific bank/investment accounts) belonging to given accounts category
    const auto&  accountList = account.accountList();
    for (const auto& accStr : accountList) {
      const auto acc = d->m_file->account(accStr);

      auto item = new QStandardItem(acc.name());
      accountsItem->appendRow(item);
      item->setEditable(false);
      auto subaccountsStr = acc.accountList();
      // filter out stocks with zero balance if requested by user
      for (auto subaccStr = subaccountsStr.begin(); subaccStr != subaccountsStr.end();) {
        const auto subacc = d->m_file->account(*subaccStr);
        if (subacc.isInvest() && KMyMoneySettings::hideZeroBalanceEquities() && subacc.balance().isZero())
          subaccStr = subaccountsStr.erase(subaccStr);
        else
          ++subaccStr;
      }

      // adding subaccounts (e.g. stocks under given investment account) belonging to given account
      d->loadSubaccounts(item, favoriteAccountsItem, subaccountsStr);
      const auto row = item->row();
      d->setAccountData(accountsItem, row, acc, d->m_columns);
      d->loadPreferredAccount(acc, accountsItem, row, favoriteAccountsItem);
    }

    d->setAccountData(rootItem, accountsItem->row(), account, d->m_columns);
  }
```

#### AUTO 


```{c}
auto tip = i18n("Reconcile - disabled because you are currently reconciling <b>%1</b>", d->m_reconciliationAccount.name());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
    Q_D(LedgerFilter);
    setStateFilter(static_cast<LedgerFilter::State>(idx));
  }
```

#### AUTO 


```{c}
const auto journalEntry = file->journalModel()->itemById(journalEntryId);
```

#### AUTO 


```{c}
auto item = dynamic_cast<Transaction*>(focusItem);
```

#### AUTO 


```{c}
const auto commodity = MyMoneyFile::instance()->currency(d->m_account.currencyId());
```

#### AUTO 


```{c}
const auto accountId = mapToSource(index).data(AccountsModel::AccountIdRole);
```

#### AUTO 


```{c}
auto p = file->storage();
```

#### AUTO 


```{c}
auto report = MyMoneyXmlContentHandler2::readReport(child.toElement());
```

#### AUTO 


```{c}
const auto blocked = file->blockSignals(true);
```

#### AUTO 


```{c}
auto categoryLabel = dynamic_cast<QLabel*>(w)
```

#### AUTO 


```{c}
auto accountToMove = d->accountsModel.itemById(accountId);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &column : visibleColumns) {
          if (applyStorageOffsetColumns.contains(column + storageOffset)) {
            column += storageOffset;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits)
      list.append(qMakePair(transaction, split));
```

#### AUTO 


```{c}
const auto lastColumn = model()->columnCount()-1;
```

#### AUTO 


```{c}
const auto formattedValue = balance.isNegative() ? d->formatViewLabelValue(-balance, KMyMoneySettings::schemeColor(SchemeColor::Negative))
                                : d->formatViewLabelValue(balance, KMyMoneySettings::schemeColor(SchemeColor::Positive));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tSplit : transaction.splits()) {
                    if (tSplit.accountId() != account.id()) {
                        if (!category.isEmpty())
                            category += QLatin1String(", "); // this is a split transaction
                        category += file->account(tSplit.accountId()).name();
                    }
                }
```

#### AUTO 


```{c}
const auto& next = sched.nextDueDate();
```

#### AUTO 


```{c}
const auto desc = idx.data(eMyMoney::Model::TemplatesLongDescriptionRole).toString();
```

#### AUTO 


```{c}
const auto idx = selected.indexes().at(0);
```

#### AUTO 


```{c}
auto okButton = d->ui->buttonBox->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
const auto url = QUrl::fromUserInput(QString("%1/%2").arg(dir.canonicalPath(), file));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
              // if the split is assigned to one of the selected payees, we need to modify it
              if (payeeInList(m_selectedPayeesList, split.payeeId())) {
                split.setPayeeId(payee_id); // first modify payee in current split
                // then modify the split in our local copy of the transaction list
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
            }
```

#### AUTO 


```{c}
const auto& onlineTaskIid
```

#### AUTO 


```{c}
const auto journalEntry = static_cast<TreeItem<JournalEntry>*>(q->index(startRow, 0).internalPointer())->constDataRef();
```

#### AUTO 


```{c}
const auto widgetIt = QTreeWidgetItemIterator(d->ui->m_budgetList);
```

#### AUTO 


```{c}
const auto hashBase(QStringLiteral("%1-%2").arg(m_qifProfile.date(extractLine('D')).toString(Qt::ISODate)).arg(h, 7, 16, QLatin1Char('0')));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : d->m_plugins.storage) {
    const auto fileExtension = plugin->fileExtension();
    if (!fileExtension.isEmpty()) {
      fileExtensions.append(fileExtension);
      fileExtensions.append(QLatin1String(";;"));
    }
  }
```

#### AUTO 


```{c}
const auto category
```

#### AUTO 


```{c}
const auto accountCombo = qobject_cast<KMyMoneyAccountCombo*>(d->m_accountCombo);
```

#### AUTO 


```{c}
auto cat = dynamic_cast<KMyMoneyCategory*>(q->haveWidget(name))
```

#### AUTO 


```{c}
const auto taskIid = job.taskIid();
```

#### AUTO 


```{c}
auto model = d->ui->m_frequencyEdit->model();
```

#### AUTO 


```{c}
auto edits = onlineJobAdministration::instance()->onlineJobEdits();
```

#### AUTO 


```{c}
auto taskFactory = pluginResult.plugin;
```

#### LAMBDA EXPRESSION 


```{c}
[this](onlineJobAdministration::onlineJobEditOffer in) {
        this->loadOnlineJobEditPlugin(in);
    }
```

#### AUTO 


```{c}
const auto sourceColumn = d->m_mdlColumns->at(mapToSource(index).column());
```

#### AUTO 


```{c}
const auto beforeIdEmpty = (before.transactionPtr() == nullptr) || (before.transaction().id().isEmpty());
```

#### AUTO 


```{c}
auto k = dynamic_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto accountID = childIdx.data(eMyMoney::Model::Roles::IdRole).toString();
```

#### AUTO 


```{c}
const auto txt = balance.formatMoney(account.fraction());
```

#### AUTO 


```{c}
auto i = (int)Attribute::Institution::ID;
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::OnlineJob>(i)).isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& from, const QModelIndex& to) {
      Q_D(KScheduledView);
      d->m_filterModel->invalidate();
    }
```

#### AUTO 


```{c}
auto dropMinimum = forecast.daysToMinimumBalance(acc);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto t : m_listTransactions) {
    if (t.m_datePosted > postDate) {
      postDate = t.m_datePosted;
    }
  }
```

#### AUTO 


```{c}
auto isEncrypted = false;
```

#### AUTO 


```{c}
const auto dispIndex = index(row, JournalModel::Column::Balance);
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(haveWidget("price"))
```

#### AUTO 


```{c}
auto anchor = d->m_helpAnchor[d->ui->m_criteriaTab->currentWidget()];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : indexes) {
        onlineJob job = idx.data(eMyMoney::Model::OnlineJobRole).value<onlineJob>();
        if (job.isValid() && job.isEditable())
            validJobs.append(job);
    }
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->account(d->m_lastSelectedAccountID);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QWidget* w) {
        if (w) {
            // if we point to a contructed widget (e.g. ButtonBox) we
            // need to select the last widget if going backward
            if (reason == Qt::BacktabFocusReason && !w->findChildren<QWidget*>().isEmpty()) {
                auto parent = w;
                while (w->nextInFocusChain()->parentWidget() == parent) {
                    w = w->nextInFocusChain();
                }
            }
            w->setFocus(reason);
        }
    }
```

#### AUTO 


```{c}
auto sharesAmount = amountEdit->value();
```

#### AUTO 


```{c}
const auto tagIdList = idx.data(eMyMoney::Model::SplitTagIdRole).toStringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
    // the following line will throw an exception if the
    // account does not exist or is one of the standard accounts
    auto acc = MyMoneyFile::account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION_CSTRING("Cannot add split with no account assigned");
    if (acc.isLoan())
      loanAccountAffected = true;
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing standard account");
  }
```

#### AUTO 


```{c}
auto address = document.createElement(d->getElName(Institution::Element::Address));
```

#### AUTO 


```{c}
auto i = (int)Attribute::OnlineJob::Send;
```

#### AUTO 


```{c}
const auto testModel = MyMoneyModelBase::baseModel(testIdx);
```

#### AUTO 


```{c}
auto account = model->data(source_index, (int)Role::Account).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto i = (int)KVC::Attribute::Key;
```

#### AUTO 


```{c}
auto mdlItem = m_equitiesProxyModel->index(treeItem.row(), EquitiesModel::Equity, treeItem.parent());
```

#### AUTO 


```{c}
auto timeout = now.msecsTo(nextDay);
```

#### AUTO 


```{c}
const auto transaction = static_cast<TreeItem<JournalEntry>*>(idx.internalPointer())->constDataRef().transaction();
```

#### AUTO 


```{c}
const auto accountId = sourceModel()->data(source, eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("qifimporter");
```

#### AUTO 


```{c}
const auto rows = feeSplitModel->rowCount();
```

#### AUTO 


```{c}
const auto icon = iconDef.key();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selected.indexes()) {
                if (idx.data(eMyMoney::Model::TransactionScheduleRole).toBool() != isSchedule) {
                    toDeselect.select(idx, idx);
                }
            }
```

#### AUTO 


```{c}
auto beginDay = QDate::currentDate().daysTo(m_forecast.beginForecastDate());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : d->m_payeesToSync) {
          MyMoneyFile::instance()->modifyPayee(payee);
        }
```

#### AUTO 


```{c}
auto beginDay = q->beginForecastDay();
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->m_reportTabWidget->widget(i));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : indeces) {
            if (idx.data(eMyMoney::Model::JournalSplitIdRole).toString() == splitId) {
                qDebug() << "converted" << journalId << "to" << idx.data(eMyMoney::Model::IdRole).toString();
                return idx.data(eMyMoney::Model::IdRole).toString();
            }
        }
```

#### AUTO 


```{c}
const auto baseIdx = file->accountsModel()->indexById(topAccount.id());
```

#### AUTO 


```{c}
auto isOverrun = false;
```

#### AUTO 


```{c}
auto ctBasicIncome = makeAccount(QString("Basic Income"), MyMoneyAccount::Income, MyMoneyMoney(), QDate(2016, 1, 1), acIncome);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyTransaction::getAttrName(static_cast<MyMoneyTransaction::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto interestAmountWidget = d->haveWidget<AmountEdit*>("interest-amount");
```

#### AUTO 


```{c}
auto a = actionConnections.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : filter.matchingSplits(transaction))
      list.append(qMakePair(transaction, split));
```

#### AUTO 


```{c}
const auto baseIdx = model->indexById(m_parentAccount.id());
```

#### AUTO 


```{c}
const auto selectedPayeesList = selectedPayees();
```

#### AUTO 


```{c}
const auto parentWidget = QApplication::activeWindow();
```

#### AUTO 


```{c}
const auto& currency
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : set) {
        switch (change.notificationMode()) {
        case File::Mode::Remove:
            removedObjects += change.id();
            break;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
auto txt = str;
```

#### AUTO 


```{c}
auto txt = value.formatMoney(QString(), d->m_prec, false);
```

#### AUTO 


```{c}
const auto row = d->ui->splitView->selectionModel()->selectedRows().first().row();
```

#### AUTO 


```{c}
auto baseValue = value * curRate;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (auto i = 0; i < tagIdList.size(); ++i) {
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (tagIdList.indexOf(tag_id) == -1)
                                    tagIdList.append(tag_id);
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList);
                        trans.modifySplit(split); // does not modify the list object 'splits'!
                    }
```

#### AUTO 


```{c}
const auto &payeeIdentifier
```

#### AUTO 


```{c}
const auto flag = action2state.value(actionId, eMyMoney::Split::State::Unknown);
```

#### AUTO 


```{c}
const auto idx = indexById(id);
```

#### AUTO 


```{c}
const auto gotoAccount = pActions[eMenu::Action::GoToAccount];
```

#### AUTO 


```{c}
auto selectedItem = ui->m_selectedList->currentItem();
```

#### AUTO 


```{c}
const auto sec = d->currentSecurity();
```

#### AUTO 


```{c}
const auto priceList = d->m_sql->fetchPrices();
```

#### AUTO 


```{c}
const auto budgetView = static_cast<KBudgetView*>(viewBases[view]);
```

#### AUTO 


```{c}
auto priceEdit = dynamic_cast<AmountEdit*>(haveWidget("price"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : selectedTags) {
      f.addTag(tag.id());
    }
```

#### AUTO 


```{c}
auto ctBasicIncome = makeAccount(QString("Basic Income"), eMyMoney::Account::Income, MyMoneyMoney(), QDate(2016, 1, 1), acIncome);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : qAsConst(accounts)) {
      if (account.hasOnlineMapping()) {
        for (const auto& onlineTaskIid : plugin->availableJobs(account.id())) {
          if (m_onlineTasks.contains(onlineTaskIid)) {
            return true;
          }
        }
      }
    }
```

#### AUTO 


```{c}
auto feeAmountWidget = d->haveWidget<AmountEdit>("feesAmountEdit");
```

#### AUTO 


```{c}
auto category = dynamic_cast<KMyMoneyCategory*>(*it_w);
```

#### AUTO 


```{c}
const auto maxColumn = d->headerView->count();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& column : visibleColumns) {
          if (applyStorageOffsetColumns.contains(column+storageOffset)) {
            column += storageOffset;
          }
        }
```

#### AUTO 


```{c}
const auto parentIdx = d->model->index(d->countryRow, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QUrl url;
            url.setUrl(QString::fromLatin1("https://%1").arg(d->ui->urlEdit->text()));
            QDesktopServices::openUrl(url);
          }
```

#### AUTO 


```{c}
auto action = qobject_cast<KDualAction*>(sender());
```

#### AUTO 


```{c}
auto amount = d->split.shares();
```

#### AUTO 


```{c}
const auto security = MyMoneyFile::instance()->security(acc.currencyId());
```

#### AUTO 


```{c}
const auto idx = journalModel->indexById(unclearedJournalEntryIds.front());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : accounts) {
        const auto sacc = MyMoneyFile::account(acc);
        if (sacc.name().compare(name) == 0)
            return sacc;
    }
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->m_reportTabWidget->widget(index))
```

#### AUTO 


```{c}
const auto tmpfile = new QTemporaryFile;
```

#### AUTO 


```{c}
const auto prec = securityIdx.data(eMyMoney::Model::SecurityPricePrecisionRole).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : selection) {
            auto baseIdx = baseModel->mapToBaseSource(idx);
            const auto id = baseIdx.data(eMyMoney::Model::IdRole).toString();
            if (!id.isEmpty()) {
                payees.append(id);
            }
        }
```

#### AUTO 


```{c}
const auto accountId = idx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : transactionList) {
        // if this split is a stock split, we can't just add the amount of shares
        const auto journalEntry = file->journalModel()->itemById(journalEntryId);
        if (!journalEntry.id().isEmpty()) {
            const auto& split = journalEntry.split();
            const auto& transaction = journalEntry.transaction();

            if (split.reconcileFlag() == eMyMoney::Split::State::NotReconciled && split.shares().isNegative()) {
                QString category;
                for (const auto& tSplit : transaction.splits()) {
                    if (tSplit.accountId() != account.id()) {
                        if (!category.isEmpty())
                            category += QLatin1String(", "); // this is a split transaction
                        category += file->account(tSplit.accountId()).name();
                    }
                }

                detailsReport += QString("<tr class=\"%1\"><td>").arg((index++ % 2 == 1) ? "row-odd" : "row-even");
                detailsReport += QString("%1").arg(QLocale().toString(transaction.entryDate(), QLocale::ShortFormat));
                detailsReport += "</td><td>";
                detailsReport += QString("%1").arg(split.number());
                detailsReport += "</td><td>";
                detailsReport += QString("%1").arg(file->payee(split.payeeId()).name());
                detailsReport += "</td><td>";
                detailsReport += QString("%1").arg(transaction.memo());
                detailsReport += "</td><td>";
                detailsReport += QString("%1").arg(category);
                detailsReport += "</td><td>";
                detailsReport += QString("%1").arg(MyMoneyUtils::formatMoney(split.shares(), file->currency(account.currencyId())));
                detailsReport += "</td></tr>";
            }
        }
    }
```

#### AUTO 


```{c}
auto& w
```

#### AUTO 


```{c}
auto item = d->itemFromAccountId(parentAccountItem, account->id());
```

#### AUTO 


```{c}
auto itInstitution = new QStandardItem(Icons::get(Icon::Institution), institution.name());
```

#### LAMBDA EXPRESSION 


```{c}
[&](QWidget* editor) {
        emit const_cast<nationalAccountDelegate*>(this)->closeEditor(editor);
    }
```

#### AUTO 


```{c}
auto& t
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
        // the following line will throw an exception if the
        // account does not exist or is one of the standard accounts
        const auto acc = account(split.accountId());
        if (acc.id().isEmpty())
            throw MYMONEYEXCEPTION_CSTRING("Cannot add split with no account assigned");
        if (isStandardAccount(split.accountId()))
            throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing standard account");
    }
```

#### AUTO 


```{c}
auto a = new KDualAction(this);
```

#### AUTO 


```{c}
const auto cellHeight = q->verticalHeader()->sectionSize(idx.row());
```

#### AUTO 


```{c}
const auto t = MyMoneyFile::instance()->transaction(id);
```

#### AUTO 


```{c}
auto reportTab = new KReportTab(ui.m_reportTabWidget, report, q);
```

#### AUTO 


```{c}
const auto idx = d->accountsModel.indexById(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& sm : tm.splits()) {
                  if (payeeInList(m_selectedPayeesList, sm.payeeId())) {
                    sm.setPayeeId(payee_id); // first modify payee in current split
                    // then modify the split in our local copy of the transaction list
                    tm.modifySplit(sm); // this does not modify the list object 'splits'!
                  }
                }
```

#### AUTO 


```{c}
auto prec = MyMoneyMoney::denomToPrec(tradingCurrency.smallestAccountFraction());
```

#### AUTO 


```{c}
auto new_name = ta->text();
```

#### AUTO 


```{c}
const auto showDetails = LedgerViewSettings::instance()->showTransactionDetails();
```

#### AUTO 


```{c}
const auto rows = m_model.rowCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
    addView(viewBases[view.id], view.name, view.id, view.icon);
  }
```

#### AUTO 


```{c}
const auto selectedItemCount = selectedItems.count();
```

#### AUTO 


```{c}
auto childIdx = index.child(i, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPrinter* printer) {
            m_tableView->print(printer);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto view : views)
      if (viewBases.contains(view))
        viewBases[view]->updateActions(obj);
```

#### AUTO 


```{c}
const auto closeRole = isInvestmentAccount ? eMyMoney::Model::AccountCanBeClosedRole : eMyMoney::Model::AccountIsClosedRole;
```

#### AUTO 


```{c}
const auto existingAccount = file->subAccountByName(parentAccount, part);
```

#### AUTO 


```{c}
auto& r = *(itemList.front());
```

#### AUTO 


```{c}
const auto selection = q->selectedTags();
```

#### AUTO 


```{c}
const auto frequency =
        model->index(d->ui->frequencyEdit->currentIndex(), 0).data(eMyMoney::Model::ScheduleFrequencyRole).value<eMyMoney::Schedule::Occurrence>();
```

#### AUTO 


```{c}
auto visSColumns = m_securitiesProxyModel->getVisibleColumns();
```

#### AUTO 


```{c}
auto boxLayout = dynamic_cast<QBoxLayout*>(form->getTabBar()->parentWidget()->layout())
```

#### AUTO 


```{c}
auto trcData = request.toUtf8();
```

#### AUTO 


```{c}
auto firstAccName = filteredAccounts.at(i).name();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        d->m_schedule.setNextDueDate(d->m_editor->postDate());
        d->setScheduleOccurrencePeriod();
        d->m_schedule.setOccurrenceMultiplier(d->ui->m_frequencyNoEdit->value());

        if (d->m_schedule.endDate() != date) {
            d->m_schedule.setEndDate(date);
            d->updateTransactionsRemaining();
        }
    }
```

#### AUTO 


```{c}
auto kyIcon = QLatin1String("view_institution") + QString::number(size);
```

#### AUTO 


```{c}
auto caption = m_storageInfo.url.isEmpty() && m_myMoneyView && m_storageInfo.isOpened  ?
        i18n("Untitled") :
        m_storageInfo.url.fileName();
```

#### AUTO 


```{c}
const auto journalEntryList = d->m_selections.selection(SelectedObjects::JournalEntry);
```

#### AUTO 


```{c}
auto storage = MyMoneyFile::instance()->storage();
```

#### AUTO 


```{c}
auto editor = d->m_item->createEditor(d->ui->m_form, list, QDate());
```

#### AUTO 


```{c}
const auto list = m_storage->institutionList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto accountId : qAsConst(fullBalanceRecalc)) {
        balanceCache[accountId] = MyMoneyMoney();
      }
```

#### AUTO 


```{c}
auto cat = d->haveWidget<KMyMoneyCategory*>(category);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QUrl url;
        url.setUrl(QString::fromLatin1("https://%1").arg(d->ui->urlEdit->text()));
        QDesktopServices::openUrl(url);
    }
```

#### AUTO 


```{c}
const auto currentTime = QTime::currentTime();
```

#### AUTO 


```{c}
auto latestDate = QDate::fromString(item->text(DATE_COL),Qt::ISODate);
```

#### AUTO 


```{c}
auto model = qobject_cast<InstitutionsModel *>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
                        auto acc = file->account(split.accountId());
                        if (acc.isClosed())
                            rc = OneAccountClosed;
                        else if (split.reconcileFlag() == eMyMoney::Split::State::Frozen)
                            rc = OneSplitFrozen;
                        else if (split.reconcileFlag() == eMyMoney::Split::State::Reconciled && rc < OneSplitReconciled)
                            rc = OneSplitReconciled;
                    }
```

#### AUTO 


```{c}
const auto list = match(index(0, 0), AccountsModel::AccountIdRole, QVariant(d->m_reconciledAccount.id()), -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto storageId = MyMoneyFile::instance()->storageId().toString(QUuid::WithoutBraces);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : tags) {
                                    if (d->m_tags.contains(tag)) {
                                        found = true;
                                        break;
                                    }
                                }
```

#### AUTO 


```{c}
const auto singleImportSummary = statementInterface()->import(statement);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& button : toolButtons) {
    button->setIcon(Icons::get(Icons::Icon::EditClear));
  }
```

#### AUTO 


```{c}
auto pluginFound = false;
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("qifimporter.rc");
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Transaction));
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        Q_D(KPayeesView);
        emit requestCustomContextMenu(eMenu::Menu::Transaction, d->ui->m_register->mapToGlobal(pos));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
          const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(split.accountId());
          if (acc.isIncomeExpense()) {
            return false;
            break;
          }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) { validateSelectedColumn(col, Column::Date); }
```

#### AUTO 


```{c}
auto const gotoPayee = pActions[eMenu::Action::GoToPayee];
```

#### AUTO 


```{c}
auto dataVariant = d->ui->m_parentAccounts->model()->data(d->ui->m_parentAccounts->currentIndex(), (int)eAccountsModel::Role::Account);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        validateSelectedColumn(col, Column::Debit);
    }
```

#### AUTO 


```{c}
auto profileName = investProfiles.begin();
```

#### AUTO 


```{c}
auto tc = endingBalanceDlg->chargeTransaction();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        d->categoryChanged(d->interestSplitModel, accountId, d->ui->interestAmountEdit, MyMoneyMoney::MINUS_ONE);
        d->updateWidgetState();
        updateTotalAmount();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotCopySplits(); }
```

#### AUTO 


```{c}
auto lastDirSeparator = appFullPath.lastIndexOf('/');
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto item : qAsConst(*m_idToItemMapper)) {
                m_referencedObjects.unite(item->constDataRef().referencedObjects());
            }
```

#### AUTO 


```{c}
auto selections = d->m_selections;
```

#### AUTO 


```{c}
const auto acc = file->account(d->accountId);
```

#### AUTO 


```{c}
auto i = (int)MyMoneySchedule::Attribute::Name;
```

#### AUTO 


```{c}
auto end = plugins.cend();
```

#### AUTO 


```{c}
const auto eol(QLatin1Char('\n'));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
                        // create a copy of the splits list in the transaction
                        // loop over all splits
                        for (auto& split : transaction.splits()) {
                            // if the split is assigned to one of the selected payees, we need to modify it
                            if (split.isMatched()) {
                                auto tm = split.matchedTransaction();
                                for (auto& sm : tm.splits()) {
                                    if (payeeInList(list, sm.payeeId())) {
                                        sm.setPayeeId(payee_id); // first modify payee in current split
                                        // then modify the split in our local copy of the transaction list
                                        tm.modifySplit(sm); // this does not modify the list object 'splits'!
                                    }
                                }
                                split.addMatch(tm);
                                transaction.modifySplit(split); // this does not modify the list object 'splits'!
                            }
                            if (payeeInList(list, split.payeeId())) {
                                split.setPayeeId(payee_id); // first modify payee in current split
                                // then modify the split in our local copy of the transaction list
                                transaction.modifySplit(split); // this does not modify the list object 'splits'!
                            }
                        } // for - Splits
                        file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
                    }
```

#### AUTO 


```{c}
const auto pairs = container.pairs();
```

#### AUTO 


```{c}
auto rc = openDatabase(newUrl);
```

#### AUTO 


```{c}
const auto kev = static_cast<QKeyEvent*>(event);
```

#### AUTO 


```{c}
const auto& sAccount
```

#### AUTO 


```{c}
const auto equitiesModel = Models::instance()->equitiesModel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : qAsConst(stdAccNames)) {
        if (id == MyMoneyAccount::stdAccName(idx))
            return true;
    }
```

#### AUTO 


```{c}
const auto idx = file->accountsModel()->indexById(accountId);
```

#### AUTO 


```{c}
const auto selectedAccountId = selection.firstSelection(SelectedObjects::Account);
```

#### AUTO 


```{c}
auto id = view->accountId();
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_balanceCol)
```

#### AUTO 


```{c}
auto indexes = journalModel->match(journalModel->index(0, 0), eMyMoney::Model::JournalSplitAccountIdRole, accountId);
```

#### AUTO 


```{c}
auto filter = MyMoneyXmlContentHandler2::readReport(subchild.toElement());
```

#### AUTO 


```{c}
auto row = d->ui->splitView->selectionModel()->selectedRows().first().row();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account(id).accountList())
        result += totalBalance(sAccount, date);
```

#### AUTO 


```{c}
const auto curPrice = file->price((*liabilities_it).tradingCurrencyId(), file->baseCurrency().id(), QDate::currentDate());
```

#### AUTO 


```{c}
const auto manager
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        d->categoryChanged(d->feeSplitModel, accountId, d->ui->feesAmountEdit, MyMoneyMoney::ONE);
        d->updateWidgetState();
        updateTotalAmount();
    }
```

#### AUTO 


```{c}
auto tocItem = dynamic_cast<TocItem*>(d->ui.m_tocTreeWidget->currentItem())
```

#### AUTO 


```{c}
const auto list = model->match(model->index(0, 0, parent->index()), (int)Role::ID, QVariant(accountId), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
auto isDeposit = false;
```

#### AUTO 


```{c}
const auto parts = entry.split(':');
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : balanceChanges) {
        if (!removedObjects.contains(id)) {
            // if we notify about balance change we don't need to notify about value change
            // for the same account since a balance change implies a value change
            d->m_valueChangedSet.remove(id);
            emit balanceChanged(account(id));
        }
    }
```

#### AUTO 


```{c}
const auto splits2 = tr.splits();
```

#### AUTO 


```{c}
auto txt = d->m_edit->text();
```

#### AUTO 


```{c}
auto security = d->haveWidget<KMyMoneyAccountCombo>("security");
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneySplit& split : d->m_splits) {
        split.negateValue();
        split.negateShares();
    }
```

#### AUTO 


```{c}
auto acBasicAccount = makeAccount(QString("Basic Account"), MyMoneyAccount::Checkings, openingBalance, QDate(2016, 1, 1), acAsset);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto col : equityColumns) {
            colIdx = columns.indexOf(col);
            if (colIdx != -1)
                columns.remove(colIdx);
        }
```

#### AUTO 


```{c}
const auto widgetCount = tabOrder.count();
```

#### AUTO 


```{c}
auto showButton = true;
```

#### AUTO 


```{c}
const auto subIdx = q->index(row, 0, idx);
```

#### AUTO 


```{c}
const auto list = idx.model()->match(idx.model()->index(0, 0), eMyMoney::Model::JournalTransactionIdRole,
                                             idx.data(eMyMoney::Model::JournalTransactionIdRole),
                                             -1,                         // all splits
                                             Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(accountFilterActive);
```

#### AUTO 


```{c}
const auto selection = d->ui->m_groupList->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
const auto startIdx = firstIndexById(newTransaction.id());
```

#### AUTO 


```{c}
auto w = m_widgetList[idx];
```

#### AUTO 


```{c}
auto s = readSplit(nodeList.item(i).toElement());
```

#### AUTO 


```{c}
const auto journalEntryId(selections.firstSelection(SelectedObjects::JournalEntry));
```

#### AUTO 


```{c}
const auto reconciledAccount = selections.firstSelection(SelectedObjects::ReconciliationAccount);
```

#### AUTO 


```{c}
const auto& selectedTransactionSplit = m_selectedTransactions[0].split();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            q->edit(idx);
        }
```

#### AUTO 


```{c}
auto s = t.splitByAccount(QString("Phony-ID"));
```

#### AUTO 


```{c}
const auto& sp = m_selectedTransactions[0].split();
```

#### AUTO 


```{c}
const auto rate = d->ui->totalAmountEdit->value() / d->ui->totalAmountEdit->shares();
```

#### AUTO 


```{c}
const auto rowTypeFromXML = d->stringToRowType(e.attribute(d->getAttrName(Report::Attribute::RowType)));
```

#### AUTO 


```{c}
const auto from = m_file->security(entry.from());
```

#### AUTO 


```{c}
const auto cond1 = !sec.id().isEmpty();
```

#### AUTO 


```{c}
const auto count = m_models->tagsModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto from = ui->m_security->security().id();
```

#### AUTO 


```{c}
const auto baseModel = model->baseModel(idx);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyReportPrivate::getElName(static_cast<Report::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
auto cat = dynamic_cast<KMyMoneyCategory*>(haveWidget("fee-account"))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id: qAsConst(openLedgers)) {
      auto thisId = id;
      openLedger(thisId.remove(QLatin1String("*")), id.endsWith(QLatin1String("*")));
    }
```

#### AUTO 


```{c}
const auto& a
```

#### AUTO 


```{c}
const auto args =
          QString::number(ui->m_comboDetail->currentIndex()) + ';' +
          QString::number(ui->m_forecastDays->value()) + ';' +
          QString::number(ui->m_tab->width()) + ';' +
          QString::number(ui->m_tab->height());
```

#### AUTO 


```{c}
const auto variantReport = reportsPlugin->requestData(QString(), eWidgetPlugin::WidgetType::NetWorthForecast);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*transaction).splits()) {
      const JournalEntry journalEntry(it.key(), transaction, split);
      static_cast<TreeItem<JournalEntry>*>(index(row, 0).internalPointer())->dataRef() = journalEntry;
      ++row;
    }
```

#### AUTO 


```{c}
const auto nonDelimMatch(nonDelimChars.match(txt[pos]));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pidid : loader->availableDelegates()) {
    QString delegateName;
    if (pidid == payeeIdentifiers::ibanBic::staticPayeeIdentifierIid())
      delegateName = i18n("IBAN and BIC");
    else if (pidid == payeeIdentifiers::nationalAccount::staticPayeeIdentifierIid())
      delegateName = i18n("National Account Number");
    comboBox->addItem(delegateName, QVariant(pidid));
  }
```

#### AUTO 


```{c}
auto appName = QString::fromUtf8(appFullPath.mid(lastDirSeparator + 1));
```

#### AUTO 


```{c}
const auto& f
```

#### AUTO 


```{c}
const auto defaultCountry = QLocale().country();
```

#### AUTO 


```{c}
auto saveToLocalFile = [&](QSaveFile* qfile)
        {
            QTextStream stream(qfile);
            stream.setCodec("UTF-8");
            stream << m_doc.toString();
            stream.flush();
        };
```

#### AUTO 


```{c}
const auto displayProperties = d->displayString(index, opt);
```

#### AUTO 


```{c}
auto const file = MyMoneyFile::instance();
```

#### AUTO 


```{c}
auto i = (int)Element::Schedule::Payment;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyModelBase::mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    // the following is only relevant for transactions with two splits
                    // in different currencies
                    const auto value = -transactionValue;
                    idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(value), eMyMoney::Model::SplitValueRole);
                    if (!value.isZero()) {
                        d->price = shares / value;
                    }
                    // make sure to use a possible foreign currency value
                    // in case of income and expense categories.
                    // in this case, we also need to use the reciprocal of the price
                    if (d->isIncomeExpense(splitIdx)) {
                        amount = -shares;
                        if (!shares.isZero()) {
                            d->price = value / shares;
                        }
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (startRow != -1) {
            selection.select(model()->index(startRow, 0), model()->index(lastRow, lastColumn));
            startRow = -1;
        }
    }
```

#### AUTO 


```{c}
auto height = fm.lineSpacing() + 6;
```

#### AUTO 


```{c}
const auto showAllSplits = LedgerViewSettings::instance()->showAllSplits();
```

#### AUTO 


```{c}
auto cat = dynamic_cast<KMyMoneyCategory*>(w);
```

#### AUTO 


```{c}
const auto iconHeight = d->m_lineHeight + 2 * d->m_margin;
```

#### AUTO 


```{c}
const auto payeeIdentifierId = element.attribute("type");
```

#### AUTO 


```{c}
const auto formattedValue = profit.isNegative() ? d->formatViewLabelValue(-profit, KMyMoneySettings::schemeColor(SchemeColor::Negative))
                                                  : d->formatViewLabelValue(profit, KMyMoneySettings::schemeColor(SchemeColor::Positive));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
          // create a copy of the splits list in the transaction
          // loop over all splits
          for (auto split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); ++i) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (d->tagInList(selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          } // for - Splits
          file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(TabOrderDialog);
        d->updateIndicatorRegion();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr decltype(reinterpret_cast<QModelIndex*>(0)->internalId()) invalidParent = std::numeric_limits<decltype(reinterpret_cast<QModelIndex*>(0)->internalId())>::max();
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("forecastview");
```

#### AUTO 


```{c}
auto interestAmountWidget = dynamic_cast<AmountEdit*>(haveWidget("interest-amount"));
```

#### AUTO 


```{c}
auto user = m_file->userModel()->itemById(m_file->fixedKey(MyMoneyFile::UserID));
```

#### AUTO 


```{c}
const auto& s
```

#### AUTO 


```{c}
auto categoryWidget = dynamic_cast<KMyMoneyCategory*>(d->m_editWidgets["category"])
```

#### AUTO 


```{c}
const auto& w
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : m_plugins.storage) {
        if (plugin->formatName().compare(QLatin1String("GNC")) == 0) {
          pReader = plugin->reader();
          break;
        }
      }
```

#### AUTO 


```{c}
const auto& split = journalEntry.split();
```

#### AUTO 


```{c}
auto a = account(accountId);
```

#### AUTO 


```{c}
const auto indexes = match(index(0, 0), eMyMoney::Model::Roles::IdRole, m_idLeadin, -1, Qt::MatchStartsWith | Qt::MatchRecursive);
```

#### AUTO 


```{c}
const auto registerPage = new KSettingsRegister();
```

#### AUTO 


```{c}
auto idx = MyMoneyFile::baseModel()->mapToBaseSource(treeItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : transactionList) {
    QString defaultAction;
    QList<MyMoneySplit> splits = transaction.splits();
    QStringList accounts;

    // check if base commodity is set. if not, set baseCurrency
    if (transaction.commodity().isEmpty()) {
      qDebug() << Q_FUNC_INFO << " " << transaction.id() << " has no base currency";
      transaction.setCommodity(file->baseCurrency().id());
      file->modifyTransaction(transaction);
    }

    bool isLoan = false;
    // Determine default action
    if (transaction.splitCount() == 2) {
      // check for transfer
      int accountCount = 0;
      MyMoneyMoney val;
      foreach (const auto split, splits) {
        auto acc = file->account(split.accountId());
        if (acc.accountGroup() == Account::Type::Asset
            || acc.accountGroup() == Account::Type::Liability) {
          val = split.value();
          accountCount++;
          if (acc.accountType() == Account::Type::Loan
              || acc.accountType() == Account::Type::AssetLoan)
            isLoan = true;
        } else
          break;
      }
      if (accountCount == 2) {
        if (isLoan)
          defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Amortization);
        else
          defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer);
      } else {
        if (val.isNegative())
          defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal);
        else
          defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit);
      }
    }

    isLoan = false;
    foreach (const auto split, splits) {
      auto acc = file->account(split.accountId());
      MyMoneyMoney val = split.value();
      if (acc.accountGroup() == Account::Type::Asset
          || acc.accountGroup() == Account::Type::Liability) {
        if (!val.isPositive()) {
          defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal);
          break;
        } else {
          defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit);
          break;
        }
      }
    }

#if 0
    // Check for correct actions in transactions referencing credit cards
    bool needModify = false;
    // The action fields are actually not used anymore in the ledger view logic
    // so we might as well skip this whole thing here!
    for (it_s = splits.begin(); needModify == false && it_s != splits.end(); ++it_s) {
      auto acc = file->account((*it_s).accountId());
      MyMoneyMoney val = (*it_s).value();
      if (acc.accountType() == Account::Type::CreditCard) {
        if (val < 0 && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal) && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer))
          needModify = true;
        if (val >= 0 && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit) && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer))
          needModify = true;
      }
    }

    // (Ace) Extended the #endif down to cover this conditional, because as-written
    // it will ALWAYS be skipped.

    if (needModify == true) {
      for (it_s = splits.begin(); it_s != splits.end(); ++it_s) {
        (*it_s).setAction(defaultAction);
        transaction.modifySplit(*it_s);
        file->modifyTransaction(transaction);
      }
      splits = transaction.splits();    // update local copy
      qDebug("Fixed credit card assignment in %s", transaction.id().data());
    }
#endif

    // Check for correct assignment of ActionInterest in all splits
    // and check if there are any duplicates in this transactions
    for (auto& split : splits) {
      MyMoneyAccount splitAccount = file->account(split.accountId());
      if (!accounts.contains(split.accountId())) {
        accounts << split.accountId();
      }
      // if this split references an interest account, the action
      // must be of type ActionInterest
      if (interestAccounts.contains(split.accountId())) {
        if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
          split.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
        // if it does not reference an interest account, it must not be
        // of type ActionInterest
      } else {
        if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
          split.setAction(defaultAction);
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
      }

      // check that for splits referencing an account that has
      // the same currency as the transactions commodity the value
      // and shares field are the same.
      if (transaction.commodity() == splitAccount.currencyId()
          && split.value() != split.shares()) {
        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
        split.setShares(split.value());
        transaction.modifySplit(split);
        file->modifyTransaction(transaction);
      }

      // fix the shares and values to have the correct fraction
      if (!splitAccount.isInvest()) {
        try {
          int fract = splitAccount.fraction();
          if (split.shares() != split.shares().convert(fract)) {
            qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
            split.setShares(split.shares().convert(fract));
            split.setValue(split.value().convert(fract));
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
          }
        } catch (const MyMoneyException &) {
          qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
        }
      }
    }

    ++cnt;
    if (!(cnt % 10))
      kmymoney->slotStatusProgressBar(cnt);
  }
```

#### AUTO 


```{c}
const auto idx = splitModel.index(row, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());

                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    // force the value of the second split to be the same as for the first
                    idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-amountValue), eMyMoney::Model::SplitValueRole);

                    // use the shares based on the second split
                    amountShares = -(splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>());

                    // adjust the commodity for the shares
                    const auto accountId = splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString();
                    const auto accountIdx = MyMoneyFile::instance()->accountsModel()->indexById(accountId);
                    const auto currencyId = accountIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
                    const auto currency = MyMoneyFile::instance()->currenciesModel()->itemById(currencyId);
                    d->ui->creditDebitEdit->setSharesCommodity(currency);
                }
            }
        }
```

#### AUTO 


```{c}
const auto splitIdx = d->splitModel.index(0, 0);
```

#### AUTO 


```{c}
auto reportTocItem = dynamic_cast<TocItemReport*>(tocItem)
```

#### AUTO 


```{c}
auto message = i18n("You are about to finish the reconciliation of this account with a difference between your bank statement and the transactions marked as cleared.\n"
                                "Are you sure you want to finish the reconciliation?");
```

#### AUTO 


```{c}
auto rc = 0;
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QUrl url;
            url.setUrl(QString::fromLatin1("https://%1/").arg(d->ui->urlEdit->text()));
            QDesktopServices::openUrl(url);
          }
```

#### AUTO 


```{c}
auto journalEntry = static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& column : qAsConst(m_columns))
      headerLabels.append(q->getHeaderName(column));
```

#### AUTO 


```{c}
const auto s = model->itemByIndex(idx);
```

#### AUTO 


```{c}
const auto favoriteIdx = MyMoneyModel<MyMoneyAccount>::indexById(MyMoneyAccount::stdAccName(d->defaults[0].groupType));
```

#### AUTO 


```{c}
const auto actionList = menu->actions();
```

#### AUTO 


```{c}
const auto endBalance = endingBalanceDlg->endingBalance();
```

#### AUTO 


```{c}
const auto acc = file->account(accountId);
```

#### AUTO 


```{c}
auto rs  = QString::fromLatin1("%1").arg(right.get_str().c_str());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto manager : managers) {
            manager->updateWidgets();
        }
```

#### AUTO 


```{c}
const auto category = MyMoneyFile::instance()->accountsModel()->itemById(categoryId);
```

#### AUTO 


```{c}
const auto accountId = split.accountId();
```

#### AUTO 


```{c}
const auto acCadChecking = makeAccount(QString("Canadian Checking"), eMyMoney::Account::Type::Checkings, moZero, QDate(2017, 8, 1), acAsset, "CAD");
```

#### AUTO 


```{c}
auto lastDirSeparator = appDir.lastIndexOf('/');
```

#### AUTO 


```{c}
auto doc = new QDomDocument(getElName(Statement::Element::KMMStatement));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { adjustDetailColumn(viewport()->width()); }
```

#### AUTO 


```{c}
auto colWidth = 55 / numberOfColumns;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->amountChanged();
    }
```

#### AUTO 


```{c}
const auto realParentIdx = indexById(item.parentAccountId());
```

#### AUTO 


```{c}
const auto& balanceChanges = d->m_balanceChangedSet;
```

#### AUTO 


```{c}
auto currentIdx = ui->m_budgetList->selectionModel()->currentIndex();
```

#### AUTO 


```{c}
auto pos = d->m_accountList.indexOf(account);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
    QList<MyMoneyAccount> accounts;
    MyMoneyFile::instance()->accountList(accounts, QStringList(), true);
    for (const auto& account : qAsConst(accounts)) {
      if (account.hasOnlineMapping()) {
        for (const auto& onlineTaskIid : plugin->availableJobs(account.id())) {
          if (m_onlineTasks.contains(onlineTaskIid)) {
            return true;
          }
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
    auto a = account(accountId);
    a.setInstitutionId(QString());
    modifyAccount(a);
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, a);
  }
```

#### AUTO 


```{c}
auto toolButton = d->m_sharedActionButtons.value(action).button;
```

#### AUTO 


```{c}
auto payee = index.data((int)eLedgerModel::Role::PayeeName).toString();
```

#### AUTO 


```{c}
const auto result = d->balanceToValue(account, it.value());
```

#### AUTO 


```{c}
const auto& sec = security(acc.currencyId());
```

#### AUTO 


```{c}
const auto fileExtension = plugin->fileExtension();
```

#### AUTO 


```{c}
auto acc = d->m_cache.account(id);
```

#### AUTO 


```{c}
auto index = 0;
```

#### AUTO 


```{c}
auto getColumns();
```

#### AUTO 


```{c}
const auto& region
```

#### AUTO 


```{c}
auto ctBasicExpense = makeAccount(QString("Basic Expense"), eMyMoney::Account::Expense, MyMoneyMoney(), QDate(2016, 1, 1), acExpense);
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(typeFilterActive);
```

#### AUTO 


```{c}
auto nextAccount = accList.cend();
```

#### AUTO 


```{c}
const auto shares = idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
auto baseView = qobject_cast<KMyMoneyViewBase*>(viewWidget);
```

#### AUTO 


```{c}
const auto data = sourceModel()->index(source_row, (int)eAccountsModel::Column::Account, source_parent).data((int)eAccountsModel::Role::ID);
```

#### AUTO 


```{c}
const auto colorsPage = new KSettingsColors();
```

#### AUTO 


```{c}
const auto tabOrder = grp.readEntry(name, defaultTabOrder);
```

#### AUTO 


```{c}
const auto& acc
```

#### AUTO 


```{c}
auto properUrl = normalizeUrlString(userInput);
```

#### AUTO 


```{c}
const auto accCurrent = d->m_file->account(itCurrent->data((int)Role::Account).value<MyMoneyAccount>().id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& pluginData : pluginDatas) {
        if (pluginData.serviceTypes().contains(QStringLiteral("KMyMoney/Plugin"))) {
            if (!onlyEnabled || isPluginEnabled(pluginData, pluginSection)) {
                // only use the first one found. Otherwise, always the last one
                // wins (usually the installed system version) and the QT_PLUGIN_PATH
                // env variable nor the current directory have an effect for KMyMoney
                if (!plugins.contains(pluginData.pluginId()))
                    plugins.insert(pluginData.pluginId(), pluginData);
            }
        }
    }
```

#### AUTO 


```{c}
auto memoWidget = dynamic_cast<KTextEdit*>(d->m_editWidgets["memo"])
```

#### AUTO 


```{c}
const auto view = qobject_cast<LedgerViewPage*>(d->ui->ledgerTab->currentWidget());
```

#### AUTO 


```{c}
const auto journalModel = MyMoneyFile::instance()->journalModel();
```

#### AUTO 


```{c}
auto icon = Icon::Forecast;
```

#### AUTO 


```{c}
auto w = tabOrderDialog->findChild<QWidget*>(widgetName);
```

#### AUTO 


```{c}
auto kvpResultOld = d->readKeyValuePairs("OFXSETTINGS", kvpInstitutionList);
```

#### AUTO 


```{c}
const auto idx = ui->m_groupList->currentIndex();
```

#### AUTO 


```{c}
auto j = 0;
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneySecurityPrivate *>(right.d_func());
```

#### AUTO 


```{c}
auto flags = QSortFilterProxyModel::flags(idx);
```

#### AUTO 


```{c}
auto itInstitution = institutionItemFromId(model, idInstitution);
```

#### AUTO 


```{c}
const auto jobId = indexes.first().data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto kev = static_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto postDate = new kMyMoneyDateInput;
```

#### AUTO 


```{c}
const auto view = viewBases.value(viewId, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : list) {
            for (const auto& split : transaction.splits()) {
                if (!split.shares().isZero()) {
                    auto acc = file->account(split.accountId());
                    if (q->isForecastAccount(acc)) {
                        dailyBalances balance;
                        balance = m_accountList[acc.id()];
                        //if it is income, the balance is stored as negative number
                        if (acc.accountType() == eMyMoney::Account::Type::Income) {
                            balance[transaction.postDate()] += (split.shares() * MyMoneyMoney::MINUS_ONE);
                        } else {
                            balance[transaction.postDate()] += split.shares();
                        }
                        m_accountList[acc.id()] = balance;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto security = d->m_storage->security(id);
```

#### AUTO 


```{c}
auto clearComboBox = [&](QComboBox* combobox) {
        combobox->setCurrentIndex(-1);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& statement : statements) {
    const auto singleImportSummary = statementInterface()->import(statement);
    if (singleImportSummary.isEmpty())
      ret = false;
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Action action) {
    if (pActions.contains(action)) {
      pActions[action]->trigger();
    }
  }
```

#### AUTO 


```{c}
const auto reason = next ? Qt::TabFocusReason : Qt::BacktabFocusReason;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotEditSplits(); }
```

#### AUTO 


```{c}
const auto sec = MyMoneyFile::instance()->security(category.currencyId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& report : file->reportList()) {
            QStringList tagList(report.tags());
            for (const auto& tag : tagList) {
                if (d->tagInList(selectedTags, tag)) {
                    used_reports.push_back(report);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto it_p = pPlugins.online.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : indexes) {
            if (idx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == id) {
                tid = idx.data(eMyMoney::Model::IdRole).toString();
                break;
            }
        }
```

#### AUTO 


```{c}
const auto idx = firstIndexByKey(key);
```

#### AUTO 


```{c}
const auto& account
```

#### AUTO 


```{c}
const auto filteredKeys = keys.filter(validKeyRegExp);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySchedulePrivate::getAttrName(static_cast<Schedule::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto totalValue = sourceModel()->data(source, eMyMoney::Model::Roles::AccountTotalValueRole);
```

#### AUTO 


```{c}
const auto acc = dynamic_cast<const MyMoneyAccount &>(obj);
```

#### AUTO 


```{c}
auto tabbar = new KMyMoneyTransactionForm::TabBar;
```

#### AUTO 


```{c}
auto pythonLib = new QLibrary();
```

#### AUTO 


```{c}
auto list = file->institutionList();
```

#### AUTO 


```{c}
auto matchType = p.matchData(ignoreCase, keys);
```

#### AUTO 


```{c}
const auto unmatchAction = qobject_cast<KDualAction*>(pActions[eMenu::Action::MatchTransaction]);
```

#### AUTO 


```{c}
auto idx = d->model->index(row, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : d->actions) {
        actionCollection()->removeAction(action);
    }
```

#### AUTO 


```{c}
auto idx = 1;
```

#### AUTO 


```{c}
const auto showInterest = !txt.isEmpty() && transactionTypesWithInterest.contains(d->m_activity->type());
```

#### AUTO 


```{c}
const auto qq = static_cast<ReconciliationLedgerViewPage*>(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName: m_displayedPlugins) {
    KPluginMetaData pluginData{fileName};
    if (isPluginEnabled(pluginData, group)) {
      pluginEnabled(pluginData);
    } else {
      pluginDisabled(pluginData);
    }
  }
```

#### AUTO 


```{c}
auto delegate
```

#### AUTO 


```{c}
auto requiredFields = new kMandatoryFieldGroup(q);
```

#### AUTO 


```{c}
auto t = dynamic_cast<Transaction*>(item);
```

#### AUTO 


```{c}
auto it_payee = payeeList.begin();
```

#### AUTO 


```{c}
auto count = 0;
```

#### AUTO 


```{c}
const auto actionStates = KBudgetViewPrivate::actionStates();
```

#### AUTO 


```{c}
auto changed = false;
```

#### AUTO 


```{c}
auto itInstitution = d->itemFromAccountId(this, account.institutionId());
```

#### AUTO 


```{c}
auto needAskUser = true;
```

#### AUTO 


```{c}
const auto accounts = d->accountsWatcher.result();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint& pos) {
      Q_D(KScheduledView);
      emit requestCustomContextMenu(eMenu::Menu::Schedule, d->ui->m_scheduleTree->viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
const auto num = validateCheckNumber(KMyMoneyUtils::nextCheckNumber(d->m_account));
```

#### AUTO 


```{c}
auto seconditem = d->m_accountsProxyModel->index(0, 0, firsitem);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(LedgerFilter);
        d->comboBox = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& schedule : file->scheduleList()) {
            // loop over all splits in the transaction of the schedule
            for (const auto& split : qAsConst(schedule.transaction().splits())) {
                for (auto i = 0; i < split.tagIdList().size(); ++i) {
                    // is the tag in the split to be deleted?
                    if (d->tagInList(selectedTags, split.tagIdList()[i])) {
                        used_schedules.push_back(schedule); // remember this schedule
                        break;
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const SelectedObjects& selections) {
        Q_D(KPayeesView);
        d->m_selections.setSelection(SelectedObjects::JournalEntry, selections.selection(SelectedObjects::JournalEntry));
        if (selections.selection(SelectedObjects::JournalEntry).count() == 1) {
            const auto file = MyMoneyFile::instance();
            const auto idx = file->journalModel()->indexById(selections.firstSelection(SelectedObjects::JournalEntry));
            d->m_selections.setSelection(SelectedObjects::Account, idx.data(eMyMoney::Model::SplitAccountIdRole).toString());
        }
        emit requestSelectionChange(d->m_selections);
    }
```

#### AUTO 


```{c}
const auto incomeValue = data(incomeList.front(), AccountsModel::AccountTotalValueRole);
```

#### AUTO 


```{c}
auto rc = OldActivity::isComplete(reason);
```

#### AUTO 


```{c}
const auto subAccountRows = rowCount();
```

#### AUTO 


```{c}
auto mdlItem = m_securitiesProxyModel->index(securityIdx.row(), SecuritiesModel::Security, securityIdx.parent());
```

#### AUTO 


```{c}
const auto next = validateCheckNumber(txt);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QChar& d, const QChar& c) {
        if (c == d) {
            rc.append(QLatin1Char('\\'));
        }
    }
```

#### AUTO 


```{c}
const auto model = qobject_cast<QStandardItemModel*>(d->ui->m_holidayRegion->model());
```

#### AUTO 


```{c}
const auto pos = d->m_accountList.indexOf(account);
```

#### AUTO 


```{c}
auto precisionWidget = dynamic_cast<KMyMoneyEdit*>(w)
```

#### AUTO 


```{c}
auto it_provider = m_onlinePlugins->constBegin();
```

#### AUTO 


```{c}
const auto subIdx = index(row, 0, idx);
```

#### AUTO 


```{c}
auto htmlPart = new KWebView();
```

#### AUTO 


```{c}
auto rc = currentPage->isComplete();
```

#### AUTO 


```{c}
const auto& row
```

#### AUTO 


```{c}
auto account = new KMyMoneyCategory;
```

#### AUTO 


```{c}
auto activity = new KMyMoneyActivityCombo();
```

#### AUTO 


```{c}
auto request = codec->toUnicode(libofx_request_accountinfo(&fi));
```

#### AUTO 


```{c}
auto form = dynamic_cast<KMyMoneyTransactionForm::TransactionForm*>(d->m_form)
```

#### CONST EXPRESSION 


```{c}
static constexpr char recoveryKeyId[] = "59B0F826D2B08440";
```

#### AUTO 


```{c}
auto reader = std::make_unique<MyMoneyStorageSql>(storage, url);
```

#### AUTO 


```{c}
auto b = inst.id().isEmpty() ? false : true;
```

#### AUTO 


```{c}
auto variant = view()->currentIndex().data((int)eAccountsModel::Role::ID);
```

#### LAMBDA EXPRESSION 


```{c}
[&, row](const auto column) {
      cell = node->child(row, column);      // try to get QStandardItem
      if (!cell) {                          // it may be uninitialized
        cell = new QStandardItem;           // so create one
        node->setChild(row, column, cell);  // and add it under the node
      }
    }
```

#### AUTO 


```{c}
auto properQUrl = QUrl::fromLocalFile(properUrl.remove(0, 1));
```

#### AUTO 


```{c}
auto* button
```

#### AUTO 


```{c}
const auto colInstitution = m_columns.indexOf(Column::Account);
```

#### AUTO 


```{c}
const auto originalStartRow = startRow;
```

#### AUTO 


```{c}
auto parent = file->account(d->m_currentCategory.parentAccountId());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& sec: securities) {
        if (!sec.tradingMarket().isEmpty()) {
            if (ui->m_tradingMarket->findText(sec.tradingMarket(), Qt::MatchExactly) == -1) {
                ui->m_tradingMarket->addItem(sec.tradingMarket());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
        auto a = account(accountId);
        a.setInstitutionId(QString());
        modifyAccount(a);
        d->m_changeSet += MyMoneyNotification(File::Mode::Modify, File::Object::Account, a.id());
    }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySchedule::getElName(static_cast<MyMoneySchedule::Element>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : selections.selection(SelectedObjects::JournalEntry)) {
                const auto idx = file->journalModel()->indexById(journalEntryId);
                if ((singleSplitTransactions < 1) || (multipleSplitTransactions < 2)) {
                    const auto indeces = file->journalModel()->indexesByTransactionId(idx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
                    switch (indeces.count()) {
                    case 0:
                        break;
                    case 1:
                        singleSplitTransactions++;
                        break;
                    default:
                        multipleSplitTransactions++;
                        break;
                    }
                }

                if (idx.data(eMyMoney::Model::JournalSplitIsMatchedRole).toBool()) {
                    ++matchedTransactions;
                }
                if (idx.data(eMyMoney::Model::TransactionIsImportedRole).toBool()) {
                    ++importedTransactions;
                }
                if ((singleSplitTransactions > 0) && (multipleSplitTransactions > 1) && (matchedTransactions > 0) && (importedTransactions > 0)) {
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto dataVariant = model()->data(index, (int)eAccountsModel::Role::Account);
```

#### AUTO 


```{c}
const auto idx = model->index(ui->tagCombo->currentIndex(), 0);
```

#### AUTO 


```{c}
const auto amount =
                        MyMoneyUtils::formatMoney((tidx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>() * factor), acc, security, true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : newTransaction.splits()) {
        JournalEntry journalEntry(QString("%1-%2").arg(oldKey, split.id()), transaction, split);
        // force recalc of row height
        journalEntry.setLinesInLedger(0);
        const auto newIdx = index(row, 0);
        static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer())->dataRef() = journalEntry;
        if (m_idToItemMapper) {
            m_idToItemMapper->insert(journalEntry.id(), static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer()));
        }
        ++row;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        validateSelectedColumn(col, Column::Credit);
    }
```

#### AUTO 


```{c}
auto balance = m_file->balance(account.id());
```

#### AUTO 


```{c}
auto previousTabWidget = [&]() {
                        --idx;
                        if (idx < 0) {
                            idx = tabOrder.count() - 1;
                        }
                        w = findChild<QWidget*>(tabOrder.at(idx));
                    };
```

#### AUTO 


```{c}
auto amountShares = d->m_split.shares();
```

#### AUTO 


```{c}
const auto totalValue = sourceModel()->data(source, (int)Role::TotalValue);
```

#### AUTO 


```{c}
const auto currency = MyMoneyFile::instance()->currency(account.tradingCurrencyId());
```

#### AUTO 


```{c}
const auto row = accountItem->row();
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Menu type, const QPoint& pos) {
    if (pMenus.contains(type)) {
      pMenus[type]->exec(pos);
    } else
      qDebug() << "Context menu for type" << static_cast<int>(type) << " not found";
  }
```

#### AUTO 


```{c}
auto eroot = doc->createElement(getElName(Statement::Element::KMMStatement));
```

#### AUTO 


```{c}
const auto filter = filterTab->setupFilter();
```

#### AUTO 


```{c}
auto it = pairs.cbegin();
```

#### AUTO 


```{c}
auto forecastChart = new reports::KReportChartView(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
        const auto acc = file->account(split.accountId());
        if (acc.isIncomeExpense()) {
          if (split.shares().isNegative() && (type == Interest)) {
            return true;
          }
          else if (split.shares().isPositive() && (type == Fees)) {
            return true;
          }
        }
      }
```

#### AUTO 


```{c}
auto items = d->ui.m_tocTreeWidget->selectedItems();
```

#### AUTO 


```{c}
auto acc = d->accountCache.value(id, &nullElement);
```

#### AUTO 


```{c}
auto number = new KMyMoneyLineEdit;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : splits) {
      MyMoneyAccount splitAccount = file->account(split.accountId());
      if (!accounts.contains(split.accountId())) {
        accounts << split.accountId();
      }
      // if this split references an interest account, the action
      // must be of type ActionInterest
      if (interestAccounts.contains(split.accountId())) {
        if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
          split.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
        // if it does not reference an interest account, it must not be
        // of type ActionInterest
      } else {
        if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
          split.setAction(defaultAction);
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
      }

      // check that for splits referencing an account that has
      // the same currency as the transactions commodity the value
      // and shares field are the same.
      if (transaction.commodity() == splitAccount.currencyId()
          && split.value() != split.shares()) {
        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
        split.setShares(split.value());
        transaction.modifySplit(split);
        file->modifyTransaction(transaction);
      }

      // fix the shares and values to have the correct fraction
      if (!splitAccount.isInvest()) {
        try {
          int fract = splitAccount.fraction();
          if (split.shares() != split.shares().convert(fract)) {
            qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
            split.setShares(split.shares().convert(fract));
            split.setValue(split.value().convert(fract));
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
          }
        } catch (const MyMoneyException &) {
          qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
        }
      }
    }
```

#### AUTO 


```{c}
const auto profile = PluginSettings::qifExportProfile();
```

#### AUTO 


```{c}
auto fraction = acc.fraction();
```

#### AUTO 


```{c}
const auto pageItem = viewFrames[idView];
```

#### AUTO 


```{c}
const auto end = d->journalModel.rowCount();
```

#### AUTO 


```{c}
const auto lineEdit = d->m_accountCombo->lineEdit();
```

#### AUTO 


```{c}
auto variant = view()->currentIndex().data(eMyMoney::Model::Roles::IdRole);
```

#### AUTO 


```{c}
const auto accountList = MyMoneyFile::instance()->accountsModel()->itemList();
```

#### AUTO 


```{c}
auto reconcile = new KMyMoneyReconcileCombo;
```

#### AUTO 


```{c}
auto dataVariant = itemData(index);
```

#### AUTO 


```{c}
const auto baseIdx = baseModel->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto favItem = d->itemFromAccountId(favoriteAccountsItem, account.id());
```

#### AUTO 


```{c}
auto factor = MyMoneyMoney::ONE;
```

#### AUTO 


```{c}
const auto key = QLatin1String("driver");
```

#### AUTO 


```{c}
const auto view = qobject_cast<LedgerViewPage*>(ui->ledgerTab->widget(idx));
```

#### AUTO 


```{c}
auto itAcc = d->itemFromId(this, acc->id(), Role::EquityID);
```

#### AUTO 


```{c}
auto result = false;
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(haveWidget("amount"));
```

#### AUTO 


```{c}
auto sec = MyMoneyFile::instance()->security(account.currencyId());
```

#### AUTO 


```{c}
const auto w = dlg_d->m_widgetList.at(target_index);
```

#### AUTO 


```{c}
auto index = costCenterModel->index(costCenterIndex, 0);
```

#### AUTO 


```{c}
auto dataVariant = itemData(currentIndex());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& plugin : plugins.standard) {
        plugin->updateActions(selections);
    }
```

#### AUTO 


```{c}
const auto& a = splits.at(0).id().compare(split.id()) == 0 ? acc : file->account(splits.at(0).accountId());
```

#### AUTO 


```{c}
const auto transactionFactor(d->amountHelper->value().isNegative() ? MyMoneyMoney::ONE : MyMoneyMoney::MINUS_ONE);
```

#### AUTO 


```{c}
const auto& split
```

#### AUTO 


```{c}
auto it = balances.constBegin();
```

#### AUTO 


```{c}
const auto journalEntry = file->journalModel()->itemByIndex(idx);
```

#### AUTO 


```{c}
const auto count = splitCount();
```

#### AUTO 


```{c}
const auto splitId = index.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto reconciliationState = idx.data(eMyMoney::Model::SplitReconcileFlagRole).value<eMyMoney::Split::State>();
```

#### AUTO 


```{c}
const auto value = split.shares();
```

#### AUTO 


```{c}
const auto account = childNode->data(AccountRole).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto haveAt = true;
```

#### AUTO 


```{c}
const auto accountsView = static_cast<KAccountsView*>(viewBases[view]);
```

#### AUTO 


```{c}
const auto detailLevelFromXML = stringToDetailLevel(node.attribute(attributeName(Attribute::Report::Detail)));
```

#### AUTO 


```{c}
auto xml = split.value(attributeName(Attribute::Split::KMMatchedTx));
```

#### AUTO 


```{c}
auto it_t = d->m_transactions.begin();
```

#### AUTO 


```{c}
auto t = s.transaction();
```

#### AUTO 


```{c}
auto menu = new QMenu(i18nc("Menu header", "Budget options"));
```

#### AUTO 


```{c}
auto prev = parent->findChild<QWidget*>(tabOrder.at(0));
```

#### LAMBDA EXPRESSION 


```{c}
[&](const MyMoneySecurity& commodity) {
        Q_D(AmountEditCurrencyHelper);
        d->amount->setSharesCommodity(commodity);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transactionId : transactions) {
                if (d->canBePrinted(accountId, transactionId)) {
                    actionEnabled = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto currency = MyMoneyFile::instance()->currenciesModel()->itemById(currencyId);
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnInstitution]);
```

#### AUTO 


```{c}
const auto acc = Models::instance()->accountsModel()->data(index, (int)eAccountsModel::Role::Account).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto depositWidget = dynamic_cast<AmountEdit*>(d->m_editWidgets["deposit"]);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(KEditScheduleDlg);
        const auto model = d->ui->frequencyEdit->model();
        const auto paymentType = model->index(idx, 0).data(eMyMoney::Model::ScheduleFrequencyRole).value<eMyMoney::Schedule::Occurrence>();

        d->ui->endSeriesOption->setEnabled(paymentType != Schedule::Occurrence::Once);
        bool isEndSeries = d->ui->endSeriesOption->isChecked();
        if (isEndSeries)
            d->ui->endOptionsFrame->setEnabled(paymentType != Schedule::Occurrence::Once);
        switch (paymentType) {
        case Schedule::Occurrence::Daily:
        case Schedule::Occurrence::Weekly:
            d->ui->frequencyNoEdit->setEnabled(true);
            d->ui->lastDayInMonthOption->setEnabled(false);
            break;

        case Schedule::Occurrence::EveryHalfMonth:
        case Schedule::Occurrence::Monthly:
        case Schedule::Occurrence::Yearly:
            // Supports Frequency Number
            d->ui->frequencyNoEdit->setEnabled(true);
            d->ui->lastDayInMonthOption->setEnabled(true);
            break;

        default:
            // Multiplier is always 1
            d->ui->frequencyNoEdit->setEnabled(false);
            d->ui->frequencyNoEdit->setValue(1);
            d->ui->lastDayInMonthOption->setEnabled(true);
            break;
        }
        if (isEndSeries && (paymentType != Schedule::Occurrence::Once)) {
            // Changing the frequency changes the number
            // of remaining transactions
            d->m_schedule.setNextDueDate(d->transactionEditor->postDate());
            d->m_schedule.setOccurrenceMultiplier(d->ui->frequencyNoEdit->value());
            d->m_schedule.setOccurrencePeriod(paymentType);
            d->m_schedule.setEndDate(d->ui->finalPaymentDateEdit->date());
            d->updateTransactionsRemaining();
        }
    }
```

#### AUTO 


```{c}
auto acc = d->accountsModel.itemById(split.accountId());
```

#### AUTO 


```{c}
const auto model = d->ui->frequencyEdit->model();
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
    });
```

#### AUTO 


```{c}
const auto acc = file->accountsModel()->itemById(idx.data(eMyMoney::Model::SplitAccountIdRole).toString());
```

#### AUTO 


```{c}
auto form = dynamic_cast<KMyMoneyTransactionForm::TransactionForm*>(d->m_regForm);
```

#### AUTO 


```{c}
const auto splitIdx = d->feeSplitModel.index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); i++) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          }
```

#### AUTO 


```{c}
const auto dlg_d = m_dialog->d_func();
```

#### AUTO 


```{c}
auto indexes = selected.front().indexes();
```

#### AUTO 


```{c}
auto firsitem = d->m_accountsProxyModel->index(0, 0, QModelIndex());
```

#### AUTO 


```{c}
auto accountMatched = !(filter & accountFilterActive);
```

#### AUTO 


```{c}
const auto count = m_models->costCenterModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto it = sharedActions.cbegin();
```

#### AUTO 


```{c}
const auto sec = MyMoneyFile::instance()->security(d->m_account.currencyId());
```

#### AUTO 


```{c}
auto b = !ui->m_budgetList->selectionModel()->selectedIndexes().isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tidx : indexes) {
                    if (tidx.data(eMyMoney::Model::IdRole).toString() == journalEntryId)
                        continue;
                    const auto acc = file->accountsModel()->itemById(tidx.data(eMyMoney::Model::SplitAccountIdRole).toString());
                    const auto category = file->accountToCategory(acc.id());
                    const auto amount =
                        MyMoneyUtils::formatMoney((tidx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>() * factor), acc, security, true);

                    txt += QString("<tr><td>%1</td><td align=right>%2</td></tr>").arg(category, amount);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& pluginData: plugins) {
    loadPlugin(pluginData);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : pPlugins.storage) {
    try {
      if (auto pStorage = plugin->open(url)) {
        MyMoneyFile::instance()->attachStorage(pStorage);
        d->m_storageInfo.type = plugin->storageType();
        if (plugin->storageType() != eKMyMoney::StorageType::GNC) {
          d->m_storageInfo.url = url;
          writeLastUsedFile(url.toDisplayString(QUrl::PreferLocalFile));
          /* Don't use url variable after KRecentFilesAction::addUrl
         * as it might delete it.
         * More in API reference to this method
         */
          d->m_recentFiles->addUrl(url);
        }
        d->m_storageInfo.isOpened = true;
        break;
      }
    } catch (const MyMoneyException &e) {
      KMessageBox::detailedError(this, i18n("Cannot open file as requested."), QString::fromLatin1(e.what()));
      return false;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& sm : tm.splits()) {
                                    if (payeeInList(list, sm.payeeId())) {
                                        sm.setPayeeId(payee_id); // first modify payee in current split
                                        // then modify the split in our local copy of the transaction list
                                        tm.modifySplit(sm); // this does not modify the list object 'splits'!
                                    }
                                }
```

#### AUTO 


```{c}
auto isOpened = false;
```

#### AUTO 


```{c}
auto sch = readSchedule(m_baseNode);
```

#### AUTO 


```{c}
auto transactionSecurity = security(t.commodity());
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneyTransaction& transaction : list) {
        // if we have a categorization, make sure we remove
        // the 'imported' flag automagically
        if (transaction.splitCount() > 1)
          transaction.setImported(false);

        // create information about min and max balances
        foreach (const auto split, transaction.splits()) {
          auto acc = file->account(split.accountId());
          accountIds[acc.id()] = true;
          MyMoneyMoney balance = file->balance(acc.id());
          if (!acc.value("minBalanceEarly").isEmpty()) {
            minBalanceEarly[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceEarly"));
          }
          if (!acc.value("minBalanceAbsolute").isEmpty()) {
            minBalanceAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceAbsolute"));
            minBalanceEarly[acc.id()] = false;
          }
          if (!acc.value("maxCreditEarly").isEmpty()) {
            maxCreditEarly[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditEarly"));
          }
          if (!acc.value("maxCreditAbsolute").isEmpty()) {
            maxCreditAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditAbsolute"));
            maxCreditEarly[acc.id()] = false;
          }

        // and adjust opening date of invest accounts
          if (acc.isInvest()) {
            if (acc.openingDate() > t.postDate()) {
              try {
                acc.setOpeningDate(t.postDate());
                file->modifyAccount(acc);
              } catch(MyMoneyException& ) {
                qDebug() << "Unable to modify opening date for invest account" << acc.name() << acc.id();
              }
            }
          }
        }

        if (transaction.id().isEmpty()) {
          bool enter = true;
          if (askForSchedule && transaction.postDate() > QDate::currentDate()) {
            KGuiItem enterButton(i18n("&Enter"),
                                 Icons::get(Icon::DialogOK),
                                 i18n("Accepts the entered data and stores it"),
                                 i18n("Use this to enter the transaction into the ledger."));
            KGuiItem scheduleButton(i18n("&Schedule"),
                                    Icons::get(Icon::NewSchedule),
                                    i18n("Accepts the entered data and stores it as schedule"),
                                    i18n("Use this to schedule the transaction for later entry into the ledger."));

            enter = KMessageBox::questionYesNo(d->m_regForm, QString("<qt>%1</qt>").arg(i18n("The transaction you are about to enter has a post date in the future.<br/><br/>Do you want to enter it in the ledger or add it to the schedules?")), i18nc("Dialog caption for 'Enter or schedule' dialog", "Enter or schedule?"), enterButton, scheduleButton, "EnterOrScheduleTransactionInFuture") == KMessageBox::Yes;
          }
          if (enter) {
            // add new transaction
            file->addTransaction(transaction);
            // pass the newly assigned id on to the caller
            newId = transaction.id();
            // refresh account object for transactional changes
            // refresh account and transaction object because they might have changed
            d->m_account = file->account(d->m_account.id());
            t = transaction;

            // if a new transaction has a valid number, keep it with the account
            d->keepNewNumber(transaction);
          } else {
            // turn object creation on, so that moving the focus does
            // not screw up the dialog that might be popping up
            emit objectCreation(true);
            emit scheduleTransaction(transaction, eMyMoney::Schedule::Occurrence::Once);
            emit objectCreation(false);

            newTransactionCreated = false;
          }

          // send out the post date of this transaction
          emit lastPostDateUsed(transaction.postDate());
        } else {
          // modify existing transaction
          // its number might have been edited
          // bearing in mind it could contain alpha characters
          d->keepNewNumber(transaction);
          file->modifyTransaction(transaction);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& index : indexList) {
        sortedList[index.row()] = index.row();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& button : m_buttons) {
            if (button->isDown()) {
                createAccount();
                return;
            }
        }
```

#### AUTO 


```{c}
const auto dataLockFromXML = stringToDataLockAttribute(node.attribute(attributeName(Attribute::Report::DataLock)));
```

#### AUTO 


```{c}
const auto chartTypeFromXML = stringToChartType(node.attribute(attributeName(Attribute::Report::ChartType)));
```

#### AUTO 


```{c}
const auto accIdx = file->accountsModel()->indexById(accId);
```

#### AUTO 


```{c}
auto categoryMatched = !(filter & categoryFilterActive);
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemByIndex(idx);
```

#### AUTO 


```{c}
const auto securityId = idx.data(eMyMoney::Model::TransactionCommodityRole).toString();
```

#### AUTO 


```{c}
auto ctBasicIncome = makeAccount(QString("Basic Income"), eMyMoney::Account::Type::Income, MyMoneyMoney(), QDate(2016, 1, 1), acIncome);
```

#### AUTO 


```{c}
auto account = dlg->account();
```

#### AUTO 


```{c}
const auto accountIdx = d->accountsModel->indexById(institution.id());
```

#### AUTO 


```{c}
auto transaction = QSharedPointer<MyMoneyTransaction>(new MyMoneyTransaction(id, t));
```

#### AUTO 


```{c}
auto t_cycle = 0;
```

#### AUTO 


```{c}
const auto view = qobject_cast<const SplitView*>(opt.widget);
```

#### AUTO 


```{c}
auto idx = MyMoneyFile::instance()->accountsModel()->indexById(objId);
```

#### AUTO 


```{c}
const auto tag = node.tagName();
```

#### AUTO 


```{c}
auto acc = file->account(split.accountId());
```

#### AUTO 


```{c}
auto fileNeedsToBeSaved = false;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
                if (!KGPGFile::keyAvailable(key)) {
                    KMessageBox::sorry(nullptr, i18n("<p>You have specified to encrypt your data for the user-id</p><p><center><b>%1</b>.</center></p><p>Unfortunately, a valid key for this user-id was not found in your keyring. Please make sure to import a valid key for this user-id. This time, encryption is disabled.</p>", key), i18n("GPG Key not found"));
                    encryptFile = false;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int offset) {
        switch(d->m_dateEdit->currentSection()) {
        case QDateTimeEdit::DaySection:
            slotDateChosen(d->m_date.addDays(offset));
            break;
        case QDateTimeEdit::MonthSection:
            slotDateChosen(d->m_date.addMonths(offset));
            break;
        case QDateTimeEdit::YearSection:
            slotDateChosen(d->m_date.addYears(offset));
            break;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
const auto onlineBalanceDate = index.data(eMyMoney::Model::AccountOnlineBalanceDateRole).toDate();
```

#### AUTO 


```{c}
auto parent = w;
```

#### AUTO 


```{c}
auto val = PyDict_GetItem(retVal, key);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
        if (split.id() == d->split.id()) {
            continue;
        }
        const auto rows = d->splitModel.rowCount();
        int row;
        for (row = 0; row < rows; ++row) {
            const QModelIndex index = d->splitModel.index(row, 0);
            if (index.data(eMyMoney::Model::IdRole).toString() == split.id()) {
                break;
            }
        }

        // if the split is not in the model, we get rid of it
        if (d->splitModel.rowCount() == row) {
            t.removeSplit(split);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @note add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      // case eMyMoney::File::Object::Currency:
      // case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
      case eMyMoney::File::Object::Transaction:
      // case eMyMoney::File::Object::Price:
      // case eMyMoney::File::Object::Parameter:
      case eMyMoney::File::Object::OnlineJob:
      // case eMyMoney::File::Object::Report:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
const auto idx = splitModel->index(row, 0);
```

#### AUTO 


```{c}
auto &column
```

#### AUTO 


```{c}
auto it = plugins.begin();
```

#### AUTO 


```{c}
const auto autoClearList = doAutoReconciliation(journalEntryIds, endBalance - startBalance);
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("icalendarexporter.rc");
```

#### AUTO 


```{c}
auto interestAccountWidget = d->haveWidget<KMyMoneyAccountCombo>("interestCombo");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
        d->m_selections.addSelection(SelectedObjects::OnlineJob, idx.data(eMyMoney::Model::IdRole).toString());
    }
```

#### AUTO 


```{c}
const auto myId = index.model()->data(index, eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto accountIds = selections.selection(SelectedObjects::Account);
```

#### AUTO 


```{c}
auto newAcc = acc;
```

#### LAMBDA EXPRESSION 


```{c}
[] (const MyMoneySecurity& c1, const MyMoneySecurity& c2)
        {
          return c1.name().compare(c2.name()) < 0;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
          acc = MyMoneyFile::instance()->account(split.accountId());
          if (split.id() != journalEntry.split().id()) {
            if (!acc.isIncomeExpense()) {
              // for stock accounts we show the portfolio account
              if (acc.isInvest()) {
                acc = MyMoneyFile::instance()->account(acc.parentAccountId());
              }
              break;
            }
          }
        }
```

#### AUTO 


```{c}
const auto payeeRow = d->ui->payeeEdit->currentIndex();
```

#### AUTO 


```{c}
const auto retAction = menu.exec(QCursor::pos());
```

#### AUTO 


```{c}
auto payee3 = MyMoneyXmlContentHandler::readPayee(el);
```

#### AUTO 


```{c}
const auto action = idx.data(eMyMoney::Model::SplitActionRole).toString();
```

#### AUTO 


```{c}
const auto start = filterModel->index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
            updateNextObjectId(item.id());
            static_cast<TreeItem<T>*>(index(row, 0).internalPointer())->dataRef() = item;
            ++row;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& region : regionList) {
        const auto entries = region.split(QLatin1Char('\0'));
        if (entries.at(0).compare(lastCountry)) {
            lastCountry = entries.at(0);
            item = new QStandardItem(lastCountry);
            item->setFlags(item->flags() & ~(Qt::ItemIsSelectable));
            item->setFont(boldFont);

            model->appendRow(item);
        }
        item = new QStandardItem(entries.at(1));
        item->setData(entries.at(2), Qt::UserRole);
        model->appendRow(item);
    }
```

#### AUTO 


```{c}
auto accounts = document.createElement(getElName(Element::AccountIDS));
```

#### AUTO 


```{c}
auto a = actionCollection()->addAction(kpartgui);
```

#### AUTO 


```{c}
const auto toolButtons = findChildren<QToolButton*>();
```

#### AUTO 


```{c}
auto& refPlugins = referencePluginDatas;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& name : qAsConst(widgetIds)) {
        auto w = d->haveWidget<QWidget>(name);
        if (w) {
            w->setVisible(visible);
        } else {
            qCritical() << "Activity::setWidgetVisibility unknown widget" << name;
        }
    }
```

#### AUTO 


```{c}
auto xml = docMatchedTransaction.toString();
```

#### AUTO 


```{c}
const auto s1 = (transaction.splits().size() < 1) ? MyMoneySplit() : transaction.splits()[0];
```

#### AUTO 


```{c}
auto printer = KMyMoneyPrinter::startPrint();
```

#### AUTO 


```{c}
auto currency = MyMoneyFile::instance()->currency(t.commodity());
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyXmlContentHandler2::elementName(static_cast<Element::Report>(i)).isEmpty();
```

#### AUTO 


```{c}
auto w = tabOrderDialog->findChild<QWidget*>("accountCombo");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
            // create a copy of the splits list in the transaction
            // loop over all splits
            for (auto& split : transaction.splits()) {
              // if the split is assigned to one of the selected payees, we need to modify it
              if (payeeInList(m_selectedPayeesList, split.payeeId())) {
                split.setPayeeId(payee_id); // first modify payee in current split
                // then modify the split in our local copy of the transaction list
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
            } // for - Splits
            file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
          }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyBudget::getAttrName(static_cast<MyMoneyBudget::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto cashflow = dynamic_cast<KMyMoneyCashFlowCombo*>(haveWidget("cashflow"))
```

#### AUTO 


```{c}
auto tmpAcc = dynamic_cast<const MyMoneyAccount * const>(obj);
```

#### AUTO 


```{c}
auto l = dynamic_cast<QLabel*>(haveWidget("interest-amount-label"));
```

#### AUTO 


```{c}
auto i = (int)MyMoneySplit::Attribute::ID;
```

#### AUTO 


```{c}
const auto account = childNode->data((int)Role::Account).value<MyMoneyAccount>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (auto i = 0; i < tagIdList.size(); ++i) {
              if (d->tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList);
            trans.modifySplit(split); // does not modify the list object 'splits'!
          }
```

#### AUTO 


```{c}
auto value = MyMoneyMoney(data);
```

#### AUTO 


```{c}
const auto expenseList = match(index(0, 0),
                                 (int)Role::ID,
                                 MyMoneyFile::instance()->expense().id(),
                                 1,
                                 Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
auto const model = parent->model();
```

#### AUTO 


```{c}
auto item = d->itemFromAccountId(parentAccountItem, account.id());
```

#### AUTO 


```{c}
auto col
```

#### AUTO 


```{c}
const auto path = d->ui->urlEdit->text();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotAssignNumber(); }
```

#### AUTO 


```{c}
const auto count = m_file->costCenterModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto bindValuesToQuery = [&]() {
      query.bindValue(":id", id);
      query.bindValue(":originAccount", task.responsibleAccount());
      query.bindValue(":value", task.value().toString());
      query.bindValue(":purpose", task.purpose());
      query.bindValue(":endToEndReference", (task.endToEndReference().isEmpty()) ? QVariant() : QVariant::fromValue(task.endToEndReference()));
      query.bindValue(":beneficiaryName", task.beneficiaryTyped().ownerName());
      query.bindValue(":beneficiaryIban", task.beneficiaryTyped().electronicIban());
      query.bindValue(":beneficiaryBic", (task.beneficiaryTyped().storedBic().isEmpty()) ? QVariant() : QVariant::fromValue(task.beneficiaryTyped().storedBic()));
      query.bindValue(":textKey", task.textKey());
      query.bindValue(":subTextKey", task.subTextKey());
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& column : qAsConst(columns)) {
                const auto idx = index.model()->index(index.row(), column);
                const auto rowCount = d->displayString(idx, option).lines.count() + d->displayMatchedString(idx, option).lines.count();
                if (rowCount > rows) {
                    rows = rowCount;
                }
            }
```

#### AUTO 


```{c}
const auto accountId = model->data(source_index, eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto institutionItem = d->institutionItemFromId(this, institution->id())
```

#### AUTO 


```{c}
const auto accountIdx = MyMoneyFile::baseModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
const auto ixAccount = mapToSource(BudgetAccountsProxyModel::index(index.row(), AccountsModel::Account, index.parent()));
```

#### AUTO 


```{c}
const auto idx = indexById(key);
```

#### AUTO 


```{c}
const auto idx = filter->index(ui->tagCombo->currentIndex(), 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
        const auto acc = file->account(split.accountId());
        if (acc.isIncomeExpense()) {
          if (split.shares().isNegative() ^ fees) {
            value += split.value();
          }
        }
      }
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnOnlineJob]);
```

#### AUTO 


```{c}
const auto attributeMap = domElement.attributes();
```

#### AUTO 


```{c}
const auto cols = m_model.columnCount();
```

#### AUTO 


```{c}
auto cat = dynamic_cast<KMyMoneyCategory*>(haveWidget("interest-account"))
```

#### AUTO 


```{c}
auto reconcile = dynamic_cast<KMyMoneyReconcileCombo*>(*it_w);
```

#### AUTO 


```{c}
const auto scheduleId = idx.data(eMyMoney::Model::TransactionScheduleIdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotGoToPayee(); }
```

#### AUTO 


```{c}
auto i = (int)Tag::Attribute::Name;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : qAsConst(schedule.transaction().splits())) {
        for (auto i = 0; i < split.tagIdList().size(); ++i) {
          // is the tag in the split to be deleted?
          if (d->tagInList(selectedTags, split.tagIdList()[i])) {
            used_schedules.push_back(schedule); // remember this schedule
            break;
          }
        }
      }
```

#### AUTO 


```{c}
auto dlg = dialog();
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["amount"])
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& idx) { Q_D(KMyMoneyAccountTreeView); d->openIndex(idx); }
```

#### AUTO 


```{c}
auto pairElement = document.createElement(elementName(Element::Account::ReconciliationEntry));
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
    Q_D(KPayeesView);
    d->m_renameProxyModel->setReferenceFilter(d->ui->m_filterBox->itemData(idx));
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&, newColPos](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          childItem->insertColumns(newColPos, 1);
          if (childItem->hasChildren())
            self(self, childItem);
          this->d->setAccountData(item, j, childItem->data(AccountRole).value<MyMoneyAccount>(), QList<Columns> {column});
        }
        return true;
      }
```

#### AUTO 


```{c}
const auto row = rowAt(helpEvent->y());
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney");
```

#### AUTO 


```{c}
const auto& journalEntryId
```

#### AUTO 


```{c}
auto accountID = childIdx.data((int)eAccountsModel::Role::ID).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
            Q_D(KInvestmentView);
            const auto tab = static_cast<eView::Investment::Tab>(index);

            switch (tab) {
            case eView::Investment::Tab::Equities:
                d->m_selections = d->m_equitySelections;
                break;
            case eView::Investment::Tab::Securities:
                d->m_selections = d->m_securitySelections;
                break;
            }
            emit requestSelectionChange(d->m_selections);
        }
```

#### AUTO 


```{c}
const auto importSummary = importStatement(statement);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx: indexes) {
      budgetIds << idx.data(eMyMoney::Model::IdRole).toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : splits) {
            split.clearId();
            d->m_transaction.addSplit(split);
        }
```

#### AUTO 


```{c}
auto ctBasicExpense = makeAccount(QString("Basic Expense"), eMyMoney::Account::Type::Expense, MyMoneyMoney(), QDate(2016, 1, 1), acExpense);
```

#### AUTO 


```{c}
const auto& tagIdList = s.tagIdList();
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::account(account.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : idList) {
        d->addTagWidget(id);
    }
```

#### AUTO 


```{c}
auto warnLevel = NoWarning;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid())
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyModelBase::mapFromBaseSource(d->payeesModel, payeeIdx).row());
                else
                    d->ui->payeeEdit->setCurrentIndex(0);

                bool blocked = d->ui->accountCombo->blockSignals(true);
                switch (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole).toInt()) {
                case 1:
                    d->ui->accountCombo->clearEditText();
                    d->ui->accountCombo->setSelected(QString());
                    break;
                case 2:
                    d->ui->accountCombo->setSelected(splitIdx.data(eMyMoney::Model::TransactionCounterAccountIdRole).toString());
                    break;
                default:
                    d->ui->accountCombo->setEditText(splitIdx.data(eMyMoney::Model::TransactionCounterAccountRole).toString());
                    break;
                }
                d->ui->accountCombo->blockSignals(blocked);

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->amountEditCredit->setText(splitIdx.data(eMyMoney::Model::JournalSplitPaymentRole).toString());
                d->ui->amountEditDebit->setText(splitIdx.data(eMyMoney::Model::JournalSplitDepositRole).toString());

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());

                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());

                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    const auto value = splitIdx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
                    if (!shares.isZero()) {
                        d->price = value / shares;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits2)
    d->addCacheNotification(split.accountId(), transaction.postDate());
```

#### AUTO 


```{c}
auto type = typeCombo->itemData(index).value<eMyMoney::Account>();
```

#### AUTO 


```{c}
const auto state = stringToStateAttribute(c.attribute(attributeName(Attribute::Report::State)));
```

#### AUTO 


```{c}
auto idInstitution = account.institutionId();
```

#### AUTO 


```{c}
const auto currency = MyMoneyFile::instance()->currency(acc.currencyId());
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& view : qAsConst(d->viewBases)) {
        view->executeCustomAction(eView::Action::CleanupBeforeFileClose);
    }
```

#### AUTO 


```{c}
const auto selection = d->m_view->selectedJournalEntries();
```

#### AUTO 


```{c}
auto font = KMyMoneyGlobalSettings::listHeaderFont();
```

#### AUTO 


```{c}
auto type = m_payee.matchData(ignorecase, keys);
```

#### AUTO 


```{c}
auto list = match(index(0, 0), (int)Role::TransactionId, id, -1);
```

#### AUTO 


```{c}
auto sch = MyMoneySchedule();
```

#### AUTO 


```{c}
const auto& occurrence
```

#### AUTO 


```{c}
auto okButton = ui->buttonBox->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
const auto &pidid
```

#### AUTO 


```{c}
auto action = pActions[eMenu::Action::AccountCreditTransfer];
```

#### AUTO 


```{c}
auto t = m_schedule.transaction();
```

#### AUTO 


```{c}
auto shareEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("shares"));
```

#### AUTO 


```{c}
auto itInvAcc = new QStandardItem(invAcc.name());
```

#### AUTO 


```{c}
const auto s2 = (transaction.splits().size() < 2) ? MyMoneySplit() : transaction.splits()[1];
```

#### AUTO 


```{c}
const auto account = itAccount->data(AccountRole).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto treeItem = ui->m_securitiesTree->currentIndex();
```

#### AUTO 


```{c}
const auto indexList = d->m_securitiesProxyModel->match(d->m_securitiesProxyModel->index(0, 0), Qt::DisplayRole, QLatin1String("Securities"), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchWrap));
```

#### AUTO 


```{c}
const auto t = file->transaction(tid);
```

#### AUTO 


```{c}
const auto tList = d->m_storage->transactionList(filter);
```

#### LAMBDA EXPRESSION 


```{c}
[=](int row)
    {
        const auto idx = d->m_tagCombo->model()->index(row, 0);
        const auto id = idx.data(eMyMoney::Model::IdRole).toString();
        d->addTagWidget(id);
        emit tagsChanged(d->tagIdList());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
        auto acc = account(split.accountId());
        if (acc.isClosed())
            throw MYMONEYEXCEPTION(QString::fromLatin1("Cannot remove transaction that references a closed account."));
        d->addCacheNotification(split.accountId(), tr.postDate());
        //FIXME-ALEX Do I need to add d->addCacheNotification(split.tagList()); ??
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : transactions) {
    // This code is used now. It adds the transaction to the list for
    // each matching split exactly once. This allows to show information
    // about different splits in the same register view (e.g. search result)
    //
    // I have no idea, if this has some impact on the functionality. So far,
    // I could not see it.  (ipwizard 9/5/2003)
    const auto cnt = filter.matchingSplitsCount(transaction);
    for (uint i = 0; i < cnt; ++i)
      list.append(transaction);
  }
```

#### AUTO 


```{c}
const auto split
```

#### AUTO 


```{c}
auto toBeDeleted = file->journalModel()->itemById(toBeDeletedId);
```

#### AUTO 


```{c}
auto colWidth = 55 / (m_forecast.forecastDays() / m_forecast.accountsCycle());
```

#### AUTO 


```{c}
const auto security = file->security(securityId);
```

#### AUTO 


```{c}
auto yearString = QInputDialog::getItem(this, i18n("Select year"), i18n("Budget year"), years, current, false, &ok);
```

#### AUTO 


```{c}
const auto model = ui->m_scheduleTree->model();
```

#### AUTO 


```{c}
const auto rows = first.data(eMyMoney::Model::TransactionSplitCountRole).toInt();
```

#### AUTO 


```{c}
auto isViewInserted = false;
```

#### AUTO 


```{c}
const auto index = splitModel.index(row, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits) {

      if (filter.accountFilter ||
          filter.categoryFilter) {
        auto removeSplit = true;
        if (d->m_considerCategory) {
          switch (file->account(s.accountId()).accountGroup()) {
            case eMyMoney::Account::Type::Income:
            case eMyMoney::Account::Type::Expense:
              isTransfer = false;
              // check if the split references one of the categories in the list
              if (filter.categoryFilter) {
                if (d->m_categories.isEmpty()) {
                  // we're looking for transactions with 'no' categories
                  d->m_matchingSplitsCount = 0;
                  matchingSplits.clear();
                  return matchingSplits;
                } else if (d->m_categories.contains(s.accountId())) {
                  categoryMatched = true;
                  removeSplit = false;
                }
              }
              break;

            default:
              // check if the split references one of the accounts in the list
              if (!filter.accountFilter) {
                removeSplit = false;
              } else if (!d->m_accounts.isEmpty() &&
                         d->m_accounts.contains(s.accountId())) {
                accountMatched = true;
                removeSplit = false;
              }

              break;
          }

        } else {
          if (!filter.accountFilter) {
            removeSplit = false;
          } else if (!d->m_accounts.isEmpty() &&
                     d->m_accounts.contains(s.accountId())) {
            accountMatched = true;
            removeSplit = false;
          }
        }

        if (removeSplit)
          continue;
      }

      // check if less frequent filters are active
      if (extendedFilter.allFilter) {
        const auto acc = file->account(s.accountId());
        if (!(matchAmount(s) && matchText(s, acc)))
          continue;

        // Determine if this account is a category or an account
        auto isCategory = false;
        switch (acc.accountGroup()) {
          case eMyMoney::Account::Type::Income:
          case eMyMoney::Account::Type::Expense:
            isCategory = true;
          default:
            break;
        }

        bool includeSplit = d->m_considerCategorySplits || (!d->m_considerCategorySplits && !isCategory);
        if (includeSplit) {
          // check the payee list
          if (filter.payeeFilter) {
            if (!d->m_payees.isEmpty()) {
              if (s.payeeId().isEmpty() || !d->m_payees.contains(s.payeeId()))
                continue;
            } else if (!s.payeeId().isEmpty())
              continue;
          }

          // check the tag list
          if (filter.tagFilter) {
            const auto tags = s.tagIdList();
            if (!d->m_tags.isEmpty()) {
              if (tags.isEmpty()) {
                continue;
              } else {
                auto found = false;
                for (const auto& tag : tags) {
                  if (d->m_tags.contains(tag)) {
                    found = true;
                    break;
                  }
                }

                if (!found)
                  continue;
              }
            } else if (!tags.isEmpty())
              continue;
          }

          // check the type list
          if (filter.typeFilter &&
              !d->m_types.isEmpty() &&
              !d->m_types.contains(splitType(transaction, s, acc)))
            continue;

          // check the state list
          if (filter.stateFilter &&
              !d->m_states.isEmpty() &&
              !d->m_states.contains(splitState(s)))
            continue;

          if (filter.nrFilter &&
              ((!d->m_fromNr.isEmpty() && s.number() < d->m_fromNr) ||
               (!d->m_toNr.isEmpty() && s.number() > d->m_toNr)))
            continue;

        } else if (filter.payeeFilter
                   || filter.tagFilter
                   || filter.typeFilter
                   || filter.stateFilter
                   || filter.nrFilter) {
          continue;
        }
      }
      if (d->m_reportAllSplits)
        matchingSplits.append(s);

      isMatchingSplitsEmpty = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalId : selection.selection(SelectedObjects::JournalEntry)) {
                    const auto journalIdx = file->journalModel()->indexById(journalId);
                    moveToAccountSelector->removeItem(journalIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString());
                    const auto accountId = journalIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString();
                    const auto accIdx = file->accountsModel()->indexById(accountId);
                    currencyIds.insert(accIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString());
                }
```

#### AUTO 


```{c}
auto visEColumns = m_equitiesProxyModel->getVisibleColumns();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selected.indexes()) {
        if (idx.data(eMyMoney::Model::TransactionScheduleRole).toBool() != isSchedule) {
          toDeselect.select(idx, idx);
        }
      }
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPlugins("kmymoney");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids) {
            const auto idx = indexById(id);
            if (idx.isValid()) {
                indeces += idx;
            }
        }
```

#### AUTO 


```{c}
auto acc = model->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
auto paths = QIcon::themeSearchPaths();
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
    viewFrames[view.id] = m_model->addPage(viewBases[view.id], view.name);
    viewFrames[view.id]->setIcon(Icons::get(view.icon));
    connect(viewBases[view.id], &KMyMoneyViewBase::aboutToShow, this, &KMyMoneyView::connectView);
    connect(viewBases[view.id], &KMyMoneyViewBase::aboutToShow, this, &KMyMoneyView::resetViewSelection);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : d->m_payeesToSync) {
                    MyMoneyFile::instance()->modifyPayee(payee);
                }
```

#### AUTO 


```{c}
const auto commodity = MyMoneyFile::instance()->currency(d->m_transaction.commodity());
```

#### AUTO 


```{c}
const auto reverse = (actionId == eMenu::Action::AddReversingTransaction);
```

#### AUTO 


```{c}
auto dateWidget = dynamic_cast<KMyMoneyDateInput*>(d->m_editWidgets["postdate"])
```

#### AUTO 


```{c}
auto w = d->haveWidget<QLabel*>(idx);
```

#### AUTO 


```{c}
const auto model
```

#### AUTO 


```{c}
const auto statementEndDate = s.statementEndDate();
```

#### AUTO 


```{c}
const auto sec = item->data(0, Qt::UserRole).value<MyMoneySecurity>();
```

#### AUTO 


```{c}
auto enableButton = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sAccount : account(id).accountList())
    result += totalBalance(sAccount, date);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
          kgpg->addRecipient(key.toLatin1());
        }
```

#### AUTO 


```{c}
const auto value = splitIdx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
auto modifiedInput(input);
```

#### AUTO 


```{c}
const auto account = file->account(split.accountId());
```

#### AUTO 


```{c}
auto view = qobject_cast<LedgerViewPage*>(tab);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& id : qAsConst(ids)) {
        if (!m_selections[type].contains(id)) {
            m_selections[type].append(id);
        }
    }
```

#### AUTO 


```{c}
const auto columnNames = grp.readEntry("HeaderState", QByteArray());
```

#### AUTO 


```{c}
auto d2 = static_cast<const AccountGroupPrivate *>(right.d_func());
```

#### AUTO 


```{c}
const auto userAgent = m_userAgent->text();
```

#### AUTO 


```{c}
auto ok = false;
```

#### AUTO 


```{c}
auto firstAccName = filteredAccounts.at(0).name();
```

#### AUTO 


```{c}
const auto value = amount.formatMoney(currencySymbol, prec);
```

#### AUTO 


```{c}
auto value = new kMyMoneyEdit;
```

#### AUTO 


```{c}
auto i = (int)MyMoneySplit::Element::Split;
```

#### AUTO 


```{c}
const auto favIcon = Icons::loadIconFromApplicationCache(iconName);
```

#### AUTO 


```{c}
auto SecuritiesModel::getColumns()
{
  return &d->m_columns;
}
```

#### AUTO 


```{c}
auto method = d->m_schedule.paymentType();
```

#### AUTO 


```{c}
auto widget = dynamic_cast<KMyMoneyCategory*>(o);
```

#### AUTO 


```{c}
auto key = event->key();
```

#### AUTO 


```{c}
const auto journalModel = file->journalModel();
```

#### AUTO 


```{c}
const auto transactionId = journalIdx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
```

#### AUTO 


```{c}
const auto securitiesModel = Models::instance()->securitiesModel();
```

#### AUTO 


```{c}
const auto account = ixAccount.data((int)Role::Account).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(haveWidget("shares"))
```

#### AUTO 


```{c}
auto model = const_cast<QAbstractItemModel*>(index.model());
```

#### AUTO 


```{c}
const auto labels = findChildren<QLabel*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
          // create a copy of the splits list in the transaction
          // loop over all splits
          for (auto& split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); i++) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          } // for - Splits
          file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &extension : desiredFileExtensions) {
        for (const auto &plugin : pPlugins.storage) {
            if (plugin->storageType() == extension) {
                fileExtensions += plugin->fileExtension() + QLatin1String(";;");
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto i = (int)MyMoneyTransaction::Element::Split;
```

#### AUTO 


```{c}
auto txt = sortOrderToText(static_cast<SortField>(abs(idx)));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
              // for some reason, using the website button as cornerWidget
              // returns the text with an ampersand character maybe inserted
              // as indication for a hotkey. This needs to be removed for
              // the construction of the URL
              const QString website = webSiteButton->text().replace('&', "");
              QUrl url;
              url.setUrl(QString::fromLatin1("https://%1/").arg(website));
              QDesktopServices::openUrl(url);
            }
```

#### AUTO 


```{c}
const auto account = file->account(parentid);
```

#### AUTO 


```{c}
auto interestAmountWidget = dynamic_cast<KMyMoneyEdit*>(haveWidget("interest-amount"));
```

#### AUTO 


```{c}
auto tag_id = dlg->show(d->m_selections.selection(SelectedObjects::Tag));
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("icalendarexporter");
```

#### AUTO 


```{c}
auto newDir = QFileDialog::getExistingDirectoryUrl(this, QString(), documentsLocation);
```

#### AUTO 


```{c}
const auto accountId = d->ui->accountCombo->getSelected();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QStringList& tagIds) {
        d->tagsChanged(tagIds);
    }
```

#### AUTO 


```{c}
auto it_a = accList.cbegin();
```

#### AUTO 


```{c}
const auto url = institution.value(QStringLiteral("url"));
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyCostCenterPrivate *>(right.d_func());
```

#### AUTO 


```{c}
const auto iconName = sStandardIcons[description.baseIcon];
```

#### AUTO 


```{c}
const auto viewId = d->viewIdByWidget(baseView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData & pluginData : plugins) {
    // Only load plugins which are enabled and have the right serviceType. Other serviceTypes are loaded on demand.
    if (isPluginEnabled(pluginData, group))
      slotPluginLoad(pluginData);
  }
```

#### AUTO 


```{c}
auto isMatchingSplitsEmpty = true;
```

#### AUTO 


```{c}
auto it = transactionList.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : transaction.splits()) {
                if(splitId != sp.id()) {
                    return sp.accountId();
                }
            }
```

#### AUTO 


```{c}
auto writeQuery = [&]() {
            query.bindValue(":id", obj.idString());
            query.bindValue(":countryCode", payeeIdentifier->country());
            query.bindValue(":accountNumber", payeeIdentifier->accountNumber());
            query.bindValue(":bankCode", (payeeIdentifier->bankCode().isEmpty()) ? QVariant(QVariant::String) : payeeIdentifier->bankCode());
            query.bindValue(":name", payeeIdentifier->ownerName());
            if (!query.exec()) { // krazy:exclude=crashy
                qWarning("Error while saving national account number for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
                return false;
            }
            return true;

        };
```

#### AUTO 


```{c}
auto& schedule
```

#### AUTO 


```{c}
auto sec = MyMoneyFile::instance()->security(d->m_account.currencyId());
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(haveWidget("shares"))
```

#### AUTO 


```{c}
const auto completionStr = QStringLiteral(".*");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
      if (plugin->formatName().compare(QLatin1String("SQL")) == 0) {
        rc = plugin->open(pStorage, url);
        pluginFound = true;
        break;
      }
    }
```

#### AUTO 


```{c}
const auto id = inv.id();
```

#### AUTO 


```{c}
auto chartWidget = new reports::KReportChartView(nullptr);
```

#### AUTO 


```{c}
auto baseModel = MyMoneyFile::instance()->payeesModel();
```

#### AUTO 


```{c}
const auto &index
```

#### AUTO 


```{c}
const auto accountIdx = indexById(account.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
    auto accIdx = file->accountsModel()->indexById(splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString());
    const auto accountGroup = accIdx.data(eMyMoney::Model::AccountGroupRole).value<eMyMoney::Account::Type>();
    if (splitIdx.row() == idx.row()) {
      security = file->security(accIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString());
    } else if (accountGroup == eMyMoney::Account::Type::Expense) {
      feeSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
    } else if (accountGroup == eMyMoney::Account::Type::Income) {
      interestSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
    } else {
      if (!assetAccountSplitIdx.isValid()) { // first asset Account should be our requested brokerage account
        assetAccountSplitIdx = splitIdx;
      } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isNegative()) { // the rest (if present) is handled as fee or interest
        feeSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
      } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isPositive()) {
        interestSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
      }
    }
  }
```

#### AUTO 


```{c}
const auto institution = institutionsModel->itemByIndex(index);
```

#### AUTO 


```{c}
const auto columns = d->ui.m_tocTreeWidget->columnCount();
```

#### AUTO 


```{c}
auto a = new QAction(Icons::get(info.icon), info.text, nullptr);
```

#### AUTO 


```{c}
auto& sm
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : actions)
    pActions[action]->setEnabled(m_storageInfo.isOpened);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
      if (idx.row() != lastRow) {
        lastRow = idx.row();
        allSelectedRows += lastRow;
      }
    }
```

#### AUTO 


```{c}
const auto value  = s.value().abs();
```

#### AUTO 


```{c}
const auto data = model()->data(index, (int)eAccountsModel::Role::Account);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : transactionList) {
        // if this split is a stock split, we can't just add the amount of shares
        const auto journalEntry = file->journalModel()->itemById(journalEntryId);
        if (!journalEntry.id().isEmpty()) {
            const auto& split = journalEntry.split();
            if (split.reconcileFlag() == eMyMoney::Split::State::NotReconciled) {
                if (split.shares().isNegative()) {
                    outstandingPayments++;
                    outstandingPaymentAmount += split.shares();
                } else {
                    outstandingDeposits++;
                    outstandingDepositAmount += split.shares();
                }
            } else {
                if (split.shares().isNegative()) {
                    clearedPayments++;
                    clearedPaymentAmount += split.shares();
                } else {
                    clearedDeposits++;
                    clearedDepositAmount += split.shares();
                }
                clearedBalance += split.shares();
            }
        }
    }
```

#### AUTO 


```{c}
auto retVal = execute("get_transactions", QVariantList{backend, accid, max});
```

#### AUTO 


```{c}
auto& transaction
```

#### AUTO 


```{c}
const auto splits2 = transaction.splits();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (d->currentActivity) {
            d->stockSplit.setShares(d->ui->sharesAmountEdit->value() * d->currentActivity->sharesFactor());
            d->stockSplit.setValue(d->currentActivity->valueAllShares().convert(d->currency.smallestAccountFraction(), d->security.roundingMethod())
                                   * d->currentActivity->sharesFactor());
            if (d->currentActivity->type() != eMyMoney::Split::InvestmentTransactionType::SplitShares) {
                updateTotalAmount();
            }
            d->updateWidgetState();
        }
    }
```

#### AUTO 


```{c}
auto option = textToSortOrder(item->text());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& plugin : plugins.standard) {
          plugin->updateActions(selections);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : deselected.indexes()) {
        d->m_selections.removeSelection(SelectedObjects::Tag, idx.data(eMyMoney::Model::IdRole).toString());
    }
```

#### AUTO 


```{c}
auto value = new KMyMoneyEdit;
```

#### AUTO 


```{c}
auto xml = value(getAttrName(Attribute::KMMatchedTx));
```

#### AUTO 


```{c}
auto t = journalEntry.transaction();
```

#### AUTO 


```{c}
auto type = d->ui->typeCombo->itemData(index).value<Account::Type>();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyXmlContentHandler2::attributeName(static_cast<Attribute::Report>(i)).isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        const auto account = MyMoneyFile::instance()->account(accountId);
        if (account.currencyId() != d->assetAccount.currencyId()) {
            /// @todo update price rate information
        }
        d->postdateChanged(d->ui->dateEdit->date());
        d->updateWidgetState();
    }
```

#### AUTO 


```{c}
auto newname = i18nc("@item:intable Your budgets, %1 budget year", "Budget %1", QString::number(date.year()));
```

#### AUTO 


```{c}
const auto tagName = m_tagCombo->itemText(m_tagCombo->findData(QVariant(id), Qt::UserRole, Qt::MatchExactly));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : d->m_transactionList) {
    // This code is used now. It adds the transaction to the list for
    // each matching split exactly once. This allows to show information
    // about different splits in the same register view (e.g. search result)
    //
    // I have no idea, if this has some impact on the functionality. So far,
    // I could not see it.  (ipwizard 9/5/2003)
    const auto cnt = filter.matchingSplitsCount(transaction);
    for (uint i = 0; i < cnt; ++i)
      list.append(transaction);
  }
```

#### AUTO 


```{c}
const auto count = m_models->budgetsModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto drivers = QSqlDatabase::drivers();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const MyMoneyReport &rep1, const MyMoneyReport &rep2) {
                return rep1.name().localeAwareCompare(rep2.name()) < 0;
            }
```

#### AUTO 


```{c}
auto i = (int)Attribute::Schedule::Name;
```

#### AUTO 


```{c}
auto tChanged = false;
```

#### AUTO 


```{c}
const auto nodeName = attribute.nodeName();
```

#### AUTO 


```{c}
auto const mdlAccounts = Models::instance()->accountsModel();
```

#### AUTO 


```{c}
auto dlg = KConfigDialog::exists("KMyMoney-Settings");
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Split>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto oldShares = d->ui->totalAmountEdit->shares();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : tList) {
        MyMoneyTransaction t = transaction;
        bool tChanged = false;
        QDate accountOpeningDate;
        QStringList accountList;
        if (!(t.value(QStringLiteral("kmm-matched-tx")).isEmpty() && t.value(QStringLiteral("kmm-match-split")).isEmpty())) {
            t.deletePair(QStringLiteral("kmm-matched-tx"));
            t.deletePair(QStringLiteral("kmm-match-split"));
            rc << i18n("  * Removed unused match information from transaction '%1'.", t.id());
            ++problemCount;
            tChanged = true;
        }

        const auto splits = t.splits();
        if (!t.splitSum().isZero()) {
            rc << i18n("  * Sum of splits in transaction '%1' posted on %2 is not zero.", t.id(), t.postDate().toString(Qt::ISODate));
            for (const auto& split : splits) {
                const auto accIdx = d->accountsModel.indexById(split.accountId());
                const auto name = accIdx.data(eMyMoney::Model::AccountFullHierarchyNameRole).toString();
                const auto acc = d->accountsModel.itemByIndex(accIdx);
                const auto security = MyMoneyFile::instance()->security(acc.currencyId());
                rc << i18n("    Account: %1, Amount: %2", name, MyMoneyUtils::formatMoney(split.shares(), security));
            }
            ++unfixedCount;
        }

        foreach (const auto split, splits) {
            bool sChanged = false;
            MyMoneySplit s = split;
            if (payeeConversionMap.find(split.payeeId()) != payeeConversionMap.end()) {
                s.setPayeeId(payeeConversionMap[s.payeeId()]);
                sChanged = true;
                rc << i18n("  * Payee id updated in split of transaction '%1'.", t.id());
                ++problemCount;
            }

            try {
                const auto acc = d->accountsModel.itemById(s.accountId());
                // compute the newest opening date of all accounts involved in the transaction
                // in case the newest opening date is newer than the transaction post date, do one
                // of the following:
                //
                // a) for category and stock accounts: update the opening date of the account
                // b) for account types where the user cannot modify the opening date through
                //    the UI issue a warning (for each account only once)
                // c) others will be caught later
                if (!acc.isIncomeExpense() && !acc.isInvest()) {
                    if (acc.openingDate() > t.postDate()) {
                        if (!accountOpeningDate.isValid() || acc.openingDate() > accountOpeningDate) {
                            accountOpeningDate = acc.openingDate();
                        }
                        accountList << this->accountToCategory(acc.id());
                        if (!supportedAccountTypes.contains(acc.accountType())
                                && !reportedUnsupportedAccounts.contains(acc.id())) {
                            rc << i18n("  * Opening date of Account '%1' cannot be changed to support transaction '%2' post date.",
                                       this->accountToCategory(acc.id()), t.id());
                            reportedUnsupportedAccounts << acc.id();
                            ++unfixedCount;
                        }
                    }
                } else {
                    if (acc.openingDate() > t.postDate()) {
                        rc << i18n("  * Transaction '%1' post date '%2' is older than opening date '%4' of account '%3'.",
                                   t.id(), t.postDate().toString(Qt::ISODate), this->accountToCategory(acc.id()), acc.openingDate().toString(Qt::ISODate));

                        rc << i18n("    Account opening date updated.");
                        MyMoneyAccount newAcc = acc;
                        newAcc.setOpeningDate(t.postDate());
                        this->modifyAccount(newAcc);
                        ++problemCount;
                    }
                }

                // make sure, that shares and value have the same number if they
                // represent the same currency.
                if (t.commodity() == acc.currencyId() && s.shares().reduce() != s.value().reduce()) {
                    // use the value as master if the transaction is balanced
                    if (t.splitSum().isZero()) {
                        s.setShares(s.value());
                        rc << i18n("  * shares set to value in split of transaction '%1'.", t.id());
                    } else {
                        s.setValue(s.shares());
                        rc << i18n("  * value set to shares in split of transaction '%1'.", t.id());
                    }
                    sChanged = true;
                    ++problemCount;
                }
            } catch (const MyMoneyException &) {
                rc << i18n("  * Split %2 in transaction '%1' contains a reference to invalid account %3. Please fix manually.", t.id(), split.id(), split.accountId());
                ++unfixedCount;
            }

            // make sure the interest splits are marked correct as such
            if (interestAccounts.find(s.accountId()) != interestAccounts.end()
                    && s.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
                s.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
                sChanged = true;
                rc << i18n("  * action marked as interest in split of transaction '%1'.", t.id());
                ++problemCount;
            }

            if (sChanged) {
                tChanged = true;
                t.modifySplit(s);
            }
        }

        // make sure that the transaction's post date is valid
        if (!t.postDate().isValid()) {
            tChanged = true;
            t.setPostDate(t.entryDate().isValid() ? t.entryDate() : QDate::currentDate());
            rc << i18n("  * Transaction '%1' has an invalid post date.", t.id());
            rc << i18n("    The post date was updated to '%1'.", QLocale().toString(t.postDate(), QLocale::ShortFormat));
            ++problemCount;
        }
        // check if the transaction's post date is after the opening date
        // of all accounts involved in the transaction. In case it is not,
        // issue a warning with the details about the transaction incl.
        // the account names and dates involved
        if (accountOpeningDate.isValid() && t.postDate() < accountOpeningDate) {
            QDate originalPostDate = t.postDate();
#if 0
            // for now we do not activate the logic to move the post date to a later
            // point in time. This could cause some severe trouble if you have lots
            // of ancient data collected with older versions of KMyMoney that did not
            // enforce certain conditions like we do now.
            t.setPostDate(accountOpeningDate);
            tChanged = true;
            // copy the price information for investments to the new date
            QList<MyMoneySplit>::const_iterator it_t;
            foreach (const auto split, t.splits()) {
                if ((split.action() != "Buy") &&
                        (split.action() != "Reinvest")) {
                    continue;
                }
                QString id = split.accountId();
                auto acc = this->account(id);
                MyMoneySecurity sec = this->security(acc.currencyId());
                MyMoneyPrice price(acc.currencyId(),
                                   sec.tradingCurrency(),
                                   t.postDate(),
                                   split.price(), "Transaction");
                this->addPrice(price);
                break;
            }
#endif
            rc << i18n("  * Transaction '%1' has a post date '%2' before one of the referenced account's opening date.", t.id(), QLocale().toString(originalPostDate, QLocale::ShortFormat));
            rc << i18n("    Referenced accounts: %1", accountList.join(","));
            rc << i18n("    The post date was not updated to '%1'.", QLocale().toString(accountOpeningDate, QLocale::ShortFormat));
            ++unfixedCount;
        }

        if (tChanged) {
            d->journalModel.modifyTransaction(t);
        }
    }
```

#### AUTO 


```{c}
auto memo = index.data((int)Role::SingleLineMemo).toString();
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneySplitPrivate *>(right.d_func());
```

#### AUTO 


```{c}
auto cellFont = KMyMoneySettings::listCellFontEx();
```

#### AUTO 


```{c}
const auto categoryId = idx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[=](int row) {
        const auto idx = d->m_tagCombo->model()->index(row, 0);
        const auto id = idx.data(eMyMoney::Model::IdRole).toString();
        d->addTagWidget(id);
        emit tagsChanged(d->tagIdList());
    }
```

#### AUTO 


```{c}
auto isTransfer = true;
```

#### AUTO 


```{c}
const auto warnLevel = MyMoneyUtils::transactionWarnLevel(journalEntryId);
```

#### AUTO 


```{c}
auto model = ui->view->model();
```

#### AUTO 


```{c}
const auto journalEntryId = index.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto skipCnt = 1;
```

#### AUTO 


```{c}
auto i = (int)Split::Attribute::ID;
```

#### AUTO 


```{c}
auto grp = KSharedConfig::openConfig()->group(getConfGrpName(m_view));
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyPayeePrivate::getElName(static_cast<Payee::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
auto b = acc.accountType() == eMyMoney::Account::Type::Investment ? true : false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : qAsConst(list)) {
        itemCount += item.splitCount();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& data) {
    return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
  }
```

#### AUTO 


```{c}
const auto defaultTabOrder = QStringList{
        QLatin1String("creditDebitEdit"),
        QLatin1String("payeeEdit"),
        QLatin1String("numberEdit"),
        QLatin1String("accountCombo"),
        QLatin1String("costCenterCombo"),
        QLatin1String("memoEdit"),
        QLatin1String("enterButton"),
        QLatin1String("cancelButton"),
    };
```

#### AUTO 


```{c}
const auto maxLegendItems = KMyMoneySettings::maximumLegendItems();
```

#### AUTO 


```{c}
auto colspan = 1;
```

#### LAMBDA EXPRESSION 


```{c}
[&](MyMoneySplit& split, int sharesFraction) {
        split.setShares(MyMoneyMoney(split.shares().convertDenominator(sharesFraction, roundingMethod)));
        split.setValue(MyMoneyMoney(split.value().convertDenominator(currencyFraction, roundingMethod)));
    }
```

#### AUTO 


```{c}
auto method = m_schedule.paymentType();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
    auto a = account(accountId);
    a.setInstitutionId(QString());
    modifyAccount(a);
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, File::Object::Account, a.id());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto delegate : d->mapping) {
    rc |= const_cast<KMMStyledItemDelegate*>(delegate)->eventFilter(watched, event);
    if (rc)
      break;
  }
```

#### AUTO 


```{c}
auto filter = new IdFilter(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& text) {
    Q_D(LedgerFilter);
    d->filterString = text;
    d->delayTimer.start(200);
  }
```

#### AUTO 


```{c}
auto acc = *accList_t;
```

#### AUTO 


```{c}
const auto idx = d->ui->m_register->currentIndex();
```

#### AUTO 


```{c}
const auto index = d->m_splitModel->index(0, 0);
```

#### AUTO 


```{c}
auto i = (int)MyMoneyReport::Attribute::ID;
```

#### AUTO 


```{c}
const auto editor = d->ui->m_ledgerView->indexWidget(d->ui->m_ledgerView->editIndex());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
    switch (plugin->storageType()) {
      case eKMyMoney::StorageType::GNC:
        break;
      default:
        availableFileTypes.append(plugin->storageType());
        break;
    }
  }
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyBudgetPrivate *>(right.d_func());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        Q_D(KEditScheduleDlg);
        if (d->m_schedule.nextDueDate() != date) {
            if (d->ui->endOptionsFrame->isEnabled()) {
                d->m_schedule.setNextDueDate(date);
                d->m_schedule.setStartDate(date);
                d->m_schedule.setOccurrenceMultiplier(d->ui->frequencyNoEdit->value());

                d->setScheduleOccurrencePeriod();

                d->m_schedule.setEndDate(d->ui->finalPaymentDateEdit->date());
                d->updateTransactionsRemaining();
            }
        }
    }
```

#### AUTO 


```{c}
auto it_pr = priceList.begin();
```

#### AUTO 


```{c}
auto keyText = event->text();
```

#### AUTO 


```{c}
auto feeAmountWidget = dynamic_cast<KMyMoneyEdit*>(haveWidget("fee-amount"));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        // update the actions in the views
        d->updateActions(d->m_selections);
        emit selectionChanged(d->m_selections);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& widgetName : widgetNames) {
            auto w = ui.m_targetWidget->findChild<QWidget*>(widgetName);
            if (w->property("kmm_taborder").toBool() && w->isVisible()) {
                m_widgetList.append(w);
            } else {
                qDebug() << "Skip invisible" << widgetName;
            }
        }
```

#### AUTO 


```{c}
const auto data = sourceModel()->index(source_row, (int)(Column::Account), source_parent).data((int)Role::ID);
```

#### AUTO 


```{c}
auto isEmpty = onlineJobPrivate::getAttrName(static_cast<OnlineJob::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto iid = QLatin1String("org.kmymoney.payeeIdentifier.nationalAccount.sqlStoragePlugin");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : qAsConst(schedule.transaction().splits())) {
                for (auto i = 0; i < split.tagIdList().size(); ++i) {
                    // is the tag in the split to be deleted?
                    if (d->tagInList(selectedTags, split.tagIdList()[i])) {
                        used_schedules.push_back(schedule); // remember this schedule
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto sharedActions = view->sharedToolbarActions();
```

#### AUTO 


```{c}
auto memo = index.data((int)eLedgerModel::Role::SingleLineMemo).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
        const auto journalEntry = file->journalModel()->itemById(journalEntryId);
        if (!journalEntry.id().isEmpty()) {
            if (!journalEntry.transaction().id().isEmpty()) {
                if (!file->referencesClosedAccount(journalEntry.transaction())) {
                    file->removeTransaction(journalEntry.transaction());
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Tag));
```

#### AUTO 


```{c}
auto printer = instance();
```

#### AUTO 


```{c}
auto itemToClone = fromNode->child(row);
```

#### AUTO 


```{c}
const auto rightPos = filterFixedStrings().indexOf(right.data(eMyMoney::Model::IdRole).toString());
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("csvexporter.rc");
```

#### AUTO 


```{c}
auto it_c = 1;
```

#### AUTO 


```{c}
auto model = qobject_cast<const AccountsModel*>(baseIdx.model());
```

#### AUTO 


```{c}
auto label = dynamic_cast<QLabel*>(haveWidget("price-label"));
```

#### AUTO 


```{c}
const auto pixmap = icon.pixmap(iconHeight, iconHeight, QIcon::Active, QIcon::On);
```

#### AUTO 


```{c}
const auto idx = indexById(account.id());
```

#### AUTO 


```{c}
const auto topLeft = BudgetsModel::index(index.row(), 0);
```

#### AUTO 


```{c}
const auto accounts = acc.accountList();
```

#### AUTO 


```{c}
auto remain = m_schedule.transactionsRemaining();
```

#### AUTO 


```{c}
const auto iconName = institution.value(QStringLiteral("icon"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const MyMoneyAccount &account : allAccounts) {
                if (account.isLoan()) {
                    MyMoneyAccountLoan loanAccount(account);
                    for (const MyMoneyPayee &payee : list) {
                        if (loanAccount.hasReferenceTo(payee.id())) {
                            usedAccounts.append(account);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto found = html.captured(1);
```

#### AUTO 


```{c}
auto numberEdit = dynamic_cast<KMyMoneyLineEdit*>(q->haveWidget("number"));
```

#### AUTO 


```{c}
const auto idx = d->payeesModel.indexById(id);
```

#### AUTO 


```{c}
auto parentAccount = file->account(acc.parentAccountId());
```

#### AUTO 


```{c}
const auto enable = !m_account.id().isEmpty();
```

#### AUTO 


```{c}
auto p = m_transactionEditor;
```

#### AUTO 


```{c}
auto f = beginDay;
```

#### AUTO 


```{c}
const auto institution = MyMoneyFile::instance()->institutionsModel()->itemById(objId);
```

#### AUTO 


```{c}
auto mdlItem = d->m_equitiesProxyModel->index(treeItem.row(), EquitiesModel::Equity, treeItem.parent());
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& pluginGroup : pluginGroups) {
    if (!pluginGroup.plugins.isEmpty()) {
      d->m_pluginSelector->addPlugins(pluginGroup.plugins,
                                      pluginGroup.loadMethod,
                                      pluginGroup.categoryName); // at that step plugin on/off state should be fetched automatically by KPluginSelector
      d->pluginInfos.append(pluginGroup.plugins);                // store initial on/off state to be able to enable/disable Apply button
    }
  }
```

#### AUTO 


```{c}
const auto ixXML = ui->fileType->findData(static_cast<int>(eKMyMoney::StorageType::XML));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const MyMoneySecurity& c1, const MyMoneySecurity& c2)
    {
        return c1.name().compare(c2.name()) < 0;
    }
```

#### AUTO 


```{c}
const auto& tidx
```

#### AUTO 


```{c}
const auto list = q->selectionModel()->selectedRows();
```

#### AUTO 


```{c}
const auto actionSeq = action->shortcut();
```

#### AUTO 


```{c}
auto b = file->isStandardAccount(acc.id()) ? false : true;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : selectedTags) {
      file->removeTag(tag);
    }
```

#### AUTO 


```{c}
auto splits = d->m_schedule.transaction().splits();
```

#### AUTO 


```{c}
auto w = qApp->focusWidget();
```

#### AUTO 


```{c}
auto user1Button = new QPushButton;
```

#### AUTO 


```{c}
const auto msg = QStringLiteral("Can reparent stock to non-investment type %1 to account").arg(static_cast<int>(*it));
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
        if (!KGPGFile::keyAvailable(key)) {
          KMessageBox::sorry(this, i18n("<p>You have specified to encrypt your data for the user-id</p><p><center><b>%1</b>.</center></p><p>Unfortunately, a valid key for this user-id was not found in your keyring. Please make sure to import a valid key for this user-id. This time, encryption is disabled.</p>", key), i18n("GPG Key not found"));
          encryptFile = false;
          break;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : tagIdList)
            if (file->tag(tag).name().contains(d->m_text))
                return !d->m_invertText;
```

#### AUTO 


```{c}
const auto statusIdx = MyMoneyFile::instance()->statusModel()->index(status, 0);
```

#### AUTO 


```{c}
auto mask = 0x01;
```

#### LAMBDA EXPRESSION 


```{c}
[=](int row)
          {
            const auto idx = d->m_tagCombo->model()->index(row, 0);
            const auto id = idx.data(eMyMoney::Model::IdRole).toString();
            d->addTagWidget(id);
            emit tagsChanged(d->tagIdList());
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
            // if the split is assigned to one of the selected payees, we need to modify it
            if (payeeInList(d->m_selectedPayees, split.payeeId())) {
              split.setPayeeId(payee_id); // first modify payee in current split
              // then modify the split in our local copy of the transaction list
              transaction.modifySplit(split); // this does not modify the list object 'splits'!
            }
          }
```

#### AUTO 


```{c}
const auto leftModel = model->baseModel(left);
```

#### AUTO 


```{c}
auto i = (int)Split::Element::Split;
```

#### AUTO 


```{c}
auto s = MyMoneyFile::instance()->storage();
```

#### AUTO 


```{c}
const auto include_me = m_config.includes(splitAcc);
```

#### AUTO 


```{c}
const auto counterAccount = idx.data(eMyMoney::Model::TransactionCounterAccountIdRole).toString();
```

#### AUTO 


```{c}
auto list = MyMoneyFile::instance()->institutionList();
```

#### AUTO 


```{c}
const auto idx = d->institutionsModel.indexById(id);
```

#### AUTO 


```{c}
const auto baseModel = MyMoneyFile::instance()->tagsModel();
```

#### AUTO 


```{c}
auto index = MyMoneyModelBase::mapToBaseSource(idx);
```

#### AUTO 


```{c}
const auto accountsModel = MyMoneyFile::instance()->accountsModel();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->valueChanged(d->feeSplitModel, d->ui->feesAmountEdit, MyMoneyMoney::ONE);
        d->updateWidgetState();
        updateTotalAmount();
    }
```

#### AUTO 


```{c}
auto rows = 0;
```

#### AUTO 


```{c}
const auto acc = d->accountsModel.itemById((*it_a).id());
```

#### AUTO 


```{c}
const auto closedRole = idx.data(eMyMoney::Model::ClosedRole);
```

#### AUTO 


```{c}
auto accountCombo = transactionEditor->findChild<KMyMoneyAccountCombo*>(QLatin1String("accountCombo"));
```

#### AUTO 


```{c}
const auto vatRate = MyMoneyMoney(account.value("VatRate")) * MyMoneyMoney(100, 1);
```

#### AUTO 


```{c}
const auto& label
```

#### AUTO 


```{c}
auto statusWidget = dynamic_cast<KMyMoneyReconcileCombo*>(d->m_editWidgets["status"])
```

#### AUTO 


```{c}
auto argValue = PyUnicode_FromString(carg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tagId : tagIdList) {
        const auto tagName = file->tag(tagId).name();
        rc = tagName.contains(d->filterString, Qt::CaseInsensitive);
        if (rc)
          break;
      }
```

#### AUTO 


```{c}
const auto transfer(transferExp.match(tmp));
```

#### AUTO 


```{c}
const auto subacc = m_file->account(subaccStr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : journalEntry.transaction().splits()) {
                const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(sp.accountId());
                if (acc.isIncomeExpense()) {
                    return false;
                }
            }
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Security>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits)
        val += split.value();
```

#### AUTO 


```{c}
auto accCurrent = &d->m_file->account(itCurrent->data((int)Role::Account).value<MyMoneyAccount>().id());
```

#### AUTO 


```{c}
auto it_pr = m_priceList.begin();
```

#### AUTO 


```{c}
auto applyButton = button(QDialogButtonBox::Apply);
```

#### AUTO 


```{c}
auto name = fields[1];
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneyTransaction& transaction : list) {
        // if we have a categorization, make sure we remove
        // the 'imported' flag automagically
        if (transaction.splitCount() > 1)
          transaction.setImported(false);

        // create information about min and max balances
        foreach (const auto split, transaction.splits()) {
          auto acc = file->account(split.accountId());
          accountIds[acc.id()] = true;
          MyMoneyMoney balance = file->balance(acc.id());
          if (!acc.value("minBalanceEarly").isEmpty()) {
            minBalanceEarly[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceEarly"));
          }
          if (!acc.value("minBalanceAbsolute").isEmpty()) {
            minBalanceAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceAbsolute"));
            minBalanceEarly[acc.id()] = false;
          }
          if (!acc.value("maxCreditEarly").isEmpty()) {
            maxCreditEarly[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditEarly"));
          }
          if (!acc.value("maxCreditAbsolute").isEmpty()) {
            maxCreditAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditAbsolute"));
            maxCreditEarly[acc.id()] = false;
          }

        // and adjust opening date of invest accounts
          if (acc.isInvest()) {
            if (acc.openingDate() > t.postDate()) {
              try {
                acc.setOpeningDate(t.postDate());
                file->modifyAccount(acc);
              } catch(MyMoneyException& ) {
                qDebug() << "Unable to modify opening date for invest account" << acc.name() << acc.id();
              }
            }
          }
        }

        if (transaction.id().isEmpty()) {
          bool enter = true;
          if (askForSchedule && transaction.postDate() > QDate::currentDate()) {
            KGuiItem enterButton(i18n("&Enter"),
                                 Icons::get(Icon::DialogOK),
                                 i18n("Accepts the entered data and stores it"),
                                 i18n("Use this to enter the transaction into the ledger."));
            KGuiItem scheduleButton(i18n("&Schedule"),
                                    Icons::get(Icon::AppointmentNew),
                                    i18n("Accepts the entered data and stores it as schedule"),
                                    i18n("Use this to schedule the transaction for later entry into the ledger."));

            enter = KMessageBox::questionYesNo(d->m_regForm, QString("<qt>%1</qt>").arg(i18n("The transaction you are about to enter has a post date in the future.<br/><br/>Do you want to enter it in the ledger or add it to the schedules?")), i18nc("Dialog caption for 'Enter or schedule' dialog", "Enter or schedule?"), enterButton, scheduleButton, "EnterOrScheduleTransactionInFuture") == KMessageBox::Yes;
          }
          if (enter) {
            // add new transaction
            file->addTransaction(transaction);
            // pass the newly assigned id on to the caller
            newId = transaction.id();
            // refresh account object for transactional changes
            // refresh account and transaction object because they might have changed
            d->m_account = file->account(d->m_account.id());
            t = transaction;

            // if a new transaction has a valid number, keep it with the account
            d->keepNewNumber(transaction);
          } else {
            // turn object creation on, so that moving the focus does
            // not screw up the dialog that might be popping up
            emit objectCreation(true);
            emit scheduleTransaction(transaction, eMyMoney::Schedule::Occurrence::Once);
            emit objectCreation(false);

            newTransactionCreated = false;
          }

          // send out the post date of this transaction
          emit lastPostDateUsed(transaction.postDate());
        } else {
          // modify existing transaction
          // its number might have been edited
          // bearing in mind it could contain alpha characters
          d->keepNewNumber(transaction);
          file->modifyTransaction(transaction);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto institution : qAsConst(list)) {
        names << institution.name();
        if (institution.name() == name) {
            d->ui->ibanEdit->setEnabled(true);
            d->ui->accountNoEdit->setEnabled(true);
            d->ui->m_bicValue->setText(institution.value("bic"));
            search = name;
        }
    }
```

#### AUTO 


```{c}
auto parent = topLevelWidget->parentWidget();
```

#### AUTO 


```{c}
const auto flag = split.reconcileFlag();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
                const auto acc = file->account(split.accountId());
                if (acc.isIncomeExpense()) {
                    if (split.shares().isNegative() && (type == Interest)) {
                        return true;
                    }
                    else if (split.shares().isPositive() && (type == Fees)) {
                        return true;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : actionInfos) {
      auto a = new QAction(Icons::get(info.icon), info.text, nullptr); // WARNING: no empty Icon::Empty here
      a->setEnabled(info.enabled);
      connect(a, &QAction::triggered, this, info.callback);
      LUTActions.append(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits) {

      if (filter.testFlag(accountFilterActive) ||
          filter.testFlag(categoryFilterActive)) {
        auto removeSplit = true;
        if (d->m_considerCategory) {
          switch (file->account(s.accountId()).accountGroup()) {
            case eMyMoney::Account::Type::Income:
            case eMyMoney::Account::Type::Expense:
              isTransfer = false;
              // check if the split references one of the categories in the list
              if (filter.testFlag(categoryFilterActive)) {
                if (d->m_categories.isEmpty()) {
                  // we're looking for transactions with 'no' categories
                  d->m_matchingSplitsCount = 0;
                  matchingSplits.clear();
                  return matchingSplits;
                } else if (d->m_categories.contains(s.accountId())) {
                  categoryMatched = true;
                  removeSplit = false;
                }
              }
              break;

            default:
              // check if the split references one of the accounts in the list
              if (!filter.testFlag(accountFilterActive)) {
                removeSplit = false;
              } else if (!d->m_accounts.isEmpty() &&
                         d->m_accounts.contains(s.accountId())) {
                accountMatched = true;
                removeSplit = false;
              }

              break;
          }

        } else {
          if (!filter.testFlag(accountFilterActive)) {
            removeSplit = false;
          } else if (!d->m_accounts.isEmpty() &&
                     d->m_accounts.contains(s.accountId())) {
            accountMatched = true;
            removeSplit = false;
          }
        }

        if (removeSplit)
          continue;
      }

      // check if less frequent filters are active
      if (extendedFilter != 0) {
        const auto acc = file->account(s.accountId());
        if (!(matchAmount(s) && matchText(s, acc)))
          continue;

        // Determine if this account is a category or an account
        auto isCategory = false;
        switch (acc.accountGroup()) {
          case eMyMoney::Account::Type::Income:
          case eMyMoney::Account::Type::Expense:
            isCategory = true;
          default:
            break;
        }

        bool includeSplit = d->m_considerCategorySplits || (!d->m_considerCategorySplits && !isCategory);
        if (includeSplit) {
          // check the payee list
          if (filter.testFlag(payeeFilterActive)) {
            if (!d->m_payees.isEmpty()) {
              if (s.payeeId().isEmpty() || !d->m_payees.contains(s.payeeId()))
                continue;
            } else if (!s.payeeId().isEmpty())
              continue;
          }

          // check the tag list
          if (filter.testFlag(tagFilterActive)) {
            const auto tags = s.tagIdList();
            if (!d->m_tags.isEmpty()) {
              if (tags.isEmpty()) {
                continue;
              } else {
                auto found = false;
                for (const auto& tag : tags) {
                  if (d->m_tags.contains(tag)) {
                    found = true;
                    break;
                  }
                }

                if (!found)
                  continue;
              }
            } else if (!tags.isEmpty())
              continue;
          }

          // check the type list
          if (filter.testFlag(typeFilterActive) &&
              !d->m_types.isEmpty() &&
              !d->m_types.contains(splitType(transaction, s, acc)))
            continue;

          // check the state list
          if (filter.testFlag(stateFilterActive) &&
              !d->m_states.isEmpty() &&
              !d->m_states.contains(splitState(s)))
            continue;

          if (filter.testFlag(nrFilterActive) &&
              ((!d->m_fromNr.isEmpty() && s.number() < d->m_fromNr) ||
               (!d->m_toNr.isEmpty() && s.number() > d->m_toNr)))
            continue;

        } else if (filter & (payeeFilterActive | tagFilterActive | typeFilterActive | stateFilterActive | nrFilterActive)) {
          continue;
        }
      }
      if (d->m_reportAllSplits)
        matchingSplits.append(s);

      isMatchingSplitsEmpty = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
        // we don't need to process all columns but only the first one
        if (idx.row() != lastRow) {
            lastRow = idx.row();
            id = idx.data(eMyMoney::Model::IdRole).toString();
            if (!selection.contains(id)) {
                selection.append(id);
            }
        }
    }
```

#### AUTO 


```{c}
auto price = d->ui->m_conversionRate->value();
```

#### AUTO 


```{c}
const auto splits = tr.splits();
```

#### AUTO 


```{c}
auto itemToClone = fromNode->child(row, i);
```

#### AUTO 


```{c}
auto b = m_budgetList.size() >= 1 ? true : false;
```

#### AUTO 


```{c}
const auto splits = transaction.splits();
```

#### AUTO 


```{c}
auto result = stockSplit.value();
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("shares"))
```

#### AUTO 


```{c}
auto p = q->mapToGlobal(QPoint(0, 0));
```

#### AUTO 


```{c}
const auto currencyId = accountIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
```

#### AUTO 


```{c}
auto EquitiesModel::getColumns()
{
  return &d->m_columns;
}
```

#### AUTO 


```{c}
const auto username = m_editUsername->text();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : transactionList) {
        // if this split is a stock split, we can't just add the amount of shares
        const auto journalEntry = file->journalModel()->itemById(journalEntryId);
        if (!journalEntry.id().isEmpty()) {
            const auto& split = journalEntry.split();
            const auto& transaction = journalEntry.transaction();

            if (split.reconcileFlag() == eMyMoney::Split::State::NotReconciled && !split.shares().isNegative()) {
                QString category;
                for (const auto& tSplit : transaction.splits()) {
                    if (tSplit.accountId() != account.id()) {
                        if (!category.isEmpty())
                            category += QLatin1String(", "); // this is a split transaction
                        category += file->account(tSplit.accountId()).name();
                    }
                }

                detailsReport += QString("<tr class=\"%1\"><td>").arg((index++ % 2 == 1) ? "row-odd" : "row-even")
                    + QString("%1").arg(QLocale().toString(transaction.entryDate(), QLocale::ShortFormat)) + "</td><td>" + QString("%1").arg(split.number())
                    + "</td><td>" + QString("%1").arg(file->payee(split.payeeId()).name()) + "</td><td>" + QString("%1").arg(transaction.memo()) + "</td><td>"
                    + QString("%1").arg(category) + "</td><td>"
                    + QString("%1").arg(MyMoneyUtils::formatMoney(split.shares(), file->currency(account.currencyId()))) + "</td></tr>";
            }
        }
    }
```

#### AUTO 


```{c}
const auto val = QStringLiteral("%1/%2").arg(amount).arg(unit);
```

#### AUTO 


```{c}
auto idx = index(rows, 0, parentIdx);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPrinter* printer) {
#ifdef ENABLE_WEBENGINE
            QEventLoop loop;
            bool result = true;
            auto printPreview = [&](bool success) {
                result = success;
                loop.quit();
            };
            m_tableView->page()->print(printer, std::move(printPreview));
            loop.exec();
            if (!result) {
                QPainter painter;
                if (painter.begin(printer)) {
                    QFont font = painter.font();
                    font.setPixelSize(20);
                    painter.setFont(font);
                    painter.drawText(QPointF(10, 25), QStringLiteral("Could not generate print preview."));
                    painter.end();
                }
            }
#else
            m_tableView->print(printer);
#endif
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        emit objectAdded(change.objectType(), change.id());
        break;
      case File::Mode::Modify:
        emit objectModified(change.objectType(), change.id());
        break;
    }
  }
```

#### AUTO 


```{c}
auto w = m_calculatorFrame->width();
```

#### AUTO 


```{c}
auto reconcile = dynamic_cast<KMyMoneyReconcileCombo*>(haveWidget("status"));
```

#### AUTO 


```{c}
auto file = qobject_cast<MyMoneyFile*>(parentObject);
```

#### AUTO 


```{c}
const auto amount =
                        MyMoneyUtils::formatMoney((idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>() * (-factor)), acc, security, true);
```

#### AUTO 


```{c}
auto fileName = QFileDialog::getSaveFileName(
                        this,
                        i18n("Select output file"),
                        QString(),
                        QString());
```

#### AUTO 


```{c}
auto commodityId = d->transaction.commodity();
```

#### AUTO 


```{c}
auto txt = d->m_fileKLineEdit->text();
```

#### AUTO 


```{c}
const auto shares = haveVisibleWidget<AmountEdit>("sharesAmountEdit");
```

#### AUTO 


```{c}
const auto idx = right.index(row, 0);
```

#### AUTO 


```{c}
auto* filterModel = qobject_cast<QSortFilterProxyModel*>(model());
```

#### AUTO 


```{c}
auto categoryMatched = !(filter.testFlag(categoryFilterActive));
```

#### AUTO 


```{c}
auto date(_date);
```

#### AUTO 


```{c}
auto priceEdit = dynamic_cast<AmountEdit*>(q->haveWidget("price"));
```

#### AUTO 


```{c}
const auto payeeId = payeesModel->index(ui->payeeEdit->currentIndex(), 0).data(eMyMoney::Model::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& view : qAsConst(d->viewBases)) {
        view->executeCustomAction(eView::Action::InitializeAfterFileOpen);
    }
```

#### AUTO 


```{c}
auto commodity = MyMoneyFile::instance()->security(d->commodityId);
```

#### AUTO 


```{c}
auto writer = new MyMoneyStorageSql(MyMoneyFile::instance()->storage(), url);
```

#### AUTO 


```{c}
const auto subIdx = d->accountsModel->index(accountIdx.row(), idx.column(), accountIdx.parent());
```

#### AUTO 


```{c}
const auto split = model->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
auto cnt = 0;
```

#### AUTO 


```{c}
auto IExtended = qobject_cast<OnlinePluginExtended *>(plugin);
```

#### AUTO 


```{c}
const auto reportsPlugin = pPlugins.data.value("reportsview", nullptr)
```

#### AUTO 


```{c}
auto end = onlineJobs.constEnd();
```

#### AUTO 


```{c}
const auto& action
```

#### AUTO 


```{c}
const auto& pair = it_allPrices.key();
```

#### AUTO 


```{c}
auto newSelections(selections);
```

#### AUTO 


```{c}
const auto accountId = static_cast<TreeItem<MyMoneyAccount>*>(idx.internalPointer())->constDataRef().id();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
      if (!result.contains(split.accountId())) {
        result[split.accountId()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
      }
      const auto flag = split.reconcileFlag();
      switch(flag) {
        case eMyMoney::Split::State::NotReconciled:
        case eMyMoney::Split::State::Cleared:
        case eMyMoney::Split::State::Reconciled:
        case eMyMoney::Split::State::Frozen:
          result[split.accountId()][(int)flag]++;
          break;
        default:
          break;
      }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : qAsConst(accounts)) {
    if (account.hasOnlineMapping()) {
      for (const onlineTask* task : qAsConst(m_onlineTasks)) {
        // Check if a online task has the correct type
        if (dynamic_cast<const creditTransfer*>(task) != 0) {
          for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
            if (plugin->availableJobs(account.id()).contains(task->taskName()))
              return true;
          }
        }
      }
    }
  }
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Transaction>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto splits = sched.transaction().splits();
```

#### AUTO 


```{c}
const auto statementCount = m_qifReader->statementCount();
```

#### AUTO 


```{c}
auto sharesEdit = d->haveWidget<AmountEdit>("sharesAmountEdit");
```

#### AUTO 


```{c}
const auto detailLevelFromXML = d->stringToDetailLevel(e.attribute(d->getAttrName(Report::Attribute::Detail)));
```

#### AUTO 


```{c}
auto ti = endingBalanceDlg->interestTransaction();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KSearchTransactionDlg);
        d->filterTab->slotReset();
    }
```

#### AUTO 


```{c}
auto bOK = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tmpl : qAsConst(templates)) {
        loader.importTemplate(tmpl);
      }
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("forecastview.rc");
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotSelectAllTransactions(); }
```

#### AUTO 


```{c}
const auto idx = q->index(row, 0);
```

#### AUTO 


```{c}
auto itInstitution = node->child(row, colInstitution);
```

#### AUTO 


```{c}
auto it = list.constBegin();
```

#### AUTO 


```{c}
auto& account
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->m_reportTabWidget->currentWidget())
```

#### AUTO 


```{c}
auto iSolo = a.daysToZeroBalance(a_Solo);
```

#### AUTO 


```{c}
auto baseIdx = baseModel->mapToBaseSource(idx);
```

#### AUTO 


```{c}
const auto payeeIdx = d->payeesModel->index(payeeRow, 0);
```

#### AUTO 


```{c}
const auto equ = d->currentEquity();
```

#### AUTO 


```{c}
auto priceEdit = dynamic_cast<KMyMoneyEdit*>(q->haveWidget("price"));
```

#### AUTO 


```{c}
auto profileName = bankProfiles.begin();
```

#### AUTO 


```{c}
auto list(_list);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tagId : tagIdList) {
                const auto tagName = file->tag(tagId).name();
                rc = tagName.contains(d->filterString, Qt::CaseInsensitive);
                if (rc)
                    break;
            }
```

#### AUTO 


```{c}
auto iter = onlineJobs.constBegin();
```

#### AUTO 


```{c}
auto i = (int)Element::Institution::AccountID;
```

#### AUTO 


```{c}
auto acc = d->accountsModel.itemById(parent.id());
```

#### AUTO 


```{c}
auto msg =
        i18np("Do you really want to delete the selected transaction?",
              "Do you really want to delete all %1 selected transactions?",
              d->m_selectedTransactions.count());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        d->categoryChanged(d->interestSplitModel, accountId, d->ui->interestAmountEdit, MyMoneyMoney::MINUS_ONE);
        d->updateWidgetState();
        if (!d->interestSplitModel->valueSum().isZero()) {
            d->scheduleUpdateTotalAmount();
        }
    }
```

#### AUTO 


```{c}
const auto accountId = args.at(0).toString();
```

#### AUTO 


```{c}
const auto col = columnAt(helpEvent->x());
```

#### AUTO 


```{c}
const auto defaultTabOrder = QStringList{
        QLatin1String("creditDebitEdit"),
        QLatin1String("payeeEdit"),
        QLatin1String("numberEdit"),
        QLatin1String("accountCombo"),
        QLatin1String("costCenterCombo"),
        QLatin1String("tagContainer"),
        QLatin1String("memoEdit"),
        QLatin1String("enterButton"),
        QLatin1String("cancelButton"),
    };
```

#### AUTO 


```{c}
auto getCell = [&, row](const auto column) {
      cell = node->child(row, column);      // try to get QStandardItem
      if (!cell) {                          // it may be uninitialized
        cell = new QStandardItem;           // so create one
        node->setChild(row, column, cell);  // and add it under the node
      }
    };
```

#### AUTO 


```{c}
auto i = (int)Payee::Attribute::Name;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : d->m_transaction.splits()) {
            if (split.id() == d->m_split.id()) {
                d->ui->dateEdit->setDate(d->m_transaction.postDate());

                const auto payeeId = split.payeeId();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(split.memo());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(split.number());
                d->ui->statusCombo->setCurrentIndex(static_cast<int>(split.reconcileFlag()));
                d->ui->tagContainer->loadTags(split.tagIdList());
            } else {
                // we block sending out signals for the category combo here to avoid
                // calling NewTransactionEditorPrivate::categoryChanged which does not
                // work properly when loading the editor
                QSignalBlocker categoryComboBlocker(d->ui->categoryCombo);
                d->splitModel.appendSplit(split);
                if (d->m_transaction.splitCount() == 2) {
                    // force the value of the second split to be the same as for the first
                    const auto idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-amountValue), eMyMoney::Model::SplitValueRole);

                    // use the shares based on the second split
                    amountShares = -split.shares();

                    // adjust the commodity for the shares
                    const auto accountId = split.accountId();
                    const auto accountIdx = MyMoneyFile::instance()->accountsModel()->indexById(accountId);
                    const auto currencyId = accountIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
                    const auto currency = MyMoneyFile::instance()->currenciesModel()->itemById(currencyId);
                    d->ui->creditDebitEdit->setSharesCommodity(currency);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto delegate : delegates) {
            JournalDelegate* journalDelegate = qobject_cast<JournalDelegate*>(delegate);
            if(journalDelegate) {
                journalDelegate->setSingleLineRole(role);
            }
        }
```

#### AUTO 


```{c}
const auto data = sourceModel()->data(source, AccountsModel::AccountRole);
```

#### AUTO 


```{c}
auto interest = new KMyMoneyCategory(true, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    if (startRow != -1) {
      selection.select(model()->index(startRow, 0), model()->index(lastRow, lastColumn));
      startRow = -1;
    }
  }
```

#### AUTO 


```{c}
auto abc = QString();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        validateSelectedColumn(col, Column::Category);
    }
```

#### AUTO 


```{c}
const auto row = legendRows.at(ixRow);
```

#### AUTO 


```{c}
auto i = (int)Attribute::Transaction::Name;
```

#### AUTO 


```{c}
const auto item = ui.m_tocTreeWidget->topLevelItem(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* button : m_control->findChildren<QToolButton*>()) {
        button->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    }
```

#### AUTO 


```{c}
const auto splitState = idx.data(eMyMoney::Model::SplitReconcileFlagRole).value<eMyMoney::Split::State>();
```

#### AUTO 


```{c}
auto idx = d->ui->m_budgetList->model()->index(row, 0);
```

#### AUTO 


```{c}
auto i = (int)View::Home;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        setState(static_cast<AccountsProxyModel::State>(idx));
    }
```

#### AUTO 


```{c}
auto account = model->itemById(categoryId);
```

#### AUTO 


```{c}
auto isEmpty = onlineJob::getElName(static_cast<onlineJob::Element>(i)).isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KCMCSVImporter);
        d->setSelectedProfile(d->ui->qifProfileCombo->currentIndex());
    }
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::instance()->costCenterModel()->indexById(id);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) { m_separator = m_fieldDelimiterCharList[index]; }
```

#### AUTO 


```{c}
const auto templates = dlg->templates();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto baseIdx : indexes) {
            if (baseIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
                row = journalModel->mapFromBaseSource(model(), baseIdx).row();
                if (row != -1) {
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto security = d->haveWidget<KMyMoneySecurity*>("security");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*transaction).splits()) {
            const JournalEntry journalEntry(it.key(), transaction, split);
            static_cast<TreeItem<JournalEntry>*>(index(row, 0).internalPointer())->dataRef() = journalEntry;
            ++row;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        d->postdateChanged(date);
        emit postDateChanged(date);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            // turn on signals before we modify the last entry in the list
            cnt--;
            MyMoneyFile::instance()->blockSignals(cnt != 0);

            // get a fresh copy
            auto journalEntry = file->journalModel()->itemById(journalEntryId);
            if (!journalEntry.id().isEmpty()) {
                auto t = journalEntry.transaction();
                auto sp = journalEntry.split();
                if (sp.reconcileFlag() != flag) {
                    if (flag == eMyMoney::Split::State::Unknown) {
                        /// @todo fixme for reconciliation
                        // if (m_reconciliationAccount.id().isEmpty()) {
                            // in normal mode we cycle through all states
                            switch (sp.reconcileFlag()) {
                                case eMyMoney::Split::State::NotReconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Cleared);
                                    break;
                                case eMyMoney::Split::State::Cleared:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Reconciled);
                                    break;
                                case eMyMoney::Split::State::Reconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                    break;
                                default:
                                    break;
                            }
#if 0
                    /// @todo fixme for reconciliation
                        } else {
                            // in reconciliation mode we skip the reconciled state
                            switch (sp.reconcileFlag()) {
                                case eMyMoney::Split::State::NotReconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Cleared);
                                    break;
                                case eMyMoney::Split::State::Cleared:
                                    sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                    break;
                                default:
                                    break;
                            }
                        }
#endif
                    } else {
                        sp.setReconcileFlag(flag);
                    }

                    t.modifySplit(sp);
                    MyMoneyFile::instance()->modifyTransaction(t);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& a : disabledActions)
            pActions[a]->setEnabled(false);
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney/onlinetasks", [&name](const KPluginMetaData& data) {
        QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
        if (array.isArray())
            return (array.toVariant().toStringList().contains(name));
        return false;
    });
```

#### AUTO 


```{c}
const auto homeView = static_cast<KHomeView*>(viewBases[view]);
```

#### AUTO 


```{c}
auto job = readOnlineJob(m_baseNode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : m_valueChanges) {
    if (!removedObjects.contains(id)) {
      emit valueChanged(account(id));
    }
  }
```

#### AUTO 


```{c}
const auto baseCurrency = MyMoneyFile::instance()->baseCurrency();
```

#### AUTO 


```{c}
auto model = new QStringListModel(this);
```

#### AUTO 


```{c}
auto accIdx = file->accountsModel()->indexById(splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString());
```

#### AUTO 


```{c}
auto totalcolumn = 0;
```

#### AUTO 


```{c}
const auto& inst = static_cast<const MyMoneyInstitution&>(obj);
```

#### AUTO 


```{c}
const auto accountData = sourceModel()->data(index, (int)Role::Account);
```

#### AUTO 


```{c}
const auto delegate = d->findDelegate(index);
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(accId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid())
                    d->ui->payeeEdit->setCurrentIndex(d->payeesModel->mapFromSource(payeeIdx).row());
                else
                    d->ui->payeeEdit->setCurrentIndex(0);

                bool blocked = d->ui->accountCombo->blockSignals(true);
                switch (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole).toInt()) {
                case 1:
                    d->ui->accountCombo->clearEditText();
                    d->ui->accountCombo->setSelected(QString());
                    break;
                case 2:
                    d->ui->accountCombo->setSelected(splitIdx.data(eMyMoney::Model::TransactionCounterAccountIdRole).toString());
                    break;
                default:
                    d->ui->accountCombo->setEditText(splitIdx.data(eMyMoney::Model::TransactionCounterAccountRole).toString());
                    break;
                }
                d->ui->accountCombo->blockSignals(blocked);

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                // The calculator for the amount field can simply be added as an icon to the line edit widget.
                // See https://stackoverflow.com/questions/11381865/how-to-make-an-extra-icon-in-qlineedit-like-this howto do it
                d->ui->amountEditCredit->setText(splitIdx.data(eMyMoney::Model::JournalSplitPaymentRole).toString());
                d->ui->amountEditDebit->setText(splitIdx.data(eMyMoney::Model::JournalSplitDepositRole).toString());

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
                d->ui->statusCombo->setCurrentIndex(0); // default is not reconciled

                const QModelIndexList stList = statusModel->match(statusModel->index(0, 0), eMyMoney::Model::SplitReconcileFlagRole, splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
                if (!stList.isEmpty()) {
                    d->ui->statusCombo->setCurrentIndex(stList.front().row());
                }
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    const auto value = splitIdx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
                    d->price = value / shares;
                }
            }
        }
```

#### AUTO 


```{c}
const auto memo = rowIndex.data(eMyMoney::Model::Roles::SplitSingleLineMemoRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& statement : statements) {
        if (abort)
            break;
        if (importStatement(statement).isEmpty())
            ok = false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
      Q_D(KTagsView);
      d->m_renameProxyModel->setReferenceFilter(d->ui->m_filterBox->itemData(idx));
    }
```

#### AUTO 


```{c}
const auto rowIndex = rowIndeces[row];
```

#### AUTO 


```{c}
const auto view = d->stackedView;
```

#### AUTO 


```{c}
auto cb = qobject_cast<QComboBox*>(o);
```

#### AUTO 


```{c}
const auto list = m_q->model()->match(m_q->model()->index(startRow, 0),
                                              eMyMoney::Model::Roles::IdRole,
                                              QVariant(id),
                                              1,
                                              Qt::MatchFlags(Qt::MatchExactly | Qt::MatchWrap | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto i = (int)TransactionFilter::Date::All;
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnTag]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : qAsConst(selection)) {
            list << d->model->itemByIndex(idx);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
    /* There is a bug in
    static int layoutText(QTextLayout *layout, int maxWidth)
    from kpageview_p.cpp from kwidgetsaddons.
    The method doesn't break strings that are too long. Following line
    workarounds this by using LINE SEPARATOR character which is accepted by
    QTextLayout::createLine().*/
    viewFrames[view.id] = m_model->addPage(viewBases[view.id], QString(view.name).replace('\n', QString::fromLocal8Bit("\xe2\x80\xa8")));
    viewFrames[view.id]->setIcon(Icons::get(view.icon));
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByObject, this, &KMyMoneyView::slotSelectByObject);
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByVariant, this, &KMyMoneyView::slotSelectByVariant);
    connect(viewBases[view.id], &KMyMoneyViewBase::customActionRequested, this, &KMyMoneyView::slotCustomActionRequested);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
    // the following line will throw an exception if the
    // account does not exist or is one of the standard accounts
    const auto acc = account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION("Cannot add split with no account assigned");
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION("Cannot add split referencing standard account");
  }
```

#### AUTO 


```{c}
auto depositWidget = dynamic_cast<AmountEdit*>(d->m_editWidgets["deposit"])
```

#### AUTO 


```{c}
auto plugins = findPlugins("kmymoney/onlinetasks", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
    });
```

#### AUTO 


```{c}
const auto accountBalance = MyMoneyFile::instance()->balance(index.data(eMyMoney::Model::SplitAccountIdRole).toString(), reconciliationDate);
```

#### AUTO 


```{c}
auto cashflow = dynamic_cast<KMyMoneyCashFlowCombo*>(d->m_editWidgets["cashflow"])
```

#### AUTO 


```{c}
const auto rows = model->rowCount();
```

#### AUTO 


```{c}
const auto focusWidget = findChild<QWidget*>(tabOrder.first());
```

#### AUTO 


```{c}
auto payeeId = m_split.payeeId();
```

#### AUTO 


```{c}
const auto txt(amount.formatMoney(QString(), d->precision(AmountEdit::DisplayShares), false));
```

#### AUTO 


```{c}
auto tab = static_cast<Tab>(m_tab->currentIndex());
```

#### AUTO 


```{c}
auto i = (int)KVC::Element::Pair;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& current, const QModelIndex& previous) {
                Q_UNUSED(previous)
                Q_D(KInvestmentView);
                d->m_equitySelections.setSelection(SelectedObjects::Account, current.data(eMyMoney::Model::IdRole).toString());
                if (d->ui->m_equitiesTree->isVisible()) {
                    d->m_selections = d->m_equitySelections;
                    emit requestSelectionChange(d->m_selections);
                }
            }
```

#### AUTO 


```{c}
auto item = d->ui->m_homePageList->currentItem();
```

#### AUTO 


```{c}
auto list = d->ui.m_targetWidget->findChildren<QObject*>();
```

#### AUTO 


```{c}
const auto list = model->match(model->index(0, 0), AccountsModel::AccountIdRole, QVariant(accountId), -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyPayee::getAttrName(static_cast<MyMoneyPayee::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto item = ui->m_selectedList->currentItem();
```

#### AUTO 


```{c}
auto categoryLabel = dynamic_cast<QLabel*>(haveWidget("category-label"));
```

#### AUTO 


```{c}
const auto idx = d->ui->securityCombo->model()->index(index, 0);
```

#### AUTO 


```{c}
auto pattern = exp.pattern();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyKeyValueContainerPrivate::getAttrName(static_cast<KVC::Attribute>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : splits) {
        MyMoneyAccount splitAccount = file->account(split.accountId());
        if (!accounts.contains(split.accountId())) {
          accounts << split.accountId();
        }
        // if this split references an interest account, the action
        // must be of type ActionInterest
        if (interestAccounts.contains(split.accountId())) {
          if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
            qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
            split.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
            qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
          }
          // if it does not reference an interest account, it must not be
          // of type ActionInterest
        } else {
          if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
            qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
            split.setAction(defaultAction);
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
            qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
          }
        }

        // check that for splits referencing an account that has
        // the same currency as the transactions commodity the value
        // and shares field are the same.
        if (transaction.commodity() == splitAccount.currencyId()
            && split.value() != split.shares()) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
          split.setShares(split.value());
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
        }

        // fix the shares and values to have the correct fraction
        if (!splitAccount.isInvest()) {
          try {
            int fract = splitAccount.fraction();
            if (split.shares() != split.shares().convert(fract)) {
              qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
              split.setShares(split.shares().convert(fract));
              split.setValue(split.value().convert(fract));
              transaction.modifySplit(split);
              file->modifyTransaction(transaction);
            }
          } catch (const MyMoneyException &) {
            qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
          }
        }
      }
```

#### AUTO 


```{c}
const auto idx = q->model()->index(row, 0);
```

#### AUTO 


```{c}
const auto reportsPlugin = pPlugins.data.value(QStringLiteral("reportsview"), nullptr)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits2) {
    d->accountsModel.touchAccountById(split.accountId());;
    d->addCacheNotification(split.accountId(), transaction.postDate());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& view : d->viewsInfo) {
        d->addSharedActions(d->viewBases[view.id]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& it : actionOverlaidIcons)
      lutActions[it.action]->setIcon(KMyMoneyUtils::overlayIcon(g_Icons[it.icon], g_Icons[it.overlay], it.corner));
```

#### AUTO 


```{c}
const auto currentIndex = view->currentIndex();
```

#### AUTO 


```{c}
const auto idx = ui->m_parentAccounts->currentIndex();
```

#### AUTO 


```{c}
auto specialDatesFilter = new SpecialDatesFilter(file->specialDatesModel(), q);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyPayeePrivate::getAttrName(static_cast<Payee::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto fee = dynamic_cast<KMyMoneyCategory*>(haveWidget("fee-account"));
```

#### AUTO 


```{c}
auto t_day = 1;
```

#### AUTO 


```{c}
const auto rightData = sourceModel()->data(right, eMyMoney::Model::Roles::AccountDisplayOrderRole);
```

#### AUTO 


```{c}
const auto idx = ui->m_frequencyEdit->model()->index(row, 0);
```

#### AUTO 


```{c}
auto idx = d->accountsModel.indexById(account.id());
```

#### AUTO 


```{c}
const auto indexes = journalModel->indexesByTransactionId(id);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int multiplier) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        auto oldOccurrenceMultiplier = d->m_schedule.occurrenceMultiplier();
        if (multiplier != oldOccurrenceMultiplier) {
            if (d->ui->endOptionsFrame->isEnabled()) {
                d->m_schedule.setNextDueDate(d->transactionEditor->postDate());
                d->m_schedule.setOccurrenceMultiplier(multiplier);
                d->setScheduleOccurrencePeriod();
                d->m_schedule.setEndDate(d->ui->finalPaymentDateEdit->date());
                d->updateTransactionsRemaining();
            }
        }
    }
```

#### AUTO 


```{c}
auto css = cssUrl.toLocalFile();
```

#### AUTO 


```{c}
auto feeAccountWidget = dynamic_cast<KMyMoneyCategory*>(haveWidget("fee-account"));
```

#### AUTO 


```{c}
const auto accounts = selections.selection(SelectedObjects::Account);
```

#### AUTO 


```{c}
auto payee = MyMoneyFile::instance()->payee(sp.payeeId());
```

#### AUTO 


```{c}
auto t_day = 0;
```

#### AUTO 


```{c}
auto security = MyMoneyFile::instance()->security(account.currencyId());
```

#### AUTO 


```{c}
auto categoryId = d->m_editCategory->selectedItem();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &column : visibleColumns) {
          if (d->applyStorageOffsetColumns.contains(column)) {
            column -= d->storageOffset;
          }
        }
```

#### AUTO 


```{c}
const auto& last = sched.lastPayment();
```

#### AUTO 


```{c}
const auto secId = idx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
```

#### AUTO 


```{c}
const auto ret = !statementInterface()->import(s, m_silent).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto split : transaction.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (int i = 0; i < tagIdList.size(); ++i) {
                            // if the split is assigned to one of the selected tags, we need to modify it
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (tagIdList.indexOf(tag_id) == -1)
                                    tagIdList.append(tag_id);
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList); // first modify tag list in current split
                        // then modify the split in our local copy of the transaction list
                        transaction.modifySplit(split); // this does not modify the list object 'splits'!
                    }
```

#### AUTO 


```{c}
const auto accId = selections.selection(SelectedObjects::Account).at(0);
```

#### AUTO 


```{c}
auto sortOrder = static_cast<Qt::SortOrder>(grp.readEntry<int>("KScheduleView_sortOrder", Qt::AscendingOrder));
```

#### AUTO 


```{c}
const auto rightData = sourceModel()->data(sourceModel()->index(right.row(), AccountsModel::Column::AccountName, right.parent()), eMyMoney::Model::Roles::AccountTotalValueRole);
```

#### AUTO 


```{c}
const auto needAccountMatch = filter.testFlag(accountFilterActive);
```

#### AUTO 


```{c}
const auto& list = m_profile->m_memoColList;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &split : transaction.splits())
        writeSplit(split, document, splitsElement);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        d->m_schedule.setNextDueDate(d->transactionEditor->postDate());
        d->setScheduleOccurrencePeriod();
        d->m_schedule.setOccurrenceMultiplier(d->ui->frequencyNoEdit->value());

        if (d->m_schedule.endDate() != date) {
            d->m_schedule.setEndDate(date);
            d->updateTransactionsRemaining();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& pluginData : pluginDatas) {
      if (pluginData.serviceTypes().contains(QStringLiteral("KMyMoney/Plugin"))) {
        if (!onlyEnabled ||
            (onlyEnabled && isPluginEnabled(pluginData, pluginSection))) {
          plugins.insert(pluginData.pluginId(), pluginData);
        }
      }
    }
```

#### AUTO 


```{c}
auto themeName = KMyMoneySettings::iconsTheme();
```

#### AUTO 


```{c}
const auto journalEntry = journalModel->itemByIndex(idx);
```

#### AUTO 


```{c}
auto it = st.m_listPrices.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
          // create copy of transaction in current schedule
          auto trans = schedule.transaction();
          // create copy of lists of splits
          for (auto& split : trans.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (auto i = 0; i < tagIdList.size(); ++i) {
              if (d->tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList);
            trans.modifySplit(split); // does not modify the list object 'splits'!
          } // for - Splits
          // store transaction in current schedule
          schedule.setTransaction(trans);
          file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
        }
```

#### AUTO 


```{c}
const auto idx = MyMoneyModelBase::lowerBound(key);
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::account(parent.id());
```

#### AUTO 


```{c}
auto warnLevel = 0;
```

#### AUTO 


```{c}
auto colNum = m_columns.indexOf(Column::Security);
```

#### AUTO 


```{c}
auto tmp = node.attribute(attributeName(Attribute::Account::Type));
```

#### AUTO 


```{c}
auto font = KMyMoneySettings::listHeaderFontEx();
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto payment = dynamic_cast<AmountEdit*>(haveWidget("payment"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx: indexes) {
            budgetIds << idx.data(eMyMoney::Model::IdRole).toString();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPrinter* printer) {
                m_tableView->print(printer);
            }
```

#### AUTO 


```{c}
const auto transactions = d->selections.selection(SelectedObjects::Transaction);
```

#### AUTO 


```{c}
auto value = baseAmountMM.convert(file->baseCurrency().smallestAccountFraction());
```

#### AUTO 


```{c}
auto report = variantReport.value<QWidget *>();
```

#### AUTO 


```{c}
auto payment = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["payment"]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : qAsConst(list)) {
    result[acc.id()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
  }
```

#### AUTO 


```{c}
const auto showLedgerLens = LedgerViewSettings::instance()->showLedgerLens();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
        addAccount(QString(), idx.data(eMyMoney::Model::IdRole).toString());
    }
```

#### AUTO 


```{c}
auto favItem = d->itemFromAccountId(favoriteAccountsItem, account.id())
```

#### AUTO 


```{c}
auto schedule = MyMoneyFile::instance()->schedule(scheduleId);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& button : buttons)
            button = nullptr;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : pPlugins.storage) {
      if (plugin->storageType() == extension) {
        fileExtensions += plugin->fileExtension() + QLatin1String(";;");
        break;
      }
    }
```

#### AUTO 


```{c}
auto i = (int)Attribute::Tag::Name;
```

#### AUTO 


```{c}
auto connection = actionConnections.cbegin();
```

#### AUTO 


```{c}
auto button
```

#### AUTO 


```{c}
auto i = (int)MyMoneyTag::Attribute::Name;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotAcceptTransaction(); }
```

#### AUTO 


```{c}
const auto pointSizeDelta = (stockPointSize * KMyMoneySettings::zoomFactor()) - currentPointSize;
```

#### AUTO 


```{c}
const auto accountGroup = accIdx.data(eMyMoney::Model::AccountGroupRole).value<eMyMoney::Account::Type>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char* containerClass, const char* widgetClass) {
        if (focusWidget->qt_metacast(widgetClass) && focusWidget->parentWidget()->qt_metacast(containerClass) && (reason == Qt::BacktabFocusReason)) {
            if (focusWidget->previousInFocusChain() == focusWidget->parentWidget()) {
                focusWidget = focusWidget->parentWidget();
            }
        }
    }
```

#### AUTO 


```{c}
auto newIdx = index(srcRow, 0);
```

#### AUTO 


```{c}
const auto& idx
```

#### AUTO 


```{c}
const auto forecastPage = new KSettingsForecast();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : list) {
            for (const auto& split : transaction.splits()) {
                if (!split.shares().isZero()) {
                    auto acc = file->account(split.accountId());

                    //workaround for stock accounts which have faulty opening dates
                    QDate openingDate;
                    if (acc.accountType() == eMyMoney::Account::Type::Stock) {
                        auto parentAccount = file->account(acc.parentAccountId());
                        openingDate = parentAccount.openingDate();
                    } else {
                        openingDate = acc.openingDate();
                    }

                    if (q->isForecastAccount(acc) //If it is one of the accounts we are checking, add the amount of the transaction
                            && ((openingDate < transaction.postDate() && q->skipOpeningDate())
                                || !q->skipOpeningDate())) {  //don't take the opening day of the account to calculate balance
                        dailyBalances balance;
                        //FIXME deal with leap years
                        balance = m_accountListPast[acc.id()];
                        if (acc.accountType() == eMyMoney::Account::Type::Income) {//if it is income, the balance is stored as negative number
                            balance[transaction.postDate()] += (split.shares() * MyMoneyMoney::MINUS_ONE);
                        } else {
                            balance[transaction.postDate()] += split.shares();
                        }
                        // check if this is a new account for us
                        m_accountListPast[acc.id()] = balance;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto kyIcon = g_Icons.value(Icon::ViewInstitutions) + QString::number(size);
```

#### AUTO 


```{c}
auto onlineBankSettingsPairs = account.onlineBankingSettings().pairs();
```

#### AUTO 


```{c}
const auto& transactions = d->m_transactionList;
```

#### AUTO 


```{c}
const auto matchType = (*it_p).matchData(ignoreCase, keys);
```

#### AUTO 


```{c}
const auto idColumn = static_cast<SecuritiesModel::Column>(retAction->objectName().toInt());
```

#### AUTO 


```{c}
auto it = menuNames.cbegin();
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->accountsModel()->itemById(sp.accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits)
    if (!d->m_accountList.contains(split.accountId()))
      throw MYMONEYEXCEPTION("bad account id");
```

#### AUTO 


```{c}
const auto selection = d->m_view->selectedTransactions();
```

#### AUTO 


```{c}
const auto accounts = account.accountList();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& parent, int first, int last) {
            Q_D(SimpleLedgerView);
            for (int row = first; row <= last; ++row) {
                const auto modelIdx = parent.model()->index(row, 0, parent);
                auto accountId = modelIdx.data(eMyMoney::Model::IdRole).toString();
                const auto idx = d->tabIdByAccountId(accountId);
                if (idx != -1) {
                    closeLedger(idx);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& subAccount : subAccounts) {
      if (subAccount.isInvest()) {
        d->loadInstitution(this, subAccount);
      }
    }
```

#### AUTO 


```{c}
auto institutionItem = d->institutionItemFromId(this, id)
```

#### AUTO 


```{c}
auto amount = d->haveWidget<AmountEdit>("priceAmountEdit")
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto view : views)
            if (d->viewBases.contains(view))
                d->viewBases[view]->slotSelectByObject(obj, eView::Intent::UpdateActions);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
      Q_D(KTagsView);
      emit requestCustomContextMenu(eMenu::Menu::Transaction, d->ui->m_register->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto pattern(textfilter.pattern());
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Schedule>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto matchedSplit = d->matchedSplit(split);
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(*it_w);
```

#### AUTO 


```{c}
const auto selectedSplitRow = idx.row();
```

#### AUTO 


```{c}
const auto prec = MyMoneyMoney::denomToPrec(tradingCurrencyIdx.data(eMyMoney::Model::SecuritySmallestAccountFractionRole).toInt());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        validateSelectedColumn(col, Column::Date);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
      query.bindValue(":id", id);
      query.bindValue(":originAccount", task.responsibleAccount());
      query.bindValue(":value", task.value().toString());
      query.bindValue(":purpose", task.purpose());
      query.bindValue(":endToEndReference", (task.endToEndReference().isEmpty()) ? QVariant() : QVariant::fromValue(task.endToEndReference()));
      query.bindValue(":beneficiaryName", task.beneficiaryTyped().ownerName());
      query.bindValue(":beneficiaryIban", task.beneficiaryTyped().electronicIban());
      query.bindValue(":beneficiaryBic", (task.beneficiaryTyped().storedBic().isEmpty()) ? QVariant() : QVariant::fromValue(task.beneficiaryTyped().storedBic()));
      query.bindValue(":textKey", task.textKey());
      query.bindValue(":subTextKey", task.subTextKey());
    }
```

#### AUTO 


```{c}
auto s = t.splitById(journalIdx.data(eMyMoney::Model::JournalSplitIdRole).toString());
```

#### AUTO 


```{c}
auto msg =
      i18np("Do you really want to delete the selected transaction?",
            "Do you really want to delete all %1 selected transactions?",
            d->m_selectedTransactions.count());
```

#### AUTO 


```{c}
auto accounts = tmpl.accountTree();
```

#### AUTO 


```{c}
auto i = 1;
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(source_row, (int)Column::Account, source_parent);
```

#### AUTO 


```{c}
const auto value = index.data(eMyMoney::Model::TransactionInterestValueRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
const auto idx = current.model()->index(current.row(), 0);
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(cid);
```

#### AUTO 


```{c}
const auto data = model()->data(index, AccountsModel::AccountRole);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int logicalIndex, int oldIndex, int newIndex) {
        emit sectionMoved(this, logicalIndex, oldIndex, newIndex);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
          // create copy of transaction in current schedule
          auto trans = schedule.transaction();
          // create copy of lists of splits
          for (auto& split : trans.splits()) {
            if (payeeInList(d->m_selectedPayees, split.payeeId())) {
              split.setPayeeId(payee_id);
              trans.modifySplit(split); // does not modify the list object 'splits'!
            }
          } // for - Splits
          // store transaction in current schedule
          schedule.setTransaction(trans);
          file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
        }
```

#### AUTO 


```{c}
const auto list = model->match(model->index(0, 0), AccountsModel::AccountIdRole, QVariant(institutionId), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
const auto investmentAccount = m_file->account(account.parentAccountId());
```

#### AUTO 


```{c}
const auto splitIdx = splitModel.index(0, 0);
```

#### AUTO 


```{c}
auto tag2 = MyMoneyXmlContentHandler::readTag(el);
```

#### AUTO 


```{c}
const auto view = qobject_cast<const QTableView*>(w);
```

#### LAMBDA EXPRESSION 


```{c}
[&] { d->updateItemCount(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        Q_D(KPayeesView);
        // it does not make sense to jump to myself
        pActions[eMenu::Action::GoToPayee]->setDisabled(true);
        emit requestCustomContextMenu(eMenu::Menu::Transaction, d->ui->m_register->mapToGlobal(pos));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
    // the following line will throw an exception if the
    // account does not exist or is one of the standard accounts
    auto acc = MyMoneyFile::account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION_CSTRING("Cannot add split with no account assigned");
    if (acc.isLoan())
      loanAccountAffected = true;
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing standard account");
    if (!split.payeeId().isEmpty()) {
      if (payee(split.payeeId()).id().isEmpty()) {
        throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing unknown payee");
      }
    }
    foreach (const auto tagId, split.tagIdList()) {
      if (!tagId.isEmpty())
        tag(tagId);
    }
  }
```

#### AUTO 


```{c}
auto canWrite = false;
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<KMyMoneyDateInput*>(editor->haveWidget("postdate"))
```

#### AUTO 


```{c}
auto schedules = file->scheduleList(accountId, eMyMoney::Schedule::Type::Any, eMyMoney::Schedule::Occurrence::Any, eMyMoney::Schedule::PaymentType::Any, QDate(), QDate(), true);
```

#### AUTO 


```{c}
const auto schedulesView = static_cast<KScheduledView*>(viewBases[view]);
```

#### AUTO 


```{c}
auto pattern(d->ui->m_textEdit->text());
```

#### AUTO 


```{c}
auto budget = file->budget(id);
```

#### AUTO 


```{c}
auto* editor = qobject_cast<TransactionEditorBase*>(editWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
    /* There is a bug in
    static int layoutText(QTextLayout *layout, int maxWidth)
    from kpageview_p.cpp from kwidgetsaddons.
    The method doesn't break strings that are too long. Following line
    workarounds this by using LINE SEPARATOR character which is accepted by
    QTextLayout::createLine().*/
    viewFrames[view.id] = m_model->addPage(viewBases[view.id], QString(view.name).replace(QLatin1Char('\n'), QString::fromUtf8("\xe2\x80\xa8")));
    viewFrames[view.id]->setIcon(Icons::get(view.icon));
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByObject, this, &KMyMoneyView::slotSelectByObject);
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByVariant, this, &KMyMoneyView::slotSelectByVariant);
    connect(viewBases[view.id], &KMyMoneyViewBase::customActionRequested, this, &KMyMoneyView::slotCustomActionRequested);
    connect(this, &KMyMoneyView::settingsChanged, viewBases[view.id], &KMyMoneyViewBase::slotSettingsChanged);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& it : checkableActions) {
      lutActions[it]->setCheckable(true);
      lutActions[it]->setEnabled(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& idx) {
        Q_D(KSearchTransactionDlg);
        d->selectTransaction(idx);
    }
```

#### AUTO 


```{c}
auto i = 0 ;
```

#### AUTO 


```{c}
auto account = m->account(MyMoneyAccount::stdAccName(eMyMoney::Account::Standard::Income));
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->account(d->m_idInvAcc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& pluginData : allPluginDatas)
        switch (KMyMoneyPlugin::pluginCategory(pluginData)) {
        case KMyMoneyPlugin::Category::StandardPlugin:
            standardPlugins.append(pluginData);
            break;
        case KMyMoneyPlugin::Category::PayeeIdentifier:
            payeePlugins.append(pluginData);
            break;
        case KMyMoneyPlugin::Category::OnlineBankOperations:
            onlinePlugins.append(pluginData);
            break;
        default:
            break;
        }
```

#### AUTO 


```{c}
auto secondAccName = filteredAccounts.at(i).name();
```

#### AUTO 


```{c}
auto const& weekDay
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& view : d->viewsInfo) {
        addView(d->viewBases[view.id], view.name, view.id, view.icon);
    }
```

#### AUTO 


```{c}
const auto acc = file->account(sp->accountId());
```

#### AUTO 


```{c}
auto it = m_reader->d->fileInfoKvp.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : journalEntryIds) {
            const auto idx = journalModel->indexById(journalEntryId);
            if (idx.data(eMyMoney::Model::SplitReconcileFlagRole).value<eMyMoney::Split::State>() == eMyMoney::Split::State::Cleared) {
                transactionsBalance += idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
            } else {
                qDebug() << "Found uncleared" << journalEntryId;
                unclearedJournalEntryIds.append(journalEntryId);
            }
        }
```

#### AUTO 


```{c}
auto type = static_cast<eMyMoney::Security::Type>(field("securityType").toInt());
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyPricePrivate *>(right.d_func());
```

#### AUTO 


```{c}
auto treeItem = m_equitiesTree->currentIndex();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& sp : qAsConst(interestSplits)) {
                  amount += sp.value();
                }
```

#### AUTO 


```{c}
const auto indexes = match(index(0, 0, group), eMyMoney::Model::Roles::IdRole, m_idLeadin, -1, Qt::MatchStartsWith | Qt::MatchRecursive);
```

#### AUTO 


```{c}
const auto& priceInfo
```

#### AUTO 


```{c}
const auto screenRect = QApplication::desktop()->screenGeometry(screenNr);
```

#### AUTO 


```{c}
const auto taxId = taxCategoryId();
```

#### AUTO 


```{c}
const auto newSymbol = d->ui->m_currencyList->currentItem()->text(2);
```

#### AUTO 


```{c}
auto newColPos = 0;
```

#### AUTO 


```{c}
auto sec = security(acc.currencyId());
```

#### AUTO 


```{c}
const auto rate = d->assetSplit.value() / d->assetSplit.shares();
```

#### AUTO 


```{c}
const auto memo(memoExp.match(kt.m_strMemo));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); i++) {
              if (tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList);
            trans.modifySplit(split); // does not modify the list object 'splits'!
          }
```

#### AUTO 


```{c}
auto removeCellFromRow = [=](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          if (childItem->hasChildren())
            self(self, childItem);
          childItem->removeColumn(ixCol);
        }
        return true;
      };
```

#### AUTO 


```{c}
auto selectedId = d->ui->m_paymentMethodEdit->itemData(d->ui->m_paymentMethodEdit->currentIndex(), Qt::UserRole).toInt();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KInstitutionsView);
        d->ui->m_searchWidget->clear();
        d->ui->m_filterContainer->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto tag : qAsConst(m_tagLabelList)) {
            tags << tag->id();
        }
```

#### AUTO 


```{c}
auto transactionID = transaction.id();
```

#### LAMBDA EXPRESSION 


```{c}
[&](firstOrLastVisible type) {
        const int ofs = (type == FirstVisible) ? 1 : -1;
        int idx = (type == FirstVisible) ? 0 : tabOrder.count() - 1;
        for (; idx >= 0 && idx < tabOrder.count(); idx += ofs) {
            auto w = topLevelWidget->findChild<QWidget*>(tabOrder.at(idx));
            // in case of embedded transaction editors, we may search
            // for a widget that is known to the parent
            if (!w) {
                auto parent = topLevelWidget->parentWidget();
                while (true) {
                    w = parent->findChild<QWidget*>(tabOrder.at(idx));
                    if (!w && qobject_cast<QGroupBox*>(parent)) {
                        parent = parent->parentWidget();
                        continue;
                    }
                    break;
                }
            }
            if (w && w->isVisible() && w->isEnabled()) {
                return w;
            }
        }
        return static_cast<QWidget*>(nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& stPrice : st.m_listPrices) {
        auto currency = file->baseCurrency().id();
        QString security;

        if (!stPrice.m_strCurrency.isEmpty()) {
            security = stPrice.m_strSecurity;
            currency = stPrice.m_strCurrency;
        } else if (secBySymbol.contains(stPrice.m_strSecurity)) {
            security = secBySymbol[stPrice.m_strSecurity].id();
            currency = file->security(file->security(security).tradingCurrency()).id();
        } else if (secByName.contains(stPrice.m_strSecurity)) {
            security = secByName[stPrice.m_strSecurity].id();
            currency = file->security(file->security(security).tradingCurrency()).id();
        } else
            return;

        MyMoneyPrice price(security,
                           currency,
                           stPrice.m_date,
                           stPrice.m_amount, stPrice.m_sourceName.isEmpty() ? i18n("Prices Importer") : stPrice.m_sourceName);
        file->addPrice(price);
    }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyReportPrivate::getAttrName(static_cast<Report::Attribute>(i)).isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
        m_separator = m_fieldDelimiterCharList[index];
    }
```

#### AUTO 


```{c}
auto i = (int)Element::KVP::Pair;
```

#### AUTO 


```{c}
auto factoryResult = KPluginFactory::loadFactory(*it);
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Account>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : t.splits()) {
    auto acc = account(split.accountId());
    auto fraction = acc.fraction();
    if(fraction == -1) {
      auto sec = security(acc.currencyId());
      fraction = acc.fraction(sec);
    }
    split.setShares(static_cast<const MyMoneyMoney>(split.shares().convertDenominator(fraction).canonicalize()));
    split.setValue(static_cast<const MyMoneyMoney>(split.value().convertDenominator(transactionFraction).canonicalize()));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : selection) {
                payeeIds.append(payee.id());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : d->m_transactionList)
    for (const auto& split : filter.matchingSplits(transaction))
      list.append(qMakePair(transaction, split));
```

#### AUTO 


```{c}
const auto idx = indexById(item.id());
```

#### AUTO 


```{c}
auto category = new KMyMoneyCategory(0, true);
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_dateCol)
```

#### AUTO 


```{c}
auto tag_id = dlg->show(remainingTags);
```

#### AUTO 


```{c}
const auto accountId = d->ui->m_parentAccounts->currentIndex().data(eMyMoney::Model::Roles::IdRole).toString();
```

#### AUTO 


```{c}
auto parentIdx = indexById(account.parentAccountId());
```

#### AUTO 


```{c}
auto transaction = QSharedPointer<MyMoneyTransaction>(new MyMoneyTransaction(item));
```

#### AUTO 


```{c}
auto memo = d->m_split.memo();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            auto value = task.value().toString();
            if (value.isEmpty()) {
                value = QStringLiteral("0");
            }
            query.bindValue(":id", id);
            query.bindValue(":originAccount", task.responsibleAccount());
            query.bindValue(":value", value);
            query.bindValue(":purpose", task.purpose());
            query.bindValue(":endToEndReference", (task.endToEndReference().isEmpty()) ? QVariant() : QVariant::fromValue(task.endToEndReference()));
            query.bindValue(":beneficiaryName", task.beneficiaryTyped().ownerName());
            query.bindValue(":beneficiaryIban", task.beneficiaryTyped().electronicIban());
            query.bindValue(":beneficiaryBic", (task.beneficiaryTyped().storedBic().isEmpty()) ? QVariant() : QVariant::fromValue(task.beneficiaryTyped().storedBic()));
            query.bindValue(":textKey", task.textKey());
            query.bindValue(":subTextKey", task.subTextKey());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& a : disabledActions)
    pActions[a]->setEnabled(false);
```

#### AUTO 


```{c}
const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
```

#### AUTO 


```{c}
auto d3 = static_cast<const AccountGroupPrivate *>(r.d_func());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : d->m_actions) {
    d->m_actionCollection->removeAction(action);
  }
```

#### AUTO 


```{c}
const auto itemList = model->match(model->index(0, 0), role, QVariant(id), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto shortNumber(shortNumberExp.match(d->m_name));
```

#### AUTO 


```{c}
auto rc = KMyMoneyUtils::tabFocusHelper(this, next);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->valueChanged(d->interestSplitModel, d->ui->interestAmountEdit, MyMoneyMoney::MINUS_ONE);
        d->updateWidgetState();
        updateTotalAmount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneyTransaction& transaction : list) {
        // if we have a categorization, make sure we remove
        // the 'imported' flag automagically
        if (transaction.splitCount() > 1)
          transaction.setImported(false);

        // create information about min and max balances
        foreach (const auto split, transaction.splits()) {
          auto acc = file->account(split.accountId());
          accountIds[acc.id()] = true;
          MyMoneyMoney balance = file->balance(acc.id());
          if (!acc.value("minBalanceEarly").isEmpty()) {
            minBalanceEarly[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceEarly"));
          }
          if (!acc.value("minBalanceAbsolute").isEmpty()) {
            minBalanceAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceAbsolute"));
            minBalanceEarly[acc.id()] = false;
          }
          if (!acc.value("maxCreditEarly").isEmpty()) {
            maxCreditEarly[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditEarly"));
          }
          if (!acc.value("maxCreditAbsolute").isEmpty()) {
            maxCreditAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditAbsolute"));
            maxCreditEarly[acc.id()] = false;
          }
        }

        if (transaction.id().isEmpty()) {
          bool enter = true;
          if (askForSchedule && transaction.postDate() > QDate::currentDate()) {
            KGuiItem enterButton(i18n("&Enter"),
                                 Icons::get(Icon::DialogOK),
                                 i18n("Accepts the entered data and stores it"),
                                 i18n("Use this to enter the transaction into the ledger."));
            KGuiItem scheduleButton(i18n("&Schedule"),
                                    Icons::get(Icon::AppointmentNew),
                                    i18n("Accepts the entered data and stores it as schedule"),
                                    i18n("Use this to schedule the transaction for later entry into the ledger."));

            enter = KMessageBox::questionYesNo(d->m_regForm, QString("<qt>%1</qt>").arg(i18n("The transaction you are about to enter has a post date in the future.<br/><br/>Do you want to enter it in the ledger or add it to the schedules?")), i18nc("Dialog caption for 'Enter or schedule' dialog", "Enter or schedule?"), enterButton, scheduleButton, "EnterOrScheduleTransactionInFuture") == KMessageBox::Yes;
          }
          if (enter) {
            // add new transaction
            file->addTransaction(transaction);
            // pass the newly assigned id on to the caller
            newId = transaction.id();
            // refresh account object for transactional changes
            // refresh account and transaction object because they might have changed
            d->m_account = file->account(d->m_account.id());
            t = transaction;

            // if a new transaction has a valid number, keep it with the account
            d->keepNewNumber(transaction);
          } else {
            // turn object creation on, so that moving the focus does
            // not screw up the dialog that might be popping up
            emit objectCreation(true);
            emit scheduleTransaction(transaction, eMyMoney::Schedule::Occurrence::Once);
            emit objectCreation(false);

            newTransactionCreated = false;
          }

          // send out the post date of this transaction
          emit lastPostDateUsed(transaction.postDate());
        } else {
          // modify existing transaction
          // its number might have been edited
          // bearing in mind it could contain alpha characters
          d->keepNewNumber(transaction);
          file->modifyTransaction(transaction);
        }
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->updateCaption(); }
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnAccount]);
```

#### AUTO 


```{c}
auto _t = dynamic_cast<KMyMoneyRegister::Transaction*>(list[0])
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySecurity::getAttrName(static_cast<MyMoneySecurity::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto idx = d->adjustToSecuritySplitIdx(MyMoneyFile::baseModel()->mapToBaseSource(index));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selected.indexes()) {
    d->m_selections.addSelection(SelectedObjects::Tag, idx.data(eMyMoney::Model::IdRole).toString());
  }
```

#### AUTO 


```{c}
const auto& schedule
```

#### AUTO 


```{c}
const auto row = item->row();
```

#### AUTO 


```{c}
const auto time = QDateTime::currentDateTime();
```

#### AUTO 


```{c}
auto r = readReport(m_baseNode);
```

#### AUTO 


```{c}
auto w = dynamic_cast<KMyMoneyTransactionForm::TabBar*>(editWidgets["tabbar"]);
```

#### AUTO 


```{c}
const auto list = m_storage->reportList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transactionId : transactions) {
              if (d->canBePrinted(accountId, transactionId)) {
                  d->printCheck(accountId, transactionId);
              }
          }
```

#### AUTO 


```{c}
const auto encryptionPage = new KSettingsGpg();
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& data: plugins) {
        QJsonArray editorsArray = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].toArray();
        for(QJsonValue entry: editorsArray) {
            if (!entry.toObject()["OnlineTaskIds"].isNull()) {
                list.append(onlineJobAdministration::onlineJobEditOffer{
                    data.fileName(),
                    entry.toObject()["PluginKeyword"].toString(),
                    KPluginMetaData::readTranslatedString(entry.toObject(), "Name")
                });
            }
        }
    }
```

#### AUTO 


```{c}
const auto account = file->account(d->m_idInvAcc);
```

#### AUTO 


```{c}
const auto columnTypeFromXML = d->stringToColumnType(e.attribute(d->getAttrName(Report::Attribute::ColumnType)));
```

#### AUTO 


```{c}
const auto oldTransaction = static_cast<TreeItem<JournalEntry>*>(startIdx.internalPointer())->constDataRef().transaction();
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->account(accountId);
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["deposit"]);
```

#### AUTO 


```{c}
auto acc = file->account(*it_nc);
```

#### AUTO 


```{c}
auto category = dynamic_cast<KMyMoneyCategory*>(d->m_editWidgets["category"]);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyInstitutionPrivate::getElName(static_cast<Institution::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
auto sec = dynamic_cast<KMyMoneySecurity*>(d->m_editWidgets["security"]);
```

#### AUTO 


```{c}
const auto cat = d->haveVisibleWidget<KMyMoneyAccountCombo>(categoryWidget);
```

#### AUTO 


```{c}
auto b = account.accountType() == eMyMoney::Account::Type::Investment ? true : false;
```

#### AUTO 


```{c}
const auto count = rowCount(favoriteIdx);
```

#### AUTO 


```{c}
const auto acc = file->accountsModel()->itemById(tidx.data(eMyMoney::Model::SplitAccountIdRole).toString());
```

#### AUTO 


```{c}
const auto commodity = file->security(m_transaction.commodity());
```

#### AUTO 


```{c}
auto newTagId = dlg->reassignTo();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto payee : list) {
        f.addPayee(payee.id());
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
    if (ui->m_amountTabWidget->widget(index) == ui->amountTab) { // amountTab
      clearComboBox(ui->m_debitCol);
      clearComboBox(ui->m_creditCol);
    } else {          // creditDebitTab
      clearComboBox(ui->m_amountCol);
    }
  }
```

#### AUTO 


```{c}
auto categoryMatched = !filter.categoryFilter;
```

#### AUTO 


```{c}
auto tag = new KTagContainer;
```

#### AUTO 


```{c}
auto aC = q->actionCollection();
```

#### AUTO 


```{c}
auto widget = m_comboBox->nextInFocusChain();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotPostponeReconciliation(); }
```

#### AUTO 


```{c}
auto transaction = item.sharedtransactionPtr();
```

#### AUTO 


```{c}
const auto accountId = idx.data(eMyMoney::Model::Roles::IdRole).toString();
```

#### AUTO 


```{c}
const auto acc = this->account(s.accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selected.indexes()) {
      if (idx.row() != lastRow) {
        lastRow = idx.row();
        selectedRows += lastRow;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
    viewFrames[view.id] = m_model->addPage(viewBases[view.id], view.name);
    viewFrames[view.id]->setIcon(Icons::get(view.icon));
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByObject, this, &KMyMoneyView::slotSelectByObject);
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByVariant, this, &KMyMoneyView::slotSelectByVariant);
    connect(viewBases[view.id], &KMyMoneyViewBase::customActionRequested, this, &KMyMoneyView::slotCustomActionRequested);
  }
```

#### AUTO 


```{c}
auto amountValue = d->m_split.value();
```

#### AUTO 


```{c}
auto id = splitList.first().accountId();
```

#### AUTO 


```{c}
const auto index = model()->index(currentIndex().row(), AccountsModel::Account, currentIndex().parent());
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Action action, const QString& id) {
    pActions[action]->setData(id);
    emit requestActionTrigger(action);
  }
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney", [&name](const KPluginMetaData& data) {
        QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
        if (array.isArray())
            return (array.toVariant().toStringList().contains(name));
        return false;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        emit done();
    }
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::instance()->payeesModel()->indexById(id);
```

#### AUTO 


```{c}
auto isTransfer = false;
```

#### AUTO 


```{c}
const auto paymentType =
        model->index(d->ui->paymentMethodCombo->currentIndex(), 0).data(eMyMoney::Model::SchedulePaymentTypeRole).value<eMyMoney::Schedule::PaymentType>();
```

#### AUTO 


```{c}
auto menu = pMenus[eMenu::Menu::MoveTransaction];
```

#### AUTO 


```{c}
const auto index = model->accountById(accountId);
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Institution>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto override = accountType.captured(1);
```

#### AUTO 


```{c}
auto itInstitution = d->itemFromAccountId(this, account.institutionId())
```

#### AUTO 


```{c}
const auto acc = d->m_file->account(idAcc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
        addView(d->viewBases[view.id], view.name, view.id, view.icon);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : journalEntryIds) {
        if (id.isEmpty())
            continue;
        int row = -1;
        const auto baseIdx = journalModel->indexById(id);
        row = journalModel->mapFromBaseSource(model(), baseIdx).row();

        // the baseIdx may point to a split in a different account which
        // we don't see here. In this case, we scan the journal entries
        // of the transaction
        if ((row == -1) && baseIdx.isValid()) {
            const auto indexes = journalModel->indexesByTransactionId(baseIdx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
            for (const auto idx : indexes) {
                if (idx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
                    row = journalModel->mapFromBaseSource(model(), idx).row();
                    if (row != -1) {
                        break;
                    }
                }
            }
        }

        if (row == -1) {
            qDebug() << "transaction" << id << "not found anymore for selection. skipped";
            continue;
        }

        if (startRow == -1) {
            startRow = row;
            lastRow = row;
            // use the first as the current index
            if (!currentIdx.isValid()) {
                currentIdx = model()->index(startRow, 0);
            }
        } else {
            if (row == lastRow+1) {
                lastRow = row;
            } else {
                // a new range start, so we take care of it
                createSelectionRange();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            // turn on signals before we modify the last entry in the list
            cnt--;
            MyMoneyFile::instance()->blockSignals(cnt != 0);

            // get a fresh copy
            auto journalEntry = file->journalModel()->itemById(journalEntryId);
            if (!journalEntry.id().isEmpty()) {
                auto t = journalEntry.transaction();
                auto sp = journalEntry.split();
                if (sp.reconcileFlag() != flag) {
                    if (flag == eMyMoney::Split::State::Unknown) {
                        if (!isReconciliationMode) {
                            // in normal mode we cycle through all states
                            switch (sp.reconcileFlag()) {
                                case eMyMoney::Split::State::NotReconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Cleared);
                                    break;
                                case eMyMoney::Split::State::Cleared:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Reconciled);
                                    break;
                                case eMyMoney::Split::State::Reconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                    break;
                                default:
                                    break;
                            }
                        } else {
                            // in reconciliation mode we skip the reconciled state
                            switch (sp.reconcileFlag()) {
                                case eMyMoney::Split::State::NotReconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Cleared);
                                    break;
                                case eMyMoney::Split::State::Cleared:
                                    sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                    break;
                                default:
                                    break;
                            }
                        }
                    } else {
                        sp.setReconcileFlag(flag);
                    }

                    t.modifySplit(sp);
                    MyMoneyFile::instance()->modifyTransaction(t);
                }
            }
        }
```

#### AUTO 


```{c}
const auto viewActions = d->m_myMoneyView->actionsToBeConnected();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
          // create copy of transaction in current schedule
          auto trans = schedule.transaction();
          // create copy of lists of splits
          for (auto& split : trans.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (auto i = 0; i < tagIdList.size(); ++i) {
              if (d->tagInList(selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList);
            trans.modifySplit(split); // does not modify the list object 'splits'!
          } // for - Splits
          // store transaction in current schedule
          schedule.setTransaction(trans);
          file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
        }
```

#### AUTO 


```{c}
const auto idx = MyMoneyFile::instance()->accountsModel()->indexById(split.accountId());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
      query.bindValue(":id", obj.idString());
      query.bindValue(":iban", payeeIdentifier->electronicIban());
      const auto bic = payeeIdentifier->fullStoredBic();
      query.bindValue(":bic", (bic.isEmpty()) ? QVariant(QVariant::String) : bic);
      query.bindValue(":name", payeeIdentifier->ownerName());
      if (!query.exec()) { // krazy:exclude=crashy
        qWarning("Error while saving ibanbic data for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
        return false;
      }
      return true;
    }
```

#### AUTO 


```{c}
const auto institutionsModel = Models::instance()->institutionsModel();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& text) {
        Q_D(LedgerFilter);
        d->filterString = text;
        d->delayTimer.start(200);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Action action, const QString& id) {
        pActions[action]->setData(id);
        emit requestActionTrigger(action);
    }
```

#### AUTO 


```{c}
const auto institution = MyMoneyFile::instance()->institution(id);
```

#### AUTO 


```{c}
const auto rows = index.data(eMyMoney::Model::TransactionSplitCountRole).toInt();
```

#### AUTO 


```{c}
auto cat = dynamic_cast<KMyMoneyCategory*>(haveWidget("asset-account"));
```

#### AUTO 


```{c}
auto acc = account(*it_a);
```

#### AUTO 


```{c}
auto acc = d->accountsModel.itemByIndex(idx);
```

#### AUTO 


```{c}
const auto costCenterId = index.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto toBeClosedAccID = makeAccount("EasyAccount", "123456789", eMyMoney::Account::Type::Investment, QDate(2017, 8, 1), file->asset().id());
```

#### AUTO 


```{c}
const auto data = source_parent.isValid() ? index.parent().data((int)eAccountsModel::Role::ID)
                                            : index.data((int)eAccountsModel::Role::ID);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& plugin: plugins) {
    QJsonValue array = plugin.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
    if (array.isArray())
      list.append(array.toVariant().toStringList());
  }
```

#### AUTO 


```{c}
const auto parentIdx = idx.parent();
```

#### AUTO 


```{c}
const auto viewModel = ui->m_register->model();
```

#### LAMBDA EXPRESSION 


```{c}
[=] { QMetaObject::invokeMethod(this, "updateWidgets", Qt::QueuedConnection); }
```

#### AUTO 


```{c}
const auto accountIdx = MyMoneyFile::baseModel()->mapToBaseSource(index);
```

#### AUTO 


```{c}
const auto paymentType =
        model->index(d->ui->m_paymentMethodEdit->currentIndex(), 0).data(eMyMoney::Model::SchedulePaymentTypeRole).value<eMyMoney::Schedule::PaymentType>();
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney", [&name](const KPluginMetaData& data) {
    QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
    if (array.isArray())
      return (array.toVariant().toStringList().contains(name));
    return false;
  });
```

#### AUTO 


```{c}
auto writeQuery = [&]() {
            query.bindValue(":id", obj.idString());
            query.bindValue(":iban", payeeIdentifier->electronicIban());
            const auto bic = payeeIdentifier->fullStoredBic();
            query.bindValue(":bic", (bic.isEmpty()) ? QVariant(QVariant::String) : bic);
            query.bindValue(":name", payeeIdentifier->ownerName());
            if (!query.exec()) { // krazy:exclude=crashy
                qWarning("Error while saving ibanbic data for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
                return false;
            }
            return true;
        };
```

#### AUTO 


```{c}
auto moduleName = nativeScriptFileInfo.baseName().toLocal8Bit();
```

#### AUTO 


```{c}
const auto sTransactionMarkMenu = QStringLiteral("transaction_mark_menu");
```

#### AUTO 


```{c}
const auto strBIC = QStringLiteral("bic");
```

#### AUTO 


```{c}
const auto oldTransaction = static_cast<TreeItem<JournalEntry>*>(srcIdx.internalPointer())->constDataRef().transaction();
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.stateFilter;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : tagIdList)
      if (file->tag(tag).name().contains(d->m_text))
        return !d->m_invertText;
```

#### AUTO 


```{c}
auto addCellToRow = [&, newColPos](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          childItem->insertColumns(newColPos, 1);
          if (childItem->hasChildren())
            self(self, childItem);
          this->d->setAccountData(item, j, childItem->data((int)Role::Account).value<MyMoneyAccount>(), QList<Column> {column});
        }
        return true;
      };
```

#### AUTO 


```{c}
auto colNum = m_columns.indexOf(Columns::Account);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            // search the empty split and start editing it
            const auto rows = q->model()->rowCount();
            for (int row = 0; row < rows; ++row) {
                const auto idx = q->model()->index(row, 0);
                const auto id = idx.data(eMyMoney::Model::IdRole).toString();
                if (id.isEmpty() || id.endsWith('-')) {
                    // force a call to currentChanged() to start editing
                    q->setCurrentIndex(QModelIndex());
                    q->setCurrentIndex(idx);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(source_row, (int)eAccountsModel::Column::Account, source_parent);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int logicalIndex, Qt::SortOrder order) {
            Q_D(KScheduledView);
            d->m_filterModel->sort(logicalIndex, order);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& column : qAsConst(columns)) {
                const auto rowCount = d->displayString(index.model()->index(index.row(), column), option).lines.count();
                if (rowCount > rows) {
                    rows = rowCount;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
        if (ui->m_amountTabWidget->widget(index) == ui->amountTab) { // amountTab
            clearComboBox(ui->m_debitCol);
            clearComboBox(ui->m_creditCol);
        } else {          // creditDebitTab
            clearComboBox(ui->m_amountCol);
        }
    }
```

#### AUTO 


```{c}
const auto libPath = qgetenv("LD_LIBRARY_PATH");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
    // the following line will throw an exception if the
    // account does not exist or is one of the standard accounts
    auto acc = MyMoneyFile::account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION("Cannot add split with no account assigned");
    if (acc.isLoan())
      loanAccountAffected = true;
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION("Cannot add split referencing standard account");
  }
```

#### AUTO 


```{c}
const auto onlineBalanceValue = index.data(eMyMoney::Model::AccountOnlineBalanceValueRole).value<MyMoneyMoney>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : journalEntryIds) {
                const auto idx = journalModel->indexById(journalEntryId);
                if (idx.data(eMyMoney::Model::SplitReconcileFlagRole).value<eMyMoney::Split::State>() == eMyMoney::Split::State::NotReconciled) {
                    clearedBalance -= idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                }
            }
```

#### AUTO 


```{c}
auto activity = d->m_activity;
```

#### AUTO 


```{c}
auto payeeId = field("payeeEdit").toString();
```

#### AUTO 


```{c}
const auto model = MyMoneyFile::instance()->tagsModel();
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Report>(i)).isEmpty();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                d->unregisterGlobalEditor();
            }
```

#### AUTO 


```{c}
auto type = d->m_payee.matchData(ignorecase, keys);
```

#### AUTO 


```{c}
auto accountId = index.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### AUTO 


```{c}
const auto index = model->index(row, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
      updateNextObjectId(item.id());
      static_cast<TreeItem<T>*>(index(row, 0).internalPointer())->dataRef() = item;
      ++row;
    }
```

#### AUTO 


```{c}
auto isEmpty = onlineJobPrivate::getElName(static_cast<OnlineJob::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto account = schedule.account();
```

#### AUTO 


```{c}
const auto count = m_file->budgetsModel()->processItems(&writer);
```

#### AUTO 


```{c}
const auto rows = sourceModel()->rowCount(source_parent);
```

#### AUTO 


```{c}
auto cat = d->haveWidget<KMyMoneyAccountCombo>("accountCombo");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    // the following is only relevant for transactions with two splits
                    // in different currencies
                    const auto value = -transactionValue;
                    idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(value), eMyMoney::Model::SplitValueRole);
                    if (!value.isZero()) {
                        d->price = shares / value;
                    }
                    // make sure to use a possible foreign currency value
                    // in case of income and expense categories.
                    // in this case, we also need to use the reciprocal of the price
                    if (d->isIncomeExpense(splitIdx)) {
                        amount = -shares;
                        if (!shares.isZero()) {
                            d->price = value / shares;
                        }
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&, row](auto column)
    {
      cell = node->child(row, column);
      if (!cell) {
        cell = new QStandardItem;
        node->setChild(row, column, cell);
      }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            d->editSplits(d->interestSplitModel, d->ui->interestAmountEdit, MyMoneyMoney::MINUS_ONE);
        }
```

#### AUTO 


```{c}
auto iconRect = QRect(cellRect.x() + cellRect.width() - iconWidth, cellRect.y(), iconWidth, iconWidth);
```

#### AUTO 


```{c}
auto isWindows = false;
```

#### AUTO 


```{c}
const auto idx = file->accountsModel()->mapFromBaseSource(d->ui->m_parentAccounts->model(), baseIdx);
```

#### AUTO 


```{c}
const auto curPrice = file->price(acc.tradingCurrencyId(), file->baseCurrency().id(), QDate::currentDate());
```

#### AUTO 


```{c}
const auto memo = index.data(eMyMoney::Model::MatchedSplitMemoRole).toString();
```

#### AUTO 


```{c}
auto writeQuery = [&]() {
      query.bindValue(":id", obj.idString());
      query.bindValue(":countryCode", payeeIdentifier->country());
      query.bindValue(":accountNumber", payeeIdentifier->accountNumber());
      query.bindValue(":bankCode", (payeeIdentifier->bankCode().isEmpty()) ? QVariant(QVariant::String) : payeeIdentifier->bankCode());
      query.bindValue(":name", payeeIdentifier->ownerName());
      if (!query.exec()) { // krazy:exclude=crashy
        qWarning("Error while saving national account number for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
        return false;
      }
      return true;

    };
```

#### AUTO 


```{c}
auto buttonInfo
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : d->m_transactionList) {
    const auto& splits = filter.matchingSplits(transaction);
    for (const auto& split : splits)
      list.append(qMakePair(transaction, split));
  }
```

#### AUTO 


```{c}
auto c = readCostCenter(m_baseNode);
```

#### LAMBDA EXPRESSION 


```{c}
[=](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          if (childItem->hasChildren())
            self(self, childItem);
          childItem->removeColumn(ixCol);
        }
        return true;
      }
```

#### AUTO 


```{c}
const auto sec = MyMoneyFile::instance()->security(acc.currencyId());
```

#### AUTO 


```{c}
const auto total = sumSplits(s0, feeSplits, interestSplits);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entry : entries) {
            const auto parts = entry.split(':');
            if (parts.count() == 2) {
                const auto date = QDate::fromString(parts[0], Qt::ISODate);
                MyMoneyMoney amount(parts[1]);
                if (parts.count() == 2 && date.isValid()) {
                    d->m_reconciliationHistory[date] = amount;
                }
            } else {
                qDebug() << "Invalid reconciliationHistory" << entry;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotEnterTransaction(); }
```

#### AUTO 


```{c}
const auto showClosedAccounts = !KMyMoneySettings::hideClosedAccounts() || KMyMoneySettings::showAllAccounts();
```

#### AUTO 


```{c}
auto it = viewActions.cbegin();
```

#### AUTO 


```{c}
const auto memo(exceptionExp.match(kt.m_strMemo));
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
      Q_D(KTagsView);
      emit requestCustomContextMenu(eMenu::Menu::Tag, d->ui->m_tagsList->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto favItem = itemFromAccountId(toNode, acc.id())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : t.splits()) {
                        split.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                        split.setReconcileDate(QDate());
                        split.setBankID(QString());
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : accounts) {
        if (account(acc).name().compare(name) == 0)
            return true;
    }
```

#### AUTO 


```{c}
const auto msg = i18n("<qt>Do you want to add <b>%1</b> as payer/receiver?</qt>", newnameBase);
```

#### AUTO 


```{c}
const auto& investmentsView = static_cast<KInvestmentView*>(viewBases[View::Investments]);
```

#### AUTO 


```{c}
const auto tag = baseModel->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
auto rootItem = invisibleRootItem();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (d->currentActivity) {
            d->stockSplit.setShares(d->ui->sharesAmountEdit->value() * d->currentActivity->sharesFactor());
            d->stockSplit.setValue(d->currentActivity->valueAllShares().convert(d->transactionCurrency.smallestAccountFraction(), d->security.roundingMethod())
                                   * d->currentActivity->sharesFactor());
            if (d->currentActivity->type() != eMyMoney::Split::InvestmentTransactionType::SplitShares) {
                d->scheduleUpdateTotalAmount();
            }
            d->updateWidgetState();
        }
    }
```

#### AUTO 


```{c}
const auto split = transaction.splitByAccount(accountId);
```

#### AUTO 


```{c}
auto type = d->ui->typeCombo->itemData(index).value<Account>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids)
    addAccount(id);
```

#### AUTO 


```{c}
const auto category = file->accountsModel()->itemById(categoryId);
```

#### AUTO 


```{c}
auto msg = i18np("Do you really want to change the selected transaction?",
                         "Do you really want to change all %1 selected transactions?",
                         d->m_selections.selection(SelectedObjects::JournalEntry).count());
```

#### AUTO 


```{c}
auto idx = profileList.indexOf(text);
```

#### AUTO 


```{c}
auto pValue = execute("get_backends", QVariantList());
```

#### AUTO 


```{c}
auto i = (int)Element::Report::Payee;
```

#### AUTO 


```{c}
const auto w = m_calculatorFrame->width();
```

#### AUTO 


```{c}
const auto model = ui->m_register->model();
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Budget));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    Q_D(KInstitutionsView);
    // only react if this is the current view
    if (isVisible()) {
      d->ui->m_filterContainer->show();
      d->ui->m_searchWidget->setFocus();
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids)
        addCategory(id);
```

#### AUTO 


```{c}
auto priceEdit = d->haveWidget<AmountEdit>("priceAmountEdit");
```

#### AUTO 


```{c}
auto i = (int)Transaction::Element::Split;
```

#### AUTO 


```{c}
auto date = QDate::currentDate();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        const auto menuType = d->updateDynamicActions();
        emit requestCustomContextMenu(menuType, viewport()->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
const auto rows = q->model()->rowCount();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int logicalIndex, Qt::SortOrder order) {
      Q_D(KScheduledView);
      d->m_filterModel->sort(logicalIndex, order);
    }
```

#### AUTO 


```{c}
const auto actionId = d->qActionToId(action);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& xmlContent, int kvpPairs) {
        doc.setContent(xmlContent);
        node = doc.documentElement().firstChild().toElement();

        a.addAccountId("TEST");
        a.setValue("KEY", "VALUE");

        a = MyMoneyXmlContentHandler::readAccount(node);
        QCOMPARE(a.id(), QStringLiteral("A000001"));
        QCOMPARE(a.name(), QStringLiteral("AccountName"));
        QCOMPARE(a.parentAccountId(), QStringLiteral("Parent"));
        QCOMPARE(a.lastModified(), QDate::currentDate());
        QCOMPARE(a.lastReconciliationDate(), QDate());
        QCOMPARE(a.institutionId(), QStringLiteral("B000001"));
        QCOMPARE(a.number(), QStringLiteral("465500"));
        QCOMPARE(a.openingDate(), QDate::currentDate());
        QCOMPARE(a.accountType(), eMyMoney::Account::Type::Asset);
        QCOMPARE(a.description(), QStringLiteral("Desc"));
        QCOMPARE(a.accountList().count(), 2);
        QCOMPARE(a.accountList()[0], QStringLiteral("A000002"));
        QCOMPARE(a.accountList()[1], QStringLiteral("A000003"));
        QCOMPARE(a.pairs().count(), kvpPairs);
        QCOMPARE(a.value("key"), QStringLiteral("value"));
        QCOMPARE(a.value("Key"), QStringLiteral("Value"));
        QCOMPARE(a.pairs().contains("lastStatementDate"), false);
        QCOMPARE(a.reconciliationHistory().count(), 2);
        QCOMPARE(a.reconciliationHistory()[QDate(2011, 1, 1)].toString(), MyMoneyMoney(123, 100).toString());
        QCOMPARE(a.reconciliationHistory()[QDate(2011, 2, 1)].toString(), MyMoneyMoney(456, 100).toString());
    }
```

#### AUTO 


```{c}
auto objId = currentIndex().data(eMyMoney::Model::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : qAsConst(list)) {
        itemCount += item->splitCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : transactionIds) {
        if (id.isEmpty())
            continue;
        const auto indexes = journalModel->indexesByTransactionId(id);
        int row = -1;
        for (const auto baseIdx : indexes) {
            if (baseIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
                row = journalModel->mapFromBaseSource(model(), baseIdx).row();
                if (row != -1) {
                    break;
                }
            }
        }
        if (row == -1) {
            qDebug() << "transaction" << id << "not found anymore for selection. skipped";
            continue;
        }

        if (startRow == -1) {
            startRow = row;
            lastRow = row;
            // use the first as the current index
            if (!currentIdx.isValid()) {
                currentIdx = model()->index(startRow, 0);
            }
        } else {
            if (row == lastRow+1) {
                lastRow = row;
            } else {
                // a new range start, so we take care of it
                createSelectionRange();
            }
        }
    }
```

#### AUTO 


```{c}
const auto selection = ui->m_groupList->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
const auto attributes = nodeList.item(0).toElement().attributes();
```

#### AUTO 


```{c}
const auto idx = model()->index(row, col);
```

#### AUTO 


```{c}
auto*profile = dynamic_cast<PricesProfile *>(m_profile);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint&) {
      Q_D(KBudgetView);
      if (d->m_contextMenu) {
        d->m_contextMenu->exec(QCursor::pos());
      } else {
        qDebug() << "No context menu assigned in KBudgetView";
      }
    }
```

#### AUTO 


```{c}
const auto journalEntryId = idx.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto customIconRelativePath = QString(QStringLiteral("icons/hicolor/16x16/actions/account-add.png"));
```

#### AUTO 


```{c}
auto roundSplitValues = [&](MyMoneySplit& split, int sharesFraction) {
        split.setShares(MyMoneyMoney(split.shares().convertDenominator(sharesFraction, roundingMethod)));
        split.setValue(MyMoneyMoney(split.value().convertDenominator(currencyFraction, roundingMethod)));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : journalEntry.transaction().splits()) {
                const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(sp.accountId());
                if (acc.accountType() == eMyMoney::Account::Type::Investment) {
                    return acc.id();
                }
                if (acc.isInvest()) {
                    accountId = acc.parentAccountId();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_amountCol)
```

#### AUTO 


```{c}
const auto& accStr
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<KMyMoneyEdit*>(haveWidget("deposit"));
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(q->haveWidget(amountWidgetName));
```

#### AUTO 


```{c}
auto path_list = ld_library_path.split(QLatin1Char(':'));
```

#### AUTO 


```{c}
const auto count = m_models->payeesModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto tabOrder = editor->property("kmm_defaulttaborder").toStringList();
```

#### AUTO 


```{c}
auto list = d->ui->m_ledgerView->selectedJournalEntries();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& w : m_widgetList) {
            widgetNames += w->objectName();
        }
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Transaction>(i)).isEmpty();
```

#### AUTO 


```{c}
auto iid = QLatin1String("org.kmymoney.payeeIdentifier.ibanbic.sqlStoragePlugin");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id: qAsConst(openLedgers)) {
        auto thisId = id;
        openLedger(thisId.remove(QLatin1String("*")), id.endsWith(QLatin1String("*")));
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : accounts)
            d->ui->accountsList->addTopLevelItem(new QTreeWidgetItem(QStringList{account.id,
                                                 account.name,
                                                 account.balance.formatMoney(QString(), 2)}));
```

#### AUTO 


```{c}
auto pReader = new MyMoneyGncReader;
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->account(id);
```

#### AUTO 


```{c}
const auto sec = MyMoneyFile::instance()->baseCurrency();
```

#### AUTO 


```{c}
auto sharesWidget = dynamic_cast<AmountEdit*>(haveWidget("shares"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
                            if (payeeInList(list, split.payeeId())) {
                                split.setPayeeId(payee_id);
                                trans.modifySplit(split); // does not modify the list object 'splits'!
                            }
                        }
```

#### AUTO 


```{c}
const auto matchedDisplayProperties = d->displayMatchedString(index, opt);
```

#### AUTO 


```{c}
const auto idx = file->journalModel()->indexById(selections.firstSelection(SelectedObjects::JournalEntry));
```

#### AUTO 


```{c}
auto paymentWidget = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["payment"])
```

#### AUTO 


```{c}
const auto& journalId
```

#### AUTO 


```{c}
auto t = dynamic_cast<KMyMoneyRegister::Transaction*>(p);
```

#### AUTO 


```{c}
const auto checkMark = QIcon::fromTheme(g_Icons[Icon::DialogOK]);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& sm : tm.splits()) {
                  if (payeeInList(list , sm.payeeId())) {
                    sm.setPayeeId(payee_id); // first modify payee in current split
                    // then modify the split in our local copy of the transaction list
                    tm.modifySplit(sm); // this does not modify the list object 'splits'!
                  }
                }
```

#### AUTO 


```{c}
auto balance = file->balance(accountId, endingBalanceDlg->statementDate());
```

#### AUTO 


```{c}
const auto newSplitCount = static_cast<int>(newTransaction.splitCount());
```

#### AUTO 


```{c}
const auto journalEntry = static_cast<TreeItem<JournalEntry>*>(idx.internalPointer())->constDataRef();
```

#### AUTO 


```{c}
auto fromCurrency = file->security(t.commodity());
```

#### AUTO 


```{c}
const auto expenseIdx = AccountsModel::mapFromBaseSource(this, file->accountsModel()->expenseIndex());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& plugin : plugins.standard) {
          plugin->updateConfiguration();
      }
```

#### AUTO 


```{c}
const auto model = &d->journalModel;
```

#### AUTO 


```{c}
const auto currencyId = (*it)->data(0, Qt::UserRole).value<MyMoneySecurity>().id();
```

#### AUTO 


```{c}
auto name = acc.name();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& it_split : d->m_splits) {
        if (split.id() == it_split.id()) {
            it_split = split;
            return;
        }
    }
```

#### AUTO 


```{c}
auto fromValue = s.value().abs();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
            Q_D(KTagsView);
            emit requestCustomContextMenu(eMenu::Menu::Tag, d->ui->m_tagsList->mapToGlobal(pos));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { Q_D(KCurrencyEditorDlg); d->validateValues(); }
```

#### AUTO 


```{c}
auto t = file->transaction(journalIdx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
```

#### AUTO 


```{c}
auto iter = map.constBegin();
```

#### AUTO 


```{c}
auto feesEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("fee-amount"));
```

#### AUTO 


```{c}
const auto kvp_end = kvpResult.constEnd();
```

#### AUTO 


```{c}
auto priceEdit = d->haveWidget<AmountEdit*>("price");
```

#### AUTO 


```{c}
const auto view
```

#### AUTO 


```{c}
const auto newIdx = index(startRow, 0);
```

#### AUTO 


```{c}
auto w = (*it_plugin)->accountConfigTab(m_currentAccount, name);
```

#### AUTO 


```{c}
auto toBeClosedAccID = makeAccount("EasyAccount", "123456789", eMyMoney::Account::Investment, QDate(2017, 8, 1), file->asset().id());
```

#### AUTO 


```{c}
const auto indexes = journalModel->indexesByTransactionId(baseIdx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
```

#### AUTO 


```{c}
const auto& it
```

#### AUTO 


```{c}
const auto data = sourceModel()->data(source, (int)Role::Account);
```

#### AUTO 


```{c}
const auto bottomRight = PayeesModel::index(index.row(), columnCount()-1);
```

#### AUTO 


```{c}
auto ti = d->m_endingBalanceDlg->interestTransaction();
```

#### AUTO 


```{c}
const auto expMatch = regExp.match(journalId);
```

#### AUTO 


```{c}
auto txt = d->m_result;
```

#### AUTO 


```{c}
const auto payeeId = field("payeeEdit").toString();
```

#### AUTO 


```{c}
auto itInvestmentAccount = account.isInvest() ? itemFromAccountId(itInstitution, account.parentAccountId()) : nullptr;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt) {
        if (txt.isEmpty()) {
            d->ui->payeeEdit->setCurrentIndex(-1);
        }
    }
```

#### AUTO 


```{c}
const auto clientUid = m_editClientUid->text();
```

#### AUTO 


```{c}
auto getCell = [&, row](const auto column) {
      cell = node->child(row, column);      // try to get QStandardItem
      if (!cell) {                          // it may be uninitialized
        cell = new QStandardItem;           // so create one
        node->setChild(row, column, cell);  // and add it under the node
        cell->setEditable(false);           // and don't forget that it's non-editable
      }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& sec: securities) {
    if (!sec.tradingMarket().isEmpty()) {
      if (ui->m_tradingMarket->findText(sec.tradingMarket(), Qt::MatchExactly) == -1) {
        ui->m_tradingMarket->addItem(sec.tradingMarket());
      }
    }
  }
```

#### AUTO 


```{c}
auto it_terms = q->forecastCycles() - actualTerms;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(KEditScheduleDlg);
        const auto model = d->ui->m_frequencyEdit->model();
        const auto paymentType = model->index(idx, 0).data(eMyMoney::Model::ScheduleFrequencyRole).value<eMyMoney::Schedule::Occurrence>();

        d->ui->m_endSeriesEdit->setEnabled(paymentType != Schedule::Occurrence::Once);
        bool isEndSeries = d->ui->m_endSeriesEdit->isChecked();
        if (isEndSeries)
            d->ui->m_endOptionsFrame->setEnabled(paymentType != Schedule::Occurrence::Once);
        switch (paymentType) {
        case Schedule::Occurrence::Daily:
        case Schedule::Occurrence::Weekly:
            d->ui->m_frequencyNoEdit->setEnabled(true);
            d->ui->m_lastDayInMonthEdit->setEnabled(false);
            break;

        case Schedule::Occurrence::EveryHalfMonth:
        case Schedule::Occurrence::Monthly:
        case Schedule::Occurrence::Yearly:
            // Supports Frequency Number
            d->ui->m_frequencyNoEdit->setEnabled(true);
            d->ui->m_lastDayInMonthEdit->setEnabled(true);
            break;

        default:
            // Multiplier is always 1
            d->ui->m_frequencyNoEdit->setEnabled(false);
            d->ui->m_frequencyNoEdit->setValue(1);
            d->ui->m_lastDayInMonthEdit->setEnabled(true);
            break;
        }
        if (isEndSeries && (paymentType != Schedule::Occurrence::Once)) {
            // Changing the frequency changes the number
            // of remaining transactions
            d->m_schedule.setNextDueDate(d->m_editor->postDate());
            d->m_schedule.setOccurrenceMultiplier(d->ui->m_frequencyNoEdit->value());
            d->m_schedule.setOccurrencePeriod(paymentType);
            d->m_schedule.setEndDate(d->ui->m_FinalPaymentEdit->date());
            d->updateTransactionsRemaining();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
            Q_D(KTagsView);
            d->m_renameProxyModel->setReferenceFilter(d->ui->m_filterBox->itemData(idx));
        }
```

#### AUTO 


```{c}
auto type = static_cast<eMyMoney::Payee::MatchType>(node.attribute(attributeName(Attribute::Payee::MatchingEnabled), "0").toUInt());
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnPayee]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& priceInfo : *itPairs) {
            if (lastDate > priceInfo.date()) {
                qDebug() << "Price loader: dates not sorted as needed" << priceInfo.date() << "older than" << lastDate;
            }
            PriceEntry newEntry(priceInfo);
            static_cast<TreeItem<PriceEntry>*>(index(row, 0).internalPointer())->dataRef() = newEntry;
            lastDate = priceInfo.date();
            ++row;
        }
```

#### AUTO 


```{c}
const auto account
```

#### AUTO 


```{c}
const auto idx = index.model()->index(index.row(), 0, index.parent());
```

#### AUTO 


```{c}
const auto text = i18n(MyMoneySchedule::paymentMethodToString(paymentMethod));
```

#### AUTO 


```{c}
const auto& id
```

#### AUTO 


```{c}
auto newParent = d->accountsModel.itemById(acc.parentAccountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &column : visibleColumns) {
                    if (applyStorageOffsetColumns.contains(column + storageOffset)) {
                        column += storageOffset;
                    }
                }
```

#### AUTO 


```{c}
auto acc = file->accountsModel()->itemByIndex(m_filterProxyModel->mapToSource(*it));
```

#### AUTO 


```{c}
const auto index(cb->findText(cb->currentText(), Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
auto w = d->haveWidget<QWidget>(*it_w);
```

#### AUTO 


```{c}
auto kyIcon = QString::fromLatin1("view_institution%1").arg(QString::number(size));
```

#### AUTO 


```{c}
const auto shares = d->haveVisibleWidget<AmountEdit>("sharesAmountEdit");
```

#### AUTO 


```{c}
const auto& change
```

#### AUTO 


```{c}
const auto tag = model->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
const auto& subaccStr
```

#### AUTO 


```{c}
auto pValue = execute("get_accounts", QVariantList{backend});
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(d->m_editWidgets["amount"]);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        auto list = d->ui->m_ledgerView->selectedJournalEntries();
        if (list.isEmpty()) {
            d->ui->m_ledgerView->selectMostRecentTransaction();
        } else {
            d->ui->m_ledgerView->ensureCurrentItemIsVisible();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& statement : statements) {
    if (abort)
      break;
    const auto importSummary = importStatement(statement);
    if (importSummary.isEmpty())
      ok = false;

    d->m_importSummary.append(importSummary);
  }
```

#### AUTO 


```{c}
auto itAccount = itemFromAccountId(itInstitution, account.id());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint& pos) {
            Q_D(KScheduledView);
            emit requestCustomContextMenu(eMenu::Menu::Schedule, d->ui->m_scheduleTree->viewport()->mapToGlobal(pos));
        }
```

#### AUTO 


```{c}
auto pyKey = PyString_FromString(szKey);
```

#### AUTO 


```{c}
auto storage = new MyMoneyStorageMgr;
```

#### AUTO 


```{c}
auto w = dlg_d->m_widgetList.at(idx);
```

#### AUTO 


```{c}
const auto tag
```

#### AUTO 


```{c}
auto w = dlg_d->m_widgetList[idx];
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(source_row, static_cast<int>(Column::Account), source_parent);
```

#### AUTO 


```{c}
const auto fiscalYearDiffersFromCalendarYear = (((m_beginDate.day() != 1) || (m_beginDate.month() != 0)) && startDateIsFiscalYearStart());
```

#### AUTO 


```{c}
auto groupIdx = d->indexByType(item.type());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
                const auto acc = file->account(split.accountId());
                if (acc.isIncomeExpense()) {
                    if (split.shares().isNegative() ^ fees) {
                        value += split.value();
                    }
                }
            }
```

#### AUTO 


```{c}
const auto *model = index.model();
```

#### AUTO 


```{c}
auto profile = dynamic_cast<PricesProfile *>(m_profile)
```

#### AUTO 


```{c}
const auto havePayeeColumn = !m_view->isColumnHidden(JournalModel::Payee);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex &parent, int first, int last) {
        Q_UNUSED(parent)
        Q_UNUSED(first)
        Q_UNUSED(last)

        Q_D(LedgerAccountFilter);
        // mark this view for sorting but don't actually start sorting
        // until we come back to the main event loop. This allows to collect
        // multiple row insertions into the model into a single sort run.
        // This is important during import of multiple transactions.
        if (!d->sortPending) {
            d->sortPending = true;
            // in case a recalc operation is pending, we turn it off
            // since we need to sort first. Once sorting is done,
            // the recalc will be triggered again
            d->balanceCalculationPending = false;
            QMetaObject::invokeMethod(this, &LedgerAccountFilter::sortView, Qt::QueuedConnection);
        }
    }
```

#### AUTO 


```{c}
auto t = (*it).transaction();
```

#### AUTO 


```{c}
auto rc = dlg->exec();
```

#### AUTO 


```{c}
auto acc = *theParent;
```

#### AUTO 


```{c}
const auto openCount = input.count(openParen);
```

#### AUTO 


```{c}
auto categoryId = dlg->show(d->m_currentCategory);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid())
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyModelBase::mapFromBaseSource(d->payeesModel, payeeIdx).row());
                else
                    d->ui->payeeEdit->setCurrentIndex(0);

                bool blocked = d->ui->accountCombo->blockSignals(true);
                switch (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole).toInt()) {
                case 1:
                    d->ui->accountCombo->clearEditText();
                    d->ui->accountCombo->setSelected(QString());
                    break;
                case 2:
                    d->ui->accountCombo->setSelected(splitIdx.data(eMyMoney::Model::TransactionCounterAccountIdRole).toString());
                    break;
                default:
                    d->ui->accountCombo->setEditText(splitIdx.data(eMyMoney::Model::TransactionCounterAccountRole).toString());
                    break;
                }
                d->ui->accountCombo->blockSignals(blocked);

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->amountEditCredit->setText(splitIdx.data(eMyMoney::Model::JournalSplitPaymentRole).toString());
                d->ui->amountEditDebit->setText(splitIdx.data(eMyMoney::Model::JournalSplitDepositRole).toString());

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());

                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    const auto value = splitIdx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
                    if (!shares.isZero()) {
                        d->price = value / shares;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto tread = MyMoneyXmlContentHandler::readTransaction(transaction);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (d->ui->enterButton->isEnabled()) {
            // move focus to enter button which
            // triggers update of widgets
            d->ui->enterButton->setFocus();
            d->ui->enterButton->click();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(KEditScheduleDlg);
        const auto model = d->ui->paymentMethodCombo->model();
        const auto paymentType = model->index(idx, 0).data(eMyMoney::Model::SchedulePaymentTypeRole).value<eMyMoney::Schedule::PaymentType>();
        const bool isWriteCheck = paymentType == Schedule::PaymentType::WriteChecque;
        d->transactionEditor->setShowNumberWidget(isWriteCheck);
    }
```

#### AUTO 


```{c}
auto payee = new KMyMoneyPayeeCombo;
```

#### AUTO 


```{c}
auto t = dynamic_cast<KMyMoneyRegister::Transaction*>(item);
```

#### AUTO 


```{c}
const auto& kvp = m_currentAccount.onlineBankingSettings();
```

#### AUTO 


```{c}
const auto transactionFactor(amountHelper->value().isNegative() ? MyMoneyMoney::ONE : MyMoneyMoney::MINUS_ONE);
```

#### AUTO 


```{c}
const auto acCadChecking = makeAccount(QString("Canadian Checking"), eMyMoney::Account::Checkings, moZero, QDate(2017, 8, 1), acAsset, "CAD");
```

#### AUTO 


```{c}
const auto next = parent->findChild<QWidget*>(tabOrder.at(i));
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotCreateScheduledTransaction(); }
```

#### AUTO 


```{c}
const auto hierarchyParts(hierarchyExp.match(it_h.key()));
```

#### AUTO 


```{c}
const auto payee = file->payee(sp->payeeId());
```

#### AUTO 


```{c}
const auto item
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : qAsConst(accounts)) {
        if (account.hasOnlineMapping()) {
            for (const onlineTask* task : qAsConst(m_onlineTasks)) {
                // Check if a online task has the correct type
                if (dynamic_cast<const creditTransfer*>(task) != 0) {
                    for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
                        if (plugin->availableJobs(account.id()).contains(task->taskName()))
                            return true;
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (auto i = 0; i < tagIdList.size(); ++i) {
              if (d->tagInList(selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList);
            trans.modifySplit(split); // does not modify the list object 'splits'!
          }
```

#### AUTO 


```{c}
const auto splits = t.splits();
```

#### AUTO 


```{c}
auto url = dialog->selectedURL();
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneyTransaction& transaction : list) {
                // if we have a categorization, make sure we remove
                // the 'imported' flag automagically
                if (transaction.splitCount() > 1)
                    transaction.setImported(false);

                // create information about min and max balances
                foreach (const auto split, transaction.splits()) {
                    auto acc = file->account(split.accountId());
                    accountIds[acc.id()] = true;
                    MyMoneyMoney balance = file->balance(acc.id());
                    if (!acc.value("minBalanceEarly").isEmpty()) {
                        minBalanceEarly[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceEarly"));
                    }
                    if (!acc.value("minBalanceAbsolute").isEmpty()) {
                        minBalanceAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("minBalanceAbsolute"));
                        minBalanceEarly[acc.id()] = false;
                    }
                    if (!acc.value("maxCreditEarly").isEmpty()) {
                        maxCreditEarly[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditEarly"));
                    }
                    if (!acc.value("maxCreditAbsolute").isEmpty()) {
                        maxCreditAbsolute[acc.id()] = balance < MyMoneyMoney(acc.value("maxCreditAbsolute"));
                        maxCreditEarly[acc.id()] = false;
                    }

                    // and adjust opening date of invest accounts
                    if (acc.isInvest()) {
                        if (acc.openingDate() > t.postDate()) {
                            try {
                                acc.setOpeningDate(t.postDate());
                                file->modifyAccount(acc);
                            } catch(MyMoneyException& ) {
                                qDebug() << "Unable to modify opening date for invest account" << acc.name() << acc.id();
                            }
                        }
                    }
                }

                if (transaction.id().isEmpty()) {
                    bool enter = true;
                    if (askForSchedule && transaction.postDate() > QDate::currentDate()) {
                        KGuiItem enterButton(i18n("&Enter"),
                                             Icons::get(Icon::DialogOK),
                                             i18n("Accepts the entered data and stores it"),
                                             i18n("Use this to enter the transaction into the ledger."));
                        KGuiItem scheduleButton(i18n("&Schedule"),
                                                Icons::get(Icon::NewSchedule),
                                                i18n("Accepts the entered data and stores it as schedule"),
                                                i18n("Use this to schedule the transaction for later entry into the ledger."));

                        enter = KMessageBox::questionYesNo(d->m_regForm, QString("<qt>%1</qt>").arg(i18n("The transaction you are about to enter has a post date in the future.<br/><br/>Do you want to enter it in the ledger or add it to the schedules?")), i18nc("Dialog caption for 'Enter or schedule' dialog", "Enter or schedule?"), enterButton, scheduleButton, "EnterOrScheduleTransactionInFuture") == KMessageBox::Yes;
                    }
                    if (enter) {
                        // add new transaction
                        file->addTransaction(transaction);
                        // pass the newly assigned id on to the caller
                        newId = transaction.id();
                        // refresh account object for transactional changes
                        // refresh account and transaction object because they might have changed
                        d->m_account = file->account(d->m_account.id());
                        t = transaction;

                        // if a new transaction has a valid number, keep it with the account
                        d->keepNewNumber(transaction);
                    } else {
                        // turn object creation on, so that moving the focus does
                        // not screw up the dialog that might be popping up
                        emit objectCreation(true);
                        emit scheduleTransaction(transaction, eMyMoney::Schedule::Occurrence::Once);
                        emit objectCreation(false);

                        newTransactionCreated = false;
                    }

                    // send out the post date of this transaction
                    emit lastPostDateUsed(transaction.postDate());
                } else {
                    // modify existing transaction
                    // its number might have been edited
                    // bearing in mind it could contain alpha characters
                    d->keepNewNumber(transaction);
                    file->modifyTransaction(transaction);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) { validateSelectedColumn(col, Column::Number); }
```

#### AUTO 


```{c}
const auto tabOrder = topLevelWidget->property("kmm_currenttaborder").toStringList();
```

#### AUTO 


```{c}
const auto curPrice = file->price(repSplitAcc.tradingCurrencyId(), file->baseCurrency().id(), QDate::currentDate());
```

#### AUTO 


```{c}
auto it_kvp = kvpResult.constBegin();
```

#### AUTO 


```{c}
auto i = (int)Element::Budget::Budget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : list) {
                f.addPayee(payee.id());
            }
```

#### AUTO 


```{c}
const auto* splitHelper = new KMyMoneyAccountComboSplitHelper(d->ui->accountCombo, &d->splitModel);
```

#### AUTO 


```{c}
auto h = m_calculatorFrame->height();
```

#### AUTO 


```{c}
static const auto passphrase(QStringLiteral("blue valentines"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto view : d->viewBases) {
        if (view != currentView) {
            view->executeAction(action, selections);
        }
    }
```

#### AUTO 


```{c}
auto levelToClose = groups.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& column : m_columns)
      headerLabels.append(q->getHeaderName(column));
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(cmd, this);
```

#### AUTO 


```{c}
const auto key(keyExp.match(d->ui->m_masterKeyCombo->currentText()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const pageInfo& info : pageInfos) {
    auto a = new QAction(this);
    // KActionCollection::addAction by name sets object name anyways,
    // so, as better alternative, set it here right from the start
    a->setObjectName(QString::fromLatin1("ShowPage%1").arg(QString::number(pageCount++)));
    a->setText(info.text);
    connect(a, &QAction::triggered, this, info.callback);
    lutActions.insert(info.view, a);  // store QAction's pointer for later processing
    if (!info.shortcut.isEmpty())
      a->setShortcut(info.shortcut);
  }
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("checkprinting");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& fileType : fileTypes) {
    switch (fileType) {
      case eKMyMoney::StorageType::XML:
        ui->fileType->addItem(i18n("XML"), static_cast<int>(fileType));
        break;
      case eKMyMoney::StorageType::SQL:
        ui->fileType->addItem(i18n("SQL"), static_cast<int>(fileType));

        break;
      default:
        break;
    }
  }
```

#### AUTO 


```{c}
const auto itAcc = d->itemFromId(this, account.id(), Role::EquityID);
```

#### AUTO 


```{c}
const auto rows = right.rowCount();
```

#### AUTO 


```{c}
auto item = dynamic_cast<KPayeeListItem*>(d->ui->m_payeesList->currentItem())
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex &parent, int first, int last) {
    Q_UNUSED(parent)
    Q_UNUSED(first)
    Q_UNUSED(last)

    Q_D(LedgerAccountFilter);
    // mark this view for sorting but don't actually start sorting
    // until we come back to the main event loop. This allows to collect
    // multiple row insertions into the model into a single sort run.
    // This is important during import of multiple transactions.
    if (!d->sortPending) {
      d->sortPending = true;
      QMetaObject::invokeMethod(this, &LedgerAccountFilter::sortView, Qt::QueuedConnection);
    }
  }
```

#### AUTO 


```{c}
const auto decimalPoint = m_locale.decimalPoint();
```

#### AUTO 


```{c}
const auto to = m_file->security(entry.to());
```

#### AUTO 


```{c}
auto type = p.matchData(ignoreCase, matchKeys);
```

#### AUTO 


```{c}
auto tc = d->m_endingBalanceDlg->chargeTransaction();
```

#### AUTO 


```{c}
const auto reconciledAccountId = selections.firstSelection(SelectedObjects::ReconciliationAccount);
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Payee>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& backend : backends)
        d->ui->backendsList->addTopLevelItem(new QTreeWidgetItem(QStringList{backend.name, backend.module}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
    auto acc = account(split.accountId());
    if (acc.isClosed())
      throw MYMONEYEXCEPTION(i18n("Cannot remove transaction that references a closed account."));
    d->addCacheNotification(split.accountId(), tr.postDate());
    //FIXME-ALEX Do I need to add d->addCacheNotification(split.tagList()); ??
  }
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::KVP>(i)).isEmpty();
```

#### CONST EXPRESSION 


```{c}
constexpr int horizMargin = 1;
```

#### AUTO 


```{c}
auto triggerAction = [&](eMenu::Action action, const QString& id) {
    pActions[action]->setData(id);
    emit requestActionTrigger(action);
  };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : qAsConst(selection)) {
      list << d->model->itemByIndex(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            if (isVisible()) {
                Q_D(KReportsView);
                d->ui.m_filterContainer->show();
                d->ui.m_searchWidget->setFocus();
            }
        }
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(i, AccountsModel::Account, source);
```

#### AUTO 


```{c}
auto j = i;
```

#### AUTO 


```{c}
const auto file = MyMoneyFile::instance();
```

#### AUTO 


```{c}
auto checkNodeOk = [&](const QString& xmlContent, int kvpPairs) {
        doc.setContent(xmlContent);
        node = doc.documentElement().firstChild().toElement();

        a.addAccountId("TEST");
        a.setValue("KEY", "VALUE");

        a = MyMoneyXmlContentHandler::readAccount(node);
        QCOMPARE(a.id(), QStringLiteral("A000001"));
        QCOMPARE(a.name(), QStringLiteral("AccountName"));
        QCOMPARE(a.parentAccountId(), QStringLiteral("Parent"));
        QCOMPARE(a.lastModified(), QDate::currentDate());
        QCOMPARE(a.lastReconciliationDate(), QDate());
        QCOMPARE(a.institutionId(), QStringLiteral("B000001"));
        QCOMPARE(a.number(), QStringLiteral("465500"));
        QCOMPARE(a.openingDate(), QDate::currentDate());
        QCOMPARE(a.accountType(), eMyMoney::Account::Type::Asset);
        QCOMPARE(a.description(), QStringLiteral("Desc"));
        QCOMPARE(a.accountList().count(), 2);
        QCOMPARE(a.accountList()[0], QStringLiteral("A000002"));
        QCOMPARE(a.accountList()[1], QStringLiteral("A000003"));
        QCOMPARE(a.pairs().count(), kvpPairs);
        QCOMPARE(a.value("key"), QStringLiteral("value"));
        QCOMPARE(a.value("Key"), QStringLiteral("Value"));
        QCOMPARE(a.pairs().contains("lastStatementDate"), false);
        QCOMPARE(a.reconciliationHistory().count(), 2);
        QCOMPARE(a.reconciliationHistory()[QDate(2011, 1, 1)].toString(), MyMoneyMoney(123, 100).toString());
        QCOMPARE(a.reconciliationHistory()[QDate(2011, 2, 1)].toString(), MyMoneyMoney(456, 100).toString());
    };
```

#### AUTO 


```{c}
const auto count = m_file->onlineJobsModel()->processItems(&writer);
```

#### AUTO 


```{c}
const auto currencyList = m_sql->fetchCurrencies().values();
```

#### AUTO 


```{c}
auto i = (int)Element::Split::Split;
```

#### AUTO 


```{c}
auto parent = dlg->parentAccount();
```

#### AUTO 


```{c}
auto item = ui->m_priceList->currentItem();
```

#### AUTO 


```{c}
const auto newKey = newTransaction.uniqueSortKey();
```

#### AUTO 


```{c}
const auto idView = KMyMoneySettings::startLastViewSelected() ?
        static_cast<View>(KMyMoneySettings::lastViewSelected()) :
        View::Home;
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->ui.m_reportTabWidget->currentWidget());
```

#### AUTO 


```{c}
const auto closeCount = input.count(closeParen);
```

#### AUTO 


```{c}
auto firstAccNumber = filteredAccounts.at(i).number();
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Action action) {
        if (pActions.contains(action)) {
            pActions[action]->trigger();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto action : m_sharedActionButtons[Action::FileNew].button->actions()) {
            action->setEnabled(m_storageInfo.isOpened);
        }
```

#### AUTO 


```{c}
auto payeeId = indexes.at(0).data(eMyMoney::Model::SplitPayeeIdRole).toString();
```

#### AUTO 


```{c}
auto ok = true;
```

#### AUTO 


```{c}
auto value = task.value().toString();
```

#### AUTO 


```{c}
const auto cnt = filter.matchingSplitsCount(transaction);
```

#### AUTO 


```{c}
const auto filter = d->m_filterSet.singleFilter;
```

#### AUTO 


```{c}
auto logFile = QString::fromLatin1("%1/kmm-statement-%2.txt").arg(KMyMoneySettings::logPath(),
                                                                      QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyy-MM-dd hh-mm-ss")));
```

#### AUTO 


```{c}
const auto budgetAccount = d->m_budget.account(accountId);
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Report>(i)).isEmpty();
```

#### AUTO 


```{c}
auto bgOpt = opt;
```

#### AUTO 


```{c}
const auto type = data(index, payeeIdentifierType).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyModelBase::mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->amountEditCredit->setText(splitIdx.data(eMyMoney::Model::JournalSplitPaymentRole).toString());
                d->ui->amountEditDebit->setText(splitIdx.data(eMyMoney::Model::JournalSplitDepositRole).toString());

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());

                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());

                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    const auto value = splitIdx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
                    if (!shares.isZero()) {
                        d->price = value / shares;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& institution : list) {
        const auto idx = index(row, 0);
        static_cast<TreeItem<MyMoneyInstitution>*>(idx.internalPointer())->dataRef() = institution;
        d->loadAccounts(idx, institution.accountList());
        ++row;
    }
```

#### AUTO 


```{c}
const auto col = columnAt(pos.x());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : selectedTags) {
            f.addTag(tag.id());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : transactionList) {
      QString defaultAction;
      QList<MyMoneySplit> splits = transaction.splits();
      QStringList accounts;

      // check if base commodity is set. if not, set baseCurrency
      if (transaction.commodity().isEmpty()) {
        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " has no base currency";
        transaction.setCommodity(file->baseCurrency().id());
        file->modifyTransaction(transaction);
      }

      bool isLoan = false;
      // Determine default action
      if (transaction.splitCount() == 2) {
        // check for transfer
        int accountCount = 0;
        MyMoneyMoney val;
        foreach (const auto split, splits) {
          auto acc = file->account(split.accountId());
          if (acc.accountGroup() == eMyMoney::Account::Type::Asset
              || acc.accountGroup() == eMyMoney::Account::Type::Liability) {
            val = split.value();
            accountCount++;
            if (acc.accountType() == eMyMoney::Account::Type::Loan
                || acc.accountType() == eMyMoney::Account::Type::AssetLoan)
              isLoan = true;
          } else
            break;
        }
        if (accountCount == 2) {
          if (isLoan)
            defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Amortization);
          else
            defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer);
        } else {
          if (val.isNegative())
            defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal);
          else
            defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit);
        }
      }

      isLoan = false;
      foreach (const auto split, splits) {
        auto acc = file->account(split.accountId());
        MyMoneyMoney val = split.value();
        if (acc.accountGroup() == eMyMoney::Account::Type::Asset
            || acc.accountGroup() == eMyMoney::Account::Type::Liability) {
          if (!val.isPositive()) {
            defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal);
            break;
          } else {
            defaultAction = MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit);
            break;
          }
        }
      }

  #if 0
      // Check for correct actions in transactions referencing credit cards
      bool needModify = false;
      // The action fields are actually not used anymore in the ledger view logic
      // so we might as well skip this whole thing here!
      for (it_s = splits.begin(); needModify == false && it_s != splits.end(); ++it_s) {
        auto acc = file->account((*it_s).accountId());
        MyMoneyMoney val = (*it_s).value();
        if (acc.accountType() == Account::Type::CreditCard) {
          if (val < 0 && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Withdrawal) && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer))
            needModify = true;
          if (val >= 0 && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Deposit) && (*it_s).action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer))
            needModify = true;
        }
      }

      // (Ace) Extended the #endif down to cover this conditional, because as-written
      // it will ALWAYS be skipped.

      if (needModify == true) {
        for (it_s = splits.begin(); it_s != splits.end(); ++it_s) {
          (*it_s).setAction(defaultAction);
          transaction.modifySplit(*it_s);
          file->modifyTransaction(transaction);
        }
        splits = transaction.splits();    // update local copy
        qDebug("Fixed credit card assignment in %s", transaction.id().data());
      }
  #endif

      // Check for correct assignment of ActionInterest in all splits
      // and check if there are any duplicates in this transactions
      for (auto& split : splits) {
        MyMoneyAccount splitAccount = file->account(split.accountId());
        if (!accounts.contains(split.accountId())) {
          accounts << split.accountId();
        }
        // if this split references an interest account, the action
        // must be of type ActionInterest
        if (interestAccounts.contains(split.accountId())) {
          if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
            qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
            split.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
            qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
          }
          // if it does not reference an interest account, it must not be
          // of type ActionInterest
        } else {
          if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
            qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
            split.setAction(defaultAction);
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
            qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
          }
        }

        // check that for splits referencing an account that has
        // the same currency as the transactions commodity the value
        // and shares field are the same.
        if (transaction.commodity() == splitAccount.currencyId()
            && split.value() != split.shares()) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
          split.setShares(split.value());
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
        }

        // fix the shares and values to have the correct fraction
        if (!splitAccount.isInvest()) {
          try {
            int fract = splitAccount.fraction();
            if (split.shares() != split.shares().convert(fract)) {
              qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
              split.setShares(split.shares().convert(fract));
              split.setValue(split.value().convert(fract));
              transaction.modifySplit(split);
              file->modifyTransaction(transaction);
            }
          } catch (const MyMoneyException &) {
            qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
          }
        }
      }

      ++cnt;
      if (!(cnt % 10))
        q->slotStatusProgressBar(cnt);
    }
```

#### AUTO 


```{c}
const auto openingBalance = node.attribute(attributeName(Attribute::Account::OpeningBalance));
```

#### AUTO 


```{c}
auto baseIdx = MyMoneyFile::baseModel()->mapToBaseSource(current.indexes().front());
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QMetaObject::invokeMethod(this, "updateWidgets", Qt::QueuedConnection);
        }
```

#### AUTO 


```{c}
const auto list = model->match(model->index(0, 0), (int)Role::ID, QVariant(accountId), -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto& set = d->m_changeSet;
```

#### AUTO 


```{c}
const auto& accId
```

#### AUTO 


```{c}
auto itParentAcc = d->itemFromId(this, acc->parentAccountId(), Role::InvestmentID);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto option : opts) {
        option = option.trimmed();
        if (option.startsWith(QLatin1String("QSQLITE_BUSY_TIMEOUT"))) {
            option = option.mid(20).trimmed();
            if (option.startsWith(QLatin1Char('='))) {
                bool ok;
                const int nt = option.mid(1).trimmed().toInt(&ok);
                if (ok)
                    timeOut = nt;
            }
        } else if (option == QLatin1String("QSQLITE_OPEN_READONLY")) {
            openReadOnlyOption = true;
        } else if (option == QLatin1String("QSQLITE_OPEN_URI")) {
            openUriOption = true;
        } else if (option == QLatin1String("QSQLITE_ENABLE_SHARED_CACHE")) {
            sharedCache = true;
        }
#if QT_CONFIG(regularexpression)
        else if (option.startsWith(regexpConnectOption)) {
            option = option.mid(regexpConnectOption.size()).trimmed();
            if (option.isEmpty()) {
                defineRegexp = true;
            } else if (option.startsWith(QLatin1Char('='))) {
                bool ok = false;
                const int cacheSize = option.mid(1).trimmed().toInt(&ok);
                if (ok) {
                    defineRegexp = true;
                    if (cacheSize > 0)
                        regexpCacheSize = cacheSize;
                }
            }
        }
#endif
    }
```

#### AUTO 


```{c}
auto indexList = d->accountsModel.indexListByName(name);
```

#### AUTO 


```{c}
const auto start = d->journalModel.MyMoneyModelBase::lowerBound(d->journalModel.keyForDate(acc.openingDate())).row();
```

#### AUTO 


```{c}
const auto acc = file->accountsModel()->itemById(accountIds.at(0));
```

#### AUTO 


```{c}
auto seconditem = m_accountsProxyModel->index(0, 0, firsitem);
```

#### AUTO 


```{c}
const auto isChecked = retAction->isChecked();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
                    // create a copy of the splits list in the transaction
                    // loop over all splits
                    for (auto split : transaction.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (int i = 0; i < tagIdList.size(); ++i) {
                            // if the split is assigned to one of the selected tags, we need to modify it
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (!newTagId.isEmpty()) {
                                    if (tagIdList.indexOf(newTagId) == -1) {
                                        tagIdList.append(newTagId);
                                    }
                                }
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList); // first modify tag list in current split
                        // then modify the split in our local copy of the transaction list
                        transaction.modifySplit(split); // this does not modify the list object 'splits'!
                    } // for - Splits
                    file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
        const auto acc = file->account(split.accountId());
        if (acc.isIncomeExpense()) {
          if (split.shares().isNegative() ^ fees) {
            if (rc.isEmpty()) {
              rc = MyMoneyFile::instance()->accountsModel()->accountIdToHierarchicalName(split.accountId());
            } else {
              return fees ? i18n("Multiple fee categories") : i18n("Multiple interest categories");
            }
          }
        }
      }
```

#### AUTO 


```{c}
const auto leftData = sourceModel()->data(left, AccountsModel::DisplayOrderRole);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : findChildren<QToolButton*>()) {
            const auto action = button->defaultAction();
            if (action) {
                const auto actionSeq = action->shortcut();
                if (keySeq == actionSeq) {
                    action->trigger();
                    event->accept();
                    return true;
                }
            }
        }
```

#### AUTO 


```{c}
const auto value = file->price(acc.currencyId(), tradingCurrencyId).rate(tradingCurrencyId);
```

#### AUTO 


```{c}
auto i = (int)onlineJob::Attribute::Send;
```

#### AUTO 


```{c}
auto secondAccNumber = filteredAccounts.at(i + 1).number();
```

#### AUTO 


```{c}
const auto& column
```

#### AUTO 


```{c}
const auto& sp
```

#### AUTO 


```{c}
const auto id = idx.data(filterRole()).toString();
```

#### AUTO 


```{c}
auto prec(m_prec);
```

#### AUTO 


```{c}
const auto journalEntries = selections.selection(SelectedObjects::JournalEntry);
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(s1.accountId());
```

#### AUTO 


```{c}
const auto widgetIt = QTreeWidgetItemIterator(ui->m_budgetList);
```

#### AUTO 


```{c}
auto itParent = d->itemFromAccountId(this, account.id());
```

#### AUTO 


```{c}
const auto sec = file->security(d->m_transaction.commodity());
```

#### AUTO 


```{c}
auto stockNames = csvImporter->m_mapSymbolName.values();
```

#### AUTO 


```{c}
const auto newJournalEntryId = journalModel->updateJournalId(journalEntryId);
```

#### AUTO 


```{c}
const auto expenseValue = data(expenseList.front(), AccountsModel::AccountTotalValueRole);
```

#### AUTO 


```{c}
const auto accounts = account(id).accountList();
```

#### LAMBDA EXPRESSION 


```{c}
[&](SplitModel* model, AmountEdit* amountEdit) {
        amountEdit->setReadOnly(false);
        amountEdit->setCommodity(transactionCurrency);
        switch (model->rowCount()) {
        case 0:
            amountEdit->clear();
            break;
        case 1: {
            const auto idx = model->index(0, 0);
            amountEdit->setValue(idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().abs());
            amountEdit->setShares(idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>().abs());
            adjustSharesCommodity(amountEdit, idx.data(eMyMoney::Model::SplitAccountIdRole).toString());
        } break;
        default:
            amountEdit->setValue(model->valueSum().abs());
            amountEdit->setShares(model->valueSum().abs());
            amountEdit->setReadOnly(true);
            break;
        }
    }
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::instance()->tagsModel()->indexById(id);
```

#### AUTO 


```{c}
auto idx = indexById(institutionId);
```

#### AUTO 


```{c}
auto closedAcc = file->account(toBeClosedAccID);
```

#### LAMBDA EXPRESSION 


```{c}
[&, newColPos](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          childItem->insertColumns(newColPos, 1);
          if (childItem->hasChildren())
            self(self, childItem);
          this->d->setAccountData(item, j, childItem->data((int)Role::Account).value<MyMoneyAccount>(), QList<Column> {column});
        }
        return true;
      }
```

#### AUTO 


```{c}
const auto rows = transaction.splitCount();
```

#### AUTO 


```{c}
const auto accountBalanceStr = QVariant::fromValue(MyMoneyUtils::formatMoney(accountBalance, m_file->security(account.currencyId())));
```

#### AUTO 


```{c}
const auto idx = model->index(row, 0);
```

#### AUTO 


```{c}
auto colNum = m_columns.indexOf(Column::Equity);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& backend : backends)
        d->ui->backendsList->addTopLevelItem(new QTreeWidgetItem(QStringList{backend.name,
                                             backend.module}));
```

#### AUTO 


```{c}
const auto beginDate = d->m_lastPayment.isValid() ? d->m_lastPayment : startDate();
```

#### AUTO 


```{c}
const auto transactions = selections.selection(SelectedObjects::Transaction);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& t : m_listTransactions) {
    if (t.m_datePosted > postDate) {
      postDate = t.m_datePosted;
    }
  }
```

#### AUTO 


```{c}
const auto payeeId = index.data(eMyMoney::Model::SplitPayeeIdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int value) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        d->m_schedule.setNextDueDate(d->transactionEditor->postDate());
        d->setScheduleOccurrencePeriod();
        d->m_schedule.setOccurrenceMultiplier(d->ui->frequencyNoEdit->value());

        QSignalBlocker blocked(d->ui->finalPaymentDateEdit);
        d->ui->finalPaymentDateEdit->setDate(d->m_schedule.dateAfter(value));
    }
```

#### AUTO 


```{c}
const auto index = CostCenterModel::mapFromBaseSource(d->costCenterModel, baseIdx);
```

#### AUTO 


```{c}
auto amountWidget = dynamic_cast<KMyMoneyEdit*>(w)
```

#### LAMBDA EXPRESSION 


```{c}
[&](int multiplier) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        auto oldOccurrenceMultiplier = d->m_schedule.occurrenceMultiplier();
        if (multiplier != oldOccurrenceMultiplier) {
            if (d->ui->m_endOptionsFrame->isEnabled()) {
                d->m_schedule.setNextDueDate(d->m_editor->postDate());
                d->m_schedule.setOccurrenceMultiplier(multiplier);
                d->setScheduleOccurrencePeriod();
                d->m_schedule.setEndDate(d->ui->m_FinalPaymentEdit->date());
                d->updateTransactionsRemaining();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& stPrice : st.m_listPrices) {
    auto currency = file->baseCurrency().id();
    QString security;

    if (!stPrice.m_strCurrency.isEmpty()) {
      security = stPrice.m_strSecurity;
      currency = stPrice.m_strCurrency;
    } else if (secBySymbol.contains(stPrice.m_strSecurity)) {
      security = secBySymbol[stPrice.m_strSecurity].id();
      currency = file->security(file->security(security).tradingCurrency()).id();
    } else if (secByName.contains(stPrice.m_strSecurity)) {
      security = secByName[stPrice.m_strSecurity].id();
      currency = file->security(file->security(security).tradingCurrency()).id();
    } else
      return;

    MyMoneyPrice price(security,
                       currency,
                       stPrice.m_date,
                       stPrice.m_amount, stPrice.m_sourceName.isEmpty() ? i18n("Prices Importer") : stPrice.m_sourceName);
    file->addPrice(price);
  }
```

#### AUTO 


```{c}
auto a = d->accountsModel.itemById(sAccount);
```

#### AUTO 


```{c}
auto d2 = static_cast<const PeriodGroupPrivate *>(right.d_func());
```

#### AUTO 


```{c}
const auto& ledgersView = static_cast<KGlobalLedgerView*>(viewBases[View::Ledgers]);
```

#### AUTO 


```{c}
const auto result = tmpl.setAccountTree(&file);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& it_split : d->m_splits) {
    if (split.id() == it_split.id()) {
      it_split = split;
      return;
    }
  }
```

#### AUTO 


```{c}
auto treeItem = ui->m_equitiesTree->currentIndex();
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::instance()->journalModel()->mapToBaseSource(indexes.at(0));
```

#### AUTO 


```{c}
auto baseIdx = journalModel->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto it = reconciliationHistory.cbegin();
```

#### AUTO 


```{c}
auto fMethod = d->forecastMethod();
```

#### AUTO 


```{c}
auto item = dynamic_cast<KPayeeListItem *>(it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : qAsConst(t.splits())) {
        if (sp.id() == stockSplit.id()) {
            continue;
        }
        const auto rows = splitModel->rowCount();
        int row;
        for (row = 0; row < rows; ++row) {
            const QModelIndex index = splitModel->index(row, 0);
            if (index.data(eMyMoney::Model::IdRole).toString() == sp.id()) {
                break;
            }
        }

        // if the split is not in the model, we get rid of it
        if (splitModel->rowCount() == row) {
            t.removeSplit(sp);
        }
    }
```

#### AUTO 


```{c}
auto transactionValue = d->split.value();
```

#### AUTO 


```{c}
auto selectedAccountName = d->m_currentCategory.name();
```

#### AUTO 


```{c}
const auto baseIdx
```

#### AUTO 


```{c}
const auto& sch = static_cast<const MyMoneySchedule&>(obj);
```

#### AUTO 


```{c}
auto depositWidget = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["deposit"]);
```

#### AUTO 


```{c}
auto i = (int)Budget::Element::Budget;
```

#### AUTO 


```{c}
auto payee = dynamic_cast<KMyMoneyPayeeCombo*>(d->m_editWidgets["payee"])
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
            // create a copy of the splits list in the transaction
            // loop over all splits
            for (auto& split : transaction.splits()) {
              // if the split is assigned to one of the selected payees, we need to modify it
              if (split.isMatched()) {
                auto tm = split.matchedTransaction();
                for (auto& sm : tm.splits()) {
                  if (payeeInList(m_selectedPayeesList, sm.payeeId())) {
                    sm.setPayeeId(payee_id); // first modify payee in current split
                    // then modify the split in our local copy of the transaction list
                    tm.modifySplit(sm); // this does not modify the list object 'splits'!
                  }
                }
                split.addMatch(tm);
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
              if (payeeInList(m_selectedPayeesList, split.payeeId())) {
                split.setPayeeId(payee_id); // first modify payee in current split
                // then modify the split in our local copy of the transaction list
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
            } // for - Splits
            file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &standardPath : QStandardPaths::standardLocations(QStandardPaths::AppDataLocation))
        qWarning() << standardPath;
```

#### AUTO 


```{c}
const auto row = rowAt(pos.y());
```

#### AUTO 


```{c}
const auto frameWidth = ofs ? q->style()->pixelMetric(QStyle::PM_DefaultFrameWidth) : 0;
```

#### AUTO 


```{c}
const auto& testInstitution
```

#### AUTO 


```{c}
const auto list = match(index(0, 0), (int)Role::ID, QVariant(account.id()), -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto hierarchyParts(hierarchyExp.match(parent));
```

#### AUTO 


```{c}
const auto idx = ui->tagCombo->model()->index(ui->tagCombo->currentIndex(), 0);
```

#### AUTO 


```{c}
auto end = map.constEnd();
```

#### AUTO 


```{c}
auto tabCount = ui->ledgerTab->count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
        if (d->canBePrinted(accountId)) {
            for (const auto& transactionId : transactions) {
                if (d->canBePrinted(accountId, transactionId)) {
                    actionEnabled = true;
                    break;
                }
            }
        }
        if (actionEnabled) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& account : accountList) {
        const auto history = account.reconciliationHistory();
        if (!history.isEmpty()) {
            const auto& accountId = account.id();

            insertRows(0, history.count());

            int row = 0;
            QMap<QDate, MyMoneyMoney>::const_iterator it;
            for (it = history.constBegin(); it != history.constEnd(); ++it) {
                ReconciliationEntry entry(nextId(), accountId, it.key(), *it);
                static_cast<TreeItem<ReconciliationEntry>*>(index(row, 0).internalPointer())->dataRef() = entry;
                ++row;
            }
        }
    }
```

#### AUTO 


```{c}
const auto storedMatchType = d->m_payee.matchData(ignorecase, keys);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto category : categories) {
    MyMoneyAccount account;
    QString accountName;
    int displayOrder;

    switch (category) {
      case Account::Type::Asset:
        // Asset accounts
        account = d->m_file->asset();
        accountName = i18n("Asset accounts");
        displayOrder = 1;
        break;
      case Account::Type::Liability:
        // Liability accounts
        account = d->m_file->liability();
        accountName = i18n("Liability accounts");
        displayOrder = 2;
        break;
      case Account::Type::Income:
        // Income categories
        account = d->m_file->income();
        accountName = i18n("Income categories");
        displayOrder = 3;
        break;
      case Account::Type::Expense:
        // Expense categories
        account = d->m_file->expense();
        accountName = i18n("Expense categories");
        displayOrder = 4;
        break;
      case Account::Type::Equity:
        // Equity accounts
        account = d->m_file->equity();
        accountName = i18n("Equity accounts");
        displayOrder = 5;
        break;
      default:
        continue;
    }

    auto accountsItem = new QStandardItem(accountName);
    accountsItem->setEditable(false);
    rootItem->appendRow(accountsItem);

    {
      QMap<int, QVariant> itemData;
      itemData[Qt::DisplayRole] = accountName;
      itemData[(int)Role::FullName] = itemData[Qt::EditRole] = QVariant::fromValue(MyMoneyFile::instance()->accountToCategory(account.id(), true));
      itemData[Qt::FontRole] = font;
      itemData[(int)Role::DisplayOrder] = displayOrder;
      this->setItemData(accountsItem->index(), itemData);
    }

    // adding accounts (specific bank/investment accounts) belonging to given accounts category
    for (const auto& accStr : account.accountList()) {
      const auto acc = d->m_file->account(accStr);

      auto item = new QStandardItem(acc.name());
      accountsItem->appendRow(item);
      item->setEditable(false);
      auto subaccountsStr = acc.accountList();
      // filter out stocks with zero balance if requested by user
      for (auto subaccStr = subaccountsStr.begin(); subaccStr != subaccountsStr.end();) {
        const auto subacc = d->m_file->account(*subaccStr);
        if (subacc.isInvest() && KMyMoneySettings::hideZeroBalanceEquities() && subacc.balance().isZero())
          subaccStr = subaccountsStr.erase(subaccStr);
        else
          ++subaccStr;
      }

      // adding subaccounts (e.g. stocks under given investment account) belonging to given account
      d->loadSubaccounts(item, favoriteAccountsItem, subaccountsStr);
      const auto row = item->row();
      d->setAccountData(accountsItem, row, acc, d->m_columns);
      d->loadPreferredAccount(acc, accountsItem, row, favoriteAccountsItem);
    }

    d->setAccountData(rootItem, accountsItem->row(), account, d->m_columns);
  }
```

#### AUTO 


```{c}
const auto rect = d->ui->ledgerTab->tabBar()->tabRect(idx);
```

#### AUTO 


```{c}
const auto accountIdx = AccountsModel::mapToBaseSource(index);
```

#### AUTO 


```{c}
auto rc = (int)Split::State::NotReconciled;
```

#### AUTO 


```{c}
const auto selectedTransaction
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mimeTypeName : formatMimeTypes())
            if (mime.inherits(mimeTypeName))
                    return true;
```

#### AUTO 


```{c}
auto rows = index.data(eMyMoney::Model::JournalSplitMaxLinesCountRole).toInt();
```

#### AUTO 


```{c}
auto result = KMessageBox::questionYesNoCancel(this,
                                      i18n("For <b>%1</b> on <b>%2</b> price <b>%3</b> already exists.<br>"
                                           "Do you want to replace it with <b>%4</b>?",
                                           storedPrice.from(), storedPrice.date().toString(Qt::ISODate),
                                           QString().setNum(storedPrice.rate(storedPrice.to()).toDouble(), 'g', 10),
                                           QString().setNum((*it).m_amount.toDouble(), 'g', 10)),
                                      i18n("Price Already Exists"));
```

#### AUTO 


```{c}
auto cols = MyMoneyReport::eQCnumber | MyMoneyReport::eQCpayee | MyMoneyReport::eQCcategory | MyMoneyReport::eQCbalance;
```

#### AUTO 


```{c}
const auto accountId = m_view->accountId();
```

#### AUTO 


```{c}
const auto idx = d->splitModel.index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
        if (plugin->storageType() == d->m_storageInfo.type) {
            d->consistencyCheck(false);
            try {
                if (plugin->save(d->m_storageInfo.url)) {
                    d->fileAction(eKMyMoney::FileAction::Saved);
                    return true;
                }
                return false;
            } catch (const MyMoneyException &e) {
                KMessageBox::detailedError(this, i18n("Failed to save your storage."), e.what());
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
const auto rowCount = rowIndeces.count();
```

#### AUTO 


```{c}
auto counter = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
                const auto acc = file->account(split.accountId());
                if (acc.isAssetLiability() && !acc.isInvest() && (acc.accountType() != eMyMoney::Account::Type::Investment)) {
                    return acc.name();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
        const auto idx = d->ui->securityAccountCombo->model()->index(index, 0);
        if (idx.isValid()) {
            const auto accountId = idx.data(eMyMoney::Model::IdRole).toString();
            const auto securityId = idx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
            try {
                const auto file = MyMoneyFile::instance();
                const auto sec = file->security(securityId);

                d->stockAccount = file->account(accountId);
                d->stockSplit.setAccountId(accountId);
                d->setSecurity(sec);

                updateTotalAmount();

            } catch (MyMoneyException& e) {
                qDebug() << "Problem to find securityId" << accountId << "or" << securityId << "in InvestTransactionEditor::securityAccountChanged";
            }
        }
    }
```

#### AUTO 


```{c}
auto list = match(index(0, 0), (int)Role::ID, id, -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto blocked = blockSignals(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account(id).accountList())
    result += totalBalance(sAccount, date);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sec : file->securityList()) {
    secBySymbol[sec.tradingSymbol()] = sec;
    secByName[sec.name()] = sec;
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QComboBox* combobox) {
        combobox->setCurrentIndex(-1);
    }
```

#### AUTO 


```{c}
auto result = journalEntryIds;
```

#### AUTO 


```{c}
const auto show = pActions[Action::ViewTransactionDetail]->isChecked();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : d->transaction.splits()) {
            if (split.id() == d->split.id()) {
                d->ui->dateEdit->setDate(d->transaction.postDate());

                const auto payeeId = split.payeeId();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(split.memo());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(split.number());
                d->ui->statusCombo->setCurrentIndex(static_cast<int>(split.reconcileFlag()));
                d->ui->tagContainer->loadTags(split.tagIdList());
            } else {
                d->splitModel.appendSplit(split);
                if (d->transaction.splitCount() == 2) {
                    const auto shares = split.shares();
                    // the following is only relevant for transactions with two splits
                    // in different currencies
                    const auto value = -transactionValue;
                    const auto idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(value), eMyMoney::Model::SplitValueRole);
                    if (!value.isZero()) {
                        d->price = shares / value;
                    }
                    // make sure to use a possible foreign currency value
                    // in case of income and expense categories.
                    // in this case, we also need to use the reciprocal of the price
                    if (d->isIncomeExpense(split.accountId())) {
                        amount = -shares;
                        if (!shares.isZero()) {
                            d->price = value / shares;
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto prev = ui->m_selectedList->item(ui->m_selectedList->row(item) - 1);
```

#### AUTO 


```{c}
const auto sec = file->securitiesModel()->itemById(acc.currencyId());
```

#### AUTO 


```{c}
auto widget = m_parent->findChild<T*>(aName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
        if (idx.row() != lastRow) {
            lastRow = idx.row();
            if (d->firstSelectedId != idx.data(eMyMoney::Model::IdRole).toString()) {
                selectedJournalEntries += idx.data(eMyMoney::Model::IdRole).toString();
            } else {
                firstSelectedStillPresent = true;
            }
            const auto scheduleId = idx.data(eMyMoney::Model::TransactionScheduleIdRole).toString();
            if (!scheduleId.isEmpty()) {
                selectedSchedules += scheduleId;
            }
        }
    }
```

#### AUTO 


```{c}
const auto fileName = url.toLocalFile();
```

#### AUTO 


```{c}
const auto startIndex = currentWidgetIndex;
```

#### AUTO 


```{c}
auto baseAmountMM = amount * curRate;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int logicalIndex, int oldSize, int newSize) {
        emit sectionResized(this, d->columnSelector->configGroupName(), logicalIndex, oldSize, newSize);
        QMetaObject::invokeMethod(this, "adjustDetailColumn", Qt::QueuedConnection, Q_ARG(int, viewport()->width()), Q_ARG(bool, false));
    }
```

#### AUTO 


```{c}
auto isTopLevel = false;
```

#### AUTO 


```{c}
const auto tags = s.tagIdList();
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("onlinejoboutboxview");
```

#### AUTO 


```{c}
auto split
```

#### AUTO 


```{c}
auto counter = 1;
```

#### AUTO 


```{c}
const auto dateEdit = d->m_editor->findChild<QWidget*>("dateEdit");
```

#### AUTO 


```{c}
const auto tradingCurrencyIdx = securityIdx.data(eMyMoney::Model::SecurityTradingCurrencyIndexRole).value<QModelIndex>();
```

#### AUTO 


```{c}
auto interest = dynamic_cast<KMyMoneyCategory*>(haveWidget("interest-account"));
```

#### AUTO 


```{c}
auto prec = security.pricePrecision();
```

#### AUTO 


```{c}
const auto subIdx = index(rows, 0, idx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid())
                    d->ui->payeeEdit->setCurrentIndex(d->payeesModel->mapFromSource(payeeIdx).row());
                else
                    d->ui->payeeEdit->setCurrentIndex(0);

                bool blocked = d->ui->accountCombo->blockSignals(true);
                switch (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole).toInt()) {
                case 1:
                    d->ui->accountCombo->clearEditText();
                    d->ui->accountCombo->setSelected(QString());
                    break;
                case 2:
                    d->ui->accountCombo->setSelected(splitIdx.data(eMyMoney::Model::TransactionCounterAccountIdRole).toString());
                    break;
                default:
                    d->ui->accountCombo->setEditText(splitIdx.data(eMyMoney::Model::TransactionCounterAccountRole).toString());
                    break;
                }
                d->ui->accountCombo->blockSignals(blocked);

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->amountEditCredit->setText(splitIdx.data(eMyMoney::Model::JournalSplitPaymentRole).toString());
                d->ui->amountEditDebit->setText(splitIdx.data(eMyMoney::Model::JournalSplitDepositRole).toString());

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());

                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
            } else {
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());
                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
                    const auto value = splitIdx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
                    if (!shares.isZero()) {
                        d->price = value / shares;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto acCadChecking = makeAccount(QString("Canadian Checking"), MyMoneyAccount::Checkings, moZero, QDate(2017, 8, 1), acAsset, "CAD");
```

#### AUTO 


```{c}
auto pStorage = plugin->open(url)
```

#### AUTO 


```{c}
const auto id = obj.id();
```

#### AUTO 


```{c}
auto creator = new AccountCreator(q);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString&  indicator) {
    m_profile->m_debitIndicator = indicator;
    emit completeChanged();
  }
```

#### AUTO 


```{c}
const auto&  accountList = account.accountList();
```

#### AUTO 


```{c}
auto item = d->ui->m_priceList->currentItem();
```

#### AUTO 


```{c}
auto b = acc.isClosed() ? false : true;
```

#### AUTO 


```{c}
auto totalValue = accountValue(account, accountBalance(account.id()));
```

#### AUTO 


```{c}
const auto baseIdx = file->journalModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Payee>(i)).isEmpty();
```

#### AUTO 


```{c}
auto i = (int)Attribute::KVP::Key;
```

#### AUTO 


```{c}
const auto currentView = d->viewBases[d->currentViewId()];
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Institution));
```

#### AUTO 


```{c}
auto acc = file->account((*it_t).split().accountId());
```

#### AUTO 


```{c}
const auto model = d->ui->m_paymentMethodEdit->model();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& statement : statements) {
        const auto singleImportSummary = statementInterface()->import(statement);
        if (singleImportSummary.isEmpty())
            ret = false;
    }
```

#### AUTO 


```{c}
const auto category = MyMoneyFile::instance()->account(accountId);
```

#### AUTO 


```{c}
const auto sAccounts = account->accountList();
```

#### AUTO 


```{c}
const auto sOldConfigFilename = sOldMainConfigPath + sConfigName;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : qAsConst(splits)) {
                list.append(qMakePair(journalEntry.transaction(), split));
            }
```

#### AUTO 


```{c}
auto security = dynamic_cast<KMyMoneySecurity*>(haveWidget("security"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& t : m_listTransactions) {
        if (t.m_datePosted > postDate) {
            postDate = t.m_datePosted;
        }
    }
```

#### AUTO 


```{c}
auto current = dynamic_cast<KReportTab*>(d->m_reportTabWidget->widget(index));
```

#### AUTO 


```{c}
const auto baseIdx = journalModel->indexById(id);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        // wait another round if any of the buttons is pressed
        for (const auto& button : m_buttons) {
            if (button->isDown()) {
                createAccount();
                return;
            }
        }

        MyMoneyAccount parent;
        MyMoneyAccount account;

        account.setName(m_comboBox->currentText());

        if (m_accountType == eMyMoney::Account::Type::Asset) {
            parent = MyMoneyFile::instance()->asset();
        } else if (m_accountType == eMyMoney::Account::Type::Liability) {
            parent = MyMoneyFile::instance()->liability();
        } else if (m_accountType == eMyMoney::Account::Type::Expense) {
            parent = MyMoneyFile::instance()->expense();
        } else if (m_accountType == eMyMoney::Account::Type::Income) {
            parent = MyMoneyFile::instance()->income();
        }

        if ((m_accountType == eMyMoney::Account::Type::Asset) || (m_accountType == eMyMoney::Account::Type::Asset)) {
            KNewAccountDlg::newAccount(account, parent);
        } else {
            KNewAccountDlg::newCategory(account, parent);
        }

        if (account.id().isEmpty()) {
            m_comboBox->setSelected(QString());
            m_comboBox->clearSelection();
            m_comboBox->setFocus();
        } else {
            m_comboBox->setSelected(account.id());
            auto widget = m_comboBox->nextInFocusChain();
            widget->setFocus();
        }

        // suicide, we're done
        deleteLater();
    }
```

#### AUTO 


```{c}
const auto toplevelItem = d->ui.m_tocTreeWidget->topLevelItem(i);
```

#### AUTO 


```{c}
const auto cond3 = cond1 && sec.id() != file->baseCurrency().id();
```

#### AUTO 


```{c}
auto paymentWidget = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["payment"]);
```

#### AUTO 


```{c}
auto activity = dynamic_cast<KMyMoneyActivityCombo*>(haveWidget("activity"));
```

#### AUTO 


```{c}
auto price = MyMoneyPrice(basePrice);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QSaveFile* qfile)
    {
      QTextStream stream(qfile);
      stream.setCodec("UTF-8");
      stream << m_doc.toString();
      stream.flush();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : selectedSourceTransaction.splits()) {
                                // Don't copy the source split, as we already have that
                                // as part of the destination transaction
                                if (split.id() == selectedSourceSplitId) {
                                    continue;
                                }

                                MyMoneySplit sp(split);
                                // clear the ID and reconciliation state
                                sp.clearId();
                                sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                sp.setReconcileDate(QDate());

                                // in case it is a simple transaction consisting of two splits,
                                // we can adjust the share and value part of the second split we
                                // just created. We need to keep a possible price in mind in case
                                // of different currencies
                                if (t.splitCount() == 2) {
                                    sp.setValue(-baseSplit.value());
                                    sp.setShares(-(baseSplit.shares() * baseSplit.price()));
                                }
                                t.addSplit(sp);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
        // we don't need to process all columns but only the first one
        if (idx.row() != lastRow) {
            lastRow = idx.row();
            id = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
            if (!selection.contains(id)) {
                selection.append(id);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
                    const auto journalEntry = file->journalModel()->itemById(journalEntryId);
                    if (!journalEntry.id().isEmpty()) {
                        auto t = journalEntry.transaction();
                        // don't process the source transaction
                        if (selectedSourceTransaction.id() == t.id()) {
                            continue;
                        }

                        if (!t.id().isEmpty() && (t.splitCount() == 1)) {
                            // keep a copy of that one and only split
                            const auto baseSplit = t.splits().first();

                            for (const auto& split : selectedSourceTransaction.splits()) {
                                // Don't copy the source split, as we already have that
                                // as part of the destination transaction
                                if (split.id() == selectedSourceSplitId) {
                                    continue;
                                }

                                MyMoneySplit sp(split);
                                // clear the ID and reconciliation state
                                sp.clearId();
                                sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                sp.setReconcileDate(QDate());

                                // in case it is a simple transaction consisting of two splits,
                                // we can adjust the share and value part of the second split we
                                // just created. We need to keep a possible price in mind in case
                                // of different currencies
                                if (t.splitCount() == 2) {
                                    sp.setValue(-baseSplit.value());
                                    sp.setShares(-(baseSplit.shares() * baseSplit.price()));
                                }
                                t.addSplit(sp);
                            }
                            // check if we need to add/update a VAT assignment
                            file->updateVAT(t);

                            // and store the modified transaction
                            file->modifyTransaction(t);
                        }
                    }
                }
```

#### AUTO 


```{c}
const auto value = -transactionValue;
```

#### AUTO 


```{c}
auto newSplit(split);
```

#### AUTO 


```{c}
auto journalEntry = m_rootItem->takeChild(srcRow);
```

#### AUTO 


```{c}
const auto splitId = idx.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto accountIdx = file->accountsModel()->indexById(accountId);
```

#### AUTO 


```{c}
auto childItem = item->child(j);
```

#### AUTO 


```{c}
const auto totalValue = sourceModel()->data(source, AccountsModel::AccountTotalValueRole);
```

#### AUTO 


```{c}
const auto detailLevelFromXML = stringToDetailLevel(node.attribute(attributeName(Attribute::Report::Detail), "none"));
```

#### AUTO 


```{c}
const auto property = w->property("kmm_taborder");
```

#### AUTO 


```{c}
const auto& t = m_selectedTransactions[0].transaction();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            const auto journalEntry = file->journalModel()->itemById(journalEntryId);
            if (!journalEntry.id().isEmpty()) {
                auto t = journalEntry.transaction();
                if (!t.id().isEmpty()) {
                    // wipe out any reconciliation information
                    for (auto& split : t.splits()) {
                        split.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                        split.setReconcileDate(QDate());
                        split.setBankID(QString());
                        split.removeMatch();
                    }
                    // clear invalid data
                    t.setEntryDate(QDate());
                    t.clearId();

                    if (reverse)
                        // reverse transaction
                        t.reverse();
                    else
                        // set the post date to today
                        t.setPostDate(QDate::currentDate());

                    file->addTransaction(t);
                    lastAddedTransactionId = t.id();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : qAsConst(budgetIds)) {
            auto budget = file->budget(id);
            file->removeBudget(budget);
        }
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<kMyMoneyDateInput*>(d->m_editor->haveWidget("postdate"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pluginPath) {
          KPluginMetaData metadata(pluginPath);
          qDebug() << "Located plugin" << pluginPath << "Validity" << metadata.isValid();
      }
```

#### AUTO 


```{c}
auto f_day = 1;
```

#### AUTO 


```{c}
const auto viewId = actionRoutes.value(action, View::None);
```

#### AUTO 


```{c}
auto view = qobject_cast<SplitView*>(parent->parentWidget());
```

#### AUTO 


```{c}
const auto category = MyMoneyFile::instance()->account(categoryId);
```

#### AUTO 


```{c}
const auto fileName = tmpfile->fileName();
```

#### AUTO 


```{c}
auto storeTransactions = true;
```

#### AUTO 


```{c}
const auto disabled = idx.data(eMyMoney::Model::AccountIsClosedRole).toBool();
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<KMyMoneyLineEdit*>(d->m_editor->haveWidget("number"));
```

#### AUTO 


```{c}
const auto subIdx = index(accountIdx.row(), idx.column(), accountIdx.parent());
```

#### AUTO 


```{c}
const auto separator = m_locale.groupSeparator();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : qAsConst(balanceChangedSet)) {
      balances.insert(accountId, balanceCache.value(accountId));
    }
```

#### AUTO 


```{c}
const auto validInput = (!idx.data(eMyMoney::Model::IdRole).toString().isEmpty() || ui->removeCheckBox->isChecked());
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemById(selections.firstSelection(SelectedObjects::Account));
```

#### AUTO 


```{c}
auto itAcc = d->itemFromId(this, id, Role::EquityID);
```

#### AUTO 


```{c}
auto w = d->haveWidget<QLabel>(idx);
```

#### AUTO 


```{c}
auto kvpResult = d->readKeyValuePairs("INSTITUTION", kvpInstitutionList);
```

#### AUTO 


```{c}
auto idx = d->ui->m_budgetList->selectionModel()->selectedIndexes().first();
```

#### AUTO 


```{c}
const auto accountId = journalIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : qAsConst(stdAccNames)) {
    if (id == MyMoneyAccount::stdAccName(idx))
      return true;
  }
```

#### AUTO 


```{c}
auto tab = d->ui->ledgerTab->widget(idx);
```

#### AUTO 


```{c}
const auto commodity = MyMoneyFile::instance()->currency(d->m_additionalFeesTransaction.commodity());
```

#### AUTO 


```{c}
const auto item = d->ui->m_currencyList->currentItem();
```

#### AUTO 


```{c}
const auto iconWidth = (metrics.lineSpacing() + 2) + (2 * q->style()->pixelMetric(QStyle::PM_FocusFrameHMargin));
```

#### AUTO 


```{c}
auto counterAccount = index.data((int)eLedgerModel::Role::CounterAccount).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids) {
      const auto idx = indexById(id);
      if (idx.isValid()) {
        indeces += idx;
      }
    }
```

#### AUTO 


```{c}
auto accCol = m_mdlColumns->indexOf(eAccountsModel::Column::Account);
```

#### AUTO 


```{c}
const auto number = idx.data(eMyMoney::Model::JournalSplitNumberRole).toString();
```

#### AUTO 


```{c}
const auto accountId = d->ui->interestCombo->getSelected();
```

#### AUTO 


```{c}
const auto rows = rowCount(idx);
```

#### AUTO 


```{c}
auto t = transaction;
```

#### AUTO 


```{c}
const auto rate = file->price(fromSecurity.id(), toSecurity.id(), date).rate(toSecurity.id());
```

#### AUTO 


```{c}
const auto currentItem = static_cast<TreeItem<JournalEntry>*>(idx.internalPointer())->constDataRef();
```

#### AUTO 


```{c}
const auto item = m_idToItemMapper->value(id, nullptr);
```

#### AUTO 


```{c}
auto *transferForm = new kOnlineTransferForm(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mimeTypeName : formatMimeTypes())
            if (mime.inherits(mimeTypeName))
                return true;
```

#### AUTO 


```{c}
auto helpEvent = static_cast<QHelpEvent*>(event);
```

#### AUTO 


```{c}
const auto duplicateItem = menu->addAction(Icons::get(Icons::Icon::EditCopy), i18nc("@item:inmenu Duplicate selected split(s)", "Duplicate"), q, [&]() {
            const auto list = q->selectionModel()->selectedRows();
            QPersistentModelIndex newCurrentIdx;
            for (const auto idx : list) {
                const auto id = idx.data(eMyMoney::Model::IdRole).toString();
                if (!(id.isEmpty() || id.endsWith('-'))) {
                    // we can use any model object for the next operation, but we have to use one
                    const auto baseIdx = MyMoneyFile::instance()->accountsModel()->mapToBaseSource(idx);
                    auto model = const_cast<SplitModel*>(qobject_cast<const SplitModel*>(baseIdx.model()));
                    if (model) {
                        // get the original data
                        const auto split = model->itemByIndex(baseIdx);

                        model->appendEmptySplit();
                        const auto newIdx = model->emptySplit();
                        // prevent update signals
                        QSignalBlocker block(model);
                        // the id of the split will be automatically assigned by the model
                        model->setData(newIdx, split.number(), eMyMoney::Model::SplitNumberRole);
                        model->setData(newIdx, split.memo(), eMyMoney::Model::SplitMemoRole);
                        model->setData(newIdx, split.accountId(), eMyMoney::Model::SplitAccountIdRole);
                        model->setData(newIdx, split.costCenterId(), eMyMoney::Model::SplitCostCenterIdRole);
                        model->setData(newIdx, split.payeeId(), eMyMoney::Model::SplitPayeeIdRole);
                        model->setData(newIdx, QVariant::fromValue<MyMoneyMoney>(split.shares()), eMyMoney::Model::SplitSharesRole);
                        // send out the dataChanged signal with the next (last) setData()
                        block.unblock();
                        model->setData(newIdx, QVariant::fromValue<MyMoneyMoney>(split.value()), eMyMoney::Model::SplitValueRole);

                        // now add a new empty split at the end
                        model->appendEmptySplit();
                        // and make the new split the current one
                        if (!newCurrentIdx.isValid()) {
                            newCurrentIdx = newIdx;
                        }
                    }
                }
            }
            if (newCurrentIdx.isValid()) {
                q->setCurrentIndex(newCurrentIdx);
            }
        });
```

#### AUTO 


```{c}
const auto indexes = m_accountsProxyModel->match(m_accountsProxyModel->index(0, 0),
                                                             eMyMoney::Model::AccountTypeRole,
                                                             QVariant::fromValue<eMyMoney::Account::Type>(eMyMoney::Account::Type::Investment),
                                                             1,
                                                             Qt::MatchRecursive);
```

#### AUTO 


```{c}
const auto pluginDatas = KPluginMetaData::findPlugins(QStringLiteral("kmymoney_plugins"));
```

#### AUTO 


```{c}
const auto maxColumn = columns.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account.accountList())
    this->account(sAccount);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& newNumber) {
        d->numberChanged(newNumber);
    }
```

#### AUTO 


```{c}
auto loanAccountAffected = false;
```

#### AUTO 


```{c}
auto sharesAmount = ui->creditDebitEdit->value();
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(q->haveWidget(amountWidgetName));
```

#### AUTO 


```{c}
auto creator = new payeeIdentifiers::ibanBic();
```

#### AUTO 


```{c}
auto getCell = [&, row](auto column)
    {
      cell = node->child(row, column);
      if (!cell) {
        cell = new QStandardItem;
        node->setChild(row, column, cell);
      }
    };
```

#### AUTO 


```{c}
const auto currency = d->m_storage->currency(id);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& id) {
        d->accountChanged(id);
    }
```

#### AUTO 


```{c}
auto mandatory = new KMandatoryFieldGroup(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(KCMCSVImporter);
        d->setSelectedProfile(idx);
    }
```

#### AUTO 


```{c}
auto cfgGroup = KSharedConfig::openConfig()->group("KInvestmentView_Equities");
```

#### AUTO 


```{c}
auto removed = false;
```

#### AUTO 


```{c}
const auto prec = MyMoneyMoney::denomToPrec(account.fraction());
```

#### AUTO 


```{c}
const auto &idx
```

#### AUTO 


```{c}
auto passphrase = password();
```

#### AUTO 


```{c}
const auto widgetList = parent->findChildren<QWidget*>(QString(), Qt::FindChildrenRecursively);
```

#### AUTO 


```{c}
auto fCycles = forecastCycles();
```

#### AUTO 


```{c}
auto extendedFilter = d->m_filterSet;
```

#### AUTO 


```{c}
const auto childNode = node->child(i, Columns::Account);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccountId : toInvAcc.accountList()) {
                        if (file->account(sAccountId).currencyId() == stockSecurityId) {
                            newStockAccountId = sAccountId;
                            break;
                        }
                    }
```

#### AUTO 


```{c}
auto asset = dynamic_cast<KMyMoneyCategory*>(haveWidget("asset-account"));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(AmountEdit);
        d->swapCommodities();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& href) {
        Q_UNUSED(href)
        d->infoMessage->animatedHide();
        emit requestView(s_globalEditData()->basePage, s_globalEditData()->accountId, s_globalEditData()->journalEntryId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& from, const QModelIndex& to) {
            Q_UNUSED(from)
            Q_UNUSED(to)
            Q_D(KScheduledView);
            d->m_filterModel->invalidate();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* widget : actionObject->associatedWidgets()) {
                toolButton = qobject_cast<QToolButton*>(widget);
                if (toolButton) {
                    d->m_sharedActionButtons[action].button = toolButton;
                    d->m_sharedActionButtons[action].defaultAction = actionObject;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto schedulesPage = new KSettingsSchedules();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits)
      matchingSplits.append(s);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->accepted = true; emit done(); }
```

#### AUTO 


```{c}
const auto firstIdx = index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*transaction).splits()) {
            const JournalEntry journalEntry(QString("%1-%2").arg(it.key(), split.id()), transaction, split);
            const auto newIdx = index(row, 0);
            static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer())->dataRef() = journalEntry;
            if (m_idToItemMapper) {
                m_idToItemMapper->insert(journalEntry.id(), static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer()));
            }
            ++row;
        }
```

#### AUTO 


```{c}
auto accounts = document.createElement(d->getElName(Institution::Element::AccountIDS));
```

#### AUTO 


```{c}
const auto data = sourceModel()->index(source_row, AccountsModel::Account, source_parent).data(AccountsModel::AccountIdRole);
```

#### AUTO 


```{c}
auto i = (int)Split::InvestmentTransactionType::BuyShares;
```

#### AUTO 


```{c}
auto fDays = d->calculateBeginForecastDay();
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(i, (int)(int)Column::Account, source);
```

#### AUTO 


```{c}
const auto id = split.accountId();
```

#### AUTO 


```{c}
const auto hashBase(QStringLiteral("%1-%2").arg(kt.m_datePosted.toString(Qt::ISODate)).arg(h, 7, 16, QLatin1Char('0')));
```

#### AUTO 


```{c}
auto acc = wizard->account();
```

#### AUTO 


```{c}
auto interestAmountWidget = d->haveWidget<AmountEdit>("interestAmountEdit");
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.tagFilter;
```

#### AUTO 


```{c}
auto feeAmountWidget = dynamic_cast<AmountEdit*>(haveWidget("fee-amount"));
```

#### AUTO 


```{c}
auto const model = Models::instance()->accountsModel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : transaction.splits()) {
            acc = MyMoneyFile::instance()->account(s.accountId());
            list.append(acc.id());
            if (acc.accountGroup() == eMyMoney::Account::Type::Asset
              || acc.accountGroup() == eMyMoney::Account::Type::Liability) {
              if (acc.accountType() != eMyMoney::Account::Type::Loan
              && acc.accountType() != eMyMoney::Account::Type::AssetLoan) {
                split = s;
                found = true;
                break;
              }
            }
          }
```

#### AUTO 


```{c}
auto mapping = iconDef.value().cbegin();
```

#### AUTO 


```{c}
auto baseIdx = AccountsModel::mapToBaseSource(current.indexes().front());
```

#### AUTO 


```{c}
auto acc = *it_a;
```

#### AUTO 


```{c}
auto sharesEdit = d->haveWidget<AmountEdit*>("shares");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto institution : qAsConst(list)) {
    names << institution.name();
    if (institution.name() == name) {
      d->ui->ibanEdit->setEnabled(true);
      d->ui->accountNoEdit->setEnabled(true);
      d->ui->m_bicValue->setText(institution.value("bic"));
      search = name;
    }
  }
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("budgetview.rc");
```

#### AUTO 


```{c}
const auto payeeId(selections.firstSelection(SelectedObjects::Payee));
```

#### AUTO 


```{c}
const auto leftData = sourceModel()->data(sourceModel()->index(left.row(), AccountsModel::Column::AccountName, left.parent()), eMyMoney::Model::Roles::AccountTotalValueRole);
```

#### AUTO 


```{c}
auto amountWidget = dynamic_cast<AmountEdit*>(d->m_editWidgets["amount"])
```

#### AUTO 


```{c}
auto category = dynamic_cast<KMyMoneyCategory*>(m_editWidgets[categoryWidgetName]);
```

#### AUTO 


```{c}
const auto isReconciliationMode = !d->m_selections.firstSelection(SelectedObjects::ReconciliationAccount).isEmpty();
```

#### AUTO 


```{c}
auto payee = dynamic_cast<KMyMoneyPayeeCombo*>(*it_w);
```

#### AUTO 


```{c}
auto modelUtils = static_cast<InstitutionsPrivate *>(d);
```

#### AUTO 


```{c}
auto pyName = PyString_FromString(sBaseName);
```

#### AUTO 


```{c}
auto w = q->parentWidget();
```

#### AUTO 


```{c}
const auto baseSplit = t.splits().first();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : transactions) {
    for (const auto& split : transaction.splits()) {
      if (!result.contains(split.accountId())) {
        result[split.accountId()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
      }
      const auto flag = split.reconcileFlag();
      switch(flag) {
        case eMyMoney::Split::State::NotReconciled:
        case eMyMoney::Split::State::Cleared:
        case eMyMoney::Split::State::Reconciled:
        case eMyMoney::Split::State::Frozen:
          result[split.accountId()][(int)flag]++;
          break;
        default:
          break;
      }

    }
  }
```

#### AUTO 


```{c}
auto kev = static_cast<QKeyEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tmpl : qAsConst(templates)) {
                loader.importTemplate(tmpl);
            }
```

#### AUTO 


```{c}
const auto h = m_calculatorFrame->height();
```

#### AUTO 


```{c}
const auto transaction = MyMoneyFile::instance()->transaction(transactionId);
```

#### AUTO 


```{c}
auto idx = AccountsModel::mapToBaseSource(treeItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : acc.accountList()) {
        auto accountToMove = d->accountsModel.itemById(accountId);
        reparentAccount(accountToMove, newParent);
        d->m_changeSet += MyMoneyNotification(File::Mode::Modify, File::Object::Account, accountToMove.id());
    }
```

#### AUTO 


```{c}
auto w = ui.m_targetWidget->findChild<QWidget*>(widgetName);
```

#### AUTO 


```{c}
auto w = haveWidget(*it_w);
```

#### AUTO 


```{c}
auto shareEdit = dynamic_cast<kMyMoneyEdit*>(haveWidget("shares"));
```

#### AUTO 


```{c}
auto itSec = d->itemFromSecurityId(this, id);
```

#### AUTO 


```{c}
const auto tagIds = m_selections.selection(SelectedObjects::Tag);
```

#### AUTO 


```{c}
const auto previousActivity = d->currentActivity;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : d->m_splits) {
        ids.unite(split.referencedObjects());
    }
```

#### AUTO 


```{c}
auto cashflow = dynamic_cast<KMyMoneyCashFlowCombo*>(haveWidget("cashflow"));
```

#### AUTO 


```{c}
const auto row = model()->rowCount() - 1;
```

#### AUTO 


```{c}
auto money(amount);
```

#### AUTO 


```{c}
const auto leftData = sourceModel()->data(left, eMyMoney::Model::Roles::AccountDisplayOrderRole);
```

#### AUTO 


```{c}
const auto accountId = d->ui->assetAccountCombo->getSelected();
```

#### AUTO 


```{c}
const auto changed = d->m_storage->commitTransaction();
```

#### AUTO 


```{c}
const auto c = pattern[pos];
```

#### AUTO 


```{c}
auto const model = MyMoneyFile::instance()->accountsModel();
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::OnlineJob));
```

#### AUTO 


```{c}
const auto idx = m_model.index(row, 0);
```

#### AUTO 


```{c}
auto idx = splitModel.index(row, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
        if (idx.row() != lastRow) {
            lastRow = idx.row();
            if (d->firstSelectedId != idx.data(eMyMoney::Model::IdRole).toString()) {
                selectedJournalEntries += idx.data(eMyMoney::Model::IdRole).toString();
            } else {
                firstSelectedStillPresent = true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto count = m_file->institutionsModel()->processItems(&writer);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
    if (validateSelectedColumn(col, Column::CreditDebitIndicator)) {
      ui->m_creditIndicator->setDisabled(col == -1);
      ui->m_debitIndicator->setDisabled(col == -1);
      ui->m_oppositeSigns->setEnabled(col == -1);
      ui->labelBnk_opposite->setEnabled(col == -1);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& data: plugins) {
        QJsonArray editorsArray = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].toArray();
        for(QJsonValue entry: editorsArray) {
            if (!entry.toObject()["OnlineTaskIds"].isNull()) {
                list.append(onlineJobAdministration::onlineJobEditOffer{
                    data.fileName(),
                    KPluginMetaData::readTranslatedString(entry.toObject(), "Name")
                });
            }
        }
    }
```

#### AUTO 


```{c}
const auto reportsView = static_cast<KReportsView*>(viewBases[view]);
```

#### AUTO 


```{c}
auto progressBarIndex = 0;
```

#### AUTO 


```{c}
const auto indexes = d->securitiesModel->match(d->securitiesModel->index(0,0), eMyMoney::Model::IdRole, d->split.accountId(), 1, Qt::MatchFixedString);
```

#### AUTO 


```{c}
auto moduleName  = QFileInfo(nativeScriptFileInfo).baseName().toLocal8Bit();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(LedgerFilter);
        setStateFilter(static_cast<LedgerFilter::State>(idx));
    }
```

#### AUTO 


```{c}
const auto baseIdx = AccountsModel::mapToBaseSource(idx);
```

#### AUTO 


```{c}
const auto indexes = model->match(model->index(0, 0), Qt::UserRole, region, 1, Qt::MatchCaseSensitive | Qt::MatchRecursive | Qt::MatchWrap);
```

#### AUTO 


```{c}
const auto match(exp.match(name));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& row : qAsConst(qStack)) {
      if (!m_containsNonBaseCurrency && row[ctCurrency] != file->baseCurrency().id()) {
        m_containsNonBaseCurrency = true;
        break;
      }
    }
```

#### AUTO 


```{c}
auto i = (int)MyMoneyInstitution::Element::AccountID;
```

#### AUTO 


```{c}
auto t = MyMoneyFile::instance()->transaction((*it_t).transaction().id());
```

#### AUTO 


```{c}
auto r = MyMoneyXmlContentHandler2::readReport(m_baseNode);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPrinter* printer) {
                QPainter painter(printer);
                m_chartView->paint(&painter, painter.window());
            }
```

#### AUTO 


```{c}
const auto& sec
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : pPlugins.storage) {
    try {
      if (auto pStorage = plugin->open(url)) {
        MyMoneyFile::instance()->attachStorage(pStorage);
        d->m_storageInfo.type = plugin->storageType();
        if (plugin->storageType() != eKMyMoney::StorageType::GNC) {
          d->m_storageInfo.url = plugin->openUrl();
          writeLastUsedFile(url.toDisplayString(QUrl::PreferLocalFile));
          /* Don't use url variable after KRecentFilesAction::addUrl
         * as it might delete it.
         * More in API reference to this method
         */
          d->m_recentFiles->addUrl(url);
        }
        d->m_storageInfo.isOpened = true;
        break;
      }
    } catch (const MyMoneyException &e) {
      KMessageBox::detailedError(this, i18n("Cannot open file as requested."), QString::fromLatin1(e.what()));
      return false;
    }
  }
```

#### AUTO 


```{c}
const auto indexes = file->journalModel()->indexesByTransactionId(idx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("csvimporter.rc");
```

#### AUTO 


```{c}
auto filename = _filename;
```

#### AUTO 


```{c}
auto categoryId = cat->getSelected();
```

#### AUTO 


```{c}
auto memo = new KTextEdit;
```

#### AUTO 


```{c}
auto postDate = dynamic_cast<kMyMoneyDateInput*>(haveWidget("postdate"));
```

#### AUTO 


```{c}
auto caption = m_storageInfo.url.isEmpty() && m_myMoneyView && m_storageInfo.isOpened  ?
                   i18n("Untitled") :
                   m_storageInfo.url.fileName();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyTag::getAttrName(static_cast<MyMoneyTag::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto lastRow = lastIdx.row();
```

#### AUTO 


```{c}
auto cell = node->child(row, colTotalValue);
```

#### AUTO 


```{c}
const auto priceMatch(priceExp.match(*it_line));
```

#### AUTO 


```{c}
auto view = qobject_cast<SplitView*>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& pluginData : allPluginDatas)
    switch (KMyMoneyPlugin::pluginCategory(pluginData)) {
      case KMyMoneyPlugin::Category::StandardPlugin:
        standardPlugins.append(pluginData);
        break;
      case KMyMoneyPlugin::Category::PayeeIdentifier:
        payeePlugins.append(pluginData);
        break;
      case KMyMoneyPlugin::Category::OnlineBankOperations:
        onlinePlugins.append(pluginData);
        break;
      default:
        break;
    }
```

#### AUTO 


```{c}
auto precisionWidget = dynamic_cast<AmountEdit*>(w)
```

#### AUTO 


```{c}
auto postDateWidget = dynamic_cast<KMyMoneyDateInput*>(d->m_editWidgets["postdate"])
```

#### AUTO 


```{c}
const auto accountID = childIdx.data((int)eAccountsModel::Role::ID).toString();
```

#### AUTO 


```{c}
const auto idx = q->currentIndex();
```

#### AUTO 


```{c}
const auto existingAccount = file->subAccountByName(parentAccount, name);
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Payee));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : t.splits()) {
    auto acc = account(split.accountId());
    auto fraction = acc.fraction();
    if(fraction == -1) {
      auto sec = security(acc.currencyId());
      fraction = acc.fraction(sec);
    }
    // Don't do any rounding on a split factor
    if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::SplitShares)) {
      split.setShares(static_cast<const MyMoneyMoney>(split.shares().convertDenominator(fraction).canonicalize()));
      split.setValue(static_cast<const MyMoneyMoney>(split.value().convertDenominator(transactionFraction).canonicalize()));
    }
  }
```

#### AUTO 


```{c}
const auto accountIdx = MyMoneyFile::instance()->accountsModel()->indexById(accountId);
```

#### AUTO 


```{c}
const auto sAccount
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& pluginGroup : pluginGroups) {
        if (!pluginGroup.plugins.isEmpty()) {
            d->m_pluginSelector->addPlugins(pluginGroup.plugins,
                                            pluginGroup.loadMethod,
                                            pluginGroup.categoryName); // at that step plugin on/off state should be fetched automatically by KPluginSelector
            d->pluginInfos.append(pluginGroup.plugins);                // store initial on/off state to be able to enable/disable Apply button
        }
    }
```

#### AUTO 


```{c}
auto needLeadIn = fi.isFile();
```

#### AUTO 


```{c}
const auto index = model->indexById(accountId);
```

#### AUTO 


```{c}
auto customIconAbsolutePath = QStandardPaths::locate(QStandardPaths::AppDataLocation, customIconRelativePath);
```

#### AUTO 


```{c}
auto const model = file->accountsModel();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        validateSelectedColumn(col, Column::Number);
    }
```

#### AUTO 


```{c}
auto newDir = QFileDialog::getExistingDirectoryUrl(this, QString(), QUrl::fromLocalFile(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)));
```

#### AUTO 


```{c}
const auto leftData = sourceModel()->data(sourceModel()->index(left.row(), AccountsModel::Account, left.parent()), AccountsModel::AccountTotalValueRole);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : list) {
      const auto splits = transaction.splits();
      for (const auto& split : splits) {
        if (split.accountId().compare(id) != 0)
          continue;
        else if (split.action().compare(MyMoneySplit::actionName(eMyMoney::Split::Action::SplitShares)) == 0)
          balance *= split.shares();
        else
          balance += split.shares();
      }
    }
```

#### AUTO 


```{c}
const auto currencyList = file->availableCurrencyList();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt) {
        if (txt.isEmpty()) {
            d->ui->categoryCombo->setSelected(QString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto option : opts) {
        option = option.trimmed();
        if (option.startsWith(QLatin1String("QSQLITE_BUSY_TIMEOUT"))) {
            option = option.mid(20).trimmed();
            if (option.startsWith(QLatin1Char('='))) {
                bool ok;
                const int nt = option.mid(1).trimmed().toInt(&ok);
                if (ok)
                    timeOut = nt;
            }
        } else if (option == QLatin1String("QSQLITE_OPEN_READONLY")) {
            openReadOnlyOption = true;
        } else if (option == QLatin1String("QSQLITE_OPEN_URI")) {
            openUriOption = true;
        } else if (option == QLatin1String("QSQLITE_ENABLE_SHARED_CACHE")) {
            sharedCache = true;
        }
#ifndef QT_NO_REGULAREXPRESSION
        else if (option.startsWith(regexpConnectOption)) {
            option = option.mid(regexpConnectOption.size()).trimmed();
            if (option.isEmpty()) {
                defineRegexp = true;
            } else if (option.startsWith(QLatin1Char('='))) {
                bool ok = false;
                const int cacheSize = option.mid(1).trimmed().toInt(&ok);
                if (ok) {
                    defineRegexp = true;
                    if (cacheSize > 0)
                        regexpCacheSize = cacheSize;
                }
            }
        }
#endif
    }
```

#### AUTO 


```{c}
auto netValue = false;
```

#### AUTO 


```{c}
auto pageCount = 0;
```

#### AUTO 


```{c}
const auto cid = idx.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto baseCurrency = file->baseCurrency();
```

#### AUTO 


```{c}
const auto variantReport = reportsPlugin->requestData(args, eWidgetPlugin::WidgetType::NetWorthForecastWithArgs);
```

#### AUTO 


```{c}
auto acc = d->m_accountList[id];
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto institution : list) {
    const auto idx = index(row, 0);
    static_cast<TreeItem<MyMoneyInstitution>*>(idx.internalPointer())->dataRef() = institution;
    d->loadAccounts(idx, institution.accountList());
    ++row;
  }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyTransactionPrivate::getElName(static_cast<Transaction::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->ui.m_reportTabWidget->widget(index))
```

#### AUTO 


```{c}
const auto bic = payeeIdentifier->fullStoredBic();
```

#### AUTO 


```{c}
auto account = model->data(source_index, AccountsModel::AccountRole).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto status = static_cast<eIBANBIC::bicAllocationStatus>(plugin->requestData(bic, eIBANBIC::DataType::isBicAllocated).toInt());
```

#### AUTO 


```{c}
const auto widgetName = focusWidget()->parentWidget()->objectName();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyReport::getElName(static_cast<MyMoneyReport::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
auto user2Button = new QPushButton;
```

#### AUTO 


```{c}
auto tmpBegin = dateRange.firstTransaction;
```

#### AUTO 


```{c}
const auto &kpartgui = QStringLiteral("file_export_qif");
```

#### AUTO 


```{c}
auto it = iconNames.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto account : list) {
    result[account.id()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
  }
```

#### AUTO 


```{c}
auto item = dynamic_cast<KBudgetListItem*>(d->ui->m_budgetList->itemAt(p));
```

#### AUTO 


```{c}
auto total = dynamic_cast<QLabel*>(haveWidget("total"));
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->m_reportTabWidget->currentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pluginPath) {
            KPluginMetaData metadata(pluginPath);
            qDebug() << "Located plugin" << pluginPath << "Validity" << metadata.isValid();
        }
```

#### AUTO 


```{c}
const auto hashBase(QStringLiteral("%1-%2").arg(t.m_datePosted.toString(Qt::ISODate)).arg(h, 7, 16, QLatin1Char('0')));
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Budget>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto scriptResourceName = ":/plugins/woob/kmymoneywoob.py";
```

#### AUTO 


```{c}
auto cashflow = dynamic_cast<KMyMoneyCashFlowCombo*>(*it_w);
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("weboob");
```

#### AUTO 


```{c}
const auto accIdx = file->accountsModel()->indexById(accountId);
```

#### AUTO 


```{c}
auto factory = loader.factory();
```

#### AUTO 


```{c}
auto it = columns.cbegin();
```

#### AUTO 


```{c}
const auto childIdx = index.child(i, 0);
```

#### AUTO 


```{c}
const auto& sAccountId
```

#### AUTO 


```{c}
auto itParentAcc = d->itemFromId(this, acc.parentAccountId(), Role::InvestmentID);
```

#### AUTO 


```{c}
auto items = d->m_tocTreeWidget->selectedItems();
```

#### AUTO 


```{c}
auto valueWidget = d->haveWidget<AmountEdit*>(amount)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
    // the following line will throw an exception if the
    // account does not exist
    auto acc = MyMoneyFile::account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION_CSTRING("Cannot store split with no account assigned");
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION_CSTRING("Cannot store split referencing standard account");
    if (acc.isLoan() && (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer)))
      loanAccountAffected = true;
    if (!split.payeeId().isEmpty()) {
      if (payee(split.payeeId()).id().isEmpty()) {
        throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing unknown payee");
      }
    }
    foreach (const auto tagId, split.tagIdList()) {
      if (!tagId.isEmpty())
        tag(tagId);
    }
  }
```

#### AUTO 


```{c}
const auto& schedule = static_cast<TreeItem<MyMoneySchedule>*>(idx.internalPointer())->constDataRef();
```

#### AUTO 


```{c}
const auto cnt = idx.data(eMyMoney::Model::TransactionSplitCountRole).toInt();
```

#### AUTO 


```{c}
auto account = filteredAccounts.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : tagList) {
                if (d->tagInList(selectedTags, tag)) {
                    used_reports.push_back(report);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
      if (plugin->formatName().compare(QLatin1String("GNC")) == 0) {
        pReader = plugin->reader();
        break;
      }
    }
```

#### AUTO 


```{c}
const auto menuType = d->updateDynamicActions();
```

#### AUTO 


```{c}
auto fileType = dlg->fileType();
```

#### AUTO 


```{c}
auto institutionItem = static_cast<InstitutionsPrivate *>(d)->institutionItemFromId(this, institution.id());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const SelectedObjects& selections) {
    Q_D(KMyMoneyViewBase);
    d->m_selections = selections;
  }
```

#### AUTO 


```{c}
auto txt = acc.value(QStringLiteral("lastStatementDate"));
```

#### AUTO 


```{c}
const auto& budget
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Tag>(i)).isEmpty();
```

#### AUTO 


```{c}
auto changed = d->m_storage->commitTransaction();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            query.bindValue(":id", obj.idString());
            query.bindValue(":countryCode", payeeIdentifier->country());
            query.bindValue(":accountNumber", payeeIdentifier->accountNumber());
            query.bindValue(":bankCode", (payeeIdentifier->bankCode().isEmpty()) ? QVariant(QVariant::String) : payeeIdentifier->bankCode());
            query.bindValue(":name", payeeIdentifier->ownerName());
            if (!query.exec()) { // krazy:exclude=crashy
                qWarning("Error while saving national account number for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
                return false;
            }
            return true;

        }
```

#### AUTO 


```{c}
auto pageStack = qobject_cast<QStackedWidget*>(w);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @todo add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      // case eMyMoney::File::Object::Currency:
      // case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
auto newCategory = file->account(categoryId);
```

#### AUTO 


```{c}
auto selectWidget = [&](QWidget* w) {
        if (w) {
            // if we point to a contructed widget (e.g. ButtonBox) we
            // need to select the last widget if going backward
            if (reason == Qt::BacktabFocusReason && !w->findChildren<QWidget*>().isEmpty()) {
                auto parent = w;
                while (w->nextInFocusChain()->parentWidget() == parent) {
                    w = w->nextInFocusChain();
                }
            }
            w->setFocus(reason);
        }
    };
```

#### AUTO 


```{c}
auto accountsItem = new QStandardItem(accountName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : d->m_actions) {
        d->m_actionCollection->removeAction(action);
    }
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::ScheduleTX));
```

#### AUTO 


```{c}
const auto commodity = MyMoneyFile::instance()->security(transaction.commodity());
```

#### AUTO 


```{c}
auto editor = new MyMoneyQifProfileEditor(true, this);
```

#### AUTO 


```{c}
const auto price = file->price(acc.currencyId(), base.id());
```

#### AUTO 


```{c}
const auto rows = m_rows.count();
```

#### AUTO 


```{c}
auto addCellToRow = [&, newColPos](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          childItem->insertColumns(newColPos, 1);
          if (childItem->hasChildren())
            self(self, childItem);
          d->setAccountData(item, j, childItem->data((int)Role::Account).value<MyMoneyAccount>(), QList<Column> {column});
        }
        return true;
      };
```

#### AUTO 


```{c}
auto strPrice = QVariant(price.rate(tradingCurrency.id()).formatMoney(tradingCurrency.tradingSymbol(), prec));
```

#### AUTO 


```{c}
auto rc = eDialogs::ScheduleResultCode::Cancel;
```

#### AUTO 


```{c}
const auto acc = d->accountsModel.itemByIndex(accIdx);
```

#### AUTO 


```{c}
auto schedules = file->scheduleList(acc.id(), eMyMoney::Schedule::Type::Any, eMyMoney::Schedule::Occurrence::Any, eMyMoney::Schedule::PaymentType::Any, QDate(), QDate(), true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& testInstitution : list) {
            if (testInstitution.name() == institution) {
                acc.setInstitutionId(testInstitution.id());
                break;
            }
        }
```

#### AUTO 


```{c}
auto feeAmount = dynamic_cast<KMyMoneyEdit*>(haveWidget("fee-amount"));
```

#### AUTO 


```{c}
auto txn = tr;
```

#### AUTO 


```{c}
auto abort = false;
```

#### AUTO 


```{c}
auto statjob = KIO::statDetails(file(), KIO::StatJob::SourceSide, KIO::StatNoDetails);
```

#### AUTO 


```{c}
const auto model = d->ui->paymentMethodCombo->model();
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneySchedulePrivate *>(right.d_func());
```

#### AUTO 


```{c}
const auto payee = index.data(eMyMoney::Model::SplitPayeeRole).toString();
```

#### AUTO 


```{c}
auto widget = dynamic_cast<const KMyMoneyEdit*>(*it_w)
```

#### AUTO 


```{c}
const auto idx = index(row, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& indicator) {
        m_profile->m_creditIndicator = indicator;
        emit completeChanged();
    }
```

#### AUTO 


```{c}
const auto& entry
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->accountsModel()->itemById(split.accountId());
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->ui.m_reportTabWidget->widget(i));
```

#### AUTO 


```{c}
const auto idx = d->ui->m_accountTree->currentIndex();
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->account(split.accountId());
```

#### AUTO 


```{c}
auto numberOfColumns = m_forecast.forecastDays() / m_forecast.accountsCycle();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        const auto idx = d->m_popupView->currentIndex();
        if (d->m_lastSelectedAccount.isEmpty() && idx.isValid()) {
            selectItem(idx);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits3)
    d->addCacheNotification(split.accountId(), tCopy.postDate());
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyAccountPrivate *>(right.d_func());
```

#### AUTO 


```{c}
auto legendRows = legendTotal.values();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
                    // create a copy of the splits list in the transaction
                    // loop over all splits
                    for (auto split : transaction.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (int i = 0; i < tagIdList.size(); ++i) {
                            // if the split is assigned to one of the selected tags, we need to modify it
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (tagIdList.indexOf(tag_id) == -1)
                                    tagIdList.append(tag_id);
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList); // first modify tag list in current split
                        // then modify the split in our local copy of the transaction list
                        transaction.modifySplit(split); // this does not modify the list object 'splits'!
                    } // for - Splits
                    file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
                }
```

#### AUTO 


```{c}
auto amount = dynamic_cast<AmountEdit*>(d->m_editWidgets["amount"])
```

#### AUTO 


```{c}
auto tmpEnd = dateRange.lastTransaction;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
        list.append(qMakePair(journalEntry.transaction(), split));
      }
```

#### AUTO 


```{c}
const auto journalIdx = file->journalModel()->indexById(journalId);
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->account(assetId);
```

#### AUTO 


```{c}
const auto accountIdx = MyMoneyFile::instance()->accountsModel()->indexById(split.accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto buttonInfo : d->m_sharedActionButtons) {
                buttonInfo.button->setDefaultAction(buttonInfo.defaultAction);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& view : d->viewBases.keys()) {
        if (view == currentView)
            continue;
        d->viewBases[view]->updateActions(selections);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const MyMoneySecurity& c1, const MyMoneySecurity& c2)
    {
        const bool c1Metal = c1.tradingSymbol().startsWith(QLatin1Char('X')) && metalSymbols.contains(c1.tradingSymbol());
        const bool c2Metal = c2.tradingSymbol().startsWith(QLatin1Char('X')) && metalSymbols.contains(c2.tradingSymbol());
        if (c1Metal ^ c2Metal)
            return c2Metal;

        return c1.name().compare(c2.name()) < 0;
    }
```

#### AUTO 


```{c}
auto anonymous = false;
```

#### AUTO 


```{c}
auto rc = true;
```

#### AUTO 


```{c}
const auto rowIndeces =
            MyMoneyFile::instance()->journalModel()->indexesByTransactionId(index.data(eMyMoney::Model::Roles::JournalTransactionIdRole).toString());
```

#### AUTO 


```{c}
auto firstAccNumber = filteredAccounts.at(0).number();
```

#### AUTO 


```{c}
auto i = (int)Institution::Attribute::ID;
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPrinter* printer) {
            Q_D(KHomeView);
            d->m_view->print(printer);
        }
```

#### AUTO 


```{c}
auto i = (int)Element::Transaction::Split;
```

#### AUTO 


```{c}
const auto endRow = row + rows;
```

#### AUTO 


```{c}
auto parentAccountItem = d->itemFromAccountId(this, account->parentAccountId());
```

#### AUTO 


```{c}
const auto indexList = m_securitiesProxyModel->match(m_securitiesProxyModel->index(0, 0), Qt::DisplayRole, QLatin1String("Securities"), 1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchWrap));
```

#### AUTO 


```{c}
auto tabbar = dynamic_cast<KMyMoneyTransactionForm::TabBar*>(w);
```

#### AUTO 


```{c}
auto mdl = qobject_cast<KRecursiveFilterProxyModel *>(model());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &idx : indexes) {
    if(d->showValuesInverted) {
      balance -= idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
    } else {
      balance += idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
    }
    const auto dispIndex = index(idx.row(), JournalModel::Column::Balance);
    setData(dispIndex, QVariant::fromValue(balance), Qt::DisplayRole);
  }
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney/onlinetasks", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
    });
```

#### AUTO 


```{c}
auto i = (int)Institution::Element::AccountID;
```

#### AUTO 


```{c}
const auto tradingCurrencySymbol = tradingCurrencyIdx.data(eMyMoney::Model::SecuritySymbolRole).toString();
```

#### AUTO 


```{c}
auto triggerAction = [&](eMenu::Action action, const QString& id) {
        pActions[action]->setData(id);
        emit requestActionTrigger(action);
    };
```

#### AUTO 


```{c}
const auto ixRow = sourceModel()->index(source_row, EquitiesModel::Equity, source_parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : account.accountList()) {
    this->account(accountId);
  }
```

#### AUTO 


```{c}
const auto subAccountId = parentAccount.accountList().at(row);
```

#### AUTO 


```{c}
auto sp = t.splitById((*it_t).split().id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits) {
      if (needAccountMatch || needCategoryMatch) {
        auto removeSplit = true;
        if (d->m_considerCategory) {
          switch (file->account(s.accountId()).accountGroup()) {
            case eMyMoney::Account::Type::Income:
            case eMyMoney::Account::Type::Expense:
              isTransfer = false;
              // check if the split references one of the categories in the list
              if (needCategoryMatch) {
                if (d->m_categories.isEmpty()) {
                  // we're looking for transactions with 'no' categories
                  d->m_matchingSplitsCount = 0;
                  matchingSplits.clear();
                  return matchingSplits;
                } else if (d->m_categories.contains(s.accountId())) {
                  categoryMatched = true;
                  removeSplit = false;
                }
              }
              break;

            default:
              // check if the split references one of the accounts in the list
              if (!filter.testFlag(accountFilterActive)) {
                removeSplit = false;
              } else if (!d->m_accounts.isEmpty() &&
                         d->m_accounts.contains(s.accountId())) {
                accountMatched = true;
                removeSplit = false;
              }

              break;
          }

        } else {
          if (!filter.testFlag(accountFilterActive)) {
            removeSplit = false;
          } else if (!d->m_accounts.isEmpty() &&
                     d->m_accounts.contains(s.accountId())) {
            accountMatched = true;
            removeSplit = false;
          }
        }

        if (removeSplit)
          continue;
      }

      // check if less frequent filters are active
      if (extendedFilter != 0) {
        const auto acc = file->account(s.accountId());
        if (!(matchAmount(s) && matchText(s, acc)))
          continue;

        // Determine if this account is a category or an account
        auto isCategory = false;
        switch (acc.accountGroup()) {
          case eMyMoney::Account::Type::Income:
          case eMyMoney::Account::Type::Expense:
            isCategory = true;
          default:
            break;
        }

        bool includeSplit = d->m_considerCategorySplits || (!d->m_considerCategorySplits && !isCategory);
        if (includeSplit) {
          // check the payee list
          if (filter.testFlag(payeeFilterActive)) {
            if (!d->m_payees.isEmpty()) {
              if (s.payeeId().isEmpty() || !d->m_payees.contains(s.payeeId()))
                continue;
            } else if (!s.payeeId().isEmpty())
              continue;
          }

          // check the tag list
          if (filter.testFlag(tagFilterActive)) {
            const auto tags = s.tagIdList();
            if (!d->m_tags.isEmpty()) {
              if (tags.isEmpty()) {
                continue;
              } else {
                auto found = false;
                for (const auto& tag : tags) {
                  if (d->m_tags.contains(tag)) {
                    found = true;
                    break;
                  }
                }

                if (!found)
                  continue;
              }
            } else if (!tags.isEmpty())
              continue;
          }

          // check the type list
          if (filter.testFlag(typeFilterActive) &&
              !d->m_types.isEmpty() &&
              !d->m_types.contains(splitType(transaction, s, acc)))
            continue;

          // check the state list
          if (filter.testFlag(stateFilterActive) &&
              !d->m_states.isEmpty() &&
              !d->m_states.contains(splitState(s)))
            continue;

          if (filter.testFlag(nrFilterActive) &&
              ((!d->m_fromNr.isEmpty() && s.number() < d->m_fromNr) ||
               (!d->m_toNr.isEmpty() && s.number() > d->m_toNr)))
            continue;

        } else if (filter & (payeeFilterActive | tagFilterActive | typeFilterActive | stateFilterActive | nrFilterActive)) {
          continue;
        }
      }
      if (d->m_reportAllSplits)
        matchingSplits.append(s);

      isMatchingSplitsEmpty = false;
    }
```

#### AUTO 


```{c}
auto w = topLevelWidget->findChild<QWidget*>(tabOrder.at(idx));
```

#### AUTO 


```{c}
auto shareEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("shares"))
```

#### AUTO 


```{c}
auto accountId = modelIdx.data(eMyMoney::Model::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : transaction.splits()) {
                if (!split.shares().isZero()) {
                    auto acc = file->account(split.accountId());
                    if (q->isForecastAccount(acc)) {
                        dailyBalances balance;
                        balance = m_accountList[acc.id()];
                        //if it is income, the balance is stored as negative number
                        if (acc.accountType() == eMyMoney::Account::Type::Income) {
                            balance[transaction.postDate()] += (split.shares() * MyMoneyMoney::MINUS_ONE);
                        } else {
                            balance[transaction.postDate()] += split.shares();
                        }
                        m_accountList[acc.id()] = balance;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto accountId = selections.firstSelection(SelectedObjects::Account);
```

#### AUTO 


```{c}
const auto sacc = MyMoneyFile::account(acc);
```

#### AUTO 


```{c}
auto idx = sourceModel()->index(source_row, 0, source_parent);
```

#### AUTO 


```{c}
const auto rows = viewModel->rowCount();
```

#### AUTO 


```{c}
const auto& tSplit
```

#### AUTO 


```{c}
auto accountBalance(onlineBalanceValue);
```

#### AUTO 


```{c}
const auto vatAccount = itemById(account.value("VatAccount"));
```

#### AUTO 


```{c}
const auto startIdx = firstIndexById(t.id());
```

#### AUTO 


```{c}
auto transaction = QSharedPointer<MyMoneyTransaction>(new MyMoneyTransaction(*it));
```

#### AUTO 


```{c}
auto adjustToContainer = [&](const char* containerClass, const char* widgetClass) {
        if (focusWidget->qt_metacast(widgetClass) && focusWidget->parentWidget()->qt_metacast(containerClass) && (reason == Qt::BacktabFocusReason)) {
            if (focusWidget->previousInFocusChain() == focusWidget->parentWidget()) {
                focusWidget = focusWidget->parentWidget();
            }
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const onlineTask* task : qAsConst(m_onlineTasks)) {
                // Check if a online task has the correct type
                if (dynamic_cast<const creditTransfer*>(task) != 0) {
                    for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
                        if (plugin->availableJobs(account.id()).contains(task->taskName()))
                            return true;
                    }
                }
            }
```

#### AUTO 


```{c}
auto accountItem = d->itemFromAccountId(this, account->id());
```

#### AUTO 


```{c}
auto t = dynamic_cast<KMyMoneyRegister::Transaction*>(registerItem)
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        validateSelectedColumn(col, Column::Amount);
    }
```

#### AUTO 


```{c}
auto tid = file->openingBalanceTransaction(account);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->editSplits();
    }
```

#### AUTO 


```{c}
const auto txt = columnIndex.data().toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            const auto journalEntry = file->journalModel()->itemById(journalEntryId);
            auto t = journalEntry.transaction();
            auto s = journalEntry.split();
            if (t.isImported()) {
                t.setImported(false);
                s.setReconcileFlag(eMyMoney::Split::State::Cleared);
                t.modifySplit(s);
                file->modifyTransaction(t);
            }
            TransactionMatcher matcher;
            matcher.accept(t, s);
        }
```

#### AUTO 


```{c}
const auto isFileNotSaved = q->actionCollection()->action(QString::fromLatin1(KStandardAction::name(KStandardAction::Save)))->isEnabled();
```

#### AUTO 


```{c}
auto colCount = colList.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : selection) {
      payeeIds.append(payee.id());
    }
```

#### AUTO 


```{c}
auto h = MyMoneyTransaction::hash(t_in.m_strPayee.trimmed());
```

#### AUTO 


```{c}
auto i = (int)MyMoneyPayee::Element::Address;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const SplitModel* model) {
        const auto rows = model->rowCount();
        for (int row = 0; row < rows; ++row) {
            const auto index = model->index(row, 0);
            accountIds << index.data(eMyMoney::Model::SplitAccountIdRole).toString();
        }
    }
```

#### AUTO 


```{c}
const auto rows = feeSplitModel.rowCount();
```

#### AUTO 


```{c}
auto itInstitution = new QStandardItem(Icons::get(Icon::ViewInstitutions), institution.name());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int costCenterIndex) {
        d->costCenterChanged(costCenterIndex);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& testInstitution : list) {
      if (testInstitution.name() == institution) {
        acc.setInstitutionId(testInstitution.id());
        break;
      }
    }
```

#### AUTO 


```{c}
const auto isSuccessfullyOpened = QSqlDatabase::open();
```

#### AUTO 


```{c}
const auto& tagId
```

#### AUTO 


```{c}
const auto currencyMatch(currencyExp.match(it->name()));
```

#### AUTO 


```{c}
auto categoryWidget = dynamic_cast<KMyMoneyCategory*>(d->m_editWidgets["category"]);
```

#### AUTO 


```{c}
auto chosenFileType = eKMyMoney::StorageType::None;
```

#### AUTO 


```{c}
auto split = _split;
```

#### AUTO 


```{c}
auto entryDate = QDate::fromString(node.attribute(attributeName(Attribute::Transaction::EntryDate)),Qt::ISODate);
```

#### AUTO 


```{c}
auto w = dynamic_cast<QLabel*>(haveWidget(idx));
```

#### AUTO 


```{c}
auto dlg = new KSettingsKMyMoney(this, "KMyMoney-Settings", KMyMoneyGlobalSettings::self());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& name : qAsConst(widgetIds)) {
    auto w = d->haveWidget<QWidget>(name);
    if (w) {
      w->setVisible(visible);
    } else {
      qCritical() << "Activity::setWidgetVisibility unknown widget" << name;
    }
  }
```

#### AUTO 


```{c}
auto m1 = MyMoneyMoney("1.12345678921234567893123");
```

#### AUTO 


```{c}
const auto ixAccount = mapToSource(BudgetViewProxyModel::index(index.row(), static_cast<int>(Column::Account), index.parent()));
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySplitPrivate::getElName(static_cast<Split::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
auto value = new AmountEdit;
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->accountsModel()->itemById(accountId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
                const auto acc = file->account(split.accountId());
                if (acc.isIncomeExpense()) {
                    if (split.shares().isNegative() ^ fees) {
                        if (rc.isEmpty()) {
                            rc = MyMoneyFile::instance()->accountsModel()->accountIdToHierarchicalName(split.accountId());
                        } else {
                            return fees ? i18n("Multiple fee categories") : i18n("Multiple interest categories");
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
const auto& mimeTypeName
```

#### AUTO 


```{c}
auto toBeClosedAccID = makeAccount("EasyAccount", "123456789", MyMoneyAccount::Investment, QDate(2017, 8, 1), file->asset().id());
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString tagId) { return MyMoneyFile::instance()->tagsModel()->itemById(tagId).name(); }
```

#### AUTO 


```{c}
const auto amount = d->m_editor->transactionAmount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& budget : d->m_budgetList)
      file->removeBudget(budget);
```

#### AUTO 


```{c}
const auto indexes = filterModel->match(start, (int)eLedgerModel::Role::AccountId, account.id(), -1);
```

#### AUTO 


```{c}
auto baseIdx = AccountsModel::mapToBaseSource(idx);
```

#### AUTO 


```{c}
const auto dlg_d = d->m_dialog->d_func();
```

#### AUTO 


```{c}
auto cb = d->m_tabRowColPivot->ui->m_checkTransfers;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotDuplicateTransaction(); }
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(source_row, AccountsModel::Column::AccountName, source_parent);
```

#### AUTO 


```{c}
auto const model = sourceModel();
```

#### AUTO 


```{c}
auto parent = m_storage->asset();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int value) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        d->m_schedule.setNextDueDate(d->transactionEditor->postDate());
        d->setScheduleOccurrencePeriod();
        d->m_schedule.setOccurrenceMultiplier(d->ui->frequencyNoEdit->value());

        if (d->m_schedule.transactionsRemaining() != value) {
            QSignalBlocker blocked(d->ui->finalPaymentDateEdit);
            d->ui->finalPaymentDateEdit->setDate(d->m_schedule.dateAfter(value));
        }
    }
```

#### AUTO 


```{c}
const auto& frame
```

#### AUTO 


```{c}
const auto report = action->data().value<MyMoneyReconciliationReport>();
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Schedule>(i)).isEmpty();
```

#### AUTO 


```{c}
auto findFirstOrLastVisible = [&](firstOrLastVisible type) {
        const int ofs = (type == FirstVisible) ? 1 : -1;
        int idx = (type == FirstVisible) ? 0 : tabOrder.count() - 1;
        for (; idx >= 0 && idx < tabOrder.count(); idx += ofs) {
            auto w = topLevelWidget->findChild<QWidget*>(tabOrder.at(idx));
            // in case of embedded transaction editors, we may search
            // for a widget that is known to the parent
            if (!w) {
                auto parent = topLevelWidget->parentWidget();
                while (true) {
                    w = parent->findChild<QWidget*>(tabOrder.at(idx));
                    if (!w && qobject_cast<QGroupBox*>(parent)) {
                        parent = parent->parentWidget();
                        continue;
                    }
                    break;
                }
            }
            if (w && w->isVisible() && w->isEnabled()) {
                return w;
            }
        }
        return static_cast<QWidget*>(nullptr);
    };
```

#### AUTO 


```{c}
const auto fileInfo = QFileInfo(QStandardPaths::locate(QStandardPaths::GenericDataLocation, "kmymoney/weboob/kmymoneyweboob.py"));
```

#### AUTO 


```{c}
const auto tagsCount = tags.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits3)
        d->addCacheNotification(split.accountId(), tCopy.postDate());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& view : d->viewBases.keys()) {
        if (view == currentView)
            break;
        d->viewBases[view]->updateActions(selections);
    }
```

#### AUTO 


```{c}
const auto dateEdit = d->transactionEditor->findChild<QWidget*>("dateEdit");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
    if (plugin->formatName().compare(format) == 0) {
      rc = plugin->save(d->m_fileName);
      pluginFound = true;
      break;
    }
  }
```

#### AUTO 


```{c}
const auto newParentid = MyMoneyAccount::stdAccName(static_cast<eMyMoney::Account::Standard>((*ita).accountGroup()));
```

#### AUTO 


```{c}
const auto view = qobject_cast<KMyMoneyViewBase*>(previous->widget());
```

#### AUTO 


```{c}
auto cat = d->haveWidget<KMyMoneyCategory*>("asset-account");
```

#### AUTO 


```{c}
auto next = ui->m_selectedList->item(ui->m_selectedList->row(item) + 1);
```

#### AUTO 


```{c}
const auto accountBalance = MyMoneyFile::instance()->balance(index.data(eMyMoney::Model::IdRole).toString(), onlineBalanceDate);
```

#### LAMBDA EXPRESSION 


```{c}
[&](eMenu::Action action, QAction* newAction) {
        if (d->m_sharedActionButtons.contains(action) && newAction) {
            d->m_sharedActionButtons.value(action).button->setDefaultAction(newAction);
        } else {
            for (auto buttonInfo : d->m_sharedActionButtons) {
                buttonInfo.button->setDefaultAction(buttonInfo.defaultAction);
            }
        }
    }
```

#### AUTO 


```{c}
const auto idx = d->institutionsModel.indexById(institution.id());
```

#### AUTO 


```{c}
const auto currency = MyMoneyFile::instance()->currency(account.currencyId());
```

#### LAMBDA EXPRESSION 


```{c}
[](MyMoneyAccount &a1, MyMoneyAccount &a2) {return a1.name() < a2.name();}
```

#### AUTO 


```{c}
const auto rows = q->rowCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entry : list) {
            txt += QString("%1, ").arg(entry+1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*transaction).splits()) {
        const JournalEntry journalEntry(QString("%1-%2").arg(key, split.id()), transaction, split);
        const auto newIdx = index(startRow, 0);
        static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer())->dataRef() = journalEntry;
        if (m_idToItemMapper) {
            m_idToItemMapper->insert(journalEntry.id(), static_cast<TreeItem<JournalEntry>*>(newIdx.internalPointer()));
        }

        ++startRow;
    }
```

#### AUTO 


```{c}
const auto model = ui->m_ledgerView->model();
```

#### AUTO 


```{c}
auto ret = false;
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
          if (!KGPGFile::keyAvailable(key)) {
            KMessageBox::sorry(q, i18n("<p>You have specified to encrypt your data for the user-id</p><p><center><b>%1</b>.</center></p><p>Unfortunately, a valid key for this user-id was not found in your keyring. Please make sure to import a valid key for this user-id. This time, encryption is disabled.</p>", key), i18n("GPG Key not found"));
            encryptFile = false;
            break;
          }
        }
```

#### AUTO 


```{c}
auto i = (int)MyMoneyAccount::Element::SubAccount;
```

#### AUTO 


```{c}
auto rc = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accStr : accountList) {
      const auto acc = d->m_file->account(accStr);

      auto item = new QStandardItem(acc.name());
      accountsItem->appendRow(item);
      item->setEditable(false);
      auto subaccountsStr = acc.accountList();
      // filter out stocks with zero balance if requested by user
      for (auto subaccStr = subaccountsStr.begin(); subaccStr != subaccountsStr.end();) {
        const auto subacc = d->m_file->account(*subaccStr);
        if (subacc.isInvest() && KMyMoneySettings::hideZeroBalanceEquities() && subacc.balance().isZero())
          subaccStr = subaccountsStr.erase(subaccStr);
        else
          ++subaccStr;
      }

      // adding subaccounts (e.g. stocks under given investment account) belonging to given account
      d->loadSubaccounts(item, favoriteAccountsItem, subaccountsStr);
      const auto row = item->row();
      d->setAccountData(accountsItem, row, acc, d->m_columns);
      d->loadPreferredAccount(acc, accountsItem, row, favoriteAccountsItem);
    }
```

#### AUTO 


```{c}
auto flags = QAbstractItemModel::flags(index) | Qt::ItemIsDragEnabled;
```

#### AUTO 


```{c}
auto parentAccount = file->account(d->m_currentCategory.parentAccountId());
```

#### AUTO 


```{c}
const auto widgetCount = m_widgetList.count();
```

#### AUTO 


```{c}
const auto idAcc = sourceModel()->data(ixRow, EquitiesModel::EquityID).toString();
```

#### AUTO 


```{c}
auto term = 1;
```

#### AUTO 


```{c}
const auto driverName = this->driverName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @todo add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      // case eMyMoney::File::Object::Currency:
      // case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
      case eMyMoney::File::Object::Transaction:
      // case eMyMoney::File::Object::Price:
      // case eMyMoney::File::Object::Parameter:
      case eMyMoney::File::Object::OnlineJob:
      // case eMyMoney::File::Object::Report:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { writeConfig(); accept(); }
```

#### AUTO 


```{c}
const auto text = i18n(MyMoneySchedule::occurrenceToString(occurrence));
```

#### AUTO 


```{c}
const auto idx = sec->model()->index(sec->currentIndex(), 0);
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(i, AccountsModel::Column::AccountName, source);
```

#### AUTO 


```{c}
auto reader = new MyMoneyStatementReader;
```

#### AUTO 


```{c}
auto secondAccNumber = filteredAccounts.at(i).number();
```

#### AUTO 


```{c}
auto security = MyMoneyFile::instance()->security(d->m_currentEquity.currencyId());
```

#### AUTO 


```{c}
const auto editItem = menu->addAction(Icons::get(Icons::Icon::DocumentEdit), i18nc("@item:inmenu Edit a split", "Edit..."), q, [&]() {
            q->edit(idx);
        });
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool checked) {
        m_profile->m_oppositeSigns = checked;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& paymentMethod : paymentMethods) {
            const auto text = i18n(MyMoneySchedule::paymentMethodToString(paymentMethod));
            paymentMethodToRowMap.insert(paymentMethod, row);
            rowToPaymentMethodMap.insert(row, paymentMethod);
            q->setData(q->index(row++, 0), text, Qt::DisplayRole);
        }
```

#### AUTO 


```{c}
auto priceEntry = static_cast<TreeItem<PriceEntry>*>(index(row, 0).internalPointer())->data();
```

#### AUTO 


```{c}
const auto action = qobject_cast<QAction*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : pPlugins.storage) {
    try {
      if (plugin->open(url)) {
        d->m_storageInfo.type = plugin->storageType();
        if (plugin->storageType() != eKMyMoney::StorageType::GNC) {
          d->m_storageInfo.url = plugin->openUrl();
          writeLastUsedFile(url.toDisplayString(QUrl::PreferLocalFile));
          /* Don't use url variable after KRecentFilesAction::addUrl
         * as it might delete it.
         * More in API reference to this method
         */
          d->m_recentFiles->addUrl(url);
        }
        d->m_storageInfo.isOpened = true;
        break;
      }
    } catch (const MyMoneyException &e) {
      KMessageBox::detailedError(this, i18n("Cannot open file as requested."), QString::fromLatin1(e.what()));
      return false;
    }
  }
```

#### AUTO 


```{c}
auto status = dynamic_cast<KMyMoneyReconcileCombo*>(d->m_editWidgets["status"]);
```

#### AUTO 


```{c}
const auto model = d->ui->m_onlineJobView->model();
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(otherSplit.accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
          // create a copy of the splits list in the transaction
          // loop over all splits
          for (auto split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); ++i) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (d->tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          } // for - Splits
          file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
        }
```

#### AUTO 


```{c}
const auto indexes = d->m_filterModel->match(d->m_filterModel->index(0, 0),
                                                   eMyMoney::Model::IdRole,
                                                   QVariant(sch.id()),
                                                   1,
                                                   Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : m_valueChanges) {
        if (!removedObjects.contains(id)) {
            changed = true;
            emit valueChanged(account(id));
        }
    }
```

#### AUTO 


```{c}
auto postdateWidget = dynamic_cast<KMyMoneyDateInput*>(d->m_editWidgets["postdate"])
```

#### AUTO 


```{c}
auto report
```

#### AUTO 


```{c}
auto itAccount = d->itemFromAccountId(this, id);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
                    // create copy of transaction in current schedule
                    auto trans = schedule.transaction();
                    // create copy of lists of splits
                    for (auto& split : trans.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (auto i = 0; i < tagIdList.size(); ++i) {
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (tagIdList.indexOf(tag_id) == -1)
                                    tagIdList.append(tag_id);
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList);
                        trans.modifySplit(split); // does not modify the list object 'splits'!
                    } // for - Splits
                    // store transaction in current schedule
                    schedule.setTransaction(trans);
                    file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
                }
```

#### AUTO 


```{c}
const auto expenseIdx = baseModel->mapFromBaseSource(this, file->accountsModel()->expenseIndex());
```

#### AUTO 


```{c}
const auto isSchedule = baseIdx.data(eMyMoney::Model::TransactionScheduleRole).toBool();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : t.splits()) {
        auto acc = account(split.accountId());
        auto fraction = acc.fraction();
        if(fraction == -1) {
            auto sec = security(acc.currencyId());
            fraction = acc.fraction(sec);
        }
        // Don't do any rounding on a split factor
        if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::SplitShares)) {
            split.setShares(static_cast<const MyMoneyMoney>(split.shares().convertDenominator(fraction).canonicalize()));
            split.setValue(static_cast<const MyMoneyMoney>(split.value().convertDenominator(transactionFraction).canonicalize()));
        }
    }
```

#### AUTO 


```{c}
const auto acc = model->itemByIndex(baseIdx);
```

#### AUTO 


```{c}
const auto accId = journalIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString();
```

#### AUTO 


```{c}
auto itSec = new QStandardItem(sec.name());
```

#### AUTO 


```{c}
auto isEmpty = elementName(static_cast<Element::Budget>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto idx = q->index(row, 0, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& a : actionsToBeDisabled)
    pActions[a]->setEnabled(false);
```

#### AUTO 


```{c}
auto scheduledTransactionSelected = false;
```

#### AUTO 


```{c}
const auto identifierNodesLength = identifierNodes.length();
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Account>(i)).isEmpty();
```

#### AUTO 


```{c}
auto list = d->m_moveToAccountSelector->accountList();
```

#### AUTO 


```{c}
auto label = dynamic_cast<QLabel*>(editor->haveWidget("date-label"))
```

#### AUTO 


```{c}
const auto selectedMatchType = static_cast<eMyMoney::Payee::MatchType>(d->ui->matchTypeCombo->currentData().toUInt());
```

#### AUTO 


```{c}
const auto clipboard = qApp->clipboard();
```

#### AUTO 


```{c}
auto jobId = index.data(eMyMoney::Model::IdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        d->postdateChanged(date);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
    auto acc = account(split.accountId());
    if (!acc.id().isEmpty()) {
      if (acc.isInvest() && (split.investmentTransactionType() != eMyMoney::Split::InvestmentTransactionType::UnknownTransactionType)) {
        return true;
      }
    }
  }
```

#### AUTO 


```{c}
auto argValue = PyString_FromString(carg);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            d->editSplits(d->feeSplitModel, d->ui->feesAmountEdit, MyMoneyMoney::ONE);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPrinter* printer) {
            Q_D(KHomeView);
#ifdef ENABLE_WEBENGINE
            QEventLoop loop;
            bool result = true;
            auto printPreview = [&](bool success) {
                result = success;
                loop.quit();
            };
            d->m_view->page()->print(printer, std::move(printPreview));
            loop.exec();
            if (!result) {
                QPainter painter;
                if (painter.begin(printer)) {
                    QFont font = painter.font();
                    font.setPixelSize(20);
                    painter.setFont(font);
                    painter.drawText(QPointF(10, 25), QStringLiteral("Could not generate print preview."));
                    painter.end();
                }
            }
#else
            d->m_view->print(printer);
#endif
        }
```

#### AUTO 


```{c}
const auto id = d->extractId(idExp, (*iter).id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& actionInfo : actionInfos) {
    QAction *action = d->m_actionCollection->addAction(actionInfo.name, this, actionInfo.callback);
    action->setText(actionInfo.text);
    action->setIcon(Icons::get(actionInfo.icon));
    d->m_actions.insert(actionInfo.id, action);
  }
```

#### AUTO 


```{c}
const auto &split
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        writeConfig();
        accept();
    }
```

#### AUTO 


```{c}
const auto state = baseIdx.data(eMyMoney::Model::SplitReconcileFlagRole).value<eMyMoney::Split::State>();
```

#### AUTO 


```{c}
const auto journalEntryId = d->m_selections.firstSelection(SelectedObjects::JournalEntry);
```

#### AUTO 


```{c}
auto t = d->m_editor->transaction();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
        switch (plugin->storageType()) {
        case eKMyMoney::StorageType::GNC:
            break;
        default:
            availableFileTypes.append(plugin->storageType());
            break;
        }
    }
```

#### AUTO 


```{c}
const auto accountId = ui->accountCombo->getSelected();
```

#### AUTO 


```{c}
const auto journalIdx = file->journalModel()->indexById(journalEntryId);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
            Q_D(KInvestmentView);
            d->loadAccount(accountId);
        }
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::instance()->account(*it_a);
```

#### AUTO 


```{c}
auto i = (int)Account::Element::SubAccount;
```

#### AUTO 


```{c}
const auto isInvestmentAccount = account.accountType() == eMyMoney::Account::Type::Investment;
```

#### AUTO 


```{c}
const auto accIdx = d->accountsModel.indexById(split.accountId());
```

#### AUTO 


```{c}
auto list = m_file->scheduleList();
```

#### AUTO 


```{c}
const auto indexList = d->m_equitiesProxyModel->match(d->m_equitiesProxyModel->index(0,0), EquitiesModel::InvestmentID, id, 1,
                                                   Qt::MatchFlags(Qt::MatchExactly | Qt::MatchRecursive | Qt::MatchWrap));
```

#### AUTO 


```{c}
auto b = acc.isInvest() ? true : false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
        if (idx.row() != lastRow) {
            lastRow = idx.row();
            selectedJournalEntries += idx.data(eMyMoney::Model::IdRole).toString();
        }
    }
```

#### AUTO 


```{c}
const auto& index
```

#### AUTO 


```{c}
auto strQuantity = QVariant(balance.formatMoney(QString(), prec));
```

#### AUTO 


```{c}
const auto brokerageAccount = file->accountsModel()->itemByName(d->parentAccount.brokerageName());
```

#### AUTO 


```{c}
auto treeItem = m_securitiesTree->currentIndex();
```

#### AUTO 


```{c}
auto reconciliationAccount = file->account(accountId);
```

#### AUTO 


```{c}
const auto pluginSection(KSharedConfig::openConfig()->group(QStringLiteral("Plugins")));
```

#### AUTO 


```{c}
const auto editor = d->ui->m_register->indexWidget(d->ui->m_register->editIndex());
```

#### AUTO 


```{c}
auto xml = value(d->getAttrName(Split::Attribute::KMMatchedTx));
```

#### AUTO 


```{c}
auto interestAccountWidget = d->haveWidget<KMyMoneyCategory*>("interest-account");
```

#### AUTO 


```{c}
auto list = m_selectedTransactions;
```

#### AUTO 


```{c}
const auto openParen = QStringLiteral("(");
```

#### AUTO 


```{c}
const auto hasReference = file->isReferenced(d->m_currentCategory, skip);
```

#### AUTO 


```{c}
auto reportTocItem = dynamic_cast<TocItemReport*>(tocItem);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& id) {
        d->categoryChanged(id);
    }
```

#### AUTO 


```{c}
auto writeQuery = [&]() {
      query.bindValue(":id", obj.idString());
      query.bindValue(":iban", payeeIdentifier->electronicIban());
      const auto bic = payeeIdentifier->fullStoredBic();
      query.bindValue(":bic", (bic.isEmpty()) ? QVariant(QVariant::String) : bic);
      query.bindValue(":name", payeeIdentifier->ownerName());
      if (!query.exec()) { // krazy:exclude=crashy
        qWarning("Error while saving ibanbic data for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
        return false;
      }
      return true;
    };
```

#### AUTO 


```{c}
auto prec = MyMoneyMoney::denomToPrec(security.smallestAccountFraction());
```

#### AUTO 


```{c}
auto transferForm = new kOnlineTransferForm(q);
```

#### AUTO 


```{c}
auto parentIndex = m_filterProxyModel->getSelectedParentAccountIndex();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : actionInfos) {
            auto a = new QAction(this);
            // KActionCollection::addAction by name sets object name anyways,
            // so, as better alternative, set it here right from the start
            a->setObjectName(info.name);
            a->setText(info.text);
            if (info.icon != Icon::Empty) // no need to set empty icon
                a->setIcon(Icons::get(info.icon));
            a->setEnabled(false);
            lutActions.insert(info.action, a);  // store QAction's pointer for later processing
        }
```

#### AUTO 


```{c}
const auto sTransactionContextMarkMenu = QStringLiteral("transaction_context_mark_menu");
```

#### AUTO 


```{c}
auto interest = new KMyMoneyCategory(0, true);
```

#### AUTO 


```{c}
const auto oldValue = d->ui->totalAmountEdit->value();
```

#### AUTO 


```{c}
auto payee = index.data((int)Role::PayeeName).toString();
```

#### AUTO 


```{c}
auto statjob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatNoDetails);
```

#### AUTO 


```{c}
const auto payeeId = split.payeeId();
```

#### AUTO 


```{c}
auto oAcc = MyMoneyFile::instance()->account(acc.id());
```

#### AUTO 


```{c}
auto lineEdit = dynamic_cast<KMyMoneyLineEdit*>(w)
```

#### AUTO 


```{c}
const auto strStkAccList = invAcc.accountList();
```

#### AUTO 


```{c}
auto k = dynamic_cast<QKeyEvent*>(e)
```

#### AUTO 


```{c}
const auto start = index(0, 0);
```

#### AUTO 


```{c}
auto downloadedFile = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : list) {
                    const auto idx = file->accountsModel()->indexById(accountId);
                    if (!currencyIds.contains(idx.data(eMyMoney::Model::AccountCurrencyIdRole).toString())) {
                        moveToAccountSelector->removeItem(accountId);
                    }
                }
```

#### DECLTYPE 


```{c}
static constexpr decltype(reinterpret_cast<QModelIndex*>(0)->internalId()) invalidParent = std::numeric_limits<decltype(reinterpret_cast<QModelIndex*>(0)->internalId())>::max();
```

#### AUTO 


```{c}
auto i = readInstitution(m_baseNode);
```

#### AUTO 


```{c}
const auto cond1 = !price.from().isEmpty() && price.source() != QLatin1String("KMyMoney");
```

#### AUTO 


```{c}
auto pr = MyMoneyFile::instance()->price(d->m_fromCurrency.id(), d->m_toCurrency.id(), d->ui->m_dateEdit->date());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto payee : qAsConst(m_selectedPayeesList)) {
      payeeIds.append(payee.id());
    }
```

#### AUTO 


```{c}
auto institution = file->institution(d->m_currentInstitution.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : transactionIds) {
    if (id.isEmpty())
      continue;
    const auto indexes = journalModel->indexesByTransactionId(id);
    int row = -1;
    for (const auto baseIdx : indexes) {
      if (baseIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
        row = journalModel->mapFromBaseSource(model(), baseIdx).row();
        if (row != -1) {
          break;
        }
      }
    }
    if (row == -1) {
      qDebug() << "transaction" << id << "not found anymore for selection. skipped";
      continue;
    }

    if (startRow == -1) {
      startRow = row;
      lastRow = row;
      // use the first as the current index
      if (!currentIdx.isValid()) {
        currentIdx = model()->index(startRow, 0);
      }
    } else {
      if (row == lastRow+1) {
        lastRow = row;
      } else {
        // a new range start, so we take care of it
        createSelectionRange();
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
      if (plugin->formatName().compare(QLatin1String("XML")) == 0) {
        rc = plugin->open(pStorage, url);
        pluginFound = true;
        break;
      }
    }
```

#### AUTO 


```{c}
const auto delegate = d->delegateProxy->delegate(index.model());
```

#### AUTO 


```{c}
auto newRow = 0;
```

#### AUTO 


```{c}
const auto journalEntry = journalModel->itemById(journalEntryId);
```

#### AUTO 


```{c}
const auto baseModel = MyMoneyFile::baseModel()->baseModel(idx);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(LedgerFilter);
        d->lineEdit = nullptr;
    }
```

#### AUTO 


```{c}
auto t = dynamic_cast<Transaction*>(d->m_focusItem);
```

#### AUTO 


```{c}
auto strFixVersion = MyMoneyUtils::QStringEmpty(temp.attribute(attributeName(Attribute::General::ID))).toUInt();
```

#### AUTO 


```{c}
auto p = readPayee(m_baseNode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
        ++itemCount;
        QRegularExpressionMatch m = exp.match(item.id());
        if (m.hasMatch()) {
            const quint64 id = m.captured(1).toUInt();
            if (id > m_nextId) {
                m_nextId = id;
            }
        }
        auto groupIdx = d->indexByType(item.type());
        if (groupIdx.isValid()) {
            const int r = rowCount(groupIdx);
            insertRows(r, 1, groupIdx);
            static_cast<TreeItem<MyMoneySchedule>*>(index(r, 0, groupIdx).internalPointer())->dataRef() = item;
        } else {
            qDebug() << "Invalid schedule item of type" << static_cast<int>(item.type()) << "- Skipped";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : actions)
        pActions[action]->setEnabled(m_storageInfo.isOpened);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
    // the following line will throw an exception if the
    // account does not exist
    auto acc = MyMoneyFile::account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION("Cannot store split with no account assigned");
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION("Cannot store split referencing standard account");
    if (acc.isLoan() && (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer)))
      loanAccountAffected = true;
  }
```

#### AUTO 


```{c}
const auto statusRoles = this->statusRoles(idx);
```

#### AUTO 


```{c}
auto newLibPath = appDir;
```

#### AUTO 


```{c}
const auto securities = file->securityList();
```

#### AUTO 


```{c}
auto el = document.createElement(d->getElName(Split::Element::Split));
```

#### AUTO 


```{c}
auto list_s = file->scheduleList(QString(), eMyMoney::Schedule::Type::Any, eMyMoney::Schedule::Occurrence::Any, eMyMoney::Schedule::PaymentType::Any,
                                     QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto IStorage = qobject_cast<StoragePlugin *>(plugin);
```

#### AUTO 


```{c}
auto const view
```

#### AUTO 


```{c}
const auto indexes = d->m_filterModel->match(d->m_filterModel->index(0, 0),
                                 eMyMoney::Model::IdRole,
                                 QVariant(sch.id()),
                                 1,
                                 Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto tabOrder = property("kmm_defaulttaborder").toStringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& pluginData : pluginDatas) {
        if (!onlyEnabled || isPluginEnabled(pluginData, pluginSection)) {
            // only use the first one found. Otherwise, always the last one
            // wins (usually the installed system version) and the QT_PLUGIN_PATH
            // env variable nor the current directory have an effect for KMyMoney
            if (!plugins.contains(pluginData.pluginId()))
                plugins.insert(pluginData.pluginId(), pluginData);
        }
    }
```

#### AUTO 


```{c}
auto i = (int)Account::Attribute::ID;
```

#### AUTO 


```{c}
const auto accountId = d->ui->categoryCombo->getSelected();
```

#### AUTO 


```{c}
auto interestEdit = dynamic_cast<kMyMoneyEdit*>(haveWidget("interest-amount"));
```

#### AUTO 


```{c}
auto grp = KSharedConfig::openConfig()->group("SplitTable");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits())
    val += split.value();
```

#### AUTO 


```{c}
const auto idx = model()->index(row, 0);
```

#### AUTO 


```{c}
const auto acc = file->account(m_split.accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
                        // create copy of transaction in current schedule
                        auto trans = schedule.transaction();
                        // create copy of lists of splits
                        for (auto& split : trans.splits()) {
                            if (payeeInList(list, split.payeeId())) {
                                split.setPayeeId(payee_id);
                                trans.modifySplit(split); // does not modify the list object 'splits'!
                            }
                        } // for - Splits
                        // store transaction in current schedule
                        schedule.setTransaction(trans);
                        file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& widgetName : buttonNames) {
                auto w = tabOrderDialog->findChild<QWidget*>(widgetName);
                if (w) {
                    w->setVisible(false);
                }
            }
```

#### AUTO 


```{c}
auto budget = MyMoneyXmlContentHandler2::readBudget(child.toElement());
```

#### AUTO 


```{c}
auto acc = file->account(it_a.key());
```

#### AUTO 


```{c}
auto& column
```

#### AUTO 


```{c}
auto text = ui->kcfg_QifExportProfile->text();
```

#### AUTO 


```{c}
auto rc(matchedSplit.memo());
```

#### AUTO 


```{c}
auto isEmpty = onlineJob::getAttrName(static_cast<onlineJob::Attribute>(i)).isEmpty();
```

#### CONST EXPRESSION 


```{c}
constexpr int backgroundAlpha = 32;
```

#### AUTO 


```{c}
const auto list = match(index(0, 0), (int)Role::ID, QVariant(d->m_reconciledAccount.id()), -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto securityId = idx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
```

#### AUTO 


```{c}
auto sch = m->scheduleList(QString(), Schedule::Type::Any, Schedule::Occurrence::Any, Schedule::PaymentType::Any,
                                   QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto payee2 = MyMoneyXmlContentHandler::readPayee(el);
```

#### AUTO 


```{c}
auto showClosedAccounts = KMyMoneySettings::showAllAccounts();
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::baseModel()->mapToBaseSource( currentIdx );
```

#### AUTO 


```{c}
auto acc = m_accountList[id];
```

#### AUTO 


```{c}
auto acc = account((*it_s).accountId());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) {
        if (validateSelectedColumn(col, Column::CreditDebitIndicator)) {
            ui->m_creditIndicator->setDisabled(col == -1);
            ui->m_debitIndicator->setDisabled(col == -1);
            ui->m_oppositeSigns->setEnabled(col == -1);
            ui->labelBnk_opposite->setEnabled(col == -1);
        }
    }
```

#### AUTO 


```{c}
auto mdlItem = m_securitiesProxyModel->index(treeItem.row(), SecuritiesModel::Security, treeItem.parent());
```

#### AUTO 


```{c}
const auto accountId = (*it_t).split().accountId();
```

#### AUTO 


```{c}
const auto list = match(index(0, 0), (int)Role::ID, id, -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchRecursive));
```

#### AUTO 


```{c}
auto intervalDays = ((i * forecast.accountsCycle()) + daysToBeginDay);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySchedule::getAttrName(static_cast<MyMoneySchedule::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto& splits = transaction.splits();
```

#### AUTO 


```{c}
const auto index = MyMoneyFile::baseModel()->mapFromBaseSource(d->costCenterModel, baseIdx);
```

#### AUTO 


```{c}
auto it = pairs.constBegin();
```

#### AUTO 


```{c}
auto valueWidget = dynamic_cast<AmountEdit*>(haveWidget(amount))
```

#### AUTO 


```{c}
auto payee = dynamic_cast<KMyMoneyPayeeCombo*>(d->m_editWidgets["payee"]);
```

#### AUTO 


```{c}
const auto actionStates = d->actionStates();
```

#### AUTO 


```{c}
const auto locale = idx.data(eMyMoney::Model::TemplatesLocaleRole).toString();
```

#### AUTO 


```{c}
const auto rightData = sourceModel()->data(right, (int)Role::DisplayOrder);
```

#### AUTO 


```{c}
auto item = dynamic_cast<KPayeeListItem*>(d->ui->m_payeesList->currentItem());
```

#### AUTO 


```{c}
auto favItem = itemFromAccountId(toNode, acc.id());
```

#### AUTO 


```{c}
const auto grp = KSharedConfig::openConfig()->group(configGroupName);
```

#### AUTO 


```{c}
const auto  liabilityValue = data(liabilityList.front(), (int)Role::TotalValue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& a : disabledActions)
      pActions[a]->setEnabled(false);
```

#### AUTO 


```{c}
const auto templates = wizard.templates();
```

#### AUTO 


```{c}
auto newIndex = d->ui->m_paymentMethodEdit->findData(QVariant(selectedId), Qt::UserRole, Qt::MatchExactly);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyBudgetPrivate::getAttrName(static_cast<Budget::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto iid = QLatin1String("org.kmymoney.creditTransfer.sepa.sqlStoragePlugin");
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { emit done(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (d->currentActivity) {
            d->stockSplit.setValue(d->currentActivity->valueAllShares().convert(d->currency.smallestAccountFraction(), d->security.roundingMethod())
                                   * d->currentActivity->sharesFactor());
            if (d->currentActivity->type() != eMyMoney::Split::InvestmentTransactionType::SplitShares) {
                updateTotalAmount();
            }
            d->updateWidgetState();
        }
    }
```

#### AUTO 


```{c}
auto reader = std::make_unique<MyMoneyStorageSql>(MyMoneyFile::instance(), url);
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(d->m_reportTabWidget->widget(1))
```

#### AUTO 


```{c}
auto accountMatched = !(filter.testFlag(accountFilterActive));
```

#### AUTO 


```{c}
auto tabbar = dynamic_cast<KMyMoneyTransactionForm::TabBar*>(d->m_editor->haveWidget("tabbar"))
```

#### AUTO 


```{c}
auto grp = KSharedConfig::openConfig()->group("Last Use Settings");
```

#### AUTO 


```{c}
const auto formattedValue = d->formatViewLabelValue(netWorth);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : transaction.splits()) {
        if(splitId != sp.id()) {
          return MyMoneyFile::instance()->accountsModel()->accountIdToHierarchicalName(sp.accountId());
        }
      }
```

#### AUTO 


```{c}
const auto idx = view()->currentIndex();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto accountId : acc.accountList()) {
    auto accountToMove = d->accountsModel.itemById(accountId);
    reparentAccount(accountToMove, newParent);
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, MyMoneyFile::account(accountToMove.id()));
  }
```

#### AUTO 


```{c}
auto it_terms = 0, weight = 1;
```

#### AUTO 


```{c}
const auto count = m_models->onlineJobsModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto i = (int)Attribute::Report::ID;
```

#### AUTO 


```{c}
auto id = m->storageId();
```

#### AUTO 


```{c}
const auto dispIndex = filterModel->index(index.row(), JournalModel::Column::Balance);
```

#### AUTO 


```{c}
const auto msg = QString::fromLatin1("Unknown account id '%1'").arg(id);
```

#### AUTO 


```{c}
auto identifierData = readPayeeIdentifier(identifierNodes.item(i).toElement());
```

#### AUTO 


```{c}
const auto& tag
```

#### AUTO 


```{c}
const auto columnIndex = rowIndex.model()->index(rowIndex.row(), column, rowIndex.parent());
```

#### AUTO 


```{c}
const auto objId = selected.indexes().front().data(eMyMoney::Model::IdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    d->stateFilter->clearFilter();
    d->ui->m_filterContainer->hide();
    d->ui->m_ledgerView->setFocus();
    QMetaObject::invokeMethod(d->ui->m_ledgerView, &LedgerView::ensureCurrentItemIsVisible, Qt::QueuedConnection);
  }
```

#### AUTO 


```{c}
auto legendItems = legendNames.count();
```

#### AUTO 


```{c}
const auto list = m_storage->scheduleList(QString(), Schedule::Type::Any, Schedule::Occurrence::Any, Schedule::PaymentType::Any,
                                              QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto filter = d->m_tabFilters->setupFilter();
```

#### AUTO 


```{c}
const auto securityId = selections.firstSelection(SelectedObjects::Security);
```

#### AUTO 


```{c}
const auto fontColor = KMyMoneySettings::schemeColor(valInstitution.isNegative() ? SchemeColor::Negative : SchemeColor::Positive);
```

#### AUTO 


```{c}
auto securities = MyMoneyFile::instance()->securityList();
```

#### AUTO 


```{c}
const auto* splitHelper = new KMyMoneyAccountComboSplitHelper(d->ui->categoryCombo, &d->splitModel);
```

#### AUTO 


```{c}
const auto& accountId
```

#### AUTO 


```{c}
auto baseModel = MyMoneyFile::instance()->tagsModel();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& sp : qAsConst(interestSplits)) {
                    amount += sp.value();
                }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto history = account.reconciliationHistory();
```

#### AUTO 


```{c}
const auto iconIndex = d->iconClickIndex(idx, event->pos());
```

#### AUTO 


```{c}
const auto endingBalance = dd->endingBalanceDlg->endingBalance();
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnScheduleTX]);
```

#### AUTO 


```{c}
auto accountItem = d->itemFromAccountId(this, account.id());
```

#### AUTO 


```{c}
auto writer = new MyMoneyStorageSql(MyMoneyFile::instance()->storage(), Models::instance(), url);
```

#### AUTO 


```{c}
const auto now = QDateTime::currentDateTime();
```

#### AUTO 


```{c}
auto taskFactory = pluginFactory->create<KMyMoneyPlugin::onlineTaskFactory>(onlineJobAdministration::instance());
```

#### AUTO 


```{c}
auto iconDef = iconMappings.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto baseIdx : indexes) {
      if (baseIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
        row = journalModel->mapFromBaseSource(model(), baseIdx).row();
        if (row != -1) {
          break;
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& w : widgetList) {
        const auto property = w->property("kmm_taborder");
        if (property.isValid() && property.toBool()) {
            qDebug() << (void*)(w) << w->metaObject()->className() << w->objectName() << w->property("kmm_taborder").toBool();
        }
    }
```

#### AUTO 


```{c}
const auto isInstitutionsModel = model ? true : false;
```

#### AUTO 


```{c}
const auto& sConfigName
```

#### AUTO 


```{c}
const auto category = qobject_cast<KMyMoneyAccountCombo*>(parent());
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->account(m_idInvAcc);
```

#### AUTO 


```{c}
auto stockSymbols = csvImporter->m_mapSymbolName.keys();
```

#### AUTO 


```{c}
auto tag = dynamic_cast<KTagContainer*>(d->m_editWidgets["tag"]);
```

#### AUTO 


```{c}
auto i = (int)MyMoneyInstitution::Attribute::ID;
```

#### AUTO 


```{c}
auto favItem = d->itemFromAccountId(favoriteAccountsItem, account->id());
```

#### AUTO 


```{c}
auto favRow = toNode->rowCount();
```

#### AUTO 


```{c}
const auto txProblemHeader(i18n("* Problems with transactions"));
```

#### AUTO 


```{c}
const auto incomeValue = data(incomeList.front(), (int)Role::TotalValue);
```

#### AUTO 


```{c}
auto interestEdit = dynamic_cast<KMyMoneyEdit*>(haveWidget("interest-amount"));
```

#### AUTO 


```{c}
const auto sourceColumn = m_mdlColumns->at(mapToSource(index).column());
```

#### AUTO 


```{c}
const auto fid = extractNodeText(doc, "institution/fid");
```

#### AUTO 


```{c}
const auto acc = file->accountsModel()->itemById(d->m_parentAccountId);
```

#### AUTO 


```{c}
const auto dialogButtonBox = focusWidget()->parentWidget();
```

#### AUTO 


```{c}
const auto cond2 = cond1 && !file->isReferenced(sec, skip);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @todo add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      // case eMyMoney::File::Object::Currency:
      // case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
      case eMyMoney::File::Object::Transaction:
      // case eMyMoney::File::Object::Price:
      // case eMyMoney::File::Object::Parameter:
      case eMyMoney::File::Object::OnlineJob:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
const auto idx = indexById(before.id());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KAccountTemplateSelector);
        d->loadHierarchy();
    }
```

#### AUTO 


```{c}
auto feesEdit = dynamic_cast<AmountEdit*>(haveWidget("fee-amount"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
        const auto acc = file->account(split.accountId());
        if (acc.isAssetLiability() && !acc.isInvest() && (acc.accountType() != eMyMoney::Account::Type::Investment)) {
          return acc.name();
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& button : buttons)
      button = nullptr;
```

#### AUTO 


```{c}
const auto account = list.value(MyMoneyAccount::stdAccName(baseAccount.groupType));
```

#### AUTO 


```{c}
const auto index = feeSplitModel->index(row, 0);
```

#### AUTO 


```{c}
const auto splits3 = tCopy.splits();
```

#### AUTO 


```{c}
auto cache = new QCache<QString, QRegularExpression>(regexpCacheSize);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& id : qAsConst(ids)) {
    if (!m_selections[type].contains(id)) {
      m_selections[type].append(id);
    }
  }
```

#### AUTO 


```{c}
auto helper = new KMyMoneyAccountComboSplitHelper(d->ui->feesCombo, d->feeSplitModel);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const& weekDay: locale.weekdays())
    {
        d->m_processingDays.setBit(static_cast<int>(weekDay));
    }
```

#### AUTO 


```{c}
const auto tabOrder = property("kmm_currenttaborder").toStringList();
```

#### AUTO 


```{c}
auto el = document.createElement(nodeNames[nnCostCenter]);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KNewAccountDlg);
        d->changeHierarchyLabel();
    }
```

#### AUTO 


```{c}
auto availableItem = ui->m_availableList->currentItem();
```

#### AUTO 


```{c}
auto label = dynamic_cast<QLabel*>(q->haveWidget("price-label"))
```

#### AUTO 


```{c}
const auto idx
```

#### AUTO 


```{c}
auto pyVal = PyDict_GetItem(pyContainer, pyKey);
```

#### AUTO 


```{c}
auto tag = dynamic_cast<KTagContainer*>(d->m_editWidgets["tag"])
```

#### AUTO 


```{c}
const auto rowCount = sourceModel()->rowCount(source);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        KHelpClient::invokeHelp("details.schedules.entering");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->amountChanged(d->feeSplitModel, d->ui->feesAmountEdit, MyMoneyMoney::ONE);
        d->updateWidgetState();
        if (!d->ui->feesCombo->getSelected().isEmpty()) {
            d->scheduleUpdateTotalAmount();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& index : list) {
      // always return the account which is not the child of the favorite accounts item
      if (index.parent().data((int)Role::ID).toString() != AccountsModel::favoritesAccountId)
        return model->itemFromIndex(index);
    }
```

#### AUTO 


```{c}
auto view = qobject_cast<LedgerViewPage*>(d->ui->ledgerTab->currentWidget());
```

#### AUTO 


```{c}
const auto identifierType = element.attribute(attributeName(Attribute::Payee::Type));
```

#### AUTO 


```{c}
auto sharesEdit = d->haveWidget<AmountEdit>("sharesAmountEdit")
```

#### AUTO 


```{c}
auto cashflow = dynamic_cast<KMyMoneyCashFlowCombo*>(w)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : tList) {
        const auto splits = transaction.splits();
        for (const auto& split : splits) {
            if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest))
                interestAccounts[split.accountId()] = true;
        }
    }
```

#### AUTO 


```{c}
auto csvContent = csvDataset(0);
```

#### AUTO 


```{c}
const auto splitDelegate = qobject_cast<const SplitDelegate*>(delegate);
```

#### AUTO 


```{c}
const auto oldTransaction = (*it_t);
```

#### AUTO 


```{c}
auto plugins = findPlugins("kmymoney/onlinetasks", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
    });
```

#### AUTO 


```{c}
auto acc = m_accountList[account];
```

#### AUTO 


```{c}
const auto accountIdx = file->accountsModel()->indexById(selectedAccountId);
```

#### AUTO 


```{c}
const auto defaultTabOrder = QStringList{
            QLatin1String("nameEdit"),
            QLatin1String("frequencyNoEdit"),
            QLatin1String("frequencyEdit"),
            QLatin1String("paymentMethodCombo"),
            // the std transaction editor (see also newtransactioneditor.cpp
            QLatin1String("accountCombo"),
            QLatin1String("dateEdit"),
            QLatin1String("creditDebitEdit"),
            QLatin1String("payeeEdit"),
            QLatin1String("numberEdit"),
            QLatin1String("categoryCombo"),
            QLatin1String("costCenterCombo"),
            QLatin1String("tagContainer"),
            QLatin1String("statusCombo"),
            QLatin1String("memoEdit"),
            // the schedule options
            QLatin1String("weekendOptionCombo"),
            QLatin1String("estimateOption"),
            QLatin1String("variationEdit"),
            QLatin1String("lastDayInMonthOption"),
            QLatin1String("autoEnterOption"),
            QLatin1String("endSeriesOption"),
            QLatin1String("remainingEdit"),
            QLatin1String("finalPaymentDateEdit"),
            QLatin1String("buttonBox"),
        };
```

#### AUTO 


```{c}
auto i = (int)Element::Payee::Address;
```

#### AUTO 


```{c}
auto haveValue = [&](const SplitModel* model) {
            const auto rows = model->rowCount();
            for (int row = 0; row < rows; ++row) {
                const auto idx = model->index(row, 0);
                if (!idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isZero()) {
                    return true;
                }
            }
            return false;
        };
```

#### AUTO 


```{c}
auto dlg = new KCategoryReassignDlg(this);
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["amount"]);
```

#### AUTO 


```{c}
auto schedule = MyMoneyFile::instance()->schedule(d->m_currentSchedule.id());
```

#### AUTO 


```{c}
const auto rows = d->m_transactionFilter->rowCount();
```

#### AUTO 


```{c}
auto currency = d->currenciesModel.itemById(id);
```

#### AUTO 


```{c}
auto date = postdateWidget->date();
```

#### AUTO 


```{c}
auto numberWiget = dynamic_cast<QWidget*>(o);
```

#### AUTO 


```{c}
auto transactionFactor(MyMoneyMoney::ONE);
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(ui.m_reportTabWidget->widget(index))
```

#### AUTO 


```{c}
auto model = plugin->requestData(QString(), eIBANBIC::DataType::bicModel).value<QAbstractItemModel *>()
```

#### LAMBDA EXPRESSION 


```{c}
[&](QWidget* editor) { emit const_cast<ibanBicItemDelegate*>(this)->closeEditor(editor); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& plugin: plugins) {
        QJsonValue array = plugin.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
        if (array.isArray())
            list.append(array.toVariant().toStringList());
    }
```

#### AUTO 


```{c}
const auto securityIdx = ui->m_securitiesTree->currentIndex();
```

#### AUTO 


```{c}
auto taxCategoryId = [&]() {
        if (categoryId.isEmpty()) {
            return QString();
        }
        const auto category = MyMoneyFile::instance()->account(categoryId);
        return category.value("VatAccount");
    };
```

#### AUTO 


```{c}
const auto editIndex = viewWidget->model()->index(index.row(), 0);
```

#### AUTO 


```{c}
auto boldFont = ui->m_fromCurrencyText->font();
```

#### AUTO 


```{c}
const auto currentPointSize = m_view->font().pointSizeF();
```

#### AUTO 


```{c}
const auto accountId = accountIdx.data(eMyMoney::Model::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const pageInfo& info : pageInfos) {
        auto a = new QAction(this);
        // KActionCollection::addAction by name sets object name anyways,
        // so, as better alternative, set it here right from the start
        a->setObjectName(QString::fromLatin1("ShowPage%1").arg(QString::number(pageCount++)));
        a->setText(info.text);
        a->setData(static_cast<int>(info.view));
        connect(a, &QAction::triggered, [this, a] { showPageAndFocus(static_cast<View>(a->data().toUInt())); } );
        lutActions.insert(info.action, a);  // store QAction's pointer for later processing
        if (!info.shortcut.isEmpty())
            a->setShortcut(info.shortcut);
    }
```

#### AUTO 


```{c}
auto fAccCycle = accountsCycle();
```

#### AUTO 


```{c}
const auto journalRows = q->rowCount();
```

#### AUTO 


```{c}
auto translist = file->transactionList(f);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    Q_D(KAccountTemplateSelector);
    d->loadHierarchy();
  }
```

#### AUTO 


```{c}
const auto transaction = MyMoneyFile::instance()->journalModel()->transactionById(transactionId);
```

#### AUTO 


```{c}
auto baseIdx = MyMoneyFile::baseModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto const model = Models::instance()->institutionsModel();
```

#### AUTO 


```{c}
auto acBasicAccount = makeAccount(QString("Basic Account"), eMyMoney::Account::Type::Checkings, openingBalance, QDate(2016, 1, 1), acAsset);
```

#### AUTO 


```{c}
auto adjustDateSection = [&](int offset) {
    switch(d->m_dateEdit->currentSection()) {
      case QDateTimeEdit::DaySection:
        slotDateChosen(d->m_date.addDays(offset));
        break;
      case QDateTimeEdit::MonthSection:
        slotDateChosen(d->m_date.addMonths(offset));
        break;
      case QDateTimeEdit::YearSection:
        slotDateChosen(d->m_date.addYears(offset));
        break;
      default:
        break;
    }
  };
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& baseAccount : d->defaults) {
        ++itemCount;
        // we have nothing to do for favorites
        if (baseAccount.groupType == eMyMoney::Account::Standard::Favorite)
            continue;
        const auto account = list.value(MyMoneyAccount::stdAccName(baseAccount.groupType));
        if (account.id() == MyMoneyAccount::stdAccName(baseAccount.groupType)) {
            const auto idx = indexById(account.id());
            static_cast<TreeItem<MyMoneyAccount>*>(idx.internalPointer())->dataRef() = account;
            itemCount += d->loadSubAccounts(idx, list);
        } else {
            qDebug() << "Baseaccount for" << MyMoneyAccount::stdAccName(baseAccount.groupType) << "not found in list";
        }
    }
```

#### AUTO 


```{c}
auto plugin = pPlugins.data.value(QString::fromLatin1("ibanbicdata"), nullptr)
```

#### AUTO 


```{c}
auto amount = dynamic_cast<kMyMoneyEdit*>(d->m_editWidgets["amount"]);
```

#### AUTO 


```{c}
const auto  assetValue = data(assetList.front(), AccountsModel::AccountTotalValueRole);
```

#### LAMBDA EXPRESSION 


```{c}
[&, newColPos](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          childItem->insertColumns(newColPos, 1);
          if (childItem->hasChildren())
            self(self, childItem);
          d->setAccountData(item, j, childItem->data((int)Role::Account).value<MyMoneyAccount>(), QList<Column> {column});
        }
        return true;
      }
```

#### AUTO 


```{c}
const auto payeeCount = list.count();
```

#### AUTO 


```{c}
auto it = pActions.constBegin();
```

#### AUTO 


```{c}
auto accCurrent = &d->m_file->account(itCurrent->data(AccountRole).value<MyMoneyAccount>().id());
```

#### AUTO 


```{c}
auto payment = dynamic_cast<kMyMoneyEdit*>(d->m_editWidgets["payment"]);
```

#### AUTO 


```{c}
auto txt = c.attribute(getAttrName(Statement::Attribute::Action), txAction[eMyMoney::Transaction::Action::Buy]);
```

#### AUTO 


```{c}
auto prec = MyMoneyMoney::denomToPrec(securityIdx.data(eMyMoney::Model::SecuritySmallestAccountFractionRole).toInt());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); ++i) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (d->tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transactionId : transactions) {
                if (d->canBePrinted(accountId, transactionId)) {
                    d->printCheck(accountId, transactionId);
                }
            }
```

#### AUTO 


```{c}
auto i = (int)Schedule::Element::Payment;
```

#### AUTO 


```{c}
const auto selections = d->m_selections;
```

#### AUTO 


```{c}
const auto incomeIdx = AccountsModel::mapFromBaseSource(this, file->accountsModel()->incomeIndex());
```

#### AUTO 


```{c}
const auto list = transactionList(filter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : transaction.splits()) {
                acc = MyMoneyFile::instance()->account(s.accountId());
                list.append(acc.id());
                if (acc.accountGroup() == eMyMoney::Account::Type::Asset
                        || acc.accountGroup() == eMyMoney::Account::Type::Liability) {
                    if (acc.accountType() != eMyMoney::Account::Type::Loan
                            && acc.accountType() != eMyMoney::Account::Type::AssetLoan) {
                        split = s;
                        found = true;
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto institution = MyMoneyFile::instance()->institutionsModel()->itemByIndex(idx);
```

#### AUTO 


```{c}
const auto accountIdx = AccountsModel::mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto columns = getNumericalColumns();
```

#### AUTO 


```{c}
const auto leftData = sourceModel()->data(sourceModel()->index(left.row(), (int)Column::Account, left.parent()), (int)Role::TotalValue);
```

#### AUTO 


```{c}
auto sizeVal = PyList_Size(val);
```

#### AUTO 


```{c}
const auto childIndex = model->index(i, index.column(), index);
```

#### AUTO 


```{c}
const auto occurrence = idx.data(eMyMoney::Model::ScheduleFrequencyRole).value<Schedule::Occurrence>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids)
        addAccount(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& subAccount : accountIds) {
                if (!_list.contains(subAccount) || _list.value(subAccount).parentAccountId() != (*ita).id()) {
                    (*ita).removeAccountId(subAccount);
                    qDebug() << "check account hierarchy:" << "removed" << subAccount << "from" << (*ita).id();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
            if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer)) {
                auto acc = MyMoneyFile::account(split.accountId());

                if (acc.isAssetLiability()) {
                    MyMoneySplit s = split;
                    s.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Amortization));
                    tCopy.modifySplit(s);
                }
            }
        }
```

#### AUTO 


```{c}
auto message = i18n(
                    "You are about to finish the reconciliation of this account with a difference between your bank statement and the transactions marked as "
                    "cleared.\n"
                    "Are you sure you want to finish the reconciliation?");
```

#### AUTO 


```{c}
auto a = new QAction(this);
```

#### AUTO 


```{c}
const auto rowCount = d->displayString(index.model()->index(index.row(), column), option).lines.count();
```

#### AUTO 


```{c}
const auto payee(payeeExp.match(kt.m_strMemo));
```

#### AUTO 


```{c}
auto it = d->viewFrames.constBegin();
```

#### AUTO 


```{c}
const auto t = journalEntry.transaction();
```

#### AUTO 


```{c}
auto parentAcc = file->account(parent);
```

#### AUTO 


```{c}
const auto amount = idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotNewTransaction(); }
```

#### AUTO 


```{c}
const auto openLedgers = grp.readEntry(storageId, QStringList());
```

#### AUTO 


```{c}
const auto endIdx = idx.model()->index(idx.row(), idx.model()->columnCount()-1);
```

#### AUTO 


```{c}
auto &tmpl
```

#### AUTO 


```{c}
const auto identifierId = element.attribute(attributeName(Attribute::Payee::ID)).toUInt();
```

#### AUTO 


```{c}
const auto selectedItems = selectedTags();
```

#### AUTO 


```{c}
const auto pluginsPage = new KSettingsPlugins();
```

#### AUTO 


```{c}
auto mType = (*it).matchData(ignorecase, matchPattern);
```

#### AUTO 


```{c}
auto secList = d->m_file->securityList();
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_debitCol)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& onlineTaskIid : plugin->availableJobs(account.id())) {
                    if (m_onlineTasks.contains(onlineTaskIid)) {
                        return true;
                    }
                }
```

#### AUTO 


```{c}
auto skipTransactions = false;
```

#### AUTO 


```{c}
auto idx = d->journalModel.index(row, 0);
```

#### AUTO 


```{c}
auto categoryId = cat->selectedItem();
```

#### AUTO 


```{c}
const auto startIdx = idx.model()->index(idx.row(), 0);
```

#### AUTO 


```{c}
const auto idColumn = static_cast<EquitiesModel::Column>(retAction->objectName().toInt());
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(source_row, 0, source_parent);
```

#### AUTO 


```{c}
const auto payeesCount = payees.count();
```

#### AUTO 


```{c}
auto postDate = new KMyMoneyDateInput;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
            // create copy of transaction in current schedule
            auto trans = schedule.transaction();
            // create copy of lists of splits
            for (auto& split : trans.splits()) {
              if (payeeInList(m_selectedPayeesList, split.payeeId())) {
                split.setPayeeId(payee_id);
                trans.modifySplit(split); // does not modify the list object 'splits'!
              }
            } // for - Splits
            // store transaction in current schedule
            schedule.setTransaction(trans);
            file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& schedule : used_schedules) {
                    // create copy of transaction in current schedule
                    auto trans = schedule.transaction();
                    // create copy of lists of splits
                    for (auto& split : trans.splits()) {
                        QList<QString> tagIdList = split.tagIdList();
                        for (auto i = 0; i < tagIdList.size(); ++i) {
                            if (d->tagInList(selectedTags, tagIdList[i])) {
                                tagIdList.removeAt(i);
                                if (!newTagId.isEmpty()) {
                                    if (tagIdList.indexOf(newTagId) == -1) {
                                        tagIdList.append(newTagId);
                                    }
                                }
                                i = -1; // restart from the first element
                            }
                        }
                        split.setTagIdList(tagIdList);
                        trans.modifySplit(split); // does not modify the list object 'splits'!
                    } // for - Splits
                    // store transaction in current schedule
                    schedule.setTransaction(trans);
                    file->modifySchedule(schedule);  // modify the schedule in the MyMoney engine
                }
```

#### AUTO 


```{c}
auto list = d->ui->m_register->selectedItems();
```

#### AUTO 


```{c}
auto last = i+1;
```

#### AUTO 


```{c}
auto next = txt;
```

#### AUTO 


```{c}
const auto item = new QTreeWidgetItem(ui->m_currencyList);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->stateFilter->clearFilter();
        d->ui->m_filterContainer->hide();
        d->ui->m_ledgerView->setFocus();
        QMetaObject::invokeMethod(d->ui->m_ledgerView, &LedgerView::ensureCurrentItemIsVisible, Qt::QueuedConnection);
    }
```

#### AUTO 


```{c}
auto strFile(m_qlineeditFile->text());
```

#### AUTO 


```{c}
auto t = d->transaction();
```

#### AUTO 


```{c}
auto font = painter->font();
```

#### AUTO 


```{c}
const auto idx = list.front();
```

#### AUTO 


```{c}
auto acc = account(_acc.id());
```

#### AUTO 


```{c}
const auto maxColumn = model->columnCount();
```

#### AUTO 


```{c}
auto columnSelector = new ColumnSelector(ui->m_parentAccounts);
```

#### AUTO 


```{c}
const auto indexList = match(index(0, 0), Role::EquityID, id, -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto popupView = d->accountCombo->popup();
```

#### AUTO 


```{c}
auto value = data.value<MyMoneyMoney>();
```

#### AUTO 


```{c}
auto tmpAcc = MyMoneyFile::instance()->account(id);
```

#### AUTO 


```{c}
auto i = (int)Element::Account::SubAccount;
```

#### AUTO 


```{c}
const auto fees = d->haveVisibleWidget<AmountEdit>("feesAmountEdit");
```

#### AUTO 


```{c}
const auto account = itAccount->data((int)Role::Account).value<MyMoneyAccount>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &standardPath : QStandardPaths::standardLocations(QStandardPaths::AppDataLocation))
      qWarning() << standardPath;
```

#### AUTO 


```{c}
const auto view = qobject_cast<const SplitView *>(opt.widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
    auto accIdx = file->accountsModel()->indexById(splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString());
    const auto accountGroup = accIdx.data(eMyMoney::Model::AccountGroupRole).value<eMyMoney::Account::Type>();
    if (splitIdx.row() == idx.row()) {
      security = file->security(accIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString());
    } else if (accountGroup == eMyMoney::Account::Type::Expense) {
      feeSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
    } else if (accountGroup == eMyMoney::Account::Type::Income) {
        interestSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
    } else {
      if (!assetAccountSplitIdx.isValid()) { // first asset Account should be our requested brokerage account
        assetAccountSplitIdx = splitIdx;
      } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isNegative()) { // the rest (if present) is handled as fee or interest
        feeSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
      } else if (idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().isPositive()) {
        interestSplitModel->appendSplit(file->journalModel()->itemByIndex(splitIdx).split());
      }
    }
  }
```

#### AUTO 


```{c}
auto itInstitution = new QStandardItem(QIcon::fromTheme(g_Icons.value(Icon::ViewInstitutions)), institution.name());
```

#### AUTO 


```{c}
auto ancientCurrencies = file->ancientCurrencies();
```

#### AUTO 


```{c}
const auto maxColumn = view->model()->columnCount();
```

#### AUTO 


```{c}
auto schedule = MyMoneyFile::instance()->schedule(inputSchedule.id());
```

#### AUTO 


```{c}
const auto& pair = it.key();
```

#### AUTO 


```{c}
auto pattern(c.attribute(attributeName(Attribute::Report::Pattern)));
```

#### AUTO 


```{c}
const auto data = model()->data(model()->index(indexes.front().row(), (int)eAccountsModel::Column::Account, indexes.front().parent()), (int)eAccountsModel::Role::Account);
```

#### AUTO 


```{c}
const auto& report
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
              if (payeeInList(list, split.payeeId())) {
                split.setPayeeId(payee_id);
                trans.modifySplit(split); // does not modify the list object 'splits'!
              }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
      if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer)) {
        auto acc = MyMoneyFile::account(split.accountId());

        if (acc.isAssetLiability()) {
          MyMoneySplit s = split;
          s.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Amortization));
          tCopy.modifySplit(s);
        }
      }
    }
```

#### AUTO 


```{c}
const auto shares = baseIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
auto jobId = d->ui->m_onlineJobView->model()->data(index, onlineJobModel::OnlineJobId).toString();
```

#### AUTO 


```{c}
auto dontShowAgain = "CancelOrEditTransaction";
```

#### AUTO 


```{c}
const auto& acc = static_cast<const MyMoneyAccount&>(obj);
```

#### AUTO 


```{c}
auto accountItem = d->itemFromAccountId(this, id);
```

#### AUTO 


```{c}
auto journalEntry = file->journalModel()->itemById(journalEntryId);
```

#### AUTO 


```{c}
auto model = new payeeIdentifierContainerModel(ui->view);
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("onlinejoboutboxview.rc");
```

#### AUTO 


```{c}
auto itInstitution = d->institutionItemFromId(this, id)
```

#### AUTO 


```{c}
auto i = (int)MyMoneyAccount::Attribute::ID;
```

#### AUTO 


```{c}
auto dropZero = forecast.daysToZeroBalance(acc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& file : qAsConst(files)) {
        const auto url = QUrl::fromUserInput(QString("%1/%2").arg(dir.canonicalPath(), file));
        MyMoneyTemplate tmpl;
        if (d->loadTemplate(url, tmpl)) {
          d->model->addItem(tmpl, parentIdx);
        }
      }
```

#### AUTO 


```{c}
const auto& id = obj.id();
```

#### AUTO 


```{c}
const auto txt = QString::number(idx + 1);
```

#### AUTO 


```{c}
auto account = file->account(accountId);
```

#### AUTO 


```{c}
const auto item = ui->m_selectedList->currentItem();
```

#### LAMBDA EXPRESSION 


```{c}
[](MyMoneyAccount &a1, MyMoneyAccount &a2) {
                return a1.name() < a2.name();
            }
```

#### AUTO 


```{c}
auto splitList = it_t.transaction().splits();
```

#### AUTO 


```{c}
const auto fraction = m_isCashAmount ? sec.smallestCashFraction() : sec.smallestAccountFraction();
```

#### AUTO 


```{c}
auto invertSplitValues = [&]() -> void {
        const auto rows = splitModel.rowCount();
        MyMoneyMoney v;
        for (int row = 0; row < rows; ++row)
        {
            auto idx = splitModel.index(row, 0);
            v = idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
            splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-v), eMyMoney::Model::SplitSharesRole);
            v = idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
            splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-v), eMyMoney::Model::SplitValueRole);
        }
    };
```

#### AUTO 


```{c}
auto value = MyMoneyMoney(data) * MyMoneyMoney(100, 1);
```

#### AUTO 


```{c}
const auto value = split.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : transaction.splits()) {
                if(splitId != sp.id()) {
                    return MyMoneyFile::instance()->accountsModel()->accountIdToHierarchicalName(sp.accountId());
                }
            }
```

#### AUTO 


```{c}
auto tab = static_cast<eView::Investment::Tab>(index);
```

#### AUTO 


```{c}
auto c = pattern[pos];
```

#### AUTO 


```{c}
const auto accList = account.accountList();
```

#### AUTO 


```{c}
const auto msg = i18n("<qt>Do you want to add <b>%1</b> as tag?</qt>", newnameBase);
```

#### AUTO 


```{c}
auto accCycle = q->accountsCycle();
```

#### AUTO 


```{c}
const auto &kpartgui = QStringLiteral("file_import_qif");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& priceInfo : *itPairs) {
      if (lastDate > priceInfo.date()) {
        qDebug() << "Price loader: dates not sorted as needed" << priceInfo.date() << "older than" << lastDate;
      }
      PriceEntry newEntry(priceInfo);
      static_cast<TreeItem<PriceEntry>*>(index(row, 0).internalPointer())->dataRef() = newEntry;
      lastDate = priceInfo.date();
      ++row;
    }
```

#### AUTO 


```{c}
auto split = d->m_transaction.splits()[i];
```

#### AUTO 


```{c}
auto transactions = file->transactionList(filter);
```

#### AUTO 


```{c}
const auto split = right.itemByIndex(idx);
```

#### AUTO 


```{c}
const auto grp = KSharedConfig::openConfig()->group(getConfGrpName(view));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : *m_storagePlugins) {
      if (plugin->formatName().compare(QLatin1String("SQL")) == 0) {
        rc = plugin->open(pStorage, url);
        pluginFound = true;
        break;
      }
    }
```

#### AUTO 


```{c}
const auto groupType = static_cast<eMyMoney::Schedule::Type>(idx.data(eMyMoney::Model::ScheduleTypeRole).toInt());
```

#### AUTO 


```{c}
auto interestEdit = dynamic_cast<AmountEdit*>(haveWidget("interest-amount"));
```

#### AUTO 


```{c}
const auto accountId = d->ui->feesCombo->getSelected();
```

#### AUTO 


```{c}
const auto security = d->haveWidget<QComboBox>("securityCombo");
```

#### AUTO 


```{c}
const auto costCenterId = costCenterModel->data(index, eMyMoney::Model::Roles::IdRole).toString();
```

#### AUTO 


```{c}
auto account = m->account(MyMoneyAccount::stdAccName(eMyMoney::Account::Standard::Expense));
```

#### RANGE FOR STATEMENT 


```{c}
for (QSQLiteResult *result : qAsConst(d->results))
            result->d_func()->finalize();
```

#### AUTO 


```{c}
const auto splits = d->m_schedule.transaction().splits();
```

#### AUTO 


```{c}
auto it = m_profile->m_colNumType.begin();
```

#### AUTO 


```{c}
const auto delim = kt.m_strPayee.isEmpty() ? QChar() : QLatin1Char('/');
```

#### AUTO 


```{c}
auto tab = dynamic_cast<KReportTab*>(m_reportTabWidget->widget(index))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
    auto acc = account(split.accountId());
    if (acc.isClosed())
      throw MYMONEYEXCEPTION(QString::fromLatin1("Cannot remove transaction that references a closed account."));
    d->addCacheNotification(split.accountId(), tr.postDate());
    //FIXME-ALEX Do I need to add d->addCacheNotification(split.tagList()); ??
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tagId : tagIdList) {
                        if (d->tagInList(selectedTags, tagId)) {
                            report.removeReference(tagId);
                            if (!newTagId.isEmpty()) {
                                report.addTag(newTagId);
                            }
                        }
                    }
```

#### AUTO 


```{c}
auto loadAmountEdit = [&](SplitModel* model, AmountEdit* amountEdit) {
        amountEdit->setReadOnly(false);
        amountEdit->setCommodity(transactionCurrency);
        switch (model->rowCount()) {
        case 0:
            amountEdit->clear();
            break;
        case 1: {
            const auto idx = model->index(0, 0);
            amountEdit->setValue(idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>().abs());
            amountEdit->setShares(idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>().abs());
            adjustSharesCommodity(amountEdit, idx.data(eMyMoney::Model::SplitAccountIdRole).toString());
        } break;
        default:
            amountEdit->setValue(model->valueSum().abs());
            amountEdit->setShares(model->valueSum().abs());
            amountEdit->setReadOnly(true);
            break;
        }
    };
```

#### AUTO 


```{c}
const auto priorSelection(m_selections);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        d->categoryChanged(d->feeSplitModel, accountId, d->ui->feesAmountEdit, MyMoneyMoney::ONE);
        d->updateWidgetState();
        if (!d->feeSplitModel->valueSum().isZero()) {
            d->scheduleUpdateTotalAmount();
        }
    }
```

#### AUTO 


```{c}
const auto count = m_file->currenciesModel()->processItems(&writer);
```

#### AUTO 


```{c}
const auto currentItem = itemByIndex(idx);
```

#### AUTO 


```{c}
const auto indeces = indexesByTransactionId(transactionId);
```

#### AUTO 


```{c}
auto prec = MyMoneyMoney::denomToPrec(file->baseCurrency().smallestAccountFraction());
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
        Q_D(KPayeesView);
        emit requestCustomContextMenu(eMenu::Menu::Payee, d->ui->m_payees->mapToGlobal(pos));
    }
```

#### AUTO 


```{c}
auto securityIdx = file->securitiesModel()->indexById(acc.currencyId());
```

#### AUTO 


```{c}
auto taskElem = node.firstChildElement(elementName(Element::OnlineJob::OnlineTask));
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("csvexporter");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t_old.splits()) {
                            // We don't need the split that covers this account,
                            // we just need the other ones.
                            if (split.accountId() != thisaccount.id()) {
                                MyMoneySplit s(split);
                                s.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                s.clearId();
                                s.setBankID(QString());
                                s.removeMatch();

                                // in case the old transaction has two splits
                                // we simply inverse the amount of the current
                                // transaction found in s1. In other cases (more
                                // than two splits we copy all splits and don't
                                // modify the splits. This may lead to unbalanced
                                // transactions which the user has to fix manually
                                if (t_old.splits().count() == 2) {
                                    s.setShares(-s1.shares());
                                    s.setValue(-s1.value());
                                    s.setMemo(s1.memo());
                                }
                                MyMoneyAccount splitAccount = file->account(s.accountId());
                                qDebug("Adding second split to %s(%s)",
                                       qPrintable(splitAccount.name()),
                                       qPrintable(s.accountId()));
                                d->setupPrice(s, splitAccount, d->m_account, statementTransactionUnderImport.m_datePosted);
                                transactionUnderImport.addSplit(s);

                                // check for vat categories
                                if (t_old.splits().count() == 3) {
                                    if (!splitAccount.value(QLatin1String("VatAccount")).isEmpty()) {
                                        newVatAccountId = splitAccount.value(QLatin1String("VatAccount"));
                                        categorySplit = s;
                                    } else {
                                        taxSplit = s;
                                        oldVatAccountId = split.accountId();
                                    }
                                }
                            }
                        }
```

#### AUTO 


```{c}
const auto institution
```

#### AUTO 


```{c}
const auto list = selectedPayees();
```

#### AUTO 


```{c}
const auto rows = d->splitModel.rowCount();
```

#### AUTO 


```{c}
const auto securityIdx = MyMoneyFile::instance()->currenciesModel()->indexById(currencyId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            const auto journalEntry = file->journalModel()->itemById(journalEntryId);
            auto t = journalEntry.transaction();
            auto s = journalEntry.split();
            if (t.isImported()) {
                t.setImported(false);
                if (s.reconcileFlag() < eMyMoney::Split::State::Reconciled) {
                    s.setReconcileFlag(eMyMoney::Split::State::Cleared);
                }
                t.modifySplit(s);
                file->modifyTransaction(t);
            }
            TransactionMatcher matcher;
            matcher.accept(t, s);
        }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyXmlContentHandler2::attributeName(static_cast<Attribute::Budget>(i)).isEmpty();
```

#### AUTO 


```{c}
auto it = m_columnBoxes.cbegin();
```

#### AUTO 


```{c}
auto t = transaction();
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("budgetview");
```

#### AUTO 


```{c}
auto i = (int)MyMoneyBudget::Element::Budget;
```

#### AUTO 


```{c}
auto b = d->isTransfer(name, m_qifProfile.accountDelimiter().left(1), m_qifProfile.accountDelimiter().mid(1, 1));
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyPayee::getElName(static_cast<MyMoneyPayee::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto index = splitModel.index(0, 0);
```

#### AUTO 


```{c}
auto pyFunc = PyObject_GetAttrString(m_weboobInterface, cmethod);
```

#### AUTO 


```{c}
auto acc = findAccount(account, MyMoneyAccount());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& view : d->viewBases) {
        view->updateActions(selections);
    }
```

#### AUTO 


```{c}
auto label = dynamic_cast<QLabel*>(q->haveWidget("price-label"));
```

#### AUTO 


```{c}
auto t
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : t.splits()) {
        if (sp.id() == split.id()) {
            continue;
        }
        const auto rows = splitModel->rowCount();
        int row;
        for (row = 0; row < rows; ++row) {
            const QModelIndex index = splitModel->index(row, 0);
            if (index.data(eMyMoney::Model::IdRole).toString() == sp.id()) {
                break;
            }
        }

        // if the split is not in the model, we get rid of it
        if (splitModel->rowCount() == row) {
            t.removeSplit(sp);
        }
    }
```

#### AUTO 


```{c}
const auto* viewWidget = qobject_cast<const QAbstractItemView*>(opt.widget);
```

#### AUTO 


```{c}
const auto sharesAmount = ui->creditDebitEdit->value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : accounts) {
    const auto sacc = MyMoneyFile::account(acc);
    if (sacc.name().compare(name) == 0)
      return sacc;
  }
```

#### AUTO 


```{c}
auto label = dynamic_cast<QLabel *>(d->m_editor->haveWidget("number-label"))
```

#### AUTO 


```{c}
auto option
```

#### AUTO 


```{c}
const auto transactionFactor(ui->creditDebitEdit->value().isNegative() ? MyMoneyMoney::ONE : MyMoneyMoney::MINUS_ONE);
```

#### AUTO 


```{c}
const auto idx = d->payeesModel->index(d->ui->payeeEdit->currentIndex(), 0);
```

#### AUTO 


```{c}
auto security = new KMyMoneySecurity;
```

#### AUTO 


```{c}
const auto transactionId = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
```

#### AUTO 


```{c}
const auto needCategoryMatch = filter.testFlag(categoryFilterActive);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
    const auto fileExtension = plugin->fileExtension();
    if (!fileExtension.isEmpty()) {
      fileExtensions.append(fileExtension);
      fileExtensions.append(QLatin1String(";;"));
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits)
            matchingSplits.append(s);
```

#### AUTO 


```{c}
const auto& paymentMethod
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySplitPrivate::getAttrName(static_cast<Split::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto firstSplit = true;
```

#### AUTO 


```{c}
auto current = dynamic_cast<KReportTab*>(d->ui.m_reportTabWidget->widget(index));
```

#### AUTO 


```{c}
const auto& institution
```

#### AUTO 


```{c}
auto item = d->ui->m_currencyList->itemAt(p);
```

#### AUTO 


```{c}
const auto idx = d->accountsModel.indexById(account.id());
```

#### AUTO 


```{c}
auto acc = account(id);
```

#### AUTO 


```{c}
const auto idx = sourceModel()->index(source_row, 0, source_parent);
```

#### AUTO 


```{c}
const auto newTransaction = after.transaction();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); ++i) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (d->tagInList(selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          }
```

#### AUTO 


```{c}
const auto journalEntry = MyMoneyFile::instance()->journalModel()->itemById(journalEntryId);
```

#### AUTO 


```{c}
const auto idx = d->m_tagCombo->model()->index(row, 0);
```

#### AUTO 


```{c}
auto itCurrent = itParent;
```

#### AUTO 


```{c}
const auto idx = index(count, 0, favoriteIdx);
```

#### AUTO 


```{c}
const auto &kpartgui = QStringLiteral("file_import_csv");
```

#### AUTO 


```{c}
auto importAction = actionCollection()->addAction(kpartgui);
```

#### AUTO 


```{c}
auto model = const_cast<SplitModel*>(qobject_cast<const SplitModel*>(baseIdx.model()));
```

#### AUTO 


```{c}
auto message = i18n("You are about to finish the reconciliation of this account with a difference between your bank statement and the transactions marked as cleared.\n"
                             "Are you sure you want to finish the reconciliation?");
```

#### AUTO 


```{c}
auto item = dynamic_cast<KTagListItem*>(d->ui->m_tagsList->currentItem());
```

#### AUTO 


```{c}
auto format(QDateEdit::displayFormat());
```

#### AUTO 


```{c}
auto dateEdit = dynamic_cast<KMyMoneyLineEdit*>(d->m_editor->haveWidget("number"))
```

#### AUTO 


```{c}
auto flags = QSortFilterProxyModel::flags(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
    // the following line will throw an exception if the
    // account does not exist or is one of the standard accounts
    const auto acc = account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION_CSTRING("Cannot add split with no account assigned");
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing standard account");
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& actionInfo : actionInfos) {
        QAction *action = d->m_actionCollection->addAction(actionInfo.name, this, actionInfo.callback);
        action->setText(actionInfo.text);
        action->setIcon(Icons::get(actionInfo.icon));
        d->m_actions.insert(actionInfo.id, action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            emit q->deleteSelectedSplits();
        }
```

#### AUTO 


```{c}
const auto grp = KSharedConfig::openConfig()->group(getConfGrpName(m_view));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KCMCSVImporter);
        // Check if the combo box has been loaded. There must
        // be at least one entry in the list. If none is present,
        // we simply call loadProfile() to fix that.
        if (d->ui->qifProfileCombo->count() == 0) {
            d->loadProfiles();
        }
        d->setSelectedProfile(d->ui->qifProfileCombo->currentIndex());
    }
```

#### AUTO 


```{c}
auto schedule(d->m_schedule);
```

#### AUTO 


```{c}
const auto institution = MyMoneyFile::instance()->institution(acc.institutionId());
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<KMyMoneyEdit*>(q->haveWidget("shares"));
```

#### AUTO 


```{c}
auto st = csvImporter->unattendedImport(filename, pricesProfile);
```

#### AUTO 


```{c}
const auto key = QStringLiteral("ir-%1").arg(date.toString(Qt::ISODate));
```

#### AUTO 


```{c}
const auto chartTypeFromXML = d->stringToChartType(e.attribute(d->getAttrName(Report::Attribute::ChartType)));
```

#### AUTO 


```{c}
const auto splitAmount = idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
auto txt = KMyMoneyUtils::reconcileStateToString(d->m_split.reconcileFlag(), text);
```

#### AUTO 


```{c}
auto iter = plugins.cbegin();
```

#### AUTO 


```{c}
const auto journalEntries = d->selections.selection(SelectedObjects::JournalEntry);
```

#### AUTO 


```{c}
const auto view = currentPage();
```

#### AUTO 


```{c}
const auto statusRoles = d->m_view->statusRoles(index);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySchedulePrivate::getElName(static_cast<Schedule::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto categoryId = q->accountId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
        // the following line will throw an exception if the
        // account does not exist or is one of the standard accounts
        auto acc = MyMoneyFile::account(split.accountId());
        if (acc.id().isEmpty())
            throw MYMONEYEXCEPTION_CSTRING("Cannot add split with no account assigned");
        if (acc.isLoan())
            loanAccountAffected = true;
        if (isStandardAccount(split.accountId()))
            throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing standard account");
        if (!split.payeeId().isEmpty()) {
            if (payee(split.payeeId()).id().isEmpty()) {
                throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing unknown payee");
            }
        }
        foreach (const auto tagId, split.tagIdList()) {
            if (!tagId.isEmpty())
                tag(tagId);
        }
    }
```

#### AUTO 


```{c}
auto requiredFields = new KMandatoryFieldGroup(this);
```

#### AUTO 


```{c}
auto mdlItem = d->m_securitiesProxyModel->index(treeItem.row(), SecuritiesModel::Security, treeItem.parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& stock : stocksList) {
    if (!(KMyMoneySettings::hideZeroBalanceEquities() && stock.balance().isZero()))
      d->loadInstitution(this, stock);
  }
```

#### AUTO 


```{c}
auto it = viewFrames.constBegin();
```

#### AUTO 


```{c}
const auto splitId = expMatch.captured(2);
```

#### AUTO 


```{c}
const auto data = model()->data(model()->index(indexes.front().row(), AccountsModel::Account, indexes.front().parent()), AccountsModel::AccountRole);
```

#### AUTO 


```{c}
auto currentAction = toolButton->defaultAction();
```

#### AUTO 


```{c}
const auto org = extractNodeText(doc, "institution/org");
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDate& date) {
        Q_D(KEditScheduleDlg);
        // Make sure the required fields are set
        d->m_schedule.setNextDueDate(d->transactionEditor->postDate());
        d->setScheduleOccurrencePeriod();
        d->m_schedule.setOccurrenceMultiplier(d->ui->frequencyNoEdit->value());

        d->m_schedule.setEndDate(date);
        d->updateTransactionsRemaining();
    }
```

#### AUTO 


```{c}
auto tabCount = d->ui->ledgerTab->count();
```

#### AUTO 


```{c}
auto isSQLiteAutocreated = false;
```

#### CONST EXPRESSION 


```{c}
constexpr int vertMargin = 2;
```

#### AUTO 


```{c}
auto t0 = readTransaction(m_baseNode);
```

#### AUTO 


```{c}
auto asset = new KMyMoneyCategory(0, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &column : visibleColumns) {
                    if (d->applyStorageOffsetColumns.contains(column)) {
                        column -= d->storageOffset;
                    }
                }
```

#### AUTO 


```{c}
const auto dataLockFromXML = d->stringToDataLockAttribute(e.attribute(d->getAttrName(Report::Attribute::DataLock)));
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(stateFilterActive);
```

#### AUTO 


```{c}
auto fileName = QFileDialog::getSaveFileName(
        this,
        i18n("Select output file"),
        QString(),
        QString());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex &parent, int first, int last) {
    Q_UNUSED(parent)
    Q_UNUSED(first)
    Q_UNUSED(last)

    Q_D(LedgerAccountFilter);
    // mark this view for sorting but don't actually start sorting
    // until we come back to the main event loop. This allows to collect
    // multiple row insertions into the model into a single sort run.
    // This is important during import of multiple transactions.
    if (!d->sortPending) {
      d->sortPending = true;
      // in case a recalc operation is pending, we turn it off
      // since we need to sort first. Once sorting is done,
      // the recalc will be triggered again
      d->balanceCalculationPending = false;
      QMetaObject::invokeMethod(this, &LedgerAccountFilter::sortView, Qt::QueuedConnection);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : idList) {
    d->addTagWidget(id);
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    // update the actions in the views
    d->updateActions(d->m_selections);
    emit selectionChanged(d->m_selections);
  }
```

#### AUTO 


```{c}
const auto idx = splitModel.index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
                            // if the split is assigned to one of the selected payees, we need to modify it
                            if (split.isMatched()) {
                                auto tm = split.matchedTransaction();
                                for (auto& sm : tm.splits()) {
                                    if (payeeInList(list, sm.payeeId())) {
                                        sm.setPayeeId(payee_id); // first modify payee in current split
                                        // then modify the split in our local copy of the transaction list
                                        tm.modifySplit(sm); // this does not modify the list object 'splits'!
                                    }
                                }
                                split.addMatch(tm);
                                transaction.modifySplit(split); // this does not modify the list object 'splits'!
                            }
                            if (payeeInList(list, split.payeeId())) {
                                split.setPayeeId(payee_id); // first modify payee in current split
                                // then modify the split in our local copy of the transaction list
                                transaction.modifySplit(split); // this does not modify the list object 'splits'!
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : acc.accountList()) {
    auto accountToMove = d->accountsModel.itemById(accountId);
    reparentAccount(accountToMove, newParent);
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, MyMoneyFile::account(accountToMove.id()));
  }
```

#### AUTO 


```{c}
auto factory = factoryResult.plugin;
```

#### AUTO 


```{c}
auto value = split.value(transaction.commodity(), acc.currencyId());
```

#### AUTO 


```{c}
auto numberEdit = dynamic_cast<kMyMoneyLineEdit*>(q->haveWidget("number"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& subaccStr : subaccounts) {
      const auto subacc = m_file->account(subaccStr);

      auto item = new QStandardItem(subacc.name());                         // initialize first column of subaccount
      node->appendRow(item);                                                // add subaccount row to node
      item->setEditable(false);

      item->setData(node->data((int)Role::DisplayOrder), (int)Role::DisplayOrder);        // inherit display order role from node

      loadSubaccounts(item, favoriteAccountsItem, subacc.accountList());    // subaccount may have subaccounts as well

      // set the account data after the children have been loaded
      const auto row = item->row();
      setAccountData(node, row, subacc, m_columns);                          // initialize rest of columns of subaccount
      loadPreferredAccount(subacc, node, row, favoriteAccountsItem);         // add to favourites node if preferred
    }
```

#### AUTO 


```{c}
const auto sFileToShort = QString::fromLatin1("File %1 is too short.").arg(fileName);
```

#### AUTO 


```{c}
const auto type = static_cast<eMyMoney::Split::InvestmentTransactionType>(index);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) { validateSelectedColumn(col, Column::Category); }
```

#### AUTO 


```{c}
const auto date = QDateTime::fromString(node.attribute(attributeName(Attribute::OnlineJob::BankAnswerDate)), Qt::ISODate);
```

#### AUTO 


```{c}
auto i = (int)Attribute::Budget::ID;
```

#### AUTO 


```{c}
const auto tradingCurrencyId = tradingCurrencyIdx.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto i = (int)idView;
```

#### AUTO 


```{c}
const auto splitIdx = sourceSplitModel->index(0, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
      if (d->canBePrinted(accountId)) {
          for (const auto& transactionId : transactions) {
              if (d->canBePrinted(accountId, transactionId)) {
                  d->printCheck(accountId, transactionId);
              }
          }
      }
  }
```

#### AUTO 


```{c}
const auto pluginDatas = KPluginLoader::findPlugins(QStringLiteral("kmymoney"));
```

#### AUTO 


```{c}
const auto count = m_file->tagsModel()->processItems(&writer);
```

#### AUTO 


```{c}
auto list = QSqlDatabase::drivers();
```

#### AUTO 


```{c}
auto idx = MyMoneyFile::baseModel()->mapToBaseSource(investSplitIdx);
```

#### AUTO 


```{c}
const auto variantReport = reportsPlugin->requestData(QString(), eWidgetPlugin::WidgetType::Budget);
```

#### AUTO 


```{c}
auto tradingCurrency = m_file->security(security.tradingCurrency());
```

#### LAMBDA EXPRESSION 


```{c}
[&](int offset) {
    switch(d->m_dateEdit->currentSection()) {
      case QDateTimeEdit::DaySection:
        slotDateChosen(d->m_date.addDays(offset));
        break;
      case QDateTimeEdit::MonthSection:
        slotDateChosen(d->m_date.addMonths(offset));
        break;
      case QDateTimeEdit::YearSection:
        slotDateChosen(d->m_date.addYears(offset));
        break;
      default:
        break;
    }
  }
```

#### AUTO 


```{c}
const auto rightData = sourceModel()->data(sourceModel()->index(right.row(), (int)Column::Account, right.parent()), (int)Role::TotalValue);
```

#### AUTO 


```{c}
auto foundItems = d->ui->lvEquityList->findItems(_kmmID, Qt::MatchExactly, KMMID_COL);
```

#### AUTO 


```{c}
auto okEnabled = true;
```

#### AUTO 


```{c}
auto number = dynamic_cast<KMyMoneyLineEdit*>(haveWidget("number"))
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDesktopServices::openUrl(webSiteUrl);
        }
```

#### AUTO 


```{c}
const auto value = (file->price(acc.currencyId(), tradingCurrencyId).rate(tradingCurrencyId) * balance);
```

#### AUTO 


```{c}
const auto list = ui->m_payees->model()->match(ui->m_payees->model()->index(0, 0), eMyMoney::Model::IdRole,
                          payeeId,
                          -1,                         // all splits
                          Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive | Qt::MatchRecursive));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        auto list = d->ui->m_ledgerView->selectedTransactions();
        if (list.isEmpty()) {
            d->ui->m_ledgerView->selectMostRecentTransaction();
        } else {
            d->ui->m_ledgerView->ensureCurrentItemIsVisible();
        }
    }
```

#### AUTO 


```{c}
const auto childIndex = index(i, 0);
```

#### AUTO 


```{c}
auto cnt = selector()->slotMakeCompletion(txt.trimmed());
```

#### AUTO 


```{c}
const auto maxColumn = d->view->header()->count();
```

#### AUTO 


```{c}
const auto overlayName = sStandardIcons[description.overlayIcon];
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotEditTransaction(); }
```

#### AUTO 


```{c}
const auto currentRow = currentIndex().row();
```

#### AUTO 


```{c}
const auto rows = d->feeSplitModel.rowCount();
```

#### AUTO 


```{c}
auto occ2 = occ;
```

#### AUTO 


```{c}
auto sharesEdit = d->haveWidget<AmountEdit*>("shares")
```

#### AUTO 


```{c}
auto account = index.data((int)Role::Account).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotFinishReconciliation(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KSearchTransactionDlg);
        if (d->ui.m_tabWidget->currentIndex() == 0) {
            d->filterTab->slotShowHelp();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
          // create a copy of the splits list in the transaction
          // loop over all splits
          for (auto& split : transaction.splits()) {
            QList<QString> tagIdList = split.tagIdList();
            for (int i = 0; i < tagIdList.size(); ++i) {
              // if the split is assigned to one of the selected tags, we need to modify it
              if (d->tagInList(d->m_selectedTags, tagIdList[i])) {
                tagIdList.removeAt(i);
                if (tagIdList.indexOf(tag_id) == -1)
                  tagIdList.append(tag_id);
                i = -1; // restart from the first element
              }
            }
            split.setTagIdList(tagIdList); // first modify tag list in current split
            // then modify the split in our local copy of the transaction list
            transaction.modifySplit(split); // this does not modify the list object 'splits'!
          } // for - Splits
          file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
        }
```

#### AUTO 


```{c}
const auto indexes = d->securitiesModel->match(d->securitiesModel->index(0,0), eMyMoney::Model::IdRole, d->stockSplit.accountId(), 1, Qt::MatchFixedString);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalId : journalEntryList) {
                const auto journalIdx = file->journalModel()->indexById(journalId);
                auto t = file->transaction(journalIdx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
                if (journalIdx.data(eMyMoney::Model::TransactionIsInvestmentRole).toBool()) {
                    /// moving an investment transactions must make sure that the
                    //  necessary (security) accounts exist before the transaction is moved
                    auto toInvAcc = file->account(accountId);
                    // first determine which stock we are dealing with.
                    // fortunately, investment transactions have only one stock involved
                    QString stockAccountId;
                    QString stockSecurityId;
                    MyMoneySplit s;
                    for (const auto& split : t.splits()) {
                        stockAccountId = split.accountId();
                        stockSecurityId = file->account(stockAccountId).currencyId();
                        if (!file->security(stockSecurityId).isCurrency()) {
                            s = split;
                            break;
                        }
                    }
                    // Now check the target investment account to see if it
                    // contains a stock with this id
                    QString newStockAccountId;
                    for (const auto& sAccountId : toInvAcc.accountList()) {
                        if (file->account(sAccountId).currencyId() == stockSecurityId) {
                            newStockAccountId = sAccountId;
                            break;
                        }
                    }
                    // if it doesn't exist, we need to add it as a copy of the old one
                    // no 'copyAccount()' function??
                    if (newStockAccountId.isEmpty()) {
                        MyMoneyAccount stockAccount = file->account(stockAccountId);
                        MyMoneyAccount newStock;
                        newStock.setName(stockAccount.name());
                        newStock.setNumber(stockAccount.number());
                        newStock.setDescription(stockAccount.description());
                        newStock.setInstitutionId(stockAccount.institutionId());
                        newStock.setOpeningDate(stockAccount.openingDate());
                        newStock.setAccountType(stockAccount.accountType());
                        newStock.setCurrencyId(stockAccount.currencyId());
                        newStock.setClosed(stockAccount.isClosed());
                        file->addAccount(newStock, toInvAcc);
                        newStockAccountId = newStock.id();
                    }

                    // now update the split and the transaction
                    s.setAccountId(newStockAccountId);
                    t.modifySplit(s);

                } else {
                    auto s = t.splitById(journalIdx.data(eMyMoney::Model::JournalSplitIdRole).toString());
                    s.setAccountId(accountId);
                    t.modifySplit(s);
                }
                file->modifyTransaction(t);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : tags) {
                  if (d->m_tags.contains(tag)) {
                    found = true;
                    break;
                  }
                }
```

#### AUTO 


```{c}
auto priceEntry = static_cast<TreeItem<PriceEntry>*>(index(idx.row(), 0).internalPointer())->data();
```

#### AUTO 


```{c}
auto index = accountsModel->indexById(view->accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : selection) {
        tagIds.append(tag.id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& actionInfo : actionInfos) {
            d->m_contextMenu->insertAction(nullptr, d->m_actions[actionInfo.id]);
        }
```

#### AUTO 


```{c}
const auto indeces = file->journalModel()->indexesByTransactionId(idx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
```

#### AUTO 


```{c}
auto accountId = list.front().data(eMyMoney::Model::Roles::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : qAsConst(balanceChangedSet)) {
      balances.insert(accountId, balanceCache.value(accountId));
      emit q->balanceChanged(accountId);
    }
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->account(d->accountId);
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto view : qAsConst(viewBases)) {
    view->executeCustomAction(eView::Action::InitializeAfterFileOpen);
  }
```

#### AUTO 


```{c}
const auto shares = splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    Q_D(KInstitutionsView);
    d->ui->m_searchWidget->clear();
    d->ui->m_filterContainer->hide();
  }
```

#### AUTO 


```{c}
const auto frequency(frequencyExp.match(value("interest-changefrequency")));
```

#### AUTO 


```{c}
auto pyFunc = PyObject_GetAttrString(m_pythonWoobModule, cmethod);
```

#### AUTO 


```{c}
auto transaction = readTransaction(nodeList.item(0).toElement());
```

#### AUTO 


```{c}
const auto payeeName = currentText();
```

#### AUTO 


```{c}
auto ba = method.toLocal8Bit();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& schedule : file->scheduleList()) {
      // loop over all splits in the transaction of the schedule
      for (const auto& split : qAsConst(schedule.transaction().splits())) {
        for (auto i = 0; i < split.tagIdList().size(); ++i) {
          // is the tag in the split to be deleted?
          if (d->tagInList(selectedTags, split.tagIdList()[i])) {
            used_schedules.push_back(schedule); // remember this schedule
            break;
          }
        }
      }
    }
```

#### AUTO 


```{c}
const auto baseIdx = model()->index(*allSelectedRows.constBegin(), 0);
```

#### AUTO 


```{c}
const auto chartPaletteFromXML = stringToChartPalette(node.attribute(attributeName(Attribute::Report::ChartPalette)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto baseIdx : indexes) {
      row = journalModel->mapFromBaseSource(model(), baseIdx).row();
      if (row != -1) {
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& splitIdx : list) {
            if (selectedSplitRow == splitIdx.row()) {
                d->ui->dateEdit->setDate(splitIdx.data(eMyMoney::Model::TransactionPostDateRole).toDate());

                const auto payeeId = splitIdx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
                const QModelIndex payeeIdx = MyMoneyFile::instance()->payeesModel()->indexById(payeeId);
                if (payeeIdx.isValid()) {
                    d->ui->payeeEdit->setCurrentIndex(MyMoneyFile::baseModel()->mapFromBaseSource(d->payeesModel, payeeIdx).row());
                } else {
                    d->ui->payeeEdit->setCurrentIndex(0);
                }

                d->ui->memoEdit->clear();
                d->ui->memoEdit->insertPlainText(splitIdx.data(eMyMoney::Model::SplitMemoRole).toString());
                d->ui->memoEdit->moveCursor(QTextCursor::Start);
                d->ui->memoEdit->ensureCursorVisible();

                d->ui->numberEdit->setText(splitIdx.data(eMyMoney::Model::SplitNumberRole).toString());
                d->ui->statusCombo->setCurrentIndex(splitIdx.data(eMyMoney::Model::SplitReconcileFlagRole).toInt());
                d->ui->tagContainer->loadTags(splitIdx.data(eMyMoney::Model::SplitTagIdRole).toStringList());
            } else {
                // block the signals sent out from the model here so that
                // connected widgets don't overwrite the values we just loaded
                // because they are not yet set (d->ui->creditDebitEdit)
                QSignalBlocker blocker(d->splitModel);
                d->splitModel.appendSplit(MyMoneyFile::instance()->journalModel()->itemByIndex(splitIdx).split());

                if (splitIdx.data(eMyMoney::Model::TransactionSplitCountRole) == 2) {
                    // force the value of the second split to be the same as for the first
                    idx = d->splitModel.index(0, 0);
                    d->splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-amountValue), eMyMoney::Model::SplitValueRole);

                    // use the shares based on the second split
                    amountShares = -(splitIdx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>());

                    // adjust the commodity for the shares
                    const auto accountId = splitIdx.data(eMyMoney::Model::SplitAccountIdRole).toString();
                    const auto accountIdx = MyMoneyFile::instance()->accountsModel()->indexById(accountId);
                    const auto currencyId = accountIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString();
                    const auto currency = MyMoneyFile::instance()->currenciesModel()->itemById(currencyId);
                    d->ui->creditDebitEdit->setSharesCommodity(currency);
                }
            }
        }
```

#### AUTO 


```{c}
auto clearComboBox = [&](QComboBox* combobox) { combobox->setCurrentIndex(-1); };
```

#### AUTO 


```{c}
const auto categoryId = ui->categoryCombo->getSelected();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyTagPrivate::getAttrName(static_cast<Tag::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto col = columnAt(event->x());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sConfigName : qAsConst(sConfigNames)) {
            const auto sOldConfigFilename = sOldMainConfigPath + sConfigName;
            const auto sNewConfigFilename = sMainConfigPath + configNamesChange.value(sConfigName, sConfigName);
            if (QFile::exists(sOldConfigFilename)) {
                if (QFile::copy(sOldConfigFilename, sNewConfigFilename))
                    QFile::remove(sOldConfigFilename);
            }
        }
```

#### AUTO 


```{c}
auto it = transactionList.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        // wait another round if any of the buttons is pressed
        for (const auto& button : m_buttons) {
            if (button->isDown()) {
                createPayee();
                return;
            }
        }

        QString payeeId;
        qDebug() << "createPayee" << m_comboBox->currentText();
        if (!KMyMoneyUtils::newPayee(m_comboBox->currentText(), payeeId)) {
            m_comboBox->clearEditText();
            m_comboBox->setCurrentIndex(-1);
            m_comboBox->setFocus();
        } else {
            const auto index = m_comboBox->findData(payeeId, eMyMoney::Model::IdRole);
            if (index != -1) {
                m_comboBox->setCurrentIndex(index);
                auto widget = m_comboBox->nextInFocusChain();
                widget->setFocus();
            } else {
                m_comboBox->clearEditText();
                m_comboBox->setCurrentIndex(-1);
                m_comboBox->setFocus();
            }
        }

        // suicide, we're done
        deleteLater();
    }
```

#### AUTO 


```{c}
const auto detailLevelFromXML = d->stringToDetailLevel(e.attribute(d->getAttrName(Report::Attribute::Detail), "none"));
```

#### AUTO 


```{c}
auto plugins = findPlugins("kmymoney/onlinetasks", [&name](const KPluginMetaData& data) {
        QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
        if (array.isArray())
            return (array.toVariant().toStringList().contains(name));
        return false;
    });
```

#### AUTO 


```{c}
const auto fontsPage = new KSettingsFonts();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& fileType : fileTypes) {
        switch (fileType) {
        case eKMyMoney::StorageType::XML:
            ui->fileType->addItem(i18n("XML"), static_cast<int>(fileType));
            break;
        case eKMyMoney::StorageType::SQL:
            ui->fileType->addItem(i18n("SQL"), static_cast<int>(fileType));

            break;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
const auto schedulesView = static_cast<KScheduledView*>(viewBases[View::Schedules]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : qAsConst(fullBalanceRecalc)) {
        balanceCache[accountId] = MyMoneyMoney();
      }
```

#### AUTO 


```{c}
auto occurrence = static_cast<Schedule::Occurrence>(node.attribute(attributeName(Attribute::Schedule::Occurrence)).toInt());
```

#### AUTO 


```{c}
const auto security = file->security(category.currencyId());
```

#### AUTO 


```{c}
const auto entries = region.split(QLatin1Char('\0'));
```

#### AUTO 


```{c}
const auto clearedBalance = MyMoneyFile::instance()->journalModel()->clearedBalance(dd->accountId, dd->endingBalanceDlg->statementDate());
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::CostCenter));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString& tagId) { return MyMoneyFile::instance()->tagsModel()->itemById(tagId).name(); }
```

#### AUTO 


```{c}
auto category = new KMyMoneyCategory(true, nullptr);
```

#### AUTO 


```{c}
auto isClosed = acc.isClosed() ? true : false;
```

#### AUTO 


```{c}
const auto tag = MyMoneyFile::instance()->tagByName(new_name);
```

#### AUTO 


```{c}
const auto idx = journalModel->index(row, 0);
```

#### AUTO 


```{c}
const auto resultMessages = MyMoneyStatementReader::resultMessages();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        invalidateFilter();
    }
```

#### AUTO 


```{c}
auto account = m->account(MyMoneyAccount::stdAccName(eMyMoney::Account::Standard::Asset));
```

#### AUTO 


```{c}
auto columnSelector = new ColumnSelector(ui->m_accountTree, q->metaObject()->className());
```

#### AUTO 


```{c}
const auto accountId = idx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### AUTO 


```{c}
const auto account = data.value<MyMoneyAccount>();
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->account(id);
```

#### AUTO 


```{c}
auto cashflow = new KMyMoneyCashFlowCombo(0, d->m_account.accountGroup());
```

#### AUTO 


```{c}
auto sec = d->haveWidget<QComboBox>("securityCombo");
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("qifexporter");
```

#### AUTO 


```{c}
const auto margin = style->pixelMetric(QStyle::PM_FocusFrameHMargin);
```

#### AUTO 


```{c}
const auto iconsPage = new KSettingsIcons();
```

#### AUTO 


```{c}
auto idx = d->adjustToSecuritySplitIdx(MyMoneyModelBase::mapToBaseSource(index));
```

#### AUTO 


```{c}
auto accounts = budget.accountsMap();
```

#### AUTO 


```{c}
const auto paymentType = model->index(idx, 0).data(eMyMoney::Model::SchedulePaymentTypeRole).value<eMyMoney::Schedule::PaymentType>();
```

#### AUTO 


```{c}
const auto expenseList = match(index(0, 0),
                                 AccountsModel::AccountIdRole,
                                 MyMoneyFile::instance()->expense().id(),
                                 1,
                                 Qt::MatchFlags(Qt::MatchExactly | Qt::MatchCaseSensitive));
```

#### AUTO 


```{c}
auto reader = std::make_unique<MyMoneyStorageSql>(storage, Models::instance(), url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
            if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest))
                interestAccounts[split.accountId()] = true;
        }
```

#### AUTO 


```{c}
auto a = new QAction(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : qAsConst(selection)) {
      const auto tmpl = model->itemByIndex(idx);
      hierarchy(tmpl.accountTree(), templateHierarchy);
    }
```

#### AUTO 


```{c}
auto cat = haveWidget<KMyMoneyAccountCombo>("assetAccountCombo");
```

#### AUTO 


```{c}
auto statementCount = 0;
```

#### AUTO 


```{c}
auto itSec = d->itemFromSecurityId(this, sec->id());
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
            Q_D(KTagsView);
            emit requestCustomContextMenu(eMenu::Menu::Transaction, d->ui->m_register->mapToGlobal(pos));
        }
```

#### AUTO 


```{c}
auto numberEdit = dynamic_cast<KMyMoneyLineEdit*>(d->m_editor->haveWidget("number"))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sConfigName : sConfigNames) {
      const auto sOldConfigFilename = sOldMainConfigPath + sConfigName;
      const auto sNewConfigFilename = sMainConfigPath + configNamesChange.value(sConfigName, sConfigName);
      if (QFile::exists(sOldConfigFilename)) {
        if (QFile::copy(sOldConfigFilename, sNewConfigFilename))
          QFile::remove(sOldConfigFilename);
      }
    }
```

#### AUTO 


```{c}
const auto& transaction = before.transaction();
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(accountId);
```

#### AUTO 


```{c}
const auto first = MyMoneyFile::instance()->journalModel()->adjustToFirstSplitIdx(index);
```

#### AUTO 


```{c}
auto memo = dynamic_cast<KTextEdit*>(d->m_editWidgets["memo"]);
```

#### AUTO 


```{c}
const auto symbol = QString::fromLatin1("%1 > %2").arg(pair.first, pair.second);
```

#### AUTO 


```{c}
const auto accountName = accountIdx.data(eMyMoney::Model::AccountNameRole).toString();
```

#### AUTO 


```{c}
auto valueStr = value.formatMoney(fraction);
```

#### AUTO 


```{c}
auto cellFont = KMyMoneyGlobalSettings::listCellFont();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotCancelTransaction(); }
```

#### AUTO 


```{c}
auto name = iconDef.value().value(themeIconSet);
```

#### AUTO 


```{c}
const auto rowCount = d->displayString(idx, option).lines.count() + d->displayMatchedString(idx, option).lines.count();
```

#### AUTO 


```{c}
const auto idx = tabIdByAccountId(accountId);
```

#### AUTO 


```{c}
auto cfgHeader = cfgGroup.readEntry("HeaderState", QByteArray());
```

#### AUTO 


```{c}
const auto accountId = journalEntry.split().accountId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item : list) {
    ++itemCount;
    QRegularExpressionMatch m = exp.match(item.id());
    if (m.hasMatch()) {
      const quint64 id = m.captured(1).toUInt();
      if (id > m_nextId) {
        m_nextId = id;
      }
    }
    auto groupIdx = d->indexByType(item.type());
    if (groupIdx.isValid()) {
      const int r = rowCount(groupIdx);
      insertRows(r, 1, groupIdx);
      static_cast<TreeItem<MyMoneySchedule>*>(index(r, 0, groupIdx).internalPointer())->dataRef() = item;
    } else {
      qDebug() << "Invalid schedule item of type" << static_cast<int>(item.type()) << "- Skipped";
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : resultSplits) {
        split.clearId();
        roundSplitValues(split, currencyFraction);
        t.addSplit(split);
    }
```

#### AUTO 


```{c}
const auto reportsPage = new KSettingsReports();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString&  indicator) {
        m_profile->m_debitIndicator = indicator;
        emit completeChanged();
    }
```

#### AUTO 


```{c}
const auto idx = MyMoneyModelBase::mapFromBaseSource(m_renameProxyModel, baseIdx);
```

#### AUTO 


```{c}
auto address = document.createElement(getElName(Element::Address));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : splits) {
                MyMoneyAccount splitAccount = file->account(split.accountId());
                if (!accounts.contains(split.accountId())) {
                    accounts << split.accountId();
                }
                // if this split references an interest account, the action
                // must be of type ActionInterest
                if (interestAccounts.contains(split.accountId())) {
                    if (split.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
                        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
                        split.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
                        transaction.modifySplit(split);
                        file->modifyTransaction(transaction);
                        qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
                    }
                    // if it does not reference an interest account, it must not be
                    // of type ActionInterest
                } else {
                    if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
                        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
                        split.setAction(defaultAction);
                        transaction.modifySplit(split);
                        file->modifyTransaction(transaction);
                        qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
                    }
                }

                // check that for splits referencing an account that has
                // the same currency as the transactions commodity the value
                // and shares field are the same.
                if (transaction.commodity() == splitAccount.currencyId()
                        && split.value() != split.shares()) {
                    qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
                    split.setShares(split.value());
                    transaction.modifySplit(split);
                    file->modifyTransaction(transaction);
                }

                // fix the shares and values to have the correct fraction
                if (!splitAccount.isInvest()) {
                    try {
                        int fract = splitAccount.fraction();
                        if (split.shares() != split.shares().convert(fract)) {
                            qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
                            split.setShares(split.shares().convert(fract));
                            split.setValue(split.value().convert(fract));
                            transaction.modifySplit(split);
                            file->modifyTransaction(transaction);
                        }
                    } catch (const MyMoneyException &) {
                        qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
                    }
                }
            }
```

#### AUTO 


```{c}
auto txt = _e.attribute(getAttrName(Statement::Attribute::Type), txAccountType[Statement::Type::Checkings]);
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<AmountEdit*>(haveWidget("shares"))
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : (*transaction).splits()) {
            const JournalEntry journalEntry(QString("%1-%2").arg(it.key(), split.id()), transaction, split);
            static_cast<TreeItem<JournalEntry>*>(index(row, 0).internalPointer())->dataRef() = journalEntry;
            ++row;
        }
```

#### AUTO 


```{c}
auto writer = new MyMoneyStorageSql(MyMoneyFile::instance(), url);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> void {
        const auto rows = splitModel.rowCount();
        MyMoneyMoney v;
        for (int row = 0; row < rows; ++row)
        {
            auto idx = splitModel.index(row, 0);
            v = idx.data(eMyMoney::Model::SplitSharesRole).value<MyMoneyMoney>();
            splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-v), eMyMoney::Model::SplitSharesRole);
            v = idx.data(eMyMoney::Model::SplitValueRole).value<MyMoneyMoney>();
            splitModel.setData(idx, QVariant::fromValue<MyMoneyMoney>(-v), eMyMoney::Model::SplitValueRole);
        }
    }
```

#### AUTO 


```{c}
auto days = a.daysToZeroBalance(nullAcc);
```

#### AUTO 


```{c}
auto creator = new PayeeCreator(q);
```

#### AUTO 


```{c}
const auto acc = file->account(split.accountId());
```

#### AUTO 


```{c}
auto currentWidgetIndex = d->m_tabOrderWidgets.indexOf(w);
```

#### AUTO 


```{c}
const auto rightModel = MyMoneyModelBase::baseModel(right);
```

#### AUTO 


```{c}
auto script = QString::fromLatin1("import sys\n"
                                    "sys.path.append('%1')\n").arg(fileInfo.absolutePath());
```

#### AUTO 


```{c}
auto dd = static_cast<ReconciliationLedgerViewPage::Private*>(d);
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(tagFilterActive);
```

#### AUTO 


```{c}
const auto curRate = curPrice.rate(file->baseCurrency().id());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    d->stateFilter->clearFilter();
    d->ui->m_filterContainer->hide();
    QMetaObject::invokeMethod(d->ui->m_ledgerView, &LedgerView::ensureCurrentItemIsVisible, Qt::QueuedConnection);
  }
```

#### AUTO 


```{c}
const auto validity = stringToValidityAttribute(c.attribute(attributeName(Attribute::Report::Validity)));
```

#### AUTO 


```{c}
const auto &extension
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    auto list = d->ui->m_ledgerView->selectedTransactions();
    if (list.isEmpty()) {
      d->ui->m_ledgerView->selectMostRecentTransaction();
    } else {
      d->ui->m_ledgerView->ensureCurrentItemIsVisible();
    }
  }
```

#### AUTO 


```{c}
auto it_f = fields.constBegin();
```

#### AUTO 


```{c}
const auto appDataIconsLocation = QStringLiteral("icons");
```

#### AUTO 


```{c}
auto amount = d->haveWidget<AmountEdit>("sharesAmountEdit")
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { checkData(); }
```

#### AUTO 


```{c}
const auto& item = static_cast<TreeItem<ParameterItem>*>(index(row, 0).internalPointer())->constDataRef();
```

#### AUTO 


```{c}
const auto currency = file->currency(acc.currencyId());
```

#### AUTO 


```{c}
const auto model = ui->splitView->model();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : list) {
            if (idx.data(eMyMoney::Model::SplitAccountIdRole).toString() == m_account.id()
                && idx.data(eMyMoney::Model::JournalTransactionIdRole).toString().compare(m_transaction.id())) {
                WidgetHintFrame::show(ui->numberEdit, i18n("The check number <b>%1</b> has already been used in this account.", newNumber));
                rc = false;
                break;
            }
        }
```

#### AUTO 


```{c}
auto tocItem = dynamic_cast<TocItem*>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : transactionIds) {
    const auto indexes = journalModel->indexesByTransactionId(id);
    int row = -1;
    for (const auto baseIdx : indexes) {
      row = journalModel->mapFromBaseSource(model(), baseIdx).row();
      if (row != -1) {
        break;
      }
    }
    if (row == -1) {
      qDebug() << "transaction" << id << "not found anymore for selection. skipped";
      continue;
    }

    if (startRow == -1) {
      startRow = row;
      lastRow = row;
      // use the first as the current index
      if (!currentIdx.isValid()) {
        currentIdx = model()->index(startRow, 0);
      }
    } else {
      if (row == lastRow+1) {
        lastRow = row;
      } else {
        // a new range start, so we take care of it
        createSelectionRange();
      }
    }
  }
```

#### AUTO 


```{c}
auto* widget
```

#### AUTO 


```{c}
auto numberWidget = dynamic_cast<KMyMoneyLineEdit*>(w)
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(sp.accountId());
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySplit::getElName(static_cast<MyMoneySplit::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto memo = index.data(eMyMoney::Model::Roles::SplitSingleLineMemoRole).toString();
```

#### AUTO 


```{c}
const auto data = childNode->data((int)Role::Value);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tag : selectedTags) {
            file->removeTag(tag);
        }
```

#### AUTO 


```{c}
const auto accountID = idx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### AUTO 


```{c}
const auto keySeq = QKeySequence(kev->modifiers() + kev->key());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& s : splits) {

      if (filter.accountFilter ||
          filter.categoryFilter) {
        auto removeSplit = true;
        if (d->m_considerCategory) {
          switch (file->account(s.accountId()).accountGroup()) {
            case eMyMoney::Account::Type::Income:
            case eMyMoney::Account::Type::Expense:
              isTransfer = false;
              // check if the split references one of the categories in the list
              if (filter.categoryFilter) {
                if (d->m_categories.isEmpty()) {
                  // we're looking for transactions with 'no' categories
                  d->m_matchingSplitsCount = 0;
                  matchingSplits.clear();
                  return matchingSplits;
                } else if (d->m_categories.contains(s.accountId())) {
                  categoryMatched = true;
                  removeSplit = false;
                }
              }
              break;

            default:
              // check if the split references one of the accounts in the list
              if (!filter.accountFilter) {
                removeSplit = false;
              } else if (!d->m_accounts.isEmpty() &&
                         d->m_accounts.contains(s.accountId())) {
                accountMatched = true;
                removeSplit = false;
              }

              break;
          }

        } else {
          if (!filter.accountFilter) {
            removeSplit = false;
          } else if (!d->m_accounts.isEmpty() &&
                     d->m_accounts.contains(s.accountId())) {
            accountMatched = true;
            removeSplit = false;
          }
        }

        if (removeSplit)
          continue;
      }

      // check if less frequent filters are active
      if (extendedFilter.allFilter) {
        const auto acc = file->account(s.accountId());
        if (!(matchAmount(s) && matchText(s, acc)))
          continue;

        // Determine if this account is a category or an account
        auto isCategory = false;
        switch (acc.accountGroup()) {
          case eMyMoney::Account::Type::Income:
          case eMyMoney::Account::Type::Expense:
            isCategory = true;
          default:
            break;
        }

        if (!isCategory) {
          // check the payee list
          if (filter.payeeFilter) {
            if (!d->m_payees.isEmpty()) {
              if (s.payeeId().isEmpty() || !d->m_payees.contains(s.payeeId()))
                continue;
            } else if (!s.payeeId().isEmpty())
              continue;
          }

          // check the tag list
          if (filter.tagFilter) {
            const auto tags = s.tagIdList();
            if (!d->m_tags.isEmpty()) {
              if (tags.isEmpty()) {
                continue;
              } else {
                auto found = false;
                for (const auto& tag : tags) {
                  if (d->m_tags.contains(tag)) {
                    found = true;
                    break;
                  }
                }

                if (!found)
                  continue;
              }
            } else if (!tags.isEmpty())
              continue;
          }

          // check the type list
          if (filter.typeFilter &&
              !d->m_types.isEmpty() &&
              !d->m_types.contains(splitType(transaction, s, acc)))
            continue;

          // check the state list
          if (filter.stateFilter &&
              !d->m_states.isEmpty() &&
              !d->m_states.contains(splitState(s)))
            continue;

          if (filter.nrFilter &&
              ((!d->m_fromNr.isEmpty() && s.number() < d->m_fromNr) ||
               (!d->m_toNr.isEmpty() && s.number() > d->m_toNr)))
            continue;

        } else if (filter.payeeFilter
                   || filter.tagFilter
                   || filter.typeFilter
                   || filter.stateFilter
                   || filter.nrFilter) {
          continue;
        }
      }
      if (d->m_reportAllSplits)
        matchingSplits.append(s);

      isMatchingSplitsEmpty = false;
    }
```

#### AUTO 


```{c}
const auto accountType(accountTypeExp.match(m_account.description()));
```

#### AUTO 


```{c}
auto reader = std::make_unique<MyMoneyStorageSql>(storage, MyMoneyFile::instance(), url);
```

#### AUTO 


```{c}
const auto match = exp.match(txtId, 0, QRegularExpression::NormalMatch, QRegularExpression::AnchoredMatchOption);
```

#### AUTO 


```{c}
const auto accountTypeValue = sourceModel()->data(source, eMyMoney::Model::Roles::AccountTypeRole);
```

#### AUTO 


```{c}
auto total = s0.value();
```

#### AUTO 


```{c}
const auto helper
```

#### AUTO 


```{c}
auto i = (int)Schedule::Attribute::Name;
```

#### AUTO 


```{c}
const auto payeeId = idx.data(eMyMoney::Model::SplitPayeeIdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : journalEntries) {
                const auto idx = file->journalModel()->indexById(journalEntryId);
                const auto transactionId = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
                if (d->canBePrinted(accountId, transactionId)) {
                    actionEnabled = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
        if (split.id() == d->split.id()) {
            continue;
        }
        const auto rows = d->feeSplitModel.rowCount();
        int row;
        for (row = 0; row < rows; ++row) {
            const QModelIndex index = d->feeSplitModel.index(row, 0);
            if (index.data(eMyMoney::Model::IdRole).toString() == split.id()) {
                break;
            }
        }

        // if the split is not in the model, we get rid of it
        if (d->feeSplitModel.rowCount() == row) {
            t.removeSplit(split);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                        --idx;
                        if (idx < 0) {
                            idx = tabOrder.count() - 1;
                        }
                        w = findChild<QWidget*>(tabOrder.at(idx));
                    }
```

#### AUTO 


```{c}
auto sch = m->scheduleList(QString(), Schedule::Type::Any, Schedule::Occurrence::Any, Schedule::PaymentType::Any,
                               QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyInstitutionPrivate::getAttrName(static_cast<Institution::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto idx = MyMoneyModelBase::mapToBaseSource(index);
```

#### AUTO 


```{c}
const auto idx = d->findMatchingItem(id);
```

#### AUTO 


```{c}
auto IOnline = qobject_cast<OnlinePlugin *>(plugin);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
      auto value = task.value().toString();
      if (value.isEmpty()) {
        value = QStringLiteral("0");
      }
      query.bindValue(":id", id);
      query.bindValue(":originAccount", task.responsibleAccount());
      query.bindValue(":value", value);
      query.bindValue(":purpose", task.purpose());
      query.bindValue(":endToEndReference", (task.endToEndReference().isEmpty()) ? QVariant() : QVariant::fromValue(task.endToEndReference()));
      query.bindValue(":beneficiaryName", task.beneficiaryTyped().ownerName());
      query.bindValue(":beneficiaryIban", task.beneficiaryTyped().electronicIban());
      query.bindValue(":beneficiaryBic", (task.beneficiaryTyped().storedBic().isEmpty()) ? QVariant() : QVariant::fromValue(task.beneficiaryTyped().storedBic()));
      query.bindValue(":textKey", task.textKey());
      query.bindValue(":subTextKey", task.subTextKey());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint& pos) {
            Q_D(KInvestmentView);
            emit requestCustomContextMenu(eMenu::Menu::Investment, d->ui->m_equitiesTree->viewport()->mapToGlobal(pos));
        }
```

#### AUTO 


```{c}
const auto index = sourceModel()->index(source_row, AccountsModel::Account, source_parent);
```

#### AUTO 


```{c}
const auto idx = firstIndexById(transaction.id());
```

#### AUTO 


```{c}
const auto destIdx = MyMoneyModelBase::lowerBound(newKey);
```

#### AUTO 


```{c}
const auto model = MyMoneyFile::baseModel();
```

#### AUTO 


```{c}
const auto reportType = stringToTypeAttribute(c.attribute(attributeName(Attribute::Report::Type)));
```

#### AUTO 


```{c}
const auto value = index.data(eMyMoney::Model::TransactionFeesValueRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
auto i = proxyModels.count() - 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
            // turn on signals before we modify the last entry in the list
            cnt--;
            MyMoneyFile::instance()->blockSignals(cnt != 0);

            // get a fresh copy
            auto journalEntry = file->journalModel()->itemById(journalEntryId);
            if (!journalEntry.id().isEmpty()) {
                auto t = journalEntry.transaction();
                auto sp = journalEntry.split();
                if (sp.reconcileFlag() != flag) {
                    if (flag == eMyMoney::Split::State::Unknown) {
                        if (!isReconciliationMode) {
                            // in normal mode we cycle through all states
                            switch (sp.reconcileFlag()) {
                                case eMyMoney::Split::State::NotReconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Cleared);
                                    break;
                                case eMyMoney::Split::State::Cleared:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Reconciled);
                                    t.setImported(false);
                                    break;
                                case eMyMoney::Split::State::Reconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                    break;
                                default:
                                    break;
                            }
                        } else {
                            // in reconciliation mode we skip the reconciled state
                            switch (sp.reconcileFlag()) {
                                case eMyMoney::Split::State::NotReconciled:
                                    sp.setReconcileFlag(eMyMoney::Split::State::Cleared);
                                    break;
                                case eMyMoney::Split::State::Cleared:
                                    sp.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                                    break;
                                default:
                                    break;
                            }
                        }
                    } else {
                        sp.setReconcileFlag(flag);
                    }

                    t.modifySplit(sp);
                    MyMoneyFile::instance()->modifyTransaction(t);
                }
            }
        }
```

#### AUTO 


```{c}
auto startRow = idx.row();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QPoint pos) {
    Q_D(KPayeesView);
    emit requestCustomContextMenu(eMenu::Menu::Payee, d->ui->m_payees->mapToGlobal(pos));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : set) {
    switch (change.notificationMode()) {
      case File::Mode::Remove:
        removedObjects += change.id();
        break;
      default:
        break;
    }
  }
```

#### AUTO 


```{c}
const auto currentId = currentIndex.model()->data(currentIndex, eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto modelID = itParentAcc->data(Role::InvestmentID).toString();
```

#### AUTO 


```{c}
auto rc = Activity::isComplete(reason);
```

#### AUTO 


```{c}
const auto itemCount = list.count();
```

#### AUTO 


```{c}
auto payeeId = index.data(eMyMoney::Model::Roles::SplitPayeeIdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& occurrence : occurrences) {
            const auto text = i18n(MyMoneySchedule::occurrenceToString(occurrence));
            rowToScheduleMap.insert(row, occurrence);
            scheduleToRowMap.insert(occurrence, row);
            scheduleToStringMap.insert(occurrence, text);
            stringToScheduleMap.insert(text, occurrence);
            q->setData(q->index(row++, 0), text, Qt::DisplayRole);
        }
```

#### AUTO 


```{c}
auto tip = d->createSplitTooltip(idx);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->accepted = true;
        emit done();
    }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyReport::getAttrName(static_cast<MyMoneyReport::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto codecList = QTextCodec::availableCodecs();
```

#### AUTO 


```{c}
const auto sacc = account(acc);
```

#### AUTO 


```{c}
const auto start = journalModel->MyMoneyModelBase::lowerBound(journalModel->keyForDate(m_beginDate)).row();
```

#### AUTO 


```{c}
const auto iid = account.institutionId();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        // trigger update
        d->delayTimer.start(20);
    }
```

#### AUTO 


```{c}
auto cfgHeader = m_equitiesTree->header()->saveState();
```

#### AUTO 


```{c}
auto num = acc.value("lastNumberUsed");
```

#### AUTO 


```{c}
const auto lastReconciliationDate = acc.lastReconciliationDate().toString(Qt::SystemLocaleShortDate);
```

#### AUTO 


```{c}
const auto &plugin
```

#### AUTO 


```{c}
auto acc = file->account(accountId);
```

#### AUTO 


```{c}
const auto &standardPath
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyTransaction::getElName(static_cast<MyMoneyTransaction::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto rows = splitModel.rowCount();
```

#### AUTO 


```{c}
auto value = s.value(t.commodity(), acc.currencyId());
```

#### AUTO 


```{c}
const auto category = MyMoneyFile::instance()->account(id);
```

#### AUTO 


```{c}
const auto currencyList = d->m_sql->fetchCurrencies().values();
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemById(report.accountId);
```

#### AUTO 


```{c}
const auto indicator = m_file->m_model->item(row, col)->text();
```

#### AUTO 


```{c}
const auto ledgersView = static_cast<KGlobalLedgerView*>(viewBases[View::Ledgers]);
```

#### AUTO 


```{c}
auto i = (int)MyMoneyReport::Element::Payee;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : transactions) {
    const auto& splits = transaction.splits();
    for (const auto& split : splits) {
      if (!result.contains(split.accountId())) {
        result[split.accountId()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
      }
      const auto flag = split.reconcileFlag();
      switch(flag) {
        case eMyMoney::Split::State::NotReconciled:
        case eMyMoney::Split::State::Cleared:
        case eMyMoney::Split::State::Reconciled:
        case eMyMoney::Split::State::Frozen:
          result[split.accountId()][(int)flag]++;
          break;
        default:
          break;
      }

    }
  }
```

#### AUTO 


```{c}
const auto tagLabel = qobject_cast<KTagLabel *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
            if (split.id() != splitId) {
                auto s0 = split;
                s0.clearId();
                s0.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                s0.setReconcileDate(QDate());
                t.addSplit(s0);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            if (d->m_searchDlg)
                d->m_searchDlg->deleteLater();
            d->m_searchDlg = nullptr;
        }
```

#### AUTO 


```{c}
const auto security = MyMoneyFile::instance()->securitiesModel()->itemById(account.tradingCurrencyId());
```

#### AUTO 


```{c}
const auto acc = file->account(s.accountId());
```

#### AUTO 


```{c}
auto attrs = planeDiagram->dataValueAttributes(idx);
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("woob.rc");
```

#### AUTO 


```{c}
auto pyRepr = PyObject_Repr(pyValue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
        if (d->canBePrinted(accountId)) {
            for (const auto& journalEntryId : journalEntries) {
                const auto idx = file->journalModel()->indexById(journalEntryId);
                const auto transactionId = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
                if (d->canBePrinted(accountId, transactionId)) {
                    actionEnabled = true;
                    break;
                }
            }
        }
        if (actionEnabled) {
            break;
        }
    }
```

#### AUTO 


```{c}
const auto idx = indexes.first();
```

#### AUTO 


```{c}
auto oldDate = QDate(d->m_start.year(), d->m_start.month(), 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (MyMoneySplit& split : d->m_splits) {
    split.negateValue();
    split.negateShares();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& plugin: plugins) {
    QJsonValue array = plugin.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iid"];
    if (array.isArray())
      list.append(array.toVariant().toStringList());
  }
```

#### AUTO 


```{c}
const auto& tmpl
```

#### LAMBDA EXPRESSION 


```{c}
[=](int row)
          {
            const auto idx = d->m_tagCombo->model()->index(row, 0);
            const auto id = idx.data(eMyMoney::Model::IdRole).toString();
            d->addTagWidget(id);
          }
```

#### AUTO 


```{c}
auto text = MyMoneySecurity::securityTypeToString(security.securityType());
```

#### AUTO 


```{c}
auto accountSelectorAction = new QWidgetAction(menu);
```

#### AUTO 


```{c}
auto newPos = ui->ledgerTab->count() - 1;
```

#### AUTO 


```{c}
const auto fullName = idx.data(eMyMoney::Model::AccountFullHierarchyNameRole).toString();
```

#### AUTO 


```{c}
auto list = d->checkHierarchy(_list);
```

#### AUTO 


```{c}
auto idx = MyMoneyModelBase::mapToBaseSource(investSplitIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : transaction.splits()) {
              // if the split is assigned to one of the selected payees, we need to modify it
              if (split.isMatched()) {
                auto tm = split.matchedTransaction();
                for (auto& sm : tm.splits()) {
                  if (payeeInList(m_selectedPayeesList, sm.payeeId())) {
                    sm.setPayeeId(payee_id); // first modify payee in current split
                    // then modify the split in our local copy of the transaction list
                    tm.modifySplit(sm); // this does not modify the list object 'splits'!
                  }
                }
                split.addMatch(tm);
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
              if (payeeInList(m_selectedPayeesList, split.payeeId())) {
                split.setPayeeId(payee_id); // first modify payee in current split
                // then modify the split in our local copy of the transaction list
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
            }
```

#### AUTO 


```{c}
auto value = balance * price.rate(tradingCurrency.id());
```

#### AUTO 


```{c}
auto requiredFields = new kMandatoryFieldGroup(this);
```

#### AUTO 


```{c}
const auto selections = m_selections;
```

#### AUTO 


```{c}
auto logFile = QString::fromLatin1("%1/kmm-statement-%2.txt").arg(KMyMoneySettings::logPath(),
                                                                      QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyy-MM-dd hh-mm-ss.zzz")));
```

#### AUTO 


```{c}
const auto index = feeSplitModel.index(row, 0);
```

#### AUTO 


```{c}
auto acc = MyMoneyFile::account((*it_s).accountId());
```

#### AUTO 


```{c}
auto key = PyUnicode_FromString("transactions");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : pPlugins.storage) {
    try {
      if (auto pStorage = plugin->open(url)) {
        MyMoneyFile::instance()->attachStorage(pStorage);
        d->m_storageInfo.type = plugin->storageType();
        if (plugin->storageType() != eKMyMoney::StorageType::GNC) {
          d->m_storageInfo.url = url;
          writeLastUsedFile(url.toDisplayString(QUrl::PreferLocalFile));
          /* Don't use url variable after KRecentFilesAction::addUrl
         * as it might delete it.
         * More in API reference to this method
         */
          d->m_recentFiles->addUrl(url);
        }
        d->m_storageInfo.isOpened = true;
        break;
      }
    } catch (const MyMoneyException &e) {
      KMessageBox::sorry(this, i18n("Cannot open file as requested. Error was: %1", QString::fromLatin1(e.what())));
      return false;
    }
  }
```

#### AUTO 


```{c}
const auto deletedNum = (*it_t).split().number();
```

#### AUTO 


```{c}
const auto transaction = schedule.transaction();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) {
        if (index != -1) {
            const auto idx = d->m_popupView->currentIndex();
            if (d->m_lastSelectedAccount.isEmpty() && idx.isValid()) {
                selectItem(idx);
            }
        }
    }
```

#### AUTO 


```{c}
const auto& plugin
```

#### AUTO 


```{c}
const auto index = model->index(idx, 0);
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::Account));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    Q_D(LedgerFilter);
    d->comboBox = nullptr;
  }
```

#### AUTO 


```{c}
auto column = 0;
```

#### AUTO 


```{c}
auto a = readAccount(m_baseNode);
```

#### AUTO 


```{c}
const auto dispIndex = filterModel->index(index.row(), (int)eLedgerModel::Column::Balance);
```

#### AUTO 


```{c}
auto el = document.createElement(nodeName(Node::KeyValuePairs));
```

#### AUTO 


```{c}
auto accountIdx = indexById(it.key());
```

#### RANGE FOR STATEMENT 


```{c}
for (const MyMoneyAccount &account : allAccounts) {
        if (account.isLoan()) {
          MyMoneyAccountLoan loanAccount(account);
          for (const MyMoneyPayee &payee : list) {
            if (loanAccount.hasReferenceTo(payee.id())) {
              usedAccounts.append(account);
            }
          }
        }
      }
```

#### AUTO 


```{c}
auto addCellToRow = [&, newColPos](auto &&self, QStandardItem *item) -> bool {
        for(auto j = 0; j < item->rowCount(); ++j) {
          auto childItem = item->child(j);
          childItem->insertColumns(newColPos, 1);
          if (childItem->hasChildren())
            self(self, childItem);
          this->d->setAccountData(item, j, childItem->data(AccountRole).value<MyMoneyAccount>(), QList<Columns> {column});
        }
        return true;
      };
```

#### AUTO 


```{c}
auto col = columns.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : indexes) {
        jobIds << idx.data(eMyMoney::Model::IdRole).toString();
    }
```

#### AUTO 


```{c}
const auto idx = index.model()->index(index.row(), column);
```

#### AUTO 


```{c}
auto font = cell->data(Qt::FontRole).value<QFont>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QWidget* editor) { emit const_cast<nationalAccountDelegate*>(this)->closeEditor(editor); }
```

#### AUTO 


```{c}
const auto t0 = QSharedPointer<MyMoneyTransaction>(new MyMoneyTransaction(readTransaction(m_baseNode)));
```

#### AUTO 


```{c}
const auto txt(amount.formatMoney(QString(), d->precision(AmountEdit::DisplayValue), false));
```

#### AUTO 


```{c}
auto txt = clipboard->text();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
    // we don't need to process all columns but only the first one
    if (idx.row() != lastRow) {
      lastRow = idx.row();
      id = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
      if (!selection.contains(id)) {
        selection.append(id);
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : transaction.splits()) {
                if (!split.shares().isZero()) {
                    auto acc = file->account(split.accountId());

                    //workaround for stock accounts which have faulty opening dates
                    QDate openingDate;
                    if (acc.accountType() == eMyMoney::Account::Type::Stock) {
                        auto parentAccount = file->account(acc.parentAccountId());
                        openingDate = parentAccount.openingDate();
                    } else {
                        openingDate = acc.openingDate();
                    }

                    if (q->isForecastAccount(acc) //If it is one of the accounts we are checking, add the amount of the transaction
                            && ((openingDate < transaction.postDate() && q->skipOpeningDate())
                                || !q->skipOpeningDate())) {  //don't take the opening day of the account to calculate balance
                        dailyBalances balance;
                        //FIXME deal with leap years
                        balance = m_accountListPast[acc.id()];
                        if (acc.accountType() == eMyMoney::Account::Type::Income) {//if it is income, the balance is stored as negative number
                            balance[transaction.postDate()] += (split.shares() * MyMoneyMoney::MINUS_ONE);
                        } else {
                            balance[transaction.postDate()] += split.shares();
                        }
                        // check if this is a new account for us
                        m_accountListPast[acc.id()] = balance;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto idx = model->index(*it, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : t.splits()) {
                        split.setReconcileFlag(eMyMoney::Split::State::NotReconciled);
                        split.setReconcileDate(QDate());
                        split.setBankID(QString());
                        split.removeMatch();
                    }
```

#### AUTO 


```{c}
const auto accountId(index.data(eMyMoney::Model::IdRole).toString());
```

#### AUTO 


```{c}
auto type = matchData(ignorecase, keys);
```

#### AUTO 


```{c}
const auto index = d->ui->m_accountTree->currentIndex();
```

#### AUTO 


```{c}
const auto account = MyMoneyFile::instance()->accountsModel()->itemById(accountId);
```

#### AUTO 


```{c}
const auto& actionInfo
```

#### AUTO 


```{c}
const auto formattedValue = profit.isNegative() ? d->formatViewLabelValue(-profit, KMyMoneySettings::schemeColor(SchemeColor::Negative))
                                : d->formatViewLabelValue(profit, KMyMoneySettings::schemeColor(SchemeColor::Positive));
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyKeyValueContainerPrivate::getElName(static_cast<KVC::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto& acc = MyMoneyFile::instance()->account(s.accountId());
```

#### AUTO 


```{c}
const auto splits1 = transaction.splits();
```

#### AUTO 


```{c}
const auto homePage = new KSettingsHome();
```

#### AUTO 


```{c}
const auto selectedPayees = d->selectedPayees();
```

#### AUTO 


```{c}
const auto incomeIdx = baseModel->mapFromBaseSource(this, file->accountsModel()->incomeIndex());
```

#### AUTO 


```{c}
const auto cfgColumns = grp.readEntry("ColumnsSelection", QList<int>());
```

#### AUTO 


```{c}
const auto fontColor = KMyMoneySettings::schemeColor(accountTotalValue.isNegative() ? SchemeColor::Negative : SchemeColor::Positive);
```

#### AUTO 


```{c}
auto lineCount = 20;
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("checkprinting.rc");
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney", [](const KPluginMetaData& data) {
    return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
  });
```

#### AUTO 


```{c}
const auto institutionsView = static_cast<KInstitutionsView*>(viewBases[view]);
```

#### AUTO 


```{c}
auto prev = d->ui->m_homePageList->item(d->ui->m_homePageList->row(item) - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tmpl : templates) {
      loader.importTemplate(tmpl);
    }
```

#### AUTO 


```{c}
auto payee4 = MyMoneyXmlContentHandler::readPayee(el);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QComboBox* combobox) { combobox->setCurrentIndex(-1); }
```

#### AUTO 


```{c}
const auto& pluginGroup
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : list) {
        f.addPayee(payee.id());
      }
```

#### LAMBDA EXPRESSION 


```{c}
[this](onlineJobAdministration::onlineJobEditOffer in) {this->loadOnlineJobEditPlugin(in);}
```

#### AUTO 


```{c}
const auto id = idx.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto accountsModel = Models::instance()->accountsModel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accountIds) {
        if (!isDatePostOpeningDate(date, accountId)) {
            MyMoneyAccount account = MyMoneyFile::instance()->account(accountId);
            WidgetHintFrame::show(ui->dateEdit, i18n("The posting date is prior to the opening date of account <b>%1</b>.", account.name()));
            rc = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto w = d->haveWidget<QWidget>(name);
```

#### AUTO 


```{c}
auto bal = dlg->openingBalance();
```

#### AUTO 


```{c}
const auto rows = m_transactionFilter->rowCount();
```

#### AUTO 


```{c}
auto allPluginDatas = KMyMoneyPlugin::listPlugins(false);
```

#### AUTO 


```{c}
const auto accId = idx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### AUTO 


```{c}
auto createSelectionRange = [&]() {
    if (startRow != -1) {
      selection.select(model()->index(startRow, 0), model()->index(lastRow, lastColumn));
      startRow = -1;
    }
  };
```

#### AUTO 


```{c}
auto iYear = dToday.year();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& acc : accounts) {
    auto a = account(acc);
    a.setInstitutionId(QString());
    modifyAccount(a);
    d->m_changeSet += MyMoneyNotification(File::Mode::Modify, a);
  }
```

#### AUTO 


```{c}
auto favoriteAccountsItem = d->itemFromAccountId(this, favoritesAccountId)
```

#### AUTO 


```{c}
const auto beforeIdEmpty = before.id().isEmpty();
```

#### AUTO 


```{c}
const auto accountId = d->m_selections.firstSelection(SelectedObjects::Account);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& plugin : pPlugins.storage) {
    if (plugin->storageType() == d->m_storageInfo.type) {
      d->consistencyCheck(false);
      try {
        if (plugin->save(d->m_storageInfo.url)) {
          d->fileAction(eKMyMoney::FileAction::Saved);
          return true;
        }
        return false;
      } catch (const MyMoneyException &e) {
        KMessageBox::detailedError(this, i18n("Failed to save your storage."), e.what());
        return false;
      }
    }
  }
```

#### AUTO 


```{c}
const auto idx = MyMoneyFile::instance()->journalModel()->index(d->row, 0);
```

#### AUTO 


```{c}
auto plugins = findPlugins("kmymoney_plugins/onlinetasks", [&name](const KPluginMetaData& data) {
        QJsonValue array = data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Iids"];
        if (array.isArray())
            return (array.toVariant().toStringList().contains(name));
        return false;
    });
```

#### AUTO 


```{c}
const auto subacc = d->m_file->account(*subaccStr);
```

#### AUTO 


```{c}
const auto stockPointSize = q->font().pointSizeF();
```

#### AUTO 


```{c}
const auto tagIdList = split.tagIdList();
```

#### AUTO 


```{c}
auto list_s = file->scheduleList(QString(), eMyMoney::Schedule::Type::Any, eMyMoney::Schedule::Occurrence::Any, eMyMoney::Schedule::PaymentType::Any,
                                      QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto oldOccurrenceMultiplier = d->m_schedule.occurrenceMultiplier();
```

#### AUTO 


```{c}
auto sc = m_storage->schedule(m_suspectList[si]);
```

#### AUTO 


```{c}
auto feesEdit = dynamic_cast<kMyMoneyEdit*>(haveWidget("fee-amount"));
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyTransactionPrivate *>(right.d_func());
```

#### AUTO 


```{c}
const auto keySeq = QKeySequence(event->modifiers() + event->key());
```

#### AUTO 


```{c}
const auto model = MyMoneyFile::instance()->accountsModel();
```

#### AUTO 


```{c}
auto parentAccountItem = d->itemFromAccountId(this, account.parentAccountId());
```

#### AUTO 


```{c}
const auto tmpl = model->itemByIndex(idx);
```

#### AUTO 


```{c}
const auto list = moveToAccountSelector->accountList();
```

#### AUTO 


```{c}
const auto baseIdx = MyMoneyFile::instance()->accountsModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
const auto account_id = QString::fromUtf8(data.account_id).trimmed();
```

#### AUTO 


```{c}
const auto list = m_file->scheduleList(QString(), Schedule::Type::Any, Schedule::Occurrence::Any, Schedule::PaymentType::Any,
                                               QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto t = d->m_schedule.transaction();
```

#### AUTO 


```{c}
auto reconciliationView = new ReconciliationLedgerViewPage(q, configGroupName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& a : actionsToBeDisabled)
        pActions[a]->setEnabled(false);
```

#### AUTO 


```{c}
auto rc = LedgerFilterBase::filterAcceptsRow(source_row, source_parent);
```

#### AUTO 


```{c}
const auto leftPos = filterFixedStrings().indexOf(left.data(eMyMoney::Model::IdRole).toString());
```

#### AUTO 


```{c}
auto it_account = accounts.constBegin();
```

#### AUTO 


```{c}
const auto oldSplitCount = static_cast<int>(oldTransaction.splitCount());
```

#### AUTO 


```{c}
const auto selection = selectedPayees();
```

#### AUTO 


```{c}
const auto sNewConfigFilename = sMainConfigPath + configNamesChange.value(sConfigName, sConfigName);
```

#### AUTO 


```{c}
auto ke = dynamic_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
const auto model = file->tagsModel();
```

#### AUTO 


```{c}
const auto rows = invhold.rows();
```

#### AUTO 


```{c}
const auto numericChars(numericCharsExp.match(c));
```

#### AUTO 


```{c}
auto amount = d->ui->creditDebitEdit->value();
```

#### LAMBDA EXPRESSION 


```{c}
[this, a] { showPageAndFocus(static_cast<View>(a->data().toUInt())); }
```

#### AUTO 


```{c}
auto saveToLocalFile = [&](QSaveFile* qfile)
    {
      QTextStream stream(qfile);
      stream.setCodec("UTF-8");
      stream << m_doc.toString();
      stream.flush();
    };
```

#### AUTO 


```{c}
auto map = MyMoneyDbDriver::driverMap();
```

#### AUTO 


```{c}
const auto generalPage = new KSettingsGeneral();
```

#### AUTO 


```{c}
auto matchType = newPayee.matchData(ignorecase, payeeNames);
```

#### AUTO 


```{c}
const auto model = MyMoneyFile::instance()->journalModel();
```

#### AUTO 


```{c}
auto cfgHeader = ui->m_equitiesTree->header()->saveState();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &index : indexes) {
      if(showValuesInverted) {
        balance -= filterModel->data(index, eMyMoney::Model::Roles::SplitSharesRole).value<MyMoneyMoney>();
      } else {
        balance += filterModel->data(index, eMyMoney::Model::Roles::SplitSharesRole).value<MyMoneyMoney>();
      }
      const auto txt = balance.formatMoney(account.fraction());
      const auto dispIndex = filterModel->index(index.row(), JournalModel::Column::Balance);
      filterModel->setData(dispIndex, txt, Qt::DisplayRole);
    }
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::Institution>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : qAsConst(splits)) {
        list.append(qMakePair(journalEntry.transaction(), split));
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& categoryId) {
        d->categoryChanged(categoryId);
    }
```

#### AUTO 


```{c}
auto pStorage = MyMoneyFile::instance()->storage();
```

#### AUTO 


```{c}
const auto newName = d->ui->m_currencyList->currentItem()->text(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : transaction.splits()) {
            if (!split.shares().isZero()) {
                if (acc.id() == split.accountId()) netIncome += split.value();
            }
        }
```

#### AUTO 


```{c}
const auto payee = file->payee(split.payeeId());
```

#### AUTO 


```{c}
const auto acc = accountsModel->itemByIndex(index);
```

#### AUTO 


```{c}
auto rect = dlg_d->indicatorRectangle(w, d->m_indicatorFontMetrics.size(Qt::TextSingleLine, txt));
```

#### AUTO 


```{c}
const auto driverName = d->selectedDriver();
```

#### AUTO 


```{c}
auto tid = file->openingBalanceTransaction(m_currentAccount);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : d->ui->m_tagsList->selectionModel()->selectedIndexes()) {
        baseIdx = model->mapToBaseSource(idx);
        const auto tag = model->itemByIndex(baseIdx);
        if (!tag.id().isEmpty()) {
            selectedTags.append(tag);
        }
    }
```

#### AUTO 


```{c}
auto l = dynamic_cast<QLabel*>(haveWidget("fee-amount-label"));
```

#### AUTO 


```{c}
auto balance = baseIdx.data(eMyMoney::Model::AccountBalanceRole).value<MyMoneyMoney>();
```

#### AUTO 


```{c}
const auto idx = MyMoneyFile::instance()->onlineJobsModel()->indexById(jobId);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
        kgpg->addRecipient(key.toLatin1());
      }
```

#### AUTO 


```{c}
const auto subAccount = list.value(subAccountId);
```

#### AUTO 


```{c}
const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(split.accountId());
```

#### AUTO 


```{c}
const auto& button
```

#### AUTO 


```{c}
const auto rows = rowCount();
```

#### AUTO 


```{c}
const auto font = QVariant(cell->data(Qt::FontRole).value<QFont>());
```

#### AUTO 


```{c}
auto b = readBudget(m_baseNode);
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("weboob.rc");
```

#### AUTO 


```{c}
auto row = d->ui->m_budgetList->selectionModel()->selectedIndexes().first().row();
```

#### AUTO 


```{c}
auto list = match(index(0, 0), AccountsModel::AccountIdRole, id, -1, Qt::MatchFlags(Qt::MatchExactly | Qt::MatchRecursive));
```

#### AUTO 


```{c}
const auto storageId = MyMoneyFile::instance()->storageId().remove(QRegularExpression("[\\{\\}]"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
        if (split.accountId().compare(id) != 0)
          continue;
        else if (split.action().compare(MyMoneySplit::actionName(eMyMoney::Split::Action::SplitShares)) == 0)
          balance *= split.shares();
        else
          balance += split.shares();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : qAsConst(budgetIds)) {
      auto budget = file->budget(id);
      file->removeBudget(budget);
    }
```

#### AUTO 


```{c}
const auto end = m_reader->d->fileInfoKvp.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KCurrencyEditorDlg);
        d->validateValues();
    }
```

#### AUTO 


```{c}
auto sec = dynamic_cast<const MyMoneySecurity * const>(obj);
```

#### AUTO 


```{c}
const auto ledgersView = static_cast<KGlobalLedgerView*>(viewBases[view]);
```

#### AUTO 


```{c}
const auto idx = journalModel->indexById(journalEntryId);
```

#### AUTO 


```{c}
auto favoriteAccountsItem = d->itemFromAccountId(this, favoritesAccountId);
```

#### AUTO 


```{c}
auto shareEdit = dynamic_cast<AmountEdit*>(haveWidget("shares"))
```

#### AUTO 


```{c}
const auto row = ui->m_frequencyEdit->currentIndex();
```

#### AUTO 


```{c}
const auto accountTotalValueStr = QVariant::fromValue(MyMoneyUtils::formatMoney(accountTotalValue, m_file->baseCurrency()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& statement : statements) {
    const auto singleImportSummary = statementInterface()->import(statement);
    if (singleImportSummary.isEmpty())
      ret = false;

    importSummary.append(singleImportSummary);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : journalEntry.transaction().splits()) {
          const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(sp.accountId());
          if (acc.accountType() == eMyMoney::Account::Type::Investment) {
            return acc.id();
          }
          if (acc.isInvest()) {
            accountId = acc.parentAccountId();
          }
        }
```

#### AUTO 


```{c}
auto le = dynamic_cast<KLineEdit*>(o)
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
      query.bindValue(":id", obj.idString());
      query.bindValue(":countryCode", payeeIdentifier->country());
      query.bindValue(":accountNumber", payeeIdentifier->accountNumber());
      query.bindValue(":bankCode", (payeeIdentifier->bankCode().isEmpty()) ? QVariant(QVariant::String) : payeeIdentifier->bankCode());
      query.bindValue(":name", payeeIdentifier->ownerName());
      if (!query.exec()) { // krazy:exclude=crashy
        qWarning("Error while saving national account number for '%s': %s", qPrintable(obj.idString()), qPrintable(query.lastError().text()));
        return false;
      }
      return true;

    }
```

#### AUTO 


```{c}
const auto& statement
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotMarkCleared(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : ids)
    addCategory(id);
```

#### AUTO 


```{c}
const auto pushButton = focusWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
      if ((rc |= static_cast<TreeItem<T>*>(idx.internalPointer())->constDataRef().hasReferenceTo(id)) == true)
        break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& it : m_selectedTransactions) {
            if (it.transaction().isImported()) {
                if (toBeDeleted.transaction().id().isEmpty()) {
                    toBeDeleted = it;
                } else {
                    //This is a second imported transaction, we still want to merge
                    remaining = it;
                }
            } else if (!it.split().isMatched()) {
                if (remaining.transaction().id().isEmpty()) {
                    remaining = it;
                } else {
                    toBeDeleted = it;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits2) {
        d->accountsModel.touchAccountById(split.accountId());
        d->addCacheNotification(split.accountId(), transaction.postDate());
    }
```

#### AUTO 


```{c}
auto index = m_profile->m_colTypeNum.value(it.key());
```

#### AUTO 


```{c}
auto i = (int)View::Institutions;
```

#### RANGE FOR STATEMENT 


```{c}
for(const KPluginMetaData& pluginData: plugins) {
        KPluginInfo info {pluginData};
        // Add plugin to selector, just in case it was not found on construction time already.
        // Duplicates should be detected by KPluginSelector.
        m_pluginSelector->addPlugins(QList<KPluginInfo> {info}, KPluginSelector::PluginLoadMethod::ReadConfigFile, categoryByPluginType(pluginData));

        // Only load plugins which are enabled and have the right serviceType. Other serviceTypes are loaded on demand.
        if (info.isPluginEnabled() && pluginData.serviceTypes().contains("KMyMoney/Plugin"))
          loadPlugin(pluginData);
    }
```

#### AUTO 


```{c}
auto trans = schedule.transaction();
```

#### AUTO 


```{c}
auto st = csvImporter->unattendedImport(filename, investmentProfile);
```

#### AUTO 


```{c}
auto tag_id = dlg->show(selectedTagIds);
```

#### AUTO 


```{c}
auto b = MyMoneyXmlContentHandler2::readBudget(m_baseNode);
```

#### AUTO 


```{c}
auto model = sourceModel();
```

#### AUTO 


```{c}
const auto rows = qtbl.rows();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : pPlugins.storage) {
        try {
            if (plugin->open(url)) {
                d->m_storageInfo.type = plugin->storageType();
                if (plugin->storageType() != eKMyMoney::StorageType::GNC) {
                    d->m_storageInfo.url = plugin->openUrl();
                    writeLastUsedFile(url.toDisplayString(QUrl::PreferLocalFile));
                    /* Don't use url variable after KRecentFilesAction::addUrl
                    * as it might delete it.
                    * More in API reference to this method
                    */
                    d->m_recentFiles->addUrl(url);
                }
                d->m_storageInfo.isOpened = true;
                break;
            }
        } catch (const MyMoneyException &e) {
            KMessageBox::detailedError(this, i18n("Cannot open file as requested."), QString::fromLatin1(e.what()));
            return false;
        }
    }
```

#### AUTO 


```{c}
auto acc = d->m_accountList[account];
```

#### AUTO 


```{c}
const auto id = acc.id();
```

#### AUTO 


```{c}
const auto currencyId = transaction.commodity();
```

#### AUTO 


```{c}
const auto closeParen = QStringLiteral(")");
```

#### AUTO 


```{c}
auto icon = Icon::ViewForecast;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
            if ((rc |= static_cast<TreeItem<T>*>(idx.internalPointer())->constDataRef().hasReferenceTo(id)) == true)
                break;
        }
```

#### AUTO 


```{c}
auto plugins = findPlugins("kmymoney_plugins/onlinetasks", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accId : list) {
                    const auto idx = file->accountsModel()->indexById(accId);
                    if (!currencyIds.contains(idx.data(eMyMoney::Model::AccountCurrencyIdRole).toString())) {
                        moveToAccountSelector->removeItem(accId);
                    }
                }
```

#### AUTO 


```{c}
auto next = ui->m_availableList->item(ui->m_availableList->row(item) + 1);
```

#### AUTO 


```{c}
auto m = dynamic_cast<KMyMoneyRegister::GroupMarker*>(p);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) { validateSelectedColumn(col, Column::Debit); }
```

#### AUTO 


```{c}
auto index = MyMoneyFile::baseModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto name = indexes.at(0).data(eMyMoney::Model::SplitPayeeRole).toString();
```

#### AUTO 


```{c}
const auto accountValueStr = QVariant::fromValue(MyMoneyUtils::formatMoney(accountValue, m_file->baseCurrency()));
```

#### AUTO 


```{c}
const auto modelIdx = parent.model()->index(row, 0, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : trans.splits()) {
              if (payeeInList(m_selectedPayeesList, split.payeeId())) {
                split.setPayeeId(payee_id);
                trans.modifySplit(split); // does not modify the list object 'splits'!
              }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const MyMoneyReport &rep1, const MyMoneyReport &rep2) {
        return rep1.name().localeAwareCompare(rep2.name()) < 0;
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto split : d->m_splits) {
        ids.unite(split.referencedObjects());
    }
```

#### AUTO 


```{c}
auto aC = actionCollection();
```

#### AUTO 


```{c}
auto accountSelectorAction = qobject_cast<QWidgetAction*>(actionList.at(1));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const view : viewBases) {
    view->updateActions(selections);
  }
```

#### AUTO 


```{c}
auto pluginName = QString();
```

#### AUTO 


```{c}
const auto id = first.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.payeeFilter;
```

#### AUTO 


```{c}
const auto contains = d->m_visColumns.contains(idColumn);
```

#### AUTO 


```{c}
auto tabOrderWidget = static_cast<TabOrderEditorInterface*>(qt_metacast("TabOrderEditorInterface"));
```

#### AUTO 


```{c}
auto tocItem = dynamic_cast<TocItem*>(d->m_tocTreeWidget->currentItem())
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            const auto list = q->selectionModel()->selectedRows();
            QPersistentModelIndex newCurrentIdx;
            for (const auto idx : list) {
                const auto id = idx.data(eMyMoney::Model::IdRole).toString();
                if (!(id.isEmpty() || id.endsWith('-'))) {
                    // we can use any model object for the next operation, but we have to use one
                    const auto baseIdx = MyMoneyFile::instance()->accountsModel()->mapToBaseSource(idx);
                    auto model = const_cast<SplitModel*>(qobject_cast<const SplitModel*>(baseIdx.model()));
                    if (model) {
                        // get the original data
                        const auto split = model->itemByIndex(baseIdx);

                        model->appendEmptySplit();
                        const auto newIdx = model->emptySplit();
                        // prevent update signals
                        QSignalBlocker block(model);
                        // the id of the split will be automatically assigned by the model
                        model->setData(newIdx, split.number(), eMyMoney::Model::SplitNumberRole);
                        model->setData(newIdx, split.memo(), eMyMoney::Model::SplitMemoRole);
                        model->setData(newIdx, split.accountId(), eMyMoney::Model::SplitAccountIdRole);
                        model->setData(newIdx, split.costCenterId(), eMyMoney::Model::SplitCostCenterIdRole);
                        model->setData(newIdx, split.payeeId(), eMyMoney::Model::SplitPayeeIdRole);
                        model->setData(newIdx, QVariant::fromValue<MyMoneyMoney>(split.shares()), eMyMoney::Model::SplitSharesRole);
                        // send out the dataChanged signal with the next (last) setData()
                        block.unblock();
                        model->setData(newIdx, QVariant::fromValue<MyMoneyMoney>(split.value()), eMyMoney::Model::SplitValueRole);

                        // now add a new empty split at the end
                        model->appendEmptySplit();
                        // and make the new split the current one
                        if (!newCurrentIdx.isValid()) {
                            newCurrentIdx = newIdx;
                        }
                    }
                }
            }
            if (newCurrentIdx.isValid()) {
                q->setCurrentIndex(newCurrentIdx);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& statement : statements) {
    if (abort)
      break;
    if (importStatement(statement).isEmpty())
      ok = false;
  }
```

#### AUTO 


```{c}
auto url = QFileDialog::getOpenFileUrl(nullptr, QString(), QUrl(), i18n("GnuCash files (*.gnucash *.xac *.gnc);;All files (*)"));
```

#### AUTO 


```{c}
const auto inst = file->institutionsModel()->itemById(ids.at(0));
```

#### AUTO 


```{c}
auto mandatory = new kMandatoryFieldGroup(this);
```

#### AUTO 


```{c}
auto reportTocItem = dynamic_cast<TocItemReport*>(tocItems.at(0));
```

#### AUTO 


```{c}
auto accountId = view()->currentIndex().data(eMyMoney::Model::Roles::IdRole).toString();
```

#### AUTO 


```{c}
auto name = payee.name();
```

#### AUTO 


```{c}
auto &plugin
```

#### AUTO 


```{c}
const auto interestRateDate(interestRateExp.match(it.key()));
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(KEditScheduleDlg);
        const auto model = d->ui->m_paymentMethodEdit->model();
        const auto paymentType = model->index(idx, 0).data(eMyMoney::Model::SchedulePaymentTypeRole).value<eMyMoney::Schedule::PaymentType>();
        const bool isWriteCheck = paymentType == Schedule::PaymentType::WriteChecque;
        d->m_editor->setShowNumberWidget(isWriteCheck);
    }
```

#### AUTO 


```{c}
const auto indexes = filterModel->match(start, eMyMoney::Model::Roles::SplitAccountIdRole, account.id(), -1);
```

#### AUTO 


```{c}
const auto vatAccount = MyMoneyFile::instance()->account(account.value("VatAccount"));
```

#### AUTO 


```{c}
const auto classAndMethod(classMethodExp.match(name));
```

#### AUTO 


```{c}
const auto isNegative = val.isNegative();
```

#### AUTO 


```{c}
const auto splitCount = transaction.splits().count();
```

#### AUTO 


```{c}
auto acc = account(accountId);
```

#### AUTO 


```{c}
auto haveEquityAccount = false;
```

#### AUTO 


```{c}
auto row = d->ui->m_quoteSourceList->currentRow();
```

#### AUTO 


```{c}
const auto idx = viewModel->index(row, 0);
```

#### AUTO 


```{c}
auto aboutApp = aC->action(QString::fromLatin1(KStandardAction::name(KStandardAction::AboutApp)));
```

#### AUTO 


```{c}
auto ret = true;
```

#### AUTO 


```{c}
auto result(MyMoneyMoney::ONE);
```

#### AUTO 


```{c}
auto institutionList = d->m_file->institutionList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : qAsConst(accounts)) {
            if (account.hasOnlineMapping()) {
                for (const auto& onlineTaskIid : plugin->availableJobs(account.id())) {
                    if (m_onlineTasks.contains(onlineTaskIid)) {
                        return true;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto i = (int)OnlineJob::Element::OnlineTask;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& accountId) {
        d->setupAssetAccount(accountId);
        d->assetSplit.setAccountId(accountId);

        // check the opening dates of this account and
        // update the widgets accordingly
        d->postdateChanged(d->ui->dateEdit->date());
        d->updateWidgetState();
    }
```

#### AUTO 


```{c}
const auto grp = KSharedConfig::openConfig()->group(d->getConfGrpName(view));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : actionInfos) {
            auto a = new QAction(Icons::get(info.icon), info.text, nullptr); // WARNING: no empty Icon::Empty here
            a->setEnabled(info.enabled);
            connect(a, &QAction::triggered, this, info.callback);
            LUTActions.append(a);
        }
```

#### AUTO 


```{c}
const auto endDate = endingBalanceDlg->statementDate();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
    // the following line will throw an exception if the
    // account does not exist
    auto acc = MyMoneyFile::account(split.accountId());
    if (acc.id().isEmpty())
      throw MYMONEYEXCEPTION_CSTRING("Cannot store split with no account assigned");
    if (isStandardAccount(split.accountId()))
      throw MYMONEYEXCEPTION_CSTRING("Cannot store split referencing standard account");
    if (acc.isLoan() && (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer)))
      loanAccountAffected = true;
  }
```

#### AUTO 


```{c}
const auto accountId = index.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
auto amount = d->haveWidget<AmountEdit*>("shares")
```

#### AUTO 


```{c}
auto currency = security(account.currencyId());
```

#### AUTO 


```{c}
auto menu = new QMenu;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& split : splits) {
      MyMoneyAccount splitAccount = file->account(split.accountId());
      if (!accounts.contains(split.accountId())) {
        accounts << split.accountId();
      }
      // if this split references an interest account, the action
      // must be of type ActionInterest
      if (interestAccounts.contains(split.accountId())) {
        if (split.action() != MyMoneySplit::ActionInterest) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " contains an interest account (" << split.accountId() << ") but does not have ActionInterest";
          split.setAction(MyMoneySplit::ActionInterest);
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
        // if it does not reference an interest account, it must not be
        // of type ActionInterest
      } else {
        if (split.action() == MyMoneySplit::ActionInterest) {
          qDebug() << Q_FUNC_INFO << " " << transaction.id() << " does not contain an interest account so it should not have ActionInterest";
          split.setAction(defaultAction);
          transaction.modifySplit(split);
          file->modifyTransaction(transaction);
          qDebug("Fixed interest action in %s", qPrintable(transaction.id()));
        }
      }

      // check that for splits referencing an account that has
      // the same currency as the transactions commodity the value
      // and shares field are the same.
      if (transaction.commodity() == splitAccount.currencyId()
          && split.value() != split.shares()) {
        qDebug() << Q_FUNC_INFO << " " << transaction.id() << " " << split.id() << " uses the transaction currency, but shares != value";
        split.setShares(split.value());
        transaction.modifySplit(split);
        file->modifyTransaction(transaction);
      }

      // fix the shares and values to have the correct fraction
      if (!splitAccount.isInvest()) {
        try {
          int fract = splitAccount.fraction();
          if (split.shares() != split.shares().convert(fract)) {
            qDebug("adjusting fraction in %s,%s", qPrintable(transaction.id()), qPrintable(split.id()));
            split.setShares(split.shares().convert(fract));
            split.setValue(split.value().convert(fract));
            transaction.modifySplit(split);
            file->modifyTransaction(transaction);
          }
        } catch (const MyMoneyException &) {
          qDebug("Missing security '%s', split not altered", qPrintable(splitAccount.currencyId()));
        }
      }
    }
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyAccountPrivate::getElName(static_cast<Account::Element>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
                        if (plugin->availableJobs(account.id()).contains(task->taskName()))
                            return true;
                    }
```

#### AUTO 


```{c}
const auto accountIdx = indexById(accountId);
```

#### AUTO 


```{c}
const auto amount = split.shares().abs();
```

#### AUTO 


```{c}
auto item = ui->m_availableList->currentItem();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex& current, const QModelIndex& previous) {
                Q_UNUSED(previous)
                Q_D(KInvestmentView);
                d->m_securitySelections.setSelection(SelectedObjects::Security, current.data(eMyMoney::Model::IdRole).toString());
                if (d->ui->m_securitiesTree->isVisible()) {
                    d->m_selections = d->m_securitySelections;
                    emit requestSelectionChange(d->m_selections);
                }
            }
```

#### AUTO 


```{c}
auto sec = readSecurity(m_baseNode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
            if (idx.row() != lastRow) {
                lastRow = idx.row();
                allSelectedRows += lastRow;
            }
        }
```

#### AUTO 


```{c}
const auto attribute = attributeMap.item(i);
```

#### AUTO 


```{c}
const auto jobId = slotOnlineJobSave(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const onlineTask* task : qAsConst(m_onlineTasks)) {
        // Check if a online task has the correct type
        if (dynamic_cast<const creditTransfer*>(task) != 0) {
          for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
            if (plugin->availableJobs(account.id()).contains(task->taskName()))
              return true;
          }
        }
      }
```

#### AUTO 


```{c}
auto strFile(ui->m_qlineeditFile->text());
```

#### AUTO 


```{c}
const auto payee = MyMoneyFile::instance()->payeeByName(newname);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : list) {
                const auto id = idx.data(eMyMoney::Model::IdRole).toString();
                if (!(id.isEmpty() || id.endsWith('-'))) {
                    // we can use any model object for the next operation, but we have to use one
                    const auto baseIdx = MyMoneyFile::instance()->accountsModel()->mapToBaseSource(idx);
                    auto model = const_cast<SplitModel*>(qobject_cast<const SplitModel*>(baseIdx.model()));
                    if (model) {
                        // get the original data
                        const auto split = model->itemByIndex(baseIdx);

                        model->appendEmptySplit();
                        const auto newIdx = model->emptySplit();
                        // prevent update signals
                        QSignalBlocker block(model);
                        // the id of the split will be automatically assigned by the model
                        model->setData(newIdx, split.number(), eMyMoney::Model::SplitNumberRole);
                        model->setData(newIdx, split.memo(), eMyMoney::Model::SplitMemoRole);
                        model->setData(newIdx, split.accountId(), eMyMoney::Model::SplitAccountIdRole);
                        model->setData(newIdx, split.costCenterId(), eMyMoney::Model::SplitCostCenterIdRole);
                        model->setData(newIdx, split.payeeId(), eMyMoney::Model::SplitPayeeIdRole);
                        model->setData(newIdx, QVariant::fromValue<MyMoneyMoney>(split.shares()), eMyMoney::Model::SplitSharesRole);
                        // send out the dataChanged signal with the next (last) setData()
                        block.unblock();
                        model->setData(newIdx, QVariant::fromValue<MyMoneyMoney>(split.value()), eMyMoney::Model::SplitValueRole);

                        // now add a new empty split at the end
                        model->appendEmptySplit();
                        // and make the new split the current one
                        if (!newCurrentIdx.isValid()) {
                            newCurrentIdx = newIdx;
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
const auto& accountKvpValue = (*it_a).value(key);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto delegate : d->mapping) {
        rc |= const_cast<KMMStyledItemDelegate*>(delegate)->eventFilter(watched, event);
        if (rc)
            break;
    }
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.categoryFilter;
```

#### AUTO 


```{c}
const auto payeeId = payeesModel->index(payeeIndex, 0).data(eMyMoney::Model::IdRole).toString();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotMarkNotReconciled(); }
```

#### AUTO 


```{c}
const auto& accountId = account.id();
```

#### AUTO 


```{c}
auto userAgent = m_connector.userAgent();
```

#### AUTO 


```{c}
const auto ixRow = legendRows.count() - 1 - i;
```

#### AUTO 


```{c}
const auto key(keyExp.match(selectedKeyName));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
    const auto idx = d->m_popupView->currentIndex();
    if (d->m_lastSelectedAccount.isEmpty() && idx.isValid()) {
      selectItem(idx);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& account : list) {
    result[account.id()] = QVector<int>((int)eMyMoney::Split::State::MaxReconcileState, 0);
  }
```

#### AUTO 


```{c}
const auto rows = journalModel->rowCount();
```

#### AUTO 


```{c}
const auto price = d->haveVisibleWidget<AmountEdit>("priceAmountEdit");
```

#### AUTO 


```{c}
const auto childIndex = model->index(i, AccountsModel::Account, index);
```

#### AUTO 


```{c}
const auto actions = m_menu->actions();
```

#### AUTO 


```{c}
const auto appVersion(appVersionExp.match(appId));
```

#### AUTO 


```{c}
auto d2 = static_cast<const MyMoneyPayeePrivate *>(right.d_func());
```

#### AUTO 


```{c}
const auto rows = m_q->model()->rowCount();
```

#### AUTO 


```{c}
const auto priceEntry = static_cast<TreeItem<PriceEntry>*>(index(idx.row(), 0).internalPointer())->constDataRef();
```

#### AUTO 


```{c}
const auto& sourceSplit = selectedSourceTransaction.split();
```

#### AUTO 


```{c}
const auto matchingItem(exp.match(it_v->data(0, static_cast<int>(eWidgets::Selector::Role::Key)).toString().mid(1)));
```

#### AUTO 


```{c}
auto index = Models::instance()->accountsModel()->indexById(view->accountId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& tmpl : templates) {
            loader.importTemplate(tmpl);
        }
```

#### AUTO 


```{c}
const auto role = isInvestmentAccount ? eMyMoney::Model::AccountCanBeClosedRole : eMyMoney::Model::AccountIsClosedRole;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : d->m_selections.selection(SelectedObjects::JournalEntry)) {
        const auto journalEntry = file->journalModel()->itemById(journalEntryId);
        if (!journalEntry.id().isEmpty()) {
            if (!journalEntry.transaction().id().isEmpty()) {
                if (!file->referencesClosedAccount(journalEntry.transaction())) {
                    MyMoneyTransaction tr = file->transaction(journalEntry.transaction().id());
                    tr.setPostDate(today);
                    file->modifyTransaction(tr);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : tList) {
    MyMoneyTransaction t = transaction;
    bool tChanged = false;
    QDate accountOpeningDate;
    QStringList accountList;
    const auto splits = t.splits();
    foreach (const auto split, splits) {
      bool sChanged = false;
      MyMoneySplit s = split;
      if (payeeConversionMap.find(split.payeeId()) != payeeConversionMap.end()) {
        s.setPayeeId(payeeConversionMap[s.payeeId()]);
        sChanged = true;
        rc << i18n("  * Payee id updated in split of transaction '%1'.", t.id());
        ++problemCount;
      }

      try {
        const auto acc = this->account(s.accountId());
        // compute the newest opening date of all accounts involved in the transaction
        // in case the newest opening date is newer than the transaction post date, do one
        // of the following:
        //
        // a) for category and stock accounts: update the opening date of the account
        // b) for account types where the user cannot modify the opening date through
        //    the UI issue a warning (for each account only once)
        // c) others will be caught later
        if (!acc.isIncomeExpense() && !acc.isInvest()) {
          if (acc.openingDate() > t.postDate()) {
            if (!accountOpeningDate.isValid() || acc.openingDate() > accountOpeningDate) {
              accountOpeningDate = acc.openingDate();
            }
            accountList << this->accountToCategory(acc.id());
            if (!supportedAccountTypes.contains(acc.accountType())
                && !reportedUnsupportedAccounts.contains(acc.id())) {
              rc << i18n("  * Opening date of Account '%1' cannot be changed to support transaction '%2' post date.",
                         this->accountToCategory(acc.id()), t.id());
              reportedUnsupportedAccounts << acc.id();
              ++unfixedCount;
            }
          }
        } else {
          if (acc.openingDate() > t.postDate()) {
            rc << i18n("  * Transaction '%1' post date '%2' is older than opening date '%4' of account '%3'.",
                       t.id(), t.postDate().toString(Qt::ISODate), this->accountToCategory(acc.id()), acc.openingDate().toString(Qt::ISODate));

            rc << i18n("    Account opening date updated.");
            MyMoneyAccount newAcc = acc;
            newAcc.setOpeningDate(t.postDate());
            this->modifyAccount(newAcc);
            ++problemCount;
          }
        }

        // make sure, that shares and value have the same number if they
        // represent the same currency.
        if (t.commodity() == acc.currencyId() && s.shares().reduce() != s.value().reduce()) {
          // use the value as master if the transaction is balanced
          if (t.splitSum().isZero()) {
            s.setShares(s.value());
            rc << i18n("  * shares set to value in split of transaction '%1'.", t.id());
          } else {
            s.setValue(s.shares());
            rc << i18n("  * value set to shares in split of transaction '%1'.", t.id());
          }
          sChanged = true;
          ++problemCount;
        }
      } catch (const MyMoneyException &) {
        rc << i18n("  * Split %2 in transaction '%1' contains a reference to invalid account %3. Please fix manually.", t.id(), split.id(), split.accountId());
        ++unfixedCount;
      }

      // make sure the interest splits are marked correct as such
      if (interestAccounts.find(s.accountId()) != interestAccounts.end()
          && s.action() != MyMoneySplit::actionName(eMyMoney::Split::Action::Interest)) {
        s.setAction(MyMoneySplit::actionName(eMyMoney::Split::Action::Interest));
        sChanged = true;
        rc << i18n("  * action marked as interest in split of transaction '%1'.", t.id());
        ++problemCount;
      }

      if (sChanged) {
        tChanged = true;
        t.modifySplit(s);
      }
    }

    // make sure that the transaction's post date is valid
    if (!t.postDate().isValid()) {
      tChanged = true;
      t.setPostDate(t.entryDate().isValid() ? t.entryDate() : QDate::currentDate());
      rc << i18n("  * Transaction '%1' has an invalid post date.", t.id());
      rc << i18n("    The post date was updated to '%1'.", QLocale().toString(t.postDate(), QLocale::ShortFormat));
      ++problemCount;
    }
    // check if the transaction's post date is after the opening date
    // of all accounts involved in the transaction. In case it is not,
    // issue a warning with the details about the transaction incl.
    // the account names and dates involved
    if (accountOpeningDate.isValid() && t.postDate() < accountOpeningDate) {
      QDate originalPostDate = t.postDate();
#if 0
      // for now we do not activate the logic to move the post date to a later
      // point in time. This could cause some severe trouble if you have lots
      // of ancient data collected with older versions of KMyMoney that did not
      // enforce certain conditions like we do now.
      t.setPostDate(accountOpeningDate);
      tChanged = true;
      // copy the price information for investments to the new date
      QList<MyMoneySplit>::const_iterator it_t;
      foreach (const auto split, t.splits()) {
        if ((split.action() != "Buy") &&
            (split.action() != "Reinvest")) {
          continue;
        }
        QString id = split.accountId();
        auto acc = this->account(id);
        MyMoneySecurity sec = this->security(acc.currencyId());
        MyMoneyPrice price(acc.currencyId(),
                           sec.tradingCurrency(),
                           t.postDate(),
                           split.price(), "Transaction");
        this->addPrice(price);
        break;
      }
#endif
      rc << i18n("  * Transaction '%1' has a post date '%2' before one of the referenced account's opening date.", t.id(), QLocale().toString(originalPostDate, QLocale::ShortFormat));
      rc << i18n("    Referenced accounts: %1", accountList.join(","));
      rc << i18n("    The post date was not updated to '%1'.", QLocale().toString(accountOpeningDate, QLocale::ShortFormat));
      ++unfixedCount;
    }

    if (tChanged) {
      d->m_storage->modifyTransaction(t);
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
              QDesktopServices::openUrl(webSiteUrl);
            }
```

#### AUTO 


```{c}
const auto dispIndex = model->index(idx.row(), JournalModel::Column::Balance);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : journalEntryIds) {
        if (id.isEmpty())
            continue;
        const auto baseIdx = journalModel->indexById(id);
        auto row = journalModel->mapFromBaseSource(model(), baseIdx).row();

        // the baseIdx may point to a split in a different account which
        // we don't see here. In this case, we scan the journal entries
        // of the transaction
        if ((row == -1) && baseIdx.isValid()) {
            const auto indexes = journalModel->indexesByTransactionId(baseIdx.data(eMyMoney::Model::JournalTransactionIdRole).toString());
            for (const auto idx : indexes) {
                if (idx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString() == d->accountId) {
                    row = journalModel->mapFromBaseSource(model(), idx).row();
                    if (row != -1) {
                        break;
                    }
                }
            }
        }

        if (row == -1) {
            qDebug() << "transaction" << id << "not found anymore for selection. skipped";
            continue;
        }

        if (startRow == -1) {
            startRow = row;
            lastRow = row;
            // use the first as the current index
            if (!currentIdx.isValid()) {
                currentIdx = model()->index(startRow, 0);
            }
        } else {
            if (row == lastRow+1) {
                lastRow = row;
            } else {
                // a new range start, so we take care of it
                createSelectionRange();
            }
        }
    }
```

#### AUTO 


```{c}
auto model = d->ui->frequencyEdit->model();
```

#### AUTO 


```{c}
auto pattern = QRegularExpression::wildcardToRegularExpression(profile->m_creditIndicator);
```

#### AUTO 


```{c}
const auto amount = dynamic_cast<AmountEdit*>(haveWidget(*it_f));
```

#### AUTO 


```{c}
auto list_s = storage->scheduleList(QString(), eMyMoney::Schedule::Type::Any, eMyMoney::Schedule::Occurrence::Any, eMyMoney::Schedule::PaymentType::Any,
                                      QDate(), QDate(), false);
```

#### AUTO 


```{c}
auto item = p->item(row);
```

#### AUTO 


```{c}
const auto rcFileName = QLatin1String("qifexporter.rc");
```

#### AUTO 


```{c}
const auto balance = baseIdx.data(eMyMoney::Model::AccountBalanceRole).value<MyMoneyMoney>();
```

#### RANGE FOR STATEMENT 


```{c}
for(QJsonValue entry: editorsArray) {
            if (!entry.toObject()["OnlineTaskIds"].isNull()) {
                list.append(onlineJobAdministration::onlineJobEditOffer{
                    data.fileName(),
                    entry.toObject()["PluginKeyword"].toString(),
                    KPluginMetaData::readTranslatedString(entry.toObject(), "Name")
                });
            }
        }
```

#### AUTO 


```{c}
const auto date = d->m_transaction.postDate();
```

#### AUTO 


```{c}
const auto list = q->transactionList(filter);
```

#### AUTO 


```{c}
const auto d = qobject_cast<KNewLoanWizard*>(wizard())->d_func();
```

#### AUTO 


```{c}
const auto formattedValue = balance.isNegative() ? d->formatViewLabelValue(-balance, KMyMoneySettings::schemeColor(SchemeColor::Negative))
                                                   : d->formatViewLabelValue(balance, KMyMoneySettings::schemeColor(SchemeColor::Positive));
```

#### AUTO 


```{c}
const auto widget = ui->sharesAmountEdit;
```

#### AUTO 


```{c}
auto cat = d->haveWidget<KMyMoneyAccountCombo>(category);
```

#### AUTO 


```{c}
const auto amount = d->transactionEditor->transactionAmount();
```

#### AUTO 


```{c}
auto repSplitAcc = file->account((*split_it).accountId());
```

#### AUTO 


```{c}
const auto colInstitution = m_columns.indexOf(Columns::Account);
```

#### AUTO 


```{c}
const auto fixVersion = QString("%1").arg(m_file->availableFixVersion());
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ KGlobalLedgerView::slotMarkReconciled(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
        auto acc = account(split.accountId());
        if (!acc.id().isEmpty()) {
            if (acc.isInvest() && (split.investmentTransactionType() != eMyMoney::Split::InvestmentTransactionType::UnknownTransactionType)) {
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto reportItem = toplevelItem->child(j);
```

#### AUTO 


```{c}
const auto& splits = t.splits();
```

#### AUTO 


```{c}
auto transactionValue = d->m_split.value();
```

#### AUTO 


```{c}
const auto componentName = QLatin1String("sqlstorage");
```

#### LAMBDA EXPRESSION 


```{c}
[&](const SelectedObjects& selections) {
        Q_D(KMyMoneyViewBase);
        d->m_selections = selections;
    }
```

#### AUTO 


```{c}
const auto item = d->ui->m_scheduleTree->currentItem();
```

#### AUTO 


```{c}
const auto p = dynamic_cast<KBudgetListItem*>(*widgetIt);
```

#### AUTO 


```{c}
const auto payeesList = d->selectedPayees();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto item : qAsConst(*m_idToItemMapper)) {
        m_referencedObjects.unite(item->constDataRef().referencedObjects());
      }
```

#### AUTO 


```{c}
const auto commodity = d->m_wizard->d_func()->currency();
```

#### AUTO 


```{c}
const auto priceList = m_sql->fetchPrices();
```

#### AUTO 


```{c}
auto amount = dynamic_cast<KMyMoneyEdit*>(*it_w);
```

#### AUTO 


```{c}
auto txt(account.value("iban"));
```

#### AUTO 


```{c}
auto& it_split
```

#### AUTO 


```{c}
auto sec = MyMoneyFile::instance()->security(id);
```

#### AUTO 


```{c}
const auto index = MyMoneyFile::baseModel()->mapToBaseSource(idx);
```

#### AUTO 


```{c}
auto oldType = eMyMoney::Split::InvestmentTransactionType::UnknownTransactionType;
```

#### AUTO 


```{c}
auto isEmpty = attributeName(static_cast<Attribute::KVP>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto new_name = value.toString();
```

#### AUTO 


```{c}
const auto sacc = account(*it_a);
```

#### AUTO 


```{c}
auto row = journalModel->mapFromBaseSource(model(), baseIdx).row();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int col) { validateSelectedColumn(col, Column::Credit); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : t.splits()) {
                        stockAccountId = split.accountId();
                        stockSecurityId = file->account(stockAccountId).currencyId();
                        if (!file->security(stockSecurityId).isCurrency()) {
                            s = split;
                            break;
                        }
                    }
```

#### AUTO 


```{c}
const auto rows = d->journalModel.rowCount();
```

#### AUTO 


```{c}
auto roundingMethod = static_cast<AlkValue::RoundingMethod>(field("roundingMethod").toInt());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        const auto idx = model->index(ui->tagCombo->currentIndex(), 0);
        const auto validInput = (!idx.data(eMyMoney::Model::IdRole).toString().isEmpty() || ui->removeCheckBox->isChecked());
        ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(validInput);
    }
```

#### AUTO 


```{c}
const auto accountId(selections.firstSelection(SelectedObjects::Account));
```

#### AUTO 


```{c}
const auto state = node.attribute(attributeName(Attribute::OnlineJob::BankAnswerState));
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_creditDebitIndicatorCol)
```

#### AUTO 


```{c}
const auto btnSize = q->sizeHint().height() - 5;
```

#### AUTO 


```{c}
auto commodityId = transaction.commodity();
```

#### AUTO 


```{c}
const auto state = amountEdit->displayState();
```

#### AUTO 


```{c}
const auto startBalance = endingBalanceDlg->previousBalance();
```

#### AUTO 


```{c}
const auto securityIdx = file->securitiesModel()->indexById(acc.currencyId());
```

#### AUTO 


```{c}
const auto lastRow = rowCount() - 1;
```

#### AUTO 


```{c}
const auto scriptResourceName = ":/plugins/weboob/kmymoneyweboob.py";
```

#### AUTO 


```{c}
const auto row = rowAt(event->y());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->amountChanged(d->interestSplitModel, d->ui->interestAmountEdit, MyMoneyMoney::MINUS_ONE);
        d->updateWidgetState();
        if (!d->ui->interestCombo->getSelected().isEmpty()) {
            d->scheduleUpdateTotalAmount();
        }
    }
```

#### AUTO 


```{c}
auto sharesEdit = dynamic_cast<AmountEdit*>(q->haveWidget("shares"));
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (d->currentActivity) {
            if (d->currentActivity->type() != eMyMoney::Split::InvestmentTransactionType::SplitShares) {
                updateTotalAmount();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : m_valueChanges) {
    if (!removedObjects.contains(id)) {
      changed = true;
      emit valueChanged(account(id));
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
connectClearButton(m_payeeCol)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : m_splits) {
            usedIds.insert(split.id());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& comboBox : m_columnBoxes) {
    comboBox->setCurrentIndex(-1);
  }
```

#### AUTO 


```{c}
auto paymentWidget = dynamic_cast<AmountEdit*>(d->m_editWidgets["payment"])
```

#### AUTO 


```{c}
const auto returnValue = d->journalModel.balance(id, date);
```

#### AUTO 


```{c}
auto accountCombo = m_editor->findChild<KMyMoneyAccountCombo*>(QLatin1String("accountCombo"));
```

#### AUTO 


```{c}
auto transactionFraction = transactionSecurity.smallestAccountFraction();
```

#### AUTO 


```{c}
auto val = amount ? amount->value() : MyMoneyMoney();
```

#### AUTO 


```{c}
auto t = schedule.transaction();
```

#### AUTO 


```{c}
const auto cellRect = q->visualRect(idx);
```

#### AUTO 


```{c}
auto firsitem = m_accountsProxyModel->index(0, 0, QModelIndex());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint&) {
            Q_D(KBudgetView);
            if (d->m_contextMenu) {
                d->m_contextMenu->exec(QCursor::pos());
            } else {
                qDebug() << "No context menu assigned in KBudgetView";
            }
        }
```

#### AUTO 


```{c}
auto i = (int)MyMoneyPayee::Attribute::Name;
```

#### AUTO 


```{c}
const auto& acc = dynamic_cast<const MyMoneyAccount&>(obj);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString& tagId) {
            return MyMoneyFile::instance()->tagsModel()->itemById(tagId).name();
        }
```

#### AUTO 


```{c}
const auto showHeaders = KMyMoneySettings::showFancyMarker();
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyBudgetPrivate::getElName(static_cast<Budget::Element>(i)).isEmpty();
```

#### AUTO 


```{c}
const auto idx = d->ui->securityAccountCombo->model()->index(index, 0);
```

#### AUTO 


```{c}
const auto sec = file->security(securityId);
```

#### AUTO 


```{c}
auto jsonKMyMoneyData = pluginInfo.rawData()[QLatin1String("KMyMoney")].toObject();
```

#### AUTO 


```{c}
const auto split = journalEntry.split();
```

#### AUTO 


```{c}
auto srcIdx = firstIndexById(after.transaction().id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    // turn on the global changed flag for model based objects
    switch(change.objectType()) {
      /// @note add new models here
      case eMyMoney::File::Object::Payee:
      case eMyMoney::File::Object::CostCenter:
      case eMyMoney::File::Object::Schedule:
      case eMyMoney::File::Object::Tag:
      case eMyMoney::File::Object::Security:
      case eMyMoney::File::Object::Currency:
      case eMyMoney::File::Object::Budget:
      case eMyMoney::File::Object::Account:
      case eMyMoney::File::Object::Institution:
      case eMyMoney::File::Object::Transaction:
      case eMyMoney::File::Object::Price:
      case eMyMoney::File::Object::Parameter:
      case eMyMoney::File::Object::OnlineJob:
      case eMyMoney::File::Object::Report:
      case eMyMoney::File::Object::BaseCurrency:
        changed = true;
        break;
      default:
        break;
    }

    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
const auto indexes = d->ui->m_onlineJobView->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
auto ba = script.toLocal8Bit();
```

#### AUTO 


```{c}
const auto indexes = d->ui->m_accountTree->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
const auto tagName = file->tag(tagId).name();
```

#### AUTO 


```{c}
const auto match = filter.match(txt);
```

#### AUTO 


```{c}
const auto splitAccountId = baseIdx.data(eMyMoney::Model::SplitAccountIdRole).toString();
```

#### AUTO 


```{c}
auto number = dynamic_cast<kMyMoneyLineEdit*>(haveWidget("number"));
```

#### AUTO 


```{c}
const auto name = accIdx.data(eMyMoney::Model::AccountFullHierarchyNameRole).toString();
```

#### AUTO 


```{c}
const auto row = ui->frequencyEdit->currentIndex();
```

#### AUTO 


```{c}
const auto msg = QStringLiteral("Can add non-equity type %1 to investment").arg(static_cast<int>(*it));
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt) {
        d->numberChanged(txt);
    }
```

#### AUTO 


```{c}
auto tRegister = dlg->getRegister();
```

#### AUTO 


```{c}
const auto sch = item->data(0, Qt::UserRole).value<MyMoneySchedule>();
```

#### AUTO 


```{c}
auto currency = MyMoneyFile::instance()->security(security.tradingCurrency());
```

#### AUTO 


```{c}
auto it_t = transactions.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int idx) {
        Q_D(KPayeesView);
        d->m_renameProxyModel->setReferenceFilter(d->ui->m_filterBox->itemData(idx));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transaction : tList) {
    const auto splits = transaction.splits();
    for (const auto& split : splits) {
      if (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Interest))
        interestAccounts[split.accountId()] = true;
    }
  }
```

#### AUTO 


```{c}
const auto maxLegendItems = KMyMoneyGlobalSettings::maximumLegendItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits1) {
        // the following line will throw an exception if the
        // account does not exist
        auto acc = MyMoneyFile::account(split.accountId());
        if (acc.id().isEmpty())
            throw MYMONEYEXCEPTION_CSTRING("Cannot store split with no account assigned");
        if (isStandardAccount(split.accountId()))
            throw MYMONEYEXCEPTION_CSTRING("Cannot store split referencing standard account");
        if (acc.isLoan() && (split.action() == MyMoneySplit::actionName(eMyMoney::Split::Action::Transfer)))
            loanAccountAffected = true;
        if (!split.payeeId().isEmpty()) {
            if (payee(split.payeeId()).id().isEmpty()) {
                throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing unknown payee");
            }
        }
        foreach (const auto tagId, split.tagIdList()) {
            if (!tagId.isEmpty())
                tag(tagId);
        }
    }
```

#### AUTO 


```{c}
auto cat = d->haveVisibleWidget<KMyMoneyAccountCombo>(categoryWidget);
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney", [](const KPluginMetaData& data) {
    return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
  });
```

#### AUTO 


```{c}
auto collectAccounts = [&](const SplitModel* model) {
        const auto rows = model->rowCount();
        for (int row = 0; row < rows; ++row) {
            const auto index = model->index(row, 0);
            accountIds << index.data(eMyMoney::Model::SplitAccountIdRole).toString();
        }
    };
```

#### AUTO 


```{c}
auto isEmpty = MyMoneyInstitution::getAttrName(static_cast<MyMoneyInstitution::Attribute>(i)).isEmpty();
```

#### AUTO 


```{c}
auto item = dynamic_cast<QListWidgetItem*>(ui->m_selectedList->item(0));
```

#### AUTO 


```{c}
const auto oldAccount = accountItem->data(AccountRole).value<MyMoneyAccount>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool checked) { m_profile->m_oppositeSigns = checked; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sAccount : account_list) {
        if (transactionCount(sAccount) != 0)
            return false; // the current account has a transaction assigned
        if (!hasOnlyUnusedAccounts(account(sAccount).accountList(), level + 1))
            return false; // some sub-account has a transaction assigned
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& data) {
    return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
  }
```

#### AUTO 


```{c}
auto s0 = split;
```

#### AUTO 


```{c}
auto currency = d->ui->m_currencyList->currentItem()->data(0, Qt::UserRole).value<MyMoneySecurity>();
```

#### AUTO 


```{c}
const auto accounts = inst.accountList();
```

#### AUTO 


```{c}
const auto itemId = idx.data(eMyMoney::Model::IdRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto view : qAsConst(viewBases)) {
    view->executeCustomAction(eView::Action::CleanupBeforeFileClose);
  }
```

#### AUTO 


```{c}
auto t = MyMoneyXmlContentHandler::readTransaction(nodeMatchedTransaction);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& transaction : translist) {
            // create a copy of the splits list in the transaction
            // loop over all splits
            for (auto& split : transaction.splits()) {
              // if the split is assigned to one of the selected payees, we need to modify it
              if (split.isMatched()) {
                auto tm = split.matchedTransaction();
                for (auto& sm : tm.splits()) {
                  if (payeeInList(list , sm.payeeId())) {
                    sm.setPayeeId(payee_id); // first modify payee in current split
                    // then modify the split in our local copy of the transaction list
                    tm.modifySplit(sm); // this does not modify the list object 'splits'!
                  }
                }
                split.addMatch(tm);
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
              if (payeeInList(list, split.payeeId())) {
                split.setPayeeId(payee_id); // first modify payee in current split
                // then modify the split in our local copy of the transaction list
                transaction.modifySplit(split); // this does not modify the list object 'splits'!
              }
            } // for - Splits
            file->modifyTransaction(transaction);  // modify the transaction in the MyMoney object
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto helper : qAsConst(d->amountEditCurrencyHelpers)) {
        helper->setCommodity(d->transaction.commodity());
    }
```

#### AUTO 


```{c}
const auto statusModel = MyMoneyFile::instance()->statusModel();
```

#### AUTO 


```{c}
auto amount = d->haveVisibleWidget<AmountEdit>(amountWidget);
```

#### AUTO 


```{c}
const auto& m_valueChanges = d->m_valueChangedSet;
```

#### AUTO 


```{c}
const auto price = haveVisibleWidget<AmountEdit>("priceAmountEdit");
```

#### AUTO 


```{c}
const auto currentView = d->currentViewId();
```

#### AUTO 


```{c}
auto st = csvImporter->unattendedImport(filename, amountProfile);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : journalEntry.transaction().splits()) {
          const auto acc = MyMoneyFile::instance()->accountsModel()->itemById(split.accountId());
          if (acc.accountType() == eMyMoney::Account::Type::Investment) {
            return acc.id();
          }
          if (acc.isInvest()) {
            accountId = acc.parentAccountId();
          }
        }
```

#### AUTO 


```{c}
const auto filter = d->m_filterSet;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& change : changes) {
    switch (change.notificationMode()) {
      case File::Mode::Remove:
        emit objectRemoved(change.objectType(), change.id());
        // if there is a balance change recorded for this account remove it since the account itself will be removed
        // this can happen when deleting categories that have transactions and the reassign category feature was used
        d->m_balanceChangedSet.remove(change.id());
        break;
      case File::Mode::Add:
        if (!removedObjects.contains(change.id())) {
          emit objectAdded(change.objectType(), change.id());
        }
        break;
      case File::Mode::Modify:
        if (!removedObjects.contains(change.id())) {
          emit objectModified(change.objectType(), change.id());
        }
        break;
    }
  }
```

#### AUTO 


```{c}
const auto corner = description.corner;
```

#### AUTO 


```{c}
auto result = d->m_filterSet.testFlag(validityFilterActive);
```

#### AUTO 


```{c}
const auto baseModel = MyMoneyFile::instance()->payeesModel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : indexes) {
    addAccount(QString(), idx.data(eMyMoney::Model::IdRole).toString());
  }
```

#### AUTO 


```{c}
const auto m = model();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto model : specialJournalModels) {
    d->concatModel->addSourceModel(model);
  }
```

#### AUTO 


```{c}
auto list = d->ui->m_ledgerView->selectedTransactions();
```

#### AUTO 


```{c}
const auto showAllAccounts = KMyMoneySettings::showAllAccounts();
```

#### AUTO 


```{c}
auto removeSplit = true;
```

#### AUTO 


```{c}
const auto endRow = first.row() + rows;
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<KMyMoneyEdit*>(d->m_editWidgets["deposit"])
```

#### AUTO 


```{c}
auto const rows = model->rowCount();
```

#### AUTO 


```{c}
const auto category = file->accountToCategory(acc.id());
```

#### AUTO 


```{c}
const auto& brokerageAccount = MyMoneyFile::instance()->accountsModel()->itemByName(d->m_account.brokerageName());
```

#### AUTO 


```{c}
auto isEmpty = MyMoneySecurityPrivate::getAttrName(static_cast<Security::Attribute>(i)).isEmpty();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const& weekDay: locale.weekdays())
  {
    d->m_processingDays.setBit(static_cast<int>(weekDay));
  }
```

#### AUTO 


```{c}
const auto indexes = MyMoneyFile::instance()->journalModel()->indexesByTransactionId(tid);
```

#### AUTO 


```{c}
const auto end = journalModel->MyMoneyModelBase::upperBound(journalModel->keyForDate(m_endDate)).row();
```

#### AUTO 


```{c}
const auto acc = file->accountsModel()->itemById(journalEntry.split().accountId());
```

#### AUTO 


```{c}
const auto id = baseIdx.data(eMyMoney::Model::IdRole).toString();
```

#### AUTO 


```{c}
const auto securityList = file->securityList();
```

#### AUTO 


```{c}
auto amountShares = splitDialog->transactionAmount() * transactionFactor;
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.typeFilter;
```

#### AUTO 


```{c}
auto grp = config->group("Equity Price Update");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : pPlugins.storage) {
    if (chosenFileType == plugin->storageType()) {
      try {
        d->consistencyCheck(false);
        if (plugin->saveAs()) {
          d->fileAction(eKMyMoney::FileAction::Saved);
          d->m_storageInfo.type = plugin->storageType();
          return true;
        }
      } catch (const MyMoneyException &e) {
        KMessageBox::detailedError(this, i18n("Failed to save your storage."), e.what());
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sAccount : account.accountList())
    this->account(sAccount);
```

#### AUTO 


```{c}
auto paymentWidget = dynamic_cast<AmountEdit*>(d->m_editWidgets["payment"]);
```

#### AUTO 


```{c}
const auto dateRange = MyMoneyFile::instance()->journalModel()->dateRange();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalId : selection.selection(SelectedObjects::JournalEntry)) {
                    const auto journalIdx = file->journalModel()->indexById(journalId);
                    moveToAccountSelector->removeItem(journalIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString());
                    const auto accId = journalIdx.data(eMyMoney::Model::JournalSplitAccountIdRole).toString();
                    const auto accIdx = file->accountsModel()->indexById(accId);
                    currencyIds.insert(accIdx.data(eMyMoney::Model::AccountCurrencyIdRole).toString());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& plugin: metaData) {
    m_displayedPlugins.insert(plugin.fileName());
    KPluginInfo info {plugin};
    KPluginSelector::PluginLoadMethod loadMethod = (plugin.serviceTypes().contains("KMyMoney/Plugin"))
      ? KPluginSelector::PluginLoadMethod::ReadConfigFile
      : KPluginSelector::PluginLoadMethod::IgnoreConfigFile;
    m_pluginSelector->addPlugins(QList<KPluginInfo> {info}, loadMethod, categoryByPluginType(plugin));
    //! @fixme The not all plugins are deactivated correctly at the moment. This has to change or the user should not get any option to enable and disable them
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        d->valueChanged(d->amountHelper);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : transactionIds) {
    if (id.isEmpty())
      continue;
    const auto indexes = journalModel->indexesByTransactionId(id);
    int row = -1;
    for (const auto baseIdx : indexes) {
      row = journalModel->mapFromBaseSource(model(), baseIdx).row();
      if (row != -1) {
        break;
      }
    }
    if (row == -1) {
      qDebug() << "transaction" << id << "not found anymore for selection. skipped";
      continue;
    }

    if (startRow == -1) {
      startRow = row;
      lastRow = row;
      // use the first as the current index
      if (!currentIdx.isValid()) {
        currentIdx = model()->index(startRow, 0);
      }
    } else {
      if (row == lastRow+1) {
        lastRow = row;
      } else {
        // a new range start, so we take care of it
        createSelectionRange();
      }
    }
  }
```

#### AUTO 


```{c}
auto sec = haveWidget<QComboBox>("securityAccountCombo");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& id : balanceChanges) {
    if (!removedObjects.contains(id)) {
      // if we notify about balance change we don't need to notify about value change
      // for the same account since a balance change implies a value change
      d->m_valueChangedSet.remove(id);
      emit balanceChanged(account(id));
    }
  }
```

#### AUTO 


```{c}
auto deposit = dynamic_cast<AmountEdit*>(d->m_editWidgets["deposit"])
```

#### AUTO 


```{c}
const auto transaction = file->transaction(transactionId);
```

#### AUTO 


```{c}
auto valueWidget = dynamic_cast<KMyMoneyEdit*>(haveWidget(amount))
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& it : actionShortcuts)
            aC->setDefaultShortcut(lutActions[it.first], it.second);
```

#### LAMBDA EXPRESSION 


```{c}
[&](int payeeIndex) {
        d->payeeChanged(payeeIndex);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& payee : list) {
      if (payee.id() == id) {
        return true;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
                kgpg->addRecipient(key.toLatin1());
            }
```

#### AUTO 


```{c}
const auto managers = dlg->findChildren<KConfigDialogManager*>();
```

#### AUTO 


```{c}
const auto transactionId = expMatch.captured(1);
```

#### AUTO 


```{c}
auto widget = editor->findChild<T*>(aName);
```

#### AUTO 


```{c}
auto w = d->haveWidget<QWidget*>(*it_w);
```

#### AUTO 


```{c}
const auto& reportsView = static_cast<KReportsView*>(viewBases[View::Reports]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sp : transaction.splits()) {
        if(splitId != sp.id()) {
          return sp.accountId();
        }
      }
```

#### AUTO 


```{c}
auto i = d->ui->m_qcomboboxInstitutions->findText(search);
```

#### RANGE FOR STATEMENT 


```{c}
for (const viewInfo& view : viewsInfo) {
    /* There is a bug in
    static int layoutText(QTextLayout *layout, int maxWidth)
    from kpageview_p.cpp from kwidgetsaddons.
    The method doesn't break strings that are too long. Following line
    workarounds this by using LINE SEPARATOR character which is accepted by
    QTextLayout::createLine().*/
    viewFrames[view.id] = m_model->addPage(viewBases[view.id], QString(view.name).replace(QLatin1Char('\n'), QString::fromUtf8("\xe2\x80\xa8")));
    viewFrames[view.id]->setIcon(Icons::get(view.icon));
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByObject, this, &KMyMoneyView::slotSelectByObject);
    connect(viewBases[view.id], &KMyMoneyViewBase::selectByVariant, this, &KMyMoneyView::slotSelectByVariant);
    connect(viewBases[view.id], &KMyMoneyViewBase::customActionRequested, this, &KMyMoneyView::slotCustomActionRequested);
  }
```

#### AUTO 


```{c}
const auto transactions = d->m_storage->transactionList(filter);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MyMoneyPayee &payee : list) {
            if (loanAccount.hasReferenceTo(payee.id())) {
              usedAccounts.append(account);
            }
          }
```

#### AUTO 


```{c}
auto sp = journalEntry.split();
```

#### AUTO 


```{c}
auto filterProxyModel = new AccountNamesFilterProxyModel(this);
```

#### AUTO 


```{c}
const auto institution = file->institution(account.institutionId());
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].toObject()["Editors"].isNull());
    });
```

#### AUTO 


```{c}
const auto budgetAccount = m_budget.account(account.id());
```

#### AUTO 


```{c}
const auto acc = account(split.accountId());
```

#### AUTO 


```{c}
auto next = d->ui->m_homePageList->item(d->ui->m_homePageList->row(item) + 1);
```

#### AUTO 


```{c}
auto fDays = q->forecastDays();
```

#### AUTO 


```{c}
auto concatModel = new KConcatenateRowsProxyModel(parent);
```

#### AUTO 


```{c}
const auto value =
		      MyMoneyFile::instance()->balance((*it).id(), QDate::currentDate());
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
    }
```

#### AUTO 


```{c}
const auto oldAccount = accountItem->data((int)Role::Account).value<MyMoneyAccount>();
```

#### AUTO 


```{c}
auto i = (int)Element::OnlineJob::OnlineTask;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& label : labels) {
      if (label->buddy() == it.value()) {
        m_dlg->m_colTypeName.insert(it.key(), label->text());
        break;
      }
    }
```

#### AUTO 


```{c}
const auto list = m_storage->transactionList(filter);
```

#### AUTO 


```{c}
const auto itemCount = pairs.count();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto split : splits) {
        // the following line will throw an exception if the
        // account does not exist or is one of the standard accounts
        const auto acc = account(split.accountId());
        if (acc.id().isEmpty())
            throw MYMONEYEXCEPTION_CSTRING("Cannot add split with no account assigned");
        if (isStandardAccount(split.accountId()))
            throw MYMONEYEXCEPTION_CSTRING("Cannot add split referencing standard account");

        // If we have match information in a split don't copy it into the schedule
        if (split.isMatched()) {
            split.removeMatch();
            t.modifySplit(split);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& label : labels) {
            if (label->buddy() == it.value()) {
                m_dlg->m_colTypeName.insert(it.key(), label->text());
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : pPlugins.storage) {
            if (plugin->storageType() == extension) {
                fileExtensions += plugin->fileExtension() + QLatin1String(";;");
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto option : opts) {
        option = option.trimmed();
        if (option.startsWith(QLatin1String("QSQLITE_BUSY_TIMEOUT"))) {
            option = option.mid(20).trimmed();
            if (option.startsWith(QLatin1Char('='))) {
                bool ok;
                const int nt = option.mid(1).trimmed().toInt(&ok);
                if (ok)
                    timeOut = nt;
            }
        } else if (option == QLatin1String("QSQLITE_OPEN_READONLY")) {
            openReadOnlyOption = true;
        } else if (option == QLatin1String("QSQLITE_OPEN_URI")) {
            openUriOption = true;
        } else if (option == QLatin1String("QSQLITE_ENABLE_SHARED_CACHE")) {
            sharedCache = true;
        }
    }
```

#### AUTO 


```{c}
auto replacement = QStringLiteral(".*:");
```

#### AUTO 


```{c}
auto splitsElement = document.createElement(elementName(Element::Transaction::Splits));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& journalEntryId : m_selections.selection(SelectedObjects::JournalEntry)) {
                const auto idx = file->journalModel()->indexById(journalEntryId);
                if (idx.data(eMyMoney::Model::JournalSplitIsMatchedRole).toBool()) {
                    const auto journalEntry = file->journalModel()->itemByIndex(idx);
                    TransactionMatcher matcher;
                    matcher.unmatch(journalEntry.transaction(), journalEntry.split());
                }
            }
```

#### AUTO 


```{c}
auto value = attribute.nodeValue();
```

#### AUTO 


```{c}
auto action = qobject_cast<QAction*>(sender());
```

#### AUTO 


```{c}
auto rc = eDialogs::ScheduleResultCode::Enter;
```

#### AUTO 


```{c}
const auto count = m_models->currenciesModel()->processItems(&writer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& split : splits) {
            const auto idx = MyMoneyFile::instance()->accountsModel()->indexById(split.accountId());
            if (idx.data(eMyMoney::Model::AccountIsAssetLiabilityRole).toBool() == false) {
                isTransfer = false;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto afterIdEmpty = (after.transactionPtr() == nullptr) || (after.transaction().id().isEmpty());
```

#### AUTO 


```{c}
auto t = q->transaction();
```

#### AUTO 


```{c}
auto actionObject = pActions.value(action, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : accounts) {
        if (d->canBePrinted(accountId)) {
            for (const auto& journalEntryId : journalEntries) {
                const auto idx = file->journalModel()->indexById(journalEntryId);
                const auto transactionId = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
                if (d->canBePrinted(accountId, transactionId)) {
                    d->printCheck(accountId, transactionId);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto result = d->m_filterSet.singleFilter.accountFilter;
```

#### AUTO 


```{c}
auto grp = config->group("Last Use Settings");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto idx : selection) {
      auto baseIdx = baseModel->mapToBaseSource(idx);
      const auto id = baseIdx.data(eMyMoney::Model::IdRole).toString();
      if (!id.isEmpty()) {
        payees.append(id);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMyMoneyPlugin::OnlinePluginExtended* plugin : qAsConst(*m_onlinePlugins)) {
        QList<MyMoneyAccount> accounts;
        MyMoneyFile::instance()->accountList(accounts, QStringList(), true);
        for (const auto& account : qAsConst(accounts)) {
            if (account.hasOnlineMapping()) {
                for (const auto& onlineTaskIid : plugin->availableJobs(account.id())) {
                    if (m_onlineTasks.contains(onlineTaskIid)) {
                        return true;
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto idx = d->m_popupView->currentIndex();
```

#### AUTO 


```{c}
const auto& info
```

#### RANGE FOR STATEMENT 


```{c}
for(QJsonValue entry: editorsArray) {
      if (!entry.toObject()["OnlineTaskIds"].isNull()) {
        list.append(onlineJobAdministration::onlineJobEditOffer{
            data.fileName(),
            entry.toObject()["PluginKeyword"].toString(),
            KPluginMetaData::readTranslatedString(entry.toObject(), "Name")
          });
      }
    }
```

#### AUTO 


```{c}
auto end = d->m_splits.size(), i = 0;
```

#### AUTO 


```{c}
auto category = dynamic_cast<KMyMoneyCategory*>(d->m_editWidgets["category"])
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto accountId : qAsConst(balanceChangedSet)) {
      balances.insert(accountId, balanceCache.value(accountId));
    }
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::findPlugins("kmymoney/onlinetasks", [](const KPluginMetaData& data) {
        return !(data.rawData()["KMyMoney"].toObject()["OnlineTask"].isNull());
    });
```

#### AUTO 


```{c}
auto tagContainer = dynamic_cast<KTagContainer*>(*it_w);
```

#### AUTO 


```{c}
const auto& sAccounts = account.accountList();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_D(KEnterScheduleDlg);
        d->m_extendedReturnCode = eDialogs::ScheduleResultCode::Ignore;
        accept();
    }
```

#### AUTO 


```{c}
const auto rows = d->m_splitModel->rowCount();
```

#### AUTO 


```{c}
const auto reconciliationBalanceValue = index.data(eMyMoney::Model::ReconciliationAmountRole).value<MyMoneyMoney>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& idx : selectionModel()->selectedIndexes()) {
    id = idx.data(eMyMoney::Model::JournalTransactionIdRole).toString();
    if (!selection.contains(id)) {
      selection.append(id);
    }
  }
```

#### AUTO 


```{c}
const auto data = childNode->data(AccountValueRole);
```

#### AUTO 


```{c}
auto splitChild = c.firstChild();
```

#### AUTO 


```{c}
const auto number(stripZeroExp.match(s));
```

#### AUTO 


```{c}
auto model = MyMoneyFile::instance()->journalModel();
```

#### AUTO 


```{c}
auto accID = makeAccount("Easy", "123456789", eMyMoney::Account::Investment, QDate(2017, 8, 1), file->asset().id());
```

#### LAMBDA EXPRESSION 


```{c}
[&](QWidget* editor) {
        emit const_cast<ibanBicItemDelegate*>(this)->closeEditor(editor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& accountId : account.accountList()) {
        this->account(accountId);
    }
```

#### AUTO 


```{c}
auto iconIndex = -1;
```

#### AUTO 


```{c}
auto t = sched.transaction();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& pluginData : pluginDatas) {
      if (pluginData.serviceTypes().contains(QStringLiteral("KMyMoney/Plugin"))) {
        if (!onlyEnabled || isPluginEnabled(pluginData, pluginSection)) {
          // only use the first one found. Otherwise, always the last one
          // wins (usually the installed system version) and the QT_PLUGIN_PATH
          // env variable nor the current directory have an effect for KMyMoney
          if (!plugins.contains(pluginData.pluginId()))
            plugins.insert(pluginData.pluginId(), pluginData);
        }
      }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (categoryId.isEmpty()) {
            return QString();
        }
        const auto category = MyMoneyFile::instance()->account(categoryId);
        return category.value("VatAccount");
    }
```

#### AUTO 


```{c}
const auto selectedItemCount = selections.selection(SelectedObjects::Payee).count();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& txt)
    {
        if (txt.isEmpty()) {
            d->ui->payeeEdit->setCurrentIndex(0);
        }
    }
```

#### AUTO 


```{c}
auto tradingCurrencyIdx = securityIdx.data(eMyMoney::Model::SecurityTradingCurrencyIndexRole).value<QModelIndex>();
```

#### AUTO 


```{c}
auto ita = list.begin();
```

#### AUTO 


```{c}
auto model = Models::instance()->accountsModel();
```

#### AUTO 


```{c}
const auto sAccounts = account.accountList();
```

#### AUTO 


```{c}
auto item = new QStandardItem(subacc.name());
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& key: keyList.split(',', QString::SkipEmptyParts)) {
        if (!KGPGFile::keyAvailable(key)) {
          KMessageBox::sorry(nullptr, i18n("<p>You have specified to encrypt your data for the user-id</p><p><center><b>%1</b>.</center></p><p>Unfortunately, a valid key for this user-id was not found in your keyring. Please make sure to import a valid key for this user-id. This time, encryption is disabled.</p>", key), i18n("GPG Key not found"));
          encryptFile = false;
          break;
        }
      }
```

#### AUTO 


```{c}
const auto idx = index(row, 0, parent);
```

#### AUTO 


```{c}
auto memo = index.data(eMyMoney::Model::Roles::SplitSingleLineMemoRole).toString();
```

#### AUTO 


```{c}
const auto security = MyMoneyFile::instance()->security(category.currencyId());
```

