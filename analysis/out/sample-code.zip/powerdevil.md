#### LAMBDA EXPRESSION 


```{c}
[=] {
        qCDebug(POWERDEVIL) << "Enforcing inhibition from" << service << appName << "with cookie"
                            << cookie << "and reason" << reason;

        if (!m_pendingInhibitions.contains(cookie)) {
            qCDebug(POWERDEVIL) << "By the time we wanted to enforce the inhibition it was already gone; discarding it";
            return;
        }

        m_cookieToAppName.insert(cookie, qMakePair<QString, QString>(appName, reason));

        addInhibitionTypeHelper(cookie, static_cast< PolicyAgent::RequiredPolicies >(types));

        Q_EMIT InhibitionsChanged({ {qMakePair(appName, reason)} }, {});

        m_pendingInhibitions.removeOne(cookie);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
            QString actionId = offer->property(QStringLiteral("X-KDE-PowerDevil-Action-ID"), QVariant::String).toString();

            if (m_actionPool.contains(actionId)) {
                QDBusConnection::sessionBus().registerObject(QStringLiteral("/org/kde/Solid/PowerManagement/Actions/") + actionId, m_actionPool[actionId]);
            }
        }
```

#### AUTO 


```{c}
auto timeout = mobile ? 300000 : 600000;
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (m_lastKeyboardBrightness > -1) {
            setKeyboardBrightnessSilent(m_lastKeyboardBrightness);
        }
    }
```

#### AUTO 


```{c}
auto output = m_registry->createOutput(name, version, this);
```

#### AUTO 


```{c}
auto i = m_registeredActionTimeouts.constBegin(), end = m_registeredActionTimeouts.constEnd();
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        loadProfile();
    }
```

#### AUTO 


```{c}
auto dpms = it.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                    if (syspathJob->error()) {
                                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                        qCDebug(POWERDEVIL) << syspathJob->errorText();
                                        Q_EMIT brightnessSupportQueried(false);
                                        return;
                                    }
                                    m_syspath = syspathJob->data()["syspath"].toString();
                                    m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                    m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                    if (!m_isLedBrightnessControl) {
                                        UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                        connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                    }

                                    Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                                }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<QStringList> reply = *watcher;
            watcher->deleteLater();

            if (reply.isError()) {
                qCWarning(POWERDEVIL) << "Failed to fetch list of DBus service names for pausing players on entering sleep" << reply.error().message();
                return;
            }

            const QStringList &services = reply.value();
            for (const QString &serviceName : services) {
                if (!serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2."))) {
                    continue;
                }

                if (serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2.kdeconnect.mpris_"))) {
                    // This is actually a player on another device exposed by KDE Connect
                    // We don't want to pause it
                    // See https://bugs.kde.org/show_bug.cgi?id=427209
                    continue;
                }

                qCDebug(POWERDEVIL) << "Pausing media player with service name" << serviceName;

                QDBusMessage pauseMsg = QDBusMessage::createMethodCall(serviceName,
                                                                       QStringLiteral("/org/mpris/MediaPlayer2"),
                                                                       QStringLiteral("org.mpris.MediaPlayer2.Player"),
                                                                       QStringLiteral("Pause"));
                QDBusConnection::sessionBus().asyncCall(pauseMsg);
            }
       }
```

#### AUTO 


```{c}
auto configGroup = KSharedConfig::openConfig("powermanagementprofilesrc")->group("migration");
```

#### AUTO 


```{c}
auto interface = Kirigami::TabletModeWatcher::self();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &choice : choices) {
            m_profileCombo->addItem(profileNames.value(choice, choice), choice);
        }
```

#### AUTO 


```{c}
auto timeout = mobile ? 60 : 600;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & interface : interfaces) {
        file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        buffer = file.readLine().trimmed();
        if (buffer == "firmware") {
            firmware.append(interface);
        } else if(buffer == "platform") {
            platform.append(interface);
        } else if (buffer == "raw") {
            raw.append(interface);
        } else {
            qCWarning(POWERDEVIL) << "Interface type not handled" << buffer;
        }

        file.close();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QVariantMap &dict) {
                return dict[QStringLiteral("Profile")].toString();
            }
```

#### AUTO 


```{c}
const auto dpmsData = m_registry->interface(Registry::Interface::Dpms);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            d->serviceRegistered = false;
            d->setCanSuspend(false);
            d->setCanHibernate(false);
            d->setCanHybridSuspend(false);
        }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(m_powerProfilesPropertiesInterface->GetAll(m_powerProfilesInterface->interface()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &action : qAsConst(m_activeActions)) {
        m_actionPool[action]->onProfileUnload();
        m_actionPool[action]->unloadAction();
    }
```

#### AUTO 


```{c}
auto initLid = [toRam](KConfigGroup &profile)
    {
        const bool mobile = !qEnvironmentVariableIsEmpty("QT_QUICK_CONTROLS_MOBILE");
        const Modes defaultPowerButtonAction = mobile ? ToRamMode : LogoutDialogMode;

        KConfigGroup handleButtonEvents(&profile, "HandleButtonEvents");
        handleButtonEvents.writeEntry< uint >("powerButtonAction", defaultPowerButtonAction);
        handleButtonEvents.writeEntry< uint >("powerDownAction", LogoutDialogMode);
        if (toRam) {
            handleButtonEvents.writeEntry< uint >("lidAction", ToRamMode);
        } else {
            handleButtonEvents.writeEntry< uint >("lidAction", TurnOffScreenMode);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[msg, watcher, this] {
        watcher->deleteLater();
        if (watcher->isError()) {
            QDBusConnection::sessionBus().send(msg.createErrorReply(watcher->error()));
        } else {
            m_holdMap.remove(msg.service(), msg.arguments()[0].toUInt());
            if (m_holdMap.count(msg.service())) {
                m_holdWatcher->removeWatchedService(msg.service());
            }
            QDBusConnection::sessionBus().send(msg.createReply());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &interface : devices) {
        int max_brightness = readFromDevice(interface, "max_brightness");
        m_devices.append(qMakePair(interface, max_brightness));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    qCDebug(POWERDEVIL) << brightnessJob->errorText();
                    Q_EMIT brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
                    }
                );
                brightnessMaxJob->start();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[cookie](WakeupInfo wakeup) {
        return wakeup.cookie == cookie;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activity : activities) {
        KActivities::Info *info = new KActivities::Info(activity, this);
        const QString icon = info->icon();
        const QString name = info->name();
        qCDebug(POWERDEVIL) << activity << info->isValid() << info->availability();

        QScrollArea *scrollArea = new QScrollArea();
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setFrameShadow(QFrame::Plain);
        scrollArea->setLineWidth(0);
        scrollArea->setWidgetResizable(true);

        ActivityWidget *activityWidget = new ActivityWidget(activity);
        scrollArea->setWidget(activityWidget);

        activityWidget->load();
        m_activityWidgets.append(activityWidget);

        connect(activityWidget, SIGNAL(changed(bool)), this, SIGNAL(changed(bool)));
        if (!icon.isEmpty()) {
            m_tabWidget->addTab(scrollArea, QIcon::fromTheme(icon), name);
        } else {
            m_tabWidget->addTab(scrollArea, name);
        }

        if (m_activityConsumer->currentActivity() == activity) {
            m_tabWidget->setCurrentIndex(index);
        }

        ++index;
    }
```

#### AUTO 


```{c}
auto it = m_peripheralBatteriesPercent.constBegin(), end = m_peripheralBatteriesPercent.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &interface : devices) {
        int max_brightness = readFromDevice(BACKLIGHT_SYSFS_PATH + interface, "max_brightness");
        m_devices.append(qMakePair(BACKLIGHT_SYSFS_PATH + interface, max_brightness));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionId: actionIds) {
            QAction oldAction;
            oldAction.setObjectName(actionId);
            oldAction.setProperty("componentName", "kded5");

            //claim the old shortcut so we can remove it..
            KGlobalAccel::self()->setShortcut(&oldAction, QList<QKeySequence>(), KGlobalAccel::Autoloading);
            auto shortcuts = KGlobalAccel::self()->shortcut(&oldAction);
            KGlobalAccel::self()->removeAllShortcuts(&oldAction);

            QAction newAction;
            newAction.setObjectName(actionId);
            newAction.setProperty("componentName", "org_kde_powerdevil");
            if (!shortcuts.isEmpty()) {
                //register with no autoloading to sync config, we then delete our QAction, and powerdevil will
                //re-register as normal
                KGlobalAccel::self()->setShortcut(&newAction, shortcuts, KGlobalAccel::NoAutoloading);
            }
        }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(call);
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                            if (syspathJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                qCDebug(POWERDEVIL) << syspathJob->errorText();
                                Q_EMIT brightnessSupportQueried(false);
                                return;
                            }
                            m_syspath = syspathJob->data()["syspath"].toString();
                            m_syspath = QFileInfo(m_syspath).readLink();

                            m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                            if (!m_isLedBrightnessControl) {
                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                            }

                            Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // Notify the screensaver
        OrgFreedesktopScreenSaverInterface iface("org.freedesktop.ScreenSaver", "/ScreenSaver", QDBusConnection::sessionBus());
        iface.SimulateUserActivity();
        PowerDevil::PolicyAgent::instance()->setupSystemdInhibition();

        m_fadeEffect->stop();

        Q_EMIT resumingFromSuspend();
    }
```

#### AUTO 


```{c}
auto *outputs = xcb_randr_get_screen_resources_current_outputs(m_resources);
```

#### AUTO 


```{c}
auto powerButtonMode = [globalAction] (bool isTablet) {
        if (!isTablet) {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, QList<QKeySequence>());
        } else {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, Qt::Key_PowerOff);
        }
    };
```

#### AUTO 


```{c}
auto it = m_editWidgets.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            d->serviceRegistered = false;
            d->setCanSuspend(false);
            d->setCanHibernate(false);
            d->setCanHybridSuspend(false);
            d->setCanSuspendThenHibernate(false);
        }
```

#### AUTO 


```{c}
auto *watcher = new QDBusPendingCallWatcher(QDBusConnection::sessionBus().asyncCall(msg), m_profileCombo);
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

#ifdef Q_OS_FREEBSD
                        // FreeBSD doesn't have the sysfs interface that the bits below expect;
                        // the sysfs calls always fail, leading to brightnessSupportQueried(false) emission.
                        // Skip that command and carry on with the information that we do have.
                        Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
#else
                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, &UdevQt::Client::deviceChanged, this, &PowerDevilUPowerBackend::onDeviceChanged);
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
#endif
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                if (syspathJob->error()) {
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                Q_EMIT brightnessSupportQueried(true);
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    Q_EMIT brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                Q_EMIT brightnessSupportQueried(true);
                            }
                        );
                        syspathJob->start();
                    }
                );
                brightnessMaxJob->start();
            }
```

#### AUTO 


```{c}
auto msg = QDBusMessage::createMethodCall(
        QStringLiteral("org.freedesktop.DBus"),
        QStringLiteral("/"),
        QStringLiteral("org.freedesktop.DBus"),
        QStringLiteral("GetNameOwner")
    );
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    emit brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    emit brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                emit brightnessSupportQueried(true);
                            }
                        );
                        syspathJob->start();
                    }
                );
                brightnessMaxJob->start();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &interface : interfaces) {
        file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        buffer = file.readLine().trimmed();
        if (buffer == "firmware") {
            firmware.append(BACKLIGHT_SYSFS_PATH + interface);
        } else if (buffer == "platform") {
            platform.append(BACKLIGHT_SYSFS_PATH + interface);
        } else if (buffer == "raw") {
            QFile enabled(BACKLIGHT_SYSFS_PATH + interface + "/device/enabled");
            rawAll.append(BACKLIGHT_SYSFS_PATH + interface);
            if (enabled.open(QIODevice::ReadOnly | QIODevice::Text) && enabled.readLine().trimmed() == "enabled") {
                // this backlight device is connected to a display, so append
                // it to rawEnabled list
                rawEnabled.append(BACKLIGHT_SYSFS_PATH + interface);
            }
        } else {
            qCWarning(POWERDEVIL) << "Interface type not handled" << buffer;
        }

        file.close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activity : activities) {
        if (activity == m_activity) {
            continue;
        }

        if (activitiesGroup.group(activity).readEntry("mode", "None") == "None" ||
            activitiesGroup.group(activity).readEntry("mode", "None") == "ActLike") {
            continue;
        }

        KActivities::Info *info = new KActivities::Info(activity, this);
        QString icon = info->icon();
        QString name = i18nc("This is meant to be: Act like activity %1",
                             "Activity \"%1\"", info->name());

        m_ui->actLikeComboBox->addItem(QIcon::fromTheme(icon), name, activity);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        if (job->error()) {
            qCWarning(POWERDEVIL) << "org.kde.powerdevil.chargethresholdhelper.getthreshold failed" << job->errorText();
            return;
        }

        const auto data = job->data();

        const int chargeStartThreshold = data.value(QStringLiteral("chargeStartThreshold")).toInt();
        if (chargeStartThreshold != -1 && m_chargeStartThreshold != chargeStartThreshold) {
            m_chargeStartThreshold = chargeStartThreshold;
            Q_EMIT chargeStartThresholdChanged(chargeStartThreshold);
        }

        const int chargeStopThreshold = data.value(QStringLiteral("chargeStopThreshold")).toInt();
        if (chargeStopThreshold != -1 && m_chargeStopThreshold != chargeStopThreshold) {
            m_chargeStopThreshold = chargeStopThreshold;
            Q_EMIT chargeStopThresholdChanged(chargeStopThreshold);
        }

        qCDebug(POWERDEVIL) << "Charge thresholds: start at" << chargeStartThreshold << "- stop at" << chargeStopThreshold;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
        // Does it have a runtime requirement?
        if (offer->property(QStringLiteral("X-KDE-PowerDevil-Action-HasRuntimeRequirement"), QVariant::Bool).toBool()) {
            qCDebug(POWERDEVIL) << offer->name() << " has a runtime requirement";

            QDBusMessage call = QDBusMessage::createMethodCall("org.kde.Solid.PowerManagement", "/org/kde/Solid/PowerManagement",
                                                               "org.kde.Solid.PowerManagement", "isActionSupported");
            call.setArguments(QVariantList() << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String));
            QDBusPendingReply< bool > reply = QDBusConnection::sessionBus().asyncCall(call);
            reply.waitForFinished();

            if (reply.isValid()) {
                if (!reply.value()) {
                    qCDebug(POWERDEVIL) << "The action " << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String) << " appears not to be supported by the core.";
                    continue;
                }
            } else {
                qCDebug(POWERDEVIL) << "There was a problem in contacting DBus!! Assuming the action is ok.";
            }
        }

        //try to load the specified library
        KPluginFactory *factory = KPluginLoader(offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                QVariant::String).toString()).factory();

        if (!factory) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        PowerDevil::ActionConfig *actionConfig = factory->create<PowerDevil::ActionConfig>();
        if (!actionConfig) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property(QStringLiteral("X-KDE-PowerDevil-Action-UIComponentLibrary"),
                                                                       QVariant::String).toString();
            continue;
        }

        connect(actionConfig, &PowerDevil::ActionConfig::changed, this, &ActionEditWidget::onChanged);

        QCheckBox *checkbox = new QCheckBox(offer->name());
        connect(checkbox, &QCheckBox::stateChanged, this, &ActionEditWidget::onChanged);
        m_actionsHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), checkbox);
        m_actionsConfigHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), actionConfig);

        QList<QPair<QString, QWidget*> > offerWidgets = actionConfig->buildUi();
        offerWidgets.prepend(qMakePair<QString,QWidget*>(QString(), checkbox));
        widgets.insert(100 - offer->property("X-KDE-PowerDevil-Action-ConfigPriority", QVariant::Int).toInt(),
                            offerWidgets);
    }
```

#### AUTO 


```{c}
auto shortcuts = KGlobalAccel::self()->shortcut(&oldAction);
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, &UdevQt::Client::deviceChanged, this, &PowerDevilUPowerBackend::onDeviceChanged);
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
                    }
```

#### AUTO 


```{c}
auto *watcher = new QDBusPendingCallWatcher(reply, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                    if (syspathJob->error()) {
                                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                        qCDebug(POWERDEVIL) << syspathJob->errorText();
                                        Q_EMIT brightnessSupportQueried(false);
                                        return;
                                    }
                                    m_syspath = syspathJob->data()["syspath"].toString();
                                    m_syspath = QFileInfo(m_syspath).readLink();

                                    m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                    if (!m_isLedBrightnessControl) {
                                        UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                        connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                    }

                                    Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    qCDebug(POWERDEVIL) << brightnessJob->errorText();
                    Q_EMIT brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

#ifdef Q_OS_FREEBSD
                        // FreeBSD doesn't have the sysfs interface that the bits below expect;
                        // the sysfs calls always fail, leading to brightnessSupportQueried(false) emission.
                        // Skip that command and carry on with the information that we do have.
                        Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
#else
                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, &UdevQt::Client::deviceChanged, this, &PowerDevilUPowerBackend::onDeviceChanged);
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
#endif
                    }
                );
                brightnessMaxJob->start();
            }
```

#### AUTO 


```{c}
auto powerButtonMode = [globalAction] (bool isTablet) {
        if (!isTablet) {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, Qt::Key_PowerOff);
        } else {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, QList<QKeySequence>());
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& subsysDevtype : subsystemList) {
        int ix = subsysDevtype.indexOf(u'/');

        if (ix > 0) {
            QByteArray subsystem = subsysDevtype.leftRef(ix).toLatin1();
            QByteArray devType = subsysDevtype.midRef(ix + 1).toLatin1();
            udev_monitor_filter_add_match_subsystem_devtype(newM, subsystem.constData(), devType.constData());
        } else {
            udev_monitor_filter_add_match_subsystem_devtype(newM, subsysDevtype.toLatin1().constData(), nullptr);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &battery : batteries) {
        QFile file(s_powerSupplySysFsPath + QLatin1Char('/') + battery + QLatin1Char('/') + which);
        if (!file.open(QIODevice::ReadOnly)) {
            continue;
        }

        int threshold = -1;
        QTextStream stream(&file);
        stream >> threshold;

        if (threshold < 0 || threshold > 100) {
            qWarning() << file.fileName() << "contains invalid threshold" << threshold;
            continue;
        }

        thresholds.append(threshold);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    qCDebug(POWERDEVIL) << brightnessJob->errorText();
                    Q_EMIT brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, &UdevQt::Client::deviceChanged, this, &PowerDevilUPowerBackend::onDeviceChanged);
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
                    }
                );
                brightnessMaxJob->start();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, output] {
            auto it = m_dpms.find(output);
            if (it == m_dpms.end()) {
                return;
            }
            auto dpms = it.value();
            m_dpms.erase(it);
            if (dpms) {
                dpms->deleteLater();
            }
            output->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activeInhibition : activeInhibitions) {
            if (activeInhibition.mode != QLatin1String("block")) {
                continue;
            }

            if (static_cast<pid_t>(activeInhibition.pid) == getpid()) {
                continue;
            }

            const auto types = activeInhibition.what.split(QLatin1Char(':'));

            RequiredPolicies policies{};

            if (types.contains(QLatin1String("sleep"))) {
                policies |= InterruptSession;
            }
            if (types.contains(QLatin1String("idle"))) {
                policies |= ChangeScreenSettings;
            }

            if (!policies) {
                continue;
            }

            const bool known = std::find(m_logindInhibitions.constBegin(),
                                         m_logindInhibitions.constEnd(),
                                         activeInhibition) != m_logindInhibitions.constEnd();
            if (known) {
                continue;
            }

            qCDebug(POWERDEVIL) << "Adding logind inhibition:" << activeInhibition.what << activeInhibition.who << activeInhibition.why
                                << "from" << activeInhibition.pid << "of user" << activeInhibition.uid;
            const uint cookie = AddInhibition(policies, activeInhibition.who, activeInhibition.why);
            m_logindInhibitions.insert(cookie, activeInhibition);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](PowerDevil::PolicyAgent::RequiredPolicies newPolicies) {
        Q_UNUSED(newPolicies);
        KIdleTime::instance()->simulateUserActivity();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ActivityWidget *widget : qAsConst(m_activityWidgets)) {
        widget->load();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        qCDebug(POWERDEVIL) << "Enforcing inhibition from" << service << appName << "with cookie"
                            << cookie << "and reason" << reason;

        if (!m_pendingInhibitions.contains(cookie)) {
            qCDebug(POWERDEVIL) << "By the time we wanted to enforce the inhibition it was already gone; discarding it";
            return;
        }

        m_cookieToAppName.insert(cookie, qMakePair<QString, QString>(appName, reason));

        if (!m_busWatcher.isNull() && !service.isEmpty()) {
            m_cookieToBusService.insert(cookie, service);
            m_busWatcher.data()->addWatchedService(service);
        }

        addInhibitionTypeHelper(cookie, static_cast< PolicyAgent::RequiredPolicies >(types));

        Q_EMIT InhibitionsChanged({ {qMakePair(appName, reason)} }, {});

        m_pendingInhibitions.removeOne(cookie);
    }
```

#### AUTO 


```{c}
const auto startThresholds = getThresholds(s_chargeStartThreshold);
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    emit brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                emit brightnessSupportQueried(true);
                            }
                        );
                        syspathJob->start();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        qCDebug(POWERDEVIL) << "Enforcing inhibition from" << service << appName << "with cookie"
                            << cookie << "and reason" << reason;

        if (!m_pendingInhibitions.contains(cookie)) {
            qCDebug(POWERDEVIL) << "By the time we wanted to enforce the inhibition it was already gone; discarding it";
            return;
        }

        m_cookieToAppName.insert(cookie, qMakePair(appName, reason));

        addInhibitionTypeHelper(cookie, static_cast< PolicyAgent::RequiredPolicies >(types));

        Q_EMIT InhibitionsChanged({ {qMakePair(appName, reason)} }, {});

        m_pendingInhibitions.removeOne(cookie);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                            if (brightnessMaxJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                                qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                            } else {
                                m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                            }

                            KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                            syspathAction.setHelperId(HELPER_ID);
                            KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                            connect(syspathJob, &KJob::result, this,
                                [this, syspathJob] {
                                    if (syspathJob->error()) {
                                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                        qCDebug(POWERDEVIL) << syspathJob->errorText();
                                        Q_EMIT brightnessSupportQueried(false);
                                        return;
                                    }
                                    m_syspath = syspathJob->data()["syspath"].toString();
                                    m_syspath = QFileInfo(m_syspath).readLink();

                                    m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                    if (!m_isLedBrightnessControl) {
                                        UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                        connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                    }

                                    Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                                }
                            );
                            syspathJob->start();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &f : qAsConst(fileInfos)) {
        if (f.baseName().toLower() == QLatin1String("powerdevilupowerbackend")) {
            backendFileInfo = f;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QString> reply = *watcher;
        if (!reply.isError()) {
            onScreenLockerOwnerChanged(SCREEN_LOCKER_SERVICE_NAME, {}, reply.value());
        }
        watcher->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[msg, watcher] {
            watcher->deleteLater();
            if (watcher->isError()) {
                QDBusConnection::sessionBus().send(msg.createErrorReply(watcher->error()));
            } else {
                QDBusConnection::sessionBus().send(msg.createReply());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        QDir dir(path + QLatin1String("/kf5/powerdevil/"),
            QStringLiteral("*"),
            QDir::SortFlags(QDir::QDir::Name),
            QDir::NoDotAndDotDot | QDir::Files);
        fileInfos.append(dir.entryInfoList());
    }
```

#### AUTO 


```{c}
auto erased = m_scheduledWakeups.erase(std::remove_if(m_scheduledWakeups.begin(), m_scheduledWakeups.end(), [cookie](WakeupInfo wakeup) {
        return wakeup.cookie == cookie;
    }));
```

#### AUTO 


```{c}
auto it = m_batteriesPercent.constBegin();
```

#### AUTO 


```{c}
auto *watcher = new QDBusPendingCallWatcher(QDBusConnection::sessionBus().asyncCall(msg), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : timeoutsToClean) {
        KIdleTime::instance()->removeIdleTimeout(id);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & interface : interfaces) {
        QFile enabled(BACKLIGHT_SYSFS_PATH + interface + "/device/enabled");
        if (!enabled.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }
        if (enabled.readLine().trimmed() != "enabled") {
            // this backlight device isn't connected to a display, so move on
            // to the next one and see if it does.
            continue;
        }

        file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        buffer = file.readLine().trimmed();
        if (buffer == "firmware") {
            firmware.append(interface);
        } else if(buffer == "platform") {
            platform.append(interface);
        } else if (buffer == "raw") {
            raw.append(interface);
        } else {
            qCWarning(POWERDEVIL) << "Interface type not handled" << buffer;
        }

        file.close();
    }
```

#### AUTO 


```{c}
auto it = m_dpms.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[toRam, mobile](KConfigGroup &profile)
    {
        const Modes defaultPowerButtonAction = mobile ? ToggleScreenOnOffMode : LogoutDialogMode;

        KConfigGroup handleButtonEvents(&profile, "HandleButtonEvents");
        handleButtonEvents.writeEntry< uint >("powerButtonAction", defaultPowerButtonAction);
        handleButtonEvents.writeEntry< uint >("powerDownAction", LogoutDialogMode);
        if (toRam) {
            handleButtonEvents.writeEntry< uint >("lidAction", ToRamMode);
        } else {
            handleButtonEvents.writeEntry< uint >("lidAction", TurnOffScreenMode);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& subsysDevtype : subsystemList) {
        int ix = subsysDevtype.indexOf(u'/');

        if (ix > 0) {
            QByteArray subsystem = QStringView(subsysDevtype).left(ix).toLatin1();
            QByteArray devType = QStringView(subsysDevtype).mid(ix + 1).toLatin1();
            udev_monitor_filter_add_match_subsystem_devtype(newM, subsystem.constData(), devType.constData());
        } else {
            udev_monitor_filter_add_match_subsystem_devtype(newM, subsysDevtype.toLatin1().constData(), nullptr);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KScreen::ConfigOperation *op) {
                m_screenConfiguration = qobject_cast<KScreen::GetConfigOperation *>(op)->config();
                checkOutputs();

                KScreen::ConfigMonitor::instance()->addConfig(m_screenConfiguration);
                connect(KScreen::ConfigMonitor::instance(), &KScreen::ConfigMonitor::configurationChanged, this, &HandleButtonEvents::checkOutputs);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<bool> reply = *watcher;
            if (!reply.isError()) {
                onScreenLockerActiveChanged(reply.value());
            }
            watcher->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & interface : interfaces) {
        file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        buffer = file.readLine().trimmed();
        if (buffer == "firmware") {
            firmware.append(interface);
        } else if(buffer == "platform") {
            platform.append(interface);
        } else if (buffer == "raw") {
            QFile enabled(BACKLIGHT_SYSFS_PATH + interface + "/device/enabled");
            if (enabled.open(QIODevice::ReadOnly | QIODevice::Text) && 
                enabled.readLine().trimmed() == "enabled") {
                // this backlight device is connected to a display, so append
                // it to raw list
                raw.append(interface);
            }
        } else {
            qCWarning(POWERDEVIL) << "Interface type not handled" << buffer;
        }

        file.close();
    }
```

#### AUTO 


```{c}
auto it = permissions.constBegin();
```

#### AUTO 


```{c}
auto *extension = xcb_get_extension_data(c, &xcb_randr_id);
```

#### AUTO 


```{c}
const auto batteries = Solid::Device::listFromType(Solid::DeviceInterface::Battery, QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        writeBrightness(value.toInt());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        qCDebug(POWERDEVIL) << "Enforcing inhibition from" << service << appName << "with cookie"
                            << cookie << "and reason" << reason;

        if (!m_pendingInhibitions.contains(cookie)) {
            qCDebug(POWERDEVIL) << "By the time we wanted to enforce the inhibition it was already gone; discarding it";
            return;
        }

        m_cookieToAppName.insert(cookie, qMakePair<QString, QString>(appName, reason));

        if (!m_busWatcher.isNull() && !service.isEmpty()) {
            m_cookieToBusService.insert(cookie, service);
            m_busWatcher.data()->addWatchedService(service);
        }

        addInhibitionTypeHelper(cookie, static_cast< PolicyAgent::RequiredPolicies >(types));

        emit InhibitionsChanged({ {qMakePair(appName, reason)} }, {});

        m_pendingInhibitions.removeOne(cookie);
    }
```

#### AUTO 


```{c}
const auto activeInhibitions = reply.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (m_helper) {
            if (m_lockBeforeTurnOff) {
                lockScreen();
            }
            m_helper->trigger(QStringLiteral("TurnOff"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionName : groupList) {
            Action *action = ActionPool::instance()->loadAction(actionName, config.group(actionName), this);
            if (action) {
                action->onProfileLoad();
            } else {
                // Ouch, error. But let's just warn and move on anyway
                //TODO Maybe Remove from the configuration if unsupported
                qCWarning(POWERDEVIL) << "The profile " << profileId <<  "tried to activate"
                                << actionName << "a non-existent action. This is usually due to an installation problem,"
                                " a configuration problem, or because the action is not supported";
            }
        }
```

#### AUTO 


```{c}
const auto oldPolicies = unavailablePolicies();
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<QStringList> reply = *watcher;
            watcher->deleteLater();

            if (reply.isError()) {
                qCWarning(POWERDEVIL) << "Failed to fetch list of DBus service names for pausing players on entering sleep" << reply.error().message();
                return;
            }

            const QStringList &services = reply.value();
            for (const QString &serviceName : services) {
                if (!serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2."))) {
                    continue;
                }

                if (serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2.kdeconnect.mpris_"))) {
                    // This is actually a player on another device exposed by KDE Connect
                    // We don't want to pause it
                    // See https://bugs.kde.org/show_bug.cgi?id=427209
                    continue;
                }

                qCDebug(POWERDEVIL) << "Pausing media player with service name" << serviceName;

                QDBusMessage pauseMsg = QDBusMessage::createMethodCall(serviceName,
                                                                       QStringLiteral("/org/mpris/MediaPlayer2"),
                                                                       QStringLiteral("org.mpris.MediaPlayer2.Player"),
                                                                       QStringLiteral("Pause"));
                QDBusConnection::sessionBus().asyncCall(pauseMsg);
            }
       }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<LogindInhibition>> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qCWarning(POWERDEVIL) << "Failed to ask logind for inhibitions" << reply.error().message();
            return;
        }

        const auto activeInhibitions = reply.value();

        // Add all inhibitions that we don't know already
        for (const auto &activeInhibition : activeInhibitions) {
            if (activeInhibition.mode != QLatin1String("block")) {
                continue;
            }

            if (static_cast<pid_t>(activeInhibition.pid) == getpid()) {
                continue;
            }

            const auto types = activeInhibition.what.split(QLatin1Char(':'));

            RequiredPolicies policies{};

            if (types.contains(QLatin1String("sleep"))) {
                policies |= InterruptSession;
            }
            if (types.contains(QLatin1String("idle"))) {
                policies |= ChangeScreenSettings;
            }

            if (!policies) {
                continue;
            }

            const bool known = std::find(m_logindInhibitions.constBegin(),
                                         m_logindInhibitions.constEnd(),
                                         activeInhibition) != m_logindInhibitions.constEnd();
            if (known) {
                continue;
            }

            qCDebug(POWERDEVIL) << "Adding logind inhibition:" << activeInhibition.what << activeInhibition.who << activeInhibition.why
                                << "from" << activeInhibition.pid << "of user" << activeInhibition.uid;
            const uint cookie = AddInhibition(policies, activeInhibition.who, activeInhibition.why);
            m_logindInhibitions.insert(cookie, activeInhibition);
        }

        // Remove all inhibitions that logind doesn't have anymore
        for (auto it = m_logindInhibitions.begin(); it != m_logindInhibitions.end();) {
            if (!activeInhibitions.contains(*it)) {
                qCDebug(POWERDEVIL) << "Releasing logind inhibition:" << it->what << it->who << it->why << "from" << it->pid << "of user" << it->uid;
                ReleaseInhibition(it.key());
                it = m_logindInhibitions.erase(it);
            } else {
                ++it;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[msg, watcher, this] {
        watcher->deleteLater();
        QDBusPendingReply<unsigned int> reply = *watcher;
        if (reply.isError()) {
            QDBusConnection::sessionBus().send(msg.createErrorReply(watcher->error()));
        } else {
            m_holdWatcher->addWatchedService(msg.service());
            m_holdMap.insert(msg.service(), reply.value());
            QDBusConnection::sessionBus().send(msg.createReply(reply.value()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<QStringList> reply = *watcher;
            watcher->deleteLater();

            if (reply.isError()) {
                qCWarning(POWERDEVIL) << "Failed to fetch list of DBus service names for pausing players on entering sleep" << reply.error().message();
                return;
            }

            const QStringList &services = reply.value();
            for (const QString &serviceName : services) {
                if (!serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2."))) {
                    continue;
                }

                qCDebug(POWERDEVIL) << "Pausing media player with service name" << serviceName;

                QDBusMessage pauseMsg = QDBusMessage::createMethodCall(serviceName,
                                                                       QStringLiteral("/org/mpris/MediaPlayer2"),
                                                                       QStringLiteral("org.mpris.MediaPlayer2.Player"),
                                                                       QStringLiteral("Pause"));
                QDBusConnection::sessionBus().asyncCall(pauseMsg);
            }
       }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OrgFreedesktopUPowerDeviceInterface * upowerDevice : qAsConst(m_devices)) {
        if (upowerDevice->type() == 2 && upowerDevice->powerSupply()) {
            QString udi = upowerDevice->path();
            setCapacityForBattery(udi, qRound(upowerDevice->capacity()));  // acknowledge capacity
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : m_devices) {
            writeToDevice(device.first, brightness * device.second / first_maxbrightness);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, profile](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        m_profileCombo->clear();
        m_profileCombo->addItem(i18n("Leave unchanged"));

        if (reply.isError()) {
            qWarning() << "Failed to query platform profile choices" << reply.error().message();
            return;
        }

        const QHash<QString, QString> profileNames = {
            {QStringLiteral("power-saver"), i18n("Power Save")},
            {QStringLiteral("balanced"), i18n("Balanced")},
            {QStringLiteral("performance"), i18n("Performance")},
        };

        const QStringList choices = reply.value();
        for (const QString &choice : choices) {
            m_profileCombo->addItem(profileNames.value(choice, choice), choice);
        }
        m_profileCombo->setCurrentIndex(qMax(0, m_profileCombo->findData(profile)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & interface : interfaces) {
        QFile enabled(BACKLIGHT_SYSFS_PATH + interface + "/device/enabled");
        if (enabled.open(QIODevice::ReadOnly | QIODevice::Text)) {
            if (enabled.readLine().trimmed() != "enabled") {
                // this backlight device isn't connected to a display, so move on
                // to the next one and see if it does.
                continue;
            }
        }

        file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        buffer = file.readLine().trimmed();
        if (buffer == "firmware") {
            firmware.append(interface);
        } else if(buffer == "platform") {
            platform.append(interface);
        } else if (buffer == "raw") {
            raw.append(interface);
        } else {
            qCWarning(POWERDEVIL) << "Interface type not handled" << buffer;
        }

        file.close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ActivityWidget *widget : qAsConst(m_activityWidgets)) {
        widget->save();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, &UdevQt::Client::deviceChanged, this, &PowerDevilUPowerBackend::onDeviceChanged);
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
```

#### AUTO 


```{c}
auto stopThresholds = getThresholds(s_chargeEndThreshold);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KScreen::OutputPtr &output : m_screenConfiguration->outputs()) {
        if (output->isConnected() && output->isEnabled() && output->type() != KScreen::Output::Panel && output->type() != KScreen::Output::Unknown) {
            hasExternalMonitor = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto initLid = [toRam, mobile](KConfigGroup &profile)
    {
        const Modes defaultPowerButtonAction = mobile ? ToggleScreenOnOffMode : LogoutDialogMode;

        KConfigGroup handleButtonEvents(&profile, "HandleButtonEvents");
        handleButtonEvents.writeEntry< uint >("powerButtonAction", defaultPowerButtonAction);
        handleButtonEvents.writeEntry< uint >("powerDownAction", LogoutDialogMode);
        if (toRam) {
            handleButtonEvents.writeEntry< uint >("lidAction", ToRamMode);
        } else {
            handleButtonEvents.writeEntry< uint >("lidAction", TurnOffScreenMode);
        }
    };
```

#### AUTO 


```{c}
auto interface = qobject_cast<PowerDevil::BackendInterface*>(instance);
```

#### LAMBDA EXPRESSION 


```{c}
[globalAction] (bool isTablet) {
        if (!isTablet) {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, QList<QKeySequence>());
        } else {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, Qt::Key_PowerOff);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                if (syspathJob->error()) {
                                    emit brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                emit brightnessSupportQueried(true);
                            }
```

#### AUTO 


```{c}
auto it = cookies.first;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &battery : batteries) {
        QFile file(s_powerSupplySysFsPath + QLatin1Char('/') + battery + QLatin1Char('/') + which);
        if (!file.open(QIODevice::ReadOnly)) {
            qWarning() << "Failed to open" << file.fileName() << "for reading";
            continue;
        }

        int threshold = -1;
        QTextStream stream(&file);
        stream >> threshold;

        if (threshold < 0 || threshold > 100) {
            qWarning() << file.fileName() << "contains invalid threshold" << threshold;
            continue;
        }

        thresholds.append(threshold);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[globalAction] (bool isTablet) {
        if (!isTablet) {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, Qt::Key_PowerOff);
        } else {
            KGlobalAccel::self()->setGlobalShortcut(globalAction, QList<QKeySequence>());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : m_devices) {
            // Some monitor brightness values are ridiculously high, and can easily overflow during computation
            const qint64 new_brightness_64 = static_cast<qint64>(brightness) * static_cast<qint64>(device.second) / static_cast<qint64>(first_maxbrightness);
            // cautiously truncate it back
            const int new_brightness = static_cast<int>(std::min(static_cast<qint64>(std::numeric_limits<int>::max()), new_brightness_64));
            writeToDevice(device.first, new_brightness);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
                    }
```

#### AUTO 


```{c}
auto it = cookieToBusService.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : devices) {
        const Solid::Battery *b = qobject_cast<const Solid::Battery*> (device.asDeviceInterface(Solid::DeviceInterface::Battery));
        if (b->isPowerSupply()) {
            hasPowerSupplyBattery = true;
        } else {
            hasPeripheralBattery = true;
        }
    }
```

#### AUTO 


```{c}
auto *c = QX11Info::connection();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
            QDBusPendingReply<QStringList> reply = *self;
            self->deleteLater();
            if (!reply.isValid()) {
                return;
            }
            if (reply.value().contains(s_fdoPowerService)) {
                d->update();
            }
        }
```

#### AUTO 


```{c}
auto it = std::find(m_holdMap.begin(), m_holdMap.end(), cookie);
```

#### AUTO 


```{c}
auto it = m_dpms.find(output);
```

#### AUTO 


```{c}
auto timeout = mobile ? 60 : 300;
```

#### AUTO 


```{c}
auto *backlightReply = xcb_intern_atom_reply(QX11Info::connection(),
        xcb_intern_atom (QX11Info::connection(), 1, strlen("Backlight"), "Backlight"),
    nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
            if (brightnessJob->error()) {
                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                qCDebug(POWERDEVIL) << brightnessJob->errorText();
                Q_EMIT brightnessSupportQueried(false);
                return;
            }
            m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

            KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
            brightnessMaxAction.setHelperId(HELPER_ID);
            KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
            connect(brightnessMaxJob, &KJob::result, this,
                [this, brightnessMaxJob] {
                    if (brightnessMaxJob->error()) {
                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                        qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                    } else {
                        m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                    }

                    KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                    syspathAction.setHelperId(HELPER_ID);
                    KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                    connect(syspathJob, &KJob::result, this,
                        [this, syspathJob] {
                            if (syspathJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                qCDebug(POWERDEVIL) << syspathJob->errorText();
                                Q_EMIT brightnessSupportQueried(false);
                                return;
                            }
                            m_syspath = syspathJob->data()["syspath"].toString();
                            m_syspath = QFileInfo(m_syspath).readLink();

                            m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                            if (!m_isLedBrightnessControl) {
                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                            }

                            Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                        }
                    );
                    syspathJob->start();
                }
            );
            brightnessMaxJob->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QString> reply = *watcher;

        if (!reply.isError()) {
            const QString &currentProfile = reply.value();
            if (currentProfile == QLatin1String("Battery")) {
                tabWidget->setCurrentIndex(1);
            } else if (currentProfile == QLatin1String("LowBattery")) {
                tabWidget->setCurrentIndex(2);
            }
        }

        watcher->deleteLater();
    }
```

#### AUTO 


```{c}
const auto groupList = config.groupList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceName : services) {
                if (!serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2."))) {
                    continue;
                }

                qCDebug(POWERDEVIL) << "Pausing media player with service name" << serviceName;

                QDBusMessage pauseMsg = QDBusMessage::createMethodCall(serviceName,
                                                                       QStringLiteral("/org/mpris/MediaPlayer2"),
                                                                       QStringLiteral("org.mpris.MediaPlayer2.Player"),
                                                                       QStringLiteral("Pause"));
                QDBusConnection::sessionBus().asyncCall(pauseMsg);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                    if (brightnessMaxJob->error()) {
                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                        qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                    } else {
                        m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                    }

                    KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                    syspathAction.setHelperId(HELPER_ID);
                    KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                    connect(syspathJob, &KJob::result, this,
                        [this, syspathJob] {
                            if (syspathJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                qCDebug(POWERDEVIL) << syspathJob->errorText();
                                Q_EMIT brightnessSupportQueried(false);
                                return;
                            }
                            m_syspath = syspathJob->data()["syspath"].toString();
                            m_syspath = QFileInfo(m_syspath).readLink();

                            m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                            if (!m_isLedBrightnessControl) {
                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                            }

                            Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                        }
                    );
                    syspathJob->start();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setKeyboardBrightnessSilent(keyboardBrightness());
    }
```

#### AUTO 


```{c}
auto it = m_logindInhibitions.begin();
```

#### AUTO 


```{c}
auto startThresholds = getThresholds(s_chargeStartThreshold);
```

#### AUTO 


```{c}
auto *propertyReply = xcb_randr_query_output_property_reply(QX11Info::connection(),
        xcb_randr_query_output_property(QX11Info::connection(), output, m_backlight)
    , nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
        // Does it have a runtime requirement?
        if (offer->property("X-KDE-PowerDevil-Action-HasRuntimeRequirement", QVariant::Bool).toBool()) {
            qCDebug(POWERDEVIL) << offer->name() << " has a runtime requirement";

            QDBusMessage call = QDBusMessage::createMethodCall("org.kde.Solid.PowerManagement", "/org/kde/Solid/PowerManagement",
                                                               "org.kde.Solid.PowerManagement", "isActionSupported");
            call.setArguments(QVariantList() << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String));
            QDBusPendingReply< bool > reply = QDBusConnection::sessionBus().asyncCall(call);
            reply.waitForFinished();

            if (reply.isValid()) {
                if (!reply.value()) {
                    qCDebug(POWERDEVIL) << "The action " << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String) << " appears not to be supported by the core.";
                    continue;
                }
            } else {
                qCDebug(POWERDEVIL) << "There was a problem in contacting DBus!! Assuming the action is ok.";
            }
        }

        //try to load the specified library
        KPluginFactory *factory = KPluginLoader(offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                QVariant::String).toString()).factory();

        if (!factory) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        PowerDevil::ActionConfig *actionConfig = factory->create<PowerDevil::ActionConfig>();
        if (!actionConfig) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        connect(actionConfig, SIGNAL(changed()), this, SLOT(onChanged()));

        QCheckBox *checkbox = new QCheckBox(offer->name());
        connect(checkbox, SIGNAL(stateChanged(int)), this, SLOT(onChanged()));
        m_actionsHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), checkbox);
        m_actionsConfigHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), actionConfig);

        QList<QPair<QString, QWidget*> > offerWidgets = actionConfig->buildUi();
        offerWidgets.prepend(qMakePair<QString,QWidget*>(QString(), checkbox));
        widgets.insert(100 - offer->property("X-KDE-PowerDevil-Action-ConfigPriority", QVariant::Int).toInt(),
                            offerWidgets);
    }
```

#### AUTO 


```{c}
auto call = m_powerProfilesInterface->ReleaseProfile(cookie);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &battery : batteries) {
        QFile file(s_powerSupplySysFsPath + QLatin1Char('/') + battery + QLatin1Char('/') + which);
        // TODO should we check the current value before writing the new one or is it clever
        // enough not to shred some chip by writing the same thing again?
        if (!file.open(QIODevice::WriteOnly)) {
            qWarning() << "Failed to open" << file.fileName() << "for writing";
            return false;
        }

        if (file.write(QByteArray::number(threshold)) == -1) {
            qWarning() << "Failed to write threshold into" << file.fileName();
            return false;
        }
    }
```

#### AUTO 


```{c}
auto it = m_cookieToBusService.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (uint cookie : allCookies) {
        ReleaseInhibition(cookie);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
        QString actionId = offer->property(QStringLiteral("X-KDE-PowerDevil-Action-ID"), QVariant::String).toString();

        qCDebug(POWERDEVIL) << "Got a valid offer for " << actionId;

        if (!offer->showOnCurrentPlatform()) {
            qCDebug(POWERDEVIL) << "Doesn't support the windowing system";
            continue;
        }

        //try to load the specified library
        PowerDevil::Action *retaction = offer->createInstance< PowerDevil::Action >(parent);

        if (!retaction) {
            // Troubles...
            qCWarning(POWERDEVIL) << "failed to load" << offer->desktopEntryName();
            continue;
        }

        // Is the action available and supported?
        if (!retaction->isSupported()) {
            // Skip that
            retaction->deleteLater();
            continue;
        }

        // Insert
        m_actionPool.insert(actionId, retaction);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
                    }
```

#### AUTO 


```{c}
auto *job = action.execute();
```

#### AUTO 


```{c}
auto *outputs = xcb_randr_get_screen_resources_current_outputs(m_resources.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                Q_EMIT brightnessSupportQueried(true);
                            }
                        );
                        syspathJob->start();
                    }
```

#### AUTO 


```{c}
const auto cookieToBusService = m_cookieToBusService;
```

#### RANGE FOR STATEMENT 


```{c}
for(const KScreen::OutputPtr &output : m_screenConfiguration->outputs()) {
        if (output->isConnected() && output->isEnabled() && output->type() != KScreen::Output::Panel) {
            hasExternalMonitor = true;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    qCDebug(POWERDEVIL) << brightnessJob->errorText();
                    Q_EMIT brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }
                                Q_EMIT brightnessSupportQueried(true);
                            }
                        );
                        syspathJob->start();
                    }
                );
                brightnessMaxJob->start();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
        // Does it have a runtime requirement?
        if (offer->property("X-KDE-PowerDevil-Action-HasRuntimeRequirement", QVariant::Bool).toBool()) {
            qCDebug(POWERDEVIL) << offer->name() << " has a runtime requirement";

            QDBusMessage call = QDBusMessage::createMethodCall("org.kde.Solid.PowerManagement", "/org/kde/Solid/PowerManagement",
                                                               "org.kde.Solid.PowerManagement", "isActionSupported");
            call.setArguments(QVariantList() << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String));
            QDBusPendingReply< bool > reply = QDBusConnection::sessionBus().asyncCall(call);
            reply.waitForFinished();

            if (reply.isValid()) {
                if (!reply.value()) {
                    qCDebug(POWERDEVIL) << "The action " << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String) << " appears not to be supported by the core.";
                    continue;
                }
            } else {
                qCDebug(POWERDEVIL) << "There was a problem in contacting DBus!! Assuming the action is ok.";
            }
        }

        //try to load the specified library
        KPluginFactory *factory = KPluginLoader(offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                QVariant::String).toString()).factory();

        if (!factory) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        PowerDevil::ActionConfig *actionConfig = factory->create<PowerDevil::ActionConfig>();
        if (!actionConfig) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        connect(actionConfig, &PowerDevil::ActionConfig::changed, this, &ActionEditWidget::onChanged);

        QCheckBox *checkbox = new QCheckBox(offer->name());
        connect(checkbox, &QCheckBox::stateChanged, this, &ActionEditWidget::onChanged);
        m_actionsHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), checkbox);
        m_actionsConfigHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), actionConfig);

        QList<QPair<QString, QWidget*> > offerWidgets = actionConfig->buildUi();
        offerWidgets.prepend(qMakePair<QString,QWidget*>(QString(), checkbox));
        widgets.insert(100 - offer->property("X-KDE-PowerDevil-Action-ConfigPriority", QVariant::Int).toInt(),
                            offerWidgets);
    }
```

#### AUTO 


```{c}
const auto &device
```

#### LAMBDA EXPRESSION 


```{c}
[this] (unsigned int cookie) {
        auto it = std::find(m_holdMap.begin(), m_holdMap.end(), cookie);
        if (it != m_holdMap.end()) {
            if (m_holdMap.count(it.key()) == 1) {
                m_holdWatcher->removeWatchedService(it.key());
            }
            m_holdMap.erase(it);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OrgFreedesktopUPowerDeviceInterface * upowerDevice : qAsConst(m_devices)) {
            const uint type = upowerDevice->type();
            if (( type == 2 || type == 3) && upowerDevice->powerSupply()) {
                const uint state = upowerDevice->state();
                energyFullTotal += upowerDevice->energyFull();
                energyTotal += upowerDevice->energy();
                energyRateTotal += upowerDevice->energyRate();

                if (state == 1) { // total is charging
                    stateTotal = 1;
                } else if (state == 2 && stateTotal != 1) { // total is discharging
                    stateTotal = 2;
                } else if (state == 4 && stateTotal != 0) { // total is fully-charged
                    stateTotal = 4;
                }

                if (state == 1) { // charging
                    remainingTime += upowerDevice->timeToFull();
                } else if (state == 2) { // discharging
                    remainingTime += upowerDevice->timeToEmpty();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!m_savedArgs.isEmpty()) {
            QVariantMap args = m_savedArgs;
            args["SkipFade"] = true;
            triggerImpl(args);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (chargeStopThresholdSpin->value() > m_chargeStopThreshold) {
            chargeStopThresholdMessage->animatedShow();
        } else {
            chargeStopThresholdMessage->animatedHide();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, setter](QDBusPendingCallWatcher *self) {
            QDBusPendingReply<bool> reply = *self;
            self->deleteLater();
            if (!reply.isValid()) {
                return;
            }
            ((this)->*setter)(reply.value());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->update(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        setBrightnessHelper(m_oldScreenBrightness, m_oldKeyboardBrightness, true);
    }
```

#### AUTO 


```{c}
auto timeout = mobile ? 30000 : 60000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
        // Does it have a runtime requirement?
        if (offer->property("X-KDE-PowerDevil-Action-HasRuntimeRequirement", QVariant::Bool).toBool()) {
            qCDebug(POWERDEVIL) << offer->name() << " has a runtime requirement";

            QDBusMessage call = QDBusMessage::createMethodCall("org.kde.Solid.PowerManagement", "/org/kde/Solid/PowerManagement",
                                                               "org.kde.Solid.PowerManagement", "isActionSupported");
            call.setArguments(QVariantList() << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String));
            QDBusPendingReply< bool > reply = QDBusConnection::sessionBus().asyncCall(call);
            reply.waitForFinished();

            if (reply.isValid()) {
                if (!reply.value()) {
                    qCDebug(POWERDEVIL) << "The action " << offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String) << " appears not to be supported by the core.";
                    continue;
                }
            } else {
                qCDebug(POWERDEVIL) << "There was a problem in contacting DBus!! Assuming the action is ok.";
            }
        }

        //try to load the specified library
        KPluginFactory *factory = KPluginLoader(offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                QVariant::String).toString()).factory();

        if (!factory) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        PowerDevil::ActionConfig *actionConfig = factory->create<PowerDevil::ActionConfig>();
        if (!actionConfig) {
            qCWarning(POWERDEVIL) << "KPluginFactory could not load the plugin:" << offer->property("X-KDE-PowerDevil-Action-UIComponentLibrary",
                                                                       QVariant::String).toString();
            continue;
        }

        connect(actionConfig, SIGNAL(changed()), this, SLOT(onChanged()));

        QCheckBox *checkbox = new QCheckBox(offer->name());
        connect(checkbox, SIGNAL(stateChanged(int)), this, SLOT(onChanged()));
        m_actionsHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), checkbox);
        m_actionsConfigHash.insert(offer->property("X-KDE-PowerDevil-Action-ID", QVariant::String).toString(), actionConfig);

        QList<QPair<QString, QWidget*> > offerWidgets = actionConfig->buildUi();
        offerWidgets.prepend(qMakePair<QString,QWidget*>(QString(), checkbox));
        widgets.insertMulti(100 - offer->property("X-KDE-PowerDevil-Action-ConfigPriority", QVariant::Int).toInt(),
                            offerWidgets);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath & device : deviceList) {
        addDevice(device.path());
    }
```

#### AUTO 


```{c}
auto i = m_batteriesCharged.constBegin();
```

#### AUTO 


```{c}
auto call = m_powerProfilesPropertiesInterface->Set(m_powerProfilesInterface->interface(), activeProfileProperty, QDBusVariant(profile));
```

#### AUTO 


```{c}
auto *versionReply = xcb_randr_query_version_reply(QX11Info::connection(),
        xcb_randr_query_version(QX11Info::connection(), 1, 2),
    nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr offer : offers) {
        QString actionId = offer->property(QStringLiteral("X-KDE-PowerDevil-Action-ID"), QVariant::String).toString();

        qCDebug(POWERDEVIL) << "Got a valid offer for " << actionId;

        if (!offer->showOnCurrentPlatform()) {
            qCDebug(POWERDEVIL) << "Doesn't support the windowing system";
            continue;
        }

        //try to load the specified library
        PowerDevil::Action *retaction = offer->createInstance< PowerDevil::Action >(parent);

        if (!retaction) {
            // Troubles...
            qCWarning(POWERDEVIL) << "failed to load" << offer->desktopEntryName();
            continue;
        }

        // Is the action available and supported?
        if (!retaction->isSupported()) {
            // Skip that
            retaction->deleteLater();
            continue;
        }

        // Insert
        m_actionPool.insert(actionId, retaction);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, value] {
                if (job->error()) {
                    qCWarning(POWERDEVIL) << "Failed to set screen brightness" << job->errorText();
                    return;
                }

                // Immediately announce the new brightness to everyone while we still animate to it
                m_cachedBrightnessMap[Screen] = value;
                onBrightnessChanged(Screen, value, brightnessMax(Screen));

                // So we ignore any brightness changes during the animation
                if (!m_brightnessAnimationTimer) {
                    m_brightnessAnimationTimer = new QTimer(this);
                    m_brightnessAnimationTimer->setSingleShot(true);
                }
                m_brightnessAnimationTimer->start(PowerDevilSettings::brightnessAnimationDuration());
            }
```

#### AUTO 


```{c}
auto output = outputs[i];
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        KIdleTime::instance()->simulateUserActivity();

        PowerDevil::PolicyAgent::instance()->setupSystemdInhibition();

        m_fadeEffect->stop();

        Q_EMIT resumingFromSuspend();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto o: outputs) {
        initOutput(o.name, o.version);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, discreteGpuJob]  {
        if (discreteGpuJob->error()) {
            qCWarning(POWERDEVIL) << "org.kde.powerdevil.discretegpuhelper.hasdualgpu failed";
            qCDebug(POWERDEVIL) << discreteGpuJob->errorText();
            return;
        }
        m_hasDualGpu = discreteGpuJob->data()[QStringLiteral("hasdualgpu")].toBool();
    }
```

#### AUTO 


```{c}
const auto devices = Device::listFromType(DeviceInterface::Battery, QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr offer : offers) {
            QString actionId = offer->property(QStringLiteral("X-KDE-PowerDevil-Action-ID"), QVariant::String).toString();

            if (m_actionPool.contains(actionId)) {
                QDBusConnection::sessionBus().registerObject(QStringLiteral("/org/kde/Solid/PowerManagement/Actions/") + actionId, m_actionPool[actionId]);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool active) {
        if (active) {
            // force reload profile so all actions re-register their idle timeouts
            loadProfile(true /*force*/);
        } else {
            // Bug 354250: Keep us from sending the computer to sleep when switching
            // to an idle session by removing all idle timeouts
            KIdleTime::instance()->removeAllIdleTimeouts();
            m_registeredActionTimeouts.clear();
        }
    }
```

#### AUTO 


```{c}
auto *activeReplyWatcher = new QDBusPendingCallWatcher(m_screenLockerInterface->GetActive());
```

#### AUTO 


```{c}
auto i = m_pendingResumeFromIdleActions.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                            if (brightnessMaxJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                                qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                            } else {
                                m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                            }

                            KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                            syspathAction.setHelperId(HELPER_ID);
                            KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                            connect(syspathJob, &KJob::result, this,
                                [this, syspathJob] {
                                    if (syspathJob->error()) {
                                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                        qCDebug(POWERDEVIL) << syspathJob->errorText();
                                        Q_EMIT brightnessSupportQueried(false);
                                        return;
                                    }
                                    m_syspath = syspathJob->data()["syspath"].toString();
                                    m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                    m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                    if (!m_isLedBrightnessControl) {
                                        UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                        connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                    }

                                    Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                                }
                            );
                            syspathJob->start();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device &device : devices) {
            onDeviceAdded(device.udi());
        }
```

#### AUTO 


```{c}
auto *extension = xcb_get_extension_data(c, &xcb_dpms_id);
```

#### AUTO 


```{c}
const auto data = job->data();
```

#### AUTO 


```{c}
auto timeout = mobile ? 30 : 120;
```

#### AUTO 


```{c}
const auto mode = static_cast<Mode>(args["Type"].toUInt());
```

#### AUTO 


```{c}
const auto newPolicies = unavailablePolicies();
```

#### AUTO 


```{c}
const auto devices = Solid::Device::listFromType(Solid::DeviceInterface::Battery, QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_criticalBatteryTimer->stop();
        m_criticalBatteryNotification->close();
    }
```

#### AUTO 


```{c}
const auto types = activeInhibition.what.split(QLatin1Char(':'));
```

#### LAMBDA EXPRESSION 


```{c}
[this] { setSupported(true);}
```

#### AUTO 


```{c}
const auto outputs = m_registry->interfaces(Registry::Interface::Output);
```

#### LAMBDA EXPRESSION 


```{c}
[toRam](KConfigGroup &profile)
    {
        const bool mobile = !qEnvironmentVariableIsEmpty("QT_QUICK_CONTROLS_MOBILE");
        const Modes defaultPowerButtonAction = mobile ? ToRamMode : LogoutDialogMode;

        KConfigGroup handleButtonEvents(&profile, "HandleButtonEvents");
        handleButtonEvents.writeEntry< uint >("powerButtonAction", defaultPowerButtonAction);
        handleButtonEvents.writeEntry< uint >("powerDownAction", LogoutDialogMode);
        if (toRam) {
            handleButtonEvents.writeEntry< uint >("lidAction", ToRamMode);
        } else {
            handleButtonEvents.writeEntry< uint >("lidAction", TurnOffScreenMode);
        }
    }
```

#### AUTO 


```{c}
auto o
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        if (job->error()) {
            qCWarning(POWERDEVIL) << "org.kde.powerdevil.chargethresholdhelper.getthreshold failed" << job->errorText();
            return;
        }

        const auto data = job->data();

        const int chargeStartThreshold = data.value(QStringLiteral("chargeStartThreshold")).toInt();
        if (m_chargeStartThreshold != chargeStartThreshold) {
            m_chargeStartThreshold = chargeStartThreshold;
            Q_EMIT chargeStartThresholdChanged(chargeStartThreshold);
        }

        const int chargeStopThreshold = data.value(QStringLiteral("chargeStopThreshold")).toInt();
        if (m_chargeStopThreshold != chargeStopThreshold) {
            m_chargeStopThreshold = chargeStopThreshold;
            Q_EMIT chargeStopThresholdChanged(chargeStopThreshold);
        }

        qCDebug(POWERDEVIL) << "Charge thresholds: start at" << chargeStartThreshold << "- stop at" << chargeStopThreshold;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<QStringList> reply = *watcher;
            watcher->deleteLater();

            if (reply.isError()) {
                qCWarning(POWERDEVIL) << "Failed to fetch list of DBus service names for pausing players on suspend" << reply.error().message();
                return;
            }

            const QStringList &services = reply.value();
            for (const QString &serviceName : services) {
                if (!serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2."))) {
                    continue;
                }

                qCDebug(POWERDEVIL) << "Pausing media player with service name" << serviceName;

                QDBusMessage pauseMsg = QDBusMessage::createMethodCall(serviceName,
                                                                       QStringLiteral("/org/mpris/MediaPlayer2"),
                                                                       QStringLiteral("org.mpris.MediaPlayer2.Player"),
                                                                       QStringLiteral("Pause"));
                QDBusConnection::sessionBus().asyncCall(pauseMsg);
            }
       }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : batteries) {
        const Solid::Battery *b = qobject_cast<const Solid::Battery*> (device.asDeviceInterface(Solid::DeviceInterface::Battery));
        if (b->type() == Solid::Battery::PrimaryBattery || b->type() == Solid::Battery::UpsBattery) {
            hasBattery = false;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto &activeInhibition
```

#### LAMBDA EXPRESSION 


```{c}
[this, watcher] {
        watcher->deleteLater();
        QDBusPendingReply<QVariantMap> reply = *watcher;
        if (watcher->isError()) {
            return;
        }
        readProperties(reply.value());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &interface : interfaces) {
            file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
            if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                continue;
            }

            buffer = file.readLine().trimmed();
            if (buffer == "raw") {
                raw.append(interface);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                    if (brightnessJob->error()) {
                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                        qCDebug(POWERDEVIL) << brightnessJob->errorText();
                        Q_EMIT brightnessSupportQueried(false);
                        return;
                    }
                    m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                    KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                    brightnessMaxAction.setHelperId(HELPER_ID);
                    KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                    connect(brightnessMaxJob, &KJob::result, this,
                        [this, brightnessMaxJob] {
                            if (brightnessMaxJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                                qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                            } else {
                                m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                            }

                            KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                            syspathAction.setHelperId(HELPER_ID);
                            KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                            connect(syspathJob, &KJob::result, this,
                                [this, syspathJob] {
                                    if (syspathJob->error()) {
                                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                        qCDebug(POWERDEVIL) << syspathJob->errorText();
                                        Q_EMIT brightnessSupportQueried(false);
                                        return;
                                    }
                                    m_syspath = syspathJob->data()["syspath"].toString();
                                    m_syspath = QFileInfo(m_syspath).readLink();

                                    m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                    if (!m_isLedBrightnessControl) {
                                        UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                        connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                    }

                                    Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                                }
                            );
                            syspathJob->start();
                        }
                    );
                    brightnessMaxJob->start();
                }
```

#### AUTO 


```{c}
const auto msg = message();
```

#### LAMBDA EXPRESSION 


```{c}
[this, discreteGpuJob]  {
        if (discreteGpuJob->error()) {
            qCWarning(POWERDEVIL) << "org.kde.powerdevil.discretegpuhelper.hasdualgpu failed";
            qCDebug(POWERDEVIL) << discreteGpuJob->errorText();
            return;
        }
        m_hasDualGpu = discreteGpuJob->data()["hasdualgpu"].toBool();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QVariant &value) {
        // When animating to zero, it emits a value change to 0 before starting the animation...
        if (m_anim.state() == QAbstractAnimation::Running) {
            writeBrightness(value.toInt());
        }
    }
```

#### AUTO 


```{c}
const auto stopThresholds = getThresholds(s_chargeStopThreshold);
```

#### AUTO 


```{c}
auto timeout = mobile ? 30000 : 120000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceName : services) {
                if (!serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2."))) {
                    continue;
                }

                if (serviceName.startsWith(QLatin1String("org.mpris.MediaPlayer2.kdeconnect.mpris_"))) {
                    // This is actually a player on another device exposed by KDE Connect
                    // We don't want to pause it
                    // See https://bugs.kde.org/show_bug.cgi?id=427209
                    continue;
                }

                qCDebug(POWERDEVIL) << "Pausing media player with service name" << serviceName;

                QDBusMessage pauseMsg = QDBusMessage::createMethodCall(serviceName,
                                                                       QStringLiteral("/org/mpris/MediaPlayer2"),
                                                                       QStringLiteral("org.mpris.MediaPlayer2.Player"),
                                                                       QStringLiteral("Pause"));
                QDBusConnection::sessionBus().asyncCall(pauseMsg);
            }
```

#### AUTO 


```{c}
auto call = m_powerProfilesInterface->HoldProfile(profile, reason, applicationId);
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                if (brightnessJob->error()) {
                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                    qCDebug(POWERDEVIL) << brightnessJob->errorText();
                    Q_EMIT brightnessSupportQueried(false);
                    return;
                }
                m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                brightnessMaxAction.setHelperId(HELPER_ID);
                KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                connect(brightnessMaxJob, &KJob::result, this,
                    [this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }

                                Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                            }
                        );
                        syspathJob->start();
                    }
                );
                brightnessMaxJob->start();
            }
```

#### AUTO 


```{c}
auto reply = ActionReply::HelperErrorReply();
```

#### AUTO 


```{c}
const auto cookies = m_holdMap.equal_range(name);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QString> reply = *watcher;
        if (!reply.isError()) {
            const QString &currentProfile = reply.value();
            if (currentProfile == QLatin1String("Battery")) {
                tabWidget->setCurrentIndex(1);
            } else if (currentProfile == QLatin1String("LowBattery")) {
                tabWidget->setCurrentIndex(2);
            }
        }
        watcher->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groupList) {
        // Don't delete activity-specific settings
        if (group != "Activities") {
            profilesConfig->deleteGroup(group);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : devices) {
            const Solid::Battery *b = qobject_cast<const Solid::Battery*>(device.asDeviceInterface(Solid::DeviceInterface::Battery));
            if (b->chargeState() == Solid::Battery::Charging || b->chargeState() == Solid::Battery::FullyCharged) {
                chargeStopThresholdMessage->animatedShow();
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }
                                Q_EMIT brightnessSupportQueried(true);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &interface : interfaces) {
        file.setFileName(BACKLIGHT_SYSFS_PATH + interface + "/type");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            continue;
        }

        buffer = file.readLine().trimmed();
        if (buffer == "firmware") {
            firmware.append(BACKLIGHT_SYSFS_PATH + interface);
        } else if (buffer == "platform") {
            platform.append(BACKLIGHT_SYSFS_PATH + interface);
        } else if (buffer == "raw") {
            QFile enabled(BACKLIGHT_SYSFS_PATH + interface + "/device/enabled");
            rawAll.append(interface);
            if (enabled.open(QIODevice::ReadOnly | QIODevice::Text) && enabled.readLine().trimmed() == "enabled") {
                // this backlight device is connected to a display, so append
                // it to rawEnabled list
                rawEnabled.append(interface);
            }
        } else {
            qCWarning(POWERDEVIL) << "Interface type not handled" << buffer;
        }

        file.close();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessMaxJob] {
                        if (brightnessMaxJob->error()) {
                            qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                            qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                        } else {
                            m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                        }

                        KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                        syspathAction.setHelperId(HELPER_ID);
                        KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                        connect(syspathJob, &KJob::result, this,
                            [this, syspathJob] {
                                if (syspathJob->error()) {
                                    qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                    qCDebug(POWERDEVIL) << syspathJob->errorText();
                                    Q_EMIT brightnessSupportQueried(false);
                                    return;
                                }
                                m_syspath = syspathJob->data()["syspath"].toString();
                                m_syspath = QFileInfo(m_syspath).readLink();

                                m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                if (!m_isLedBrightnessControl) {
                                    UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                    connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                }
                                Q_EMIT brightnessSupportQueried(true);
                            }
                        );
                        syspathJob->start();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        QDBusConnection::sessionBus().asyncCall(QDBusMessage::createMethodCall("org.freedesktop.ScreenSaver",
                                                                            "/ScreenSaver",
                                                                            "org.freedesktop.ScreenSaver",
                                                                            "Lock"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, brightnessJob]  {
                    if (brightnessJob->error()) {
                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightness failed";
                        qCDebug(POWERDEVIL) << brightnessJob->errorText();
                        Q_EMIT brightnessSupportQueried(false);
                        return;
                    }
                    m_cachedBrightnessMap.insert(Screen, brightnessJob->data()["brightness"].toFloat());

                    KAuth::Action brightnessMaxAction("org.kde.powerdevil.backlighthelper.brightnessmax");
                    brightnessMaxAction.setHelperId(HELPER_ID);
                    KAuth::ExecuteJob *brightnessMaxJob = brightnessMaxAction.execute();
                    connect(brightnessMaxJob, &KJob::result, this,
                        [this, brightnessMaxJob] {
                            if (brightnessMaxJob->error()) {
                                qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.brightnessmax failed";
                                qCDebug(POWERDEVIL) << brightnessMaxJob->errorText();
                            } else {
                                m_brightnessMax = brightnessMaxJob->data()["brightnessmax"].toInt();
                            }

                            KAuth::Action syspathAction("org.kde.powerdevil.backlighthelper.syspath");
                            syspathAction.setHelperId(HELPER_ID);
                            KAuth::ExecuteJob* syspathJob = syspathAction.execute();
                            connect(syspathJob, &KJob::result, this,
                                [this, syspathJob] {
                                    if (syspathJob->error()) {
                                        qCWarning(POWERDEVIL) << "org.kde.powerdevil.backlighthelper.syspath failed";
                                        qCDebug(POWERDEVIL) << syspathJob->errorText();
                                        Q_EMIT brightnessSupportQueried(false);
                                        return;
                                    }
                                    m_syspath = syspathJob->data()["syspath"].toString();
                                    m_syspath = QFileInfo(m_syspath).symLinkTarget();

                                    m_isLedBrightnessControl = m_syspath.contains(QLatin1String("/leds/"));
                                    if (!m_isLedBrightnessControl) {
                                        UdevQt::Client *client =  new UdevQt::Client(QStringList("backlight"), this);
                                        connect(client, SIGNAL(deviceChanged(UdevQt::Device)), SLOT(onDeviceChanged(UdevQt::Device)));
                                    }

                                    Q_EMIT brightnessSupportQueried(m_brightnessMax > 0);
                                }
                            );
                            syspathJob->start();
                        }
                    );
                    brightnessMaxJob->start();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        m_profileCombo->clear();
        m_profileCombo->addItem(i18n("Leave unchanged"));

        if (reply.isError()) {
            qWarning() << "Failed to query platform profile choices" << reply.error().message();
            return;
        }

        const QHash<QString, QString> profileNames = {
            {QStringLiteral("power-saver"), i18n("Power Save")},
            {QStringLiteral("balanced"), i18n("Balanced")},
            {QStringLiteral("performance"), i18n("Performance")},
        };

        const QStringList choices = reply.value();
        for (const QString &choice : choices) {
            m_profileCombo->addItem(profileNames.value(choice, choice), choice);
        }

        if (configGroup().isValid()) {
            const QString profile = configGroup().readEntry("profile", QString());
            m_profileCombo->setCurrentIndex(qMax(0, m_profileCombo->findData(profile)));
        }
    }
```

