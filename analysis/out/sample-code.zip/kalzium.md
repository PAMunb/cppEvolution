#### AUTO 


```{c}
auto header2 = new QListWidgetItem(i18n("Properties"));
```

#### AUTO 


```{c}
auto toolPluginFactories =
        manager->pluginFactories<Avogadro::QtGui::ToolPluginFactory>();
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *e : v) {
        if (e) {
            const QList<ChemicalDataObject> list = e->data();

            // Test: give me all data available
            for (const ChemicalDataObject &o : list) {
                QString unit = o.unitAsString();
                if (unit == QLatin1String("bo:noUnit")) {
                    unit = QLatin1String("");
                }
                qDebug() << "Name: " << o.type() << " " << o.valueAsString() << " " << unit;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Isotope *i : v) {
        if (i) {
            // X             if (i->nucleons() == 50 ) {
            // X                 qDebug() << "   Isotope of " << i->parentElementSymbol() << " with a mass of " << i->mass();
            // X                 qDebug() << "       Halflife: " << i->halflife() << i->halflifeUnit( );
            // X             }
            if (i->parentElementSymbol() == QLatin1String("Ti")) {
                qDebug() << "   Isotope of " << i->parentElementSymbol() << " with a mass of " << i->mass();
                qDebug() << "       Halflife: " << i->halflife() << i->halflifeUnit();
            }
        }
    }
```

#### AUTO 


```{c}
auto mol = new Avogadro::QtGui::Molecule(*tmpMol);
```

#### AUTO 


```{c}
auto toolPluginFactories = manager->pluginFactories<Avogadro::QtGui::ToolPluginFactory>();
```

#### AUTO 


```{c}
auto molecule = new Avogadro::QtGui::Molecule(tmpMol);
```

#### AUTO 


```{c}
auto kpor = new KPlotObject(Qt::red, KPlotObject::Lines);
```

#### AUTO 


```{c}
auto newsearch = new Search();
```

#### AUTO 


```{c}
auto mouseEvent = static_cast<QMouseEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (Isotope *i : ilist) {
            int x = elementNumber * m_itemSize;
            int y = (300 - i->nucleons()) * m_itemSize;

            if (m_mode == 0) {
                // One part to the side of the other
                int threshold = 60;
                if (elementNumber > threshold) {
                    y += 120 * m_itemSize;
                    x += 5 * m_itemSize;
                }
            } else if (m_mode == 1) {
                // Both parts continuous
            } else if (m_mode == 2) {
                // Horizontally
                y = (elist.count() - elementNumber) * m_itemSize;
                x = i->nucleons() * m_itemSize;
            } else if (m_mode == 3) {
                // Horizontally (shifted)
                y = (elist.count() - elementNumber) * m_itemSize;
                x = (i->nucleons() - elementNumber) * m_itemSize;
            }

            auto item = new IsotopeItem(i, x, y, m_itemSize, m_itemSize);
            m_isotopeGroup->addToGroup(item);
        }
```

#### AUTO 


```{c}
auto main = new QTreeWidgetItem();
```

#### AUTO 


```{c}
auto frame = new QWidget();
```

#### AUTO 


```{c}
auto LabelPixmap = new QLabel(this);
```

#### AUTO 


```{c}
auto searchWidget = new SearchWidget(pseTempWidget);
```

#### AUTO 


```{c}
auto browser = new QTextBrowser(frame);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &link) {
        // using the "path" part of a qurl as reference
        QString myurl = link.path().toLower();
        QTreeWidgetItemIterator it(this->d->m_glosstree);
        while (*it) {
            if ((*it)->type() == GlossaryTreeItemType && (*it)->text(0).toLower() == myurl) {
                // force the item to be selected
                this->d->m_glosstree->setCurrentItem(*it);
                // display its content
                Q_EMIT this->d->itemActivated((*it), 0);
                break;
            } else {
                ++it;
            }
        }
    }
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto ItemLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto menu = QMenu((QWidget *)sender());
```

#### AUTO 


```{c}
auto vs = new QSplitter(main);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &st : rSplit) {
            r << st.toInt();
        }
```

#### AUTO 


```{c}
auto entry = new ElementListEntry(element);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close);
```

#### RANGE FOR STATEMENT 


```{c}
for (peak *p : std::as_const(m_peaklist)) {
        if (value < p->wavelength) {
            value = p->wavelength;
        }
    }
```

#### AUTO 


```{c}
auto item = new IsotopeItem(i, x, y, m_itemSize, m_itemSize);
```

#### AUTO 


```{c}
auto mol = new Avogadro::Core::Molecule;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChemicalDataObject &o : std::as_const(dataList)) {
        if (o.type() == type) {
            return o.value();
        }
    }
```

#### AUTO 


```{c}
auto vLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto kpob = new KPlotObject(Qt::blue, KPlotObject::Lines);
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *e : std::as_const(m_elementList)) {
        if (e->dataAsVariant(ChemicalDataObject::symbol) == _name) {
            qCDebug(KALZIUM_LIBSCIENCE_LOG) << "Found element " << _name;
            return e;
        }
    }
```

#### AUTO 


```{c}
auto spectrumparser = new SpectrumParser();
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementCount *count : std::as_const(m_map)) {
        count->multiply(_factor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (peak *p : std::as_const(m_peaklist)) {
        if (p->wavelength >= min || p->wavelength <= max) {
            spec->addPeak(p);
        }
    }
```

#### AUTO 


```{c}
auto nextButton = new QPushButton(QIcon::fromTheme(nextButtonIconSource), i18nc("Next element", "Next"), this);
```

#### AUTO 


```{c}
auto frame = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (peak *p : std::as_const(m_peaklist)) {
        double newInt = p->intensity * 1000 / maxInt;

        p->intensity = (int)qRound(newInt);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChemicalDataObject &o : list) {
                QString unit = o.unitAsString();
                if (unit == QLatin1String("bo:noUnit")) {
                    unit = QLatin1String("");
                }
                qDebug() << "Name: " << o.type() << " " << o.valueAsString() << " " << unit;
            }
```

#### AUTO 


```{c}
auto LegendLabel = new QLabel(this);
```

#### AUTO 


```{c}
auto main = new QWidget(this);
```

#### AUTO 


```{c}
auto w_colors = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChemicalDataObject &o : dataList) {
        if (o.type() == type) {
            if (unit == KUnitConversion::NoUnit) {
                return o.value();
            }
            KUnitConversion::Value data(o.value().toDouble(), KUnitConversion::UnitId(o.unit()));
            return QVariant(data.convertTo(KUnitConversion::UnitId(unit)).number());
        }
    }
```

#### AUTO 


```{c}
auto kpog = new KPlotObject(Qt::green, KPlotObject::Lines);
```

#### AUTO 


```{c}
auto spec = new Spectrum();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &link){
        // using the "path" part of a qurl as reference
        QString myurl = link.path().toLower();
        QTreeWidgetItemIterator it(this->d->m_glosstree);
        while (*it) {
            if ((*it)->type() == GlossaryTreeItemType && (*it)->text(0).toLower() == myurl) {
                 // force the item to be selected
                 this->d->m_glosstree->setCurrentItem(*it);
                 // display its content
                 Q_EMIT this->d->itemActivated((*it), 0);
                 break;
            } else {
                ++it;
            }
         }
    }
```

#### AUTO 


```{c}
auto glosstreeitem = static_cast<GlossaryTreeItem *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementCount* c : std::as_const(m_map)) {
        Element* e = c->m_element;
        if (!list.contains(e)) {
            list << e;
        }
    }
```

#### AUTO 


```{c}
auto pseTempWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(pseTempWidget);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Help | QDialogButtonBox::Close);
```

#### AUTO 


```{c}
auto card2 = new IsotopeTableSettingsCard(this, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto card : std::as_const(m_cards)) {
        if (i != m_mode)
            card->setChecked(false);
        i++;
    }
```

#### AUTO 


```{c}
auto m_pModelTab = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Isotope *i : list) {
        isotope.setNum(i->mass());
        ui.isotope->addItem(isotope);
    }
```

#### AUTO 


```{c}
auto format = getFileReader(QFileInfo(filename).suffix());
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto titemo = new QTableWidgetItem;
```

#### AUTO 


```{c}
auto drag = new QDrag(event->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (peak *p : std::as_const(m_peaklist)) {
        if (p->intensity > maxInt) {
            maxInt = p->intensity;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &st : sSplit) {
            s << st.toInt();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementCount *c : std::as_const(m_map)) {
        if (c->element() == _element) {
            return c;
        }
    }
```

#### AUTO 


```{c}
auto layout = new QGridLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : std::as_const(sphrases)) {
        int number = 0;
        QString phrase(QLatin1String(""));
        QRegularExpressionMatch match = reg.match(p);

        if (match.hasMatch()) {
            const QString part1 = match.captured(2);
            const QString part2 = match.captured(3);

            phrase = part2;
            number = part1.toInt();
        }

        sphrases_map.insert(number, phrase);
    }
```

#### AUTO 


```{c}
auto tmpMol = IoWrapper::readMolecule(filename);
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *e : v) {
        if (e) {
            const QList<ChemicalDataObject> list = e->data();

            //Test: give me all data available
            for (const ChemicalDataObject &o : list) {
                QString unit = o.unitAsString();
                if (unit == QLatin1String("bo:noUnit")) {
                    unit = QLatin1String("");
                }
                qDebug() << "Name: " << o.type() << " " << o.valueAsString() << " " << unit;
            }
        }
    }
```

#### AUTO 


```{c}
auto modelLayout = new QVBoxLayout(m_pModelTab);
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
        if (m_radioButton->isChecked())
            emit checked(m_isotopeView->mode());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Isotope *iso : isotopes) {
        int num = iso->parentElementNumber();
        if (m_isotopes.contains(num)) {
            m_isotopes[num].append(iso);
        } else {
            QList<Isotope *> newlist;
            newlist.append(iso);
            m_isotopes.insert(num, newlist);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto card : m_cards)
    {
        if (i != m_mode)
            card->setChecked(false);
        i++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &link){
        // using the "path" part of a qurl as reference
        QString myurl = link.path().toLower();
        QTreeWidgetItemIterator it(this->d->m_glosstree);
        while (*it) {
            if ((*it)->type() == GlossaryTreeItemType && (*it)->text(0).toLower() == myurl) {
                 // force the item to be selected
                 this->d->m_glosstree->setCurrentItem(*it);
                 // display its content
                 emit this->d->itemActivated((*it), 0);
                 break;
            } else {
                ++it;
            }
         }
    }
```

#### AUTO 


```{c}
auto titem = new QTableWidgetItem;
```

#### AUTO 


```{c}
auto molecule = new Avogadro::QtGui::Molecule(*tmpMol);
```

#### AUTO 


```{c}
auto scene2 = static_cast<IsotopeScene *>(scene());
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (m_radioButton->isChecked())
            Q_EMIT checked(m_isotopeView->mode());
    }
```

#### AUTO 


```{c}
auto isoparser = new IsotopeParser();
```

#### AUTO 


```{c}
auto g = new Glossary(u);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(frame);
```

#### AUTO 


```{c}
auto parser = new ElementSaxParser();
```

#### AUTO 


```{c}
auto item = new GlossaryItem();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Help | QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
auto trans = new StateSwitchTransition(id);
```

#### AUTO 


```{c}
auto parser = new SpectrumParser();
```

#### RANGE FOR STATEMENT 


```{c}
for (Spectrum::peak *p : s->peaklist()) {
                qDebug() << "         Peak: " << p->wavelength;
            }
```

#### AUTO 


```{c}
auto statusBar = new QStatusBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *e : elist) {
        int elementNumber = e->dataAsVariant(ChemicalDataObject::atomicNumber).toInt();

        const QList<Isotope *> ilist = KalziumDataObject::instance()->isotopes(elementNumber);
        for (Isotope *i : ilist) {
            int x = elementNumber * m_itemSize;
            int y = (300 - i->nucleons()) * m_itemSize;

            if (m_mode == 0) {
                // One part to the side of the other
                int threshold = 60;
                if (elementNumber > threshold) {
                    y += 120 * m_itemSize;
                    x += 5 * m_itemSize;
                }
            } else if (m_mode == 1) {
                // Both parts continuous
            } else if (m_mode == 2) {
                // Horizontally
                y = (elist.count() - elementNumber) * m_itemSize;
                x = i->nucleons() * m_itemSize;
            } else if (m_mode == 3) {
                // Horizontally (shifted)
                y = (elist.count() - elementNumber) * m_itemSize;
                x = (i->nucleons() - elementNumber) * m_itemSize;
            }

            auto item = new IsotopeItem(i, x, y, m_itemSize, m_itemSize);
            m_isotopeGroup->addToGroup(item);
        }
    }
```

#### AUTO 


```{c}
auto card1 = new IsotopeTableSettingsCard(this, 1);
```

#### AUTO 


```{c}
auto parser = new IsotopeParser();
```

#### RANGE FOR STATEMENT 


```{c}
for (NumerationItem *item : std::as_const(m_numerationItemList)) {
        m_tableStatesList.at(tableIndex)->assignProperty(item, "pos", QPointF(hiddenPoint()));
    }
```

#### AUTO 


```{c}
auto card3 = new IsotopeTableSettingsCard(this, 3);
```

#### AUTO 


```{c}
auto w_gradients = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Isotope* i: v) {
        if (i) {
//X             if (i->nucleons() == 50 ) {
//X                 qDebug() << "   Isotope of " << i->parentElementSymbol() << " with a mass of " << i->mass();
//X                 qDebug() << "       Halflife: " << i->halflife() << i->halflifeUnit( );
//X             }
            if (i->parentElementSymbol() == QLatin1String("Ti")) {
                qDebug() << "   Isotope of " << i->parentElementSymbol() << " with a mass of " << i->mass();
                qDebug() << "       Halflife: " << i->halflife() << i->halflifeUnit( );
            }
        }
    }
```

#### AUTO 


```{c}
auto labelLenght = new QLabel(i18n("Length:"), this);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Spectrum::peak * p : s->peaklist()) {
                qDebug() << "         Peak: " << p->wavelength;
            }
```

#### AUTO 


```{c}
auto molecule_ptr = IoWrapper::readMolecule(filename);
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : r) {
            QString phrase("<b>" + QString::number(i) + " - ");
            phrase.append(rphrase(i) + "</b>");
            string.append(phrase + "<br>");
        }
```

#### AUTO 


```{c}
auto la = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto header1 = new QListWidgetItem(i18n("Elements"));
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementCount *c : std::as_const(_map.m_map)) {
        add(c->m_element, c->m_count);
    }
```

#### AUTO 


```{c}
auto m_pSpectrumTab = new QWidget(this);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(m_electronConf);
```

#### AUTO 


```{c}
auto tmpMol = IoWrapper::readMolecule(file);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Cancel | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
auto mainlay = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto user1Button = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (ElementCount *c : std::as_const(m_map)) {
        Element *e = c->m_element;
        if (!list.contains(e)) {
            list << e;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (peak *p : std::as_const(m_peaklist)) {
        if (value > p->wavelength) {
            value = p->wavelength;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (peak *p : std::as_const(m_peaklist)) {
        if (p->wavelength >= min || p->wavelength <= max) {
            list.append(p->wavelength);
        }
    }
```

#### AUTO 


```{c}
auto labelTemperature = new QLabel(i18n("Temperature:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Spectrum *s : v) {
        if (s) {
            qDebug() << "Element:  " << s->parentElementNumber();
            for (Spectrum::peak * p : s->peaklist()) {
                qDebug() << "         Peak: " << p->wavelength;
            }
        }
    }
```

#### AUTO 


```{c}
auto svgGen = new QSvgGenerator();
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto card
```

#### AUTO 


```{c}
auto card0 = new IsotopeTableSettingsCard(this, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (int unit : unitList) {
        unitString = KUnitConversion::Converter().unit(KUnitConversion::UnitId(unit)).description();
        unitString.append(" (");
        unitString.append(KUnitConversion::Converter().unit(KUnitConversion::UnitId(unit)).symbol());
        unitString.append(")");
        comboBox->addItem(unitString, unit);
    }
```

#### AUTO 


```{c}
auto labelEnergy = new QLabel(i18n("Energy:"), this);
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
auto mol = std::make_unique<Avogadro::Core::Molecule>();
```

#### AUTO 


```{c}
auto spectrumLayout = new QVBoxLayout(m_pSpectrumTab);
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(main);
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : s) {
            QString phrase("<b>" + QString::number(i) + " -  ");
            phrase.append(sphrase(i) + "</b>");
            string.append(phrase + "<br>");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChemicalDataObject &o : dataList) {
        if (o.type() == type) {
            if (unit == KUnitConversion::NoUnit) {
                return o.value();
            }
            KUnitConversion::Value data(o.value().toDouble(), KUnitConversion::UnitId(o.unit()));
            return {data.convertTo(KUnitConversion::UnitId(unit)).number()};
        }
    }
```

#### AUTO 


```{c}
auto mol = new Avogadro::QtGui::Molecule(temp);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : m_isotopeGroup->childItems()) {
        m_isotopeGroup->removeFromGroup(item);
        delete item;
    }
```

#### AUTO 


```{c}
auto w_calc = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : std::as_const(rphrases)) {
        int number = 0;
        QString phrase(QLatin1String(""));
        QRegularExpressionMatch match = reg.match(p);

        if (match.hasMatch()) {
            const QString part1 = match.captured(2);
            const QString part2 = match.captured(3);

            phrase = part2;
            number = part1.toInt();
        }

        rphrases_map.insert(number, phrase);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Spectrum *s : v) {
        if (s) {
            qDebug() << "Element:  " << s->parentElementNumber();
            for (Spectrum::peak *p : s->peaklist()) {
                qDebug() << "         Peak: " << p->wavelength;
            }
        }
    }
```

#### AUTO 


```{c}
auto prevButton = new QPushButton(QIcon::fromTheme(prevButtonIconSource), i18nc("Previous element", "Previous"), this);
```

