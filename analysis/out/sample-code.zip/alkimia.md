#### AUTO 


```{c}
auto result = m_eventLoop->exec(QEventLoop::ExcludeUserInputEvents);
```

#### AUTO 


```{c}
const auto& flag
```

#### AUTO 


```{c}
const auto s = denominator.get_str();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& flag : setFlags) {
        QCOMPARE(errors & flag, true);
    }
```

#### AUTO 


```{c}
const auto errorsCopy(errors);
```

#### AUTO 


```{c}
auto tmpFileName = QUrl::fromLocalFile(tmpFile->fileName());
```

#### AUTO 


```{c}
const auto resources = QStandardPaths::locateAll(QStandardPaths::DataLocation, filename);
```

#### AUTO 


```{c}
auto tmpFile = new QTemporaryFile;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& flag : set) {
        errors |= flag;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& flag : resetFlags) {
        QCOMPARE(errors & flag, false);
    }
```

#### AUTO 


```{c}
const auto flag = *it;
```

