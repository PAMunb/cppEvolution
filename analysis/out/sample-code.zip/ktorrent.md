#### RANGE FOR STATEMENT 


```{c}
for (const net::Port &p : pl)
        model->undoForward(p, job);
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area : qAsConst(pages))
        area->page->updateSettings();
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](const QPoint & point) {
        QModelIndex index = m_tracker_list->indexAt(point);
        if (index.isValid()) {
            m_ContextMenu->exec(m_tracker_list->viewport()->mapToGlobal(point));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots))
        slot->setTimerDuration(timerDuration);
```

#### LAMBDA EXPRESSION 


```{c}
[&](auto &target, const auto &source, int column) {
        if (fabs(target - source) > 0.001) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &i : qAsConst(queue)) {
        bt::TorrentInterface *tc = i.tc;
        if (tc->getDisplayName().contains(text, Qt::CaseInsensitive)) {
            endResetModel();
            return index(idx, 0);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShutdownRule& r : qAsConst(rules))
            {
                items += QStringLiteral("- ") + r.toolTip();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Range& r : qAsConst(seasons)) {
            if (season >= r.start && season <= r.end) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(*qman)) {
        if (visible(tc)) {
            Item item = {tc, 0};
            queue.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl)
        out << s << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(filters))
        enc.write(f->filterID().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
        Script *s = model->scriptForIndex(idx);
        if (s)
            new KRun(QUrl::fromLocalFile(s->scriptFile()), 0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(filters))
        names << f->filterName();
```

#### RANGE FOR STATEMENT 


```{c}
for (Item &i : item->children)
        i.row = row_index++;
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(freeDownloadingSlots))
        slot->setTimerDuration(timerDuration);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
            {
                Qt::CheckState s = n->checkState(tc);
                if (s == Qt::PartiallyChecked)
                    return s;
                else if (s == Qt::Checked)
                    found_checked = true;
                else
                    found_unchecked = true;

                if (found_checked && found_unchecked)
                    return Qt::PartiallyChecked;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::ItemPtr& item : feedItems)
            feed_items_id.insert(item->id());
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                    QDBusPendingReply<void> reply = *callWatcher;
                    if (reply.isValid()) {
                        sleep_suppression_cookie = 0;
                        Out(SYS_GEN | LOG_DEBUG) << "Stopped suppressing sleep" << endl;
                    } else
                        Out(SYS_GEN | LOG_IMPORTANT) << "Failed to stop suppressing sleep" << endl;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents)) {
        if (item->tc == ti) {
            view->scrollTo(index(idx, 0));
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : missing)
        {
            QListWidgetItem* lwi = new QListWidgetItem(m_file_list);
            lwi->setText(s);
            lwi->setIcon(QIcon::fromTheme(mimeDatabase.mimeTypeForFile(s).iconName()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area : qAsConst(pages))
        area->page->loadSettings();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchEngine* se : qAsConst(engines)) {
        if (se->engineDir() == user_dir)
            return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                QDBusPendingReply<void> reply = *callWatcher;
                if (reply.isValid()) {
                    screensaver_cookie = 0;
                    Out(SYS_MPL | LOG_NOTICE) << "Screensaver uninhibited" << endl;
                }
                else
                    Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit screensaver" << endl;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](auto &target, const auto &source, int column){
            if (fabs(target - source) > 0.001) {
                to_update.append(model->index(row, column));
                target = source;
                ret |= (sort_column == column);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewListener *vl : qAsConst(listeners))
        vl->currentTorrentChanged(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : items) {
        out << s << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* i : *qman)
        {
            torrentAdded(i);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* w : qAsConst(searches))
        {
            enc.beginDict();
            enc.write("TEXT", w->getSearchText().toUtf8());
            enc.write("URL", w->getCurrentUrl().toDisplayString().toUtf8());
            enc.write("SBTEXT", w->getSearchBarText().toUtf8());
            enc.write("ENGINE", (bt::Uint32)w->getSearchBarEngine());
            enc.end();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KParts::Part* part: parts)
            {
                if (part->domDocument().documentElement().attribute(QStringLiteral("name")) == p->parentPart())
                {
                    part->removeChildClient(p);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *gi : gis) {
            if (gi->zValue() == 3) {
                clearSelection();
                gi->setSelected(true);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        if (a->data().value<QObject *>() == act) {
            activity_switching_group->removeAction(a);
            a->deleteLater();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        bt::TrackerInterface *trk = selectedTracker();
        if (trk)
            QApplication::clipboard()->setText(trk->trackerStatusString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SeasonEpisodeItem& item: se)
            {
                enc.write((bt::Uint32)item.season);
                enc.write((bt::Uint32)item.episode);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchEngine* se : qAsConst(to_remove))
        {
            bt::Touch(se->engineDir() + QStringLiteral("removed"));
            engines.removeAll(se);
            delete se;
        }
```

#### AUTO 


```{c}
auto pendingReply2 = powerManagement.Inhibit(QStringLiteral("ktorrent"), msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (Syndication::ItemPtr item : items)
            {
                // Skip already loaded items
                if (loaded.contains(item->id()))
                    continue;

                if (needToDownload(item, f))
                {
                    Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                    downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots))
        magnetQueue.at(slot->getMagnetIndex())->update();
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* s : sel) {
        QMap<QGraphicsItem*, ScheduleItem*>::iterator i = item_map.find(s);
        if (i != item_map.end())
            selection.append(i.value());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem& f : qAsConst(files))
        out << f.first.path() << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* feed : qAsConst(feeds)) {
        if (feed->usingFilter(f))
            feed->runFilters();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area : qAsConst(pages)) {
        if (area->page == page) {
            found = area;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                tc->setMaxSeedTime(0.0f);
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(filters))
            f->save(enc);
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(freeDownloadingSlots))
        delete slot;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        if (tc && !tc->getJobQueue()->runningJobs()) {
            const TorrentStats& s = tc->getStats();
            bool data_to = false;
            if (!s.completed) {
                QString msg = i18n("The torrent <b>%1</b> has not finished downloading, "
                                   "do you want to delete the incomplete data, too?", tc->getDisplayName());
                int ret = KMessageBox::questionYesNoCancel(
                              this,
                              msg,
                              i18n("Remove Download"),
                              KGuiItem(i18n("Delete Data")),
                              KGuiItem(i18n("Keep Data")),
                              KStandardGuiItem::cancel());
                if (ret == KMessageBox::Cancel)
                    return;
                else if (ret == KMessageBox::Yes)
                    data_to = true;
            }
            core->remove(tc, data_to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(to_remove)) {
        if (!s->packageDirectory().isEmpty())
            bt::Delete(s->packageDirectory(), true);
        scripts.removeAll(s);
        s->stop();
        s->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(to_remove))
        {
            feed_list->filterRemoved(f);
            filter_list->removeFilter(f);
            delete f;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
            bt::TorrentFileInterface *tfi = model->indexToFile(proxy_model->mapToSource(idx));
            if (!tfi)
                continue;

            if (tfi->getFirstChunk() < from)
                from = tfi->getFirstChunk();
            if (tfi->getLastChunk() > to)
                to = tfi->getLastChunk();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item & i : qAsConst(queue))
            i.tc->setPriority(idx--);
```

#### AUTO 


```{c}
const auto update_if_differs = [&](auto &target, const auto &source, int column) {
        if (target != source) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Item &i : children) {
        QModelIndex ret = i.findGroup(g, model->index(row, 0, idx));
        row++;
        if (ret.isValid())
            return ret;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int r : qAsConst(dragged_rows))
        {
            r -= nr;
            removeRow(r);
            nr++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
        {
            if (!model->setData(idx, Qt::Checked, Qt::CheckStateRole))
                Out(SYS_SCR | LOG_DEBUG) << "setData failed" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : to_update)
                QAbstractItemView::update(idx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i : idx) {
        bt::TorrentInterface* tc = torrentFromIndex(i);
        if (tc)
            tlist.append(tc);
    }
```

#### AUTO 


```{c}
const auto rul = (tc->getRunningTimeUL() >= tc->getRunningTimeDL()
                      ? tc->getRunningTimeUL() - tc->getRunningTimeDL()
                      : 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *item : qAsConst(torrents))
            if (item->highlight)
                item->highlight = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& r: qAsConst(re))
        {
            items.append(r.pattern());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(queue)) {
        Out(SYS_GEN | LOG_DEBUG) << "Item " << idx << ": " << item.tc->getDisplayName() << " " << item.tc->getPriority() << endl;
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
        Filter *f = filter_list->filterForIndex(idx);
        if (f)
            to_remove.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : queue)
        {
            bt::TorrentInterface* tc = i.tc;
            if (!tc->getStats().running)
            {
                if (i.stalled_time != -1)
                {
                    i.stalled_time = -1;
                    emit dataChanged(createIndex(r, 3), createIndex(r, 3));
                }
            }
            else
            {
                Int64 stalled_time = 0;
                if (tc->getStats().completed)
                    stalled_time = (now - tc->getStats().last_upload_activity_time) / 1000;
                else
                    stalled_time = (now - tc->getStats().last_download_activity_time) / 1000;

                if (i.stalled_time != stalled_time)
                {
                    i.stalled_time = stalled_time;
                    emit dataChanged(createIndex(r, 3), createIndex(r, 3));
                }
            }
            r++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tab &tab : qAsConst(tabs)) {
        if (tab.action == action) {
            view->setGroup(tab.group);
            view->restoreState(tab.view_settings);
            current_tab = idx;
            edit_group_policy->setEnabled(!tab.group->isStandardGroup());
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children)) {
            n->fillChunks();
            chunks.orBitSet(n->chunks);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
        {
            tc->setPriority(prio--);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents)) {
        if (item->visible(group, filter_string))
            tlist.append(item->tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Range &r : qAsConst(episodes)) {
            if (episode >= r.start && episode <= r.end) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : urlStrings) {
        QUrl url(s);
        if (url.isValid() && (url.scheme() == QLatin1String("http")
                              || url.scheme() == QLatin1String("https")
                              || url.scheme() == QLatin1String("udp"))) {
            trackers->insertItem(s);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::ItemPtr& item : feedItems)
        feed_items_id.insert(item->id());
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) { QDBusPendingReply<quint32> reply = *callWatcher; if (reply.isValid()) { screensaver_cookie = reply.value(); Out(SYS_MPL | LOG_NOTICE) << "PowerManagement inhibited (cookie " << powermanagement_cookie << ")" << endl; } else Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel)
        rows.append(idx.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions) {
        g.writeEntry(QLatin1String("Priority_") + a->objectName(), (int)a->priority());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& child: qAsConst(children))
        {
            child.expandedGroups(gview, groups, idx.child(row, 0));
            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        if (tc->getStats().multi_file_torrent)
            new KRun(QUrl::fromLocalFile(tc->getStats().output_path), 0, true);
        else
            new KRun(QUrl::fromLocalFile(tc->getDataDir()), 0, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s : qAsConst(searches)) {
        if (s->getCurrentUrl() == QUrl(QStringLiteral("about:ktorrent"))) {
            s->search(text, engine);
            tabs->setCurrentWidget(s);
            return;
        }
    }
```

#### AUTO 


```{c}
auto i = expanded_state_map.constFind(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(files))
        {
            order.insert(begin_row, file);
            begin_row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &file : files) {
        core->load(file, QString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget, &parser](const QStringList &arguments, const QString &workingDirectory) {
            parser.parse(arguments);
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString &filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
        {
            if (i != item && (i->conflicts(*item) || item->conflicts(*i)))
                return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
        stop(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
        const TorrentStats &s = tc->getStats();
        if (s.completed && tc->overMaxRatio()) {
            names.append(s.torrent_name);
            tmp.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &module : pluginsMetaData)
        {
            KPluginInfo pi(module);
            pi.setConfig(KSharedConfig::openConfig()->group(pi.pluginName()));
            pi.load();

            plugins << pi;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QDBusPendingCallWatcher * callWatcher) {
                QDBusPendingReply<quint32> reply = *callWatcher;
                if (reply.isValid()) {
                    sleep_suppression_cookie = reply.value();
                    Out(SYS_GEN | LOG_DEBUG) << "Suppressing sleep" << endl;
                } else
                    Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : positionalArguments)
            {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MediaFileRef& f: qAsConst(files))
            play_list->removeFile(f);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& group : groups) {
        addTab(gman->findByPath(group));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
        const TorrentStats& s = tc->getStats();
        if (s.running)
            continue;

        if (tc->getJobQueue()->runningJobs())
            continue;

        if (enabled())
            tc->setAllowedToStart(true);
        else
            startSafely(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel))
        group->removeTorrent(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (QModelIndex index : indexes)
        {
            if (index.isValid() && index.column() == 0)
            {
                urls << QUrl::fromLocalFile(files.at(index.row()).first.path());
                dragged_rows.append(index.row());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* t : qAsConst(trackers)) {
        if (t->update())
            Q_EMIT dataChanged(index(idx, 1), index(idx, 5));
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
        const TorrentStats &s = tc->getStats();
        if (s.running)
            continue;

        if (tc->getJobQueue()->runningJobs())
            continue;

        if (enabled())
            tc->setAllowedToStart(true);
        else
            startSafely(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(freeDownloadingSlots))
        delete slot;
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem *i : qAsConst(items)) {
        if (i != item && (i->conflicts(*item) || item->conflicts(*i)))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idx_list)
        {
            if (!mman->isStopped(idx.row()))
                stop->setEnabled(true);
            else
                start->setEnabled(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface * tor : qAsConst(*qman))
        {
            if (isMember(tor))
            {
                total++;
                if (tor->getStats().running)
                    running++;
            }
        }
```

#### AUTO 


```{c}
const auto positionalArguments = parser.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : qAsConst(actions))
        {
            if (a != act)
                a->setChecked(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port& p : pl)
            model->undoForward(p, job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(filters))
        if (f->filterName() == name)
            return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo))
        {
            const TorrentStats& s = tc->getStats();
            if (s.running)
                continue;

            if (tc->getJobQueue()->runningJobs())
                continue;

            if (enabled())
                tc->setAllowedToStart(true);
            else
                startSafely(tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items)) {
        if (item->conflicts(*i))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(*qman))
        {
            connect(tc, &bt::TorrentInterface::statusChanged, this, &QueueManagerModel::onTorrentStatusChanged);

            if (visible(tc))
            {
                Item item = {tc, 0};
                queue.append(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& u : qAsConst(trs))
                {
                    enc.write(u.toEncoded());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(order))
        {
            // skip file if it is complete
            if (std::fabs(100.0f - tor->getTorrentFile(file).getDownloadPercentage()) < 0.01)
                continue;

            // skip excluded or only seed files
            if (tor->getTorrentFile(file).getPriority() < LAST_PRIORITY)
                continue;

            // we have found the incomplete file
            return file;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* t : qAsConst(suspended_torrents))
            {
                info_hash_list << t->getInfoHash().toString();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indices)
        {
            bt::PeerInterface* peer = model->indexToPeer(pm->mapToSource(idx));
            if (peer)
                peer->kill();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->getStats().multi_file_torrent)
            new KRun(QUrl::fromLocalFile(tc->getStats().output_path), 0, true);
        else
            new KRun(QUrl::fromLocalFile(tc->getDataDir()), 0, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsLineItem *line : qAsConst(lines))
        line->setPen(pen);
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem* s: sel)
        {
            int r = m_tracker_list->row(s);
            if (r > 0)
            {
                m_tracker_list->insertItem(r - 1, m_tracker_list->takeItem(r));
                m_tracker_list->setCurrentRow(r - 1);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int val) {
        m_proxy->setFiltered(!val);
        setupModels();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::ItemPtr& item : items)
            {
                // Skip already loaded items
                if (loaded.contains(item->id()))
                    continue;

                if (needToDownload(item, f))
                {
                    Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                    downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* gi : gis)
        {
            if (gi->zValue() == 3)
            {
                itemDoubleClicked(gi);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *i : qAsConst(items)) {
        if (i->peer == peer) {
            found = true;
            break;
        }
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QString idir = data_dir + s;
        if (!idir.endsWith(DirSeparator()))
            idir.append(DirSeparator());

        Out(SYS_GEN | LOG_NOTICE) << "Loading feed from directory " << idir << endl;
        Feed *feed = nullptr;
        try {
            feed = new Feed(idir);
            connect(feed, &Feed::downloadLink, activity, &SyndicationActivity::downloadLink);
            feed->load(filter_list);
            addFeed(feed);

        } catch (...) {
            delete feed;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &tracker: qAsConst(trs))
                {
                    enc.beginList();
                    enc.write(tracker.toDisplayString().toUtf8());
                    enc.end();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tor : *qman)
        {
            torrentAdded(tor);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Syndication::ItemPtr item : feedItems)
            feed_items_id.insert(item->id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idx_list) {
            if (const MagnetDownloader* md = mman->getMagnetDownloader(idx.row())) {
                sl.append(md->magnetLink().toString());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i : idx) {
        Filter* f = available->filterForIndex(i);
        if (f)
            to_add.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sd : subdirs) {
            loadEngine(QDir::cleanPath(dir) + QLatin1Char('/') + sd + QLatin1Char('/'), data_dir + sd + QLatin1Char('/'), removed_to);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
            QDBusPendingReply<void> reply = *callWatcher;
            if (reply.isValid()) {
                powermanagement_cookie = 0;
                Out(SYS_MPL | LOG_NOTICE) << "Power management uninhibited" << endl;
            } else
                Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit power management" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : qAsConst(default_groups))
            addTab(gman->findByPath(group));
```

#### RANGE FOR STATEMENT 


```{c}
for (const MediaFileRef &f : qAsConst(files))
        play_list->removeFile(f);
```

#### RANGE FOR STATEMENT 


```{c}
for (Group* g : qAsConst(defaults))
            groups.insert(g->groupName(), g);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urls)) {
        bt::TrackerInterface* trk = tc.data()->getTrackersList()->addTracker(url, true);
        if (!trk)
            dupes.append(url);
        else
            tl.append(trk);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
        {
            if (between(now.date().dayOfWeek(), i->start_day, i->end_day) && i->start > now.time())
            {
                if (!item || i->start < item->start)
                    item = i;
            }
        }
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<kt::Plugin>(data).plugin;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(stalled))
        Out(SYS_GEN | LOG_NOTICE) << "The torrent " << tc->getStats().torrent_name << " has stalled longer than " << min_stall_time << " minutes, decreasing its priority" << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* t : qAsConst(suspended_torrents)) {
            info_hash_list << t->getInfoHash().toString();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        bt::TrackerInterface* trk = selectedTracker();
        if (trk)
            QApplication::clipboard()->setText(trk->trackerStatusString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : entries) {
        const KArchiveEntry *entry = dir->entry(e);
        if (entry && entry->isDirectory()) {
            addScriptFromArchiveDirectory((const KArchiveDirectory *)entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(links)) {
        if (u.path().endsWith(QStringLiteral(".torrent")) || u.path().endsWith(QStringLiteral(".TORRENT"))) {
            Out(SYS_SYN | LOG_DEBUG) << "Trying torrent link: " << u.toDisplayString() << endl;
            link_url = u;
            KIO::StoredTransferJob *j = KIO::storedGet(u, KIO::Reload, verbose ? KIO::DefaultFlags : KIO::HideProgressInfo);
            connect(j, &KIO::StoredTransferJob::result, this, &LinkDownloader::torrentDownloadFinished);
            links.removeAll(u);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(default_opensearch_urls))
        {
            Out(SYS_SRC | LOG_DEBUG) << "Setting up default engine " << u.toDisplayString() << endl;
            QString dir = data_dir + u.host() + QLatin1Char('/');
            if (!bt::Exists(dir))
            {
                OpenSearchDownloadJob* j = new OpenSearchDownloadJob(u, dir, m_proxy);
                connect(j, &OpenSearchDownloadJob::result, this, &SearchEngineList::openSearchDownloadJobFinished);
                j->start();
            }
            else
            {
                loadEngine(dir, dir, true);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
        const TorrentStats &s = tc->getStats();
        if (s.completed && tc->overMaxSeedTime()) {
            names.append(s.torrent_name);
            tmp.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : idx) {
        bt::TorrentInterface *tc = torrentFromIndex(i);
        if (tc)
            tlist.append(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& f: qAsConst(folders))
        {
            m_folders->addItem(new QListWidgetItem(QIcon::fromTheme(QStringLiteral("folder")), f));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl_d) {
        FNode *d = addChild(root, s, true);
        next_dir.setPath(dir.path() + QLatin1String("/") + s);
        fillFromDir(d, next_dir);
    }
```

#### AUTO 


```{c}
const auto &match
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
            bt::TorrentFileInterface *tfi = model->indexToFile(proxy_model->mapToSource(idx));
            if (!tfi)
                continue;

            moves.insert(tfi, dir);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* trk : qAsConst(tracker_list))
            {
                trackers.append(new Item(trk));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(dir_list))
        {
            const QStringList subdirs = QDir(dir).entryList(QDir::Dirs | QDir::NoDotAndDotDot);
            for (const QString& sd : subdirs)
            {
                loadEngine(QDir::cleanPath(dir) + QLatin1Char('/') + sd + QLatin1Char('/'), data_dir + sd + QLatin1Char('/'), removed_to);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(scripts)) {
        if (r.contains(s->scriptFile()) && !s->running()) {
            s->execute();
            QModelIndex i = index(idx, 0);
            Q_EMIT dataChanged(i, i);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dir_list)
        {
            QDir d(dir);
            const QStringList subdirs = d.entryList(QDir::Dirs);
            for (const QString& sdir : subdirs)
            {
                if (sdir != QStringLiteral("..") && sdir != QStringLiteral("."))
                {
                    QString absolute_path = d.absoluteFilePath(sdir);
                    Script* s = loadScriptDir(absolute_path);
                    if (s)
                    {
                        // Scripts in the home directory can be deleted
                        s->setRemoveable(absolute_path.startsWith(kt::DataDir()));
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : idx) {
        Feed *f = feedForIndex(i);
        if (f)
            to_remove.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : qAsConst(dir_list)) {
        const QStringList subdirs = QDir(dir).entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QString& sd : subdirs) {
            loadEngine(QDir::cleanPath(dir) + QLatin1Char('/') + sd + QLatin1Char('/'), data_dir + sd + QLatin1Char('/'), removed_to);
        }
    }
```

#### AUTO 


```{c}
auto pendingReply = screensaver.Inhibit(QStringLiteral("ktorrent"), msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tor : qAsConst(downloads))
        {
            if (tor->getInfoHash() == ih)
            {
                TrackersList* ta = tor->getTrackersList();
                const int cnt = ta->getTrackers().count();
                ta->merge(trk);
                if (cnt < ta->getTrackers().count()) {
                    // new trackers were added
                    // do "Manual Announce" for this torrent
                    if (tor->getStats().running) {
                        tor->updateTracker();
                    }
                }
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
        if (!model->setData(idx, Qt::Checked, Qt::CheckStateRole))
            Out(SYS_SCR | LOG_DEBUG) << "setData failed" << endl;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                QDBusPendingReply<quint32> reply = *callWatcher;
                if (reply.isValid()) {
                    screensaver_cookie = reply.value();
                    Out(SYS_MPL | LOG_NOTICE) << "Screensaver inhibited (cookie " << screensaver_cookie << ")" << endl;
                }
                else
                    Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress screensaver" << endl;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area: qAsConst(pages))
        {
            if (area->page == page)
            {
                found = area;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs)
        tab.action->setText(tab.group->groupName() + QStringLiteral(" %1/%2").arg(tab.group->runningTorrents()).arg(tab.group->totalTorrents()));
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area: qAsConst(pages))
            area->page->loadDefaults();
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(filters))
        {
            f->startMatching();
            const QList<Syndication::ItemPtr> items = feed->items();
            for (const Syndication::ItemPtr& item : items)
            {
                // Skip already loaded items
                if (loaded.contains(item->id()))
                    continue;

                if (needToDownload(item, f))
                {
                    Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                    downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indexes)
        {
            if (!idx.isValid() || idx.row() < 0 || idx.row() >= items.count())
                continue;

            MediaFile::Ptr p = items.at(idx.row());
            urls << QUrl::fromLocalFile(p->path());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
        if (!index.isValid())
            continue;

        const bt::TorrentInterface* ti = torrentFromIndex(index);
        if (ti) {
            QString hash = ti->getInfoHash().toString();
            if (!hashes.contains(hash)) {
                hashes.append(hash);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file: files)
        {
            // look for the desktop file
            if (!file.endsWith(QStringLiteral(".desktop")) && !file.endsWith(QStringLiteral(".DESKTOP")))
                continue;

            // check for duplicate packages
            QString dest_dir = kt::DataDir() + QStringLiteral("scripts/") + dir->name() + QLatin1Char('/');
            for (Script* s: qAsConst(scripts))
            {
                if (s->packageDirectory() == dest_dir)
                    throw bt::Error(i18n("There is already a script package named %1 installed.", dir->name()));
            }

            // extract to the scripts dir
            dir->copyTo(dest_dir, true);
            if (!addScriptFromDesktopFile(dest_dir, file))
                throw bt::Error(i18n("Failed to load script from archive. There is something wrong with the desktop file."));

            return;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : queue) {
        bt::TorrentInterface* tc = i.tc;
        if (!tc->getStats().running) {
            if (i.stalled_time != -1) {
                i.stalled_time = -1;
                Q_EMIT dataChanged(createIndex(r, 3), createIndex(r, 3));
            }
        } else {
            Int64 stalled_time = 0;
            if (tc->getStats().completed)
                stalled_time = (now - tc->getStats().last_upload_activity_time) / 1000;
            else
                stalled_time = (now - tc->getStats().last_download_activity_time) / 1000;

            if (i.stalled_time != stalled_time) {
                i.stalled_time = stalled_time;
                Q_EMIT dataChanged(createIndex(r, 3), createIndex(r, 3));
            }
        }
        r++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        // set default values for current pref page only
        kcfg_okTorrentColor->setColor(QColor(40, 205, 40));
        kcfg_stalledTorrentColor->setColor(QColor(255, 174, 0));
        kcfg_errorTorrentColor->setColor(QColor(Qt::red));

        kcfg_highlightTorrentNameByTrackerStatus->setChecked(true);
        kcfg_okTrackerConnectionColor->setColor(QColor(40, 205, 40));
        kcfg_warningsTrackerConnectionColor->setColor(QColor(255, 80, 0));
        kcfg_timeoutTrackerConnectionColor->setColor(QColor(0, 170, 110));
        kcfg_noTrackerConnectionColor->setColor(QColor(Qt::red));

        kcfg_goodShareRatioColor->setColor(QColor(40, 205, 40));
        kcfg_lowShareRatioColor->setColor(QColor(Qt::red));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl) {
        QString idir = data_dir + s;
        if (!idir.endsWith(DirSeparator()))
            idir.append(DirSeparator());

        Out(SYS_GEN | LOG_NOTICE) << "Loading " << idir << endl;
        loadExistingTorrent(idir);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* otc : qAsConst(downloads)) {
            int p = otc->getPriority();
            otc->setPriority(p + 1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QModelIndex index = treeView->currentIndex();
        new KRun(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(index))), 0, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(usedDownloadingSlots))
        slot->setTimerDuration(timerDuration);
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QSet<QString>* filter) {
        if (filter) {
            m_proxy->setFilter(filter);
            setupModels();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(queue))
        {
            if (tc == i.tc)
            {
                found = true;
                break;
            }
            r++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(order)) {
        TorrentFileInterface& tf = tor->getTorrentFile(file);
        if (tf.getPriority() < LAST_PRIORITY)
            continue;

        if (file == next_file) {
            tf.setPriority(FIRST_PRIORITY);
            high_found = true;
        } else if (!normal_found && high_found) {
            // the file after the high prio file is set to normal
            // so that when the high prio file is finished the selector
            // will select it before we can set a new high prio file
            tf.setPriority(NORMAL_PRIORITY);
            normal_found = true;
            current_normal_priority_file = file;
        } else
            tf.setPriority(LAST_PRIORITY);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
        QAction *a = m->addAction(url);
        a->setData(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
            g->addTorrent(tc, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SeasonEpisodeItem &item : se) {
            enc.write((bt::Uint32)item.season);
            enc.write((bt::Uint32)item.episode);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(*qman)) {
        connect(tc, &bt::TorrentInterface::statusChanged, this, &QueueManagerModel::onTorrentStatusChanged);

        if (visible(tc)) {
            Item item = {tc, 0};
            queue.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QItemSelectionRange &r : sel)
        doRange(r, command);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl)
            out << s << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sd : subdirs)
            {
                loadEngine(QDir::cleanPath(dir) + QLatin1Char('/') + sd + QLatin1Char('/'), data_dir + sd + QLatin1Char('/'), removed_to);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->getStats().multi_file_torrent)
            new KRun(QUrl::fromLocalFile(tc->getStats().output_path), nullptr, true);
        else
            new KRun(QUrl::fromLocalFile(tc->getDataDir()), nullptr, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& subdir : dirs) {
            if (subdir != QStringLiteral(".") && subdir != QStringLiteral("..") && subdir != loaded_localized) {
                QCoreApplication::postEvent(this, new RecursiveScanEvent(QUrl::fromLocalFile(d.absoluteFilePath(subdir))));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children)
        {
            Out(SYS_GEN | LOG_DEBUG) << indent << "child " << i.row << endl;
            i.dump();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget *s : qAsConst(searches)) {
        if (s->getCurrentUrl() == QUrl(QStringLiteral("about:ktorrent"))) {
            s->search(text, engine);
            tabs->setCurrentWidget(s);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs) {
        if (tab.action->isChecked()) {
            tab.group = group;
            QString name = group->groupName() +  QStringLiteral(" %1/%2").arg(group->runningTorrents()).arg(group->totalTorrents());
            tab.action->setText(name);
            tab.action->setIcon(group->groupIcon());
            edit_group_policy->setEnabled(!group->isStandardGroup());
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerItem& c : qAsConst(conds)) {
        if (c.tc == tc) {
            removeRow(idx);
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface& iface : iface_list) {
        QIcon icon = QIcon::fromTheme(QStringLiteral("network-wired"));
#if 0 //FIXME KF5
        for (const Solid::Device& device : netlist) {
            const Solid::NetworkInterface* netdev = device.as<Solid::NetworkInterface>();
            if (netdev->ifaceName() == iface.name() && netdev->isWireless()) {
                icon = QIcon::fromTheme(QStringLiteral("network-wireless"));
                break;
            }

        }
#endif

        combo_networkInterface->addItem(icon, iface.humanReadableName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : qAsConst(se_formats)) {
        QRegExp exp(format, Qt::CaseInsensitive);
        int pos = exp.indexIn(title);
        if (pos > -1) {
            QString s = exp.cap(1); // Season
            QString e = exp.cap(2); // Episode
            bool ok = false;
            season = s.toInt(&ok);
            if (!ok)
                continue;

            episode = e.toInt(&ok);
            if (!ok)
                continue;

            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node* sibling : qAsConst(n->parent->children)) {
            if (sibling != n && sibling->name == name)
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        if (tc->readyForPreview() && !tc->getStats().multi_file_torrent) {
            new KRun(QUrl::fromLocalFile(tc->getStats().output_path), 0, true);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                    QDBusPendingReply<quint32> reply = *callWatcher;
                    if (reply.isValid()) {
                        sleep_suppression_cookie = reply.value();
                        Out(SYS_GEN | LOG_DEBUG) << "Suppressing sleep" << endl;
                    }
                    else
                        Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area: qAsConst(pages))
            area->page->loadSettings();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selected) {
        Script *s = model->scriptForIndex(idx);
        if (s) {
            if (s->running())
                num_running++;
            else
                num_not_running++;
            if (s->removable())
                num_removable++;
        } else
            num_not_running++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children)) {
            Qt::CheckState s = n->checkState(tc);
            if (s == Qt::PartiallyChecked)
                return s;
            else if (s == Qt::Checked)
                found_checked = true;
            else
                found_unchecked = true;

            if (found_checked && found_unchecked)
                return Qt::PartiallyChecked;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s: qAsConst(searches))
        {
            if (w == s)
            {
                s->home();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel))
            tc->setPriority(prio + sel.count() - idx++);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : qAsConst(pluginsMetaData)) {
        if (loaded.contains(idx) && !isPluginEnabled(data)) {
            // unload it
            unload(data, idx);
        } else if (!loaded.contains(idx) && isPluginEnabled(data)) {
            // load it
            load(data, idx);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* t : trackers)
            ret << t->trackerURL().toDisplayString();
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem *i : qAsConst(items)) {
        if (between(now.date().dayOfWeek(), i->start_day, i->end_day) && i->start > now.time()) {
            if (!item || i->start < item->start)
                item = i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
        {
            if (!n->file)
            {
                if (BDictNode* d = dict->getDict(n->name.toUtf8()))
                    n->loadExpandedState(pm->index(idx, 0, index), pm, tv, d);
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
        {
            if (item->visible(group, filter_string))
                tlist.append(item->tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs)
            tab.action->setText(tab.group->groupName() + QStringLiteral(" %1/%2").arg(tab.group->runningTorrents()).arg(tab.group->totalTorrents()));
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(downloads)) {
        const TorrentStats &s = tc->getStats();
        if (s.running || tc->getJobQueue()->runningJobs() || !s.autostart)
            continue;

        todo.append(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MediaFileRef& f : qAsConst(files))
        play_list->removeFile(f);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerItem &c : qAsConst(conds)) {
        if (c.checked)
            rules->addRule(action, SPECIFIC_TORRENT, c.trigger, c.tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp: qAsConst(exclusion_patterns))
        {
            QRegExp tmp = exp;
            tmp.setCaseSensitivity(exclusion_case_sensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
            tmp.setPatternSyntax(exclusion_reg_exp ? QRegExp::RegExp : QRegExp::Wildcard);
            if (exclusion_all_must_match)
            {
                if (!match(item->title(), tmp))
                {
                    found_match = false;
                    break;
                }
                else
                    found_match = true;
            }
            else if (match(item->title(), tmp))
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children)
        {
            i.expandGroups(gview, groups, model->index(row, 0, idx));
            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* gi: gis)
            {
                if (gi->zValue() == 3)
                {
                    clearSelection();
                    gi->setSelected(true);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        openUrl(QUrl::fromLocalFile(tc->getTorDir()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(tmp))
                todo.removeAll(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(usedDownloadingSlots)) {
            slot->stopTimer();
            slot->setTimerDuration(timerDuration);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : items)
        {
            out << s << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
            const WebSeedInterface *ws = curr_tc.data()->getWebSeed(proxy_model->mapToSource(idx).row());
            if (ws && ws->isUserCreated()) {
                m_remove->setEnabled(true);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget *s : qAsConst(searches)) {
        if (w == s) {
            s->home();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : qAsConst(queue)) {
        Out(SYS_GEN | LOG_DEBUG) << "Item " << idx << ": " << item.tc->getDisplayName() << " " << item.tc->getPriority() << endl;
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface *trk : qAsConst(tracker_list))
        trackers.append(new Item(trk));
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(filters)) {
        f->startMatching();
        const QList<Syndication::ItemPtr> items = feed->items();
        for (const Syndication::ItemPtr &item : items) {
            // Skip already loaded items
            if (loaded.contains(item->id()))
                continue;

            if (needToDownload(item, f)) {
                Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem& f : qAsConst(files))
            out << f.first.path() << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
                s += n->bytesToDownload(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(to_remove)) {
        available->addFilter(f);
        active->removeFilter(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
                tc->setPriority(prio + sel.count() - idx++);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& e: entries)
        {
            const KArchiveEntry* entry = dir->entry(e);
            if (entry && entry->isDirectory())
            {
                addScriptFromArchiveDirectory((const KArchiveDirectory*)entry);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Range& r: qAsConst(seasons))
            {
                if (season >= r.start && season <= r.end)
                {
                    found = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : qAsConst(tmp)) {
        if (scan_folders.find(folder))
            continue;

        if (QDir(folder).exists()) {
            // only add folder when it exists
            ScanFolder *sf = new ScanFolder(this, QUrl::fromLocalFile(folder), recursive);
            scan_folders.insert(folder, sf);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
        {
            removeTorrent(item->tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &loadedItem: qAsConst(loaded))
        {
            if (!feed_items_id.contains(loadedItem))
            {
                itemsToRemove.push_front(loadedItem);
                need_to_save = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
        if (!idx.isValid() || idx.row() < 0 || idx.row() >= items.count())
            continue;

        MediaFile::Ptr p = items.at(idx.row());
        urls << QUrl::fromLocalFile(p->path());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url: urls)
        {
            QAction* a = m->addAction(url);
            a->setData(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes)
        {
            setData(idx, newpriority, Qt::UserRole);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *s : sel) {
        QMap<QGraphicsItem *, ScheduleItem *>::iterator i = item_map.find(s);
        if (i != item_map.end())
            selection.append(i.value());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl)
            out << s << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *t : qAsConst(suspended_torrents)) {
            info_hash_list << t->getInfoHash().toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex & i : sel)
        {
            if (proxy_model->hasChildren(i))
                expandCollapseTree(i, expand);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Extender* ext : qAsConst(extenders)) {
        ext->hide();
        ext->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        new KRun(QUrl::fromLocalFile(tc->getTorDir()), 0, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::UPnPRouter *r : qAsConst(routers))
            r->forward(port);
```

#### AUTO 


```{c}
auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget *s : qAsConst(searches)) {
        if (s == tabs->currentWidget()) {
            tabs->removeTab(tabs->currentIndex());
            searches.removeAll(s);
            delete s;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots))
        delete slot;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (url.isValid()) {
                if (silently || Settings::openMultipleTorrentsSilently())
                    loadSilently(url);
                else
                    load(url);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *i : *qman) {
        torrents.append(new Item(i));
        num_visible++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid()) {
            files.append(order.at(index.row()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        QAction* a = m->addAction(url);
        a->setData(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& u: qAsConst(links))
        {
            if (u.path().endsWith(QStringLiteral(".torrent")) || u.path().endsWith(QStringLiteral(".TORRENT")))
            {
                Out(SYS_SYN | LOG_DEBUG) << "Trying torrent link: " << u.toDisplayString() << endl;
                link_url = u;
                KIO::StoredTransferJob* j = KIO::storedGet(u, KIO::Reload, verbose ? KIO::DefaultFlags : KIO::HideProgressInfo);
                connect(j, &KIO::StoredTransferJob::result, this, &LinkDownloader::torrentDownloadFinished);
                links.removeAll(u);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *f : qAsConst(to_remove)) {
        bt::Delete(f->directory(), true);
        feeds.removeAll(f);
        delete f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemToRemove : qAsConst(itemsToRemove))
        loaded.remove(itemToRemove);
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
            QDBusPendingReply<void> reply = *callWatcher;
            if (reply.isValid()) {
                screensaver_cookie = 0;
                Out(SYS_MPL | LOG_NOTICE) << "Screensaver uninhibited" << endl;
            } else
                Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit screensaver" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MediaFile::Ptr mf : qAsConst(items)) {
        if (mf->torrent() == tc) {
            if (start == -1) {
                // start of the range
                start = row;
                cnt = 1;
            } else
                cnt++; // Still in the middle of the media files of this torrent
        } else if (start != -1) {
            // We have found the end
            break;
        }

        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                tc->setMaxShareRatio(0.0f);
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* tc : qAsConst(downloads)) {
        const TorrentStats& s = tc->getStats();
        if (s.running || (tc->isAllowedToStart() && !s.stopped_by_error && !tc->getJobQueue()->runningJobs())) {
            if (s.completed) {
                if (s.running || (!tc->overMaxRatio() && !tc->overMaxSeedTime()))
                    seed_queue.append(tc);
            } else
                download_queue.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: selected)
        {
            Script* s = model->scriptForIndex(idx);
            if (s)
            {
                if (s->running())
                    num_running++;
                else
                    num_not_running++;
                if (s->removeable())
                    num_removeable++;
            }
            else
                num_not_running++;
        }
```

#### AUTO 


```{c}
auto &i
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        new KRun(QUrl::fromLocalFile(tc->getTorDir()), 0, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->readyForPreview() && !tc->getStats().multi_file_torrent) {
            openUrl(QUrl::fromLocalFile(tc->getStats().output_path));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
            const TorrentStats &s = tc->getStats();
            if (!s.completed && !tc->checkDiskSpace(false)) {
                names.append(s.torrent_name);
                tmp.append(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : to_update)
            QAbstractItemView::update(idx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        PlayListItem item = qMakePair(collection->find(url.toLocalFile()), (TagLib::FileRef *)nullptr);
        files.insert(row, item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children) {
        i.expandGroups(gview, groups, model->index(row, 0, idx));
        row++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        QModelIndex index = treeView->currentIndex();
        new KRun(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(index))), 0, true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget, &parser](const QStringList & arguments, const QString & workingDirectory) {
            if (!arguments.isEmpty()) {
                parser.parse(arguments);
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5,62,0)
                widget.setAttribute(Qt::WA_NativeWindow, true);
                KStartupInfo::setNewStartupId(widget.windowHandle(), KStartupInfo::startupId());
#else
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
#endif
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString& filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
            size += n->fileSize(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s: interpreters)
            Out(SYS_SCR | LOG_DEBUG) << s << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions)
        {
            if (a->data().value<QObject*>() == act || act == 0)
            {
                a->setChecked(true);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* t: qAsConst(trackers))
        {
            if (t->update())
                Q_EMIT dataChanged(index(idx, 1), index(idx, 5));
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(usedDownloadingSlots)) {
            if (!slot->isTimerActived()) {
                slot->setTimerDuration(timerDuration);
                slot->startTimer();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            // set default values for current pref page only
            kcfg_okTorrentColor->setColor(QColor(40, 205, 40));
            kcfg_stalledTorrentColor->setColor(QColor(255, 174, 0));
            kcfg_errorTorrentColor->setColor(QColor(Qt::red));

            kcfg_highlightTorrentNameByTrackerStatus->setChecked(true);
            kcfg_okTrackerConnectionColor->setColor(QColor(40, 205, 40));
            kcfg_warningsTrackerConnectionColor->setColor(QColor(255, 80, 0));
            kcfg_timeoutTrackerConnectionColor->setColor(QColor(0, 170, 110));
            kcfg_noTrackerConnectionColor->setColor(QColor(Qt::red));

            kcfg_goodShareRatioColor->setColor(QColor(40, 205, 40));
            kcfg_lowShareRatioColor->setColor(QColor(Qt::red));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
        {
            enc.beginDict();
            enc.write(QByteArrayLiteral("start_day")); enc.write((Uint32)i->start_day);
            enc.write(QByteArrayLiteral("end_day")); enc.write((Uint32)i->end_day);
            enc.write(QByteArrayLiteral("start")); enc.write(i->start.toString().toLatin1());
            enc.write(QByteArrayLiteral("end")); enc.write(i->end.toString().toLatin1());
            enc.write(QByteArrayLiteral("upload_limit")); enc.write(i->upload_limit);
            enc.write(QByteArrayLiteral("download_limit")); enc.write(i->download_limit);
            enc.write(QByteArrayLiteral("suspended")); enc.write((Uint32)(i->suspended ? 1 : 0));
            if (i->set_conn_limits)
            {
                enc.write(QByteArrayLiteral("conn_limits"));
                enc.beginDict();
                enc.write(QByteArrayLiteral("global")); enc.write((Uint32)i->global_conn_limit);
                enc.write(QByteArrayLiteral("per_torrent")); enc.write((Uint32)i->torrent_conn_limit);
                enc.end();
            }
            enc.write(QByteArrayLiteral("screensaver_limits"), (Uint32)i->screensaver_limits);
            enc.write(QByteArrayLiteral("ss_upload_limit"), i->ss_upload_limit);
            enc.write(QByteArrayLiteral("ss_download_limit"), i->ss_download_limit);
            enc.end();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : to_update)
            QAbstractItemView::update(idx);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
                n->initPercentage(tc, havechunks);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        const TorrentStats& s = tc->getStats();

        if (tc->readyForPreview() && !s.multi_file_torrent)
            en_prev = true;

        if (tc->getJobQueue()->runningJobs())
            continue;

        en_remove = true;
        if (!s.running) {
            if (qm_enabled) {
                // Queued torrents can be stopped, and not started
                if (s.queued)
                    en_stop = true;
                else
                    en_start = true;
            } else {
                en_start = true;
            }
        } else {
            en_stop = true;
            if (tc->announceAllowed())
                en_announce = true;

            if (!s.paused)
                en_pause = true;
            else
                en_start = true;
        }

        if (!s.priv_torrent) {
            en_add_peer = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp: qAsConst(exclusion_patterns))
            enc.write(exp.pattern().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (int mib : qAsConst(encodings)) {
        m_encoding->addItem(QString::fromUtf8(QTextCodec::codecForMib(mib)->name()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children) {
        Out(SYS_GEN | LOG_DEBUG) << indent << "child " << i.row << endl;
        i.dump();
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(SearchPluginSettings::customBrowser() + QStringLiteral(" ") + KShell::quoteArg(url.toDisplayString()), nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node *sibling : qAsConst(n->parent->children)) {
            if (sibling != n && sibling->name == name)
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(to_remove)) {
        feed_list->filterRemoved(f);
        filter_list->removeFilter(f);
        delete f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& s : download_location_history)
        if (s.endsWith(QLatin1String("//"))) s.chop(1);
```

#### RANGE FOR STATEMENT 


```{c}
for (Group* g : qAsConst(defaults))
        groups.insert(g->groupName(), g);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        btnScanFolder->click();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &m : sel) {
            to_del.append(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(m))));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indices) {
        Script *s = scriptForIndex(idx);
        if (s && s->removable())
            to_remove << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* tc : qAsConst(downloads))
            {
                const TorrentStats& s = tc->getStats();
                if (s.running)
                {
                    suspended_torrents.insert(tc);
                    stopSafely(tc);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* t : qAsConst(downloads))
        {
            if (t == tc)
                continue;

            if (t->getStats().multi_file_torrent)
            {
                for (bt::Uint32 i = 0; i < t->getNumFiles(); i++)
                {
                    if (files.contains(t->getTorrentFile(i).getPathOnDisk()))
                    {
                        conflicting.append(t->getDisplayName());
                        break;
                    }
                }
            }
            else
            {
                if (files.contains(t->getStats().output_path))
                    conflicting.append(t->getDisplayName());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        g->addTorrent(tc, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Range& r : qAsConst(episodes)) {
            if (episode >= r.start && episode <= r.end) {
                found = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int val){
            m_proxy->setFiltered(!val);
            setupModels();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : scripts) {
        Out(SYS_SCR | LOG_DEBUG) << "Loading script " << s << endl;
        if (bt::Exists(s)) {
            try {
                model->addScript(s);
            } catch (bt::Error& err) {
                getGUI()->errorMsg(err.toString());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget, &parser](const QStringList &arguments, const QString &workingDirectory)
        {
            if (!arguments.isEmpty())
            {
                parser.parse(arguments);
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5,62,0)
                widget.setAttribute(Qt::WA_NativeWindow, true);
                KStartupInfo::setNewStartupId(widget.windowHandle(), KStartupInfo::startupId());
#else
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
#endif
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString& filePath : positionalArguments)
            {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port& p : pl)
            {
                if (p.forward)
                    r->undoForward(p);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
                op(i);
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QDBusPendingCallWatcher * callWatcher) {
            QDBusPendingReply<quint32> reply = *callWatcher;
            if (reply.isValid()) {
                screensaver_cookie = reply.value();
                Out(SYS_MPL | LOG_NOTICE) << "Screensaver inhibited (cookie " << screensaver_cookie << ")" << endl;
            } else Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress screensaver" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QItemSelectionRange& r : sel)
        doRange(r, command);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem &item : qAsConst(files)) {
        if (item.first == file) {
            found = true;
            break;
        }
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MagnetDownloader *md : qAsConst(magnetQueue))
        writeEncoderInfo(enc, md);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo))
        {
            tc->pause();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& subdir: dirs)
            {
                if (subdir != QStringLiteral(".") && subdir != QStringLiteral("..") && subdir != loaded_localized)
                {
                    QCoreApplication::postEvent(this, new RecursiveScanEvent(QUrl::fromLocalFile(d.absoluteFilePath(subdir))));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idx_list) {
        if (const MagnetDownloader* md = mman->getMagnetDownloader(idx.row())) {
            sl.append(md->magnetLink().toString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget *s : qAsConst(searches)) {
        if (w == s) {
            s->search();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl_d) {
        FNode* d = addChild(root, s, true);
        next_dir.setPath(dir.path() + QLatin1String("/") + s);
        fillFromDir(d, next_dir);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children)) {
        if (!n->file) {
            enc->write(n->name.toUtf8());
            enc->beginDict();
            n->saveExpandedState(pm->index(idx, 0, index), pm, tv, enc);
            enc->end();
        }
        idx++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget] {
            if (!widget.isVisible()) {
                widget.show();
            } else {
                KWindowSystem::updateStartupId(widget.windowHandle());
                KWindowSystem::activateWindow(widget.windowHandle());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions) {
        if (a->data().value<QObject*>() == act) {
            activity_switching_group->removeAction(a);
            a->deleteLater();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FlagDBSource& s : qAsConst(sources)) {
        const QString& path = s.getPath(c);
        //e.g.: /usr/share/locale/l10n/ru/flag.png
        if (QFile::exists(path) && img.load(path)) {
            if (img.width() != preferredWidth || img.height() != preferredHeight) {
                const QImage& imgScaled = img.scaled(preferredWidth, preferredHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                if (!imgScaled.isNull()) {
                    pixmap = QPixmap::fromImage(imgScaled);
                    break;
                } else if (img.width() <= preferredWidth || img.height() <= preferredHeight) {
                    pixmap = QPixmap::fromImage(img);
                    break;
                }
            } else {
                pixmap = QPixmap::fromImage(img);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs)
        {
            groups << tab.group->groupPath();
            if (idx == current_tab)
                tab.view_settings = view->header()->saveState();
            g.writeEntry(QStringLiteral("tab%1_settings").arg(idx++), tab.view_settings);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
        tc->pause();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i : idx)
        {
            bt::TorrentInterface* tc = torrentFromIndex(i);
            if (tc)
                tlist.append(tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* gi : gis) {
        if (gi->zValue() == 3) {
            itemDoubleClicked(gi);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children)) {
        if (!n->file) {
            if (BDictNode *d = dict->getDict(n->name.toUtf8()))
                n->loadExpandedState(pm->index(idx, 0, index), pm, tv, d);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->readyForPreview() && !tc->getStats().multi_file_torrent) {
            new KRun(QUrl::fromLocalFile(tc->getStats().output_path), nullptr, true);
        }
    }
```

#### AUTO 


```{c}
auto *job =
                new KIO::CommandLauncherJob(SearchPluginSettings::customBrowser() + QStringLiteral(" ") + KShell::quoteArg(url.toDisplayString()), nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* i : *qman) {
        torrents.append(new Item(i));
        num_visible++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& t : trackers) {
        if (t.isEmpty())
            continue;

        QUrl url(t.trimmed());
        if (!url.isValid() || (url.scheme() != QLatin1String("udp")
                               && url.scheme() != QLatin1String("http")
                               && url.scheme() != QLatin1String("https")))
            invalid.append(t);
        else {
            if (!tracker_hints.contains(url.toDisplayString()))
                tracker_hints.append(url.toDisplayString());
            urls.append(url);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls)
        {
            PlayListItem item = qMakePair(collection->find(url.toLocalFile()), (TagLib::FileRef*)0);
            files.insert(row, item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area : qAsConst(pages))
        if (area->page->customWidgetsChanged())
            return true;
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                        QDBusPendingReply<void> reply = *callWatcher;
                        if (reply.isValid()) {
                            sleep_suppression_cookie = 0;
                            Out(SYS_GEN | LOG_DEBUG) << "Stopped suppressing sleep" << endl;
                        }
                        else
                            Out(SYS_GEN | LOG_IMPORTANT) << "Failed to stop suppressing sleep" << endl;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
        Syndication::ItemPtr ptr = model->itemForIndex(idx);
        if (ptr)
            feed->downloadItem(ptr, QString(), QString(), QString(), false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QPoint & point) {
            QModelIndex index = m_tracker_list->indexAt(point);
            if (index.isValid()) {
                m_ContextMenu->exec(m_tracker_list->viewport()->mapToGlobal(point));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MagnetDownloader* md : qAsConst(stoppedList))
        writeEncoderInfo(enc, md);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indices) {
        bt::PeerInterface *peer = model->indexToPeer(pm->mapToSource(idx));
        if (peer) {
            aman.banPeer(peer->getStats().ip_address);
            peer->kill();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem* s : sel) {
        int r = m_tracker_list->row(s);
        if (r > 0) {
            m_tracker_list->insertItem(r - 1, m_tracker_list->takeItem(r));
            m_tracker_list->setCurrentRow(r - 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                QDBusPendingReply<quint32> reply = *callWatcher;
                if (reply.isValid()) {
                    screensaver_cookie = reply.value();
                    Out(SYS_MPL | LOG_NOTICE) << "PowerManagement inhibited (cookie " << powermanagement_cookie << ")" << endl;
                }
                else
                    Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s : qAsConst(scripts)) {
        if (s->running())
            ret << s->scriptFile();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
        {
            if (item->conflicts(*i))
                return false;
        }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: idx_list)
        {
            const WebSeedInterface* ws = tc->getWebSeed(proxy_model->mapToSource(idx).row());
            if (ws && ws->isUserCreated())
            {
                if (!tc->removeWebSeed(ws->getUrl()))
                    KMessageBox::error(this, i18n("Cannot remove webseed %1, it is part of the torrent.", ws->getUrl().toDisplayString()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, slot](bool){ (this->*slot)(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children)) {
            if (n->name == subdir) {
                n->insert(path.mid(p + 1), file, num_chunks);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(to_remove))
        {
            available->addFilter(f);
            active->removeFilter(f);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[core](const QString &) {
        core->applySettings();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node *sibling : qAsConst(n->parent->children)) {
                if (sibling != n && sibling->name == name)
                    return false;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab &tab : tabs) {
        groups << tab.group->groupPath();
        if (idx == current_tab)
            tab.view_settings = view->header()->saveState();
        g.writeEntry(QStringLiteral("tab%1_settings").arg(idx++), tab.view_settings);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* i : *qman)
            torrentAdded(i);
```

#### AUTO 


```{c}
auto it = db.constFind(c);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idx_list) {
        const WebSeedInterface* ws = tc->getWebSeed(proxy_model->mapToSource(idx).row());
        if (ws && ws->isUserCreated()) {
            if (!tc->removeWebSeed(ws->getUrl()))
                KMessageBox::error(this, i18n("Cannot remove webseed %1, it is part of the torrent.", ws->getUrl().toDisplayString()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i: idx)
        {
            Filter* f = active->filterForIndex(i);
            if (f)
                to_remove.append(f);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : queueCopy)
        {
            if (tc == i.tc)
            {
                queue.removeAt(r);
                removeRow(r);
                break;
            }
            r++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children)
        {
            QModelIndex ret = i.findGroup(g, model->index(row, 0, idx));
            row++;
            if (ret.isValid())
                return ret;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children)) {
            if (n->name == subdir) {
                n->insert(path.mid(p + 1), file, num_chunks);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : qAsConst(tmp)) {
        QTextCharFormat fm = output->currentCharFormat();
        output->append(line);
        output->setCurrentCharFormat(fm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IPBlock& block : qAsConst(input)) {
        dlg->progress(i, tot);
        target.write((char*) & block, sizeof(IPBlock));
        if (abort) {
            return;
        }
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
        {
            if (index.isValid() && index.column() == 0)
            {
                urls << QUrl::fromLocalFile(files.at(index.row()).first.path());
                dragged_rows.append(index.row());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(filters))
        f->save(enc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i : idx) {
        Filter* f = active->filterForIndex(i);
        if (f)
            to_remove.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s : qAsConst(scripts)) {
            if (s->packageDirectory() == dest_dir)
                throw bt::Error(i18n("There is already a script package named %1 installed.", dir->name()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port &p : pl) {
            if (p.forward)
                r->undoForward(p);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(default_opensearch_urls)) {
        Out(SYS_SRC | LOG_DEBUG) << "Setting up default engine " << u.toDisplayString() << endl;
        QString dir = data_dir + u.host() + QLatin1Char('/');
        if (!bt::Exists(dir)) {
            OpenSearchDownloadJob *j = new OpenSearchDownloadJob(u, dir, m_proxy);
            connect(j, &OpenSearchDownloadJob::result, this, &SearchEngineList::openSearchDownloadJobFinished);
            j->start();
        } else {
            loadEngine(dir, dir, true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tor : qAsConst(*qman)) {
        if (isMember(tor)) {
            total++;
            if (tor->getStats().running)
                running++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder : qAsConst(tmp)) {
        if (scan_folders.find(folder))
            continue;

        if (QDir(folder).exists()) {
            // only add folder when it exists
            ScanFolder* sf = new ScanFolder(this, QUrl::fromLocalFile(folder), recursive);
            scan_folders.insert(folder, sf);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
        setData(idx, newpriority, Qt::UserRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            g->addTorrent(tc, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                todo.removeAll(tc);
```

#### AUTO 


```{c}
auto handleCmdLine = [&widget, &parser](const QStringList &arguments, const QString &workingDirectory)
        {
            if (!arguments.isEmpty())
            {
                parser.parse(arguments);
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            Q_FOREACH (const QString& filePath, parser.positionalArguments())
            {
                QUrl url = QFile::exists(filePath)?QUrl::fromLocalFile(filePath):QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        a->setPriority((QAction::Priority)g.readEntry(QLatin1String("Priority_") + a->objectName(), (int)QAction::NormalPriority));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& format : qAsConst(se_formats)) {
        QRegExp exp(format, Qt::CaseInsensitive);
        int pos = exp.indexIn(title);
        if (pos > -1) {
            QString s = exp.cap(1); // Season
            QString e = exp.cap(2);  // Episode
            bool ok = false;
            season = s.toInt(&ok);
            if (!ok)
                continue;

            episode = e.toInt(&ok);
            if (!ok)
                continue;

            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& p : parts) {
        Range r = {0, 0};
        if (stringToRange(p, r))
            results.append(r);
        else
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children))
            n->initPercentage(tc, havechunks);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indices) {
        Script* s = scriptForIndex(idx);
        if (s && s->removable())
            to_remove << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes)
        {
            Node* n = (Node*)idx.internalPointer();
            if (!n)
                continue;

            setData(idx, newpriority, Qt::UserRole);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s: qAsConst(searches))
        {
            if (w == s)
            {
                s->search();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea *area : qAsConst(pages)) {
        if (area->page == page) {
            found = area;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *t : qAsConst(downloads)) {
            if (info_hash_list.contains(t->getInfoHash().toString()))
                suspended_torrents.insert(t);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsRectItem *rect : qAsConst(rects)) {
        rect->setPen(pen);
        rect->setBrush(brush);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* t : qAsConst(downloads)) {
            if (info_hash_list.contains(t->getInfoHash().toString()))
                suspended_torrents.insert(t);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indexes)
        {
            Node* n = (Node*)idx.internalPointer();
            if (n)
                setPriority(n, newpriority, true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QModelIndex index = treeView->currentIndex();
        new KRun(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(index))), nullptr, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& e : qAsConst(ip_list)) {
        if (e.start <= ip && ip <= e.end)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp : qAsConst(exclusion_patterns))
        enc.write(exp.pattern().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& group: groups)
        {
            addTab(gman->findByPath(group));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(filters))
        if (f->filterID() == id)
            return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Range& r: qAsConst(episodes))
            {
                if (episode >= r.start && episode <= r.end)
                {
                    found = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* os : qAsConst(scripts)) {
        if (s->scriptFile() == os->scriptFile()) {
            delete s;
            return 0;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& format : qAsConst(se_formats)) {
            QRegExp exp(format, Qt::CaseInsensitive);
            int pos = exp.indexIn(title);
            if (pos > -1) {
                QString s = exp.cap(1); // Season
                QString e = exp.cap(2);  // Episode
                bool ok = false;
                season = s.toInt(&ok);
                if (!ok)
                    continue;

                episode = e.toInt(&ok);
                if (!ok)
                    continue;

                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port &p : pl) {
            if (p.forward)
                r->forward(p);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(order))
            out << file << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            if (tc->getStats().running)
                tc->updateTracker();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->getStats().multi_file_torrent)
            openUrl(QUrl::fromLocalFile(tc->getStats().output_path));
        else
            openUrl(QUrl::fromLocalFile(tc->getDataDir()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads)) {
        if (IsStalled(tc, now, min_stall_time)) {
            stalled.append(tc);
        } else {
            // decreasing makes only sense if there are QM torrents after the stalled ones
            can_decrease = stalled.count() > 0;
            newlist.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(tmp))
                tc->setMaxShareRatio(0.0f);
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(QUrl(link));
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
                tc->setAllowedToStart(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        if (file.endsWith(QStringLiteral(".desktop"))) {
            return model->addScriptFromDesktopFile(dir_path, file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : interpreters)
        Out(SYS_SCR | LOG_DEBUG) << s << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &exp : qAsConst(word_matches)) {
        QRegExp tmp = exp;
        tmp.setCaseSensitivity(case_sensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
        tmp.setPatternSyntax(use_regular_expressions ? QRegExp::RegExp : QRegExp::Wildcard);
        if (all_word_matches_must_match) {
            if (!match(item->title(), tmp))
                return false;
            else
                found_match = true;
        } else if (match(item->title(), tmp)) {
            found_match = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo))
        {
            const TorrentStats& s = tc->getStats();
            if (s.completed && tc->overMaxRatio())
            {
                names.append(s.torrent_name);
                tmp.append(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* i : qAsConst(items)) {
        if (i->changed()) {
            if (lowest == -1)
                lowest = idx;
            highest = idx;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s : qAsConst(searches)) {
        if (w == s) {
            s->search();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(downloads))
            tc->setAllowedToStart(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(to_add)) {
        active->addFilter(f);
        available->removeFilter(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QModelIndex &i : sel)
        i = proxy_model->mapToSource(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QString idir = data_dir + s;
        if (!idir.endsWith(DirSeparator()))
            idir.append(DirSeparator());

        Out(SYS_GEN | LOG_NOTICE) << "Loading feed from directory " << idir << endl;
        Feed *feed = 0;
        try {
            feed = new Feed(idir);
            connect(feed, &Feed::downloadLink, activity, &SyndicationActivity::downloadLink);
            feed->load(filter_list);
            addFeed(feed);

        } catch (...) {
            delete feed;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tor : *qman) {
        torrentAdded(tor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tab & tab : qAsConst(tabs)) {
        if (tab.action == action) {
            view->setGroup(tab.group);
            view->restoreState(tab.view_settings);
            current_tab = idx;
            edit_group_policy->setEnabled(!tab.group->isStandardGroup());
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& i: qAsConst(queue))
        {
            if (tc == i.tc)
            {
               found = true;
               break;
            }

            r++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::EnclosurePtr& e : encs)
        {
            if (e->type() == QStringLiteral("application/x-bittorrent") || e->url().endsWith(QStringLiteral(".torrent")))
                return e->url();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s: qAsConst(searches))
        {
            if (s == tabs->currentWidget())
            {
                tabs->removeTab(tabs->currentIndex());
                searches.removeAll(s);
                delete s;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            QModelIndex index = treeView->currentIndex();
            new KRun(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(index))), 0, true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(seed_queue)) {
        const TorrentStats &s = tc->getStats();
        if (num_running < max_seeds || max_seeds == 0) {
            if (!s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Starting: " << s.torrent_name << endl;
                if (startInternal(tc) == bt::START_OK)
                    num_running++;
            } else
                num_running++;
        } else {
            if (s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Stopping: " << s.torrent_name << endl;
                stopSafely(tc);
            }
            tc->setQueued(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(items))
        {
            if (item->cd == cd)
            {
                found = true;
                break;
            }
            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *f : qAsConst(feeds)) {
            if (f->feedUrl() == feed_url) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemToRemove: qAsConst(itemsToRemove))
            loaded.remove(itemToRemove);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl)
        {
            QString idir = data_dir + s;
            if (!idir.endsWith(DirSeparator()))
                idir.append(DirSeparator());

            Out(SYS_GEN | LOG_NOTICE) << "Loading feed from directory " << idir << endl;
            Feed* feed = 0;
            try
            {
                feed = new Feed(idir);
                connect(feed, &Feed::downloadLink, activity, &SyndicationActivity::downloadLink);
                feed->load(filter_list);
                addFeed(feed);

            }
            catch (...)
            {
                delete feed;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &module : qAsConst(pluginsMetaData))
        {
            KPluginInfo pi(module);
            pi.setConfig(KSharedConfig::openConfig()->group(pi.pluginName()));
            pi.load();

            plugins << pi;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &r : qAsConst(re)) {
        items.append(r.pattern());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indices)
        {
            Script* s = scriptForIndex(idx);
            if (s && s->removable())
                to_remove << s;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (core->checkMissingFiles(tc))
            tc->changeOutputDir(dir, bt::TorrentInterface::MOVE_FILES);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *i : sel) {
        folders.removeAll(i->text());
        delete i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MediaFile::Ptr mf : qAsConst(items)) {
        if (mf->path() == path)
            return index(idx, 0, QModelIndex());
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
        {
            if (item->tc == ti)
            {
                view->scrollTo(index(idx, 0));
                break;
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* trk : tracker_list) {
            trackers.append(new Item(trk));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes)
        files.append(play_list->fileForIndex(idx));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tab & tab : qAsConst(tabs))
        {
            if (tab.action == action)
            {
                view->setGroup(tab.group);
                view->restoreState(tab.view_settings);
                current_tab = idx;
                edit_group_policy->setEnabled(!tab.group->isStandardGroup());
                break;
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc && !tc->getJobQueue()->runningJobs()) {
            const TorrentStats &s = tc->getStats();
            bool data_to = false;
            if (!s.completed) {
                QString msg = i18n(
                    "The torrent <b>%1</b> has not finished downloading, "
                    "do you want to delete the incomplete data, too?",
                    tc->getDisplayName());
                int ret = KMessageBox::questionYesNoCancel(this,
                                                           msg,
                                                           i18n("Remove Download"),
                                                           KGuiItem(i18n("Delete Data")),
                                                           KGuiItem(i18n("Keep Data")),
                                                           KStandardGuiItem::cancel());
                if (ret == KMessageBox::Cancel)
                    return;
                else if (ret == KMessageBox::Yes)
                    data_to = true;
            }
            core->remove(tc, data_to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *item : qAsConst(torrents)) {
        if (item->tc == ti) {
            removeRow(idx);
            update(view->viewDelegate(), true);
            break;
        }
        idx++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) { QDBusPendingReply<void> reply = *callWatcher; if (reply.isValid()) { powermanagement_cookie = 0; Out(SYS_MPL | LOG_NOTICE) << "Power management uninhibited" << endl; } else Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit power management" << endl; }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(scripts))
        {
            if (r.contains(s->scriptFile()) && !s->running())
            {
                s->execute();
                QModelIndex i = index(idx, 0);
                Q_EMIT dataChanged(i, i);
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Extender *ext : qAsConst(extenders)) {
        ext->hide();
        ext->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KParts::Part *part : parts) {
            if (part->domDocument().documentElement().attribute(QStringLiteral("name")) == p->parentPart()) {
                part->insertChildClient(p);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp: qAsConst(word_matches))
            enc.write(exp.pattern().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes) {
        Node* n = (Node*)idx.internalPointer();
        if (!n)
            continue;

        setData(idx, newpriority, Qt::UserRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indices) {
        Script *s = model->scriptForIndex(idx);
        if (s && !s->packageDirectory().isEmpty())
            scripts_to_delete.append(s->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
            {
                g->addTorrent(tc, false);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
        {
            Script* s = model->scriptForIndex(idx);
            if (s)
                new KRun(QUrl::fromLocalFile(s->scriptFile()), 0);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
        Script *s = model->scriptForIndex(idx);
        if (s)
            new KRun(QUrl::fromLocalFile(s->scriptFile()), nullptr);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QModelIndex m = treeView->currentIndex();
        m = m_proxy->mapToSource(m);
        const QString fname = m_model->fileName(m);
        QGuiApplication::clipboard()->setText(fname);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sdir : subdirs) {
            if (sdir != QStringLiteral("..") && sdir != QStringLiteral(".")) {
                QString absolute_path = d.absoluteFilePath(sdir);
                Script* s = loadScriptDir(absolute_path);
                if (s) {
                    // Scripts in the home directory can be deleted
                    s->setRemovable(absolute_path.startsWith(kt::DataDir()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(downloads)) {
        tc->setPriority(prio--);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FlagDBSource &s : qAsConst(sources)) {
        const QString &path = s.getPath(c);
        // e.g.: /usr/share/locale/l10n/ru/flag.png
        if (QFile::exists(path) && img.load(path)) {
            if (img.width() != preferredWidth || img.height() != preferredHeight) {
                const QImage &imgScaled = img.scaled(preferredWidth, preferredHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                if (!imgScaled.isNull()) {
                    pixmap = QPixmap::fromImage(imgScaled);
                    break;
                } else if (img.width() <= preferredWidth || img.height() <= preferredHeight) {
                    pixmap = QPixmap::fromImage(img);
                    break;
                }
            } else {
                pixmap = QPixmap::fromImage(img);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* w : qAsConst(searches)) {
        enc.beginDict();
        enc.write("TEXT", w->getSearchText().toUtf8());
        enc.write("URL", w->getCurrentUrl().toDisplayString().toUtf8());
        enc.write("SBTEXT", w->getSearchBarText().toUtf8());
        enc.write("ENGINE", (bt::Uint32)w->getSearchBarEngine());
        enc.end();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(filters))
            if (f->filterID() == id)
                return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
            {
                if (n->name == subdir)
                {
                    n->insert(path.mid(p + 1), file, num_chunks);
                    return;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KParts::Part* part : parts) {
            if (part->domDocument().documentElement().attribute(QStringLiteral("name")) == p->parentPart()) {
                part->removeChildClient(p);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(download_queue)) {
        const TorrentStats& s = tc->getStats();

        if (num_running < max_downloads || max_downloads == 0) {
            if (!s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Starting: " << s.torrent_name << endl;
                if (startInternal(tc) == bt::START_OK)
                    num_running++;
            } else
                num_running++;
        } else {
            if (s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Stopping: " << s.torrent_name << endl;
                stopSafely(tc);
            }
            tc->setQueued(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::UPnPRouter* r : qAsConst(routers))
                r->undoForward(port, wjob);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children)
        {
            i.expandGroups(gview, groups, idx.child(row, 0));
            row++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QSet<QString>* filter){
            if (filter) {
                m_proxy->setFilter(filter);
                setupModels();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &i : qAsConst(queue)) {
        if (tc == i.tc) {
            found = true;
            break;
        }

        r++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions)
        {
            a->setPriority( (QAction::Priority) g.readEntry(QLatin1String("Priority_") + a->objectName(), (int)QAction::NormalPriority) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : scripts) {
        Out(SYS_SCR | LOG_DEBUG) << "Loading script " << s << endl;
        if (bt::Exists(s)) {
            try {
                model->addScript(s);
            } catch (bt::Error &err) {
                getGUI()->errorMsg(err.toString());
            }
        }
    }
```

#### AUTO 


```{c}
auto handleCmdLine = [&widget, &parser](const QStringList &arguments, const QString &workingDirectory) {
            if (!arguments.isEmpty()) {
                parser.parse(arguments);
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5, 62, 0)
                widget.setAttribute(Qt::WA_NativeWindow, true);
                KStartupInfo::setNewStartupId(widget.windowHandle(), KStartupInfo::startupId());
#else
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
#endif
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString &filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(seed_queue))
        {
            const TorrentStats& s = tc->getStats();
            if (num_running < max_seeds || max_seeds == 0)
            {
                if (!s.running)
                {
                    Out(SYS_GEN | LOG_DEBUG) << "QM Starting: " << s.torrent_name << endl;
                    if (startInternal(tc) == bt::START_OK)
                        num_running++;
                }
                else
                    num_running++;
            }
            else
            {
                if (s.running)
                {
                    Out(SYS_GEN | LOG_DEBUG) << "QM Stopping: " << s.torrent_name << endl;
                    stopSafely(tc);
                }
                tc->setQueued(true);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        btnScanFolder->setText(i18n("Scan"));
        progressBar->setVisible(false);
        m_thread->deleteLater();
        m_thread = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
        stop(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : qAsConst(loaded))
        enc.write(id.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port& p : pl)
        model->undoForward(p, job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes) {
        setData(idx, newpriority, Qt::UserRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(usedDownloadingSlots))
        magnetQueue.at(slot->getMagnetIndex())->update();
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area: qAsConst(pages))
            area->page->updateSettings();
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(seed_queue)) {
        const TorrentStats& s = tc->getStats();
        if (num_running < max_seeds || max_seeds == 0) {
            if (!s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Starting: " << s.torrent_name << endl;
                if (startInternal(tc) == bt::START_OK)
                    num_running++;
            } else
                num_running++;
        } else {
            if (s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Stopping: " << s.torrent_name << endl;
                stopSafely(tc);
            }
            tc->setQueued(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : qAsConst(loaded))
        enc.write(id.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea *area : qAsConst(pages))
        area->page->loadSettings();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : idx) {
        Feed *f = feed_list->feedForIndex(i);
        if (f && feed_widget->getFeed() == f) {
            feed_widget->setFeed(0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
        tc->pause();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchEngine *se : qAsConst(engines)) {
        if (se->engineDir() == user_dir)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(scripts))
        {
            if (r.contains(s->scriptFile()) && !s->running())
            {
                s->execute();
                QModelIndex i = index(idx, 0);
                emit dataChanged(i, i);
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node* sibling : qAsConst(n->parent->children))
            {
                if (sibling != n && sibling->name == name)
                    return false;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget, &parser](const QStringList &arguments, const QString &workingDirectory)
        {
            if (!arguments.isEmpty())
            {
                parser.parse(arguments);
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString& filePath : positionalArguments)
            {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        }
```

#### AUTO 


```{c}
auto handleCmdLine = [&widget, &parser](const QStringList &arguments, const QString &workingDirectory)
        {
            if (!arguments.isEmpty())
            {
                parser.parse(arguments);
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5,62,0)
                widget.setAttribute(Qt::WA_NativeWindow, true);
                KStartupInfo::setNewStartupId(widget.windowHandle(), KStartupInfo::startupId());
#else
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
#endif
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString& filePath : positionalArguments)
            {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads)) {
                if (tc->getStats().running)
                    tc->networkUp();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : qAsConst(urls)) {
        bt::TrackerInterface *trk = tc.data()->getTrackersList()->addTracker(url, true);
        if (!trk)
            dupes.append(url);
        else
            tl.append(trk);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : missing) {
        QListWidgetItem* lwi = new QListWidgetItem(m_file_list);
        lwi->setText(s);
        lwi->setIcon(QIcon::fromTheme(mimeDatabase.mimeTypeForFile(s).iconName()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
        if (index.isValid() && !dragged_items.contains(index.row()))
            dragged_items.append(index.row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid() && index.column() == 0) {
            urls << QUrl::fromLocalFile(files.at(index.row()).first.path());
            dragged_rows.append(index.row());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &i : list) {
        i.save();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc: qAsConst(*qman))
        {
            const TorrentStats& s = tc->getStats();
            speed_dl += s.download_rate;
            speed_ul += s.upload_rate;
            bytes_dl += s.session_bytes_downloaded;
            bytes_ul += s.session_bytes_uploaded;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port& p : pl) {
            if (p.forward)
                r->forward(p);
        }
```

#### AUTO 


```{c}
auto pendingCallWatcher = new QDBusPendingCallWatcher(pendingReply, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions)
        {
            g.writeEntry(QLatin1String("Priority_") + a->objectName(), (int)a->priority());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indexes)
            files.append(play_list->fileForIndex(idx));
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(order))
        {
            // skip file if it is complete
            if (qAbs(100.0f - tor->getTorrentFile(file).getDownloadPercentage()) < 0.01)
                continue;

            // skip excluded or only seed files
            if (tor->getTorrentFile(file).getPriority() < LAST_PRIORITY)
                continue;

            // we have found the incomplete file
            return file;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsLineItem* line : qAsConst(lines))
        line->setPen(pen);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        if (a->data().value<QObject *>() == act || act == 0) {
            a->setChecked(true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MagnetDownloader* md : qAsConst(magnetQueue))
        writeEncoderInfo(enc, md);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i: idx)
        {
            Filter* f = available->filterForIndex(i);
            if (f)
                to_add.append(f);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* gi : gis) {
            if (gi->zValue() == 3) {
                clearSelection();
                gi->setSelected(true);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
        {
            if (IsStalled(tc, now, min_stall_time))
            {
                stalled.append(tc);
            }
            else
            {
                // decreasing makes only sense if there are QM torrents after the stalled ones
                can_decrease = stalled.count() > 0;
                newlist.append(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
            op(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node* sibling : qAsConst(n->parent->children))
                {
                    if (sibling != n && sibling->name == name)
                        return false;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &file : files)
        {
            core->load(file, QString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SearchEngine* se : qAsConst(engines))
        {
            if (se->engineDir() == user_dir)
                return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* i : qAsConst(items)) {
        if (i->peer == peer) {
            found = true;
            break;
        }
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : parts) {
        Range r = {0, 0};
        if (stringToRange(p, r))
            results.append(r);
        else
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewListener* vl : qAsConst(listeners))
            vl->currentTorrentChanged(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp: qAsConst(word_matches))
        {
            QRegExp tmp = exp;
            tmp.setCaseSensitivity(case_sensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
            tmp.setPatternSyntax(use_regular_expressions ? QRegExp::RegExp : QRegExp::Wildcard);
            if (all_word_matches_must_match)
            {
                if (!match(item->title(), tmp))
                    return false;
                else
                    found_match = true;
            }
            else if (match(item->title(), tmp))
            {
                found_match = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MagnetDownloader *md : qAsConst(stoppedList))
        writeEncoderInfo(enc, md);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShutdownRule &r : qAsConst(rules)) {
            items += QStringLiteral("- ") + r.toolTip();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* t : qAsConst(downloads)) {
        if (t == tc)
            continue;

        if (t->getStats().multi_file_torrent) {
            for (bt::Uint32 i = 0; i < t->getNumFiles(); i++) {
                if (files.contains(t->getTorrentFile(i).getPathOnDisk())) {
                    conflicting.append(t->getDisplayName());
                    break;
                }
            }
        } else {
            if (files.contains(t->getStats().output_path))
                conflicting.append(t->getDisplayName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s : qAsConst(scripts)) {
        if (r.contains(s->scriptFile()) && !s->running()) {
            s->execute();
            QModelIndex i = index(idx, 0);
            Q_EMIT dataChanged(i, i);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
            rows.append(idx.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes) {
        Filter* f = filter_list->filterForIndex(idx);
        if (f)
            to_remove.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem *i : qAsConst(items)) {
        if (i->contains(now)) {
            return i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tor : qAsConst(downloads)) {
        if (tor->getInfoHash() == ih) {
            TrackersList *ta = tor->getTrackersList();
            const int cnt = ta->getTrackers().count();
            ta->merge(trk);
            if (cnt < ta->getTrackers().count()) {
                // new trackers were added
                // do "Manual Announce" for this torrent
                if (tor->getStats().running) {
                    tor->updateTracker();
                }
            }
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
            {
                if (item->visible(group, filter_string))
                    if (!a(item->tc))
                        break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                        todo.removeAll(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
            {
                n->fillChunks();
                chunks.orBitSet(n->chunks);
            }
```

#### AUTO 


```{c}
const auto update_if_differs_float = [&](auto &target, const auto &source, int column){
            if (fabs(target - source) > 0.001) {
                to_update.append(model->index(row, column));
                target = source;
                ret |= (sort_column == column);
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            bt::TrackerInterface* trk = selectedTracker();
            if (trk)
                QApplication::clipboard()->setText(trk->trackerStatusString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface& iface : iface_list)
        {
            QIcon icon = QIcon::fromTheme(QStringLiteral("network-wired"));
#if 0 //FIXME KF5
            foreach (const Solid::Device& device, netlist)
            {
                const Solid::NetworkInterface* netdev = device.as<Solid::NetworkInterface>();
                if (netdev->ifaceName() == iface.name() && netdev->isWireless())
                {
                    icon = QIcon::fromTheme(QStringLiteral("network-wireless"));
                    break;
                }

            }
#endif

            combo_networkInterface->addItem(icon, iface.humanReadableName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::EnclosurePtr& e : encs) {
        if (e->type() == QStringLiteral("application/x-bittorrent") || e->url().endsWith(QStringLiteral(".torrent")))
            return e->url();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indices)
        {
            bt::PeerInterface* peer = model->indexToPeer(pm->mapToSource(idx));
            if (peer)
            {
                aman.banPeer(peer->getStats().ip_address);
                peer->kill();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        new KRun(QUrl::fromLocalFile(tc->getTorDir()), nullptr, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        names.append(tc->getDisplayName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchEngine *se : qAsConst(to_remove)) {
        bt::Touch(se->engineDir() + QStringLiteral("removed"));
        engines.removeAll(se);
        delete se;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i : idx) {
        Feed* f = feed_list->feedForIndex(i);
        if (f && feed_widget->getFeed() == f) {
            feed_widget->setFeed(0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface *t : trackers)
        ret << t->trackerURL().toDisplayString();
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) { QDBusPendingReply<quint32> reply = *callWatcher; if (reply.isValid()) { screensaver_cookie = reply.value(); Out(SYS_MPL | LOG_NOTICE) << "Screensaver inhibited (cookie " << screensaver_cookie << ")" << endl; } else Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress screensaver" << endl; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FlagDBSource& s: qAsConst(sources))
    {
        const QString& path = s.getPath(c);
        //e.g.: /usr/share/locale/l10n/ru/flag.png
        if (QFile::exists(path) && img.load(path))
        {
            if (img.width() != preferredWidth || img.height() != preferredHeight)
            {
                const QImage& imgScaled = img.scaled(preferredWidth, preferredHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                if (!imgScaled.isNull())
                {
                    pixmap = QPixmap::fromImage(imgScaled);
                    break;
                }
                else if (img.width() <= preferredWidth || img.height() <= preferredHeight)
                {
                    pixmap = QPixmap::fromImage(img);
                    break;
                }
            }
            else
            {
                pixmap = QPixmap::fromImage(img);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children)) {
        if (!n->file) {
            enc->write(n->name.toUtf8());
            enc->beginDict();
            n->saveExpandedState(pm->index(idx, 0, index), pm, tv, enc);
            enc->end();
        }
        idx++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QDBusPendingCallWatcher * callWatcher) {
                    QDBusPendingReply<void> reply = *callWatcher;
                    if (reply.isValid()) {
                        sleep_suppression_cookie = 0;
                        Out(SYS_GEN | LOG_DEBUG) << "Stopped suppressing sleep" << endl;
                    } else
                        Out(SYS_GEN | LOG_IMPORTANT) << "Failed to stop suppressing sleep" << endl;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &module : qAsConst(pluginsMetaData)) {
        KPluginInfo pi(module);
        pi.setConfig(KSharedConfig::openConfig()->group(pi.pluginName()));
        pi.load();

        plugins << pi;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl_f) {
        addChild(root, s, false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QSet<QString> *filter) {
            if (filter) {
                m_proxy->setFilter(filter);
                setupModels();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        const TorrentStats &s = tc->getStats();

        if (tc->readyForPreview() && !s.multi_file_torrent)
            en_prev = true;

        if (tc->getJobQueue()->runningJobs())
            continue;

        en_remove = true;
        if (!s.running) {
            if (qm_enabled) {
                // Queued torrents can be stopped, and not started
                if (s.queued)
                    en_stop = true;
                else
                    en_start = true;
            } else {
                en_start = true;
            }
        } else {
            en_stop = true;
            if (tc->announceAllowed())
                en_announce = true;

            if (!s.paused)
                en_pause = true;
            else
                en_start = true;
        }

        if (!s.priv_torrent) {
            en_add_peer = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(actions)) {
        if (a != act)
            a->setChecked(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *os : qAsConst(scripts)) {
        if (s->scriptFile() == os->scriptFile()) {
            delete s;
            return nullptr;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &w : words) {
            if (w.startsWith(QLatin1String("http://")) || w.startsWith(QLatin1String("https://")) || w.startsWith(QLatin1String("ftp://")))
                w = QStringLiteral("<a href=\"") + w + QStringLiteral("\">") + w + QStringLiteral("</a>");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& group : qAsConst(default_groups))
            addTab(gman->findByPath(group));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Range &r : qAsConst(seasons)) {
            if (season >= r.start && season <= r.end) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item &i : queue) {
        bt::TorrentInterface *tc = i.tc;
        if (!tc->getStats().running) {
            if (i.stalled_time != -1) {
                i.stalled_time = -1;
                Q_EMIT dataChanged(createIndex(r, 3), createIndex(r, 3));
            }
        } else {
            Int64 stalled_time = 0;
            if (tc->getStats().completed)
                stalled_time = (now - tc->getStats().last_upload_activity_time) / 1000;
            else
                stalled_time = (now - tc->getStats().last_download_activity_time) / 1000;

            if (i.stalled_time != stalled_time) {
                i.stalled_time = stalled_time;
                Q_EMIT dataChanged(createIndex(r, 3), createIndex(r, 3));
            }
        }
        r++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line: qAsConst(tmp))
        {
            QTextCharFormat fm = output->currentCharFormat();
            output->append(line);
            output->setCurrentCharFormat(fm);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dir_list) {
        QDir d(dir);
        const QStringList subdirs = d.entryList(QDir::Dirs);
        for (const QString& sdir : subdirs) {
            if (sdir != QStringLiteral("..") && sdir != QStringLiteral(".")) {
                QString absolute_path = d.absoluteFilePath(sdir);
                Script* s = loadScriptDir(absolute_path);
                if (s) {
                    // Scripts in the home directory can be deleted
                    s->setRemovable(absolute_path.startsWith(kt::DataDir()));
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](auto &target, const auto &source, int column){
            if (target != source) {
                to_update.append(model->index(row, column));
                target = source;
                ret |= (sort_column == column);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items)) {
        if (i != item && (i->conflicts(*item) || item->conflicts(*i)))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *f : qAsConst(feeds))
        if (f->directory() == dir)
            return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dir_list)
        {
            QDir d(dir);
            const QStringList subdirs = d.entryList(QDir::Dirs);
            for (const QString& sdir : subdirs)
            {
                if (sdir != QStringLiteral("..") && sdir != QStringLiteral("."))
                {
                    QString absolute_path = d.absoluteFilePath(sdir);
                    Script* s = loadScriptDir(absolute_path);
                    if (s)
                    {
                        // Scripts in the home directory can be deleted
                        s->setRemovable(absolute_path.startsWith(kt::DataDir()));
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
            QDBusPendingReply<quint32> reply = *callWatcher;
            if (reply.isValid()) {
                screensaver_cookie = reply.value();
                Out(SYS_MPL | LOG_NOTICE) << "Screensaver inhibited (cookie " << screensaver_cookie << ")" << endl;
            } else
                Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress screensaver" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
        if (!model->setData(idx, Qt::Checked, Qt::CheckStateRole))
            Out(SYS_SCR | LOG_DEBUG) << "setData failed" << endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : *qman) {
        onTorrentAdded(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogFlag& f : qAsConst(log_flags)) {
        if (sys == f.name) {
            removeRow(idx);
            log_flags.removeAt(idx);
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem* i : sel) {
        folders.removeAll(i->text());
        delete i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* i : *qman)
        torrentAdded(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& i : qAsConst(queue)) {
        bt::TorrentInterface* tc = i.tc;
        if (tc->getDisplayName().contains(text, Qt::CaseInsensitive)) {
            endResetModel();
            return index(idx, 0);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(download_queue))
        {
            const TorrentStats& s = tc->getStats();

            if (num_running < max_downloads || max_downloads == 0)
            {
                if (!s.running)
                {
                    Out(SYS_GEN | LOG_DEBUG) << "QM Starting: " << s.torrent_name << endl;
                    if (startInternal(tc) == bt::START_OK)
                        num_running++;
                }
                else
                    num_running++;
            }
            else
            {
                if (s.running)
                {
                    Out(SYS_GEN | LOG_DEBUG) << "QM Stopping: " << s.torrent_name << endl;
                    stopSafely(tc);
                }
                tc->setQueued(true);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        bt::TrackerInterface *trk = selectedTracker();
        if (trk)
            QApplication::clipboard()->setText(trk->trackerURL().toDisplayString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : queue)
        {
            bt::TorrentInterface* tc = i.tc;
            if (!tc->getStats().running)
            {
                if (i.stalled_time != -1)
                {
                    i.stalled_time = -1;
                    Q_EMIT dataChanged(createIndex(r, 3), createIndex(r, 3));
                }
            }
            else
            {
                Int64 stalled_time = 0;
                if (tc->getStats().completed)
                    stalled_time = (now - tc->getStats().last_upload_activity_time) / 1000;
                else
                    stalled_time = (now - tc->getStats().last_download_activity_time) / 1000;

                if (i.stalled_time != stalled_time)
                {
                    i.stalled_time = stalled_time;
                    Q_EMIT dataChanged(createIndex(r, 3), createIndex(r, 3));
                }
            }
            r++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : *qman) {
        onTorrentAdded(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl) {
        QString idir = data_dir + s;
        if (!idir.endsWith(DirSeparator()))
            idir.append(DirSeparator());

        Out(SYS_GEN | LOG_NOTICE) << "Loading feed from directory " << idir << endl;
        Feed* feed = 0;
        try {
            feed = new Feed(idir);
            connect(feed, &Feed::downloadLink, activity, &SyndicationActivity::downloadLink);
            feed->load(filter_list);
            addFeed(feed);

        } catch (...) {
            delete feed;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(to_add))
        {
            active->addFilter(f);
            available->removeFilter(f);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
            s += n->bytesToDownload(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items)) {
        enc.beginDict();
        enc.write(QByteArrayLiteral("start_day")); enc.write((Uint32)i->start_day);
        enc.write(QByteArrayLiteral("end_day")); enc.write((Uint32)i->end_day);
        enc.write(QByteArrayLiteral("start")); enc.write(i->start.toString().toLatin1());
        enc.write(QByteArrayLiteral("end")); enc.write(i->end.toString().toLatin1());
        enc.write(QByteArrayLiteral("upload_limit")); enc.write(i->upload_limit);
        enc.write(QByteArrayLiteral("download_limit")); enc.write(i->download_limit);
        enc.write(QByteArrayLiteral("suspended")); enc.write((Uint32)(i->suspended ? 1 : 0));
        if (i->set_conn_limits) {
            enc.write(QByteArrayLiteral("conn_limits"));
            enc.beginDict();
            enc.write(QByteArrayLiteral("global")); enc.write((Uint32)i->global_conn_limit);
            enc.write(QByteArrayLiteral("per_torrent")); enc.write((Uint32)i->torrent_conn_limit);
            enc.end();
        }
        enc.write(QByteArrayLiteral("screensaver_limits"), (Uint32)i->screensaver_limits);
        enc.write(QByteArrayLiteral("ss_upload_limit"), i->ss_upload_limit);
        enc.write(QByteArrayLiteral("ss_download_limit"), i->ss_download_limit);
        enc.end();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            tc->scrapeTracker();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* f : qAsConst(feeds)) {
            if (f->feedUrl() == feed_url) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &loadedItem : qAsConst(loaded)) {
        if (!feed_items_id.contains(loadedItem)) {
            itemsToRemove.push_front(loadedItem);
            need_to_save = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem &f : qAsConst(files))
        out << f.first.path() << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsRectItem* rect : qAsConst(rects)) {
        rect->setPen(pen);
        rect->setBrush(brush);
    }
```

#### AUTO 


```{c}
auto pendingReply = powerManagement.UnInhibit(sleep_suppression_cookie);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface * tor : qAsConst(*qman)) {
        if (isMember(tor)) {
            total++;
            if (tor->getStats().running)
                running++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : idx) {
        Filter *f = active->filterForIndex(i);
        if (f)
            to_remove.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : qAsConst(queue)) {
        if (tc == i.tc) {
            found = true;
            break;
        }
        r++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &s : download_location_history)
        if (s.endsWith(QLatin1String("//")))
            s.chop(1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s: sl)
        {
            QString idir = data_dir + s;
            if (!idir.endsWith(DirSeparator()))
                idir.append(DirSeparator());

            Out(SYS_GEN | LOG_NOTICE) << "Loading " << idir << endl;
            loadExistingTorrent(idir);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            if (tc && !tc->getJobQueue()->runningJobs())
            {
                const TorrentStats& s = tc->getStats();
                bool data_to = false;
                if (!s.completed)
                {
                    QString msg = i18n("The torrent <b>%1</b> has not finished downloading, "
                                       "do you want to delete the incomplete data, too?", tc->getDisplayName());
                    int ret = KMessageBox::questionYesNoCancel(
                                  this,
                                  msg,
                                  i18n("Remove Download"),
                                  KGuiItem(i18n("Delete Data")),
                                  KGuiItem(i18n("Keep Data")),
                                  KStandardGuiItem::cancel());
                    if (ret == KMessageBox::Cancel)
                        return;
                    else if (ret == KMessageBox::Yes)
                        data_to = true;
                }
                core->remove(tc, data_to);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* tc : qAsConst(downloads)) {
            const TorrentStats& s = tc->getStats();
            if (s.running) {
                suspended_torrents.insert(tc);
                stopSafely(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *s : sel) {
        int r = m_tracker_list->row(s);
        if (r > 0) {
            m_tracker_list->insertItem(r - 1, m_tracker_list->takeItem(r));
            m_tracker_list->setCurrentRow(r - 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
        if (!model->setData(idx, Qt::Unchecked, Qt::CheckStateRole))
            Out(SYS_SCR | LOG_DEBUG) << "setData failed" << endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *t : qAsConst(downloads)) {
        if (t == tc)
            continue;

        if (t->getStats().multi_file_torrent) {
            for (bt::Uint32 i = 0; i < t->getNumFiles(); i++) {
                if (files.contains(t->getTorrentFile(i).getPathOnDisk())) {
                    conflicting.append(t->getDisplayName());
                    break;
                }
            }
        } else {
            if (files.contains(t->getStats().output_path))
                conflicting.append(t->getDisplayName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(filters))
        names << f->filterName();
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab &tab : tabs) {
        if (tab.action->isChecked()) {
            tab.group = group;
            QString name = group->groupName() + QStringLiteral(" %1/%2").arg(group->runningTorrents()).arg(group->totalTorrents());
            tab.action->setText(name);
            tab.action->setIcon(group->groupIcon());
            edit_group_policy->setEnabled(!group->isStandardGroup());
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &exp : qAsConst(exclusion_patterns))
        enc.write(exp.pattern().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *item : qAsConst(items)) {
        if (item->cd == cd) {
            found = true;
            break;
        }
        row++;
    }
```

#### AUTO 


```{c}
auto i = plugins.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
            n->initPercentage(tc, havechunks);
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(preview_path));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& e : entries) {
        const KArchiveEntry* entry = dir->entry(e);
        if (entry && entry->isDirectory()) {
            addScriptFromArchiveDirectory((const KArchiveDirectory*)entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : qAsConst(hashes))
        stream << s;
```

#### RANGE FOR STATEMENT 


```{c}
for (MediaFile::Ptr mf: qAsConst(items))
        {
            if (mf->path() == path)
                return index(idx, 0, QModelIndex());
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tors))
        remove(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& m : sel) {
                to_del.append(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(m))));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(scripts)) {
        if (s->running())
            ret << s->scriptFile();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            if (tc->getStats().status != bt::ALLOCATING_DISKSPACE)
                core->doDataCheck(tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IPBlock& block: qAsConst(input))
        {
            dlg->progress(i, tot);
            target.write((char*) & block, sizeof(IPBlock));
            if (abort)
            {
                return;
            }
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sdir : subdirs) {
            if (sdir != QStringLiteral("..") && sdir != QStringLiteral(".")) {
                QString absolute_path = d.absoluteFilePath(sdir);
                Script *s = loadScriptDir(absolute_path);
                if (s) {
                    // Scripts in the home directory can be deleted
                    s->setRemovable(absolute_path.startsWith(kt::DataDir()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : qAsConst(dir_list)) {
        const QStringList subdirs = QDir(dir).entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QString &sd : subdirs) {
            loadEngine(QDir::cleanPath(dir) + QLatin1Char('/') + sd + QLatin1Char('/'), data_dir + sd + QLatin1Char('/'), removed_to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Extender* ext: qAsConst(extenders))
        {
            ext->hide();
            ext->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(order))
            out << file << endl;
```

#### LAMBDA EXPRESSION 


```{c}
[&](auto & target, const auto & source, int column) {
        if (fabs(target - source) > 0.001) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->getStats().status != bt::ALLOCATING_DISKSPACE)
            core->doDataCheck(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel)
        {
            if (idx.isValid() && idx.row() >= 0 && idx.row() < engines.count())
                to_remove.append(engines.at(idx.row()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* feed: qAsConst(feeds))
        {
            if (feed->usingFilter(f))
                feed->runFilters();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
            bt::TorrentFileInterface* tfi = model->indexToFile(proxy_model->mapToSource(idx));
            if (!tfi)
                continue;

            if (tfi->getFirstChunk() < from)
                from = tfi->getFirstChunk();
            if (tfi->getLastChunk() > to)
                to = tfi->getLastChunk();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo))
        {
            const TorrentStats& s = tc->getStats();
            if (s.completed && tc->overMaxSeedTime())
            {
                names.append(s.torrent_name);
                tmp.append(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s : qAsConst(searches)) {
        if (s == tabs->currentWidget()) {
            tabs->removeTab(tabs->currentIndex());
            searches.removeAll(s);
            delete s;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : urlStrings)
        {
            QUrl url(s);
            if (url.isValid() && (url.scheme() == QLatin1String("http")
                               || url.scheme() == QLatin1String("https")
                               || url.scheme() == QLatin1String("udp")))
            {
                trackers->insertItem(s);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i: idx)
        {
            Feed* f = feed_list->feedForIndex(i);
            if (f && feed_widget->getFeed() == f)
            {
                feed_widget->setFeed(0);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* i : qAsConst(torrents))
        {
            bool hidden = !i->visible(group, filter_string);
            if (!hidden && i->update(row, sort_column, update_list, this))
                resort = true;

            if (hidden != i->hidden)
            {
                i->hidden = hidden;
                resort = true;
            }

            // hide the extender if there is one shown
            if (hidden && delegate->extended(i->tc))
                delegate->hideExtender(i->tc);

            if (!i->hidden)
                num_visible++;
            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem& item: qAsConst(files))
        {
            if (item.first == file)
            {
                found = true;
                break;
            }
            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : qAsConst(se_formats)) {
            QRegExp exp(format, Qt::CaseInsensitive);
            int pos = exp.indexIn(title);
            if (pos > -1) {
                QString s = exp.cap(1); // Season
                QString e = exp.cap(2); // Episode
                bool ok = false;
                season = s.toInt(&ok);
                if (!ok)
                    continue;

                episode = e.toInt(&ok);
                if (!ok)
                    continue;

                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget *s : qAsConst(searches)) {
        if (w == s) {
            //              s->find();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(download_queue)) {
        const TorrentStats &s = tc->getStats();

        if (num_running < max_downloads || max_downloads == 0) {
            if (!s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Starting: " << s.torrent_name << endl;
                if (startInternal(tc) == bt::START_OK)
                    num_running++;
            } else
                num_running++;
        } else {
            if (s.running) {
                Out(SYS_GEN | LOG_DEBUG) << "QM Stopping: " << s.torrent_name << endl;
                stopSafely(tc);
            }
            tc->setQueued(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea *area : qAsConst(pages))
        if (area->page->customWidgetsChanged())
            return true;
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(filters))
        if (f->filterID() == id)
            return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->getStats().running)
            tc->updateTracker();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewListener* vl : qAsConst(listeners))
        vl->currentTorrentChanged(tc);
```

#### LAMBDA EXPRESSION 


```{c}
[this, slot](bool) {
        (this->*slot)();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const bt::TorrentInterface* tor : qAsConst(downloads))
        {
            if (tor->getInfoHash() == ih)
                return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *item : qAsConst(torrents)) {
        if (item->tc == ti) {
            view->scrollTo(index(idx, 0));
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(*qman))
        {
            if (visible(tc))
            {
                Item item = {tc, 0};
                queue.append(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(filters))
        f->save(enc);
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
            QDBusPendingReply<quint32> reply = *callWatcher;
            if (reply.isValid()) {
                screensaver_cookie = reply.value();
                Out(SYS_MPL | LOG_NOTICE) << "PowerManagement inhibited (cookie " << powermanagement_cookie << ")" << endl;
            } else
                Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(to_add)) {
        active->addFilter(f);
        available->removeFilter(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& s : download_location_history)
            if (s.endsWith(QLatin1String("//"))) s.chop(1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &i : qAsConst(queue))
        i.tc->setPriority(idx--);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *i : qAsConst(torrents)) {
        bool hidden = !i->visible(group, filter_string);
        if (!hidden && i->update(row, sort_column, update_list, this))
            resort = true;

        if (hidden != i->hidden) {
            i->hidden = hidden;
            resort = true;
        }

        // hide the extender if there is one shown
        if (hidden && delegate->extended(i->tc))
            delegate->hideExtender(i->tc);

        if (!i->hidden)
            num_visible++;
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* trk: qAsConst(tracker_list))
            trackers.append(new Item(trk));
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
        {
            if (!n->file)
            {
                enc->write(n->name.toUtf8());
                enc->beginDict();
                n->saveExpandedState(index.child(idx, 0), pm, tv, enc);
                enc->end();
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MediaFile::Ptr mf : qAsConst(items))
        {
            if (mf->torrent() == tc)
            {
                if (start == -1)
                {
                    // start of the range
                    start = row;
                    cnt = 1;
                }
                else
                    cnt++; // Still in the middle of the media files of this torrent
            }
            else if (start != -1)
            {
                // We have found the end
                break;
            }

            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s: qAsConst(searches))
        {
            if (w == s)
            {
//              s->find();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions) {
        a->setPriority((QAction::Priority) g.readEntry(QLatin1String("Priority_") + a->objectName(), (int)QAction::NormalPriority));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *feed : qAsConst(feeds))
        feed->removeFilter(f);
```

#### AUTO 


```{c}
const auto rul = (tc->getRunningTimeUL() >= tc->getRunningTimeDL()
                              ? tc->getRunningTimeUL() - tc->getRunningTimeDL()
                              : 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indices) {
        Script* s = model->scriptForIndex(idx);
        if (s && !s->packageDirectory().isEmpty())
            scripts_to_delete.append(s->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes)
        files.append(play_list->fileForIndex(idx));
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* trk : qAsConst(tracker_list))
        trackers.append(new Item(trk));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
            {
                bt::TorrentFileInterface* tfi = model->indexToFile(proxy_model->mapToSource(idx));
                if (!tfi)
                    continue;

                moves.insert(tfi, dir);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dir_list) {
        QDir d(dir);
        const QStringList subdirs = d.entryList(QDir::Dirs);
        for (const QString &sdir : subdirs) {
            if (sdir != QStringLiteral("..") && sdir != QStringLiteral(".")) {
                QString absolute_path = d.absoluteFilePath(sdir);
                Script *s = loadScriptDir(absolute_path);
                if (s) {
                    // Scripts in the home directory can be deleted
                    s->setRemovable(absolute_path.startsWith(kt::DataDir()));
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : item->children)
        i.row = row_index++;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
            {
                bt::TorrentFileInterface* tfi = model->indexToFile(proxy_model->mapToSource(idx));
                if (!tfi)
                    continue;

                if (tfi->getFirstChunk() < from)
                    from = tfi->getFirstChunk();
                if (tfi->getLastChunk() > to)
                    to = tfi->getLastChunk();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(filters))
            enc.write(f->filterID().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *s : sel) {
        int r = m_tracker_list->row(s);
        if (r + 1 < m_tracker_list->count()) {
            m_tracker_list->insertItem(r + 1, m_tracker_list->takeItem(r));
            m_tracker_list->setCurrentRow(r + 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface *otc : qAsConst(downloads)) {
            int p = otc->getPriority();
            otc->setPriority(p + 1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : items) {
        out << s << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogFlag &f : qAsConst(log_flags)) {
        if (sys == f.name) {
            removeRow(idx);
            log_flags.removeAt(idx);
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
        if (!model->setData(idx, Qt::Unchecked, Qt::CheckStateRole))
            Out(SYS_SCR | LOG_DEBUG) << "setData failed" << endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
        const bt::TorrentStats& s = tc->getStats();
        removed_bytes_up += s.session_bytes_uploaded;
        removed_bytes_down += s.session_bytes_downloaded;

        QString dir = tc->getTorDir();

        try {
            if (data_to)
                tc->deleteDataFiles();
        } catch (Error& e) {
            gui->errorMsg(e.toString());
        }

        torrentRemoved(tc);
        gman->torrentRemoved(tc);
        try {
            bt::Delete(dir, false);
        } catch (Error& e) {
            gui->errorMsg(e.toString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : qAsConst(tmp)) {
        QTextCharFormat fm = output->currentCharFormat();
        output->append(line);
        output->setCurrentCharFormat(fm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s : qAsConst(scripts))
        ret << s->scriptFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children))
            size += n->fileSize(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *os : qAsConst(scripts)) {
        if (s->scriptFile() == os->scriptFile()) {
            delete s;
            return 0;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget, &parser](const QStringList &arguments, const QString &workingDirectory) {
            if (!arguments.isEmpty()) {
                parser.parse(arguments);
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5, 62, 0)
                widget.setAttribute(Qt::WA_NativeWindow, true);
                KStartupInfo::setNewStartupId(widget.windowHandle(), KStartupInfo::startupId());
#else
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
#endif
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString &filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex & i : sel) {
        if (proxy_model->hasChildren(i))
            expandCollapseTree(i, expand);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ShutdownRule& r : qAsConst(rules)) {
            items += QStringLiteral("- ") + r.toolTip();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(scripts))
            if (s->scriptFile() == file)
                return;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
        {
            if (!model->setData(idx, Qt::Unchecked, Qt::CheckStateRole))
                Out(SYS_SCR | LOG_DEBUG) << "setData failed" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs)
        {
            tab.view_settings = g.readEntry(QStringLiteral("tab%1_settings").arg(idx++), view->defaultState());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](auto & target, const auto & source, int column) {
        if (target != source) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(items)) {
        if (item->cd == cd) {
            found = true;
            break;
        }
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::ItemPtr& item : items) {
            // Skip already loaded items
            if (loaded.contains(item->id()))
                continue;

            if (needToDownload(item, f)) {
                Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem *i : qAsConst(items)) {
        if (item->conflicts(*i))
            return false;
    }
```

#### AUTO 


```{c}
auto pendingHibernateReply = powerManagement.CanHibernate();
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            names.append(tc->getDisplayName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        if (tc->readyForPreview() && !tc->getStats().multi_file_torrent) {
            new KRun(QUrl::fromLocalFile(tc->getStats().output_path), 0, true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots)) {
            if (!slot->isTimerActived()) {
                slot->setTimerDuration(timerDuration);
                slot->startTimer();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sd : qAsConst(subdirs)) {

            // Load only if there is an opensearch.xml file and not a removed file
            if (bt::Exists(data_dir + sd + QStringLiteral("/opensearch.xml")) && !bt::Exists(data_dir + sd + QStringLiteral("/removed"))) {
                Out(SYS_SRC | LOG_DEBUG) << "Loading " << sd << endl;
                SearchEngine* se = new SearchEngine(data_dir + sd + QLatin1Char('/'));
                if (!se->load(data_dir + sd + QStringLiteral("/opensearch.xml")))
                    delete se;
                else
                    engines.append(se);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(downloads)) {
            const TorrentStats &s = tc->getStats();
            if (s.running)
                continue;

            if (tc->getJobQueue()->runningJobs())
                continue;

            todo.append(tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* s : sel)
        {
            QMap<QGraphicsItem*, ScheduleItem*>::iterator i = item_map.find(s);
            if (i != item_map.end())
                selection.append(i.value());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerItem& c : qAsConst(conds))
        {
            if (c.tc == tc)
            {
                removeRow(idx);
                break;
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *i : qAsConst(items)) {
        if (i->changed()) {
            if (lowest == -1)
                lowest = idx;
            highest = idx;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &exp : qAsConst(word_matches))
        enc.write(exp.pattern().toUtf8());
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QPoint &point) {
        QModelIndex index = m_tracker_list->indexAt(point);
        if (index.isValid()) {
            m_ContextMenu->exec(m_tracker_list->viewport()->mapToGlobal(point));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QItemSelectionRange& r : sel)
            doRange(r, command);
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(scripts))
            {
                if (s->packageDirectory() == dest_dir)
                    throw bt::Error(i18n("There is already a script package named %1 installed.", dir->name()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(scripts))
        ret << s->scriptFile();
```

#### AUTO 


```{c}
auto pendingCallWatcher2 = new QDBusPendingCallWatcher(pendingReply2, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(*qman)) {
        const TorrentStats& s = tc->getStats();
        speed_dl += s.download_rate;
        speed_ul += s.upload_rate;
        bytes_dl += s.session_bytes_downloaded;
        bytes_ul += s.session_bytes_uploaded;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        group->removeTorrent(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& i : qAsConst(queue)) {
        if (tc == i.tc) {
            found = true;
            break;
        }

        r++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file: qAsConst(order))
        {
            TorrentFileInterface& tf = tor->getTorrentFile(file);
            if (tf.getPriority() < LAST_PRIORITY)
                continue;

            if (file == next_file)
            {
                tf.setPriority(FIRST_PRIORITY);
                high_found = true;
            }
            else if (!normal_found && high_found)
            {
                // the file after the high prio file is set to normal
                // so that when the high prio file is finished the selector
                // will select it before we can set a new high prio file
                tf.setPriority(NORMAL_PRIORITY);
                normal_found = true;
                current_normal_priority_file = file;
            }
            else
                tf.setPriority(LAST_PRIORITY);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            QModelIndex m = treeView->currentIndex();
            m = m_proxy->mapToSource(m);
            const QString fname = m_model->fileName(m);
            QGuiApplication::clipboard()->setText(fname);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& r : qAsConst(re)) {
        items.append(r.pattern());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
        if (index.isValid() && index.column() == 0) {
            urls << QUrl::fromLocalFile(files.at(index.row()).first.path());
            dragged_rows.append(index.row());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* f : qAsConst(feeds))
        if (f->directory() == dir)
            return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(order))
        out << file << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(order)) {
        TorrentFileInterface &tf = tor->getTorrentFile(file);
        if (tf.getPriority() < LAST_PRIORITY)
            continue;

        if (file == next_file) {
            tf.setPriority(FIRST_PRIORITY);
            high_found = true;
        } else if (!normal_found && high_found) {
            // the file after the high prio file is set to normal
            // so that when the high prio file is finished the selector
            // will select it before we can set a new high prio file
            tf.setPriority(NORMAL_PRIORITY);
            normal_found = true;
            current_normal_priority_file = file;
        } else
            tf.setPriority(LAST_PRIORITY);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface *tc : qAsConst(downloads)) {
            const TorrentStats &s = tc->getStats();
            if (s.running) {
                suspended_torrents.insert(tc);
                stopSafely(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
        Node *n = (Node *)idx.internalPointer();
        if (n)
            setPriority(n, newpriority, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots))
        {
            if (!slot->isTimerActived())
            {
                slot->setTimerDuration(timerDuration);
                slot->startTimer();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs) {
        groups << tab.group->groupPath();
        if (idx == current_tab)
            tab.view_settings = view->header()->saveState();
        g.writeEntry(QStringLiteral("tab%1_settings").arg(idx++), tab.view_settings);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchEngine* se : qAsConst(to_remove)) {
        bt::Touch(se->engineDir() + QStringLiteral("removed"));
        engines.removeAll(se);
        delete se;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        g->addTorrent(tc, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        if (tc->getStats().status != bt::ALLOCATING_DISKSPACE)
            core->doDataCheck(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::UPnPRouter* r : qAsConst(routers))
                r->forward(port);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& f : qAsConst(folders)) {
        m_folders->addItem(new QListWidgetItem(QIcon::fromTheme(QStringLiteral("folder")), f));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children)) {
        if (!n->file) {
            if (BDictNode* d = dict->getDict(n->name.toUtf8()))
                n->loadExpandedState(pm->index(idx, 0, index), pm, tv, d);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* os: qAsConst(scripts))
        {
            if (s->scriptFile() == os->scriptFile())
            {
                delete s;
                return 0;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item &i : children) {
        i.expandGroups(gview, groups, model->index(row, 0, idx));
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface *trk : tracker_list) {
            trackers.append(new Item(trk));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads)) {
            const TorrentStats& s = tc->getStats();
            if (s.running)
                continue;

            if (tc->getJobQueue()->runningJobs())
                continue;

            todo.append(tc);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&core](const QString &) {core->applySettings();}
```

#### AUTO 


```{c}
const auto update_if_differs_float = [&](auto & target, const auto & source, int column) {
        if (fabs(target - source) > 0.001) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp : qAsConst(word_matches))
        enc.write(exp.pattern().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tor : qAsConst(downloads)) {
        if (tor->getInfoHash() == ih) {
            TrackersList* ta = tor->getTrackersList();
            const int cnt = ta->getTrackers().count();
            ta->merge(trk);
            if (cnt < ta->getTrackers().count()) {
                // new trackers were added
                // do "Manual Announce" for this torrent
                if (tor->getStats().running) {
                    tor->updateTracker();
                }
            }
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(tors))
        remove(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* tc : qAsConst(downloads))
        {
            const TorrentStats& s = tc->getStats();
            if (s.running || (tc->isAllowedToStart() && !s.stopped_by_error && !tc->getJobQueue()->runningJobs()))
            {
                if (s.completed)
                {
                    if (s.running || (!tc->overMaxRatio() && !tc->overMaxSeedTime()))
                        seed_queue.append(tc);
                }
                else
                    download_queue.append(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indices) {
        bt::PeerInterface* peer = model->indexToPeer(pm->mapToSource(idx));
        if (peer) {
            aman.banPeer(peer->getStats().ip_address);
            peer->kill();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions)
        {
            if (a->data().value<QObject*>() == act)
            {
                activity_switching_group->removeAction(a);
                a->deleteLater();
                break;
            }
        }
```

#### AUTO 


```{c}
auto pendingReply2 = powerManagement.UnInhibit(powermanagement_cookie);
```

#### AUTO 


```{c}
auto pendingReply = screensaver.UnInhibit(screensaver_cookie);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children)
        {
            QModelIndex ret = i.findGroup(g, idx.child(row, 0));
            row++;
            if (ret.isValid())
                return ret;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
            if (url.isValid()) {
                if (silently || Settings::openMultipleTorrentsSilently())
                    loadSilently(url);
                else
                    load(url);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url: qAsConst(urls))
        {
            bt::TrackerInterface* trk = tc.data()->getTrackersList()->addTracker(url, true);
            if (!trk)
                dupes.append(url);
            else
                tl.append(trk);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(scripts))
            ret << s->scriptFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items))
        {
            if (i->contains(now))
            {
                return i;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& format: qAsConst(se_formats))
            {
                QRegExp exp(format, Qt::CaseInsensitive);
                int pos = exp.indexIn(title);
                if (pos > -1)
                {
                    QString s = exp.cap(1); // Season
                    QString e = exp.cap(2);  // Episode
                    bool ok = false;
                    season = s.toInt(&ok);
                    if (!ok)
                        continue;

                    episode = e.toInt(&ok);
                    if (!ok)
                        continue;

                    return true;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::EnclosurePtr &e : encs) {
        if (e->type() == QStringLiteral("application/x-bittorrent") || e->url().endsWith(QStringLiteral(".torrent")))
            return e->url();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            btnScanFolder->setText(i18n("Scan"));
            progressBar->setVisible(false);
            m_thread->deleteLater();
            m_thread = nullptr;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : activity_switching_group->actions())
        {
            g.writeEntry(QLatin1String("Priority_") + a->objectName(), (int)a->priority());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(filters))
        enc.write(f->filterID().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const IPBlock &block : qAsConst(input)) {
        dlg->progress(i, tot);
        target.write((char *)&block, sizeof(IPBlock));
        if (abort) {
            return;
        }
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                    todo.removeAll(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (KParts::Part* part: parts)
            {
                if (part->domDocument().documentElement().attribute(QStringLiteral("name")) == p->parentPart())
                {
                    part->insertChildClient(p);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i: idx)
        {
            Feed* f = feedForIndex(i);
            if (f)
                to_remove.append(f);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes) {
        if (!idx.isValid() || idx.row() < 0 || idx.row() >= items.count())
            continue;

        MediaFile::Ptr p = items.at(idx.row());
        urls << QUrl::fromLocalFile(p->path());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : qAsConst(hashes))
            stream << s;
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        QModelIndex m = treeView->currentIndex();
        m = m_proxy->mapToSource(m);
        const QString fname = m_model->fileName(m);
        QGuiApplication::clipboard()->setText(fname);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LogFlag& f: qAsConst(log_flags))
        {
            if (sys == f.name)
            {
                removeRow(idx);
                log_flags.removeAt(idx);
                break;
            }
            idx++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QDBusPendingCallWatcher * callWatcher) {
            QDBusPendingReply<quint32> reply = *callWatcher;
            if (reply.isValid()) {
                screensaver_cookie = reply.value();
                Out(SYS_MPL | LOG_NOTICE) << "PowerManagement inhibited (cookie " << powermanagement_cookie << ")" << endl;
            } else Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : idx) {
        Feed *f = feed_list->feedForIndex(i);
        if (f && feed_widget->getFeed() == f) {
            feed_widget->setFeed(nullptr);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        g.writeEntry(QLatin1String("Priority_") + a->objectName(), (int)a->priority());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : selected) {
        Script* s = model->scriptForIndex(idx);
        if (s) {
            if (s->running())
                num_running++;
            else
                num_not_running++;
            if (s->removable())
                num_removable++;
        } else
            num_not_running++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(tmp))
                tc->setMaxSeedTime(0.0f);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents)) {
        if (item->tc == ti) {
            removeRow(idx);
            update(view->viewDelegate(), true);
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : missing)
        {
            QListWidgetItem* lwi = new QListWidgetItem(m_file_list);
            lwi->setText(s);
            lwi->setIcon(SmallIcon(mimeDatabase.mimeTypeForFile(s).iconName()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp : qAsConst(exclusion_patterns)) {
        QRegExp tmp = exp;
        tmp.setCaseSensitivity(exclusion_case_sensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
        tmp.setPatternSyntax(exclusion_reg_exp ? QRegExp::RegExp : QRegExp::Wildcard);
        if (exclusion_all_must_match) {
            if (!match(item->title(), tmp)) {
                found_match = false;
                break;
            } else
                found_match = true;
        } else if (match(item->title(), tmp))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MediaFile::Ptr mf: qAsConst(items))
        {
            if (mf->path() == path)
                return MediaFileRef(mf);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children)) {
            Qt::CheckState s = n->checkState(tc);
            if (s == Qt::PartiallyChecked)
                return s;
            else if (s == Qt::Checked)
                found_checked = true;
            else
                found_unchecked = true;

            if (found_checked && found_unchecked)
                return Qt::PartiallyChecked;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        addTab(gman->findByPath(group));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : urlStrings) {
        QUrl url(s);
        if (url.isValid() && (url.scheme() == QLatin1String("http") || url.scheme() == QLatin1String("https") || url.scheme() == QLatin1String("udp"))) {
            trackers->insertItem(s);
        }
    }
```

#### AUTO 


```{c}
const auto update_if_differs_float = [&](auto &target, const auto &source, int column) {
        if (fabs(target - source) > 0.001) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        // set default values for current pref page only
        kcfg_okTorrentColor->setColor(QColor(40, 205, 40));
        kcfg_stalledTorrentColor->setColor(QColor(255, 174, 0));
        kcfg_errorTorrentColor->setColor(QColor(Qt::red));

        kcfg_highlightTorrentNameByTrackerStatus->setChecked(true);
        kcfg_okTrackerConnectionColor->setColor(QColor(40, 205, 40));
        kcfg_warningsTrackerConnectionColor->setColor(QColor(255, 80, 0));
        kcfg_timeoutTrackerConnectionColor->setColor(QColor(0, 170, 110));
        kcfg_noTrackerConnectionColor->setColor(QColor(Qt::red));

        kcfg_goodShareRatioColor->setColor(QColor(40, 205, 40));
        kcfg_lowShareRatioColor->setColor(QColor(Qt::red));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem& f : qAsConst(files))
            out << f.first.path() << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& i : idx) {
        Feed* f = feedForIndex(i);
        if (f)
            to_remove.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(tmp))
                    todo.removeAll(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                    tc->setMaxShareRatio(0.0f);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : scripts)
        {
            Out(SYS_SCR | LOG_DEBUG) << "Loading script " << s << endl;
            if (bt::Exists(s))
            {
                try
                {
                    model->addScript(s);
                }
                catch (bt::Error& err)
                {
                    getGUI()->errorMsg(err.toString());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : qAsConst(pluginsMetaData)) {
        if (loaded.contains(idx) && !data.isEnabled(cfg)) {
            // unload it
            unload(data, idx);
        } else if (!loaded.contains(idx) && data.isEnabled(cfg)) {
            // load it
            load(data, idx);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SeasonEpisodeItem& item : se) {
            enc.write((bt::Uint32)item.season);
            enc.write((bt::Uint32)item.episode);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : idx_list) {
        if (!mman->isStopped(idx.row()))
            stop->setEnabled(true);
        else
            start->setEnabled(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes)
        {
            Filter* f = filter_list->filterForIndex(idx);
            if (f)
                to_remove.append(f);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *item : qAsConst(torrents)) {
            if (item->visible(group, filter_string))
                if (!a(item->tc))
                    break;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        bt::TrackerInterface* trk = selectedTracker();
        if (trk)
            QApplication::clipboard()->setText(trk->trackerURL().toDisplayString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::ItemPtr &item : feedItems)
        feed_items_id.insert(item->id());
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot *slot : qAsConst(usedDownloadingSlots))
        delete slot;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
            const TorrentStats& s = tc->getStats();
            if (!s.completed && !tc->checkDiskSpace(false)) {
                names.append(s.torrent_name);
                tmp.append(tc);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PlayListItem& item : qAsConst(files)) {
        if (item.first == file) {
            found = true;
            break;
        }
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s : qAsConst(searches)) {
        if (w == s) {
            s->home();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(to_remove))
        {
            if (!s->packageDirectory().isEmpty())
                bt::Delete(s->packageDirectory(), true);
            scripts.removeAll(s);
            s->stop();
            s->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab &tab : tabs) {
        tab.view_settings = g.readEntry(QStringLiteral("tab%1_settings").arg(idx++), view->defaultState());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&widget, &parser](const QStringList &arguments, const QString &workingDirectory)
        {
            if (!arguments.isEmpty())
            {
                parser.parse(arguments);
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            Q_FOREACH (const QString& filePath, parser.positionalArguments())
            {
                QUrl url = QFile::exists(filePath)?QUrl::fromLocalFile(filePath):QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tor: files)
        {
            if (!alreadyLoaded(d, tor))
                torrents.append(QUrl::fromLocalFile(d.absoluteFilePath(tor)));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f : qAsConst(to_remove)) {
        available->addFilter(f);
        active->removeFilter(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs) {
        tab.view_settings = g.readEntry(QStringLiteral("tab%1_settings").arg(idx++), view->defaultState());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : sel) {
        if (proxy_model->hasChildren(i))
            expandCollapseTree(i, expand);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerItem& c : qAsConst(conds))
        {
            if (c.checked)
                rules->addRule(action, SPECIFIC_TORRENT, c.trigger, c.tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(*qman)) {
        connect(tc, &bt::TorrentInterface::statusChanged, this, &QueueManagerModel::onTorrentStatusChanged);

        if (visible(tc)) {
            Item item = {tc, 0};
            queue.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* feed : qAsConst(feeds))
        feed->removeFilter(f);
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots))
        {
            slot->stopTimer();
            slot->setTimerDuration(timerDuration);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::UPnPRouter* r : qAsConst(routers))
            r->forward(port);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& format: qAsConst(se_formats))
        {
            QRegExp exp(format, Qt::CaseInsensitive);
            int pos = exp.indexIn(title);
            if (pos > -1)
            {
                QString s = exp.cap(1); // Season
                QString e = exp.cap(2);  // Episode
                bool ok = false;
                season = s.toInt(&ok);
                if (!ok)
                    continue;

                episode = e.toInt(&ok);
                if (!ok)
                    continue;

                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id: qAsConst(loaded))
            enc.write(id.toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        // look for the desktop file
        if (!file.endsWith(QStringLiteral(".desktop")) && !file.endsWith(QStringLiteral(".DESKTOP")))
            continue;

        // check for duplicate packages
        QString dest_dir = kt::DataDir() + QStringLiteral("scripts/") + dir->name() + QLatin1Char('/');
        for (Script *s : qAsConst(scripts)) {
            if (s->packageDirectory() == dest_dir)
                throw bt::Error(i18n("There is already a script package named %1 installed.", dir->name()));
        }

        // extract to the scripts dir
        dir->copyTo(dest_dir, true);
        if (!addScriptFromDesktopFile(dest_dir, file))
            throw bt::Error(i18n("Failed to load script from archive. There is something wrong with the desktop file."));

        return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* otc : qAsConst(downloads))
            {
                int p = otc->getPriority();
                otc->setPriority(p + 1);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes) {
            const WebSeedInterface* ws = curr_tc.data()->getWebSeed(proxy_model->mapToSource(idx).row());
            if (ws && ws->isUserCreated()) {
                m_remove->setEnabled(true);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const bt::TorrentInterface* tor : qAsConst(downloads)) {
        if (tor->getInfoHash() == ih)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(trs)) {
                    enc.write(u.toEncoded());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* i: qAsConst(items))
        {
            if (i->peer == peer)
            {
                found = true;
                break;
            }
            row++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indexes) {
        Node* n = (Node*)idx.internalPointer();
        if (n)
            setPriority(n, newpriority, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sdir : subdirs)
            {
                if (sdir != QStringLiteral("..") && sdir != QStringLiteral("."))
                {
                    QString absolute_path = d.absoluteFilePath(sdir);
                    Script* s = loadScriptDir(absolute_path);
                    if (s)
                    {
                        // Scripts in the home directory can be deleted
                        s->setRemovable(absolute_path.startsWith(kt::DataDir()));
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : items)
        {
            out << s << Qt::endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& w : words) {
            if (w.startsWith(QLatin1String("http://")) || w.startsWith(QLatin1String("https://")) || w.startsWith(QLatin1String("ftp://")))
                w = QStringLiteral("<a href=\"") + w + QStringLiteral("\">") + w + QStringLiteral("</a>");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Syndication::EnclosurePtr e : encs)
        {
            if (e->type() == QStringLiteral("application/x-bittorrent") || e->url().endsWith(QStringLiteral(".torrent")))
                return e->url();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        if (tc->getStats().running)
            tc->updateTracker();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
        Node *n = (Node *)idx.internalPointer();
        if (!n)
            continue;

        setData(idx, newpriority, Qt::UserRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* ti: qAsConst(sel))
        {
            g->addTorrent(ti, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        PlayListItem item = qMakePair(collection->find(url.toLocalFile()), (TagLib::FileRef *)0);
        files.insert(row, item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                QDBusPendingReply<quint32> reply = *callWatcher;
                if (reply.isValid()) {
                    sleep_suppression_cookie = reply.value();
                    Out(SYS_GEN | LOG_DEBUG) << "Suppressing sleep" << endl;
                } else
                    Out(SYS_GEN | LOG_IMPORTANT) << "Failed to suppress sleeping" << endl;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& s: sl_d) {
            FNode* d = addChild(root, s, true);
            next_dir.setPath(dir.path() + QLatin1String("/") + s);
            fillFromDir(d, next_dir);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerItem &c : qAsConst(conds)) {
        if (c.tc == tc) {
            removeRow(idx);
            break;
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* s : sel) {
        QMap<QGraphicsItem*, ScheduleItem*>::iterator i = item_map.find(s);
        if (i != item_map.end()) {
            ScheduleItem* si = i.value();
            scene->removeItem(s);
            item_map.erase(i);
            schedule->removeItem(si);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            new KRun(QUrl::fromLocalFile(tc->getTorDir()), 0, true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QDBusPendingCallWatcher * callWatcher) {
            QDBusPendingReply<void> reply = *callWatcher;
            if (reply.isValid()) {
                powermanagement_cookie = 0;
                Out(SYS_MPL | LOG_NOTICE) << "Power management uninhibited" << endl;
            } else Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit power management" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
        {
            if (!index.isValid())
                continue;

            const bt::TorrentInterface* ti = torrentFromIndex(index);
            if (ti)
            {
                QString hash = ti->getInfoHash().toString();
                if (!hashes.contains(hash))
                {
                    hashes.append(hash);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(hashes))
        stream << s;
```

#### AUTO 


```{c}
auto handleCmdLine = [&widget, &parser](const QStringList &arguments, const QString &workingDirectory) {
            parser.parse(arguments);
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString &filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: selected)
        {
            Script* s = model->scriptForIndex(idx);
            if (s)
            {
                if (s->running())
                    num_running++;
                else
                    num_not_running++;
                if (s->removable())
                    num_removable++;
            }
            else
                num_not_running++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            if (core->checkMissingFiles(tc))
                tc->changeOutputDir(dir, bt::TorrentInterface::MOVE_FILES);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& child : qAsConst(children)) {
        child.expandedGroups(gview, groups, model->index(row, 0, idx));
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (index.isValid() && !dragged_items.contains(index.row()))
            dragged_items.append(index.row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& p : parts)
        {
            Range r = {0, 0};
            if (stringToRange(p, r))
                results.append(r);
            else
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem *i : qAsConst(items))
            op(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(downloads)) {
        if (IsStalled(tc, now, min_stall_time)) {
            stalled.append(tc);
        } else {
            // decreasing makes only sense if there are QM torrents after the stalled ones
            can_decrease = stalled.count() > 0;
            newlist.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
            g->addTorrent(tc, false);
        }
```

#### AUTO 


```{c}
const auto &i
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : *qman)
        {
            onTorrentAdded(tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder: qAsConst(tmp))
        {
            if (scan_folders.find(folder))
                continue;

            if (QDir(folder).exists())
            {
                // only add folder when it exists
                ScanFolder* sf = new ScanFolder(this, QUrl::fromLocalFile(folder), recursive);
                scan_folders.insert(folder, sf);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file: files)
        {
            if (file.endsWith(QStringLiteral(".desktop")))
            {
                return model->addScriptFromDesktopFile(dir_path, file);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(scripts))
        {
            if (s->running())
                ret << s->scriptFile();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item: qAsConst(queue))
        {
            Out(SYS_GEN | LOG_DEBUG) << "Item " << idx << ": " << item.tc->getDisplayName() << " " << item.tc->getPriority() << endl;
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            const TorrentStats& s = tc->getStats();

            if (tc->readyForPreview() && !s.multi_file_torrent)
                en_prev = true;

            if (tc->getJobQueue()->runningJobs())
                continue;

            en_remove = true;
            if (!s.running)
            {
                if (qm_enabled)
                {
                    // Queued torrents can be stopped, and not started
                    if (s.queued)
                        en_stop = true;
                    else
                        en_start = true;
                }
                else
                {
                    en_start = true;
                }
            }
            else
            {
                en_stop = true;
                if (tc->announceAllowed())
                    en_announce = true;

                if (!s.paused)
                    en_pause = true;
                else
                    en_start = true;
            }

            if (!s.priv_torrent)
            {
                en_add_peer = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsLineItem* line : qAsConst(lines))
            line->setPen(pen);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sd : subdirs) {
            loadEngine(QDir::cleanPath(dir) + QLatin1Char('/') + sd + QLatin1Char('/'), data_dir + sd + QLatin1Char('/'), removed_to);
        }
```

#### AUTO 


```{c}
auto handleCmdLine = [&widget, &parser](const QStringList &arguments, const QString &workingDirectory)
        {
            if (!arguments.isEmpty())
            {
                parser.parse(arguments);
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString& filePath : positionalArguments)
            {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index: indexes)
        {
            if (index.isValid())
            {
                files.append(order.at(index.row()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : qAsConst(actions)) {
        if (a != act)
            a->setChecked(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &t : trackers) {
        if (t.isEmpty())
            continue;

        QUrl url(t.trimmed());
        if (!url.isValid() || (url.scheme() != QLatin1String("udp") && url.scheme() != QLatin1String("http") && url.scheme() != QLatin1String("https")))
            invalid.append(t);
        else {
            if (!tracker_hints.contains(url.toDisplayString()))
                tracker_hints.append(url.toDisplayString());
            urls.append(url);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& s: sl_f) {
            addChild(root, s, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : qAsConst(urls))
        {
            PlayListItem item = qMakePair(collection->find(url.toLocalFile()), (TagLib::FileRef*)0);
            files.insert(row, item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(to_remove)) {
        feed_list->filterRemoved(f);
        filter_list->removeFilter(f);
        delete f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(usedDownloadingSlots)) {
            slot->stopTimer();
            slot->setTimerDuration(timerDuration);
        }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url, QApplication::activeWindow());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& child: qAsConst(children))
        {
            child.expandedGroups(gview, groups, model->index(row, 0, idx));
            row++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) {
                QDBusPendingReply<void> reply = *callWatcher;
                if (reply.isValid()) {
                    powermanagement_cookie = 0;
                    Out(SYS_MPL | LOG_NOTICE) << "Power management uninhibited" << endl;
                }
                else
                    Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit power management" << endl;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &iface : iface_list) {
        QIcon icon = QIcon::fromTheme(QStringLiteral("network-wired"));
#if 0 // FIXME KF5
        for (const Solid::Device& device : netlist) {
            const Solid::NetworkInterface* netdev = device.as<Solid::NetworkInterface>();
            if (netdev->ifaceName() == iface.name() && netdev->isWireless()) {
                icon = QIcon::fromTheme(QStringLiteral("network-wireless"));
                break;
            }

        }
#endif

        combo_networkInterface->addItem(icon, iface.humanReadableName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s : qAsConst(searches))
        {
            if (s->getCurrentUrl() == QUrl(QStringLiteral("about:ktorrent")))
            {
                s->search(text, engine);
                tabs->setCurrentWidget(s);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* i : qAsConst(torrents)) {
        bool hidden = !i->visible(group, filter_string);
        if (!hidden && i->update(row, sort_column, update_list, this))
            resort = true;

        if (hidden != i->hidden) {
            i->hidden = hidden;
            resort = true;
        }

        // hide the extender if there is one shown
        if (hidden && delegate->extended(i->tc))
            delegate->hideExtender(i->tc);

        if (!i->hidden)
            num_visible++;
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* f : qAsConst(to_remove)) {
        bt::Delete(f->directory(), true);
        feeds.removeAll(f);
        delete f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s : qAsConst(to_remove)) {
        if (!s->packageDirectory().isEmpty())
            bt::Delete(s->packageDirectory(), true);
        scripts.removeAll(s);
        s->stop();
        s->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& e: qAsConst(ip_list))
        {
            if (e.start <= ip && ip <= e.end)
                return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : idx) {
        Filter *f = available->filterForIndex(i);
        if (f)
            to_add.append(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int mib: qAsConst(encodings))
        {
            m_encoding->addItem(QString::fromUtf8(QTextCodec::codecForMib(mib)->name()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget *w : qAsConst(searches)) {
        enc.beginDict();
        enc.write("TEXT", w->getSearchText().toUtf8());
        enc.write("URL", w->getCurrentUrl().toDisplayString().toUtf8());
        enc.write("SBTEXT", w->getSearchBarText().toUtf8());
        enc.write("ENGINE", (bt::Uint32)w->getSearchBarEngine());
        enc.end();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* f: qAsConst(feeds))
            if (f->directory() == dir)
                return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
        if (idx.isValid() && idx.row() >= 0 && idx.row() < engines.count())
            to_remove.append(engines.at(idx.row()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
        Syndication::ItemPtr ptr = model->itemForIndex(idx);
        if (ptr)
            feed->downloadItem(ptr, QString(), QString(), QString(), false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* t : qAsConst(downloads))
            {
                if (info_hash_list.contains(t->getInfoHash().toString()))
                    suspended_torrents.insert(t);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes) {
        if (index.isValid()) {
            files.append(order.at(index.row()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Group *g : qAsConst(defaults))
        groups.insert(g->groupName(), g);
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items)) {
        if (between(now.date().dayOfWeek(), i->start_day, i->end_day) && i->start > now.time()) {
            if (!item || i->start < item->start)
                item = i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port& p : pl)
            {
                if (p.forward)
                    r->forward(p);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& u : qAsConst(trs)) {
                    enc.write(u.toEncoded());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : files)
        play_list->addFile(collection->find(file));
```

#### RANGE FOR STATEMENT 


```{c}
for (MediaFile::Ptr mf : qAsConst(items)) {
        if (mf->path() == path)
            return MediaFileRef(mf);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        QString idir = data_dir + s;
        if (!idir.endsWith(DirSeparator()))
            idir.append(DirSeparator());

        Out(SYS_GEN | LOG_NOTICE) << "Loading " << idir << endl;
        loadExistingTorrent(idir);
    }
```

#### AUTO 


```{c}
auto i = rs.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* i : *qman) {
        torrentAdded(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads)) {
        const TorrentStats& s = tc->getStats();
        if (s.running || tc->getJobQueue()->runningJobs() || !s.autostart)
            continue;

        todo.append(tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl)
        out << s << Qt::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* feed: qAsConst(feeds))
            feed->removeFilter(f);
```

#### RANGE FOR STATEMENT 


```{c}
for (int r : qAsConst(dragged_rows)) {
        r -= nr;
        removeRow(r);
        nr++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item &i : children) {
        Out(SYS_GEN | LOG_DEBUG) << indent << "child " << i.row << endl;
        i.dump();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc: qAsConst(todo))
        {
            const bt::TorrentStats& s = tc->getStats();
            removed_bytes_up += s.session_bytes_uploaded;
            removed_bytes_down += s.session_bytes_downloaded;

            QString dir = tc->getTorDir();

            try
            {
                if (data_to)
                    tc->deleteDataFiles();
            }
            catch (Error& e)
            {
                gui->errorMsg(e.toString());
            }

            torrentRemoved(tc);
            gman->torrentRemoved(tc);
            try
            {
                bt::Delete(dir, false);
            }
            catch (Error& e)
            {
                gui->errorMsg(e.toString());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *gi : gis) {
        if (gi->zValue() == 3) {
            itemDoubleClicked(gi);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
                if (item->highlight)
                    item->highlight = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsRectItem* rect : qAsConst(rects))
        {
            rect->setPen(pen);
            rect->setBrush(brush);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
        {
            if (!n->file)
            {
                if (BDictNode* d = dict->getDict(n->name.toUtf8()))
                    n->loadExpandedState(index.child(idx, 0), pm, tv, d);
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node* sibling : qAsConst(n->parent->children)) {
                if (sibling != n && sibling->name == name)
                    return false;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url: urls)
            {
                if (url.isValid())
                {
                    if (silently || Settings::openMultipleTorrentsSilently())
                        loadSilently(url);
                    else
                        load(url);
                }
            }
```

#### AUTO 


```{c}
auto handleCmdLine = [&widget, &parser](const QStringList & arguments, const QString & workingDirectory) {
            if (!arguments.isEmpty()) {
                parser.parse(arguments);
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5,62,0)
                widget.setAttribute(Qt::WA_NativeWindow, true);
                KStartupInfo::setNewStartupId(widget.windowHandle(), KStartupInfo::startupId());
#else
                KStartupInfo::setNewStartupId(&widget, KStartupInfo::startupId());
#endif
                KWindowSystem::forceActiveWindow(widget.winId());
            }
            QString oldCurrent = QDir::currentPath();
            if (!workingDirectory.isEmpty())
                QDir::setCurrent(workingDirectory);

            bool silent = parser.isSet(QStringLiteral("silent"));
            auto loadMethod = silent ? &kt::GUI::loadSilently : &kt::GUI::load;
            const auto positionalArguments = parser.positionalArguments();
            for (const QString& filePath : positionalArguments) {
                QUrl url = QFile::exists(filePath) ? QUrl::fromLocalFile(filePath) : QUrl(filePath);
                (widget.*loadMethod)(url);
            }

            if (!workingDirectory.isEmpty())
                QDir::setCurrent(oldCurrent);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
        const TorrentStats& s = tc->getStats();
        if (s.completed && tc->overMaxRatio()) {
            names.append(s.torrent_name);
            tmp.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &tracker : qAsConst(trs)) {
                enc.beginList();
                enc.write(tracker.toDisplayString().toUtf8());
                enc.end();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* a : actions) {
        if (a->data().value<QObject*>() == act || act == 0) {
            a->setChecked(true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem* i: sel)
        {
            folders.removeAll(i->text());
            delete i;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(filters))
            names << f->filterName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& i: qAsConst(queue))
        {
            bt::TorrentInterface* tc = i.tc;
            if (tc->getDisplayName().contains(text, Qt::CaseInsensitive))
            {
                endResetModel();
                return index(idx, 0);
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
            {
                const TorrentStats& s = tc->getStats();
                if (s.running)
                    continue;

                if (tc->getJobQueue()->runningJobs())
                    continue;

                todo.append(tc);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
            tc->setPriority(prio + sel.count() - idx++);
```

#### AUTO 


```{c}
auto pendingSuspendReply = powerManagement.CanSuspend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sd : qAsConst(subdirs))
            {

                // Load only if there is an opensearch.xml file and not a removed file
                if (bt::Exists(data_dir + sd + QStringLiteral("/opensearch.xml")) && !bt::Exists(data_dir + sd + QStringLiteral("/removed")))
                {
                    Out(SYS_SRC | LOG_DEBUG) << "Loading " << sd << endl;
                    SearchEngine* se = new SearchEngine(data_dir + sd + QLatin1Char('/'));
                    if (!se->load(data_dir + sd + QStringLiteral("/opensearch.xml")))
                        delete se;
                    else
                        engines.append(se);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(stalled))
        Out(SYS_GEN | LOG_NOTICE) << "The torrent " << tc->getStats().torrent_name << " has stalled longer than " << min_stall_time
                                  << " minutes, decreasing its priority" << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area: qAsConst(pages))
            if (area->page->customWidgetsChanged())
                return true;
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& u : qAsConst(links)) {
        if (u.path().endsWith(QStringLiteral(".torrent")) || u.path().endsWith(QStringLiteral(".TORRENT"))) {
            Out(SYS_SYN | LOG_DEBUG) << "Trying torrent link: " << u.toDisplayString() << endl;
            link_url = u;
            KIO::StoredTransferJob* j = KIO::storedGet(u, KIO::Reload, verbose ? KIO::DefaultFlags : KIO::HideProgressInfo);
            connect(j, &KIO::StoredTransferJob::result, this, &LinkDownloader::torrentDownloadFinished);
            links.removeAll(u);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem* s : sel) {
        int r = m_tracker_list->row(s);
        if (r + 1 < m_tracker_list->count()) {
            m_tracker_list->insertItem(r + 1, m_tracker_list->takeItem(r));
            m_tracker_list->setCurrentRow(r + 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indices) {
        bt::PeerInterface *peer = model->indexToPeer(pm->mapToSource(idx));
        if (peer)
            peer->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo))
        {
            stop(tc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *item : qAsConst(torrents)) {
        if (item->visible(group, filter_string))
            tlist.append(item->tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: sel)
        {
            Syndication::ItemPtr ptr = model->itemForIndex(idx);
            if (ptr)
                feed->downloadItem(ptr, QString(), QString(), QString(), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo)) {
        const TorrentStats& s = tc->getStats();
        if (s.completed && tc->overMaxSeedTime()) {
            names.append(s.torrent_name);
            tmp.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface& iface : iface_list)
        {
            QIcon icon = QIcon::fromTheme(QStringLiteral("network-wired"));
#if 0 //FIXME KF5
            for (const Solid::Device& device: netlist)
            {
                const Solid::NetworkInterface* netdev = device.as<Solid::NetworkInterface>();
                if (netdev->ifaceName() == iface.name() && netdev->isWireless())
                {
                    icon = QIcon::fromTheme(QStringLiteral("network-wireless"));
                    break;
                }

            }
#endif

            combo_networkInterface->addItem(icon, iface.humanReadableName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indexes)
            {
                const WebSeedInterface* ws = curr_tc.data()->getWebSeed(proxy_model->mapToSource(idx).row());
                if (ws && ws->isUserCreated())
                {
                    m_remove->setEnabled(true);
                    return;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel)
        rows.append(idx.row());
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* t : trackers)
        ret << t->trackerURL().toDisplayString();
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem *i : qAsConst(items)) {
        enc.beginDict();
        enc.write(QByteArrayLiteral("start_day"));
        enc.write((Uint32)i->start_day);
        enc.write(QByteArrayLiteral("end_day"));
        enc.write((Uint32)i->end_day);
        enc.write(QByteArrayLiteral("start"));
        enc.write(i->start.toString().toLatin1());
        enc.write(QByteArrayLiteral("end"));
        enc.write(i->end.toString().toLatin1());
        enc.write(QByteArrayLiteral("upload_limit"));
        enc.write(i->upload_limit);
        enc.write(QByteArrayLiteral("download_limit"));
        enc.write(i->download_limit);
        enc.write(QByteArrayLiteral("suspended"));
        enc.write((Uint32)(i->suspended ? 1 : 0));
        if (i->set_conn_limits) {
            enc.write(QByteArrayLiteral("conn_limits"));
            enc.beginDict();
            enc.write(QByteArrayLiteral("global"));
            enc.write((Uint32)i->global_conn_limit);
            enc.write(QByteArrayLiteral("per_torrent"));
            enc.write((Uint32)i->torrent_conn_limit);
            enc.end();
        }
        enc.write(QByteArrayLiteral("screensaver_limits"), (Uint32)i->screensaver_limits);
        enc.write(QByteArrayLiteral("ss_upload_limit"), i->ss_upload_limit);
        enc.write(QByteArrayLiteral("ss_download_limit"), i->ss_download_limit);
        enc.end();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f: qAsConst(filters))
            if (f->filterName() == name)
                return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s : qAsConst(scripts))
            if (s->scriptFile() == file)
                return;
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
            if (item->highlight)
                item->highlight = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (int v : qAsConst(values)) {
        if (v >= 1) {
            QAction *act = addAction(QString::number(v));
            act->setCheckable(true);
            act->setChecked(rate == v);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &match : sm)
                    addresses.push_back(match.str());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
        Script* s = model->scriptForIndex(idx);
        if (s)
            new KRun(QUrl::fromLocalFile(s->scriptFile()), 0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DownloadSlot* slot : qAsConst(freeDownloadingSlots))
        slot->setTimerDuration(timerDuration);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : children) {
        QModelIndex ret = i.findGroup(g, model->index(row, 0, idx));
        row++;
        if (ret.isValid())
            return ret;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QModelIndex & i : sel)
        i = proxy_model->mapToSource(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            if (tc->getStats().multi_file_torrent)
                new KRun(QUrl::fromLocalFile(tc->getStats().output_path), 0, true);
            else
                new KRun(QUrl::fromLocalFile(tc->getDataDir()), 0, true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(default_opensearch_urls))
        {
            Out(SYS_SRC | LOG_DEBUG) << "Setting up default engine " << u.toDisplayString() << endl;
            QString dir = data_dir + u.host() + QLatin1Char('/');
            if (!bt::Exists(dir))
            {
                OpenSearchDownloadJob* j = new OpenSearchDownloadJob(u, dir, m_proxy);
                connect(j, SIGNAL(result(KJob*)), this, SLOT(openSearchDownloadJobFinished(KJob*)));
                j->start();
            }
            else
            {
                loadEngine(dir, dir, true);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tors))
            remove(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* f: qAsConst(to_remove))
        {
            bt::Delete(f->directory(), true);
            feeds.removeAll(f);
            delete f;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(files)) {
        order.insert(begin_row, file);
        begin_row++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        QModelIndex index = treeView->currentIndex();
        auto job = new KIO::OpenUrlJob(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(index))));
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, nullptr));
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tor : files) {
        if (!alreadyLoaded(d, tor))
            torrents.append(QUrl::fromLocalFile(d.absoluteFilePath(tor)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &grpName : groups) {
            const QString entryName = grpName + QLatin1String("Enabled");
            KConfigGroup grp = config->group(grpName);
            if (grp.hasKey(entryName)) {
                // bool is just for typing reasons - we know that there is a value
                pluginsGroup.writeEntry(entryName, grp.readEntry(entryName, true));
                grp.deleteEntry(entryName);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int v : qAsConst(values))
        {
            if (v >= 1)
            {
                QAction* act = addAction(QString::number(v));
                act->setCheckable(true);
                act->setChecked(rate == v);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](int val) {
        m_proxy->setFiltered(!val);
        setupModels();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerItem& c : qAsConst(conds)) {
        if (c.checked)
            rules->addRule(action, SPECIFIC_TORRENT, c.trigger, c.tc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(filters))
        if (f->filterName() == name)
            return f;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tor : qAsConst(downloads))
        {
            if (tor->getInfoHash() == ih)
            {
                TrackersList* ta = tor->getTrackersList();
                ta->merge(trk);
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indices) {
        bt::PeerInterface* peer = model->indexToPeer(pm->mapToSource(idx));
        if (peer)
            peer->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab & tab : tabs)
        {
            if (tab.action->isChecked())
            {
                tab.group = group;
                QString name = group->groupName() +  QStringLiteral(" %1/%2").arg(group->runningTorrents()).arg(group->totalTorrents());
                tab.action->setText(name);
                tab.action->setIcon(group->groupIcon());
                edit_group_policy->setEnabled(!group->isStandardGroup());
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::UPnPRouter *r : qAsConst(routers))
            r->undoForward(port, wjob);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tor : *qman) {
        torrentAdded(tor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        names.append(tc->getDisplayName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(sel)) {
        tc->scrapeTracker();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : idx_list) {
        const WebSeedInterface *ws = tc->getWebSeed(proxy_model->mapToSource(idx).row());
        if (ws && ws->isUserCreated()) {
            if (!tc->removeWebSeed(ws->getUrl()))
                KMessageBox::error(this, i18n("Cannot remove webseed %1, it is part of the torrent.", ws->getUrl().toDisplayString()));
        }
    }
```

#### AUTO 


```{c}
const auto update_if_differs = [&](auto &target, const auto &source, int column){
            if (target != source) {
                to_update.append(model->index(row, column));
                target = source;
                ret |= (sort_column == column);
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const bt::TorrentInterface *tor : qAsConst(downloads)) {
        if (tor->getInfoHash() == ih)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& group: qAsConst(default_groups))
                addTab(gman->findByPath(group));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& t: trackers)
        {
            if (t.isEmpty())
                continue;

            QUrl url(t.trimmed());
            if (!url.isValid() || (url.scheme() != QLatin1String("udp")
                                && url.scheme() != QLatin1String("http")
                                && url.scheme() != QLatin1String("https")))
                invalid.append(t);
            else
            {
                if (!tracker_hints.contains(url.toDisplayString()))
                    tracker_hints.append(url.toDisplayString());
                urls.append(url);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(*qman)) {
        if (visible(tc)) {
            Item item = {tc, 0};
            queue.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
        {
            const TorrentStats& s = tc->getStats();
            if (s.running || tc->getJobQueue()->runningJobs() || !s.autostart)
                continue;

            todo.append(tc);
        }
```

#### AUTO 


```{c}
auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea *area : qAsConst(pages))
        area->page->updateSettings();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : interpreters)
        Out(SYS_SCR | LOG_DEBUG) << s << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files)
        play_list->addFile(collection->find(file));
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *i : *qman)
        torrentAdded(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
        {
            if (!n->file)
            {
                enc->write(n->name.toUtf8());
                enc->beginDict();
                n->saveExpandedState(pm->index(idx, 0, index), pm, tv, enc);
                enc->end();
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children)) {
            n->fillChunks();
            chunks.orBitSet(n->chunks);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter* f : qAsConst(filters)) {
        f->startMatching();
        const QList<Syndication::ItemPtr> items = feed->items();
        for (const Syndication::ItemPtr& item : items) {
            // Skip already loaded items
            if (loaded.contains(item->id()))
                continue;

            if (needToDownload(item, f)) {
                Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KParts::Part* part : parts) {
            if (part->domDocument().documentElement().attribute(QStringLiteral("name")) == p->parentPart()) {
                part->insertChildClient(p);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem* s: sel)
        {
            int r = m_tracker_list->row(s);
            if (r + 1 < m_tracker_list->count())
            {
                m_tracker_list->insertItem(r + 1, m_tracker_list->takeItem(r));
                m_tracker_list->setCurrentRow(r + 1);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *feed : qAsConst(feeds)) {
        if (feed->usingFilter(f))
            feed->runFilters();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *i : *qman) {
        torrentAdded(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(tmp))
                    tc->setMaxSeedTime(0.0f);
```

#### RANGE FOR STATEMENT 


```{c}
for (KParts::Part *part : parts) {
            if (part->domDocument().documentElement().attribute(QStringLiteral("name")) == p->parentPart()) {
                part->removeChildClient(p);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QModelIndex & i : sel)
            i = proxy_model->mapToSource(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (Tab &tab : tabs)
        tab.action->setText(tab.group->groupName() + QStringLiteral(" %1/%2").arg(tab.group->runningTorrents()).arg(tab.group->totalTorrents()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : idx_list) {
        if (!mman->isStopped(idx.row()))
            stop->setEnabled(true);
        else
            start->setEnabled(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface* ti : qAsConst(sel)) {
        g->addTorrent(ti, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(*qman)) {
        const TorrentStats &s = tc->getStats();
        speed_dl += s.download_rate;
        speed_ul += s.upload_rate;
        bytes_dl += s.session_bytes_downloaded;
        bytes_ul += s.session_bytes_uploaded;
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(pathToOpen));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        if (a->data().value<QObject *>() == act || act == nullptr) {
            a->setChecked(true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
        {
            if (index.isValid() && !dragged_items.contains(index.row()))
                dragged_items.append(index.row());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[core](const QString &) {core->applySettings();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : indices)
        {
            Script* s = scriptForIndex(idx);
            if (s && s->removeable())
                to_remove << s;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
                {
                    if (tc->getStats().running)
                        tc->networkUp();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (SearchWidget* s : qAsConst(searches)) {
        if (w == s) {
//              s->find();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& exp : qAsConst(word_matches)) {
        QRegExp tmp = exp;
        tmp.setCaseSensitivity(case_sensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
        tmp.setPatternSyntax(use_regular_expressions ? QRegExp::RegExp : QRegExp::Wildcard);
        if (all_word_matches_must_match) {
            if (!match(item->title(), tmp))
                return false;
            else
                found_match = true;
        } else if (match(item->title(), tmp)) {
            found_match = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        tc->scrapeTracker();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : files) {
        if (file.endsWith(QStringLiteral(".desktop"))) {
            return model->addScriptFromDesktopFile(dir_path, file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx: indices)
        {
            Script* s = model->scriptForIndex(idx);
            if (s && !s->packageDirectory().isEmpty())
                scripts_to_delete.append(s->name());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : sl_f) {
        addChild(root, s, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tor : files) {
        if (!alreadyLoaded(d, tor))
            torrents.append(QUrl::fromLocalFile(d.absoluteFilePath(tor)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : missing) {
        QListWidgetItem *lwi = new QListWidgetItem(m_file_list);
        lwi->setText(s);
        lwi->setIcon(QIcon::fromTheme(mimeDatabase.mimeTypeForFile(s).iconName()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads))
            tc->setAllowedToStart(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const net::Port& p : pl) {
            if (p.forward)
                r->undoForward(p);
        }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(index))));
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(stalled))
            Out(SYS_GEN | LOG_NOTICE) << "The torrent " << tc->getStats().torrent_name << " has stalled longer than " << min_stall_time << " minutes, decreasing its priority" << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents))
        {
            if (item->tc == ti)
            {
                removeRow(idx);
                update(view->viewDelegate(), true);
                break;
            }
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& m : sel) {
            to_del.append(QUrl::fromLocalFile(m_model->filePath(m_proxy->mapToSource(m))));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
        {
            if (tc->readyForPreview() && !tc->getStats().multi_file_torrent)
            {
                new KRun(QUrl::fromLocalFile(tc->getStats().output_path), 0, true);
            }
        }
```

#### AUTO 


```{c}
const auto update_if_differs = [&](auto & target, const auto & source, int column) {
        if (target != source) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    };
```

#### AUTO 


```{c}
auto it = std::sregex_iterator(line.begin(), line.end(), rx);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &subdir : dirs) {
            if (subdir != QStringLiteral(".") && subdir != QStringLiteral("..") && subdir != loaded_localized) {
                QCoreApplication::postEvent(this, new RecursiveScanEvent(QUrl::fromLocalFile(d.absoluteFilePath(subdir))));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea *area : qAsConst(pages))
        area->page->loadDefaults();
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel))
            group->removeTorrent(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n : qAsConst(children))
            s += n->bytesToDownload(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* t: qAsConst(trackers))
        {
            if (t->update())
                emit dataChanged(index(idx, 1), index(idx, 5));
            idx++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int v : qAsConst(values)) {
        if (v >= 1) {
            QAction* act = addAction(QString::number(v));
            act->setCheckable(true);
            act->setChecked(rate == v);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface *tc : qAsConst(downloads)) {
        const TorrentStats &s = tc->getStats();
        if (s.running || (tc->isAllowedToStart() && !s.stopped_by_error && !tc->getJobQueue()->runningJobs())) {
            if (s.completed) {
                if (s.running || (!tc->overMaxRatio() && !tc->overMaxSeedTime()))
                    seed_queue.append(tc);
            } else
                download_queue.append(tc);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : idx_list) {
        if (const MagnetDownloader *md = mman->getMagnetDownloader(idx.row())) {
            sl.append(md->magnetLink().toString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : qAsConst(folders)) {
        m_folders->addItem(new QListWidgetItem(QIcon::fromTheme(QStringLiteral("folder")), f));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* n : qAsConst(children))
                size += n->fileSize(tc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Syndication::ItemPtr &item : items) {
            // Skip already loaded items
            if (loaded.contains(item->id()))
                continue;

            if (needToDownload(item, f)) {
                Out(SYS_SYN | LOG_NOTICE) << "Downloading item " << item->title() << " (filter: " << f->filterName() << ")" << endl;
                downloadItem(item, f->group(), f->downloadLocation(), f->moveOnCompletionLocation(), f->openSilently());
            }
        }
```

#### AUTO 


```{c}
const auto queueCopy = queue;
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* i : *qman)
        {
            torrents.append(new Item(i));
            num_visible++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& idx : sel) {
            bt::TorrentFileInterface* tfi = model->indexToFile(proxy_model->mapToSource(idx));
            if (!tfi)
                continue;

            moves.insert(tfi, dir);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
        PlayListItem item = qMakePair(collection->find(url.toLocalFile()), (TagLib::FileRef*)0);
        files.insert(row, item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item & i : qAsConst(queue))
        i.tc->setPriority(idx--);
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(downloads)) {
        tc->setPriority(prio--);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& sdir : subdirs)
            {
                if (sdir != QStringLiteral("..") && sdir != QStringLiteral("."))
                {
                    QString absolute_path = d.absoluteFilePath(sdir);
                    Script* s = loadScriptDir(absolute_path);
                    if (s)
                    {
                        // Scripts in the home directory can be deleted
                        s->setRemoveable(absolute_path.startsWith(kt::DataDir()));
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item & i : item->children)
            i.row = row_index++;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file: files)
            play_list->addFile(collection->find(file));
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* s : sel)
        {
            QMap<QGraphicsItem*, ScheduleItem*>::iterator i = item_map.find(s);
            if (i != item_map.end())
            {
                ScheduleItem* si = i.value();
                scene->removeItem(s);
                item_map.erase(i);
                schedule->removeItem(si);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &child : qAsConst(children)) {
        child.expandedGroups(gview, groups, model->index(row, 0, idx));
        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(downloads)) {
                if (tc->getStats().running)
                    tc->networkUp();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &exp : qAsConst(exclusion_patterns)) {
        QRegExp tmp = exp;
        tmp.setCaseSensitivity(exclusion_case_sensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);
        tmp.setPatternSyntax(exclusion_reg_exp ? QRegExp::RegExp : QRegExp::Wildcard);
        if (exclusion_all_must_match) {
            if (!match(item->title(), tmp)) {
                found_match = false;
                break;
            } else
                found_match = true;
        } else if (match(item->title(), tmp))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TorrentInterface *ti : qAsConst(sel)) {
        g->addTorrent(ti, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface *tc : qAsConst(todo)) {
        const bt::TorrentStats &s = tc->getStats();
        removed_bytes_up += s.session_bytes_uploaded;
        removed_bytes_down += s.session_bytes_downloaded;

        QString dir = tc->getTorDir();

        try {
            if (data_to)
                tc->deleteDataFiles();
        } catch (Error &e) {
            gui->errorMsg(e.toString());
        }

        torrentRemoved(tc);
        gman->torrentRemoved(tc);
        try {
            bt::Delete(dir, false);
        } catch (Error &e) {
            gui->errorMsg(e.toString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        if (!index.isValid())
            continue;

        const bt::TorrentInterface *ti = torrentFromIndex(index);
        if (ti) {
            QString hash = ti->getInfoHash().toString();
            if (!hashes.contains(hash)) {
                hashes.append(hash);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem *s : sel) {
        QMap<QGraphicsItem *, ScheduleItem *>::iterator i = item_map.find(s);
        if (i != item_map.end()) {
            ScheduleItem *si = i.value();
            scene->removeItem(s);
            item_map.erase(i);
            schedule->removeItem(si);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PrefPageScrollArea* area : qAsConst(pages))
        area->page->loadDefaults();
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            bt::TrackerInterface* trk = selectedTracker();
            if (trk)
                QApplication::clipboard()->setText(trk->trackerURL().toDisplayString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TrackerInterface* trk : tracker_list)
            {
                trackers.append(new Item(trk));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(todo))
            {
                const TorrentStats& s = tc->getStats();
                if (!s.completed && !tc->checkDiskSpace(false))
                {
                    names.append(s.torrent_name);
                    tmp.append(tc);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item *t : qAsConst(trackers)) {
        if (t->update())
            Q_EMIT dataChanged(index(idx, 1), index(idx, 5));
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script *s : qAsConst(scripts)) {
            if (s->packageDirectory() == dest_dir)
                throw bt::Error(i18n("There is already a script package named %1 installed.", dir->name()));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](auto &target, const auto &source, int column) {
        if (target != source) {
            to_update.append(model->index(row, column));
            target = source;
            ret |= (sort_column == column);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& w : words)
            {
                if (w.startsWith(QLatin1String("http://")) || w.startsWith(QLatin1String("https://")) || w.startsWith(QLatin1String("ftp://")))
                    w = QStringLiteral("<a href=\"") + w + QStringLiteral("\">") + w + QStringLiteral("</a>");
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleItem* i : qAsConst(items)) {
        if (i->contains(now)) {
            return i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &u : qAsConst(default_opensearch_urls)) {
        Out(SYS_SRC | LOG_DEBUG) << "Setting up default engine " << u.toDisplayString() << endl;
        QString dir = data_dir + u.host() + QLatin1Char('/');
        if (!bt::Exists(dir)) {
            OpenSearchDownloadJob* j = new OpenSearchDownloadJob(u, dir, m_proxy);
            connect(j, &OpenSearchDownloadJob::result, this, &SearchEngineList::openSearchDownloadJobFinished);
            j->start();
        } else {
            loadEngine(dir, dir, true);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](QDBusPendingCallWatcher * callWatcher) {
            QDBusPendingReply<void> reply = *callWatcher;
            if (reply.isValid()) {
                screensaver_cookie = 0;
                Out(SYS_MPL | LOG_NOTICE) << "Screensaver uninhibited" << endl;
            } else Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit screensaver" << endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Script* s: qAsConst(scripts))
                if (s->scriptFile() == file)
                    return;
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed* f: qAsConst(feeds))
            {
                if (f->feedUrl() == feed_url)
                {
                    found = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::UPnPRouter* r : qAsConst(routers))
            r->undoForward(port, wjob);
```

#### RANGE FOR STATEMENT 


```{c}
for (Uint32 file : qAsConst(order)) {
        // skip file if it is complete
        if (std::fabs(100.0f - tor->getTorrentFile(file).getDownloadPercentage()) < 0.01)
            continue;

        // skip excluded or only seed files
        if (tor->getTorrentFile(file).getPriority() < LAST_PRIORITY)
            continue;

        // we have found the incomplete file
        return file;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : files) {
        // look for the desktop file
        if (!file.endsWith(QStringLiteral(".desktop")) && !file.endsWith(QStringLiteral(".DESKTOP")))
            continue;

        // check for duplicate packages
        QString dest_dir = kt::DataDir() + QStringLiteral("scripts/") + dir->name() + QLatin1Char('/');
        for (Script* s : qAsConst(scripts)) {
            if (s->packageDirectory() == dest_dir)
                throw bt::Error(i18n("There is already a script package named %1 installed.", dir->name()));
        }

        // extract to the scripts dir
        dir->copyTo(dest_dir, true);
        if (!addScriptFromDesktopFile(dest_dir, file))
            throw bt::Error(i18n("Failed to load script from archive. There is something wrong with the desktop file."));

        return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry &e : qAsConst(ip_list)) {
        if (e.start <= ip && ip <= e.end)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sd : qAsConst(subdirs)) {
            // Load only if there is an opensearch.xml file and not a removed file
            if (bt::Exists(data_dir + sd + QStringLiteral("/opensearch.xml")) && !bt::Exists(data_dir + sd + QStringLiteral("/removed"))) {
                Out(SYS_SRC | LOG_DEBUG) << "Loading " << sd << endl;
                SearchEngine *se = new SearchEngine(data_dir + sd + QLatin1Char('/'));
                if (!se->load(data_dir + sd + QStringLiteral("/opensearch.xml")))
                    delete se;
                else
                    engines.append(se);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (bt::TorrentInterface* tc : qAsConst(sel)) {
        if (core->checkMissingFiles(tc))
            tc->changeOutputDir(dir, bt::TorrentInterface::MOVE_FILES);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QDBusPendingCallWatcher *callWatcher) { QDBusPendingReply<void> reply = *callWatcher; if (reply.isValid()) { screensaver_cookie = 0; Out(SYS_MPL | LOG_NOTICE) << "Screensaver uninhibited" << endl; } else Out(SYS_MPL | LOG_IMPORTANT) << "Failed uninhibit screensaver" << endl; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : sel) {
        if (idx.isValid() && idx.row() >= 0 && idx.row() < engines.count())
            to_remove.append(engines.at(idx.row()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* item : qAsConst(torrents)) {
            if (item->visible(group, filter_string))
                if (!a(item->tc))
                    break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Item* i: qAsConst(items))
        {
            if (i->changed())
            {
                if (lowest == -1)
                    lowest = idx;
                highest = idx;
            }
            idx++;
        }
```

