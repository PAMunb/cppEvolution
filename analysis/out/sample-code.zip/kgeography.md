#### RANGE FOR STATEMENT 


```{c}
for (const QString &mapFilename : mapFiles) {
		KGmap *m = p_reader.parseMap(mapFilename);
		if (!m)
			errorTexts << i18n("Error parsing %1: %2", mapFilename, p_reader.getError());
		else
		{
			QString text = m -> getName();
			KGmap* existingMap = p_maps.value(text);
			if (existingMap)
			{
				errorTexts << i18n("The map %1 has the same name of map %2", mapFilename, existingMap -> getFile());
				delete m;
			}
			else
			{
				texts << text;
				p_maps.insert(text, m);
				if ( mapFilename == lastMapFile )
					stringToSelect = text;
			}
		}
	}
```

