#### RANGE FOR STATEMENT 


```{c}
for (Planet *home : m_game->planets()) {
        if (home->player() != this) {
            continue;
        }

        int minimumDefenceFleetSize = getMinimumDefenceFleetSize(home, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction);
        int surplusFleetSize = home->ships() - minimumDefenceFleetSize; // can be negative

        Planet* closestUpstreamPlanet = home;
        double closestUpstreamDistance = DBL_MAX;

        Planet* closestSupportPlanet = home;
        double closestSupportDistance = DBL_MAX;

        QMultiMap<double, TargetPlanet> targetList;

        for (Planet *other : m_game->planets()) {
            if (other->player() == this) {
                if (other != home) {

                    // We found one of our own planets which is not the current
                    // planet.

                    double distance = m_game->map()->distance(home, other);

                    if (distance <= closestUpstreamDistance) {

                        // The planet is closer. Check if it has a higher
                        // kill percentage. We just want to find the closest
                        // planet with a higher kill percentage.

                        if (other->killPercentage() > home->killPercentage()) {
                            closestUpstreamPlanet = other;
                            closestUpstreamDistance = distance;
                        }
                    }

                    if (distance <= closestSupportDistance) {

                        // The planet is closer. Check if it needs support.

                        if (other->ships() < getMinimumDefenceFleetSize(other, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction)) {
                            closestSupportPlanet = other;
                            closestSupportDistance = distance;
                        }
                    }
                }
            }
            else {

                // We found an enemy planet.

                // Do not send a fleet to the planet if a fleet is already on
                // its way.

                bool found = false;

                for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if (fleet->destination == other) {
                        found = true;
                        break;
                    }
                }

                if (found != true) {
                    double distance = m_game->map()->distance(home, other);

                    int production;
                    bool isNeutral;

                    if (other->player()->isNeutral()) {
                        production = m_game->options().NeutralsProduction;
                        isNeutral = true;
                    }
                    else {
                        production = other->production();
                        isNeutral = false;
                    }

                    double killPercentageOther = other->killPercentage();
                    double killPercentageHome = home->killPercentage();

                    // Avoid division by zero. Right now, these cases are only
                    // possible by manually altering game conditions at the
                    // beginning.

                    if (killPercentageOther < 0.1) {
                        killPercentageOther = 0.1;
                    }

                    if (killPercentageHome < 0.1) {
                        killPercentageOther = 0.1;
                    }

                    /**
                     * @todo The production increment in cumultative games is
                     * not considered here.
                     */

                    int minimumAttackFleetToConquerPlanet = std::ceil((other->ships() + std::ceil(distance) * production) * killPercentageOther / killPercentageHome);

                    if (minimumAttackFleetToConquerPlanet == 0) {

                        // In case neutral planets have a production of zero,
                        // we would need a fleet of size zero to conquer them.
                        // As this does not work we use a minimum attack fleet
                        // size of one.

                        ++minimumAttackFleetToConquerPlanet;
                    }

                    // Prefer closer targets to further away targets (distance
                    // penalty).

                    /**
                     * @todo Instead of a distance penalty, simply consider the
                     * production we could get from the closer planet due to
                     * saved transit time compared to what we save in attack
                     * ships.
                     */

                    /**
                     * @todo Maybe not take the weakest we can get (first on
                     * list), but the strongest we can get.
                     */

                    /**
                     * @todo The universe is flat, so prefer planets at the
                     * edge. They have less closer neightbours than centrally
                     * located planets!
                     */

                    /**
                     * @todo If we have a choice, attack the strongest player.
                     * This way our empire can expand and at the end, we do not
                     * have to face fighting a superpower.
                     */

                    double planetScore = minimumAttackFleetToConquerPlanet * distance;

                    // Try to prefer higher production and higher kill percentage.

                    planetScore *= 1 / (killPercentageOther / averageOwnKillPercentage);
                    planetScore *= 1 / (other->production() / averageOwnProduction);

                    // Prefer attacking non-neutral planets.
                    // Neutrals don't harm us, enemies do.

                    if (isNeutral) {

                        // Penalty for neutral planets!
                        // Multiply the score with the defence so that closer
                        // planets are higher ranked (smaller value).

                        targetList.insert(1.1 * planetScore, TargetPlanet(other, minimumAttackFleetToConquerPlanet, distance));
                    }
                    else {
                        targetList.insert(1.0 * planetScore, TargetPlanet(other, minimumAttackFleetToConquerPlanet, distance));
                    }
                }
            }
        }

        // Process the first few possible targets from the target list. As this
        // is a priority list, only consider the first few ones and do not
        // process possible targets with low priority (high score).

        QMapIterator<double, TargetPlanet> targetListIt(targetList);

        int skipCount = 3;

        while (targetListIt.hasNext() && (skipCount > 0)) {
            targetListIt.next();

            // Always decrement the skip counter. If an attack can be launched
            // successfully, simply increment it again as this is no skip then.

            --skipCount;

            Planet *attackPlanet = targetListIt.value().planet();
            int minimumAttackFleetToConquerPlanet = targetListIt.value().minimumAttackFleetToConquerPlanet();
            double distance = targetListIt.value().distance();

            if (closestUpstreamPlanet != home) {

                // We know that there is an own planet with higher kill
                // percentage. Do not attack other planet if that one is quite
                // far away compared to upstream planet.

                if (distance > 2 * closestUpstreamDistance) {
                    continue;
                }
            }

            if (surplusFleetSize > 0) {

                // We actually have more ships than required for defence,
                // so we can start an attack.

                if (surplusFleetSize > minimumAttackFleetToConquerPlanet) {

                    // We now know that we can conquer the planet with our home
                    // fleet. Now, figure out how many ships we need and
                    // actually want to send.

                    // Send as many ships as needed to conquer the planet and to
                    // build up a "proper" defence fleet. If we do not have that
                    // many ships, send our whole surplus fleet.

                    /**
                     * @todo Maybe first check if we can attack all targets, and
                     * if we still have a surplus, use that one distributed
                     * across all targets!
                     */

                    int attackFleetSize = 0;
                    int minimumActualDefenceFleetSize = getMinimumDefenceFleetSize(attackPlanet, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction);

                    if (surplusFleetSize > minimumAttackFleetToConquerPlanet + minimumActualDefenceFleetSize) {
                        attackFleetSize = minimumAttackFleetToConquerPlanet + minimumActualDefenceFleetSize;
                    }
                    else
                    if (surplusFleetSize > minimumAttackFleetToConquerPlanet) {

                        // We actually can conquer the planet. So send as much
                        // as we have of surplus.

                        attackFleetSize = surplusFleetSize;
                    }

                    if (attackFleetSize > 0) {
                        //qDebug() << "Attacking " << attackPlanet->name() << " from " << home->name() << " with " << attackFleetSize << ".";
                        m_game->attack(home, attackPlanet, attackFleetSize);

                        surplusFleetSize -= attackFleetSize;
                        ++skipCount;
                    }
                }
            }
            else {

                // Either our surplus fleet size is negative and we actually
                // need supply, or our surplus fleet is not large enough
                // to successfully conquer this planet.

            }
        }

        // If we still have surplus now, this is likely because we are out of
        // close targets. Either use surplus for support or send it upstream.

        if (closestSupportPlanet != home) {
            if (closestSupportDistance < 2 * closestUpstreamDistance) {

                // Send ships to support the other planet, but only if that
                // planet is not much further away than our upstream planet.

                // And only send support if not another planet sent support
                // already. So for now, just check if there is an incoming
                // friendly attack fleet.

                bool skip = false;

                for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if ((fleet->destination == closestSupportPlanet) && (fleet->owner == this)) {
                        skip = true;
                        break;
                    }
                }

                if (!skip) {

                    // Additionally add as much as one round of production.

                    // Or better not, as that just makes this planet look like
                    // requiring support from others.

                    // surplusFleetSize += home->production();

                    if (surplusFleetSize > 0) {

                        // Send complete surplus fleet. This could be more than
                        // the support planet actually needs (or less), but for
                        // now this is good enough.

                        //qDebug() << "Supporting (support) " << closestSupportPlanet->name() << " from " << home->name() << " with " << surplusFleetSize << ".";
                        m_game->attack(home, closestSupportPlanet, surplusFleetSize);

                        // We do not have any surplus fleet anymore to send
                        // upsteam.

                        surplusFleetSize = 0;
                    }
                }
            }
        }

        if (closestUpstreamPlanet != home) {

            // Send ships in larger chunks. Having defence on our planets makes
            // them less attractive for enemy attacks. And having more than the
            // minimum defence allows giving support to other planets, if
            // needed.

            if (surplusFleetSize > 3 * home->production()) { // > 0) {
                //qDebug() << "Supporting (upstream) " << closestUpstreamPlanet->name() << " from " << home->name() << " with " << surplusFleetSize << ".";
                m_game->attack(home, closestUpstreamPlanet, surplusFleetSize);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Fleet *fleet : this->attackList()) {
        totalOwnFleet += fleet->shipCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *attack : m_game->planets()) {
                    if (attack->player() == this)
                        continue;

                    bool    skip = false;
                    double  dist = m_game->map()->distance( home, attack );

                    if (dist < minDistance && attack->ships() < ships ) {
                        for (AttackFleet *curFleet : attackList()) {
                            if (curFleet->destination == attack) {
                                skip = true;
                                break;
                            }
                        }
                        if (skip)
                            continue;

                        target      = attack;
                        hasAttack   = true;
                        minDistance = dist;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (AttackFleet *curFleet : attackList()) {
                            if (curFleet->destination == attack) {
                                skip = true;
                                break;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *home : m_game->planets()) {
        if (home->player() == this) {
            bool  hasAttack = false;
            ships = (int)floor(home->ships() * 0.7 );

            if (ships >= minimumShips) {
                double  minDistance = 100;

                for (Planet *attack : m_game->planets()) {
                    if (attack->player() == this)
                        continue;

                    bool    skip = false;
                    double  dist = m_game->map()->distance( home, attack );

                    if (dist < minDistance && attack->ships() < ships ) {
                        for (AttackFleet *curFleet : attackList()) {
                            if (curFleet->destination == attack) {
                                skip = true;
                                break;
                            }
                        }
                        if (skip)
                            continue;

                        target      = attack;
                        hasAttack   = true;
                        minDistance = dist;
                    }
                }

                if (hasAttack) {
                    m_game->attack( home, target, ships );
                } else {
                    minDistance = DBL_MAX;
                    int shipsToSend = 0;
                    bool hasDestination = false;

                    for (Planet *attack : m_game->planets()) {
                        bool    skip = false;
                        double  dist = m_game->map()->distance( home, attack );
                        int     homeships = (int)floor(home->ships() * 0.5 );

                        if (dist < minDistance
                            && attack->player() == this
                            && attack->ships() < homeships ) {
                            for (AttackFleet *curFleet : attackList()) {
                                if (curFleet->destination == attack) {
                                    skip = true;
                                    break;
                                }
                            }
                            if (skip)
                                continue;

                            shipsToSend = (int)floor( double(home->ships()
                                                             - attack->ships()) / shipCountFactor);

                            target         = attack;
                            hasDestination = true;
                            minDistance    = dist;
                        }
                    }
                    if (hasDestination) {
                        m_game->attack( home, target, shipsToSend );
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AttackFleet *curFleet : attackList()) {
                                if (curFleet->destination == attack) {
                                    skip = true;
                                    break;
                                }
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if ((fleet->destination == closestSupportPlanet) && (fleet->owner == this)) {
                        skip = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Player *player : m_game->players()) {
        player->resetTurnStats();

        for (AttackFleet *fleet : player->attackList()) {
            if (m_game->doFleetArrival(fleet)) {
                player->attackDone(fleet);
                fleet->deleteLater();
            }
            else {

                // Only add the number of ships of the fleet to the player's
                // total fleet size if the fleet does not arrive this turn.

                player->statShipCount(fleet->shipCount());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *planet : m_game->planets())
        if (planet->player() == this)
            return false;
```

#### RANGE FOR STATEMENT 


```{c}
for (Player *player : players()) {
        if (player->isNeutral() || player->isSpectator()) {
            continue;
        }
        if (!player->isDead()) {
            if (winner) {
                //qDebug() << "Ok, returning 0";
                return;
            } else {
                winner = player;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int &fleetSize : qAsConst(nonOwnPlanetDefenceFleetSizeList)) {
        averageNonOwnPlanetDefenceFleetSize += fleetSize;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *planet : m_game->planets()) {
        totalTotalPlanets += 1;

        if (planet->player() == this) {

            // We found a planet of us.

            totalOwnProduction += planet->production();
            totalOwnPlanets += 1;
            totalOwnFleet += planet->fleet().shipCount();

            totalKillPercentage += planet->killPercentage();
        }
        else {
            if (planet->player()->isNeutral() != true) {

                // We found a non-neutral enemy planet.

                totalEnemyProduction += planet->production();
                totalEnemyPlanets += 1;
                totalEnemyDefence += planet->fleet().shipCount();
            }

            nonOwnPlanetDefenceFleetSizeList.push_back(planet->fleet().shipCount());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if (fleet->destination == other) {
                        found = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *attack : m_game->planets()) {
                        bool    skip = false;
                        double  dist = m_game->map()->distance( home, attack );
                        int     homeships = (int)floor(home->ships() * 0.5 );

                        if (dist < minDistance
                            && attack->player() == this
                            && attack->ships() < homeships ) {
                            for (AttackFleet *curFleet : attackList()) {
                                if (curFleet->destination == attack) {
                                    skip = true;
                                    break;
                                }
                            }
                            if (skip)
                                continue;

                            shipsToSend = (int)floor( double(home->ships()
                                                             - attack->ships()) / shipCountFactor);

                            target         = attack;
                            hasDestination = true;
                            minDistance    = dist;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *planet : m_game->map()->planets()) {
        //qDebug() << "Turn for planet " << planet->name();
        planet->turn(m_game->options());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int &fleetSize : std::as_const(nonOwnPlanetDefenceFleetSizeList)) {
        averageNonOwnPlanetDefenceFleetSize += fleetSize;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *home : m_game->planets()) {
        if (home->player() != this) {
            continue;
        }

        int minimumDefenceFleetSize = getMinimumDefenceFleetSize(home, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction);
        int surplusFleetSize = home->ships() - minimumDefenceFleetSize; // can be negative

        Planet* closestUpstreamPlanet = home;
        double closestUpstreamDistance = DBL_MAX;

        Planet* closestSupportPlanet = home;
        double closestSupportDistance = DBL_MAX;

        QMultiMap<double, TargetPlanet> targetList;

        for (Planet *other : m_game->planets()) {
            if (other->player() == this) {
                if (other != home) {

                    // We found one of our own planets which is not the current
                    // planet.

                    double distance = m_game->map()->distance(home, other);

                    if (distance <= closestUpstreamDistance) {

                        // The planet is closer. Check if it has a higher
                        // kill percentage. We just want to find the closest
                        // planet with a higher kill percentage.

                        if (other->killPercentage() > home->killPercentage()) {
                            closestUpstreamPlanet = other;
                            closestUpstreamDistance = distance;
                        }
                    }

                    if (distance <= closestSupportDistance) {

                        // The planet is closer. Check if it needs support.

                        if (other->ships() < getMinimumDefenceFleetSize(other, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction)) {
                            closestSupportPlanet = other;
                            closestSupportDistance = distance;
                        }
                    }
                }
            }
            else {

                // We found an enemy planet.

                // Do not send a fleet to the planet if a fleet is already on
                // its way.

                bool found = false;

                for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if (fleet->destination == other) {
                        found = true;
                        break;
                    }
                }

                if (found != true) {
                    double distance = m_game->map()->distance(home, other);

                    int production;
                    bool isNeutral;

                    if (other->player()->isNeutral()) {
                        production = m_game->options().NeutralsProduction;
                        isNeutral = true;
                    }
                    else {
                        production = other->production();
                        isNeutral = false;
                    }

                    double killPercentageOther = other->killPercentage();
                    double killPercentageHome = home->killPercentage();

                    // Avoid division by zero. Right now, these cases are only
                    // possible by manually altering game conditions at the
                    // beginning.

                    if (killPercentageOther < 0.1) {
                        killPercentageOther = 0.1;
                    }

                    if (killPercentageHome < 0.1) {
                        killPercentageOther = 0.1;
                    }

                    /**
                     * @todo The production increment in cumultative games is
                     * not considered here.
                     */

                    int minimumAttackFleetToConquerPlanet = std::ceil((other->ships() + std::ceil(distance) * production) * killPercentageOther / killPercentageHome);

                    if (minimumAttackFleetToConquerPlanet == 0) {

                        // In case neutral planets have a production of zero,
                        // we would need a fleet of size zero to conquer them.
                        // As this does not work we use a minimum attack fleet
                        // size of one.

                        ++minimumAttackFleetToConquerPlanet;
                    }

                    // Prefer closer targets to further away targets (distance
                    // penalty).

                    /**
                     * @todo Instead of a distance penalty, simply consider the
                     * production we could get from the closer planet due to
                     * saved transit time compared to what we save in attack
                     * ships.
                     */

                    /**
                     * @todo Maybe not take the weakest we can get (first on
                     * list), but the strongest we can get.
                     */

                    /**
                     * @todo The universe is flat, so prefer planets at the
                     * edge. They have less closer neightbours than centrally
                     * located planets!
                     */

                    /**
                     * @todo If we have a choice, attack the strongest player.
                     * This way our empire can expand and at the end, we do not
                     * have to face fighting a superpower.
                     */

                    double planetScore = minimumAttackFleetToConquerPlanet * distance;

                    // Try to prefer higher production and higher kill percentage.

                    planetScore *= 1 / (killPercentageOther / averageOwnKillPercentage);
                    planetScore *= 1 / (other->production() / averageOwnProduction);

                    // Prefer attacking non-neutral planets.
                    // Neutrals don't harm us, enemies do.

                    if (isNeutral) {

                        // Penalty for neutral planets!
                        // Multiply the score with the defence so that closer
                        // planets are higher ranked (smaller value).

                        targetList.insert(1.1 * planetScore, TargetPlanet(other, minimumAttackFleetToConquerPlanet, distance));
                    }
                    else {
                        targetList.insert(1.0 * planetScore, TargetPlanet(other, minimumAttackFleetToConquerPlanet, distance));
                    }
                }
            }
        }

        // Process the first few possible targets from the target list. As this
        // is a priority list, only consider the first few ones and do not
        // process possible targets with low priority (high score).
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
        QMapIterator<double, TargetPlanet> targetListIt(targetList);
#else
        QMultiMapIterator<double, TargetPlanet> targetListIt(targetList);
#endif
        int skipCount = 3;

        while (targetListIt.hasNext() && (skipCount > 0)) {
            targetListIt.next();

            // Always decrement the skip counter. If an attack can be launched
            // successfully, simply increment it again as this is no skip then.

            --skipCount;

            Planet *attackPlanet = targetListIt.value().planet();
            int minimumAttackFleetToConquerPlanet = targetListIt.value().minimumAttackFleetToConquerPlanet();
            double distance = targetListIt.value().distance();

            if (closestUpstreamPlanet != home) {

                // We know that there is an own planet with higher kill
                // percentage. Do not attack other planet if that one is quite
                // far away compared to upstream planet.

                if (distance > 2 * closestUpstreamDistance) {
                    continue;
                }
            }

            if (surplusFleetSize > 0) {

                // We actually have more ships than required for defence,
                // so we can start an attack.

                if (surplusFleetSize > minimumAttackFleetToConquerPlanet) {

                    // We now know that we can conquer the planet with our home
                    // fleet. Now, figure out how many ships we need and
                    // actually want to send.

                    // Send as many ships as needed to conquer the planet and to
                    // build up a "proper" defence fleet. If we do not have that
                    // many ships, send our whole surplus fleet.

                    /**
                     * @todo Maybe first check if we can attack all targets, and
                     * if we still have a surplus, use that one distributed
                     * across all targets!
                     */

                    int attackFleetSize = 0;
                    int minimumActualDefenceFleetSize = getMinimumDefenceFleetSize(attackPlanet, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction);

                    if (surplusFleetSize > minimumAttackFleetToConquerPlanet + minimumActualDefenceFleetSize) {
                        attackFleetSize = minimumAttackFleetToConquerPlanet + minimumActualDefenceFleetSize;
                    }
                    else
                    if (surplusFleetSize > minimumAttackFleetToConquerPlanet) {

                        // We actually can conquer the planet. So send as much
                        // as we have of surplus.

                        attackFleetSize = surplusFleetSize;
                    }

                    if (attackFleetSize > 0) {
                        //qDebug() << "Attacking " << attackPlanet->name() << " from " << home->name() << " with " << attackFleetSize << ".";
                        m_game->attack(home, attackPlanet, attackFleetSize);

                        surplusFleetSize -= attackFleetSize;
                        ++skipCount;
                    }
                }
            }
            else {

                // Either our surplus fleet size is negative and we actually
                // need supply, or our surplus fleet is not large enough
                // to successfully conquer this planet.

            }
        }

        // If we still have surplus now, this is likely because we are out of
        // close targets. Either use surplus for support or send it upstream.

        if (closestSupportPlanet != home) {
            if (closestSupportDistance < 2 * closestUpstreamDistance) {

                // Send ships to support the other planet, but only if that
                // planet is not much further away than our upstream planet.

                // And only send support if not another planet sent support
                // already. So for now, just check if there is an incoming
                // friendly attack fleet.

                bool skip = false;

                for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if ((fleet->destination == closestSupportPlanet) && (fleet->owner == this)) {
                        skip = true;
                        break;
                    }
                }

                if (!skip) {

                    // Additionally add as much as one round of production.

                    // Or better not, as that just makes this planet look like
                    // requiring support from others.

                    // surplusFleetSize += home->production();

                    if (surplusFleetSize > 0) {

                        // Send complete surplus fleet. This could be more than
                        // the support planet actually needs (or less), but for
                        // now this is good enough.

                        //qDebug() << "Supporting (support) " << closestSupportPlanet->name() << " from " << home->name() << " with " << surplusFleetSize << ".";
                        m_game->attack(home, closestSupportPlanet, surplusFleetSize);

                        // We do not have any surplus fleet anymore to send
                        // upsteam.

                        surplusFleetSize = 0;
                    }
                }
            }
        }

        if (closestUpstreamPlanet != home) {

            // Send ships in larger chunks. Having defence on our planets makes
            // them less attractive for enemy attacks. And having more than the
            // minimum defence allows giving support to other planets, if
            // needed.

            if (surplusFleetSize > 3 * home->production()) { // > 0) {
                //qDebug() << "Supporting (upstream) " << closestUpstreamPlanet->name() << " from " << home->name() << " with " << surplusFleetSize << ".";
                m_game->attack(home, closestUpstreamPlanet, surplusFleetSize);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AttackFleet *fleet : player->attackList()) {
            if (m_game->doFleetArrival(fleet)) {
                player->attackDone(fleet);
                fleet->deleteLater();
            }
            else {

                // Only add the number of ships of the fleet to the player's
                // total fleet size if the fleet does not arrive this turn.

                player->statShipCount(fleet->shipCount());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Player *curPlayer : players) {
        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->name());
        item->setData(Qt::DecorationRole, curPlayer->color());
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 0, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->shipsBuilt());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 1, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->planetsConquered());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 2, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->fleetsLaunched());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 3, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->enemyFleetsDestroyed());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 4, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->enemyShipsDestroyed());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 5, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->turnProduction());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 6, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, curPlayer->turnShips());
        item->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        item->setFlags(Qt::ItemIsEnabled);
        m_standingsTable->setItem(row, 7, item);

        ++row;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Planet *other : m_game->planets()) {
            if (other->player() == this) {
                if (other != home) {

                    // We found one of our own planets which is not the current
                    // planet.

                    double distance = m_game->map()->distance(home, other);

                    if (distance <= closestUpstreamDistance) {

                        // The planet is closer. Check if it has a higher
                        // kill percentage. We just want to find the closest
                        // planet with a higher kill percentage.

                        if (other->killPercentage() > home->killPercentage()) {
                            closestUpstreamPlanet = other;
                            closestUpstreamDistance = distance;
                        }
                    }

                    if (distance <= closestSupportDistance) {

                        // The planet is closer. Check if it needs support.

                        if (other->ships() < getMinimumDefenceFleetSize(other, minimumBaseDefenceFleetSize, averageOwnKillPercentage, averageOwnProduction)) {
                            closestSupportPlanet = other;
                            closestSupportDistance = distance;
                        }
                    }
                }
            }
            else {

                // We found an enemy planet.

                // Do not send a fleet to the planet if a fleet is already on
                // its way.

                bool found = false;

                for (AttackFleet *fleet : this->attackList() + this->newAttacks()) {
                    if (fleet->destination == other) {
                        found = true;
                        break;
                    }
                }

                if (found != true) {
                    double distance = m_game->map()->distance(home, other);

                    int production;
                    bool isNeutral;

                    if (other->player()->isNeutral()) {
                        production = m_game->options().NeutralsProduction;
                        isNeutral = true;
                    }
                    else {
                        production = other->production();
                        isNeutral = false;
                    }

                    double killPercentageOther = other->killPercentage();
                    double killPercentageHome = home->killPercentage();

                    // Avoid division by zero. Right now, these cases are only
                    // possible by manually altering game conditions at the
                    // beginning.

                    if (killPercentageOther < 0.1) {
                        killPercentageOther = 0.1;
                    }

                    if (killPercentageHome < 0.1) {
                        killPercentageOther = 0.1;
                    }

                    /**
                     * @todo The production increment in cumultative games is
                     * not considered here.
                     */

                    int minimumAttackFleetToConquerPlanet = std::ceil((other->ships() + std::ceil(distance) * production) * killPercentageOther / killPercentageHome);

                    if (minimumAttackFleetToConquerPlanet == 0) {

                        // In case neutral planets have a production of zero,
                        // we would need a fleet of size zero to conquer them.
                        // As this does not work we use a minimum attack fleet
                        // size of one.

                        ++minimumAttackFleetToConquerPlanet;
                    }

                    // Prefer closer targets to further away targets (distance
                    // penalty).

                    /**
                     * @todo Instead of a distance penalty, simply consider the
                     * production we could get from the closer planet due to
                     * saved transit time compared to what we save in attack
                     * ships.
                     */

                    /**
                     * @todo Maybe not take the weakest we can get (first on
                     * list), but the strongest we can get.
                     */

                    /**
                     * @todo The universe is flat, so prefer planets at the
                     * edge. They have less closer neightbours than centrally
                     * located planets!
                     */

                    /**
                     * @todo If we have a choice, attack the strongest player.
                     * This way our empire can expand and at the end, we do not
                     * have to face fighting a superpower.
                     */

                    double planetScore = minimumAttackFleetToConquerPlanet * distance;

                    // Try to prefer higher production and higher kill percentage.

                    planetScore *= 1 / (killPercentageOther / averageOwnKillPercentage);
                    planetScore *= 1 / (other->production() / averageOwnProduction);

                    // Prefer attacking non-neutral planets.
                    // Neutrals don't harm us, enemies do.

                    if (isNeutral) {

                        // Penalty for neutral planets!
                        // Multiply the score with the defence so that closer
                        // planets are higher ranked (smaller value).

                        targetList.insert(1.1 * planetScore, TargetPlanet(other, minimumAttackFleetToConquerPlanet, distance));
                    }
                    else {
                        targetList.insert(1.0 * planetScore, TargetPlanet(other, minimumAttackFleetToConquerPlanet, distance));
                    }
                }
            }
        }
```

