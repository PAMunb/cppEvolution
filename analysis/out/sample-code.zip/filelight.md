#### RANGE FOR STATEMENT 


```{c}
for (const File *child : files) {
            if (child->isFolder()) {
                ret->append(((Folder *)child)->duplicate());
            } else {
                ret->append(child->name8Bit(), child->size());
            }
        }
```

#### AUTO 


```{c}
auto dialog = new SettingsDialog(nullptr);
```

#### AUTO 


```{c}
auto iconLabel = new QLabel(this);
```

#### AUTO 


```{c}
auto *job = new KTerminalLauncherJob(QString(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : std::as_const(*m_trees)) {
                if (new_path == folder->name8Bit()) {
                    qDebug() << "Tree pre-completed: " << folder->decodedName();
                    d = folder;
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname.constData());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : string.split(QLatin1Char('\n'))) {
                tooltipHeight += fontMetrics.height();
                tooltipWidth = qMax(tooltipWidth, fontMetrics.width(part));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](Label *item1, Label *item2) {
        //you add 1440 to work round the fact that later you want the circle split vertically
        //and as it is you start at 3 o' clock. It's to do with rightPrevY, stops annoying bug

        int angle1 = (item1)->angle + 1440;
        int angle2 = (item2)->angle + 1440;

        // Also sort by level
        if (angle1 == angle2)
                return (item1->lvl > item2->lvl);

        if (angle1 > 5760) angle1 -= 5760;
        if (angle2 > 5760) angle2 -= 5760;

        return (angle1 < angle2);

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (!storage.isReady() || ignoredFsTypes.contains(storage.fileSystemType())) {
            continue;
        }

        Disk disk;
        disk.mount = storage.rootPath();
        disk.name = storage.name();
        disk.size = storage.bytesTotal();
        disk.free = storage.bytesAvailable();
        disk.used = disk.size - disk.free;

        // if something is mounted over same path, last mounted point would be used since only it is currently reachable.
        (*this)[disk.mount] = disk;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : subCaches) {
        m_cache.append(folder);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (!storage.isReady() || ignoredFsTypes.contains(storage.fileSystemType())) {
            continue;
        }

        Disk disk;
        disk.mount = storage.rootPath();
        disk.name = storage.name();
        disk.size = storage.bytesTotal();
        disk.free = storage.bytesFree();
        disk.used = disk.size - disk.free;

        *this += disk;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](File *a, File *b) {
        return a->size() > b->size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[i]) {
            if (m_summary){ // Summary view has its own colors, special cased.
                if (segment->file()->name() == QLatin1String("Used")) {
                    cb = QApplication::palette().highlight().color();
                    cb.getHsv(&h, &s1, &v1);

                    if (s1 > 80)
                        s1 = 80;

                    v2 = v1 - int(contrast * v1);
                    s2 = s1 + int(contrast * (255 - s1));

                    cb.setHsv(h, s1, v1);
                    cp.setHsv(h, s2, v2);
                }
                else
                {
                    cp = Qt::gray;
                    cb = Qt::white;
                }

                segment->setPalette(cp, cb);
            }
            else
            {
                switch (Config::scheme)
                {
                case Filelight::KDE:
                {
                    //gradient will work by figuring out rgb delta values for 360 degrees
                    //then each component is angle*delta

                    int a = segment->start();

                    if (a > 2880) a = 2880 - (a - 2880);

                    h  = (int)(deltaRed   * a) + kdeColour[1].red();
                    s1 = (int)(deltaGreen * a) + kdeColour[1].green();
                    v1 = (int)(deltaBlue  * a) + kdeColour[1].blue();

                    cb.setRgb(h, s1, v1);
                    cb.getHsv(&h, &s1, &v1);

                    break;
                }

                case Filelight::HighContrast:
                    cp.setHsv(0, 0, 0); //values of h, s and v are irrelevant
                    cb.setHsv(180, 0, int(255.0 * contrast));
                    segment->setPalette(cp, cb);
                    continue;

                default:
                    h  = int(segment->start() / 16);
                    s1 = 160;
                    v1 = (int)(255.0 / darkness); //****doing this more often than once seems daft!
                }

                v2 = v1 - int(contrast * v1);
                s2 = s1 + int(contrast * (255 - s1));

                if (s1 < 80) s1 = 80; //can fall too low and makes contrast between the files hard to discern

                if (segment->isFake()) //multi-file
                {
                    cb.setHsv(h, s2, (v2 < 90) ? 90 : v2); //too dark if < 100
                    cp.setHsv(h, 17, v1);
                }
                else if (!segment->file()->isFolder()) //file
                {
                    cb.setHsv(h, 17, v1);
                    cp.setHsv(h, 17, v2);
                }
                else //folder
                {
                    cb.setHsv(h, s1, v1); //v was 225
                    cp.setHsv(h, s2, v2); //v was 225 - delta
                }

                segment->setPalette(cp, cb);

                //TODO:
                //**** may be better to store KDE colours as H and S and vary V as others
                //**** perhaps make saturation difference for s2 dependent on contrast too
                //**** fake segments don't work with highContrast
                //**** may work better with cp = cb rather than Qt::white
                //**** you have to ensure the grey of files is sufficient, currently it works only with rainbow (perhaps use contrast there too)
                //**** change v1,v2 to vp, vb etc.
                //**** using percentages is not strictly correct as the eye doesn't work like that
                //**** darkness factor is not done for kde_colour scheme, and also value for files is incorrect really for files in this scheme as it is not set like rainbow one is
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](Label *item1, Label *item2) {
        // you add 1440 to work round the fact that later you want the circle split vertically
        // and as it is you start at 3 o' clock. It's to do with rightPrevY, stops annoying bug

        int angle1 = (item1)->angle + 1440;
        int angle2 = (item2)->angle + 1440;

        // Also sort by level
        if (angle1 == angle2) {
            return (item1->level > item2->level);
        }

        if (angle1 > 5760)
            angle1 -= 5760;
        if (angle2 > 5760)
            angle2 -= 5760;

        return (angle1 < angle2);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Label *label : list) {
                range = qMax(range, label->level);

                //**** better way would just be to assign if nothing is range
            }
```

#### AUTO 


```{c}
auto freeBuffer = qScopeGuard([buffer] { LocalFree(buffer); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &label : std::as_const(list)) {
        if (varySizes) {
            //**** how much overhead in making new QFont each time?
            //     (implicate sharing remember)
            font.setPointSize(sizes[label->level]);
            paint.setFont(font);
        }

        paint.drawLine(label->targetX, label->targetY, label->middleX, label->startY);
        paint.drawLine(label->middleX, label->startY, label->startX, label->startY);

        paint.drawText(label->textX, label->textY, label->qs);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *d : std::as_const(returnedCwds)) {
        if (d) { // then scan was successful
            cwd->append(d);
        }
    }
```

#### AUTO 


```{c}
auto new_path = m_pathW + L"/" + name;
```

#### LAMBDA EXPRESSION 


```{c}
[action, object] {
            object->setProperty("enabled", action->isEnabled());
        }
```

#### AUTO 


```{c}
auto ac = new KActionCollection(this, QStringLiteral("dummycollection"));
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url);
```

#### LAMBDA EXPRESSION 


```{c}
[buffer] { LocalFree(buffer); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[x]) {
            // draw the pie segments, most of this code is concerned with drawing the little
            // arrows on the ends of segments when they have hidden files
            paint.setPen(segment->pen());

            paint.setPen(segment->pen());
            paint.setBrush(segment->brush());
            paint.drawPie(rect, segment->start(), segment->length());

            if (!segment->hasHiddenChildren()) {
                continue;
            }

            // draw arrow head to indicate undisplayed files/directories
            QPolygonF pts;
            QPointF pos, cpos = rect.center();
            uint a[3] = {segment->start(), segment->length(), 0};

            a[2] = a[0] + (a[1] / 2); // assign to halfway between
            if (a[1] > a_max) {
                a[1] = a_max;
                a[0] = a[2] - a_max / 2;
            }

            a[1] += a[0];

            for (int i = 0, radius = width; i < 3; ++i) {
                double ra = M_PI / (180 * 16) * a[i], sinra, cosra;

                if (i == 2) {
                    radius += MAP_HIDDEN_TRIANGLE_SIZE;
                }

                sincos(ra, &sinra, &cosra);
                pos.rx() = cpos.x() + cosra * radius;
                pos.ry() = cpos.y() - sinra * radius;
                pts << pos;
            }

            paint.setBrush(segment->pen());
            paint.drawPolygon(pts);

            // Draw outline on the arc for hidden children
            QPen pen = paint.pen();
            pen.setCapStyle(Qt::FlatCap);
            int width = 2;
            pen.setWidth(width);
            paint.setPen(pen);
            QRectF rect2 = rect;
            width /= 2;
            rect2.adjust(width, width, -width, -width);
            paint.drawArc(rect2, segment->start(), segment->length());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &msg) { statusBar()->showMessage(msg); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const File *child : files) {
            if (child->isFolder()) {
                ret->append(((Folder*)child)->duplicate());
            } else {
                ret->append(child->name8Bit(), child->size());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : *m_trees)
            {
                if (new_path == folder->name8Bit())
                {
                    qDebug() << "Tree pre-completed: " << folder->decodedName();
                    d = folder;
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[i]) {
            switch (Config::scheme) {
                case Filelight::KDE: {
                        //gradient will work by figuring out rgb delta values for 360 degrees
                        //then each component is angle*delta

                        int a = segment->start();

                        if (a > 2880) a = 2880 - (a - 2880);

                        h  = (int)(deltaRed   * a) + kdeColour[1].red();
                        s1 = (int)(deltaGreen * a) + kdeColour[1].green();
                        v1 = (int)(deltaBlue  * a) + kdeColour[1].blue();

                        cb.setRgb(h, s1, v1);
                        cb.getHsv(&h, &s1, &v1);

                        break;
                    }

                case Filelight::HighContrast:
                    cp.setHsv(0, 0, 0); //values of h, s and v are irrelevant
                    cb.setHsv(180, 0, int(255.0 * contrast));
                    segment->setPalette(cp, cb);
                    continue;

                default:
                    h  = int(segment->start() / 16);
                    s1 = 160;
                    v1 = (int)(255.0 / darkness); //****doing this more often than once seems daft!
            }

            v2 = v1 - int(contrast * v1);
            s2 = s1 + int(contrast * (255 - s1));

            if (s1 < 80) s1 = 80; //can fall too low and makes contrast between the files hard to discern

            if (segment->isFake()) { //multi-file
                cb.setHsv(h, s2, (v2 < 90) ? 90 : v2); //too dark if < 100
                cp.setHsv(h, 17, v1);
            } else if (!segment->file()->isFolder()) { //file
                cb.setHsv(h, 17, v1);
                cp.setHsv(h, 17, v2);
            } else { //folder
                cb.setHsv(h, s1, v1); //v was 225
                cp.setHsv(h, s2, v2); //v was 225 - delta
            }

            segment->setPalette(cp, cb);

            //TODO:
            //**** may be better to store KDE colours as H and S and vary V as others
            //**** perhaps make saturation difference for s2 dependent on contrast too
            //**** fake segments don't work with highContrast
            //**** may work better with cp = cb rather than Qt::white
            //**** you have to ensure the grey of files is sufficient, currently it works only with rainbow (perhaps use contrast there too)
            //**** change v1,v2 to vp, vb etc.
            //**** using percentages is not strictly correct as the eye doesn't work like that
            //**** darkness factor is not done for kde_colour scheme, and also value for files is incorrect really for files in this scheme as it is not set like rainbow one is
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &label : std::as_const(list)) {
                range = qMax(range, label->level);

                //**** better way would just be to assign if nothing is range
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](Label *item1, Label *item2) {
        // you add 1440 to work round the fact that later you want the circle split vertically
        // and as it is you start at 3 o' clock. It's to do with rightPrevY, stops annoying bug

        int angle1 = (item1)->angle + 1440;
        int angle2 = (item2)->angle + 1440;

        // Also sort by level
        if (angle1 == angle2) {
            return (item1->level > item2->level);
        }

        if (angle1 > 5760) {
            angle1 -= 5760;
        }
        if (angle2 > 5760) {
            angle2 -= 5760;
        }

        return (angle1 < angle2);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainUrl](QObject *obj, const QUrl &objUrl) {
            if (!obj && mainUrl == objUrl) {
                qWarning() << "Failed to load QML dialog.";
                abort();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_combo->returnPressed(QString());
    }
```

#### AUTO 


```{c}
const auto volumes = QStorageInfo::mountedVolumes();
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url, QStringLiteral("inode/directory"), nullptr);
```

#### AUTO 


```{c}
auto freeBuffer = qScopeGuard([buffer] {
        LocalFree(buffer);
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto segment : std::as_const(m_signature[x])) {
            // draw the pie segments, most of this code is concerned with drawing the little
            // arrows on the ends of segments when they have hidden files
            paint.setPen(segment->pen());

            paint.setPen(segment->pen());
            paint.setBrush(segment->brush());
            paint.drawPie(rect, segment->start(), segment->length());

            if (!segment->hasHiddenChildren()) {
                continue;
            }

            // draw arrow head to indicate undisplayed files/directories
            QPolygonF pts;
            QPointF pos;
            QPointF cpos = rect.center();
            std::array<uint, 3> a{segment->start(), segment->length(), 0};

            a[2] = a[0] + (a[1] / 2); // assign to halfway between
            if (a[1] > a_max) {
                a[1] = a_max;
                a[0] = a[2] - a_max / 2;
            }

            a[1] += a[0];

            for (int i = 0, radius = width; i < 3; ++i) {
                if (i == 2) {
                    radius += MAP_HIDDEN_TRIANGLE_SIZE;
                }

                double ra = M_PI / (180 * 16) * a[i];
                double sinra = 0.0;
                double cosra = 0.0;
                sincos(ra, &sinra, &cosra);
                pos.rx() = cpos.x() + cosra * radius;
                pos.ry() = cpos.y() - sinra * radius;
                pts << pos;
            }

            paint.setBrush(segment->pen());
            paint.drawPolygon(pts);

            // Draw outline on the arc for hidden children
            QPen pen = paint.pen();
            pen.setCapStyle(Qt::FlatCap);
            int width = 2;
            pen.setWidth(width);
            paint.setPen(pen);
            QRectF rect2 = rect;
            width /= 2;
            rect2.adjust(width, width, -width, -width);
            paint.drawArc(rect2, segment->start(), segment->length());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *d : std::as_const(returnedCwds)) {
        if (d) { //then scan was successful
            cwd->append(d);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_map.m_signature[0]) {
            if (segment->length() > 288) {
                list.append(new Label(segment, 0));

            }
        }
```

#### AUTO 


```{c}
auto updateRunning = [this] {
            if (m_remoteLister && m_remoteLister->isFinished()) {
                m_remoteLister = nullptr;
                Q_EMIT runningChanged();
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (File *file : dir->files) {
        if (file->size() < m_limits[depth] * 6) { // limit is half a degree? we want at least 3 degrees
            hiddenSize += file->size();
            if (file->isFolder()) { //**** considered virtual, but dir wouldn't count itself!
                hiddenFileCount += static_cast<const Folder *>(file)->children(); // need to add one to count the dir as well
            }
            ++hiddenFileCount;
            continue;
        }

        unsigned int a_len = (unsigned int)(5760 * ((double)file->size() / (double)m_root->size()));

        Segment *s = new Segment(file, a_start, a_len);
        m_signature[depth].append(s);

        if (file->isFolder()) {
            if (depth != m_visibleDepth) {
                // recurse
                s->m_hasHiddenChildren = build((Folder *)file, depth + 1, a_start, a_start + a_len);
            } else {
                s->m_hasHiddenChildren = true;
            }
        }

        a_start += a_len; //**** should we add 1?
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (File *file : dir->files) {
        if (file->isFolder() && file->size() > m_minSize) {
            findVisibleDepth((Folder *)file, currentDepth + 1); //if no files greater than min size the depth is still recorded
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[x]) {
            //draw the pie segments, most of this code is concerned with drawing the little
            //arrows on the ends of segments when they have hidden files
            paint.setPen(segment->pen());

            paint.setPen(segment->pen());
            paint.setBrush(segment->brush());
            paint.drawPie(rect, segment->start(), segment->length());

            if (!segment->hasHiddenChildren()) {
                continue;
            }

            //draw arrow head to indicate undisplayed files/directories
            QPolygon pts(3);
            QPoint pos, cpos = rect.center();
            uint a[3] = { segment->start(), segment->length(), 0 };

            a[2] = a[0] + (a[1] / 2); //assign to halfway between
            if (a[1] > a_max)
            {
                a[1] = a_max;
                a[0] = a[2] - a_max / 2;
            }

            a[1] += a[0];

            for (int i = 0, radius = width; i < 3; ++i) {
                double ra = M_PI/(180*16) * a[i], sinra, cosra;

                if (i == 2) {
                    radius += MAP_HIDDEN_TRIANGLE_SIZE;
                }

                sincos(ra, &sinra, &cosra);
                pos.rx() = cpos.x() + static_cast<int>(cosra * radius);
                pos.ry() = cpos.y() - static_cast<int>(sinra * radius);
                pts.setPoint(i, pos);
            }

            paint.setBrush(segment->pen());
            paint.drawPolygon(pts);

            // Draw outline on the arc for hidden children
            QPen pen = paint.pen();
            pen.setCapStyle(Qt::FlatCap);
            int width = 2;
            pen.setWidth(width);
            paint.setPen(pen);
            QRect rect2 = rect;
            width /= 2;
            rect2.adjust(width, width, -width, -width);
            paint.drawArc(rect2, segment->start(), segment->length());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : volumes) {
        if (storage.isRoot()) {
            continue;
        }

        QString path = storage.rootPath();
        if (!path.endsWith(QLatin1Char('/'))) {
            path += QLatin1Char('/');
        }

        if (Config::remoteFsTypes.contains(storage.fileSystemType()) && !s_remoteMounts.contains(path)) {
            s_remoteMounts.append(path);
        } else if (!s_localMounts.contains(path)) {
            s_localMounts.append(path);
        }
    }
```

#### AUTO 


```{c}
auto newStore = propagate(m_store.get(), m_root);
```

#### AUTO 


```{c}
static auto l10nContext = new KLocalizedContext(engine);
```

#### AUTO 


```{c}
static constexpr auto arbitraryTinySpacing = 8;
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *d : returnedCwds) {
        if (d) { //then scan was successful
            cwd->append(d);
        }
    }
```

#### AUTO 


```{c}
auto buttonLayout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](File *a, File*b) { return a->size() > b->size(); }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto arbitraryTinySpacing = 8;
```

#### AUTO 


```{c}
const auto segment
```

#### AUTO 


```{c}
const auto &label
```

#### AUTO 


```{c}
auto engine = new QQmlApplicationEngine(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : DirectoryIterator(tree)) {
            qDebug() << entry.name;
            QVERIFY(!entries.contains(entry.name));
            entries.insert(entry.name, entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (File *file : dir->files) {
        if (file->size() < m_limits[depth] * 6) { // limit is half a degree? we want at least 3 degrees
            hiddenSize += file->size();
            if (file->isFolder()) { //**** considered virtual, but dir wouldn't count itself!
                hiddenFileCount += static_cast<const Folder*>(file)->children(); //need to add one to count the dir as well
            }
            ++hiddenFileCount;
            continue;
        }

        unsigned int a_len = (unsigned int)(5760 * ((double)file->size() / (double)m_root->size()));

        Segment *s = new Segment(file, a_start, a_len);
        m_signature[depth].append(s);

        if (file->isFolder()) {
            if (depth != m_visibleDepth) {
                //recurse
                s->m_hasHiddenChildren = build((Folder*)file, depth + 1, a_start, a_start + a_len);
            } else {
                s->m_hasHiddenChildren = true;
            }
        }

        a_start += a_len; //**** should we add 1?
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[i]) {
            switch (Config::scheme)
            {
                case Filelight::KDE:
                    {
                        //gradient will work by figuring out rgb delta values for 360 degrees
                        //then each component is angle*delta

                        int a = segment->start();

                        if (a > 2880) a = 2880 - (a - 2880);

                        h  = (int)(deltaRed   * a) + kdeColour[1].red();
                        s1 = (int)(deltaGreen * a) + kdeColour[1].green();
                        v1 = (int)(deltaBlue  * a) + kdeColour[1].blue();

                        cb.setRgb(h, s1, v1);
                        cb.getHsv(&h, &s1, &v1);

                        break;
                    }

                case Filelight::HighContrast:
                    cp.setHsv(0, 0, 0); //values of h, s and v are irrelevant
                    cb.setHsv(180, 0, int(255.0 * contrast));
                    segment->setPalette(cp, cb);
                    continue;

                default:
                    h  = int(segment->start() / 16);
                    s1 = 160;
                    v1 = (int)(255.0 / darkness); //****doing this more often than once seems daft!
            }

            v2 = v1 - int(contrast * v1);
            s2 = s1 + int(contrast * (255 - s1));

            if (s1 < 80) s1 = 80; //can fall too low and makes contrast between the files hard to discern

            if (segment->isFake()) //multi-file
            {
                cb.setHsv(h, s2, (v2 < 90) ? 90 : v2); //too dark if < 100
                cp.setHsv(h, 17, v1);
            }
            else if (!segment->file()->isFolder()) //file
            {
                cb.setHsv(h, 17, v1);
                cp.setHsv(h, 17, v2);
            }
            else //folder
            {
                cb.setHsv(h, s1, v1); //v was 225
                cp.setHsv(h, s2, v2); //v was 225 - delta
            }

            segment->setPalette(cp, cb);

            //TODO:
            //**** may be better to store KDE colours as H and S and vary V as others
            //**** perhaps make saturation difference for s2 dependent on contrast too
            //**** fake segments don't work with highContrast
            //**** may work better with cp = cb rather than Qt::white
            //**** you have to ensure the grey of files is sufficient, currently it works only with rainbow (perhaps use contrast there too)
            //**** change v1,v2 to vp, vb etc.
            //**** using percentages is not strictly correct as the eye doesn't work like that
            //**** darkness factor is not done for kde_colour scheme, and also value for files is incorrect really for files in this scheme as it is not set like rainbow one is
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[i]) {
            switch (Config::scheme) {
            case Filelight::KDE: {
                // gradient will work by figuring out rgb delta values for 360 degrees
                // then each component is angle*delta

                int a = segment->start();

                if (a > 2880)
                    a = 2880 - (a - 2880);

                h = (int)(deltaRed * a) + kdeColour[1].red();
                s1 = (int)(deltaGreen * a) + kdeColour[1].green();
                v1 = (int)(deltaBlue * a) + kdeColour[1].blue();

                cb.setRgb(h, s1, v1);
                cb.getHsv(&h, &s1, &v1);

                break;
            }

            case Filelight::HighContrast:
                cp.setHsv(0, 0, 0); // values of h, s and v are irrelevant
                cb.setHsv(180, 0, int(255.0 * contrast));
                segment->setPalette(cp, cb);
                continue;

            default:
                h = int(segment->start() / 16);
                s1 = 160;
                v1 = (int)(255.0 / darkness); //****doing this more often than once seems daft!
            }

            v2 = v1 - int(contrast * v1);
            s2 = s1 + int(contrast * (255 - s1));

            if (s1 < 80)
                s1 = 80; // can fall too low and makes contrast between the files hard to discern

            if (segment->isFake()) { // multi-file
                cb.setHsv(h, s2, (v2 < 90) ? 90 : v2); // too dark if < 100
                cp.setHsv(h, 17, v1);
            } else if (!segment->file()->isFolder()) { // file
                cb.setHsv(h, 17, v1);
                cp.setHsv(h, 17, v2);
            } else { // folder
                cb.setHsv(h, s1, v1); // v was 225
                cp.setHsv(h, s2, v2); // v was 225 - delta
            }

            segment->setPalette(cp, cb);

            // TODO:
            //**** may be better to store KDE colours as H and S and vary V as others
            //**** perhaps make saturation difference for s2 dependent on contrast too
            //**** fake segments don't work with highContrast
            //**** may work better with cp = cb rather than Qt::white
            //**** you have to ensure the grey of files is sufficient, currently it works only with rainbow (perhaps use contrast there too)
            //**** change v1,v2 to vp, vb etc.
            //**** using percentages is not strictly correct as the eye doesn't work like that
            //**** darkness factor is not done for kde_colour scheme, and also value for files is incorrect really for files in this scheme as it is not set
            // like rainbow one is
        }
```

#### AUTO 


```{c}
const auto parts = string.split(QLatin1Char('\n'));
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : *m_trees)
            {
                if (new_path == folder->name8Bit())
                {
                    qDebug() << "Tree pre-completed: " << folder->name();
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (File *file : dir->files) {
        if (file->size() < m_limits[depth] * 6) { // limit is half a degree? we want at least 3 degrees
            hiddenSize += file->size();
            if (file->isFolder()) { //**** considered virtual, but dir wouldn't count itself!
                hiddenFileCount += dynamic_cast<const Folder *>(file)->children(); // need to add one to count the dir as well
            }
            ++hiddenFileCount;
            continue;
        }

        auto a_len = (unsigned int)(5760 * ((double)file->size() / (double)m_root->size()));

        auto *s = new Segment(file, a_start, a_len);
        m_signature[depth].append(s);

        if (file->isFolder()) {
            if (depth != m_visibleDepth) {
                // recurse
                s->m_hasHiddenChildren = build(dynamic_cast<Folder *>(file), depth + 1, a_start, a_start + a_len);
            } else {
                s->m_hasHiddenChildren = true;
            }
        }

        a_start += a_len; //**** should we add 1?
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_map.m_signature[depth]) {
                    if (segment->intersects(a)) {
                        return segment;
                    }
                }
```

#### AUTO 


```{c}
auto ret = new Folder(m_name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (storage.isRoot()) {
            continue;
        }

        QString path = storage.rootPath();
        if (!path.endsWith(QLatin1Char('/'))) {
            path += QLatin1Char('/');
        }

        if (remoteFsTypes.contains(storage.fileSystemType()) && !s_remoteMounts.contains(path)) {
            s_remoteMounts.append(path);
        } else if (!s_localMounts.contains(path)) {
            s_localMounts.append(path);
        }
    }
```

#### AUTO 


```{c}
auto *trees = new QList<Folder *>;
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto newStore = propagate(m_store.get(), m_root); newStore != m_store) {
            // We need to clean up old stores
            m_store = newStore;
        }
```

#### AUTO 


```{c}
const auto &item
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (m_remoteLister && m_remoteLister->isFinished()) {
                m_remoteLister = nullptr;
                Q_EMIT runningChanged();
            }
        }
```

#### AUTO 


```{c}
auto welcomeLabel = new QLabel(i18nc("@title", "Welcome to Filelight"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : *m_trees)
            {
                if (new_path == folder->name8Bit())
                {
                    qDebug() << "Tree pre-completed: " << folder->decodedName();
                    d = folder;
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname.constData());
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_map.resize(QRectF(x(), y(), width(), height()))) {
            m_timer.setSingleShot(true);
        }
        m_timer.start(500); // will cause signature to rebuild for new size

        // always do these as they need to be initialised on creation
        m_offset.rx() = (width() - m_map.width()) / 2;
        m_offset.ry() = (height() - m_map.height()) / 2;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Label *label : list) {
        if (varySizes) {
            //**** how much overhead in making new QFont each time?
            //     (implicate sharing remember)
            font.setPointSize(sizes[label->level]);
            paint.setFont(font);
        }

        paint.drawLine(label->targetX, label->targetY, label->middleX, label->startY);
        paint.drawLine(label->middleX, label->startY, label->startX, label->startY);

        QString text = label->qs;
        paint.drawText(label->textX, label->textY, text);
    }
```

#### AUTO 


```{c}
auto *buttons = new QDialogButtonBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : *m_map.m_signature) {
            if (segment->length() > 288) {
                list.append(new Label(segment, 0));
                
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (File *file : dir->files) {
        if (file->isFolder() && file->size() > m_minSize) {
            findVisibleDepth((Folder *)file, currentDepth + 1); // if no files greater than min size the depth is still recorded
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<Segment *> &segments : m_signature) {
        qDeleteAll(segments);
    }
```

#### AUTO 


```{c}
auto action = ac->action(name);
```

#### AUTO 


```{c}
const auto attributes = fileAttributeData.dwFileAttributes;
```

#### AUTO 


```{c}
auto about = new About(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[i]) {
            if (m_summary){ // Summary view has its own colors, special cased.
                if (segment->file()->decodedName() == QLatin1String("Used")) {
                    cb = QApplication::palette().highlight().color();
                    cb.getHsv(&h, &s1, &v1);

                    if (s1 > 80)
                        s1 = 80;

                    v2 = v1 - int(contrast * v1);
                    s2 = s1 + int(contrast * (255 - s1));

                    cb.setHsv(h, s1, v1);
                    cp.setHsv(h, s2, v2);
                }
                else
                {
                    cp = Qt::gray;
                    cb = Qt::white;
                }

                segment->setPalette(cp, cb);
            }
            else
            {
                switch (Config::scheme)
                {
                case Filelight::KDE:
                {
                    //gradient will work by figuring out rgb delta values for 360 degrees
                    //then each component is angle*delta

                    int a = segment->start();

                    if (a > 2880) a = 2880 - (a - 2880);

                    h  = (int)(deltaRed   * a) + kdeColour[1].red();
                    s1 = (int)(deltaGreen * a) + kdeColour[1].green();
                    v1 = (int)(deltaBlue  * a) + kdeColour[1].blue();

                    cb.setRgb(h, s1, v1);
                    cb.getHsv(&h, &s1, &v1);

                    break;
                }

                case Filelight::HighContrast:
                    cp.setHsv(0, 0, 0); //values of h, s and v are irrelevant
                    cb.setHsv(180, 0, int(255.0 * contrast));
                    segment->setPalette(cp, cb);
                    continue;

                default:
                    h  = int(segment->start() / 16);
                    s1 = 160;
                    v1 = (int)(255.0 / darkness); //****doing this more often than once seems daft!
                }

                v2 = v1 - int(contrast * v1);
                s2 = s1 + int(contrast * (255 - s1));

                if (s1 < 80) s1 = 80; //can fall too low and makes contrast between the files hard to discern

                if (segment->isFake()) //multi-file
                {
                    cb.setHsv(h, s2, (v2 < 90) ? 90 : v2); //too dark if < 100
                    cp.setHsv(h, 17, v1);
                }
                else if (!segment->file()->isFolder()) //file
                {
                    cb.setHsv(h, 17, v1);
                    cp.setHsv(h, 17, v2);
                }
                else //folder
                {
                    cb.setHsv(h, s1, v1); //v was 225
                    cp.setHsv(h, s2, v2); //v was 225 - delta
                }

                segment->setPalette(cp, cb);

                //TODO:
                //**** may be better to store KDE colours as H and S and vary V as others
                //**** perhaps make saturation difference for s2 dependent on contrast too
                //**** fake segments don't work with highContrast
                //**** may work better with cp = cb rather than Qt::white
                //**** you have to ensure the grey of files is sufficient, currently it works only with rainbow (perhaps use contrast there too)
                //**** change v1,v2 to vp, vb etc.
                //**** using percentages is not strictly correct as the eye doesn't work like that
                //**** darkness factor is not done for kde_colour scheme, and also value for files is incorrect really for files in this scheme as it is not set like rainbow one is
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : DirectoryIterator(m_tree.toUtf8())) {
            QVERIFY(!entries.contains(entry.name));
            entries.insert(entry.name, entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<Segment*> &segments : m_signature) {
        qDeleteAll(segments);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : *m_trees)
            {
                if (new_path == folder->name8Bit())
                {
                    qDebug() << "Tree pre-completed: " << folder->name();
                    d = folder;
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname);
                }
            }
```

#### AUTO 


```{c}
static constexpr auto arbitraryTinySpacing = 6;
```

#### RANGE FOR STATEMENT 


```{c}
for (File *file : dir->files) {
        if (file->isFolder() && file->size() > m_minSize) {
            findVisibleDepth(dynamic_cast<Folder *>(file), currentDepth + 1); // if no files greater than min size the depth is still recorded
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[buffer] {
        LocalFree(buffer);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i, &subDirectories, &semaphore, &returnedCwds]() {
            returnedCwds[i] = scan(subDirectories[i].first, subDirectories[i].second);
            semaphore.release(1);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto arbitraryTinySpacing = 6;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : string.split(QLatin1Char('\n'))) {
        tooltipHeight += fontMetrics.height();
        tooltipWidth = qMax(tooltipWidth, fontMetrics.boundingRect(part).width());
    }
```

#### AUTO 


```{c}
auto button = new QToolButton(this);
```

#### AUTO 


```{c}
const auto &segment
```

#### CONST EXPRESSION 


```{c}
static constexpr auto msToS = 1000;
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[x]) {
            //draw the pie segments, most of this code is concerned with drawing the little
            //arrows on the ends of segments when they have hidden files
            paint.setPen(segment->pen());

            paint.setPen(segment->pen());
            paint.setBrush(segment->brush());
            paint.drawPie(rect, segment->start(), segment->length());

            if (!segment->hasHiddenChildren()) {
                continue;
            }

            //draw arrow head to indicate undisplayed files/directories
            QPolygonF pts;
            QPointF pos, cpos = rect.center();
            uint a[3] = { segment->start(), segment->length(), 0 };

            a[2] = a[0] + (a[1] / 2); //assign to halfway between
            if (a[1] > a_max)
            {
                a[1] = a_max;
                a[0] = a[2] - a_max / 2;
            }

            a[1] += a[0];

            for (int i = 0, radius = width; i < 3; ++i) {
                double ra = M_PI/(180*16) * a[i], sinra, cosra;

                if (i == 2) {
                    radius += MAP_HIDDEN_TRIANGLE_SIZE;
                }

                sincos(ra, &sinra, &cosra);
                pos.rx() = cpos.x() + cosra * radius;
                pos.ry() = cpos.y() - sinra * radius;
                pts << pos;
            }

            paint.setBrush(segment->pen());
            paint.drawPolygon(pts);

            // Draw outline on the arc for hidden children
            QPen pen = paint.pen();
            pen.setCapStyle(Qt::FlatCap);
            int width = 2;
            pen.setWidth(width);
            paint.setPen(pen);
            QRectF rect2 = rect;
            width /= 2;
            rect2.adjust(width, width, -width, -width);
            paint.drawArc(rect2, segment->start(), segment->length());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (!storage.isReady() || storage.fileSystemType() == "tmpfs") {
            continue;
        }

        Disk disk;
        disk.mount = storage.rootPath();
        disk.name = storage.name();
        disk.size = storage.bytesTotal();
        disk.free = storage.bytesFree();
        disk.used = disk.size - disk.free;

        *this += disk;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_map.m_signature[depth]) {
                    if (segment->intersects(a))
                        return segment;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *folder : *m_trees)
            {
                if (new_path == folder->name8Bit())
                {
                    qCDebug(FILELIGHT_LOG) << "Tree pre-completed: " << folder->decodedName();
                    d = folder;
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname.constData());
                }
            }
```

#### AUTO 


```{c}
auto *mimedata = new QMimeData();
```

#### AUTO 


```{c}
const auto url = m_store->url;
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<Segment *> &segments : m_signature) {
            qDeleteAll(segments);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](Label *item1, Label *item2) {
        //you add 1440 to work round the fact that later you want the circle split vertically
        //and as it is you start at 3 o' clock. It's to do with rightPrevY, stops annoying bug

        int angle1 = (item1)->angle + 1440;
        int angle2 = (item2)->angle + 1440;

        // Also sort by level
        if (angle1 == angle2) {
                return (item1->level > item2->level);
        }

        if (angle1 > 5760) angle1 -= 5760;
        if (angle2 > 5760) angle2 -= 5760;

        return (angle1 < angle2);

    }
```

#### AUTO 


```{c}
auto a_len = (unsigned int)(5760 * ((double)file->size() / (double)m_root->size()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : string.split(QLatin1Char('\n'))) {
        tooltipHeight += fontMetrics.height();
        tooltipWidth = qMax(tooltipWidth, fontMetrics.horizontalAdvance(part));
    }
```

#### AUTO 


```{c}
auto *s = new Segment(file, a_start, a_len);
```

#### RANGE FOR STATEMENT 


```{c}
for (Label *label : list) {
        if (varySizes) {
            //**** how much overhead in making new QFont each time?
            //     (implicate sharing remember)
            font.setPointSize(sizes[label->level]);
            paint.setFont(font);
        }

        paint.drawLine(label->targetX, label->targetY, label->middleX, label->startY);
        paint.drawLine(label->middleX, label->startY, label->startX, label->startY);

        QString text = label->qs;
        if (isSummary() && text == QLatin1String("free")) text = i18nc("Free as in part of the disk that is free", "free");
        else if (isSummary() && text == QLatin1String("used")) text = i18nc("Used as in part of the disk that is used", "used");
        paint.drawText(label->textX, label->textY, text);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotAbortScan();
        showOverview();
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(url));
```

#### AUTO 


```{c}
auto cwd = new Folder(dirname.constData());
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : *m_map.m_signature) {
            if (segment->length() > 288) {
                list.append(new Label(segment, 0));

            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : string.split(QLatin1Char('\n'))) {
        tooltipHeight += fontMetrics.height();
        tooltipWidth = qMax(tooltipWidth, fontMetrics.width(part));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (!storage.isReady() || ignoredFsTypes.contains(storage.fileSystemType())) {
            continue;
        }

        // https://docs.flatpak.org/en/latest/sandbox-permissions.html
        // /var and friends are not useful paths. /var has some stuff mounted that isn't useful either
        static const bool inSandbox =
            !(QStandardPaths::locate(QStandardPaths::RuntimeLocation, QLatin1String("flatpak-info")).isEmpty() ||
              qEnvironmentVariableIsSet("SNAP"));
        const QString flatpakAppVar = QDir::homePath() + QLatin1String("/.var/app/");
        if ((inSandbox && (storage.isReadOnly())) || storage.rootPath().startsWith(QLatin1String("/var/")) ||
            storage.rootPath().startsWith(flatpakAppVar)) {
            continue;
        }

        Disk disk;
        disk.mount = storage.rootPath();
        disk.name = storage.name();
        disk.size = storage.bytesTotal();
        disk.free = storage.bytesAvailable();
        disk.used = disk.size - disk.free;

        // if something is mounted over same path, last mounted point would be used since only it is currently reachable.
        (*this)[disk.mount] = disk;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : parts) {
        tooltipHeight += fontMetrics.height();
        tooltipWidth = qMax(tooltipWidth, fontMetrics.horizontalAdvance(part));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Segment *segment : m_map.m_signature[i]) {
                if (segment->start() >= start && segment->end() <= end) {
                    if (segment->length() > minAngle) {
                        list.append(new Label(segment, i));
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : DirectoryIterator(QByteArrayLiteral("/tmp/filelighttest1312312312313123123123"))) {
            Q_UNUSED(entry);
            QVERIFY(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : DirectoryIterator(path)) {
        if (m_parent->m_abort) {
            return cwd;
        }

        if (entry.isSkipable) {
            continue;
        }

        if (entry.isFile) {
            cwd->append(entry.name.constData(), entry.size);
            m_parent->m_totalSize += entry.size;
        } else if (entry.isDir) {
            Folder *d = nullptr;
            const QByteArray new_dirname = entry.name + QByteArrayLiteral("/");
            const QByteArray new_path = path + entry.name + '/';

            // check to see if we've scanned this section already

            QMutexLocker lock(&m_treeMutex);
            for (Folder *folder : std::as_const(*m_trees)) {
                if (new_path == folder->name8Bit()) {
                    qDebug() << "Tree pre-completed: " << folder->decodedName();
                    d = folder;
                    m_trees->removeAll(folder);
                    m_parent->m_files += folder->children();
                    cwd->append(folder, new_dirname.constData());
                }
            }
            lock.unlock();

            if (!d) { // then scan
                // qDebug() << "Tree fresh" <<new_path << new_dirname;
                subDirectories.append({new_path, new_dirname});
            }
        }

        ++m_parent->m_files;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_signature[x]) {
            //draw the pie segments, most of this code is concerned with drawing the little
            //arrows on the ends of segments when they have hidden files

            paint.setPen(segment->pen());

            if (segment->hasHiddenChildren())
            {
                //draw arrow head to indicate undisplayed files/directories
                QPolygon pts(3);
                QPoint pos, cpos = rect.center();
                uint a[3] = { segment->start(), segment->length(), 0 };

                a[2] = a[0] + (a[1] / 2); //assign to halfway between
                if (a[1] > a_max)
                {
                    a[1] = a_max;
                    a[0] = a[2] - a_max / 2;
                }

                a[1] += a[0];

                for (int i = 0, radius = width; i < 3; ++i)
                {
                    double ra = M_PI/(180*16) * a[i], sinra, cosra;

                    if (i == 2)
                        radius += 5;
                    sincos(ra, &sinra, &cosra);
                    pos.rx() = cpos.x() + static_cast<int>(cosra * radius);
                    pos.ry() = cpos.y() - static_cast<int>(sinra * radius);
                    pts.setPoint(i, pos);
                }

                paint.setBrush(segment->pen());
                paint.drawPolygon(pts);
            }

            paint.setBrush(segment->brush());
            paint.drawPie(rect, segment->start(), segment->length());

            if (segment->hasHiddenChildren())
            {
                //**** code is bloated!
                paint.save();
                QPen pen = paint.pen();
                int width = 2;
                pen.setWidth(width);
                paint.setPen(pen);
                QRect rect2 = rect;
                width /= 2;
                rect2.adjust(width, width, -width, -width);
                paint.drawArc(rect2, segment->start(), segment->length());
                paint.restore();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<Segment*> &segments : m_signature) {
            qDeleteAll(segments);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        if (item.isDir()) {
            m_store->stores << std::make_shared<Store>(item.url(), item.name(), m_store);
        } else {
            m_store->folder->append(item.name().toUtf8().constData(), item.size());
            m_manager->m_totalSize += item.size();
        }

        m_manager->m_files++;
    }
```

#### AUTO 


```{c}
auto grp = stateConfig->group("general");
```

#### RANGE FOR STATEMENT 


```{c}
for (Segment *segment : m_map.m_signature[0]) {
            if (segment->length() > 288) {
                list.append(new Label(segment, 0));
            }
        }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url, QStringLiteral("inode/directory"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (storage.isRoot()) {
            continue;
        }

        QString path = storage.rootPath();
        if (!path.endsWith(QLatin1Char('/'))) {
            path += QLatin1Char('/');
        }

        if (Config::remoteFsTypes.contains(storage.fileSystemType()) && !s_remoteMounts.contains(path)) {
            s_remoteMounts.append(path);
        } else if (!s_localMounts.contains(path)) {
            s_localMounts.append(path);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ignorePath : std::as_const(list)) {
        if (ignorePath.startsWith(path)) {
            QString folderName = ignorePath;
            if (!folderName.endsWith(QLatin1Char('/'))) {
                folderName += QLatin1Char('/');
            }
            m_trees->append(new Folder(folderName.toLocal8Bit().constData()));
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
static constexpr auto msToS = 1000;
```

#### RANGE FOR STATEMENT 


```{c}
for (Label *label : list) {
        if (varySizes) {
            //**** how much overhead in making new QFont each time?
            //     (implicate sharing remember)
            font.setPointSize(sizes[label->level]);
            paint.setFont(font);
        }

        paint.drawLine(label->targetX, label->targetY, label->middleX, label->startY);
        paint.drawLine(label->middleX, label->startY, label->startX, label->startY);

        paint.drawText(label->textX, label->textY, label->qs);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ignorePath : qAsConst(list)) {
        if (ignorePath.startsWith(path)) {
            QString folderName = ignorePath;
            if (!folderName.endsWith(QLatin1Char('/'))) {
                folderName += QLatin1Char('/');
            }
            m_trees->append(new Folder(folderName.toLocal8Bit().constData()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &storage : QStorageInfo::mountedVolumes()) {
        if (!storage.isReady() || ignoredFsTypes.contains(storage.fileSystemType())) {
            continue;
        }

        Disk disk;
        disk.mount = storage.rootPath();
        disk.name = storage.name();
        disk.size = storage.bytesTotal();
        disk.free = storage.bytesFree();
        disk.used = disk.size - disk.free;

        // if something is mounted over same path, last mounted point would be used since only it is currently reachable.
        (*this)[disk.mount] = disk;
    }
```

#### AUTO 


```{c}
auto stateConfig = KSharedConfig::openStateConfig();
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : {QStringLiteral("go_back"), QStringLiteral("go_forward")}) {
        // Synthesize actions
        auto action = ac->action(name);
        Q_ASSERT(action);
        QQmlComponent component(engine, QUrl(QStringLiteral("qrc:/ui/Action.qml")));
        QObject *object = component.create();
        Q_ASSERT(object);
        object->setProperty("iconName", action->icon().name());
        object->setProperty("text", action->text());
        connect(object, SIGNAL(triggered()), action, SIGNAL(triggered()));
        connect(action, &QAction::changed, object, [action, object] {
            object->setProperty("enabled", action->isEnabled());
        });
        object->setProperty("enabled", action->isEnabled());
        object->setProperty("shortcut", action->shortcut());

        addHistoryAction(object);
    }
```

#### AUTO 


```{c}
const auto size = statbuf.st_blocks * S_BLKSIZE;
```

#### AUTO 


```{c}
const auto &name
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &segment : std::as_const(m_signature[i])) {
            switch (Config::scheme) {
            case Filelight::KDE: {
                // gradient will work by figuring out rgb delta values for 360 degrees
                // then each component is angle*delta

                int a = segment->start();

                if (a > 2880) {
                    a = 2880 - (a - 2880);
                }

                h = (int)(deltaRed * a) + kdeColour[1].red();
                s1 = (int)(deltaGreen * a) + kdeColour[1].green();
                v1 = (int)(deltaBlue * a) + kdeColour[1].blue();

                cb.setRgb(h, s1, v1);
                cb.getHsv(&h, &s1, &v1);

                break;
            }

            case Filelight::HighContrast:
                cp.setHsv(0, 0, 0); // values of h, s and v are irrelevant
                cb.setHsv(180, 0, int(255.0 * contrast));
                segment->setPalette(cp, cb);
                continue;

            default:
                h = int(segment->start() / 16);
                s1 = 160;
                v1 = (int)(255.0 / darkness); //****doing this more often than once seems daft!
            }

            v2 = v1 - int(contrast * v1);
            s2 = s1 + int(contrast * (255 - s1));

            if (s1 < 80) {
                s1 = 80; // can fall too low and makes contrast between the files hard to discern
            }

            if (segment->isFake()) { // multi-file
                cb.setHsv(h, s2, (v2 < 90) ? 90 : v2); // too dark if < 100
                cp.setHsv(h, 17, v1);
            } else if (!segment->file()->isFolder()) { // file
                cb.setHsv(h, 17, v1);
                cp.setHsv(h, 17, v2);
            } else { // folder
                cb.setHsv(h, s1, v1); // v was 225
                cp.setHsv(h, s2, v2); // v was 225 - delta
            }

            segment->setPalette(cp, cb);

            // TODO:
            //**** may be better to store KDE colours as H and S and vary V as others
            //**** perhaps make saturation difference for s2 dependent on contrast too
            //**** fake segments don't work with highContrast
            //**** may work better with cp = cb rather than Qt::white
            //**** you have to ensure the grey of files is sufficient, currently it works only with rainbow (perhaps use contrast there too)
            //**** change v1,v2 to vp, vb etc.
            //**** using percentages is not strictly correct as the eye doesn't work like that
            //**** darkness factor is not done for kde_colour scheme, and also value for files is incorrect really for files in this scheme as it is not set
            // like rainbow one is
        }
```

#### AUTO 


```{c}
auto ac= new KActionCollection(this, QStringLiteral("dummycollection"));
```

