#### AUTO 


```{c}
auto id = attributes.value(QLatin1String(""), QStringLiteral("id") );
```

