#### AUTO 


```{c}
auto branches = j->fetchResults().toList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& annotation: m_annotations) {
        const auto revision = static_cast<MercurialPlugin*>(vcsPlugin())->toMercurialRevision(annotation.value<VcsAnnotationLine>().revision());
        if (!m_revisionsToLog.contains(revision)) {
            m_revisionsToLog.insert(revision);
        }
    }
```

#### AUTO 


```{c}
auto verifyAnnotateJobFailed = [this](MercurialAnnotateJob::TestCase test)
    {
        VcsRevision revision;
        revision.setRevisionValue(0, KDevelop::VcsRevision::GlobalNumber);
        auto job = m_proxy->annotate(QUrl::fromLocalFile(mercurialTest_BaseDir + mercurialTest_FileName), revision);
        auto annotateJob = dynamic_cast<MercurialAnnotateJob*>(job);
        QVERIFY(annotateJob);
        annotateJob->m_testCase = test;

        QVERIFY(job->exec());
        QVERIFY(job->status() == KDevelop::VcsJob::JobFailed);
    };
```

#### AUTO 


```{c}
auto annotationLine = m_annotations[idx].value<VcsAnnotationLine>();
```

#### AUTO 


```{c}
const auto &copies = *it++;
```

#### AUTO 


```{c}
auto mergeJob = new DVcsJob(m_workingDir, vcsPlugin());
```

#### AUTO 


```{c}
const auto &files = *it++;
```

#### AUTO 


```{c}
auto job = m_proxy->checkoutHead(QUrl::fromLocalFile(mercurialTest_BaseDir), revision);
```

#### AUTO 


```{c}
auto commit2 = results[2].value<VcsAnnotationLine>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](VcsJob* j) {
				auto job = static_cast<DVcsJob *>(j);
				if (job->status() != VcsJob::JobSucceeded || job->output().isEmpty())
					return setFail();
				setSuccess();
			}
```

#### AUTO 


```{c}
const auto commits = m_proxy->getAllCommits(mercurialTest_BaseDir);
```

#### AUTO 


```{c}
auto results = job->fetchResults().toList();
```

#### AUTO 


```{c}
auto rev2 = headsModel->data(headsModel->index(0, VcsBasicEventModel::RevisionColumn)).toLongLong();
```

#### AUTO 


```{c}
auto commits = m_proxy->allCommits(mercurialTest_BaseDir);
```

#### AUTO 


```{c}
const auto revision = revisionToString(annotation.value<VcsAnnotationLine>().revision());
```

#### AUTO 


```{c}
auto j = m_proxy->commit(QString("new head"), {QUrl::fromLocalFile(mercurialTest_BaseDir)}, KDevelop::IBasicVersionControl::Recursive);
```

#### AUTO 


```{c}
auto it = m_revisionsToLog.begin();
```

#### AUTO 


```{c}
auto commit1 = results[1].value<VcsAnnotationLine>();
```

#### AUTO 


```{c}
auto rev1 = headsModel->data(headsModel->index(1, VcsBasicEventModel::RevisionColumn)).toLongLong();
```

#### AUTO 


```{c}
auto statusResults = job->fetchResults().toList();
```

#### AUTO 


```{c}
const auto& annotation
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& annotation: m_annotations) {
        const auto revision = revisionToString(annotation.value<VcsAnnotationLine>().revision());
        if (!m_revisionsToLog.contains(revision)) {
            m_revisionsToLog.insert(revision);
        }
    }
```

#### AUTO 


```{c}
auto items = job->output().split("\\_%");
```

#### LAMBDA EXPRESSION 


```{c}
[this](MercurialAnnotateJob::TestCase test)
    {
        VcsRevision revision;
        revision.setRevisionValue(0, KDevelop::VcsRevision::GlobalNumber);
        auto job = m_proxy->annotate(QUrl::fromLocalFile(mercurialTest_BaseDir + mercurialTest_FileName), revision);
        auto annotateJob = dynamic_cast<MercurialAnnotateJob*>(job);
        QVERIFY(annotateJob);
        annotateJob->m_testCase = test;

        QVERIFY(job->exec());
        QVERIFY(job->status() == KDevelop::VcsJob::JobFailed);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
			if (job->error()) {
				setFail();
			}
		}
```

#### AUTO 


```{c}
auto j = m_proxy->branches(QUrl::fromLocalFile(mercurialTest_BaseDir));
```

#### LAMBDA EXPRESSION 


```{c}
[this](VcsJob* j) {
			auto job = static_cast<DVcsJob *>(j);
			if (job->status() != VcsJob::JobSucceeded || job->output().isEmpty())
				return setFail();

			auto mergeJob = new DVcsJob(m_workingDir, vcsPlugin());

			*mergeJob << "hg" << "merge" << "-r" << job->output().trimmed();

			connect(mergeJob, &KJob::finished, this, [this](KJob *job) {
				if (job->error()) {
					setFail();
				}
			});
			connect(mergeJob, &DVcsJob::resultsReady, this, [this](VcsJob* j) {
				auto job = static_cast<DVcsJob *>(j);
				if (job->status() != VcsJob::JobSucceeded || job->output().isEmpty())
					return setFail();
				setSuccess();
			});

			m_job = mergeJob;
			mergeJob->start();
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){emit repositoryBranchChanged(m_branchesChange.takeFirst());}
```

#### AUTO 


```{c}
auto job = m_proxy->annotate(QUrl::fromLocalFile(mercurialTest_BaseDir + mercurialTest_FileName), revision);
```

#### AUTO 


```{c}
auto statusResults = j->fetchResults().toList();
```

#### AUTO 


```{c}
auto job = static_cast<DVcsJob *>(j);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
				if (job->error()) {
					setFail();
				}
			}
```

#### AUTO 


```{c}
const auto revision = static_cast<MercurialPlugin*>(vcsPlugin())->toMercurialRevision(annotationLine.revision());
```

#### AUTO 


```{c}
const auto commits = m_proxy->allCommits(mercurialTest_BaseDir);
```

#### AUTO 


```{c}
const auto revision = revisionToString(annotationLine.revision());
```

#### AUTO 


```{c}
auto commit0 = results[0].value<VcsAnnotationLine>();
```

#### AUTO 


```{c}
auto commits = m_proxy->getAllCommits(mercurialTest_BaseDir);
```

#### AUTO 


```{c}
auto it = items.constBegin();
```

#### AUTO 


```{c}
const auto revision = static_cast<MercurialPlugin*>(vcsPlugin())->toMercurialRevision(annotation.value<VcsAnnotationLine>().revision());
```

#### AUTO 


```{c}
auto job = new DVcsJob(m_workingDir, vcsPlugin(), KDevelop::OutputJob::Silent);
```

#### AUTO 


```{c}
auto status = statusResults[0].value<VcsStatusInfo>();
```

#### AUTO 


```{c}
auto annotateJob = dynamic_cast<MercurialAnnotateJob*>(job);
```

