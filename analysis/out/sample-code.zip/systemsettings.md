#### AUTO 


```{c}
const auto servicesList = KServiceTypeTrader::self()->query(QStringLiteral("SystemSettingsExternalApp"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto state : { QPalette::Active, QPalette::Inactive, QPalette::Disabled }) {
            pal.setBrush(state, QPalette::WindowText, pal.toolTipText());
        pal.setBrush(state, QPalette::Window, pal.toolTipBase());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (m_resultModel->rowCount() >= 5) {
                setSourceModel(m_resultModel);
            } else {
                setSourceModel(m_defaultModel);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : actions) {
                QStandardItem *item = new QStandardItem();
                item->setData(QUrl(QStringLiteral("kcm:%1.desktop").arg(action.name())), ResultModel::ResourceRole);
                m_defaultModel->appendRow(item);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &m : qAsConst(metaDataList)) {
        modules << m;
        auto insertionIterator = uniquePluginIds.insert(m.pluginId());
        Q_ASSERT_X(insertionIterator != uniquePluginIds.end(),
                   Q_FUNC_INFO,
                   qPrintable(QStringLiteral("the plugin %1 was found in multiple namespaces").arg(m.pluginId())));
    }
```

#### AUTO 


```{c}
auto loadFromMetaData = [&moduleData](const KPluginMetaData &data) {
        if (data.isValid()) {
            auto factory = KPluginFactory::loadFactory(data).plugin;
            moduleData = factory ? factory->create<KCModuleData>() : nullptr;
        }
    };
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### LAMBDA EXPRESSION 


```{c}
[&moduleData](const KPluginMetaData &data) {
        if (data.isValid()) {
            auto factory = KPluginFactory::loadFactory(data).plugin;
            moduleData = factory ? factory->create<KCModuleData>() : nullptr;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                const int rootImplicitWidth = d->quickWidget->rootObject()->property("implicitWidth").toInt();
                if (rootImplicitWidth != 0) {
                    d->quickWidget->setFixedWidth(rootImplicitWidth);
                } else {
                    d->quickWidget->setFixedWidth(240);
                }
            }
```

#### AUTO 


```{c}
auto parentIdx = d->model->indexForItem(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[queryList, data, &relevance](const QString &value, qreal relevanceValue) {
            if (value.contains(queryList.first(), Qt::CaseInsensitive)) {
                relevance = relevanceValue;
                return true;
            }
            for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
            return false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &m1, const KPluginMetaData &m2) {
        return QString::compare(m1.pluginId(), m2.pluginId(), Qt::CaseInsensitive) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KService::Ptr activeService : pluginObjects) {
        QString error;
        BaseMode * controller = activeService->createInstance<BaseMode>(this, {m_mode, m_startupModule, m_startupModuleArgs}, &error);
        if( error.isEmpty() ) {
            possibleViews.insert( activeService->library(), controller );
            controller->init( activeService );
            connect(controller, &BaseMode::changeToolBarItems, this, &SettingsBase::changeToolBar);
            connect(controller, &BaseMode::actionsChanged, this, &SettingsBase::updateViewActions);
            connect(searchText, &KLineEdit::textChanged, controller, &BaseMode::searchChanged);
            connect(controller, &BaseMode::viewChanged, this, &SettingsBase::viewChange);
        } else {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << QStringLiteral("View load error: ") + error;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            BaseConfig::setActiveView(QStringLiteral("systemsettings_sidebar_mode"));
            changePlugin();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&query](const QString &keyword) {
                    return keyword.startsWith(query, Qt::CaseInsensitive);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : modules) {
            QString entry(QStringLiteral("%1 - %2"));

            entry = entry.arg(metaData.pluginId().leftJustified(maxLen, QLatin1Char(' ')))
                        .arg(!metaData.description().isEmpty() ? metaData.description() : i18n("No description available"));

            std::cout << entry.toLocal8Bit().data() << std::endl;
        }
```

#### AUTO 


```{c}
auto item = categoryIdx.data(Qt::UserRole).value<MenuItem*>();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QStringList &arguments, const QString &workingDirectory) {
        if (!window) {
            return;
        }

        if (arguments.size() > 1) {
            window->setStartupModule(arguments[1]);

            if (arguments.size() > 2) {
                window->setStartupModuleArgs(arguments.mid(2));
            }
            window->reloadStartupModule();
        }

        KWindowSystem::forceActiveWindow(window->winId());
    }
```

#### AUTO 


```{c}
auto *moduleScroll = new QScrollArea(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&viewToUse](const KPluginMetaData &plugin) {
        return viewToUse.contains(plugin.pluginId());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->setActionMenuVisible(this, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        // Make sure we only load one plugin per type if we're installed on multiple prefixes
        if (possibleViews.contains(plugin.pluginId())) {
            continue;
        }

        KPluginLoader loader(plugin.fileName());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "KPluginFactory could not load the plugin:" << plugin.pluginId() << loader.errorString();
            continue;
        }

        BaseMode *controller = factory->create<BaseMode>(this, {m_mode, m_startupModule, m_startupModuleArgs});
        if (!controller) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "Error loading plugin";
            continue;
        }

        possibleViews.insert(plugin.pluginId(), controller);
        controller->init(plugin);
        connect(controller, &BaseMode::changeToolBarItems, this, &SettingsBase::changeToolBar);
        connect(controller, &BaseMode::actionsChanged, this, &SettingsBase::updateViewActions);
        connect(searchText, &KLineEdit::textChanged, controller, &BaseMode::searchChanged);
        connect(controller, &BaseMode::viewChanged, this, &SettingsBase::viewChange);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : qAsConst(pluginModules)) {
        QString category;
        QString categoryv2;
        if (m_mode == BaseMode::InfoCenter) {
            category = metaData.value(QStringLiteral("X-KDE-KInfoCenter-Category"));
        } else {
            category = metaData.value(QStringLiteral("X-KDE-System-Settings-Parent-Category"));
            categoryv2 = metaData.value(QStringLiteral("X-KDE-System-Settings-Parent-Category-V2"));
        }
        const QString parentCategoryKcm = parent->systemsettingsCategoryModule();
        bool isCategoryOwner = false;

        if (!parentCategoryKcm.isEmpty() && parentCategoryKcm == metaData.pluginId()) {
            parent->setMetaData(metaData);
            isCategoryOwner = true;
        }

        if (!parent->category().isEmpty() && (category == parent->category() || categoryv2 == parent->category())) {
            if (!metaData.isHidden()) {
                // Add the module info to the menu
                MenuItem *infoItem = new MenuItem(false, parent);
                infoItem->setMetaData(metaData);
                infoItem->setCategoryOwner(isCategoryOwner);

                if (m_mode == BaseMode::InfoCenter && metaData.pluginId() == QStringLiteral("kcm_about_distro")) {
                    homeModule = infoItem;
                } else if (m_mode == BaseMode::SystemSettings && metaData.pluginId() == QStringLiteral("kcm_landingpage")) {
                    homeModule = infoItem;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto itemIdx = d->model->indexForItem(item);
```

#### AUTO 


```{c}
auto *moduleData = KCModuleLoader::loadModuleData(item->item());
```

#### AUTO 


```{c}
const auto findExternalModulesInFilesystem = [](const QString &sourceNamespace) {
        const QString sourceNamespaceDirName = QStringLiteral("plasma/%1/externalmodules").arg(sourceNamespace);
        const QStringList dirs = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, sourceNamespaceDirName, QStandardPaths::LocateDirectory);
        const QStringList files = KFileUtils::findAllUniqueFiles(dirs, QStringList{QStringLiteral("*.desktop")});

        QList<KPluginMetaData> metaDataList;
        for (const QString &file : files) {
            KService service(file);
            QJsonObject kplugin;
            kplugin.insert(QLatin1String("Name"), service.name());
            kplugin.insert(QLatin1String("Icon"), service.icon());
            kplugin.insert(QLatin1String("Description"), service.comment());

            QJsonObject root;
            root.insert(QLatin1String("KPlugin"), kplugin);
            root.insert(QLatin1String("X-KDE-Weight"), service.property(QStringLiteral("X-KDE-Weight")).toInt());
            root.insert(QLatin1String("X-KDE-KInfoCenter-Category"), service.property(QStringLiteral("X-KDE-KInfoCenter-Category")).toString());
            root.insert(QLatin1String("X-KDE-System-Settings-Category"), service.property(QStringLiteral("X-KDE-System-Settings-Category")).toString());
            root.insert(QLatin1String("IsExternalApp"), true);

            metaDataList << KPluginMetaData(root, file);
        }
        return metaDataList;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        window->activateWindow();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : servicesList) {
            const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + s->entryPath());
            metaDataList << KPluginMetaData::fromDesktopFile(path);
        }
```

#### AUTO 


```{c}
const auto pageList = d->mPagesPluginIdMap.keys();
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &workingDirectory) {
        Q_UNUSED(workingDirectory);

        // We can't use startupModule and args from above since they come from the existing instance, so we need to parse arguments.
        // We don't need to do the error checking again though.
        QCommandLineParser parser;
        parser.addPositionalArgument(QStringLiteral("module"), i18n("Configuration module to open"));
        parser.addOption(QCommandLineOption(QStringLiteral("args"), i18n("Arguments for the module"), QStringLiteral("arguments")));

        parser.parse(arguments);

        const QStringList args = parser.value(QStringLiteral("args")).split(QRegularExpression(QStringLiteral(" +")), Qt::SkipEmptyParts);
        QString startupModule;

        if (parser.positionalArguments().count() == 1) {
            startupModule = parser.positionalArguments().constFirst();
        }

        if (!startupModule.isEmpty()) {
            mainWindow->setStartupModule(startupModule);
            mainWindow->setStartupModuleArgs(args);
            mainWindow->reloadStartupModule();
        }

        KWindowSystem::forceActiveWindow(mainWindow->winId());
    }
```

#### AUTO 


```{c}
auto source = mode == BaseMode::InfoCenter ? MetaDataSource::KInfoCenter : MetaDataSource::SystemSettings;
```

#### AUTO 


```{c}
auto *moduleProxy = new KCModuleProxy(data, moduleScroll, args);
```

#### AUTO 


```{c}
auto titleWidget = qobject_cast<KTitleWidget *>(d->mPageWidget->pageHeader())
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(categories)) {
        const KDesktopFile file(category);
        const KConfigGroup entry = file.desktopGroup();
        QString parentCategory;
        QString parentCategory2;
        if (m_mode == BaseMode::InfoCenter) {
            parentCategory = entry.readEntry("X-KDE-KInfoCenter-Parent-Category");
        } else {
            parentCategory = entry.readEntry("X-KDE-System-Settings-Parent-Category");
            parentCategory2 = entry.readEntry("X-KDE-System-Settings-Parent-Category-V2");
        }

        if (parentCategory == parent->category() ||
            // V2 entries must not be empty if they want to become a proper category.
            (!parentCategory2.isEmpty() && parentCategory2 == parent->category())) {
            MenuItem *menuItem = new MenuItem(true, parent);
            menuItem->setCategoryConfig(file);
            if (entry.readEntry("X-KDE-System-Settings-Category") == QLatin1String("lost-and-found")) {
                lostFound = menuItem;
                continue;
            }
            initMenuList(menuItem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, moduleDataSignaling]() {
                        item->setDefaultIndicator(!moduleDataSignaling->isDefaults());

                        auto itemIdx = d->model->indexForItem(item);
                        emit d->model->dataChanged(itemIdx, itemIdx);
                        MenuItem *parent = item->parent();
                        while (parent) {
                            auto parentIdx = d->model->indexForItem(parent);
                            if (parentIdx.isValid()) {
                                emit d->model->dataChanged(parentIdx, parentIdx);
                                parent = parent->parent();
                            } else {
                                parent = nullptr;
                            }
                        }
                        emit defaultsIndicatorsVisibleChanged();
                        moduleDataSignaling->deleteLater();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : qAsConst(services)) {
        if (!s->noDisplay() && !s->exec().isEmpty() && KAuthorized::authorizeControlModule(s->menuId())) {
            const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + s->entryPath());
            const KPluginMetaData data = KPluginMetaData::fromDesktopFile(path);
            if (!uniquePluginIds.contains(data.pluginId())) {
                modules << data;
                uniquePluginIds << data.pluginId();
            }
        }
    }
```

#### AUTO 


```{c}
auto item = categoryIdx.data(Qt::UserRole).value<MenuItem *>();
```

#### AUTO 


```{c}
auto *child
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : qAsConst(services)) {
        if (!s->noDisplay() && !uniquePluginIds.contains(s->library()) && KAuthorized::authorizeControlModule(s->menuId())) {
            QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + s->entryPath());
            modules << KPluginMetaData::fromDesktopFile(path);
            uniquePluginIds << s->library();
        }
    }
```

#### AUTO 


```{c}
auto controllerResult = KPluginFactory::instantiatePlugin<BaseMode>(plugin, this, {m_mode, m_startupModule, m_startupModuleArgs});
```

#### AUTO 


```{c}
const auto controller = controllerResult.plugin;
```

#### AUTO 


```{c}
auto *data = new QMimeData();
```

#### AUTO 


```{c}
auto *delegate = new KNotificationJobUiDelegate;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &sourceNamespace, const QString &serviceType) {
        const QString sourceNamespaceDirName = QStringLiteral("plasma/%1/externalmodules").arg(sourceNamespace);
        const QStringList dirs = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, sourceNamespaceDirName, QStandardPaths::LocateDirectory);
        const QStringList files = KFileUtils::findAllUniqueFiles(dirs, QStringList{QStringLiteral("*.desktop")});

        QList<KPluginMetaData> metaDataList;
        for (const QString &file : files) {
            metaDataList << KPluginMetaData::fromDesktopFile(file, QStringList(serviceType));
        }
        return metaDataList;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                qWarning()<<"AAA"<<d->quickWidget->quickWindow()->activeFocusItem();
            }
```

#### AUTO 


```{c}
auto factory = KPluginFactory::loadFactory(data).plugin;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &err : d->quickWidget->errors()) {
            qWarning() << err.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : modules) {
            const int len = metaData.pluginId().length();
            if (len > maxLen) {
                maxLen = len;
            }
        }
```

#### AUTO 


```{c}
auto linearlyInterpolateDouble = [](double one, double two, double factor) {
        return one + (two - one) * factor;
    };
```

#### AUTO 


```{c}
auto page = d->mPagesPluginIdMap.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractItemView *view : theViews) {
        tooltipManagers << new ToolTipManager(view);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
```

#### AUTO 


```{c}
auto item = idx.data(MenuModel::MenuItemRole).value<MenuItem *>();
```

#### AUTO 


```{c}
auto infoItem = new MenuItem(false, lostFound);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : qAsConst(m_modules)) {
        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::CompletionMatch);
        setupMatch(data, match);
        qreal relevance = -1;

        auto checkMatchAndRelevance = [queryList, data, &relevance](const QString &value, qreal relevanceValue) {
            if (value.contains(queryList.first(), Qt::CaseInsensitive)) {
                relevance = relevanceValue;
                return true;
            }
            for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
            return false;
        };

        if (checkMatchAndRelevance(data.name(), 0.8)) {
            if (data.name().startsWith(queryList[0], Qt::CaseInsensitive)) {
                relevance += 0.1;
            }
        } else {
            // check if the generic name or description matches
            if (!checkMatchAndRelevance(data.value(QStringLiteral("GenericName")), 0.65) && !checkMatchAndRelevance(data.description(), 0.5)) {
                // if not, check the keyowords
                const QString &query = ctx.query();
                const QStringList keywords = data.value(QStringLiteral("X-KDE-Keywords")).split(QLatin1Char(','));
                bool anyKeywordMatches = std::any_of(keywords.begin(), keywords.end(), [&query](const QString &keyword) {
                    return keyword.startsWith(query);
                });
                if (anyKeywordMatches && keywords.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5; // If the keyword matches exactly we give it the same relevance as if the description matched
                } else if (anyKeywordMatches) {
                    relevance = 0.2; // give it a lower relevance than if it had been found by name or description
                } else {
                    continue; // we haven't found any matching keyword, skip this KCM
                }
            }
        }

        if (isKinfoCenterKcm(data)) {
            match.setMatchCategory(i18n("System Information"));
        } else {
            match.setMatchCategory(i18n("System Settings"));
        }
        // KCMs are, on the balance, less relevant. Drop it ever so much. So they may get outscored
        // by an otherwise equally applicable match.
        relevance -= .001;

        match.setRelevance(relevance);

        matches << match;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : qAsConst(services)) {
        if (!s->noDisplay() && !s->exec().isEmpty() && KAuthorized::authorizeControlModule(s->menuId())) {
            QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + s->entryPath());
            const KPluginMetaData data = KPluginMetaData::fromDesktopFile(path);
            if (!uniquePluginIds.contains(data.pluginId())) {
                modules << data;
                uniquePluginIds << data.pluginId();
            }
        }
    }
```

#### AUTO 


```{c}
auto *moduleData = KPluginFactory::instantiatePlugin<KCModuleData>(item->metaData()).plugin;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            KService service(file);
            QJsonObject kplugin;
            kplugin.insert(QLatin1String("Name"), service.name());
            kplugin.insert(QLatin1String("Icon"), service.icon());
            kplugin.insert(QLatin1String("Description"), service.comment());

            QJsonObject root;
            root.insert(QLatin1String("KPlugin"), kplugin);
            root.insert(QLatin1String("X-KDE-Weight"), service.property(QStringLiteral("X-KDE-Weight")).toInt());
            root.insert(QLatin1String("X-KDE-KInfoCenter-Category"), service.property(QStringLiteral("X-KDE-KInfoCenter-Category")).toString());
            root.insert(QLatin1String("X-KDE-System-Settings-Category"), service.property(QStringLiteral("X-KDE-System-Settings-Category")).toString());
            root.insert(QLatin1String("IsExternalApp"), true);

            metaDataList << KPluginMetaData(root, file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &m : qAsConst(metaDataList)) {
        // We check both since porting a module to loading view KPluginMetaData drops ".desktop" from the pluginId()
        if (!KAuthorized::authorizeControlModule(m.pluginId()) || !KAuthorized::authorizeControlModule(m.pluginId().append(QStringLiteral(".desktop")))) {
            continue;
        }
        modules << m;
        auto insertionIterator = uniquePluginIds.insert(m.pluginId());
        Q_ASSERT_X(insertionIterator != uniquePluginIds.end(),
                   Q_FUNC_INFO,
                   qPrintable(QStringLiteral("the plugin %1 was found in multiple namespaces").arg(m.pluginId())));
    }
```

#### AUTO 


```{c}
const auto data = match.data().value<KPluginMetaData>();
```

#### AUTO 


```{c}
const auto pluginIt = std::find_if(m_plugins.cbegin(), m_plugins.cend(), [&viewToUse](const KPluginMetaData &plugin) {
        return viewToUse.contains(plugin.pluginId());
    });
```

#### AUTO 


```{c}
auto controller = controllerResult.plugin;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        KWindowSystem::forceActiveWindow(window->winId());
    }
```

#### AUTO 


```{c}
auto state
```

#### AUTO 


```{c}
auto *externalWidget = new ExternalAppModule(this, KService::Ptr(new KService(item->metaData().metaDataFileName())));
```

#### AUTO 


```{c}
auto loader = KIconLoader::global();
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &workingDirectory) {
        Q_UNUSED(workingDirectory);

        // We can't use startupModule and args from above since they come from the existing instance, so we need to parse arguments.
        // We don't need to do the error checking again though.
        QCommandLineParser parser;
        parser.addPositionalArgument(QStringLiteral("module"), i18n("Configuration module to open"));
        parser.addOption(QCommandLineOption(QStringLiteral("args"), i18n("Arguments for the module"), QStringLiteral("arguments")));

        parser.parse(arguments);

        const QStringList args = parser.value(QStringLiteral("args")).split(QRegularExpression(QStringLiteral(" +")), Qt::SkipEmptyParts);
        QString startupModule;

        if (parser.positionalArguments().count() == 1) {
            startupModule = parser.positionalArguments().constFirst();
        }

        if (!startupModule.isEmpty()) {
            mainWindow->setStartupModule(startupModule);
            mainWindow->setStartupModuleArgs(args);
            mainWindow->reloadStartupModule();
        }

        KWindowSystem::updateStartupId(mainWindow->windowHandle());
        KWindowSystem::activateWindow(mainWindow->windowHandle());
    }
```

#### AUTO 


```{c}
auto *moduleDataSignaling = qobject_cast<KCModuleDataSignaling *>(moduleData);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : qAsConst(pluginModules)) {
            auto infoItem = new MenuItem(false, lostFound);
            infoItem->setMetaData(metaData);
            qCDebug(SYSTEMSETTINGS_APP_LOG) << "Added " << metaData.pluginId();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &data) {
        const auto supportedPlatforms = data.value(QStringLiteral("X-KDE-OnlyShowOnQtPlatforms"), QStringList());
        return supportedPlatforms.isEmpty() || supportedPlatforms.contains(qGuiApp->platformName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *child : d->children) {
        MenuItem *candidate = child->descendantForModule(moduleName);
        if (candidate) {
            return candidate;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto state : {QPalette::Active, QPalette::Inactive, QPalette::Disabled}) {
        pal.setBrush(state, QPalette::WindowText, pal.toolTipText());
        pal.setBrush(state, QPalette::Window, pal.toolTipBase());
    }
```

#### AUTO 


```{c}
const auto &m
```

#### AUTO 


```{c}
const auto value = match.data().value<KPluginMetaData>();
```

#### AUTO 


```{c}
const auto &s
```

#### AUTO 


```{c}
auto *page = new KPageWidgetItem(moduleScroll, data.name());
```

#### AUTO 


```{c}
const auto findExternalModulesInFilesystem = [](const QString &sourceNamespace, const QString &serviceType) {
        const QString sourceNamespaceDirName = QStringLiteral("plasma/%1/externalmodules").arg(sourceNamespace);
        const QStringList dirs = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, sourceNamespaceDirName, QStandardPaths::LocateDirectory);
        const QStringList files = KFileUtils::findAllUniqueFiles(dirs, QStringList{QStringLiteral("*.desktop")});

        QList<KPluginMetaData> metaDataList;
        for (const QString &file : files) {
            metaDataList << KPluginMetaData::fromDesktopFile(file, QStringList(serviceType));
        }
        return metaDataList;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const int rootImplicitWidth = d->quickWidget->rootObject()->property("implicitWidth").toInt();
        if (rootImplicitWidth != 0) {
            d->quickWidget->setFixedWidth(rootImplicitWidth);
        } else {
            d->quickWidget->setFixedWidth(240);
        }
    }
```

#### AUTO 


```{c}
auto sourceIdx = d->categorizedModel->mapToSource(categoryIdx);
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, moduleData]() {
                    item->setDefaultIndicator(!moduleData->isDefaults());
                    updateModelMenuItem(item);
                    moduleData->deleteLater();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : qAsConst(m_modules)) {
        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::CompletionMatch);
        setupMatch(data, match);
        qreal relevance = -1;

        auto checkMatchAndRelevance = [queryList, data, &relevance](const QString &value, qreal relevanceValue) {
            if (value.contains(queryList.first(), Qt::CaseInsensitive)) {
                relevance = relevanceValue;
                return true;
            }
            for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
            return false;
        };

        if (checkMatchAndRelevance(data.name(), 0.8)) {
            if (data.name().startsWith(queryList[0], Qt::CaseInsensitive)) {
                relevance += 0.1;
            }
        } else {
            // check if the generic name or description matches
            if (!checkMatchAndRelevance(data.value(QStringLiteral("GenericName")), 0.65) && !checkMatchAndRelevance(data.description(), 0.5)) {
                // if not, check the keyowords
                const QString &query = ctx.query();
                const QStringList keywords = data.value(QStringLiteral("X-KDE-Keywords")).split(QLatin1Char(','));
                bool anyKeywordMatches = std::any_of(keywords.begin(), keywords.end(), [&query](const QString &keyword) {
                    return keyword.startsWith(query, Qt::CaseInsensitive);
                });
                if (anyKeywordMatches && keywords.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5; // If the keyword matches exactly we give it the same relevance as if the description matched
                } else if (anyKeywordMatches) {
                    relevance = 0.2; // give it a lower relevance than if it had been found by name or description
                } else {
                    continue; // we haven't found any matching keyword, skip this KCM
                }
            }
        }

        if (isKinfoCenterKcm(data)) {
            match.setMatchCategory(i18n("System Information"));
        } else {
            match.setMatchCategory(i18n("System Settings"));
        }
        // KCMs are, on the balance, less relevant. Drop it ever so much. So they may get outscored
        // by an otherwise equally applicable match.
        relevance -= .001;

        match.setRelevance(relevance);

        matches << match;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        if (d->activeCategoryIndex.isValid() && d->activeCategoryIndex.row() >= 0) {
            d->subCategoryModel->setParentIndex( d->activeCategoryIndex );
            emit activeCategoryChanged();
        }
    }
```

#### AUTO 


```{c}
auto filter = [](const KPluginMetaData &data) {
        const auto supportedPlatforms = data.value(QStringLiteral("X-KDE-OnlyShowOnQtPlatforms"), QStringList());
        return supportedPlatforms.isEmpty() || supportedPlatforms.contains(qGuiApp->platformName());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, moduleDataSignaling]() {
                item->setDefaultIndicator(!moduleDataSignaling->isDefaults());

                auto itemIdx = d->model->indexForItem(item);
                emit d->model->dataChanged(itemIdx, itemIdx);

                moduleDataSignaling->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionName : actionList) {
        menu->addAction(d->collection->action(actionName));
    }
```

#### AUTO 


```{c}
auto source = m_mode == BaseMode::InfoCenter ? MetaDataSource::KInfoCenter : MetaDataSource::SystemSettings;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : qAsConst(m_modules)) {
        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::CompletionMatch);
        setupMatch(data, match);
        qreal relevance = -1;

        auto checkMatchAndRelevance = [queryList, data, &relevance](const QString &value, qreal relevanceValue) {
            if (value.contains(queryList.first(), Qt::CaseInsensitive)) {
                relevance = relevanceValue;
                return true;
            }
            for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
            return false;
        };

        if (checkMatchAndRelevance(data.name(), 0.8)) {
            if (data.name().startsWith(queryList[0], Qt::CaseInsensitive)) {
                relevance += 0.1;
            }
        } else {
            if (!checkMatchAndRelevance(data.value(QStringLiteral("GenericName")), 0.65) && !checkMatchAndRelevance(data.description(), 0.5)) {
                continue;
            }
        }

        if (isKinfoCenterKcm(data)) {
            match.setMatchCategory(i18n("System Information"));
        } else {
            match.setMatchCategory(i18n("System Settings"));
        }
        // KCMs are, on the balance, less relevant. Drop it ever so much. So they may get outscored
        // by an otherwise equally applicable match.
        relevance -= .001;

        match.setRelevance(relevance);

        matches << match;
    }
```

#### AUTO 


```{c}
auto disabled = KColorScheme(QPalette::Disabled, KColorScheme::Header, config);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &m : qAsConst(metaDataList)) {
        // We check both since porting a module to loading view KPluginMetaData drops ".desktop" from the pluginId()
        if (!KAuthorized::authorizeControlModule(m.pluginId()) || !KAuthorized::authorizeControlModule(m.pluginId().append(QStringLiteral(".desktop")))) {
            continue;
        }
        modules << m;
        const bool inserted = uniquePluginIds.insert(m.pluginId()).second;
        if (!inserted) {
            qWarning() << "the plugin" << m.pluginId() << " was found in multiple namespaces";
        }
    }
```

#### AUTO 


```{c}
const auto page
```

#### AUTO 


```{c}
const auto it = m_loadedViews.constFind(viewToUse);
```

#### RANGE FOR STATEMENT 


```{c}
for (MenuItem *child : qAsConst(d->children)) {
        listOfKeywords << child->keywords(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            metaDataList << KPluginMetaData::fromDesktopFile(file, QStringList(serviceType));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &m : qAsConst(metaDataList)) {
        modules << m;
        auto insertionIterator = uniquePluginIds.insert(m.pluginId());
        Q_ASSERT_X(insertionIterator != uniquePluginIds.end(),
                   Q_FUNC_INFO,
                   qPrintable(QStringLiteral("the plugin %1 was found in mutiple namespaces").arg(m.pluginId())));
    }
```

#### AUTO 


```{c}
const auto modules = findKCMsMetaData(source) << findExternalKCMModules(source);
```

#### AUTO 


```{c}
auto child
```

#### AUTO 


```{c}
const auto &err
```

#### AUTO 


```{c}
const auto actions = service->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            BaseConfig::setActiveView(QStringLiteral("systemsettings_icon_mode"));
            changePlugin();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&query](const QString &keyword) {
                    return keyword.startsWith(query);
                }
```

#### AUTO 


```{c}
const auto controllerResult = KPluginFactory::instantiatePlugin<BaseMode>(*pluginIt, this, {m_mode, m_startupModule, m_startupModuleArgs});
```

#### RANGE FOR STATEMENT 


```{c}
for (auto child : children()) {
            d->showDefaultIndicator |= child->showDefaultIndicator();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        auto controllerResult = KPluginFactory::instantiatePlugin<BaseMode>(plugin, this, {m_mode, m_startupModule, m_startupModuleArgs});
        if (!controllerResult) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "Error loading plugin" << controllerResult.errorText;
            continue;
        }

        auto controller = controllerResult.plugin;
        possibleViews.insert(plugin.pluginId(), controller);
        controller->init(plugin);
        connect(controller, &BaseMode::changeToolBarItems, this, &SettingsBase::changeToolBar);
        connect(controller, &BaseMode::actionsChanged, this, &SettingsBase::updateViewActions);
        connect(searchText, &KLineEdit::textChanged, controller, &BaseMode::searchChanged);
        connect(controller, &BaseMode::viewChanged, this, &SettingsBase::viewChange);
    }
```

#### AUTO 


```{c}
auto *view = loadCurrentView()
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &workingDirectory) {
        Q_UNUSED(workingDirectory);

        // We can't use startupModule and args from above since they come from the existing instance, so we need to parse arguments.
        // We don't need to do the error checking again though.
        QCommandLineParser parser;
        parser.addPositionalArgument(QStringLiteral("module"), i18n("Configuration module to open"));
        parser.addOption(QCommandLineOption(QStringLiteral("args"), i18n("Arguments for the module"), QLatin1String("arguments")));

        parser.parse(arguments);

        const QStringList args = parser.value(QStringLiteral("args")).split(QRegExp(QStringLiteral(" +")), Qt::SkipEmptyParts);
        QString startupModule;

        if (parser.positionalArguments().count() == 1) {
            startupModule = parser.positionalArguments().first();
        }

        if (!startupModule.isEmpty()) {
            mainWindow->setStartupModule(startupModule);
            mainWindow->setStartupModuleArgs(args);
            mainWindow->reloadStartupModule();
        }

        KWindowSystem::forceActiveWindow(mainWindow->winId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : qAsConst(services)) {
        if (!s->noDisplay() && !s->exec().isEmpty() && !uniquePluginIds.contains(s->library()) && KAuthorized::authorizeControlModule(s->menuId())) {
            QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + s->entryPath());
            modules << KPluginMetaData::fromDesktopFile(path);
            uniquePluginIds << s->library();
        }
    }
```

#### AUTO 


```{c}
const auto &metaData
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (window) {
            KWindowSystem::forceActiveWindow(window->winId());
        }
    }
```

#### AUTO 


```{c}
auto updateModel = [this]() {
            if (m_resultModel->rowCount() >= 5) {
                setSourceModel(m_resultModel);
            } else {
                setSourceModel(m_defaultModel);
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        KPluginLoader loader(plugin.fileName());
        KPluginFactory *factory = loader.factory();
        if (!factory) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "KPluginFactory could not load the plugin:" << plugin.pluginId() << loader.errorString();
            continue;
        }

        BaseMode *controller = factory->create<BaseMode>(this, {m_mode, m_startupModule, m_startupModuleArgs});
        if (!controller) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "Error loading plugin";
            continue;
        }

        possibleViews.insert(plugin.pluginId(), controller);
        controller->init(plugin);
        connect(controller, &BaseMode::changeToolBarItems, this, &SettingsBase::changeToolBar);
        connect(controller, &BaseMode::actionsChanged, this, &SettingsBase::updateViewActions);
        connect(searchText, &KLineEdit::textChanged, controller, &BaseMode::searchChanged);
        connect(controller, &BaseMode::viewChanged, this, &SettingsBase::viewChange);
    }
```

#### AUTO 


```{c}
auto inactive = KColorScheme(QPalette::Inactive, KColorScheme::Header, config);
```

#### AUTO 


```{c}
auto subCategorySourceIdx = d->categorizedModel->mapToSource(d->subCategoryModel->mapToSource(subCateogryIdx));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : qAsConst(services)) {
        if (!s->noDisplay() && !s->exec().isEmpty() && KAuthorized::authorizeControlModule(s->menuId())) {
            const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("kservices5/") + s->entryPath());
            const KPluginMetaData data = KPluginMetaData::fromDesktopFile(path);
            const bool inserted = uniquePluginIds.insert(data.pluginId()).second;
            if (inserted) {
                modules << data;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : qAsConst(pluginModules)) {
        QString category;
        QString categoryv2;
        if (m_mode == BaseMode::InfoCenter) {
            category = metaData.value(QStringLiteral("X-KDE-KInfoCenter-Category"));
        } else {
            category = metaData.value(QStringLiteral("X-KDE-System-Settings-Parent-Category"));
            categoryv2 = metaData.value(QStringLiteral("X-KDE-System-Settings-Parent-Category-V2"));
        }
        const QString parentCategoryKcm = parent->systemsettingsCategoryModule();
        bool isCategoryOwner = false;

        if (!parentCategoryKcm.isEmpty() && parentCategoryKcm == metaData.pluginId()) {
            parent->setMetaData(metaData);
            isCategoryOwner = true;
        }

        if (!parent->category().isEmpty() && (category == parent->category() || categoryv2 == parent->category())) {
            if (!metaData.isHidden()) {
                // Add the module info to the menu
                MenuItem *infoItem = new MenuItem(false, parent);
                infoItem->setMetaData(metaData);
                infoItem->setCategoryOwner(isCategoryOwner);

                if (m_mode == BaseMode::InfoCenter && metaData.pluginId() == QStringLiteral("kcm_about-distro")) {
                    homeModule = infoItem;
                } else if (m_mode == BaseMode::SystemSettings && metaData.pluginId() == QStringLiteral("kcm_landingpage")) {
                    homeModule = infoItem;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, moduleData, categoryIdx]() {
            item->setDefaultIndicator(!moduleData->isDefaults());
            updateCategoryModel(categoryIdx);
            moduleData->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &arguments, const QString &workingDirectory) {
        Q_UNUSED(workingDirectory);

        // We can't use startupModule and args from above since they come from the existing instance, so we need to parse arguments.
        // We don't need to do the error checking again though.
        QCommandLineParser parser;
        parser.addPositionalArgument(QStringLiteral("module"), i18n("Configuration module to open"));
        parser.addOption(QCommandLineOption(QStringLiteral("args"), i18n("Arguments for the module"), QStringLiteral("arguments")));

        parser.parse(arguments);

        const QStringList args = parser.value(QStringLiteral("args")).split(QRegExp(QStringLiteral(" +")), Qt::SkipEmptyParts);
        QString startupModule;

        if (parser.positionalArguments().count() == 1) {
            startupModule = parser.positionalArguments().constFirst();
        }

        if (!startupModule.isEmpty()) {
            mainWindow->setStartupModule(startupModule);
            mainWindow->setStartupModuleArgs(args);
            mainWindow->reloadStartupModule();
        }

        KWindowSystem::forceActiveWindow(mainWindow->winId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto page : pageList) {
        if (d->mPagesPluginIdMap.value(page) == moduleName) {
            d->mPageWidget->setCurrentPage(page);
            break;
        }
    }
```

#### AUTO 


```{c}
auto checkMatchAndRelevance = [queryList, data, &relevance](const QString &value, qreal relevanceValue) {
            if (value.contains(queryList.first(), Qt::CaseInsensitive)) {
                relevance = relevanceValue;
                return true;
            }
            for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
            return false;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->setActionMenuVisible(this, false); }
```

#### AUTO 


```{c}
const auto supportedPlatforms = data.value(QStringLiteral("X-KDE-OnlyShowOnQtPlatforms"), QStringList());
```

#### AUTO 


```{c}
auto active = KColorScheme(QPalette::Active, KColorScheme::Header, config);
```

#### AUTO 


```{c}
auto subCateogryIdx = d->subCategoryModel->index(d->activeSubCategoryRow, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &sourceNamespace) {
        const QString sourceNamespaceDirName = QStringLiteral("plasma/%1/externalmodules").arg(sourceNamespace);
        const QStringList dirs = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, sourceNamespaceDirName, QStandardPaths::LocateDirectory);
        const QStringList files = KFileUtils::findAllUniqueFiles(dirs, QStringList{QStringLiteral("*.desktop")});

        QList<KPluginMetaData> metaDataList;
        for (const QString &file : files) {
            KService service(file);
            QJsonObject kplugin;
            kplugin.insert(QLatin1String("Name"), service.name());
            kplugin.insert(QLatin1String("Icon"), service.icon());
            kplugin.insert(QLatin1String("Description"), service.comment());

            QJsonObject root;
            root.insert(QLatin1String("KPlugin"), kplugin);
            root.insert(QLatin1String("X-KDE-Weight"), service.property(QStringLiteral("X-KDE-Weight")).toInt());
            root.insert(QLatin1String("X-KDE-KInfoCenter-Category"), service.property(QStringLiteral("X-KDE-KInfoCenter-Category")).toString());
            root.insert(QLatin1String("X-KDE-System-Settings-Category"), service.property(QStringLiteral("X-KDE-System-Settings-Category")).toString());
            root.insert(QLatin1String("IsExternalApp"), true);

            metaDataList << KPluginMetaData(root, file);
        }
        return metaDataList;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        KPluginLoader loader(plugin.fileName());
        KPluginFactory* factory = loader.factory();
        if (!factory) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "KPluginFactory could not load the plugin:" << plugin.pluginId() << loader.errorString();
            continue;
        }

        BaseMode *controller = factory->create<BaseMode>(this, {m_mode, m_startupModule, m_startupModuleArgs});
        if (!controller) {
            qCWarning(SYSTEMSETTINGS_APP_LOG) << "Error loading plugin";
            continue;
        }

        possibleViews.insert(plugin.pluginId(), controller);
        controller->init(plugin);
        connect(controller, &BaseMode::changeToolBarItems, this, &SettingsBase::changeToolBar);
        connect(controller, &BaseMode::actionsChanged, this, &SettingsBase::updateViewActions);
        connect(searchText, &KLineEdit::textChanged, controller, &BaseMode::searchChanged);
        connect(controller, &BaseMode::viewChanged, this, &SettingsBase::viewChange);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : qAsConst(m_modules)) {
        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::CompletionMatch);
        setupMatch(data, match);
        qreal relevance = -1;

        auto checkMatchAndRelevance = [queryList, data, &relevance](const QString &value, qreal relevanceValue) {
            if (value.contains(queryList.first(), Qt::CaseInsensitive)) {
                relevance = relevanceValue;
                return true;
            }
            for (const QString &query : queryList) {
                if (relevance == -1 && value.contains(query, Qt::CaseInsensitive)) {
                    relevance = 0.5;
                    return true;
                }
            }
            return false;
        };

        if (checkMatchAndRelevance(data.name(), 0.8)) {
            if (data.name().startsWith(queryList[0], Qt::CaseInsensitive)) {
                relevance += 0.1;
            }
        } else {
            // check if the generic name or description matches
            if (!checkMatchAndRelevance(data.value(QStringLiteral("GenericName")), 0.65) && !checkMatchAndRelevance(data.description(), 0.5)) {
                // if not, check the keyowords
                const QString &query = ctx.query();
                const QStringList keywords = data.value(QStringLiteral("X-KDE-Keywords")).split(QLatin1Char(','));
                bool anyKeywordMatches = std::any_of(keywords.begin(), keywords.end(), [&query](const QString &keyword) {
                    return keyword.startsWith(query);
                });
                if (anyKeywordMatches) {
                    relevance = 0.2; // give it a lower relevance than if it had been found by name or description
                } else {
                    continue; // we haven't found any matching keyword, skip this KCM
                }
            }
        }

        if (isKinfoCenterKcm(data)) {
            match.setMatchCategory(i18n("System Information"));
        } else {
            match.setMatchCategory(i18n("System Settings"));
        }
        // KCMs are, on the balance, less relevant. Drop it ever so much. So they may get outscored
        // by an otherwise equally applicable match.
        relevance -= .001;

        match.setRelevance(relevance);

        matches << match;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](double one, double two, double factor) {
        return one + (two - one) * factor;
    }
```

#### AUTO 


```{c}
auto insertionIterator = uniquePluginIds.insert(m.pluginId());
```

