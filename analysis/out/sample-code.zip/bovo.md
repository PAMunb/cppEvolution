#### AUTO 


```{c}
auto p = new Standing(*this->standing);
```

#### AUTO 


```{c}
auto sample_size = (pos_T)sample_vect.size();
```

