#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : document->edges()) {
        out << edge->from()->id() << " " << edge->to()->id() << " " << edge->dynamicProperty("label").toString() <<'\n';
    }
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<FileFormatInterface>(metadata, this);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        emit colorChanged(m_edge->type()->style()->color());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
            properties.append(property + QString('='));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : nodeTypes) {
        if (type->id() == typeId) {
            newType = type;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        QVERIFY(node->x() - EPS >= margin);
        QVERIFY(node->y() - EPS >= margin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const edge : document->edges()) {
        out << processEdge(edge);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& property : properties) {
                        if (!property.isEmpty()) {
                            tmpEdgeType->addDynamicProperty(property.section('=',0,0));
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &nodeA : nodes) {
        for (const NodePtr &nodeB : nodes) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodesWithIntersections++;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
            QJsonObject propertyJson;
            propertyJson.insert("Name", property);
            propertyJson.insert("Value", node->dynamicProperty(property).toString());
            propertiesJson.append(propertyJson);
        }
```

#### AUTO 


```{c}
const auto edges = m_document->edges();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &nodeA : nodes) {
        for (const NodePtr &nodeB : nodes) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodeIntersections++;
            }
        }
    }
```

#### AUTO 


```{c}
const auto documentEdgeTypes = document->edgeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : metadataList) {
        qCDebug(GRAPHTHEORY_FILEFORMAT) << "Load Plugin: " << metadata.name();

        const auto result = KPluginFactory::instantiatePlugin<FileFormatInterface>(metadata, this);

        if (!result) {
            qCCritical(GRAPHTHEORY_FILEFORMAT) << "Error while loading plugin:" << result.errorString;
            continue;
        }

        d->backends.append(result.plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &node : m_document->nodes()) {
        if (node->id() == id) {
            return m_engine->newQObject(nodeWrapper(node),
                                        QScriptEngine::QtOwnership,
                                        QScriptEngine::AutoCreateDynamicProperties);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        node->destroy();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& t : list) {
        map.insert(id++, t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &n : nodes) {
        d->_buffer += QString("[Data %1]\n").arg(QString::number(n->id()));
        d->_buffer += QString("type : ") + QString::number(document->nodeTypes().indexOf(n->type())) + QChar('\n');
        const auto dynamicProperties = n->dynamicProperties();
        for (const QString &property : dynamicProperties) {
            d->_buffer += QString("%1 : %2 \n").arg(property).arg(n->dynamicProperty(property).toString());
        }
        d->_buffer += QChar('\n');
    }
```

#### AUTO 


```{c}
const auto importDocumentNodes = importDocument->nodes();
```

#### LAMBDA EXPRESSION 


```{c}
[this, button, idx] {
        showDock(button->isChecked(), idx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& e : node->inEdges()) {
            qDebug() << ".. in " << e->from()->dynamicProperty("label") << e->to()->dynamicProperty("label");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr edgeB : document->edges()) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgesWithCrosses++;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
            QString nodeStr = QString("\\node[nodetype%1] (%2) at (%3,%4) [label=left:%5]  {%6};").
                arg(nodeTypeIdMap[type]).
                arg(node->id()).
                arg(node->x()/resize).
                arg(node->y()*(-1)/resize).
                arg(node->property("name").toString()).
                arg(node->property("value").toString());
            out << nodeStr;
            out << '\n';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &property : m_node->dynamicProperties()) {
        // property value must not be set to QVariant::Invalid, else the properties are not accessible
        // from the script engine
        if (m_node->dynamicProperty(property).isValid()) {
            setProperty(property.toUtf8(), m_node->dynamicProperty(property));
        } else {
            setProperty(property.toUtf8(), QVariant::Int);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int neighbour : graph.adjacency[node]) {
        if (not visited[neighbour]) {
            children.push_back(neighbour);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF& point : positions) {
        xDisplacement = qMin(xDisplacement, point.x() - minX);
        yDisplacement = qMin(yDisplacement, point.y() - minY);
    }
```

#### AUTO 


```{c}
const auto nodes = d->m_nodes;
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointF& point : positions) {
        point.setX(point.x() - xDisplacement);
        point.setY(point.y() - yDisplacement);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () { update(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
            d->_buffer += QString("%1 : %2 \n").arg(property).arg(e->dynamicProperty(property).toString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : availablePlugins) {
        auto *action = new QAction(plugin->displayName(), this);
        action->setData(count++);
        connect(action, &QAction::triggered,
            this, &MainWindow::showEditorPluginDialog);
        actions << action;
    }
```

#### AUTO 


```{c}
const auto value = obj[key];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &node : documentNodes) {
        QJsonObject nodeJson;
        nodeJson.insert("Id", node->id());
        nodeJson.insert("Type", node->type()->id());
        nodeJson.insert("X", node->x());
        nodeJson.insert("Y", node->y());
        nodeJson.insert("Color", node->color().name());
        QJsonArray propertiesJson;
        const auto dynamicProperties = node->dynamicProperties();
        for (const QString &property : dynamicProperties) {
            QJsonObject propertyJson;
            propertyJson.insert("Name", property);
            propertyJson.insert("Value", node->dynamicProperty(property).toString());
            propertiesJson.append(propertyJson);
        }
        nodeJson.insert("Properties", propertiesJson);
        nodes.append(nodeJson);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : outEdges) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### AUTO 


```{c}
const auto outEdges = m_node->outEdges(typePtr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : std::as_const(d->m_edges)) {
        if (type && edge->type() != type) {
            continue;
        }
        if (edge->type()->direction() == EdgeType::Bidirectional) {
            inEdges.append(edge);
            continue;
        }
        if (edge->type()->direction() == EdgeType::Unidirectional
            && edge->to() == self()
        ) {
            inEdges.append(edge);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileFormatInterface * p :  std::as_const(d->backends)) {
        if (p->extensions().join(";").contains(suffix, Qt::CaseInsensitive)) {
            return p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr nodeB : document->nodes()) {
            if (nodeA != nodeB) {
                EdgePtr edge = Edge::create(nodeA, nodeB);
                edge->setType(edgeType);
            }
        }
```

#### AUTO 


```{c}
const auto edgeTypes = m_edge->from()->document()->edgeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : nodes) {
        nodeToIndexMap[node] = nextIndex;
        nextIndex++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Object *object : std::as_const(dataList)) {
        QList<QVariant> columnData;
        columnData << object->id();
        Item *objectItem = new Item(columnData, parent);
        objectItem->setDocumentAnchor(object->apiDocumentIdentifier(), QString());
        parent->appendChild(objectItem);

        QList<QVariant> propertyColumnData;
        propertyColumnData << i18n("Properties");
        Item *propertyContainer = new Item(propertyColumnData, objectItem);
        propertyContainer->setDocumentAnchor(object->apiDocumentIdentifier(), "properties");
        objectItem->appendChild(propertyContainer);
        const auto properties = object->properties();
        for (Property *property : properties) {
            QList<QVariant> columnData;
            columnData << property->name();
            Item *propertyItem = new Item(columnData, propertyContainer);
            propertyItem->setDocumentAnchor(object->apiDocumentIdentifier(),
                property->apiDocumentAnchor());
            propertyContainer->appendChild(propertyItem);
        }

        QList<QVariant> methodColumnData;
        methodColumnData << i18n("Methods");
        Item *methodContainer = new Item(methodColumnData, objectItem);
        methodContainer->setDocumentAnchor(object->apiDocumentIdentifier(), "methods");
        objectItem->appendChild(methodContainer);
        const auto methods = object->methods();
        for (Method *method : methods) {
            QList<QVariant> columnData;
            columnData << method->name();
            Item *methodProperty = new Item(columnData, methodContainer);
            methodProperty->setDocumentAnchor(object->apiDocumentIdentifier(),
                method->apiDocumentAnchor());
            methodContainer->appendChild(methodProperty);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        if (node->type() == type) {
            node->destroy();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& t : types) {
        qDebug() << ".." << t->name() << t->direction();
    }
```

#### AUTO 


```{c}
const auto &typeTest
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &type : nodeTypes) {
                type->addDynamicProperty(property);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : documentNodes) {
        QCOMPARE(node->edges().count(), 2);
    }
```

#### AUTO 


```{c}
const auto &property
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        QString name = node->property("name").toString();
        if (name == "LR_0") {
            from = node;
            QVERIFY(node->property("shape").toString() == "doublecircle");
        }
        if (name == "LR_2") {
            to = node;
            QVERIFY(node->property("shape").toString() == "circle");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr& edge : edges) {
        const int from = nodeToIndexMap[edge->from()];
        const int to = nodeToIndexMap[edge->to()];
        remappedEdges.push_back(RemappedEdge(from, to));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &type : nodeTypes) {
        complete->insertItems(type->dynamicProperties());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        QString name = node->dynamicProperty("label").toString();
        if (name == "student") {
            from = node;
        }
        if (name == "S-C") {
            to = node;
        }
        if (name == "name0" || name == "name1" || name == "name2") {
            QVERIFY(node->dynamicProperty("label").toString() == "name");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& e : node->outEdges()) {
            qDebug() << ".. out" << e->from()->dynamicProperty("label") << e->to()->dynamicProperty("label");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& d : project.codeDocuments()) {
        qDebug() << "Code document path=" << d->url().toLocalFile();
        QVERIFY(d->url().toLocalFile().startsWith(QDir::currentPath()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
            QJsonObject propertyJson;
            propertyJson.insert("Name", property);
            propertyJson.insert("Value", edge->dynamicProperty(property).toString());
            propertiesJson.append(propertyJson);
        }
```

#### AUTO 


```{c}
const auto nodeTypes = m_document->nodeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &document : d->m_codeDocuments) {
        connect(document, &KTextEditor::Document::modifiedChanged,
            this, &Project::modifiedChanged);
    }
```

#### AUTO 


```{c}
const auto properties = objectApi->properties();
```

#### RANGE FOR STATEMENT 


```{c}
for (const int child : children) { 
        const qreal childWedgeAngle = constrainedWedgeAngle * numberOfLeafs[child] /
                                      numberOfLeafs[node];

        radialLayoutHelper(graph, numberOfLeafs, nodeRadius, childWedgeAngle, childRotationAngle,
                           circleRadiusForChildren, nodeSeparation, child, visited, positions);
        
        childRotationAngle += childWedgeAngle;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Property *property : properties) {
            QList<QVariant> columnData;
            columnData << property->name();
            Item *propertyItem = new Item(columnData, propertyContainer);
            propertyItem->setDocumentAnchor(object->apiDocumentIdentifier(),
                property->apiDocumentAnchor());
            propertyContainer->appendChild(propertyItem);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        auto iter = std::find_if(document->edgeTypes().cbegin(), document->edgeTypes().cend(), [type](const EdgeTypePtr &testType) {
            return testType->id() == type->id();
        });
        QVERIFY(iter != document->edgeTypes().cend());
        QCOMPARE(type->id(), (*iter)->id());
        QCOMPARE(type->name(), (*iter)->name());
        QCOMPARE(type->style()->color().name(), (*iter)->style()->color().name());
        QCOMPARE(type->style()->isVisible(), (*iter)->style()->isVisible());
        QCOMPARE(type->style()->isPropertyNamesVisible(), (*iter)->style()->isPropertyNamesVisible());
        QCOMPARE(type->direction(), (*iter)->direction());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : document->nodes()) {
        out << processNode(node);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Object *obj : m_objectApiList) {
        if (obj->id() == identifier) {
            objectApi = obj;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto &node
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        const auto edges = graph->edges(type);
        for (const EdgePtr &edge : edges) {
            QString edgeStr = QString("\\path[edgetype%1] (%2) -- node[value] {%3} (%4);").
                arg(edgeTypeIdMap[type]).
                arg(edge->from()->id()).
                arg(edge->property("value").toString()).
                arg(edge->to()->id());
            out << edgeStr;
            out << '\n';
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : documentNodeTypes) {
        QJsonObject typeJson;
        typeJson.insert("Id", type->id());
        if (type->id() == -1) {
            qCCritical(GRAPHTHEORY_FILEFORMAT) << "Serializing unset ID, this will break import";
        }
        typeJson.insert("Name", type->name());
        typeJson.insert("Color", type->style()->color().name());
        typeJson.insert("Visible", type->style()->isVisible());
        typeJson.insert("PropertyNamesVisible", type->style()->isPropertyNamesVisible());
        QJsonArray propertiesJson;
        const auto dynamicProperties = type->dynamicProperties();
        for (const QString &property : dynamicProperties) {
            propertiesJson.append(property);
        }
        typeJson.insert("Properties", propertiesJson);
        nodeTypes.append(typeJson);
    }
```

#### AUTO 


```{c}
auto doc = KTextEditor::Editor::instance()->createDocument(nullptr);
```

#### AUTO 


```{c}
const auto& nodePtr
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : edges) {
        out << processEdge(edge);
    }
```

#### AUTO 


```{c}
const auto inEdges = m_node->inEdges();
```

#### AUTO 


```{c}
const auto edgeTypes = d->m_edgeTypes;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& nodePtr : document->nodes()) {
        const int nodeId = nodePtr->id();
        ui->rootComboBox->addItem(QString::number(nodeId), QVariant(nodeId));
    }
```

#### AUTO 


```{c}
const auto properties = object->properties();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& n : nodes) {
        if (n->x() < minX) {
            minX = n->x();
        }
        if (n->y() < minY) {
            minY = n->y();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &document : d->m_graphDocuments) {
        connect(document.data(), &GraphDocument::modifiedChanged,
            this, &Project::modifiedChanged);
    }
```

#### AUTO 


```{c}
const auto documentEdges = nodes.first()->document()->edges();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : documentNodes) {
        qDebug() << "Node" << node->dynamicProperty("label");
        for(const auto& e : node->outEdges()) {
            qDebug() << ".. out" << e->from()->dynamicProperty("label") << e->to()->dynamicProperty("label");
        }
        for(const auto& e : node->inEdges()) {
            qDebug() << ".. in " << e->from()->dynamicProperty("label") << e->to()->dynamicProperty("label");
        }
        QCOMPARE(node->outEdges().size(), 1);
        QCOMPARE(node->inEdges().size(), 1);
        QCOMPARE(node->edges().count(), 2);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &type : nodeTypes) {
        type->destroy();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KTextEditor::Document *document : std::as_const(d->m_codeDocuments)) {
        document->save();
        tar.addLocalFile(document->url().toLocalFile(), document->url().fileName());
    }
```

#### AUTO 


```{c}
const auto documentNodes = m_document->nodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr nodeB : document->nodes()) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodeIntersections++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr nodeB : document->nodes()) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodesWithIntersections++;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &e : edges) {
        d->_buffer += QString("[Pointer %1->%2]\n").
            arg(QString::number(e->from()->id())).
            arg(QString::number(e->to()->id())).toUtf8();
        d->_buffer += QString("type : ") + QString::number(document->edgeTypes().indexOf(e->type())) + QChar('\n');
        const auto dynamicProperties = e->dynamicProperties();
        for (const QString &property : dynamicProperties) {
            d->_buffer += QString("%1 : %2 \n").arg(property).arg(e->dynamicProperty(property).toString());
        }
        d->_buffer += QChar('\n');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &edge : document->edges()) {
            out << "edge [\n";
            out << processEdge(edge);
            out << "]\n";
        }
```

#### AUTO 


```{c}
const auto nodes = document->nodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : metadataList) {
        KPluginFactory *factory = KPluginLoader(metadata.fileName()).factory();
        EditorPluginInterface *plugin = factory->create<EditorPluginInterface>(this);
        plugin->setDisplayName(metadata.name());
        d->m_plugins.append(plugin);
        qCDebug(GRAPHTHEORY_GENERAL) << "Loaded plugin:" << metadata.name();
    }
```

#### AUTO 


```{c}
const auto nodes = m_node->document()->nodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : documentEdges) {
        QJsonObject edgeJson;
        edgeJson.insert("Type", edge->type()->id());
        edgeJson.insert("From", edge->from()->id());
        edgeJson.insert("To", edge->to()->id());
        QJsonArray propertiesJson;
        const auto dynamicProperties = edge->dynamicProperties();
        for (const QString &property : dynamicProperties) {
            QJsonObject propertyJson;
            propertyJson.insert("Name", property);
            propertyJson.insert("Value", edge->dynamicProperty(property).toString());
            propertiesJson.append(propertyJson);
        }
        edgeJson.insert("Properties", propertiesJson);
        edges.append(edgeJson);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& n : nodes) {
            n->setX(n->x() - minX);
            n->setY(n->y() - minY);
        }
```

#### AUTO 


```{c}
const auto methods = objectApi->methods();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
            propertiesJson.append(property);
        }
```

#### AUTO 


```{c}
const auto dynamicProperties = document->nodeTypes().at(typeID)->dynamicProperties();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : typeEdges) {
        edge->destroy();
    }
```

#### AUTO 


```{c}
const auto dynamicProperties = e->dynamicProperties();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->inEdges(typePtr)) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edgeA : edges) {
        for (const EdgePtr &edgeB : edges) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgesWithCrosses++;
                break;
            }
        }
    }
```

#### AUTO 


```{c}
const auto edgeTypes = importDocument->edgeTypes();
```

#### AUTO 


```{c}
const auto& e
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        complete->insertItems(type->dynamicProperties());
    }
```

#### AUTO 


```{c}
const auto& d
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : std::as_const(d->m_edges)) {
        if (type && edge->type() != type) {
            continue;
        }
        if (edge->type()->direction() == EdgeType::Bidirectional) {
            outEdges.append(edge);
            continue;
        }
        if (edge->type()->direction() == EdgeType::Unidirectional
            && edge->from() == self()
        ) {
            outEdges.append(edge);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QVector<int> changedRoles;
            changedRoles.append(VisibilityRole);
            Q_EMIT dataChanged(index(0), index(d->m_edge->dynamicProperties().count() - 1), changedRoles);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RemappedEdge& edge : graph.edges) {
            const int i = edge.first;
            const int j = edge.second;
            QVector2D direction(currentPositions[j] - currentPositions[i]);
            const qreal distance = direction.length();

            //Do not use attraction forces between nodes that are already too close.
            if (distance < 3 * nodeRadius) {
                continue;
            }

            direction.normalize();
            const qreal force = attractionForce * distance * distance / k;
            
            nodeForce[i] += force * direction;
            nodeForce[j] -= force * direction;
        }
```

#### AUTO 


```{c}
auto document = m_project->codeDocuments().at(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        if (type->direction() == EdgeType::Bidirectional) {
            continue;
        }
        QList< QPair< NodePtr, NodePtr > > newEdges;
        const auto edges = m_document->edges(type);
        for (const EdgePtr &e : edges) {
            newEdges << QPair< NodePtr, NodePtr >(e->to(), e->from());
            e->destroy();
        }

        for (int i = 0; i < newEdges.count(); ++i) {
            EdgePtr edge = Edge::create(newEdges[i].first, newEdges[i].second);
            edge->setType(type);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const edge : document->edges()) {
        out << edge->from()->id() << " " << edge->to()->id() << " " << edge->dynamicProperty("label").toString() <<'\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Object *object : m_objectApiList) {
        switch (object->componentType()) {
        case Object::KernelModule:
            kernelModuleList.append(QVariant::fromValue<QObject*>(object));
            break;
        case Object::Document:
            elementList.append(QVariant::fromValue<QObject*>(object));
            break;
        case Object::Edge:
            elementList.append(QVariant::fromValue<QObject*>(object));
            break;
        case Object::Node:
            elementList.append(QVariant::fromValue<QObject*>(object));
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&numberOfLeafs](const int i, const int j) {
            return numberOfLeafs[i] < numberOfLeafs[j];
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
            if (type->id() == edgeJson["Type"].toInt()) {
                typeToSet = type;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileFormatInterface * f : exportBackends) { //TODO fragile code
        nameFilter << f->extensions();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &property : node->dynamicPropertyNames()) {
        nodeStr.append(", ");
        nodeStr.append(QString(" %1 = \"%2\" ").arg(QString(property)).arg(node->property(property).toString()));
    }
```

#### AUTO 


```{c}
const auto edges = m_document->edges(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : documentEdgeTypes) {
        QJsonObject typeJson;
        typeJson.insert("Id", type->id());
        if (type->id() == -1) {
            qCCritical(GRAPHTHEORY_FILEFORMAT) << "Serializing unset ID, this will break import";
        }
        typeJson.insert("Name", type->name());
        typeJson.insert("Color", type->style()->color().name());
        typeJson.insert("Visible", type->style()->isVisible());
        typeJson.insert("PropertyNamesVisible", type->style()->isPropertyNamesVisible());
        typeJson.insert("Direction", direction(type->direction()));
        QJsonArray propertiesJson;
        const auto dynamicProperties = type->dynamicProperties();
        for (const QString &property : dynamicProperties) {
            propertiesJson.append(property);
        }
        typeJson.insert("Properties", propertiesJson);
        edgeTypes.append(typeJson);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int REPETITIONS = 30;
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        registerWrapper(node);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : nodes) {
        const int index = nodeToIndexMap[node];
        positions[index] = QPointF(node->x(), node->y());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : types) {
        if (type != m_type && type->id() == m_id->value()) {
            valid = false;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : metadataList) {
        const auto result = KPluginFactory::instantiatePlugin<EditorPluginInterface>(metadata, this);

        if (!result) {
            qCWarning(GRAPHTHEORY_GENERAL) << "Failed to load editor plugin" << result.errorText;
            continue;
        }

        result.plugin->setDisplayName(metadata.name());
        d->m_plugins.append(result.plugin);
        qCDebug(GRAPHTHEORY_GENERAL) << "Loaded plugin:" << metadata.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KActionCollection *ac : allCollections) {
        if (ac->action("file_save")) {
            ac->action("file_save")->setDisabled(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GraphDocumentPtr &document : std::as_const(d->m_graphDocuments)) {
        if (document->isModified()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto const &node
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr edge : document->edges()) {
        if (edge->type()->direction() != EdgeType::Bidirectional) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &paragraph : m_description) {
        list.append(paragraph);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KTextEditor::Document *document : std::as_const(m_codeDocuments)) {
        QJsonObject docInfo;
        docInfo.insert("file", document->url().fileName());
        codeDocs.append(docInfo);
        codeDocNames.append(m_documentNames.value(document));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : document->edges()) {
        out << processEdge(edge);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : nodeEges) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &e : edges) {
        if (e->to() == e->from()) {
            e->destroy();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        qCDebug(GRAPHTHEORY_FILEFORMAT) << "test NODE " << node->dynamicProperty("name").toString();
    }
```

#### AUTO 


```{c}
const auto nodeTypes = document->nodeTypes();
```

#### CONST EXPRESSION 


```{c}
constexpr int MAXIMUM_NUMBER_OF_ITERATIONS = 100;
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        node_mapping[node] = counter++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
            if (node->id() == edgeJson["From"].toInt()) {
                fromNode = node;
            }
            if (node->id() == edgeJson["To"].toInt()) {
                toNode = node;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& d : loadedDocs) {
        qDebug() << "Code document path=" << d->url().toLocalFile();
        QVERIFY(d->url().toLocalFile().startsWith(loadedProject.workingDir()));
    }
```

#### AUTO 


```{c}
const auto typeEdges = edges(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (Method *method : methods) {
            QList<QVariant> columnData;
            columnData << method->name();
            Item *methodProperty = new Item(columnData, methodContainer);
            methodProperty->setDocumentAnchor(object->apiDocumentIdentifier(),
                method->apiDocumentAnchor());
            methodContainer->appendChild(methodProperty);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->outEdges()) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr nodeA : document->nodes()) {
        for (const NodePtr nodeB : document->nodes()) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodeIntersections++;
            }
        }
    }
```

#### AUTO 


```{c}
const auto edgeTypes = m_node->document()->edgeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        QVERIFY(node->x() - nodeRadius >= margin - EPS);
        QVERIFY(node->y() - nodeRadius >= margin - EPS);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, button, idx] {

        // Force uncheck the button because of the exclusive
        // Without this the toolbar buttons cannot be all unchecked
        // after one is clicked4
        if (button->wasChecked) {
            _btnGroup->setExclusive(false);
            button->setChecked(false);
            _btnGroup->setExclusive(true);

            button->wasChecked = false;
        } else {
            button->wasChecked = true;
        }

        showDock(button->isChecked(), idx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : importDocument->edgeTypes()) {
        auto iter = std::find_if(document->edgeTypes().cbegin(), document->edgeTypes().cend(), [type](const EdgeTypePtr &testType) {
            return testType->id() == type->id();
        });
        QVERIFY(iter != document->edgeTypes().cend());
        QCOMPARE(type->id(), (*iter)->id());
        QCOMPARE(type->name(), (*iter)->name());
        QCOMPARE(type->style()->color().name(), (*iter)->style()->color().name());
        QCOMPARE(type->style()->isVisible(), (*iter)->style()->isVisible());
        QCOMPARE(type->style()->isPropertyNamesVisible(), (*iter)->style()->isPropertyNamesVisible());
        QCOMPARE(type->direction(), (*iter)->direction());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileFormatInterface *backend : std::as_const(d->backends)) {
        switch(type) {
            case Import:
                if (backend->pluginCapability() == FileFormatInterface::ImportOnly
                    || backend->pluginCapability() == FileFormatInterface::ImportAndExport)
                {
                    backends.append(backend);
                }
                break;
            case Export:
                if (backend->pluginCapability() == FileFormatInterface::ExportOnly
                    || backend->pluginCapability() == FileFormatInterface::ImportAndExport)
                {
                    backends.append(backend);
                }
                break;
            default:
                break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &typeTest : nodeTypes) {
        if (typeTest->id() == type) {
            typePtr = typeTest;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const NodePtr &n : document->nodes()) {
            out << QString("node [\n id \"%1\" \n").arg(n->dynamicProperty("name").toString());
            out << processNode(n);
            out << "]\n";

        }
```

#### AUTO 


```{c}
const auto nodeEdges = m_node->edges();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        QString name = node->dynamicProperty("name").toString();
        int index = nodeNames.indexOf(name);
        if (index == -1) {
            qCDebug(GRAPHTHEORY_FILEFORMAT) << "Node "<< name << " was created unnecessarily.";
        }
        QVERIFY(index != -1);
        nodeNames.removeAt(index);
    }
```

#### AUTO 


```{c}
const auto edgeTypes = m_document->edgeTypes();
```

#### AUTO 


```{c}
auto const &edge
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &property : dynamicProperties) {
        // property value must not be set to QVariant::Invalid, else the properties are not accessible
        // from the script engine
        if (m_node->dynamicProperty(property).isValid()) {
            setProperty(property.toUtf8(), m_node->dynamicProperty(property));
        } else {
            setProperty(property.toUtf8(), QVariant::Int);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &nodeB : nodes) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodesWithIntersections++;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node :nodes) {
        node_mapping[node] = counter++;
    }
```

#### AUTO 


```{c}
auto plugin
```

#### LAMBDA EXPRESSION 


```{c}
[type](const EdgeTypePtr &testType) {
            return testType->id() == type->id();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileFormatInterface *f : std::as_const(d->backends)) {
        delete f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : edges) {
        d->m_document->remove(edge);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        loadObjectApi(QUrl::fromLocalFile(dir + '/' + file));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { openProject(); }
```

#### LAMBDA EXPRESSION 


```{c}
[typeJson](const EdgeTypePtr &testType) {
            return testType->id() == typeJson["Id"].toInt();
        }
```

#### AUTO 


```{c}
auto const edge
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : edges) {
        D[map[edge->from()->id()]][map[edge->to()->id()]] = edge->dynamicProperty(lengthProperty).toDouble();
        if (edge->type()->direction() == EdgeType::Bidirectional) {
            D[map[edge->to()->id()]][map[edge->from()->id()]] = edge->dynamicProperty(lengthProperty).toDouble();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->inEdges(typePtr)) {
        if (edge->type()->direction() == EdgeType::Unidirectional) {
            precessors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            continue;
        } else {
            if (m_node == edge->from()) {
                precessors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            } else {
                precessors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto dynamicProperties = document->edgeTypes().at(typeID)->dynamicProperties();
```

#### AUTO 


```{c}
const auto numberOfLeafsComparator = [&numberOfLeafs](const int i, const int j) {
            return numberOfLeafs[i] < numberOfLeafs[j];
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : edges) {
        registerWrapper(edge);
    }
```

#### AUTO 


```{c}
const auto edges = d->m_edges;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &paragraph : m_description) {
        list << paragraph;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GraphTheory::GraphDocumentPtr &document : std::as_const(d->m_graphDocuments)) {
        usedFileNames.append(document->documentUrl().fileName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        out << processNode(node);
    }
```

#### AUTO 


```{c}
const auto dynamicProperties = m_edge->dynamicProperties();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : nodes) {
            xList << node->x();
            yList << node->y();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GraphTheory::GraphDocumentPtr &document : std::as_const(d->m_graphDocuments)) {
        document->documentSave();
        tar.addLocalFile(document->documentUrl().toLocalFile(), document->documentUrl().fileName());
    }
```

#### AUTO 


```{c}
const auto documentEdges = document->edges();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : outEdges) {
        if (edge->type()->direction() == EdgeType::Unidirectional) {
            successors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            continue;
        } else {
            if (m_node == edge->from()) {
                successors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            } else {
                successors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto nodes = m_document->nodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &node : nodes) {
        if (node != m_node && node->id() == ui->id->value()) {
            valid = false;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto dynamicProperties = type->dynamicProperties();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &property : edge->dynamicPropertyNames()) {
        if (firstProperty == true) {
                firstProperty = false;
                edgeStr.append("[");
            } else {
                edgeStr.append(", ");
        }
        edgeStr.append(QString(" %1 = \"%2\" ").arg(QString(property)).arg(edge->property(property).toString()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &nodeB : nodes) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodeIntersections++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &type : nodeTypes) {
        ui->nodeType->addItem(type->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : nodes) {
        Vertex v = boost::vertex(node_mapping[node], graph);
        node->setX(positionMap[v][0]);
        node->setY(positionMap[v][1]);
    }
```

#### AUTO 


```{c}
const auto docs = project.codeDocuments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->inEdges()) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        type->destroy();
    }
```

#### AUTO 


```{c}
const auto documentNodeTypes = document->nodeTypes();
```

#### AUTO 


```{c}
auto path = d->m_workingDirectory.path() + QLatin1Char('/') + filePath + QStringLiteral(".js");
```

#### AUTO 


```{c}
const auto dynamicProperties = edge->dynamicProperties();
```

#### AUTO 


```{c}
const auto &type
```

#### AUTO 


```{c}
auto iter = std::find_if(document->edgeTypes().cbegin(), document->edgeTypes().cend(), [type](const EdgeTypePtr &testType) {
            return testType->id() == type->id();
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto nodePtr : document->nodes()) {
        const int nodeId = nodePtr->id();
        ui->rootComboBox->addItem(QString::number(nodeId), QVariant(nodeId));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->inEdges()) {
        if (edge->type()->direction() == EdgeType::Unidirectional) {
            precessors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            continue;
        } else {
            if (m_node == edge->from()) {
                precessors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            } else {
                precessors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto dynamicProperties = n->dynamicProperties();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QVector<int> changedRoles;
            changedRoles.append(VisibilityRole);
            emit dataChanged(index(0), index(d->m_node->dynamicProperties().count() - 1), changedRoles);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &property : n->dynamicProperties()) {
        node.append(QString("%1 %2\n").arg(property).arg(n->dynamicProperty(property).toString()));
    }
```

#### AUTO 


```{c}
const auto nodePtr
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& d : loadedProject.codeDocuments()) {
        qDebug() << "Code document path=" << d->url().toLocalFile();
        QVERIFY(d->url().toLocalFile().startsWith(loadedProject.workingDir()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        if (type->id() == typeId) {
            newType = type;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &e : edges) {
        e->destroy();
    }
```

#### AUTO 


```{c}
const auto edges = m_node->edges(typePtr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : inEdges) {
        if (edge->type()->direction() == EdgeType::Unidirectional) {
            precessors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            continue;
        } else {
            if (m_node == edge->from()) {
                precessors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            } else {
                precessors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<EditorPluginInterface>(metadata, this);
```

#### AUTO 


```{c}
const auto& t
```

#### AUTO 


```{c}
const auto edges = graph->edges(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
        // property value must not be set to QVariant::Invalid, else the properties are not accessible
        // from the script engine
        if (m_edge->dynamicProperty(property).isValid()) {
            setProperty(property.toUtf8(), m_edge->dynamicProperty(property));
        } else {
            setProperty(property.toUtf8(), QVariant::Int);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr node : document->nodes()) {
        QVERIFY(node->x() - EPS >= margin);
        QVERIFY(node->y() - EPS >= margin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int neighbour : graph.adjacency[node]) {
            if (not visited[neighbour]) {
                stack.push(neighbour);
                visited[neighbour] = true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QVector<int> changedRoles;
            changedRoles.append(VisibilityRole);
            Q_EMIT dataChanged(index(0), index(d->m_node->dynamicProperties().count() - 1), changedRoles);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int neighbour : graph.adjacency[node]) {
            if (not visited[neighbour]) {
                degree[neighbour]--;
                if (degree[neighbour] == 1) {
                    queue.enqueue(neighbour);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &node : m_document->nodes()) {
        if (node->id() == id) {
            return m_engine->newQObject(nodeWrapper(node),
                                        QScriptEngine::AutoOwnership,
                                        QScriptEngine::AutoCreateDynamicProperties);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->edges(typePtr)) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edgeA : edges) {
        for (const EdgePtr &edgeB : edges) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgeCrosses++;
            }
        }
    }
```

#### AUTO 


```{c}
const auto documentNodes = document->nodes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edgeB : edges) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgesWithCrosses++;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const qreal nodeRadius : nodeRadiusValues) {
                QString entryName = QString("%1#%2#%3").arg(file.path()).arg(margin).arg(nodeRadius);

                QTest::newRow(entryName.toLocal8Bit().constData()) << file << margin << nodeRadius;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : metadataList) {
        loader.setFileName(metadata.fileName());

        qCDebug(GRAPHTHEORY_FILEFORMAT) << "Load Plugin: " << metadata.name();
        if (!loader.load()) {
            qCCritical(GRAPHTHEORY_FILEFORMAT) << "Error while loading plugin: " << metadata.name();
        }

        KPluginFactory *factory = KPluginLoader(loader.fileName()).factory();
        FileFormatInterface *plugin = factory->create<FileFormatInterface>(this);
        d->backends.append(plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& property : properties) {
                        if (!property.isEmpty()) {
                            nodeTypeMap[tmpDataTypeId]->addDynamicProperty(property.section('=',0,0));
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        if (node->id() == m_root) {
            root = node;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : m_node->document()->nodeTypes()) {
        if (type->id() == typeId) {
            newType = type;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->outEdges(typePtr)) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : std::as_const(d->m_nodes)) {
        if (node->type() == type) {
            nodes.append(node);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        positionMap[counter][0] = node->x();
        positionMap[counter][1] = node->y();
        counter++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (m_visible->isChecked()) {
            m_visible->setIcon(QIcon::fromTheme("layer-visible-on"));
        } else {
            m_visible->setIcon(QIcon::fromTheme("layer-visible-off"));
        }
    }
```

#### AUTO 


```{c}
const auto nodeEges = m_node->edges(typePtr);
```

#### AUTO 


```{c}
const auto nodeTypes = d->m_nodeTypes;
```

#### AUTO 


```{c}
const auto nodes = graph->nodes(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : nodes) {
        xList << node->x();
        yList << node->y();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        Vertex v = boost::vertex(node_mapping[node], graph);
        node->setX(positionMap[v][0]);
        node->setY(positionMap[v][1]);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (QColor) { update(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : availablePlugins) {
        QAction *action = new QAction(plugin->displayName(), this);
        action->setData(count++);
        connect(action, &QAction::triggered,
            this, &MainWindow::showEditorPluginDialog);
        actions << action;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GraphTheory::GraphDocumentPtr &document : std::as_const(m_graphDocuments)) {
        QJsonObject docInfo;
        docInfo.insert("file", document->documentUrl().fileName());
        docInfo.insert("name", document->documentName());
        graphDocs.append(docInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->edges(typePtr)) {
        if (m_node == edge->from()) {
            neighbors.insert(m_documentWrapper->nodeWrapper(edge->to()));
        } else {
            neighbors.insert(m_documentWrapper->nodeWrapper(edge->from()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const NodePtr &node : document->nodes()) {
        out << node->id();
        out << " ";
        out << node->dynamicProperty("label").toString(); //TODO change to selectable property
        out << '\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : nodes) {
        const int index = nodeToIndexMap[node];
        const QPointF& position = positions[index];
        node->setX(position.x());
        node->setY(position.y());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr edgeA : document->edges()) {
        for (const EdgePtr edgeB : document->edges()) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgesWithCrosses++;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : documentNodes) {
        xSum += node->x();
        ySum += node->y();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (NodeTypePtr) { update(); }
```

#### AUTO 


```{c}
const auto outEdges = m_node->outEdges();
```

#### RANGE FOR STATEMENT 


```{c}
for (Property *property : properties) {
        propertyList.insert(property->name(), QVariant::fromValue<QObject*>(property));
    }
```

#### AUTO 


```{c}
const auto types = m_type->document()->edgeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : inEdges) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Method *method : methods) {
        methodList.append(QVariant::fromValue<QObject*>(method));
    }
```

#### AUTO 


```{c}
auto context = new KLocalizedContext(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr& edge : documentEdges) {
        edges[counter++] = BoostEdge(node_mapping[edge->from()], node_mapping[edge->to()]);
    }
```

#### AUTO 


```{c}
const auto allCollections = KActionCollection::allCollections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &node : nodes) {
        out << node->id();
        out << " ";
        out << node->dynamicProperty("label").toString(); //TODO change to selectable property
        out << '\n';
    }
```

#### AUTO 


```{c}
const auto nodeTypes = m_node->document()->nodeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &typeTest : edgeTypes) {
        if (typeTest->id() == type) {
            typePtr = typeTest;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto edges = document->edges();
```

#### AUTO 


```{c}
auto& n
```

#### AUTO 


```{c}
auto iter = std::find_if(types.cbegin(), types.cend(), [typeJson](const EdgeTypePtr &testType) {
            return testType->id() == typeJson["Id"].toInt();
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr& type : edgeTypes) {
                type->addDynamicProperty(property);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr nodeA : document->nodes()) {
        for (const NodePtr nodeB : document->nodes()) {
            if (nodeA != nodeB and intersects(nodeA, nodeB)) {
                numberOfNodesWithIntersections++;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &type : edgeTypes) {
        ui->edgeType->addItem(type->name());
    }
```

#### AUTO 


```{c}
const auto &edge
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &typeTest : m_node->document()->edgeTypes()) {
        if (typeTest->id() == type) {
            typePtr = typeTest;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->outEdges(typePtr)) {
        if (edge->type()->direction() == EdgeType::Unidirectional) {
            successors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            continue;
        } else {
            if (m_node == edge->from()) {
                successors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            } else {
                successors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto loadedDocs = loadedProject.codeDocuments();
```

#### AUTO 


```{c}
const auto &document
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &data){
            return data.serviceTypes().contains("rocs/graphtheory/fileformat");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileFormatInterface * f : importBackends) {
        ext.append(f->extensions().join(""));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->outEdges()) {
        if (edge->type()->direction() == EdgeType::Unidirectional) {
            successors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            continue;
        } else {
            if (m_node == edge->from()) {
                successors.insert(m_documentWrapper->nodeWrapper(edge->to()));
            } else {
                successors.insert(m_documentWrapper->nodeWrapper(edge->from()));
            }
        }
    }
```

#### AUTO 


```{c}
const auto nodeTypes = graph->nodeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : std::as_const(d->m_edges)) {
        if (edge->type() == type) {
            edges.append(edge);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &type : nodeTypes) {
        const auto nodes = graph->nodes(type);
        for (const NodePtr &node : nodes) {
            QString nodeStr = QString("\\node[nodetype%1] (%2) at (%3,%4) [label=left:%5]  {%6};").
                arg(nodeTypeIdMap[type]).
                arg(node->id()).
                arg(node->x()/resize).
                arg(node->y()*(-1)/resize).
                arg(node->property("name").toString()).
                arg(node->property("value").toString());
            out << nodeStr;
            out << '\n';
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KTextEditor::Document *document : std::as_const(d->m_codeDocuments)) {
        if (document->isModified()) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& d : docs) {
        qDebug() << "Code document path=" << d->url().toLocalFile();
        QVERIFY(d->url().toLocalFile().startsWith(QDir::currentPath()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr nodeB : document->nodes()) {
            if (nodeA != nodeB) {
                Edge::create(nodeA, nodeB);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodeTypePtr &type : nodeTypes) {
            if (type->id() == nodeJson["Type"].toInt()) {
                typeToSet = type;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : edges) {
        edge->destroy();
    }
```

#### AUTO 


```{c}
const auto types = m_type->document()->nodeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &e : edges) {
            newEdges << QPair< NodePtr, NodePtr >(e->to(), e->from());
            e->destroy();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        Q_EMIT colorChanged(m_edge->type()->style()->color());
    }
```

#### AUTO 


```{c}
const auto dynamicProperties = m_node->dynamicProperties();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->edges()) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : m_node->edges()) {
        if (m_node == edge->from()) {
            neighbors.insert(m_documentWrapper->nodeWrapper(edge->to()));
        } else {
            neighbors.insert(m_documentWrapper->nodeWrapper(edge->from()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<int, int>& edge : remappedGraph.edges) {
        remappedGraph.adjacency[edge.first].push_back(edge.second);
        remappedGraph.adjacency[edge.second].push_back(edge.first);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](EdgeTypePtr) { update(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const qreal margin : marginValues) {
            for (const qreal nodeRadius : nodeRadiusValues) {
                QString entryName = QString("%1#%2#%3").arg(file.path()).arg(margin).arg(nodeRadius);

                QTest::newRow(entryName.toLocal8Bit().constData()) << file << margin << nodeRadius;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &property : dynamicProperties) {
            d->_buffer += QString("%1 : %2 \n").arg(property).arg(n->dynamicProperty(property).toString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr edgeA : document->edges()) {
        for (const EdgePtr edgeB : document->edges()) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgeCrosses++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : edges) {
            QString edgeStr = QString("\\path[edgetype%1] (%2) -- node[value] {%3} (%4);").
                arg(edgeTypeIdMap[type]).
                arg(edge->from()->id()).
                arg(edge->property("value").toString()).
                arg(edge->to()->id());
            out << edgeStr;
            out << '\n';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr edgeB : document->edges()) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgeCrosses++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int neighbour : graph.adjacency[node]) {
        if (not visited[neighbour]) {
            isLeaf = false;
            calculateNumberOfLeafs(graph, neighbour, visited, numberOfLeafs);
            numberOfLeafs[node] += numberOfLeafs[neighbour];
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr node : m_document->nodes()) {
        if (node->id() == m_root) {
            root = node;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto inEdges = m_node->inEdges(typePtr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr& node : importDocumentNodes) {
        if (node->id() == 1) {
            testNode = node;
        }
    }
```

#### AUTO 


```{c}
const auto methods = object->methods();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const edge : document->edges()) {
            out << "edge [\n";
//                  foreach (QByteArray p, e->dynamicPropertyNames()){
//                    out << p << " " << e->property(p).toString() << "\n";
//                  }
            out << processEdge(edge);

            out << "]\n";
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : edges) {
        if (m_node == edge->from()) {
            neighbors.insert(m_documentWrapper->nodeWrapper(edge->to()));
        } else {
            neighbors.insert(m_documentWrapper->nodeWrapper(edge->from()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NodePtr &nodeB : nodes) {
            if (nodeA != nodeB) {
                EdgePtr edge = Edge::create(nodeA, nodeB);
                edge->setType(edgeType);
            }
        }
```

#### AUTO 


```{c}
const auto &metadata
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : nodeEdges) {
        edges.append(m_documentWrapper->edgeWrapper(edge));
    }
```

#### AUTO 


```{c}
const auto edgeTypes = document->edgeTypes();
```

#### AUTO 


```{c}
auto *stackLayout = qobject_cast<QStackedLayout*>(layout());
```

#### AUTO 


```{c}
const auto edgeTypes = graph->edgeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &edge : edges) {
        out << edge->from()->id() << " " << edge->to()->id() << " " << edge->dynamicProperty("label").toString() <<'\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& file : files) {
        for (const qreal margin : marginValues) {
            for (const qreal nodeRadius : nodeRadiusValues) {
                QString entryName = QString("%1#%2#%3").arg(file.path()).arg(margin).arg(nodeRadius);

                QTest::newRow(entryName.toLocal8Bit().constData()) << file << margin << nodeRadius;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgeTypePtr &typeTest : edgeTypes) {
        if (typeTest->id() == type) {
            typePtr = typeTest;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *action = new QAction(plugin->displayName(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &property : e->dynamicProperties()) {
        edge.append(QString("%1 %2\n").arg(property).arg(e->dynamicProperty(property).toString()));
    }
```

#### AUTO 


```{c}
const auto edges = m_node->edges();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            QVector<int> changedRoles;
            changedRoles.append(VisibilityRole);
            emit dataChanged(index(0), index(d->m_edge->dynamicProperties().count() - 1), changedRoles);
        }
```

#### AUTO 


```{c}
const auto dynamicProperties = node->dynamicProperties();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edgeB : edges) {
            if (edgeA != edgeB and crosses(edgeA, edgeB)) {
                numberOfEdgeCrosses++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EdgePtr &edge : edges) {
        if (edge->type()->direction() != EdgeType::Bidirectional) {
            return false;
        }
    }
```

