#### AUTO 


```{c}
const auto lst = d.propertyNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (const struct BackendDescriptor &bd : backendList) {
        m_select->addItem(bd.name);
        m_backends.insert(bd.name, bd);
    }
```

#### AUTO 


```{c}
const auto backend = m_backends[item->text()];
```

#### RANGE FOR STATEMENT 


```{c}
for (const Phonon::VideoCaptureDevice &vcd : phononList) {
        experimentalList << phononVcdToExperimentalVcd(vcd);
    }
```

#### AUTO 


```{c}
const auto index = iidPreference.indexOf(bd.iid);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        save();
        qApp->quit();
    }
```

#### AUTO 


```{c}
const auto &backend = backendList.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const BackendDescriptor &descriptor : qAsConst(foundBackends)) {
        if (tryCreateBackend(descriptor.pluginPath))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : plugins) {
            Phonon::BackendDescriptor bd(libPath + plugin);
            if (!bd.isValid) {
                continue;
            }

            const auto index = iidPreference.indexOf(bd.iid);
            if (index >= 0) {
                // Apply a weight. Weight strongly influences sort order.
                bd.weight = iidPreference.size() - index;
            }
            backendList.append(bd);
        }
```

#### AUTO 


```{c}
const auto &backend
```

#### AUTO 


```{c}
const auto backends = Phonon::Factory::findBackends();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &propertyName : propertyNames) {
        dbg.nospace() << "  " << propertyName << ": " <<
                         d.property(propertyName).toString() << "\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &iid : qAsConst(iidPreference)) {
        // This is slightly inefficient but we only have 2 backends :P
        // Also using a list requires less overall code than QMap<iid,desc>.
        QList<BackendDescriptor>::iterator it;
        for (it = foundBackends.begin(); it != foundBackends.end(); ++it) {
            const BackendDescriptor &descriptor = *it;
            if (descriptor.iid != iid) {
                continue;
            }
            if (tryCreateBackend(descriptor.pluginPath)) {
                return true;
            } else { // Drop backends that failed to construct.
                it = foundBackends.erase(it);
                if (it == foundBackends.end())
                    break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QListWidgetItem *selected : selectedList) {
        const int row = m_select->row(selected);
        if (row + 1 >= m_select->count()) {
            continue;
        }
        QListWidgetItem *taken = m_select->takeItem(row + 1);
        m_select->insertItem(row, taken);
        selectionChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : propertyNames) {
#else
    Q_FOREACH (const QByteArray &propertyName, d.propertyNames()) {
#endif
        dbg.nospace() << "  " << propertyName << ": " <<
                         d.property(propertyName).toString() << "\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Phonon::MediaSource &ms : mediaList) {
        Q_ASSERT(static_cast<MediaSource::Type>(ms.type()) != Link);
        Q_UNUSED(ms);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QListWidgetItem *selected : selectedList) {
        const int row = m_select->row(selected);
        if (row <= 0) {
            continue;
        }
        QListWidgetItem *taken = m_select->takeItem(row - 1);
        m_select->insertItem(row, taken);
        selectionChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : lst) {
        dbg.nospace() << "  " << propertyName << ": " <<
                         d.property(propertyName).toString() << "\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : qAsConst(newOrder)) {
        int found = currentList.indexOf(i);
        if (found < 0) {
            // It's not in the list, so something is odd (e.g. client error). Ignore it.
            continue;
        }

        // Iterate through the list from this point onward. If there are hidden devices
        // immediately following, take them too.
        newList.append(currentList.takeAt(found));

        while (found < currentList.size()) {
            bool hidden = true;

            switch (type) {
#ifndef PHONON_NO_AUDIOCAPTURE
            case AudioCaptureDeviceType:
                hidden = isHiddenAudioCaptureDevice(config, currentList.at(found));
                break;
#endif

#ifndef PHONON_NO_VIDEOCAPTURE
            case VideoCaptureDeviceType:
                hidden = isHiddenVideoCaptureDevice(config, currentList.at(found));
                break;
#endif

            default: ;
            }

            if (!hidden)
                break;

            newList.append(currentList.takeAt(found));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : plugins) {
            BackendDescriptor bd = BackendDescriptor(libPath + plugin);
            if (bd.isValid) {
                int preference = iidPreference.indexOf(bd.iid);
                if (preference != -1) {
                    bd.preference = preference;
                }
                backendList.append(bd);
            }
        }
```

#### AUTO 


```{c}
const auto backends = Factory::findBackends();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &bd : backends) {
        m_select->addItem(bd.name);
        m_backends.insert(bd.name, bd);
    }
```

#### AUTO 


```{c}
const auto propertyNames = d.propertyNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : propertyNames) {
        dbg.nospace() << "  " << propertyName << ": " <<
                         d.property(propertyName).toString() << "\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : plugins) {
        BackendDescriptor descriptor(libPath + plugin);
        if (!descriptor.isValid)
            continue;
        foundBackends.append(descriptor);
    }
```

#### AUTO 


```{c}
const auto &propertyName
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : propertyNames) {
        dbg.nospace() << "  " << propertyName << ": " <<
                         d.property(propertyName.constData()).toString() << "\n";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : qAsConst(newOrder)) {
        int found = currentList.indexOf(i);
        if (found < 0) {
            // It's not in the list, so something is odd (e.g. client error). Ignore it.
            continue;
        }

        // Iterate through the list from this point onward. If there are hidden devices
        // immediately following, take them too.
        newList.append(currentList.takeAt(found));

        while (found < currentList.size()) {
            bool hidden = isHiddenAudioOutputDevice(config, currentList.at(found));
            if (!hidden)
                break;

            newList.append(currentList.takeAt(found));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &backend : backends) {
            if (tryCreateBackend(backend.pluginPath)) {
                break;
            }
        }
```

#### AUTO 


```{c}
const auto backend = m_backends.value(item->text());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        const QString libPath = path + suffix;
        const QDir dir(libPath);
        if (!dir.exists()) {
            qDebug() << Q_FUNC_INFO << dir.absolutePath() << "does not exist";
            continue;
        }

        const QStringList plugins(dir.entryList(QDir::Files));

        for (const QString &plugin : plugins) {
            BackendDescriptor bd = BackendDescriptor(libPath + plugin);
            if (bd.isValid) {
                int preference = iidPreference.indexOf(bd.iid);
                if (preference != -1) {
                    bd.preference = preference;
                }
                backendList.append(bd);
            }
        }

        qSort(backendList);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &url) { QDesktopServices::openUrl(QUrl(url)); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        const QString libPath = path + PHONON_BACKEND_DIR_SUFFIX;
        const QDir dir(libPath);
        if (!dir.exists()) {
            pDebug() << Q_FUNC_INFO << dir.absolutePath() << "does not exist";
            continue;
        }

        const QStringList plugins(dir.entryList(QDir::Files));
        for (const QString &plugin : plugins) {
            Phonon::BackendDescriptor bd(libPath + plugin);
            if (!bd.isValid) {
                continue;
            }

            const auto index = iidPreference.indexOf(bd.iid);
            if (index >= 0) {
                // Apply a weight. Weight strongly influences sort order.
                bd.weight = iidPreference.size() - index;
            }
            backendList.append(bd);
        }

        std::sort(backendList.rbegin(), backendList.rend());
    }
```

#### AUTO 


```{c}
const auto &bd
```

