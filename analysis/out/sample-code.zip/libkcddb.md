#### RANGE FOR STATEMENT 


```{c}
for (const CDInfo &newInfo : results) {
    if (newInfo.get(QString::fromUtf8("source")) == source && newInfo.get(QString::fromUtf8("discid")).toString() == discid)
    {
      if (newInfo.get(Artist) != m_info.get(Artist))
        continue;
      if (newInfo.get(Title) != m_info.get(Title))
        continue;
      bool tracksOk = true;
      for (int i=0; i < 10; i++)
      {
        if (newInfo.track(i).get(Title) != m_info.track(i).get(Title))
        {
          tracksOk = false;
          break;
        }
      }

      if (tracksOk)
        return true;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KIO::Job *, const QByteArray &data){ data_ += data; }
```

#### AUTO 


```{c}
const auto socketError = socket_->socketError();
```

#### AUTO 


```{c}
const auto socketError = socket_->error();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(categories)) {
        QFile f( *cddbCacheDir + QLatin1Char( '/' ) + category + QLatin1Char( '/' ) + trackOffsetListToId(offsetList) );
        if ( f.exists() && f.open(QIODevice::ReadOnly) )
        {
            QTextStream ts(&f);
            ts.setCodec("UTF-8");
            QString cddbData = ts.readAll();
            f.close();
            CDInfo info;
            info.load(cddbData);
            if (category != QLatin1String( "user" ))
            {
              info.set(Category,category);
              info.set(QLatin1String( "source" ), QLatin1String( "freedb" ));
            }
            else
            {
              info.set(QLatin1String( "source" ), QLatin1String( "user" ));
            }

            infoList.append( info );
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CDInfo &i : l) {
    if (i.get(QString::fromUtf8("discid")) == QString::fromUtf8("a1107d0a") && i.get(Category) == QString::fromUtf8("jazz"))
    {
      qDebug() << "Found the CD";
      m_info = i;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(categories)) {
        QFile f( *cddbCacheDir + QLatin1Char( '/' ) + category + QLatin1Char( '/' ) + trackOffsetListToId(offsetList) );
        if ( f.exists() && f.open(QIODevice::ReadOnly) )
        {
            QTextStream ts(&f);
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
            ts.setCodec("UTF-8");
#endif
            QString cddbData = ts.readAll();
            f.close();
            CDInfo info;
            info.load(cddbData);
            if (category != QLatin1String( "user" ))
            {
              info.set(Category,category);
              info.set(QLatin1String( "source" ), QLatin1String( "freedb" ));
            }
            else
            {
              info.set(QLatin1String( "source" ), QLatin1String( "user" ));
            }

            infoList.append( info );
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CDInfo &i : l) {
    if (i.get(QString::fromUtf8("discid")) == QVariant(QString::fromUtf8("a1107d0a")) && i.get(Category) == QVariant(QString::fromUtf8("jazz")))
    {
      qDebug() << "Found the CD";
      m_info = i;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &newid : discids) {
        CDInfo newInfo = info;
        newInfo.set(QLatin1String( "discid" ), newid);
        store(offsetList, newInfo, c);
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&data](KIO::Job *, const QByteArray &d){ data += d; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CDInfo &info : list) {
      store(offsetList, info, c);
    }
```

