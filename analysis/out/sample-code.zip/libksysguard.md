#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new FormatterWrapper(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fitleredId : qAsConst(ids)) {
                sensors.append(QJsonValue(fitleredId));
            }
```

#### AUTO 


```{c}
auto provider = KPluginFactory::instantiatePlugin<ProcessDataProvider>(pluginMetaData, q);
```

#### AUTO 


```{c}
auto model = new KSysGuard::SensorDataModel();
```

#### AUTO 


```{c}
auto schedulerSensor = new ProcessSensor<uint>(this, QStringLiteral("scheduler"), i18n("Scheduler"), &KSysGuard::Process::scheduler, KSysGuard::Process::NiceLevels);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        switch (errno) {
        case ESRCH:
        case ENOENT:
            return Processes::ProcessDoesNotExistOrZombie;
        case EINVAL:
            return Processes::InvalidParameter;
        case EPERM:
            return Processes::InsufficientPermissions;
        default:
            return Processes::Unknown;
        }
    }
```

#### AUTO 


```{c}
auto now = history.constLast();
```

#### AUTO 


```{c}
auto ioWriteSyscallsSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioWriteSyscalls"), i18n("IO Write Syscalls"), &KSysGuard::Process::ioWriteSyscalls, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto file = QStandardPaths::locate(QStandardPaths::GenericConfigLocation, QLatin1String("autostart/%1.desktop").arg(appId));
```

#### LAMBDA EXPRESSION 


```{c}
[](const SensorInfo &first, const SensorInfo &second) { return first.max < second.max; }
```

#### AUTO 


```{c}
const auto ids = query.sensorIds();
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorQuery *query) {
            query->sortByName();
            query->deleteLater();

            const auto ids = query->sensorIds();
            if (ids.isEmpty()) {
                missing.append(query->path());
            } else {
                std::transform(ids.begin(), ids.end(), std::back_inserter(found), [](const QString &id) {
                    return id;
                });
            }

            queries.removeOne(query);
            if (queries.isEmpty()) {
                callback(this);
            }
        }
```

#### AUTO 


```{c}
auto strings = filterRegExp().pattern().split(QLatin1Char(','), QString::SplitBehavior::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        KService::Ptr service = KService::serviceByDesktopName(QStringLiteral("krunner"));
        if (service) {
            auto *job = new KIO::ApplicationLauncherJob(service);
            job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, window()));
            job->start();
        }
    }
```

#### AUTO 


```{c}
auto item = d->faceConfigLoader->findItemByName(key);
```

#### AUTO 


```{c}
auto ioWriteSyscallsRateSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioReadSyscallsRate"), i18n("IO Write Syscalls Rate"), &KSysGuard::Process::ioWriteSyscallsRate, KSysGuard::Process::IO);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &segment : segments) {
        int index = item->indexOf(segment);
        Q_ASSERT(index != -1);
        item = item->children.at(index);
    }
```

#### AUTO 


```{c}
auto startTimeSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("startTime"), i18n("Start Time"), &KSysGuard::Process::startTime, Process::Nothing, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->lowPrioritySensorIds) {
            return;
        }
        d->lowPrioritySensorIds = resolvedSensors;
        Q_EMIT lowPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
auto result = query.result().at(index);
```

#### AUTO 


```{c}
const auto attributes = m_processes->attributes();
```

#### AUTO 


```{c}
auto replacement
```

#### LAMBDA EXPRESSION 


```{c}
[](const SensorProperty *prop) {
            return prop->isSubscribed();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entry : iterator) {
        if (!entry.is_directory()) {
            continue;
        }
        const QString childId = node->id() % QLatin1Char('/') % QString::fromUtf8(entry.path().filename().c_str());
        CGroup *childNode = d->m_cgroupMap[childId];
        if (!childNode) {
            childNode = new CGroup(childId);
            d->m_cgroupMap[childNode->id()] = childNode;

            if (filterAcceptsCGroup(childId)) {
                int row = d->m_cGroups.count();
                beginInsertRows(QModelIndex(), row, row);
                d->m_cGroups.append(childNode);
                endInsertRows();
            }
        }
        update(childNode);
        d->m_oldGroups.remove(childId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) -> qlonglong {
        if (p->vmRSS() - p->vmURSS() < 0 || p->vmURSS() == -1) {
            return 0;
        }
        return (qlonglong)(p->vmRSS() - p->vmURSS());
    }
```

#### AUTO 


```{c}
auto uidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("uid"), i18n("UID"), &KSysGuard::Process::uid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[](long long entry) { return entry; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pair : result) {
            d->addSensor(pair.first, pair.second);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorResolver *resolver) {
        d->lowPrioritySensorIds = resolver->found;
        Q_EMIT lowPrioritySensorIdsChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pid : pids) {
        auto success = function(pid);
        if (!success) {
            switch (localProcesses->errorCode) {
            case KSysGuard::Processes::InsufficientPermissions:
            case KSysGuard::Processes::Unknown:
                result.unchanged << pid;
                result.resultCode = Result::InsufficientPermissions;
                break;
            case Processes::InvalidPid:
            case Processes::ProcessDoesNotExistOrZombie:
            case Processes::InvalidParameter:
                result.resultCode = Result::NoSuchProcess;
                break;
            case Processes::NotSupported:
                result.resultCode = Result::Unsupported;
                break;
            default:
                result.resultCode = Result::Unknown;
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto itemIndex = index(parentItem->children.indexOf(item), 0, parentIndex);
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) {
            return p->userTime() + p->sysTime();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto unusedAttr : qAsConst(unusedAttributes)) {
         disconnect(unusedAttr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
     }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& desktopName)
    {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), this);

            connect(action, &QAction::triggered, this,
                [this, kService](bool) {
                auto *job = new KIO::ApplicationLauncherJob(kService);
                job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, window()));
                job->start();
            });
            d->mToolsMenu->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto sgidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("sgid"), i18n("sgid"), &KSysGuard::Process::sgid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto statusSensor =
        new ProcessSensor<QString>(this, QStringLiteral("status"), i18n("Status"), &KSysGuard::Process::translatedStatus, KSysGuard::Process::Status);
```

#### AUTO 


```{c}
auto presetPackage = KPackage::PackageLoader::self()->loadPackage(QStringLiteral("Plasma/Applet"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &id) {
                    return id;
                }
```

#### AUTO 


```{c}
auto process = getProcess(pid);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &id) {
            return QJsonValue(id);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pid, runnable](qulonglong pss) {
        Q_EMIT processUpdated(pid, { { Process::VmPSS, pss } });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (ExtendedProcesses *p) {delete p;}
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorResolver *resolver) {
        if (resolver->found == d->totalSensors) {
            return;
        }
        d->totalSensors = resolver->found;
        Q_EMIT totalSensorsChanged();
    }
```

#### AUTO 


```{c}
auto toErase = std::vector<int>{};
```

#### AUTO 


```{c}
const auto allData = reply.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this, sensor]() {
        sensorDataChanged(sensor);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, other](bool isSubscribed) {
        if (isSubscribed) {
            other->subscribe();
            setMax(other->value().toReal());
        } else {
            other->unsubscribe();
        }
    }
```

#### AUTO 


```{c}
auto usageSensor = new ProcessSensor<int>(
    this, QStringLiteral("usage"), i18n("Total CPU Usage"), [](KSysGuard::Process *p) {
        return p->userUsage() + p->sysUsage();
    },
    KSysGuard::Process::Usage, Accumulate);
```

#### AUTO 


```{c}
const auto result = query->result();
```

#### AUTO 


```{c}
auto sourceInode = m_oldState.addressToInode.find(packet.sourceAddress());
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorResolver *resolver) {
        if (resolver->found == d->lowPrioritySensorIds) {
            return;
        }
        d->lowPrioritySensorIds = resolver->found;
        Q_EMIT lowPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
auto subDir
```

#### RANGE FOR STATEMENT 


```{c}
for (auto id : sensorIds) {
        if (regexp.match(id).hasMatch()) {
            result.append(qMakePair(id, reply.value().value(id)));
        }
    }
```

#### AUTO 


```{c}
auto error = processes->setScheduler(pid, priorityClass, priority);
```

#### AUTO 


```{c}
auto family
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sensor : sensors) {
        sensorInfos[sensor] = KSysGuard::SensorInfo();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, node]() {
        auto row = d->m_cGroups.indexOf(node);
        Q_EMIT dataChanged(index(row, 0, QModelIndex()), index(row, columnCount()-1, QModelIndex()));
    }
```

#### AUTO 


```{c}
auto loadSensors = [this](const QJsonArray &partialEntries) {
        QJsonArray sensors;

        for (const auto &id : partialEntries) {
            KSysGuard::SensorQuery query{id.toString()};
            query.execute();
            query.waitForFinished();
            for (const auto &fitleredId : query.sensorIds()) {
                sensors.append(QJsonValue(fitleredId));
            }
        }
        return sensors;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, priorityClass, priority](int pid) {
        return s_localProcesses->setIoNiceness(pid, priorityClass, priority);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){
        KRun::runCommand(QStringLiteral("krunner"), nullptr);
    }
```

#### AUTO 


```{c}
auto child = item->children.value(segment, nullptr);
```

#### AUTO 


```{c}
auto buffer = QByteArray{1024, '\0'};
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *unusedAttribute : qAsConst(unusedAttributes)) {
        disconnect(unusedAttribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        unusedAttribute->setEnabled(false);
    }
```

#### AUTO 


```{c}
auto ioniceLevelSensor =
        new ProcessSensor<int>(this, QStringLiteral("ioniceLevel"), i18n("IO Nice Level"), &KSysGuard::Process::ioniceLevel, KSysGuard::Process::NiceLevels);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : d->mModel.extraAttributes()) {
        attribute->setEnabled(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorResolver *resolver) {
        if (resolver->found == d->highPrioritySensorIds) {
            return;
        }
        d->highPrioritySensorIds = resolver->found;
        Q_EMIT highPrioritySensorIdsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, node](QVector<pid_t> pids) {
        auto row = d->m_cGroups.indexOf(node);
        if (row >= 0) {
            d->m_cGroups[row]->setPids(pids);
            d->m_processMap.remove(d->m_cGroups[row]);
            Q_EMIT dataChanged(index(row, 0, QModelIndex()), index(row, columnCount() - 1, QModelIndex()));
        }
    }
```

#### AUTO 


```{c}
auto ipv6 = match.str(2);
```

#### AUTO 


```{c}
auto parentIndex = QModelIndex{};
```

#### AUTO 


```{c}
auto addByDesktopName = [this](const QString& desktopName)
    {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), this);

            connect(action, &QAction::triggered, this,
                [kService](bool) {
                KRun::runService(*kService, { }, nullptr);
            });
            d->mToolsMenu->addAction(action);
        }
    };
```

#### AUTO 


```{c}
auto fsgidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("fsgid"), i18n("fsgid"), &KSysGuard::Process::fsgid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromUtf8(m_process->readLine());

            // Each line consists of: timestamp|PID|pid|IN|in_bytes|OUT|out_bytes
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            const auto parts = line.splitRef(QLatin1Char('|'), QString::SkipEmptyParts);
#else
            const auto parts = line.splitRef(QLatin1Char('|'), Qt::SkipEmptyParts);
#endif
            if (parts.size() < 7) {
                continue;
            }

            long pid = parts.at(2).toLong();

            auto timeStamp = QDateTime::currentDateTimeUtc();
            timeStamp.setTime(QTime::fromString(parts.at(0).toString(), QStringLiteral("HH:mm:ss")));

            auto bytesIn = parts.at(4).toUInt();
            auto bytesOut = parts.at(6).toUInt();

            auto process = getProcess(pid);
            if (!process) {
                return;
            }

            m_inboundSensor->setData(process, bytesIn);
            m_outboundSensor->setData(process, bytesOut);
        }
    }
```

#### AUTO 


```{c}
auto it = d->mMapProcessCPUHistory.find(process);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto segment : segments) {
        int index = item->indexOf(segment);

        if (index != -1) {
            item = item->children.at(index);
        } else {
            SensorTreeItem *newItem = new SensorTreeItem();
            newItem->parent = item;
            newItem->name = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->children.indexOf(item), 0, item);
            q->beginInsertRows(parentIndex, item->children.count(), item->children.count());
            item->children.append(newItem);
            q->endInsertRows();

            item = newItem;
        }
    }
```

#### AUTO 


```{c}
auto processes = d->mUsingHistoricalData ? d->mHistoricProcesses : d->mAbstractProcesses;
```

#### AUTO 


```{c}
auto watcher = SensorDaemonInterface::instance()->allSensors();
```

#### AUTO 


```{c}
auto attributes = d->mModel.extraAttributes();
```

#### AUTO 


```{c}
auto startTimeSensor = new ProcessSensor<qlonglong>(this,
                                                        QStringLiteral("startTime"),
                                                        i18n("Start Time"),
                                                        &KSysGuard::Process::startTime,
                                                        Process::Nothing,
                                                        ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto string : strings) {
			string = string.trimmed();
			if (process->name().indexOf(string) != -1 || QString::number(process->pid()).indexOf(string) != -1) {
				return true;
			}
		}
```

#### AUTO 


```{c}
auto attribute
```

#### AUTO 


```{c}
auto column = d->sensors.indexOf(sensorId);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QVariant &entry) { return entry.toInt(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pid, runnable](qulonglong pss) {
            Q_EMIT processUpdated(pid, {{Process::VmPSS, pss}});
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : std::as_const(d->m_oldGroups)) {
        int row = d->m_cGroups.indexOf(c);
        if (row >= 0) {
            beginRemoveRows(QModelIndex(), row, row);
            d->m_cGroups.removeOne(c);
            endRemoveRows();
        }
        d->m_cgroupMap.remove(c->id());
        delete c;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](ProcessAttribute *p) {
            return p->enabled();
        }
```

#### AUTO 


```{c}
const auto &entry
```

#### AUTO 


```{c}
auto metadata = p.metadata();
```

#### AUTO 


```{c}
auto inetDiagMsg = static_cast<inet_diag_msg *>(nlmsg_data(nlh));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto obj : m_subsystem->objects()) {
        if (m_matchObjects.match(obj->id()).hasMatch()) {
            auto sensor = obj->sensor(m_matchProperty);
            if (sensor) {
                addSensor(sensor);
            }
        }
    }
```

#### AUTO 


```{c}
auto getValueOfFirstExisting = [chipName, feature](std::initializer_list<sensors_subfeature_type> subfeatureTypes) {
        double value;
        for (auto subfeatureType : subfeatureTypes) {
            const sensors_subfeature *const subfeature = sensors_get_subfeature(chipName, feature, subfeatureType);
            if (subfeature && sensors_get_value(chipName, subfeature->number, &value) == 0) {
                return value;
            }
        }
        return 0.0;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const SensorInfo &first, const SensorInfo &second) {
        return first.min < second.min;
    }
```

#### AUTO 


```{c}
auto result = d->mProcessController->setCPUScheduler(pids, newCpuSched, newCpuSchedPriority);
```

#### AUTO 


```{c}
auto process = d->mProcesses.value(pid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &segment : segments) {
        if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second;
        } else {
            return nullptr;
        }
    }
```

#### AUTO 


```{c}
auto itr = array.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->lowPrioritySensorIds) {
            return;
        }
        d->lowPrioritySensorIds = resolvedSensors;
        Q_EMIT lowPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
auto itr = infos.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto segment : segments) {
        if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second;
        } else {
            SensorTreeItem *newItem = new SensorTreeItem();
            newItem->parent = item;
            newItem->segment = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->indexOf(item->segment), 0, item);

            auto index = std::distance(item->children.begin(), item->children.upper_bound(segment));

            q->beginInsertRows(parentIndex, index, index);
            item->children[segment] = newItem;
            q->endInsertRows();

            item = newItem;
        }
    }
```

#### AUTO 


```{c}
auto it = plugins.rbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {update();}
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, priorityClass, priority](int pid) {
        return s_localProcesses->setIoNiceness(pid, priorityClass, priority);
    });
```

#### THREAD 


```{c}
std::thread m_thread;
```

#### AUTO 


```{c}
auto ioCharactersActuallyWrittenRateSensor = new ProcessSensor<qlonglong>(this,
                                                                              QStringLiteral("ioCharactersActuallyWrittenRate"),
                                                                              i18n("Disk Write Rate"),
                                                                              &KSysGuard::Process::ioCharactersActuallyWrittenRate,
                                                                              KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto userNameSensor = new ProcessSensor<QString>(
    this, QStringLiteral("username"), i18n("Username"), [this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        auto userIt = d->m_userCache.constFind(uid);
        if (userIt == d->m_userCache.constEnd()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }
        return userIt->loginName();
    },
    KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto userUsageSensor = new ProcessSensor<int>(this, QStringLiteral("userUsage"), i18n("User CPU Usage"), &KSysGuard::Process::userUsage, KSysGuard::Process::Usage);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(kService->icon()), kService->name(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        uint count = std::count_if(m_sensors.constBegin(), m_sensors.constEnd(), [](const SensorProperty *prop) {
            return prop->isSubscribed();
        });
        if (count == 1) {
            emit subscribedChanged(true);
        } else if (count == 0) {
            emit subscribedChanged(false);
        }
    }
```

#### AUTO 


```{c}
const auto match = oldDiskSensor.match(entryName);
```

#### AUTO 


```{c}
auto optionIndex = 0;
```

#### AUTO 


```{c}
auto formatted = KSysGuard::Formatter::formatValue(input, KSysGuard::UnitTime);
```

#### AUTO 


```{c}
auto totalUsageSensor = new ProcessSensor<int>(
    this, QStringLiteral("totalUsage"), i18n("Group Total CPU Usage"), [](KSysGuard::Process *p) {
        return p->totalUserUsage() + p->totalSysUsage();
    },
    KSysGuard::Process::TotalUsage, Average);
```

#### AUTO 


```{c}
auto sysUsageSensor =
        new ProcessSensor<int>(this, QStringLiteral("sysUsage"), i18n("System CPU Usage"), &KSysGuard::Process::sysUsage, KSysGuard::Process::Usage);
```

#### AUTO 


```{c}
auto accumulator = std::make_shared<Accumulator>(capture, mapping);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute: enabledAttributes) {
         auto attr = d->m_availableAttributes.value(attribute, nullptr);
         if (!attr) {
             qWarning() << "Could not find attribute" << attribute;
             continue;
         }
         unusedAttributes.removeOne(attr);
         d->m_enabledAttributes << attr;
         int columnIndex = d->m_enabledAttributes.count() - 1;

         // reconnect as using the attribute in the lambda makes everything super fast
         disconnect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
         connect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
             auto cgroup = d->m_cgroupMap.value(process->cGroup());
             if (!cgroup) {
                 return;
             }
             const QModelIndex index = getQModelIndex(cgroup, columnIndex);
             emit dataChanged(index, index);
         });

     }
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) {
        return p->userTime() + p->sysTime();
    }
```

#### AUTO 


```{c}
auto remove = [this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->indexOf(item->segment);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->indexOf(parent->segment), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);

        auto itr = item->parent->children.find(item->segment);
        delete itr->second;
        item->parent->children.erase(itr);

        q->endRemoveRows();

        sensorInfos.remove(item);
    };
```

#### AUTO 


```{c}
auto nameSensor = new ProcessSensor<QString>(this, QStringLiteral("name"), i18n("Name"), &KSysGuard::Process::name, KSysGuard::Process::Name, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto remove = [this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->children.indexOf(item);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->children.indexOf(parent), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);
        delete item->parent->children.takeAt(index);
        q->endRemoveRows();

        sensorInfos.remove(item);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fitleredId : query.sensorIds()) {
                sensors.append(QJsonValue(fitleredId));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QJsonArray &resolvedSensors) {
        d->totalSensors = resolvedSensors;
        Q_EMIT totalSensorsChanged();
    }
```

#### AUTO 


```{c}
auto presetPackage = KPackage::PackageLoader::self()->loadPackage(QStringLiteral("Plasma/Applet"), pluginId);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : qAsConst(d->sensors)) {
            if (sensor) {
                sensor->unsubscribe();
            }
        }
```

#### AUTO 


```{c}
auto euidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("euid"), i18n("EUID"), &KSysGuard::Process::euid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        for (auto p : qAsConst(d->m_providers)) {
            if (p->enabled()) {
                p->update();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto processes) {
        Q_FOREACH( KSysGuard::Process *process, processes) {
            QCOMPARE(countNumChildren(process), process->numChildren());

            for(int i = 0; i < process->children().size(); i++) {
                QVERIFY(process->children()[i]->parent());
                QCOMPARE(process->children()[i]->parent(), process);
            }
        }
    }
```

#### AUTO 


```{c}
auto original = QJsonDocument::fromJson(read.readEntry(entryName, QString()).toUtf8()).array();
```

#### AUTO 


```{c}
auto target = std::string(buffer);
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [signal](int pid) {
        return s_localProcesses->sendSignal(pid, signal);
    });
```

#### AUTO 


```{c}
auto result = std::min_element(d->sensorInfos.cbegin(), d->sensorInfos.cend(), [](const SensorInfo &first, const SensorInfo &second) {
        return first.min < second.min;
    });
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
auto timeSensor = new ProcessSensor<qlonglong>(
        this,
        QStringLiteral("totalUsage"),
        i18n("Total Time"),
        [](KSysGuard::Process *p) {
            return p->userTime() + p->sysTime();
        },
        KSysGuard::Process::Usage);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromLatin1(m_process->readLine());
            if (line.startsWith(QLatin1Char('#'))) { // comment line
                if (line != QLatin1String("# gpu        pid  type    sm   mem   enc   dec   command\n")
                    && line != QLatin1String("# Idx          #   C/G     %     %     %     %   name\n")) {
                    // header format doesn't match what we expected, bail before we send any garbage
                    m_process->terminate();
                }
                continue;
            }
            const auto parts = line.splitRef(QLatin1Char(' '), Qt::SkipEmptyParts);

            // format at time of writing is
            // # gpu        pid  type    sm   mem   enc   dec   command
            if (parts.count() < 5) { // we only access up to the 5th element
                continue;
            }

            long pid = parts[1].toUInt();
            int sm = parts[3].toUInt();
            int mem = parts[4].toUInt();

            KSysGuard::Process *process = getProcess(pid);
            if (!process) {
                continue; // can in race condition etc
            }
            m_usage->setData(process, sm);
            m_memory->setData(process, mem);
        }
    }
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, priority](int pid) { return s_localProcesses->setNiceness(pid, priority); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fitleredId : qAsConst(ids)) {
            sensors.append(QJsonValue(fitleredId));
        }
```

#### AUTO 


```{c}
auto pidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("pid"), i18n("PID"), &KSysGuard::Process::pid, KSysGuard::Process::Status, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto totalPss = -1LL;
```

#### AUTO 


```{c}
auto query = new SensorQuery{QString(), this};
```

#### AUTO 


```{c}
auto unit = KSysGuard::SensorDataModel::Unit;
```

#### AUTO 


```{c}
const auto currentEntry = QJsonDocument::fromJson(d->sensorsGroup.readEntry("lowPrioritySensorIds").toUtf8()).array();
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid()) {
                    emit dataChanged(index, index);
                }
            }
        }
```

#### AUTO 


```{c}
auto userNameSensor = new ProcessSensor<QString>(
        this,
        QStringLiteral("username"),
        i18n("Username"),
        [this](KSysGuard::Process *p) {
            const K_UID uid = p->uid();
            auto userIt = d->m_userCache.find(uid);
            if (userIt == d->m_userCache.end()) {
                userIt = d->m_userCache.insert(uid, KUser(uid));
            }
            return userIt->loginName();
        },
        KSysGuard::Process::Uids,
        ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!d->shouldSync) {
            return;
        }
        d->appearanceGroup.sync();
        d->sensorsGroup.sync();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &id) {
                return QJsonValue(id);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorResolver *resolver) {
        d->totalSensors = resolver->found;
        Q_EMIT totalSensorsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i](KSysGuard::Process *process) {
            const QModelIndex index = q->getQModelIndex(process, mHeadings.count() + i);
            emit q->dataChanged(index, index);
        }
```

#### AUTO 


```{c}
auto itr = d->sensors.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_EMIT valueChanged();
            d->dataChangeQueued = false;
        }
```

#### AUTO 


```{c}
auto data = d->sensorData.value(sensor);
```

#### AUTO 


```{c}
auto it = m_sensors.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto unusedAttr : qAsConst(unusedAttributes)) {
        disconnect(unusedAttr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
    }
```

#### AUTO 


```{c}
auto value = file.readAll();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &segment : segments) {
        int index = item->indexOf(segment);
        if (index != -1) {
            item = item->children.at(index);
        } else {
            return nullptr;
        }
    }
```

#### AUTO 


```{c}
auto c = KSharedConfig::openConfig(presetPackage.filePath("config", QStringLiteral("faceproperties")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginMetaData : listMetaData) {
        qCDebug(LIBKSYSGUARD_PROCESSCORE) << "loading plugin" << pluginMetaData.name();
        auto provider = KPluginFactory::instantiatePlugin<ProcessDataProvider>(pluginMetaData, q);
        if (!provider.plugin) {
            qCCritical(LIBKSYSGUARD_PROCESSCORE) << "failed to instantiate ProcessDataProvider" << pluginMetaData.name();
            continue;
        }
        m_providers << provider.plugin;
    }
```

#### AUTO 


```{c}
auto strings = filterRegularExpression().pattern().split(QLatin1Char(','), Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[this, signal](int pid) { return s_localProcesses->sendSignal(pid, signal); }
```

#### AUTO 


```{c}
auto view = std::string_view(buffer.data(), 100);
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            auto cgroup = d->m_cgroupMap.value(process->cGroup());
            if (!cgroup) {
                return;
            }
            const QModelIndex index = getQModelIndex(cgroup, columnIndex);
            Q_EMIT dataChanged(index, index);
        }
```

#### AUTO 


```{c}
auto niceLevelSensor = new ProcessSensor<int>(this, QStringLiteral("niceLevel"), i18n("Nice Level"), &KSysGuard::Process::niceLevel, KSysGuard::Process::NiceLevels);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto p : qAsConst(d->m_providers)) {
            if (p->enabled()) {
                p->update();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Process* p : d->mListProcesses) {
        if (!d->mToBeProcessed.contains(p->pid())) {
            endedProcesses += p->pid();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto id : sensorIds) {
        if (id == path || regexp.match(id).hasMatch()) {
            result.append(qMakePair(id, reply.value().value(id)));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &plugin) {
            return plugin.value(QStringLiteral("X-Plasma-RootPath")) == QStringLiteral("org.kde.plasma.systemmonitor");
        }
```

#### AUTO 


```{c}
auto historyMapEntry = mMapProcessCPUHistory.find(process);
```

#### AUTO 


```{c}
auto timeStamp = std::chrono::time_point_cast<TimeStamp::MicroSeconds::duration>(std::chrono::system_clock::from_time_t(header->ts.tv_sec) + std::chrono::microseconds { header->ts.tv_usec });
```

#### AUTO 


```{c}
auto procList = qobject_cast<KSysGuard::Processes *>(parent);
```

#### AUTO 


```{c}
auto canUserLoginSensor = new ProcessSensor<bool>(
    this, QStringLiteral("canUserLogin"), i18n("Can Login"), [this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        if (uid == 65534) { // special value meaning nobody
            return false;
        }
        auto userIt = d->m_userCache.find(uid);
        if (userIt == d->m_userCache.end()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }

        if (!userIt->isValid()) {
            // For some reason the user isn't recognised.  This might happen under certain security situations.
            // Just return true to be safe
            return true;
        }
        const QString shell = userIt->shell();
        if (shell == QLatin1String("/bin/false")) { //FIXME - add in any other shells it could be for false
            return false;
        }
        return true;
    },
    KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[signal](int pid) { return s_localProcesses->sendSignal(pid, signal); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attr : d->m_enabledAttributes) {
        rc << attr->id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *p) {
            const K_UID uid = p->uid();
            if (uid == 65534) { // special value meaning nobody
                return false;
            }
            auto userIt = d->m_userCache.find(uid);
            if (userIt == d->m_userCache.end()) {
                userIt = d->m_userCache.insert(uid, KUser(uid));
            }

            if (!userIt->isValid()) {
                // For some reason the user isn't recognised.  This might happen under certain security situations.
                // Just return true to be safe
                return true;
            }
            const QString shell = userIt->shell();
            if (shell == QLatin1String("/bin/false")) { // FIXME - add in any other shells it could be for false
                return false;
            }
            return true;
        }
```

#### AUTO 


```{c}
auto result = d->mProcessController->setPriority(pids, niceValue);
```

#### AUTO 


```{c}
auto sensor = obj->sensor(m_matchProperty);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : changes) {
        switch (entry.first) {
            case Process::VmPSS:
                process->setVmPSS(entry.second.toLongLong());
                break;
            default:
                break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid() && process != d->m_removingRowFor) {
                    Q_EMIT dataChanged(index, index);
                }
            }
        }
```

#### AUTO 


```{c}
auto pidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("pid"), i18n("PID"), &KSysGuard::Process::pid, KSysGuard::Process::Status, ForwardFirstEntry);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (QFile file{dir.path() % QStringLiteral("/metadata.json")}; file.open(QIODevice::WriteOnly)) {
        file.write(json.toJson());
    } else {
        qWarning() << "Could not write metadata.json file for preset" << title();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[watcher, this]() {
        watcher->deleteLater();
        d->watcher = nullptr;
        d->state = Private::State::Finished;
        d->updateResult(QDBusPendingReply<SensorInfoMap>(*watcher));
        Q_EMIT finished(this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto p : std::as_const(d->m_providers)) {
        rc << p->attributes();
    }
```

#### AUTO 


```{c}
auto timeStamp = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
```

#### LAMBDA EXPRESSION 


```{c}
[this, path, callback, context]() {
        QFile pidFile(path);
        pidFile.open(QFile::ReadOnly | QIODevice::Text);
        QTextStream stream(&pidFile);

        QVector<pid_t> pids;
        QString line = stream.readLine();
        while (!line.isNull()) {
            pids.append(line.toLong());
            line = stream.readLine();
        }
        setPids(pids);

        // Ensure we call the callback on the thread the context object lives on.
        if (context) {
            QMetaObject::invokeMethod(context, callback);
        }
    }
```

#### AUTO 


```{c}
auto totalUsageSensor = new ProcessSensor<int>(
        this,
        QStringLiteral("totalUsage"),
        i18n("Group Total CPU Usage"),
        [](KSysGuard::Process *p) {
            return p->totalUserUsage() + p->totalSysUsage();
        },
        KSysGuard::Process::TotalUsage,
        Average);
```

#### AUTO 


```{c}
auto itr = data.begin();
```

#### AUTO 


```{c}
auto inode = std::stoi(match.str(5));
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromLatin1(m_process->readLine());
            if (line.startsWith(QLatin1Char('#'))) { //comment line
                if (line != QLatin1String("# gpu        pid  type    sm   mem   enc   dec   command\n") &&
                    line != QLatin1String("# Idx          #   C/G     %     %     %     %   name\n")) {
                    //header format doesn't match what we expected, bail before we send any garbage
                    m_process->terminate();
                }
                continue;
            }
            const auto parts = line.splitRef(QLatin1Char(' '),  QString::SkipEmptyParts);

            // format at time of writing is
            // # gpu        pid  type    sm   mem   enc   dec   command
            if (parts.count() < 5) { // we only access up to the 5th element
                continue;
            }

            long pid = parts[1].toUInt();
            int sm = parts[3].toUInt();
            int mem = parts[4].toUInt();

            KSysGuard::Process *process = getProcess(pid);
            if(!process) {
                continue; //can in race condition etc
            }
            m_usage->setData(process, sm);
            m_memory->setData(process, mem);
        }
    }
```

#### AUTO 


```{c}
auto killWindowKwinMethod = new QDBusInterface(QStringLiteral("org.kde.KWin"), QStringLiteral("/KWin"), QStringLiteral("org.kde.KWin"));
```

#### AUTO 


```{c}
auto newSensors = readSensors(group, entryName);
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->indexOf(item->segment);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->indexOf(parent->segment), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);

        auto itr = item->parent->children.find(item->segment);
        item->parent->children.erase(itr);

        q->endRemoveRows();

        sensorInfos.remove(item);
    }
```

#### AUTO 


```{c}
auto regexp = QRegularExpression{QRegularExpression::wildcardToRegularExpression(path)};
```

#### AUTO 


```{c}
auto sysUsageSensor = new ProcessSensor<int>(this, QStringLiteral("sysUsage"), i18n("System CPU Usage"), &KSysGuard::Process::sysUsage, KSysGuard::Process::Usage);
```

#### AUTO 


```{c}
auto timeStamp = QDateTime::currentDateTimeUtc();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : m_data) {
        if (entry.second.first == 0 && entry.second.second == 0) {
            toErase.push_back(entry.first);
        } else {
            entry.second.first = 0;
            entry.second.second = 0;
        }
    }
```

#### AUTO 


```{c}
auto error = processes->setNiceness(pid, priority);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromLatin1(m_process->readLine());
            if (line.startsWith(QLatin1Char('#'))) { // comment line
                if (line != QLatin1String("# gpu        pid  type    sm   mem   enc   dec   command\n")
                    && line != QLatin1String("# Idx          #   C/G     %     %     %     %   name\n")) {
                    // header format doesn't match what we expected, bail before we send any garbage
                    m_process->terminate();
                }
                continue;
            }
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
            const auto parts = line.splitRef(QLatin1Char(' '), Qt::SkipEmptyParts);
#else
            const auto parts = QStringView(line).split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif

            // format at time of writing is
            // # gpu        pid  type    sm   mem   enc   dec   command
            if (parts.count() < 5) { // we only access up to the 5th element
                continue;
            }

            long pid = parts[1].toUInt();
            int sm = parts[3].toUInt();
            int mem = parts[4].toUInt();

            KSysGuard::Process *process = getProcess(pid);
            if (!process) {
                continue; // can in race condition etc
            }
            m_usage->setData(process, sm);
            m_memory->setData(process, mem);
        }
    }
```

#### AUTO 


```{c}
auto history = index.data(ProcessModel::PercentageHistoryRole).value<QVector<ProcessModel::PercentageHistoryEntry>>();
```

#### AUTO 


```{c}
auto fdPath = "/proc/%/fd"s;
```

#### AUTO 


```{c}
const auto parts = line.splitRef(QLatin1Char('|'), QString::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto replacement : std::as_const(sensorIdReplacements)) {
            auto match = replacement.first.match(sensorId);
            if (match.hasMatch()) {
                sensorId.replace(replacement.first, replacement.second);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : original) {
        QString sensorId = entry.toString();
        for (auto replacement : std::as_const(sensorIdReplacements)) {
            auto match = replacement.first.match(sensorId);
            if (match.hasMatch()) {
                sensorId.replace(replacement.first, replacement.second);
            }
        }
        sensorId = replaceDiskId(sensorId);
        sensorId = replacePartitionId(sensorId);
        newSensors.append(sensorId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->indexOf(item->segment);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->indexOf(parent->segment), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);

        auto itr = item->parent->children.find(item->segment);
        delete itr->second;
        item->parent->children.erase(itr);

        q->endRemoveRows();

        sensorInfos.remove(item);
    }
```

#### AUTO 


```{c}
auto userUsageSensor =
        new ProcessSensor<int>(this, QStringLiteral("userUsage"), i18n("User CPU Usage"), &KSysGuard::Process::userUsage, KSysGuard::Process::Usage);
```

#### AUTO 


```{c}
auto result = QVariant {};
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &partialEntries) {
        QJsonArray sensors;

        for (const auto &id : partialEntries) {
            KSysGuard::SensorQuery query{id.toString()};
            query.execute();
            query.waitForFinished();
            auto ids = query.sensorIds();
            std::stable_sort(ids.begin(), ids.end());
            for (const auto &fitleredId : qAsConst(ids)) {
                sensors.append(QJsonValue(fitleredId));
            }
        }
        return sensors;
    }
```

#### AUTO 


```{c}
auto itr = m_data.find(pid);
```

#### AUTO 


```{c}
auto row = d->m_cGroups.indexOf(node);
```

#### LAMBDA EXPRESSION 


```{c}
[=](int exitCode, QProcess::ExitStatus status) {
        if (exitCode != 0 || status != QProcess::NormalExit) {
            qCWarning(KSYSGUARD_PLUGIN_NETWORK) << "Helper process terminated abnormally:" << m_process->readAllStandardError().trimmed();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) {
            return p->totalUserUsage() + p->totalSysUsage();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](int) { g_running = false; }
```

#### AUTO 


```{c}
auto suidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("suid"),
            i18n("suid"), &KSysGuard::Process::suid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto metrics = QFontMetrics{font};
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonValue &entry) {
        auto query = new SensorQuery{entry.toString()};
        query->connect(query, &KSysGuard::SensorQuery::finished, controller, [this](SensorQuery *query) {
            query->sortByName();
            query->deleteLater();

            const auto ids = query->sensorIds();
            if (ids.isEmpty()) {
                missing.append(query->path());
            } else {
                std::transform(ids.begin(), ids.end(), std::back_inserter(found), [](const QString &id) {
                    return id;
                });
            }

            queries.removeOne(query);
            if (queries.isEmpty()) {
                callback(this);
            }
        });
        query->execute();
        return query;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](int) {
        g_running = false;
    }
```

#### AUTO 


```{c}
auto original = QJsonDocument::fromJson(config.readEntry(entryName, QString()).toUtf8()).array();
```

#### AUTO 


```{c}
auto ioCharactersActuallyReadSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersActuallyRead"), i18n("IO Characters Actually Read"), &KSysGuard::Process::ioCharactersActuallyRead, KSysGuard::Process::IO);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto family : {AF_INET, AF_INET6}) {
        for (auto protocol : {IPPROTO_TCP, IPPROTO_UDP}) {
            if (!dumpSockets(socket, family, protocol)) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : partialEntries) {
        auto query = new KSysGuard::SensorQuery{id.toString()};
        query->connect(query, &KSysGuard::SensorQuery::finished, q, [this, query, sensors, callback] {
            query->sortByName();
            const auto ids = query->sensorIds();
            delete query;
            std::transform(ids.begin(), ids.end(), std::back_inserter(*sensors), [](const QString &id) {
                return QJsonValue(id);
            });
            if (sensors.use_count() == 1) {
                // We are the last query
                callback(*sensors);
            }
        });
        query->execute();
    }
```

#### AUTO 


```{c}
auto next = history.at(index);
```

#### LAMBDA EXPRESSION 


```{c}
[](qlonglong current, qlonglong previous, int elapsedTime) {
            if (elapsedTime <= 0 || previous <= 0) {
                return 0.0;
            }
            return (current - previous) * 1000.0 / elapsedTime;
        }
```

#### AUTO 


```{c}
auto configGroup = parentController->configGroup().group(groupName);
```

#### AUTO 


```{c}
auto kService = KService::serviceByDesktopName(desktopName);
```

#### LAMBDA EXPRESSION 


```{c}
[this, pluginName] () {
        d->availablePresetsModel->reload();
    }
```

#### AUTO 


```{c}
auto result = d->mProcessController->setIOScheduler(pids, newIoSched, newIoSchedPriority);
```

#### AUTO 


```{c}
auto updateRateLimit = chrono::steady_clock::duration(chrono::milliseconds(d->updateRateLimit.value()));
```

#### AUTO 


```{c}
const auto segments = sensorId.split(QLatin1Char('/'));
```

#### AUTO 


```{c}
const auto volume = devices[0].as<Solid::StorageVolume>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &plugin) {
        return plugin.value(QStringLiteral("X-Plasma-RootPath")) == QStringLiteral("org.kde.plasma.systemmonitor");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[chipName, feature](std::initializer_list<sensors_subfeature_type> subfeatureTypes) {
        double value;
        for (auto subfeatureType : subfeatureTypes) {
            const sensors_subfeature *const subfeature = sensors_get_subfeature(chipName, feature, subfeatureType);
            if (subfeature && sensors_get_value(chipName, subfeature->number, &value) == 0) {
                return value;
            }
        }
        return 0.0;
    }
```

#### AUTO 


```{c}
auto capture = std::make_shared<Capture>();
```

#### AUTO 


```{c}
auto sensor = d->sensors.at(index.column());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        auto userIt = d->m_userCache.constFind(uid);
        if (userIt == d->m_userCache.constEnd()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }
        return userIt->loginName();
    }
```

#### AUTO 


```{c}
auto resolver = new SensorResolver{q, partialEntries};
```

#### AUTO 


```{c}
auto loginSensor = new ProcessSensor<QString>(this, QStringLiteral("login"), i18n("Login"), &KSysGuard::Process::login, KSysGuard::Process::Login, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto verify_counts = [this](const auto processes) {
        for (KSysGuard::Process *process : processes) {
            QCOMPARE(countNumChildren(process), process->numChildren());

            for(int i = 0; i < process->children().size(); i++) {
                QVERIFY(process->children()[i]->parent());
                QCOMPARE(process->children()[i]->parent(), process);
            }
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, pluginName]() {
        d->availablePresetsModel->reload();
    }
```

#### AUTO 


```{c}
auto *job = presetPackage.uninstall(pluginId, root.path());
```

#### RANGE FOR STATEMENT 


```{c}
for (KSysGuard::Process *process : processes) {
        QCOMPARE(countNumChildren(process), process->numChildren());

        for (int i = 0; i < process->children().size(); i++) {
            QVERIFY(process->children()[i]->parent());
            QCOMPARE(process->children()[i]->parent(), process);
        }
    }
```

#### AUTO 


```{c}
auto result = QVariant{};
```

#### AUTO 


```{c}
auto &history = *historyMapEntry;
```

#### AUTO 


```{c}
auto statusSensor = new ProcessSensor<uint>(this, QStringLiteral("status"), i18n("Status"), &KSysGuard::Process::status, KSysGuard::Process::Status);
```

#### LAMBDA EXPRESSION 


```{c}
[](ExtendedProcesses *p) {
            delete p;
        }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), nullptr);
```

#### AUTO 


```{c}
auto tracerpidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("tracerpid"), i18n("Tracer Pid"), &KSysGuard::Process::tracerpid, Process::Nothing, ForwardFirstEntry);
```

#### AUTO 


```{c}
const auto parts = line.splitRef(QLatin1Char(' '),  Qt::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto obj : d->subsystem->objects()) {
        if (d->matchObjects.match(obj->id()).hasMatch()) {
            auto sensor = obj->sensor(d->matchProperty);
            if (sensor) {
                addSensor(sensor);
            }
        }
    }
```

#### AUTO 


```{c}
auto gidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("gid"), i18n("gid"), &KSysGuard::Process::gid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : values) {
        Q_EMIT valueChanged(entry.sensorProperty, entry.payload);
    }
```

#### AUTO 


```{c}
auto type = first.type();
```

#### LAMBDA EXPRESSION 


```{c}
[this, node]() {
        auto row = d->m_cGroups.indexOf(node);
        Q_EMIT dataChanged(index(row, 0, QModelIndex()), index(row, 0, QModelIndex()));
    }
```

#### AUTO 


```{c}
auto attribute = extraAttributes.at(i);
```

#### AUTO 


```{c}
auto userNameSensor = new ProcessSensor<QString>(
    this, QStringLiteral("username"), i18n("Username"), [this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        auto userIt = d->m_userCache.find(uid);
        if (userIt == d->m_userCache.end()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }
        return userIt->loginName();
    },
    KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto newEntry = sensorsGroup.readEntry("sensors");
```

#### AUTO 


```{c}
auto list = KPackage::PackageLoader::self()->listPackages(QStringLiteral("KSysguard/SensorFace"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        update();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        if (uid == 65534) { // special value meaning nobody
            return false;
        }
        auto userIt = d->m_userCache.find(uid);
        if (userIt == d->m_userCache.end()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }

        if (!userIt->isValid()) {
            // For some reason the user isn't recognised.  This might happen under certain security situations.
            // Just return true to be safe
            return true;
        }
        const QString shell = userIt->shell();
        if (shell == QLatin1String("/bin/false")) { //FIXME - add in any other shells it could be for false
            return false;
        }
        return true;
    }
```

#### AUTO 


```{c}
auto sharedMemorySensor = new ProcessSensor<qlonglong>(
    this, QStringLiteral("vmShared"), i18n("Shared Memory Usage"), [](KSysGuard::Process *p) -> qlonglong {
        if (p->vmRSS() - p->vmURSS() < 0 || p->vmURSS() == -1) {
            return 0;
        }
        return (qlonglong)(p->vmRSS() - p->vmURSS());
    },
    KSysGuard::Process::VmRSS);
```

#### AUTO 


```{c}
const auto label = it.value().toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : changes) {
        switch (entry.first) {
        case Process::VmPSS:
            process->setVmPSS(entry.second.toLongLong());
            break;
        default:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : iterator) {
        if (!entry.is_directory()) {
            continue;
        }
        const QString childId = node->id() % QLatin1Char('/') % QString::fromUtf8(entry.path().filename().c_str());
        CGroup *childNode = d->m_cgroupMap[childId];
        if (!childNode) {
            childNode = new CGroup(childId);
            d->m_cgroupMap[childNode->id()] = childNode;

            if (filterAcceptsCGroup(childId)) {
                int row = d->m_cGroups.count();
                beginInsertRows(QModelIndex(), row, row);
                d->m_cGroups.append(childNode);
                endInsertRows();
            }
        }
        update(childNode);
        d->m_oldGroups.remove(childId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pid : pids) {
        auto fdPath = "/proc/%/fd"s.replace(6, 1, std::to_string(pid));
        auto dir = opendir(fdPath.data());
        if (dir == NULL) {
            continue;
        }

        dirent *fd = nullptr;
        while ((fd = readdir(dir))) {
            memset(buffer, 0, 100);
            readlinkat(dirfd(dir), fd->d_name, buffer, 99);
            auto target = std::string(buffer);
            if (target.find("socket:") == std::string::npos)
                continue;

            auto inode = std::stoi(target.substr(8));
            m_inodeToPid.insert(std::make_pair(inode, pid));
        }

        closedir(dir);
    }
```

#### AUTO 


```{c}
auto percentage = index.data(ProcessModel::PercentageRole).toFloat();
```

#### AUTO 


```{c}
auto error = processes->sendSignal(pid, sig);
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [priority](int pid) { return s_localProcesses->setNiceness(pid, priority); });
```

#### AUTO 


```{c}
auto proc = d->m_processes->getProcess(pid);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &resolvedSensors) {
        d->totalSensors = resolvedSensors;
        Q_EMIT totalSensorsChanged();
    }
```

#### AUTO 


```{c}
auto status = std::from_chars(view.data(), view.data() + view.length(), value);
```

#### AUTO 


```{c}
auto unit = info.unit;
```

#### AUTO 


```{c}
const auto &id
```

#### AUTO 


```{c}
auto ioReadSyscallsSensor = new ProcessSensor<qlonglong>(this,
                                                             QStringLiteral("ioReadSyscalls"),
                                                             i18n("IO Read Syscalls"),
                                                             &KSysGuard::Process::ioReadSyscalls,
                                                             KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto *job = presetPackage.install(dir.path());
```

#### AUTO 


```{c}
auto regexp = QRegularExpression{path};
```

#### AUTO 


```{c}
auto totalUserUsageSensor = new ProcessSensor<int>(this, QStringLiteral("totalUserUsage"), i18n("Group User CPU Usage"), &KSysGuard::Process::totalUserUsage, KSysGuard::Process::TotalUsage, Average);
```

#### AUTO 


```{c}
auto userIt = d->m_userCache.find(uid);
```

#### AUTO 


```{c}
auto data
```

#### AUTO 


```{c}
const auto& entry
```

#### AUTO 


```{c}
auto ttySensor = new ProcessSensor<QByteArray>(this, QStringLiteral("tty"), i18n("tty"), &KSysGuard::Process::tty, KSysGuard::Process::Tty, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        return m_queue.size() > 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attr : qAsConst(d->m_enabledAttributes)) {
        rc << attr->id();
    }
```

#### AUTO 


```{c}
auto timeSensor = new ProcessSensor<qlonglong>(
    this, QStringLiteral("totalUsage"), i18n("Total Time"), [](KSysGuard::Process *p) {
        return p->userTime() + p->sysTime();
    },
    KSysGuard::Process::Usage);
```

#### LAMBDA EXPRESSION 


```{c}
[this, lowPrioritySensorIds] (const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->lowPrioritySensorIds) {
            return;
        }
        d->lowPrioritySensorIds = lowPrioritySensorIds;

        d->sensorsGroup.writeEntry("lowPrioritySensorIds", QJsonDocument(lowPrioritySensorIds).toJson(QJsonDocument::Compact));
        d->syncTimer->start();
        emit lowPrioritySensorIdsChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : std::as_const(d->sensors)) {
            if (sensor) {
                sensor->unsubscribe();
            }
        }
```

#### AUTO 


```{c}
auto array = QJsonDocument::fromJson(d->sensorsGroup.readEntry(configEntry, QString()).toUtf8()).array();
```

#### AUTO 


```{c}
auto query = new KSysGuard::SensorQuery{id.toString()};
```

#### AUTO 


```{c}
auto protocol
```

#### LAMBDA EXPRESSION 


```{c}
[this, pid, runnable]() {
        Q_EMIT processUpdated(pid, { { Process::VmPSS, runnable->pss() } });
        runnable->deleteLater();
    }
```

#### AUTO 


```{c}
auto a
```

#### AUTO 


```{c}
auto remove = [this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->indexOf(item->segment);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->indexOf(parent->segment), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);
        delete item->parent->children.take(item->segment);
        q->endRemoveRows();

        sensorInfos.remove(item);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, &result](pid_t pid) {
        auto process = m_processes->getProcess(pid);
        if (process) {
            result.append(process);
        }
    }
```

#### AUTO 


```{c}
auto sgidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("sgid"), i18n("sgid"), &KSysGuard::Process::sgid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (KSysGuard::Process *process : processes) {
        if (process->pid() == 0)
            continue;
        QVERIFY(process->pid() > 0);
        QVERIFY(!process->name().isEmpty());

        // test all the pids are unique
        QVERIFY(!pids.contains(process->pid()));
        pids.insert(process->pid());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : qAsConst(m_enabledAttributes)) {
        flags |= attribute->requiredUpdateFlags();
    }
```

#### AUTO 


```{c}
auto ioCharactersWrittenRateSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersWrittenRate"), i18n("IO Characters Written Rate"), &KSysGuard::Process::ioCharactersWrittenRate, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, priority](int pid) { return d->localProcesses->setNiceness(pid, priority); });
```

#### AUTO 


```{c}
auto index = model->index(i, ProcessModel::HeadingCPUUsage, {});
```

#### AUTO 


```{c}
auto attribute = d->m_enabledAttributes[attr];
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [priority](int pid) {
        return s_localProcesses->setNiceness(pid, priority);
    });
```

#### AUTO 


```{c}
auto item = d->find(sensorId);
```

#### AUTO 


```{c}
auto sensor = d->sensors.take(sensorPath);
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher{d->dbusInterface->sensorData({sensorId}), this};
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                emit dataChanged(index, index);
            }
        }
```

#### AUTO 


```{c}
const auto &pluginMetaData
```

#### AUTO 


```{c}
auto p
```

#### AUTO 


```{c}
auto ioCharactersActuallyReadRateSensor = new ProcessSensor<qlonglong>(this,
                                                                           QStringLiteral("ioCharactersActuallyReadRate"),
                                                                           i18n("Disk Read Rate"),
                                                                           &KSysGuard::Process::ioCharactersActuallyReadRate,
                                                                           KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto vmSizeSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("vmSize"), i18n("VM Size"), &KSysGuard::Process::vmSize, KSysGuard::Process::VmSize);
```

#### AUTO 


```{c}
const auto& sensor
```

#### AUTO 


```{c}
auto c
```

#### AUTO 


```{c}
auto itemIndex = index(parentItem->indexOf(item->segment), 0, parentIndex);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& entry : fs::directory_iterator(path.toUtf8().data())) {
        if (!entry.is_directory()) {
            continue;
        }
        const QString childId = node->id() % QLatin1Char('/') % QString::fromUtf8(entry.path().filename().c_str());
        CGroup *childNode = d->m_cgroupMap[childId];
        if (!childNode) {
            childNode = new CGroup(childId);
            d->m_cgroupMap[childNode->id()] = childNode;

            if (filterAcceptsCGroup(childId)) {
                int row = d->m_cGroups.count();
                beginInsertRows(QModelIndex(), row, row);
                d->m_cGroups.append(childNode);
                endInsertRows();
            }
        }
        update(childNode);
        d->m_oldGroups.remove(childId);
    }
```

#### AUTO 


```{c}
auto regexp = QRegularExpression{QStringLiteral("^") % path % QStringLiteral("$")};
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigSkeletonItem *item : items) {
            configGroup.writeEntry(item->key(), item->property());
        }
```

#### AUTO 


```{c}
auto readPidsRunnable = new CGroupPrivate::ReadPidsRunnable(context, path, callback);
```

#### AUTO 


```{c}
auto parentPidSensor = new ProcessSensor<qlonglong>(this,
                                                        QStringLiteral("parentPid"),
                                                        i18n("Parent PID"),
                                                        &KSysGuard::Process::parentPid,
                                                        Process::Nothing,
                                                        ForwardFirstEntry);
```

#### AUTO 


```{c}
const auto removedSensors = currentSet - newSet;
```

#### LAMBDA EXPRESSION 


```{c}
[kService](bool) {
                KRun::runService(*kService, { }, nullptr);
            }
```

#### AUTO 


```{c}
auto pid = m_inodeToPid.find((*inode).second);
```

#### AUTO 


```{c}
auto error = function(pid);
```

#### LAMBDA EXPRESSION 


```{c}
[this, priorityClass, priority](int pid) {
        return d->localProcesses->setIoNiceness(pid, priorityClass, priority);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attr : std::as_const(d->m_enabledAttributes)) {
        rc << attr->id();
    }
```

#### AUTO 


```{c}
const auto addedSensors = newSet - currentSet;
```

#### AUTO 


```{c}
auto plugin
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, signal](int pid) { return d->localProcesses->sendSignal(pid, signal); });
```

#### AUTO 


```{c}
const auto attrs = attributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fileInfo : filesInfo) {
                OpenFilesModel::DataItem dataItem;
                dataItem.id = fileInfo.fileName().toUInt();
                dataItem.type = fileTypeFromPath(fileInfo.absoluteFilePath());
                if (fileInfo.isFile()) {
                    dataItem.filename = fileInfo.symLinkTarget();
                } else {
                    dataItem.filename = symLinkTargetFromPath(fileInfo.absoluteFilePath());
                }
                data << std::move(dataItem);
            }
```

#### AUTO 


```{c}
const auto executable = NetworkConstants::HelperLocation;
```

#### AUTO 


```{c}
auto ioCharactersWrittenRateSensor = new ProcessSensor<qlonglong>(this,
                                                                      QStringLiteral("ioCharactersWrittenRate"),
                                                                      i18n("IO Characters Written Rate"),
                                                                      &KSysGuard::Process::ioCharactersWrittenRate,
                                                                      KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto vmRSSSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("vmRSS"), i18n("RSS Memory Usage"), &KSysGuard::Process::vmRSS, KSysGuard::Process::VmRSS);
```

#### AUTO 


```{c}
auto pair
```

#### AUTO 


```{c}
const auto relativeStartTime = absoluteStartTime.secsTo(QDateTime::currentDateTime());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto unusedAttr : std::as_const(unusedAttributes)) {
        disconnect(unusedAttr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(kService);
```

#### AUTO 


```{c}
auto unusedAttr
```

#### AUTO 


```{c}
auto ttySensor =
        new ProcessSensor<QByteArray>(this, QStringLiteral("tty"), i18n("tty"), &KSysGuard::Process::tty, KSysGuard::Process::Tty, ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : std::as_const(d->sensors)) {
            if (sensor) {
                sensor->subscribe();
            }
        }
```

#### AUTO 


```{c}
auto bytesOut = parts.at(6).toUInt();
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorResolver *resolver) {
        d->highPrioritySensorIds = resolver->found;
        Q_EMIT highPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
auto ioCharactersActuallyReadRateSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersActuallyReadRate"), i18n("Disk Read Rate"), &KSysGuard::Process::ioCharactersActuallyReadRate, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto suidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("suid"), i18n("suid"), &KSysGuard::Process::suid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
const auto parts = line.splitRef(QLatin1Char('|'), Qt::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (Process *p : d->mListProcesses) {
        if (!d->mToBeProcessed.contains(p->pid())) {
            endedProcesses += p->pid();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : d->colorsGroup.keyList()) {
        QColor color = d->colorsGroup.readEntry(key, QColor());

        if (color.isValid()) {
            colors[key] = color;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : original) {
        QString sensorId = entry.toString();
        for (auto replacement : qAsConst(sensorIdReplacements)) {
            auto match = replacement.first.match(sensorId);
            if (match.hasMatch()) {
                sensorId.replace(replacement.first, replacement.second);
            }
        }
        sensorId = replaceDiskId(sensorId);
        sensorId = replacePartitionId(sensorId);
        newSensors.append(sensorId);
    }
```

#### AUTO 


```{c}
const auto devices = Solid::Device::listFromQuery(predicate);
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid() && process != d->m_removingRowFor) {
                    emit dataChanged(index, index);
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        d->availablePresetsModel->reload();
    }
```

#### AUTO 


```{c}
auto attr = d->m_availableAttributes.value(attribute, nullptr);
```

#### AUTO 


```{c}
auto newSet = QSet<QString>{requestedSensors.begin(), requestedSensors.end()};
```

#### AUTO 


```{c}
auto process = d->m_processes->getProcess(pid);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            switch (errno) {
            case ESRCH:
            case ENOENT:
                return Processes::ProcessDoesNotExistOrZombie;
            case EINVAL:
                return Processes::InvalidParameter;
            case EACCES:
            case EPERM:
                return Processes::InsufficientPermissions;
            default:
                return Processes::Unknown;
            }
        }
```

#### AUTO 


```{c}
auto index = std::distance(item->children.begin(), item->children.upper_bound(segment));
```

#### LAMBDA EXPRESSION 


```{c}
[this, priority](int pid) { return s_localProcesses->setNiceness(pid, priority); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { return m_queue.size() > 0; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : partialEntries) {
            KSysGuard::SensorQuery query{id.toString()};
            query.execute();
            query.waitForFinished();
            auto ids = query.sensorIds();
            std::stable_sort(ids.begin(), ids.end());
            for (const auto &fitleredId : qAsConst(ids)) {
                sensors.append(QJsonValue(fitleredId));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *process) {
        beginRemoveRow(process);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parent] {
                parent->addObject(this);
            }
```

#### AUTO 


```{c}
auto success = function(pid);
```

#### AUTO 


```{c}
auto ioCharactersWrittenSensor = new ProcessSensor<qlonglong>(this,
                                                                  QStringLiteral("ioCharactersWritten"),
                                                                  i18n("IO Characters Written"),
                                                                  &KSysGuard::Process::ioCharactersWritten,
                                                                  KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto fdPath = "/proc/%/fd"s.replace(6, 1, std::to_string(pid));
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [priorityClass, priority](int pid) {
        return s_localProcesses->setIoNiceness(pid, priorityClass, priority);
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) {
        return p->totalUserUsage() + p->totalSysUsage();
    }
```

#### AUTO 


```{c}
auto ioReadSyscallsRateSensor = new ProcessSensor<qlonglong>(this,
                                                                 QStringLiteral("ioReadSyscallsRate"),
                                                                 i18n("IO Read Syscalls Rate"),
                                                                 &KSysGuard::Process::ioReadSyscallsRate,
                                                                 KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto id
```

#### AUTO 


```{c}
auto inode = m_localToINode.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &resolvedSensors) {
        d->highPrioritySensorIds = resolvedSensors;
        Q_EMIT highPrioritySensorIdsChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto segment : segments) {
        if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second.get();
        } else {
            auto newItem = std::make_unique<SensorTreeItem>();
            newItem->parent = item;
            newItem->segment = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->indexOf(item->segment), 0, item);

            auto index = std::distance(item->children.begin(), item->children.upper_bound(segment));

            q->beginInsertRows(parentIndex, index, index);
            item->children[segment] = std::move(newItem);
            q->endInsertRows();

            item = item->children[segment].get();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const T &t) {
        return QVariant::fromValue(t);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, node](QVector<pid_t> pids) {
        auto row = d->m_cGroups.indexOf(node);
        if (row >= 0) {
            d->m_cGroups[row]->setPids(pids);
            d->m_processMap.remove(d->m_cGroups[row]);
            Q_EMIT dataChanged(index(row, 0, QModelIndex()), index(row, columnCount()-1, QModelIndex()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Process* process) -> QVariant {
                return QVariant::fromValue(process->pid());
            }
```

#### AUTO 


```{c}
auto error = [this] {
        switch (errno) {
        case ESRCH:
        case ENOENT:
            return Processes::ProcessDoesNotExistOrZombie;
        case EINVAL:
            return Processes::InvalidParameter;
        case EPERM:
            return Processes::InsufficientPermissions;
        default:
            return Processes::Unknown;
        }
    };
```

#### AUTO 


```{c}
auto inode = m_oldState.addressToInode.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pluginMetaData : listMetaData) {
        qCDebug(LIBKSYSGUARD_PROCESSCORE) << "loading plugin" << pluginMetaData.name();
        auto factory = qobject_cast<KPluginFactory *>(pluginMetaData.instantiate());
        if (!factory) {
            qCCritical(LIBKSYSGUARD_PROCESSCORE) << "failed to load plugin factory" << pluginMetaData.name();
            continue;
        }
        ProcessDataProvider *provider = factory->create<ProcessDataProvider>(q);
        if (!provider) {
            qCCritical(LIBKSYSGUARD_PROCESSCORE) << "failed to instantiate ProcessDataProvider" << pluginMetaData.name();
            continue;
        }
        m_providers << provider;
    }
```

#### AUTO 


```{c}
auto ioWriteSyscallsRateSensor = new ProcessSensor<qlonglong>(this,
                                                                  QStringLiteral("ioReadSyscallsRate"),
                                                                  i18n("IO Write Syscalls Rate"),
                                                                  &KSysGuard::Process::ioWriteSyscallsRate,
                                                                  KSysGuard::Process::IO);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto entry) {
        return entry.first;
    }
```

#### AUTO 


```{c}
auto processes = instance.lock();
```

#### LAMBDA EXPRESSION 


```{c}
[](const SensorInfo &first, const SensorInfo &second) {
        return first.max < second.max;
    }
```

#### AUTO 


```{c}
auto subfeatureType
```

#### AUTO 


```{c}
auto gidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("gid"), i18n("gid"), &KSysGuard::Process::gid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attributeId : enabledAttributes) {
        auto attribute = d->m_availableAttributes[attributeId];
        if (!attribute) {
            continue;
        }
        unusedAttributes.removeOne(attribute);
        d->m_enabledAttributes << attribute;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the columnIndex in the lambda makes everything super fast
        disconnect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            const QModelIndex index = d->getQModelIndex(process, columnIndex);
            emit dataChanged(index, index);
        });

        attribute->setEnabled(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto protocol : {IPPROTO_TCP, IPPROTO_UDP}) {
            if (!dumpSockets(family, protocol)) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto runnable = [this, path, callback, context]() {
        QFile pidFile(path);
        pidFile.open(QFile::ReadOnly | QIODevice::Text);
        QTextStream stream(&pidFile);

        QVector<pid_t> pids;
        QString line = stream.readLine();
        while (!line.isNull()) {
            pids.append(line.toLong());
            line = stream.readLine();
        }
        setPids(pids);

        // Ensure we call the callback on the thread the context object lives on.
        if (context) {
            QMetaObject::invokeMethod(context, callback);
        }
    };
```

#### AUTO 


```{c}
auto ioPriorityClassSensor = new ProcessSensor<uint>(this, QStringLiteral("ioPriorityClass"), i18n("IO Priority Class"),
            &KSysGuard::Process::ioPriorityClass, KSysGuard::Process::NiceLevels);
```

#### AUTO 


```{c}
auto packet = m_capture->nextPacket();
```

#### AUTO 


```{c}
auto totalUserUsageSensor = new ProcessSensor<int>(this,
                                                       QStringLiteral("totalUserUsage"),
                                                       i18n("Group User CPU Usage"),
                                                       &KSysGuard::Process::totalUserUsage,
                                                       KSysGuard::Process::TotalUsage,
                                                       Average);
```

#### AUTO 


```{c}
auto parentPidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("parentPid"), i18n("Parent PID"), &KSysGuard::Process::parentPid, Process::Nothing, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto parentItem = item->parent;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : partialEntries) {
        auto query = new KSysGuard::SensorQuery{id.toString()};
        query->connect(query, &KSysGuard::SensorQuery::finished, q, [this, query, sensors, callback] {
            query->sortByName();
            const auto ids = query->sensorIds();
            delete query;
            std::transform(ids.begin(), ids.end(), std::back_inserter(*sensors), [] (const QString &id) {
                return QJsonValue(id);
            });
            if (sensors.use_count() == 1) {
                // We are the last query
                callback(*sensors);
            }
        });
        query->execute();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->children.indexOf(item);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->children.indexOf(parent), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);
        delete item->parent->children.takeAt(index);
        q->endRemoveRows();

        sensorInfos.remove(item);
    }
```

#### AUTO 


```{c}
auto result = m_mapping->pidForPacket(packet);
```

#### AUTO 


```{c}
auto inode = std::stoi(target.substr(8));
```

#### AUTO 


```{c}
auto ioWriteSyscallsSensor = new ProcessSensor<qlonglong>(this,
                                                              QStringLiteral("ioWriteSyscalls"),
                                                              i18n("IO Write Syscalls"),
                                                              &KSysGuard::Process::ioWriteSyscalls,
                                                              KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), this);
```

#### AUTO 


```{c}
auto remove = [this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->indexOf(item->segment);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->indexOf(parent->segment), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);

        auto itr = item->parent->children.find(item->segment);
        item->parent->children.erase(itr);

        q->endRemoveRows();

        sensorInfos.remove(item);
    };
```

#### AUTO 


```{c}
auto result = std::min_element(d->sensorInfos.cbegin(), d->sensorInfos.cend(), [](const SensorInfo &first, const SensorInfo &second) { return first.min < second.min; });
```

#### LAMBDA EXPRESSION 


```{c}
[](long long entry) {
        return entry;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto segment : segments) {
        auto child = item->children.value(segment, nullptr);

        if (child) {
            item = child;

        } else {
            SensorTreeItem *newItem = new SensorTreeItem();
            newItem->parent = item;
            newItem->segment = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->indexOf(item->segment), 0, item);

            auto index = std::distance(item->children.begin(), item->children.upperBound(segment));

            q->beginInsertRows(parentIndex, index, index);
            item->children.insert(segment, newItem);
            q->endInsertRows();

            item = newItem;
        }
    }
```

#### AUTO 


```{c}
auto ids = query.sensorIds();
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher{d->dbusInterface->sensors(sensorIds), this};
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromLatin1(m_process->readLine());
            if (line.startsWith(QLatin1Char('#'))) { //comment line
                if (line != QLatin1String("# gpu        pid  type    sm   mem   enc   dec   command\n") &&
                    line != QLatin1String("# Idx          #   C/G     %     %     %     %   name\n")) {
                    //header format doesn't match what we expected, bail before we send any garbage
                    m_process->terminate();
                }
                continue;
            }
            const auto parts = line.splitRef(QLatin1Char(' '),  QString::SkipEmptyParts);

            // format at time of writing is
            // # gpu        pid  type    sm   mem   enc   dec   command
            if (parts.count() != 9) {
                continue;
            }

            long pid = parts[1].toUInt();
            int sm = parts[3].toUInt();
            int mem = parts[4].toUInt();

            KSysGuard::Process *process = getProcess(pid);
            if(!process) {
                continue; //can in race condition etc
            }
            m_usage->setData(process, sm);
            m_memory->setData(process, mem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) {
        return p->userUsage() + p->sysUsage();
    }
```

#### AUTO 


```{c}
auto itr = map.begin();
```

#### AUTO 


```{c}
auto oldInodes = m_inodes;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->totalSensors) {
            return;
        }
        d->totalSensors = resolvedSensors;
        Q_EMIT totalSensorsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *process, KSysGuard::Process *new_parent) {
        beginMoveProcess(process, new_parent);
    }
```

#### AUTO 


```{c}
auto pid = m_oldState.inodeToPid.find((*inode).second);
```

#### AUTO 


```{c}
auto &entry
```

#### AUTO 


```{c}
auto addByDesktopName = [this](const QString& desktopName)
    {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), nullptr);

            connect(action, &QAction::triggered, this,
                [kService](bool) {
                KRun::runService(*kService, { }, nullptr);
            });
            d->mToolsMenu->addAction(action);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        for (auto p : std::as_const(d->m_providers)) {
            if (p->enabled()) {
                p->update();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->m_processMap.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : enabledAttributes) {
        auto attr = d->m_availableAttributes.value(attribute, nullptr);
        if (!attr) {
            qWarning() << "Could not find attribute" << attribute;
            continue;
        }
        unusedAttributes.removeOne(attr);
        d->m_enabledAttributes << attr;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the attribute in the lambda makes everything super fast
        disconnect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            auto cgroup = d->m_cgroupMap.value(process->cGroup());
            if (!cgroup) {
                return;
            }
            const QModelIndex index = getQModelIndex(cgroup, columnIndex);
            emit dataChanged(index, index);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collator] (const QPair<QString, SensorInfo> &left, const QPair<QString, SensorInfo> &right) {
        return collator.compare(left.second.name, right.second.name) < 0;
    }
```

#### AUTO 


```{c}
auto usageSensor = new ProcessSensor<int>(
        this,
        QStringLiteral("usage"),
        i18n("Total CPU Usage"),
        [](KSysGuard::Process *p) {
            return p->userUsage() + p->sysUsage();
        },
        KSysGuard::Process::Usage,
        Accumulate);
```

#### AUTO 


```{c}
auto sensors = std::make_shared<QJsonArray>();
```

#### AUTO 


```{c}
auto error = processes->setIoNiceness(pid, priorityClass, priority);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            switch (errno) {
            case ESRCH:
            case ENOENT:
                return Processes::ProcessDoesNotExistOrZombie;
            case EINVAL:
                return Processes::InvalidParameter;
            case EPERM:
                return Processes::InsufficientPermissions;
            default:
                return Processes::Unknown;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KSysGuard::Process *process : processes2) {
        if (process->pid() == 0)
            continue;
        QVERIFY(process->pid() > 0);
        QVERIFY(!process->name().isEmpty());

        // test all the pids are unique
        if (!pids.contains(process->pid())) {
            qCDebug(LIBKSYSGUARD_PROCESSCORE) << process->pid() << " not found. " << process->name();
        }
        pids.remove(process->pid());
    }
```

#### AUTO 


```{c}
auto uidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("uid"), i18n("UID"), &KSysGuard::Process::uid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto process = m_processes->getProcess(pid);
```

#### AUTO 


```{c}
auto dir = opendir("/proc");
```

#### LAMBDA EXPRESSION 


```{c}
[this, priority](int pid) { return d->localProcesses->setNiceness(pid, priority); }
```

#### LAMBDA EXPRESSION 


```{c}
[](pid_t pid) {
            return int(pid);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[scheduler, priority](int pid) {
        return s_localProcesses->setScheduler(pid, scheduler, priority);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            Q_EMIT valueChanged();
            m_dataChangeQueued = false;
        }
```

#### AUTO 


```{c}
auto info = d->sensorInfos.value(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { return m_finished; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attr : std::as_const(attributes)) {
        d->m_availableAttributes[attr->id()] = attr;
    }
```

#### AUTO 


```{c}
const auto tooltip = i18n("Clock ticks since system boot: %1<br/>Seconds since system boot: %2 (System boot time: %3)<br/>Absolute start time: %4<br/>Relative start time: %5",
                                clockTicksSinceSystemBoot,
                                secondsSinceSystemBoot,
                                systemBootTime.toString(),
                                absoluteStartTime.toString(),
                                TimeUtil::secondsToHumanElapsedString(relativeStartTime));
```

#### AUTO 


```{c}
auto match = replacement.first.match(sensorId);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QVariant &entry) {
        return entry.toInt();
    }
```

#### AUTO 


```{c}
auto sharedMemorySensor = new ProcessSensor<qlonglong>(
        this,
        QStringLiteral("vmShared"),
        i18n("Shared Memory Usage"),
        [](KSysGuard::Process *p) -> qlonglong {
            if (p->vmRSS() - p->vmURSS() < 0 || p->vmURSS() == -1) {
                return 0;
            }
            return (qlonglong)(p->vmRSS() - p->vmURSS());
        },
        KSysGuard::Process::VmRSS);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : threadList) {
        int threadId = entry.toInt();
        if (!threadId) {
            return Processes::InvalidParameter;
        }
        if (sched_setscheduler( threadId, policy, &params) != 0) {
            return error();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &desktopName) {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()), kService->name(), this);

            connect(action, &QAction::triggered, this, [this, kService](bool) {
                auto *job = new KIO::ApplicationLauncherJob(kService);
                job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, window()));
                job->start();
            });
            d->mToolsMenu->addAction(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const SensorProperty *prop) {
        return prop->isSubscribed();
    }
```

#### AUTO 


```{c}
const auto pids = static_cast<KSysGuard::CGroup *>(index.internalPointer())->pids();
```

#### AUTO 


```{c}
auto ioCharactersReadRateSensor = new ProcessSensor<qlonglong>(this,
                                                                   QStringLiteral("ioCharactersReadRate"),
                                                                   i18n("IO Characters Read Rate"),
                                                                   &KSysGuard::Process::ioCharactersReadRate,
                                                                   KSysGuard::Process::IO);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->availablePresetsModel->reload();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : partialEntries) {
            KSysGuard::SensorQuery query{id.toString()};
            query.execute();
            query.waitForFinished();
            for (const auto &fitleredId : query.sensorIds()) {
                sensors.append(QJsonValue(fitleredId));
            }
        }
```

#### AUTO 


```{c}
auto bytesIn = parts.at(4).toUInt();
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, priorityClass, priority](int pid) {
        return d->localProcesses->setIoNiceness(pid, priorityClass, priority);
    });
```

#### LAMBDA EXPRESSION 


```{c}
[priority](int pid) { return s_localProcesses->setNiceness(pid, priority); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : std::as_const(m_enabledAttributes)) {
        flags |= attribute->requiredUpdateFlags();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : std::as_const(resolver->missing)) {
                missingSensors.append(entry);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, node](QVector<pid_t> pids) {
        auto row = d->m_cGroups.indexOf(node);
        if (row >= 0) {
            d->m_cGroups[row]->setPids(pids);
            Q_EMIT dataChanged(index(row, 0, QModelIndex()), index(row, columnCount()-1, QModelIndex()));
        }
    }
```

#### AUTO 


```{c}
auto string
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *) -> QObject * {
        return new FormatterWrapper();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->highPrioritySensorIds) {
            return;
        }
        d->highPrioritySensorIds = resolvedSensors;
        Q_EMIT highPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
const auto parts = QStringView(line).split(QLatin1Char('|'), Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal total, KSysGuard::Process *process) {
        return total + data(process).toDouble();
    }
```

#### AUTO 


```{c}
auto dir = opendir(fdPath.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto segment : segments) {
        auto child = item->children.value(segment, nullptr);

        if (child) {
            item = child;
        } else {
            SensorTreeItem *newItem = new SensorTreeItem();
            newItem->parent = item;
            newItem->segment = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->indexOf(item->segment), 0, item);

            auto index = std::distance(item->children.begin(), item->children.upperBound(segment));

            q->beginInsertRows(parentIndex, index, index);
            item->children.insert(segment, newItem);
            q->endInsertRows();

            item = newItem;
        }
    }
```

#### AUTO 


```{c}
auto destInode = m_localToINode.find(packet.destinationAddress());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : removedSensors) {
        removeSensor(sensor);
        itemsRemoved = true;
    }
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### AUTO 


```{c}
const auto systemBootTime = TimeUtil::systemUptimeAbsolute();
```

#### AUTO 


```{c}
auto option = -1;
```

#### AUTO 


```{c}
auto fsgidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("fsgid"), i18n("fsgid"), &KSysGuard::Process::fsgid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto sensor
```

#### AUTO 


```{c}
auto timeStamp = std::chrono::time_point_cast<TimeStamp::MicroSeconds::duration>(std::chrono::system_clock::from_time_t(header->ts.tv_sec)
                                                                                     + std::chrono::microseconds{header->ts.tv_usec});
```

#### AUTO 


```{c}
auto factory = qobject_cast<KPluginFactory *>(pluginMetaData.instantiate());
```

#### AUTO 


```{c}
const auto &fitleredId
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : std::as_const(d->m_enabledAttributes)) {
        flags |= attribute->requiredUpdateFlags();
    }
```

#### AUTO 


```{c}
auto ioCharactersReadSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersRead"), i18n("IO Characters Read"), &KSysGuard::Process::ioCharactersRead, KSysGuard::Process::IO);
```

#### LAMBDA EXPRESSION 


```{c}
[this, scheduler, priority](int pid) {
        return s_localProcesses->setScheduler(pid, scheduler, priority);
    }
```

#### AUTO 


```{c}
auto mapping = std::make_shared<ConnectionMapping>();
```

#### AUTO 


```{c}
auto result = std::max_element(d->sensorInfos.cbegin(), d->sensorInfos.cend(), [](const SensorInfo &first, const SensorInfo &second) { return first.max < second.max; });
```

#### AUTO 


```{c}
auto formatted =  KSysGuard::Formatter::formatValue(input, KSysGuard::UnitTime);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto subDir : entries) {
        const QString childId = node->id() % QLatin1Char('/') % subDir;
        CGroup *childNode = d->m_cgroupMap[childId];
        if (!childNode) {
            childNode = new CGroup(childId);
            d->m_cgroupMap[childNode->id()] = childNode;

            if (filterAcceptsCGroup(childId)) {
                int row = d->m_cGroups.count();
                beginInsertRows(QModelIndex(), row, row);
                d->m_cGroups.append(childNode);
                endInsertRows();
            }
        }
        update(childNode);
        d->m_oldGroups.remove(childId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : presetGroup.keyList()) {
            KConfigSkeletonItem *item = d->faceConfigLoader->findItemByName(key);
            if (item) {
                if (item->property().type() == QVariant::StringList) {
                    item->setProperty(presetGroup.readEntry(key, QStringList()));
                } else {
                    item->setProperty(presetGroup.readEntry(key));
                }
                d->faceConfigLoader->save();
                d->faceConfigLoader->read();
            }
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second.get();
        } else {
            auto newItem = std::make_unique<SensorTreeItem>();
            newItem->parent = item;
            newItem->segment = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->indexOf(item->segment), 0, item);

            auto index = std::distance(item->children.begin(), item->children.upper_bound(segment));

            q->beginInsertRows(parentIndex, index, index);
            item->children[segment] = std::move(newItem);
            q->endInsertRows();

            item = item->children[segment].get();
        }
```

#### AUTO 


```{c}
auto runCommandAction = new QAction(i18nc("@action:inmenu", "Run Command"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *unusedAttribute : qAsConst(unusedAttributes)) {
        disconnect(unusedAttribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
    }
```

#### AUTO 


```{c}
auto fsuidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("fsuid"), i18n("fsuid"), &KSysGuard::Process::fsuid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto loginSensor =
        new ProcessSensor<QString>(this, QStringLiteral("login"), i18n("Login"), &KSysGuard::Process::login, KSysGuard::Process::Login, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collator](const QPair<QString, SensorInfo> &left, const QPair<QString, SensorInfo> &right) {
        return collator.compare(left.second.name, right.second.name) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pid : pids) {
        auto success = function(pid);
        if (!success
            && (localProcesses->errorCode == KSysGuard::Processes::InsufficientPermissions
            || localProcesses->errorCode == KSysGuard::Processes::Unknown)) {
            result.unchanged << pid;
            result.resultCode = Result::InsufficientPermissions;
        } else if (result.resultCode == Result::Success) {
            switch (localProcesses->errorCode) {
            case Processes::InvalidPid:
            case Processes::ProcessDoesNotExistOrZombie:
            case Processes::InvalidParameter:
                result.resultCode = Result::NoSuchProcess;
                break;
            case Processes::NotSupported:
                result.resultCode = Result::Unsupported;
                break;
            default:
                result.resultCode = Result::Unknown;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto subfeatureType : subfeatureTypes) {
            const sensors_subfeature *const subfeature = sensors_get_subfeature(chipName, feature, subfeatureType);
            if (subfeature && sensors_get_value(chipName, subfeature->number, &value) == 0) {
                return value;
            }
        }
```

#### AUTO 


```{c}
auto ioReadSyscallsSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioReadSyscalls"), i18n("IO Read Syscalls"), &KSysGuard::Process::ioReadSyscalls, KSysGuard::Process::IO);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &partialEntries) {
        QJsonArray sensors;

        for (const auto &id : partialEntries) {
            KSysGuard::SensorQuery query{id.toString()};
            query.execute();
            query.waitForFinished();
            for (const auto &fitleredId : query.sensorIds()) {
                sensors.append(QJsonValue(fitleredId));
            }
        }
        return sensors;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : values) {
        Q_EMIT valueChanged(entry.attribute, entry.payload);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : qAsConst(d->m_enabledAttributes)) {
        flags |= attribute->requiredUpdateFlags();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attr : qAsConst(attributes)) {
        d->m_availableAttributes[attr->id()] = attr;
    }
```

#### AUTO 


```{c}
auto sensor = m_sensors.take(sensorPath);
```

#### AUTO 


```{c}
auto inode = toInode(view.substr(8));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attributeId : enabledAttributes) {
        auto attribute = d->m_availableAttributes[attributeId];
        if (!attribute) {
            continue;
        }
        unusedAttributes.removeOne(attribute);
        d->m_enabledAttributes << attribute;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the columnIndex in the lambda makes everything super fast
        disconnect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid()) {
                    emit dataChanged(index, index);
                }
            }
        });

        attribute->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto euidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("euid"), i18n("EUID"), &KSysGuard::Process::euid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto result = std::max_element(d->sensorInfos.cbegin(), d->sensorInfos.cend(), [](const SensorInfo &first, const SensorInfo &second) {
        return first.max < second.max;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this, query, sensors, callback] {
            query->sortByName();
            const auto ids = query->sensorIds();
            delete query;
            std::transform(ids.begin(), ids.end(), std::back_inserter(*sensors), [] (const QString &id) {
                return QJsonValue(id);
            });
            if (sensors.use_count() == 1) {
                // We are the last query
                callback(*sensors);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QJsonArray &resolvedSensors) {
        d->lowPrioritySensorIds = resolvedSensors;
        Q_EMIT lowPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
auto fsuidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("fsuid"), i18n("fsuid"), &KSysGuard::Process::fsuid, KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto protocol : {IPPROTO_TCP, IPPROTO_UDP}) {
            if (!dumpSockets(socket, family, protocol)) {
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attr : attributes) {
        m_availableAttributes[attr->id()] = attr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        endRemoveRow();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pid : pids) {
        auto fdPath = "/proc/%/fd"s.replace(6, 1, std::to_string(pid));
        auto dir = opendir(fdPath.data());
        if (dir == NULL) {
            continue;
        }

        dirent *fd = nullptr;
        while ((fd = readdir(dir))) {
            memset(buffer, 0, 100);
            readlinkat(dirfd(dir), fd->d_name, buffer, 100);
            auto target = std::string(buffer);
            if (target.find("socket:") == std::string::npos)
                continue;

            auto inode = std::stoi(target.substr(8));
            m_inodeToPid.insert(std::make_pair(inode, pid));
        }

        closedir(dir);
    }
```

#### AUTO 


```{c}
auto fanMatch = fanRegex.match(labelString);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *process) {
                if (!process->changes().testFlag(m_changeFlag)) {
                    return;
                }
                Q_EMIT dataChanged(process);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : partialEntries) {
        KSysGuard::SensorQuery query{id.toString()};
        query.execute();
        query.waitForFinished();
        query.sortByName();
        const auto ids = query.sensorIds();
        std::transform(ids.begin(), ids.end(), std::back_inserter(sensors), [] (const QString &id) {
            return QJsonValue(id);
        });
    }
```

#### AUTO 


```{c}
auto order = unitOrder(unit);
```

#### LAMBDA EXPRESSION 


```{c}
[this, scheduler, priority](int pid) {
        return d->localProcesses->setScheduler(pid, scheduler, priority);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) -> qlonglong {
            if (p->vmRSS() - p->vmURSS() < 0 || p->vmURSS() == -1) {
                return 0;
            }
            return (qlonglong)(p->vmRSS() - p->vmURSS());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[priority](int pid) {
        return s_localProcesses->setNiceness(pid, priority);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->totalSensors) {
            return;
        }
        d->totalSensors = resolvedSensors;
        Q_EMIT totalSensorsChanged();
    }
```

#### AUTO 


```{c}
auto sensorsGroup = config.group("Sensors");
```

#### AUTO 


```{c}
auto forceSave = d->faceProperties.readEntry(QStringLiteral("ForceSaveOnDestroy"), false);
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, scheduler, priority](int pid) {
        return s_localProcesses->setScheduler(pid, scheduler, priority);
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute: enabledAttributes) {
         auto attr = d->m_availableAttributes.value(attribute, nullptr);
         if (!attr) {
             qWarning() << "Could not find attribute" << attribute;
             continue;
         }
         unusedAttributes.removeOne(attr);
         d->m_enabledAttributes << attr;
         int columnIndex = d->m_enabledAttributes.count() - 1;

         // reconnect as using the attribute in the lambda makes everything super fast
         disconnect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
         connect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
             auto cgroup = d->m_cgroupMap.value(process->cGroup());
             if (!cgroup) {
                 return;
             }
             const QModelIndex index = getQModelIndex(cgroup, columnIndex);
             emit dataChanged(index, index);
         });

         attr->setEnabled(true);
     }
```

#### AUTO 


```{c}
const auto secondsSinceSystemBoot = (double)clockTicksSinceSystemBoot / clockTicksPerSecond;
```

#### AUTO 


```{c}
auto attribute = d->m_attributes[index.row()];
```

#### AUTO 


```{c}
auto numThreadsSensor = new ProcessSensor<int>(this,
                                                   QStringLiteral("numThreads"),
                                                   i18n("Threads"),
                                                   &KSysGuard::Process::numThreads,
                                                   KSysGuard::Process::NumThreads,
                                                   ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto p : qAsConst(d->m_providers)) {
        rc << p->attributes();
    }
```

#### AUTO 


```{c}
auto canUserLoginSensor = new ProcessSensor<bool>(
        this,
        QStringLiteral("canUserLogin"),
        i18n("Can Login"),
        [this](KSysGuard::Process *p) {
            const K_UID uid = p->uid();
            if (uid == 65534) { // special value meaning nobody
                return false;
            }
            auto userIt = d->m_userCache.find(uid);
            if (userIt == d->m_userCache.end()) {
                userIt = d->m_userCache.insert(uid, KUser(uid));
            }

            if (!userIt->isValid()) {
                // For some reason the user isn't recognised.  This might happen under certain security situations.
                // Just return true to be safe
                return true;
            }
            const QString shell = userIt->shell();
            if (shell == QLatin1String("/bin/false")) { // FIXME - add in any other shells it could be for false
                return false;
            }
            return true;
        },
        KSysGuard::Process::Uids,
        ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (KSysGuard::Process *process : processes) {
            QCOMPARE(countNumChildren(process), process->numChildren());

            for(int i = 0; i < process->children().size(); i++) {
                QVERIFY(process->children()[i]->parent());
                QCOMPARE(process->children()[i]->parent(), process);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : attrs) {
            a->clearData(process);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, parent] {parent->addObject(this);}
```

#### AUTO 


```{c}
auto cgroup = d->m_cgroupMap.value(process->cGroup());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attributeId : enabledAttributes) {
        auto attribute = d->m_availableAttributes[attributeId];
        if (!attribute) {
            continue;
        }
        unusedAttributes.removeOne(attribute);
        d->m_enabledAttributes << attribute;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the columnIndex in the lambda makes everything super fast
        disconnect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid()) {
                    emit dataChanged(index, index);
                }
            }
        });
    }
```

#### AUTO 


```{c}
auto canUserLoginSensor = new ProcessSensor<bool>(
    this, QStringLiteral("canUserLogin"), i18n("Can Login"), [this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        if (uid == 65534) { // special value meaning nobody
            return false;
        }
        auto userIt = d->m_userCache.constFind(uid);
        if (userIt == d->m_userCache.constEnd()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }

        if (!userIt->isValid()) {
            // For some reason the user isn't recognised.  This might happen under certain security situations.
            // Just return true to be safe
            return true;
        }
        const QString shell = userIt->shell();
        if (shell == QLatin1String("/bin/false")) { //FIXME - add in any other shells it could be for false
            return false;
        }
        return true;
    },
    KSysGuard::Process::Uids, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto pid
```

#### RANGE FOR STATEMENT 


```{c}
for (auto data : allData) {
            Q_EMIT valueChanged(data.sensorProperty, data.payload);
        }
```

#### AUTO 


```{c}
auto it = labels.cbegin();
```

#### AUTO 


```{c}
auto attr
```

#### RANGE FOR STATEMENT 


```{c}
for (auto family : {AF_INET, AF_INET6}) {
        for (auto protocol : {IPPROTO_TCP, IPPROTO_UDP}) {
            if (!dumpSockets(family, protocol)) {
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
auto niceLevelSensor =
        new ProcessSensor<int>(this, QStringLiteral("niceLevel"), i18n("Nice Level"), &KSysGuard::Process::niceLevel, KSysGuard::Process::NiceLevels);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromUtf8(m_process->readLine());

            // Each line consists of: timestamp|PID|pid|IN|in_bytes|OUT|out_bytes
            const auto parts = line.splitRef(QLatin1Char('|'), Qt::SkipEmptyParts);
            if (parts.size() < 7) {
                continue;
            }

            long pid = parts.at(2).toLong();

            auto timeStamp = QDateTime::currentDateTimeUtc();
            timeStamp.setTime(QTime::fromString(parts.at(0).toString(), QStringLiteral("HH:mm:ss")));

            auto bytesIn = parts.at(4).toUInt();
            auto bytesOut = parts.at(6).toUInt();

            auto process = getProcess(pid);
            if (!process) {
                return;
            }

            m_inboundSensor->setData(process, bytesIn);
            m_outboundSensor->setData(process, bytesOut);
        }
    }
```

#### AUTO 


```{c}
auto ioPriorityClassSensor = new ProcessSensor<uint>(this,
                                                         QStringLiteral("ioPriorityClass"),
                                                         i18n("IO Priority Class"),
                                                         &KSysGuard::Process::ioPriorityClass,
                                                         KSysGuard::Process::NiceLevels);
```

#### AUTO 


```{c}
auto ioCharactersReadSensor = new ProcessSensor<qlonglong>(this,
                                                               QStringLiteral("ioCharactersRead"),
                                                               i18n("IO Characters Read"),
                                                               &KSysGuard::Process::ioCharactersRead,
                                                               KSysGuard::Process::IO);
```

#### RANGE FOR STATEMENT 


```{c}
for (KSysGuard::Process *process : processes) {
        if (process->pid() == 0)
            continue;
        QVERIFY(process->pid() > 0);
        QVERIFY(!process->name().isEmpty());

        QVERIFY(!pids.contains(process->pid()));
        pids.insert(process->pid());
    }
```

#### AUTO 


```{c}
auto numThreadsSensor = new ProcessSensor<int>(this, QStringLiteral("numThreads"), i18n("Threads"), &KSysGuard::Process::numThreads, KSysGuard::Process::NumThreads, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto formatted = KSysGuard::Formatter::formatValue(input, unit);
```

#### AUTO 


```{c}
const auto match = oldPartitionSensor.match(entryName);
```

#### AUTO 


```{c}
auto segment
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            const QModelIndex index = d->getQModelIndex(process, columnIndex);
            emit dataChanged(index, index);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : qAsConst(m_sensors)) {
            sensor->subscribe();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, killWindowKwinMethod](bool) {
        // with DBus call, always use the async method.
        // Otherwise it could wait up to 30 seconds in certain situations.
        killWindowKwinMethod->asyncCall(QStringLiteral("killWindow"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto processes) {
        for (KSysGuard::Process *process : processes) {
            QCOMPARE(countNumChildren(process), process->numChildren());

            for(int i = 0; i < process->children().size(); i++) {
                QVERIFY(process->children()[i]->parent());
                QCOMPARE(process->children()[i]->parent(), process);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &key) {
            auto item = d->faceConfigLoader->findItemByName(key);
            if (item) {
                item->writeConfig(d->faceConfigLoader->config());
            }
        }
```

#### AUTO 


```{c}
auto killWindowAction = new QAction(QIcon::fromTheme(QStringLiteral("document-close")), i18nc("@action:inmenu", "Kill a Window"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        self->deleteLater();

        const QDBusPendingReply<SensorDataList> reply = *self;
        if (reply.isError()) {
            return;
        }

        const auto allData = reply.value();
        for (auto data : allData) {
            Q_EMIT valueChanged(data.sensorProperty, data.payload);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, object]() {
        removeObject(object);
    }
```

#### AUTO 


```{c}
auto loadSensors = [this](const QJsonArray &partialEntries) {
        QJsonArray sensors;

        for (const auto &id : partialEntries) {
            KSysGuard::SensorQuery query{id.toString()};
            query.execute();
            query.waitForFinished();
            auto ids = query.sensorIds();
            std::stable_sort(ids.begin(), ids.end());
            for (const auto &fitleredId : qAsConst(ids)) {
                sensors.append(QJsonValue(fitleredId));
            }
        }
        return sensors;
    };
```

#### AUTO 


```{c}
auto it = d->sensors.constBegin();
```

#### AUTO 


```{c}
auto query = new SensorQuery{entry.toString()};
```

#### AUTO 


```{c}
auto tracerpidSensor = new ProcessSensor<qlonglong>(this,
                                                        QStringLiteral("tracerpid"),
                                                        i18n("Tracer Pid"),
                                                        &KSysGuard::Process::tracerpid,
                                                        Process::Nothing,
                                                        ForwardFirstEntry);
```

#### AUTO 


```{c}
auto sourceInode = m_localToINode.find(packet.sourceAddress());
```

#### AUTO 


```{c}
const auto pids = static_cast<KSysGuard::CGroup*>(index.internalPointer())->pids();
```

#### AUTO 


```{c}
auto commandSensor = new ProcessSensor<QString>(this,
                                                    QStringLiteral("command"),
                                                    i18n("Command"),
                                                    &KSysGuard::Process::command,
                                                    KSysGuard::Process::Command,
                                                    ForwardFirstEntry);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : threadList) {
        int threadId = entry.toInt();
        if (!threadId) {
            return Processes::InvalidParameter;
        }
        if (setpriority(PRIO_PROCESS, threadId, priority)) {
            return error();
        }
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second;
        } else {
            SensorTreeItem *newItem = new SensorTreeItem();
            newItem->parent = item;
            newItem->segment = segment;

            const QModelIndex &parentIndex = (item == rootItem) ? QModelIndex() : q->createIndex(item->parent->indexOf(item->segment), 0, item);

            auto index = std::distance(item->children.begin(), item->children.upper_bound(segment));

            q->beginInsertRows(parentIndex, index, index);
            item->children[segment] = newItem;
            q->endInsertRows();

            item = newItem;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin : list) {
        QStandardItem *item = new QStandardItem(plugin.name());
        item->setData(plugin.pluginId(), FacesModel::PluginIdRole);
        appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto string : strings) {
            string = string.trimmed();
            if (process->name().indexOf(string) != -1 || QString::number(process->pid()).indexOf(string) != -1) {
                return true;
            }
        }
```

#### AUTO 


```{c}
const auto &plugin = *it;
```

#### LAMBDA EXPRESSION 


```{c}
[this, kService](bool) {
                auto *job = new KIO::ApplicationLauncherJob(kService);
                job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, window()));
                job->start();
            }
```

#### AUTO 


```{c}
auto totalSysUsageSensor = new ProcessSensor<int>(this, QStringLiteral("totalSysUsage"), i18n("Group System CPU Usage"), &KSysGuard::Process::totalSysUsage, KSysGuard::Process::TotalUsage, Average);
```

#### LAMBDA EXPRESSION 


```{c}
[this, highPrioritySensorIds] (const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->highPrioritySensorIds) {
            return;
        }
        d->highPrioritySensorIds = resolvedSensors;

        d->sensorsGroup.writeEntry("highPrioritySensorIds", QJsonDocument(highPrioritySensorIds).toJson(QJsonDocument::Compact));
        d->syncTimer->start();
        emit highPrioritySensorIdsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](pid_t pid) { return int(pid); }
```

#### LAMBDA EXPRESSION 


```{c}
[query, this]() {
        query->deleteLater();
        const auto result = query->result();
        for (auto pair : result) {
            d->addSensor(pair.first, pair.second);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        self->deleteLater();

        const QDBusPendingReply<SensorInfoMap> reply = *self;
        if (reply.isError()) {
            return;
        }

        const auto infos = reply.value();
        for (auto itr = infos.begin(); itr != infos.end(); ++itr) {
            Q_EMIT metaDataChanged(itr.key(), itr.value());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[query, this]() {
        query->deleteLater();
        const auto result = query->result();
        beginResetModel();
        for (auto pair : result) {
            d->addSensor(pair.first, pair.second);
        }
        endResetModel();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->appearanceGroup.sync();
        d->sensorsGroup.sync();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromUtf8(m_process->readLine());

            // Each line consists of: timestamp|PID|pid|IN|in_bytes|OUT|out_bytes
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
            const auto parts = line.splitRef(QLatin1Char('|'), Qt::SkipEmptyParts);
#else
            const auto parts = QStringView(line).split(QLatin1Char('|'), Qt::SkipEmptyParts);
#endif
            if (parts.size() < 7) {
                continue;
            }

            long pid = parts.at(2).toLong();

            auto timeStamp = QDateTime::currentDateTimeUtc();
            timeStamp.setTime(QTime::fromString(parts.at(0).toString(), QStringLiteral("HH:mm:ss")));

            auto bytesIn = parts.at(4).toUInt();
            auto bytesOut = parts.at(6).toUInt();

            auto process = getProcess(pid);
            if (!process) {
                return;
            }

            m_inboundSensor->setData(process, bytesIn);
            m_outboundSensor->setData(process, bytesOut);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
            auto cgroup = d->m_cgroupMap.value(process->cGroup());
            if (!cgroup) {
                return;
            }
            const QModelIndex index = getQModelIndex(cgroup, columnIndex);
            emit dataChanged(index, index);
        }
```

#### AUTO 


```{c}
auto id = KSysGuard::SensorDataModel::SensorId;
```

#### AUTO 


```{c}
auto userTimeSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("userTime"), i18n("User Time"), &KSysGuard::Process::userTime);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : threadList) {
        int threadId = entry.toInt();
        if (!threadId) {
            return Processes::InvalidParameter;
        }
        if (setpriority( PRIO_PROCESS, threadId, priority )) {
            return error();
        }
    }
```

#### AUTO 


```{c}
auto statusSensor = new ProcessSensor<QString>(this, QStringLiteral("status"), i18n("Status"), &KSysGuard::Process::translatedStatus, KSysGuard::Process::Status);
```

#### AUTO 


```{c}
auto self = static_cast<ConnectionMapping *>(arg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
            // all strings for now, type conversion happens in QML side when we have the config property map
            config.insert(key, configGroup.readEntry(key));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromLatin1(m_process->readLine());
            if (line.startsWith(QLatin1Char('#'))) { //comment line
                if (line != QLatin1String("# gpu        pid  type    sm   mem   enc   dec   command\n") &&
                    line != QLatin1String("# Idx          #   C/G     %     %     %     %   name\n")) {
                    //header format doesn't match what we expected, bail before we send any garbage
                    m_process->terminate();
                }
                continue;
            }
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            const auto parts = line.splitRef(QLatin1Char(' '),  QString::SkipEmptyParts);
#else
            const auto parts = line.splitRef(QLatin1Char(' '),  Qt::SkipEmptyParts);
#endif

            // format at time of writing is
            // # gpu        pid  type    sm   mem   enc   dec   command
            if (parts.count() < 5) { // we only access up to the 5th element
                continue;
            }

            long pid = parts[1].toUInt();
            int sm = parts[3].toUInt();
            int mem = parts[4].toUInt();

            KSysGuard::Process *process = getProcess(pid);
            if(!process) {
                continue; //can in race condition etc
            }
            m_usage->setData(process, sm);
            m_memory->setData(process, mem);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, totalSensors] (const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->totalSensors) {
            return;
        }
        d->totalSensors = resolvedSensors;

        d->sensorsGroup.writeEntry("totalSensors", QJsonDocument(totalSensors).toJson(QJsonDocument::Compact));
        d->syncTimer->start();
        emit totalSensorsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                update();
            }
```

#### AUTO 


```{c}
auto percentageHist = index.data(ProcessModel::PercentageHistoryRole).value<QVector<ProcessModel::PercentageHistoryEntry>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto p : std::as_const(d->m_providers)) {
            if (p->enabled()) {
                p->update();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const SensorInfo &first, const SensorInfo &second) { return first.min < second.min; }
```

#### AUTO 


```{c}
const auto &key
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        uint count = std::count_if(d->sensors.constBegin(), d->sensors.constEnd(), [](const SensorProperty *prop) {
            return prop->isSubscribed();
        });
        if (count == 1) {
            Q_EMIT subscribedChanged(true);
        } else if (count == 0) {
            Q_EMIT subscribedChanged(false);
        }
    }
```

#### AUTO 


```{c}
auto commandSensor = new ProcessSensor<QString>(this, QStringLiteral("command"), i18n("Command"), &KSysGuard::Process::command, KSysGuard::Process::Command, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto entry = itr.value();
```

#### AUTO 


```{c}
auto tempMatch = tempRegex.match(labelString);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : qAsConst(d->m_oldGroups)) {
        int row = d->m_cGroups.indexOf(c);
        if (row >= 0) {
            beginRemoveRows(QModelIndex(), row, row);
            d->m_cGroups.removeOne(c);
            endRemoveRows();
        }
        d->m_cgroupMap.remove(c->id());
        delete c;
    }
```

#### AUTO 


```{c}
auto sensor = d->sensors.at(section);
```

#### AUTO 


```{c}
auto strings = filterRegExp().pattern().split(QLatin1Char(','), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto replaceSensors = [this, from, to](const QString &configEntry) {
        auto array = QJsonDocument::fromJson(d->sensorsGroup.readEntry(configEntry, QString()).toUtf8()).array();
        for (auto itr = array.begin(); itr != array.end(); ++itr) {
            if (itr->toString() == from) {
                *itr = QJsonValue(to);
            }
        }
        return QJsonDocument(array).toJson(QJsonDocument::Compact);
    };
```

#### AUTO 


```{c}
auto sysTimeSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("sysTime"), i18n("System Time"), &KSysGuard::Process::sysTime);
```

#### AUTO 


```{c}
auto info = d->sensorInfos.value(sensor);
```

#### AUTO 


```{c}
auto obj
```

#### AUTO 


```{c}
auto itr = item->children.find(segment);
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [signal](int pid) { return s_localProcesses->sendSignal(pid, signal); });
```

#### AUTO 


```{c}
auto *unusedAttribute
```

#### AUTO 


```{c}
const auto clockTicksSinceSystemBoot = process->startTime();
```

#### AUTO 


```{c}
auto it = response.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KSysGuard::Process *p) {
            return p->userUsage() + p->sysUsage();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *process) {
                if (!process->changes().testFlag(m_changeFlag)) {
                    return;
                }
                emit dataChanged(process);
            }
```

#### AUTO 


```{c}
const auto killWindowShortcutList = KGlobalAccel::self()->globalShortcut(QStringLiteral("kwin"), QStringLiteral("Kill Window"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attributeId : enabledAttributes) {
        auto attribute = d->m_availableAttributes[attributeId];
        if (!attribute) {
            continue;
        }
        unusedAttributes.removeOne(attribute);
        d->m_enabledAttributes << attribute;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the columnIndex in the lambda makes everything super fast
        disconnect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                emit dataChanged(index, index);
            }
        });

        attribute->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto verify_counts = [this](const auto processes) {
        Q_FOREACH( KSysGuard::Process *process, processes) {
            QCOMPARE(countNumChildren(process), process->numChildren());

            for(int i = 0; i < process->children().size(); i++) {
                QVERIFY(process->children()[i]->parent());
                QCOMPARE(process->children()[i]->parent(), process);
            }
        }
    };
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second;
        } else {
            return nullptr;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *process) {
        const auto attrs = attributes();
        for (auto a : attrs) {
            a->clearData(process);
        }
    }
```

#### AUTO 


```{c}
auto itr = metaData.begin();
```

#### AUTO 


```{c}
auto itr = options.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonArray &resolvedSensors) {
        d->lowPrioritySensorIds = resolvedSensors;
        Q_EMIT lowPrioritySensorIdsChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pid : pids) {
        auto error = function(pid);
        switch (error) {
        case KSysGuard::Processes::InsufficientPermissions:
        case KSysGuard::Processes::Unknown:
            result.unchanged << pid;
            result.resultCode = Result::InsufficientPermissions;
            break;
        case Processes::InvalidPid:
        case Processes::ProcessDoesNotExistOrZombie:
        case Processes::InvalidParameter:
            result.resultCode = Result::NoSuchProcess;
            break;
        case Processes::NotSupported:
            result.resultCode = Result::Unsupported;
            break;
        case Processes::NoError:
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        endMoveProcess();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : partialEntries) {
        KSysGuard::SensorQuery query{id.toString()};
        query.execute();
        query.waitForFinished();
        auto ids = query.sensorIds();
        std::stable_sort(ids.begin(), ids.end());
        for (const auto &fitleredId : qAsConst(ids)) {
            sensors.append(QJsonValue(fitleredId));
        }
    }
```

#### AUTO 


```{c}
auto it = colors.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int pid) { m_data.erase(pid); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        auto userIt = d->m_userCache.find(uid);
        if (userIt == d->m_userCache.end()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }
        return userIt->loginName();
    }
```

#### AUTO 


```{c}
auto itr = item->parent->children.find(item->segment);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attributeId : enabledAttributes) {
        auto attribute = d->m_availableAttributes[attributeId];
        if (!attribute) {
            continue;
        }
        unusedAttributes.removeOne(attribute);
        d->m_enabledAttributes << attribute;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the columnIndex in the lambda makes everything super fast
        disconnect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid() && process != d->m_removingRowFor) {
                    emit dataChanged(index, index);
                }
            }
        });
    }
```

#### AUTO 


```{c}
auto addByDesktopName = [this](const QString& desktopName)
    {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), this);

            connect(action, &QAction::triggered, this,
                [this, kService](bool) {
                auto *job = new KIO::ApplicationLauncherJob(kService);
                job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, window()));
                job->start();
            });
            d->mToolsMenu->addAction(action);
        }
    };
```

#### AUTO 


```{c}
auto fdDir = opendir(fdPath.data());
```

#### AUTO 


```{c}
const auto currentEntry = QJsonDocument::fromJson(d->sensorsGroup.readEntry("highPrioritySensorIds").toUtf8()).array();
```

#### AUTO 


```{c}
auto inetDiagMsg = static_cast<inet_diag_msg*>(nlmsg_data(nlh));
```

#### AUTO 


```{c}
const auto runCommandShortcutList = KGlobalAccel::self()->globalShortcut(QStringLiteral("krunner"), QStringLiteral("run command"));
```

#### AUTO 


```{c}
auto ioCharactersReadRateSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersReadRate"), i18n("IO Characters Read Rate"), &KSysGuard::Process::ioCharactersReadRate, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto err
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [scheduler, priority](int pid) {
        return s_localProcesses->setScheduler(pid, scheduler, priority);
    });
```

#### AUTO 


```{c}
auto sensors = d->readAndUpdateSensors(d->sensorsGroup, QStringLiteral("totalSensors"));
```

#### AUTO 


```{c}
const auto sensorIds = reply.value().keys();
```

#### AUTO 


```{c}
auto ioCharactersActuallyWrittenRateSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersActuallyWrittenRate"), i18n("Disk Write Rate"), &KSysGuard::Process::ioCharactersActuallyWrittenRate, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto newItem = std::make_unique<SensorTreeItem>();
```

#### AUTO 


```{c}
auto index = -1 - i;
```

#### AUTO 


```{c}
auto sensor = obj->sensor(d->matchProperty);
```

#### AUTO 


```{c}
auto now = QDateTime::currentDateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        QDirIterator it(dir, QStringList() << QStringLiteral("*.desktop"), QDir::NoFilter, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            scripts.append(it.next());
        }
    }
```

#### AUTO 


```{c}
auto threadList{QDir(QString::fromLatin1("/proc/%1/task").arg(pid)).entryList(QDir::NoDotAndDotDot | QDir::Dirs)};
```

#### AUTO 


```{c}
auto tester = new QAbstractItemModelTester(model);
```

#### AUTO 


```{c}
const auto parts = line.splitRef(QLatin1Char(' '), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto itr = d->units.begin() + index.row();
```

#### AUTO 


```{c}
auto userIt = d->m_userCache.constFind(uid);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second.get();
        } else {
            return nullptr;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &segment : segments) {
        item = item->children.value(segment, nullptr);
        if (!item) {
            return nullptr;
        }
    }
```

#### AUTO 


```{c}
auto statsRequested = false;
```

#### AUTO 


```{c}
static auto calculateRate = [](qlonglong current, qlonglong previous, int elapsedTime) {
            if (elapsedTime <= 0 || previous <= 0) {
                return 0.0;
            }
            return (current - previous) * 1000.0 / elapsedTime;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, i](KSysGuard::Process *process) {
            const QModelIndex index = q->getQModelIndex(process, mHeadings.count() + i);
            Q_EMIT q->dataChanged(index, index);
        }
```

#### AUTO 


```{c}
auto entry
```

#### AUTO 


```{c}
auto vmRSSSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("vmRSS"), i18n("RSS Memory Usage"), &KSysGuard::Process::vmRSS, KSysGuard::Process::VmRSS);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attribute : enabledAttributes) {
        auto attr = d->m_availableAttributes.value(attribute, nullptr);
        if (!attr) {
            qWarning() << "Could not find attribute" << attribute;
            continue;
        }
        unusedAttributes.removeOne(attr);
        d->m_enabledAttributes << attr;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the attribute in the lambda makes everything super fast
        disconnect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attr, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            auto cgroup = d->m_cgroupMap.value(process->cGroup());
            if (!cgroup) {
                return;
            }
            const QModelIndex index = getQModelIndex(cgroup, columnIndex);
            Q_EMIT dataChanged(index, index);
        });
    }
```

#### AUTO 


```{c}
auto error =
        [this] {
            switch (errno) {
            case ESRCH:
            case ENOENT:
                return Processes::ProcessDoesNotExistOrZombie;
            case EINVAL:
                return Processes::InvalidParameter;
            case EPERM:
                return Processes::InsufficientPermissions;
            default:
                return Processes::Unknown;
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, signal](int pid) { return d->localProcesses->sendSignal(pid, signal); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            update();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pid, runnable](qulonglong pss) {
            Q_EMIT processUpdated(pid, { { Process::VmPSS, pss } });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto attributeId : enabledAttributes) {
        auto attribute = d->m_availableAttributes[attributeId];
        if (!attribute) {
            continue;
        }
        unusedAttributes.removeOne(attribute);
        d->m_enabledAttributes << attribute;
        int columnIndex = d->m_enabledAttributes.count() - 1;

        // reconnect as using the columnIndex in the lambda makes everything super fast
        disconnect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
        connect(attribute, &KSysGuard::ProcessAttribute::dataChanged, this, [this, columnIndex](KSysGuard::Process *process) {
            if (process->pid() != -1) {
                const QModelIndex index = d->getQModelIndex(process, columnIndex);
                if (index.isValid() && process != d->m_removingRowFor) {
                    Q_EMIT dataChanged(index, index);
                }
            }
        });
    }
```

#### AUTO 


```{c}
auto model = processList.processModel();
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &id) {
                return QJsonValue(id);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &input) {
        return std::atoll(input);
    }
```

#### AUTO 


```{c}
auto error =
        [this] {
            switch (errno) {
            case ESRCH:
            case ENOENT:
                return Processes::ProcessDoesNotExistOrZombie;
            case EINVAL:
                return Processes::InvalidParameter;
            case EACCES:
            case EPERM:
                return Processes::InsufficientPermissions;
            default:
                return Processes::Unknown;
            }
        };
```

#### AUTO 


```{c}
auto killWindowAction = new QAction(QIcon::fromTheme(QStringLiteral("document-close")),
                                        i18nc("@action:inmenu", "Kill a Window"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto entry) { return entry.first; }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        self->deleteLater();

        const QDBusPendingReply<SensorDataList> reply = *self;
        if (reply.isError()) {
            return;
        }

        const auto allData = reply.value();
        for (auto data : allData) {
            Q_EMIT valueChanged(data.attribute, data.payload);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto replacement : qAsConst(sensorIdReplacements)) {
            auto match = replacement.first.match(sensorId);
            if (match.hasMatch()) {
                sensorId.replace(replacement.first, replacement.second);
            }
        }
```

#### AUTO 


```{c}
auto currentSet = QSet<QString>{sensors.begin(), sensors.end()};
```

#### RANGE FOR STATEMENT 


```{c}
for (auto data : allData) {
            Q_EMIT valueChanged(data.attribute, data.payload);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *p) {
        const K_UID uid = p->uid();
        if (uid == 65534) { // special value meaning nobody
            return false;
        }
        auto userIt = d->m_userCache.constFind(uid);
        if (userIt == d->m_userCache.constEnd()) {
            userIt = d->m_userCache.insert(uid, KUser(uid));
        }

        if (!userIt->isValid()) {
            // For some reason the user isn't recognised.  This might happen under certain security situations.
            // Just return true to be safe
            return true;
        }
        const QString shell = userIt->shell();
        if (shell == QLatin1String("/bin/false")) { //FIXME - add in any other shells it could be for false
            return false;
        }
        return true;
    }
```

#### AUTO 


```{c}
auto index = q->createIndex(row, ProcessModel::HeadingVmPSS, process);
```

#### AUTO 


```{c}
auto vmPSSSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("vmPSS"), i18n("Memory Usage"), &KSysGuard::Process::vmPSS, KSysGuard::Process::VmPSS);
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback](SensorResolver *resolver) {
        callback(resolver);

        if (!resolver->missing.isEmpty()) {
            for (const auto &entry : std::as_const(resolver->missing)) {
                missingSensors.append(entry);
            }
            Q_EMIT q->missingSensorsChanged();
        }

        delete resolver;
    }
```

#### AUTO 


```{c}
auto now = chrono::steady_clock::now();
```

#### AUTO 


```{c}
auto error = [this] {
        switch (errno) {
        case ESRCH:
        case ENOENT:
            return Processes::ProcessDoesNotExistOrZombie;
        case EINVAL:
            return Processes::InvalidParameter;
        case EACCES:
        case EPERM:
            return Processes::InsufficientPermissions;
        default:
            return Processes::Unknown;
        }
    };
```

#### AUTO 


```{c}
auto result = d->mProcessController->sendSignal(pids, sig);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto pid : pids) {
        auto success = function(pid);
        if (!success) {
            switch (s_localProcesses->errorCode) {
            case KSysGuard::Processes::InsufficientPermissions:
            case KSysGuard::Processes::Unknown:
                result.unchanged << pid;
                result.resultCode = Result::InsufficientPermissions;
                break;
            case Processes::InvalidPid:
            case Processes::ProcessDoesNotExistOrZombie:
            case Processes::InvalidParameter:
                result.resultCode = Result::NoSuchProcess;
                break;
            case Processes::NotSupported:
                result.resultCode = Result::Unsupported;
                break;
            default:
                result.resultCode = Result::Unknown;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : original) {
        QString sensorId = entry.toString();
        for (auto replacement : qAsConst(sensorIdReplacements)) {
            auto match = replacement.first.match(sensorId);
            if (match.hasMatch()) {
                sensorId.replace(replacement.first, replacement.second);
            }
        }
        newSensors.append(sensorId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto unusedAttr : qAsConst(unusedAttributes)) {
         disconnect(unusedAttr, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
         unusedAttr->setEnabled(false);
     }
```

#### LAMBDA EXPRESSION 


```{c}
[signal](int pid) {
        return s_localProcesses->sendSignal(pid, signal);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, columnIndex](KSysGuard::Process *process) {
             auto cgroup = d->m_cgroupMap.value(process->cGroup());
             if (!cgroup) {
                 return;
             }
             const QModelIndex index = getQModelIndex(cgroup, columnIndex);
             emit dataChanged(index, index);
         }
```

#### AUTO 


```{c}
const auto infos = reply.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this](SensorTreeItem *item, SensorTreeItem *parent) {
        const int index = item->parent->indexOf(item->segment);

        const QModelIndex &parentIndex = (parent == rootItem) ? QModelIndex() : q->createIndex(parent->parent->indexOf(parent->segment), 0, parent);
        q->beginRemoveRows(parentIndex, index, index);
        delete item->parent->children.take(item->segment);
        q->endRemoveRows();

        sensorInfos.remove(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const T& t){return QVariant::fromValue(t);}
```

#### LAMBDA EXPRESSION 


```{c}
[this, query, sensors, callback] {
            query->sortByName();
            const auto ids = query->sensorIds();
            delete query;
            std::transform(ids.begin(), ids.end(), std::back_inserter(*sensors), [](const QString &id) {
                return QJsonValue(id);
            });
            if (sensors.use_count() == 1) {
                // We are the last query
                callback(*sensors);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& desktopName)
    {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), nullptr);

            connect(action, &QAction::triggered, this,
                [kService](bool) {
                KRun::runService(*kService, { }, nullptr);
            });
            d->mToolsMenu->addAction(action);
        }
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto status = std::from_chars(view.data(), view.data() + view.length(), value); status.ec == std::errc()) {
        return value;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { actionTriggered(action); }
```

#### AUTO 


```{c}
auto ioCharactersWrittenSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioCharactersWritten"), i18n("IO Characters Written"), &KSysGuard::Process::ioCharactersWritten, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto extraAttributes = d->mModel.extraAttributes();
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, scheduler, priority](int pid) {
        return d->localProcesses->setScheduler(pid, scheduler, priority);
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        if (enabled == d->m_enabled) {
            return;
        }
        bool wasEnabled = d->m_enabled;

        d->m_enabled = std::any_of(d->m_attributes.constBegin(), d->m_attributes.constEnd(), [](ProcessAttribute *p) {
            return p->enabled();
        });

        if (d->m_enabled != wasEnabled) {
            handleEnabledChanged(d->m_enabled);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromLatin1(m_process->readLine());
            if (line.startsWith(QLatin1Char('#'))) { //comment line
                if (line != QLatin1String("# gpu        pid  type    sm   mem   enc   dec   command\n") &&
                    line != QLatin1String("# Idx          #   C/G     %     %     %     %   name\n")) {
                    //header format doesn't match what we expected, bail before we send any garbage
                    m_process->terminate();
                }
                continue;
            }
            const auto parts = line.splitRef(QLatin1Char(' '),  Qt::SkipEmptyParts);

            // format at time of writing is
            // # gpu        pid  type    sm   mem   enc   dec   command
            if (parts.count() < 5) { // we only access up to the 5th element
                continue;
            }

            long pid = parts[1].toUInt();
            int sm = parts[3].toUInt();
            int mem = parts[4].toUInt();

            KSysGuard::Process *process = getProcess(pid);
            if(!process) {
                continue; //can in race condition etc
            }
            m_usage->setData(process, sm);
            m_memory->setData(process, mem);
        }
    }
```

#### AUTO 


```{c}
auto packet = std::move(m_queue.front());
```

#### AUTO 


```{c}
auto egidSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("egid"), i18n("egid"), &KSysGuard::Process::egid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() {
            actionTriggered(action);
        }
```

#### AUTO 


```{c}
auto runnable = new ReadProcSmapsRunnable{dir};
```

#### AUTO 


```{c}
const auto absoluteStartTime = systemBootTime.addSecs(secondsSinceSystemBoot);
```

#### AUTO 


```{c}
auto attribute = d->m_availableAttributes[attributeId];
```

#### AUTO 


```{c}
auto totalSysUsageSensor = new ProcessSensor<int>(this,
                                                      QStringLiteral("totalSysUsage"),
                                                      i18n("Group System CPU Usage"),
                                                      &KSysGuard::Process::totalSysUsage,
                                                      KSysGuard::Process::TotalUsage,
                                                      Average);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *unusedAttribute : std::as_const(unusedAttributes)) {
        disconnect(unusedAttribute, &KSysGuard::ProcessAttribute::dataChanged, this, nullptr);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        while (m_process->canReadLine()) {
            const QString line = QString::fromUtf8(m_process->readLine());

            // Each line consists of: timestamp|PID|pid|IN|in_bytes|OUT|out_bytes
            const auto parts = line.splitRef(QLatin1Char('|'), QString::SkipEmptyParts);
            if (parts.size() < 7) {
                continue;
            }

            long pid = parts.at(2).toLong();

            auto timeStamp = QDateTime::currentDateTimeUtc();
            timeStamp.setTime(QTime::fromString(parts.at(0).toString(), QStringLiteral("HH:mm:ss")));

            auto bytesIn = parts.at(4).toUInt();
            auto bytesOut = parts.at(6).toUInt();

            auto process = getProcess(pid);
            if (!process) {
                return;
            }

            m_inboundSensor->setData(process, bytesIn);
            m_outboundSensor->setData(process, bytesOut);
        }
    }
```

#### AUTO 


```{c}
auto size = readlinkat(dirfd(fdDir), fd->d_name, buffer.data(), 99);
```

#### AUTO 


```{c}
auto threadList { QDir(QString::fromLatin1("/proc/%1/task").arg(pid)).
                     entryList( QDir::NoDotAndDotDot | QDir::Dirs ) };
```

#### AUTO 


```{c}
const auto clockTicksPerSecond = sysconf(_SC_CLK_TCK);
```

#### AUTO 


```{c}
const auto clockTicksSinceSystemBoot = process->startTime;
```

#### AUTO 


```{c}
const auto parts = line.splitRef(QLatin1Char(' '),  QString::SkipEmptyParts);
```

#### AUTO 


```{c}
const auto entries = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
```

#### AUTO 


```{c}
auto sensors = d.readAndUpdateSensors(sensorsGroup, QStringLiteral("sensors"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto err : component->errors()) {
            qWarning() << err.toString();
        }
```

#### AUTO 


```{c}
auto result = d->applyToPids(pids, [this, signal](int pid) { return s_localProcesses->sendSignal(pid, signal); });
```

#### AUTO 


```{c}
auto vmURSSSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("vmURSS"), i18n("Private Memory Usage"), &KSysGuard::Process::vmURSS, KSysGuard::Process::VmURSS);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &segment : segments) {
        if (auto itr = item->children.find(segment); itr != item->children.end() && itr->second) {
            item = itr->second.get();
        } else {
            return nullptr;
        }
    }
```

#### AUTO 


```{c}
auto data = accumulator->data();
```

#### AUTO 


```{c}
auto sensor = new SensorsFeatureSensor(id, chipName, valueFeature, parent);
```

#### AUTO 


```{c}
auto it = d->sensorLabels.constFind(sensor);
```

#### AUTO 


```{c}
auto item = rootItem;
```

#### AUTO 


```{c}
auto inMatch = inRegex.match(labelString);
```

#### AUTO 


```{c}
auto destInode = m_oldState.addressToInode.find(packet.destinationAddress());
```

#### LAMBDA EXPRESSION 


```{c}
[this, from, to](const QString &configEntry) {
        auto array = QJsonDocument::fromJson(d->sensorsGroup.readEntry(configEntry, QString()).toUtf8()).array();
        for (auto itr = array.begin(); itr != array.end(); ++itr) {
            if (itr->toString() == from) {
                *itr = QJsonValue(to);
            }
        }
        return QJsonDocument(array).toJson(QJsonDocument::Compact);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, other]() {
        setMax(other->value().toReal());
    }
```

#### AUTO 


```{c}
auto ioniceLevelSensor = new ProcessSensor<int>(this, QStringLiteral("ioniceLevel"), i18n("IO Nice Level"), &KSysGuard::Process::ioniceLevel, KSysGuard::Process::NiceLevels);
```

#### AUTO 


```{c}
auto nameSensor =
        new ProcessSensor<QString>(this, QStringLiteral("name"), i18n("Name"), &KSysGuard::Process::name, KSysGuard::Process::Name, ForwardFirstEntry);
```

#### AUTO 


```{c}
auto attribute = d->m_enabledAttributes[section];
```

#### AUTO 


```{c}
auto ioReadSyscallsRateSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("ioReadSyscallsRate"), i18n("IO Read Syscalls Rate"), &KSysGuard::Process::ioReadSyscallsRate, KSysGuard::Process::IO);
```

#### AUTO 


```{c}
auto vmURSSSensor =
        new ProcessSensor<qlonglong>(this, QStringLiteral("vmURSS"), i18n("Private Memory Usage"), &KSysGuard::Process::vmURSS, KSysGuard::Process::VmURSS);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : qAsConst(m_sensors)) {
            sensor->unsubscribe();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        uint count = std::count_if(d->sensors.constBegin(), d->sensors.constEnd(), [](const SensorProperty *prop) {
            return prop->isSubscribed();
        });
        if (count == 1) {
            emit subscribedChanged(true);
        } else if (count == 0) {
            emit subscribedChanged(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *p) {
            const K_UID uid = p->uid();
            auto userIt = d->m_userCache.find(uid);
            if (userIt == d->m_userCache.end()) {
                userIt = d->m_userCache.insert(uid, KUser(uid));
            }
            return userIt->loginName();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QJsonArray &resolvedSensors) {
        if (resolvedSensors == d->highPrioritySensorIds) {
            return;
        }
        d->highPrioritySensorIds = resolvedSensors;
        Q_EMIT highPrioritySensorIdsChanged();
    }
```

#### AUTO 


```{c}
const auto ids = query->sensorIds();
```

#### AUTO 


```{c}
auto self = static_cast<ConnectionMapping*>(arg);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &id]() {
        endResetModel();
        d->processedSensors.insert(id);
        Q_EMIT readyChanged();
    }
```

#### AUTO 


```{c}
auto guard = qScopeGuard([this, &id]() {
        endResetModel();
        d->processedSensors.insert(id);
        Q_EMIT readyChanged();
    });
```

#### AUTO 


```{c}
auto device = m_interface.empty() ? (const char *)nullptr : m_interface.c_str();
```

#### AUTO 


```{c}
auto schedulerSensor =
        new ProcessSensor<uint>(this, QStringLiteral("scheduler"), i18n("Scheduler"), &KSysGuard::Process::scheduler, KSysGuard::Process::NiceLevels);
```

#### AUTO 


```{c}
const auto parts = QStringView(line).split(QLatin1Char(' '), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto model = new KSysGuard::SensorTreeModel();
```

#### LAMBDA EXPRESSION 


```{c}
[=](int exitCode, QProcess::ExitStatus status) {
        if (exitCode != 0 || status != QProcess::NormalExit) {
            qCWarning(KSYSGUARD_PLUGIN_NETWORK) << "Helper process terminated abnormally!";
            qCWarning(KSYSGUARD_PLUGIN_NETWORK) << m_process->readAllStandardError();
        }
    }
```

#### AUTO 


```{c}
const auto currentEntry = QJsonDocument::fromJson(d->sensorsGroup.readEntry("totalSensors").toUtf8()).array();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int pid) {
        m_data.erase(pid);
    }
```

#### AUTO 


```{c}
const auto pids = app->pids();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : d->labelsGroup.keyList()) {
        labels[key] = d->labelsGroup.readEntry(key);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &key) {
            auto item = d->faceConfigLoader->findItemByName(key);
            if (item) {
                item->writeConfig(d->faceConfigLoader->config());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : threadList) {
        int threadId = entry.toInt();
        if (!threadId) {
            return Processes::InvalidParameter;
        }
        if (sched_setscheduler(threadId, policy, &params) != 0) {
            return error();
        }
    }
```

#### AUTO 


```{c}
auto egidSensor = new ProcessSensor<qlonglong>(this, QStringLiteral("egid"), i18n("egid"), &KSysGuard::Process::egid, KSysGuard::Process::Gids, ForwardFirstEntry);
```

#### LAMBDA EXPRESSION 


```{c}
[priorityClass, priority](int pid) {
        return s_localProcesses->setIoNiceness(pid, priorityClass, priority);
    }
```

#### AUTO 


```{c}
auto parentEnabled = parent()->property("enabled");
```

#### AUTO 


```{c}
auto itr = std::find(from.begin(), from.end(), start);
```

#### AUTO 


```{c}
const auto &items = d->faceConfigLoader->items();
```

#### AUTO 


```{c}
auto addByDesktopName = [this](const QString &desktopName) {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()), kService->name(), this);

            connect(action, &QAction::triggered, this, [this, kService](bool) {
                auto *job = new KIO::ApplicationLauncherJob(kService);
                job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, window()));
                job->start();
            });
            d->mToolsMenu->addAction(action);
        }
    };
```

#### AUTO 


```{c}
auto ioCharactersActuallyReadSensor = new ProcessSensor<qlonglong>(this,
                                                                       QStringLiteral("ioCharactersActuallyRead"),
                                                                       i18n("IO Characters Actually Read"),
                                                                       &KSysGuard::Process::ioCharactersActuallyRead,
                                                                       KSysGuard::Process::IO);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        endInsertRow();
    }
```

#### AUTO 


```{c}
auto attributeId
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& desktopName)
    {
        auto kService = KService::serviceByDesktopName(desktopName);
        if (kService) {
            auto action = new QAction(QIcon::fromTheme(kService->icon()),
                            kService->name(), this);

            connect(action, &QAction::triggered, this,
                [kService](bool) {
                KRun::runService(*kService, { }, nullptr);
            });
            d->mToolsMenu->addAction(action);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto sensor : qAsConst(d->sensors)) {
            if (sensor) {
                sensor->subscribe();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        switch (errno) {
        case ESRCH:
        case ENOENT:
            return Processes::ProcessDoesNotExistOrZombie;
        case EINVAL:
            return Processes::InvalidParameter;
        case EACCES:
        case EPERM:
            return Processes::InsufficientPermissions;
        default:
            return Processes::Unknown;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QJsonArray &resolvedSensors) {
        d->highPrioritySensorIds = resolvedSensors;
        Q_EMIT highPrioritySensorIdsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KSysGuard::Process *process) {
        beginInsertRow(process);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const pid_t pid : pids) {
        auto proc = d->m_processes->getProcess(pid);
        if (proc) { // as potentially this is racey with when kprocess fetched data
            processes << proc;
        }
    }
```

#### AUTO 


```{c}
const auto column = d->sensors.indexOf(sensorId);
```

#### AUTO 


```{c}
auto c = KSharedConfig::openConfig(presetPackage.filePath("config", QStringLiteral("faceproperties")), KConfig::SimpleConfig);
```

#### AUTO 


```{c}
auto tmp = m_data;
```

#### AUTO 


```{c}
auto index = std::distance(item->children.begin(), item->children.upperBound(segment));
```

