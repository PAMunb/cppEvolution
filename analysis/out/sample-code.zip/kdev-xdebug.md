#### AUTO 


```{c}
auto session = new DebugSession;
```

#### AUTO 


```{c}
const auto url = QUrl::fromLocalFile(file.fileName());
```

#### AUTO 


```{c}
auto it = m_ids.find(breakpoint);
```

#### AUTO 


```{c}
auto* b = m_ids.key(el.attribute("id"))
```

