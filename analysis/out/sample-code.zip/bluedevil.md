#### LAMBDA EXPRESSION 


```{c}
[ request](RequestConfirmation::Result result) {
        if (result == RequestConfirmation::Accept) {
            qCDebug(BLUEDAEMON) << "Accepting request";
            request.accept();
            return;
        }

        qCDebug(BLUEDAEMON) << "Rejecting request";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, service, call]() {
        QDBusPendingReply<bool> reply = *call;
        if (reply.isError()) {
            return;
        }

        Q_EMIT networkAvailable(service, reply.value());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int id) {
        if (id == Success) {
            done(QDialog::Accepted);
        }
        // Sending notification in SuccessPage is asynchronous, so this needs to be queued.
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, request](RequestConfirmation::Result result) {
        if (result == RequestConfirmation::Accept) {
            qCDebug(BLUEDAEMON) << "Accepting request";
            request.accept();
            return;
        }

        qCDebug(BLUEDAEMON) << "Rejecting request";
        request.reject();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &file : itemList) {
        fileList << file.localPath();
    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(KService::serviceByDesktopName(QStringLiteral("org.kde.bluedevilwizard")));
```

#### RANGE FOR STATEMENT 


```{c}
for (BluezQt::AdapterPtr adapter : m_manager->adapters()) {
            adapter->setPowered(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : files) {
        QFile file(filePath);
        m_filesSizes << file.size();
        m_totalSize += file.size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BluezQt::AdapterPtr adapter : m_manager->adapters()) {
            adapter->setPowered(false);
        }
```

#### AUTO 


```{c}
const auto onCurrentIdChanged = [this](int id) {
        if (id == Success) {
            done(QDialog::Accepted);
        }
        // Sending notification in SuccessPage is asynchronous, so this needs to be queued.
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](int id) {
            if (id == Success) {
                done(QDialog::Accepted);
            }
            // Sending notification in SuccessPage is asynchronous, so this needs to be queued.
        }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("bluedevil-sendfile"), {QStringLiteral("-u"), ubi});
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](QDBusPendingCallWatcher *watcher) {
        const QDBusPendingReply<bool> &reply = *watcher;
        watcher->deleteLater();
        if (reply.isError() || !reply.value()) {
            menu->menuAction()->setVisible(false);
            return;
        }

        watcher = new QDBusPendingCallWatcher(m_kded->allDevices());
        connect(watcher, &QDBusPendingCallWatcher::finished, this, [this, menu](QDBusPendingCallWatcher *watcher) {
            const QDBusPendingReply<QMapDeviceInfo> &reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                menu->menuAction()->setVisible(false);
                return;
            }

            const QMapDeviceInfo &devices = m_kded->allDevices().value();
            Q_FOREACH (const DeviceInfo &device, devices) {
                if (device.value(QStringLiteral("UUIDs")).contains(BluezQt::Services::ObexObjectPush)) {
                    const QIcon &icon = QIcon::fromTheme(device[QStringLiteral("icon")], QIcon::fromTheme(QStringLiteral("preferences-system-bluetooth")));
                    QAction *action = new QAction(icon, device.value(QStringLiteral("name")), this);
                    connect(action, &QAction::triggered, this, &SendFileItemAction::deviceTriggered);
                    action->setData(device.value(QStringLiteral("UBI")));
                    menu->insertAction(0, action);
                }
            }

            QAction *otherAction = new QAction(i18nc("Other Bluetooth device", "Other..."), this);
            connect(otherAction, &QAction::triggered, this, &SendFileItemAction::otherTriggered);

            menu->addSeparator();
            menu->addAction(otherAction);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, device, request](RequestAuthorization::Result result) {
        processAuthorizationRequest(device, request, result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](QDBusPendingCallWatcher *watcher) {
            const QDBusPendingReply<QMapDeviceInfo> &reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                menu->menuAction()->setVisible(false);
                return;
            }

            const QMapDeviceInfo &devices = m_kded->allDevices().value();
            Q_FOREACH (const DeviceInfo &device, devices) {
                if (device.value(QStringLiteral("UUIDs")).contains(BluezQt::Services::ObexObjectPush)) {
                    const QIcon &icon = QIcon::fromTheme(device[QStringLiteral("icon")], QIcon::fromTheme(QStringLiteral("preferences-system-bluetooth")));
                    QAction *action = new QAction(icon, device.value(QStringLiteral("name")), this);
                    connect(action, &QAction::triggered, this, &SendFileItemAction::deviceTriggered);
                    action->setData(device.value(QStringLiteral("UBI")));
                    menu->insertAction(0, action);
                }
            }

            QAction *otherAction = new QAction(i18nc("Other Bluetooth device", "Other..."), this);
            connect(otherAction, &QAction::triggered, this, &SendFileItemAction::otherTriggered);

            menu->addSeparator();
            menu->addAction(otherAction);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BluezQt::ObexFileTransferEntry &item : items) {
        if (!item.isValid()) {
            continue;
        }

        KIO::UDSEntry entry;
        entry.fastInsert(KIO::UDSEntry::UDS_NAME, item.name());
        entry.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, item.label());
        entry.fastInsert(KIO::UDSEntry::UDS_ACCESS, 0700);
        entry.fastInsert(KIO::UDSEntry::UDS_MODIFICATION_TIME, item.modificationTime().toSecsSinceEpoch());
        entry.fastInsert(KIO::UDSEntry::UDS_SIZE, item.size());

        if (item.type() == BluezQt::ObexFileTransferEntry::Folder) {
            entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFDIR);
        } else if (item.type() == BluezQt::ObexFileTransferEntry::File) {
            entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFREG);
        }

        if (urlIsRoot(url)) {
            updateRootEntryIcon(entry, item.memoryType());
        }

        list.append(entry);

        // Most probably the client of the kio will stat each file
        // so since we are on it, let's cache all of them.
        QUrl statUrl = url;

        if (statUrl.path().endsWith('/')) {
            statUrl.setPath(statUrl.path() + item.name());
        } else {
            statUrl.setPath(statUrl.path() + QLatin1Char('/') + item.name());
        }

        if (!m_statMap.contains(statUrl.toDisplayString())) {
            qCDebug(BLUEDEVIL_KIO_OBEXFTP_LOG) << "Stat:" << statUrl.toDisplayString() << entry.stringValue(KIO::UDSEntry::UDS_NAME)
                                               << entry.numberValue(KIO::UDSEntry::UDS_SIZE);
            m_statMap.insert(statUrl.toDisplayString(), entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DeviceInfo &device : devices) {
        listDevice(device);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[request](RequestConfirmation::Result result) {
        if (result == RequestConfirmation::Accept) {
            qCDebug(BLUEDAEMON) << "Accepting request";
            request.accept();
            return;
        }

        qCDebug(BLUEDAEMON) << "Rejecting request";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool exists) {
            if (!exists) {
                m_ui->napButton->show();
                updateActions();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ request](const QString &result) {
        if (!result.isEmpty()) {
            qCDebug(BLUEDAEMON) << "Introducing PIN...";
            request.accept(result);
            return;
        }

        qCDebug(BLUEDAEMON) << "No PIN introduced";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_isParentValid = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QModelIndex index : indexes) {
            BluezQt::DevicePtr device = m_devicesModel->device(m_proxyModel->mapToSource(index));
            if (device) {
                device->adapter()->removeDevice(device);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[wizard]() {
        wizard->setWindowState((wizard->windowState() & ~Qt::WindowMinimized) | Qt::WindowActive);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, request](const QString &result) {
        if (!result.isEmpty()) {
            qCDebug(BLUEDAEMON) << "Introducing PIN...";
            request.accept(result);
            return;
        }

        qCDebug(BLUEDAEMON) << "No PIN introduced";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, request](const QString &result) {
        bool ok;
        quint32 passkey = result.toInt(&ok);
        if (ok) {
            qCDebug(BLUEDAEMON) << "Introducing PassKey...";
            request.accept(passkey);
            return;
        }

        qCDebug(BLUEDAEMON) << "No PassKey introduced";
        request.reject();
    }
```

#### AUTO 


```{c}
auto *delegate = new KNotificationJobUiDelegate(KNotificationJobUiDelegate::AutoErrorHandlingEnabled);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            QFileInfo info(file);
            fileNames.append(info.fileName());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ device, request](RequestAuthorization::Result result) {
        processAuthorizationRequest(device, request, result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[wizard]() {
        KWindowSystem::updateStartupId(wizard->windowHandle());
        KWindowSystem::activateWindow(wizard->windowHandle());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[request](RequestConfirmation::Result result) {
        if (result == RequestConfirmation::Accept) {
            qCDebug(BLUEDEVIL_KDED_LOG) << "Accepting request";
            request.accept();
            return;
        }

        qCDebug(BLUEDEVIL_KDED_LOG) << "Rejecting request";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, adapter]() {
        restoreAdapter(adapter);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[request](const QString &result) {
        if (!result.isEmpty()) {
            qCDebug(BLUEDEVIL_KDED_LOG) << "Introducing PIN...";
            request.accept(result);
            return;
        }

        qCDebug(BLUEDEVIL_KDED_LOG) << "No PIN introduced";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[request](const QString &result) {
        if (!result.isEmpty()) {
            qCDebug(BLUEDAEMON) << "Introducing PIN...";
            request.accept(result);
            return;
        }

        qCDebug(BLUEDAEMON) << "No PIN introduced";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[device, request](RequestAuthorization::Result result) {
        processAuthorizationRequest(device, request, result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[w]() {
        w->startTransfer();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool exists) {
            if (!exists) {
                m_ui->dunButton->show();
                updateActions();
            }
        }
```

#### AUTO 


```{c}
const auto config = KSharedConfig::openConfig(QStringLiteral("bluedevilglobalrc"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](QDBusPendingCallWatcher *watcher) {
            const QDBusPendingReply<QMapDeviceInfo> &reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                menu->menuAction()->setVisible(false);
                return;
            }

            const QMapDeviceInfo &devices = m_kded->allDevices().value();
            Q_FOREACH (const DeviceInfo &device, devices) {
                if (device.value(QStringLiteral("UUIDs")).contains(BluezQt::Services::ObexObjectPush)) {
                    const QIcon &icon = QIcon::fromTheme(device[QStringLiteral("icon")], QIcon::fromTheme(QStringLiteral("preferences-system-bluetooth")));
                    QAction *action = new QAction(icon, device.value(QStringLiteral("name")), this);
                    connect(action, &QAction::triggered, this, &SendFileItemAction::deviceTriggered);
                    action->setData(device.value(QStringLiteral("UBI")));
                    menu->insertAction(nullptr, action);
                }
            }

            QAction *otherAction = new QAction(i18nc("Other Bluetooth device", "Other..."), this);
            connect(otherAction, &QAction::triggered, this, &SendFileItemAction::otherTriggered);

            menu->addSeparator();
            menu->addAction(otherAction);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[call, func]() {
        QDBusPendingReply<bool> reply = *call;
        func(!reply.isError() && reply.value());
    }
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(QStringLiteral("bluedevilglobalrc"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            emitResult();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ request](const QString &result) {
        bool ok;
        quint32 passkey = result.toInt(&ok);
        if (ok) {
            qCDebug(BLUEDAEMON) << "Introducing PassKey...";
            request.accept(passkey);
            return;
        }

        qCDebug(BLUEDAEMON) << "No PassKey introduced";
        request.reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[request](const QString &result) {
        bool ok;
        quint32 passkey = result.toInt(&ok);
        if (ok) {
            qCDebug(BLUEDAEMON) << "Introducing PassKey...";
            request.accept(passkey);
            return;
        }

        qCDebug(BLUEDAEMON) << "No PassKey introduced";
        request.reject();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uuid : uuids) {
        if (m_supportedServices.contains(uuid)) {
            retValue << m_supportedServices[uuid];
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Service &service : services) {
        KIO::UDSEntry entry;
        entry.fastInsert(KIO::UDSEntry::UDS_NAME, service.uuid);
        entry.fastInsert(KIO::UDSEntry::UDS_DISPLAY_NAME, service.name);
        entry.fastInsert(KIO::UDSEntry::UDS_ICON_NAME, service.icon);
        entry.fastInsert(KIO::UDSEntry::UDS_ACCESS, S_IRUSR | S_IRGRP | S_IROTH);

        // If it is browse files, act as a folder
        if (service.uuid == BluezQt::Services::ObexFileTransfer) {
            QUrl obexUrl;
            obexUrl.setScheme(QStringLiteral("obexftp"));
            obexUrl.setHost(m_currentHostname.replace(QLatin1Char(':'), QLatin1Char('-')).toUpper());
            entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFDIR);
            entry.fastInsert(KIO::UDSEntry::UDS_URL, obexUrl.toString());
        } else {
            entry.fastInsert(KIO::UDSEntry::UDS_FILE_TYPE, S_IFREG);
        }

        if (service.mimetype.isEmpty()) {
            entry.fastInsert(KIO::UDSEntry::UDS_MIME_TYPE, QStringLiteral("inode/vnd.kde.bluedevil.service"));
        } else {
            entry.fastInsert(KIO::UDSEntry::UDS_MIME_TYPE, service.mimetype);
        }

        listEntry(entry);
        processedSize(i++);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            Q_EMIT errorOccured(job->errorString());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](QDBusPendingCallWatcher *watcher) {
        const QDBusPendingReply<bool> &reply = *watcher;
        watcher->deleteLater();
        if (reply.isError() || !reply.value()) {
            menu->menuAction()->setVisible(false);
            return;
        }

        watcher = new QDBusPendingCallWatcher(m_kded->allDevices());
        connect(watcher, &QDBusPendingCallWatcher::finished, this, [this, menu](QDBusPendingCallWatcher *watcher) {
            const QDBusPendingReply<QMapDeviceInfo> &reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                menu->menuAction()->setVisible(false);
                return;
            }

            const QMapDeviceInfo &devices = m_kded->allDevices().value();
            Q_FOREACH (const DeviceInfo &device, devices) {
                if (device.value(QStringLiteral("UUIDs")).contains(BluezQt::Services::ObexObjectPush)) {
                    const QIcon &icon = QIcon::fromTheme(device[QStringLiteral("icon")], QIcon::fromTheme(QStringLiteral("preferences-system-bluetooth")));
                    QAction *action = new QAction(icon, device.value(QStringLiteral("name")), this);
                    connect(action, &QAction::triggered, this, &SendFileItemAction::deviceTriggered);
                    action->setData(device.value(QStringLiteral("UBI")));
                    menu->insertAction(nullptr, action);
                }
            }

            QAction *otherAction = new QAction(i18nc("Other Bluetooth device", "Other..."), this);
            connect(otherAction, &QAction::triggered, this, &SendFileItemAction::otherTriggered);

            menu->addSeparator();
            menu->addAction(otherAction);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry &entry : list) {
        listEntry(entry);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int id) {
        if (id == Success) {
            done(QDialog::Accepted);
        }
    // Sending notification in SuccessPage is asynchronous, so this needs to be queued.
    }
```

#### LAMBDA EXPRESSION 


```{c}
[request](const QString &result) {
        bool ok;
        quint32 passkey = result.toInt(&ok);
        if (ok) {
            qCDebug(BLUEDEVIL_KDED_LOG) << "Introducing PassKey...";
            request.accept(passkey);
            return;
        }

        qCDebug(BLUEDEVIL_KDED_LOG) << "No PassKey introduced";
        request.reject();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &addr : connectedDevices) {
        BluezQt::DevicePtr device = m_manager->deviceForAddress(addr);
        if (device) {
            device->connectToDevice();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_ui->connectButton->setEnabled(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool state) {
        Q_EMIT changed(state);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        emitResult();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](QDBusPendingCallWatcher *watcher) {
        const QDBusPendingReply<bool> &reply = *watcher;
        watcher->deleteLater();
        if (reply.isError() || !reply.value()) {
            menu->menuAction()->setVisible(false);
            return;
        }

        watcher = new QDBusPendingCallWatcher(m_kded->allDevices());
        connect(watcher, &QDBusPendingCallWatcher::finished, this, [this, menu](QDBusPendingCallWatcher *watcher) {
            const QDBusPendingReply<QMapDeviceInfo> &reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                menu->menuAction()->setVisible(false);
                return;
            }

            const QMapDeviceInfo &devices = m_kded->allDevices().value();
            Q_FOREACH (const DeviceInfo &device, devices) {
                if (device.value(QStringLiteral("UUIDs")).contains(BluezQt::Services::ObexObjectPush)) {
                    QAction *action = new QAction(QIcon::fromTheme(device[QStringLiteral("icon")]), device.value(QStringLiteral("name")), this);
                    connect(action, &QAction::triggered, this, &SendFileItemAction::deviceTriggered);
                    action->setData(device.value(QStringLiteral("UBI")));
                    menu->insertAction(0, action);
                }
            }

            QAction *otherAction = new QAction(i18nc("Other Bluetooth device", "Other..."), this);
            connect(otherAction, &QAction::triggered, this, &SendFileItemAction::otherTriggered);

            menu->addSeparator();
            menu->addAction(otherAction);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu](QDBusPendingCallWatcher *watcher) {
            const QDBusPendingReply<QMapDeviceInfo> &reply = *watcher;
            watcher->deleteLater();
            if (reply.isError()) {
                menu->menuAction()->setVisible(false);
                return;
            }

            const QMapDeviceInfo &devices = m_kded->allDevices().value();
            Q_FOREACH (const DeviceInfo &device, devices) {
                if (device.value(QStringLiteral("UUIDs")).contains(BluezQt::Services::ObexObjectPush)) {
                    QAction *action = new QAction(QIcon::fromTheme(device[QStringLiteral("icon")]), device.value(QStringLiteral("name")), this);
                    connect(action, &QAction::triggered, this, &SendFileItemAction::deviceTriggered);
                    action->setData(device.value(QStringLiteral("UBI")));
                    menu->insertAction(0, action);
                }
            }

            QAction *otherAction = new QAction(i18nc("Other Bluetooth device", "Other..."), this);
            connect(otherAction, &QAction::triggered, this, &SendFileItemAction::otherTriggered);

            menu->addSeparator();
            menu->addAction(otherAction);
        }
```

