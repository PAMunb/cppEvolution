#### AUTO 


```{c}
const auto themes = provider->themes();
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : qAsConst(m_bornBalls)) {
	ball->setColor(ball->color(), true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : items) {
        ball = qgraphicsitem_cast<BallItem*>(item);
        if(ball)
            balls.append(ball);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : std::as_const(m_bornBalls)) {
        ball->setSpriteKey( KLinesRenderer::animationFrameId( KLinesRenderer::BornAnim,
                                                                 ball->color(), frame) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* item : qAsConst(m_itemsToDelete)) {
            removeItem(item);
            delete item;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldPos& pos : qAsConst(positionsToDelete)) {
        m_itemsToDelete.append(m_field[pos.x][pos.y]);
        m_field[pos.x][pos.y] = nullptr;
        m_numFreeCells++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme* theme : themes) {
        if (theme->customData(QStringLiteral("Default")) == QLatin1String("true"))
        {
            provider->setDefaultTheme(theme);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* item : std::as_const(m_itemsToDelete)) {
            removeItem(item);
            delete item;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { mselector->showAsDialog(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldPos &pos : std::as_const(adjacentSquares)) {
            if( m_scene->ballAt(pos) != nullptr ) // skip non-walkable cells
                continue;

            // skip if closed list contains this square
            if(indexOfNodeWithPos(pos, closedList) != -1)
                continue;

            // search for node with position 'pos' in openList
            int idx = indexOfNodeWithPos(pos, openList);
            if(idx == -1) // not found
            {
                PathNode *node = new PathNode( pos );
                node->parent = curNode;
                node->G = curNode->G + 10;
                // h is manhattanLength from node to target square
                node->H = sqrt( pow( (to.x - pos.x)*10, 2. ) + pow( (to.y - pos.y)*10, 2. ) );
                node->F = node->G+node->H;
                openList.append( node );
            }
            else
            {
                PathNode *node = openList.at(idx);
                // check if this path to square is better
                if( curNode->G + 10 < node->G )
                {
                    // yup, it's better, reparent and recalculate G,F
                    node->parent = curNode;
                    node->G = curNode->G + 10;
                    node->F = node->G + node->H;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : std::as_const(m_bornBalls)) {
	ball->setColor(ball->color(), true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : std::as_const(m_bornBalls)) {
        ball->setRenderSize(KLinesRenderer::cellExtent());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : itemlist) {
        BallItem* ball = qgraphicsitem_cast<BallItem*>(item);
        if( ball )
        {
            removeItem(item);
            delete item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldPos& pos : std::as_const(positionsToDelete)) {
        m_itemsToDelete.append(m_field[pos.x][pos.y]);
        m_field[pos.x][pos.y] = nullptr;
        m_numFreeCells++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : qAsConst(m_bornBalls)) {
        ball->setSpriteKey( KLinesRenderer::animationFrameId( KLinesRenderer::BornAnim,
                                                                 ball->color(), frame) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : std::as_const(m_removedBalls)) {
	ball->setSpriteKey(KLinesRenderer::animationFrameId( KLinesRenderer::DieAnim,
                                                                 ball->color(), frame) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : qAsConst(m_bornBalls)) {
        ball->setRenderSize(KLinesRenderer::cellExtent());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (BallItem* ball : qAsConst(m_removedBalls)) {
	ball->setSpriteKey(KLinesRenderer::animationFrameId( KLinesRenderer::DieAnim,
                                                                 ball->color(), frame) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldPos &pos : qAsConst(adjacentSquares)) {
            if( m_scene->ballAt(pos) != nullptr ) // skip non-walkable cells
                continue;

            // skip if closed list contains this square
            if(indexOfNodeWithPos(pos, closedList) != -1)
                continue;

            // search for node with position 'pos' in openList
            int idx = indexOfNodeWithPos(pos, openList);
            if(idx == -1) // not found
            {
                PathNode *node = new PathNode( pos );
                node->parent = curNode;
                node->G = curNode->G + 10;
                // h is manhattanLength from node to target square
                node->H = sqrt( pow( (to.x - pos.x)*10, 2. ) + pow( (to.y - pos.y)*10, 2. ) );
                node->F = node->G+node->H;
                openList.append( node );
            }
            else
            {
                PathNode *node = openList.at(idx);
                // check if this path to square is better
                if( curNode->G + 10 < node->G )
                {
                    // yup, it's better, reparent and recalculate G,F
                    node->parent = curNode;
                    node->G = curNode->G + 10;
                    node->F = node->G + node->H;
                }
            }
        }
```

