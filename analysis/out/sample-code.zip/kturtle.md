#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang_code : dictionaries)
		map.insert(codeToFullName(lang_code), lang_code);
```

#### AUTO 


```{c}
const auto coordsToRectsList{coordsToRects(currentWord)};
```

#### AUTO 


```{c}
const auto rootItemChildren = rootItem->takeChildren();
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : rootItemChildren) {
		treeView->addTopLevelItem(item);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : coordsToRectsLst)
                    painter.fillRect(rect, QBrush(ERROR_HIGHLIGHT_COLOR));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : coordsToRectsList)
                    painter.fillRect(rect, QBrush(WORD_HIGHLIGHT_COLOR));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QList<KNSCore::Entry> &changedEntries) {
		if (!changedEntries.isEmpty()) {
			updateExamplesMenu();
		}
	}
```

#### AUTO 


```{c}
const auto str{rootNode->toString().split(QLatin1Char('\n'), Qt::SkipEmptyParts)};
```

#### AUTO 


```{c}
const auto exampleNames{Translator::instance()->exampleNames()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang_code : std::as_const(map)) {
		a = new QAction(codeToFullName(lang_code), actionCollection());
		a->setData(lang_code);
		a->setStatusTip(i18n("Switch to the %1 dictionary", codeToFullName(lang_code)));
		a->setCheckable(true);
		if (lang_code == currentLanguageCode) {
			a->setChecked(true);
		}
		//languageMenu->addAction(a);
		languageGroup->addAction(a);
		languageList.append(a);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &exampleName : exampleNames) {
		newExample = new QAction (exampleName, this);
		newExample->setData(exampleName);
		exampleGroup->addAction (newExample);

		connect(newExample, &QAction::triggered, this, &MainWindow::openExample);
		exampleList.append (newExample);
	}
```

#### AUTO 


```{c}
const auto coordsToRectsLst{coordsToRects(currentError)};
```

#### RANGE FOR STATEMENT 


```{c}
for (const ErrorMessage &error : *errorList) {
		int col = 0;
		QStringList itemTexts;
        itemTexts << QString::number(error.token().startRow()) << error.text() << QString::number(error.code());
        for (const QString &itemText : std::as_const(itemTexts)) {
			errorTable->setItem(row, col, new QTableWidgetItem(itemText));
			col++;
		}
		row++;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (int token : tokenList) resultMap.insert(token, look2typeMap.keys(token));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : exampleDirs) {
		const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.turtle"), QDir::Files);
        for (const QString &fileName : fileNames) {
            allExamples.append(dir + QLatin1Char('/') + fileName);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : fileNames) {
            allExamples.append(dir + QLatin1Char('/') + fileName);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : list) {
		// delete all but the turtle (who lives on a separate layer with z-value 1)
		if ((item->zValue() != kTurtleZValue) && (item->zValue() != kCanvasFrameZValue))
			delete item;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : splitLst) std::cout << qPrintable(QStringLiteral("\"%1\"").arg(line)) << std::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& exampleFilename : std::as_const(allExamples)) {
		QFileInfo fileInfo(exampleFilename);
		newExample = new QAction (fileInfo.baseName(), this);
		newExample->setData(exampleFilename);
		exampleGroup->addAction (newExample);
		exampleList.append (newExample);
			
		connect(newExample, &QAction::triggered, this, &MainWindow::openDownloadedExample);
	}
```

#### AUTO 


```{c}
auto knsa = new KNSWidgets::Action(i18n("Get more examples..."), QStringLiteral("kturtle.knsrc"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int type : *types) {
		if(child->parent()->token()->type()==type)
			return child->parent();
		else if(child->parent()->token()->type()==Token::Root)
			return nullptr;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemText : std::as_const(itemTexts)) {
			errorTable->setItem(row, col, new QTableWidgetItem(itemText));
			col++;
		}
```

#### AUTO 


```{c}
const auto splitLst{result.split(QLatin1Char('\n'))};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : str) {
		qDebug() << prefix << qPrintable(line.trimmed());
	}
```

