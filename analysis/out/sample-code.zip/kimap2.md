#### LAMBDA EXPRESSION 


```{c}
[&]() {
        m_currentPayload = &m_message->responseCode;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d, guard](KIMAP2::Session::State newState, KIMAP2::Session::State) {
            qCDebug(KIMAP2_LOG) << "Session state changed" << newState;
            d->login();
            delete guard;
        }
```

#### AUTO 


```{c}
const auto list = stream->readParenthesizedList();
```

#### RANGE FOR STATEMENT 


```{c}
for (ImapSet::Id id : {1, 2, 3, 5, 6, 8, 9, 10, 15, 16, 19, 20, 21, 23}) {
                imapSet.add(id);
            }
```

#### AUTO 


```{c}
auto job = new ListJob(&session);
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : { 5, 8, 3, 1, 9, 2, 7, 4, 6 }) {
                imapSet.add(i);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const ImapInterval &lhs, const ImapInterval &rhs) {
                   return lhs.begin() < rhs.begin();
              }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *data, const int size) {
        if (!m_message) {
            //We just assume that we always get a string first
            m_message.reset(new Message);
            m_currentPayload = &m_message->content;
        }
        if (m_list) {
            *m_list << QByteArray(data, size);
        } else {
            *m_currentPayload << Message::Part(QByteArray(data, size));
        }
    }
```

#### AUTO 


```{c}
const auto readBytes = m_socket->read(buffer().data() + m_readPosition, amountToRead);
```

#### AUTO 


```{c}
const auto payloadSize = 32000;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        Q_ASSERT(m_literalData);
        string(m_literalData->constData(), m_literalData->size());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (m_list || m_listCounter != 0) {
            qWarning() << "List parsing in progress: " << m_listCounter;
            m_error = true;
        }
        if (m_literalSize || m_readingLiteral) {
            qWarning() << "Literal parsing in progress: " << m_literalSize;
            m_error = true;
        }
        Q_ASSERT(responseReceived);
        if (m_message) {
            responseReceived(*m_message);
            m_message.reset(nullptr);
        }
        m_currentPayload = nullptr;
    }
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto remainderSize = m_readPosition - offset;
```

#### AUTO 


```{c}
auto startPos = m_position;
```

#### AUTO 


```{c}
auto it = response.responseCode.cbegin(), end = response.responseCode.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char c) {
        if (c == '[') {
            m_currentPayload = &m_message->responseCode;
            return;
        }
        if (!m_list) {
            m_list = new QList<QByteArray>;
        }
    }
```

#### AUTO 


```{c}
auto searchJob = new SearchJob(&session);
```

#### LAMBDA EXPRESSION 


```{c}
[](const MailBoxDescriptor &descriptor, const QList<QByteArray> &flags) {
            qInfo() << "* " << descriptor.name
                    <<  "flags " << flags;
        }
```

#### AUTO 


```{c}
const auto readBytes = m_socket->read(m_literalData.data() + pos, amountToRead);
```

#### AUTO 


```{c}
auto next = std::next(it);
```

#### AUTO 


```{c}
const auto data = QString("* 11 FETCH (UID 123 BODY[HEADER] {%1}\r\n").arg(payloadSize).toLatin1() + payload + " FLAGS ())\r\n";
```

#### AUTO 


```{c}
auto job = new KIMAP2::MoveJob(&session);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const int size) {
        m_literalData.clear();
        m_literalData.reserve(size);
    }
```

#### AUTO 


```{c}
const auto amountToRead = qMin(m_socket->bytesAvailable(), m_literalSize);
```

#### AUTO 


```{c}
auto pos = m_literalData.size();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *data, const int size) {
        m_literalData.append(QByteArray::fromRawData(data, size));
    }
```

#### AUTO 


```{c}
auto it = d->intervals.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &gotResponse, &message](const Message &response) {
            gotResponse = true;
            printResponse(response);
            message = response;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Message &) {
            parser.parseStream();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char c) {
        if (c == ']') {
            m_currentPayload = &m_message->content;
            return;
        }
        if (m_listCounter == 0) {
            Q_ASSERT(m_currentPayload);
            Q_ASSERT(m_list);
            *m_currentPayload << Message::Part(*m_list);
            delete m_list;
            m_list = nullptr;
        }
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::MoveJob(&session);
```

#### LAMBDA EXPRESSION 


```{c}
[&result, this, startPos]() {
        result = mid(startPos, m_position - startPos - 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Message &message) {
        responseReceived(message);
    }
```

#### AUTO 


```{c}
auto pos = m_literalData->size();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractSocket::SocketState state) {
        qCDebug(KIMAP2_LOG) << "Socket state changed: " << state;
        //The disconnected signal will not fire if we fail to lookup the host, but this will.
        if (state == QAbstractSocket::UnconnectedState) {
            d->socketDisconnected();
        }
        if (state == QAbstractSocket::HostLookupState) {
            d->hostLookupInProgress = true;
        } else {
            d->hostLookupInProgress = false;
        }
    }
```

#### AUTO 


```{c}
const auto data = m_socket->readAll();
```

#### AUTO 


```{c}
auto job = new FetchJob(&session);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        m_currentPayload = &m_message->content;
    }
```

#### AUTO 


```{c}
const auto string = stream->readString();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const int size) {
        m_literalData->clear();
        m_literalData->reserve(size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : response.content) {
                if (c.type() == Message::Part::List) {
                    qDebug() << c.toList();
                } else {
                    qDebug() << c.toString();
                }
            }
```

#### AUTO 


```{c}
const auto &c
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractSocket::SocketState state) {
        qCDebug(KIMAP2_LOG) << "Socket state changed: " << state;
        //The disconnected signal will not fire if we fail to lookup the host, but this will.
        if (state == QAbstractSocket::UnconnectedState) {
            d->socketDisconnected();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[session](const QList<QSslError> &errors) {
            qWarning() << "Got ssl error: " << errors;
            session->ignoreErrors(errors);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (m_listCounter <= 0) {
            qWarning() << "Brackets are off";
            m_error = true;
            return;
        }
        m_listCounter--;
        if (m_listCounter == 0) {
            Q_ASSERT(m_currentPayload);
            Q_ASSERT(m_list);
            *m_currentPayload << Message::Part(*m_list);
            delete m_list;
            m_list = nullptr;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KIMAP2::FetchJob::Result &result) {
            qInfo() << "* " << result.sequenceNumber
                    << "uid " << result.uid
                    <<  "flags " << result.flags;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const char *data, const int size) {
        Q_ASSERT(m_literalData);
        m_literalData->append(QByteArray::fromRawData(data, size));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KIMAP2::FetchJob::Result &result) {
            qInfo() << "* " << result.sequenceNumber
                    << "uid " << result.uid
                    <<  "size " << result.size
                    <<  "message size " << result.message->encodedContent().size();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&session](const QList<QSslError> &errors) {
        qWarning() << "Got ssl error: " << errors;
        session.ignoreErrors(errors);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : response.responseCode) {
                if (c.type() == Message::Part::List) {
                    qDebug() << c.toList();
                } else {
                    qDebug() << c.toString();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Term &t : subterms) {
                d->command += t.serialize() + ' ';
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        string(m_literalData.constData(), m_literalData.size());
    }
```

#### AUTO 


```{c}
const auto begin = vals[i];
```

#### AUTO 


```{c}
const auto readBytes = m_socket->read(m_literalData->data() + pos, amountToRead);
```

#### AUTO 


```{c}
const auto endPos = m_position;
```

#### AUTO 


```{c}
auto optimizedSet = set;
```

#### AUTO 


```{c}
const auto amountToRead = qMin(m_socket->bytesAvailable(), qint64(m_bufferSize - m_readPosition));
```

#### AUTO 


```{c}
auto guard = new QObject(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        m_listCounter++;
        if (m_listCounter > 1) {
            //Parse sublists as string
            setState(SublistString);
            m_stringStartPos = m_position;
        } else {
            if (!m_list) {
                m_list = new QList<QByteArray>;
            }
        }
    }
```

