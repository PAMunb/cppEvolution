#### AUTO 


```{c}
auto transactionW = new PkTransactionWidget(this);
```

#### AUTO 


```{c}
auto proxy = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : qAsConst(m_mimes)) {
                if (mime.name() == mimeType) {
                    ret = true;
/*                    kDebug() << "Found Supported Mime" << mimeType << mime->iconName();*/
                    item = new QStandardItem(fileInfo.fileName());
                    item->setData(path);
                    item->setToolTip(path);
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                          KIconLoader::Desktop));
                    break;
                }
            }
```

#### AUTO 


```{c}
auto effect = new QGraphicsOpacityEffect(m_screenshotL);
```

#### AUTO 


```{c}
auto notify = new KNotification("TransactionError", 0, KNotification::Persistent);
```

#### AUTO 


```{c}
auto drawer = new CategoryDrawer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pid : updates) {
             _updates += QString::fromUtf8("\xE2\x80\xA2 ") + Transaction::packageName(pid) + " - " + Transaction::packageVersion(pid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tid : tids) {
            watchTransaction(QDBusObjectPath(tid), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
        if (!ret.isEmpty()) {
            ret += QLatin1String("<br>");
        }
        ret += QString::fromUtf8(" \xE2\x80\xA2 <a href=\"") % url % QLatin1String("\">") % url % QLatin1String("</a>");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : listBattery) {
        const Solid::Battery *battery = device.as<Solid::Battery>();
        if (battery && battery->type() == Solid::Battery::PrimaryBattery) {
            notFound = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto notify = new KNotification("DistroUpgradeError");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath &path : paths) {
            tids << path.path();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pid : updates) {
             _updates += QString::fromUtf8("\xE2\x80\xA2 ") + Transaction::packageName(pid) + QLatin1String(" - ") + Transaction::packageVersion(pid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &p : qAsConst(m_packages)) {
        pkgs << Transaction::packageName(p.packageID);
    }
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("DistroUpgradeAvailable"), 0, KNotification::Persistent);
```

#### AUTO 


```{c}
auto effect = new QGraphicsOpacityEffect(descriptionKTB);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatcher &parser : m_child) {
            if (!(ret = parser.match(categories))) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto sourceFalse = new QAction(i18n("Only non-sourcecode"), sourceGroup);
```

#### AUTO 


```{c}
auto anim2 = new QPropertyAnimation(this, "minimumSize", this);
```

#### AUTO 


```{c}
auto notify = new KNotification("DistroUpgradeAvailable", 0, KNotification::Persistent);
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &font : resources) {
        // TODO never return in here
        // TODO add name field from /usr/share/xml/iso-codes/iso_639.xml into model
        if (!font.startsWith(QLatin1String(":lang="))) {
            errors << QString(QLatin1String("not recognised prefix: '%1'")).arg(font);
            qCWarning(APPER_SESSION) << QString(QLatin1String("not recognised prefix: '%1'")).arg(font);
            continue;
        }
        int size = font.size();
        if (size < 7 || size > 20) {
            errors << QString(QLatin1String("lang tag malformed: '%1'")).arg(font);
            qCWarning(APPER_SESSION) << QString(QLatin1String("lang tag malformed: '%1'")).arg(font);
            continue;
        }

        m_resources << font;
        iso639 << font.mid(6);
    }
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Upgrade"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &codec : resources) {
        if (codec.contains("|gstreamer0.10(decoder")) {
            decoder = true;
        } else if (codec.contains("|gstreamer0.10(encoder")) {
            encoder = true;
        }

        auto item = new QStandardItem(codec.section('|', 0, 0));
        item->setIcon(QIcon::fromTheme("x-kde-nsplugin-generated").pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);

        m_resources << codec.section('|', 1, -1);
    }
```

#### AUTO 


```{c}
auto guiFalse = new QAction(i18n("Only text"), guiGroup);
```

#### AUTO 


```{c}
auto freeNone = new QAction(i18n("No filter"), freeGroup);
```

#### AUTO 


```{c}
auto dateI    = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### AUTO 


```{c}
auto detailsI = new QStandardItem;
```

#### AUTO 


```{c}
auto developmentGroup = new QActionGroup(menuDevelopment);
```

#### AUTO 


```{c}
auto userI    = new QStandardItem;
```

#### AUTO 


```{c}
auto tempFile = new QTemporaryFile;
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatcher &parser : m_child) {
            if ((ret = parser.match(categories))) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto browser = new QTextBrowser(this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(details);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : mimes) {
            QMimeType mime = db.mimeTypeForName(mimeName);
            if (mime.isValid()) {
                auto item = new QStandardItem(mimeName);
                item->setData(mimeName);
                item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                      KIconLoader::Desktop));
                appendRow(item);
            }
        }
```

#### AUTO 


```{c}
auto menuCollections = new QMenu(i18n("Collections"), this);
```

#### AUTO 


```{c}
auto developmentNone = new QAction(i18n("No filter"), developmentGroup);
```

#### AUTO 


```{c}
auto watcher = new QDBusServiceWatcher(QLatin1String("org.freedesktop.PackageKit"),
                                           QDBusConnection::systemBus(),
                                           QDBusServiceWatcher::WatchForRegistration,
                                           this);
```

#### AUTO 


```{c}
auto trans = qobject_cast<Transaction*>(sender());
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("TransactionError"), 0, KNotification::Persistent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            QFile catalog(file);
            if (catalog.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&catalog);
                while (!in.atEnd()) {
                    if (rx.indexIn(in.readLine()) != -1) {
                        if (rx.cap(1).compare(QLatin1String("InstallPackages"), Qt::CaseInsensitive) == 0) {
                            m_installPackages.append(rx.cap(2).split(QLatin1Char(';')));
                        } else if (rx.cap(1).compare(QLatin1String("InstallProvides"), Qt::CaseInsensitive) == 0) {
                            m_installProvides.append(rx.cap(2).split(QLatin1Char(';')));
                        } else if (rx.cap(1).compare(QLatin1String("InstallFiles"), Qt::CaseInsensitive) == 0) {
                            m_installFiles.append(rx.cap(2).split(QLatin1Char(';')));
                        }
                    }
                }
            } else {
                filesFailedToOpen << file;
            }
        }
```

#### AUTO 


```{c}
auto native = new QAction(i18n("Only Native Packages"), this);
```

#### AUTO 


```{c}
auto view = new ScreenShotViewer(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageID : qAsConst(d->packages)) {
                d->simulateModel->removePackage(packageID);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, eula] () {
        qCDebug(APPER_LIB) << "Accepting EULA" << eula->id();
        setupTransaction(Daemon::acceptEula(eula->id()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
        if (!ret.isEmpty()) {
            ret += "<br/>";
        }
        ret += QString::fromUtf8(" \xE2\x80\xA2 <a href=\"") % url % QLatin1String("\">") % url % QLatin1String("</a>");
    }
```

#### AUTO 


```{c}
auto model = new QStandardItemModel(this);
```

#### AUTO 


```{c}
auto supportedTrue = new QAction(i18n("Only supported software"), supportedGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
        list << package.packageID;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, repoSig] () {
        qCDebug(APPER_LIB) << "Installing Signature" << repoSig->keyID();
        setupTransaction(Daemon::installSignature(repoSig->sigType(), repoSig->keyID(), repoSig->packageID()));
    }
```

#### AUTO 


```{c}
const auto proxy = qobject_cast<const QSortFilterProxyModel*>(index.model());
```

#### AUTO 


```{c}
auto transaction = qobject_cast<PackageKit::Transaction*>(sender());
```

#### AUTO 


```{c}
auto it = m_checkedPackages.find(packageID);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
        if (!containsChecked(package.packageID)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto anim1 = new QPropertyAnimation(this, "maximumSize", this);
```

#### AUTO 


```{c}
auto transaction = qobject_cast<PkTransaction*>(sender());
```

#### AUTO 


```{c}
auto task = new PkInstallPackageFiles(xid, files, interaction, message());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : niceNames) {
        auto item = new QStandardItem(name);
        item->setIcon(QIcon::fromTheme(QLatin1String("fonts-package")).pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);
    }
```

#### AUTO 


```{c}
auto menuInstalled = new QMenu(i18n("Installed"), this);
```

#### AUTO 


```{c}
auto widget = qobject_cast<PkTransactionWidget *>(d->parentWindow);
```

#### AUTO 


```{c}
auto tempFile = new QTemporaryFile(QDir::tempPath() + QLatin1String("/apper.XXXXXX.png"));
```

#### AUTO 


```{c}
auto transaction = qobject_cast<PkTransaction *>(sender());
```

#### AUTO 


```{c}
auto helper = new BackendDetails;
```

#### AUTO 


```{c}
auto installedTrue = new QAction(i18n("Only installed"), installedGroup);
```

#### AUTO 


```{c}
auto newest = new QAction(i18n("Only Newest Packages"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
            checkPackage(package, false);
        }
```

#### AUTO 


```{c}
auto developmentFalse = new QAction(i18n("Only end user files"), developmentGroup);
```

#### AUTO 


```{c}
auto changedProxy = new KCategorizedSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto transaction = qobject_cast<PkTransaction*>(ui->stackedWidget->currentWidget());
```

#### AUTO 


```{c}
auto task = new PkSearchFile(file_name, interaction, message());
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### AUTO 


```{c}
auto collectionGroup = new QActionGroup(menuCollections);
```

#### AUTO 


```{c}
auto watcher = new QDBusServiceWatcher(QLatin1String("org.kde.ApperUpdaterIcon"),
                                           QDBusConnection::sessionBus(),
                                           QDBusServiceWatcher::WatchForOwnerChange,
                                           this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktop : m_files) {
        // we use KService to parse the .desktop file because findByDestopPath
        // might fail because the Sycoca database is not up to date yet.
        KService service(desktop);
        if (service.isApplication() &&
           !service.noDisplay() &&
           !service.exec().isEmpty())
        {
            QString name = service.genericName().isEmpty() ? service.name()
                                                           : service.name() + " - " + service.genericName();
            item = new QStandardItem(name);
            item->setIcon(QIcon::fromTheme(service.icon()));
            item->setData(service.entryPath(), Qt::UserRole);
            item->setFlags(Qt::ItemIsEnabled);
            model->appendRow(item);
        }
    }
```

#### AUTO 


```{c}
auto task = new PkInstallProvideFiles(xid, files, interaction, message());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pid : obsoletes) {
             _obsoletes += QString::fromUtf8("\xE2\x80\xA2 ") + Transaction::packageName(pid) + QLatin1String(" - ") + Transaction::packageVersion(pid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &font : iso639) {
        QString queryTxt;
        queryTxt = QString("declare variable $path external;"
                           "doc($path)/iso_639_entries/"
                           "iso_639_entry[@iso_639_2B_code=\"%1\" or "
                                         "@iso_639_2T_code=\"%1\" or "
                                         "@iso_639_1_code=\"%1\"]/string(@name)").arg(font);
        query.setQuery(queryTxt);
        QStringList result;
        query.evaluateTo(&result);
        niceNames.append(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &deviceid : resources) {
        QString mfg, mdl;
        const QStringList fields = deviceid.split(QLatin1Char(';'));
        for (const QString &field : fields) {
            const QString keyvalue = field.trimmed();
            if (keyvalue.startsWith(QLatin1String("MFG:"))) {
                mfg = keyvalue.mid(4);
            } else if (keyvalue.startsWith(QLatin1String("MDL:"))) {
                mdl = keyvalue.mid(4);
            }
        }

        if (!mfg.isEmpty() && !mdl.isEmpty()) {
            QString prov;
            QTextStream out(&prov);
            out << mfg.toLower().replace(QLatin1Char(' '), QLatin1Char('_')) << QLatin1Char(';')
                << mdl.toLower().replace(QLatin1Char(' '), QLatin1Char('_')) << QLatin1Char(';');
            search << prov;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction * const action : actions) {
        if (action->isChecked()) {
            if (m_filtersAction.contains(action)) {
                filters |= m_filtersAction[action];
                filterSet = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto transaction = new PkTransaction(this);
```

#### AUTO 


```{c}
auto roleI    = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[this, transaction] () {
        transactionChanged(transaction);
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(codec.section(QLatin1Char('|'), 0, 0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &font : resources) {
        // TODO never return in here
        // TODO add name field from /usr/share/xml/iso-codes/iso_639.xml into model
        if (!font.startsWith(QLatin1String(":lang="))) {
            errors << QString("not recognised prefix: '%1'").arg(font);
            qCWarning(APPER_SESSION) << QString("not recognised prefix: '%1'").arg(font);
            continue;
        }
        int size = font.size();
        if (size < 7 || size > 20) {
            errors << QString("lang tag malformed: '%1'").arg(font);
            qCWarning(APPER_SESSION) << QString("lang tag malformed: '%1'").arg(font);
            continue;
        }

        m_resources << font;
        iso639 << font.mid(6);
    }
```

#### AUTO 


```{c}
auto task = new PkInstallCatalogs(xid, files, interaction, message());
```

#### AUTO 


```{c}
auto basename = new QAction(i18n("Hide Subpackages"), this);
```

#### AUTO 


```{c}
auto guiTrue = new QAction(i18n("Only graphical"), guiGroup);
```

#### AUTO 


```{c}
auto menuFree = new QMenu(i18nc("Filter for free packages", "Free"), this);
```

#### AUTO 


```{c}
auto pkgInfo = index.data(PackageModel::InfoRole).value<Transaction::Info>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            urls << QUrl(file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageId : updates) {
        const QString packageName = Transaction::packageName(packageId);
        if (text.length() + packageName.length() > 150) {
            text.append(QLatin1String(" ..."));
            break;
        } else if (!text.isNull()) {
            text.append(QLatin1String(", "));
        }
        text.append(packageName);
    }
```

#### AUTO 


```{c}
auto model = new FilesModel(files, QStringList(), this);
```

#### AUTO 


```{c}
auto anim = new QPropertyAnimation(effect, "opacity");
```

#### AUTO 


```{c}
auto eula = qobject_cast<LicenseAgreement*>(sender());
```

#### AUTO 


```{c}
auto proxy = qobject_cast<ApplicationSortFilterModel*>(ui->packageView->model());
```

#### AUTO 


```{c}
auto task = new PkIsInstalled(package_name, interaction, message());
```

#### AUTO 


```{c}
auto collectionFalse = new QAction(i18n("Exclude collections"), collectionGroup);
```

#### AUTO 


```{c}
auto task = new PkInstallPlasmaResources(xid, resources, interaction, message());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            QFile catalog(file);
            if (catalog.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&catalog);
                while (!in.atEnd()) {
                    if (rx.indexIn(in.readLine()) != -1) {
                        if (rx.cap(1).compare(QLatin1String("InstallPackages"), Qt::CaseInsensitive) == 0) {
                            m_installPackages.append(rx.cap(2).split(';'));
                        } else if (rx.cap(1).compare(QLatin1String("InstallProvides"), Qt::CaseInsensitive) == 0) {
                            m_installProvides.append(rx.cap(2).split(';'));
                        } else if (rx.cap(1).compare(QLatin1String("InstallFiles"), Qt::CaseInsensitive) == 0) {
                            m_installFiles.append(rx.cap(2).split(QLatin1Char(';')));
                        }
                    }
                }
            } else {
                filesFailedToOpen << file;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &p : qAsConst(m_packages)) {
        pkgs << p.pkgName;
    }
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("DistroUpgradeError"));
```

#### AUTO 


```{c}
auto task = new PkInstallPrinterDrivers(xid, resources, interaction, message());
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("RestartRequired"), 0, KNotification::Persistent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
        checkPackage(package, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktop : m_files) {
        // we use KService to parse the .desktop file because findByDestopPath
        // might fail because the Sycoca database is not up to date yet.
        KService service(desktop);
        if (service.isApplication() &&
           !service.noDisplay() &&
           !service.exec().isEmpty())
        {
            QString name = service.genericName().isEmpty() ? service.name()
                                                           : service.name() + QLatin1String(" - ") + service.genericName();
            item = new QStandardItem(name);
            item->setIcon(QIcon::fromTheme(service.icon()));
            item->setData(service.entryPath(), Qt::UserRole);
            item->setFlags(Qt::ItemIsEnabled);
            model->appendRow(item);
        }
    }
```

#### AUTO 


```{c}
auto freeFalse = new QAction(i18n("Only non-free software"), freeGroup);
```

#### AUTO 


```{c}
auto menuGui = new QMenu(i18n("Graphical"), this);
```

#### AUTO 


```{c}
auto watcher = qobject_cast<QDBusServiceWatcher*>(sender());
```

#### AUTO 


```{c}
auto introDialog = new IntroDialog(this);
```

#### AUTO 


```{c}
auto task = new PkInstallPackageNames(xid, packages, interaction, message());
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("ShowUpdates"), 0, KNotification::Persistent);
```

#### AUTO 


```{c}
auto stdItem = new QStandardItem(description);
```

#### AUTO 


```{c}
auto task = new PkInstallMimeTypes(xid, mime_types, interaction, message());
```

#### AUTO 


```{c}
auto info = new InfoWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : qAsConst(m_mimes)) {
                if (mime.name() == mimeType) {
                    ret = true;
                    qCDebug(APPER_SESSION) << "Found Supported Mime" << mimeType << mime.iconName();
                    item = new QStandardItem(fileInfo.fileName());
                    item->setData(path);
                    item->setToolTip(path);
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                          KIconLoader::Desktop));
                    break;
                }
            }
```

#### AUTO 


```{c}
auto developmentTrue = new QAction(i18n("Only development"), developmentGroup);
```

#### AUTO 


```{c}
auto transaction = qobject_cast<Transaction*>(sender());
```

#### AUTO 


```{c}
auto job = qobject_cast<TransactionJob*>(sender());
```

#### AUTO 


```{c}
auto supportedNone = new QAction(i18n("No filter"), supportedGroup);
```

#### AUTO 


```{c}
auto sourceNone = new QAction(i18n("No filter"), sourceGroup);
```

#### AUTO 


```{c}
auto repoSig = qobject_cast<RepoSig*>(sender());
```

#### AUTO 


```{c}
auto fJob = qobject_cast<KIO::FileCopyJob*>(job);
```

#### AUTO 


```{c}
auto installedFalse = new QAction(i18n("Only available"), installedGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &font : iso639) {
        QString queryTxt;
        queryTxt = QString(QLatin1String("declare variable $path external;"
                                         "doc($path)/iso_639_entries/"
                                         "iso_639_entry[@iso_639_2B_code=\"%1\" or "
                                         "@iso_639_2T_code=\"%1\" or "
                                         "@iso_639_1_code=\"%1\"]/string(@name)")).arg(font);
        query.setQuery(queryTxt);
        QStringList result;
        query.evaluateTo(&result);
        niceNames.append(result);
    }
```

#### AUTO 


```{c}
auto args = parser.positionalArguments();
```

#### AUTO 


```{c}
auto menuSupported = new QMenu(i18nc("Filter for supported packages", "Supported"), this);
```

#### AUTO 


```{c}
auto notify = new KNotification("DistroUpgradeFinished");
```

#### AUTO 


```{c}
auto button = new QToolButton(this);
```

#### AUTO 


```{c}
auto service = new KService(path);
```

#### AUTO 


```{c}
auto it = m_checkedPackages.begin();
```

#### AUTO 


```{c}
auto item = new QStandardItem(codec.section('|', 0, 0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : packages) {
        addPackage(package.info, package.packageID, package.summary, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &codec : resources) {
        if (codec.contains(QLatin1String("|gstreamer0.10(decoder"))) {
            decoder = true;
        } else if (codec.contains(QLatin1String("|gstreamer0.10(encoder"))) {
            encoder = true;
        }

        auto item = new QStandardItem(codec.section(QLatin1Char('|'), 0, 0));
        item->setIcon(QIcon::fromTheme(QLatin1String("x-kde-nsplugin-generated")).pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);

        m_resources << codec.section(QLatin1Char('|'), 1, -1);
    }
```

#### AUTO 


```{c}
auto supportedFalse = new QAction(i18n("Only non-supported software"), supportedGroup);
```

#### AUTO 


```{c}
auto installedGroup = new QActionGroup(menuInstalled);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &package : packages) {
        QStandardItem *item = new QStandardItem(package);
        item->setIcon(QIcon::fromTheme("package-x-generic").pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &packageId : updates) {
                if (!m_oldUpdateList.contains(packageId)) {
                    different = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto item = new QStandardItem(name);
```

#### AUTO 


```{c}
auto menuDevelopment = new QMenu(i18n("Development"), this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(prettyService);
```

#### AUTO 


```{c}
auto sourceGroup = new QActionGroup(menuSource);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        QString path = QUrl::fromPercentEncoding(url.path().toUtf8());
        if (files().contains(path)) {
            continue;
        }

        QFileInfo fileInfo(path);
        QStandardItem *item = 0;
        if (fileInfo.isFile()) {
            QMimeDatabase db;
            QMimeType mime = db.mimeTypeForFile(path, QMimeDatabase::MatchContent);
            qCDebug(APPER_SESSION) << url << mime.name();
            for (const QString &mimeType : qAsConst(m_mimes)) {
                if (mime.name() == mimeType) {
                    ret = true;
/*                    kDebug() << "Found Supported Mime" << mimeType << mime->iconName();*/
                    item = new QStandardItem(fileInfo.fileName());
                    item->setData(path);
                    item->setToolTip(path);
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                          KIconLoader::Desktop));
                    break;
                }
            }

            if (ret == false && m_mimes.isEmpty()) {
                if (mime.name() == "application/x-desktop") {
                    auto service = new KService(path);
                    item = new QStandardItem(service->name());
                    item->setData(true, Qt::UserRole);
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(service->icon(),
                                                                          KIconLoader::Desktop));
                } else {
                    item = new QStandardItem(fileInfo.fileName());
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                        KIconLoader::Desktop));
                }
                item->setData(path);
                item->setToolTip(path);
            } else if (ret == false && !m_mimes.isEmpty()) {
                item = new QStandardItem(fileInfo.fileName());
                item->setData(path);
                item->setToolTip(path);
                item->setEnabled(false);
                item->setIcon(KIconLoader::global()->loadIcon("dialog-cancel", KIconLoader::Desktop));
            }
        } else if (m_mimes.isEmpty()) {
            // It's not a file but we don't have a mime so it's ok
            item = new QStandardItem(fileInfo.fileName());
            item->setData(path);
            item->setToolTip(path);
            item->setIcon(KIconLoader::global()->loadIcon("unknown", KIconLoader::Desktop));
        }

        if (item) {
            appendRow(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
        if (package.info == info) {
            // Append to the list if the package matches the info value
            list << package.packageID;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatcher &parser : m_child) {
            if (!(ret = !parser.match(categories))) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : resources) {
        QString prettyService = service;
        if (service.startsWith(QLatin1String("dataengine-"))) {
            prettyService = i18n("%1 data engine", service.mid(11));
        } else if (service.startsWith(QLatin1String("scriptengine-"))) {
            prettyService = i18n("%1 script engine", service.mid(13));
        }

        auto item = new QStandardItem(prettyService);
        item->setIcon(QIcon::fromTheme("application-x-plasma").pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);

        m_resources << service;
    }
```

#### AUTO 


```{c}
auto notify = qobject_cast<KNotification*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
            if (package.packageID == packageID) {
                checkPackage(package);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        const QString path = QUrl::fromPercentEncoding(url.path().toLatin1());
        if (files().contains(path)) {
            continue;
        }

        QFileInfo fileInfo(path);
        QStandardItem *item = 0;
        if (fileInfo.isFile()) {
            QMimeDatabase db;
            QMimeType mime = db.mimeTypeForFile(path, QMimeDatabase::MatchContent);
            qCDebug(APPER_SESSION) << url << mime.name();
            for (const QString &mimeType : qAsConst(m_mimes)) {
                if (mime.name() == mimeType) {
                    ret = true;
                    qCDebug(APPER_SESSION) << "Found Supported Mime" << mimeType << mime.iconName();
                    item = new QStandardItem(fileInfo.fileName());
                    item->setData(path);
                    item->setToolTip(path);
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                          KIconLoader::Desktop));
                    break;
                }
            }

            if (ret == false && m_mimes.isEmpty()) {
                if (mime.name() == QLatin1String("application/x-desktop")) {
                    auto service = new KService(path);
                    item = new QStandardItem(service->name());
                    item->setData(true, Qt::UserRole);
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(service->icon(),
                                                                          KIconLoader::Desktop));
                } else {
                    item = new QStandardItem(fileInfo.fileName());
                    item->setIcon(KIconLoader::global()->loadMimeTypeIcon(mime.iconName(),
                                                                        KIconLoader::Desktop));
                }
                item->setData(path);
                item->setToolTip(path);
            } else if (ret == false && !m_mimes.isEmpty()) {
                item = new QStandardItem(fileInfo.fileName());
                item->setData(path);
                item->setToolTip(path);
                item->setEnabled(false);
                item->setIcon(KIconLoader::global()->loadIcon(QLatin1String("dialog-cancel"), KIconLoader::Desktop));
            }
        } else if (m_mimes.isEmpty()) {
            // It's not a file but we don't have a mime so it's ok
            item = new QStandardItem(fileInfo.fileName());
            item->setData(path);
            item->setToolTip(path);
            item->setIcon(KIconLoader::global()->loadIcon(QLatin1String("unknown"), KIconLoader::Desktop));
        }

        if (item) {
            appendRow(item);
        }
    }
```

#### AUTO 


```{c}
auto freeTrue = new QAction(i18n("Only free software"), freeGroup);
```

#### AUTO 


```{c}
auto repoSig = new RepoSig(packageID, repoName, keyUrl, keyUserid, keyId, keyFingerprint, keyTimestamp, type, d->parentWindow);
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("UpdatesComplete"));
```

#### AUTO 


```{c}
auto confWatch = new KDirWatch(this);
```

#### AUTO 


```{c}
auto task = new PkInstallGStreamerResources(xid, resources, interaction, message());
```

#### AUTO 


```{c}
auto notify = new KNotification("UpdatesComplete");
```

#### AUTO 


```{c}
auto job = new TransactionJob(transaction, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_packages)) {
        if (package.info == info) {
            ++ret;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : niceNames) {
        auto item = new QStandardItem(name);
        item->setIcon(QIcon::fromTheme("fonts-package").pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);
    }
```

#### AUTO 


```{c}
auto task = new PkRemovePackageByFiles(xid, files, interaction, message());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &deviceid : resources) {
        QString mfg, mdl;
        const QStringList fields = deviceid.split(';');
        for (const QString &field : fields) {
            const QString keyvalue = field.trimmed();
            if (keyvalue.startsWith(QLatin1String("MFG:"))) {
                mfg = keyvalue.mid(4);
            } else if (keyvalue.startsWith(QLatin1String("MDL:"))) {
                mdl = keyvalue.mid(4);
            }
        }

        if (!mfg.isEmpty() && !mdl.isEmpty()) {
            QString prov;
            QTextStream out(&prov);
            out << mfg.toLower().replace(' ', '_') << ';'
                << mdl.toLower().replace(' ', '_') << ';';
            search << prov;
        }
    }
```

#### AUTO 


```{c}
auto proxyModel = new ApplicationSortFilterModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &p : qAsConst(m_packages)) {
        pkgs << p.packageID;
    }
```

#### AUTO 


```{c}
auto installedNone = new QAction(i18n("No filter"), installedGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_checkedPackages)) {
        if (package.info != Transaction::InfoInstalled &&
                package.info != Transaction::InfoCollectionInstalled) {
            // append the packages are not installed
            list << package.packageID;
        }
    }
```

#### AUTO 


```{c}
auto notify = new KNotification("ShowUpdates", 0, KNotification::Persistent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &field : fields) {
            const QString keyvalue = field.trimmed();
            if (keyvalue.startsWith(QLatin1String("MFG:"))) {
                mfg = keyvalue.mid(4);
            } else if (keyvalue.startsWith(QLatin1String("MDL:"))) {
                mdl = keyvalue.mid(4);
            }
        }
```

#### AUTO 


```{c}
auto task = new PkInstallFontconfigResources(xid, resources, interaction, message());
```

#### AUTO 


```{c}
auto eula = new LicenseAgreement(eulaID, packageID, vendor, licenseAgreement, d->parentWindow);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_checkedPackages)) {
        size += package.size;
    }
```

#### AUTO 


```{c}
auto notify = new KNotification(QLatin1String("DistroUpgradeFinished"));
```

#### AUTO 


```{c}
auto supportedGroup = new QActionGroup(menuSupported);
```

#### AUTO 


```{c}
auto appI     = new QStandardItem;
```

#### AUTO 


```{c}
auto action = new QAction(i18n("Refresh Cache"), this);
```

#### AUTO 


```{c}
auto sourceTrue = new QAction(i18n("Only sourcecode"), sourceGroup);
```

#### AUTO 


```{c}
auto requires = qobject_cast<Requirements *>(sender());
```

#### AUTO 


```{c}
auto item = new QStandardItem(mimeName);
```

#### AUTO 


```{c}
auto proxyWatch = new KDirWatch(this);
```

#### AUTO 


```{c}
auto guiGroup = new QActionGroup(menuGui);
```

#### AUTO 


```{c}
auto guiNone = new QAction(i18n("No filter"), guiGroup);
```

#### AUTO 


```{c}
auto service = new KDBusService(KDBusService::Unique);
```

#### AUTO 


```{c}
auto transaction = new PkTransaction;
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &package : qAsConst(m_checkedPackages)) {
        if (package.info == Transaction::InfoInstalled ||
                package.info == Transaction::InfoCollectionInstalled) {
            // check what packages are installed and marked to be removed
            list << package.packageID;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : resources) {
        QString prettyService = service;
        if (service.startsWith(QLatin1String("dataengine-"))) {
            prettyService = i18n("%1 data engine", service.mid(11));
        } else if (service.startsWith(QLatin1String("scriptengine-"))) {
            prettyService = i18n("%1 script engine", service.mid(13));
        }

        auto item = new QStandardItem(prettyService);
        item->setIcon(QIcon::fromTheme(QLatin1String("application-x-plasma")).pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);

        m_resources << service;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
        const QStringList sections = line.split(QLatin1Char('\t'));
        if (sections.size() > 1) {
            switch (status) {
                case Transaction::StatusInstall:
                    if (sections.at(0) != QLatin1String("installing")) {
                        continue;
                    }
                    break;
                case Transaction::StatusRemove:
                    if (sections.at(0) != QLatin1String("removing")) {
                        continue;
                    }
                    break;
                case Transaction::StatusUpdate:
                    if (sections.at(0) != QLatin1String("updating")) {
                        continue;
                    }
                    break;
                default:
                    continue;
            }
            QStringList packageData = sections.at(1).split(QLatin1Char(';'));
            if (packageData.size()) {
                text << packageData.at(0);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &package : packages) {
        QStandardItem *item = new QStandardItem(package);
        item->setIcon(QIcon::fromTheme(QLatin1String("package-x-generic")).pixmap(32, 32));
        item->setFlags(Qt::ItemIsEnabled);
        model->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pid : obsoletes) {
             _obsoletes += QString::fromUtf8("\xE2\x80\xA2 ") + Transaction::packageName(pid) + " - " + Transaction::packageVersion(pid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const InternalPackage &iPackage : qAsConst(m_packages)) {
            if (iPackage.packageID == package.packageID) {
                notFound = false;
                break;
            }
        }
```

#### AUTO 


```{c}
auto mapper = new QSignalMapper(this);
```

#### AUTO 


```{c}
auto freeGroup = new QActionGroup(menuFree);
```

#### AUTO 


```{c}
auto notify = new KNotification("RestartRequired", 0, KNotification::Persistent);
```

#### AUTO 


```{c}
auto delegate = new ChangesDelegate(ui->packageView);
```

#### AUTO 


```{c}
auto menuSource = new QMenu(i18nc("Filter for source packages", "Source"), this);
```

