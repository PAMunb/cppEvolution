#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : d->remounts)
        {
          if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), option->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)) == 0)
          {
            insertShare = false;
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : encryptionLevelChoices) {
        encryptionLevel->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks)
  {
    for (QAction *a : actions)
    {
      if (a->data().toMap().value("text").toString() == b)
      {
        addAction(a);
        break;
      }
      else
      {
        continue;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : mountedSharesList())
      {
        if (mountedShare->url() == object->url())
        {
          shares << mountedShare;
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : qAsConst(d->tempWorkgroupList))
            {
                if (w->workgroupName() == workgroup->workgroupName())
                {
                    foundWorkgroup = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(discoveredShares)) {
        // Process only those shares that the user wants to see
        if (share->isHidden() && !Smb4KSettings::detectHiddenShares()) {
            continue;
        }

        if (share->isPrinter() && !Smb4KSettings::detectPrinterShares()) {
            continue;
        }

        // Add or update the shares
        if (!findShare(share->url(), share->workgroupName())) {
            addShare(share);
        } else {
            updateShare(share);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : Smb4KGlobal::hostsList())
  {
    d->hostObjects << new Smb4KNetworkObject(host.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &importedShare : d->importedShares)
      {
        // Check the mountpoint, since that one is unique. We will only use
        // Smb4KShare::path(), so that we do not run into trouble if a share 
        // is inaccessible.
        if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
        {
          found = true;
          break;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : qAsConst(d->options)) {
        if (Smb4KSettings::useProfiles() && options->profile() != Smb4KProfileManager::self()->activeProfile()) {
            continue;
        }

        if (options->hasOptions(withoutRemountOnce)) {
            optionsList << options;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : allMountActions) {
                if (action->data().toMap().value("categrory").toString() == category && action->data().toMap().value("type") == "category_mount") {
                    action->setEnabled(bookmarks.size() != mountedBookmarks);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : job->workgroups())
  {
    if (!findWorkgroup(workgroup->workgroupName()))
    {
      addWorkgroup(workgroup);
      
      // Since this is a new workgroup, no master browser is present.
      HostPtr masterBrowser = HostPtr(new Smb4KHost());
      masterBrowser->setWorkgroupName(workgroup->workgroupName());
      masterBrowser->setHostName(workgroup->masterBrowserName());
      masterBrowser->setIpAddress(workgroup->masterBrowserIpAddress());
      masterBrowser->setIsMasterBrowser(true);
      
      addHost(masterBrowser);
    }
    else
    {
      updateWorkgroup(workgroup);
      
      // Check if the master browser changed
      QList<HostPtr> members = workgroupMembers(workgroup);
      
      for (const HostPtr &host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress())
          {
            host->setIpAddress(workgroup->masterBrowserIpAddress());
          }
          else
          {
            // Do nothing
          }          
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : m_categories) {
        if (!category.isEmpty()) {
            QTreeWidgetItem *categoryItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
            categoryItem->setIcon(0, KDE::icon("folder-bookmark"));
            categoryItem->setText(0, category);
            categoryItem->setText((treeWidget->columnCount() - 1), QString("00_%1").arg(category));
            categoryItem->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsDropEnabled);
            treeWidget->addTopLevelItem(categoryItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mp : qAsConst(mountpoints))
  {
    dir.cd(mp);
    dir.rmdir(dir.canonicalPath());
    
    if (dir.cdUp())
    {
      dir.rmdir(dir.canonicalPath());
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : children)
        {
          if (object == obj)
          {
            m_focusWidget = sharesViewDock;
            setupDynamicActionList(sharesViewDock);
            break;
          }
          else
          {
            // Do nothing
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *action : qAsConst(actionsList)) {
            if (action->objectName() == "bookmark_action") {
                if (bookmarkMenu) {
                    bookmarkMenu->setBookmarkActionEnabled(action->isEnabled());
                    connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
                    continue;
                }
            } else if (QString::compare(action->objectName(), "filemanager_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "konsole_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "icon_view_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "list_view_action") == 0) {
                continue;
            }

            dynamicList << action;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create new share and set the mountpoint and the filesystem
      SharePtr share = SharePtr(new Smb4KShare(mountPoint->mountedFrom()));
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          // Do nothing
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      else
      {
        // Do nothing
      }
      
      d->importedShares << share;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : shares)
  {
    if ((!s->isForeign() || Smb4KSettings::detectAllShares()) && s->isMounted())
    {
      share->setMounted(s->isMounted());
      share->setPath(s->path());
      share->setForeign(s->isForeign());
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *entry : m_bookmarks->actions()) {
        if (entry->data().toMap().value("category").toString() == bookmark->categoryName()) {
            displayNames << entry->data().toMap().value("text").toString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : qAsConst(mountOptions)) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setUserName(option.section('=', 1, 1).trimmed());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (share->url() == a->data().toMap().value("url").toUrl())
      {
        a->setEnabled(!share->isMounted());
        bookmarkGroup = a->data().toMap().value("group").toString();
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : allCategories)
  {
    if (!category.isEmpty())
    {
      // Category menu entry
      KActionMenu *bookmarkCategoryMenu = new KActionMenu(category, menu());
      bookmarkCategoryMenu->setIcon(KDE::icon("folder-favorites"));
      QMap<QString,QVariant> menuInfo;
      menuInfo["type"] = "category_menu";
      menuInfo["category"] = category;
      bookmarkCategoryMenu->setData(menuInfo);
      addAction(bookmarkCategoryMenu);
      
      // Mount action for the category
      QAction *bookmarkCategoryMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkCategoryMenu->menu());
      QMap<QString,QVariant> categoryMountInfo;
      categoryMountInfo["type"] = "category_mount";
      categoryMountInfo["category"] = category;
      bookmarkCategoryMount->setData(categoryMountInfo);
      bookmarkCategoryMenu->addAction(bookmarkCategoryMount);
      m_actions->addAction(bookmarkCategoryMount);
      
      // Get the list of bookmarks belonging to this category.
      // Use it to decide whether the category mount action should be enabled 
      // (only if not all bookmarks belonging to this category are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(category);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkCategoryMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["category"] = category;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkCategoryMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["category"] = category;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
          }
        }
      }
      
      bookmarkCategoryMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkCategoryMenu->addSeparator();
      
      // Insert the sorted bookmarks into the category menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkCategoryMenu->addAction(a);
            break;
          }
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (QString::compare(s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                         url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                         Qt::CaseInsensitive) == 0 &&
        (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0))
    {
      share = s;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(allActions)) {
            if (a->data().toMap().value("type").toString() == "toplevel_mount" && bookmarkCategory.isEmpty()) {
                a->setEnabled(!allMounted);
                break;
            } else if (a->data().toMap().value("type").toString() == "category_mount" && a->data().toMap().value("category").toString() == bookmarkCategory) {
                a->setEnabled(!allMounted);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (options->type() == Share)
    {
      if (options->remount() == Smb4KCustomOptions::RemountOnce)
      {
        options->setRemount(Smb4KCustomOptions::UndefinedRemount);
      }
      else if (options->remount() == Smb4KCustomOptions::RemountAlways && force)
      {
        options->setRemount(Smb4KCustomOptions::UndefinedRemount);
      }
    }
    
    if (!options->hasOptions())
    {
      removeCustomOptions(options, false);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
      {
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
        if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
#else
        if (options->hasOptions())
#endif
        {
          xmlWriter.writeStartElement("options");
          xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
          xmlWriter.writeAttribute("profile", options->profile());

          xmlWriter.writeTextElement("workgroup", options->workgroupName());
          xmlWriter.writeTextElement("url", options->url().toDisplayString());
          xmlWriter.writeTextElement("ip", options->ipAddress());
          
          xmlWriter.writeStartElement("custom");

          QMap<QString,QString> map = options->customOptions();
          QMapIterator<QString,QString> it(map);

          while (it.hasNext())
          {
            it.next();

            if (!it.value().isEmpty())
            {
              xmlWriter.writeTextElement(it.key(), it.value());
            }
          }

          xmlWriter.writeEndElement();
          xmlWriter.writeEndElement();
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList()) {
            QList<QTreeWidgetItem *> items = m_networkBrowser->findItems(workgroup->workgroupName(), Qt::MatchFixedString, Smb4KNetworkBrowser::Network);

            if (items.isEmpty()) {
                (void)new Smb4KNetworkBrowserItem(m_networkBrowser, workgroup);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList()) {
            addShareToMenu(share);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark :bookmarks)
      {
        QList<SharePtr> mounted = findShareByUNC(bookmark->unc());
      
        if (!mounted.isEmpty())
        {
          for (const SharePtr &share : mounted)
          {
            if (!share->isForeign())
            {
              number++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (QString::compare(s->hostName(), host->hostName(), Qt::CaseInsensitive) == 0 &&
        QString::compare(s->workgroupName(), host->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      shares += s;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &to : qAsConst(tabOrientationChoices)) {
        tabOrientation->addItem(to.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(actions)) {
                    if (a->text() == b) {
                        bookmarkCategoryMenu->addAction(a);
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions())
  {
    if (action)
    {
      action->setEnabled(use);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : minimalProtocolVersionChoices)
  {
    minimalProtocolVersion->addItem(c.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    QAction *bookmarkAction = 0;
        
    if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
      QMap<QString,QVariant> info;
      info["group"] = "";
      info["unc"] = bookmark->unc();
      bookmarkAction->setData(info);
      sortedBookmarks << bookmark->label();
      m_action_collection->addAction(bookmark->unc(), bookmarkAction);
    }
    else
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->unc(), m_bookmarks);
      QMap<QString,QVariant> info;
      info["group"] = "";
      info["unc"] = bookmark->unc();
      bookmarkAction->setData(info);
      sortedBookmarks << bookmark->unc();
      m_action_collection->addAction(bookmark->unc(), bookmarkAction);
    }
        
    QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
    if (!mountedShares.isEmpty())
    {
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          bookmarkAction->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : job->shares())
    {
      if (s->workgroupName() == share->workgroupName() && s->unc() == share->unc())
      {
        found = true;
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      QUrl bookmarkUrl = a->data().toMap().value("url").toUrl();
      
      if (share->url().matches(bookmarkUrl, QUrl::RemoveUserInfo|QUrl::RemovePort))
      {
        a->setEnabled(!share->isMounted());
        bookmarkCategory = a->data().toMap().value("category").toString();
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.trimmed().startsWith(QLatin1String("Enumerating")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("Domain name")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("-------------")))
      {
        continue;
      }
      else if (line.trimmed().isEmpty())
      {
        continue;
      }
      else
      {
        // This is the workgroup and master entry. Process it.
        workgroup->setWorkgroupName(line.section("   ", 0, 0).trimmed());
        workgroup->setMasterBrowserName(line.section("   ", 1, -1).trimmed());

        m_workgroups_list << new Smb4KWorkgroup(*workgroup);

        delete workgroup;
        workgroup = new Smb4KWorkgroup();
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
    {
      if (bookmark->profile() == Smb4KSettings::activeProfile())
      {
        bookmarks << bookmark;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible() && !Smb4KSynchronizer::self()->isRunning(item->shareItem()))
    {
      Smb4KSynchronizer::self()->synchronize(item->shareItem(), m_sharesView);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : minimalClientProtocolVersionChoices) {
        minimalClientProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : qAsConst(d->tempHostList)) {
            if (host->hostName() == workgroup->masterBrowserName()) {
                host->setIsMasterBrowser(true);
            } else {
                host->setIsMasterBrowser(false);
            }

            if (!findHost(host->hostName(), host->workgroupName())) {
                addHost(host);
            } else {
                updateHost(host);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList())
    {
        lookupShares(host);
    
        while(isRunning())
        {
            QTest::qWait(50);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : d->bookmarks)
  {
    if (!d->groups.contains(bookmark->groupName(), Qt::CaseInsensitive))
    {
      d->groups << bookmark->groupName();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *b : d->bookmarks)
  {
    if (QString::compare(b->label().toUpper(), label.toUpper()) == 0)
    {
      bookmark = b;
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : qAsConst(minimalProtocolVersionChoices)) {
        minimalProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkCategoryMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["category"] = category;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkCategoryMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["category"] = category;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : options)
  {
    if (o->remount() == Smb4KCustomOptions::RemountOnce)
    {
      remounts << o;
    }
    else if (o->remount() == Smb4KCustomOptions::RemountAlways)
    {
      remounts << o;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : Smb4KBookmarkHandler::self()->bookmarksList()) {
        d->bookmarkObjects << new Smb4KBookmarkObject(bookmark.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : list)
        {
          QList<SharePtr> mountedShares = findShareByUrl(opt->url());
          
          if (!mountedShares.isEmpty())
          {
            bool mount = true;
            
            for (const SharePtr &s : mountedShares)
            {
              if (!s->isForeign())
              {
                mount = false;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (mount)
            {
              SharePtr share = SharePtr(new Smb4KShare());
              share->setUrl(opt->url());
              share->setWorkgroupName(opt->workgroupName());
              share->setHostIpAddress(opt->ipAddress());
              
              if (share->url().isValid() && !share->url().isEmpty())
              {
                d->remounts << share;
              }
            }
          }
          else
          {
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(opt->url());
            share->setWorkgroupName(opt->workgroupName());
            share->setHostIpAddress(opt->ipAddress());
              
            if (share->url().isValid() && !share->url().isEmpty())
            {
              d->remounts << share;
            }
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
    bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
    bookmarkItem->setIcon(0, bookmark->icon());
    bookmarkItem->setText(0, bookmark->unc());
    bookmarkItem->setText((m_tree_widget->columnCount() - 1), QString("01_%1").arg(bookmark->unc()));
    bookmarkItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDragEnabled);
    
    if (!bookmark->groupName().isEmpty())
    {
      QList<QTreeWidgetItem *> items = m_tree_widget->findItems(bookmark->groupName(), Qt::MatchFixedString|Qt::MatchCaseSensitive, 0);
      
      if (!items.isEmpty())
      {
        items.first()->addChild(bookmarkItem);
        items.first()->setExpanded(true);
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      m_tree_widget->addTopLevelItem(bookmarkItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profile : profiles)
  {
    QAction *action = addAction(profile);
  
    if (action)
    {
      action->setEnabled(Smb4KProfileManager::self()->useProfiles());
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      // FIXME: Check if the bookmarked share has already been mounted.
      SharePtr share = SharePtr(new Smb4KShare());
      share->setHostName(bookmark->hostName());
      share->setShareName(bookmark->shareName());
      share->setWorkgroupName(bookmark->workgroupName());
      share->setHostIpAddress(bookmark->hostIpAddress());
      share->setLogin(bookmark->login());
      mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
      {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);
        
        if (item && item->shareItem()->isForeign())
        {
          foreign++;
        }
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
    if (!isRunning())
    {
      import(true);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
  {
    //
    // Printer shares cannot be bookmarked
    //
    if (share->isPrinter())
    {
      Smb4KNotification::cannotBookmarkPrinter(share);
      continue;
    }
    else
    {
      // Do nothing
    }
    
    //
    // Process homes shares
    //
    if (share->isHomesShare())
    {
      if (!Smb4KHomesSharesHandler::self()->specifyUser(share, true, parent))
      {
        continue;
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
    
    //
    // Check if the share has already been bookmarked and skip it if it
    // already exists
    //
    BookmarkPtr knownBookmark = findBookmarkByUrl(share->isHomesShare() ? share->homeUrl() : share->url());
    
    if (knownBookmark)
    {
      Smb4KNotification::bookmarkExists(knownBookmark.data());
      continue;
    }
    else
    {
      // Do nothing
    }
    
    BookmarkPtr bookmark = BookmarkPtr(new Smb4KBookmark(share.data()));
    bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
    newBookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : hosts_list)
      {
        if (h->workgroupName() == host->workgroupName() && h->hostName() == host->hostName())
        {
          found = true;
          break;
        }
        else
        {
          continue;
        }        
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
          {
            if (share->isMounted())
            {
              slotShareMounted(share);
               
              if (!share->isForeign())
              {
                break;
              }
              else
              {
                continue;
              }
            }
            else
            {
              continue;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(allCategories)) {
            QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(category);

            for (const BookmarkPtr &bookmark : bookmarks) {
                QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

                if (!mountedShares.isEmpty()) {
                    for (const SharePtr &share : qAsConst(mountedShares)) {
                        if (!share->isForeign()) {
                            mountedBookmarks++;
                            break;
                        }
                    }
                }
            }

            for (QAction *action : allMountActions) {
                if (action->data().toMap().value("categrory").toString() == category && action->data().toMap().value("type") == "category_mount") {
                    action->setEnabled(bookmarks.size() != mountedBookmarks);
                    break;
                }
            }

            mountedBookmarks = 0;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : shares_list)
      {
        if (s->workgroupName() == share->workgroupName() && s->unc() == share->unc())
        {
          found = true;
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
      {
        if (options->hasOptions())
        {
          xmlWriter.writeStartElement("options");
          xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
          xmlWriter.writeAttribute("profile", options->profile());

          xmlWriter.writeTextElement("workgroup", options->workgroupName());
          xmlWriter.writeTextElement("url", options->url().toDisplayString());
          xmlWriter.writeTextElement("ip", options->ipAddress());
          
          xmlWriter.writeStartElement("custom");

          QMap<QString,QString> map = options->customOptions();
          QMapIterator<QString,QString> it(map);

          while (it.hasNext())
          {
            it.next();

            if (!it.value().isEmpty())
            {
              xmlWriter.writeTextElement(it.key(), it.value());
            }
          }

          xmlWriter.writeEndElement();
          xmlWriter.writeEndElement();
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : Smb4KBookmarkHandler::self()->bookmarksList())
  {
    d->bookmarkObjects << new Smb4KBookmarkObject(bookmark);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
  {
    // Unmount the share
    unmountShare(share, silent);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
                Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

                if (item && item->shareItem()->isForeign()) {
                    foreign++;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            // In case of a host, there can only be an exact match.
            if (QString::compare(host->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 Qt::CaseInsensitive) == 0 ||
                (host->url().isEmpty() && host->ipAddress() == o->ipAddress()))
            {
              options = o;
              break;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints))
  {
    if (mountPoint->mountType() == "cifs" || mountPoint->mountType() == "smb3" || mountPoint->mountType() == "smbfs")
    {
      // Create a new share and set the mountpoint and filesystem
      SharePtr share = SharePtr(new Smb4KShare());
      share->setUrl(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      
      d->importedShares << share;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &file : qAsConst(discoveredFiles)) {
        if (file->isHidden() && !Smb4KSettings::previewHiddenItems()) {
            continue;
        }

        list << file;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : qAsConst(userList)) {
                    //
                    // Create a temp share
                    //
                    SharePtr tempShare = share;

                    //
                    // Set the login
                    //
                    tempShare->setLogin(user);

                    //
                    // Read the authentication information
                    //
                    readAuthInfo(tempShare);

                    //
                    // Save the authentication data in the map
                    //
                    knownLogins.insert(tempShare->login(), tempShare->password());

                    //
                    // Clear the temp share
                    //
                    tempShare.clear();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options) {
        if (options->profile() == from) {
            options->setProfile(to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs())
  {
    if (QString::compare(QString("PreviewJob_%1").arg(unc), job->objectName()) == 0)
    {
      job->kill(KJob::EmitResult);
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->mountedSharesList)) {
        if (s->isInaccessible()) {
            inaccessibleShares += s;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : qAsConst(optionsList)) {
            if (o->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash)
                == url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash)) {
                options = o;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(allBookmarks)) {
            QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

            if (!mountedShares.isEmpty()) {
                for (const SharePtr &share : qAsConst(mountedShares)) {
                    if (!share->isForeign()) {
                        mountedBookmarks++;
                        break;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : addresses)
    {
      // We only use global addresses.
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
      if (addr.isGlobal())
#else
      if (!addr.isLoopback() && !addr.isMulticast())
#endif
      {
        if (addr.protocol() == QAbstractSocket::IPv4Protocol)
        {
          ipAddress = addr;
          break;
        }
        else if (addr.protocol() == QAbstractSocket::IPv6Protocol)
        {
          // FIXME: Use the right address here.
          ipAddress = addr;
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : list)
        {
          QList<SharePtr> mountedShares = findShareByUNC(opt->unc());
          
          if (!mountedShares.isEmpty())
          {
            bool mount = true;
            
            for (const SharePtr &s : mountedShares)
            {
              if (!s->isForeign())
              {
                mount = false;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (mount)
            {
              SharePtr share = SharePtr(new Smb4KShare());
              share->setUrl(opt->url());
              share->setWorkgroupName(opt->workgroupName());
              share->setHostIpAddress(opt->ipAddress());
              
              if (share->url().isValid() && !share->url().isEmpty())
              {
                d->remounts << share;
              }
              else
              {
                // Do nothing
              }
            }
            else
            {
              // Do nothing
            }
          }
          else
          {
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(opt->url());
            share->setWorkgroupName(opt->workgroupName());
            share->setHostIpAddress(opt->ipAddress());
              
            if (share->url().isValid() && !share->url().isEmpty())
            {
              d->remounts << share;
            }
            else
            {
              // Do nothing
            }
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *host : hostsList())
  {
    d->hostObjects << new Smb4KNetworkObject(host);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : list)
  {
    if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
    {
      Smb4KNotification::bookmarkLabelInUse(bookmark);
      Smb4KBookmark *new_bookmark = new Smb4KBookmark(*bookmark);
      new_bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
      d->bookmarks << new_bookmark;
    }
    else
    {
      d->bookmarks << new Smb4KBookmark(*bookmark);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList) {
            switch (o->type()) {
            case Host: {
                QListWidgetItem *item = new QListWidgetItem(KDE::icon("network-server"), o->displayString(), optionsListWidget, Host);
                item->setData(Qt::UserRole, o->url().toDisplayString());
                break;
            }
            case Share: {
                QListWidgetItem *item = new QListWidgetItem(KDE::icon("folder-network"), o->displayString(), optionsListWidget, Share);
                item->setData(Qt::UserRole, o->url().toDisplayString());
                break;
            }
            default: {
                break;
            }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : minimalClientProtocolVersionChoices)
  {
    minimalClientProtocolVersion->addItem(c.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : mountedSharesList())
    {
      if (share->url() == object->url())
      {
        Smb4KSynchronizer::self()->synchronize(share);
      }
      else
      {
        // Do nothing
      }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
          if (!isRunning())
          {
            if (d->firstImportDone && d->importedShares.isEmpty() && d->newlyMounted > 1)
            {
              Smb4KNotification::sharesMounted(d->newlyMounted);
            }
              
            d->newlyMounted = 0;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks) {
                if (!bookmark->url().isValid()) {
                    Smb4KNotification::invalidURLPassed();
                    continue;
                }

                xmlWriter.writeStartElement("bookmark");
                xmlWriter.writeAttribute("profile", bookmark->profile());
                xmlWriter.writeAttribute("category", bookmark->categoryName());

                xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
                xmlWriter.writeTextElement("url", bookmark->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort));
                xmlWriter.writeTextElement("login", bookmark->login());
                xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
                xmlWriter.writeTextElement("label", bookmark->label());

                xmlWriter.writeEndElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
      {
        if (!bookmark->url().isValid())
        {
          Smb4KNotification::invalidURLPassed();
          continue;
        }
        
        xmlWriter.writeStartElement("bookmark");
        xmlWriter.writeAttribute("profile", bookmark->profile());
        xmlWriter.writeAttribute("category", bookmark->categoryName());

        xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
        xmlWriter.writeTextElement("url", bookmark->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort));
        xmlWriter.writeTextElement("login", bookmark->login());
        xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
        xmlWriter.writeTextElement("label", bookmark->label());

        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : qAsConst(mountOptions)) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setLogin(option.section('=', 1, 1).trimmed());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
  {
    if (QString::compare(b->unc().toUpper(), unc.toUpper()) == 0)
    {
      bookmark = b;
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.startsWith(QLatin1String("Looking up status of")))
      {
        // Get the IP address of the master browser.
        ipAddress = line.section("of", 1, 1).trimmed();
        continue;
      }
      else if (line.contains("MAC Address", Qt::CaseSensitive))
      {
        // Add workgroup to the list. 
      }
      else if (line.contains(" <00> ", Qt::CaseSensitive))
      {
        // Set the name of the workgroup/host.
        if (line.contains(" <GROUP> ", Qt::CaseSensitive))
        {
          // Avoid setting the workgroup name twice.
          if (workgroupName.isEmpty())
          {
            workgroupName = line.section("<00>", 0, 0).trimmed();
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Avoid setting the name of the master browser twice.
          if (masterBrowserName.isEmpty())
          {
            masterBrowserName = line.section("<00>", 0, 0).trimmed();
          }
          else
          {
            // Do nothing
          }
        }

        continue;
      }
      else if (line.contains(" <1d> ", Qt::CaseSensitive))
      {
        // Get the workgroup name.
        if (workgroupName.isEmpty())
        {
          workgroupName = line.section("<1d>", 0, 0).trimmed();
        }
        else
        {
          // Do nothing
        }

        continue;
      }
      else
      {
        continue;
      }
      
      if (!workgroupName.isEmpty() && !masterBrowserName.isEmpty())
      {
        WorkgroupPtr workgroup = WorkgroupPtr(new Smb4KWorkgroup());
        workgroup->setWorkgroupName(workgroupName);
        workgroup->setMasterBrowserIP(ipAddress);
        workgroup->setMasterBrowserName(masterBrowserName);
        m_workgroups_list << workgroup;
        
        workgroupName.clear();
        ipAddress.clear();
        masterBrowserName.clear();
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList()) {
        lookupDomainMembers(workgroup);

        while (isRunning()) {
            QTest::qWait(50);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (a->data().toMap().value("group").toString() == bookmarkGroup && a->isEnabled())
      {
        allMounted = false;
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::sharesList())
        {
          if (share->url() == object->url())
          {
            Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(share);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkCategoryMenu->addAction(a);
            break;
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : mountedShares) {
                    if (!s->isForeign()) {
                        share->setMountData(s.data());
                        break;
                    } else {
                        continue;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : qAsConst(d->tempWorkgroupList))
        {
            if (!findWorkgroup(workgroup->workgroupName()))
            {
                addWorkgroup(workgroup);
      
                // Since this is a new workgroup, no master browser is present.
                HostPtr masterBrowser = HostPtr(new Smb4KHost());
                masterBrowser->setWorkgroupName(workgroup->workgroupName());
                masterBrowser->setHostName(workgroup->masterBrowserName());
                masterBrowser->setIpAddress(workgroup->masterBrowserIpAddress());
                masterBrowser->setIsMasterBrowser(true);
      
                addHost(masterBrowser);
            }
            else
            {
                updateWorkgroup(workgroup);
      
                // Check if the master browser changed
                QList<HostPtr> members = workgroupMembers(workgroup);
      
                for (const HostPtr &host : qAsConst(members))
                {
                    if (workgroup->masterBrowserName() == host->hostName())
                    {
                        host->setIsMasterBrowser(true);
          
                        if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress())
                        {
                            host->setIpAddress(workgroup->masterBrowserIpAddress());
                        }
                    }
                    else
                    {
                        host->setIsMasterBrowser(false);
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
    {
      Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);
      
      if (item)
      {
        // Is the share synchronized at the moment?
        if (Smb4KSynchronizer::self()->isRunning(item->shareItem()))
        {
          syncsRunning += 1;
        }
        else
        {
          // Do nothing
        }
        
        // Is the share inaccessible at the moment?
        if (item->shareItem()->isInaccessible())
        {
          inaccessible += 1;
        }
        else
        {
          // Do nothing
        }
        
        // Was the share being mounted by another user?
        if (item->shareItem()->isForeign())
        {
          foreign += 1;
        }
        else
        {
          // Do nothing
        }
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : unmountedShares)
      {
        // Copy the share
        Smb4KShare unmountedShare(*share);
        
        // Remove the share from the global list and notify the program
        removeMountedShare(share);
        emit unmounted(&unmountedShare);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : mountedSharesList())
  {
    d->mountedObjects << new Smb4KNetworkObject(mountedShare.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList) {
            if (!s->isForeign()) {
                p->onlyForeignShares = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : qAsConst(p->workgroupsList)) {
        if (QString::compare(w->workgroupName(), name, Qt::CaseInsensitive) == 0) {
            workgroup = w;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
        SharePtr share = SharePtr(new Smb4KShare());
        share->setHostName(bookmark->hostName());
        share->setShareName(bookmark->shareName());
        share->setWorkgroupName(bookmark->workgroupName());
        share->setHostIpAddress(bookmark->hostIpAddress());
        share->setUserName(bookmark->userName());
        mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
      {
        if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
        {
          xmlWriter.writeStartElement("options");
          xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
          xmlWriter.writeAttribute("profile", options->profile());

          xmlWriter.writeTextElement("workgroup", options->workgroupName());
          xmlWriter.writeTextElement("url", options->url().toDisplayString());
          xmlWriter.writeTextElement("ip", options->ipAddress());
          
          xmlWriter.writeStartElement("custom");

          QMap<QString,QString> map = options->customOptions();
          QMapIterator<QString,QString> it(map);

          while (it.hasNext())
          {
            it.next();

            if (!it.value().isEmpty())
            {
              xmlWriter.writeTextElement(it.key(), it.value());
            }
            else
            {
              // Do nothing
            }
          }

          xmlWriter.writeEndElement();
          xmlWriter.writeEndElement();
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(d->bookmarks)) {
        if (QString::compare(bookmark->profile(), from, Qt::CaseSensitive) == 0) {
            bookmark->setProfile(to);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList &/*args*/, const QString &/*workingDir*/){
        if (mainWindow->isVisible()) {
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5, 91, 0)
            KWindowSystem::updateStartupId(mainWindow->windowHandle());
            KWindowSystem::activateWindow(mainWindow->windowHandle());
#endif
        } else {
            mainWindow->setVisible(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : Smb4KGlobal::workgroupsList()) {
        d->workgroupObjects << new Smb4KNetworkObject(workgroup.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
        if (args["mh_mountpoint"].toString() == mountPoint->mountPoint()
            && (mountPoint->mountType() == "cifs" || mountPoint->mountType() == "smb3" || mountPoint->mountType() == "smbfs")) {
            mountPointOk = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    QAction *bookmarkAction = 0;
        
    if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), menu());
      bookmarkAction->setObjectName(bookmark->url().toDisplayString());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["url"] = bookmark->url();
      bookmarkInfo["text"] = bookmark->label();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->label();
    }
    else
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), menu());
      bookmarkAction->setObjectName(bookmark->url().toDisplayString());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["url"] = bookmark->url();
      bookmarkInfo["text"] = bookmark->displayString();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->displayString();
    }
        
    QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
    if (!mountedShares.isEmpty())
    {
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          bookmarkAction->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : m_groups)
  {
    if (!group.isEmpty())
    {
      QTreeWidgetItem *groupItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
      groupItem->setIcon(0, KDE::icon("folder-bookmark"));
      groupItem->setText(0, group);
      groupItem->setText((m_tree_widget->columnCount() - 1), QString("00_%1").arg(group));
      groupItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDropEnabled);
      m_tree_widget->addTopLevelItem(groupItem);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
  {
    //
    // Printer shares cannot be bookmarked
    //
    if (share->isPrinter())
    {
      Smb4KNotification::cannotBookmarkPrinter(share);
      continue;
    }
    else
    {
      // Do nothing
    }
    
    //
    // Process homes shares
    //
    if (share->isHomesShare())
    {
      if (!Smb4KHomesSharesHandler::self()->specifyUser(share, true, parent))
      {
        continue;
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
    
    //
    // Check if the share has already been bookmarked and skip it if it
    // already exists
    //
    BookmarkPtr knownBookmark = findBookmarkByUNC(share->isHomesShare() ? share->homeUNC() : share->unc());
    
    if (knownBookmark)
    {
      Smb4KNotification::bookmarkExists(knownBookmark.data());
      continue;
    }
    else
    {
      // Do nothing
    }
    
    BookmarkPtr bookmark = BookmarkPtr(new Smb4KBookmark(share.data()));
    bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
    newBookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks) {
                QAction *bookmarkAction = 0;

                if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty()) {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->label();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->label();
                } else {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->displayString();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->displayString();
                }

                QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

                if (!mountedShares.isEmpty()) {
                    for (const SharePtr &share : mountedShares) {
                        if (!share->isForeign()) {
                            bookmarkAction->setEnabled(false);
                            mountedBookmarks++;
                            break;
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      QList<SharePtr> mounted = findShareByUNC(bookmark->unc());
      
      if (!mounted.isEmpty())
      {
        for (const SharePtr &share : mounted)
        {
          if (!share->isForeign())
          {
            number++;
            break;
          }
          else
          {
            continue;
          }
        }
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(*pHosts))
            {
                //
                // On a local network there will most likely be no two servers with
                // identical name, thus, to avoid duplicates, only test the hostname
                // here.
                // 
                if (QString::compare(h->hostName(), service->serviceName(), Qt::CaseInsensitive) == 0)
                {
                    foundServer = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item && !item->shareItem()->isInaccessible()) {
            openShare(item->shareItem(), Konsole);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profile : profiles)
  {
    QAction *action = addAction(profile);
    
    if (action)
    {
      action->setEnabled(Smb4KProfileManager::self()->useProfiles());
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
    {
      share->setHostIP(host->ip());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->mountedObjects)
    {
      if (url.matches(obj->url(), QUrl::None))
      {
        object = obj;
        break;
      }
      else if (!exactMatch && url.matches(obj->url(), QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash))
      {
        object = obj;
        continue;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *importedShare : d->importedShares)
    {
      // Check the mountpoint, since that one is unique. We will only use
      // Smb4KShare::path(), so that we do not run into trouble if a share 
      // is inaccessible.
      if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
      {
        found = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(mountedShares)) {
            if (!s->isForeign()) {
                isMounted = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
        {
          bool foundShare = false;
          
          for (int i = 0; i < hostItem->childCount(); ++i)
          {
            Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));
            
            if (shareItem->shareItem()->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort) == share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort))
            {
              foundShare = true;
              break;
            }
          }

          if (!foundShare)
          {
            (void) new Smb4KNetworkBrowserItem(hostItem, share);
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *host : hosts_list)
    {
      if (host->hostName() == workgroup->masterBrowserName())
      {
        host->setIsMasterBrowser(true);
      }
      else
      {
        host->setIsMasterBrowser(false);
      }
      
      if (!findHost(host->hostName(), host->workgroupName()))
      {
        addHost(new Smb4KHost(*host));
        d->haveNewHosts = true;
      }
      else
      {
        updateHost(host);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(discoveredShares)) {
            if (s->workgroupName() == share->workgroupName() && s->url().matches(share->url(), QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                foundShare = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares_list)
    {
      //
      // Process only those shares that the user wants to see
      //
      if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      //
      // Add the host's IP address and authentication information
      //
      Smb4KHost *host = findHost(share->hostName(), share->workgroupName());
      
      if (host)
      {
        share->setHostIP(host->ip());
        share->setLogin(host->login());
        share->setPassword(host->password());
      }
      else
      {
        // Do nothing
      }
      
      //
      // Add or update the shares
      //      
      if (!findShare(share->unc(), share->workgroupName()))
      {
        addShare(new Smb4KShare(*share));
      }
      else
      {
        updateShare(share);
      }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
            browsingFinished = true;
            serviceBrowser.disconnect();
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(allCategories)) {
            if (action->data().toMap().value("category").toString() == bookmark->categoryName()) {
                bookmarkMenu = static_cast<KActionMenu *>(action);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : job->shares()) {
            if (s->workgroupName() == share->workgroupName() && s->url().matches(share->url(), QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                foundShare = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);
        shares << item->shareItem();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks)
  {
    for (QAction *a : actions)
    {
      if (a->text() == b)
      {
        addAction(a);
        break;
      }
      else
      {
        continue;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : qAsConst(*pWorkgroups)) {
            if (QString::compare(w->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0) {
                foundWorkgroup = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : list) {
        write(authInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
    {
      QList<QTreeWidgetItem *> items = m_networkBrowser->findItems(workgroup->workgroupName(), Qt::MatchFixedString, Smb4KNetworkBrowser::Network);
        
      if (items.isEmpty())
      {
        (void) new Smb4KNetworkBrowserItem(m_networkBrowser, workgroup);
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName())
        {
          o->setIpAddress(options->ipAddress());
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
          o->setUseUser(options->useUser());
          o->setUser(options->user());
          o->setUseGroup(options->useGroup());
          o->setGroup(options->group());
          o->setUseFileMode(options->useFileMode());
          o->setFileMode(options->fileMode());
          o->setUseDirectoryMode(options->useDirectoryMode());
          o->setDirectoryMode(options->directoryMode());
#endif
#if defined(Q_OS_LINUX)
          o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
          o->setUseFileSystemPort(options->useFileSystemPort());
          o->setFileSystemPort(options->fileSystemPort());
          o->setUseSecurityMode(options->useSecurityMode());
          o->setSecurityMode(options->securityMode());
          o->setUseWriteAccess(options->useWriteAccess());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUseSmbPort(options->useSmbPort());
          o->setSmbPort(options->smbPort());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible())
    {
      openShare(item->shareItem(), FileManager);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
    {
      BookmarkPtr existingBookmark = findBookmarkByUNC(bookmark->unc());
      
      if (!existingBookmark)
      {
        if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
        {
          Smb4KNotification::bookmarkLabelInUse(bookmark.data());
          bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
        }
        else
        {
          // Do nothing
        }
        
        d->bookmarks << bookmark;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    // Do not process null pointers
    if (!share)
    {
      continue;
    }
    else
    {
      // Do nothing
    }
    
    // Add the display name to the list
    displayNames << share->displayString();
    
    // Create the share menu
    KActionMenu *shareMenu = new KActionMenu(share->displayString(), m_menus);
    shareMenu->setIcon(share->icon());
    
    QMap<QString,QVariant> data;
    data["text"] = share->displayString();
    
    shareMenu->setData(data);
    
    // Add the menu to the action collection
    m_action_collection->addAction(share->displayString(), shareMenu);
    
    // Add the unmount action to the menu
    QAction *unmount = new QAction(KDE::icon("media-eject"), i18n("Unmount"), m_actions);
    
    QMap<QString,QVariant> unmountData;
    unmountData["type"] = "unmount";
    unmountData["mountpoint"] = share->path();
    
    unmount->setData(unmountData);
    unmount->setEnabled(!share->isForeign() || Smb4KSettings::unmountForeignShares());
    shareMenu->addAction(unmount);
    m_action_collection->addAction(QString("%1_%2").arg("[unmount]", share->path()), unmount);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the bookmark action to the menu
    QAction *addBookmark = new QAction(KDE::icon("bookmark-new"), i18n("Add Bookmark"), m_actions);
    
    QMap<QString,QVariant> bookmarkData;
    bookmarkData["type"] = "bookmark";
    bookmarkData["mountpoint"] = share->path();
    
    addBookmark->setData(bookmarkData);
    shareMenu->addAction(addBookmark);
    m_action_collection->addAction(QString("%1_%2").arg("[bookmark]", share->path()), addBookmark);
    
    // Add the synchronization action to the menu
    QAction *synchronize = new QAction(KDE::icon("folder-sync"), i18n("Synchronize"), m_actions);
    
    QMap<QString,QVariant> syncData;
    syncData["type"] = "sync";
    syncData["mountpoint"] = share->path();
    
    synchronize->setData(syncData);
    synchronize->setEnabled(!QStandardPaths::findExecutable("rsync").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(synchronize);
    m_action_collection->addAction(QString("%1_%2").arg("[sync]", share->path()), synchronize);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the Open with Konsole action to the menu
    QAction *konsole = new QAction(KDE::icon("utilities-terminal"), i18n("Open with Konsole"), m_actions);
    
    QMap<QString,QVariant> konsoleData;
    konsoleData["type"] = "konsole";
    konsoleData["mountpoint"] = share->path();
    
    konsole->setData(konsoleData);
    konsole->setEnabled(!QStandardPaths::findExecutable("konsole").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(konsole);
    m_action_collection->addAction(QString("%1_%2").arg("[konsole]", share->path()), konsole);
    
    // Add the Open with Filemanager action to the menu
    QAction *filemanager = new QAction(KDE::icon("system-file-manager"), i18n("Open with File Manager"), m_actions);
    
    QMap<QString,QVariant> fmData;
    fmData["type"] = "filemanager";
    fmData["mountpoint"] = share->path();
    
    filemanager->setData(fmData);
    filemanager->setEnabled(!share->isInaccessible());
    shareMenu->addAction(filemanager);
    m_action_collection->addAction(QString("%1_%2").arg("[filemanager]", share->path()), filemanager);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
            Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

            if (item) {
                // Is the share synchronized at the moment?
                if (Smb4KSynchronizer::self()->isRunning(item->shareItem())) {
                    syncsRunning += 1;
                }

                // Is the share inaccessible at the moment?
                if (item->shareItem()->isInaccessible()) {
                    inaccessible += 1;
                }

                // Was the share being mounted by another user?
                if (item->shareItem()->isForeign()) {
                    foreign += 1;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks) {
        if (!m_categories.contains(bookmark->categoryName())) {
            m_categories << bookmark->categoryName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *host : hostsList())
        {
          if (host->url() == object->url())
          {
            Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(host);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarksList())
  {
    if (QString::compare(group, bookmark->groupName(), Qt::CaseInsensitive) == 0)
    {
      bookmarks << bookmark;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->shareObjects)
        {
          if (url == obj->url())
          {
            object = obj;
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList())
    {
      if (share->url() == object->url())
      {
        shares << share;
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
    {
      if (QString::compare(unc, o->unc(), Qt::CaseInsensitive) == 0 || ipAddress == o->ip())
      {
        options = o;
        break;
      }
      else if (!exactMatch && o->type() == Host && (QString::compare(hostUNC, o->unc(), Qt::CaseInsensitive) == 0 || ipAddress == o->ip()))
      {
        options = o;
        // Do not break here. The exact match is always favored.
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : Smb4KBookmarkHandler::self()->bookmarksList()) {
        addBookmarkToMenu(bookmark);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &hostDir : qAsConst(hostDirs))
  {
    dir.cd(hostDir);
    
    QStringList shareDirs = dir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::NoSort);
    
    for (const QString &shareDir : qAsConst(shareDirs))
    {
      dir.cd(shareDir);
      mountpoints << dir.absolutePath();
      dir.cdUp();
    }
    
    dir.cdUp();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shareDir : qAsConst(shareDirs))
    {
      dir.cd(shareDir);
      mountpoints << dir.absolutePath();
      dir.cdUp();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KProfileObject *profile : d->profileObjects)
  {
    if (profile->isActiveProfile())
    {
      activeProfile = profile->profileName();
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    slotShareMounted(share);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList)
    {
      if (Smb4KSettings::useProfiles())
      {
        options->setProfile(Smb4KProfileManager::self()->activeProfile());
      }
      else
      {
        // Do nothing
      }
      
      if (hasCustomOptions(options) || options->remount() == Smb4KCustomOptions::RemountOnce)
      {
        d->options << options;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName())
        {
          o->setIpAddress(options->ipAddress());
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
          o->setUseUser(options->useUser());
          o->setUser(options->user());
          o->setUseGroup(options->useGroup());
          o->setGroup(options->group());
          o->setUseFileMode(options->useFileMode());
          o->setFileMode(options->fileMode());
          o->setUseDirectoryMode(options->useDirectoryMode());
          o->setDirectoryMode(options->directoryMode());
#endif
#if defined(Q_OS_LINUX)
          o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
          o->setUseFileSystemPort(options->useFileSystemPort());
          o->setFileSystemPort(options->fileSystemPort());
          o->setUseSecurityMode(options->useSecurityMode());
          o->setSecurityMode(options->securityMode());
          o->setUseWriteAccess(options->useWriteAccess());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUseSmbPort(options->useSmbPort());
          o->setSmbPort(options->smbPort());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &vm : sharesViewModeChoices)
  {
    viewMode->addItem(vm.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : children)
        {
          if (object == obj)
          {
            m_focusWidget = networkBrowserDock;
            setupDynamicActionList(networkBrowserDock);
            break;
          }
          else
          {
            // Do nothing
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList()) {
        if (!share->isForeign()) {
            Smb4KCustomOptionsManager::self()->addRemount(share, false);
        } else {
            Smb4KCustomOptionsManager::self()->removeRemount(share, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : optionsList)
    {
      //
      // If we want to have an exact match, skip all options that do not match
      // 
      if (exactMatch)
      {
        if (networkItem->type() != opt->type() || 
            QString::compare(networkItem->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash), 
                             opt->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash), Qt::CaseInsensitive) != 0)
        {
          continue;
        }
      }
      
      //
      // Now assign the options
      // 
      if (networkItem->type() == Host && opt->type() == Host)
      {
        HostPtr host = networkItem.staticCast<Smb4KHost>();
        
        if (host)
        {
          if (QString::compare(host->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash), 
                               opt->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash), Qt::CaseInsensitive) == 0 ||
              (host->url().isEmpty() && host->ipAddress() == opt->ipAddress()))
          {
            options = opt;
            break;
          }
        }
      }
      else if (networkItem->type() == Share)
      {
        SharePtr share = networkItem.staticCast<Smb4KShare>();
        
        if (share)
        {
          if (opt->type() == Share &&
              QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash), 
                               opt->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash), Qt::CaseInsensitive) == 0)
          {
            // Since this is the exact match, break here
            options = opt;
            break;
          }
          else if (opt->type() == Host &&
                   QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath|QUrl::StripTrailingSlash), 
                                    opt->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath|QUrl::StripTrailingSlash), Qt::CaseInsensitive) == 0)
          {
            // These options belong to the host. Do not break here, 
            // because there might still be an exact match
            options = opt;
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : mountedShares)
        {
          if (!s->isForeign())
          {
            share->setMountData(s.data());
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *newEntry : newWalletEntries)
      {
        if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive) == 0 /* leave the user info here */ &&
            QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0)
        {
          enable = true;
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      check(share);
      emit updated(share);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
  {
    HostPtr host = findHost(bookmark->hostName(), bookmark->workgroupName());
    
    if (host)
    {
      if (host->hasIpAddress() && bookmark->hostIpAddress() != host->ipAddress())
      {
        bookmark->setHostIpAddress(host->ipAddress());
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
    {
      if (QString::compare(b->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           Qt::CaseInsensitive) == 0)
      {
        bookmark = b;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList) {
            if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName()) {
                o->setIpAddress(m_currentOptions->ipAddress());
                o->setUseUser(m_currentOptions->useUser());
                o->setUser(m_currentOptions->user());
                o->setUseGroup(m_currentOptions->useGroup());
                o->setGroup(m_currentOptions->group());
                o->setUseFileMode(m_currentOptions->useFileMode());
                o->setFileMode(m_currentOptions->fileMode());
                o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
                o->setDirectoryMode(m_currentOptions->directoryMode());
#if defined(Q_OS_LINUX)
                o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
                o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
                o->setFileSystemPort(m_currentOptions->fileSystemPort());
                o->setUseMountProtocolVersion(m_currentOptions->useMountProtocolVersion());
                o->setMountProtocolVersion(m_currentOptions->mountProtocolVersion());
                o->setUseSecurityMode(m_currentOptions->useSecurityMode());
                o->setSecurityMode(m_currentOptions->securityMode());
                o->setUseWriteAccess(m_currentOptions->useWriteAccess());
                o->setWriteAccess(m_currentOptions->writeAccess());
#endif
                o->setUseClientProtocolVersions(m_currentOptions->useClientProtocolVersions());
                o->setMinimalClientProtocolVersion(m_currentOptions->minimalClientProtocolVersion());
                o->setMaximalClientProtocolVersion(m_currentOptions->maximalClientProtocolVersion());
                o->setUseSmbPort(m_currentOptions->useSmbPort());
                o->setSmbPort(m_currentOptions->smbPort());
                o->setUseKerberos(m_currentOptions->useKerberos());
                o->setMACAddress(m_currentOptions->macAddress());
                o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
                o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list) {
        m_searchResults << share->url().toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (options->profile() == from)
    {
      options->setProfile(to);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList) {
            if (QString::compare(s->path(), path, Qt::CaseInsensitive) == 0 || QString::compare(s->canonicalPath(), path, Qt::CaseInsensitive) == 0) {
                share = s;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : qAsConst(m_bookmarks)) {
        if (b->url() == url) {
            bookmark = b;
            break;
        } else {
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : qAsConst(d->tempWorkgroupList)) {
            if (!findWorkgroup(workgroup->workgroupName())) {
                addWorkgroup(workgroup);

                // Since this is a new workgroup, no master browser is present.
                HostPtr masterBrowser = HostPtr(new Smb4KHost());
                masterBrowser->setWorkgroupName(workgroup->workgroupName());
                masterBrowser->setHostName(workgroup->masterBrowserName());
                masterBrowser->setIpAddress(workgroup->masterBrowserIpAddress());
                masterBrowser->setIsMasterBrowser(true);

                addHost(masterBrowser);
            } else {
                updateWorkgroup(workgroup);

                // Check if the master browser changed
                QList<HostPtr> members = workgroupMembers(workgroup);

                for (const HostPtr &host : qAsConst(members)) {
                    if (workgroup->masterBrowserName() == host->hostName()) {
                        host->setIsMasterBrowser(true);

                        if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress()) {
                            host->setIpAddress(workgroup->masterBrowserIpAddress());
                        }
                    } else {
                        host->setIsMasterBrowser(false);
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (a->text() == b)
      {
        addAction(a);
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList()) {
            // Only mark the shares inaccessible and DO NOT emit
            // the updated() signal here, because that would freeze
            // the application.
            share->setInaccessible(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares)
  {
    mountShare(share, parent);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.contains("<01>"))
      {        
        ipAddresses << line.trimmed().section(" ", 0, 0).trimmed();
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item)
    {
      shares << item->shareItem();
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
      {
        o->setIpAddress(m_currentOptions->ipAddress());
        o->setUseUser(m_currentOptions->useUser());
        o->setUser(m_currentOptions->user());
        o->setUseGroup(m_currentOptions->useGroup());
        o->setGroup(m_currentOptions->group());
        o->setUseFileMode(m_currentOptions->useFileMode());
        o->setFileMode(m_currentOptions->fileMode());
        o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
        o->setDirectoryMode(m_currentOptions->directoryMode());
#if defined(Q_OS_LINUX)
        o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
        o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
        o->setFileSystemPort(m_currentOptions->fileSystemPort());
        o->setUseSmbMountProtocolVersion(m_currentOptions->useSmbMountProtocolVersion());
        o->setSmbMountProtocolVersion(m_currentOptions->smbMountProtocolVersion());
        o->setUseSecurityMode(m_currentOptions->useSecurityMode());
        o->setSecurityMode(m_currentOptions->securityMode());
        o->setUseWriteAccess(m_currentOptions->useWriteAccess());
        o->setWriteAccess(m_currentOptions->writeAccess());
#endif
        o->setUseSmbPort(m_currentOptions->useSmbPort());
        o->setSmbPort(m_currentOptions->smbPort());
        o->setUseKerberos(m_currentOptions->useKerberos());
        o->setMACAddress(m_currentOptions->macAddress());
        o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
        o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : Smb4KGlobal::mountedSharesList())
      {
        if (mountedShare->url() == object->url())
        {
          shares << mountedShare;
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPreviewDialog *p : d->previewDialogs)
    {
        if (share == p->share())
        {
            dlg = p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHomesUsers *users : qAsConst(allUsers)) {
                xmlWriter.writeStartElement("homes");
                xmlWriter.writeAttribute("profile", users->profile());
                xmlWriter.writeTextElement("host", users->hostName());
                xmlWriter.writeTextElement("workgroup", users->workgroupName());
                xmlWriter.writeTextElement("ip", users->hostIP());
                xmlWriter.writeStartElement("users");
                
                QStringList userList = users->userList();

                for (const QString &user : qAsConst(userList)) {
                    xmlWriter.writeTextElement("user", user);
                }

                xmlWriter.writeEndElement();
                xmlWriter.writeEndElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->unc(), unc, Qt::CaseInsensitive) == 0)
      {
        shares += s;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : m_bookmarks)
  {
    QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
    bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
    bookmarkItem->setIcon(0, bookmark->icon());
    bookmarkItem->setText(0, bookmark->unc());
    bookmarkItem->setText((m_tree_widget->columnCount() - 1), QString("01_%1").arg(bookmark->unc()));
    bookmarkItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDragEnabled);
    
    if (!bookmark->groupName().isEmpty())
    {
      QList<QTreeWidgetItem *> items = m_tree_widget->findItems(bookmark->groupName(), Qt::MatchFixedString|Qt::MatchCaseSensitive, 0);
      
      if (!items.isEmpty())
      {
        items.first()->addChild(bookmarkItem);
        items.first()->setExpanded(true);
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      m_tree_widget->addTopLevelItem(bookmarkItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
        if (mountPoint->mountType() == "cifs" || mountPoint->mountType() == "smb3" || mountPoint->mountType() == "smbfs") {
            // Create a new share and set the mountpoint and filesystem
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(mountPoint->mountedFrom());
            share->setPath(mountPoint->mountPoint());
            share->setMounted(true);

            // Get all mount options
            QStringList mountOptions = mountPoint->mountOptions();

            for (const QString &option : qAsConst(mountOptions)) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setLogin(option.section('=', 1, 1).trimmed());
                }
            }

            // Work around empty usernames
            if (share->login().isEmpty()) {
                share->setLogin("guest");
            }

            d->importedShares << share;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &file : job->files())
    {
        if (file->isHidden() && !Smb4KSettings::previewHiddenItems())
        {
            continue;
        }
    
        list << file;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
  {
    if (url == o->url().toDisplayString())
    {
      m_currentOptions = o;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks) {
            QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

            if (!mountedShares.isEmpty()) {
                for (const SharePtr &share : mountedShares) {
                    if (!share->isForeign()) {
                        mountedBookmarks++;
                        break;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list) {
        //
        // Check if the bookmark label is already in use
        //
        if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label())) {
            Smb4KNotification::bookmarkLabelInUse(bookmark.data());
            bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
        }

        //
        // Check if we have to add the bookmark
        //
        BookmarkPtr existingBookmark = findBookmarkByUrl(bookmark->url());

        if (!existingBookmark) {
            d->bookmarks << bookmark;
            emit bookmarkAdded(bookmark);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : d->tempHostList)
        {
            if (host->workgroupName() == newHost->workgroupName() && host->hostName() == newHost->hostName())
            {
                foundHost = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharePtr s : p->searchResults)
      {
        if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                             s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                             Qt::CaseInsensitive) == 0)
        {
          s->setMountData(share.data());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(d->remounts))
        {
          if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), option->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)) == 0)
          {
            insertShare = false;
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      if (share->url() == object->url())
      {
        Smb4KSynchronizer::self()->synchronize(share);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : qAsConst(m_entriesList)) {
            if (walletEntriesWidget->currentItem()->text() == authInfo->displayString()
                || (walletEntriesWidget->currentItem()->text() == i18n("Default Login") && authInfo->type() == UnknownNetworkItem)) {
                loadDetails(authInfo);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      switch (o->type())
      {
        case Host:
        {
          QListWidgetItem *item = new QListWidgetItem(KDE::icon("network-server"), o->unc(), optionsListWidget, Host);
          item->setData(Qt::UserRole, o->url().toDisplayString());
          break;
        }
        case Share:
        {
          QListWidgetItem *item = new QListWidgetItem(KDE::icon("folder-network"), o->unc(), optionsListWidget, Share);
          item->setData(Qt::UserRole, o->url().toDisplayString());
          break;
        }
        default:
        {
          break;
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares)) {
                if (!share->isForeign()) {
                    qDebug() << "Disabling bookmark" << share->url().toDisplayString();
                    bookmarkAction->setEnabled(false);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : allActions)
    {
      if (a->objectName() == "toplevel_mount_action" && bookmarkGroup.isEmpty())
      {
        a->setEnabled(!allMounted);
        break;
      }
      else if (a->objectName() == QString("%1_mount_action").arg(bookmarkGroup))
      {
        a->setEnabled(!allMounted);
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item && !item->shareItem()->isInaccessible() && !Smb4KSynchronizer::self()->isRunning(item->shareItem())) {
            Smb4KSynchronizer::self()->synchronize(item->shareItem());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(actions)) {
            if (a->data().toMap().value("category").toString() == bookmarkCategory && a->isEnabled()) {
                allMounted = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profile : profiles)
  {
    QAction *action = addAction(profile);
    
    if (action)
    {
      action->setEnabled(Smb4KProfileManager::self()->useProfiles());
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : Smb4KBookmarkHandler::self()->categoryList())
  {
    d->bookmarkCategoryObjects << new Smb4KBookmarkObject(group);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(actionsList)) {
        m_contextMenu->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : qAsConst(oldWalletEntries)) {
            for (Smb4KAuthInfo *newEntry : newWalletEntries) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                        == 0 /* leave the user info here */
                    && QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0) {
                    enable = true;
                    break;
                }
            }

            if (enable) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
          {
            bool foundShare = false;
            
            for (int i = 0; i < hostItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));
              
              if (QString::compare(shareItem->shareItem()->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                   share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                   Qt::CaseInsensitive) == 0)
              {
                foundShare = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundShare)
            {
              (void) new Smb4KNetworkBrowserItem(hostItem, share);
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : qAsConst(userList)) {
                    xmlWriter.writeTextElement("user", user);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mp : mountpoints)
  {
    dir.cd(mp);
    dir.rmdir(dir.canonicalPath());
    
    if (dir.cdUp())
    {
      dir.rmdir(dir.canonicalPath());
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (a->data().toMap().value("text").toString() == b)
      {
        addAction(a);
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIP() && workgroup->hasMasterBrowserIP())
          {
            host->setIP(workgroup->masterBrowserIP());
          }
          else
          {
            // Do nothing
          }          
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : Smb4KGlobal::mountedSharesList()) {
                if (mountedShare->url() == object->url()) {
                    shares << mountedShare;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *host : members)
          {
            bool foundHost = false;
            
            for (int i = 0; i < workgroupItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *hostItem = static_cast<Smb4KNetworkBrowserItem *>(workgroupItem->child(i));
              
              if (hostItem->hostItem()->hostName() == host->hostName())
              {
                foundHost = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundHost)
            {
              (void) new Smb4KNetworkBrowserItem(workgroupItem, host);
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarksList())
  {
    if (QString::compare(group, bookmark->groupName(), Qt::CaseInsensitive) == 0)
    {
      bookmarks << bookmark;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : job->shares())
        {
            if (s->workgroupName() == share->workgroupName() && s->url().matches(share->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
            {
                foundShare = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            // In case of a host, there can only be an exact match.
            if (QString::compare(host->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 Qt::CaseInsensitive) == 0 ||
                (host->url().isEmpty() && host->ipAddress() == o->ipAddress()))
            {
              options = o;
              break;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : qAsConst(*pWorkgroups))
            {
                if (QString::compare(w->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0)
                {
                    foundWorkgroup = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
      
      if (!mountedShares.isEmpty())
      {
        for (const SharePtr &share : mountedShares)
        {
          if (!share->isForeign())
          {
            mountedBookmarks++;
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups)
  {
    if (!group.isEmpty())
    {
      // Group menu entry
      KActionMenu *bookmarkGroupMenu = new KActionMenu(group, menu());
      bookmarkGroupMenu->setIcon(KDE::icon("folder-favorites"));
      QMap<QString,QVariant> menuInfo;
      menuInfo["type"] = "group_menu";
      menuInfo["group"] = group;
      bookmarkGroupMenu->setData(menuInfo);
      addAction(bookmarkGroupMenu);
      
      // Mount action for the group
      QAction *bookmarkGroupMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkGroupMenu->menu());
      QMap<QString,QVariant> groupMountInfo;
      groupMountInfo["type"] = "group_mount";
      groupMountInfo["group"] = group;
      bookmarkGroupMount->setData(groupMountInfo);
      bookmarkGroupMenu->addAction(bookmarkGroupMount);
      m_actions->addAction(bookmarkGroupMount);
      
      // Get the list of bookmarks belonging to this group.
      // Use it to decide whether the group mount action should be enabled 
      // (only if not all bookmarks belonging to this group are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(group);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
      }
      
      bookmarkGroupMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkGroupMenu->addSeparator();
      
      // Insert the sorted bookmarks into the group menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
      {
        o->setIpAddress(m_currentOptions->ipAddress());
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
        o->setUseUser(m_currentOptions->useUser());
        o->setUser(m_currentOptions->user());
        o->setUseGroup(m_currentOptions->useGroup());
        o->setGroup(m_currentOptions->group());
        o->setUseFileMode(m_currentOptions->useFileMode());
        o->setFileMode(m_currentOptions->fileMode());
        o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
        o->setDirectoryMode(m_currentOptions->directoryMode());
#endif
#if defined(Q_OS_LINUX)
        o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
        o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
        o->setFileSystemPort(m_currentOptions->fileSystemPort());
        o->setUseSecurityMode(m_currentOptions->useSecurityMode());
        o->setSecurityMode(m_currentOptions->securityMode());
        o->setUseWriteAccess(m_currentOptions->useWriteAccess());
        o->setWriteAccess(m_currentOptions->writeAccess());
#endif
        o->setUseSmbPort(m_currentOptions->useSmbPort());
        o->setSmbPort(m_currentOptions->smbPort());
        o->setUseKerberos(m_currentOptions->useKerberos());
        o->setMACAddress(m_currentOptions->macAddress());
        o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
        o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPreviewDialog *p : qAsConst(d->previewDialogs)) {
        if (share == p->share()) {
            dlg = p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    // Do not process null pointers
    if (!share)
    {
      continue;
    }
    else
    {
      // Do nothing
    }
    
    // Add the display name to the list
    displayNames << share->displayString();
    
    // Create the share menu
    KActionMenu *shareMenu = new KActionMenu(share->displayString(), menu());
    shareMenu->setIcon(share->icon());
    
    QMap<QString,QVariant> data;
    data["text"] = share->displayString();
    
    shareMenu->setData(data);
    m_menus->addAction(shareMenu);
    
    // Add the unmount action to the menu
    QAction *unmount = new QAction(KDE::icon("media-eject"), i18n("Unmount"), shareMenu->menu());
    
    QMap<QString,QVariant> unmountData;
    unmountData["type"] = "unmount";
    unmountData["mountpoint"] = share->path();
    
    unmount->setData(unmountData);
    unmount->setEnabled(!share->isForeign() || Smb4KSettings::unmountForeignShares());
    shareMenu->addAction(unmount);
    m_actions->addAction(unmount);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the bookmark action to the menu
    QAction *addBookmark = new QAction(KDE::icon("bookmark-new"), i18n("Add Bookmark"), shareMenu->menu());
    
    QMap<QString,QVariant> bookmarkData;
    bookmarkData["type"] = "bookmark";
    bookmarkData["mountpoint"] = share->path();
    
    addBookmark->setData(bookmarkData);
    shareMenu->addAction(addBookmark);
    m_actions->addAction(addBookmark);
    
    // Add the synchronization action to the menu
    QAction *synchronize = new QAction(KDE::icon("folder-sync"), i18n("Synchronize"), shareMenu->menu());
    
    QMap<QString,QVariant> syncData;
    syncData["type"] = "sync";
    syncData["mountpoint"] = share->path();
    
    synchronize->setData(syncData);
    synchronize->setEnabled(!QStandardPaths::findExecutable("rsync").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(synchronize);
    m_actions->addAction(synchronize);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the Open with Konsole action to the menu
    QAction *konsole = new QAction(KDE::icon("utilities-terminal"), i18n("Open with Konsole"), shareMenu->menu());
    
    QMap<QString,QVariant> konsoleData;
    konsoleData["type"] = "konsole";
    konsoleData["mountpoint"] = share->path();
    
    konsole->setData(konsoleData);
    konsole->setEnabled(!QStandardPaths::findExecutable("konsole").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(konsole);
    m_actions->addAction(konsole);
    
    // Add the Open with Filemanager action to the menu
    QAction *filemanager = new QAction(KDE::icon("system-file-manager"), i18n("Open with File Manager"), shareMenu->menu());
    
    QMap<QString,QVariant> fmData;
    fmData["type"] = "filemanager";
    fmData["mountpoint"] = share->path();
    
    filemanager->setData(fmData);
    filemanager->setEnabled(!share->isInaccessible());
    shareMenu->addAction(filemanager);
    m_actions->addAction(filemanager);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
  {
    if (QString::compare(bookmark->profile(), from, Qt::CaseSensitive) == 0)
    {
      bookmark->setProfile(to);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList())
          {
            lookupShares(host);
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(m_categories)) {
        if (!category.isEmpty()) {
            QTreeWidgetItem *categoryItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
            categoryItem->setIcon(0, KDE::icon("folder-bookmark"));
            categoryItem->setText(0, category);
            categoryItem->setText((treeWidget->columnCount() - 1), QString("00_%1").arg(category));
            categoryItem->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsDropEnabled);
            treeWidget->addTopLevelItem(categoryItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->mountedSharesList)
      {
        if (!s->isForeign())
        {
          p->onlyForeignShares = false;
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (QString::compare(s->unc(), unc, Qt::CaseInsensitive) == 0 &&
        (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0))
    {
      share = s;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            // In case of a host, there can only be an exact match.
            if (QString::compare(host->unc(), o->unc(), Qt::CaseInsensitive) == 0 || (host->unc().isEmpty() && host->ipAddress() == o->ipAddress()))
            {
              options = o;
              break;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            // In case of a host, there can only be an exact match.
            if (QString::compare(host->unc(), o->unc(), Qt::CaseInsensitive) == 0 || (host->unc().isEmpty() && host->ip() == o->ip()))
            {
              options = o;
              break;
            }
            else
            {
              // Do nothing
            }
          }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KDNSSD::RemoteService::Ptr service) {
            switch (m_process)
            {
              case LookupDomains:
              {
                //
                // Check if the workgroup/domain is already known
                // 
                bool foundWorkgroup = false;
                
                for (const WorkgroupPtr &w : qAsConst(m_workgroups))
                {
                  if (QString::compare(w->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0)
                  {
                    foundWorkgroup = true;
                    break;
                  }
                }
                
                //
                // If the workgroup is not known yet, add it to the list
                // 
                if (!foundWorkgroup)
                {
                  //
                  // Create the workgroup item
                  // 
                  WorkgroupPtr workgroup = WorkgroupPtr(new Smb4KWorkgroup());
                  
                  //
                  // Set the _DNS-SD_ domain name
                  // 
                  workgroup->setWorkgroupName(service->domain());
                  
                  //
                  // Tell the program that the workgroup was discovered by DNS-SD
                  // 
                  workgroup->setDnsDiscovered(true);
                  
                  //
                  // Add the workgroup
                  // 
                  m_workgroups << workgroup;
                }
                break;
              }
              case LookupDomainMembers:
              {
                //
                // Check if the server is already known
                // 
                bool foundServer = false;
                
                for (const HostPtr &h : qAsConst(m_hosts))
                {
                  if (QString::compare(h->hostName(), service->serviceName(), Qt::CaseInsensitive) == 0 &&
                      QString::compare(h->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0)
                  {
                    foundServer = true;
                    break;
                  }
                }
                
                //
                // If the server is not known yet, add it to the list
                // 
                if (!foundServer)
                {
                  //
                  // Create the host item
                  // 
                  HostPtr host = HostPtr(new Smb4KHost());
                  
                  //
                  // Set the _DNS-SD_ host name
                  // 
                  host->setHostName(service->serviceName());
                  
                  //
                  // Set the _DNS-SD_ domain name
                  // 
                  host->setWorkgroupName(service->domain());
                  
                  //
                  // Tell the program that the workgroup was discovered by DNS-SD
                  //                   
                  host->setDnsDiscovered(true);
                  
                  // 
                  // Lookup IP address
                  // 
                  QHostAddress address = lookupIpAddress(service->serviceName());
          
                  // 
                  // Process the IP address. 
                  // 
                  if (!address.isNull())
                  {
                    host->setIpAddress(address);
                  }
                  
                  //
                  // Add the host
                  // 
                  m_hosts << host;
                }
                
                break;
              }
              default:
              {
                break;
              }
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (Smb4KSettings::useProfiles() && options->profile() != Smb4KProfileManager::self()->activeProfile())
    {
      continue;
    }

    if (options->hasOptions(withoutRemountOnce))
    {
      optionsList << options;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    if (!m_categories.contains(bookmark->categoryName()))
    {
      m_categories << bookmark->categoryName();
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->sharesList)) {
        if (QString::compare(s->hostName(), host->hostName(), Qt::CaseInsensitive) == 0
            && QString::compare(s->workgroupName(), host->workgroupName(), Qt::CaseInsensitive) == 0) {
            shares += s;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options) {
                if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName()) {
                    o->setIpAddress(options->ipAddress());
                    o->setUseUser(options->useUser());
                    o->setUser(options->user());
                    o->setUseGroup(options->useGroup());
                    o->setGroup(options->group());
                    o->setUseFileMode(options->useFileMode());
                    o->setFileMode(options->fileMode());
                    o->setUseDirectoryMode(options->useDirectoryMode());
                    o->setDirectoryMode(options->directoryMode());
#if defined(Q_OS_LINUX)
                    o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
                    o->setUseFileSystemPort(options->useFileSystemPort());
                    o->setFileSystemPort(options->fileSystemPort());
                    o->setUseMountProtocolVersion(options->useMountProtocolVersion());
                    o->setMountProtocolVersion(options->mountProtocolVersion());
                    o->setUseSecurityMode(options->useSecurityMode());
                    o->setSecurityMode(options->securityMode());
                    o->setUseWriteAccess(options->useWriteAccess());
                    o->setWriteAccess(options->writeAccess());
#endif
                    o->setUseSmbPort(options->useSmbPort());
                    o->setSmbPort(options->smbPort());
                    o->setUseKerberos(options->useKerberos());
                    o->setMACAddress(options->macAddress());
                    o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
                    o->setWOLSendBeforeMount(options->wolSendBeforeMount());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : profiles)
  {
    Smb4KProfileObject *profile = new Smb4KProfileObject();
    profile->setProfileName(p);
    
    if (QString::compare(p, Smb4KProfileManager::self()->activeProfile()) == 0)
    {
      profile->setActiveProfile(true);
    }
    else
    {
      profile->setActiveProfile(false);
    }
    
    d->profileObjects << profile;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      // FIXME: Check if the bookmarked share has already been mounted.
      SharePtr share = SharePtr(new Smb4KShare());
      share->setHostName(bookmark->hostName());
      share->setShareName(bookmark->shareName());
      share->setWorkgroupName(bookmark->workgroupName());
      share->setHostIP(bookmark->hostIP());
      share->setLogin(bookmark->login());
      mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->workgroupObjects)
        {
          if (url == obj->url())
          {
            object = obj;
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : hosts) {
            Smb4KNetworkBrowserItem *tempHost = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (tempHost->type() == Host && tempHost->hostItem()->workgroupName() == host->workgroupName()) {
                hostItem = tempHost;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : job->workgroups())
    {
      if (w->workgroupName() == workgroup->workgroupName())
      {
        found = true;
        break;
      }
      else
      {
        continue;
      }        
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : job->shares())
    {
      if (s->workgroupName() == share->workgroupName() && s->url().matches(share->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
      {
        found = true;
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    QAction *bookmarkAction = 0;
        
    if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), menu());
      bookmarkAction->setObjectName(bookmark->url().toDisplayString());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["url"] = bookmark->url();
      bookmarkInfo["text"] = bookmark->label();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->label();
    }
    else
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), menu());
      bookmarkAction->setObjectName(bookmark->url().toDisplayString());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["url"] = bookmark->url();
      bookmarkInfo["text"] = bookmark->displayString();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->displayString();
    }
        
    QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
    if (!mountedShares.isEmpty())
    {
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          bookmarkAction->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
  {
    // Unmount the share
    unmountShare(share, silent);
    
    // Wait for 50 ms so we can act on the networkShareRemoved() 
    // signal and we do not trigger a busy error from umount
    QTest::qWait(TIMEOUT);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems) {
            Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (browserItem && browserItem->shareItem()->isMounted()) {
                mounted << browserItem->shareItem();
            } else if (browserItem && !browserItem->shareItem()->isMounted()) {
                unmounted << browserItem->shareItem();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList)
    {
      if (Smb4KSettings::useProfiles())
      {
        options->setProfile(Smb4KProfileManager::self()->activeProfile());
      }
      
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
      if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
#else
      if (options->hasOptions())
#endif
      {
        d->options << options;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharePtr searchResult : searchResults())
      {
        if (searchResult->url().matches(share->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
        {
          searchResult->resetMountData();
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::mountedSharesList())
    {
      if (share->url() == object->url())
      {
        Smb4KSynchronizer::self()->synchronize(share);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : job->files())
  {
    if (f->isHidden() && !Smb4KSettings::previewHiddenItems())
    {
      continue;
    }
    else
    {
      // Do nothing
    }
    
    list << f;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mounted)
          {
            if (!share->isForeign())
            {
              bookmark->setEnabled(false);
              break;
            }
            else
            {
              continue;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_menus->actions())
    {
      if (action->data().toMap().value("text").toString() == name)
      {
        addAction(action);
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarksList()) {
        if (categoryName == bookmark->categoryName()) {
            bookmarks << bookmark;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : qAsConst(allDevices)) {
        if (device.isDeviceInterface(Solid::DeviceInterface::NetworkShare)) {
            d->udis << device.udi();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList())
  {
    if (share->shareName().contains(item, Qt::CaseInsensitive))
    {
      results << share;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : allCategories) {
        if (!category.isEmpty()) {
            // Category menu entry
            KActionMenu *bookmarkCategoryMenu = new KActionMenu(category, menu());
            bookmarkCategoryMenu->setIcon(KDE::icon("folder-favorites"));
            QMap<QString, QVariant> menuInfo;
            menuInfo["type"] = "category_menu";
            menuInfo["category"] = category;
            bookmarkCategoryMenu->setData(menuInfo);
            addAction(bookmarkCategoryMenu);

            // Mount action for the category
            QAction *bookmarkCategoryMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkCategoryMenu->menu());
            QMap<QString, QVariant> categoryMountInfo;
            categoryMountInfo["type"] = "category_mount";
            categoryMountInfo["category"] = category;
            bookmarkCategoryMount->setData(categoryMountInfo);
            bookmarkCategoryMenu->addAction(bookmarkCategoryMount);
            m_actions->addAction(bookmarkCategoryMount);

            // Get the list of bookmarks belonging to this category.
            // Use it to decide whether the category mount action should be enabled
            // (only if not all bookmarks belonging to this category are mounted) and
            // to sort the bookmarks.
            QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(category);
            QStringList sortedBookmarks;
            int mountedBookmarks = 0;

            for (const BookmarkPtr &bookmark : bookmarks) {
                QAction *bookmarkAction = 0;

                if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty()) {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->label();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->label();
                } else {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->displayString();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->displayString();
                }

                QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

                if (!mountedShares.isEmpty()) {
                    for (const SharePtr &share : mountedShares) {
                        if (!share->isForeign()) {
                            bookmarkAction->setEnabled(false);
                            mountedBookmarks++;
                            break;
                        }
                    }
                }
            }

            bookmarkCategoryMount->setEnabled(mountedBookmarks != bookmarks.size());
            sortedBookmarks.sort();

            // Add a separator
            bookmarkCategoryMenu->addSeparator();

            // Insert the sorted bookmarks into the category menu
            QList<QAction *> actions = m_bookmarks->actions();

            for (const QString &b : sortedBookmarks) {
                for (QAction *a : actions) {
                    if (a->text() == b) {
                        bookmarkCategoryMenu->addAction(a);
                        break;
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList)
    {
      //
      // Create a auth info object
      // 
      Smb4KAuthInfo *authInfo = new Smb4KAuthInfo();
      
      //
      // Read the authentication information from the wallet
      // 
      QMap<QString, QString> authInfoMap;
      d->wallet->readMap(entry, authInfoMap);
      
      //
      // Process the entry
      // 
      if (entry == "DEFAULT_LOGIN")
      {
        //
        // Default login
        // 
        authInfo->setUserName(authInfoMap.value("Login"));
        authInfo->setPassword(authInfoMap.value("Password"));
      }
      else
      {
        //
        // Entry for a specific URL
        // 
        authInfo->setUrl(entry);
        authInfo->setIpAddress(authInfoMap.value("IP Address"));
        authInfo->setWorkgroupName(authInfoMap.value("Workgroup"));
        authInfo->setUserName(authInfoMap.value("Login"));
        authInfo->setPassword(authInfoMap.value("Password"));
      }
      
      entries << authInfo;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(allActions)) {
                if (a->data().toMap().value("type").toString() == "category_mount" && a->data().toMap().value("category").toString() == bookmarkCategory) {
                    a->setEnabled(!allMounted);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (a->data().toMap().value("text").toString() == b)
      {
        addAction(a);
        break;
      }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
    import(true);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shareDir : shareDirs)
    {
      dir.cd(shareDir);
      mountpoints << dir.absolutePath();
      dir.cdUp();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
                    if (a->text() == b) {
                        bookmarkCategoryMenu->addAction(a);
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOut)
  {
    if (!line.contains("added interface", Qt::CaseInsensitive) &&
        !line.contains("tdb(", Qt::CaseInsensitive) &&
        !line.contains("Got a positive", Qt::CaseInsensitive) &&
        !line.contains("error connecting", Qt::CaseInsensitive) &&
        !line.isEmpty())
    {
      if (!line.contains("\\") && !line.trimmed().isEmpty())
      {
        workgroup_name = line.trimmed();
        continue;
      }
      else if (line.count("\\") == 3)
      {
        QString unc = line.trimmed().section('\t', 0, 0).trimmed().replace("\\", "/");
        QString comment = line.trimmed().section('\t', 1, -1).trimmed();

        if (unc.contains(m_string, Qt::CaseInsensitive))
        {
          SharePtr share = SharePtr(new Smb4KShare());
          share->setURL(unc);
          share->setComment(comment);
          share->setWorkgroupName(workgroup_name);

          emit result(share);
          share.clear();
        }
        else
        {
          // Do nothing
        }
        continue;
      }
      else
      {
        continue;
      }
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : d->tempWorkgroupList) {
            if (workgroup->workgroupName() == newWorkgroup->workgroupName()) {
                foundWorkgroup = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : mountedShares)
    {
      if (!s->isForeign())
      {
        isMounted = true;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems)
    {
      Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (browserItem && browserItem->shareItem()->isMounted())
      {
        mounted << browserItem->shareItem();
      }
      else if (browserItem && !browserItem->shareItem()->isMounted())
      {
        unmounted << browserItem->shareItem();
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
  {
    //
    // Mount the share
    // 
    mountShare(share);
    
    // Wait for 50 ms so we can act on the networkShareAdded() 
    // signal and we do not trigger a busy error from mount
    QTest::qWait(TIMEOUT);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entriesList)
  {
    switch (authInfo->type())
    {
      case UnknownNetworkItem:
      {
        (void) new QListWidgetItem(KDE::icon("dialog-password"), i18n("Default Login"), walletEntriesWidget);
        break;
      }
      default:
      {
        (void) new QListWidgetItem(KDE::icon("dialog-password"), authInfo->displayString(), walletEntriesWidget);
        break;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : qAsConst(d->shareObjects)) {
                if (url == obj->url()) {
                    object = obj;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName())
        {
          o->setIpAddress(options->ipAddress());
          o->setUseUser(options->useUser());
          o->setUser(options->user());
          o->setUseGroup(options->useGroup());
          o->setGroup(options->group());
          o->setUseFileMode(options->useFileMode());
          o->setFileMode(options->fileMode());
          o->setUseDirectoryMode(options->useDirectoryMode());
          o->setDirectoryMode(options->directoryMode());
#if defined(Q_OS_LINUX)
          o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
          o->setUseFileSystemPort(options->useFileSystemPort());
          o->setFileSystemPort(options->fileSystemPort());
          o->setUseSecurityMode(options->useSecurityMode());
          o->setSecurityMode(options->securityMode());
          o->setUseWriteAccess(options->useWriteAccess());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUseSmbPort(options->useSmbPort());
          o->setSmbPort(options->smbPort());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : unmountedShares)
    {
      // 
      // Remove the mountpoint if the share is not a foreign one
      // 
      if (!share->isForeign())
      {
        QDir dir;
        dir.cd(share->canonicalPath());
        dir.rmdir(dir.canonicalPath());
          
        if (dir.cdUp())
        {
          dir.rmdir(dir.canonicalPath());
        }
      }
      
      //
      // Mark it as unmounted
      // 
      share->setMounted(false);
      
      // 
      // Copy the share
      // 
      SharePtr unmountedShare = share;
        
      // 
      // Remove the share from the global list and notify the program
      // 
      removeMountedShare(share);
      emit unmounted(unmountedShare);
      
      //
      // Report the unmounted share to the user if it is a single one
      // 
      if (!isRunning() && d->newlyUnmounted == 1)
      {
        Smb4KNotification::shareUnmounted(unmountedShare);
      }
      
      unmountedShare.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : mountedSharesList())
  {
    for (const SharePtr &importedShare : d->importedShares)
    {
      // Check the mountpoint, since that one is unique. We will only use
      // Smb4KShare::path(), so that we do not run into trouble if a share 
      // is inaccessible.
      if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
      {
        found = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
    
    if (!found)
    {
      // Remove the mountpoint if the share is not a foreign one
      if (!mountedShare->isForeign())
      {
        QDir dir;
        dir.cd(mountedShare->canonicalPath());
        dir.rmdir(dir.canonicalPath());
        
        if (dir.cdUp())
        {
          dir.rmdir(dir.canonicalPath());
        }
        else
        {
          // Do nothing
        }        
      }
      else
      {
        // Do nothing
      }
      
      mountedShare->setMounted(false);
      unmountedShares << mountedShare;
    }
    else
    {
      // Do nothing
    }
    
    found = false;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress())
          {
            host->setIpAddress(workgroup->masterBrowserIpAddress());
          }
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : qAsConst(members)) {
                    if (workgroup->masterBrowserName() == host->hostName()) {
                        host->setIsMasterBrowser(true);

                        if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress()) {
                            host->setIpAddress(workgroup->masterBrowserIpAddress());
                        }
                    } else {
                        host->setIsMasterBrowser(false);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList) {
            if (o->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash)
                == url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash)) {
                options = o;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &hostDir : hostDirs)
  {
    dir.cd(hostDir);
    
    QStringList shareDirs = dir.entryList(QDir::Dirs|QDir::NoDotAndDotDot, QDir::NoSort);
    
    for (const QString &shareDir : shareDirs)
    {
      dir.cd(shareDir);
      mountpoints << dir.absolutePath();
      dir.cdUp();
    }
    
    dir.cdUp();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
      {
        o->setIpAddress(m_currentOptions->ipAddress());
        o->setUseUser(m_currentOptions->useUser());
        o->setUser(m_currentOptions->user());
        o->setUseGroup(m_currentOptions->useGroup());
        o->setGroup(m_currentOptions->group());
        o->setUseFileMode(m_currentOptions->useFileMode());
        o->setFileMode(m_currentOptions->fileMode());
        o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
        o->setDirectoryMode(m_currentOptions->directoryMode());
#if defined(Q_OS_LINUX)
        o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
        o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
        o->setFileSystemPort(m_currentOptions->fileSystemPort());
        o->setUseSecurityMode(m_currentOptions->useSecurityMode());
        o->setSecurityMode(m_currentOptions->securityMode());
        o->setUseWriteAccess(m_currentOptions->useWriteAccess());
        o->setWriteAccess(m_currentOptions->writeAccess());
#endif
        o->setUseSmbPort(m_currentOptions->useSmbPort());
        o->setSmbPort(m_currentOptions->smbPort());
        o->setUseKerberos(m_currentOptions->useKerberos());
        o->setMACAddress(m_currentOptions->macAddress());
        o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
        o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList)
      {
        if (networkItem->type() == Host)
        {
          if (QString::compare(entry, networkItem->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 ||
              QString::compare(entry, networkItem->url().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
          {
            d->wallet->readMap(entry, authInfoMap);
            break;
          }
        }
        else if (networkItem->type() == Share)
        {
          //
          // Cast the network item. We need some share specific info
          // 
          SharePtr share = networkItem.staticCast<Smb4KShare>();
          
          if (share)
          {
            //
            // Process normal and 'homes' shares differently
            // 
            if (!share->isHomesShare())
            {
              //
              // Prefer the credentials for the share. Use the ones for the 
              // host as fallback.
              //
              if (QString::compare(entry, share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 ||
                  QString::compare(entry, share->url().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
                break;
              }
              else if (QString::compare(entry, share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0 ||
                       QString::compare(entry, share->url().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
              }
            }
            else
            {
              //
              // Prefer the credentials for the share. Use the ones for the 
              // host as fallback.
              //
              if (QString::compare(entry, share->homeUrl().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 ||
                  QString::compare(entry, share->homeUrl().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
                break;
              }
              else if (QString::compare(entry, share->homeUrl().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0 ||
                       QString::compare(entry, share->homeUrl().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
              }
            }
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups)
  {
    if (!group.isEmpty())
    {
      // Group menu entry
      KActionMenu *bookmarkGroupMenu = new KActionMenu(group, m_groups);
      bookmarkGroupMenu->setIcon(KDE::icon("folder-favorites"));
      QMap<QString,QVariant> menuInfo;
      menuInfo["type"] = "group_menu";
      menuInfo["group"] = group;
      bookmarkGroupMenu->setData(menuInfo);
      m_action_collection->addAction(QString("group_%1").arg(group), bookmarkGroupMenu);
      addAction(bookmarkGroupMenu);
      
      // Mount action for the group
      QAction *bookmarkGroupMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), m_groups);
      QMap<QString,QVariant> groupMountInfo;
      groupMountInfo["type"] = "group_mount";
      groupMountInfo["group"] = group;
      bookmarkGroupMount->setData(groupMountInfo);
      m_action_collection->addAction(QString("%1_mount_action").arg(group));
      bookmarkGroupMenu->addAction(bookmarkGroupMount);
      
      // Get the list of bookmarks belonging to this group.
      // Use it to decide whether the group mount action should be enabled 
      // (only if not all bookmarks belonging to this group are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(group);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          sortedBookmarks << bookmark->label();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), m_bookmarks);
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          sortedBookmarks << bookmark->displayString();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
      
      bookmarkGroupMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkGroupMenu->addSeparator();
      
      // Insert the sorted bookmarks into the group menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
    if (!coreIsRunning())
    {
      m_progress_bar->setVisible(false);
      m_progress_bar->reset();
      statusBar()->showMessage(i18n("Done."), 2000);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
#if defined(Q_OS_LINUX)
        if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0
            && QString::compare(mountPoint->mountType(), "cifs", Qt::CaseInsensitive) == 0)
#else
        if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0
            && QString::compare(mountPoint->mountType(), "smbfs", Qt::CaseInsensitive) == 0)
#endif
        {
            mountPointOk = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks)
  {
    for (QAction *a : actions)
    {
      if (a->data().toMap().value("text").toString() == b)
      {
        addAction(a);
        break;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : users->users())
        {
          xmlWriter.writeTextElement("user", user);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : hostInfo.addresses())
            {
                // We only use global addresses.
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
                if (addr.isGlobal())
#else
                if (!addr.isLoopback() && !addr.isMulticast())
#endif
                {
                    if (addr.protocol() == QAbstractSocket::IPv4Protocol)
                    {
                        ipAddress = addr;
                        break;
                    }
                    else if (addr.protocol() == QAbstractSocket::IPv6Protocol)
                    {
                        // FIXME: Use the right address here.
                        ipAddress = addr;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
  {
    if (url == o->url().toString())
    {
      m_currentOptions = o;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &option : options)
    {
      //
      // Skip one time remount shares, if needed
      // 
      if (option->remount() == Smb4KCustomOptions::RemountOnce && !Smb4KMountSettings::remountShares())
      {
        continue;
      }
      
      //
      // Check which share has to be remounted
      // 
      QList<SharePtr> mountedShares = findShareByUrl(option->url());
      bool remountShare = true;
      
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          remountShare = false;
          break;
        }          
      }
      
      //
      // Insert the share to the list of remounts
      // 
      if (remountShare)
      {
        bool insertShare = true;
        
        for (const SharePtr &share : d->remounts)
        {
          if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), option->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)) == 0)
          {
            insertShare = false;
            break;
          }
        }
        
        if (insertShare)
        {
          SharePtr share = SharePtr(new Smb4KShare());
          share->setUrl(option->url());
          share->setWorkgroupName(option->workgroupName());
          share->setHostIpAddress(option->ipAddress());
          
          if (share->url().isValid() && !share->url().isEmpty())
          {
            d->remounts << share;
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks) {
        QAction *bookmarkAction = 0;

        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty()) {
            bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), menu());
            bookmarkAction->setObjectName(bookmark->url().toDisplayString());
            QMap<QString, QVariant> bookmarkInfo;
            bookmarkInfo["type"] = "bookmark";
            bookmarkInfo["category"] = "";
            bookmarkInfo["url"] = bookmark->url();
            bookmarkInfo["text"] = bookmark->label();
            bookmarkAction->setData(bookmarkInfo);
            m_bookmarks->addAction(bookmarkAction);
            sortedBookmarks << bookmark->label();
        } else {
            bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), menu());
            bookmarkAction->setObjectName(bookmark->url().toDisplayString());
            QMap<QString, QVariant> bookmarkInfo;
            bookmarkInfo["type"] = "bookmark";
            bookmarkInfo["category"] = "";
            bookmarkInfo["url"] = bookmark->url();
            bookmarkInfo["text"] = bookmark->displayString();
            bookmarkAction->setData(bookmarkInfo);
            m_bookmarks->addAction(bookmarkAction);
            sortedBookmarks << bookmark->displayString();
        }

        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

        if (!mountedShares.isEmpty()) {
            for (const SharePtr &share : mountedShares) {
                if (!share->isForeign()) {
                    qDebug() << "Disabling bookmark" << share->url().toDisplayString();
                    bookmarkAction->setEnabled(false);
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHomesUsers *users : allUsers) {
                xmlWriter.writeStartElement("homes");

                // FIXME: Remove this block with Smb4K > 2.0 and use the commented line below.
                // This block was introduced for migration, because the default profile
                // (i.e. use of no profiles) was not empty but named "Default"...
                if (!Smb4KProfileManager::self()->useProfiles()) {
                    xmlWriter.writeAttribute("profile", Smb4KSettings::self()->activeProfile());
                } else {
                    xmlWriter.writeAttribute("profile", users->profile());
                }
                // xmlWriter.writeAttribute("profile", users->profile());
                xmlWriter.writeTextElement("host", users->hostName());
                xmlWriter.writeTextElement("workgroup", users->workgroupName());
                xmlWriter.writeTextElement("ip", users->hostIP());
                xmlWriter.writeStartElement("users");

                for (const QString &user : users->users()) {
                    xmlWriter.writeTextElement("user", user);
                }

                xmlWriter.writeEndElement();
                xmlWriter.writeEndElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(actions)) {
            if (a->data().toMap().value("text").toString() == b) {
                addAction(a);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks) {
        for (QAction *a : actions) {
            if (a->data().toMap().value("text").toString() == b) {
                addAction(a);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(shares)) {
                    bool foundShare = false;

                    for (int i = 0; i < hostItem->childCount(); ++i) {
                        Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));

                        if (shareItem->shareItem()->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort)
                            == share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                            foundShare = true;
                            break;
                        }
                    }

                    if (!foundShare) {
                        (void)new Smb4KNetworkBrowserItem(hostItem, share);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName())
        {
          o->setIpAddress(options->ipAddress());
          o->setUseUser(options->useUser());
          o->setUser(options->user());
          o->setUseGroup(options->useGroup());
          o->setGroup(options->group());
          o->setUseFileMode(options->useFileMode());
          o->setFileMode(options->fileMode());
          o->setUseDirectoryMode(options->useDirectoryMode());
          o->setDirectoryMode(options->directoryMode());
#if defined(Q_OS_LINUX)
          o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
          o->setUseFileSystemPort(options->useFileSystemPort());
          o->setFileSystemPort(options->fileSystemPort());
          o->setUseMountProtocolVersion(options->useMountProtocolVersion());
          o->setMountProtocolVersion(options->mountProtocolVersion());
          o->setUseSecurityMode(options->useSecurityMode());
          o->setSecurityMode(options->securityMode());
          o->setUseWriteAccess(options->useWriteAccess());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUseSmbPort(options->useSmbPort());
          o->setSmbPort(options->smbPort());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::sharesList()) {
                if (share->url() == object->url()) {
                    Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(share);
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList()) {
        // Do not process null pointers
        if (!share) {
            continue;
        }

        // Add the display name to the list
        displayNames << share->displayString();

        // Create the share menu
        KActionMenu *shareMenu = new KActionMenu(share->displayString(), menu());
        shareMenu->setIcon(share->icon());

        QMap<QString, QVariant> data;
        data["text"] = share->displayString();

        shareMenu->setData(data);
        m_menus->addAction(shareMenu);

        // Add the unmount action to the menu
        QAction *unmount = new QAction(KDE::icon("media-eject"), i18n("Unmount"), shareMenu->menu());

        QMap<QString, QVariant> unmountData;
        unmountData["type"] = "unmount";
        unmountData["mountpoint"] = share->path();

        unmount->setData(unmountData);
        unmount->setEnabled(!share->isForeign() || Smb4KMountSettings::unmountForeignShares());
        shareMenu->addAction(unmount);
        m_actions->addAction(unmount);

        // Add a separator
        shareMenu->addSeparator();

        // Add the bookmark action to the menu
        QAction *addBookmark = new QAction(KDE::icon("bookmark-new"), i18n("Add Bookmark"), shareMenu->menu());

        QMap<QString, QVariant> bookmarkData;
        bookmarkData["type"] = "bookmark";
        bookmarkData["mountpoint"] = share->path();

        addBookmark->setData(bookmarkData);
        shareMenu->addAction(addBookmark);
        m_actions->addAction(addBookmark);

        // Add the synchronization action to the menu
        QAction *synchronize = new QAction(KDE::icon("folder-sync"), i18n("Synchronize"), shareMenu->menu());

        QMap<QString, QVariant> syncData;
        syncData["type"] = "sync";
        syncData["mountpoint"] = share->path();

        synchronize->setData(syncData);
        synchronize->setEnabled(!QStandardPaths::findExecutable("rsync").isEmpty() && !share->isInaccessible());
        shareMenu->addAction(synchronize);
        m_actions->addAction(synchronize);

        // Add a separator
        shareMenu->addSeparator();

        // Add the Open with Konsole action to the menu
        QAction *konsole = new QAction(KDE::icon("utilities-terminal"), i18n("Open with Konsole"), shareMenu->menu());

        QMap<QString, QVariant> konsoleData;
        konsoleData["type"] = "konsole";
        konsoleData["mountpoint"] = share->path();

        konsole->setData(konsoleData);
        konsole->setEnabled(!QStandardPaths::findExecutable("konsole").isEmpty() && !share->isInaccessible());
        shareMenu->addAction(konsole);
        m_actions->addAction(konsole);

        // Add the Open with Filemanager action to the menu
        QAction *filemanager = new QAction(KDE::icon("system-file-manager"), i18n("Open with File Manager"), shareMenu->menu());

        QMap<QString, QVariant> fmData;
        fmData["type"] = "filemanager";
        fmData["mountpoint"] = share->path();

        filemanager->setData(fmData);
        filemanager->setEnabled(!share->isInaccessible());
        shareMenu->addAction(filemanager);
        m_actions->addAction(filemanager);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
    {
      if (o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash) == 
          url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash))
      {
        options = o;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_active_part->actionCollection()->actions())
  {
    if (action)
    {
      if (QString::compare(action->objectName(), "bookmark_action") == 0)
      {
        actionCollection()->action("bookmark_action")->setEnabled(action->isEnabled());
        connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
        continue;
      }
      else if (QString::compare(action->objectName(), "filemanager_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "konsole_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "icon_view_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "list_view_action") == 0)
      {
        continue;
      }
      else
      {
        // Do nothing
      }

      dynamic_list << action;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
    {
      // NOTE: Since also user provided URLs can be bookmarked, we cannot use
      // QUrl::matches() here, because it does not allow for case insensitive 
      // comparison.
      if (QString::compare(url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort), b->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
      {
        bookmark = b;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress())
          {
            host->setIpAddress(workgroup->masterBrowserIpAddress());
          }
          else
          {
            // Do nothing
          }          
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    QAction *bookmarkAction = 0;
        
    if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), menu());
      bookmarkAction->setObjectName(bookmark->unc());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["unc"] = bookmark->unc();
      bookmarkInfo["text"] = bookmark->label();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->label();
    }
    else
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), menu());
      bookmarkAction->setObjectName(bookmark->unc());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["unc"] = bookmark->unc();
      bookmarkInfo["text"] = bookmark->displayString();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->displayString();
    }
        
    QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
    if (!mountedShares.isEmpty())
    {
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          bookmarkAction->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item && !item->shareItem()->isInaccessible()) {
            openShare(item->shareItem(), FileManager);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
      {
        shares << s;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    // FIXME: Check if the bookmarked share has already been mounted.
    SharePtr share = SharePtr(new Smb4KShare());
    share->setHostName(bookmark->hostName());
    share->setShareName(bookmark->shareName());
    share->setWorkgroupName(bookmark->workgroupName());
    share->setHostIP(bookmark->hostIP());
    share->setLogin(bookmark->login());
    mounts << share;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->mountedSharesList)
  {
    if (s->isInaccessible())
    {
      inaccessibleShares += s;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : unmountedShares)
      {
        emit unmounted(share);
        removeMountedShare(share);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_menus->actions()) {
                if (action->data().toMap().value("text").toString() == displayStringBefore) {
                    insertAction(action, shareMenu);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : list)
  {
    allBookmarks << new Smb4KBookmark(*bookmark);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (options->profile() == from)
    {
      options->setProfile(to);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
  {
    //
    // Printer shares cannot be bookmarked
    //
    if (share->isPrinter())
    {
      Smb4KNotification::cannotBookmarkPrinter(share);
      continue;
    }
    
    //
    // Process homes shares
    //
    if (share->isHomesShare())
    {
      if (!Smb4KHomesSharesHandler::self()->specifyUser(share, true))
      {
        continue;
      }
    }
    
    //
    // Check if the share has already been bookmarked and skip it if it
    // already exists
    //
    BookmarkPtr knownBookmark = findBookmarkByUrl(share->isHomesShare() ? share->homeUrl() : share->url());
    
    if (knownBookmark)
    {
      Smb4KNotification::bookmarkExists(knownBookmark.data());
      continue;
    }
    
    BookmarkPtr bookmark = BookmarkPtr(new Smb4KBookmark(share.data()));
    bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
    newBookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : d->tempHostList)
        {
            if (host->hostName() == workgroup->masterBrowserName())
            {
                host->setIsMasterBrowser(true);
            }
            else
            {
                host->setIsMasterBrowser(false);
            }
      
            if (!findHost(host->hostName(), host->workgroupName()))
            {
                addHost(host);
            }
            else
            {
                updateHost(host);
            }            
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : mountedShares)
    {
      if (!s->isForeign())
      {
        isMounted = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
  {
    //
    // Printer shares cannot be bookmarked
    //
    if (share->isPrinter())
    {
      Smb4KNotification::cannotBookmarkPrinter(share);
      continue;
    }
    
    //
    // Process homes shares
    //
    if (share->isHomesShare() && !Smb4KHomesSharesHandler::self()->specifyUser(share, true))
    {
      continue;
    }
    
    //
    // Check if the share has already been bookmarked and skip it if it
    // already exists
    //
    BookmarkPtr knownBookmark = findBookmarkByUrl(share->isHomesShare() ? share->homeUrl() : share->url());
    
    if (knownBookmark)
    {
      Smb4KNotification::bookmarkExists(knownBookmark.data());
      continue;
    }
    
    BookmarkPtr bookmark = BookmarkPtr(new Smb4KBookmark(share.data()));
    bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
    newBookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           Qt::CaseInsensitive) == 0)
      {
        shares << s;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(p->hostsList)) {
        if ((workgroup.isEmpty() || QString::compare(h->workgroupName(), workgroup, Qt::CaseInsensitive) == 0)
            && QString::compare(h->hostName(), name, Qt::CaseInsensitive) == 0) {
            host = h;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *newEntry : qAsConst(newLoginCredentials)) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                    == 0 /* leave the user info here */) {
                    enable = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (QString::compare(s->hostName(), host->hostName(), Qt::CaseInsensitive) == 0 &&
        QString::compare(s->workgroupName(), host->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      shares += s;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : optionsListWidget->actions()) {
            if (a->objectName() == "edit_action") {
                a->setEnabled(item != 0);
            } else if (a->objectName() == "remove_action") {
                a->setEnabled(item != 0);
            } else if (a->objectName() == "clear_action") {
                a->setEnabled(optionsListWidget->count() != 0);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      share->setInaccessible(true);
      emit updated(share);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
    {
      if (QString::compare(m_details_widget->item(0, 1)->text(), authInfo->displayString()) == 0 ||
          (QString::compare(m_details_widget->item(0, 1)->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem))
      {
        switch (authInfo->type())
        {
          case Host:
          case Share:
          {
            if (column == 1)
            {
              switch (row)
              {
                case 1: // Workgroup
                {
                  authInfo->setWorkgroupName(m_details_widget->item(row, column)->text());
                  break;
                }
                case 2: // Login
                {
                  authInfo->setUserName(m_details_widget->item(row, column)->text());
                  break;
                }
                case 3: // Password
                {
                  authInfo->setPassword(m_details_widget->item(row, column)->text());
                  break;
                }
                default:
                {
                  break;
                }
              }
            }
            
            break;
          }
          default:
          {
            if (column == 1)
            {
              switch (row)
              {
                case 1: // Login
                {
                  authInfo->setUserName(m_details_widget->item(row, column)->text());
                  break;
                }
                case 2: // Password
                {
                  authInfo->setPassword(m_details_widget->item(row, column)->text());
                  break;
                }
                default:
                {
                  break;
                }
              }
            }
            
            break;
          }
        }
        
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
  {
    //
    // Check if the bookmark label is already in use
    // 
    if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
    {
      Smb4KNotification::bookmarkLabelInUse(bookmark.data());
      bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
    }
      
    //
    // Check if we have to add the bookmark
    // 
    BookmarkPtr existingBookmark = findBookmarkByUrl(bookmark->url());
      
    if (!existingBookmark)
    {
      qDebug() << "Adding the bookmark to the internal list";
      d->bookmarks << bookmark;
    }
    else
    {
      // We do not need to update the bookmark, because we are
      // operating on a shared pointer.
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList)
      {
        if (networkItem->type() == Host)
        {
          if (QString::compare(entry, networkItem->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 ||
              QString::compare(entry, networkItem->url().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
          {
            d->wallet->readMap(entry, authInfoMap);
            break;
          }
          else
          {
            // Do nothing
          }
        }
        else if (networkItem->type() == Share)
        {
          //
          // Cast the network item. We need some share specific info
          // 
          SharePtr share = networkItem.staticCast<Smb4KShare>();
          
          if (share)
          {
            //
            // Process normal and 'homes' shares differently
            // 
            if (!share->isHomesShare())
            {
              //
              // Prefer the credentials for the share. Use the ones for the 
              // host as fallback.
              //
              if (QString::compare(entry, share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 ||
                  QString::compare(entry, share->url().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
                break;
              }
              else if (QString::compare(entry, share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0 ||
                       QString::compare(entry, share->url().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
              }
              else
              {
                // Do nothing
              }
            }
            else
            {
              //
              // Prefer the credentials for the share. Use the ones for the 
              // host as fallback.
              //
              if (QString::compare(entry, share->homeUrl().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 ||
                  QString::compare(entry, share->homeUrl().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
                break;
              }
              else if (QString::compare(entry, share->homeUrl().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0 ||
                       QString::compare(entry, share->homeUrl().toString(QUrl::RemoveScheme|QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath), Qt::CaseInsensitive) == 0)
              {
                d->wallet->readMap(entry, authInfoMap);
              }
              else
              {
                // Do nothing
              }
            }
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
      {
        if (networkItem->shareItem() == share)
        {
          //
          // Select the search result
          // 
          networkItem->setSelected(true);
          
          //
          // Expand the branch of the network tree where a search result
          // was retrieved
          // 
          if (!networkItem->parent()->isExpanded())
          {
            m_networkBrowser->expandItem(networkItem->parent());
          }
          else
          {
            // Do nothing
          }
          
          if (!networkItem->parent()->parent()->isExpanded())
          {
            m_networkBrowser->expandItem(networkItem->parent()->parent());
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(displayNames)) {
        QList<QAction *> actionsList = m_menus->actions();
        
        for (QAction *action : qAsConst(actionsList)) {
            if (action->data().toMap().value("text").toString() == name) {
                addAction(action);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (!options->macAddress().isEmpty() && (options->wolSendBeforeNetworkScan() || options->wolSendBeforeMount()))
    {
      list << options;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks) {
        // FIXME: Check if the bookmarked share has already been mounted.
        SharePtr share = SharePtr(new Smb4KShare());
        share->setHostName(bookmark->hostName());
        share->setShareName(bookmark->shareName());
        share->setWorkgroupName(bookmark->workgroupName());
        share->setHostIpAddress(bookmark->hostIpAddress());
        share->setLogin(bookmark->login());
        mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &oo : old_list)
        {
          if (!no->equals(oo.data()))
          {
            enable = true;
            break;
          }
          else
          {
            // Do nothing
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
    {
      if (b->url().matches(url, QUrl::RemoveUserInfo|QUrl::RemovePort))
      {
        bookmark = b;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : d->tempHostList) {
            if (host->hostName() == workgroup->masterBrowserName()) {
                host->setIsMasterBrowser(true);
            } else {
                host->setIsMasterBrowser(false);
            }

            if (!findHost(host->hostName(), host->workgroupName())) {
                addHost(host);
            } else {
                updateHost(host);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
      {
        if (!s->isForeign())
        {
          p->onlyForeignShares = false;
          break;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList) {
        if (QString::compare(s->hostName(), host->hostName(), Qt::CaseInsensitive) == 0
            && QString::compare(s->workgroupName(), host->workgroupName(), Qt::CaseInsensitive) == 0) {
            shares += s;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : selectedItems)
    {
      Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (browserItem && browserItem->shareItem()->isMounted())
      {
        mounted << browserItem->shareItem();
      }
      else if (browserItem && !browserItem->shareItem()->isMounted())
      {
        unmounted << browserItem->shareItem();
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : workgroups_list)
    {
      if (w->workgroupName() == workgroup->workgroupName())
      {
        found = true;
        break;
      }
      else
      {
        continue;
      }        
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : unmountedShares)
        {
          emit unmounted(share);
          removeMountedShare(share);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : users) {
                    //
                    // Create a temp share
                    //
                    SharePtr tempShare = share;

                    //
                    // Set the login
                    //
                    tempShare->setLogin(user);

                    //
                    // Read the authentication information
                    //
                    readAuthInfo(tempShare);

                    //
                    // Save the authentication data in the map
                    //
                    knownLogins.insert(tempShare->login(), tempShare->password());

                    //
                    // Clear the temp share
                    //
                    tempShare.clear();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
            // FIXME: Check if the bookmarked share has already been mounted.
            SharePtr share = SharePtr(new Smb4KShare());
            share->setHostName(bookmark->hostName());
            share->setShareName(bookmark->shareName());
            share->setWorkgroupName(bookmark->workgroupName());
            share->setHostIpAddress(bookmark->hostIpAddress());
            share->setLogin(bookmark->login());
            mounts << share;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList()) {
        lookupShares(host);

        while (isRunning()) {
            wait(50);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares)
          {
            bool foundShare = false;
            
            for (int i = 0; i < hostItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));
              
              if (shareItem->shareItem()->unc() == share->unc())
              {
                foundShare = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundShare)
            {
              (void) new Smb4KNetworkBrowserItem(hostItem, share);
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(allCategories)) {
        if (!category.isEmpty()) {
            // Category menu entry
            KActionMenu *bookmarkCategoryMenu = new KActionMenu(category, menu());
            bookmarkCategoryMenu->setIcon(KDE::icon("folder-favorites"));
            QMap<QString, QVariant> menuInfo;
            menuInfo["type"] = "category_menu";
            menuInfo["category"] = category;
            bookmarkCategoryMenu->setData(menuInfo);
            addAction(bookmarkCategoryMenu);

            // Mount action for the category
            QAction *bookmarkCategoryMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkCategoryMenu->menu());
            QMap<QString, QVariant> categoryMountInfo;
            categoryMountInfo["type"] = "category_mount";
            categoryMountInfo["category"] = category;
            bookmarkCategoryMount->setData(categoryMountInfo);
            bookmarkCategoryMenu->addAction(bookmarkCategoryMount);
            m_actions->addAction(bookmarkCategoryMount);

            // Get the list of bookmarks belonging to this category.
            // Use it to decide whether the category mount action should be enabled
            // (only if not all bookmarks belonging to this category are mounted) and
            // to sort the bookmarks.
            QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(category);
            QStringList sortedBookmarks;
            int mountedBookmarks = 0;

            for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
                QAction *bookmarkAction = 0;

                if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty()) {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->label();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->label();
                } else {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->displayString();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->displayString();
                }

                QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

                if (!mountedShares.isEmpty()) {
                    for (const SharePtr &share : qAsConst(mountedShares)) {
                        if (!share->isForeign()) {
                            bookmarkAction->setEnabled(false);
                            mountedBookmarks++;
                            break;
                        }
                    }
                }
            }

            bookmarkCategoryMount->setEnabled(mountedBookmarks != bookmarks.size());
            sortedBookmarks.sort();

            // Add a separator
            bookmarkCategoryMenu->addSeparator();

            // Insert the sorted bookmarks into the category menu
            QList<QAction *> actions = m_bookmarks->actions();

            for (const QString &b : qAsConst(sortedBookmarks)) {
                for (QAction *a : qAsConst(actions)) {
                    if (a->text() == b) {
                        bookmarkCategoryMenu->addAction(a);
                        break;
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups)
  {
    if (!group.isEmpty())
    {
      // Group menu entry
      QAction *bookmarkGroup = new QAction(KDE::icon("folder-favorites"), group, m_groups);
      addAction(bookmarkGroup);
      m_action_collection->addAction(QString("group_%1").arg(group));
      
      // Group submenu
      KActionMenu *bookmarkGroupMenu = new KActionMenu(bookmarkGroup);
      bookmarkGroup->setMenu(bookmarkGroupMenu->menu());
      
      // Mount action for the group
      QAction *bookmarkGroupMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), m_groups);
      bookmarkGroupMount->setData(group);
      bookmarkGroupMount->setObjectName(QString("%1_mount_action").arg(group));
      bookmarkGroupMenu->addAction(bookmarkGroupMount);
      m_action_collection->addAction(QString("%1_mount_action").arg(group));

      // Get the list of bookmarks belonging to this group.
      // Use it to decide whether the group mount action should be enabled 
      // (only if not all bookmarks belonging to this group are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(group);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
          QMap<QString,QVariant> info;
          info["group"] = group;
          info["unc"] = bookmark->unc();
          bookmarkAction->setData(info);
          sortedBookmarks << bookmark->label();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->unc(), m_bookmarks);
          QMap<QString,QVariant> info;
          info["group"] = group;
          info["unc"] = bookmark->unc();
          bookmarkAction->setData(info);
          sortedBookmarks << bookmark->unc();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
      
      bookmarkGroupMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkGroupMenu->addSeparator();
      
      // Insert the sorted bookmarks into the group menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &newHost : job->hosts()) {
        bool foundHost = false;

        for (const HostPtr &host : d->tempHostList) {
            if (host->workgroupName() == newHost->workgroupName() && host->hostName() == newHost->hostName()) {
                foundHost = true;
                break;
            }
        }

        if (!foundHost) {
            d->tempHostList << newHost;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
  {
    d->workgroupObjects << new Smb4KNetworkObject(workgroup.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : hostInfo.addresses())
      {
        // We only use global addresses.
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
        if (addr.isGlobal())
#else
        if (!addr.isLoopback() && !addr.isMulticast())
#endif
        {
          if (addr.protocol() == QAbstractSocket::IPv4Protocol)
          {
            ipAddress = addr;
            break;
          }
          else if (addr.protocol() == QAbstractSocket::IPv6Protocol)
          {
            // FIXME: Use the right address here.
            ipAddress = addr;
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(entryList)) {
            //
            // Create a auth info object
            //
            Smb4KAuthInfo *authInfo = new Smb4KAuthInfo();

            //
            // Read the authentication information from the wallet
            //
            QMap<QString, QString> authInfoMap;
            d->wallet->readMap(entry, authInfoMap);

            //
            // Process the entry
            //
            if (entry == "DEFAULT_LOGIN") {
                //
                // Default login
                //
                authInfo->setUserName(authInfoMap.value("Login"));
                authInfo->setPassword(authInfoMap.value("Password"));
            } else {
                //
                // Entry for a specific URL
                //
                authInfo->setUrl(entry);
                authInfo->setIpAddress(authInfoMap.value("IP Address"));
                authInfo->setWorkgroupName(authInfoMap.value("Workgroup"));
                authInfo->setUserName(authInfoMap.value("Login"));
                authInfo->setPassword(authInfoMap.value("Password"));
            }

            entries << authInfo;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &to : tabOrientationChoices) {
        tabOrientation->addItem(to.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &file : job->files()) {
        if (file->isHidden() && !Smb4KSettings::previewHiddenItems()) {
            continue;
        }

        list << file;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : m_listing)
    {
      if (item->data(Qt::UserRole).toUrl().matches(f->url(), QUrl::None))
      {
        m_currentItem = f;
        emit requestPreview(m_currentItem);
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList)
  {
    if (options->remount() != Smb4KCustomOptions::UndefinedRemount)
    {
      remounts << options;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
            d->wallet->removeEntry(entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups)
  {
    if (!group.isEmpty())
    {
      // Group menu entry
      QAction *bookmarkGroup = new QAction(KDE::icon("folder-favorites"), group, m_groups);
      addAction(bookmarkGroup);
      m_action_collection->addAction(QString("group_%1").arg(group));
      
      // Group submenu
      KActionMenu *bookmarkGroupMenu = new KActionMenu(bookmarkGroup);
      bookmarkGroup->setMenu(bookmarkGroupMenu->menu());
      
      // Mount action for the group
      QAction *bookmarkGroupMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkGroupMenu);
      bookmarkGroupMount->setData(group);
      bookmarkGroupMount->setObjectName(QString("%1_mount_action").arg(group));
      bookmarkGroupMenu->addAction(bookmarkGroupMount);
      m_action_collection->addAction(QString("%1_mount_action").arg(group));

      // Get the list of bookmarks belonging to this group.
      // Use it to decide whether the group mount action should be enabled 
      // (only if not all bookmarks belonging to this group are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(group);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
          QMap<QString,QVariant> info;
          info["group"] = group;
          info["unc"] = bookmark->unc();
          bookmarkAction->setData(info);
          sortedBookmarks << bookmark->label();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->unc(), m_bookmarks);
          QMap<QString,QVariant> info;
          info["group"] = group;
          info["unc"] = bookmark->unc();
          bookmarkAction->setData(info);
          sortedBookmarks << bookmark->unc();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
      
      bookmarkGroupMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkGroupMenu->addSeparator();
      
      // Insert the sorted bookmarks into the group menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
      {
        if (!bookmark->url().isValid())
        {
          Smb4KNotification::invalidURLPassed();
          continue;
        }
        else
        {
          // Do nothing
        }
        
        xmlWriter.writeStartElement("bookmark");
        xmlWriter.writeAttribute("profile", bookmark->profile());
        xmlWriter.writeAttribute("group", bookmark->groupName());

        xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
        xmlWriter.writeTextElement("unc", bookmark->unc());
        xmlWriter.writeTextElement("login", bookmark->login());
        xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
        xmlWriter.writeTextElement("label", bookmark->label());

        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &p : qAsConst(shares)) {
                qDebug() << p->url();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList())
    {
      if (!host->hasIP())
      {
        Smb4KLookupIPAddressJob *job = new Smb4KLookupIPAddressJob(this);
        job->setObjectName(QString("LookupIPAddressJob_%1").arg(host->unc()));
        job->setupLookup(host, 0);

        connect(job, SIGNAL(result(KJob*)), SLOT(slotJobFinished(KJob*)));
        connect(job, SIGNAL(ipAddress(HostPtr)), SLOT(slotProcessIPAddress(HostPtr)));

        addSubjob(job);

        job->start();
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    QAction *bookmarkAction = 0;
        
    if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["unc"] = bookmark->unc();
      bookmarkInfo["text"] = bookmark->label();
      bookmarkAction->setData(bookmarkInfo);
      sortedBookmarks << bookmark->label();
      m_action_collection->addAction(bookmark->unc(), bookmarkAction);
    }
    else
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), m_bookmarks);
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["group"] = "";
      bookmarkInfo["unc"] = bookmark->unc();
      bookmarkInfo["text"] = bookmark->displayString();
      bookmarkAction->setData(bookmarkInfo);
      sortedBookmarks << bookmark->displayString();
      m_action_collection->addAction(bookmark->unc(), bookmarkAction);
    }
        
    QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
    if (!mountedShares.isEmpty())
    {
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          bookmarkAction->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : children) {
                if (object == obj) {
                    m_focusWidget = sharesViewDock;
                    setupDynamicActionList(sharesViewDock);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KWorkgroup *w : workgroups_list)
    {
      if (w->workgroupName() == workgroup->workgroupName())
      {
        found = true;
        break;
      }
      else
      {
        continue;
      }        
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : d->importedShares)
    {
      Smb4KShare *mountedShare = findShareByPath(share->path());
      
      if (mountedShare)
      {
        if (mountedShare->isInaccessible() && !checkInaccessible)
        {
          continue;
        }
        else
        {
          // Do nothing
        }
      }
      else
      {
        // Do nothing
      }
      
      QUrl url = QUrl::fromLocalFile(share->path());
      KIO::StatJob *job = KIO::stat(url, KIO::HideProgressInfo);
      job->setDetails(0);
      connect(job, SIGNAL(result(KJob*)), this, SLOT(slotStatResult(KJob*)));
      
      // Do not use addSubJob(), because that would confuse isRunning(), etc.
      job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(p->hostsList)) {
        if (QString::compare(h->workgroupName(), workgroup->workgroupName(), Qt::CaseInsensitive) == 0) {
            hosts << h;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hosts_list)
    {
      if (host->hostName() == workgroup->masterBrowserName())
      {
        host->setIsMasterBrowser(true);
      }
      else
      {
        host->setIsMasterBrowser(false);
      }
      
      if (!findHost(host->hostName(), host->workgroupName()))
      {
        addHost(host);
        d->haveNewHosts = true;
      }
      else
      {
        updateHost(host);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible())
    {
      openShare(item->shareItem(), FileManager);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(m_hosts))
                {
                  //
                  // On a local network there will most likely be no two servers with
                  // identical name, thus, to avoid duplicates, only test the hostname
                  // here.
                  // 
                  if (QString::compare(h->hostName(), service->serviceName(), Qt::CaseInsensitive) == 0)
                  {
                    foundServer = true;
                    break;
                  }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
      {
        if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
        {
          // Propagate the options to the shared resources of the host.
          // They overwrite the ones defined for the shares.
          o->setSMBPort(m_currentOptions->smbPort());
          o->setUseKerberos(m_currentOptions->useKerberos());
          o->setMACAddress(m_currentOptions->macAddress());
          o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : sharesList()) {
                if (s->workgroupName() == file->workgroupName() && s->hostName() == file->hostName() && s->shareName() == file->shareName()) {
                    message = i18n("Looking for files and directories in %1...", s->displayString());
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &interface : qAsConst(interfaces))
  {
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
    if (interface.isValid() && interface.type() != QNetworkInterface::Loopback && interface.flags() & QNetworkInterface::IsRunning && !online)
#else
    if (interface.isValid() && !(interface.flags() & QNetworkInterface::IsLoopBack) && interface.flags() & QNetworkInterface::IsRunning && !online)
#endif
    {
      online = true;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : entries)
    {
      QMap<QString, QString> authInfoMap;
      
      if (authInfo->type() == UnknownNetworkItem)
      {
        //
        // Default login
        // 
        authInfoMap.insert("Login", authInfo->userName());
        authInfoMap.insert("Password", authInfo->password());
        
        //
        // Write the default authentication information to the wallet
        // 
        d->wallet->writeMap("DEFAULT_LOGIN", authInfoMap);
      }
      else
      {
        //
        // Authentication information for a specific URL
        // 
        authInfoMap.insert("IP Address", authInfo->ipAddress());
        authInfoMap.insert("Workgroup", authInfo->workgroupName());
        authInfoMap.insert("Login", authInfo->userName());
        authInfoMap.insert("Password", authInfo->password());
        
        //
        // Write the authentication information to the wallet
        // 
        d->wallet->writeMap(authInfo->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), authInfoMap);
      }
      
      //
      // Sync the entries to disk
      // 
      d->wallet->sync();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : qAsConst(members)) {
                    bool foundHost = false;

                    for (int i = 0; i < workgroupItem->childCount(); ++i) {
                        Smb4KNetworkBrowserItem *hostItem = static_cast<Smb4KNetworkBrowserItem *>(workgroupItem->child(i));

                        if (hostItem->hostItem()->hostName() == host->hostName()) {
                            foundHost = true;
                            break;
                        }
                    }

                    if (!foundHost) {
                        (void)new Smb4KNetworkBrowserItem(workgroupItem, host);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mounted)
        {
          if (!share->isForeign())
          {
            number++;
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPrintDialog *p : d->printDialogs)
    {
        if (share == p->share())
        {
            dlg = p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : Smb4KGlobal::mountedSharesList()) {
        d->mountedObjects << new Smb4KNetworkObject(mountedShare.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : hostInfo.addresses()) {
                // We only use global addresses.
                if (addr.isGlobal()) {
                    if (addr.protocol() == QAbstractSocket::IPv4Protocol) {
                        ipAddress = addr;
                        break;
                    } else if (addr.protocol() == QAbstractSocket::IPv6Protocol) {
                        // FIXME: Use the right address here.
                        ipAddress = addr;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : users)
          {
            //
            // Create a temp share
            // 
            SharePtr tempShare = share;
            
            // 
            // Set the login
            // 
            tempShare->setLogin(user);
            
            //
            // Read the authentication information
            // 
            readAuthInfo(tempShare);
            
            //
            // Save the authentication data in the map
            // 
            knownLogins.insert(tempShare->login(), tempShare->password());
            
            //
            // Clear the temp share
            // 
            tempShare.clear();
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : qAsConst(sortedBookmarks)) {
        for (QAction *a : qAsConst(actions)) {
            if (a->data().toMap().value("text").toString() == b) {
                addAction(a);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList())
  {
    d->shareObjects << new Smb4KNetworkObject(share.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &hostDir : qAsConst(hostDirs)) {
        dir.cd(hostDir);

        QStringList shareDirs = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::NoSort);

        for (const QString &shareDir : qAsConst(shareDirs)) {
            dir.cd(shareDir);
            mountpoints << dir.absolutePath();
            dir.cdUp();
        }

        dir.cdUp();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : d->tempWorkgroupList)
        {
            if (workgroup->workgroupName() == newWorkgroup->workgroupName())
            {
                foundWorkgroup = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : qAsConst(d->options)) {
                if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName()) {
                    o->setIpAddress(options->ipAddress());
                    o->setUseUser(options->useUser());
                    o->setUser(options->user());
                    o->setUseGroup(options->useGroup());
                    o->setGroup(options->group());
                    o->setUseFileMode(options->useFileMode());
                    o->setFileMode(options->fileMode());
                    o->setUseDirectoryMode(options->useDirectoryMode());
                    o->setDirectoryMode(options->directoryMode());
#if defined(Q_OS_LINUX)
                    o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
                    o->setUseFileSystemPort(options->useFileSystemPort());
                    o->setFileSystemPort(options->fileSystemPort());
                    o->setUseMountProtocolVersion(options->useMountProtocolVersion());
                    o->setMountProtocolVersion(options->mountProtocolVersion());
                    o->setUseSecurityMode(options->useSecurityMode());
                    o->setSecurityMode(options->securityMode());
                    o->setUseWriteAccess(options->useWriteAccess());
                    o->setWriteAccess(options->writeAccess());
#endif
                    o->setUseSmbPort(options->useSmbPort());
                    o->setSmbPort(options->smbPort());
                    o->setUseKerberos(options->useKerberos());
                    o->setMACAddress(options->macAddress());
                    o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
                    o->setWOLSendBeforeMount(options->wolSendBeforeMount());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          qDebug() << "Not implemented mount option:" << option;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
            if (a->data().toMap().value("category").toString() == bookmarkCategory && a->isEnabled()) {
                allMounted = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : m_bookmarks)
  {
    if (b->url() == url)
    {
      bookmark = b;
      break;
    }
    else
    {
      continue;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { saveSettings(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : qAsConst(m_optionsList)) {
            if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName()) {
                o->setIpAddress(m_currentOptions->ipAddress());
                o->setUseUser(m_currentOptions->useUser());
                o->setUser(m_currentOptions->user());
                o->setUseGroup(m_currentOptions->useGroup());
                o->setGroup(m_currentOptions->group());
                o->setUseFileMode(m_currentOptions->useFileMode());
                o->setFileMode(m_currentOptions->fileMode());
                o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
                o->setDirectoryMode(m_currentOptions->directoryMode());
#if defined(Q_OS_LINUX)
                o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
                o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
                o->setFileSystemPort(m_currentOptions->fileSystemPort());
                o->setUseMountProtocolVersion(m_currentOptions->useMountProtocolVersion());
                o->setMountProtocolVersion(m_currentOptions->mountProtocolVersion());
                o->setUseSecurityMode(m_currentOptions->useSecurityMode());
                o->setSecurityMode(m_currentOptions->securityMode());
                o->setUseWriteAccess(m_currentOptions->useWriteAccess());
                o->setWriteAccess(m_currentOptions->writeAccess());
#endif
                o->setUseClientProtocolVersions(m_currentOptions->useClientProtocolVersions());
                o->setMinimalClientProtocolVersion(m_currentOptions->minimalClientProtocolVersion());
                o->setMaximalClientProtocolVersion(m_currentOptions->maximalClientProtocolVersion());
                o->setUseSmbPort(m_currentOptions->useSmbPort());
                o->setSmbPort(m_currentOptions->smbPort());
                o->setUseKerberos(m_currentOptions->useKerberos());
                o->setMACAddress(m_currentOptions->macAddress());
                o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
                o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mp : mountpoints)
  {
    dir.cd(mp);
    dir.rmdir(dir.canonicalPath());
    
    if (dir.cdUp())
    {
      dir.rmdir(dir.canonicalPath());
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : qAsConst(d->mountedObjects)) {
            if (url.matches(obj->url(), QUrl::None)) {
                object = obj;
                break;
            } else if (!exactMatch && url.matches(obj->url(), QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash)) {
                object = obj;
                continue;
            } else {
                continue;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(d->tempHostList))
            {
                if (h->workgroupName() == host->workgroupName() && h->hostName() == host->hostName())
                {
                    foundHost = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
            QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

            if (!mountedShares.isEmpty()) {
                for (const SharePtr &share : qAsConst(mountedShares)) {
                    if (!share->isForeign()) {
                        mountedBookmarks++;
                        break;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : qAsConst(d->options)) {
        if (options->type() == Share) {
            if (options->remount() == Smb4KCustomOptions::RemountOnce) {
                options->setRemount(Smb4KCustomOptions::UndefinedRemount);
            } else if (options->remount() == Smb4KCustomOptions::RemountAlways && force) {
                options->setRemount(Smb4KCustomOptions::UndefinedRemount);
            }
        }

        if (!options->hasOptions()) {
            removeCustomOptions(options, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &p : shares) {
                qDebug() << p->url();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : oldWalletEntries)
    {
      for (Smb4KAuthInfo *newEntry : newWalletEntries)
      {
        if (oldEntry->url().matches(newEntry->url(), QUrl::RemovePort /* leave the user info here */) &&
            oldEntry->workgroupName() == newEntry->workgroupName())
        {
          enable = true;
          break;
        }
        else
        {
          // Do nothing
        }
      }
      
      if (enable)
      {
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : qAsConst(m_entriesList)) {
        switch (authInfo->type()) {
        case UnknownNetworkItem: {
            (void)new QListWidgetItem(KDE::icon("dialog-password"), i18n("Default Login"), walletEntriesWidget);
            break;
        }
        default: {
            (void)new QListWidgetItem(KDE::icon("dialog-password"), authInfo->displayString(), walletEntriesWidget);
            break;
        }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : allActions)
    {
      if (a->data().toMap().value("type").toString() == "toplevel_mount" && bookmarkCategory.isEmpty())
      {
        a->setEnabled(!allMounted);
        break;
      }
      else if (a->data().toMap().value("type").toString() == "category_mount" &&
               a->data().toMap().value("category").toString() == bookmarkCategory)
      {
        a->setEnabled(!allMounted);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &newHost : qAsConst(discoveredHosts)) {
        bool foundHost = false;

        for (const HostPtr &host : qAsConst(d->tempHostList)) {
            if (host->workgroupName() == newHost->workgroupName() && host->hostName() == newHost->hostName()) {
                foundHost = true;
                break;
            }
        }

        if (!foundHost) {
            d->tempHostList << newHost;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkCategoryMenu->addAction(a);
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : m_listing)
        {
            if (item->data(Qt::UserRole).toUrl().matches(f->url(), QUrl::None))
            {
                m_currentItem = f;
                emit requestPreview(m_currentItem);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
        {
          if (!share->isForeign())
          {
            mountedBookmarks++;
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
#if defined(Q_OS_LINUX)
    if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0 &&
        QString::compare(mountPoint->mountType(), "cifs", Qt::CaseInsensitive) == 0)
#else
    if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0 &&
        QString::compare(mountPoint->mountType(), "smbfs", Qt::CaseInsensitive) == 0)
#endif
    {
      mountPointOk = true;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : qAsConst(m_optionsList)) {
            switch (o->type()) {
            case Host: {
                QListWidgetItem *item = new QListWidgetItem(KDE::icon("network-server"), o->displayString(), optionsListWidget, Host);
                item->setData(Qt::UserRole, o->url().toDisplayString());
                break;
            }
            case Share: {
                QListWidgetItem *item = new QListWidgetItem(KDE::icon("folder-network"), o->displayString(), optionsListWidget, Share);
                item->setData(Qt::UserRole, o->url().toDisplayString());
                break;
            }
            default: {
                break;
            }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : mountedSharesList())
  {
    for (const SharePtr &importedShare : d->importedShares)
    {
      // Check the mountpoint, since that one is unique. We will only use
      // Smb4KShare::path(), so that we do not run into trouble if a share 
      // is inaccessible.
      if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
      {
        found = true;
        break;
      }
    }
    
    if (!found)
    {
      // Remove the mountpoint if the share is not a foreign one
      if (!mountedShare->isForeign())
      {
        QDir dir;
        dir.cd(mountedShare->canonicalPath());
        dir.rmdir(dir.canonicalPath());
        
        if (dir.cdUp())
        {
          dir.rmdir(dir.canonicalPath());
        }
      }
      
      mountedShare->setMounted(false);
      unmountedShares << mountedShare;
    }
    
    found = false;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->mountedSharesList)
    {
      if (QString::compare(s->path(), path, Qt::CaseInsensitive) == 0 ||
          QString::compare(s->canonicalPath(), path, Qt::CaseInsensitive) == 0)
      {
        share = s;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    // We do not need to use slotShareUnmounted() here, too,
    // because slotShareMounted() will take care of everything
    // we need here.
    slotShareMounted(share);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
    {
      if (o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash) == 
          url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::StripTrailingSlash))
      {
        options = o;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
  {
    //
    // Check if the bookmark label is already in use
    // 
    if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
    {
      Smb4KNotification::bookmarkLabelInUse(bookmark.data());
      bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
    }
    else
    {
      // Do nothing
    }
      
    //
    // Check if we have to add the bookmark
    // 
    BookmarkPtr existingBookmark = findBookmarkByUNC(bookmark->unc());
      
    if (!existingBookmark)
    {
      d->bookmarks << bookmark;
    }
    else
    {
      // We do not to update the bookmark, because we are
      // operating on a shared pointer.
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
  {
    if (!categories.contains(b->categoryName()))
    {
      categories << b->categoryName();
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : sharesList())
          {
            if (s->workgroupName() == file->workgroupName() && s->hostName() == file->hostName() && s->shareName() == file->shareName())
            {
              message = i18n("Looking for files and directories in %1...", s->displayString());   
              break;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item) {
            shares << item->shareItem();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares) {
                        if (!share->isForeign()) {
                            bookmarkAction->setEnabled(false);
                            mountedBookmarks++;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks) {
            if (bookmark->profile() == Smb4KSettings::activeProfile()) {
                bookmarks << bookmark;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &vm : qAsConst(sharesViewModeChoices)) {
        viewMode->addItem(vm.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list) {
        //
        // Printer shares cannot be bookmarked
        //
        if (share->isPrinter()) {
            Smb4KNotification::cannotBookmarkPrinter(share);
            continue;
        }

        //
        // Process homes shares
        //
        if (share->isHomesShare() && !Smb4KHomesSharesHandler::self()->specifyUser(share, true)) {
            continue;
        }

        //
        // Check if the share has already been bookmarked and skip it if it
        // already exists
        //
        BookmarkPtr knownBookmark = findBookmarkByUrl(share->isHomesShare() ? share->homeUrl() : share->url());

        if (knownBookmark) {
            Smb4KNotification::bookmarkExists(knownBookmark.data());
            continue;
        }

        BookmarkPtr bookmark = BookmarkPtr(new Smb4KBookmark(share.data()));
        bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
        newBookmarks << bookmark;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *mountedShare : mountedSharesList())
  {
    d->mountedObjects << new Smb4KNetworkObject(mountedShare);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : qAsConst(mountedSharesList())) {
            for (const SharePtr &importedShare : qAsConst(d->importedShares)) {
                // Check the mountpoint, since that one is unique. We will only use
                // Smb4KShare::path(), so that we do not run into trouble if a share
                // is inaccessible.
                if (QString::compare(mountedShare->path(), importedShare->path()) == 0) {
                    found = true;
                    break;
                }
            }

            if (!found) {
                unmountedShares << mountedShare;
            }

            found = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           Qt::CaseInsensitive) == 0)
      {
        shares << s;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(d->bookmarks)) {
                if (!bookmark->url().isValid()) {
                    Smb4KNotification::invalidURLPassed();
                    continue;
                }

                xmlWriter.writeStartElement("bookmark");
                xmlWriter.writeAttribute("profile", bookmark->profile());
                xmlWriter.writeAttribute("category", bookmark->categoryName());

                xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
                xmlWriter.writeTextElement("url", bookmark->url().toString(QUrl::RemovePassword | QUrl::RemovePort));
                xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
                xmlWriter.writeTextElement("label", bookmark->label());

                xmlWriter.writeEndElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
    bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
    bookmarkItem->setIcon(0, bookmark->icon());
    bookmarkItem->setText(0, bookmark->displayString());
    bookmarkItem->setText((m_tree_widget->columnCount() - 1), QString("01_%1").arg(bookmark->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)));
    bookmarkItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDragEnabled);
    
    if (!bookmark->groupName().isEmpty())
    {
      QList<QTreeWidgetItem *> items = m_tree_widget->findItems(bookmark->groupName(), Qt::MatchFixedString|Qt::MatchCaseSensitive, 0);
      
      if (!items.isEmpty())
      {
        items.first()->addChild(bookmarkItem);
        items.first()->setExpanded(true);
      }
    }
    else
    {
      m_tree_widget->addTopLevelItem(bookmarkItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *b : buttonBox->buttons()) {
            if (buttonBox->buttonRole(b) == QDialogButtonBox::ResetRole) {
                b->setEnabled(!checkDefaultValues());
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KWorkgroup *workgroup : workgroups_list)
  {
    if (!findWorkgroup(workgroup->workgroupName()))
    {
      addWorkgroup(new Smb4KWorkgroup(*workgroup));
      
      // Since this is a new workgroup, no master browser is present.
      Smb4KHost *masterBrowser = new Smb4KHost();
      masterBrowser->setWorkgroupName(workgroup->workgroupName());
      masterBrowser->setHostName(workgroup->masterBrowserName());
      masterBrowser->setIP(workgroup->masterBrowserIP());
      masterBrowser->setIsMasterBrowser(true);
      
      addHost(masterBrowser);
    }
    else
    {
      updateWorkgroup(workgroup);
      
      // Check if the master browser changed
      QList<Smb4KHost *> members = workgroupMembers(workgroup);
      
      for (Smb4KHost *host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIP() && workgroup->hasMasterBrowserIP())
          {
            host->setIP(workgroup->masterBrowserIP());
          }
          else
          {
            // Do nothing
          }          
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && 
            QString::compare(o->hostName(), options->hostName(), Qt::CaseInsensitive) == 0 &&
            QString::compare(o->workgroupName(), options->workgroupName(), Qt::CaseInsensitive) == 0)
        {
          // Do not use Smb4KCustomOptions::update() here, because that
          // would overwrite more options than wanted.
          o->setSMBPort(options->smbPort());
#if defined(Q_OS_LINUX)
          o->setFileSystemPort(options->fileSystemPort());
          o->setSecurityMode(options->securityMode());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUser(options->user());
          o->setGroup(options->group());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());   
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : p->workgroupsList)
  {
    if (QString::compare(w->workgroupName(), name, Qt::CaseInsensitive) == 0)
    {
      workgroup = w;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(d->bookmarks)) {
            if (bookmark->profile() == Smb4KSettings::activeProfile()) {
                bookmarks << bookmark;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList())
    {
        if (share->shareName().contains(item, Qt::CaseInsensitive))
        {
            results << share;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : sharesList())
    {
      if (share->url() == object->url())
      {
        shares << share;
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
  {
    if (m_auth_info->url().matches(authInfo->url(), QUrl::RemovePort /* we can leave the user info here */) ||
        (m_auth_info->type() == UnknownNetworkItem && m_auth_info->type() == authInfo->type()))
    {
      switch (m_auth_info->type())
      {
        case Host:
        case Share:
        {
          authInfo->setWorkgroupName(m_auth_info->workgroupName());
          authInfo->setUserName(m_auth_info->userName());
          authInfo->setPassword(m_auth_info->password());
          break;
        }
        default:
        {
          authInfo->setUserName(m_auth_info->userName());
          authInfo->setPassword(m_auth_info->password());
          break;
        }
      }
      
      break;
    }
    else
    {
      // Do nothing
    }          
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : list)
        {
          QList<SharePtr> mountedShares = findShareByUrl(opt->url());
          
          if (!mountedShares.isEmpty())
          {
            bool mount = true;
            
            for (const SharePtr &s : mountedShares)
            {
              if (!s->isForeign())
              {
                mount = false;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (mount)
            {
              SharePtr share = SharePtr(new Smb4KShare());
              share->setUrl(opt->url());
              share->setWorkgroupName(opt->workgroupName());
              share->setHostIpAddress(opt->ipAddress());
              
              if (share->url().isValid() && !share->url().isEmpty())
              {
                d->remounts << share;
              }
              else
              {
                // Do nothing
              }
            }
            else
            {
              // Do nothing
            }
          }
          else
          {
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(opt->url());
            share->setWorkgroupName(opt->workgroupName());
            share->setHostIpAddress(opt->ipAddress());
              
            if (share->url().isValid() && !share->url().isEmpty())
            {
              d->remounts << share;
            }
            else
            {
              // Do nothing
            }
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &option : qAsConst(options))
    {
      //
      // Skip one time remount shares, if needed
      // 
      if (option->remount() == Smb4KCustomOptions::RemountOnce && !Smb4KMountSettings::remountShares())
      {
        continue;
      }
      
      //
      // Check which share has to be remounted
      // 
      QList<SharePtr> mountedShares = findShareByUrl(option->url());
      bool remountShare = true;
      
      for (const SharePtr &share : qAsConst(mountedShares))
      {
        if (!share->isForeign())
        {
          remountShare = false;
          break;
        }          
      }
      
      //
      // Insert the share to the list of remounts
      // 
      if (remountShare)
      {
        bool insertShare = true;
        
        for (const SharePtr &share : qAsConst(d->remounts))
        {
          if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort), option->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)) == 0)
          {
            insertShare = false;
            break;
          }
        }
        
        if (insertShare)
        {
          SharePtr share = SharePtr(new Smb4KShare());
          share->setUrl(option->url());
          share->setWorkgroupName(option->workgroupName());
          share->setHostIpAddress(option->ipAddress());
          
          if (share->url().isValid() && !share->url().isEmpty())
          {
            d->remounts << share;
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharePtr s : p->searchResults)
      {
        if (share->unc() == s->unc())
        {
          s->setMountData(share.data());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : dockActionCollection->actions())
    {
      if (action->objectName() == "bookmark_action")
      {
        if (bookmarkMenu)
        {
          bookmarkMenu->setBookmarkActionEnabled(action->isEnabled());
          connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
          continue;
        }
        else
        {
          // Do nothing
        }
      }
      else if (QString::compare(action->objectName(), "filemanager_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "konsole_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "icon_view_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "list_view_action") == 0)
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      dynamicList << action;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : output)
  {
    if (line.contains("<00>"))
    {
      QString ip_address = line.section(' ', 0, 0).trimmed();
      m_host->setIP(ip_address);
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_menus->actions())
    {
      if (action->data().toMap().value("text").toString() == name)
      {
        addAction(action);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_menus->actions())
    {
      if (action->data().toMap().value("text").toString() == displayNames.at(i))
      {
        addAction(action);
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks) {
        HostPtr host = findHost(bookmark->hostName(), bookmark->workgroupName());

        if (host) {
            if (host->hasIpAddress() && bookmark->hostIpAddress() != host->ipAddress()) {
                bookmark->setHostIpAddress(host->ipAddress());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(walletEntries)) {
                    if (QString::compare(entry, testString, Qt::CaseInsensitive) == 0) {
                        itemUrlString = entry;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *category : qAsConst(allCategoryActions)) {
            if (category->data().toMap().value("category").toString() == bookmark->categoryName()) {
                bookmarkMenu = static_cast<KActionMenu *>(category);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList)
  {
    if (QString::compare(h->workgroupName(), workgroup->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      hosts << h;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(actionsList)) {
            if (action->data().toMap().value("text").toString() == name) {
                addAction(action);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entriesList) {
            if (walletEntriesWidget->currentItem()->text() == authInfo->displayString()
                || (walletEntriesWidget->currentItem()->text() == i18n("Default Login") && authInfo->type() == UnknownNetworkItem)) {
                loadDetails(authInfo);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->sharesList)
  {
    if (QString::compare(s->unc(), unc, Qt::CaseInsensitive) == 0 &&
        (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0))
    {
      share = s;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            if (QString::compare(share->unc(), o->unc(), Qt::CaseInsensitive) == 0)
            {
              options = o;
              break;
            }
            else if (!exactMatch && o->type() == Host && QString::compare(share->hostUNC(), o->unc(), Qt::CaseInsensitive) == 0)
            {
              options = o;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : shares)
  {
    if ((!s->isForeign() || Smb4KSettings::detectAllShares()) && s->isMounted())
    {
      share->setMounted(s->isMounted());
      share->setPath(s->path());
      share->setForeign(s->isForeign());
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item && !item->shareItem()->isInaccessible() && !Smb4KSynchronizer::self()->isRunning(item->shareItem())) {
            Smb4KSynchronizer::self()->synchronize(item->shareItem());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
  {
    if (QString::compare(b->label().toUpper(), label.toUpper()) == 0)
    {
      bookmark = b;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : Smb4KBookmarkHandler::self()->groupsList())
  {
    d->bookmarkGroupObjects << new Smb4KBookmarkObject(group);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares)) {
                        if (!share->isForeign()) {
                            bookmarkAction->setEnabled(false);
                            mountedBookmarks++;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
    {
#if defined(Q_OS_LINUX)
      if (QString::compare(entry.value("mh_mountpoint").toString(), mountPoint->mountPoint()) == 0 &&
          QString::compare(mountPoint->mountType(), "cifs", Qt::CaseInsensitive) == 0)
#else
      if (QString::compare(entry.value("mh_mountpoint").toString(), mountPoint->mountPoint()) == 0 &&
          QString::compare(mountPoint->mountType(), "smbfs", Qt::CaseInsensitive) == 0)
#endif
      {
        mountPointOk = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item)
    {
      shares << item->shareItem();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : mountedShares)
    {
      if (!s->isForeign())
      {
        isMounted = true;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (!options->macAddress().isEmpty() && (options->wolSendBeforeNetworkScan() || options->wolSendBeforeMount()))
    {
      list << options;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList()) {
        if (QString::compare(b->label().toUpper(), label.toUpper()) == 0) {
            bookmark = b;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares) {
                    if (!share->isForeign()) {
                        mountedBookmarks++;
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!coreIsRunning()) {
            m_progress_bar->setVisible(false);
            m_progress_bar->reset();
            statusBar()->showMessage(i18n("Done."), 2000);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : children) {
                if (object == obj) {
                    m_focusWidget = networkBrowserDock;
                    setupDynamicActionList(networkBrowserDock);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &newOptions : newOptionsList)
      {
        for (const OptionsPtr &oldOptions : oldOptionsList)
        {
          if (!newOptions->equals(oldOptions.data()))
          {
            enable = true;
            break;
          }
          else
          {
            // Do nothing
          }
        }
        
        if (enable)
        {
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &vm : sharesViewModeChoices) {
        viewMode->addItem(vm.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : mountedSharesList())
    {
      for (const SharePtr &importedShare : d->importedShares)
      {
        // Check the mountpoint, since that one is unique. We will only use
        // Smb4KShare::path(), so that we do not run into trouble if a share 
        // is inaccessible.
        if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
        {
          found = true;
          break;
        }
      }
      
      if (!found)
      {
        unmountedShares << mountedShare;
      }
      
      found = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares))
      {
        if (!share->isForeign())
        {
          remountShare = false;
          break;
        }          
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (s->url().matches(url, QUrl::RemoveUserInfo|QUrl::RemovePort))
      {
        shares << s;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(entryList)) {
            d->wallet->removeEntry(entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHomesUsers *users : allUsers)
      {
        xmlWriter.writeStartElement("homes");
        
        // FIXME: Remove this block with Smb4K > 2.0 and use the commented line below. 
        // This block was introduced for migration, because the default profile 
        // (i.e. use of no profiles) was not empty but named "Default"...
        if (!Smb4KProfileManager::self()->useProfiles())
        {
          xmlWriter.writeAttribute("profile", Smb4KSettings::self()->activeProfile());
        }
        else
        {
          xmlWriter.writeAttribute("profile", users->profile());
        }
        // xmlWriter.writeAttribute("profile", users->profile());
        xmlWriter.writeTextElement("host", users->hostName());
        xmlWriter.writeTextElement("workgroup", users->workgroupName());
        xmlWriter.writeTextElement("ip", users->hostIP());
        xmlWriter.writeStartElement("users");

        for (const QString &user : users->users())
        {
          xmlWriter.writeTextElement("user", user);
        }

        xmlWriter.writeEndElement();
        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create a new share and set the mountpoint and filesystem
      SharePtr share = SharePtr(new Smb4KShare());
      share->setUrl(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      
      d->importedShares << share;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
  {
    if (Smb4KSettings::useProfiles() && o->profile() != Smb4KProfileManager::self()->activeProfile())
    {
      continue;
    }

#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
    if (o->hasOptions() || (!optionsOnly && o->remount() == Smb4KCustomOptions::RemountOnce))
#else
    if (o->hasOptions())
#endif
    {
      options << o;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *newEntry : newWalletEntries)
      {
        if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive) == 0 /* leave the user info here */ &&
            QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0)
        {
          enable = true;
          break;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : minimalProtocolVersionChoices) {
        minimalProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &oldOptions : oldOptionsList)
        {
          if (!newOptions->equals(oldOptions.data()))
          {
            enable = true;
            break;
          }
          else
          {
            // Do nothing
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *newEntry : qAsConst(newLoginCredentials)) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                        == 0 /* leave the user info here */) {
                    enable = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
      
      if (!mountedShares.isEmpty())
      {
        for (const SharePtr &share : mountedShares)
        {
          if (!share->isForeign())
          {
            mountedBookmarks++;
            break;
          }
          else
          {
            continue;
          }
        }
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->mountedObjects) {
            if (url.matches(obj->url(), QUrl::None)) {
                object = obj;
                break;
            } else if (!exactMatch && url.matches(obj->url(), QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash)) {
                object = obj;
                continue;
            } else {
                continue;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : profiles) {
        Smb4KProfileObject *profile = new Smb4KProfileObject();
        profile->setProfileName(p);

        if (QString::compare(p, Smb4KProfileManager::self()->activeProfile()) == 0) {
            profile->setActiveProfile(true);
        } else {
            profile->setActiveProfile(false);
        }

        d->profileObjects << profile;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create new share and set the mountpoint and the filesystem
      SharePtr share = SharePtr(new Smb4KShare());
      share->setUrl(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      
      d->importedShares << share;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares)) {
                if (!share->isForeign()) {
                    remountShare = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    // FIXME: Check if the bookmarked share has already been mounted.
    SharePtr share = SharePtr(new Smb4KShare());
    share->setHostName(bookmark->hostName());
    share->setShareName(bookmark->shareName());
    share->setWorkgroupName(bookmark->workgroupName());
    share->setHostIpAddress(bookmark->hostIpAddress());
    share->setLogin(bookmark->login());
    mounts << share;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible() && !Smb4KSynchronizer::self()->isRunning(item->shareItem()))
    {
      Smb4KSynchronizer::self()->synchronize(item->shareItem());
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
  {
    HostPtr host = findHost(bookmark->hostName(), bookmark->workgroupName());
    
    if (host)
    {
      if (host->hasIP() && bookmark->hostIP() != host->ip())
      {
        bookmark->setHostIP(host->ip());
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIP(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : items)
    {
      Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (browserItem && browserItem->shareItem()->isMounted() && !browserItem->shareItem()->isForeign())
      {
        //
        // Subtract shares mounted by the user
        // 
        unmountedShares--;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarks) {
        QListWidgetItem *item = new QListWidgetItem(b->icon(), b->displayString(), listWidget);
        item->setData(Qt::UserRole, static_cast<QUrl>(b->url()));

        m_bookmarks << b;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
  {
    if (QString::compare(b->label().toUpper(), label.toUpper()) == 0)
    {
      bookmark = b;
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHomesUsers *users : list)
  {
    allUsers << new Smb4KHomesUsers(*users);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks) {
        if (QString::compare(bookmark->profile(), from, Qt::CaseSensitive) == 0) {
            bookmark->setProfile(to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPrintDialog *p : d->printDialogs)
  {
    if (share == p->share())
    {
      dlg = p;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPrintDialog *p : d->printDialogs)
  {
    if (share == p->share())
    {
      dlg = p;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
  {
    if (QString::compare(m_auth_info->url().toString(QUrl::RemovePort),
                         authInfo->url().toString(QUrl::RemovePort),
                         Qt::CaseInsensitive) == 0 /* we can leave the user info here */ ||
        (m_auth_info->type() == UnknownNetworkItem && m_auth_info->type() == authInfo->type()))
    {
      switch (m_auth_info->type())
      {
        case Host:
        case Share:
        {
          authInfo->setWorkgroupName(m_auth_info->workgroupName());
          authInfo->setUserName(m_auth_info->userName());
          authInfo->setPassword(m_auth_info->password());
          break;
        }
        default:
        {
          authInfo->setUserName(m_auth_info->userName());
          authInfo->setPassword(m_auth_info->password());
          break;
        }
      }
      
      break;
    }
    else
    {
      // Do nothing
    }          
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
  {
    switch (authInfo->type())
    {
      case UnknownNetworkItem:
      {
        (void) new QListWidgetItem(KDE::icon("dialog-password"), i18n("Default Login"), m_entries_widget);
        break;
      }
      default:
      {
        (void) new QListWidgetItem(KDE::icon("dialog-password"), authInfo->displayString(), m_entries_widget);
        break;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : m_listing) {
            if (item->data(Qt::UserRole).toUrl().matches(f->url(), QUrl::None)) {
                m_currentItem = f;
                emit requestPreview(m_currentItem);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList) {
        if (s->isInaccessible()) {
            inaccessibleShares += s;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->mountedSharesList)) {
                if (!s->isForeign()) {
                    p->onlyForeignShares = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : d->bookmarks)
    {
      if (b->profile() == Smb4KSettings::activeProfile())
      {
        bookmarks << b;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
      {
        if (hasCustomOptions(options) || options->remount() == Smb4KCustomOptions::RemountOnce)
        {
          xmlWriter.writeStartElement("options");
          xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
          xmlWriter.writeAttribute("profile", options->profile());

          xmlWriter.writeTextElement("workgroup", options->workgroupName());
          xmlWriter.writeTextElement("unc", options->unc());
          xmlWriter.writeTextElement("ip", options->ip());
          
          xmlWriter.writeStartElement("custom");

          QMap<QString,QString> map = options->customOptions();
          QMapIterator<QString,QString> it(map);

          while (it.hasNext())
          {
            it.next();

            if (!it.value().isEmpty())
            {
              xmlWriter.writeTextElement(it.key(), it.value());
            }
            else
            {
              // Do nothing
            }
          }

          xmlWriter.writeEndElement();
          xmlWriter.writeEndElement();
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (!s->isForeign())
      {
        p->onlyForeignShares = false;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
  {
    switch (o->type())
    {
      case Host:
      {
        QListWidgetItem *item = new QListWidgetItem(KDE::icon("network-server"), o->unc(), m_custom_options, Host);
        item->setData(Qt::UserRole, o->url().toDisplayString());
        break;
      }
      case Share:
      {
        QListWidgetItem *item = new QListWidgetItem(KDE::icon("folder-network"), o->unc(), m_custom_options, Share);
        item->setData(Qt::UserRole, o->url().toDisplayString());
        break;
      }
      default:
      {
        break;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          bookmarkAction->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
      {
        o->setIpAddress(m_currentOptions->ipAddress());
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
        o->setUseUser(m_currentOptions->useUser());
        o->setUser(m_currentOptions->user());
        o->setUseGroup(m_currentOptions->useGroup());
        o->setGroup(m_currentOptions->group());
        o->setUseFileMode(m_currentOptions->useFileMode());
        o->setFileMode(m_currentOptions->fileMode());
        o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
        o->setDirectoryMode(m_currentOptions->directoryMode());
#endif
#if defined(Q_OS_LINUX)
        o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
        o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
        o->setFileSystemPort(m_currentOptions->fileSystemPort());
        o->setUseSecurityMode(m_currentOptions->useSecurityMode());
        o->setSecurityMode(m_currentOptions->securityMode());
        o->setUseWriteAccess(m_currentOptions->useWriteAccess());
        o->setWriteAccess(m_currentOptions->writeAccess());
#endif
        o->setUseSmbPort(m_currentOptions->useSmbPort());
        o->setSmbPort(m_currentOptions->smbPort());
        o->setUseKerberos(m_currentOptions->useKerberos());
        o->setMACAddress(m_currentOptions->macAddress());
        o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
        o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::sharesList())
  {
    d->shareObjects << new Smb4KNetworkObject(share.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList()) {
        if (share->shareName().contains(item, Qt::CaseInsensitive)) {
            results << share;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create new share and set the mountpoint and the filesystem
      SharePtr share = SharePtr(new Smb4KShare());
      share->setUrl(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          // Do nothing
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      else
      {
        // Do nothing
      }
      
      d->importedShares << share;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : qAsConst(userList)) {
                    //
                    // Create a temp share
                    //
                    SharePtr tempShare = share;

                    //
                    // Set the login
                    //
                    tempShare->setLogin(user);

                    //
                    // Read the authentication information
                    //
                    readLoginCredentials(tempShare);

                    //
                    // Save the authentication data in the map
                    //
                    knownLogins.insert(tempShare->login(), tempShare->password());

                    //
                    // Clear the temp share
                    //
                    tempShare.clear();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : qAsConst(m_entriesList)) {
        if (QString::compare(detailsWidget->item(0, 1)->text(), authInfo->displayString()) == 0
            || (QString::compare(detailsWidget->item(0, 1)->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem)) {
            switch (authInfo->type()) {
            case Host:
            case Share: {
                if (column == 1) {
                    switch (row) {
                    case 1: // Workgroup
                    {
                        authInfo->setWorkgroupName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 2: // Login
                    {
                        authInfo->setUserName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 3: // Password
                    {
                        authInfo->setPassword(detailsWidget->item(row, column)->text());
                        break;
                    }
                    default: {
                        break;
                    }
                    }
                }

                break;
            }
            default: {
                if (column == 1) {
                    switch (row) {
                    case 1: // Login
                    {
                        authInfo->setUserName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 2: // Password
                    {
                        authInfo->setPassword(detailsWidget->item(row, column)->text());
                        break;
                    }
                    default: {
                        break;
                    }
                    }
                }

                break;
            }
            }

            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
    {
        lookupDomainMembers(workgroup);
    
        while(isRunning())
        {
            QTest::qWait(50);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : qAsConst(oldLoginCredentials)) {
            for (Smb4KAuthInfo *newEntry : qAsConst(newLoginCredentials)) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                    == 0 /* leave the user info here */) {
                    enable = true;
                    break;
                }
            }

            if (enable) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints))
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create a new share and set the mountpoint and filesystem
      SharePtr share = SharePtr(new Smb4KShare());
      share->setUrl(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      
      d->importedShares << share;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
      {
        if (!s->isForeign())
        {
          p->onlyForeignShares = false;
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList()) {
        // We do not need to use slotShareUnmounted() here, too,
        // because slotShareMounted() will take care of everything
        // we need here.
        slotShareMounted(share);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible())
    {
      openShare(item->shareItem(), Konsole);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : m_actionCollection->actions())
  {
    m_contextMenu->addAction(a);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : items)
    {
      Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (browserItem && browserItem->shareItem()->isMounted() && !browserItem->shareItem()->isForeign())
      {
        //
        // Subtract shares mounted by the user
        // 
        unmountedShares--;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KProfileObject *profile : d->profileObjects)
  {
    if (QString::compare(profile->profileName(), activeProfile) == 0)
    {
      profile->setActiveProfile(true);
    }
    else
    {
      profile->setActiveProfile(false);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : sharesList())
  {
    d->shareObjects << new Smb4KNetworkObject(share);
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                    if (!isRunning()) {
                        if (d->firstImportDone && d->importedShares.isEmpty() && d->newlyMounted > 1) {
                            Smb4KNotification::sharesMounted(d->newlyMounted);
                        }

                        d->newlyMounted = 0;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarksList)) {
        d->bookmarkObjects << new Smb4KBookmarkObject(bookmark.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList)
    {
      if (Smb4KSettings::useProfiles())
      {
        options->setProfile(Smb4KProfileManager::self()->activeProfile());
      }
      
      if (options->hasOptions())
      {
        d->options << options;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (s->url().matches(url, QUrl::RemoveUserInfo|QUrl::RemovePort) && (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0))
    {
      share = s;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : job->hosts())
    {
      if (h->workgroupName() == host->workgroupName() && h->hostName() == host->hostName())
      {
        found = true;
        break;
      }
      else
      {
        continue;
      }        
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(d->tempHostList)) {
                if (h->workgroupName() == host->workgroupName() && h->hostName() == host->hostName()) {
                    foundHost = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profile : profiles) {
        QAction *action = addAction(profile);

        if (action) {
            action->setEnabled(Smb4KProfileManager::self()->useProfiles());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : job->shares())
    {
        // Process only those shares that the user wants to see
        if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
        {
            continue;
        }
      
        if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
        {
            continue;
        }
      
        // Add or update the shares
        if (!findShare(share->url(), share->workgroupName()))
        {
            addShare(share);
        }
        else
        {
            updateShare(share);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profile : qAsConst(profiles)) {
        QAction *action = addAction(profile);

        if (action) {
            action->setEnabled(Smb4KProfileManager::self()->useProfiles());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->sharesList)
  {
    if (QString::compare(s->hostName(), host->hostName(), Qt::CaseInsensitive) == 0 &&
        QString::compare(s->workgroupName(), host->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      shares += s;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList) {
        if (QString::compare(h->workgroupName(), workgroup->workgroupName(), Qt::CaseInsensitive) == 0) {
            hosts << h;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : bookmarks)
  {
    m_bookmarks << new Smb4KBookmark(*bookmark);
    
    if (!m_groups.contains(bookmark->groupName()))
    {
      m_groups << bookmark->groupName();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
      {
        if (!bookmark->url().isValid())
        {
          Smb4KNotification::invalidURLPassed();
          continue;
        }
        
        xmlWriter.writeStartElement("bookmark");
        xmlWriter.writeAttribute("profile", bookmark->profile());
        xmlWriter.writeAttribute("group", bookmark->groupName());

        xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
        xmlWriter.writeTextElement("url", bookmark->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort));
        xmlWriter.writeTextElement("login", bookmark->login());
        xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
        xmlWriter.writeTextElement("label", bookmark->label());

        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList())
  {
    if (share->shareName().contains(item, Qt::CaseInsensitive))
    {
      results << share;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares) {
                if (networkItem->shareItem() == share) {
                    //
                    // Select the search result
                    //
                    networkItem->setSelected(true);

                    //
                    // Expand the branch of the network tree where a search result
                    // was retrieved
                    //
                    if (!networkItem->parent()->isExpanded()) {
                        m_networkBrowser->expandItem(networkItem->parent());
                    }

                    if (!networkItem->parent()->parent()->isExpanded()) {
                        m_networkBrowser->expandItem(networkItem->parent()->parent());
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(unmountedShares))
    {
      // 
      // Remove the mountpoint if the share is not a foreign one
      // 
      if (!share->isForeign())
      {
        QDir dir;
        dir.cd(share->canonicalPath());
        dir.rmdir(dir.canonicalPath());
          
        if (dir.cdUp())
        {
          dir.rmdir(dir.canonicalPath());
        }
      }
      
      //
      // Mark it as unmounted
      // 
      share->setMounted(false);
      
      // 
      // Copy the share
      // 
      SharePtr unmountedShare = share;
        
      // 
      // Remove the share from the global list and notify the program
      // 
      removeMountedShare(share);
      emit unmounted(unmountedShare);
      
      //
      // Report the unmounted share to the user if it is a single one
      // 
      if (!isRunning() && d->newlyUnmounted == 1)
      {
        Smb4KNotification::shareUnmounted(unmountedShare);
      }
      
      unmountedShare.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems)
    {
      Smb4KNetworkSearchItem *searchItem = static_cast<Smb4KNetworkSearchItem *>(item);
      
      if (searchItem && searchItem->shareItem()->isMounted())
      {
        mounted << searchItem->shareItem();
      }
      else if (searchItem && !searchItem->shareItem()->isMounted())
      {
        unmounted << searchItem->shareItem();
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(*pHosts)) {
            //
            // On a local network there will most likely be no two servers with
            // identical name, thus, to avoid duplicates, only test the hostname
            // here.
            //
            if (QString::compare(h->hostName(), service->serviceName(), Qt::CaseInsensitive) == 0) {
                foundServer = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(d->bookmarks)) {
                if (!bookmark->url().isValid()) {
                    Smb4KNotification::invalidURLPassed();
                    continue;
                }

                xmlWriter.writeStartElement("bookmark");
                xmlWriter.writeAttribute("profile", bookmark->profile());
                xmlWriter.writeAttribute("category", bookmark->categoryName());

                xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
                xmlWriter.writeTextElement("url", bookmark->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort));
                xmlWriter.writeTextElement("login", bookmark->login());
                xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
                xmlWriter.writeTextElement("label", bookmark->label());

                xmlWriter.writeEndElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
    {
      if (QString::compare(selectedItems.first()->text(), authInfo->displayString()) == 0 ||
          (QString::compare(selectedItems.first()->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem))
      {
        showDetails(authInfo);
        break;
      }
      else
      {
        continue;
      }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (KDNSSD::RemoteService::Ptr service) {
            switch (m_process)
            {
              case LookupDomains:
              {
                //
                // Check if the workgroup/domain is already known
                // 
                bool foundWorkgroup = false;
                
                for (const WorkgroupPtr &w : qAsConst(m_workgroups))
                {
                  if (QString::compare(w->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0)
                  {
                    foundWorkgroup = true;
                    break;
                  }
                }
                
                //
                // If the workgroup is not known yet, add it to the list
                // 
                if (!foundWorkgroup)
                {
                  //
                  // Create the workgroup item
                  // 
                  WorkgroupPtr workgroup = WorkgroupPtr(new Smb4KWorkgroup());
                  
                  //
                  // Set the _DNS-SD_ domain name
                  // 
                  workgroup->setWorkgroupName(service->domain());
                  
                  //
                  // Tell the program that the workgroup was discovered by DNS-SD
                  // 
                  workgroup->setDnsDiscovered(true);
                  
                  //
                  // Add the workgroup
                  // 
                  m_workgroups << workgroup;
                }
                break;
              }
              case LookupDomainMembers:
              {
                //
                // Check if the server is already known
                // 
                bool foundServer = false;
                
                for (const HostPtr &h : qAsConst(m_hosts))
                {
                  //
                  // On a local network there will most likely be no two servers with
                  // identical name, thus, to avoid duplicates, only test the hostname
                  // here.
                  // 
                  if (QString::compare(h->hostName(), service->serviceName(), Qt::CaseInsensitive) == 0)
                  {
                    foundServer = true;
                    break;
                  }
                }
                
                //
                // If the server is not known yet, add it to the list
                // 
                if (!foundServer)
                {
                  //
                  // Create the host item
                  // 
                  HostPtr host = HostPtr(new Smb4KHost());
                  
                  //
                  // Set the _DNS-SD_ host name
                  // 
                  host->setHostName(service->serviceName());
                  
                  //
                  // Set the _DNS-SD_ domain name
                  // 
                  host->setWorkgroupName(service->domain());
                  
                  //
                  // Tell the program that the workgroup was discovered by DNS-SD
                  //                   
                  host->setDnsDiscovered(true);
                  
                  // 
                  // Lookup IP address
                  // 
                  QHostAddress address = lookupIpAddress(service->serviceName());
          
                  // 
                  // Process the IP address. 
                  // 
                  if (!address.isNull())
                  {
                    host->setIpAddress(address);
                  }
                  
                  //
                  // Add the host
                  // 
                  m_hosts << host;
                }
                
                break;
              }
              default:
              {
                break;
              }
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : addresses)
        {
            // We only use global addresses.
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
            if (addr.isGlobal())
#else
            if (!addr.isLoopback() && !addr.isMulticast())
#endif

            {
                if (addr.protocol() == QAbstractSocket::IPv4Protocol)
                {
                    ipAddress = addr;
                    break;
                }
                else if (addr.protocol() == QAbstractSocket::IPv6Protocol)
                {
                    // FIXME: Use the right address here.
                    ipAddress = addr;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
  {
    if (!groups.contains(b->groupName()))
    {
      groups << b->groupName();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (share->unc() == a->data().toMap().value("unc").toString())
      {
        a->setEnabled(!share->isMounted());
        bookmarkGroup = a->data().toMap().value("group").toString();
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
          {
            lookupDomainMembers(workgroup);
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : users->users()) {
                    xmlWriter.writeTextElement("user", user);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : items) {
            Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (browserItem && browserItem->shareItem()->isMounted() && !browserItem->shareItem()->isForeign()) {
                //
                // Subtract shares mounted by the user
                //
                unmountedShares--;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(actionsList)) {
            if (action->objectName() == "edit_action") {
                action->setEnabled(item != 0);
            } else if (action->objectName() == "remove_action") {
                action->setEnabled(item != 0);
            } else if (action->objectName() == "clear_action") {
                action->setEnabled(optionsListWidget->count() != 0);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : qAsConst(d->tempHostList)) {
            if (host->workgroupName() == newHost->workgroupName() && host->hostName() == newHost->hostName()) {
                foundHost = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList) {
                if (!s->isForeign()) {
                    p->onlyForeignShares = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPrintDialog *p : d->printDialogs) {
        if (share == p->share()) {
            dlg = p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints))
  {
    mountpoints.removeOne(mountPoint->mountPoint());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &interface : qAsConst(interfaces)) {
        if (interface.isValid() && interface.type() != QNetworkInterface::Loopback && interface.flags() & QNetworkInterface::IsRunning && !online)
        {
            online = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList()) {
            // NOTE: Since also user provided URLs can be bookmarked, we cannot use
            // QUrl::matches() here, because it does not allow for case insensitive
            // comparison.
            if (QString::compare(url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 b->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 Qt::CaseInsensitive)
                == 0) {
                bookmark = b;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
    {
      QList<QTreeWidgetItem *> items = m_networkBrowser->findItems(workgroup->workgroupName(), Qt::MatchFixedString, Smb4KNetworkBrowser::Network);
        
      if (items.isEmpty())
      {
        (void) new Smb4KNetworkBrowserItem(m_networkBrowser, workgroup);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KWorkgroup *workgroup : workgroupsList())
    {
      QList<QTreeWidgetItem *> items = m_widget->findItems(workgroup->workgroupName(), Qt::MatchFixedString, Smb4KNetworkBrowser::Network);
      
      if (items.isEmpty())
      {
        (void) new Smb4KNetworkBrowserItem(m_widget, workgroup);
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharePtr s : p->searchResults)
      {
        if (share->url().matches(s->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
        {
          s->setMountData(share.data());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : job->workgroups())
  {
    if (!findWorkgroup(workgroup->workgroupName()))
    {
      addWorkgroup(workgroup);
      
      // Since this is a new workgroup, no master browser is present.
      HostPtr masterBrowser = HostPtr(new Smb4KHost());
      masterBrowser->setWorkgroupName(workgroup->workgroupName());
      masterBrowser->setHostName(workgroup->masterBrowserName());
      masterBrowser->setIpAddress(workgroup->masterBrowserIpAddress());
      masterBrowser->setIsMasterBrowser(true);
      
      addHost(masterBrowser);
    }
    else
    {
      updateWorkgroup(workgroup);
      
      // Check if the master browser changed
      QList<HostPtr> members = workgroupMembers(workgroup);
      
      for (const HostPtr &host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress())
          {
            host->setIpAddress(workgroup->masterBrowserIpAddress());
          }
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName())
        {
          o->setIpAddress(options->ipAddress());
          o->setUseUser(options->useUser());
          o->setUser(options->user());
          o->setUseGroup(options->useGroup());
          o->setGroup(options->group());
          o->setUseFileMode(options->useFileMode());
          o->setFileMode(options->fileMode());
          o->setUseDirectoryMode(options->useDirectoryMode());
          o->setDirectoryMode(options->directoryMode());
#if defined(Q_OS_LINUX)
          o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
          o->setUseFileSystemPort(options->useFileSystemPort());
          o->setFileSystemPort(options->fileSystemPort());
          o->setUseSmbMountProtocolVersion(options->useSmbMountProtocolVersion());
          o->setSmbMountProtocolVersion(options->smbMountProtocolVersion());
          o->setUseSecurityMode(options->useSecurityMode());
          o->setSecurityMode(options->securityMode());
          o->setUseWriteAccess(options->useWriteAccess());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUseSmbPort(options->useSmbPort());
          o->setSmbPort(options->smbPort());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
        // FIXME: Check if the bookmarked share has already been mounted.
        SharePtr share = SharePtr(new Smb4KShare());
        share->setHostName(bookmark->hostName());
        share->setShareName(bookmark->shareName());
        share->setWorkgroupName(bookmark->workgroupName());
        share->setHostIpAddress(bookmark->hostIpAddress());
        share->setLogin(bookmark->login());
        mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->workgroupObjects) {
                if (url == obj->url()) {
                    object = obj;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList()) {
        lookupDomainMembers(workgroup);

        while (isRunning()) {
            wait(50);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_manager->activePart()->actionCollection()->actions())
    {
      if (action)
      {
        if (QString::compare(action->objectName(), "bookmark_action") == 0)
        {
          actionCollection()->action("bookmark_action")->setEnabled(action->isEnabled());
          
          if (bookmarkMenu)
          {
            Smb4KEvent *customEvent = 0;
            
            if (action->isEnabled())
            {
              customEvent = new Smb4KEvent(Smb4KEvent::EnableBookmarkAction);
            }
            else
            {
              customEvent = new Smb4KEvent(Smb4KEvent::DisableBookmarkAction);
            }
              
            QApplication::postEvent(bookmarkMenu, customEvent);
          }
          else
          {
            // Do nothing
          }          
          
          connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
          continue;
        }
        else if (QString::compare(action->objectName(), "filemanager_action") == 0)
        {
          continue;
        }
        else if (QString::compare(action->objectName(), "konsole_action") == 0)
        {
          continue;
        }
        else if (QString::compare(action->objectName(), "icon_view_action") == 0)
        {
          continue;
        }
        else if (QString::compare(action->objectName(), "list_view_action") == 0)
        {
          continue;
        }
        else
        {
          // Do nothing
        }

        dynamicList << action;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : qAsConst(maximalProtocolVersionChoices)) {
        maximalProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create new share and set the mountpoint and the filesystem
      SharePtr share = SharePtr(new Smb4KShare(mountPoint->mountedFrom()));
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIP(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          // Do nothing
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      else
      {
        // Do nothing
      }
      
      d->importedShares << share;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : Smb4KGlobal::hostsList()) {
                if (host->url() == object->url()) {
                    Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(host);
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KProfileObject *profile : qAsConst(d->profileObjects)) {
        if (QString::compare(profile->profileName(), activeProfile) == 0) {
            profile->setActiveProfile(true);
        } else {
            profile->setActiveProfile(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
    bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
    bookmarkItem->setIcon(0, bookmark->icon());
    bookmarkItem->setText(0, bookmark->displayString());
    bookmarkItem->setText((treeWidget->columnCount() - 1), QString("01_%1").arg(bookmark->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)));
    bookmarkItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDragEnabled);
    
    if (!bookmark->categoryName().isEmpty())
    {
      QList<QTreeWidgetItem *> items = treeWidget->findItems(bookmark->categoryName(), Qt::MatchFixedString|Qt::MatchCaseSensitive, 0);
      
      if (!items.isEmpty())
      {
        items.first()->addChild(bookmarkItem);
        items.first()->setExpanded(true);
      }
    }
    else
    {
      treeWidget->addTopLevelItem(bookmarkItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
          {
            bool foundShare = false;
            
            for (int i = 0; i < hostItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));
              
              if (QString::compare(shareItem->shareItem()->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                   share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                   Qt::CaseInsensitive) == 0)
              {
                foundShare = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundShare)
            {
              (void) new Smb4KNetworkBrowserItem(hostItem, share);
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KProfileObject *profile : d->profileObjects) {
        if (QString::compare(profile->profileName(), activeProfile) == 0) {
            profile->setActiveProfile(true);
        } else {
            profile->setActiveProfile(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *b : buttonBox->buttons())
    {
      if (buttonBox->buttonRole(b) == QDialogButtonBox::ResetRole)
      {
        b->setEnabled(!checkDefaultValues());
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &newHost : job->hosts())
    {
        bool foundHost = false;
            
        for (const HostPtr &host : d->tempHostList)
        {
            if (host->workgroupName() == newHost->workgroupName() && host->hostName() == newHost->hostName())
            {
                foundHost = true;
                break;
            }
        }
            
        if (!foundHost)
        {
            d->tempHostList << newHost;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : d->tempHostList) {
            if (host->workgroupName() == newHost->workgroupName() && host->hostName() == newHost->hostName()) {
                foundHost = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
  {
    //
    // Check if the bookmark label is already in use
    // 
    if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
    {
      Smb4KNotification::bookmarkLabelInUse(bookmark.data());
      bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
    }
    else
    {
      // Do nothing
    }
      
    //
    // Check if we have to add the bookmark
    // 
    BookmarkPtr existingBookmark = findBookmarkByUNC(bookmark->unc());
      
    if (!existingBookmark)
    {
      d->bookmarks << bookmark;
    }
    else
    {
      // We do not need to update the bookmark, because we are
      // operating on a shared pointer.
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
  {
    if (url == o->url().toDisplayString())
    {
      options = o;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : qAsConst(optionsList)) {
            //
            // If we want to have an exact match, skip all options that do not match
            //
            if (exactMatch) {
                if (networkItem->type() != opt->type()
                    || QString::compare(networkItem->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                        opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                        Qt::CaseInsensitive)
                        != 0) {
                    continue;
                }
            }

            //
            // Now assign the options
            //
            if (networkItem->type() == Host && opt->type() == Host) {
                HostPtr host = networkItem.staticCast<Smb4KHost>();

                if (host) {
                    if (QString::compare(host->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                         opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                         Qt::CaseInsensitive)
                            == 0
                        || (host->url().isEmpty() && host->ipAddress() == opt->ipAddress())) {
                        options = opt;
                        break;
                    }
                }
            } else if (networkItem->type() == Share) {
                SharePtr share = networkItem.staticCast<Smb4KShare>();

                if (share) {
                    if (opt->type() == Share
                        && QString::compare(share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                            opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                            Qt::CaseInsensitive)
                            == 0) {
                        // Since this is the exact match, break here
                        options = opt;
                        break;
                    } else if (opt->type() == Host
                               && QString::compare(share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath | QUrl::StripTrailingSlash),
                                                   opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath | QUrl::StripTrailingSlash),
                                                   Qt::CaseInsensitive)
                                   == 0) {
                        // These options belong to the host. Do not break here,
                        // because there might still be an exact match
                        options = opt;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(d->remounts)) {
                    if (QString::compare(share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                         option->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort))
                        == 0) {
                        insertShare = false;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : qAsConst(actions)) {
            QUrl bookmarkUrl = a->data().toMap().value("url").toUrl();

            if (share->url().matches(bookmarkUrl, QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                a->setEnabled(!share->isMounted());
                bookmarkCategory = a->data().toMap().value("category").toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *b : qAsConst(buttons)) {
            if (buttonBox->buttonRole(b) == QDialogButtonBox::ResetRole) {
                b->setEnabled(!checkDefaultValues());
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 Qt::CaseInsensitive) == 0)
            {
              options = o;
              break;
            }
            else if (!exactMatch && o->type() == Host && 
                     QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath),
                                      o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath),
                                      Qt::CaseInsensitive) == 0)
            {
              options = o;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : options)
  {
    if (o->type() == Share)
    {
      if (o->remount() == Smb4KCustomOptions::RemountOnce)
      {
        o->setRemount(Smb4KCustomOptions::RemountNever);
      }
      else if (o->remount() == Smb4KCustomOptions::RemountAlways && force)
      {
        o->setRemount(Smb4KCustomOptions::RemountNever);
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members) {
                    bool foundHost = false;

                    for (int i = 0; i < workgroupItem->childCount(); ++i) {
                        Smb4KNetworkBrowserItem *hostItem = static_cast<Smb4KNetworkBrowserItem *>(workgroupItem->child(i));

                        if (hostItem->hostItem()->hostName() == host->hostName()) {
                            foundHost = true;
                            break;
                        }
                    }

                    if (!foundHost) {
                        (void)new Smb4KNetworkBrowserItem(workgroupItem, host);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &newHost : qAsConst(discoveredHosts)) {
        bool foundHost = false;

        QMutableListIterator<HostPtr> it(d->tempHostList);

        while (it.hasNext()) {
            HostPtr host = static_cast<HostPtr>(it.next());

            if (newHost->url().matches(host->url(), QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                if (newHost->workgroupName() == host->workgroupName()) {
                    foundHost = true;
                } else if (host->dnsDiscovered()) {
                    it.remove();
                }

                break;
            }
        }

        if (!foundHost) {
            d->tempHostList << newHost;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      share->setInaccessible(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs())
    {
      if (QString("SyncJob_%1").arg(share->canonicalPath()) == job->objectName())
      {
        job->kill(KJob::EmitResult);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList)
  {
    if ((workgroup.isEmpty() || QString::compare(h->workgroupName(), workgroup, Qt::CaseInsensitive) == 0) &&
        QString::compare(h->hostName(), name, Qt::CaseInsensitive) == 0)
    {
      host = h;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarksList())
  {
    if (QString::compare(category, bookmark->categoryName(), Qt::CaseInsensitive) == 0)
    {
      bookmarks << bookmark;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : hosts)
    {
      Smb4KNetworkBrowserItem *tempHost = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (tempHost->type() == Host && tempHost->hostItem()->workgroupName() == host->workgroupName())
      {
        hostItem = tempHost;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.contains("blocks of size") || line.contains("Domain=["))
      {
        continue;
      }
      else
      {
        QString entry = line;
        
        QString left = entry.trimmed().section("     ", 0, -2).trimmed();
        QString right = entry.remove(left);

        QString name = left.section("  ", 0, -2).trimmed().isEmpty() ?
                       left :
                       left.section("  ", 0, -2).trimmed();

        QString dir_string = left.right(3).trimmed();
        bool is_dir = (!dir_string.isEmpty() && dir_string.contains("D"));

        QString tmp_size = right.trimmed().section("  ", 0, 0).trimmed();
        QString size;

        if (tmp_size[0].isLetter())
        {
          size = right.trimmed().section("  ", 1, 1).trimmed();
        }
        else
        {
          size = tmp_size;
        }

        QString date = QDateTime::fromString(right.section(QString(" %1 ").arg(size), 1, 1).trimmed()).toString();
        
        if (!name.isEmpty())
        {
          if (!name.startsWith('.'))
          {
            Smb4KPreviewFileItem item;
            item.setItemName(name);
            item.setDir(is_dir);
            item.setDate(date);
            item.setItemSize(size);
            items << item;
          }
          else if (name.startsWith('.') && QString::compare(name, ".") != 0 && QString::compare(name, "..") != 0)
          {
            if (Smb4KSettings::previewHiddenItems())
            {
              Smb4KPreviewFileItem item;
              item.setItemName(name);
              item.setDir(is_dir);
              item.setDate(date);
              item.setItemSize(size);
              items << item;
            }
            else
            {
              // Do nothing
            }
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Do nothing
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *mountedShare : mountedShares)
          {
            if (!mountedShare->isForeign())
            {
              share->setMountData(mountedShare);
              break;
            }
            else
            {
              continue;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : sharesList())
        {
          if (share->url() == object->url())
          {
            Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(share);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            // In case of a host, there can only be an exact match.
            if (host->url().matches(o->url(), QUrl::RemoveUserInfo|QUrl::RemovePort) || (host->url().isEmpty() && host->ipAddress() == o->ipAddress()))
            {
              options = o;
              break;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options) {
        if (Smb4KSettings::useProfiles() && options->profile() != Smb4KProfileManager::self()->activeProfile()) {
            continue;
        }

        if (options->hasOptions(withoutRemountOnce)) {
            optionsList << options;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : options)
  {
    if (o->type() == Share)
    {
      if (o->remount() == Smb4KCustomOptions::RemountOnce)
      {
        o->setRemount(Smb4KCustomOptions::RemountNever);
      }
      else if (o->remount() == Smb4KCustomOptions::RemountAlways && force)
      {
        o->setRemount(Smb4KCustomOptions::RemountNever);
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    if (!m_groups.contains(bookmark->groupName()))
    {
      m_groups << bookmark->groupName();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          qDebug() << "Disabling bookmark" << share->url().toDisplayString();
          bookmarkAction->setEnabled(false);
          break;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
  {
    lookupDomainMembers(workgroup);
    
    while(isRunning())
    {
      QTest::qWait(50);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : maximalClientProtocolVersionChoices) {
        maximalClientProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
  {
    if (Smb4KSettings::useProfiles() && o->profile() != Smb4KProfileManager::self()->activeProfile())
    {
      continue;
    }

    if (o->hasOptions() || (!optionsOnly && o->remount() == Smb4KCustomOptions::RemountOnce))
    {
      options << o;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : qAsConst(m_entriesList)) {
        if (QString::compare(detailsWidget->item(0, 1)->text(), authInfo->displayString()) == 0
            || (QString::compare(detailsWidget->item(0, 1)->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem)) {
            switch (authInfo->type()) {
            case Host:
            case Share: {
                if (column == 1) {
                    switch (row) {
                    case 1: // Login
                    {
                        authInfo->setUserName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 2: // Password
                    {
                        authInfo->setPassword(detailsWidget->item(row, column)->text());
                        break;
                    }
                    default: {
                        break;
                    }
                    }
                }

                break;
            }
            default: {
                if (column == 1) {
                    switch (row) {
                    case 1: // Login
                    {
                        authInfo->setUserName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 2: // Password
                    {
                        authInfo->setPassword(detailsWidget->item(row, column)->text());
                        break;
                    }
                    default: {
                        break;
                    }
                    }
                }

                break;
            }
            }

            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares) {
        mountShare(share);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
  {
    if (QString::compare(bookmark->profile(), from, Qt::CaseSensitive) == 0)
    {
      bookmark->setProfile(to);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->mountedSharesList)) {
            if (QString::compare(s->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 Qt::CaseInsensitive)
                == 0) {
                shares << s;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPreviewDialog *p : d->previewDialogs)
  {
    if (share == p->share())
    {
      dlg = p;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : d->bookmarks)
    {
      if (b->profile() == Smb4KSettings::activeProfile())
      {
        bookmarks << b;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KNetworkSearchItem *item = static_cast<Smb4KNetworkSearchItem *>(selectedItem);
    
    if (item->type() == Share)
    {
      shares << item->shareItem();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : list)
            {
                QListWidgetItem *item = new QListWidgetItem(f->icon(), f->name(), listWidget, f->isDirectory() ? Directory : File);
                item->setData(Qt::UserRole, f->url());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
        {
          if (!share->isForeign())
          {
            mountedBookmarks++;
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create new share and set the mountpoint and the filesystem
      Smb4KShare *share = new Smb4KShare(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIP(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          // Do nothing
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      else
      {
        // Do nothing
      }
      
      d->importedShares << share;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : qAsConst(temporalBookmarkList)) {
            // NOTE: Since also user provided URLs can be bookmarked, we cannot use
            // QUrl::matches() here, because it does not allow for case insensitive
            // comparison.
            if (QString::compare(url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 b->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 Qt::CaseInsensitive)
                == 0) {
                bookmark = b;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
      {
        check(share);
        emit updated(share);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : unmountedShares)
        {
          // Copy the share
          SharePtr unmountedShare = share;
          
          // Remove the share from the global list and notify the program
          removeMountedShare(share);
          emit unmounted(unmountedShare);
          unmountedShare.clear();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList()) {
        lookupShares(host);

        while (isRunning()) {
            QTest::qWait(50);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->mountedSharesList)
    {
      if (QString::compare(s->unc(), unc, Qt::CaseInsensitive) == 0)
      {
        shares += s;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *b : d->bookmarks)
    {
      if (!d->groups.contains(b->groupName()))
      {
        d->groups << b->groupName();
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : qAsConst(maximalClientProtocolVersionChoices)) {
        maximalClientProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members)
          {
            bool foundHost = false;
            
            for (int i = 0; i < workgroupItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *hostItem = static_cast<Smb4KNetworkBrowserItem *>(workgroupItem->child(i));
              
              if (hostItem->hostItem()->hostName() == host->hostName())
              {
                foundHost = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundHost)
            {
              (void) new Smb4KNetworkBrowserItem(workgroupItem, host);
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *b : d->bookmarks)
  {
    if (QString::compare(b->unc().toUpper(), unc.toUpper()) == 0)
    {
      bookmark = b;
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares)
  {
    //
    // Check that the URL is valid.
    //
    if (!share->url().isValid())
    {
      Smb4KNotification::invalidURLPassed();
      return;
    }
    else
    {
      // Do nothing
    }
    
    //
    // Handle foreign shares according to the settings
    //
    if (share->isForeign())
    {
      if (!Smb4KSettings::unmountForeignShares())
      {
        if (!silent)
        {
          Smb4KNotification::unmountingNotAllowed(share);
        }
        else
        {
          // Do nothing
        }
        continue;
      }
      else
      {
        if (!silent)
        {
          if (KMessageBox::warningYesNo(parent,
              i18n("<qt><p>The share <b>%1</b> is mounted to <br><b>%2</b> and owned by user <b>%3</b>.</p>"
                  "<p>Do you really want to unmount it?</p></qt>",
                  share->unc(), share->path(), share->user().loginName()),
              i18n("Foreign Share")) == KMessageBox::No)
          {
            continue;
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Without the confirmation of the user, we are not
          // unmounting a foreign share!
          continue;
        }
      }
    }
    else
    {
      // Do nothing
    }
    
    
    //
    // Force the unmounting of the shares either if the system went offline
    // or if the user chose to forcibly unmount inaccessible shares (Linux only).
    //
    bool force = false;
    
    if (Smb4KHardwareInterface::self()->isOnline())
    {
#if defined(Q_OS_LINUX)
      if (share->isInaccessible())
      {
        force = Smb4KSettings::forceUnmountInaccessible();
      }
      else
      {
        // Do nothing
      }
#endif
    }
    else
    {
      force = true;
    }

    //
    // Unmount arguments
    //
    QVariantMap args;

    if (!fillUnmountActionArgs(share, force, silent, args))
    {
      continue;
    }
    else
    {
      // Do nothing
    }

    map.insert(QString("%1").arg(map.size()), args);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : p->workgroupsList) {
        if (QString::compare(w->workgroupName(), name, Qt::CaseInsensitive) == 0) {
            workgroup = w;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
  {
    if (o->type() == Share)
    {
      if (o->remount() == Smb4KCustomOptions::RemountOnce)
      {
        o->setRemount(Smb4KCustomOptions::UndefinedRemount);
      }
      else if (o->remount() == Smb4KCustomOptions::RemountAlways && force)
      {
        o->setRemount(Smb4KCustomOptions::UndefinedRemount);
      }
    }
    
    if (!o->hasOptions())
    {
      removeCustomOptions(o, false);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : addresses)
    {
      // We only use global addresses.
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
      if (addr.isGlobal())
#else
      if (!addr.isLoopback() && !addr.isMulticast())
#endif
      {
        if (addr.protocol() == QAbstractSocket::IPv4Protocol)
        {
          ipAddress = addr;
          break;
        }
        else if (addr.protocol() == QAbstractSocket::IPv6Protocol)
        {
          // FIXME: Use the right address here.
          ipAddress = addr;
        }
        else
        {
          // Do nothing
        }
      }
      else
      {
        // Do nothing
      }      
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options) {
                if (options->hasOptions()) {
                    xmlWriter.writeStartElement("options");
                    xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
                    xmlWriter.writeAttribute("profile", options->profile());

                    xmlWriter.writeTextElement("workgroup", options->workgroupName());
                    xmlWriter.writeTextElement("url", options->url().toDisplayString());
                    xmlWriter.writeTextElement("ip", options->ipAddress());

                    xmlWriter.writeStartElement("custom");

                    QMap<QString, QString> map = options->customOptions();
                    QMapIterator<QString, QString> it(map);

                    while (it.hasNext()) {
                        it.next();

                        if (!it.value().isEmpty()) {
                            xmlWriter.writeTextElement(it.key(), it.value());
                        }
                    }

                    xmlWriter.writeEndElement();
                    xmlWriter.writeEndElement();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : maximalProtocolVersionChoices)
  {
    maximalProtocolVersion->addItem(c.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : networkSearchDock->widget()->children())
  {
    obj->installEventFilter(this);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions())
  {
    if (action)
    {
      action->setEnabled(use);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList)
  {
    if (QString::compare(h->workgroupName(), workgroup->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      hosts << h;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &interface : qAsConst(interfaces)) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
        if (interface.isValid() && interface.type() != QNetworkInterface::Loopback && interface.flags() & QNetworkInterface::IsRunning && !online)
#else
        if (interface.isValid() && !(interface.flags() & QNetworkInterface::IsLoopBack) && interface.flags() & QNetworkInterface::IsRunning && !online)
#endif
        {
            online = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
  {
    if (s->isInaccessible())
    {
      inaccessibleShares += s;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &p : shares)
      {
        qDebug() << p->url();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->unc());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->unc());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHomesUsers *users : list) {
        allUsers << new Smb4KHomesUsers(*users);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(mountedShares)) {
                    if (!s->isForeign()) {
                        share->setMountData(s.data());
                        break;
                    } else {
                        continue;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks) {
            // FIXME: Check if the bookmarked share has already been mounted.
            SharePtr share = SharePtr(new Smb4KShare());
            share->setHostName(bookmark->hostName());
            share->setShareName(bookmark->shareName());
            share->setWorkgroupName(bookmark->workgroupName());
            share->setHostIpAddress(bookmark->hostIpAddress());
            share->setLogin(bookmark->login());
            mounts << share;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(mountedShares))
    {
      if (!s->isForeign())
      {
        isMounted = true;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *mountedShare : mountedSharesList())
  {
    for (Smb4KShare *importedShare : d->importedShares)
    {
      // Check the mountpoint, since that one is unique. We will only use
      // Smb4KShare::path(), so that we do not run into trouble if a share 
      // is inaccessible.
      if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
      {
        found = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
    
    if (!found)
    {
      // Remove the mountpoint if the share is not a foreign one
      if (!mountedShare->isForeign())
      {
        QDir dir;
        dir.cd(mountedShare->canonicalPath());
        dir.rmdir(dir.canonicalPath());
        
        if (dir.cdUp())
        {
          dir.rmdir(dir.canonicalPath());
        }
        else
        {
          // Do nothing
        }        
      }
      else
      {
        // Do nothing
      }
      
      mountedShare->setMounted(false);
      unmountedShares << mountedShare;
    }
    else
    {
      // Do nothing
    }
    
    found = false;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : mountedSharesList())
    {
      share->setInaccessible(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible())
    {
      openShare(item->shareItem(), Konsole);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : p->workgroupsList)
  {
    if (QString::compare(w->workgroupName(), name, Qt::CaseInsensitive) == 0)
    {
      workgroup = w;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : qAsConst(members))
                {
                    if (workgroup->masterBrowserName() == host->hostName())
                    {
                        host->setIsMasterBrowser(true);
          
                        if (!host->hasIpAddress() && workgroup->hasMasterBrowserIpAddress())
                        {
                            host->setIpAddress(workgroup->masterBrowserIpAddress());
                        }
                    }
                    else
                    {
                        host->setIsMasterBrowser(false);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : allActions) {
            if (a->data().toMap().value("type").toString() == "toplevel_mount" && bookmarkCategory.isEmpty()) {
                a->setEnabled(!allMounted);
                break;
            } else if (a->data().toMap().value("type").toString() == "category_mount" && a->data().toMap().value("category").toString() == bookmarkCategory) {
                a->setEnabled(!allMounted);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : unmountedShares)
        {
          // Copy the share
          Smb4KShare unmountedShare(*share);
          
          // Remove the share from the global list and notify the program
          removeMountedShare(share);
          emit unmounted(&unmountedShare);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : qAsConst(m_listing)) {
            if (item->data(Qt::UserRole).toUrl().matches(f->url(), QUrl::None)) {
                m_currentItem = f;
                emit requestPreview(m_currentItem);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
  {
    // Unmount the share
    unmountShare(share, silent);
    
    // Wait for 50 ms so we can act on the networkShareRemoved() 
    // signal and we do not trigger a busy error from mount.cifs
    QTest::qWait(50);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
  {
    if (QString::compare(m_details_widget->item(0, 1)->text(), authInfo->displayString()) == 0 ||
        (QString::compare(m_details_widget->item(0, 1)->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem))
    {
      switch (authInfo->type())
      {
        case Host:
        case Share:
        {
          if (column == 1)
          {
            switch (row)
            {
              case 1: // Workgroup
              {
                authInfo->setWorkgroupName(m_details_widget->item(row, column)->text());
                break;
              }
              case 2: // Login
              {
                authInfo->setUserName(m_details_widget->item(row, column)->text());
                break;
              }
              case 3: // Password
              {
                authInfo->setPassword(m_details_widget->item(row, column)->text());
                break;
              }
              default:
              {
                break;
              }
            }
          }
            
          break;
        }
        default:
        {
          if (column == 1)
          {
            switch (row)
            {
              case 1: // Login
              {
                authInfo->setUserName(m_details_widget->item(row, column)->text());
                break;
              }
              case 2: // Password
              {
                authInfo->setPassword(m_details_widget->item(row, column)->text());
                break;
              }
              default:
              {
                break;
              }
            }
          }
            
          break;
        }
      }
        
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &editedOptions : qAsConst(editedOptionsList)) {
                if (editedOptions->url().matches(options->url(), QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                    // We do not need to update the custom options, because we are
                    // using QSharedPointers.
                    foundOptions = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList)
  {
    if (QString::compare(h->workgroupName(), workgroup->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      hosts += h;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
    {
      if (QString::compare(b->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                           Qt::CaseInsensitive) == 0)
      {
        bookmark = b;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : qAsConst(hosts)) {
            Smb4KNetworkBrowserItem *tempHost = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (tempHost->type() == Host && tempHost->hostItem()->workgroupName() == host->workgroupName()) {
                hostItem = tempHost;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
            if (a->data().toMap().value("text").toString() == b) {
                addAction(a);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : qAsConst(sortedBookmarks)) {
                for (QAction *a : qAsConst(actions)) {
                    if (a->text() == b) {
                        bookmarkCategoryMenu->addAction(a);
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            if (QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                                 Qt::CaseInsensitive) == 0)
            {
              options = o;
              break;
            }
            else if (!exactMatch && o->type() == Host && 
                     QString::compare(share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath),
                                      o->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath),
                                      Qt::CaseInsensitive) == 0)
            {
              options = o;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : qAsConst(m_hosts))
                {
                  if (QString::compare(h->hostName(), service->serviceName(), Qt::CaseInsensitive) == 0 &&
                      QString::compare(h->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0)
                  {
                    foundServer = true;
                    break;
                  }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.trimmed().startsWith(QLatin1String("Enumerating")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("Server name")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("-------------")))
      {
        continue;
      }
      else
      {
        // Omit host names that contain spaces since QUrl cannot handle them.
        // And, they are wrong, anyway.
        if (!line.section("   ", 0, 0).trimmed().contains(" "))
        {
          hostName = line.section("   ", 0, 0).trimmed();
          comment = line.section("   ", 1, -1).trimmed();
        }
        else
        {
          qDebug() << "This host name contains a space. I cannot handle this...";
          continue;
        }
      }
      
      if (!hostName.isEmpty())
      {
        HostPtr host = HostPtr(new Smb4KHost());
        host->setHostName(hostName);
        host->setWorkgroupName(m_workgroup->workgroupName());
        host->setComment(comment);
        
        if (host->hostName() == m_workgroup->masterBrowserName())
        {
          host->setLogin(m_master_browser->login());
          host->setPassword(m_master_browser->password());
          host->setIsMasterBrowser(true);
          
          if (m_workgroup->hasMasterBrowserIP())
          {
            host->setIP(m_workgroup->masterBrowserIP());
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
        
        m_hosts_list << host;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares)
  {
    //
    // Check that the URL is valid.
    //
    if (!share->url().isValid())
    {
      Smb4KNotification::invalidURLPassed();
      return;
    }
    else
    {
      // Do nothing
    }
    
    //
    // Check if the share has already been mounted. If it is already present,
    // do not process this share and move on to the next.
    //
    QString unc;
    
    if (share->isHomesShare())
    {
      if (!Smb4KHomesSharesHandler::self()->specifyUser(share, true, parent))
      {
        continue;
      }
      else
      {
        // Do nothing
      }

      unc = share->homeUNC();      
    }
    else
    {
      unc = share->unc();
    }
    
    QList<Smb4KShare *> mountedShares = findShareByUNC(unc);
    bool mounted = false;
    
    for (Smb4KShare *s : mountedShares)
    {
      if (!s->isForeign())
      {
        mounted = true;
      }
      else
      {
        // Do nothing
      }
    }
    
    if (mounted)
    {
      continue;
    }
    else
    {
      // Do nothing
    }
    
    //
    // Wake-On-LAN: Wake up the host before mounting 
    //
    if (Smb4KSettings::enableWakeOnLAN())
    {
      Smb4KCustomOptions *options = Smb4KCustomOptionsManager::self()->findOptions(KIO::upUrl(share->url()));

      if (options && options->wolSendBeforeMount())
      {
        emit aboutToStart(WakeUp);

        QUdpSocket *socket = new QUdpSocket(this);
        QHostAddress addr;

        // Use the host's IP address directly from the share object.
        if (!share->hostIP().isEmpty())
        {
          addr.setAddress(share->hostIP());
        }
        else
        {
          addr.setAddress("255.255.255.255");
        }

        // Construct magic sequence
        QByteArray sequence;

        // 6 times 0xFF
        for (int j = 0; j < 6; ++j)
        {
          sequence.append(QChar(0xFF).toLatin1());
        }

        // 16 times the MAC address
        QStringList parts = options->macAddress().split(':', QString::SkipEmptyParts);

        for (int j = 0; j < 16; ++j)
        {
          for (int k = 0; k < parts.size(); ++k)
          {
            sequence.append(QChar(QString("0x%1").arg(parts.at(k)).toInt(0, 16)).toLatin1());
          }
        }
            
        socket->writeDatagram(sequence, addr, 9);
        
        delete socket;
        
        // Wait the defined time
        int stop = 1000 * Smb4KSettings::wakeOnLANWaitingTime() / 250;
        int i = 0;
        
        while (i++ < stop)
        {
          QTest::qWait(250);
        }
        
        emit finished(WakeUp);
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
    
    // 
    // Create the mountpoint
    //
    QString mountpoint;
    mountpoint += Smb4KSettings::mountPrefix().path();
    mountpoint += QDir::separator();
    mountpoint += (Smb4KSettings::forceLowerCaseSubdirs() ? share->hostName().toLower() : share->hostName());
    mountpoint += QDir::separator();

    if (!share->isHomesShare())
    {
      mountpoint += (Smb4KSettings::forceLowerCaseSubdirs() ? share->shareName().toLower() : share->shareName());
    }
    else
    {
      mountpoint += (Smb4KSettings::forceLowerCaseSubdirs() ? share->login().toLower() : share->login());
    }
    
    // Get the permissions that should be used for creating the
    // mount prefix and all its subdirectories. 
    // Please note that the actual permissions of the mount points
    // are determined by the mount utility.
    QFile::Permissions permissions;
    QUrl parentDirectory;
      
    if (QFile::exists(Smb4KSettings::mountPrefix().path()))
    {
      parentDirectory = Smb4KSettings::mountPrefix();
    }
    else
    {
      QUrl u = Smb4KSettings::mountPrefix();
      parentDirectory = KIO::upUrl(u);
    }
      
    QFile f(parentDirectory.path());
    permissions = f.permissions();
      
    QDir dir(mountpoint);

    if (!dir.mkpath(dir.path()))
    {
      share->setPath("");
      Smb4KNotification::mkdirFailed(dir);
      return;
    }
    else
    {
      QUrl u = QUrl::fromLocalFile(dir.path());
      
      while (!parentDirectory.matches(u, QUrl::StripTrailingSlash))
      {
        QFile(u.path()).setPermissions(permissions);
        u = KIO::upUrl(u);
      }
    }
    
    share->setPath(QDir::cleanPath(mountpoint));
    
    // 
    // Get the authentication information
    //
    Smb4KWalletManager::self()->readAuthInfo(share);
 
    //
    // Mount arguments
    //
    QVariantMap args;
    
    if (!fillMountActionArgs(share, args))
    {
      continue;
    }
    else
    {
      // Do nothing
    }
    
    map.insert(QString("%1").arg(map.size()), args);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
                Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

                if (item && item->shareItem()->isForeign()) {
                    foreign++;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems)
    {
      Smb4KNetworkSearchItem *searchItem = static_cast<Smb4KNetworkSearchItem *>(item);
      
      if (searchItem && searchItem->shareItem()->isMounted() && !searchItem->shareItem()->isForeign())
      {
        //
        // Subtract shares mounted by the user
        // 
        unmountedShares--;
      }
      else if (searchItem && searchItem->shareItem()->isPrinter())
      {
        //
        // Subtract printer shares
        // 
        printerShares++;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *newEntry : newWalletEntries) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                        == 0 /* leave the user info here */
                    && QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0) {
                    enable = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : allBookmarks)
  {
    if (QString::compare(bookmark->profile(), from, Qt::CaseSensitive) == 0)
    {
      bookmark->setProfile(to);
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIP() && workgroup->hasMasterBrowserIP())
          {
            host->setIP(workgroup->masterBrowserIP());
          }
          else
          {
            // Do nothing
          }          
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : mountedSharesList())
    {
      check(share);
      emit updated(share);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          sortedBookmarks << bookmark->label();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), m_bookmarks);
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          sortedBookmarks << bookmark->displayString();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks) {
        QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
        bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
        bookmarkItem->setIcon(0, bookmark->icon());
        bookmarkItem->setText(0, bookmark->displayString());
        bookmarkItem->setText((treeWidget->columnCount() - 1), QString("01_%1").arg(bookmark->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort)));
        bookmarkItem->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsDragEnabled);

        if (!bookmark->categoryName().isEmpty()) {
            QList<QTreeWidgetItem *> items = treeWidget->findItems(bookmark->categoryName(), Qt::MatchFixedString | Qt::MatchCaseSensitive, 0);

            if (!items.isEmpty()) {
                items.first()->addChild(bookmarkItem);
                items.first()->setExpanded(true);
            }
        } else {
            treeWidget->addTopLevelItem(bookmarkItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList())
        {
          if (host->url() == object->url())
          {
            Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(host);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
  {
    if (s->isInaccessible())
    {
      inaccessibleShares += s;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups)
  {
    if (!group.isEmpty())
    {
      // Group menu entry
      KActionMenu *bookmarkGroupMenu = new KActionMenu(group, menu());
      bookmarkGroupMenu->setIcon(KDE::icon("folder-favorites"));
      QMap<QString,QVariant> menuInfo;
      menuInfo["type"] = "group_menu";
      menuInfo["group"] = group;
      bookmarkGroupMenu->setData(menuInfo);
      addAction(bookmarkGroupMenu);
      
      // Mount action for the group
      QAction *bookmarkGroupMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkGroupMenu->menu());
      QMap<QString,QVariant> groupMountInfo;
      groupMountInfo["type"] = "group_mount";
      groupMountInfo["group"] = group;
      bookmarkGroupMount->setData(groupMountInfo);
      bookmarkGroupMenu->addAction(bookmarkGroupMount);
      m_actions->addAction(bookmarkGroupMount);
      
      // Get the list of bookmarks belonging to this group.
      // Use it to decide whether the group mount action should be enabled 
      // (only if not all bookmarks belonging to this group are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(group);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->unc());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->unc());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["unc"] = bookmark->unc();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
      
      bookmarkGroupMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkGroupMenu->addSeparator();
      
      // Insert the sorted bookmarks into the group menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
  {
    HostPtr host = findHost(bookmark->hostName(), bookmark->workgroupName());
    
    if (host)
    {
      if (host->hasIpAddress() && bookmark->hostIpAddress() != host->ipAddress())
      {
        bookmark->setHostIpAddress(host->ipAddress());
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(m_bookmarks)) {
        QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
        bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
        bookmarkItem->setIcon(0, bookmark->icon());
        bookmarkItem->setText(0, bookmark->displayString());
        bookmarkItem->setText((treeWidget->columnCount() - 1), QString("01_%1").arg(bookmark->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort)));
        bookmarkItem->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsDragEnabled);

        if (!bookmark->categoryName().isEmpty()) {
            QList<QTreeWidgetItem *> items = treeWidget->findItems(bookmark->categoryName(), Qt::MatchFixedString | Qt::MatchCaseSensitive, 0);

            if (!items.isEmpty()) {
                items.first()->addChild(bookmarkItem);
                items.first()->setExpanded(true);
            }
        } else {
            treeWidget->addTopLevelItem(bookmarkItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : dockActionCollection->actions()) {
            if (action->objectName() == "bookmark_action") {
                if (bookmarkMenu) {
                    bookmarkMenu->setBookmarkActionEnabled(action->isEnabled());
                    connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
                    continue;
                }
            } else if (QString::compare(action->objectName(), "filemanager_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "konsole_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "icon_view_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "list_view_action") == 0) {
                continue;
            }

            dynamicList << action;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.startsWith(QLatin1String("Looking up status of")))
      {
        // Get the IP address of the master browser.
        workgroup->setMasterBrowserIP(line.section("of", 1, 1).trimmed());
        continue;
      }
      else if (line.contains("MAC Address", Qt::CaseSensitive))
      {
        // Add workgroup to the list. Ignore misconfigured master browsers,
        // that do not belong to a workgroup/domain, i.e. where the workgroup
        // name is empty.
        if (!workgroup->workgroupName().isEmpty() && !workgroup->masterBrowserName().isEmpty())
        {
          m_workgroups_list << new Smb4KWorkgroup(*workgroup);
        }
        else
        {
          // Do nothing
        }

        delete workgroup;
        workgroup = new Smb4KWorkgroup();
        continue;
      }
      else if (line.contains(" <00> ", Qt::CaseSensitive))
      {
        // Set the name of the workgroup/host.
        if (line.contains(" <GROUP> ", Qt::CaseSensitive))
        {
          // Avoid setting the workgroup name twice.
          if (workgroup->workgroupName().isEmpty())
          {
            workgroup->setWorkgroupName(line.section("<00>", 0, 0).trimmed());
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Avoid setting the name of the master browser twice.
          if (workgroup->masterBrowserName().isEmpty())
          {
            workgroup->setMasterBrowserName(line.section("<00>", 0, 0).trimmed());
          }
          else
          {
            // Do nothing
          }
        }

        continue;
      }
      else if (line.contains(" <1d> ", Qt::CaseSensitive))
      {
        // Get the workgroup name.
        if (workgroup->workgroupName().isEmpty())
        {
          workgroup->setWorkgroupName(line.section("<1d>", 0, 0).trimmed());
        }
        else
        {
          // Do nothing
        }

        continue;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

    if (item && !item->shareItem()->isInaccessible() && !Smb4KSynchronizer::self()->isRunning(item->shareItem()))
    {
      Smb4KSynchronizer::self()->synchronize(item->shareItem());
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.trimmed().startsWith(QLatin1String("Enumerating")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("Share name")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("----------")))
      {
        continue;
      }
      else if (line.contains(" Disk     ", Qt::CaseSensitive) /* line has comment */ ||
               (!line.contains(" Disk     ", Qt::CaseSensitive) &&
                line.trimmed().endsWith(QLatin1String(" Disk"), Qt::CaseSensitive) /* line has no comment */))
      {
        if (!line.trimmed().endsWith(QLatin1String(" Disk"), Qt::CaseSensitive))
        {
          shareName = line.section(" Disk     ", 0, 0).trimmed();
          comment = line.section(" Disk     ", 1, 1).trimmed();
        }
        else
        {
          shareName = line.section(" Disk", 0, 0).trimmed();
          comment = "";
        }
        
        typeString = "Disk";
      }
      else if (line.contains(" IPC      ", Qt::CaseSensitive) /* line has comment */ ||
               (!line.contains(" IPC      ", Qt::CaseSensitive) &&
                line.trimmed().endsWith(QLatin1String(" IPC"), Qt::CaseSensitive) /* line has no comment */))
      {
        if (!line.trimmed().endsWith(QLatin1String(" IPC"), Qt::CaseSensitive))
        {
          shareName = line.section(" IPC      ", 0, 0).trimmed();
          comment = line.section(" IPC      ", 1, 1).trimmed();
        }
        else
        {
          shareName = line.section(" IPC", 0, 0).trimmed();
          comment = "";
        }
        
        typeString = "IPC";
      }
      else if (line.contains(" Print    ", Qt::CaseSensitive) /* line has comment */ ||
               (!line.contains(" Print    ", Qt::CaseSensitive) &&
                line.trimmed().endsWith(QLatin1String(" Print"), Qt::CaseSensitive) /* line has no comment */))
      {
        if (!line.trimmed().endsWith(QLatin1String(" Print"), Qt::CaseSensitive))
        {
          shareName = line.section(" Print    ", 0, 0).trimmed();
          comment = line.section(" Print    ", 1, 1).trimmed();
        }
        else
        {
          shareName = line.section(" Print", 0, 0).trimmed();
          comment = "";
        }
        
        typeString = "Printer";
      }
      else
      {
        continue;
      }
      
      if (!shareName.isEmpty())
      {
        SharePtr share = SharePtr(new Smb4KShare());
        share->setShareName(shareName);
        share->setHostName(m_host->hostName());
        share->setWorkgroupName(m_host->workgroupName());
        share->setComment(comment);
        share->setTypeString(typeString);
        share->setLogin(m_host->login());
        share->setPassword(m_host->password());
        
        if (m_host->hasIP())
        {
          share->setHostIP(m_host->ip());
        }
        else
        {
          // Do nothing
        }
        
        m_shares_list << share;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares)) {
            if (!share->isForeign()) {
                bookmarkAction->setEnabled(false);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares) {
                if (!share->isForeign()) {
                    qDebug() << "Disabling bookmark" << share->url().toDisplayString();
                    bookmarkAction->setEnabled(false);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharePtr searchResult : searchResults())
      {
        if (QString::compare(searchResult->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                             share->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                             Qt::CaseInsensitive) == 0)
        {
          searchResult->resetMountData();
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
                if (networkItem->type() == Host) {
                    if (QString::compare(entry, networkItem->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), Qt::CaseInsensitive) == 0
                        || QString::compare(entry,
                                            networkItem->url().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort),
                                            Qt::CaseInsensitive)
                            == 0) {
                        d->wallet->readMap(entry, authInfoMap);
                        break;
                    }
                } else if (networkItem->type() == Share) {
                    //
                    // Cast the network item. We need some share specific info
                    //
                    SharePtr share = networkItem.staticCast<Smb4KShare>();

                    if (share) {
                        //
                        // Process normal and 'homes' shares differently
                        //
                        if (!share->isHomesShare()) {
                            //
                            // Prefer the credentials for the share. Use the ones for the
                            // host as fallback.
                            //
                            if (QString::compare(entry, share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), Qt::CaseInsensitive) == 0
                                || QString::compare(entry,
                                                    share->url().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort),
                                                    Qt::CaseInsensitive)
                                    == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                                break;
                            } else if (QString::compare(entry,
                                                        share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                                        Qt::CaseInsensitive)
                                           == 0
                                       || QString::compare(
                                              entry,
                                              share->url().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                              Qt::CaseInsensitive)
                                           == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                            }
                        } else {
                            //
                            // Prefer the credentials for the share. Use the ones for the
                            // host as fallback.
                            //
                            if (QString::compare(entry, share->homeUrl().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), Qt::CaseInsensitive) == 0
                                || QString::compare(entry,
                                                    share->homeUrl().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort),
                                                    Qt::CaseInsensitive)
                                    == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                                break;
                            } else if (QString::compare(entry,
                                                        share->homeUrl().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                                        Qt::CaseInsensitive)
                                           == 0
                                       || QString::compare(
                                              entry,
                                              share->homeUrl().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                              Qt::CaseInsensitive)
                                           == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                            }
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : entries) {
            QMap<QString, QString> authInfoMap;

            if (authInfo->type() == UnknownNetworkItem) {
                //
                // Default login
                //
                authInfoMap.insert("Login", authInfo->userName());
                authInfoMap.insert("Password", authInfo->password());

                //
                // Write the default authentication information to the wallet
                //
                d->wallet->writeMap("DEFAULT_LOGIN", authInfoMap);
            } else {
                //
                // Authentication information for a specific URL
                //
                authInfoMap.insert("IP Address", authInfo->ipAddress());
                authInfoMap.insert("Workgroup", authInfo->workgroupName());
                authInfoMap.insert("Login", authInfo->userName());
                authInfoMap.insert("Password", authInfo->password());

                //
                // Write the authentication information to the wallet
                //
                d->wallet->writeMap(authInfo->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), authInfoMap);
            }

            //
            // Sync the entries to disk
            //
            d->wallet->sync();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
            QUrl bookmarkUrl = a->data().toMap().value("url").toUrl();

            if (share->url().matches(bookmarkUrl, QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                a->setEnabled(!share->isMounted());
                bookmarkCategory = a->data().toMap().value("category").toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &newWorkgroup : qAsConst(discoveredWorkgroups)) {
        bool foundWorkgroup = false;

        for (const WorkgroupPtr &workgroup : qAsConst(d->tempWorkgroupList)) {
            if (workgroup->workgroupName() == newWorkgroup->workgroupName()) {
                foundWorkgroup = true;
                break;
            }
        }

        if (!foundWorkgroup) {
            d->tempWorkgroupList << newWorkgroup;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList)
    {
      d->wallet->removeEntry(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : workgroups)
    {
      Smb4KNetworkBrowserItem *tempWorkgroup = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (tempWorkgroup->type() == Workgroup && tempWorkgroup->workgroupItem()->workgroupName() == workgroup->workgroupName())
      {
        workgroupItem = tempWorkgroup;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *category : qAsConst(allCategoryActions)) {
            if (category->text() == bookmark->categoryName()) {
                bookmarkMenu = static_cast<KActionMenu *>(category);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : qAsConst(addresses)) {
                // We only use global addresses.
                if (addr.isGlobal()) {
                    if (addr.protocol() == QAbstractSocket::IPv4Protocol) {
                        ipAddress = addr;
                        break;
                    } else if (addr.protocol() == QAbstractSocket::IPv6Protocol) {
                        // FIXME: Use the right address here.
                        ipAddress = addr;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
  {
    if (!options->macAddress().isEmpty() && (options->wolSendBeforeNetworkScan() || options->wolSendBeforeMount()))
    {
      optionsList << options;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
            Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

            if (item) {
                // Is the share synchronized at the moment?
                if (Smb4KSynchronizer::self()->isRunning(item->shareItem())) {
                    syncsRunning += 1;
                }

                // Is the share inaccessible at the moment?
                if (item->shareItem()->isInaccessible()) {
                    inaccessible += 1;
                }

                // Was the share being mounted by another user?
                if (item->shareItem()->isForeign()) {
                    foreign += 1;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList)
    {
      if (Smb4KSettings::useProfiles())
      {
        options->setProfile(Smb4KProfileManager::self()->activeProfile());
      }
      else
      {
        // Do nothing
      }
      
      if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
      {
        d->options << options;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entriesList)
    {
      if (walletEntriesWidget->currentItem()->text() == authInfo->displayString() ||
          (walletEntriesWidget->currentItem()->text() == i18n("Default Login") && authInfo->type() == UnknownNetworkItem))
      {
        loadDetails(authInfo);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options) {
        if (options->type() == Share) {
            if (options->remount() == Smb4KCustomOptions::RemountOnce) {
                options->setRemount(Smb4KCustomOptions::UndefinedRemount);
            } else if (options->remount() == Smb4KCustomOptions::RemountAlways && force) {
                options->setRemount(Smb4KCustomOptions::UndefinedRemount);
            }
        }

        if (!options->hasOptions()) {
            removeCustomOptions(options, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList)
    {
      if (Smb4KSettings::useProfiles())
      {
        options->setProfile(Smb4KProfileManager::self()->activeProfile());
      }
      
      if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
      {
        d->options << options;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : qAsConst(d->options)) {
        if (options->profile() == from) {
            options->setProfile(to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList) {
        if ((workgroup.isEmpty() || QString::compare(h->workgroupName(), workgroup, Qt::CaseInsensitive) == 0)
            && QString::compare(h->hostName(), name, Qt::CaseInsensitive) == 0) {
            host = h;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &no : new_list)
      {
        for (const OptionsPtr &oo : old_list)
        {
          if (!no->equals(oo.data()))
          {
            enable = true;
            break;
          }
          else
          {
            // Do nothing
          }
        }
        
        if (enable)
        {
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
          if (!isRunning())
          {
            if (d->firstImportDone && d->importedShares.isEmpty() && d->newlyMounted > 1)
            {
              Smb4KNotification::sharesMounted(d->newlyMounted);
            }
              
            d->newlyMounted = 0;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : qAsConst(d->tempWorkgroupList)) {
            if (workgroup->workgroupName() == newWorkgroup->workgroupName()) {
                foundWorkgroup = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (share->unc() == a->data().toMap().value("unc").toString())
      {
        a->setEnabled(!share->isMounted());
        bookmarkGroup = a->data().toMap().value("group").toString();
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
  {
    //
    // Check if the bookmark label is already in use
    // 
    if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
    {
      Smb4KNotification::bookmarkLabelInUse(bookmark.data());
      bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
    }
    else
    {
      // Do nothing
    }
      
    //
    // Check if we have to add the bookmark
    // 
    BookmarkPtr existingBookmark = findBookmarkByUrl(bookmark->url());
      
    if (!existingBookmark)
    {
      d->bookmarks << bookmark;
    }
    else
    {
      // We do not need to update the bookmark, because we are
      // operating on a shared pointer.
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : oldWalletEntries)
    {
      for (Smb4KAuthInfo *newEntry : newWalletEntries)
      {
        if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive) == 0 /* leave the user info here */ &&
            QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0)
        {
          enable = true;
          break;
        }
      }
      
      if (enable)
      {
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : maximalClientProtocolVersionChoices)
  {
    maximalClientProtocolVersion->addItem(c.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      slotShareMounted(share);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : qAsConst(selectedItems)) {
            Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (browserItem && browserItem->shareItem()->isMounted()) {
                mounted << browserItem->shareItem();
            } else if (browserItem && !browserItem->shareItem()->isMounted()) {
                unmounted << browserItem->shareItem();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &importedShare : qAsConst(d->importedShares)) {
                // Check the mountpoint, since that one is unique. We will only use
                // Smb4KShare::path(), so that we do not run into trouble if a share
                // is inaccessible.
                if (QString::compare(mountedShare->path(), importedShare->path()) == 0) {
                    found = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
      {
        if (networkItem->shareItem() == share)
        {
          //
          // Select the search result
          // 
          networkItem->setSelected(true);
          
          //
          // Expand the branch of the network tree where a search result
          // was retrieved
          // 
          if (!networkItem->parent()->isExpanded())
          {
            m_networkBrowser->expandItem(networkItem->parent());
          }
          
          if (!networkItem->parent()->parent()->isExpanded())
          {
            m_networkBrowser->expandItem(networkItem->parent()->parent());
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : qAsConst(minimalClientProtocolVersionChoices)) {
        minimalClientProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
      {
        o->setIpAddress(m_currentOptions->ipAddress());
        o->setUseUser(m_currentOptions->useUser());
        o->setUser(m_currentOptions->user());
        o->setUseGroup(m_currentOptions->useGroup());
        o->setGroup(m_currentOptions->group());
        o->setUseFileMode(m_currentOptions->useFileMode());
        o->setFileMode(m_currentOptions->fileMode());
        o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
        o->setDirectoryMode(m_currentOptions->directoryMode());
#if defined(Q_OS_LINUX)
        o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
        o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
        o->setFileSystemPort(m_currentOptions->fileSystemPort());
        o->setUseMountProtocolVersion(m_currentOptions->useMountProtocolVersion());
        o->setMountProtocolVersion(m_currentOptions->mountProtocolVersion());
        o->setUseSecurityMode(m_currentOptions->useSecurityMode());
        o->setSecurityMode(m_currentOptions->securityMode());
        o->setUseWriteAccess(m_currentOptions->useWriteAccess());
        o->setWriteAccess(m_currentOptions->writeAccess());
#endif
        o->setUseClientProtocolVersions(m_currentOptions->useClientProtocolVersions());
        o->setMinimalClientProtocolVersion(m_currentOptions->minimalClientProtocolVersion());
        o->setMaximalClientProtocolVersion(m_currentOptions->maximalClientProtocolVersion());
        o->setUseSmbPort(m_currentOptions->useSmbPort());
        o->setSmbPort(m_currentOptions->smbPort());
        o->setUseKerberos(m_currentOptions->useKerberos());
        o->setMACAddress(m_currentOptions->macAddress());
        o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
        o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          remountShare = false;
          break;
        }          
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), m_bookmarks);
          QMap<QString,QVariant> info;
          info["group"] = group;
          info["unc"] = bookmark->unc();
          bookmarkAction->setData(info);
          sortedBookmarks << bookmark->label();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->unc(), m_bookmarks);
          QMap<QString,QVariant> info;
          info["group"] = group;
          info["unc"] = bookmark->unc();
          bookmarkAction->setData(info);
          sortedBookmarks << bookmark->unc();
          m_action_collection->addAction(bookmark->unc(), bookmarkAction);
        }
        
        QList<SharePtr> mountedShares = findShareByUNC(bookmark->unc());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarksList())
  {
    if (categoryName == bookmark->categoryName())
    {
      bookmarks << bookmark;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *b : bookmarks)
  {
    Smb4KBookmark *bookmark = new Smb4KBookmark(*b);
    QListWidgetItem *item = new QListWidgetItem(bookmark->icon(), bookmark->unc(), m_widget);
    item->setData(Qt::UserRole, static_cast<QUrl>(bookmark->url()));
    
    m_bookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : children)
        {
          if (object == obj)
          {
            m_focusWidget = sharesViewDock;
            setupDynamicActionList(sharesViewDock);
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares) {
                    bool foundShare = false;

                    for (int i = 0; i < hostItem->childCount(); ++i) {
                        Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));

                        if (shareItem->shareItem()->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort)
                            == share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort)) {
                            foundShare = true;
                            break;
                        }
                    }

                    if (!foundShare) {
                        (void)new Smb4KNetworkBrowserItem(hostItem, share);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
        if (mountPoint->mountType() == "cifs" || mountPoint->mountType() == "smb3" || mountPoint->mountType() == "smbfs") {
            // Create a new share and set the mountpoint and filesystem
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(mountPoint->mountedFrom());
            share->setPath(mountPoint->mountPoint());
            share->setMounted(true);

            // Get all mount options
            QStringList mountOptions = mountPoint->mountOptions();
            
            for (const QString &option : qAsConst(mountOptions)) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setLogin(option.section('=', 1, 1).trimmed());
                }
            }

            // Work around empty usernames
            if (share->login().isEmpty()) {
                share->setLogin("guest");
            }

            d->importedShares << share;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mounted)
      {
        if (!share->isForeign())
        {
          bookmark->setEnabled(false);
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mp : qAsConst(mountpoints)) {
        dir.cd(mp);
        dir.rmdir(dir.canonicalPath());

        if (dir.cdUp()) {
            dir.rmdir(dir.canonicalPath());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : mountedSharesList())
  {
    if (!share->isForeign())
    {
      Smb4KCustomOptionsManager::self()->addRemount(share, false);
    }
    else
    {
      Smb4KCustomOptionsManager::self()->removeRemount(share, false);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.trimmed().startsWith(QLatin1String("Enumerating")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("Share name")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("----------")))
      {
        continue;
      }
      else if (line.contains(" Disk     ", Qt::CaseSensitive) /* line has comment */ ||
               (!line.contains(" Disk     ", Qt::CaseSensitive) &&
                line.trimmed().endsWith(QLatin1String(" Disk"), Qt::CaseSensitive) /* line has no comment */))
      {
        Smb4KShare *share = new Smb4KShare();
        
        if (!line.trimmed().endsWith(QLatin1String(" Disk"), Qt::CaseSensitive))
        {
          share->setShareName(line.section(" Disk     ", 0, 0).trimmed());
          share->setComment(line.section(" Disk     ", 1, 1).trimmed());
        }
        else
        {
          share->setShareName(line.section(" Disk", 0, 0).trimmed());
          share->setComment("");
        }
            
        share->setHostName(m_host->hostName());
        share->setWorkgroupName(m_host->workgroupName());
        share->setTypeString("Disk");
        share->setLogin(m_host->login());
        share->setPassword(m_host->password());

        if (m_host->hasIP())
        {
          share->setHostIP(m_host->ip());
        }
        else
        {
          // Do nothing
        }

        m_shares_list << share;
      }
      else if (line.contains(" IPC      ", Qt::CaseSensitive) /* line has comment */ ||
               (!line.contains(" IPC      ", Qt::CaseSensitive) &&
                line.trimmed().endsWith(QLatin1String(" IPC"), Qt::CaseSensitive) /* line has no comment */))
      {
        Smb4KShare *share = new Smb4KShare();
        
        if (!line.trimmed().endsWith(QLatin1String(" IPC"), Qt::CaseSensitive))
        {
          share->setShareName(line.section(" IPC      ", 0, 0).trimmed());
          share->setComment(line.section(" IPC      ", 1, 1).trimmed());
        }
        else
        {
          share->setShareName(line.section(" IPC", 0, 0).trimmed());
          share->setComment("");
        }
            
        share->setHostName(m_host->hostName());
        share->setWorkgroupName(m_host->workgroupName());
        share->setTypeString("IPC");
        share->setLogin(m_host->login());
        share->setPassword(m_host->password());

        if (m_host->hasIP())
        {
          share->setHostIP(m_host->ip());
        }
        else
        {
          // Do nothing
        }

        m_shares_list << share;
      }      
      else if (line.contains(" Print    ", Qt::CaseSensitive) /* line has comment */ ||
               (!line.contains(" Print    ", Qt::CaseSensitive) &&
                line.trimmed().endsWith(QLatin1String(" Print"), Qt::CaseSensitive) /* line has no comment */))
      {
        Smb4KShare *share = new Smb4KShare();
        
        if (!line.trimmed().endsWith(QLatin1String(" Print"), Qt::CaseSensitive))
        {
          share->setShareName(line.section(" Print    ", 0, 0).trimmed());
          share->setComment(line.section(" Print    ", 1, 1).trimmed());
        }
        else
        {
          share->setShareName(line.section(" Print", 0, 0).trimmed());
          share->setComment("");
        }
            
        share->setHostName(m_host->hostName());
        share->setWorkgroupName(m_host->workgroupName());
        share->setTypeString("Printer");
        share->setLogin(m_host->login());
        share->setPassword(m_host->password());

        if (m_host->hasIP())
        {
          share->setHostIP(m_host->ip());
        }
        else
        {
          // Do nothing
        }

        m_shares_list << share;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    if (!share->isForeign())
    {
      Smb4KCustomOptionsManager::self()->addRemount(share, false);
    }
    else
    {
      Smb4KCustomOptionsManager::self()->removeRemount(share, false);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : mountedShares)
    {
      if (!s->isForeign())
      {
        isMounted = true;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : p->mountedSharesList)
    {
      if (!s->isForeign())
      {
        p->onlyForeignShares = false;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KProfileObject *profile : qAsConst(d->profileObjects)) {
        if (profile->isActiveProfile()) {
            activeProfile = profile->profileName();
            break;
        } else {
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (QString::compare(s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                         url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort), Qt::CaseInsensitive) == 0 &&
        (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0))
    {
      share = s;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::sharesList())
    {
      if (share->url() == object->url())
      {
        shares << share;
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : job->hosts())
  {
    if (host->hostName() == workgroup->masterBrowserName())
    {
      host->setIsMasterBrowser(true);
    }
    else
    {
      host->setIsMasterBrowser(false);
    }
      
    if (!findHost(host->hostName(), host->workgroupName()))
    {
      addHost(host);
    }
    else
    {
      updateHost(host);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : qAsConst(encryptionLevelChoices)) {
        encryptionLevel->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
      {
        if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
        {
          xmlWriter.writeStartElement("options");
          xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
          xmlWriter.writeAttribute("profile", options->profile());

          xmlWriter.writeTextElement("workgroup", options->workgroupName());
          xmlWriter.writeTextElement("url", options->url().toDisplayString());
          xmlWriter.writeTextElement("ip", options->ip());
          
          xmlWriter.writeStartElement("custom");

          QMap<QString,QString> map = options->customOptions();
          QMapIterator<QString,QString> it(map);

          while (it.hasNext())
          {
            it.next();

            if (!it.value().isEmpty())
            {
              xmlWriter.writeTextElement(it.key(), it.value());
            }
            else
            {
              // Do nothing
            }
          }

          xmlWriter.writeEndElement();
          xmlWriter.writeEndElement();
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
      
      if (!mountedShares.isEmpty())
      {
        for (const SharePtr &share : mountedShares)
        {
          if (!share->isForeign())
          {
            mountedBookmarks++;
            break;
          }
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
  {
    if (Smb4KSettings::useProfiles() && o->profile() != Smb4KProfileManager::self()->activeProfile())
    {
      continue;
    }
    else
    {
      // Do nothing
    }

    if (o->hasOptions() || (!optionsOnly && o->remount() == Smb4KCustomOptions::RemountOnce))
    {
      options << o;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPrintDialog *p : qAsConst(d->printDialogs)) {
        if (share == p->share()) {
            dlg = p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    if (!m_groups.contains(bookmark->groupName()))
    {
      m_groups << bookmark->groupName();
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list) {
        //
        // Check if the bookmark label is already in use
        //
        if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label())) {
            Smb4KNotification::bookmarkLabelInUse(bookmark.data());
            bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
        }

        //
        // Check if we have to add the bookmark
        //
        BookmarkPtr existingBookmark = findBookmarkByUrl(bookmark->url());

        if (!existingBookmark) {
            d->bookmarks << bookmark;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : list)
  {
    OptionsPtr options = findOptions(o->url().toDisplayString());
    
    if (!options)
    {
      m_optionsList << o;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : optionsListWidget->actions())
    {
      if (a->objectName() == "edit_action")
      {
        a->setEnabled(item != 0);
      }
      else if (a->objectName() == "remove_action")
      {
        a->setEnabled(item != 0);
      }
      else if (a->objectName() == "clear_action")
      {
        a->setEnabled(optionsListWidget->count() != 0);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOut)
  {
    if (!line.contains("added interface", Qt::CaseInsensitive) &&
        !line.contains("tdb(", Qt::CaseInsensitive) &&
        !line.contains("Got a positive", Qt::CaseInsensitive) &&
        !line.contains("error connecting", Qt::CaseInsensitive) &&
        !line.isEmpty())
    {
      if (!line.trimmed().startsWith("\\") && !line.trimmed().isEmpty())
      {
        workgroupName = line.trimmed();
      }
      else if (line.count("\\") == 3)
      {
        QString unc = line.trimmed().section('\t', 0, 0).trimmed().replace("\\", "/");
        QString comment = line.trimmed().section('\t', 1, -1).trimmed();

        if (unc.contains(m_string, Qt::CaseInsensitive))
        {
          SharePtr share = SharePtr(new Smb4KShare(unc));
          share->setComment(comment);
          share->setWorkgroupName(workgroupName);
          emit result(share);
        }
        else
        {
          // Do nothing
        }
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : m_actionCollection->actions()) {
        m_contextMenu->addAction(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::mountedSharesList()) {
            if (share->url() == object->url()) {
                Smb4KSynchronizer::self()->synchronize(share);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (a->data().toMap().value("category").toString() == bookmarkCategory && a->isEnabled())
      {
        allMounted = false;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &interface : qAsConst(interfaces)) {
        if (interface.isValid() && interface.type() != QNetworkInterface::Loopback && interface.flags() & QNetworkInterface::IsRunning) {
            online = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPreviewDialog *p : d->previewDialogs) {
        if (share == p->share()) {
            dlg = p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : shares_list)
      {
        if (s->workgroupName() == share->workgroupName() && s->unc() == share->unc())
        {
          found = true;
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : unmountedShares)
      {
        // Copy the share
        SharePtr unmountedShare = share;
        
        // Remove the share from the global list and notify the program
        removeMountedShare(share);
        emit unmounted(unmountedShare);
        unmountedShare.clear();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &importedShare : qAsConst(d->importedShares))
      {
        // Check the mountpoint, since that one is unique. We will only use
        // Smb4KShare::path(), so that we do not run into trouble if a share 
        // is inaccessible.
        if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
        {
          found = true;
          break;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(m_bookmarks)) {
        if (!m_categories.contains(bookmark->categoryName())) {
            m_categories << bookmark->categoryName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KCustomOptions *opt : list)
        {
          QList<SharePtr> mountedShares = findShareByUNC(opt->unc());
          
          if (!mountedShares.isEmpty())
          {
            bool mount = true;
            
            for (const SharePtr &s : mountedShares)
            {
              if (!s->isForeign())
              {
                mount = false;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (mount)
            {
              SharePtr share = SharePtr(new Smb4KShare());
              share->setURL(opt->url());
              share->setWorkgroupName(opt->workgroupName());
              share->setHostIP(opt->ip());
              
              if (share->url().isValid() && !share->url().isEmpty())
              {
                d->remounts << share;
              }
              else
              {
                // Do nothing
              }
            }
            else
            {
              // Do nothing
            }
          }
          else
          {
            SharePtr share = SharePtr(new Smb4KShare());
            share->setURL(opt->url());
            share->setWorkgroupName(opt->workgroupName());
            share->setHostIP(opt->ip());
              
            if (share->url().isValid() && !share->url().isEmpty())
            {
              d->remounts << share;
            }
            else
            {
              // Do nothing
            }
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options) {
        if (!options->macAddress().isEmpty() && (options->wolSendBeforeNetworkScan() || options->wolSendBeforeMount())) {
            optionsList << options;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
  {
    //
    // Check if the bookmark label is already in use
    // 
    if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
    {
      Smb4KNotification::bookmarkLabelInUse(bookmark.data());
      bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
    }
      
    //
    // Check if we have to add the bookmark
    // 
    BookmarkPtr existingBookmark = findBookmarkByUrl(bookmark->url());
      
    if (!existingBookmark)
    {
      d->bookmarks << bookmark;
    }
    else
    {
      // We do not need to update the bookmark, because we are
      // operating on a shared pointer.
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
          {
            bool foundShare = false;
            
            for (int i = 0; i < hostItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));
              
              if (shareItem->shareItem()->url().matches(share->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
              {
                foundShare = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundShare)
            {
              (void) new Smb4KNetworkBrowserItem(hostItem, share);
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : qAsConst(d->hostObjects)) {
                if (url == obj->url()) {
                    object = obj;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : mountPoint->mountOptions()) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setLogin(option.section('=', 1, 1).trimmed());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : list)
        {
          QList<SharePtr> mountedShares = findShareByUNC(opt->unc());
          
          if (!mountedShares.isEmpty())
          {
            bool mount = true;
            
            for (const SharePtr &s : mountedShares)
            {
              if (!s->isForeign())
              {
                mount = false;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (mount)
            {
              SharePtr share = SharePtr(new Smb4KShare());
              share->setURL(opt->url());
              share->setWorkgroupName(opt->workgroupName());
              share->setHostIP(opt->ip());
              
              if (share->url().isValid() && !share->url().isEmpty())
              {
                d->remounts << share;
              }
              else
              {
                // Do nothing
              }
            }
            else
            {
              // Do nothing
            }
          }
          else
          {
            SharePtr share = SharePtr(new Smb4KShare());
            share->setURL(opt->url());
            share->setWorkgroupName(opt->workgroupName());
            share->setHostIP(opt->ip());
              
            if (share->url().isValid() && !share->url().isEmpty())
            {
              d->remounts << share;
            }
            else
            {
              // Do nothing
            }
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : qAsConst(m_optionsList)) {
        if (url == o->url().toString()) {
            m_currentOptions = o;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(unmountedShares)) {
            //
            // Remove the mountpoint if the share is not a foreign one
            //
            if (!share->isForeign()) {
                QDir dir;
                dir.cd(share->canonicalPath());
                dir.rmdir(dir.canonicalPath());

                if (dir.cdUp()) {
                    dir.rmdir(dir.canonicalPath());
                }
            }

            //
            // Mark it as unmounted
            //
            share->setMounted(false);

            //
            // Copy the share
            //
            SharePtr unmountedShare = share;

            //
            // Remove the share from the global list and notify the program
            //
            removeMountedShare(share);
            emit unmounted(unmountedShare);

            //
            // Report the unmounted share to the user if it is a single one
            //
            if (!isRunning() && d->newlyUnmounted == 1) {
                Smb4KNotification::shareUnmounted(unmountedShare);
            }

            unmountedShare.clear();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->mountedSharesList)) {
            if (!s->isForeign()) {
                p->onlyForeignShares = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *b : buttonBox->buttons())
    {
      if (buttonBox->buttonRole(b) == QDialogButtonBox::ResetRole)
      {
        b->setEnabled(!checkDefaultValues());
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : mountedShares)
    {
      if (!s->isForeign())
      {
        mounted = true;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *h : hosts_list)
      {
        if (h->workgroupName() == host->workgroupName() && h->hostName() == host->hostName())
        {
          found = true;
          break;
        }
        else
        {
          continue;
        }        
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
  {
    if (hasCustomOptions(o) || (!optionsOnly && o->remount() == Smb4KCustomOptions::RemountOnce))
    {
      if (Smb4KSettings::useProfiles() && o->profile() != Smb4KProfileManager::self()->activeProfile())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      options << o;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : qAsConst(items)) {
            Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (browserItem && browserItem->shareItem()->isMounted() && !browserItem->shareItem()->isForeign()) {
                //
                // Subtract shares mounted by the user
                //
                unmountedShares--;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : qAsConst(workgroups)) {
            Smb4KNetworkBrowserItem *tempWorkgroup = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (tempWorkgroup->type() == Workgroup && tempWorkgroup->workgroupItem()->workgroupName() == workgroup->workgroupName()) {
                workgroupItem = tempWorkgroup;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : list)
  {
    m_optionsList << o;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints))
  {
    if (QString::compare(mountPoint->mountType(), "cifs") == 0 || QString::compare(mountPoint->mountType(), "smbfs") == 0)
    {
      // Create a new share and set the mountpoint and filesystem
      SharePtr share = SharePtr(new Smb4KShare());
      share->setUrl(mountPoint->mountedFrom());
      share->setPath(mountPoint->mountPoint());
      share->setMounted(true);
      
      // Get all mount options
      for (const QString &option : mountPoint->mountOptions())
      {
        if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup=")))
        {
          share->setWorkgroupName(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("addr=")))
        {
          share->setHostIpAddress(option.section('=', 1, 1).trimmed());
        }
        else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user=")))
        {
          share->setLogin(option.section('=', 1, 1).trimmed());
        }
        else
        {
          qDebug() << "Not implemented mount option:" << option;
        }
      }
      
      // Work around empty usernames
      if (share->login().isEmpty())
      {
        share->setLogin("guest");
      }
      
      d->importedShares << share;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : items)
    {
      Smb4KNetworkBrowserItem *browserItem = static_cast<Smb4KNetworkBrowserItem *>(item);
      
      if (browserItem && browserItem->shareItem()->isMounted() && !browserItem->shareItem()->isForeign())
      {
        //
        // Substract shares mounted by the user
        // 
        unmountedShares--;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : Smb4KBookmarkHandler::self()->bookmarksList())
  {
    d->bookmarkObjects << new Smb4KBookmarkObject(bookmark.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      if (o->type() == Share && o->hostName() == m_currentOptions->hostName() && o->workgroupName() == m_currentOptions->workgroupName())
      {
        o->setIP(m_currentOptions->ip());
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
        o->setUseUser(m_currentOptions->useUser());
        o->setUser(m_currentOptions->user());
        o->setUseGroup(m_currentOptions->useGroup());
        o->setGroup(m_currentOptions->group());
        o->setUseFileMode(m_currentOptions->useFileMode());
        o->setFileMode(m_currentOptions->fileMode());
        o->setUseDirectoryMode(m_currentOptions->useDirectoryMode());
        o->setDirectoryMode(m_currentOptions->directoryMode());
#endif
#if defined(Q_OS_LINUX)
        o->setCifsUnixExtensionsSupport(m_currentOptions->cifsUnixExtensionsSupport());
        o->setUseFileSystemPort(m_currentOptions->useFileSystemPort());
        o->setFileSystemPort(m_currentOptions->fileSystemPort());
        o->setUseSecurityMode(m_currentOptions->useSecurityMode());
        o->setSecurityMode(m_currentOptions->securityMode());
        o->setUseWriteAccess(m_currentOptions->useWriteAccess());
        o->setWriteAccess(m_currentOptions->writeAccess());
#endif
        o->setUseSmbPort(m_currentOptions->useSmbPort());
        o->setSmbPort(m_currentOptions->smbPort());
        o->setUseKerberos(m_currentOptions->useKerberos());
        o->setMACAddress(m_currentOptions->macAddress());
        o->setWOLSendBeforeNetworkScan(m_currentOptions->wolSendBeforeNetworkScan());
        o->setWOLSendBeforeMount(m_currentOptions->wolSendBeforeMount());
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KProfileObject *profile : d->profileObjects) {
        if (profile->isActiveProfile()) {
            activeProfile = profile->profileName();
            break;
        } else {
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : list)
      {
        QListWidgetItem *item = new QListWidgetItem(f->icon(), f->name(), listWidget, f->isDirectory() ? Directory : File);
        item->setData(Qt::UserRole, f->url());
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
      {
        if (!bookmark->url().isValid())
        {
          Smb4KNotification::invalidURLPassed();
          continue;
        }
        else
        {
          // Do nothing
        }

        xmlWriter.writeStartElement("bookmark");
        xmlWriter.writeAttribute("profile", bookmark->profile());
        xmlWriter.writeAttribute("group", bookmark->groupName());

        xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
        xmlWriter.writeTextElement("unc", bookmark->unc());
        xmlWriter.writeTextElement("login", bookmark->login());
        xmlWriter.writeTextElement("ip", bookmark->hostIP());
        xmlWriter.writeTextElement("type", bookmark->typeString());
        xmlWriter.writeTextElement("label", bookmark->label());

        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : job->shares())
  {
    //
    // Process only those shares that the user wants to see
    //
    if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
    {
      continue;
    }
    else
    {
      // Do nothing
    }
      
    if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
    {
      continue;
    }
    else
    {
      // Do nothing
    }
      
    //
    // Add or update the shares
    //
    if (!findShare(share->unc(), share->workgroupName()))
    {
      addShare(share);
    }
    else
    {
      updateShare(share);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *newEntry : newWalletEntries)
      {
        if (oldEntry->url().matches(newEntry->url(), QUrl::RemovePort /* leave the user info here */) &&
            oldEntry->workgroupName() == newEntry->workgroupName())
        {
          enable = true;
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths)
    {
      QDirIterator it(path, files, QDir::Files, QDirIterator::Subdirectories);
      
      while (it.hasNext())
      {
        result = it.next();
      }
      
      if (!result.isEmpty())
      {
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : maximalProtocolVersionChoices) {
        maximalProtocolVersion->addItem(c.label);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(displayNames)) {
        QList<QAction *> actionsList = m_menus->actions();

        for (QAction *action : qAsConst(actionsList)) {
            if (action->data().toMap().value("text").toString() == name) {
                addAction(action);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : mountedShares)
            {
              if (!s->isForeign())
              {
                mount = false;
                break;
              }
              else
              {
                continue;
              }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths)
    {
      QDirIterator it(path, files, QDir::Files, QDirIterator::Subdirectories);
      
      while (it.hasNext())
      {
        result = it.next();
      }
      
      if (!result.isEmpty())
      {
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->shareObjects) {
                if (url == obj->url()) {
                    object = obj;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
        mountpoints.removeOne(mountPoint->mountPoint());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &importedShare : d->importedShares)
    {
      // Check the mountpoint, since that one is unique. We will only use
      // Smb4KShare::path(), so that we do not run into trouble if a share 
      // is inaccessible.
      if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
      {
        found = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    // Do not process null pointers
    if (!share)
    {
      continue;
    }
    
    // Add the display name to the list
    displayNames << share->displayString();
    
    // Create the share menu
    KActionMenu *shareMenu = new KActionMenu(share->displayString(), menu());
    shareMenu->setIcon(share->icon());
    
    QMap<QString,QVariant> data;
    data["text"] = share->displayString();
    
    shareMenu->setData(data);
    m_menus->addAction(shareMenu);
    
    // Add the unmount action to the menu
    QAction *unmount = new QAction(KDE::icon("media-eject"), i18n("Unmount"), shareMenu->menu());
    
    QMap<QString,QVariant> unmountData;
    unmountData["type"] = "unmount";
    unmountData["mountpoint"] = share->path();
    
    unmount->setData(unmountData);
    unmount->setEnabled(!share->isForeign() || Smb4KMountSettings::unmountForeignShares());
    shareMenu->addAction(unmount);
    m_actions->addAction(unmount);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the bookmark action to the menu
    QAction *addBookmark = new QAction(KDE::icon("bookmark-new"), i18n("Add Bookmark"), shareMenu->menu());
    
    QMap<QString,QVariant> bookmarkData;
    bookmarkData["type"] = "bookmark";
    bookmarkData["mountpoint"] = share->path();
    
    addBookmark->setData(bookmarkData);
    shareMenu->addAction(addBookmark);
    m_actions->addAction(addBookmark);
    
    // Add the synchronization action to the menu
    QAction *synchronize = new QAction(KDE::icon("folder-sync"), i18n("Synchronize"), shareMenu->menu());
    
    QMap<QString,QVariant> syncData;
    syncData["type"] = "sync";
    syncData["mountpoint"] = share->path();
    
    synchronize->setData(syncData);
    synchronize->setEnabled(!QStandardPaths::findExecutable("rsync").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(synchronize);
    m_actions->addAction(synchronize);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the Open with Konsole action to the menu
    QAction *konsole = new QAction(KDE::icon("utilities-terminal"), i18n("Open with Konsole"), shareMenu->menu());
    
    QMap<QString,QVariant> konsoleData;
    konsoleData["type"] = "konsole";
    konsoleData["mountpoint"] = share->path();
    
    konsole->setData(konsoleData);
    konsole->setEnabled(!QStandardPaths::findExecutable("konsole").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(konsole);
    m_actions->addAction(konsole);
    
    // Add the Open with Filemanager action to the menu
    QAction *filemanager = new QAction(KDE::icon("system-file-manager"), i18n("Open with File Manager"), shareMenu->menu());
    
    QMap<QString,QVariant> fmData;
    fmData["type"] = "filemanager";
    fmData["mountpoint"] = share->path();
    
    filemanager->setData(fmData);
    filemanager->setEnabled(!share->isInaccessible());
    shareMenu->addAction(filemanager);
    m_actions->addAction(filemanager);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Smb4KPreviewFileItem &item : contents)
  {
    QListWidgetItem *listItem = new QListWidgetItem(item.itemIcon(), item.itemName(), m_view,
                                                    (item.isDir() ? Directory : File));
    listItem->setData(Qt::UserRole, item.itemName());    
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : list)
  {
    if (!d->groups.contains(bookmark->groupName()))
    {
      d->groups << bookmark->groupName();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroups_list)
  {
    if (!findWorkgroup(workgroup->workgroupName()))
    {
      addWorkgroup(workgroup);
      
      // Since this is a new workgroup, no master browser is present.
      HostPtr masterBrowser = HostPtr(new Smb4KHost());
      masterBrowser->setWorkgroupName(workgroup->workgroupName());
      masterBrowser->setHostName(workgroup->masterBrowserName());
      masterBrowser->setIP(workgroup->masterBrowserIP());
      masterBrowser->setIsMasterBrowser(true);
      
      addHost(masterBrowser);
    }
    else
    {
      updateWorkgroup(workgroup);
      
      // Check if the master browser changed
      QList<HostPtr> members = workgroupMembers(workgroup);
      
      for (const HostPtr &host : members)
      {
        if (workgroup->masterBrowserName() == host->hostName())
        {
          host->setIsMasterBrowser(true);
          
          if (!host->hasIP() && workgroup->hasMasterBrowserIP())
          {
            host->setIP(workgroup->masterBrowserIP());
          }
          else
          {
            // Do nothing
          }          
        }
        else
        {
          host->setIsMasterBrowser(false);
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : m_bookmarks)
  {
    QTreeWidgetItem *bookmarkItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
    bookmarkItem->setData(0, QTreeWidgetItem::UserType, static_cast<QUrl>(bookmark->url()));
    bookmarkItem->setIcon(0, bookmark->icon());
    bookmarkItem->setText(0, bookmark->displayString());
    bookmarkItem->setText((m_tree_widget->columnCount() - 1), QString("01_%1").arg(bookmark->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort)));
    bookmarkItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDragEnabled);
    
    if (!bookmark->groupName().isEmpty())
    {
      QList<QTreeWidgetItem *> items = m_tree_widget->findItems(bookmark->groupName(), Qt::MatchFixedString|Qt::MatchCaseSensitive, 0);
      
      if (!items.isEmpty())
      {
        items.first()->addChild(bookmarkItem);
        items.first()->setExpanded(true);
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      m_tree_widget->addTopLevelItem(bookmarkItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::sharesList()) {
        d->shareObjects << new Smb4KNetworkObject(share.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->path(), path, Qt::CaseInsensitive) == 0 ||
          QString::compare(s->canonicalPath(), path, Qt::CaseInsensitive) == 0)
      {
        share = s;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(actionsList)) {
            if (action->objectName() == "bookmark_action") {
                if (bookmarkMenu) {
                    bookmarkMenu->setBookmarkActionEnabled(action->isEnabled());
                    connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
                    continue;
                }
            } else if (QString::compare(action->objectName(), "filemanager_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "konsole_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "icon_view_action") == 0) {
                continue;
            } else if (QString::compare(action->objectName(), "list_view_action") == 0) {
                continue;
            }

            dynamicList << action;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *s : mountedShares)
        {
          if (!s->isForeign())
          {
            share->setMountData(s);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &c : encryptionLevelChoices)
  {
    encryptionLevel->addItem(c.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : m_categories)
  {
    if (!category.isEmpty())
    {
      QTreeWidgetItem *categoryItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
      categoryItem->setIcon(0, KDE::icon("folder-bookmark"));
      categoryItem->setText(0, category);
      categoryItem->setText((treeWidget->columnCount() - 1), QString("00_%1").arg(category));
      categoryItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDropEnabled);
      treeWidget->addTopLevelItem(categoryItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : Smb4KBookmarkHandler::self()->categoryList()) {
        d->bookmarkCategoryObjects << new Smb4KBookmarkObject(group);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : qAsConst(temporalBookmarkList)) {
        if (!categories.contains(b->categoryName())) {
            categories << b->categoryName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &editedOptions : qAsConst(editedOptionsList))
      {
        if (editedOptions->url().matches(options->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
        {
          // We do not need to update the custom options, because we are
          // using QSharedPointers.
          foundOptions = true;
          break;
        }        
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
                QAction *bookmarkAction = 0;

                if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty()) {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->label();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->label();
                } else {
                    bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkCategoryMenu->menu());
                    bookmarkAction->setObjectName(bookmark->url().toDisplayString());
                    QMap<QString, QVariant> bookmarkInfo;
                    bookmarkInfo["type"] = "bookmark";
                    bookmarkInfo["category"] = category;
                    bookmarkInfo["url"] = bookmark->url();
                    bookmarkInfo["text"] = bookmark->displayString();
                    bookmarkAction->setData(bookmarkInfo);
                    m_bookmarks->addAction(bookmarkAction);
                    sortedBookmarks << bookmark->displayString();
                }

                QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

                if (!mountedShares.isEmpty()) {
                    for (const SharePtr &share : qAsConst(mountedShares)) {
                        if (!share->isForeign()) {
                            bookmarkAction->setEnabled(false);
                            mountedBookmarks++;
                            break;
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : job->shares())
  {
    //
    // Process only those shares that the user wants to see
    //
    if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
    {
      continue;
    }
    else
    {
      // Do nothing
    }
      
    if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
    {
      continue;
    }
    else
    {
      // Do nothing
    }
      
    //
    // Add or update the shares
    //
    if (!findShare(share->url(), share->workgroupName()))
    {
      addShare(share);
    }
    else
    {
      updateShare(share);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : qAsConst(optionsList)) {
        if (options->remount() != Smb4KCustomOptions::UndefinedRemount) {
            remounts << options;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
        QAction *bookmarkAction = 0;

        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty()) {
            bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), menu());
            bookmarkAction->setObjectName(bookmark->url().toDisplayString());
            QMap<QString, QVariant> bookmarkInfo;
            bookmarkInfo["type"] = "bookmark";
            bookmarkInfo["category"] = "";
            bookmarkInfo["url"] = bookmark->url();
            bookmarkInfo["text"] = bookmark->label();
            bookmarkAction->setData(bookmarkInfo);
            m_bookmarks->addAction(bookmarkAction);
            sortedBookmarks << bookmark->label();
        } else {
            bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), menu());
            bookmarkAction->setObjectName(bookmark->url().toDisplayString());
            QMap<QString, QVariant> bookmarkInfo;
            bookmarkInfo["type"] = "bookmark";
            bookmarkInfo["category"] = "";
            bookmarkInfo["url"] = bookmark->url();
            bookmarkInfo["text"] = bookmark->displayString();
            bookmarkAction->setData(bookmarkInfo);
            m_bookmarks->addAction(bookmarkAction);
            sortedBookmarks << bookmark->displayString();
        }

        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

        if (!mountedShares.isEmpty()) {
            for (const SharePtr &share : qAsConst(mountedShares)) {
                if (!share->isForeign()) {
                    qDebug() << "Disabling bookmark" << share->url().toDisplayString();
                    bookmarkAction->setEnabled(false);
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      if (share->url() == object->url())
      {
        Smb4KSynchronizer::self()->synchronize(share);
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(walletEntries)) {
                    if (QString::compare(entry, itemUrlString, Qt::CaseInsensitive) == 0) {
                        itemUrlString = entry;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
        if (mountPoint->mountType() == "cifs" || mountPoint->mountType() == "smb3" || mountPoint->mountType() == "smbfs") {
            // Create a new share and set the mountpoint and filesystem
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(mountPoint->mountedFrom());
            share->setPath(mountPoint->mountPoint());
            share->setMounted(true);

            // Get all mount options
            QStringList mountOptions = mountPoint->mountOptions();

            for (const QString &option : qAsConst(mountOptions)) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setUserName(option.section('=', 1, 1).trimmed());
                }
            }

            // Work around empty usernames
            if (share->userName().isEmpty()) {
                share->setUserName("guest");
            }

            d->importedShares << share;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : qAsConst(m_workgroups))
                {
                  if (QString::compare(w->workgroupName(), service->domain(), Qt::CaseInsensitive) == 0)
                  {
                    foundWorkgroup = true;
                    break;
                  }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : qAsConst(categoriesList)) {
        d->bookmarkCategoryObjects << new Smb4KBookmarkObject(category);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares)
    {
      share->setHostIP(host->ip());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(actionList)) {
        if (action) {
            action->setEnabled(use);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &option : qAsConst(customOptions)) {
            switch (option->type()) {
            case Host: {
                QListWidgetItem *item = new QListWidgetItem(KDE::icon("network-server"), option->displayString(), optionsListWidget, Host);
                item->setData(Qt::UserRole, option->url());
                break;
            }
            case Share: {
                QListWidgetItem *item = new QListWidgetItem(KDE::icon("folder-network"), option->displayString(), optionsListWidget, Share);
                item->setData(Qt::UserRole, option->url());
                break;
            }
            default: {
                break;
            }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : d->bookmarks)
      {
        if (!bookmark->url().isValid())
        {
          Smb4KNotification::invalidURLPassed();
          continue;
        }
        else
        {
          // Do nothing
        }
        
        xmlWriter.writeStartElement("bookmark");
        xmlWriter.writeAttribute("profile", bookmark->profile());
        xmlWriter.writeAttribute("group", bookmark->groupName());

        xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
        xmlWriter.writeTextElement("url", bookmark->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort));
        xmlWriter.writeTextElement("login", bookmark->login());
        xmlWriter.writeTextElement("ip", bookmark->hostIpAddress());
        xmlWriter.writeTextElement("label", bookmark->label());

        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : optionsList) {
        if (options->remount() != Smb4KCustomOptions::UndefinedRemount) {
            remounts << options;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entriesList)
  {
    if (QString::compare(detailsWidget->item(0, 1)->text(), authInfo->displayString()) == 0 ||
        (QString::compare(detailsWidget->item(0, 1)->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem))
    {
      switch (authInfo->type())
      {
        case Host:
        case Share:
        {
          if (column == 1)
          {
            switch (row)
            {
              case 1: // Workgroup
              {
                authInfo->setWorkgroupName(detailsWidget->item(row, column)->text());
                break;
              }
              case 2: // Login
              {
                authInfo->setUserName(detailsWidget->item(row, column)->text());
                break;
              }
              case 3: // Password
              {
                authInfo->setPassword(detailsWidget->item(row, column)->text());
                break;
              }
              default:
              {
                break;
              }
            }
          }
            
          break;
        }
        default:
        {
          if (column == 1)
          {
            switch (row)
            {
              case 1: // Login
              {
                authInfo->setUserName(detailsWidget->item(row, column)->text());
                break;
              }
              case 2: // Password
              {
                authInfo->setPassword(detailsWidget->item(row, column)->text());
                break;
              }
              default:
              {
                break;
              }
            }
          }
            
          break;
        }
      }
        
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList()) {
        if (!categories.contains(b->categoryName())) {
            categories << b->categoryName();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : optionsListWidget->actions())
    {
      if (a->objectName() == "edit_action")
      {
        a->setEnabled(item != 0);
      }
      else if (a->objectName() == "remove_action")
      {
        a->setEnabled(item != 0);
      }
      else if (a->objectName() == "clear_action")
      {
        a->setEnabled(optionsListWidget->count() != 0);
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_menus->actions()) {
            if (action->data().toMap().value("text").toString() == name) {
                addAction(action);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : job->files())
  {
    if (f->isHidden() && !Smb4KSettings::previewHiddenItems())
    {
      continue;
    }
    
    list << f;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->hostObjects)
        {
          if (url == obj->url())
          {
            object = obj;
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
  {
    // Do not process null pointers
    if (!share)
    {
      continue;
    }
    else
    {
      // Do nothing
    }
    
    // Add the display name to the list
    displayNames << share->displayString();
    
    // Create the share menu
    KActionMenu *shareMenu = new KActionMenu(share->displayString(), menu());
    shareMenu->setIcon(share->icon());
    
    QMap<QString,QVariant> data;
    data["text"] = share->displayString();
    
    shareMenu->setData(data);
    m_menus->addAction(shareMenu);
    
    // Add the unmount action to the menu
    QAction *unmount = new QAction(KDE::icon("media-eject"), i18n("Unmount"), shareMenu->menu());
    
    QMap<QString,QVariant> unmountData;
    unmountData["type"] = "unmount";
    unmountData["mountpoint"] = share->path();
    
    unmount->setData(unmountData);
    unmount->setEnabled(!share->isForeign() || Smb4KMountSettings::unmountForeignShares());
    shareMenu->addAction(unmount);
    m_actions->addAction(unmount);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the bookmark action to the menu
    QAction *addBookmark = new QAction(KDE::icon("bookmark-new"), i18n("Add Bookmark"), shareMenu->menu());
    
    QMap<QString,QVariant> bookmarkData;
    bookmarkData["type"] = "bookmark";
    bookmarkData["mountpoint"] = share->path();
    
    addBookmark->setData(bookmarkData);
    shareMenu->addAction(addBookmark);
    m_actions->addAction(addBookmark);
    
    // Add the synchronization action to the menu
    QAction *synchronize = new QAction(KDE::icon("folder-sync"), i18n("Synchronize"), shareMenu->menu());
    
    QMap<QString,QVariant> syncData;
    syncData["type"] = "sync";
    syncData["mountpoint"] = share->path();
    
    synchronize->setData(syncData);
    synchronize->setEnabled(!QStandardPaths::findExecutable("rsync").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(synchronize);
    m_actions->addAction(synchronize);
    
    // Add a separator
    shareMenu->addSeparator();
    
    // Add the Open with Konsole action to the menu
    QAction *konsole = new QAction(KDE::icon("utilities-terminal"), i18n("Open with Konsole"), shareMenu->menu());
    
    QMap<QString,QVariant> konsoleData;
    konsoleData["type"] = "konsole";
    konsoleData["mountpoint"] = share->path();
    
    konsole->setData(konsoleData);
    konsole->setEnabled(!QStandardPaths::findExecutable("konsole").isEmpty() && !share->isInaccessible());
    shareMenu->addAction(konsole);
    m_actions->addAction(konsole);
    
    // Add the Open with Filemanager action to the menu
    QAction *filemanager = new QAction(KDE::icon("system-file-manager"), i18n("Open with File Manager"), shareMenu->menu());
    
    QMap<QString,QVariant> fmData;
    fmData["type"] = "filemanager";
    fmData["mountpoint"] = share->path();
    
    filemanager->setData(fmData);
    filemanager->setEnabled(!share->isInaccessible());
    shareMenu->addAction(filemanager);
    m_actions->addAction(filemanager);
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
      if (!isRunning())
      {
        //
        // Report the number of unmounted shares to the user if it were 
        // several ones
        // 
        if (d->newlyUnmounted > 1)
        {
          Smb4KNotification::sharesUnmounted(d->newlyUnmounted);
        }
      
        //
        // Reset the number of newly unmounted shares
        // 
        d->newlyUnmounted = 0;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : optionsList)
          {
            if (share->url().matches(o->url(), QUrl::RemoveUserInfo|QUrl::RemovePort))
            {
              options = o;
              break;
            }
            else if (!exactMatch && o->type() == Host && share->url().matches(o->url(), QUrl::RemoveUserInfo|QUrl::RemovePort|QUrl::RemovePath))
            {
              options = o;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mounted)
          {
            if (!share->isForeign())
            {
              number++;
              break;
            }
            else
            {
              continue;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
    {
      if (m_entries_widget->currentItem()->text() == authInfo->displayString() ||
          (m_entries_widget->currentItem()->text() == i18n("Default Login") && authInfo->type() == UnknownNetworkItem))
      {
        loadDetails(authInfo);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shareDir : qAsConst(shareDirs)) {
            dir.cd(shareDir);
            mountpoints << dir.absolutePath();
            dir.cdUp();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.trimmed().startsWith(QLatin1String("Enumerating")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("Server name")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("-------------")))
      {
        continue;
      }
      else
      {
        // Omit host names that contain spaces since QUrl cannot handle them.
        // And, they are wrong, anyway.
        if (!line.section("   ", 0, 0).trimmed().contains(" "))
        {
          Smb4KHost *host = new Smb4KHost();
          host->setHostName(line.section("   ", 0, 0).trimmed());
          host->setWorkgroupName(m_workgroup->workgroupName());
          host->setComment(line.section("   ", 1, -1).trimmed());
          
          if (QString::compare(host->hostName(), m_workgroup->masterBrowserName()) == 0)
          {
            host->setLogin(m_master_browser->login());
            host->setPassword(m_master_browser->password());
            host->setIsMasterBrowser(true);

            if (m_workgroup->hasMasterBrowserIP())
            {
              host->setIP(m_workgroup->masterBrowserIP());
            }
            else
            {
              // Do nothing
            }
          }
          else
          {
            host->setIsMasterBrowser(false);
          }
          
          m_hosts_list << host;
        }
        else
        {
          qDebug() << "This host name contains a space. I cannot handle this...";
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->sharesList)) {
        if (QString::compare(s->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                             url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                             Qt::CaseInsensitive)
                == 0
            && (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0)) {
            share = s;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : hostInfo.addresses())
      {
        // We only use global addresses.
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
        if (addr.isGlobal())
#else
        if (!addr.isLoopback() && !addr.isMulticast())
#endif
        {
          if (addr.protocol() == QAbstractSocket::IPv4Protocol)
          {
            ipAddress = addr;
            break;
          }
          else if (addr.protocol() == QAbstractSocket::IPv6Protocol)
          {
            // FIXME: Use the right address here.
            ipAddress = addr;
          }
          else
          {
            // Do nothing
          }
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : sharesList())
          {
            if (s->workgroupName() == file->workgroupName() && s->hostName() == file->hostName() && s->shareName() == file->shareName())
            {
              message = i18n("Looking for files and directories in %1...", s->displayString());   
              break;
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &opt : optionsList) {
            //
            // If we want to have an exact match, skip all options that do not match
            //
            if (exactMatch) {
                if (networkItem->type() != opt->type()
                    || QString::compare(networkItem->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                        opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                        Qt::CaseInsensitive)
                        != 0) {
                    continue;
                }
            }

            //
            // Now assign the options
            //
            if (networkItem->type() == Host && opt->type() == Host) {
                HostPtr host = networkItem.staticCast<Smb4KHost>();

                if (host) {
                    if (QString::compare(host->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                         opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                         Qt::CaseInsensitive)
                            == 0
                        || (host->url().isEmpty() && host->ipAddress() == opt->ipAddress())) {
                        options = opt;
                        break;
                    }
                }
            } else if (networkItem->type() == Share) {
                SharePtr share = networkItem.staticCast<Smb4KShare>();

                if (share) {
                    if (opt->type() == Share
                        && QString::compare(share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                            opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::StripTrailingSlash),
                                            Qt::CaseInsensitive)
                            == 0) {
                        // Since this is the exact match, break here
                        options = opt;
                        break;
                    } else if (opt->type() == Host
                               && QString::compare(share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath | QUrl::StripTrailingSlash),
                                                   opt->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath | QUrl::StripTrailingSlash),
                                                   Qt::CaseInsensitive)
                                   == 0) {
                        // These options belong to the host. Do not break here,
                        // because there might still be an exact match
                        options = opt;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : qAsConst(temporalBookmarkList)) {
        if (QString::compare(b->label().toUpper(), label.toUpper()) == 0) {
            bookmark = b;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : workgroupsList())
    {
      QList<QTreeWidgetItem *> items = m_widget->findItems(workgroup->workgroupName(), Qt::MatchFixedString, Smb4KNetworkBrowser::Network);
      
      if (items.isEmpty())
      {
        (void) new Smb4KNetworkBrowserItem(m_widget, workgroup);
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : qAsConst(d->options)) {
        if (!options->macAddress().isEmpty() && (options->wolSendBeforeNetworkScan() || options->wolSendBeforeMount())) {
            optionsList << options;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mainWindow](const QStringList & /*args*/, const QString & /*workingDir*/) {
        if (mainWindow->isVisible()) {
#if KWINDOWSYSTEM_VERSION >= QT_VERSION_CHECK(5, 91, 0)
            KWindowSystem::updateStartupId(mainWindow->windowHandle());
            KWindowSystem::activateWindow(mainWindow->windowHandle());
#endif
        } else {
            mainWindow->setVisible(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members)
        {
          bool foundHost = false;
            
          for (int i = 0; i < workgroupItem->childCount(); ++i)
          {
            Smb4KNetworkBrowserItem *hostItem = static_cast<Smb4KNetworkBrowserItem *>(workgroupItem->child(i));
              
            if (hostItem->hostItem()->hostName() == host->hostName())
            {
              foundHost = true;
              break;
            }
          }
            
          if (!foundHost)
          {
            (void) new Smb4KNetworkBrowserItem(workgroupItem, host);
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(bookmarks)) {
        SharePtr share = SharePtr(new Smb4KShare());
        share->setHostName(bookmark->hostName());
        share->setShareName(bookmark->shareName());
        share->setWorkgroupName(bookmark->workgroupName());
        share->setHostIpAddress(bookmark->hostIpAddress());
        share->setLogin(bookmark->login());
        mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : allBookmarks)
      {
        if (!bookmark->url().isValid())
        {
          Smb4KNotification::invalidURLPassed();
          continue;
        }
        else
        {
          // Do nothing
        }

        xmlWriter.writeStartElement("bookmark");
        xmlWriter.writeAttribute("profile", bookmark->profile());
        xmlWriter.writeAttribute("group", bookmark->groupName());

        xmlWriter.writeTextElement("workgroup", bookmark->workgroupName());
        xmlWriter.writeTextElement("unc", bookmark->unc());
        xmlWriter.writeTextElement("login", bookmark->login());
        xmlWriter.writeTextElement("ip", bookmark->hostIP());
        xmlWriter.writeTextElement("type", bookmark->typeString());
        xmlWriter.writeTextElement("label", bookmark->label());

        xmlWriter.writeEndElement();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
  {
    if (url == o->url().toString())
    {
      m_currentOptions = o;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : oldWalletEntries)
    {
      for (Smb4KAuthInfo *newEntry : newWalletEntries)
      {
        if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive) == 0 /* leave the user info here */ &&
            QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0)
        {
          enable = true;
          break;
        }
        else
        {
          // Do nothing
        }
      }
      
      if (enable)
      {
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
  {
    Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);
    shares << item->shareItem();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : oldWalletEntries) {
            for (Smb4KAuthInfo *newEntry : newWalletEntries) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                        == 0 /* leave the user info here */
                    && QString::compare(oldEntry->workgroupName(), newEntry->workgroupName(), Qt::CaseInsensitive) == 0) {
                    enable = true;
                    break;
                }
            }

            if (enable) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints) {
#if defined(Q_OS_LINUX)
        if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0
            && QString::compare(mountPoint->mountType(), "cifs", Qt::CaseInsensitive) == 0)
#else
        if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0
            && QString::compare(mountPoint->mountType(), "smbfs", Qt::CaseInsensitive) == 0)
#endif
        {
            mountPointOk = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : displayNames) {
        for (QAction *action : m_menus->actions()) {
            if (action->data().toMap().value("text").toString() == name) {
                addAction(action);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : d->bookmarks)
  {
    if (QString::compare(group, bookmark->groupName(), Qt::CaseInsensitive) == 0)
    {
      bookmarks << bookmark;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *oldEntry : qAsConst(oldLoginCredentials)) {
            for (Smb4KAuthInfo *newEntry : qAsConst(newLoginCredentials)) {
                if (QString::compare(oldEntry->url().toString(QUrl::RemovePort), newEntry->url().toString(QUrl::RemovePort), Qt::CaseInsensitive)
                        == 0 /* leave the user info here */) {
                    enable = true;
                    break;
                }
            }

            if (enable) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item && !item->shareItem()->isInaccessible()) {
            openShare(item->shareItem(), FileManager);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entriesList) {
        if (QString::compare(detailsWidget->item(0, 1)->text(), authInfo->displayString()) == 0
            || (QString::compare(detailsWidget->item(0, 1)->text(), i18n("Default Login")) == 0 && authInfo->type() == UnknownNetworkItem)) {
            switch (authInfo->type()) {
            case Host:
            case Share: {
                if (column == 1) {
                    switch (row) {
                    case 1: // Workgroup
                    {
                        authInfo->setWorkgroupName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 2: // Login
                    {
                        authInfo->setUserName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 3: // Password
                    {
                        authInfo->setPassword(detailsWidget->item(row, column)->text());
                        break;
                    }
                    default: {
                        break;
                    }
                    }
                }

                break;
            }
            default: {
                if (column == 1) {
                    switch (row) {
                    case 1: // Login
                    {
                        authInfo->setUserName(detailsWidget->item(row, column)->text());
                        break;
                    }
                    case 2: // Password
                    {
                        authInfo->setPassword(detailsWidget->item(row, column)->text());
                        break;
                    }
                    default: {
                        break;
                    }
                    }
                }

                break;
            }
            }

            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : m_groups)
  {
    if (!group.isEmpty())
    {
      QTreeWidgetItem *groupItem = new QTreeWidgetItem(QTreeWidgetItem::UserType);
      groupItem->setIcon(0, KDE::icon("folder-bookmark"));
      groupItem->setText(0, group);
      groupItem->setText((m_tree_widget->columnCount() - 1), QString("00_%1").arg(group));
      groupItem->setFlags(Qt::ItemIsSelectable|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled|Qt::ItemIsDropEnabled);
      m_tree_widget->addTopLevelItem(groupItem);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item) {
            shares << item->shareItem();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &importedShare : d->importedShares)
    {
      // Check the mountpoint, since that one is unique. We will only use
      // Smb4KShare::path(), so that we do not run into trouble if a share 
      // is inaccessible.
      if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
      {
        found = true;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &newWorkgroup : job->workgroups())
    {
        bool foundWorkgroup = false;
            
        for (const WorkgroupPtr &workgroup : d->tempWorkgroupList)
        {
            if (workgroup->workgroupName() == newWorkgroup->workgroupName())
            {
                foundWorkgroup = true;
                break;
            }
        }
            
        if (!foundWorkgroup)
        {
            d->tempWorkgroupList << newWorkgroup;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(d->bookmarks)) {
        HostPtr host = findHost(bookmark->hostName(), bookmark->workgroupName());

        if (host) {
            if (host->hasIpAddress() && bookmark->hostIpAddress() != host->ipAddress()) {
                bookmark->setHostIpAddress(host->ipAddress());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList())
  {
    lookupShares(host);
    
    while(isRunning())
    {
      QTest::qWait(50);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : qAsConst(mountedSharesList()))
    {
      for (const SharePtr &importedShare : qAsConst(d->importedShares))
      {
        // Check the mountpoint, since that one is unique. We will only use
        // Smb4KShare::path(), so that we do not run into trouble if a share 
        // is inaccessible.
        if (QString::compare(mountedShare->path(), importedShare->path()) == 0)
        {
          found = true;
          break;
        }
      }
      
      if (!found)
      {
        unmountedShares << mountedShare;
      }
      
      found = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList)
    {
      switch (o->type())
      {
        case Host:
        {
          QListWidgetItem *item = new QListWidgetItem(KDE::icon("network-server"), o->displayString(), optionsListWidget, Host);
          item->setData(Qt::UserRole, o->url().toDisplayString());
          break;
        }
        case Share:
        {
          QListWidgetItem *item = new QListWidgetItem(KDE::icon("folder-network"), o->displayString(), optionsListWidget, Share);
          item->setData(Qt::UserRole, o->url().toDisplayString());
          break;
        }
        default:
        {
          break;
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : m_listing)
    {
      if (item->data(Qt::UserRole).toUrl().matches(f->url(), QUrl::None))
      {
        m_currentItem = f;
        emit requestPreview(m_currentItem);
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarks)
  {
    QListWidgetItem *item = new QListWidgetItem(b->icon(), b->unc(), m_widget);
    item->setData(Qt::UserRole, static_cast<QUrl>(b->url()));
    
    m_bookmarks << b;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdErrList)
        {
          if (line.contains("Connecting to host="))
          {
            m_master_browser = line.section('=', 1, 1).trimmed();
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
  {
    m_searchResults << share->url().toString();
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : d->options)
      {
        if (options->hasOptions() || options->remount() == Smb4KCustomOptions::RemountOnce)
        {
          xmlWriter.writeStartElement("options");
          xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
          xmlWriter.writeAttribute("profile", options->profile());

          xmlWriter.writeTextElement("workgroup", options->workgroupName());
          xmlWriter.writeTextElement("url", options->url().toDisplayString());
          xmlWriter.writeTextElement("ip", options->ipAddress());
          
          xmlWriter.writeStartElement("custom");

          QMap<QString,QString> map = options->customOptions();
          QMapIterator<QString,QString> it(map);

          while (it.hasNext())
          {
            it.next();

            if (!it.value().isEmpty())
            {
              xmlWriter.writeTextElement(it.key(), it.value());
            }
          }

          xmlWriter.writeEndElement();
          xmlWriter.writeEndElement();
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : qAsConst(addresses)) {
            // We only use global addresses.
            if (addr.isGlobal()) {
                if (addr.protocol() == QAbstractSocket::IPv4Protocol) {
                    ipAddress = addr;
                    break;
                } else if (addr.protocol() == QAbstractSocket::IPv6Protocol) {
                    // FIXME: Use the right address here.
                    ipAddress = addr;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &option : qAsConst(options)) {
            //
            // Skip one time remount shares, if needed
            //
            if (option->remount() == Smb4KCustomOptions::RemountOnce && !Smb4KMountSettings::remountShares()) {
                continue;
            }

            //
            // Check which share has to be remounted
            //
            QList<SharePtr> mountedShares = findShareByUrl(option->url());
            bool remountShare = true;

            for (const SharePtr &share : qAsConst(mountedShares)) {
                if (!share->isForeign()) {
                    remountShare = false;
                    break;
                }
            }

            //
            // Insert the share to the list of remounts
            //
            if (remountShare) {
                bool insertShare = true;

                for (const SharePtr &share : qAsConst(d->remounts)) {
                    if (QString::compare(share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                         option->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort))
                        == 0) {
                        insertShare = false;
                        break;
                    }
                }

                if (insertShare) {
                    SharePtr share = SharePtr(new Smb4KShare());
                    share->setUrl(option->url());
                    share->setWorkgroupName(option->workgroupName());
                    share->setHostIpAddress(option->ipAddress());

                    if (share->url().isValid() && !share->url().isEmpty()) {
                        d->remounts << share;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : displayNames)
  {
    for (QAction *action : m_menus->actions())
    {
      if (action->data().toMap().value("text").toString() == name)
      {
        addAction(action);
        break;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &workgroup : Smb4KGlobal::workgroupsList())
  {
    d->workgroupObjects << new Smb4KNetworkObject(workgroup.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : bookmarkMenu->menu()->actions()) {
                if (action->data().toMap().value("text").toString() == displayStringBefore) {
                    insertAction(action, bookmarkAction);
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
    {
      if (share->url() == a->data().toMap().value("url").toUrl())
      {
        a->setEnabled(!share->isMounted());
        bookmarkGroup = a->data().toMap().value("group").toString();
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarksList())
  {
    if (!groups.contains(b->groupName()))
    {
      groups << b->groupName();
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (!s->isForeign())
      {
        p->onlyForeignShares = false;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *h : p->hostsList)
  {
    if (QString::compare(h->workgroupName(), workgroup->workgroupName(), Qt::CaseInsensitive) == 0)
    {
      hosts += h;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : Smb4KGlobal::hostsList()) {
        d->hostObjects << new Smb4KNetworkObject(host.data());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entries_list)
  {
    if (QString::compare(m_auth_info->url().toString(QUrl::RemovePort),
                         authInfo->url().toString(QUrl::RemovePort),
                         Qt::CaseInsensitive) == 0 /* we can leave the user info here */ ||
        (m_auth_info->type() == UnknownNetworkItem && m_auth_info->type() == authInfo->type()))
    {
      switch (m_auth_info->type())
      {
        case Host:
        case Share:
        {
          authInfo->setWorkgroupName(m_auth_info->workgroupName());
          authInfo->setUserName(m_auth_info->userName());
          authInfo->setPassword(m_auth_info->password());
          break;
        }
        default:
        {
          authInfo->setUserName(m_auth_info->userName());
          authInfo->setPassword(m_auth_info->password());
          break;
        }
      }
      
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *entry : qAsConst(m_entriesList)) {
            if (walletEntriesWidget->currentItem()->text() == entry->displayString()
                || (walletEntriesWidget->currentItem()->text() == i18n("Default Login") && entry->type() == UnknownNetworkItem)) {
                dlg.setPrompt(i18n("Set the username and password for wallet entry %1.", entry->displayString()));
                dlg.setUsername(entry->userName());
                dlg.setPassword(entry->password());

                authInfo = entry;

                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : job->shares())
  {
    //
    // Process only those shares that the user wants to see
    //
    if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
    {
      continue;
    }
      
    if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
    {
      continue;
    }
      
    //
    // Add or update the shares
    //
    if (!findShare(share->url(), share->workgroupName()))
    {
      addShare(share);
    }
    else
    {
      updateShare(share);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
      {
        if (line.trimmed().startsWith(QLatin1String("Enumerating")))
        {
          continue;
        }
        else if (line.trimmed().startsWith(QLatin1String("Share name")))
        {
          continue;
        }
        else if (line.trimmed().startsWith(QLatin1String("----------")))
        {
          continue;
        }
        else if (line.contains(" Disk     ", Qt::CaseSensitive) /* line has comment */ ||
                (!line.contains(" Disk     ", Qt::CaseSensitive) &&
                  line.trimmed().endsWith(QLatin1String(" Disk"), Qt::CaseSensitive) /* line has no comment */))
        {
          if (!line.trimmed().endsWith(QLatin1String(" Disk"), Qt::CaseSensitive))
          {
            shareName = line.section(" Disk     ", 0, 0).trimmed();
            comment = line.section(" Disk     ", 1, 1).trimmed();
          }
          else
          {
            shareName = line.section(" Disk", 0, 0).trimmed();
            comment = "";
          }
          
          typeString = "Disk";
        }
        else if (line.contains(" IPC      ", Qt::CaseSensitive) /* line has comment */ ||
                (!line.contains(" IPC      ", Qt::CaseSensitive) &&
                  line.trimmed().endsWith(QLatin1String(" IPC"), Qt::CaseSensitive) /* line has no comment */))
        {
          if (!line.trimmed().endsWith(QLatin1String(" IPC"), Qt::CaseSensitive))
          {
            shareName = line.section(" IPC      ", 0, 0).trimmed();
            comment = line.section(" IPC      ", 1, 1).trimmed();
          }
          else
          {
            shareName = line.section(" IPC", 0, 0).trimmed();
            comment = "";
          }
          
          typeString = "IPC";
        }
        else if (line.contains(" Print    ", Qt::CaseSensitive) /* line has comment */ ||
                (!line.contains(" Print    ", Qt::CaseSensitive) &&
                  line.trimmed().endsWith(QLatin1String(" Print"), Qt::CaseSensitive) /* line has no comment */))
        {
          if (!line.trimmed().endsWith(QLatin1String(" Print"), Qt::CaseSensitive))
          {
            shareName = line.section(" Print    ", 0, 0).trimmed();
            comment = line.section(" Print    ", 1, 1).trimmed();
          }
          else
          {
            shareName = line.section(" Print", 0, 0).trimmed();
            comment = "";
          }
          
          typeString = "Printer";
        }
        else
        {
          continue;
        }
        
        if (!shareName.isEmpty())
        {
          SharePtr share = SharePtr(new Smb4KShare());
          share->setShareName(shareName);
          share->setHostName(m_host->hostName());
          share->setWorkgroupName(m_host->workgroupName());
          share->setComment(comment);
          share->setTypeString(typeString);
          share->setLogin(m_host->login());
          share->setPassword(m_host->password());
          
          if (m_host->hasIP())
          {
            share->setHostIP(m_host->ip());
          }
          else
          {
            // Do nothing
          }
          
          m_shares_list << share;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : Smb4KGlobal::sharesList()) {
            if (share->url() == object->url()) {
                shares << share;
                break;
            } else {
                continue;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        saveSettings();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      SharePtr share = SharePtr(new Smb4KShare());
      share->setHostName(bookmark->hostName());
      share->setShareName(bookmark->shareName());
      share->setWorkgroupName(bookmark->workgroupName());
      share->setHostIP(bookmark->hostIP());
      share->setLogin(bookmark->login());
      mounts << share;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KPreviewDialog *p : d->previewDialogs)
  {
    if (share == p->share())
    {
      dlg = p;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &w : qAsConst(d->tempWorkgroupList)) {
                if (w->workgroupName() == workgroup->workgroupName()) {
                    foundWorkgroup = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : job->shares()) {
        // Process only those shares that the user wants to see
        if (share->isHidden() && !Smb4KSettings::detectHiddenShares()) {
            continue;
        }

        if (share->isPrinter() && !Smb4KSettings::detectPrinterShares()) {
            continue;
        }

        // Add or update the shares
        if (!findShare(share->url(), share->workgroupName())) {
            addShare(share);
        } else {
            updateShare(share);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList()) {
                check(share);
                emit updated(share);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : workgroups) {
            Smb4KNetworkBrowserItem *tempWorkgroup = static_cast<Smb4KNetworkBrowserItem *>(item);

            if (tempWorkgroup->type() == Workgroup && tempWorkgroup->workgroupItem()->workgroupName() == workgroup->workgroupName()) {
                workgroupItem = tempWorkgroup;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarks)
  {
    QListWidgetItem *item = new QListWidgetItem(b->icon(), b->displayString(), m_widget);
    item->setData(Qt::UserRole, static_cast<QUrl>(b->url()));
    
    m_bookmarks << b;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
        {
          if (share->isMounted())
          {
            slotShareMounted(share);
              
            if (!share->isForeign())
            {
              break;
            }
            else
            {
              continue;
            }
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : addresses) {
            // We only use global addresses.
            if (addr.isGlobal()) {
                if (addr.protocol() == QAbstractSocket::IPv4Protocol) {
                    ipAddress = addr;
                    break;
                } else if (addr.protocol() == QAbstractSocket::IPv6Protocol) {
                    // FIXME: Use the right address here.
                    ipAddress = addr;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);

        if (item && !item->shareItem()->isInaccessible()) {
            openShare(item->shareItem(), Konsole);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
    mountpoints.removeOne(mountPoint->mountPoint());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &addr : ipAddresses)
            {
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : qAsConst(p->mountedSharesList)) {
            if (QString::compare(s->path(), path, Qt::CaseInsensitive) == 0 || QString::compare(s->canonicalPath(), path, Qt::CaseInsensitive) == 0) {
                share = s;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : sharesList())
        {
          if (share->url() == object->url())
          {
            Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(share);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user : qAsConst(userList)) {
                    //
                    // Create a temp share
                    //
                    SharePtr tempShare = share;

                    //
                    // Set the login
                    //
                    tempShare->setUserName(user);

                    //
                    // Read the authentication information
                    //
                    readLoginCredentials(tempShare);

                    //
                    // Save the authentication data in the map
                    //
                    knownLogins.insert(tempShare->userName(), tempShare->password());

                    //
                    // Clear the temp share
                    //
                    tempShare.clear();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOut)
  {
    if (!line.contains("added interface", Qt::CaseInsensitive) &&
        !line.contains("tdb(", Qt::CaseInsensitive) &&
        !line.contains("Got a positive", Qt::CaseInsensitive) &&
        !line.contains("error connecting", Qt::CaseInsensitive) &&
        !line.isEmpty())
    {
      if (!line.contains("\\") && !line.trimmed().isEmpty())
      {
        workgroup_name = line.trimmed();
        continue;
      }
      else if (line.count("\\") == 3)
      {
        QString unc = line.trimmed().section('\t', 0, 0).trimmed().replace("\\", "/");
        QString comment = line.trimmed().section('\t', 1, -1).trimmed();

        if (unc.contains(m_string, Qt::CaseInsensitive))
        {
          Smb4KShare *share = new Smb4KShare();
          share->setURL(unc);
          share->setComment(comment);
          share->setWorkgroupName(workgroup_name);

          emit result(share);
          delete share;
        }
        else
        {
          // Do nothing
        }
        continue;
      }
      else
      {
        continue;
      }
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : displayNames)
  {
    for (QAction *action : m_menus->actions())
    {
      if (action->data().toMap().value("text").toString() == name)
      {
        addAction(action);
        break;
      }
      else
      {
        // Do nothing
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs()) {
            if (QString("SyncJob_%1").arg(share->canonicalPath()) == job->objectName()) {
                job->kill(KJob::EmitResult);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
  {
#if defined(Q_OS_LINUX)
    if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0 &&
        QString::compare(mountPoint->mountType(), "cifs", Qt::CaseInsensitive) == 0)
#else
    if (QString::compare(args["mh_mountpoint"].toString(), mountPoint->mountPoint()) == 0 &&
        QString::compare(mountPoint->mountType(), "smbfs", Qt::CaseInsensitive) == 0)
#endif
    {
      mountPointOk = true;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () {
    //
    // Check the online state
    // 
    checkOnlineState(false);    
    
    //
    // Tell the program that we are ready to check the network accessibilty
    // 
    emit networkSessionInitialized();

    // 
    // Start the timer to continously check the online state
    // and, under FreeBSD, additionally the mounted shares.
    // 
    startTimer(1000);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
  {
    mountShare(share);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : qAsConst(temporalBookmarkList)) {
        if (categoryName == bookmark->categoryName()) {
            bookmarks << bookmark;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *mountedShare : mountedSharesList())
      {
        if (mountedShare->url() == object->url())
        {
          shares << mountedShare;
          break;
        }
        else
        {
          continue;
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : m_bookmarks) {
        if (b->url() == url) {
            bookmark = b;
            break;
        } else {
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &h : p->hostsList)
  {
    if ((workgroup.isEmpty() || QString::compare(h->workgroupName(), workgroup, Qt::CaseInsensitive) == 0) &&
        QString::compare(h->hostName(), name, Qt::CaseInsensitive) == 0)
    {
      host = h;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *b : m_bookmarks)
  {
    if (b->url() == url)
    {
      bookmark = b;
      break;
    }
    else
    {
      continue;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : allActions)
    {
      if (a->data().toMap().value("type").toString() == "toplevel_mount" && bookmarkGroup.isEmpty())
      {
        a->setEnabled(!allMounted);
        break;
      }
      else if (a->data().toMap().value("type").toString() == "group_mount" &&
               a->data().toMap().value("group").toString() == bookmarkGroup)
      {
        a->setEnabled(!allMounted);
        break;
      }
      else
      {
        continue;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : Smb4KGlobal::hostsList())
        {
          if (host->url() == object->url())
          {
            Smb4KCustomOptionsManager::self()->openCustomOptionsDialog(host);
            break;
          }
          else
          {
            continue;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
          {
            bool foundShare = false;
            
            for (int i = 0; i < hostItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *shareItem = static_cast<Smb4KNetworkBrowserItem *>(hostItem->child(i));
              
              if (shareItem->shareItem()->unc() == share->unc())
              {
                foundShare = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundShare)
            {
              (void) new Smb4KNetworkBrowserItem(hostItem, share);
            }
            else
            {
              // Do nothing
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(entryList)) {
                if (networkItem->type() == Host) {
                    if (QString::compare(entry, networkItem->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), Qt::CaseInsensitive) == 0
                        || QString::compare(entry,
                                            networkItem->url().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort),
                                            Qt::CaseInsensitive)
                            == 0) {
                        d->wallet->readMap(entry, authInfoMap);
                        break;
                    }
                } else if (networkItem->type() == Share) {
                    //
                    // Cast the network item. We need some share specific info
                    //
                    SharePtr share = networkItem.staticCast<Smb4KShare>();

                    if (share) {
                        //
                        // Process normal and 'homes' shares differently
                        //
                        if (!share->isHomesShare()) {
                            //
                            // Prefer the credentials for the share. Use the ones for the
                            // host as fallback.
                            //
                            if (QString::compare(entry, share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), Qt::CaseInsensitive) == 0
                                || QString::compare(entry,
                                                    share->url().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort),
                                                    Qt::CaseInsensitive)
                                    == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                                break;
                            } else if (QString::compare(entry,
                                                        share->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                                        Qt::CaseInsensitive)
                                           == 0
                                       || QString::compare(
                                              entry,
                                              share->url().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                              Qt::CaseInsensitive)
                                           == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                            }
                        } else {
                            //
                            // Prefer the credentials for the share. Use the ones for the
                            // host as fallback.
                            //
                            if (QString::compare(entry, share->homeUrl().toString(QUrl::RemoveUserInfo | QUrl::RemovePort), Qt::CaseInsensitive) == 0
                                || QString::compare(entry,
                                                    share->homeUrl().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort),
                                                    Qt::CaseInsensitive)
                                    == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                                break;
                            } else if (QString::compare(entry,
                                                        share->homeUrl().toString(QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                                        Qt::CaseInsensitive)
                                           == 0
                                       || QString::compare(
                                              entry,
                                              share->homeUrl().toString(QUrl::RemoveScheme | QUrl::RemoveUserInfo | QUrl::RemovePort | QUrl::RemovePath),
                                              Qt::CaseInsensitive)
                                           == 0) {
                                d->wallet->readMap(entry, authInfoMap);
                            }
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : list) {
                QListWidgetItem *item = new QListWidgetItem(f->icon(), f->name(), listWidget, f->isDirectory() ? Directory : File);
                item->setData(Qt::UserRole, f->url());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : mountedShares)
      {
        if (!mountedShare->isForeign())
        {
          share->setMountData(mountedShare.data());
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &b : bookmarks)
  {
    QListWidgetItem *item = new QListWidgetItem(b->icon(), b->displayString(), listWidget);
    item->setData(Qt::UserRole, static_cast<QUrl>(b->url()));
    
    m_bookmarks << b;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : stdOutList)
    {
      if (line.trimmed().startsWith(QLatin1String("Enumerating")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("Domain name")))
      {
        continue;
      }
      else if (line.trimmed().startsWith(QLatin1String("-------------")))
      {
        continue;
      }
      else if (line.trimmed().isEmpty())
      {
        continue;
      }
      else
      {
        // This is the workgroup and master entry. Process it.
        workgroupName = line.section("   ", 0, 0).trimmed();
        masterBrowserName = line.section("   ", 1, -1).trimmed();
      }
      
      if (!workgroupName.isEmpty() && !masterBrowserName.isEmpty())
      {
        WorkgroupPtr workgroup = WorkgroupPtr(new Smb4KWorkgroup());
        workgroup->setWorkgroupName(workgroupName);
        workgroup->setMasterBrowserName(masterBrowserName);
        m_workgroups_list << workgroup;
        
        workgroupName.clear();
        masterBrowserName.clear();
      }
      else
      {
        // Do nothing
      }      
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : selectedItems)
    {
      Smb4KNetworkSearchItem *searchItem = static_cast<Smb4KNetworkSearchItem *>(item);
      
      if (searchItem && searchItem->shareItem()->isMounted() && !searchItem->shareItem()->isForeign())
      {
        //
        // Substract shares mounted by the user
        // 
        unmountedShares--;
      }
      else if (searchItem && searchItem->shareItem()->isPrinter())
      {
        //
        // Substract printer shares
        // 
        printerShares++;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCoreConfigSkeleton::ItemEnum::Choice &to : tabOrientationChoices)
  {
    tabOrientation->addItem(to.label);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KAuthInfo *authInfo : m_entriesList) {
        switch (authInfo->type()) {
        case UnknownNetworkItem: {
            (void)new QListWidgetItem(KDE::icon("dialog-password"), i18n("Default Login"), walletEntriesWidget);
            break;
        }
        default: {
            (void)new QListWidgetItem(KDE::icon("dialog-password"), authInfo->displayString(), walletEntriesWidget);
            break;
        }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : shares_list)
    {
      //
      // Process only those shares that the user wants to see
      //
      if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      //
      // Check if the share has already been mounted. Since version 2.1.0
      //
      QList<Smb4KShare *> mountedShares = findShareByUNC(share->unc());
      bool mounted = false;
      
      if (!mountedShares.isEmpty())
      {
        if (Smb4KSettings::detectAllShares())
        {
          //
          // FIXME: Add all mounts of this share
          //          
          share->setMountData(mountedShares.first());
        }
        else
        {
          for (Smb4KShare *mountedShare : mountedShares)
          {
            if (!mountedShare->isForeign())
            {
              share->setMountData(mountedShare);
              break;
            }
            else
            {
              continue;
            }
          }
        }
      }
      else
      {
        // Do nothing
      }
      
      //
      // Add the host's IP address and authentication information
      //
      Smb4KHost *host = findHost(share->hostName(), share->workgroupName());
      
      if (host)
      {
        share->setHostIP(host->ip());
        share->setLogin(host->login());
        share->setPassword(host->password());
      }
      else
      {
        // Do nothing
      }
      
      //
      // Add or update the shares
      //      
      if (!findShare(share->unc(), share->workgroupName()))
      {
        addShare(new Smb4KShare(*share));
      }
      else
      {
        updateShare(share);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : members)
          {
            bool foundHost = false;
            
            for (int i = 0; i < workgroupItem->childCount(); ++i)
            {
              Smb4KNetworkBrowserItem *hostItem = static_cast<Smb4KNetworkBrowserItem *>(workgroupItem->child(i));
              
              if (hostItem->hostItem()->hostName() == host->hostName())
              {
                foundHost = true;
                break;
              }
              else
              {
                continue;
              }
            }
            
            if (!foundHost)
            {
              (void) new Smb4KNetworkBrowserItem(workgroupItem, host);
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares)) {
                    if (!share->isForeign()) {
                        mountedBookmarks++;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHomesUsers *users : qAsConst(allUsers)) {
                xmlWriter.writeStartElement("homes");
                xmlWriter.writeAttribute("profile", users->profile());
                xmlWriter.writeTextElement("host", users->hostName());
                xmlWriter.writeTextElement("workgroup", users->workgroupName());
                xmlWriter.writeTextElement("ip", users->hostIP());
                xmlWriter.writeStartElement("users");

                QStringList userList = users->userList();

                for (const QString &user : qAsConst(userList)) {
                    xmlWriter.writeTextElement("user", user);
                }

                xmlWriter.writeEndElement();
                xmlWriter.writeEndElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : options)
  {
    if (o->remount() == Smb4KCustomOptions::RemountOnce)
    {
      remounts << o;
    }
    else if (o->remount() == Smb4KCustomOptions::RemountAlways)
    {
      remounts << o;
    }
    else
    {
      // Do nothing
    }  
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList)
  {
    if (QString::compare(s->url().toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                         url.toString(QUrl::RemoveUserInfo|QUrl::RemovePort),
                         Qt::CaseInsensitive) == 0 &&
        (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0))
    {
      share = s;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (!isRunning()) {
            import(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares_list)
    {
      //
      // Process only those shares that the user wants to see
      //
      if (share->isHidden() && !Smb4KSettings::detectHiddenShares())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      if (share->isPrinter() && !Smb4KSettings::detectPrinterShares())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      //
      // Add the host's IP address and authentication information
      //
      HostPtr host = findHost(share->hostName(), share->workgroupName());
      
      if (host)
      {
        share->setHostIP(host->ip());
        share->setLogin(host->login());
        share->setPassword(host->password());
      }
      else
      {
        // Do nothing
      }
      
      //
      // Add or update the shares
      //      
      if (!findShare(share->unc(), share->workgroupName()))
      {
        addShare(share);
      }
      else
      {
        updateShare(share);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
      {
        if (o->type() == Share && o->hostName() == options->hostName() && o->workgroupName() == options->workgroupName())
        {
          o->setIP(options->ip());
#if !defined(SMB4K_UNSUPPORTED_PLATFORM)
          o->setUseUser(options->useUser());
          o->setUser(options->user());
          o->setUseGroup(options->useGroup());
          o->setGroup(options->group());
          o->setUseFileMode(options->useFileMode());
          o->setFileMode(options->fileMode());
          o->setUseDirectoryMode(options->useDirectoryMode());
          o->setDirectoryMode(options->directoryMode());
#endif
#if defined(Q_OS_LINUX)
          o->setCifsUnixExtensionsSupport(options->cifsUnixExtensionsSupport());
          o->setUseFileSystemPort(options->useFileSystemPort());
          o->setFileSystemPort(options->fileSystemPort());
          o->setUseSecurityMode(options->useSecurityMode());
          o->setSecurityMode(options->securityMode());
          o->setUseWriteAccess(options->useWriteAccess());
          o->setWriteAccess(options->writeAccess());
#endif
          o->setUseSmbPort(options->useSmbPort());
          o->setSmbPort(options->smbPort());
          o->setUseKerberos(options->useKerberos());
          o->setMACAddress(options->macAddress());
          o->setWOLSendBeforeNetworkScan(options->wolSendBeforeNetworkScan());
          o->setWOLSendBeforeMount(options->wolSendBeforeMount());
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : d->hostObjects) {
                if (url == obj->url()) {
                    object = obj;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : qAsConst(mountedShares)) {
                        if (!share->isForeign()) {
                            mountedBookmarks++;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *entry : m_menus->actions()) {
        displayNames << entry->data().toMap().value("text").toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares)
  {
    mountShare(share, parent);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &interface : qAsConst(interfaces))
  {
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
    if (interface.isValid() && interface.type() != QNetworkInterface::Loopback && interface.flags() & QNetworkInterface::IsRunning)
#else
    if (interface.isValid() && !(interface.flags() & QNetworkInterface::IsLoopBack) && interface.flags() & QNetworkInterface::IsRunning)
#endif
    {
      online = true;
      break;
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KShare *share : list)
  {
    // Check if the share is a printer
    if (share->isPrinter())
    {
      Smb4KNotification::cannotBookmarkPrinter(share);
      continue;
    }
    else
    {
      // Do nothing
    }

    // Process homes shares
    if (share->isHomesShare())
    {
      // If the user provides a valid user name we set it and continue.
      // Otherwise the share will be skipped.
      if (!Smb4KHomesSharesHandler::self()->specifyUser(share, true, parent))
      {
        continue;
      }
      else
      {
        // Do nothing
      }
    }

    Smb4KBookmark *known_bookmark = 0;
    
    if (!share->isHomesShare())
    {
      known_bookmark = findBookmarkByUNC(share->unc());
    }
    else
    {
      known_bookmark = findBookmarkByUNC(share->homeUNC());
    }

    // Skip bookmarks already present
    if (known_bookmark)
    {
      Smb4KNotification::bookmarkExists(known_bookmark);
      continue;
    }
    else
    {
      // Do nothing
    }
    
    Smb4KBookmark *bookmark = new Smb4KBookmark(share);
    bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
    new_bookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KHost *h : p->hostsList)
  {
    if ((workgroup.isEmpty() || QString::compare(h->workgroupName(), workgroup, Qt::CaseInsensitive) == 0) &&
        QString::compare(h->hostName(), name, Qt::CaseInsensitive) == 0)
    {
      host = h;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    m_bookmarks << bookmark;
    
    if (!m_groups.contains(bookmark->groupName()))
    {
      m_groups << bookmark->groupName();
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &mountedShare : Smb4KGlobal::mountedSharesList())
  {
    d->mountedObjects << new Smb4KNetworkObject(mountedShare.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : shares) {
        // Unmount the share
        unmountShare(share, silent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedSharesList())
    {
      // Only mark the shares inaccessible and DO NOT emit
      // the updated() signal here, because that would freeze
      // the application.
      share->setInaccessible(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
    {
      QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
      
      if (!mountedShares.isEmpty())
      {
        for (const SharePtr &share : mountedShares)
        {
          if (!share->isForeign())
          {
            mountedBookmarks++;
            break;
          }
          else
          {
            continue;
          }
        }
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : children)
        {
          if (object == obj)
          {
            m_focusWidget = networkBrowserDock;
            setupDynamicActionList(networkBrowserDock);
            break;
          }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HostPtr &host : hostsList())
  {
    d->hostObjects << new Smb4KNetworkObject(host.data());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->sharesList) {
        if (QString::compare(s->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                             url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                             Qt::CaseInsensitive)
                == 0
            && (workgroup.isEmpty() || QString::compare(s->workgroupName(), workgroup, Qt::CaseInsensitive) == 0)) {
            share = s;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &b : sortedBookmarks) {
                for (QAction *a : actions) {
                    if (a->text() == b) {
                        bookmarkCategoryMenu->addAction(a);
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : qAsConst(mountPoints)) {
        if (mountPoint->mountType() == "cifs" || mountPoint->mountType() == "smb3" || mountPoint->mountType() == "smbfs") {
            // Create a new share and set the mountpoint and filesystem
            SharePtr share = SharePtr(new Smb4KShare());
            share->setUrl(mountPoint->mountedFrom());
            share->setPath(mountPoint->mountPoint());
            share->setMounted(true);

            // Get all mount options
            for (const QString &option : mountPoint->mountOptions()) {
                if (option.startsWith(QLatin1String("domain=")) || option.startsWith(QLatin1String("workgroup="))) {
                    share->setWorkgroupName(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("addr="))) {
                    share->setHostIpAddress(option.section('=', 1, 1).trimmed());
                } else if (option.startsWith(QLatin1String("username=")) || option.startsWith(QLatin1String("user="))) {
                    share->setLogin(option.section('=', 1, 1).trimmed());
                }
            }

            // Work around empty usernames
            if (share->login().isEmpty()) {
                share->setLogin("guest");
            }

            d->importedShares << share;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KWorkgroup *workgroup : workgroupsList())
  {
    d->workgroupObjects << new Smb4KNetworkObject(workgroup);
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KNetworkObject *obj : qAsConst(d->workgroupObjects)) {
                if (url == obj->url()) {
                    object = obj;
                    break;
                } else {
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : d->options)
  {
    if (hasCustomOptions(o) || (!optionsOnly && o->remount() == Smb4KCustomOptions::RemountOnce))
    {
      if (Smb4KSettings::useProfiles() && o->profile() != Smb4KSettings::activeProfile())
      {
        continue;
      }
      else
      {
        // Do nothing
      }
      
      options << o;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QExplicitlySharedDataPointer<KMountPoint> &mountPoint : mountPoints)
    {
#if defined(Q_OS_LINUX)
      if (QString::compare(entry.value("mh_mountpoint").toString(), mountPoint->mountPoint()) == 0 &&
          QString::compare(mountPoint->mountType(), "cifs", Qt::CaseInsensitive) == 0)
#else
      if (QString::compare(entry.value("mh_mountpoint").toString(), mountPoint->mountPoint()) == 0 &&
          QString::compare(mountPoint->mountType(), "smbfs", Qt::CaseInsensitive) == 0)
#endif
      {
        validMountPoints << mountPoint->mountPoint();
        mountPointOk = true;
        break;
      }
      else
      {
        // Do nothing
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList) {
            if (QString::compare(s->url().toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 url.toString(QUrl::RemoveUserInfo | QUrl::RemovePort),
                                 Qt::CaseInsensitive)
                == 0) {
                shares << s;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KBookmark *bookmark : d->bookmarks)
  {
    Smb4KHost *host = findHost(bookmark->hostName(), bookmark->workgroupName());
    
    if (host)
    {
      if (!host->ip().trimmed().isEmpty() &&
          QString::compare(bookmark->hostIP(), host->ip()) != 0)
      {
        bookmark->setHostIP(host->ip());
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : dockActionCollection->actions())
    {
      if (action->objectName() == "bookmark_action")
      {
        if (bookmarkMenu)
        {
          bookmarkMenu->setBookmarkActionEnabled(action->isEnabled());
          connect(action, SIGNAL(changed()), this, SLOT(slotEnableBookmarkAction()));
          continue;
        }
      }
      else if (QString::compare(action->objectName(), "filemanager_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "konsole_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "icon_view_action") == 0)
      {
        continue;
      }
      else if (QString::compare(action->objectName(), "list_view_action") == 0)
      {
        continue;
      }
      
      dynamicList << action;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions()) {
        if (action) {
            action->setEnabled(use);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharePtr searchResult : searchResults())
      {
        if (searchResult->unc() == share->unc())
        {
          searchResult->resetMountData();
          break;
        }
        else
        {
          // Do nothing
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
            //
            // Create a auth info object
            //
            Smb4KAuthInfo *authInfo = new Smb4KAuthInfo();

            //
            // Read the authentication information from the wallet
            //
            QMap<QString, QString> authInfoMap;
            d->wallet->readMap(entry, authInfoMap);

            //
            // Process the entry
            //
            if (entry == "DEFAULT_LOGIN") {
                //
                // Default login
                //
                authInfo->setUserName(authInfoMap.value("Login"));
                authInfo->setPassword(authInfoMap.value("Password"));
            } else {
                //
                // Entry for a specific URL
                //
                authInfo->setUrl(entry);
                authInfo->setIpAddress(authInfoMap.value("IP Address"));
                authInfo->setWorkgroupName(authInfoMap.value("Workgroup"));
                authInfo->setUserName(authInfoMap.value("Login"));
                authInfo->setPassword(authInfoMap.value("Password"));
            }

            entries << authInfo;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->path(), path, Qt::CaseInsensitive) == 0 || QString::compare(s->canonicalPath(), path, Qt::CaseInsensitive) == 0)
      {
        share = s;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &s : p->mountedSharesList)
    {
      if (QString::compare(s->path(), path, Qt::CaseInsensitive) == 0 ||
          QString::compare(s->canonicalPath(), path, Qt::CaseInsensitive) == 0)
      {
        share = s;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks) {
                QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());

                if (!mountedShares.isEmpty()) {
                    for (const SharePtr &share : qAsConst(mountedShares)) {
                        if (!share->isForeign()) {
                            mountedBookmarks++;
                            break;
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : bookmarks)
  {
    QAction *bookmarkAction = 0;
        
    if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), menu());
      bookmarkAction->setObjectName(bookmark->url().toDisplayString());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["category"] = "";
      bookmarkInfo["url"] = bookmark->url();
      bookmarkInfo["text"] = bookmark->label();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->label();
    }
    else
    {
      bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), menu());
      bookmarkAction->setObjectName(bookmark->url().toDisplayString());
      QMap<QString,QVariant> bookmarkInfo;
      bookmarkInfo["type"] = "bookmark";
      bookmarkInfo["category"] = "";
      bookmarkInfo["url"] = bookmark->url();
      bookmarkInfo["text"] = bookmark->displayString();
      bookmarkAction->setData(bookmarkInfo);
      m_bookmarks->addAction(bookmarkAction);
      sortedBookmarks << bookmark->displayString();
    }
        
    QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
    if (!mountedShares.isEmpty())
    {
      for (const SharePtr &share : mountedShares)
      {
        if (!share->isForeign())
        {
          qDebug() << "Disabling bookmark" << share->url().toDisplayString();
          bookmarkAction->setEnabled(false);
          break;
        }
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FilePtr &f : list)
    {
      QListWidgetItem *item = new QListWidgetItem(f->icon(), f->name(), listWidget, f->isDirectory() ? Directory : File);
      item->setData(Qt::UserRole, f->url());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : selectedItems)
    {
      Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);
      
      if (item)
      {
        // Is the share synchronized at the moment?
        if (Smb4KSynchronizer::self()->isRunning(item->shareItem()))
        {
          syncsRunning += 1;
        }
        
        // Is the share inaccessible at the moment?
        if (item->shareItem()->isInaccessible())
        {
          inaccessible += 1;
        }
        
        // Was the share being mounted by another user?
        if (item->shareItem()->isForeign())
        {
          foreign += 1;
        }
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Smb4KWorkgroup *w : p->workgroupsList)
  {
    if (QString::compare(w->workgroupName(), name, Qt::CaseInsensitive) == 0)
    {
      workgroup = w;
      break;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *selectedItem : qAsConst(selectedItems)) {
        Smb4KSharesViewItem *item = static_cast<Smb4KSharesViewItem *>(selectedItem);
        shares << item->shareItem();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &options : qAsConst(d->options)) {
                if (options->hasOptions()) {
                    xmlWriter.writeStartElement("options");
                    xmlWriter.writeAttribute("type", options->type() == Host ? "host" : "share");
                    xmlWriter.writeAttribute("profile", options->profile());

                    xmlWriter.writeTextElement("workgroup", options->workgroupName());
                    xmlWriter.writeTextElement("url", options->url().toDisplayString());
                    xmlWriter.writeTextElement("ip", options->ipAddress());

                    xmlWriter.writeStartElement("custom");

                    QMap<QString, QString> map = options->customOptions();
                    QMapIterator<QString, QString> it(map);

                    while (it.hasNext()) {
                        it.next();

                        if (!it.value().isEmpty()) {
                            xmlWriter.writeTextElement(it.key(), it.value());
                        }
                    }

                    xmlWriter.writeEndElement();
                    xmlWriter.writeEndElement();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BookmarkPtr &bookmark : list)
  {
    BookmarkPtr existingBookmark = findBookmarkByUNC(bookmark->unc());
    
    if (!existingBookmark)
    {
      if (!bookmark->label().isEmpty() && findBookmarkByLabel(bookmark->label()))
      {
        Smb4KNotification::bookmarkLabelInUse(bookmark.data());
        bookmark->setLabel(QString("%1 (1)").arg(bookmark->label()));
      }
      else
      {
        // Do nothing
      }
      
      d->bookmarks << bookmark;
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : list)
  {
    //
    // Printer shares cannot be bookmarked
    //
    if (share->isPrinter())
    {
      Smb4KNotification::cannotBookmarkPrinter(share);
      continue;
    }
    else
    {
      // Do nothing
    }
    
    //
    // Process homes shares
    //
    if (share->isHomesShare())
    {
      if (!Smb4KHomesSharesHandler::self()->specifyUser(share, true))
      {
        continue;
      }
      else
      {
        // Do nothing
      }
    }
    else
    {
      // Do nothing
    }
    
    //
    // Check if the share has already been bookmarked and skip it if it
    // already exists
    //
    BookmarkPtr knownBookmark = findBookmarkByUrl(share->isHomesShare() ? share->homeUrl() : share->url());
    
    if (knownBookmark)
    {
      Smb4KNotification::bookmarkExists(knownBookmark.data());
      continue;
    }
    else
    {
      // Do nothing
    }
    
    BookmarkPtr bookmark = BookmarkPtr(new Smb4KBookmark(share.data()));
    bookmark->setProfile(Smb4KProfileManager::self()->activeProfile());
    newBookmarks << bookmark;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface &interface : qAsConst(interfaces)) {
        if (interface.isValid() && interface.type() != QNetworkInterface::Loopback && interface.flags() & QNetworkInterface::IsRunning && !online) {
            online = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WorkgroupPtr &newWorkgroup : job->workgroups()) {
        bool foundWorkgroup = false;

        for (const WorkgroupPtr &workgroup : d->tempWorkgroupList) {
            if (workgroup->workgroupName() == newWorkgroup->workgroupName()) {
                foundWorkgroup = true;
                break;
            }
        }

        if (!foundWorkgroup) {
            d->tempWorkgroupList << newWorkgroup;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups)
  {
    if (!group.isEmpty())
    {
      // Group menu entry
      KActionMenu *bookmarkGroupMenu = new KActionMenu(group, menu());
      bookmarkGroupMenu->setIcon(KDE::icon("folder-favorites"));
      QMap<QString,QVariant> menuInfo;
      menuInfo["type"] = "group_menu";
      menuInfo["group"] = group;
      bookmarkGroupMenu->setData(menuInfo);
      addAction(bookmarkGroupMenu);
      
      // Mount action for the group
      QAction *bookmarkGroupMount = new QAction(KDE::icon("media-mount"), i18n("Mount All Bookmarks"), bookmarkGroupMenu->menu());
      QMap<QString,QVariant> groupMountInfo;
      groupMountInfo["type"] = "group_mount";
      groupMountInfo["group"] = group;
      bookmarkGroupMount->setData(groupMountInfo);
      bookmarkGroupMenu->addAction(bookmarkGroupMount);
      m_actions->addAction(bookmarkGroupMount);
      
      // Get the list of bookmarks belonging to this group.
      // Use it to decide whether the group mount action should be enabled 
      // (only if not all bookmarks belonging to this group are mounted) and
      // to sort the bookmarks.      
      QList<BookmarkPtr> bookmarks = Smb4KBookmarkHandler::self()->bookmarksList(group);
      QStringList sortedBookmarks;
      int mountedBookmarks = 0;
      
      for (const BookmarkPtr &bookmark : bookmarks)
      {
        QAction *bookmarkAction = 0;
        
        if (Smb4KSettings::showCustomBookmarkLabel() && !bookmark->label().isEmpty())
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->label(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->label();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->label();
        }
        else
        {
          bookmarkAction = new QAction(bookmark->icon(), bookmark->displayString(), bookmarkGroupMenu->menu());
          bookmarkAction->setObjectName(bookmark->url().toDisplayString());
          QMap<QString,QVariant> bookmarkInfo;
          bookmarkInfo["type"] = "bookmark";
          bookmarkInfo["group"] = group;
          bookmarkInfo["url"] = bookmark->url();
          bookmarkInfo["text"] = bookmark->displayString();
          bookmarkAction->setData(bookmarkInfo);
          m_bookmarks->addAction(bookmarkAction);
          sortedBookmarks << bookmark->displayString();
        }
        
        QList<SharePtr> mountedShares = findShareByUrl(bookmark->url());
        
        if (!mountedShares.isEmpty())
        {
          for (const SharePtr &share : mountedShares)
          {
            if (!share->isForeign())
            {
              bookmarkAction->setEnabled(false);
              mountedBookmarks++;
              break;
            }
            else
            {
              continue;
            }
          }
        }
        else
        {
          // Do nothing
        }
      }
      
      bookmarkGroupMount->setEnabled(mountedBookmarks != bookmarks.size());
      sortedBookmarks.sort();
      
      // Add a separator
      bookmarkGroupMenu->addSeparator();
      
      // Insert the sorted bookmarks into the group menu
      QList<QAction *> actions = m_bookmarks->actions();
      
      for (const QString &b : sortedBookmarks)
      {
        for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
      }
    }
    else
    {
      // Do nothing
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionsPtr &o : m_optionsList) {
        if (url == o->url().toString()) {
            m_currentOptions = o;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharePtr &share : unmountedShares)
      {
        // Copy the share
        SharePtr unmountedShare = share;
          
        // Remove the share from the global list and notify the program
        removeMountedShare(share);
        emit unmounted(unmountedShare);
        unmountedShare.clear();
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions)
        {
          if (a->text() == b)
          {
            bookmarkGroupMenu->addAction(a);
            break;
          }
          else
          {
            continue;
          }
        }
```

