#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &url){
      emit urlClicked( url.toString() );
  }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &url){
      Q_EMIT urlClicked( url.toString() );
  }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dictType : dictTypes )
  {
    DictFile *tempDictFile = makeDictFile( dictType );
    DictionaryPreferenceDialog *newDialog = tempDictFile->preferencesWidget( config, parent );

    if( newDialog == nullptr ) continue;
    result.insert( dictType, newDialog );
    delete tempDictFile;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dictType : dictTypes )
  {
    DictFile *tempDictFile = makeDictFile( dictType );
    QMap<QString,QString> tempList = tempDictFile->getSearchableAttributes();
    QMap<QString,QString>::const_iterator it = tempList.constBegin();
    while( it != tempList.constEnd() )
    {
      if( ! result.contains( it.key() ) )
      {
        result.insert( it.key(), it.value() );
      }
      ++it;
    }
    delete tempDictFile;
  }
```

