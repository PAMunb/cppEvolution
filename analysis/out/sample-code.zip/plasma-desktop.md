#### AUTO 


```{c}
auto position = shownActivities.insert(activityInfoPtr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &state : states) {
                    for (const QString &key : keys) {
                        cg.revertToDefault(state + key);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &colorSetGroup : colorSetGroupList)
    {
        KConfigGroup groupOut(m_config, colorSetGroup);
        KConfigGroup groupTheme(config, colorSetGroup);

        for (const QString &coloritem : colorItemList)
        {
            groupOut.writeEntry(coloritem, groupTheme.readEntry(coloritem));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const IconsModelData &a, const IconsModelData &b) {
        return a.display < b.display;
    }
```

#### AUTO 


```{c}
const auto command = grp.readEntry("Exec");
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &idx) {
        return idx.data(DeviceModel::TypeRole) == DeviceModel::Detached;
    }
```

#### AUTO 


```{c}
auto result = d->features->GetValue(
        QStringLiteral("org.kde.ActivityManager.Resources.Scoring/isOTR/") + activity);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sn : qAsConst(devicesSysNames)) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                   QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                   QStringLiteral("org.kde.KWin.InputDevice"),
                                   QDBusConnection::sessionBus(),
                                   this);
        QVariant reply = deviceIface.property("pointer");
        if (reply.isValid() && reply.toBool()) {
            reply = deviceIface.property("touchpad");
            if (reply.isValid() && reply.toBool()) {
                continue;
            }

            KWinWaylandDevice *dev = new KWinWaylandDevice(sn);
            if (!dev->init()) {
                qCCritical(KCM_MOUSE) << "Error on creating device object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos of %1.", sn);
                return;
            }
            m_devices.append(dev);
            qCDebug(KCM_MOUSE).nospace() << "Device found: " << dev->name() << " (" << dev->sysName() << ")";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &component: components) {
        const QString componentId = component.id();

        QVariantMap appstreamAction = Kicker::createActionItem(i18nc("@action opens a software center with the application", "Manage '%1'...", component.name()), "manageApplication", QVariant(QStringLiteral("appstream://") + componentId));
        appstreamAction[QStringLiteral("icon")] = QStringLiteral("applications-other");
        ret << appstreamAction;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&homePath](const QString &url, bool include, bool fromConfig) {
        QString displayName = url;
        if (displayName.size() > 1) {
            displayName.chop(1);
        }
        if (displayName.startsWith(homePath)) {
            displayName.replace(0, homePath.length(), QStringLiteral("~/"));
        }

        QString icon = QStringLiteral("folder");
        if (url == homePath) {
            icon = QStringLiteral("user-home");
        } else if (!fromConfig) {
            icon = QStringLiteral("drive-harddisk");
        }

        return FolderInfo{url, displayName, icon, include, fromConfig};
    }
```

#### AUTO 


```{c}
auto extraLayouts = keyboardConfig.layouts.mid(keyboardConfig.layoutLoopCount - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addedApp : addedList) {
        // without .desktop extension
        auto service = KService::serviceByStorageId(addedApp.mid(0, addedApp.length() -8));
        if (!service) {
            service = KService::serviceByStorageId(addedApp);
        }
        if (!service) {
            continue;
        }
        // avoid duplicates entry when email clients are present in mimeapps.list's Added Associations too
        const bool isServiceAlreadyInserted = std::none_of(emailClients.constBegin(), emailClients.constEnd(), [service] (const KService::Ptr &serv) { return service->storageId() == serv->storageId(); });
        if (isServiceAlreadyInserted) {
            const auto icon = QIcon::fromTheme(!service->icon().isEmpty() ? service->icon() : QStringLiteral("application-x-shellscript"));
            emailClientsCombo->addItem(icon, service->name() + " (" + KShell::tildeCollapse(service->entryPath()) + ")", service->storageId());

            if (emailClientService && emailClientService->storageId() == service->storageId()) {
                emailClientsCombo->setCurrentIndex(emailClientsCombo->count() - 1);
                m_currentIndex = emailClientsCombo->count() - 1;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceFile : autostartServices) {
                    KService service(serviceFile + QStringLiteral(".desktop"));
                    KAutostart as(serviceFile);
                    as.setCommand(service.exec());
                    as.setAutostarts(true);
                    KRun::runApplication(service, {}, nullptr);
                }
```

#### AUTO 


```{c}
auto job = KIO::mostLocalUrl(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& lang : languages) {
            if (!m_installedLanguages.contains(lang)) {
                missingLanguages << lang;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const NotificationManager::BehaviorSettings *settings) {
        return settings->isSaveNeeded();
    }
```

#### AUTO 


```{c}
auto dpiWaylandItem = fontsAASettings()->findItem("forceFontDPIWayland");
```

#### AUTO 


```{c}
const auto asEnumChoices = asEnum->choices();
```

#### AUTO 


```{c}
const auto &id
```

#### AUTO 


```{c}
const auto pendingDeletions = m_model->match(m_model->index(0, 0), ThemesModel::PendingDeletionRole, true);
```

#### DECLTYPE 


```{c}
decltype(m_screenItemMap) newMap;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            if (notifyRcFiles.contains(file)) {
                continue;
            }

            notifyRcFiles.append(file);

            KConfig config(file, KConfig::NoGlobals);
            config.addConfigSources(QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("knotifications5/") + file));

            KConfigGroup globalGroup(&config, QLatin1String("Global"));

            const QRegularExpression regExp(QStringLiteral("^Event/([^/]*)$"));
            const QStringList groups = config.groupList().filter(regExp);

            const QString notifyRcName = file.section(QLatin1Char('.'), 0, -2);
            const QString desktopEntry = globalGroup.readEntry(QStringLiteral("DesktopEntry"));
            if (!desktopEntry.isEmpty()) {
                if (desktopEntries.contains(desktopEntry)) {
                    continue;
                }

                desktopEntries.append(desktopEntry);
            }

            SourceData source{
                // The old KCM read the Name and Comment from global settings disregarding
                // any user settings and just used user-specific files for actions config
                // I'm pretty sure there's a readEntry equivalent that does that without
                // reading the config stuff twice, assuming we care about this to begin with
                globalGroup.readEntry(QStringLiteral("Name")),
                globalGroup.readEntry(QStringLiteral("Comment")),
                globalGroup.readEntry(QStringLiteral("IconName")),
                true,
                notifyRcName,
                desktopEntry,
                {} // events
            };

            QVector<EventData> events;
            for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{cg.readEntry("Name"),
                                cg.readEntry("Comment"),
                                cg.readEntry("IconName"),
                                eventId,
                                // TODO Flags?
                                cg.readEntry("Action").split(QLatin1Char('|'))};
                events.append(event);
            }

            std::sort(events.begin(), events.end(), [&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            });

            source.events = events;

            if (!source.desktopEntry.isEmpty()) {
                appsData.append(source);
            } else {
                servicesData.append(source);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *info : qAsConst(variantInfos)) {
        if (info->languages.contains(lang))
            return true;
    }
```

#### AUTO 


```{c}
auto keycodes = xcb_get_modifier_mapping_keycodes(reply);
```

#### AUTO 


```{c}
const auto path = ScreenMapper::stringToUrl(QStringLiteral("desktop:/"));
```

#### AUTO 


```{c}
const auto matching = terminalCombo->model()->match(terminalCombo->model()->index(0,0), Qt::DisplayRole, service->exec());
```

#### AUTO 


```{c}
const auto seconds = diff % 60;
```

#### AUTO 


```{c}
const auto& key
```

#### RANGE FOR STATEMENT 


```{c}
for (QString mountPoint : m_mountPoints) {
            if (url.startsWith(mountPoint)) {
                name = QLatin1Char('[') + QDir(mountPoint).dirName() + QLatin1String("]/") + url.mid(mountPoint.length());
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, serviceAction]() {
            auto *job = new KIO::ApplicationLauncherJob(serviceAction);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);
            job->start();
        }
```

#### AUTO 


```{c}
auto action = new QAction(this);
```

#### AUTO 


```{c}
auto it = m_isDirCache.constFind(item.url());
```

#### AUTO 


```{c}
const auto results = sourceModel()->match(sourceModel()->index(0, 0), ColorsModel::SchemeNameRole, m_selectedScheme);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(plugins)) {
        const int row = indexOfPlugin(name);
        if (row != -1) {
            m_checkedRows[row] = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &serviceAction : jumpListActions) {
        if (serviceAction.noDisplay()) {
            continue;
        }

        QAction *action = new QAction(parent);
        action->setText(serviceAction.text());
        action->setIcon(QIcon::fromTheme(serviceAction.icon()));
        if (serviceAction.isSeparator()) {
            action->setSeparator(true);
        }

        connect(action, &QAction::triggered, this, [this, serviceAction]() {
            auto *job = new KIO::ApplicationLauncherJob(serviceAction);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);
            job->start();
        });

        actions << QVariant::fromValue<QAction *>(action);
    }
```

#### AUTO 


```{c}
const auto shortcuts = KGlobalAccel::self()->shortcut(toggleAction);
```

#### AUTO 


```{c}
auto job =
            KIO::filePreview(list, QSize(width, height));
```

#### AUTO 


```{c}
const auto entry = m_entries.at(row);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto device : qAsConst(m_devices)) {
        device->load();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceFile : autostartServices) {
                        KService service(serviceFile + QStringLiteral(".desktop"));
                        KAutostart as(serviceFile);
                        as.setAutostarts(false);
                        //FIXME: quite ugly way to stop things, and what about non KDE things?
                        QProcess::startDetached(QStringLiteral("kquitapp5"), {QStringLiteral("--service"), service.property(QStringLiteral("X-DBUS-ServiceName")).toString()});
                    }
```

#### AUTO 


```{c}
const auto name = query.value(0).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.values) {
        scoring.call("DeleteEarlierStats", activity, months);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog](int result) {
        if (result == QDialog::Accepted && dialog->service()) {
            const KService::Ptr service = dialog->service();
            const QString desktopFileName = service->desktopEntryName() + ".desktop";
            if (m_globalAccelModel->match(m_shortcutsModel->index(0, 0), BaseModel::ComponentRole, desktopFileName).isEmpty()) {
                m_globalAccelModel->addApplication(desktopFileName, service->name());
            } else {
                qCDebug(KCMKEYS) << "Already have component" << service->storageId();
            }
        }
        dialog->deleteLater();
    }
```

#### AUTO 


```{c}
const auto whatToRemember = static_cast<WhatToRemember>(statisticsConfig.readEntry(
        "what-to-remember", static_cast<int>(AllApplications)));
```

#### AUTO 


```{c}
auto file = new QTemporaryFile(qApp);
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent::any()
                    | Type::any()
                    | Activity::current()
                    | Url::file();
```

#### AUTO 


```{c}
auto result = handler.call({ future.result() });
```

#### AUTO 


```{c}
auto closestScreen = screenForPoint(x, y);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &finger : enrolledFingerprintsRaw()) {
        for (Finger *storedFinger : FINGERS) {
            if (storedFinger->internalName() == finger) {
                fingers.append(QVariant::fromValue(storedFinger));
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto iface = m_device->m_iface.get();
```

#### AUTO 


```{c}
auto *delegate = new KNotificationJobUiDelegate;
```

#### AUTO 


```{c}
auto invocation = m_dbusIface->SetPassword(saltPassword(password), QString());
```

#### AUTO 


```{c}
const auto shortcuts = KGlobalAccel::self()->shortcut(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        (void) new KRun(url, nullptr);
    }
```

#### AUTO 


```{c}
const auto resource =
            _resource.startsWith(QLatin1Char('/')) ? QUrl::fromLocalFile(_resource).toString() : _resource;
```

#### AUTO 


```{c}
auto walResult = ptr->pragma("journal_mode = WAL");
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : qAsConst(layouts)) {
        defaultLayoutList.append(layoutUnit);
        if (layoutLoopCount != KeyboardConfig::NO_LOOPING && i >= layoutLoopCount - 1)
            break;
        i++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (q->rowCount()) {
                emit q->dataChanged(q->index(0, 0), q->index(q->rowCount() - 1, 0), QVector<int>{Qt::DisplayRole});
            }
        }
```

#### AUTO 


```{c}
auto verifyMapping = [](const QHash<int, int> &actual, const QHash<int, int> &expected) {

        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().values();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto model: models) {
                    model->onBackgroundsUpdated(changedBackgrounds);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[item]() {
        if (item && item->window() &&  item->window()->mouseGrabberItem()) {
            item->window()->mouseGrabberItem()->ungrabMouse();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", "preview.png"), ScreenhotRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            row->setData(hasColors, HasColorsRole);
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);
        }

        m_model->appendRow(row);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob *copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone, this, [map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone, this, [map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const FolderInfo& a, const FolderInfo& b) {
            return a.url < b.url;
    }
```

#### AUTO 


```{c}
auto shown = Private::activityPosition(shownActivities, id)
```

#### RANGE FOR STATEMENT 


```{c}
for (const ModelInfo *modelInfo : qAsConst(rules->modelInfos)) {
    	QString vendor = modelInfo->vendor;
    	if( vendor.isEmpty() ) {
    		vendor = i18nc("unknown keyboard model vendor", "Unknown");
    	}
		uiWidget->keyboardModelComboBox->addItem(i18nc("vendor | keyboard model", "%1 | %2", vendor, modelInfo->description), modelInfo->name);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("preview.png")), ScreenhotRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            row->setData(hasColors, HasColorsRole);
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        if (child->isWidgetType()) {
            setStyleRecursively(static_cast<QWidget *>(child), style);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode)
        Q_UNUSED(exitStatus)

        m_testProcess->deleteLater();
        m_testProcess = nullptr;
        Q_EMIT testingChanged();
    }
```

#### AUTO 


```{c}
const auto matches = match(index(0, 0), SourcesModel::DesktopEntryRole, desktopEntry, 1, Qt::MatchFixedString);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto idx : changed) {
        emit dataChanged(idx, idx);
    }
```

#### AUTO 


```{c}
const auto actions = sourceDF.readActions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : activities) {
            KActivities::Info info(key);
            QIcon icon;
            const QString iconStr = info.icon();
            if (iconStr.isEmpty()) {
                icon = m_clearHistoryButton->icon();
            } else if (QFileInfo::exists(iconStr)) {
                icon = QIcon(iconStr);
            } else {
                icon = QIcon::fromTheme(iconStr);
            }
            QAction *singleActivity = installMenu->addAction(icon, i18nc("delete history for this activity", "For activity \"%1\"", info.name()));
            singleActivity->setEnabled(historyKeys.contains(key)); // Otherwise there would be nothing to delete
            connect(singleActivity, &QAction::triggered, this, [this, key]() {
                deleteHistoryGroup(key);
            });
            installMenu->addAction(singleActivity);
            m_clearHistoryButton->setText(i18n("Clear History..."));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor]() {
        Q_EMIT const_cast<KKeySequenceWidgetDelegate *>(this)->commitData(editor);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](AbstractEntry *entry) {
            if (entry->type() == AbstractEntry::RunnableType) {
                AppEntry *appEntry = static_cast<AppEntry*>(entry);
                appsHash.insert(appEntry->service()->menuId(), appEntry);
            } else if (entry->type() == AbstractEntry::GroupType) {
                GroupEntry *groupEntry = static_cast<GroupEntry*>(entry);
                AbstractModel *model = groupEntry->childModel();

                if (!model) {
                    return;
                }

                for (int i = 0; i < model->count(); ++i) {
                    processEntry(static_cast<AbstractEntry*>(model->index(i, 0).internalPointer()));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &directory : directories) {
		const QDir dir(directory);
		for(const QString &f: dir.entryList(QStringList("*.desktop"))) {
			services += dir.absoluteFilePath(f);
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](QKeyEvent *event) {
        Q_ASSERT(event);
        if (event->nativeScanCode() == nativeScanCode) {
            pressed = event->type() == QKeyEvent::KeyPress;
            emit pressedChanged();
        }
    }
```

#### AUTO 


```{c}
auto mappableUrl = [this, dropTargetFolderUrl](const QUrl &url) -> QUrl {
        if (dropTargetFolderUrl != m_dirModel->dirLister()->url()) {
            QString mappedUrl = url.toString();
            const auto local = dropTargetFolderUrl.toString();
            const auto internal = m_dirModel->dirLister()->url().toString();
            if (mappedUrl.startsWith(local)) {
                mappedUrl.replace(0, local.size(), internal);
            }
            return ScreenMapper::stringToUrl(mappedUrl);
        }
        return url;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, process, idx, pluginName, displayName](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus)
                if (exitCode == 0) {
                    m_model->removeRow(idx.row());
                } else {
                    emit showErrorMessage(i18n("Removing theme failed: %1",
                                               QString::fromLocal8Bit(process->readAllStandardOutput().trimmed())));
                    m_model->setData(idx, false, ThemesModel::PendingDeletionRole);
                }
                process->deleteLater();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qCWarning(KCM_KDED) << "Failed to get loaded modules" << reply.error().name() << reply.error().message();
            return;
        }

        QStringList runningModules = reply.value();
        m_model->setRunningModules(runningModules);
        m_model->setRunningModulesKnown(true);

        // Check if the user just tried starting a module that then disabled itself again.
        // Some kded modules disable themselves on start when they deem themselves unnecessary
        // based on some configuration independ of kded or the current environment.
        // At least provide some feedback and not leave the user wondering why the service doesn't start.
        if (!m_lastStartedModule.isEmpty() && !runningModules.contains(m_lastStartedModule)) {
            emit showSelfDisablingModulesHint();
        }
        m_lastStartedModule.clear();

        // Check if any modules got started/stopped as a result of reloading kded
        if (!m_runningModulesBeforeReconfigure.isEmpty()) {
            std::sort(m_runningModulesBeforeReconfigure.begin(), m_runningModulesBeforeReconfigure.end());
            std::sort(runningModules.begin(), runningModules.end());

            if (m_runningModulesBeforeReconfigure != runningModules) {
                emit showRunningModulesChangedAfterSaveHint();
            }
        }
        m_runningModulesBeforeReconfigure.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        Q_EMIT this->widgetChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setStatus(Status::Ready);
        Q_EMIT listingCompleted();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QList<KGlobalShortcutInfo>> shortcutsReply = *watcher;
                if (shortcutsReply.isValid()) {
                    const auto allShortcuts = shortcutsReply.value();
                    bool isNotDefault = std::any_of(allShortcuts.cbegin(), allShortcuts.cend(), [](const KGlobalShortcutInfo &info) {
                        return info.defaultKeys() != info.keys();
                    });
                    m_isDefault &= isNotDefault;
                }
                if (--m_pendingComponentCalls == 0) {
                    Q_EMIT loaded();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const T &current) {
                    return comparator(value, current);
                }
```

#### AUTO 


```{c}
auto action_it = m_components[i].actions.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, index] {
        updateModelIsDefaultStatus(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                    QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                    QStringLiteral("org.kde.KWin.InputDevice"),
                                    QDBusConnection::sessionBus(),
                                    this);
        const QVariant reply = deviceIface.property("touchpad");
        if (reply.isValid() && reply.toBool()) {
            KWinWaylandTouchpad* tp = new KWinWaylandTouchpad(sn);
            if (!tp->init()) {
                qCCritical(KCM_TOUCHPAD) << "Error on creating touchpad object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos for touchpad %1.", sn);
                return;
            }
            m_devices.append(tp);
            touchpadFound = true;
            qCDebug(KCM_TOUCHPAD).nospace() <<  "Touchpad found: " <<  tp->name() << " (" << tp->sysName() << ")";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : newList) {
		if( ! allLayouts.contains(layoutUnit) )
			return false;
	}
```

#### AUTO 


```{c}
const auto results = match(index(0, 0), PluginNameRole, pluginName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        urls.append(itemForIndex(index).url());
    }
```

#### AUTO 


```{c}
auto stdStrPlain = plain.toStdString();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                endMoveRows();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ModelInfo *modelInfo : qAsConst(rules->modelInfos)) {
        modelInfo->vendor = translate_xml_item(modelInfo->vendor);
        modelInfo->description = translate_description(modelInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        if (folderUrl != url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto it = m_screenItemMap.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Action &a) {
                return a.id == key;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](QStringList &list)
    {
        while (!list.isEmpty() && list.constLast().isEmpty()) {
            list.removeLast();
        }
    }
```

#### AUTO 


```{c}
const auto includedComponents = m_shortcutsModel->match(m_shortcutsModel->index(0, 0), ShortcutsModel::CheckedRole, true, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder : runtimeExcluded) {
        if (settingsIncluded.contains(folder) ||
            settingsExcluded.contains(folder)) {
            // Do not add any duplicates
            continue;
        }
        if (m_deletedSettings.contains(folder)) {
            // Skip entries deleted from the config
            continue;
        }
        m_folderList.append(folderListEntry(folder, false, false));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ComponentData *cd : qAsConst(d->components)) {
                // The editors are responsible for the reset
                cd->editor()->allDefault();
            }
```

#### AUTO 


```{c}
auto button
```

#### AUTO 


```{c}
auto componentIndex = index(component - m_components.begin(), 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : qAsConst(m_components)) {
        if (component.checked) {
            for (const auto &action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
        }
    }
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), ColorsModel::SchemeNameRole, newName);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Action &a1, const Action &a2) {
            return collator.compare(a1.displayName, a2.displayName) < 0;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(m_supported)) {
        const Parameter *par = findParameter(name);
        if (!par) {
            continue;
        }

        QVariant value(getParameter(par));
        if (!value.isValid()) {
            error = true;
            continue;
        }

        double k = getPropertyScale(name);
        if (k != 1.0) {
            bool ok = false;
            value = QVariant(value.toDouble(&ok) / k);
            if (!ok) {
                error = true;
                continue;
            }
        }

        if (m_negate.contains(name)) {
            bool negative = value.toDouble() < 0.0;
            p[m_negate[name]] = QVariant(negative);
            if (negative) {
                value = negateVariant(value);
            }
        }

        if (name == "CoastingSpeed") {
            bool coasting = value.toDouble() != 0.0;
            p["Coasting"] = QVariant(coasting);
            if (!coasting) {
                continue;
            }
        }

        p[name] = value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : services) {
        if (service->noDisplay()) {
            continue;
        }

        if (desktopEntries.contains(service->desktopEntryName())) {
            continue;
        }

        SourceData source{
            service->name(),
            service->comment(),
            service->icon(),
            true,
            QString(), //notifyRcFile
            service->desktopEntryName(),
            {} // events
        };
        appsData.append(source);
        desktopEntries.append(service->desktopEntryName());
    }
```

#### AUTO 


```{c}
auto action = std::find_if(component->actions.begin(), component->actions.end(), [&] (const Action &a) {
                return a.id == key;
            });
```

#### LAMBDA EXPRESSION 


```{c}
[this, styleName] {
        if (!m_styleConfigDialog->isDirty()) {
            return;
        }

        // Force re-rendering of the preview, to apply settings
        emit styleReconfigured(styleName);

        //For now, ask all KDE apps to recreate their styles to apply the setitngs
        KGlobalSettings::self()->emitChange(KGlobalSettings::StyleChanged);

        // When user edited a style, assume they want to use it, too
        styleSettings()->setWidgetStyle(styleName);

        // We call setNeedsSave(true) here to make sure we force style re-creation
        setNeedsSave(true);
    }
```

#### AUTO 


```{c}
auto result = d->features->GetValue(
        "org.kde.ActivityManager.Resources.Scoring/isOTR/" + activityId);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog] (int result) {
        if (result == QDialog::Accepted && dialog->service()) {
            const KService::Ptr service = dialog->service();
            const QString desktopFileName = service->desktopEntryName() + ".desktop";
            if (m_shortcutsModel->match(m_shortcutsModel->index(0, 0), ShortcutsModel::ComponentRole, desktopFileName).isEmpty()) {
                m_shortcutsModel->addApplication(desktopFileName, service->name());
            } else {
                qCDebug(KCMKEYS) << "Already have component" << service->storageId();
            }
        }
        dialog->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities) {
        if (!m_activitiesWindows[activity].contains(window)) {
            m_activitiesWindows[activity] << window;

            rowChanged(rowForActivityId(activity),
                m_activitiesWindows.size() == 1
                    ? QVector<int>{WindowCount, HasWindows}
                    : QVector<int>{WindowCount});
        }
    }
```

#### AUTO 


```{c}
auto *w = enter;
```

#### LAMBDA EXPRESSION 


```{c}
[this, file](const KFileItem &item, const QPixmap &pixmap) {
            Q_UNUSED(item);

            auto image = pixmap.toImage();

            m_texture = QQuickTextureFactory::textureFactoryForImage(image);
            emit finished();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[sysName](QObject *t) {
            return static_cast<KWinWaylandTouchpad *>(t)->sysName() == sysName;
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_data.begin(), m_data.end(), [this](const IconsModelData &item) {
        return item.themeName == m_selectedTheme;
    });
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
                qCDebug(KICKER_DEBUG) << "%%% Inhibit stopped";
                m_isTriggerInhibited = false;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : qAsConst(m_iconGroups)) {
        const QString groupName = group + QLatin1String("Icons");
        KConfigGroup cg(kglobalcfg, groupName);
        KConfigGroup kde4Cg(&kde4config, groupName);

        // HACK copyTo only copies keys, it doesn't replace the entire group
        // which means if we removed the effects in our config it won't remove
        // them from the kde4 config, hence revert all of them prior to copying
        const QStringList keys =  cg.keyList() + kde4Cg.keyList();
        for (const QString &key : keys) {
            kde4Cg.revertToDefault(key);
        }
        // now copy over the new values
        cg.copyTo(&kde4Cg);
    }
```

#### AUTO 


```{c}
const auto cfg = KSharedConfig::openConfig(QStringLiteral("kactivitymanagerd-statsrc"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &choice : asEnumChoices) {
            choiceList.append(!choice.label.isEmpty() ? choice.label : choice.name);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, model]() {
        disconnectSignals();
        m_sourceModel = model;
        connectSignals();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupEmptyTrashBin();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : qAsConst(m_data)) {
        if (item.pendingDeletion) {
            pendingDeletions.append(item.pluginName);
        }
    }
```

#### AUTO 


```{c}
const auto selectedIndex = deviceView->selectionModel()->selectedIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : std::as_const(rules->layoutInfos)) {
            QDomElement layout = doc.createElement(QStringLiteral("layout"));
            layout.setAttribute(QStringLiteral("name"), layoutInfo->name);
            layout.setAttribute(QStringLiteral("description"), layoutInfo->description);

            QDomElement langList = doc.createElement(QStringLiteral("languageList"));
            for (const QString &lang : layoutInfo->languages) {
                QDomElement langNode = doc.createElement(QStringLiteral("lang"));
                langNode.setAttribute(QStringLiteral("iso639Id"), lang);
                langList.appendChild(langNode);
            }
            if (langList.hasChildNodes()) {
                layout.appendChild(langList);
            }

            QDomElement variantList = doc.createElement(QStringLiteral("variantList"));
            for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
                QDomElement variant = doc.createElement(QStringLiteral("variant"));
                variant.setAttribute(QStringLiteral("name"), variantInfo->name);
                variant.setAttribute(QStringLiteral("description"), variantInfo->description);

                QDomElement langList = doc.createElement(QStringLiteral("languageList"));
                for (const QString &lang : variantInfo->languages) {
                    QDomElement langNode = doc.createElement(QStringLiteral("lang"));
                    langNode.setAttribute(QStringLiteral("iso639Id"), lang);
                    langList.appendChild(langNode);
                }
                if (langList.hasChildNodes()) {
                    variant.appendChild(langList);
                }

                variantList.appendChild(variant);
            }
            if (variantList.hasChildNodes()) {
                layout.appendChild(variantList);
            }

            layoutList.appendChild(layout);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode);
        Q_UNUSED(exitStatus);

        const auto savedThemes = QString::fromUtf8(m_editDialogProcess->readAllStandardOutput()).split(QLatin1Char('\n'), QString::SkipEmptyParts);

        if (!savedThemes.isEmpty()) {
            loadModel(); // would be cool to just reload/add the changed/new ones

            setSelectedScheme(savedThemes.last());
        }

        m_editDialogProcess->deleteLater();
        m_editDialogProcess = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& dev : devices) {
        const Solid::StorageAccess* sa = dev.as<Solid::StorageAccess>();
        if (!sa->isAccessible())
            continue;

        const QString mountPath = sa->filePath();
        if (!shouldShowMountPoint(mountPath))
            continue;

        m_mountPoints.append(mountPath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& deleted : entry.uninstalledFiles()) {
                        QVector<QStringRef> list = deleted.splitRef(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        QModelIndex idx = m_model->findIndex(list.last().toString());
                        if (idx.isValid()) {
                            m_model->removeTheme(idx);
                        }
                    }
```

#### AUTO 


```{c}
auto cfg = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
auto result = new ActivitySettings();
```

#### AUTO 


```{c}
const auto titleRight = sourceModel()->data(sourceRight, KActivities::ActivitiesModel::ActivityName);
```

#### AUTO 


```{c}
auto it = std::find_if(m_data.begin(), m_data.end(), [&style](const StylesModelData &item) {
        return item.styleName == style;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_resultModel->rowCount() >= 6) {
            setSourceModel(m_resultModel);
        } else {
            setSourceModel(m_defaultModel);
        }
    }
```

#### AUTO 


```{c}
auto actionName = m_lastInvokedAction->objectName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &idx : selected) {
		if( idx.column() == 0 ) {
			keyboardConfig->layouts.removeAt(rowsRange.first);
		}
	}
```

#### AUTO 


```{c}
auto reply = m_fprintInterface->DeleteEnrolledFinger(finger);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& result: results) {
            DEBUG << "Got " << result.resource() << " -->";
            addResult(result.resource(), -1, false);
        }
```

#### AUTO 


```{c}
auto allocPtr = library.resolve("allocate_kstyle_config");
```

#### AUTO 


```{c}
auto *installMenu = new QMenu(m_clearHistoryButton);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : variantInfo->languages) {
                    QDomElement langNode = doc.createElement(QStringLiteral("lang"));
                    langNode.setAttribute(QStringLiteral("iso639Id"), lang);
                    langList.appendChild(langNode);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> &actual, const QHash<int, int> &expected) {

        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().values();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() {
        if (!dialog->changedEntries().isEmpty()) {
            load();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QKeySequence &key : qAsConst(action.activeShortcuts)) {
                    keys.append(key);
                }
```

#### AUTO 


```{c}
const auto activityRight = sourceModel()->data(sourceRight, KActivitiesBackport::ActivitiesModel::ActivityId);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode);
        Q_UNUSED(exitStatus);

        const auto savedThemes = QString::fromUtf8(m_editDialogProcess->readAllStandardOutput()).split(QLatin1Char('\n'), QString::SkipEmptyParts);

        if (!savedThemes.isEmpty()) {
            m_model->load(); // would be cool to just reload/add the changed/new ones

            // If the currently active scheme was edited, consider settings dirty even if the scheme itself didn't change
            if (savedThemes.contains(m_settings->colorScheme())) {
                m_activeSchemeEdited = true;
                settingsChanged();
            }

            m_model->setSelectedScheme(savedThemes.last());
        }

        m_editDialogProcess->deleteLater();
        m_editDialogProcess = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : credentialsData.keys()) {
                            qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DragImage *image : std::as_const(m_dragImages)) {
        if (!image->blank && !image->image.isNull()) {
            pos = image->rect.translated(-offset.x(), -offset.y()).topLeft();
            image->cursorOffset.setX(pos.x() - (x - offset.x()));
            image->cursorOffset.setY(pos.y() - (y - offset.y()));

            painter.drawImage(pos, image->image);
        }

        // FIXME HACK: Operate on copy.
        image->rect.translate(m_dragHotSpotScrollOffset.x(), m_dragHotSpotScrollOffset.y());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{
                    cg.readEntry("Name"),
                    cg.readEntry("Comment"),
                    cg.readEntry("IconName"),
                    eventId,
                    // TODO Flags?
                    cg.readEntry("Action").split(QLatin1Char('|'))
                };
                events.append(event);
            }
```

#### AUTO 


```{c}
const auto infoMatch = QRegularExpression(QStringLiteral("Name *: (.+)")).match(rpmInfo);
```

#### LAMBDA EXPRESSION 


```{c}
[this, items]() {
                    KPropertiesDialog::showDialog(items, nullptr, false /*non modal*/);
            }
```

#### AUTO 


```{c}
auto action = std::find_if(cat->actions.begin(), cat->actions.end(), [&] (const Action &a) {
            return a.id == key;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &source : sources) {
        onApplicationJobAdded(source);
    }
```

#### AUTO 


```{c}
auto action = activitiesActionCollection->addAction(
                QStringLiteral("switch-to-activity-") + activity);
```

#### AUTO 


```{c}
auto item = new QStandardItem(KXftConfig::description(s));
```

#### AUTO 


```{c}
const auto configFile = QStandardPaths::writableLocation(
                                        QStandardPaths::GenericConfigLocation) +
                                    QLatin1Char('/') + plasmaConfig.name();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_model->setSelectedStyle(styleSettings()->widgetStyle());
    }
```

#### AUTO 


```{c}
const auto &cont
```

#### LAMBDA EXPRESSION 


```{c}
[urlsList] {
                    KRun::displayOpenWithDialog(urlsList, nullptr);
                }
```

#### AUTO 


```{c}
auto item = new KPropertySkeletonItem(m_settingsStore, propertyName, defaultValue);
```

#### AUTO 


```{c}
const auto& activity
```

#### AUTO 


```{c}
auto allShortcutsCall = component.allShortcutInfos();
```

#### AUTO 


```{c}
const auto pair = std::make_pair(screenId, activityId);
```

#### AUTO 


```{c}
const auto savedThemes = QString::fromUtf8(m_editDialogProcess->readAllStandardOutput()).split(QLatin1Char('\n'), QString::SkipEmptyParts);
```

#### AUTO 


```{c}
auto it = std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
        return c.id == uniqueName;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_inputWindow->show();
            m_inputWindow->update();
        }
```

#### AUTO 


```{c}
const auto addedList = addedApps.readXdgListEntry(s_mimetype);
```

#### AUTO 


```{c}
auto ptr = search->second.lock();
```

#### AUTO 


```{c}
auto& action
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceFile : autostartServices) {
                    KService service(serviceFile + QStringLiteral(".desktop"));
                    KAutostart as(serviceFile);
                    as.setAutostarts(false);
                    //FIXME: quite ugly way to stop things, and what about non KDE things?
                    QProcess::startDetached(QStringLiteral("kquitapp5"), {QStringLiteral("--service"), service.property(QStringLiteral("X-DBUS-ServiceName")).toString()});
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: m_activitiesWindows.keys()) {
        if (m_activitiesWindows[activity].contains(window)) {
            m_activitiesWindows[activity].removeAll(window);

            rowChanged(rowForActivityId(activity),
                m_activitiesWindows.size() == 0
                    ? QVector<int>{WindowCount, HasWindows}
                    : QVector<int>{WindowCount});
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode)
        Q_UNUSED(exitStatus)

        m_testProcess->deleteLater();
        m_testProcess = nullptr;
        emit testingChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& shortcut : it->shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                const QStringList actionId = buildActionId(it->uniqueName, it->friendlyName,
                        shortcut.uniqueName, shortcut.friendlyName);
                //operator int of QKeySequence
                QList<int> keys(shortcut.activeShortcuts.cbegin(), shortcut.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << shortcut.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                        "Error while saving shortcut %1: %2", it->friendlyName, shortcut.friendlyName));
                } else {
                    shortcut.initialShortcuts = shortcut.activeShortcuts;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
                m_dropTargetPositions.insert(url.fileName(), dropPos);
                m_screenMapper->addMapping(mappableUrl(url), m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                m_screenMapper->removeItemFromDisabledScreen(mappableUrl(url));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QList<QKeySequence> &list) {
            return QSet<QKeySequence>{list.cbegin(), list.cend()};
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](QDBusPendingCallWatcher *watcher) mutable {
                         QDBusPendingReply<QDBusVariant> reply = *watcher;
                         setActivityIsPrivate(reply.value().variant().toBool());
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Component &c) {
            return c.displayName == componentGroupName;
        }
```

#### AUTO 


```{c}
auto query = database.execQuery(
        QStringLiteral("SELECT value FROM SchemaInfo WHERE key = 'version'"),
        /* ignore error */ true);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QString &left, const QString &right) {
            using KActivities::Info;
            const QString &leftName = Info(left).name().toLower();
            const QString &rightName = Info(right).name().toLower();

            return
                (leftName < rightName) ||
                (leftName == rightName && left < right);
        }
```

#### AUTO 


```{c}
const auto result = cache.find(resource);
```

#### AUTO 


```{c}
auto *watcher = new QDBusPendingCallWatcher(result, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& image : images) {
        if(width < image.width()) {
            width = image.width();
        }
        height += image.height() + spacing;
        format = image.format();
        devicePixelRatio = image.devicePixelRatio();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ModelInfo *modelInfo : std::as_const(rules->modelInfos)) {
            QVERIFY(modelInfo != nullptr);
            QVERIFY(modelInfo->name.length() > 0);
            QVERIFY(modelInfo->description.length() > 0);
            //        	QVERIFY( ! modelInfo->vendor.isEmpty() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &list : matchesForRunner) {
        qSort(list.begin(), list.end(), qGreater<Plasma::QueryMatch>());
    }
```

#### AUTO 


```{c}
auto currentStart    = pattern.constBegin();
```

#### AUTO 


```{c}
auto it = std::find_if(m_data.begin(), m_data.end(), [this, &scheme](const ColorsModelData &item) {
        return item.schemeName == scheme;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &disabledUrls : qAsConst(m_itemsOnDisabledScreensMap)) {
                found = disabledUrls.contains(name.first);
                if (found)
                    break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& image : images) {
        p.drawImage(0, offset, image);
        offset += (image.height() + spacing) / devicePixelRatio;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : qAsConst(component.actions)) {
            if (action.initialShortcuts != action.activeShortcuts) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
```

#### AUTO 


```{c}
auto reply = xcb_grab_keyboard_reply(QX11Info::connection(), cookie, NULL);
```

#### AUTO 


```{c}
const auto newItemsEnd =
                newItems.size() <= maxToReplace ? newItems.cend() :
                                                  newItems.cbegin() + maxToReplace;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &mod : modules) {
		QString servicePath = mod.metaDataFileName();

		// autoload defaults to false if it is not found
		const bool autoload = mod.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();
		// keep estimating dbusModuleName in sync with KDEDModule (kdbusaddons) and kded (kded)
		// currently (KF5) the module name in the D-Bus object path is set by the pluginId
		const QString dbusModuleName = mod.pluginId();
		qCDebug(KCM_KDED) << "reading kded info from" << servicePath << "autoload =" << autoload << "dbus module name =" << dbusModuleName;

		// The logic has to be identical to Kded::initModules.
		// They interpret X-KDE-Kded-autoload as false if not specified
		//                X-KDE-Kded-load-on-demand as true if not specified
		if (autoload) {
			treeitem = new QTreeWidgetItem();
			treeitem->setCheckState(StartupUse, autoloadEnabled(&kdedrc, mod) ? Qt::Checked : Qt::Unchecked);
			treeitem->setText(StartupService, mod.name());
			treeitem->setText(StartupDescription, mod.description());
			treeitem->setText(StartupStatus, NOT_RUNNING);
			treeitem->setData(StartupService, LibraryRole, dbusModuleName);
			_lvStartup->addTopLevelItem(treeitem);
		}
		else if (isModuleLoadedOnDemand(mod)) {
			treeitem = new QTreeWidgetItem();
			treeitem->setText(OnDemandService, mod.name() );
			treeitem->setText(OnDemandDescription, mod.description());
			treeitem->setText(OnDemandStatus, NOT_RUNNING);
			treeitem->setData(OnDemandService, LibraryRole, dbusModuleName);
			_lvLoD->addTopLevelItem(treeitem);
		}
		else {
			qCWarning(KCM_KDED) << "kcmkded: Module " << mod.name() << "from file" << mod.metaDataFileName() << " not loaded on demand or startup! Skipping.";
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, enable](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<void> reply = *watcher;
            watcher->deleteLater();

            checkFirmwareSetupRequested();

            KMessageWidget *message = ui->firmwareSetupMessageWidget;

            if (reply.isError()) {
                // User likely canceled the PolKit prompt, don't show an error in this case
                if (reply.error().type() != QDBusError::AccessDenied) {
                    message->setMessageType(KMessageWidget::Error);
                    message->setText(i18n("Failed to request restart to firmware setup: %1", reply.error().message()));
                    message->animatedShow();
                }
                return;
            }

            if (!enable) {
                return;
            }

            message->setMessageType(KMessageWidget::Information);
            if (m_isUefi) {
                message->setText(i18n("Next time the computer is restarted, it will enter the UEFI setup screen."));
            } else {
                message->setText(i18n("Next time the computer is restarted, it will enter the firmware setup screen."));
            }
            message->addAction(m_rebootNowAction);
            message->animatedShow();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &effect : effectList) {
            groupEffectOut.writeEntry(effect, groupEffectTheme.readEntry(effect));
        }
```

#### AUTO 


```{c}
auto foundStorageId = m_launcherUrlToStorageId.constFind(uri);
```

#### AUTO 


```{c}
const auto currentUrl = m_excludeList.at(idx.row());
```

#### AUTO 


```{c}
const auto buttons = mButtons.buttons();
```

#### LAMBDA EXPRESSION 


```{c}
[path, pendingCalls, this](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else if (!reply.value().isEmpty()) {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2) {
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            }
```

#### AUTO 


```{c}
const auto &shortcut
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layoutUnits) {
			str += layoutUnit.toString() + QLatin1Char(',');
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dictPath : qAsConst(dicts)) {
            GSList *list = ibus_emoji_data_load (dictPath.toUtf8().constData());
            m_emoji.reserve(g_slist_length(list));
            for (GSList *l = list; l; l = l->next) {
                IBusEmojiData *data = (IBusEmojiData *) l->data;
                if (!IBUS_IS_EMOJI_DATA (data)) {
                    qWarning() << "Your dict format is no longer supported.\n"
                                "Need to create the dictionaries again.";
                    g_slist_free (list);
                    return;
                }

                const QString emoji = QString::fromUtf8(ibus_emoji_data_get_emoji(data));
                const QString description = ibus_emoji_data_get_description(data);
                if (description == QString::fromUtf8("↑↑↑") || description.isEmpty() || processedEmoji.contains(emoji)) {
                    continue;
                }

                const QString category = QString::fromUtf8(ibus_emoji_data_get_category(data));
                categories.insert(category);
                m_emoji += { emoji, description, category };
                processedEmoji << emoji;
            }
            g_slist_free (list);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *componentsWatcher) {
        QDBusPendingReply<QList<QDBusObjectPath>> componentsReply = *componentsWatcher;
        componentsWatcher->deleteLater();
        if (componentsReply.isError()) {
            genericErrorOccured(QStringLiteral("Error while calling allComponents()"), componentsReply.error());
            endResetModel();
            return;
        }
        const QList<QDBusObjectPath> componentPaths = componentsReply.value();
        int *pendingCalls = new int;
        *pendingCalls = componentPaths.size();
        for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else if (!reply.value().isEmpty()) {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2) {
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possibleThemeDirectoryName : possibleThemesDirectoriesNames) {
            possibleThemesPaths += themesLocationPath + '/' + possibleThemeDirectoryName;
        }
```

#### AUTO 


```{c}
const auto items = m_sizesModel->findItems(QString::number(cursorSize));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUuid &id : ids) {
                QAbstractItemModel *model = d->windowModels.at(0)->sourceModel();
                TaskManager::WindowTasksModel *tasksModel = static_cast<TaskManager::WindowTasksModel *>(model);

                for (int i = 0; i < tasksModel->rowCount(); ++i) {
                    const QModelIndex &idx = tasksModel->index(i, 0);

                    if (idx.data(TaskManager::AbstractTasksModel::IsOnAllVirtualDesktops).toBool()) {
                        break;
                    }

                    const QVariantList &winIds = idx.data(TaskManager::AbstractTasksModel::WinIdList).toList();
                    if (!winIds.isEmpty() && winIds.at(0).value<QUuid>() == id) {
                        tasksModel->requestVirtualDesktops(idx, QVariantList() << itemId.toString());
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                   QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                   QStringLiteral("org.kde.KWin.InputDevice"),
                                   QDBusConnection::sessionBus(),
                                   this);
        QVariant reply = deviceIface.property("pointer");
        if (reply.isValid() && reply.toBool()) {
            reply = deviceIface.property("touchpad");
            if (reply.isValid() && reply.toBool()) {
                continue;
            }

            KWinWaylandDevice *dev = new KWinWaylandDevice(sn);
            if (!dev->init()) {
                qCCritical(KCM_MOUSE) << "Error on creating device object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos of %1.", sn);
                return;
            }
            m_devices.append(dev);
            qCDebug(KCM_MOUSE).nospace() << "Device found: " << dev->name() << " (" << dev->sysName() << ")";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *behaviorSettings : qAsConst(m_behaviorSettingsList)) {
        behaviorSettings->load();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & pathIt: m_screensPerPath) {
            pathIt.removeAll(screenId);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        if (!m_contextMenu) {
            return;
        }

        m_contextMenu->exec(pos);
        m_contextMenu->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        // Skip over directories.
        if (!index.data(IsDirRole).toBool()) {
            items << itemForIndex(index);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& str : output) {
            if (!str.endsWith(QDir::separator()))
                str.append(QDir::separator());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const StylesModelData &a, const StylesModelData &b) {
        const QString aDisplay = !a.display.isEmpty() ? a.display : a.styleName;
        const QString bDisplay = !b.display.isEmpty() ? b.display : b.styleName;
        return collator.compare(aDisplay, bDisplay) < 0;
    }
```

#### AUTO 


```{c}
auto &event = m_data[index.internalId() - 1].events[index.row()];
```

#### AUTO 


```{c}
auto wallpaper = wallpaperConfig.readEntry("Image", QString());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Action &a1, const Action &a2) {
            return collator.compare(a1.displayName, a2.displayName) < 0;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& agent: query.agents()) {
            for (const auto& urlFilter: query.urlFilters()) {
                scoring.call("DeleteStatsForResource", activity, agent, urlFilter);
            }
        }
```

#### AUTO 


```{c}
auto idx = index(m_userList.lastIndexOf(user));
```

#### AUTO 


```{c}
auto engine_desc = impanel->engineManager->engines()[impanel->selected];
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDBusPendingCallWatcher *componentsWatcher) {
        QDBusPendingReply<QList<QDBusObjectPath>> componentsReply = *componentsWatcher;
        componentsWatcher->deleteLater();
        if (componentsReply.isError()) {
            genericErrorOccured(QStringLiteral("Error while calling allComponents()"), componentsReply.error());
            endResetModel();
            return;
        }
        const QList<QDBusObjectPath> componentPaths = componentsReply.value();
        int *pendingCalls = new int;
        *pendingCalls = componentPaths.size();
        for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](InputDevice *dev) {
        return dev->isSaveNeeded();
    }
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent("KTp")
                    | Type::any()
                    | Activity::current()
                    | Url::startsWith("ktp");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity: activities) {
        const int row = rowForActivityId(activity);
        emit rowChanged(row, { KActivities::ActivitiesModel::ActivityBackground });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandDevice*>(t)->isChangedConfig(); }
```

#### AUTO 


```{c}
auto pos = std::lower_bound(m_components.begin(), m_components.end(), displayName, [&] (const Component &c, const QString &name) {
        return c.type != i18n("System Services") &&  collator.compare(c.friendlyName, name) < 0;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &containmentId : plasmaConfigContainments().groupList()) {
            const auto containment = plasmaConfigContainments().group(containmentId);
            const auto lastScreen = containment.readEntry("lastScreen", 0);
            const auto activity = containment.readEntry("activityId", QString());

            // Ignore the containment if the activity is not defined
            if (activity.isEmpty())
                continue;

            // If we have already found the same activity from another
            // containment, we are using the new one only if
            // the previous one was a color and not a proper wallpaper,
            // or if the screen ID is closer to zero
            const bool processed = !ghostActivities.contains(activity) && newForActivity.contains(activity) && (lastScreenForActivity[activity] <= lastScreen);

            // qDebug() << "GREPME Searching containment " << containmentId
            //          << "for the wallpaper of the " << activity << " activity - "
            //          << "currently, we think that the wallpaper is " << processed << (processed ? newForActivity[activity] : QString())
            //          << "last screen is" << lastScreen
            //          ;

            if (processed && newForActivity[activity][0] != '#')
                continue;

            // Marking the current activity as processed
            ghostActivities.removeAll(activity);

            const auto background = backgroundFromConfig(containment);

            // qDebug() << "        GREPME Found wallpaper: " << background;

            if (background.isEmpty())
                continue;

            // If we got this far and we already had a new wallpaper for
            // this activity, it means we now have a better one
            bool foundBetterWallpaper = changedActivities.contains(activity);

            if (foundBetterWallpaper || newForActivity[activity] != background) {
                if (!foundBetterWallpaper) {
                    changedActivities << activity;
                }

                // qDebug() << "        GREPME Setting: " << activity << " = " << background << "," << lastScreen;
                newForActivity[activity] = background;
                lastScreenForActivity[activity] = lastScreen;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mountPath : m_mountPoints) {
        if (includeList.contains(mountPath))
            continue;

        if (m_settings->excludedFolders().contains(mountPath))
            continue;

        if (!m_excludeList.contains(mountPath)) {
            m_excludeList.append(mountPath);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        Plasma::Package pkg = Plasma::PluginLoader::self()->loadPackage("Plasma/LookAndFeel");
        pkg.setPath(path);
        pkg.setFallbackPackage(Plasma::Package());
        if (component.isEmpty() || !pkg.filePath(component.toUtf8()).isEmpty()) {
            packages << pkg;
        }
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString,      const QString &,      Wallpaper)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& containmentId: plasmaConfigContainments().groupList()) {
                const auto containment = plasmaConfigContainments().group(containmentId);
                const auto lastScreen  = containment.readEntry("lastScreen", 0);
                const auto activity    = containment.readEntry("activityId", QString());

                // Ignore the containment if the activity is not defined
                if (activity.isEmpty()) continue;

                // If we have already found the same activity from another
                // containment, we are using the new one only if
                // the previous one was a color and not a proper wallpaper,
                // or if the screen ID is closer to zero
                const bool processed = !ghostActivities.contains(activity) &&
                                        newForActivity.contains(activity) &&
                                        (lastScreenForActivity[activity] <= lastScreen);

                // qDebug() << "GREPME Searching containment " << containmentId
                //          << "for the wallpaper of the " << activity << " activity - "
                //          << "currently, we think that the wallpaper is " << processed << (processed ? newForActivity[activity] : QString())
                //          << "last screen is" << lastScreen
                //          ;

                if (processed &&
                    newForActivity[activity][0] != '#') continue;

                // Marking the current activity as processed
                ghostActivities.removeAll(activity);

                const auto background = backgroundFromConfig(containment);

                // qDebug() << "        GREPME Found wallpaper: " << background;

                if (background.isEmpty()) continue;

                // If we got this far and we already had a new wallpaper for
                // this activity, it means we now have a better one
                bool foundBetterWallpaper = changedActivities.contains(activity);

                if (foundBetterWallpaper || newForActivity[activity] != background) {
                    if (!foundBetterWallpaper) {
                        changedActivities << activity;
                    }

                    // qDebug() << "        GREPME Setting: " << activity << " = " << background << "," << lastScreen;
                    newForActivity[activity] = background;
                    lastScreenForActivity[activity] = lastScreen;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mimeCopy, x, y, dropJob](const KFileItemListProperties &) {
        emit popupMenuAboutToShow(dropJob, mimeCopy, x, y);
        mimeCopy->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &styleName : allStyles) {
        auto &item = styleData[styleName];
        item.styleName = styleName;
    }
```

#### AUTO 


```{c}
auto &groupName
```

#### AUTO 


```{c}
auto allowedApplications = QSet<QString>::fromList(d->pluginConfig->allowedApplications());
```

#### AUTO 


```{c}
auto query
                = Database::instance(Database::ResourcesDatabase,
                                     Database::ReadOnly)
                      ->execQuery("SELECT mimetype FROM ResourceInfo WHERE "
                                  "targettedResource = '" + resource + "'");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : pendingDeletions) {
        m_model->setData(idx, false, PendingDeletionRole);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const KFileItem& item) mutable {
                    Q_UNUSED(item);
                    m_previewJobs.remove(file);

                    qWarning() << "SwitcherBackend: FAILED to get the thumbnail for "
                               << path << job->detailedErrorStrings(&file);
                    callback.call({false});
                }
```

#### AUTO 


```{c}
auto newDeskTopFile = desktopFile.copyTo(desktopPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attr : attributes) {
                entry.insert(attr.qualifiedName().toString(), attr.value().toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            const QString suffixedFileName = QLatin1String("kstyle/themes/") + file;
            if (!themeFiles.contains(suffixedFileName)) {
                themeFiles.append(suffixedFileName);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](User *lhs, User *) {
        return lhs->loggedIn();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&font, &textColor, &offset](QString text) {
        //don't try to paint stuff on a future null pixmap because the text is empty
        if (text.isEmpty()) {
            return QPixmap();
        }

        // Draw text
        QFontMetrics fm(font);
        QRect textRect = fm.boundingRect(text);
        QPixmap textPixmap(textRect.width(), fm.height());
        textPixmap.fill(Qt::transparent);
        QPainter p(&textPixmap);
        p.setPen(textColor);
        p.setFont(font);
        // FIXME: the center alignment here is odd: the rect should be the size needed by
        //        the text, but for some fonts and configurations this is off by a pixel or so
        //        and "centering" the text painting 'fixes' that. Need to research why
        //        this is the case and determine if we should be painting it differently here,
        //        doing soething different with the boundingRect call or if it's a problem
        //        in Qt itself
        p.drawText(textPixmap.rect(), Qt::AlignCenter, text);
        p.end();

        return textPixmap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : m_data) {
        if (item.pendingDeletion) {
            pendingDeletions.append(item.schemeName);
        }
    }
```

#### AUTO 


```{c}
auto root = view->rootObject();
```

#### AUTO 


```{c}
auto blockedApplications = QSet<QString>::fromList(config.readEntry("blocked-applications", QStringList()));
```

#### AUTO 


```{c}
auto doUpdateMaps = [&]() {
        for (int i = 0; i < fromIndices.count(); ++i)
        {
            const int from = fromIndices[i];
            const int to = toIndices[i];
            const int sourceRow = sourceRows[i];

            if (!toIndices.contains(from)) {
                m_proxyToSource.remove(from);
            }

            updateMaps(to, sourceRow);
            changed.append(index(from, 0));

            if (to < oldCount) {
               changed.append(index(to, 0));
            }
        }
    };
```

#### AUTO 


```{c}
const auto name = it.key();
```

#### AUTO 


```{c}
const auto &window
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &currentActivity) {
                qCDebug(KICKER_DEBUG) << "Activity just got changed to" << currentActivity;
                Q_UNUSED(currentActivity);
                auto clientId = d->m_clientId;
                initForClient(clientId);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            const QString suffixedFileName = QStringLiteral("color-schemes/") + file;
            // can't use QSet because of the transform below (passing const QString as this argument discards qualifiers)
            if (!schemeFiles.contains(suffixedFileName)) {
                schemeFiles.append(suffixedFileName);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto componentGroupName : config.groupList()) {
        auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.id == componentGroupName;
        });
        if (component == m_components.end()) {
            qCWarning(KCMKEYS) << "Ignoring unknown component" << componentGroupName;
            continue;
        }
        KConfigGroup componentGroup(&config, componentGroupName);
        if (!componentGroup.hasGroup("Global Shortcuts")) {
            qCWarning(KCMKEYS) << "Group" << componentGroupName << "has no shortcuts group";
            continue;
        }
        KConfigGroup shortcutsGroup(&componentGroup, "Global Shortcuts");
        for (const auto& key : shortcutsGroup.keyList()) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&] (const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component-m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
    }
```

#### AUTO 


```{c}
const auto& action
```

#### RANGE FOR STATEMENT 


```{c}
for (auto model: models) {
                    model->onBackgroundsUpdated(changedActivities);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerKey &key : std::as_const(m_triggersList)) {
        xcb_keysym_t sym = key.first;
        uint modifiers = key.second;
        xcb_keycode_t *keycode = xcb_key_symbols_get_keycode(m_syms, sym);
        if (!keycode) {
            g_warning("Can not convert keyval=%u to keycode!", sym);
        } else {
            xcb_ungrab_key(QX11Info::connection(), keycode[0], QX11Info::appRootWindow(), modifiers);
            if ((modifiers & XCB_MOD_MASK_SHIFT) == 0) {
                xcb_ungrab_key(QX11Info::connection(), keycode[0], QX11Info::appRootWindow(), modifiers | XCB_MOD_MASK_SHIFT);
            }
        }
        free(keycode);
    }
```

#### AUTO 


```{c}
auto screens = qGuiApp->screens();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.values) {
        for (const auto& agent: agents.values) {
            scoring.call("DeleteStatsForResource", activity, agent, resource);
        }
    }
```

#### AUTO 


```{c}
auto *w = *it;
```

#### AUTO 


```{c}
auto query = AllResources | Agent(QStringLiteral("org.kde.systemsettings")) | HighScoredFirst | Limit(5);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : qAsConst(extraLayouts)) {
                QAction *action = createAction(layoutUnit);
                actionGroup->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry& entry : list) {
                if (entry.status() == KNS3::Entry::Deleted) {
                    for (const QString& deleted : entry.uninstalledFiles()) {
                        QVector<QStringRef> list = deleted.splitRef(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        QModelIndex idx = m_themeModel->findIndex(list.last().toString());
                        if (idx.isValid()) {
                            m_themeModel->removeTheme(idx);
                        }
                    }
                } else if (entry.status() == KNS3::Entry::Installed) {
                    for (const QString& created : entry.installedFiles()) {
                        QStringList list = created.split(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        // Because we sometimes get some extra slashes in the installed files list
                        list.removeAll({});
                        // Because we'll also get the containing folder, if it was not already there
                        // we need to ignore it.
                        if (list.last() == QLatin1String(".icons")) {
                            continue;
                        }
                        m_themeModel->addTheme(QStringLiteral("/%1").arg(list.join(QLatin1Char('/'))));
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &module : modules) {
        QString servicePath = module.metaDataFileName();

        // autoload defaults to false if it is not found
        const bool autoload = module.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();

        // keep estimating dbusModuleName in sync with KDEDModule (kdbusaddons) and kded (kded)
        // currently (KF5) the module name in the D-Bus object path is set by the pluginId
        const QString dbusModuleName = module.pluginId();
        qCDebug(KCM_KDED) << "reading kded info from" << servicePath << "autoload =" << autoload << "dbus module name =" << dbusModuleName;

        if (knownModules.contains(dbusModuleName)) {
            continue;
        }

        knownModules.append(dbusModuleName);

        KConfigGroup cg(&kdedrc, QStringLiteral("Module-%1").arg(dbusModuleName));
        const bool autoloadEnabled = cg.readEntry("autoload", true);
        const bool immutable = cg.isEntryImmutable("autoload");

        ModulesModelData data{module.name(), module.description(), KDEDConfig::UnknownType, autoloadEnabled, dbusModuleName, immutable, autoloadEnabled};

        // The logic has to be identical to Kded::initModules.
        // They interpret X-KDE-Kded-autoload as false if not specified
        //                X-KDE-Kded-load-on-demand as true if not specified
        if (autoload) {
            data.type = KDEDConfig::AutostartType;
            autostartModules << data;
        } else if (isModuleLoadedOnDemand(module)) {
            data.type = KDEDConfig::OnDemandType;
            onDemandModules << data;
        } else {
            qCWarning(KCM_KDED) << "kcmkded: Module " << module.name() << "from file" << module.metaDataFileName()
                                << " not loaded on demand or startup! Skipping.";
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        Q_UNUSED(error);
        emit testingFailed();
    }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &prop : props) {
            list << String2Property(prop);
        }
```

#### AUTO 


```{c}
const auto activity = static_cast<Info*> (activityInfo);
```

#### AUTO 


```{c}
const auto &actions = service->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : windowModels) {
                    windowModel->setActivity(activityInfo->currentActivity());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, desktopEntryUrl] {
            KService::Ptr service = KService::serviceByDesktopPath(desktopEntryUrl.toLocalFile());
            if (!service) {
                return;
            }

            KRun::runService(*service, {url}, QApplication::activeWindow());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : it.value()) {
            // add the items to the new screen, if they are on a disabled screen and their
            // location is below the new screen's path
            if (name.url().startsWith(screenPathWithScheme)) {
                addMapping(name, screenId, activity, DelayedSignal);
                items.removeAll(name);
            }
        }
```

#### AUTO 


```{c}
const auto &blockedAppList = d->pluginConfig->blockedApplications();
```

#### LAMBDA EXPRESSION 


```{c}
[&](QDBusPendingCallWatcher *watcher) mutable {
            QDBusPendingReply<QDBusVariant> reply = *watcher;
            setActivityIsPrivate(reply.value().variant().toBool());
            watcher->deleteLater();
        }
```

#### AUTO 


```{c}
const auto matching = model()->match(model()->index(0,0), Qt::DisplayRole, service->exec());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : str) {
            if (!c.isPrint() && !c.isNull()) {
                str = "";
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](XkbRF_RulesPtr obj) {
        XkbRF_Free(obj, True);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : std::as_const(rules->layoutInfos)) {
            QVERIFY(!layoutInfo->fromExtras);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KXftConfig::SubPixel::Type t : {KXftConfig::SubPixel::None, KXftConfig::SubPixel::Rgb, KXftConfig::SubPixel::Bgr, KXftConfig::SubPixel::Vrgb, KXftConfig::SubPixel::Vbgr}) {
        auto item = new QStandardItem(KXftConfig::description(t));
        m_subPixelOptionsModel->appendRow(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, user, item]{
                auto idx = index(m_userList.lastIndexOf(user));
                Q_EMIT dataChanged(idx, idx, {item.second});
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, udi]() {
                addNewDevice(udi);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : l) {
            if (s == m_currentActivity) {
                continue; // Missing activity ID from the old config before 5.25
            }

            seralizedMap.append(s);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &info : oldStylePlugins) {
        if (moduleIds.contains(info.pluginName())) {
            qCWarning(KCM_KDED).nospace() << "kded module " << info.pluginName()
                                          << " has already been found using "
                                             "JSON metadata, please don't install the now unneeded .desktop file ("
                                          << info.entryPath() << ").";
        } else {
            qCDebug(KCM_KDED).nospace() << "kded module " << info.pluginName() << " still uses .desktop files (" << info.entryPath()
                                        << "). Please port it to JSON metadata.";
            plugins.append(info.toMetaData());
        }
    }
```

#### AUTO 


```{c}
auto reportProcessError = [this, process]() {
            Q_EMIT error(xi18nc("@info", "Failed to run install command: <message>%1</message>", process->errorString()));
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (OptionInfo *optionInfo : qAsConst(optionGroupInfo->optionInfos)) {
            optionInfo->description = translate_description(optionInfo);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : lines) {
        QByteArray element("layout:");
        if (line.startsWith(element)) {
            m_defaultLayout = QString::fromLatin1(line.mid(element.length(), line.length())).trimmed();
        }

        element = "variant:";
        if (line.startsWith(element)) {
            m_defaultVariant = QString::fromLatin1(line.mid(element.length(), line.length())).trimmed();
        }

        element = "options:";
        if (line.startsWith(element)) {
            m_defaultOption = QString::fromLatin1(line.mid(element.length(), line.length())).trimmed();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity: activities) {
        const int row = rowForActivityId(activity);
        emit rowChanged(row, { KActivitiesBackport::ActivitiesModel::ActivityBackground });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&c](AbstractEntry* a, AbstractEntry* b) { return c.compare(a->name(), b->name()) < 0; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& agent: query.agents()) {
            for (const auto& urlFilter: query.urlFilters()) {
                scoring.call(QStringLiteral("DeleteStatsForResource"), activity, agent, urlFilter);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : components) {
        KGlobalAccelComponentInterface component(globalAccelInterface.service(), componentPath.path(), QDBusConnection::sessionBus());
        component.setTimeout(dbusTimeout);
        if (!component.isValid()) {
            return true;
        }
        auto allShortcutsCall = component.allShortcutInfos();
        allShortcutsCall.waitForFinished();
        if (allShortcutsCall.isError()) {
            return true;
        }
        const auto allShortcuts = allShortcutsCall.value();
        for (const auto &shortcutInfo : allShortcuts) {
            if (shortcutInfo.defaultKeys() != shortcutInfo.keys()) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : mimeData->urls()) {
            m_dropTargetPositions.insert(url.fileName(), dropPos);
            m_screenMapper->addMapping(mappableUrl(url), m_screen, ScreenMapper::DelayedSignal);
            m_screenMapper->removeItemFromDisabledScreen(mappableUrl(url));
        }
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), SchemeNameRole, newName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : lstItems) {
        const QUrl url = item.url();
        lstUrls.append(url);
        if (!bTrashIncluded && ((url.scheme() == QLatin1String("trash") && url.path().length() <= 1))) {
            bTrashIncluded = true;
        }
    }
```

#### AUTO 


```{c}
auto idx
```

#### LAMBDA EXPRESSION 


```{c}
[&](Component &c1, Component &c2) {
        return collator.compare(c1.displayName, c2.displayName) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of added application") + desktopFileName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
        connect(infoWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            if (infoReply.value().isEmpty()) {
                qCWarning(KCMKEYS()) << "New component has no shortcuts:" << reply.value().path();
                Q_EMIT errorOccured(i18nc("%1 is the name of an application", "Error while adding %1, it seems it has no actions."));
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(), pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo  : rules->layoutInfos) {
    	QSet<QString> langs = QSet<QString>(layoutInfo->languages.constBegin(), layoutInfo->languages.constEnd());
    	languages.unite( langs );
    }
```

#### AUTO 


```{c}
auto wallpaperConfig = config.group("Wallpaper").group(wallpaperPlugin).group("General");
```

#### AUTO 


```{c}
auto watcher = new QDBusServiceWatcher(presentWindowsName,
                                           QDBusConnection::sessionBus(),
                                           QDBusServiceWatcher::WatchForRegistration | QDBusServiceWatcher::WatchForUnregistration,
                                           this);
```

#### AUTO 


```{c}
auto appEntry = dynamic_cast<AppEntry*>(entry.data());
```

#### AUTO 


```{c}
const auto &event = m_data.at(index.internalId() - 1).events.at(index.row());
```

#### AUTO 


```{c}
auto query = AllResources
        | Agent(QStringLiteral("org.kde.systemsettings"))
        | HighScoredFirst
        | Limit(5);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
            KFileItem item = itemForIndex(index);
            if (!item.isNull()) {
                items.append(item);
                urls.append(item.url());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this,activityToSet] () {
                setCurrentActivity(activityToSet);
            }
```

#### AUTO 


```{c}
auto newBackground = backgroundFromConfig(config);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dictPath : qAsConst(dicts)) {
            GSList *list = ibus_emoji_data_load(dictPath.toUtf8().constData());
            m_emoji.reserve(g_slist_length(list));
            for (GSList *l = list; l; l = l->next) {
                IBusEmojiData *data = (IBusEmojiData *)l->data;
                if (!IBUS_IS_EMOJI_DATA(data)) {
                    qWarning() << "Your dict format is no longer supported.\n"
                                  "Need to create the dictionaries again.";
                    g_slist_free(list);
                    return;
                }

                const QString emoji = QString::fromUtf8(ibus_emoji_data_get_emoji(data));
                const QString description = QString::fromUtf8(ibus_emoji_data_get_description(data));
                if (description == QString::fromUtf8("↑↑↑") || description.isEmpty() || processedEmoji.contains(emoji)) {
                    continue;
                }

                QStringList annotations;
                const auto annotations_glib = ibus_emoji_data_get_annotations(data);
                for (GSList *l = annotations_glib; l; l = l->next) {
                    annotations << QString::fromUtf8((const gchar *)l->data);
                }

                const QString category = QString::fromUtf8(ibus_emoji_data_get_category(data));
                categories.insert(category);
                m_emoji += {emoji, description, category, annotations};
                processedEmoji << emoji;
            }
            g_slist_free(list);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : it->actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                const QStringList actionId = buildActionId(it->id, it->displayName, action.id, action.displayName);
                // TODO: pass action.activeShortcuts to m_globalAccelInterface->setForeignShortcut() as a QSet<QKeySequence>
                // or QList<QKeySequence>?
                QList<QKeySequence> keys;
                keys.reserve(action.activeShortcuts.size());
                for (const QKeySequence &key : qAsConst(action.activeShortcuts)) {
                    keys.append(key);
                }
                qCDebug(KCMKEYS) << "Saving" << actionId << action.activeShortcuts << keys;
#if KGLOBALACCEL_VERSION >= QT_VERSION_CHECK(5, 90, 0)
                auto reply = m_globalAccelInterface->setForeignShortcutKeys(actionId, keys);
#else
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
#endif
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    Q_EMIT errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                                              "Error while saving shortcut %1: %2",
                                              it->displayName,
                                              it->displayName));
                } else {
                    action.initialShortcuts = action.activeShortcuts;
                }
            }
        }
```

#### AUTO 


```{c}
auto first = split.first();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : terminalEmulators) {
        terminalCombo->addItem(QIcon::fromTheme(service->icon()), service->name(), service->exec());

        if (!terminal.isEmpty() && service->exec() == terminal) {
            terminalCombo->setCurrentIndex(terminalCombo->count() - 1);
            m_currentIndex = terminalCombo->count() - 1;
        }
        if (service->exec() == QStringLiteral("konsole")) {
            m_konsoleIndex = terminalCombo->count() - 1;
        }
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString, const QString &, Icon)
```

#### AUTO 


```{c}
const auto oldBlockStart = std::find_if(
                    m_items.begin() + from, m_items.end(),
                    member(&ResultSet::Result::resource) == newBlockStart->resource());
```

#### AUTO 


```{c}
auto info = std::find_if(knownActivities.cbegin(), knownActivities.cend(),
        [ptr] (const InfoPtr &info) {
            return ptr == info.get();
        }
    );
```

#### AUTO 


```{c}
auto query = d->database.exec(QStringLiteral("SELECT DISTINCT(initiatingAgent) FROM ResourceScoreCache ORDER BY initiatingAgent"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
        if (job->error() != KJob::NoError) {
            emit showErrorMessage(i18n("Unable to download the color scheme: %1", job->errorText()));
            return;
        }

        installSchemeFile(m_tempInstallFile->fileName());
        m_tempInstallFile.reset();
    }
```

#### AUTO 


```{c}
auto url = d->normalizedId(id).value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : keys) {
        m_loginForced[udi] = m_settings->deviceAutomountIsForced(udi, AutomounterSettings::Login);
        m_attachedForced[udi] = m_settings->deviceAutomountIsForced(udi, AutomounterSettings::Attach);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (!m_dropTargetPositions.isEmpty()) {
                setSortMode(-1);
            }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        Q_EMIT gtkThemeSettingsChanged();
    }
```

#### AUTO 


```{c}
auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.displayName == componentGroupName;
        });
```

#### AUTO 


```{c}
auto query = LinkedResources
                    | Agent {
                        AGENT_APPLICATIONS,
                        AGENT_CONTACTS,
                        AGENT_DOCUMENTS
                      }
                    | Type::any()
                    | Activity::any()
                    | Url(url)
                    | Limit::all();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Accounts::AccountId &accountId : accountIds) {
            account = accountsManager->account(accountId);
            if (account) {
                bool completed{false};
                qCDebug(ATTICA_PLUGIN_LOG) << "Fetching data for" << accountId;
                GetCredentialsJob *job = new GetCredentialsJob(accountId, accountsManager);
                connect(job, &KJob::finished, [&completed, &accessToken, &idToken](KJob *kjob) {
                    GetCredentialsJob *job = qobject_cast<GetCredentialsJob *>(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData[QStringLiteral("AccessToken")].toString();
                    idToken = credentialsData[QStringLiteral("IdToken")].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
                    //                     if (!accessToken.isEmpty()) {
                    //                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
                    //                         for (const QString& key : credentialsData.keys()) {
                    //                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                    //                         }
                    //                     }
                    completed = true;
                });
                connect(job, &KJob::result, [&completed]() {
                    completed = true;
                });
                job->start();
                while (!completed) {
                    qApp->processEvents();
                }
                if (!idToken.isEmpty()) {
                    qCDebug(ATTICA_PLUGIN_LOG) << "OpenID Access token retrieved for account" << account->id();
                    break;
                }
            }
            if (idToken.isEmpty()) {
                // If we arrived here, we did have an opendesktop account, but without the id token, which means an old version of the signon oauth2 plugin was
                // used
                qCWarning(ATTICA_PLUGIN_LOG) << "We got an OpenDesktop account, but it seems to be lacking the id token. This means an old SignOn OAuth2 "
                                                "plugin was used for logging in. The plugin may have been upgraded in the meantime, but an account created "
                                                "using the old plugin cannot be used, and you must log out and back in again.";
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMetaObject &interface : interfaceList) {
        QString ifaceName = interface.className();
        ifaceName.remove(0, ifaceName.lastIndexOf(':') + 1);
        Solid::DeviceInterface::Type ifaceDev = Solid::DeviceInterface::stringToType( ifaceName );
        const QString cleanName = Solid::DeviceInterface::typeDescription( ifaceDev );
        types.insert( ifaceDev, cleanName );

        QMap<QString, QString> deviceValues;
        for( int doneProps = propertyOffset; interface.propertyCount() > doneProps; doneProps = doneProps + 1 ) {
            QMetaProperty ifaceProp = interface.property(doneProps);
            deviceValues.insert( ifaceProp.name(), generateUserString(ifaceProp.name()) );
        }
        values.insert( ifaceDev, deviceValues );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT changed(true);
    }
```

#### AUTO 


```{c}
auto it = m_screensPerPath.find(screenUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPackage::Package &pkg : pkgs) {
        addKPackageToModel(pkg);
    }
```

#### AUTO 


```{c}
auto last = split.last();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_lnfDirty = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ &scheme](const ColorsModelData &item) {
        return item.schemeName == scheme;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urlsToRemoveFromMapping)
        removeFromMap(url, activity);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("preview"), ScreenhotRole);
        row->setData(pkg.filePath("fullscreenpreview"), FullScreenPreviewRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            row->setData(hasColors, HasColorsRole);
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possible_ntputility : possible_ntputilities) {
        ntpUtility = QStandardPaths::findExecutable(possible_ntputility, path);
        if (!ntpUtility.isEmpty()) {
            qDebug() << "ntpUtility = " << ntpUtility;
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
            kde4Cg.revertToDefault(key);
        }
```

#### AUTO 


```{c}
auto callFutureInterface = new DBusCallFutureInterface
        <_Result>(interface->asyncCall(method, arg1, arg2, arg3, arg4, arg5,
                                       arg6, arg7, arg8));
```

#### AUTO 


```{c}
const auto years   = diff;
```

#### AUTO 


```{c}
auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[ map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        }
```

#### AUTO 


```{c}
auto keypress = reinterpret_cast<xcb_key_press_event_t*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            if (notifyRcFiles.contains(file)) {
                continue;
            }

            notifyRcFiles.append(file);

            KConfig config(file, KConfig::NoGlobals);
            config.addConfigSources(QStandardPaths::locateAll(QStandardPaths::GenericDataLocation,
                                        QStringLiteral("knotifications5/") + file));

            KConfigGroup globalGroup(&config, QLatin1String("Global"));

            const QRegularExpression regExp(QStringLiteral("^Event/([^/]*)$"));
            const QStringList groups = config.groupList().filter(regExp);

            const QString notifyRcName = file.section(QLatin1Char('.'), 0, -2);
            const QString desktopEntry = globalGroup.readEntry(QStringLiteral("DesktopEntry"));
            if (!desktopEntry.isEmpty()) {
                if (desktopEntries.contains(desktopEntry)) {
                    continue;
                }

                desktopEntries.append(desktopEntry);
            }

            SourceData source{
                // The old KCM read the Name and Comment from global settings disregarding
                // any user settings and just used user-specific files for actions config
                // I'm pretty sure there's a readEntry equivalent that does that without
                // reading the config stuff twice, assuming we care about this to begin with
                globalGroup.readEntry(QStringLiteral("Name")),
                globalGroup.readEntry(QStringLiteral("Comment")),
                globalGroup.readEntry(QStringLiteral("IconName")),
                notifyRcName,
                desktopEntry,
                {} // events
            };

            QVector<EventData> events;
            for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{
                    cg.readEntry("Name"),
                    cg.readEntry("Comment"),
                    cg.readEntry("IconName"),
                    eventId,
                    // TODO Flags?
                    cg.readEntry("Action").split(QLatin1Char('|'))
                };
                events.append(event);
            }

            std::sort(events.begin(), events.end(), [&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            });

            source.events = events;

            if (!source.desktopEntry.isEmpty()) {
                appsData.append(source);
            } else {
                servicesData.append(source);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<Property> &props : std::as_const(helper_props_map)) {
            list_result << PropertyList2LeafOnlyStringList(props);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: query) {
            result.setTitle(item["title"].toString());
            result.setMimetype(item["mimetype"].toString());
        }
```

#### AUTO 


```{c}
const auto time = lastUsedTime(activity);
```

#### AUTO 


```{c}
const auto &dictPath
```

#### LAMBDA EXPRESSION 


```{c}
[&completed](){ completed = true; }
```

#### AUTO 


```{c}
auto reply = m_fprintInterface->EnrollStart(finger);
```

#### AUTO 


```{c}
auto &plugin
```

#### AUTO 


```{c}
const auto sections = idpart.split(QLatin1Char('_'));
```

#### AUTO 


```{c}
auto results = m_themeProxyModel->findIndex(cursorTheme);
```

#### AUTO 


```{c}
const auto pendingDeletions = m_model->match(m_model->index(0, 0), ThemesModel::PendingDeletionRole, true, -1 /*all*/);
```

#### RANGE FOR STATEMENT 


```{c}
for (VariantInfo *variantInfo : qAsConst(layoutInfo->variantInfos)) {
            variantInfo->description = translate_description(variantInfo);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[sysName](QObject *t) {
        return static_cast<KWinWaylandDevice *>(t)->sysName() == sysName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &schemeFile : schemeFiles) {
        const QFileInfo fi(schemeFile);
        const QString baseName = fi.baseName();

        KSharedConfigPtr config = KSharedConfig::openConfig(schemeFile, KConfig::SimpleConfig);
        KConfigGroup group(config, "General");
        const QString name = group.readEntry("Name", baseName);

        QStandardItem *item = new QStandardItem(name);
        item->setData(baseName, SchemeNameRole);
        item->setData(fi.isWritable(), RemovableRole);
        item->setData(false, PendingDeletionRole);

        item->setData(KColorScheme::createApplicationPalette(config), PaletteRole);

        m_model->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device& dev : devices) {
        const Solid::StorageAccess* sa = dev.as<Solid::StorageAccess>();
        if (!sa->isAccessible())
            continue;

        const QString mountPath = sa->filePath();
        if (ignoredMountPoint(mountPath))
            continue;

        m_mountPoints.append(mountPath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& action : component.actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                QList<QKeySequence> keys(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                KStandardShortcut::saveShortcut(KStandardShortcut::findByName(action.id), keys);
                action.initialShortcuts = action.activeShortcuts;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &schemeFile : schemeFiles) {
        const QFileInfo fi(schemeFile);
        const QString baseName = fi.baseName();

        KSharedConfigPtr config = KSharedConfig::openConfig(schemeFile, KConfig::SimpleConfig);
        KConfigGroup group(config, "General");
        const QString name = group.readEntry("Name", baseName);

        ColorsModelData item{
            name,
            baseName,
            KColorScheme::createApplicationPalette(config),
            fi.isWritable(),
            false, // pending deletion
        };

        m_data.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : qAsConst(component.actions)) {
            if (action.initialShortcuts != action.activeShortcuts) {
                return true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[dir, readmes]() {
                QDesktopServices::openUrl(QUrl::fromLocalFile(QDir(dir).absoluteFilePath(readmes.at(0))));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& key : shortcutsGroup.keyList()) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&] (const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component-m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
```

#### AUTO 


```{c}
auto reset = [this](Prop<bool> &prop, bool defVal) {
         prop.reset(m_settings->load(prop.cfgName, defVal));
    };
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const auto ratio = screen->devicePixelRatio(); KWindowSystem::isPlatformX11() && ratio != 1.0) {
            windowGeo.setTopLeft(windowGeo.topLeft() / ratio);
            windowGeo.setBottomRight(windowGeo.bottomRight() / ratio);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities) {
            const QString groupName =
                "Favorites-" + clientId + "-" + activity;

            KConfigGroup cfgGroup(cfg, groupName);

            cfgGroup.writeEntry("ordering", ids);
        }
```

#### AUTO 


```{c}
const auto missingLanguages = m_selectedTranslationsModel->missingLanguages();
```

#### AUTO 


```{c}
const auto end       = pattern.constEnd();
```

#### AUTO 


```{c}
const auto modules = availableModules();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        switch (static_cast<UserApplyJob::Error>(job->error())) {
        case UserApplyJob::Error::PermissionDenied:
            loadData(); // Reload the old data to avoid half transactions
            Q_EMIT applyError(i18n("Could not get permission to save user %1", mName));
            break;
        case UserApplyJob::Error::Failed:
        case UserApplyJob::Error::Unknown:
            loadData(); // Reload the old data to avoid half transactions
            Q_EMIT applyError(i18n("There was an error while saving changes"));
            break;
        case UserApplyJob::Error::NoError: ; // Do nothing
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &iconNames : s_previewIcons) {
        const QString cacheKey = themeName + QLatin1Char('@') + QString::number(size) + QLatin1Char('@')
            + QString::number(dpr,'f',1) + QLatin1Char('@') + iconNames.join(QLatin1Char(','));

        QPixmap pix;
        if (!QPixmapCache::find(cacheKey, &pix)) {
            if (!theme) {
                theme.reset(new KIconTheme(themeName));
            }

            pix = getBestIcon(*theme.data(), iconNames, size, dpr);

            // Inserting a pixmap even if null so we know whether we searched for it already
            QPixmapCache::insert(cacheKey, pix);
        }

        if (pix.isNull()) {
            continue;
        }

        pixmaps.append(pix);

        if (limit > -1 && pixmaps.count() >= limit) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Finger *storedFinger : FINGERS) {
            if (storedFinger->internalName() == finger) {
                fingers.append(QVariant::fromValue(storedFinger));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dictPath : qAsConst(dicts)) {
            GSList *list = ibus_emoji_data_load (dictPath.toUtf8().constData());
            m_emoji.reserve(g_slist_length(list));
            for (GSList *l = list; l; l = l->next) {
                IBusEmojiData *data = (IBusEmojiData *) l->data;
                if (!IBUS_IS_EMOJI_DATA (data)) {
                    qWarning() << "Your dict format is no longer supported.\n"
                                "Need to create the dictionaries again.";
                    g_slist_free (list);
                    return;
                }

                const QString emoji = QString::fromUtf8(ibus_emoji_data_get_emoji(data));
                const QString description = ibus_emoji_data_get_description(data);
                qDebug() << "ooo" << dictPath << emoji << description << processedEmoji.contains(emoji);
                if (description == QString::fromUtf8("↑↑↑") || description.isEmpty() || processedEmoji.contains(emoji)) {
                    continue;
                }

                const QString category = QString::fromUtf8(ibus_emoji_data_get_category(data));
                categories.insert(category);
                m_emoji += { emoji, description, category };
                processedEmoji << emoji;
            }
            g_slist_free (list);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& agent: agents.values) {
            scoring.call("DeleteStatsForResource", activity, agent, resource);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[parentModel, this] { if (parentModel) { parentModel->entryChanged(this); } }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(serviceAction);
```

#### AUTO 


```{c}
const auto configFile = QStandardPaths::writableLocation(
                                        QStandardPaths::GenericConfigLocation) +
                                    QLatin1Char('/') + PLASMACONFIG;
```

#### RANGE FOR STATEMENT 


```{c}
for (WId wid : windows) {
            KWindowSystem::minimizeWindow(wid);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob* copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && m_screenMapper) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = QUrl::fromUserInput(m_url, {}, QUrl::AssumeLocalFile);
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl.toString(), m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url.toString(), m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone,
                this, [this, map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone,
                this, [this, map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : std::as_const(m_dragIndexes)) {
        sourceDragIndexes.append(mapToSource(index));
    }
```

#### AUTO 


```{c}
auto url = entry->url();
```

#### AUTO 


```{c}
const auto timeLeft  = lastUsedTime(activityLeft);
```

#### LAMBDA EXPRESSION 


```{c}
[](const NotificationManager::BehaviorSettings *settings) {
        return !settings->isDefaults();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mimeData, x, y, dropJob](const KFileItemListProperties &) {
        emit popupMenuAboutToShow(dropJob, mimeData, x, y);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = QUrl::fromUserInput(m_url, {}, QUrl::AssumeLocalFile);
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl.toString(), m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url.toString(), m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto sessionBus = QDBusConnection::sessionBus();
```

#### AUTO 


```{c}
const auto parentIndex = index(parent, 0);
```

#### AUTO 


```{c}
const auto url = itemForIndex(idx).url();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto componentGroupName : config.groupList()) {
        auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.displayName == componentGroupName;
        });
        if (component == m_components.end()) {
            qCWarning(KCMKEYS) << "Ignoring unknown component" << componentGroupName;
            continue;
        }
        KConfigGroup componentGroup(&config, componentGroupName);
        if (!componentGroup.hasGroup("Global Shortcuts")) {
            qCWarning(KCMKEYS) << "Group" << componentGroupName << "has no shortcuts group";
            continue;
        }
        KConfigGroup shortcutsGroup(&componentGroup, "Global Shortcuts");
        for (const auto& key : shortcutsGroup.keyList()) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&] (const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component-m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
    }
```

#### DECLTYPE 


```{c}
mutable decltype(_f()) value;
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            qApp->exit();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor]() {
		Q_EMIT const_cast<VariantComboDelegate*>(this)->commitData(editor);
	}
```

#### AUTO 


```{c}
auto component = m_components.begin();
```

#### AUTO 


```{c}
auto defaultRepeat = std::find_if(keys.constBegin(), keys.constEnd(), [=](const KeyBehaviour &key) {
        return keybehaviourNames[key] == m_settings->defaultKeyboardRepeatValue();
    });
```

#### AUTO 


```{c}
auto names = &(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &schemeName : pendingDeletions) {
        Q_ASSERT(schemeName != m_model->selectedScheme());

        const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation,
            QStringLiteral("color-schemes/%1.colors").arg(schemeName));

        auto *job = KIO::del(QUrl::fromLocalFile(path), KIO::HideProgressInfo);
        // needs to block for it to work on "OK" where the dialog (kcmshell) closes
        job->exec();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& created : entry.installedFiles()) {
                        QStringList list = created.split(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        // Because we sometimes get some extra slashes in the installed files list
                        list.removeAll({});
                        // Because we'll also get the containing folder, if it was not already there
                        // we need to ignore it.
                        if (list.last() == QLatin1String(".icons")) {
                            continue;
                        }
                        m_model->addTheme(list.join(QLatin1Char('/')));
                    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
auto job = KIO::file_copy(KUrl(userfaces.absolutePath() + "/.userinfo-tmp"),
                              KUrl(userfaces.absolutePath() + '/' + QFileInfo(imPath).fileName().section('.', 0, 0)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities) {
            m_activitiesWindows[activity] << window;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->aboutToShow(); }
```

#### AUTO 


```{c}
auto status =
            XIGetProperty(m_dpy, info->id, property, 0, 1, False, XA_INTEGER, &type_return, &format_return, &num_items_return, &bytes_after_return, &_data);
```

#### LAMBDA EXPRESSION 


```{c}
[callback, result](QDBusPendingCallWatcher *watcher) mutable {
        QDBusPendingReply<QDBusVariant> reply = *watcher;
        callback.call({reply.value().variant().toBool()});
        watcher->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &disabledUrls: qAsConst(m_itemsOnDisabledScreensMap)) {
                found = disabledUrls.contains(name);
                if (found)
                    break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMetaObject &interface : interfaceList) {
        QString ifaceName = interface.className();
        ifaceName.remove(0, ifaceName.lastIndexOf(':') + 1);
        Solid::DeviceInterface::Type ifaceDev = Solid::DeviceInterface::stringToType(ifaceName);
        const QString cleanName = Solid::DeviceInterface::typeDescription(ifaceDev);
        types.insert(ifaceDev, cleanName);

        QMap<QString, QString> deviceValues;
        for (int doneProps = propertyOffset; interface.propertyCount() > doneProps; doneProps = doneProps + 1) {
            QMetaProperty ifaceProp = interface.property(doneProps);
            deviceValues.insert(ifaceProp.name(), generateUserString(ifaceProp.name()));
        }
        values.insert(ifaceDev, deviceValues);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[inputWindow, this] {
            delete inputWindow;
            showActivitySwitcherIfNeeded();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> mapping) {
            auto values = mapping.values();
            qSort(values);
            auto uniqueValues = values.toSet().toList();
            qSort(uniqueValues);
            QVERIFY(uniqueValues == values);
        }
```

#### AUTO 


```{c}
auto &item = m_data[i];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activity : std::as_const(activities)) {
                newHistory.append(m_historyConfigGroup.readEntry(activity, QStringList()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : d->windowModels) {
        if (d->showOnlyCurrentScreen && d->screenGeometry.isValid()) {
            windowModel->setScreenGeometry(d->screenGeometry);
            windowModel->setFilterByScreen(true);
        } else {
            windowModel->setFilterByScreen(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : formats) {
        mimeCopy->setData(format, mimeData->data(format));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Consumer::ServiceStatus status) { d->setServiceStatus(status); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, dlg] (int result) {
        if (result == QDialog::Accepted) {
            const bool dialogOnlyInKde = dlg->onlyInKde();
            m_model->setData(index, dialogOnlyInKde, AutostartModel::Roles::OnlyInPlasma);
        };
    }
```

#### CONST EXPRESSION 


```{c}
constexpr static int levelCount = 4;
```

#### LAMBDA EXPRESSION 


```{c}
[this, idx, dlg](int result) {
        if (result == QDialog::Accepted) {
            reloadEntry(idx, dlg->item().localPath());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &x : set) {
        auto resp = (m_dbusIface->*(x.second))(x.first);
        resp.waitForFinished();
        if (resp.isError()) {
            setError(resp.error());
            qCWarning(KCMUSERS) << resp.error().name() << resp.error().message();
            emitResult();
            return;
        }
    }
```

#### AUTO 


```{c}
const auto entry = AutostartEntry{
        service->name(),
        service->exec(),
        AutostartEntrySource:: XdgAutoStart, // .config/autostart load desktop at startup
        true,
        desktopPath,
        false
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possibleDevice : knownDevices) {
        if (!validDevices.contains(possibleDevice)) {
            m_settings->deviceSettings(possibleDevice).deleteGroup();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const KFileItem& item, const QPixmap& pixmap) mutable {
                    Q_UNUSED(item);
                    m_wallpaperCache->insertPixmap(pixmapKey, pixmap);
                    m_previewJobs.remove(path);

                    callback.call({true});
                }
```

#### AUTO 


```{c}
auto rightIndex = ordering.indexOf(right.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (LayoutInfo *layoutInfo : qAsConst(rules->layoutInfos)) {
        layoutInfo->description = translate_description(layoutInfo);

        removeEmptyItems(layoutInfo->variantInfos);
        for (VariantInfo *variantInfo : qAsConst(layoutInfo->variantInfos)) {
            variantInfo->description = translate_description(variantInfo);
        }
    }
```

#### AUTO 


```{c}
const auto service = it.key();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : schemeDirs) {
                    const QStringList fileNames = QDir(dir).entryList(QStringList()<<QStringLiteral("*.colors"));
                    for (const QString &file : fileNames) {
                        if (file.endsWith(colorScheme + QStringLiteral(".colors"))) {
                            setColors(colorScheme, dir + QLatin1Char('/') + file);
                            schemeFound = true;
                            break;
                        }
                    }
                    if (schemeFound) {
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        Q_EMIT themeRemoved();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        m_screenMapper->removeFromMap(item.url());
        m_isDirCache.remove(item.url());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto screen : screens) {
            auto geo = screen->geometry();
            auto it =
                new QStandardItem(i18nc("model - (x,y widthxheight)", "%1 - (%2,%3 %4x%5)", screen->model(), geo.x(), geo.y(), geo.width(), geo.height()));
            it->setData(screen->name(), Qt::UserRole);
            appendRow(it);
        }
```

#### AUTO 


```{c}
auto path = listPath().at(newSource);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropTargetFolderUrl](const QUrl &url) -> QUrl {
        if (dropTargetFolderUrl != m_dirModel->dirLister()->url()) {
            QString mappedUrl = url.toString();
            const auto local = dropTargetFolderUrl.toString();
            const auto internal = m_dirModel->dirLister()->url().toString();
            if (mappedUrl.startsWith(local)) {
                mappedUrl.replace(0, local.size(), internal);
            }
            return ScreenMapper::stringToUrl(mappedUrl);
        }
        return url;
    }
```

#### AUTO 


```{c}
auto salted = crypt(cStrPlain, cStrSalt);
```

#### LAMBDA EXPRESSION 


```{c}
[data]() {
        QDBusMessage message =
            QDBusMessage::createSignal(QStringLiteral("/krunnerrc"), QStringLiteral("org.kde.kconfig.notify"), QStringLiteral("ConfigChanged"));
        const QHash<QString, QByteArrayList> changes = {
            {QStringLiteral("Runners"), {data.pluginId().toLocal8Bit()}},
        };
        message.setArguments({QVariant::fromValue(changes)});
        QDBusConnection::sessionBus().send(message);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XIDeviceInfo *info) {
        Status status;
        Atom float_type = XInternAtom (dpy, "FLOAT", False);
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        //data returned is an 1 byte boolean
        status = XIGetProperty(dpy, info->deviceid, valAtom, 0, 1,
                               False, float_type, &type_return, &format_return,
                               &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;


        if (type_return != float_type || !data || format_return != 32 || num_items_return != 1) {
            return;
        }

        unsigned char buffer[4096];
        float *sendPtr = (float*)buffer;
        *sendPtr = val;

        XIChangeProperty(dpy, info->deviceid, valAtom, float_type,
                         format_return, XIPropModeReplace, buffer, 1);

    }
```

#### AUTO 


```{c}
const auto& agent
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : qAsConst(plugins)) {
        moduleIds.insert(md.pluginId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : runnerInfos) {
        plugin.load(cfgGroup);
        if (plugin.isPluginEnabled() != plugin.isPluginEnabledByDefault()) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &activity) { d->onCurrentActivityChanged(activity); }
```

#### AUTO 


```{c}
auto it = std::find_if(radioButtons.begin(), radioButtons.end(), [=](QRadioButton *radio) {
        return radio->property("storageId") == QStringLiteral("org.kde.dolphin.desktop");
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keySequence : defaultShortcuts) {
            if (!keySequence.isEmpty()) {
                action.defaultShortcuts.insert(keySequence);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[sysName] (QObject *t) { return static_cast<KWinWaylandTouchpad*>(t)->sysName() == sysName; }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto model : models) {
                model->onBackgroundsUpdated(changedActivities);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode);
        Q_UNUSED(exitStatus);

        const auto savedThemes = QString::fromUtf8(m_editDialogProcess->readAllStandardOutput()).split(QLatin1Char('\n'), QString::SkipEmptyParts);

        if (!savedThemes.isEmpty()) {
            m_model->load(); // would be cool to just reload/add the changed/new ones

            // If the currently active scheme was edited, consider settings dirty even if the scheme itself didn't change
            if (savedThemes.contains(colorsSettings()->colorScheme())) {
                m_activeSchemeEdited = true;
                settingsChanged();
            }

            m_model->setSelectedScheme(savedThemes.last());
        }

        m_editDialogProcess->deleteLater();
        m_editDialogProcess = nullptr;
    }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(url, QUrl::fromLocalFile(tempName), -1, KIO::Overwrite);
```

#### AUTO 


```{c}
const auto index = m_folderModel->index(i, 0);
```

#### AUTO 


```{c}
auto result = d->features->SetValue(
        QStringLiteral("org.kde.ActivityManager.Resources.Scoring/isOTR/") + activity,
        QDBusVariant(isPrivate));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            emit beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            Component c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            emit endInsertRows();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &idx : persistentPendingDeletions) {
        const QString pluginName = idx.data(ThemesModel::PluginNameRole).toString();
        const QString displayName = idx.data(Qt::DisplayRole).toString();

        Q_ASSERT(pluginName != m_settings->name());

        const QStringList arguments = {QStringLiteral("-t"), QStringLiteral("theme"), QStringLiteral("-r"), pluginName};

        QProcess *process = new QProcess(this);
        connect(process, static_cast<void (QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished), this,
            [this, process, idx, pluginName, displayName](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus)
                if (exitCode == 0) {
                    m_model->removeRow(idx.row());
                } else {
                    emit showErrorMessage(i18n("Removing theme failed: %1",
                                               QString::fromLocal8Bit(process->readAllStandardOutput().trimmed())));
                    m_model->setData(idx, false, ThemesModel::PendingDeletionRole);
                }
                process->deleteLater();
            });

        process->start(program, arguments);
        process->waitForFinished(); // needed so it deletes fine when "OK" is clicked and the dialog destroyed
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.notifyrc"));
        for (const QString &file : fileNames) {
            if (notifyRcFiles.contains(file)) {
                continue;
            }

            notifyRcFiles.append(file);

            KConfig config(file, KConfig::NoGlobals);
            config.addConfigSources(QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("knotifications5/") + file));

            KConfigGroup globalGroup(&config, QLatin1String("Global"));

            const QRegularExpression regExp(QStringLiteral("^Event/([^/]*)$"));
            const QStringList groups = config.groupList().filter(regExp);

            const QString notifyRcName = file.section(QLatin1Char('.'), 0, -2);
            const QString desktopEntry = globalGroup.readEntry(QStringLiteral("DesktopEntry"));
            if (!desktopEntry.isEmpty()) {
                if (desktopEntries.contains(desktopEntry)) {
                    continue;
                }

                desktopEntries.append(desktopEntry);
            }

            SourceData source{
                // The old KCM read the Name and Comment from global settings disregarding
                // any user settings and just used user-specific files for actions config
                // I'm pretty sure there's a readEntry equivalent that does that without
                // reading the config stuff twice, assuming we care about this to begin with
                globalGroup.readEntry(QStringLiteral("Name")),
                globalGroup.readEntry(QStringLiteral("Comment")),
                globalGroup.readEntry(QStringLiteral("IconName")),
                true,
                notifyRcName,
                desktopEntry,
                {} // events
            };

            QVector<EventData> events;
            for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{cg.readEntry("Name"),
                                cg.readEntry("Comment"),
                                cg.readEntry("IconName"),
                                eventId,
                                // TODO Flags?
                                cg.readEntry("Action").split(QLatin1Char('|'))};
                events.append(event);
            }

            std::sort(events.begin(), events.end(), [&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            });

            source.events = events;

            if (!source.desktopEntry.isEmpty()) {
                appsData.append(source);
            } else {
                servicesData.append(source);
            }
        }
    }
```

#### AUTO 


```{c}
auto result = d->features->GetValue(
            QStringLiteral("org.kde.ActivityManager.Resources.Scoring/isOTR/") + activityId);
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent::any()
                    | Type::any()
                    | Activity::current()
                    | Url::startsWith("applications:");
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
        if (variant == variantInfo->description) {
            variant = variantInfo->name;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto taskModelIndex = static_cast<const WindowModel *>(index.model())->mapToSource(index);
```

#### AUTO 


```{c}
const auto shortcuts = KGlobalAccel::self()->globalShortcut(
            QStringLiteral("ActivityManager"), "switch-to-activity-" + activityId);
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString,      const QString &,      Description)
```

#### AUTO 


```{c}
const auto newFirstScreen = std::min_element(screens.constBegin(), screens.constEnd());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : settingsIncluded) {
        m_folderList.append(folderListEntry(folder, true, true));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&completed, &accessToken, &idToken](KJob *kjob) {
                    GetCredentialsJob *job = qobject_cast<GetCredentialsJob *>(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData[QStringLiteral("AccessToken")].toString();
                    idToken = credentialsData[QStringLiteral("IdToken")].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
                    //                     if (!accessToken.isEmpty()) {
                    //                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
                    //                         for (const QString& key : credentialsData.keys()) {
                    //                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                    //                         }
                    //                     }
                    completed = true;
                }
```

#### AUTO 


```{c}
const auto fileManagers = KApplicationTrader::query([] (const KService::Ptr &service) {
        if (service->exec().isEmpty()) {
            return false;
        }
        return service->categories().contains("FileManager");
    });
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandTouchpad*>(t)->isChangedConfig(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&newFileName](KIO::Job * job, const QUrl & from, const QUrl & to) {
            Q_UNUSED(job)
            Q_UNUSED(from)

            // in case the destination filename had to be renamed
            newFileName = to;
        }
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(presentWindowsName, presentWindowsPath, presentWindowsInterface, QStringLiteral("presentWindows"));
```

#### AUTO 


```{c}
const auto hours   = diff % 24;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : currentLayouts) {
			extraLayouts.removeOne(layoutUnit);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("splash.png")), ScreenhotRole);
        row->setData(pkg.metadata().comment(), DescriptionRole);
        m_model->appendRow(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : dataPaths) {
        QDir dir(path + QStringLiteral("/plasma/look-and-feel"));
        paths << dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
    }
```

#### AUTO 


```{c}
const auto oldUrl = resolvedUrl();
```

#### AUTO 


```{c}
const auto column = index.column();
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url, QStringLiteral("inode/directory"));
```

#### AUTO 


```{c}
auto cStrPlain = stdStrPlain.c_str();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& shortcut : component.shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                const QStringList actionId = buildActionId(component.uniqueName, component.friendlyName,
                        shortcut.uniqueName, shortcut.friendlyName);
                //operator int of QKeySequence
                QList<int> keys(shortcut.activeShortcuts.cbegin(), shortcut.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << shortcut.activeShortcuts << keys;
                auto watcher = new QDBusPendingCallWatcher(m_globalAccelInterface->setForeignShortcut(actionId, keys));
                connect(watcher, &QDBusPendingCallWatcher::finished, this, [&, watcher] {
                    QDBusPendingReply<> reply = *watcher;
                    if (!reply.isValid()) {
                        qCCritical(KCMKEYS) << "Error while saving";
                        if (reply.error().isValid()) {
                            qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                        }
                        emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                            "Error while saving shortcut %1: %2", component.friendlyName, shortcut.friendlyName));
                    } else {
                        shortcut.initialShortcuts = shortcut.activeShortcuts;
                    }
                    watcher->deleteLater();
                });
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &file) { settingsFileChanged(file); }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Action &a) {
                return a.id == key;
            }
```

#### AUTO 


```{c}
auto findWindows = [this](const auto &windowIds) -> QVector<QModelIndex> {
        QVector<QModelIndex> indices;
        for (const auto &id : windowIds) {
            for (int i = 0; i < d->tasksModel->rowCount(); ++i) {
                const QModelIndex &idx = d->tasksModel->index(i, 0);
                const QVariantList &winIds = idx.data(TaskManager::AbstractTasksModel::WinIdList).toList();
                if (!winIds.isEmpty() && winIds.at(0).value<typename std::remove_reference_t<decltype(windowIds)>::value_type>() == id) {
                    indices.push_back(idx);
                    break;
                }
            }
        }
        return indices;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : deselectedIndices) {
            delete m_dragImages.take(index.row());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QKeyEvent *event) {
        Q_ASSERT(event);
        if (event->nativeScanCode() == nativeScanCode) {
            pressed = event->type() == QKeyEvent::KeyPress;
            Q_EMIT pressedChanged();
        }
    }
```

#### AUTO 


```{c}
const auto name = index.data(FolderModel::UrlRole).toString();
```

#### AUTO 


```{c}
auto conf = KSharedConfig::openConfig();
```

#### AUTO 


```{c}
const auto groupList = config.groupList();
```

#### AUTO 


```{c}
const auto administrator = (m_dbusIface->accountType() == 1);
```

#### LAMBDA EXPRESSION 


```{c}
[this,file] (const KFileItem& item, const QPixmap& pixmap) {
                    Q_UNUSED(item);

                    auto image = pixmap.toImage();

                    m_texture = QQuickTextureFactory::textureFactoryForImage(image);
                    emit finished();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionDir : actionDirs) {
        QDirIterator it(actionDir, QStringList() << QStringLiteral("*.desktop"));
        while (it.hasNext()) {
            it.next();
            const QString desktop = it.filePath();
            // Get contained services list
            const QList<KServiceAction> services = KDesktopFileActions::userDefinedServices(desktop, true);
            for (const KServiceAction &deviceAction : services) {
                ActionItem * actionItem = new ActionItem( desktop, deviceAction.name(), this ); // Create an action
                d->actions.append( actionItem );
            }
        }
    }
```

#### AUTO 


```{c}
auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values;
            uniqueValues.erase(std::unique(uniqueValues.begin(), uniqueValues.end()), uniqueValues.end());
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_model->load();

            const auto newEntries = m_newStuffDialog->installedEntries();
            // If one new theme was installed, select the first color file in it
            if (newEntries.count() == 1) {
                QStringList installedThemes;

                const QString suffix = QStringLiteral(".colors");

                for (const QString &path : newEntries.first().installedFiles()) {
                    const QString fileName = path.section(QLatin1Char('/'), -1, -1);

                    const int suffixPos = fileName.indexOf(suffix);
                    if (suffixPos != fileName.length() - suffix.length()) {
                        continue;
                    }

                    installedThemes.append(fileName.left(suffixPos));
                }

                if (!installedThemes.isEmpty()) {
                    // The list is sorted by (potentially translated) name
                    // but that would require us parse every file, so this should be close enough
                    std::sort(installedThemes.begin(), installedThemes.end());

                    m_model->setSelectedScheme(installedThemes.constFirst());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::DeviceInterface::Type internalType : interfaceTypes) {
        const QString typeName = Solid::DeviceInterface::typeToString(internalType);
        KDesktopFile typeFile(QStandardPaths::GenericDataLocation, "solid/devices/solid-device-" + typeName + ".desktop");
        KConfigGroup tConfig = typeFile.desktopGroup();

        tConfig.writeEntry("Name", "Solid Device");
        tConfig.writeEntry("X-KDE-ServiceTypes", "SolidDevice");
        tConfig.writeEntry("Type", "Service");

        if (!tConfig.hasKey("X-KDE-Solid-Actions-Type")) {
            tConfig.writeEntry("X-KDE-Solid-Actions-Type", typeName);
        }

        const QStringList typeValues = availActions->propertyInternalList(internalType);
        const QString actionText = typeValues.join(QLatin1Char(';')).append(";");
        tConfig.writeEntry("Actions", actionText);

        for (const QString &tValue : typeValues) {
            KConfigGroup vConfig = typeFile.actionGroup(tValue);
            if (!vConfig.hasKey("Name")) {
                vConfig.writeEntry("Name", availActions->propertyName(internalType, tValue));
            }
            vConfig.sync();
        }
        tConfig.sync();
        typeFile.sync();
    }
```

#### AUTO 


```{c}
const auto &containmentId
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto query: queries) {
        result = execQuery(query);
    }
```

#### AUTO 


```{c}
auto query = UsedResources
            | Agent(agent)
            | Type::any()
            | Activity::current()
            | Url::file();
```

#### AUTO 


```{c}
const auto keys = components.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
                m_dropTargetPositions.insert(url.fileName(), dropPos);
                m_screenMapper->addMapping(mappableUrl(url), m_screen, ScreenMapper::DelayedSignal);
                m_screenMapper->removeItemFromDisabledScreen(mappableUrl(url));
            }
```

#### AUTO 


```{c}
const auto pendingDeletions = m_model->match(m_model->index(0, 0), PendingDeletionRole, true, -1 /*all*/);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob *copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone, this, [map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone, this, [map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### AUTO 


```{c}
const auto blockedApplicationsItem = d->pluginConfig->findItem("allowedApplications");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& lang : missingLanguages) {
        m_configuredLanguages.removeOne(lang);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &shortcutInfo : allShortcuts) {
            if (shortcutInfo.defaultKeys() != shortcutInfo.keys()) {
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ptr] (const InfoPtr &info) {
            return ptr == info.get();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& key : keys) {
        KStandardShortcut::StandardShortcut id = KStandardShortcut::findByName(key);
        if (id == KStandardShortcut::AccelNone) {
            qCWarning(KCMKEYS) << "Unknown standard shortcut" << key;
            continue;
        }
        QString name;
        switch(category(id)) {
            case KStandardShortcut::Category::File: name = "File"; break;
            case KStandardShortcut::Category::Edit: name = "Edit"; break;
            case KStandardShortcut::Category::Navigation: name = "Navigation"; break;
            case KStandardShortcut::Category::View: name = "View"; break;
            case KStandardShortcut::Category::Settings: name = "Settings"; break;
            case KStandardShortcut::Category::Help: name = "Help"; break;
        }
        auto cat = std::find_if(m_components.begin(), m_components.end(), [&name] (const Component &c) {
            return c.id == name;
        });
        if (cat == m_components.end()) {
            qCWarning(KCMKEYS) << "No category for standard shortcut" << key;
            continue;
        }
        auto action = std::find_if(cat->actions.begin(), cat->actions.end(), [&] (const Action &a) {
            return a.id == key;
        });
        if (action == cat->actions.end()) {
            qCWarning(KCMKEYS) << "Model doesn't include action" << key;
            continue;
        }
        const auto shortcuts = QKeySequence::listFromString(group.readEntry(key));
        const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
        if (shortcutsSet != action->activeShortcuts) {
            action->activeShortcuts = shortcutsSet;
            const QModelIndex i = index(action - cat->actions.begin(), 0, index(cat-m_components.begin(), 0));
            Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : recent) {
            m_emoji += { c, recentDescriptions.at(i++), QString{}, {} };
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &xkbOption : qAsConst(xkbConfig.options)) {
            keyboardConfig->xkbOptions.append(xkbOption);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : emailClients) {

        emailClientsCombo->addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if (emailClientService && emailClientService->storageId() == service->storageId()) {
            emailClientsCombo->setCurrentIndex(emailClientsCombo->count() - 1);
            m_currentIndex = emailClientsCombo->count() - 1;
        }
        if (service->storageId() == QStringLiteral("org.kde.kmail2.desktop") ||
                service->storageId() == QStringLiteral("org.kde.kmail.desktop")) {
            m_kmailIndex = emailClientsCombo->count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto w = QX11Info::appRootWindow();
```

#### AUTO 


```{c}
const auto whatToRemember =
        d->radioRememberSpecificApplications->isChecked() ? SpecificApplications :
        d->radioDontRememberApplications->isChecked()     ? NoApplications :
        /* otherwise */                                     AllApplications;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& lang : m_translationsModel->missingLanguages()) {
        m_configuredLanguages.removeOne(lang);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath &path : users) {
        User *user = new User(this);
        user->setPath(path);

        const std::list<QPair<void (User::*const)(), int>> set = {
            {&User::uidChanged, UidRole},
            {&User::nameChanged, NameRole},
            {&User::faceValidChanged, FaceValidRole},
            {&User::realNameChanged, RealNameRole},
            {&User::emailChanged, EmailRole},
            {&User::administratorChanged, AdministratorRole},
        };

        for (const auto &item : set) {
            connect(user, item.first, [this, user, item] {
                auto idx = index(m_userList.lastIndexOf(user));
                Q_EMIT dataChanged(idx, idx, {item.second});
            });
        }

        m_userList.append(user);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[q](QScreen *screen) {
        QObject::connect(screen, &QScreen::geometryChanged, q, &PagerModel::pagerItemSizeChanged);
        Q_EMIT q->pagerItemSizeChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : runtimeExcluded) {
        if (settingsIncluded.contains(folder) || settingsExcluded.contains(folder)) {
            // Do not add any duplicates
            continue;
        }
        if (m_deletedSettings.contains(folder)) {
            // Skip entries deleted from the config
            continue;
        }
        m_folderList.append(folderListEntry(folder, false, false));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : qAsConst(ucs4Str)) {
            if (!QChar::isPrint(c) && !(c == 0) && !(QChar::category(c) == QChar::Other_PrivateUse)) {
                str = "";
                break;
            }
        }
```

#### AUTO 


```{c}
const auto idx = index(i, 0, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<void> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            emit errorMessage(i18n("Failed to notify KDE Service Manager (kded5) of saved changed: %1", reply.error().message()));
            return;
        }

        qCDebug(KCM_KDED) << "Successfully reconfigured kded";
        getModuleStatus();
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QStringList activities = m_consumer->activities(); activities.size() == 1) {
        return KActivities::Info(activities.constFirst()).name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *info : qAsConst(variantInfos)) {
		if( info->languages.contains(lang) )
			return true;
	}
```

#### AUTO 


```{c}
const auto keys = keybehaviourNames.keys();
```

#### AUTO 


```{c}
auto *behaviorSettings
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &currentActivity) {
                qCDebug(KICKER_DEBUG) << "Activity just got changed to" << currentActivity;
                Q_UNUSED(currentActivity);
                if (d) {
                    auto clientId = d->m_clientId;
                    initForClient(clientId);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : actions) {
            QStandardItem *item = new QStandardItem();
            item->setData(QUrl(QStringLiteral("kcm:%1.desktop").arg(action.name())), ResultModel::ResourceRole);
            m_defaultModel->appendRow(item);
        }
```

#### AUTO 


```{c}
const auto service = KService::serviceByDesktopName(name);
```

#### AUTO 


```{c}
const auto url = entry->url();
```

#### LAMBDA EXPRESSION 


```{c}
[sysName](QObject *t) {
            return static_cast<KWinWaylandDevice *>(t)->sysName() == sysName;
        }
```

#### AUTO 


```{c}
auto destPath = dropTargetUrl.path();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &str : list) {
        str = normalizeTrailingSlashes(std::move(str));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Finger *finger : FINGERS) {
        if (!enrolledFingerprintsRaw().contains(finger->internalName())) {
            list.append(QVariant::fromValue(finger));
        }
    }
```

#### AUTO 


```{c}
auto keyrelease = reinterpret_cast<xcb_key_release_event_t *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this, process, idx, pluginName, displayName](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus);
                if (exitCode == 0) {
                    m_model->removeRow(idx.row());
                } else {
                    emit showErrorMessage(i18n("Removing theme failed: %1",
                                               QString::fromLocal8Bit(process->readAllStandardOutput().trimmed())));
                    m_model->setData(idx, false, PendingDeletionRole);
                }
                process->deleteLater();
            }
```

#### AUTO 


```{c}
auto job = new KTerminalLauncherJob(script);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : groupNameList) {
        KConfigGroup groupEffectOut(m_config, groupName);
        KConfigGroup groupEffectTheme(config, groupName);

        for (const QString &effect : effectList) {
            groupEffectOut.writeEntry(effect, groupEffectTheme.readEntry(effect));
        }
    }
```

#### AUTO 


```{c}
auto setNewModel = [this, model]() {
        disconnectSignals();
        m_sourceModel = model;
        connectSignals();
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& urlFilter: query.urlFilters()) {
            urlFilters << Common::starPatternToRegex(urlFilter);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int screenId) {
                removeScreen(screenId, {});
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", "preview.png"), ScreenhotRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "KDE");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            row->setData(hasColors, HasColorsRole);
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);
        }

        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
const auto configExtraLayouts = keyboardConfig->getExtraLayouts();
```

#### AUTO 


```{c}
const auto name = d->applications[i].name;
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandTouchpad *>(t)->getConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &containmentId : plasmaConfigContainments().groupList()) {
            const auto containment = plasmaConfigContainments().group(containmentId);
            const auto lastScreen = containment.readEntry("lastScreen", 0);
            const auto activity = containment.readEntry("activityId", QString());

            // Ignore the containment if the activity is not defined
            if (activity.isEmpty())
                continue;

            // If we have already found the same activity from another
            // containment, we are using the new one only if
            // the previous one was a color and not a proper wallpaper,
            // or if the screen ID is closer to zero
            const bool processed = !ghostActivities.contains(activity) && newForActivity.contains(activity) && (lastScreenForActivity[activity] <= lastScreen);

            // qDebug() << "GREPME Searching containment " << containmentId
            //          << "for the wallpaper of the " << activity << " activity - "
            //          << "currently, we think that the wallpaper is " << processed << (processed ? newForActivity[activity] : QString())
            //          << "last screen is" << lastScreen
            //          ;

            if (processed && newForActivity[activity][0] != QLatin1Char{'#'})
                continue;

            // Marking the current activity as processed
            ghostActivities.removeAll(activity);

            const auto background = backgroundFromConfig(containment);

            // qDebug() << "        GREPME Found wallpaper: " << background;

            if (background.isEmpty())
                continue;

            // If we got this far and we already had a new wallpaper for
            // this activity, it means we now have a better one
            bool foundBetterWallpaper = changedActivities.contains(activity);

            if (foundBetterWallpaper || newForActivity[activity] != background) {
                if (!foundBetterWallpaper) {
                    changedActivities << activity;
                }

                // qDebug() << "        GREPME Setting: " << activity << " = " << background << "," << lastScreen;
                newForActivity[activity] = background;
                lastScreenForActivity[activity] = lastScreen;
            }
        }
```

#### AUTO 


```{c}
const auto aaState = xft.getAntiAliasing();
```

#### AUTO 


```{c}
const auto service = dlg.service();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : watchedList) {
        if (allServices.contains(service)) {
            serviceRegistered(service);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : qAsConst(services))
	{
		KConfig cfg(service, KConfig::SimpleConfig);
		KConfigGroup cg = cfg.group(QByteArray());
		QListWidgetItem *item = new QListWidgetItem(
			QIcon::fromTheme(cg.readEntry("Icon",QStringLiteral("preferences-desktop-default-applications"))), 
			cg.readEntry("Name",i18n("Unknown")));
		item->setData(Qt::UserRole, service);
		ServiceChooser->addItem(item);
		loadConfigWidget(service, cfg.group(QByteArray()).readEntry("configurationType"), item->text());
	}
```

#### AUTO 


```{c}
const auto &defaultShortcuts = index.data(ShortcutsModel::DefaultShortcutsRole).value<QSet<QKeySequence>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &window : windows) {
        KWindowInfo info(window, NET::WMVisibleName, NET::WM2Activities);
        const QStringList activities = info.activities();

        if (activities.isEmpty() || activities.contains("00000000-0000-0000-0000-000000000000"))
            continue;

        for (const auto &activity : activities) {
            m_activitiesWindows[activity] << window;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                endInsertRows();
                emit countChanged();
            }
```

#### AUTO 


```{c}
auto resp = m_dbusIface->SetIconFile(file.fileName());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                beginResetModel();
            }
```

#### AUTO 


```{c}
auto cookie = xcb_get_modifier_mapping(QX11Info::connection());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int screenId) {
                addScreen(screenId, {});
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, lineEdit]() {
			Q_EMIT const_cast<LabelEditDelegate*>(this)->commitData(lineEdit);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto groupEntry : { QStringLiteral("Applications"), QStringLiteral("Services") }) {
        KConfigGroup group(&config, groupEntry);
        for (const QString &desktopEntry : group.groupList()) {
            m_behaviorSettingsList.insert(m_behaviorSettingsList.count(), new NotificationManager::BehaviorSettings(groupEntry, desktopEntry, this));
        }
    }
```

#### AUTO 


```{c}
auto valueFutureInterface = new ValueFutureInterface<void>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &mod : modules) {
		qCDebug(KCM_KDED) << "saving settings for kded module" << mod.metaDataFileName();
		// autoload defaults to false if it is not found
		const bool autoload = mod.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();
		if (autoload) {
			const QString libraryName = mod.fileName();
			int count = _lvStartup->topLevelItemCount();
			for(int i = 0; i < count; ++i) {
				QTreeWidgetItem *treeitem = _lvStartup->topLevelItem(i);
				if ( treeitem->data(StartupService, LibraryRole ).toString() == libraryName) {
					// we found a match, now compare and see what changed
					setAutoloadEnabled(&kdedrc, mod, treeitem->checkState( StartupUse ) == Qt::Checked);
					break;
				}
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c) {
        return c.uniqueName == uniqueName;
    }
```

#### AUTO 


```{c}
const auto statisticsConfig
        = d->pluginConfig->group(SQLITE_PLUGIN_CONFIG_KEY);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &themeName : themes) {
        KIconTheme theme(themeName);
        if (!theme.isValid()) {
            //qCWarning(KCM_ICONS) << "Not a valid theme" << themeName;
        }
        if (theme.isHidden()) {
            continue;
        }

        IconsModelData item{
            theme.name(),
            themeName,
            theme.description(),
            themeName != KIconTheme::defaultThemeName()
                && QFileInfo(theme.dir()).isWritable(),
            false // pending deletion
        };

        m_data.append(item);
    }
```

#### AUTO 


```{c}
auto diff = now - time;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &list : matchesForRunner) {
        std::sort(list.begin(), list.end(), qGreater<Plasma::QueryMatch>());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &f: dir.entryList(QStringList("*.desktop"))) {
        services += dir.absoluteFilePath(f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &prop : m_props) {
        if (prop.toMap()[QStringLiteral("key")] == property.key) {
            prop = property.toMap();
            emit propertiesChanged();
            break;
        }
    }
```

#### AUTO 


```{c}
const auto resource    = result.resource();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &themeName : themes) {
        KIconTheme theme(themeName);

        for (const QString &iconName : iconNames) {
            QString path = theme.iconPath(QStringLiteral("%1.png").arg(iconName), iconSize, KIconLoader::MatchBest);
            if (!path.isEmpty()) {
                QPixmap pixmap(path);
                pixmap.setDevicePixelRatio(dpr);
                return pixmap;
            }

            //could not find the .png, try loading the .svg or .svgz
            path = theme.iconPath(QStringLiteral("%1.svg").arg(iconName), iconSize, KIconLoader::MatchBest);
            if (path.isEmpty()) {
                path = theme.iconPath(QStringLiteral("%1.svgz").arg(iconName), iconSize, KIconLoader::MatchBest);
            }

            if (path.isEmpty()) {
                continue;
            }

            if (!renderer.load(path)) {
                continue;
            }

            QPixmap pixmap(iconSize, iconSize);
            pixmap.setDevicePixelRatio(dpr);
            pixmap.fill(QColor(Qt::transparent));
            QPainter p(&pixmap);
            p.setViewport(0, 0, size, size);
            renderer.render(&p);
            return pixmap;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[cachePathProcess](int exitCode, QProcess::ExitStatus status) {

        if (status == QProcess::NormalExit && exitCode == 0) {
            QString path = cachePathProcess->readAllStandardOutput().trimmed();
            path.append(QLatin1String("icon-cache.kcache"));
            QFile::remove(path);
        }

        //message kde4 apps that icon theme is changed
        for (int i = 0; i < KIconLoader::LastGroup; i++) {
            KIconLoader::emitChange(KIconLoader::Group(i));

            QDBusMessage message = QDBusMessage::createSignal(QStringLiteral("/KGlobalSettings"),
                                                              QStringLiteral("org.kde.KGlobalSettings"),
                                                              QStringLiteral("notifyChange"));
            message.setArguments({
                4, // KGlobalSettings::IconChanged
                KIconLoader::Group(i)
            });
            QDBusConnection::sessionBus().send(message);
        }

        cachePathProcess->deleteLater();
    }
```

#### AUTO 


```{c}
const auto type =  idx.data(ThemesModel::ColorTypeRole).value<ThemesModel::ColorType>();
```

#### AUTO 


```{c}
const auto destination = destinationFor(result);
```

#### AUTO 


```{c}
auto windowModel
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : std::as_const(engineList)) {
        engine_names[i] = g_strdup(name.toUtf8().constData());
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : mimeData->formats()) {
        mimeCopy->setData(format, mimeData->data(format));
    }
```

#### AUTO 


```{c}
const auto config = d->pluginConfig->group(SQLITE_PLUGIN_CONFIG_KEY);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : themes) {
        emit showProgress(i18n("Installing %1 theme...", theme));

        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);

        currentTheme = dynamic_cast<KArchiveDirectory*>(const_cast<KArchiveEntry*>(rootDir->entry(theme)));
        if (!currentTheme) {
            // we tell back that something went wrong, but try to install as much
            // as possible
            everythingOk = false;
            continue;
        }

        currentTheme->copyTo(localThemesDir + theme);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : qAsConst(m_components)) {
        if (component.pendingDeletion) {
            return true;
        }
        for (const auto& action : qAsConst(component.actions)) {
            if (action.initialShortcuts != action.activeShortcuts) {
                return true;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandTouchpad *>(t)->isChangedConfig();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int first, int last) {
        for (int i = first; i <= last; ++i) {
            const auto idx = index(i, 0, parent);
            const auto url = itemForIndex(idx).url();
            auto it = m_dropTargetPositions.find(url.fileName());
            if (it != m_dropTargetPositions.end()) {
                const auto pos = it.value();
                m_dropTargetPositions.erase(it);
                setSortMode(-1);
                emit move(pos.x(), pos.y(), {url});
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
            if (isDefaultLayoutConfig(layoutMemory.layoutMap[key], layoutMemory.keyboardConfig.getDefaultLayouts())) {
                continue;
            }

            QDomElement item = doc.createElement(ITEM_NODE);
            item.setAttribute(OWNER_KEY_ATTRIBUTE, key);
            item.setAttribute(CURRENT_LAYOUT_ATTRIBUTE, layoutMemory.layoutMap[key].currentLayout.toString());

            QString layoutSetString;
            const QList<LayoutUnit> layouts = layoutMemory.layoutMap[key].layouts;
            for (const LayoutUnit &layoutUnit : layouts) {
                if (!layoutSetString.isEmpty()) {
                    layoutSetString += LIST_SEPARATOR_LM;
                }
                layoutSetString += layoutUnit.toString();
            }
            item.setAttribute(LAYOUTS_ATTRIBUTE, layoutSetString);
            root.appendChild(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : schemeDirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList{QStringLiteral("*.colors")});
        for (const QString &file : fileNames) {
            const QString suffixedFileName = QLatin1String("color-schemes/") + file;
            // can't use QSet because of the transform below (passing const QString as this argument discards qualifiers)
            if (!schemeFiles.contains(suffixedFileName)) {
                schemeFiles.append(suffixedFileName);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[sysName](InputDevice *t) {
        return t->sysName() == sysName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&completed, &accessToken, &idToken](KJob *kjob) {
                    GetCredentialsJob *job = qobject_cast<GetCredentialsJob *>(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData["AccessToken"].toString();
                    idToken = credentialsData["IdToken"].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
                    //                     if (!accessToken.isEmpty()) {
                    //                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
                    //                         for (const QString& key : credentialsData.keys()) {
                    //                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                    //                         }
                    //                     }
                    completed = true;
                }
```

#### AUTO 


```{c}
const auto defaultBlockedValue = config.readEntry("blocked-by-default", false);
```

#### AUTO 


```{c}
auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            qSort(values);
            auto uniqueValues = values.toSet().toList();
            qSort(uniqueValues);
            QVERIFY(uniqueValues == values);
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob* copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone,
                this, [this, map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone,
                this, [this, map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### AUTO 


```{c}
auto statisticsConfig = d->pluginConfig->group(SQLITE_PLUGIN_CONFIG_KEY);
```

#### AUTO 


```{c}
auto foundStorageId = m_dataSourceToStorageId.constFind(sourceName);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            switchToNextLayout();

            LayoutUnit newLayout = X11Helper::getCurrentLayout();
            QDBusMessage msg = QDBusMessage::createMethodCall(QStringLiteral("org.kde.plasmashell"),
                                                              QStringLiteral("/org/kde/osdService"),
                                                              QStringLiteral("org.kde.osdService"),
                                                              QStringLiteral("kbdLayoutChanged"));
            msg << Flags::getLongText(newLayout, rules);
            QDBusConnection::sessionBus().asyncCall(msg);
        }
```

#### AUTO 


```{c}
auto call = (status == NotRunning ? m_kdedInterface->unloadModule(moduleName) : m_kdedInterface->loadModule(moduleName));
```

#### LAMBDA EXPRESSION 


```{c}
[](const NotificationManager::BehaviorSettings *settings) {
                                      return !settings->isDefaults();
                                  }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotOpenShareFileDialog();
            }
```

#### AUTO 


```{c}
auto reply = timedateIface.SetNTP(dtime->ntpEnabled(), true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPackage::Package &pkg : pkgs) {
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginId(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("splash.png")), ScreenshotRole);
        row->setData(pkg.metadata().description(), DescriptionRole);
        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
auto result = d->features->SetValue(QStringLiteral("org.kde.ActivityManager.Resources.Scoring/isOTR/") + activity, QDBusVariant(isPrivate));
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(appViewName, appViewPath, appViewInterface, QStringLiteral("activate"));
```

#### AUTO 


```{c}
auto action = std::find_if(component->actions.begin(), component->actions.end(), [&](const Action &a) {
                return a.id == key;
            });
```

#### AUTO 


```{c}
const auto &component
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("splash.png")), ScreenhotRole);
        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
auto *toAdd = new NotificationManager::BehaviorSettings(typeName, groupName, this);
```

#### AUTO 


```{c}
auto uniqueValues = values;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        update();
    }
```

#### AUTO 


```{c}
auto *l = leave;
```

#### AUTO 


```{c}
const auto shortcut = KGlobalAccel::self()->shortcut(action);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *behaviorSettings : qAsConst(m_behaviorSettingsList)) {
        behaviorSettings->setDefaults();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(m_supported)) {
        QVariantHash::ConstIterator i = p.find(name);
        if (i == p.end()) {
            continue;
        }
        const Parameter *par = findParameter(name);
        if (par) {
            QVariant value(i.value());

            double k = getPropertyScale(name);
            if (k != 1.0) {
                bool ok = false;
                value = QVariant(value.toDouble(&ok) * k);
                if (!ok) {
                    error = true;
                    continue;
                }
            }

            if (m_negate.contains(name)) {
                QVariantHash::ConstIterator i = p.find(m_negate[name]);
                if (i != p.end() && i.value().toBool()) {
                    value = negateVariant(value);
                }
            }

            if (name == "CoastingSpeed") {
                QVariantHash::ConstIterator coastingEnabled = p.find("Coasting");
                if (coastingEnabled != p.end() && !coastingEnabled.value().toBool()) {
                    value = QVariant(0);
                }
            }

            if (!setParameter(par, value)) {
                error = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &lu : keyboardConfig.layouts) {
        if (layoutUnit.layout() == lu.layout() && layoutUnit.variant() == lu.variant()) {
            layoutText = lu.getDisplayName();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandTouchpad*>(t)->getDefaultConfig(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigGroup *possibleGroup : values) {
            if (possibleGroup->hasKey(keyName)) {
                return possibleGroup;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KService::Ptr &service) {
        if (service->exec().isEmpty()) {
            return false;
        }
        return service->categories().contains("FileManager");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLatin1String &name : qAsConst(m_changed)) {
        m_props[name].set();
    }
```

#### AUTO 


```{c}
auto config = d->pluginConfig->group(SQLITE_PLUGIN_CONFIG_KEY);
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
            QListWidgetItem *newItem = new QListWidgetItem(variantInfo->description);
            if (flags) {
                newItem->setIcon(icon);
            }
            newItem->setData(LayoutNameRole, layoutInfo->name);
            newItem->setData(VariantNameRole, variantInfo->name);
            layoutDialogUi->layoutListWidget->addItem(newItem);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        loadData();
    }
```

#### AUTO 


```{c}
const auto path2 = QStringLiteral("desktop:/Foo2");
```

#### RANGE FOR STATEMENT 


```{c}
for (const AutostartEntry &e : qAsConst(m_entries)) {
        if (e.source == XdgAutoStart) {
            index++;
        } else {
            break;
        }
    }
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent::any()
                    | Type::any()
                    | Activity::current()
                    | Url::file()
                    | Limit(15);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : schemeDirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList{QStringLiteral("*.colors")});
        for (const QString &file : fileNames) {
            const QString suffixedFileName = QStringLiteral("color-schemes/") + file;
            // can't use QSet because of the transform below (passing const QString as this argument discards qualifiers)
            if (!schemeFiles.contains(suffixedFileName)) {
                schemeFiles.append(suffixedFileName);
            }
        }
    }
```

#### AUTO 


```{c}
auto query = database.exec(QStringLiteral("SELECT DISTINCT(initiatingAgent) FROM ResourceScoreCache ORDER BY initiatingAgent"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, bool urgent) {
        if (uri.isEmpty() || m_storageId == uri) {
            setUrgent(urgent);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, notifySignal] { emit (this->*notifySignal)(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, myProcess](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus);
                if (exitCode == 0) {
                    emit showSuccessMessage(i18n("Theme installed successfully."));
                    load();
                } else {
                    Q_EMIT showErrorMessage(i18n("Theme installation failed."));

                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : info) {
        const QString &actionUnique = action.uniqueName();
        const QString &actionFriendly = action.friendlyName();
        Shortcut shortcut;
        shortcut.uniqueName = actionUnique;
        shortcut.friendlyName = actionFriendly;
        const QList<QKeySequence> defaultShortcuts = action.defaultKeys();
        for (const auto  &keySequence : defaultShortcuts) {
            if (!keySequence.isEmpty()) {
                shortcut.defaultShortcuts.insert(keySequence);
            }
        }
        const QList<QKeySequence> activeShortcuts = action.keys();
        for (const QKeySequence &keySequence : activeShortcuts) {
            if (!keySequence.isEmpty()) {
                shortcut.activeShortcuts.insert(keySequence);
            }
        }
        shortcut.initialShortcuts = shortcut.activeShortcuts;
        c.shortcuts.push_back(shortcut);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &v : std::as_const(data)) {
                    Property prop = v.value<Property>();
                    prop_list << prop;
                }
```

#### AUTO 


```{c}
auto value = resultSet->d->currentResult();
```

#### LAMBDA EXPRESSION 


```{c}
[this, map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        }
```

#### AUTO 


```{c}
const auto isKeyboardRepeatDefault = defaultValueKeyboardRepeat() == KeyBehaviour(_keyboardRepeatButtonGroup->checkedId());
```

#### AUTO 


```{c}
const auto& result
```

#### AUTO 


```{c}
const auto activityRight =
          sourceModel()->data(sourceRight, KActivities::ActivitiesModel::ActivityId).toString();
```

#### AUTO 


```{c}
auto geo = screen->geometry();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto screen : screens) {
        totalRect |= screen->geometry();
    }
```

#### AUTO 


```{c}
const auto file = QUrl::fromUserInput(m_id);
```

#### AUTO 


```{c}
const auto& shortcut
```

#### AUTO 


```{c}
const auto &entry = m_entries.at(index.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        KFileItem item = itemForIndex(index);
        if (!item.isNull()) {
            items.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& component : m_components) {
        for (auto& action : component.actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                QList<QKeySequence> keys(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                KStandardShortcut::saveShortcut(KStandardShortcut::findByName(action.id), keys);
                action.initialShortcuts = action.activeShortcuts;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tValue : typeValues) {
            KConfigGroup vConfig = typeFile.actionGroup( tValue );
            if( !vConfig.hasKey("Name") ) {
                vConfig.writeEntry( "Name", availActions->propertyName( internalType, tValue ) );
            }
            vConfig.sync();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, key]() {
                deleteHistoryGroup(key);
            }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(m_globalAccelInterface->getComponent(desktopFileName));
```

#### AUTO 


```{c}
auto folderListEntry = [&homePath](const QString &url, bool include, bool fromConfig) {
        QString displayName = url;
        if (displayName.size() > 1) {
            displayName.chop(1);
        }
        if (displayName.startsWith(homePath)) {
            displayName.replace(0, homePath.length(), QStringLiteral("~/"));
        }

        QString icon = QStringLiteral("folder");
        if (url == homePath) {
            icon = QStringLiteral("user-home");
        } else if (!fromConfig) {
            icon = QStringLiteral("drive-harddisk");
        }

        return FolderInfo{url, displayName, icon, include, fromConfig};
    };
```

#### AUTO 


```{c}
auto update = [=]() {
        bool userDataChanged = false;
        if (mUid != m_dbusIface->uid()) {
            mUid = m_dbusIface->uid();
            userDataChanged = true;
            Q_EMIT uidChanged(mUid);
        }
        if (mName != m_dbusIface->userName()) {
            mName = m_dbusIface->userName();
            userDataChanged = true;
            Q_EMIT nameChanged(mName);
        }
        if (mFace != QUrl(m_dbusIface->iconFile())) {
            mFace = QUrl(m_dbusIface->iconFile());
            mFaceValid = QFileInfo::exists(mFace.toString());
            userDataChanged = true;
            Q_EMIT faceChanged(mFace);
            Q_EMIT faceValidChanged(mFaceValid);
        }
        if (mRealName != m_dbusIface->realName()) {
            mRealName = m_dbusIface->realName();
            userDataChanged = true;
            Q_EMIT realNameChanged(mRealName);
        }
        if (mEmail != m_dbusIface->email()) {
            mEmail = m_dbusIface->email();
            userDataChanged = true;
            Q_EMIT emailChanged(mEmail);
        }
        const auto administrator = (m_dbusIface->accountType() == 1);
        if (mAdministrator != administrator) {
            mAdministrator = administrator;
            userDataChanged = true;
            Q_EMIT administratorChanged(mAdministrator);
        }
        const auto loggedIn = (mUid == getuid());
        if (mLoggedIn != loggedIn) {
            mLoggedIn = loggedIn;
            userDataChanged = true;
        }
        if (userDataChanged) {
            Q_EMIT dataChanged();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, action, url, launcherUrl] {
            KService::Ptr service = KService::serviceByDesktopPath(launcherUrl.toLocalFile());
            if (!service) {
                return;
            }

            KRun::runService(*service, {url}, QApplication::activeWindow());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : qAsConst(indices)) {
        if (d->pagerType == VirtualDesktops) {
            if (!index.data(TaskManager::AbstractTasksModel::IsOnAllVirtualDesktops).toBool()) {
                d->tasksModel->requestVirtualDesktops(index, {itemId});
            }
        } else {
            QString newActivity = itemId.toString();
            const QStringList &runningActivities = d->activityInfo->runningActivities();

            if (!runningActivities.contains(newActivity)) {
                return;
            }

            QStringList activities = index.data(TaskManager::AbstractTasksModel::Activities).toStringList();

            if (modifiers & Qt::ControlModifier) { // 'copy' => add to activity
                if (!activities.contains(newActivity)) {
                    activities << newActivity;
                }
            } else { // 'move' to activity
                // if on only one activity, set it to only the new activity
                // if on >1 activity, remove it from the current activity and add it to the new activity
                const QString currentActivity = d->activityInfo->currentActivity();
                activities.removeAll(currentActivity);
                activities << newActivity;
            }
            d->tasksModel->requestActivities(index, activities);
        }
    }
```

#### AUTO 


```{c}
auto entry = m_entries.at(index.row());
```

#### AUTO 


```{c}
const auto &result = d->cache[row];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        KPackage::Package pkg = KPackage::PackageLoader::self()->loadPackage(QStringLiteral("Plasma/LookAndFeel"));
        pkg.setPath(path);
        pkg.setFallbackPackage(KPackage::Package());
        if (components.isEmpty()) {
            packages << pkg;
        } else {
            for (const auto &component : components) {
                if (!pkg.filePath(component.toUtf8()).isEmpty()) {
                    packages << pkg;
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto configureScreen = [q](QScreen* screen) {
        QObject::connect(screen, &QScreen::geometryChanged, q, &PagerModel::pagerItemSizeChanged);
        Q_EMIT q->pagerItemSizeChanged();
    };
```

#### AUTO 


```{c}
auto proxy = static_cast<GroupSortProxy*>(model->sourceModel());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (m_newStuffDialog->changedEntries().isEmpty()) {
                return;
            }

            // reload the display icontheme items
            KIconLoader::global()->newIconLoader();
            m_model->load();
            QPixmapCache::clear();
        }
```

#### AUTO 


```{c}
const auto destination =
            query.ordering() == HighScoredFirst ?
                lower_bound(cache, score, member(&ResultSet::Result::score) > _) :
            query.ordering() == RecentlyUsedFirst ?
                lower_bound(cache, lastUpdate, member(&ResultSet::Result::lastUpdate) > _) :
            query.ordering() == RecentlyCreatedFirst ?
                lower_bound(cache, firstUpdate, member(&ResultSet::Result::firstUpdate) > _) :
            // otherwise
                lower_bound(cache, resource, member(&ResultSet::Result::resource) > _)
            ;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto componentGroupName : config.groupList()) {
        auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.uniqueName == componentGroupName;
        });
        if (component == m_components.end()) {
            qCWarning(KCMKEYS) << "Ignoring unknown component" << componentGroupName;
            continue;
        }
        KConfigGroup componentGroup(&config, componentGroupName);
        if (!componentGroup.hasGroup("Global Shortcuts")) {
            qCWarning(KCMKEYS) << "Group" << componentGroupName << "has no shortcuts group";
            continue;
        }
        KConfigGroup shortcutsGroup(&componentGroup, "Global Shortcuts");
        for (const auto& key : shortcutsGroup.keyList()) {
            auto shortcut = std::find_if(component->shortcuts.begin(), component->shortcuts.end(), [&] (const Shortcut &s) {
                return s.uniqueName == key;
            });
            if (shortcut == component->shortcuts.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            shortcut->activeShortcuts = QSet<QKeySequence>(shortcuts.cbegin(), shortcuts.cend());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (OptionGroupInfo *optionGroupInfo : qAsConst(rules->optionGroupInfos)) {
        std::sort(optionGroupInfo->optionInfos.begin(), optionGroupInfo->optionInfos.end(), xkbOptionLessThan);
    }
```

#### AUTO 


```{c}
auto update = [=]() {
        bool userDataChanged = false;
        if (mUid != m_dbusIface->uid()) {
            mUid = m_dbusIface->uid();
            userDataChanged = true;
            Q_EMIT uidChanged();
        }
        if (mName != m_dbusIface->userName()) {
            mName = m_dbusIface->userName();
            userDataChanged = true;
            Q_EMIT nameChanged();
        }
        if (mFace != QUrl(m_dbusIface->iconFile())) {
            mFace = QUrl(m_dbusIface->iconFile());
            mFaceValid = QFileInfo::exists(mFace.toString());
            userDataChanged = true;
            Q_EMIT faceChanged();
            Q_EMIT faceValidChanged();
        }
        if (mRealName != m_dbusIface->realName()) {
            mRealName = m_dbusIface->realName();
            userDataChanged = true;
            Q_EMIT realNameChanged();
        }
        if (mEmail != m_dbusIface->email()) {
            mEmail = m_dbusIface->email();
            userDataChanged = true;
            Q_EMIT emailChanged();
        }
        const auto administrator = (m_dbusIface->accountType() == 1);
        if (mAdministrator != administrator) {
            mAdministrator = administrator;
            userDataChanged = true;
            Q_EMIT administratorChanged();
        }
        const auto loggedIn = (mUid == getuid());
        if (mLoggedIn != loggedIn) {
            mLoggedIn = loggedIn;
            userDataChanged = true;
        }
        if (userDataChanged) {
            Q_EMIT dataChanged();
        }
    };
```

#### AUTO 


```{c}
const auto &item = d->shownActivities.at(row);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                endResetModel();
                emit countChanged();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Action &a) {
            return a.id == key;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (KStandardShortcut::Category category) { return static_cast<int>(category); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : currentLayouts) {
        QAction *action = createAction(layoutUnit);
        actionGroup->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KConfigSkeletonItem *skel : itemList) {
        r[skel->name()] = skel->property();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Prop<bool> &prop, bool defVal) {
         prop.reset(m_settings->load(prop.cfgName, defVal));
    }
```

#### AUTO 


```{c}
const auto &result
```

#### AUTO 


```{c}
auto roleNames = sourceModel()->roleNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &iconName : iconNames) {
                QString path = theme.iconPath(QStringLiteral("%1.png").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (!path.isEmpty()) {
                    QPixmap pixmap(path);
                    pixmap.setDevicePixelRatio(dpr);
                    return pixmap;
                }

                //could not find the .png, try loading the .svg or .svgz
                path = theme.iconPath(QStringLiteral("%1.svg").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (path.isEmpty()) {
                    path = theme.iconPath(QStringLiteral("%1.svgz").arg(iconName), iconSize, KIconLoader::MatchBest);
                }

                if (path.isEmpty()) {
                    continue;
                }

                if (!renderer.load(path)) {
                    continue;
                }

                QPixmap pixmap(iconSize, iconSize);
                pixmap.setDevicePixelRatio(dpr);
                pixmap.fill(QColor(Qt::transparent));
                QPainter p(&pixmap);
                p.setViewport(0, 0, size, size);
                renderer.render(&p);
                return pixmap;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[url, desktopEntryUrl] {
            KService::Ptr service = KService::serviceByDesktopPath(desktopEntryUrl.toLocalFile());
            if (!service) {
                return;
            }

            KRun::runService(*service, {url}, QApplication::activeWindow());
        }
```

#### AUTO 


```{c}
const auto &choice
```

#### RANGE FOR STATEMENT 


```{c}
for (const HelperInfo &info : _helper_list) {
            if (((info.option & SCIM_HELPER_STAND_ALONE) != 0) && ((info.option & SCIM_HELPER_AUTO_START) == 0)) {
                props << Property(String(helper_prop_prefix.toUtf8().constData()) + info.uuid, info.name, info.icon, info.description);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            if (m_schemes.contains(file)) {
                continue;
            }
            m_schemes.append(dir + QLatin1Char('/') + file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString grp : iconGroups) {
        KConfigGroup cg(kglobalcfg, grp);
        KConfigGroup cg2(&kde4config, grp);
        cg.copyTo(&cg2);
    }
```

#### AUTO 


```{c}
const auto titleRight = sourceModel()->data(sourceRight, KActivitiesBackport::ActivitiesModel::ActivityName);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &item) {
        return QStandardPaths::locate(QStandardPaths::GenericDataLocation, item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&name](const Component &c) {
            return c.id == name;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog](int result) {
        if (result == QDialog::Accepted && dialog->service()) {
            const KService::Ptr service = dialog->service();
            const QString desktopFileName = service->desktopEntryName() + ".desktop";
            if (m_globalAccelModel->match(m_shortcutsModel->index(0, 0), BaseModel::ComponentRole, desktopFileName, 1, Qt::MatchExactly).isEmpty()) {
                m_globalAccelModel->addApplication(desktopFileName, service->name());
            } else {
                qCDebug(KCMKEYS) << "Already have component" << service->storageId();
            }
        }
        dialog->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &parent, int from, int to) {
                if (parent.isValid()) {
                    qWarning() << "We do not support tree models";

                } else {
                    beginInsertRows(QModelIndex(),
                                    sourceRowToRow(from),
                                    sourceRowToRow(to));

                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, activity](int screenId) {
                removeScreen(screenId, activity, {});
            }
```

#### AUTO 


```{c}
const auto result = findResource(resource);
```

#### AUTO 


```{c}
const auto &url
```

#### AUTO 


```{c}
const auto browser = KApplicationTrader::preferredService("x-scheme-handler/http");
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Action &action) {
            return action.activeShortcuts == action.defaultShortcuts;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        toggle();
        showOsd();
    }
```

#### AUTO 


```{c}
auto inputConfig = KSharedConfig::openConfig(QStringLiteral("kcminputrc"));
```

#### AUTO 


```{c}
auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().toList();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(paths)) {
        KPackage::Package pkg = KPackage::PackageLoader::self()->loadPackage(QStringLiteral("Plasma/LookAndFeel"));
        pkg.setPath(path);
        pkg.setFallbackPackage(KPackage::Package());
        if (component.isEmpty() || !pkg.filePath(component.toUtf8()).isEmpty()) {
            packages << pkg;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[index, conflict, newSequence, oldSequence](int result) {
        auto model = const_cast<BaseModel *>(static_cast<const BaseModel *>(index.model()));
        if (result != QDialogButtonBox::Yes) {
            // Also emit if we are not changing anything, to force the frontend to update and be consistent
            // with the model. It is currently out of sync because it reflects the user input that
            // was rejected now.
            Q_EMIT model->dataChanged(index, index, {BaseModel::ActiveShortcutsRole, BaseModel::CustomShortcutsRole});
            return;
        }
        const_cast<BaseModel *>(static_cast<const BaseModel *>(conflict.model()))->disableShortcut(conflict, newSequence);
        if (!oldSequence.isEmpty()) {
            model->changeShortcut(index, oldSequence, newSequence);
        } else {
            model->addShortcut(index, newSequence);
        }
    }
```

#### AUTO 


```{c}
auto filePath = targetUrl.path();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& action : it->actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                const QStringList actionId = buildActionId(it->id, it->displayName,
                        action.id, action.displayName);
                //operator int of QKeySequence
                QList<int> keys(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << action.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                        "Error while saving shortcut %1: %2", it->displayName, it->displayName));
                } else {
                    action.initialShortcuts = action.activeShortcuts;
                }
            }
        }
```

#### AUTO 


```{c}
auto setAccount = m_dbusIface->SetAccountType(m_type);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_windowViewAvailable = false;
        Q_EMIT windowViewAvailableChanged();
    }
```

#### AUTO 


```{c}
auto cleanTail = [](QStringList &list) {
        while (!list.isEmpty() && list.constLast().isEmpty()) {
            list.removeLast();
        }
    };
```

#### AUTO 


```{c}
auto it = m_itemsOnDisabledScreensMap.find(pair);
```

#### AUTO 


```{c}
auto end = matchesForRunner.constEnd();
```

#### AUTO 


```{c}
auto result = d->features->SetValue(
        "org.kde.ActivityManager.Resources.Scoring/isOTR/" + activity,
        QDBusVariant(isPrivate));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shortcut : shortcuts) {
        if (shortcut.toString(QKeySequence::NativeText).contains(m_filter, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, activity](int screenId) {
                addScreen(screenId, activity, {});
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : mimeData->urls()) {
                    m_dropTargetPositions.insert(url.fileName(), dropPos);
                    m_screenMapper->addMapping(mappableUrl(url), m_screen, ScreenMapper::DelayedSignal);
                    m_screenMapper->removeItemFromDisabledScreen(mappableUrl(url));
                }
```

#### AUTO 


```{c}
const auto &keySequence
```

#### LAMBDA EXPRESSION 


```{c}
[this,activityToSet] () {
                m_activities.setCurrentActivity(activityToSet);
            }
```

#### AUTO 


```{c}
const auto activityToSet = runningActivities[index];
```

#### AUTO 


```{c}
auto w = qobject_cast<QQuickWindow*>(object);
```

#### AUTO 


```{c}
const auto user
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() {
        if (!dialog->changedEntries().isEmpty()) {
            load();
            delete dialog;
        }
    }
```

#### AUTO 


```{c}
const auto dolphinRadio = ::findDolphinRadio(mDynamicRadioButtons);
```

#### AUTO 


```{c}
const auto hours = diff % 24;
```

#### AUTO 


```{c}
const auto defaultBlockedValue = d->pluginConfig->defaultBlockedByDefaultValue();
```

#### LAMBDA EXPRESSION 


```{c}
[this, styleName] {
        if (!m_styleConfigDialog->isDirty()) {
            return;
        }

        // Force re-rendering of the preview, to apply settings
        emit styleReconfigured(styleName);

        //For now, ask all KDE apps to recreate their styles to apply the setitngs
        KGlobalSettings::self()->emitChange(KGlobalSettings::StyleChanged);

        // When user edited a style, assume they want to use it, too
        m_model->setSelectedStyle(styleName);

        // We call setStyleDirty here to make sure we force style re-creation
        m_selectedStyleDirty = true;
        setNeedsSave(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    }
```

#### AUTO 


```{c}
auto touchpadConfig = m_config->group(m_name);
```

#### AUTO 


```{c}
auto verifyMapping = [](const QHash<int, int> &actual, const QHash<int, int> &expected) {
        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().values();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, process] (QProcess::ProcessError) {
                Q_EMIT error(i18nc("@info", "Failed to run install script in terminal \"%1\"", process->program()));
            }
```

#### AUTO 


```{c}
const auto &matchedPlaces = placesModel.match(placesModel.index(0, 0), KFilePlacesModel::UrlRole, oldUrl, 1, Qt::MatchFixedString);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropTargetFolderUrl](const QUrl &url) -> QString {
                QString mappedUrl = url.toString();
                if (dropTargetFolderUrl != m_dirModel->dirLister()->url()) {
                    const auto local = dropTargetFolderUrl.toString();
                    const auto internal = m_dirModel->dirLister()->url().toString();
                    if (mappedUrl.startsWith(local)) {
                        mappedUrl.replace(0, local.size(), internal);
                    }
                }
                return mappedUrl;
            }
```

#### AUTO 


```{c}
const auto &application = d->applications[index];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: ghostActivities) {
                newForActivity.remove(activity);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &name : std::as_const(engineList)) {
            (*pengine_names)[i] = g_strdup(name.constData());
            i++;
        }
```

#### AUTO 


```{c}
const auto emailClients = KServiceTypeTrader::self()->query(QStringLiteral("Application"),
                                                                QStringLiteral("'Email' in Categories and 'x-scheme-handler/mailto' in ServiceTypes"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sysname : devicesSysNames) {
        addDevice(sysname, false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, notifySignal] {
        Q_EMIT(this->*notifySignal)();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process](QProcess::ProcessError) {
        Q_EMIT error(i18nc("@info", "Failed to run install script in terminal \"%1\"", process->program()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().length() == 1) {
            const QString desktopPath = selectApplicationDialogUi.treeView->model()->data(selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().first(), Qt::UserRole+1).toString();

            if (!desktopPath.isEmpty() &&QFile::exists(desktopPath) ) {
                const QString desktopFile = desktopPath.split(QChar('/')).last();

                if (!desktopPath.isEmpty()) {
                    KDesktopFile sourceDF(desktopPath);
                    KDesktopFile *destinationDF = sourceDF.copyTo(QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile);
                    qWarning()<<QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile;
                    destinationDF->sync();
                    //TODO: a DBUS call to tell the daemon to refresh desktop files


                    // Create a action collection for our current component:context
                    KActionCollection *col = new KActionCollection(q, desktopFile);

                    foreach(const QString &actionId, sourceDF.readActions()) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QChar(','));
                        QList<QKeySequence> sequences;
                        if (sequencesStrings.length() > 0) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (sequences.count() > 0) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    //Global launch action
                    {
                        const QString friendlyName = i18n("Launch %1", sourceDF.readName());
                        QAction *action = col->addAction(QStringLiteral("_launch"));
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.desktopGroup().readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QChar(','));
                        QList<QKeySequence> sequences;
                        if (sequencesStrings.length() > 0) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (sequences.count() > 0) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
qWarning()<<"WWWWW"<<desktopFile<<sourceDF.readName();
                    q->addCollection(col, QDBusObjectPath(), desktopFile, sourceDF.readName());
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const SourceData &a, const SourceData &b) {
        if (a.notifyRcName == s_plasmaWorkspaceNotifyRcName) {
            return true;
        }
        if (b.notifyRcName == s_plasmaWorkspaceNotifyRcName) {
            return false;
        }
        return collator.compare(a.display(), b.display()) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::Device volume : volumes) {
        // sa can be 0 (e.g. for the swap partition)
        if (const Solid::StorageAccess *sa = volume.as<Solid::StorageAccess>()) {
            connect(sa, &Solid::StorageAccess::accessibilityChanged, this, &DeviceAutomounter::deviceMountChanged);
        }
        automountDevice(volume, m_settings->Login);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of added application") + desktopName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
        connect(infoWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopName, infoReply.error());
                return;
            }
            if (infoReply.value().isEmpty()) {
                qCWarning(KCMKEYS()) << "New component has no shortcuts:" << reply.value().path();
                Q_EMIT errorOccured(i18nc("%1 is the name of an application", "Error while adding %1, it seems it has no actions."));
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(), pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const KFileItem &item) {
        Q_UNUSED(item);
        qWarning() << "SwitcherBackend: FAILED to get the thumbnail" << job->errorString() << job->detailedErrorStrings();
        Q_EMIT finished();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            beginResetModel();
            endResetModel();
        }
```

#### AUTO 


```{c}
auto updateModel = [this]() {
        if (m_resultModel->rowCount() >= 5) {
            setSourceModel(m_resultModel);
        } else {
            setSourceModel(m_defaultModel);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri) {
        if (m_storageId == uri) {
            clear();
        }
    }
```

#### AUTO 


```{c}
__inline auto filtered(Class *const self, Member member)
    -> decltype(boost::adaptors::filtered(
                std::bind(member, self, std::placeholders::_1)))
{
    return boost::adaptors::filtered(
        std::bind(member, self, std::placeholders::_1)
    );

}
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(highlightWindowName, highlightWindowPath, highlightWindowInterface, QStringLiteral("highlightWindows"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &coloritem : colorItemListWM)
    {
            groupWMOut.writeEntry(coloritem, groupWMTheme.readEntry(coloritem));
    }
```

#### AUTO 


```{c}
auto sm = new SessionManagement(this);
```

#### AUTO 


```{c}
auto x11DefaultFlat = m_settings->load(QStringLiteral("X11LibInputXAccelProfileFlat"), false);
```

#### AUTO 


```{c}
auto setThemeIfAvailable = [this](const QString &themeName) {
        const auto results = m_model->match(m_model->index(0, 0), ThemeNameRole, themeName);
        if (results.isEmpty()) {
            return false;
        }

        m_model->setSelectedTheme(themeName);
        return true;
    };
```

#### AUTO 


```{c}
auto dialog = new KOpenWithDialog;
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of added application") + desktopFileName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
        connect(infoWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            emit beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            emit endInsertRows();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath &componentPath : components) {
        d->loadComponent(componentPath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Action &action) {
            return action.activeShortcuts == action.defaultShortcuts;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : services) {
        if (service->noDisplay()) {
            continue;
        }

        if (desktopEntries.contains(service->desktopEntryName())) {
            continue;
        }

        SourceData source{
            service->name(),
            service->comment(),
            service->icon(),
            true,
            QString(), // notifyRcFile
            service->desktopEntryName(),
            {} // events
        };
        appsData.append(source);
        desktopEntries.append(service->desktopEntryName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
                        cg.revertToDefault(state + key);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &seqString : sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString,      const QString &,      Id)
```

#### AUTO 


```{c}
const auto shortcuts = QKeySequence::listFromString(group.readEntry(key));
```

#### AUTO 


```{c}
const auto linkStatus  = result.linkStatus();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().length() == 1) {
            const QString desktopPath = selectApplicationDialogUi.treeView->model()->data(selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().first(), Qt::UserRole+1).toString();

            if (!desktopPath.isEmpty() &&QFile::exists(desktopPath) ) {
                const QString desktopFile = desktopPath.split(QLatin1Char('/')).last();

                if (!desktopPath.isEmpty()) {
                    KDesktopFile sourceDF(desktopPath);
                    KDesktopFile *destinationDF = sourceDF.copyTo(QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QLatin1String("/kglobalaccel/") + desktopFile);
                    qWarning()<<QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile;
                    destinationDF->sync();
                    //TODO: a DBUS call to tell the daemon to refresh desktop files


                    // Create a action collection for our current component:context
                    KActionCollection *col = new KActionCollection(q, desktopFile);

                    foreach(const QString &actionId, sourceDF.readActions()) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    //Global launch action
                    {
                        const QString friendlyName = i18n("Launch %1", sourceDF.readName());
                        QAction *action = col->addAction(QStringLiteral("_launch"));
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.desktopGroup().readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    q->addCollection(col, QDBusObjectPath(), desktopFile, sourceDF.readName());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& key : shortcutsGroup.keyList()) {
            auto shortcut = std::find_if(component->shortcuts.begin(), component->shortcuts.end(), [&] (const Shortcut &s) {
                return s.uniqueName == key;
            });
            if (shortcut == component->shortcuts.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            shortcut->activeShortcuts = QSet<QKeySequence>(shortcuts.cbegin(), shortcuts.cend());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *configWidget : qAsConst(configWidgetMap)) {
        delete configWidget;
	}
```

#### AUTO 


```{c}
auto applications = (blockedApplications + allowedApplications).toList();
```

#### AUTO 


```{c}
const auto destination = destinationFor(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this, uninstallJob, plugin]() {
            if (uninstallJob->error()) {
                Q_EMIT error(uninstallJob->errorString());
            } else {
                m_model->removeRows(pluginIndex(plugin), 1);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&itemText](const QString &word) {
                    return itemText.contains(word, Qt::CaseInsensitive);
                }
```

#### AUTO 


```{c}
auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().values();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };
```

#### AUTO 


```{c}
const auto matching = browserCombo->model()->match(browserCombo->model()->index(0,0), Qt::UserRole, service->storageId());
```

#### AUTO 


```{c}
auto iface = m_device->m_iface.data();
```

#### AUTO 


```{c}
auto ptr = activityInfo.get();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : m_activitiesWindows.keys()) {
        if (m_activitiesWindows[activity].contains(window)) {
            m_activitiesWindows[activity].removeAll(window);

            rowChanged(rowForActivityId(activity),
                       m_activitiesWindows.size() == 0 //
                           ? QVector<int>{WindowCount, HasWindows}
                           : QVector<int>{WindowCount});
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&c](AbstractEntry* a, AbstractEntry* b) {
            if (a->type() != b->type()) {
                return a->type() > b->type();
            } else {
                return c.compare(a->name(), b->name()) < 0;
            }
        }
```

#### AUTO 


```{c}
auto query = UsedResources
                    | (m_ordering == Recent ? RecentlyUsedFirst : HighScoredFirst)
                    | Agent::any()
                    | Type::any()
                    | Activity::current();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return
                    matcher == ANY_ACTIVITY_TAG
                        ? true
                    : matcher == CURRENT_ACTIVITY_TAG
                        ? (matcher == activity || activity == ActivitiesSync::currentActivity(activities))
                    : activity == matcher;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QListWidgetItem * item) {
        QList<Plasma::AbstractRunner *> runners = item->data(RunnersRole).value<QList<Plasma::AbstractRunner *> >();

        if (!runners.isEmpty()) {
            const QRect rect = m_listWidget->visualItemRect(item);
            m_configButton->move(QPoint(rect.right(), rect.center().y()) - QPoint(m_configButton->width(), m_configButton->height()/2));
            m_configButton->setVisible(true);
            m_configButton->setProperty("runners", QVariant::fromValue(runners));
        } else {
            m_configButton->setVisible(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { q->refresh(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layoutUnits) {
        layouts.append(layoutUnit.layout());
        variants.append(layoutUnit.variant());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *s : screens) {
        if (s->geometry().contains(globalPosition)) {
            screen = s;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& key : keys) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&] (const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component-m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
```

#### AUTO 


```{c}
const auto serializedMap = disabledScreensMap();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : qAsConst(windowModels)) {
                    windowModel->setActivity(activityInfo->currentActivity());
                }
```

#### AUTO 


```{c}
const auto containment = plasmaConfigContainments().group(containmentId);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_windowViewAvailable = true;
        Q_EMIT windowViewAvailableChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QRadioButton *radio) {
        return radio->property("storageId") == QStringLiteral("org.kde.dolphin.desktop");
    }
```

#### AUTO 


```{c}
const auto path = group.readPathEntry(key, QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor]() {
        Q_EMIT const_cast<KKeySequenceWidgetDelegate*>(this)->commitData(editor);
    }
```

#### AUTO 


```{c}
auto verifyMapping = [](const QHash<int, int> &actual, const QHash<int, int> &expected) {

        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            qSort(values);
            auto uniqueValues = values.toSet().toList();
            qSort(uniqueValues);
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &app : seenApps) {
        if (desktopEntries.contains(app)) {
            continue;
        }

        KService::Ptr service = KService::serviceByDesktopName(app);
        if (!service || service->noDisplay()) {
            continue;
        }

        SourceData source{
            service->name(),
            service->comment(),
            service->icon(),
            QString(), //notifyRcFile
            service->desktopEntryName(),
            {}
        };
        appsData.append(source);
        desktopEntries.append(service->desktopEntryName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urlsToRemoveFromMapping)
        removeFromMap(url);
```

#### AUTO 


```{c}
auto registeredPosition
        = Private::activityPosition(knownActivities, activityInfo->id());
```

#### AUTO 


```{c}
const auto events = m_data.at(parent.row()).events;
```

#### LAMBDA EXPRESSION 


```{c}
[q](QScreen* screen) {
        QObject::connect(screen, &QScreen::geometryChanged, q, &PagerModel::pagerItemSizeChanged);
        q->pagerItemSizeChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        enable();
        showOsd();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : services) {
        if (service->noDisplay()) {
            continue;
        }

        if (desktopEntries.contains(service->desktopEntryName())) {
            continue;
        }

        SourceData source{
            service->name(),
            service->comment(),
            service->icon(),
            QString(), //notifyRcFile
            service->desktopEntryName(),
            {} // events
        };
        appsData.append(source);
        desktopEntries.append(service->desktopEntryName());
    }
```

#### AUTO 


```{c}
auto savedSource2ProxyScreen0 = expectedSource2ProxyScreen0;
```

#### AUTO 


```{c}
auto verifyMapping = [](const QHash<int, int> &actual, const QHash<int, int> &expected) {
        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values;
            uniqueValues.erase(std::unique(uniqueValues.begin(), uniqueValues.end()), uniqueValues.end());
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pathIt : m_screensPerPath) {
            pathIt.removeAll(screenId);
        }
```

#### AUTO 


```{c}
const auto now = QDateTime::currentDateTime().toSecsSinceEpoch();
```

#### AUTO 


```{c}
const auto idpart = id.splitRef(QLatin1Char('.'))[0];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : qAsConst(layouts)) {
            str += layoutUnit.toString() + QLatin1Char(' ');
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : defaultLayouts) {
            layouts.append(layoutUnit.layout());
            variants.append(layoutUnit.variant());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionsList) {
        KActionCollection::setShortcutsConfigurable(act, true);
        if (isConfiguration) {
            act->setProperty("isConfigurationAction", true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : mimeData->urls()) {
            m_dropTargetPositions.insert(url.fileName(), dropPos);
            m_screenMapper->addMapping(mappableUrl(url), m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
            m_screenMapper->removeItemFromDisabledScreen(mappableUrl(url));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Action &s1, const Action &s2) {
        return collator.compare(s1.displayName, s2.displayName) < 0;
    }
```

#### AUTO 


```{c}
auto excluded = addTrailingSlashes(m_settings->excludedFolders());
```

#### RANGE FOR STATEMENT 


```{c}
for (const int row : std::as_const(rows)) {
        const QPoint pos(row % m_perStripe, row / m_perStripe);

        if (row == currentIndex) {
            continue;
        }

        if (hDirection == 0) {
            if (vDirection * pos.y() > vDirection * currentPos.y()) {
                distance = (pos - currentPos).manhattanLength();

                if (nearestItem == -1 || distance < lastDistance || (distance == lastDistance && pos.x() == currentPos.x())) {
                    nearestItem = row;
                    lastDistance = distance;
                }
            }
        } else if (vDirection == 0) {
            if (hDirection * pos.x() > hDirection * currentPos.x()) {
                distance = (pos - currentPos).manhattanLength();

                if (nearestItem == -1 || distance < lastDistance || (distance == lastDistance && pos.y() == currentPos.y())) {
                    nearestItem = row;
                    lastDistance = distance;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &themeName) {
        const auto results = m_model->match(m_model->index(0, 0), ThemeNameRole, themeName);
        if (results.isEmpty()) {
            return false;
        }

        m_model->setSelectedTheme(themeName);
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &layoutUnit : layoutsList) {
        ret.append({layoutUnit.layout(), Flags::getShortText(layoutUnit, keyboardConfig), Flags::getLongText(layoutUnit, rules)});
    }
```

#### AUTO 


```{c}
const auto begin = collection.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Action &s1, const Action &s2) {
        return collator.compare(s1.displayName, s2.displayName) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layoutsList) {
		stringList << layoutUnit.toString();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : groupNameList)
    {

        KConfigGroup groupEffectOut(m_config, groupName);
        KConfigGroup groupEffectTheme(config, groupName);

        for (const QString &effect : effectList) {
            groupEffectOut.writeEntry(effect, groupEffectTheme.readEntry("effect"));

        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &l : expectedMapping) {
        for (const auto &s : l) {
            seralizedMap.append(s);
        }
    }
```

#### AUTO 


```{c}
auto ungrabMouseHack = [item]() {
        if (item && item->window() &&  item->window()->mouseGrabberItem()) {
            item->window()->mouseGrabberItem()->ungrabMouse();
        }
    };
```

#### AUTO 


```{c}
const auto newFirstScreen = std::min_element(m_availableScreens.constBegin(), m_availableScreens.constEnd());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mountPath : m_mountPoints) {
        if (includeList.contains(mountPath))
            continue;

        if (exclude.contains(mountPath))
            continue;

        if (!m_excludeList.contains(mountPath)) {
            m_excludeList.append(mountPath);
        }
    }
```

#### AUTO 


```{c}
const auto now = QDateTime::currentDateTime().toTime_t();
```

#### AUTO 


```{c}
const auto &locale
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : keys) {
        if (components.value(text)->uniqueName() == componentUnique) {
            // Remove from QComboBox
            QModelIndexList results = proxyModel->match(proxyModel->index(0, 0), Qt::DisplayRole, text);
            Q_ASSERT(!results.isEmpty());
            model->removeRow(proxyModel->mapToSource(results.first()).row());

            // Remove from QStackedWidget
            stack->removeWidget(components[text]->editor());

            // Remove the componentData
            delete components.take(text);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mountPath : m_mountPoints) {
        if (includeList.contains(mountPath))
            continue;

        if (!m_excludeList.contains(mountPath)) {
            m_excludeList.append(mountPath);
        }
    }
```

#### AUTO 


```{c}
auto updateModel = [this]() {
        if (m_resultModel->rowCount() >= 6) {
            setSourceModel(m_resultModel);
        } else {
            setSourceModel(m_defaultModel);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus)
                if (exitCode == 0) {
                    emit showSuccessMessage(i18n("Theme installed successfully."));
                    load();
                } else {
                    Q_EMIT showErrorMessage(i18n("Theme installation failed."));

                }
            }
```

#### AUTO 


```{c}
auto query = d->database.exec("SELECT DISTINCT(initiatingAgent) FROM ResourceScoreCache ORDER BY initiatingAgent");
```

#### AUTO 


```{c}
auto cleanUpWatcher = new QDBusPendingCallWatcher(component.cleanUp());
```

#### LAMBDA EXPRESSION 


```{c}
[&](Component &c) {
        std::sort(c.actions.begin(), c.actions.end(), [&] (const Action &a1, const Action &a2) {
            return collator.compare(a1.displayName, a2.displayName) < 0;
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[sysName] (QObject *t) { return static_cast<KWinWaylandDevice*>(t)->sysName() == sysName; }
```

#### RANGE FOR STATEMENT 


```{c}
for (DragImage *image : std::as_const(m_dragImages)) {
        image->blank = isBlank(image->row);
        image->rect.translate(-m_dragHotSpotScrollOffset.x(), -m_dragHotSpotScrollOffset.y());
        if (!image->blank && !image->image.isNull()) {
            region = region.united(image->rect);
        }
    }
```

#### AUTO 


```{c}
auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : qAsConst(component.actions)) {
            if (action.defaultShortcuts != action.activeShortcuts) {
                return false;
            }
        }
```

#### AUTO 


```{c}
const auto matches = match(index(0, 0), SourcesModel::NotifyRcNameRole, notifyRcName, 1, Qt::MatchFixedString);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &themeName : pendingDeletions) {
        Q_ASSERT(themeName != m_model->selectedTheme());

        KIconTheme theme(themeName);
        auto *job = KIO::del(QUrl::fromLocalFile(theme.dir()), KIO::HideProgressInfo);
        // needs to block for it to work on "OK" where the dialog (kcmshell) closes
        job->exec();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        list << String2Property(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<Property> &props : std::as_const(helper_props_map)) {
                    list_result << PropertyList2LeafOnlyStringList(props);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &effect : effectList) {
            groupEffectOut.writeEntry(effect, groupEffectTheme.readEntry("effect"));

        }
```

#### AUTO 


```{c}
auto folderListEntry = [&homePath] (const QString& url, bool include, bool fromConfig)
    {
        QString displayName = url;
        if (displayName.size() > 1) {
            displayName.chop(1);
        }
        if (displayName.startsWith(homePath)) {
            displayName.replace(0, homePath.length(), QStringLiteral("~/"));
        }

        QString icon = QStringLiteral("folder");
        if (url == homePath) {
            icon = QStringLiteral("user-home");
        } else if (!fromConfig) {
            icon = QStringLiteral("drive-harddisk");
        }

        return FolderInfo{url, displayName, icon, include, fromConfig};
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layoutUnits) {
        layouts.append(layoutUnit.layout());
        variants.append(layoutUnit.variant());
	}
```

#### AUTO 


```{c}
auto engine_desc = ibus_bus_get_global_engine(impanel->bus);
```

#### AUTO 


```{c}
auto action = d->actionForActivity(activity);
```

#### RANGE FOR STATEMENT 


```{c}
for (ActionItem *newItem : actionList) { // Lets find our new action
        if( newItem->desktopMasterPath == filePath ) {
            const int position = actionList.indexOf( newItem );
            newAction = actionModel->index( position, 0 ); // Grab it
            break;
        }
    }
```

#### AUTO 


```{c}
const auto knownDevices = m_settings->knownDevices();
```

#### LAMBDA EXPRESSION 


```{c}
[this]{ setNeedsSave(true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *object : engine.rootObjects()) {
            auto w = qobject_cast<QQuickWindow *>(object);
            if (!w)
                continue;

            if (w && QX11Info::isPlatformX11())
                KStartupInfo::setNewStartupId(w, QX11Info::nextStartupId());

            w->setVisible(true);
            w->raise();
        }
```

#### AUTO 


```{c}
auto group = conf->group("Window");
```

#### AUTO 


```{c}
auto t
```

#### RANGE FOR STATEMENT 


```{c}
for (QRadioButton *button : qAsConst(mDynamicRadioButtons)) {
        if (button->isChecked()) {
            storageId = button->property("storageId").toString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : rulesWithExtras->layoutInfos) {
            if (layoutInfo->fromExtras)
                foundFromExtras = true;
            if (!layoutInfo->fromExtras)
                foundNonExtras = true;
            layoutInfo->languages.size(); // make sure we can access all merged objects
            layoutInfo->variantInfos.size(); // make sure we can access all merged objects
        }
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig("kcminputrc", KConfig::NoGlobals);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AutostartEntry &e : qAsConst(m_entries)) {
            if (e.source == AutostartModel::AutostartEntrySource::PlasmaShutdown) {
                break;
            }
            ++lastLoginScript;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupNewView();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const PackageKit::Details &details) {
        removePackage(details.packageId());
    }
```

#### AUTO 


```{c}
const auto &agent
```

#### AUTO 


```{c}
const auto &prop
```

#### AUTO 


```{c}
auto end        = this->end();
```

#### AUTO 


```{c}
auto future = this->future();
```

#### AUTO 


```{c}
auto reply = xcb_get_modifier_mapping_reply(QX11Info::connection(), cookie, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : themeFiles) {
        KConfig config(file, KConfig::SimpleConfig);
        if (!config.hasGroup("KDE") || !config.hasGroup("Misc")) {
            continue;
        }

        KConfigGroup kdeGroup = config.group("KDE");

        const QString styleName = kdeGroup.readEntry("WidgetStyle", QString());
        if (styleName.isEmpty()) {
            continue;
        }

        auto it = styleData.find(styleName);
        if (it == styleData.end()) {
            continue;
        }

        auto &item = *it;

        KConfigGroup desktopEntryGroup = config.group("Desktop Entry");
        if (desktopEntryGroup.readEntry("Hidden", false)) {
            // Don't list hidden styles
            styleData.remove(styleName);
            continue;
        }

        KConfigGroup miscGroup = config.group("Misc");

        item.display = miscGroup.readEntry("Name");
        item.description = miscGroup.readEntry("Comment");
        item.configPage = miscGroup.readEntry("ConfigPage");
    }
```

#### AUTO 


```{c}
const auto path = ScreenMapper::stringToUrl(QStringLiteral("desktop:/Foo"));
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const typename ActivityPosition<_Container>::ContainerElement &activity) {
                return activity->id() == activityId;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : activities) {
        const int row = rowForActivityId(activity);
        rowChanged(row, {KActivities::ActivitiesModel::ActivityBackground});
    }
```

#### AUTO 


```{c}
const auto &activity
```

#### AUTO 


```{c}
const auto  &keySequence
```

#### AUTO 


```{c}
auto query = _query
            + "\nORDER BY $orderingColumn resource ASC\n"
            + limitOffsetSuffix();
```

#### AUTO 


```{c}
const auto activityLeft =
          sourceModel()->data(sourceLeft, KActivities::ActivitiesModel::ActivityId).toString();
```

#### AUTO 


```{c}
const auto agents =
        !agent.values.isEmpty()      ? agent.values :
        !d->query.agents().isEmpty() ? d->query.agents() :
                                       Terms::Agent::current().values;
```

#### AUTO 


```{c}
auto item = new QStandardItem(KXftConfig::description(t));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of added application") + desktopFileName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
        connect(infoWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            emit beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            Component c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            emit endInsertRows();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const optional_view<QString> &activityId) {
            if (activityId.is_initialized()) {
                saveChanges(activityId.get());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractEntry *entry : m_entryList) {
            processEntry(entry);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](XDeviceInfo * info) {
            int deviceid = info->id;
            if (info->type == m_touchpadAtom) {
                return;
            }
            evdevApplyReverseScroll(deviceid, m_settings->reverseScrollPolarity);
        }
```

#### AUTO 


```{c}
const auto entry = AutostartEntry {service->name(),
                                       service->exec(),
                                       AutostartModel::AutostartEntrySource::XdgAutoStart, // .config/autostart load desktop at startup
                                       true,
                                       desktopPath,
                                       false,
                                       service->icon()};
```

#### AUTO 


```{c}
const auto activityLeft =
          sourceModel()->data(sourceLeft, KActivities::ActivitiesModel::ActivityId);
```

#### AUTO 


```{c}
auto componentsWatcher = new QDBusPendingCallWatcher(globalAccelInterface.allComponents());
```

#### AUTO 


```{c}
auto shadowText = [&font, &textColor, &offset](QString text) {
        //don't try to paint stuff on a future null pixmap because the text is empty
        if (text.isEmpty()) {
            return QPixmap();
        }

        // Draw text
        QFontMetrics fm(font);
        QRect textRect = fm.boundingRect(text);
        QPixmap textPixmap(textRect.width(), fm.height());
        textPixmap.fill(Qt::transparent);
        QPainter p(&textPixmap);
        p.setPen(textColor);
        p.setFont(font);
        // FIXME: the center alignment here is odd: the rect should be the size needed by
        //        the text, but for some fonts and configurations this is off by a pixel or so
        //        and "centering" the text painting 'fixes' that. Need to research why
        //        this is the case and determine if we should be painting it differently here,
        //        doing soething different with the boundingRect call or if it's a problem
        //        in Qt itself
        p.drawText(textPixmap.rect(), Qt::AlignCenter, text);
        p.end();

        return textPixmap;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QKeyEvent *event)
    {
        Q_ASSERT(event);
        if (event->nativeScanCode() == nativeScanCode) {
            pressed = event->type() == QKeyEvent::KeyPress;
            emit pressedChanged();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else if (!reply.value().isEmpty()) {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2) {
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        if (!m_contextMenu) {
            return;
        }

        QHoverEvent ev(QEvent::HoverLeave, QPoint(0, 0), QPoint(0, 0));
        QGuiApplication::sendEvent(item, &ev);

        emit showingContextMenuChanged();

        m_contextMenu->exec(pos);
        m_contextMenu->windowHandle()->setTransientParent(item->window());
        m_contextMenu->deleteLater();
    }
```

#### AUTO 


```{c}
auto doShutdown = [sm]() {
        sm->requestReboot();
        delete sm;
    };
```

#### AUTO 


```{c}
const auto &idx
```

#### AUTO 


```{c}
const auto &componentGroupName
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&](const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component - m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&c](AbstractEntry* a, AbstractEntry* b) {
                if (a->type() != b->type()) {
                    return a->type() > b->type();
                } else {
                    return c.compare(a->name(), b->name()) < 0;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            showActivitySwitcherIfNeeded();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KXftConfig::Hint::Style s : {KXftConfig::Hint::None, KXftConfig::Hint::Slight, KXftConfig::Hint::Medium, KXftConfig::Hint::Full}) {
        auto item = new QStandardItem(KXftConfig::description(s));
        m_hintingOptionsModel->appendRow(item);
    }
```

#### AUTO 


```{c}
auto shortcut = std::find_if(component->shortcuts.begin(), component->shortcuts.end(), [&] (const Shortcut &s) {
                return s.uniqueName == key;
            });
```

#### AUTO 


```{c}
const auto years = diff;
```

#### AUTO 


```{c}
const auto nonPending = m_model->match(idx, PendingDeletionRole, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: query) {
            result.setTitle(item[QStringLiteral("title")].toString());
            result.setMimetype(item[QStringLiteral("mimetype")].toString());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](XDeviceInfo *info) {
        int deviceid = info->id;
        Status status;
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        // data returned is an 1 byte boolean
        status = XIGetProperty(dpy, deviceid, valAtom, 0, 1, False, XA_INTEGER, &type_return, &format_return, &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;

        if (type_return != XA_INTEGER || !data || format_return != 8) {
            return;
        }

        unsigned char sendVal[2] = {0};
        if (num_items_return == 1) {
            sendVal[0] = val;
        } else {
            // Special case for acceleration profile.
            const Atom accel = XInternAtom(dpy, LIBINPUT_PROP_ACCEL_PROFILE_ENABLED, True);
            if (num_items_return != 2 || valAtom != accel) {
                return;
            }
            sendVal[val] = 1;
        }

        XIChangeProperty(dpy, deviceid, valAtom, XA_INTEGER, 8, XIPropModeReplace, sendVal, num_items_return);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ModelInfo *modelInfo : qAsConst(rules->modelInfos)) {
        QString vendor = modelInfo->vendor;
        if (vendor.isEmpty()) {
            vendor = i18nc("unknown keyboard model vendor", "Unknown");
        }
        uiWidget->keyboardModelComboBox->addItem(i18nc("vendor | keyboard model", "%1 | %2", vendor, modelInfo->description), modelInfo->name);
    }
```

#### AUTO 


```{c}
auto dropTargetFolderUrl = dropTargetUrl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
                        if (file.endsWith(colorScheme + QStringLiteral(".colors"))) {
                            setColors(colorScheme, dir + QLatin1Char('/') + file);
                            schemeFound = true;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : qAsConst(m_iconGroups)) {
        int size = KIconLoader::global()->theme()->defaultSize(static_cast<KIconLoader::Group>(i));

        KConfigGroup iconGroup(cfg, group + QLatin1String("Icons"));
        size = iconGroup.readEntry("Size", size);

        iconSizes[i] = size;

        ++i;
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString, const QString &, Name)
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
            if (action->data().toInt() == arrangement) {
                action->setChecked(true);
                break;
            }
        }
```

#### AUTO 


```{c}
auto backgroundColor = wallpaperConfig.readEntry("Color", QColor(0, 0, 0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : qAsConst(m_paths)) {
        QDir d(path);
        if (!d.exists())
            d.mkpath(path);

        QDir autostartdir( path );
        autostartdir.setFilter( QDir::Files );
        const QFileInfoList list = autostartdir.entryInfoList();

        for (int i = 0; i < list.size(); ++i) {
            QFileInfo fi = list.at(i);

            ScriptStartItem *item = new ScriptStartItem( fi.absoluteFilePath(), m_scriptItem,this );
            int typeOfStartup = m_paths.indexOf((item->fileName().adjusted(QUrl::RemoveScheme | QUrl::RemoveFilename).toString()) );
            ScriptStartItem::ENV type = ScriptStartItem::START;
            switch( typeOfStartup )
            {
            case 0:
                type =ScriptStartItem::START;
                break;
            case 1:
                type = ScriptStartItem::SHUTDOWN;
                break;
            case 2:
                type = ScriptStartItem::PRE_START;
                break;
            default:
                qDebug()<<" type is not defined :"<<type;
                break;
            }
            if ( fi.isSymLink() ) {
                QString link = fi.symLinkTarget();
                addItem(item, fi.fileName(), link, type );
            }
            else
            {
                addItem( item, fi.fileName(), fi.fileName(),type );
            }
        }
    }
```

#### AUTO 


```{c}
const auto& component
```

#### RANGE FOR STATEMENT 


```{c}
for (WId wid : windows) {
        KWindowSystem::minimizeWindow(wid);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : components) {
            KGlobalAccelComponentInterface component(QStringLiteral("org.kde.kglobalaccel"), componentPath.path(), QDBusConnection::sessionBus());
            ++m_pendingComponentCalls;
            auto shortcutsWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(shortcutsWatcher, &QDBusPendingCallWatcher::finished, this, [this](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QList<KGlobalShortcutInfo>> shortcutsReply = *watcher;
                if (shortcutsReply.isValid()) {
                    const auto allShortcuts = shortcutsReply.value();
                    bool isNotDefault = std::any_of(allShortcuts.cbegin(), allShortcuts.cend(), [](const KGlobalShortcutInfo &info) {
                        return info.defaultKeys() != info.keys();
                    });
                    m_isDefault &= isNotDefault;
                }
                if (--m_pendingComponentCalls == 0) {
                    Q_EMIT loaded();
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### AUTO 


```{c}
auto blockedApplications = QSet<QString>::fromList(d->pluginConfig->blockedApplications());
```

#### AUTO 


```{c}
auto model
```

#### AUTO 


```{c}
auto model = const_cast<BaseModel *>(static_cast<const BaseModel *>(index.model()));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : qAsConst(d->windowModels)) {
        if (d->showOnlyCurrentScreen && d->screenGeometry.isValid()) {
            windowModel->setScreenGeometry(d->screenGeometry);
            windowModel->setFilterByScreen(true);
        } else {
            windowModel->setFilterByScreen(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &x: set) {
        auto resp = (m_dbusIface->*(x.second))(x.first);
        resp.waitForFinished();
        // We don't have a meaningful way to discern between errors and
        // user cancellation; but user cancellation is more likely than errors
        // so go with that.
        if (resp.isError()) {
            emitResult();
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PanelFactoryInfo &info : factories) {
        list << QVariant::fromValue(info);
    }
```

#### AUTO 


```{c}
const auto name = config.readName();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<QDBusObjectPath>> componentsReply = *watcher;
        if (componentsReply.isError() || componentsReply.value().isEmpty()) {
            Q_EMIT loaded();
            return;
        }
        const auto components = componentsReply.value();
        for (const auto &componentPath : components) {
            KGlobalAccelComponentInterface component(QStringLiteral("org.kde.kglobalaccel"), componentPath.path(), QDBusConnection::sessionBus());
            ++m_pendingComponentCalls;
            auto shortcutsWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(shortcutsWatcher, &QDBusPendingCallWatcher::finished, this, [this](QDBusPendingCallWatcher *watcher) {
                QDBusPendingReply<QList<KGlobalShortcutInfo>> shortcutsReply = *watcher;
                if (shortcutsReply.isValid()) {
                    const auto allShortcuts = shortcutsReply.value();
                    bool isNotDefault = std::any_of(allShortcuts.cbegin(), allShortcuts.cend(), [](const KGlobalShortcutInfo &info) {
                        return info.defaultKeys() != info.keys();
                    });
                    m_isDefault &= isNotDefault;
                }
                if (--m_pendingComponentCalls == 0) {
                    Q_EMIT loaded();
                }
            });
        }
    }
```

#### AUTO 


```{c}
const auto end = collection.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return matcher == ANY_TYPE_TAG || matcher == type;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &settings](XDeviceInfo * info) {
            int deviceid = info->id;
            if (info->type == m_touchpadAtom) {
                return;
            }
            if (libinputApplyReverseScroll(deviceid, settings.reverseScrollPolarity)) {
                return;
            }
            evdevApplyReverseScroll(deviceid, settings.reverseScrollPolarity);
        }
```

#### AUTO 


```{c}
auto removeItemFromModel = [this](const QStringList &files) {
        if (!files.isEmpty()) {
            const QString guessedPluginId = QFileInfo(files.constFirst()).fileName();
            const int index = pluginIndex(guessedPluginId);
            if (index != -1) {
                m_model->removeRows(index, 1);
            }
        }
    };
```

#### AUTO 


```{c}
const auto count2 = secondFolderModel.rowCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : defaultLayouts) {
            layouts.append(layoutUnit.layout());
            variants.append(layoutUnit.variant());
		}
```

#### AUTO 


```{c}
auto reply = m_fprintInterface->Release();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& urlFilter: query.urlFilters()) {
            urlFilters << QRegExp(urlFilter, Qt::CaseSensitive, QRegExp::WildcardUnix);
        }
```

#### AUTO 


```{c}
const auto sourceModelPtr = m_sourceModel.data();
```

#### AUTO 


```{c}
const auto components = componentsReply.value();
```

#### LAMBDA EXPRESSION 


```{c}
[&completed]() {
                    completed = true;
                }
```

#### AUTO 


```{c}
const auto components = componentsCall.value();
```

#### AUTO 


```{c}
const auto agent =
            agentForUrl(resource);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qCWarning(KCM_KDED) << "Failed to get loaded modules" << reply.error().name() << reply.error().message();
            return;
        }

        QStringList runningModules = reply.value();
        m_model->setRunningModules(runningModules);
        m_model->setRunningModulesKnown(true);

        // Check if the user just tried starting a module that then disabled itself again.
        // Some kded modules disable themselves on start when they deem themselves unnecessary
        // based on some configuration independ of kded or the current environment.
        // At least provide some feedback and not leave the user wondering why the service doesn't start.
        if (!m_lastStartedModule.isEmpty() && !runningModules.contains(m_lastStartedModule)) {
            Q_EMIT showSelfDisablingModulesHint();
        }
        m_lastStartedModule.clear();

        // Check if any modules got started/stopped as a result of reloading kded
        if (!m_runningModulesBeforeReconfigure.isEmpty()) {
            std::sort(m_runningModulesBeforeReconfigure.begin(), m_runningModulesBeforeReconfigure.end());
            std::sort(runningModules.begin(), runningModules.end());

            if (m_runningModulesBeforeReconfigure != runningModules) {
                Q_EMIT showRunningModulesChangedAfterSaveHint();
            }
        }
        m_runningModulesBeforeReconfigure.clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder : settingsIncluded) {
        m_folderList.append(folderListEntry(folder, true, true));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, url, kind](KJob *theJob) {
        if (theJob->error()) {
            qWarning() << "Could add script entry" << theJob->errorString();
            return;
        }

        beginInsertRows(QModelIndex(), index, index);

        const QUrl dest = theJob->property("finalUrl").toUrl();

        AutostartEntry entry = AutostartEntry {dest.fileName(), url.path(), kind, true, dest.path(), false, QStringLiteral("dialog-scripts")};

        m_entries.insert(index, entry);

        endInsertRows();
    }
```

#### AUTO 


```{c}
const auto firstUpdate = result.firstUpdate();
```

#### RANGE FOR STATEMENT 


```{c}
for (ComponentData *cd : qAsConst(d->components)) {
        KConfigGroup group(config, cd->uniqueName());
        //qDebug() << cd->uniqueName() << group.name();
        if (group.exists()) {
            //qDebug() << "Removing" << cd->uniqueName();
            cd->editor()->clearConfiguration();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : lst) {
        QVERIFY(m_folderModel->action(str));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &layoutString : layoutStrings) {
                    layoutSet.layouts.append(LayoutUnit(layoutString));
                }
```

#### AUTO 


```{c}
auto info = findActivity(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDBusPendingCallWatcher *componentsWatcher) {
        QDBusPendingReply<QList<QDBusObjectPath>> componentsReply = *componentsWatcher;
        componentsWatcher->deleteLater();
        if (componentsReply.isError()) {
            genericErrorOccured(QStringLiteral("Error while calling allComponents()"), componentsReply.error());
            endResetModel();
            return;
        }
        const QList<QDBusObjectPath> componentPaths = componentsReply.value();
        int *pendingCalls = new int;
        *pendingCalls = componentPaths.size();
        for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[sm]() {
            sm->requestReboot();
            delete sm;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : uiWidget->switchingPolicyButtonGroup->buttons()) {
        setDefaultIndicatorVisible(button, m_highlightVisible && !isDefaultswitchingPolicy && uiWidget->switchingPolicyButtonGroup->checkedButton() == button);
    }
```

#### AUTO 


```{c}
const auto path = QStringLiteral("desktop:/Foo");
```

#### AUTO 


```{c}
const auto interfaceTypes = availActions->interfaceTypeList();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int first, int last) {
        for (int i = first; i <= last; ++i) {
            const auto idx = index(i, 0, parent);
            const auto url = itemForIndex(idx).url();
            auto it = m_dropTargetPositions.find(url.fileName());
            if (it != m_dropTargetPositions.end()) {
                const auto pos = it.value();
                m_dropTargetPositions.erase(it);
                Q_EMIT move(pos.x(), pos.y(), {url});
            }
        }
    }
```

#### AUTO 


```{c}
const auto activity    = containment.readEntry("activityId", QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possibleThemePath : possiblePathsToThemes()) {
        // If the directory contains any of gtk-3.X folders, it is the GTK3 theme for sure
        QDir possibleThemeDirectory(possibleThemePath);
        if (!possibleThemeDirectory.entryList(gtk3SubdirPattern, QDir::Dirs).isEmpty()) {

            // Do not show dark Breeze GTK variant, since the colors of it
            // are coming from the color scheme and selecting them here
            // is redundant and does not work
            if (possibleThemeDirectory.dirName() == QStringLiteral("Breeze-Dark")) {
                continue;
            }

            gtk3ThemesNames.insert(possibleThemeDirectory.dirName(), possibleThemeDirectory.path());
        }
    }
```

#### AUTO 


```{c}
auto screens = qApp->screens();
```

#### AUTO 


```{c}
auto *w = leaveList.at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDBusPendingCallWatcher *componentsWatcher) {
        QDBusPendingReply<QList<QDBusObjectPath>> componentsReply = *componentsWatcher;
        componentsWatcher->deleteLater();
        if (componentsReply.isError()) {
            genericErrorOccured(QStringLiteral("Error while calling allComponents()"), componentsReply.error());
            endResetModel();
            return;
        }
        const QList<QDBusObjectPath> componentPaths = componentsReply.value();
        int *pendingCalls = new int;
        *pendingCalls = componentPaths.size();
        for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        updateExample();
        updateEnabled();
        emit changed(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("splash.png")), ScreenshotRole);
        row->setData(pkg.metadata().comment(), DescriptionRole);
        m_model->appendRow(row);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Shortcut &s1, const Shortcut &s2) {
        return collator.compare(s1.friendlyName, s2.friendlyName) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.values) {
        scoring.call(QStringLiteral("DeleteRecentStats"), activity, count,
                what == Hours  ? "h" :
                what == Days   ? "d" :
                                 "m"
            );
    }
```

#### AUTO 


```{c}
auto& shortcut
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &themeName : pendingDeletions) {
        Q_ASSERT(themeName != m_settings->theme());

        KIconTheme theme(themeName);
        auto *job = KIO::del(QUrl::fromLocalFile(theme.dir()), KIO::HideProgressInfo);
        // needs to block for it to work on "OK" where the dialog (kcmshell) closes
        job->exec();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &prop : props) {
        menuProps << prop.toMap();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, key](){ deleteHistoryGroup(key); }
```

#### AUTO 


```{c}
const auto pixmapKey = path + "/"
        + QString::number(width) + "x"
        + QString::number(height);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            setNeedsSave(true);
        }
```

#### AUTO 


```{c}
const auto settings
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shortcut : shortcuts) {
        if (shortcut.toString(QKeySequence::NativeText).contains(m_filter, Qt::CaseInsensitive)
                || shortcut.toString(QKeySequence::PortableText).contains(m_filter, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> &actual, const QHash<int, int> &expected) {
        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().values();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    }
```

#### AUTO 


```{c}
auto settings = deviceSettings(udi);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& created : entry.installedFiles()) {
                        QStringList list = created.split(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        // Because we sometimes get some extra slashes in the installed files list
                        list.removeAll({});
                        // Because we'll also get the containing folder, if it was not already there
                        // we need to ignore it.
                        if (list.last() == QLatin1String(".icons")) {
                            continue;
                        }
                        m_themeModel->addTheme(list.join(QLatin1Char('/')));
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setNeedsSave(true);
    }
```

#### AUTO 


```{c}
auto index = m_userList.indexOf(user);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : it->actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                const QStringList actionId = buildActionId(it->id, it->displayName, action.id, action.displayName);
                // TODO: pass action.activeShortcuts to m_globalAccelInterface->setForeignShortcut() as a QSet<QKeySequence>
                // or QList<QKeySequence>?
                QList<QKeySequence> keys;
                keys.reserve(action.activeShortcuts.size());
                for (const QKeySequence &key : qAsConst(action.activeShortcuts)) {
                    keys.append(key);
                }
                qCDebug(KCMKEYS) << "Saving" << actionId << action.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcutKeys(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    Q_EMIT errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                                              "Error while saving shortcut %1: %2",
                                              it->displayName,
                                              it->displayName));
                } else {
                    action.initialShortcuts = action.activeShortcuts;
                }
            }
        }
```

#### AUTO 


```{c}
auto it = m_firstScreenForPath.begin();
```

#### AUTO 


```{c}
auto doShutdown=[sm]() {
            sm->requestReboot();
            delete sm;
        };
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString str) {
            return str.replace("%", "\\%").replace("_", "\\_");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QSqlDatabase::removeDatabase(database.connectionName());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_style.reset();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().toList();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        }
```

#### AUTO 


```{c}
auto cleanUpReply = componentInterface.cleanUp();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &row : rows) {
        iRow = row.toInt();

        if (iRow < 0) {
            return;
        }

        const QModelIndex &idx = index(iRow, 0);
        newSelection.select(idx, idx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        possibleDir = const_cast<KArchiveEntry*>(themeDir->entry(entry));
        if (!possibleDir->isDirectory()) {
            continue;
        }

        subDir = dynamic_cast<KArchiveDirectory *>(possibleDir);
        if (!subDir) {
            continue;
        }

        if (subDir->entry(QStringLiteral("index.theme"))
                || subDir->entry(QStringLiteral("index.desktop"))) {
          foundThemes.append(subDir->name());
        }
    }
```

#### AUTO 


```{c}
auto call = m_kdedInterface->loadedModules();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &shortcut : shortcuts) {
        if (shortcut.toString(QKeySequence::NativeText).contains(m_filter, Qt::CaseInsensitive)
            || shortcut.toString(QKeySequence::PortableText).contains(m_filter, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KGlobalShortcutInfo &shortcut : shortcuts) {

            const QString &objectName = shortcut.uniqueName();
            QAction *action = col->addAction(objectName);
            action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
            action->setProperty("componentDisplayName", shortcut.componentFriendlyName());
            action->setText(shortcut.friendlyName());

            // Always call this to enable global shortcuts for the action. The editor widget
            // checks it.
            // Also actually loads the shortcut using the KAction::Autoloading mechanism.
            // Avoid setting the default shortcut; it would just be written to the global
            // configuration so we would not get the real one below.
            KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());

            // The default shortcut will never be loaded because it's pointless in a real
            // application. There are no scarce resources [i.e. physical keys] to manage
            // so applications can set them at will and there's no autoloading.
            QList<QKeySequence> sc = shortcut.defaultKeys();
            if (sc.count()>0) {
                KGlobalAccel::self()->setDefaultShortcut(action, sc);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<void> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            Q_EMIT errorMessage(i18n("Failed to notify KDE Service Manager (kded5) of saved changed: %1", reply.error().message()));
            return;
        }

        qCDebug(KCM_KDED) << "Successfully reconfigured kded";
        getModuleStatus();
    }
```

#### AUTO 


```{c}
const auto path = listPath().at(i);
```

#### LAMBDA EXPRESSION 


```{c}
[path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else if (!reply.value().isEmpty()) {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            }
```

#### AUTO 


```{c}
const auto actions = service->actions();
```

#### AUTO 


```{c}
const auto isDefaultswitchingPolicy = switcingPolicyFromUI() == keyboardConfig->defaultSwitchingPolicyValue();
```

#### RANGE FOR STATEMENT 


```{c}
for (const PreviewCursor *c : qAsConst(list)) {
        if (c->rect().contains(e->pos())) {
            if (c != current) {
                const uint32_t cursor = *c;

                if (QWindow *actualWindow = QQuickRenderControl::renderWindowFor(window())) {
                    if (KWindowSystem::isPlatformX11() && cursor != XCB_CURSOR_NONE) {
                        xcb_change_window_attributes(QX11Info::connection(), actualWindow->winId(), XCB_CW_CURSOR, &cursor);
                    }
                }

                current = c;
            }
            return;
        }
    }
```

#### AUTO 


```{c}
const auto activeShortcuts = shortcutIndex.data(ShortcutsModel::ActiveShortcutsRole).value<QSet<QKeySequence>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ModelInfo *modelInfo : std::as_const(rules->modelInfos)) {
            QDomElement model = doc.createElement(QStringLiteral("model"));
            model.setAttribute(QStringLiteral("name"), modelInfo->name);
            model.setAttribute(QStringLiteral("description"), modelInfo->description);
            model.setAttribute(QStringLiteral("vendor"), modelInfo->vendor);
            modelList.appendChild(model);
        }
```

#### AUTO 


```{c}
auto job = new UserApplyJob(m_dbusIface, mName, mEmail, mRealName, mFace.toString().replace("file://", ""), mAdministrator ? 1 : 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor]() {
        Q_EMIT const_cast<VariantComboDelegate*>(this)->commitData(editor);
    }
```

#### AUTO 


```{c}
auto resourcePosition = find(resource);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &windowIds) -> QVector<QModelIndex> {
        QVector<QModelIndex> indices;
        for (const auto &id : windowIds) {
            for (int i = 0; i < d->tasksModel->rowCount(); ++i) {
                const QModelIndex &idx = d->tasksModel->index(i, 0);
                const QVariantList &winIds = idx.data(TaskManager::AbstractTasksModel::WinIdList).toList();
                if (!winIds.isEmpty() && winIds.at(0).value<typename std::remove_reference_t<decltype(windowIds)>::value_type>() == id) {
                    indices.push_back(idx);
                    break;
                }
            }
        }
        return indices;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog](int result) {
        if (result == QDialog::Accepted && dialog->service()) {
            const KService::Ptr service = dialog->service();
            const QString desktopFileName = service->storageId();
            if (m_globalAccelModel->match(m_shortcutsModel->index(0, 0), BaseModel::ComponentRole, desktopFileName, 1, Qt::MatchExactly).isEmpty()) {
                m_globalAccelModel->addApplication(desktopFileName, service->name());
            } else {
                qCDebug(KCMKEYS) << "Already have component" << service->storageId();
            }
        }
        dialog->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, reportProcessError](int exitCode, QProcess::ExitStatus exitStatus) {
                    if (exitCode == 0 && exitStatus == QProcess::NormalExit) {
                        Q_EMIT finished();
                    } else {
                        reportProcessError();
                    }
                }
```

#### AUTO 


```{c}
auto it = results.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const quint32 &id : ids) {
                QAbstractItemModel *model = d->windowModels.at(0)->sourceModel();
                TaskManager::WindowTasksModel *tasksModel = static_cast<TaskManager::WindowTasksModel *>(model);

                for (int i = 0; i < tasksModel->rowCount(); ++i) {
                    const QModelIndex &idx = tasksModel->index(i, 0);

                    if (idx.data(TaskManager::AbstractTasksModel::IsOnAllVirtualDesktops).toBool()) {
                        break;
                    }

                    const QVariantList &winIds = idx.data(TaskManager::AbstractTasksModel::WinIdList).toList();

                    if (!winIds.isEmpty() && winIds.at(0).toUInt() == id) {
                        tasksModel->requestVirtualDesktops(idx, QVariantList() << itemId.toString());
                        break;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog] (int result) {
            if (result == QDialog::Rejected) {
                Q_EMIT indexChanged();
                Q_EMIT isDefaultsChanged();
                return;
            }

            const KService::Ptr service = dialog->service();
            // Check if the selected application is already in the list
            for (int i = 0; i < m_applications.length(); i++) {
                if (m_applications[i].toMap()["storageId"] == service->storageId()) {
                    m_index = i;
                    Q_EMIT indexChanged();
                    Q_EMIT isDefaultsChanged();
                    return;
                }
            }
            const QString icon = !service->icon().isEmpty() ? service->icon() : QStringLiteral("application-x-shellscript");
            QVariantMap application;
            application["name"] = service->name();
            application["icon"] = icon;
            application["storageId"] = service->storageId();
            application["execLine"] = service->exec();
            m_applications.insert(m_applications.length() - 1, application);
            m_index = m_applications.length() - 2;
            Q_EMIT applicationsChanged();
            Q_EMIT indexChanged();
            Q_EMIT isDefaultsChanged();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &res : qAsConst(m_schemes)) {
        KConfig config(res, KConfig::SimpleConfig);
        KConfigGroup group(&config, "Settings");
        QString name = group.readEntry("Name");

        if (name.isEmpty()) {
            name = res;
        }
        ui->m_schemes->addItem(name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[sm]() {
        sm->requestReboot();
        delete sm;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().length() == 1) {
            const QString desktopPath = selectApplicationDialogUi.treeView->model()->data(selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().first(), Qt::UserRole+1).toString();

            if (!desktopPath.isEmpty() &&QFile::exists(desktopPath) ) {
                const QString desktopFile = desktopPath.split(QChar('/')).last();

                if (!desktopPath.isEmpty()) {
                    KDesktopFile sourceDF(desktopPath);
                    KDesktopFile *destinationDF = sourceDF.copyTo(QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile);
                    qWarning()<<QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile;
                    destinationDF->sync();
                    //TODO: a DBUS call to tell the daemon to refresh desktop files


                    // Create a action collection for our current component:context
                    KActionCollection *col = new KActionCollection(q, desktopFile);

                    foreach(const QString &actionId, sourceDF.readActions()) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QChar(','));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    //Global launch action
                    {
                        const QString friendlyName = i18n("Launch %1", sourceDF.readName());
                        QAction *action = col->addAction(QStringLiteral("_launch"));
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.desktopGroup().readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QChar(','));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    q->addCollection(col, QDBusObjectPath(), desktopFile, sourceDF.readName());
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of added application") + desktopFileName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
        connect(infoWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            if (infoReply.value().isEmpty()) {
                qCWarning(KCMKEYS()) << "New component has no shortcuts:" << reply.value().path();
                Q_EMIT errorOccured(i18nc("%1 is the name of an application", "Error while adding %1, it seems it has no actions."));
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        });
    }
```

#### AUTO 


```{c}
auto cleanTail = [](QStringList &list)
    {
        while (!list.isEmpty() && list.constLast().isEmpty()) {
            list.removeLast();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &componentIndex : includedComponents) {
        KConfigGroup mainGroup(&file, componentIndex.data(ShortcutsModel::ComponentRole).toString());
        KConfigGroup group(&mainGroup, "Global Shortcuts");
        for (int i = 0; i < m_shortcutsModel->rowCount(componentIndex); ++i) {
            const QModelIndex shortcutIndex = m_shortcutsModel->index(i, 0, componentIndex);
            const auto activeShortcuts = shortcutIndex.data(ShortcutsModel::ActiveShortcutsRole).value<QSet<QKeySequence>>();
            const QList<QKeySequence> shortcutsList(activeShortcuts.cbegin(), activeShortcuts.cend());
            group.writeEntry(shortcutIndex.data(ShortcutsModel::ActionRole).toString(), QKeySequence::listToString(shortcutsList));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString m : msgs) {
        if (!m.isNull()) {
            qCCritical(KCM_TOUCHPAD) << "in error:" << m;
            if (!success) {
                error_msg.append("\n");
            }
            error_msg.append(m);
            success = false;
        }
    }
```

#### AUTO 


```{c}
auto rect = screen->availableGeometry();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
            if (action->data().toInt() == sortMode) {
                action->setChecked(true);
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, moduleName, status](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<bool> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            if (status == NotRunning) {
                emit errorMessage(i18n("Failed to stop service: %1", reply.error().message()));
            } else {
                emit errorMessage(i18n("Failed to start service: %1", reply.error().message()));
            }
            return;
        }

        if (!reply.value()) {
            if (status == NotRunning) {
                emit errorMessage(i18n("Failed to stop service."));
            } else {
                emit errorMessage(i18n("Failed to start service."));
            }
            return;
        }

        qCDebug(KCM_KDED) << "Successfully" << (status == Running ? "started" : "stopped") << moduleName;
        if (status == Running) {
            m_lastStartedModule = moduleName;
        } else {
            m_lastStartedModule.clear();
        }
        getModuleStatus();
    }
```

#### AUTO 


```{c}
const auto &source = m_data.at(index.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (const TriggerKey &key : std::as_const(m_triggersList)) {
        xcb_keysym_t sym = key.first;
        uint modifiers = key.second;
        xcb_keycode_t *keycode = xcb_key_symbols_get_keycode(m_syms, sym);
        if (!keycode) {
            g_warning("Can not convert keyval=%u to keycode!", sym);
        } else {
            xcb_grab_key(QX11Info::connection(), true, QX11Info::appRootWindow(), modifiers, keycode[0], XCB_GRAB_MODE_ASYNC, XCB_GRAB_MODE_ASYNC);
            if ((modifiers & XCB_MOD_MASK_SHIFT) == 0) {
                xcb_grab_key(QX11Info::connection(),
                             true,
                             QX11Info::appRootWindow(),
                             modifiers | XCB_MOD_MASK_SHIFT,
                             keycode[0],
                             XCB_GRAB_MODE_ASYNC,
                             XCB_GRAB_MODE_ASYNC);
            }
        }
        free(keycode);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
       if (!m_corona)
           return;

       auto config = m_corona->config();
       KConfigGroup group(config, QLatin1String("ScreenMapping"));
       group.writeEntry(QLatin1String("screenMapping"), screenMapping());
       config->sync();
    }
```

#### AUTO 


```{c}
const auto urls= it.value();
```

#### AUTO 


```{c}
const auto allowedApplicationsItem = d->pluginConfig->findItem("allowedApplications");
```

#### AUTO 


```{c}
const auto &item = m_data.at(index.row());
```

#### AUTO 


```{c}
const auto setxkbmapExe = getSetxkbmapExe();
```

#### RANGE FOR STATEMENT 


```{c}
for (CfgPlugin *plugin : qAsConst(configWidgetMap)) {
        plugin->defaults();
        emitChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& layoutString : layoutStrings) {
            layouts.append(LayoutUnit(layoutString));
        }
```

#### AUTO 


```{c}
auto configureScreen = [q](QScreen *screen) {
        QObject::connect(screen, &QScreen::geometryChanged, q, &PagerModel::pagerItemSizeChanged);
        Q_EMIT q->pagerItemSizeChanged();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of added application") + desktopFileName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
        connect(infoWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        });
    }
```

#### AUTO 


```{c}
auto componentsCall = globalAccelInterface.allComponents();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString txt){
        qDebug() << "Changed" << txt;
        emit changed(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : m_components) {
        if (component.pendingDeletion) {
            return true;
        }
        for (const auto& shortcut : component.shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto lastUpdate  = result.lastUpdate();
```

#### AUTO 


```{c}
auto *item = new KPropertySkeletonItem(m_xdgPathsStore, propertyName, defaultValue);
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString str) {
        return str.replace(QLatin1String("%"), QLatin1String("\\%")).replace(QLatin1String("_"), QLatin1String("\\_"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &from, const QModelIndex &to, const QVector<int> &roles) {
                emit dataChanged(sourceIndexToIndex(from),
                                 sourceIndexToIndex(to),
                                 roles);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](QStringList &list) {
        while (!list.isEmpty() && list.constLast().isEmpty()) {
            list.removeLast();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qCWarning(KCM_KDED) << "Failed to get loaded modules" << reply.error().name() << reply.error().message();
            return;
        }

        QStringList runningModules = reply.value();
        m_model->setRunningModules(runningModules);
        m_model->setRunningModulesKnown(true);

        // Check if the user just tried starting a module that then disabled itself again.
        // Some kded modules disable themselves on start when they deem themselves unnecessary
        // based on some configuration independent of kded or the current environment.
        // At least provide some feedback and not leave the user wondering why the service doesn't start.
        if (!m_lastStartedModule.isEmpty() && !runningModules.contains(m_lastStartedModule)) {
            Q_EMIT showSelfDisablingModulesHint();
        }
        m_lastStartedModule.clear();

        // Check if any modules got started/stopped as a result of reloading kded
        if (!m_runningModulesBeforeReconfigure.isEmpty()) {
            std::sort(m_runningModulesBeforeReconfigure.begin(), m_runningModulesBeforeReconfigure.end());
            std::sort(runningModules.begin(), runningModules.end());

            if (m_runningModulesBeforeReconfigure != runningModules) {
                Q_EMIT showRunningModulesChangedAfterSaveHint();
            }
        }
        m_runningModulesBeforeReconfigure.clear();
    }
```

#### AUTO 


```{c}
auto reply = m_globalAccelInterface->setForeignShortcutKeys(actionId, keys);
```

#### AUTO 


```{c}
auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && m_screenMapper) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = QUrl::fromUserInput(m_url, {}, QUrl::AssumeLocalFile);
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl.toString(), m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url.toString(), m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, file](const KFileItem &item, const QPixmap &pixmap) {
            Q_UNUSED(item);

            auto image = pixmap.toImage();

            m_texture = QQuickTextureFactory::textureFactoryForImage(image);
            Q_EMIT finished();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().length() == 1) {
            const QString desktopPath = selectApplicationDialogUi.treeView->model()->data(selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().first(), Qt::UserRole+1).toString();

            if (!desktopPath.isEmpty() &&QFile::exists(desktopPath) ) {
                const QString desktopFile = desktopPath.split(QLatin1Char('/')).last();

                if (!desktopPath.isEmpty()) {
                    KDesktopFile sourceDF(desktopPath);
                    KDesktopFile *destinationDF = sourceDF.copyTo(QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QLatin1String("/kglobalaccel/") + desktopFile);
                    qWarning()<<QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile;
                    destinationDF->sync();
                    //TODO: a DBUS call to tell the daemon to refresh desktop files


                    // Create a action collection for our current component:context
                    KActionCollection *col = new KActionCollection(q, desktopFile);

                    const auto actions = sourceDF.readActions();
                    for (const QString &actionId : actions) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        const QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            for (const QString &seqString : sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    //Global launch action
                    {
                        const QString friendlyName = i18n("Launch %1", sourceDF.readName());
                        QAction *action = col->addAction(QStringLiteral("_launch"));
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        const QStringList sequencesStrings = sourceDF.desktopGroup().readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            for (const QString &seqString : sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    q->addCollection(col, QDBusObjectPath(), desktopFile, sourceDF.readName());
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[id] {
            KActivities::Info info(id);

            if (QMessageBox::question(nullptr, i18nc("@title:window", "Delete Activity"), i18n("Are you sure you want to delete '%1'?", info.name()))
                == QMessageBox::Yes) {
                KActivities::Controller().removeActivity(id);
            }
        }
```

#### AUTO 


```{c}
const auto type = static_cast<ModuleType>(idx.data(ModulesModel::TypeRole).toInt());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &mod : modules) {
		QString servicePath = mod.metaDataFileName();

		// autoload defaults to false if it is not found
		const bool autoload = mod.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();
		const QString dbusModuleName = mod.value(QStringLiteral("X-KDE-DBus-ModuleName"));
		qCDebug(KCM_KDED) << "reading kded info from" << servicePath << "autoload =" << autoload << "dbus module name =" << dbusModuleName;

		// The logic has to be identical to Kded::initModules.
		// They interpret X-KDE-Kded-autoload as false if not specified
		//                X-KDE-Kded-load-on-demand as true if not specified
		if (autoload) {
			treeitem = new QTreeWidgetItem();
			treeitem->setCheckState(StartupUse, autoloadEnabled(&kdedrc, mod.pluginId()) ? Qt::Checked : Qt::Unchecked);
			treeitem->setText(StartupService, mod.name());
			treeitem->setText(StartupDescription, mod.description());
			treeitem->setText(StartupStatus, NOT_RUNNING);
			if (!dbusModuleName.isEmpty()) {
				treeitem->setData(StartupService, LibraryRole, dbusModuleName);
			} else {
				qCWarning(KCM_KDED) << "X-KDE-DBUS-ModuleName not set for module " << mod.name() << "from file" << mod.metaDataFileName();
				treeitem->setData(StartupService, LibraryRole, mod.fileName());
			}
			_lvStartup->addTopLevelItem(treeitem);
		}
		else if (isModuleLoadedOnDemand(mod)) {
			treeitem = new QTreeWidgetItem();
			treeitem->setText(OnDemandService, mod.name() );
			treeitem->setText(OnDemandDescription, mod.description());
			treeitem->setText(OnDemandStatus, NOT_RUNNING);
			if (!dbusModuleName.isEmpty()) {
				treeitem->setData(OnDemandService, LibraryRole, dbusModuleName);
			} else {
				qCWarning(KCM_KDED) << "X-KDE-DBUS-ModuleName not set for module " << mod.name() << "from file" << mod.metaDataFileName();
				treeitem->setData(OnDemandService, LibraryRole, mod.fileName());
			}
			_lvLoD->addTopLevelItem(treeitem);
		}
		else {
			qCWarning(KCM_KDED) << "kcmkded: Module " << mod.name() << "from file" << mod.metaDataFileName() << " not loaded on demand or startup! Skipping.";
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        updateExample();
        updateEnabled();
        emit changed(true);
    }
```

#### AUTO 


```{c}
auto &item = styleData[styleName];
```

#### AUTO 


```{c}
auto pathIt = m_screensPerPath.find(path);
```

#### AUTO 


```{c}
auto rect = closestScreen->availableGeometry();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Accounts::AccountId& accountId : accountIds) {
            account = accountsManager->account(accountId);
            if (account) {
                bool completed{false};
                qCDebug(ATTICA_PLUGIN_LOG) << "Fetching data for" << accountId;
                GetCredentialsJob *job = new GetCredentialsJob(accountId, accountsManager);
                connect(job, &KJob::finished, [&completed,&accessToken,&idToken](KJob* kjob){
                    GetCredentialsJob *job = qobject_cast< GetCredentialsJob* >(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData["AccessToken"].toString();
                    idToken = credentialsData["IdToken"].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
//                     if (!accessToken.isEmpty()) {
//                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
//                         for (const QString& key : credentialsData.keys()) {
//                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
//                         }
//                     }
                    completed = true;
                });
                connect(job, &KJob::result, [&completed](){ completed = true; });
                job->start();
                while(!completed) {
                    qApp->processEvents();
                }
                if(!idToken.isEmpty()) {
                    qCDebug(ATTICA_PLUGIN_LOG) << "OpenID Access token retrieved for account" << account->id();
                    break;
                }
            }
            if (idToken.isEmpty()) {
                // If we arrived here, we did have an opendesktop account, but without the id token, which means an old version of the signon oauth2 plugin was used
                qCWarning(ATTICA_PLUGIN_LOG) << "We got an OpenDesktop account, but it seems to be lacking the id token. This means an old SignOn OAuth2 plugin was used for logging in. The plugin may have been upgraded in the meantime, but an account created using the old plugin cannot be used, and you must log out and back in again.";
            }
        }
```

#### AUTO 


```{c}
const auto &urls = selectedUrls();
```

#### AUTO 


```{c}
auto urls = &(*it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &shortcut : defaultShortcuts) {
        if (shortcut.toString(QKeySequence::NativeText).contains(m_filter, Qt::CaseInsensitive)
            || shortcut.toString(QKeySequence::PortableText).contains(m_filter, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : components) {
                if (!pkg.filePath(component.toUtf8()).isEmpty()) {
                    packages << pkg;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : qAsConst(m_components)) {
        if (component.checked) {
            for (const auto& action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : activities) {
        if (!m_activitiesWindows[activity].contains(window)) {
            m_activitiesWindows[activity] << window;

            rowChanged(rowForActivityId(activity),
                       m_activitiesWindows.size() == 1 //
                           ? QVector<int>{WindowCount, HasWindows}
                           : QVector<int>{WindowCount});
        }
    }
```

#### AUTO 


```{c}
auto item = new KPropertySkeletonItem(m_fontAASettingsStore, propertyName, defaultValue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : qAsConst(layouts)) {
			str += layoutUnit.toString() + QLatin1Char(' ');
		}
```

#### AUTO 


```{c}
auto pluginListConfig = d->mainConfig->group("Plugins");
```

#### AUTO 


```{c}
auto it = m_proxyToSource.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString m : msgs) {
        if (!m.isNull()) {
            qCCritical(KCM_INPUT) << "in error:" << m;
            if (!success) {
                error_msg.append("\n");
            }
            error_msg.append(m);
            success = false;
        }
    }
```

#### AUTO 


```{c}
auto newForActivity = forActivity;
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KeyBehaviour &key) {
        return keybehaviourNames[key] == m_settings->defaultKeyboardRepeatValue();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (pagerType == VirtualDesktops && windowModels.count()) {
                for (auto windowModel : windowModels) {
                    windowModel->setActivity(activityInfo->currentActivity());
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError e) {
                qCWarning(KCM_DESKTOP_THEME) << "Theme installation failed: " << e;
                Q_EMIT showErrorMessage(i18n("Theme installation failed."));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : qAsConst(ids)) {
        KService::Ptr service = KService::serviceByStorageId(id);
        if (!service || !service->isValid()) {
            continue;
        }

        QAction *action = new QAction(parent);
        action->setText(service->name());
        action->setIcon(QIcon::fromTheme(service->icon()));

        connect(action, &QAction::triggered, this, [service]() {
            auto *job = new KIO::ApplicationLauncherJob(service);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);
            job->start();
        });

        actions << QVariant::fromValue<QAction *>(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&engine](const QStringList &/*arguments*/, const QString &/*workingDirectory*/) {
        for (QObject* object : engine.rootObjects()) {
            auto w = qobject_cast<QQuickWindow*>(object);
            if (!w)
                continue;

            if (w && QX11Info::isPlatformX11())
                KStartupInfo::setNewStartupId(w, QX11Info::nextStartupId());

            w->setVisible(true);
            w->raise();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
                QDomElement variant = doc.createElement(QStringLiteral("variant"));
                variant.setAttribute(QStringLiteral("name"), variantInfo->name);
                variant.setAttribute(QStringLiteral("description"), variantInfo->description);

                QDomElement langList = doc.createElement(QStringLiteral("languageList"));
                for (const QString &lang : variantInfo->languages) {
                    QDomElement langNode = doc.createElement(QStringLiteral("lang"));
                    langNode.setAttribute(QStringLiteral("iso639Id"), lang);
                    langList.appendChild(langNode);
                }
                if (langList.hasChildNodes()) {
                    variant.appendChild(langList);
                }

                variantList.appendChild(variant);
            }
```

#### AUTO 


```{c}
auto &prop
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &parent : sourceParents) {
        if (!parent.isValid()) {
            parents << QPersistentModelIndex();
            continue;
        }
        const QModelIndex mappedParent = q->mapFromSource(parent);
        Q_ASSERT(mappedParent.isValid());
        parents << mappedParent;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            if (infoReply.value().isEmpty()) {
                qCWarning(KCMKEYS()) << "New component has no shortcuts:" << reply.value().path();
                Q_EMIT errorOccured(i18nc("%1 is the name of an application", "Error while adding %1, it seems it has no actions."));
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(), pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        }
```

#### AUTO 


```{c}
auto it = std::find_if(m_data.begin(), m_data.end(), [ &scheme](const ColorsModelData &item) {
        return item.schemeName == scheme;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& folder : settingsExcluded) {
        m_folderList.append(folderListEntry(folder, false, true));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AutostartEntry &e : qAsConst(m_entries)) {
        if (e.source == AutostartModel::AutostartEntrySource::XdgScripts) {
            break;
        }
        ++lastApplication;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        qApp->exit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service, const QString &oldOwner, const QString &newOwner) {
        Q_UNUSED(service)
        Q_UNUSED(oldOwner)
        setKdedRunning(!newOwner.isEmpty());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : qAsConst(services))
	{
		KConfig cfg(service, KConfig::SimpleConfig);
        KConfigGroup cg = cfg.group(QByteArray());

        // fill the form layout
        const auto name = cg.readEntry("Name", i18n("Unknown"));
        CfgPlugin *loadedConfigWidget = loadConfigWidget(cfg.group(QByteArray()).readEntry("configurationType"));

        QLabel *label = new QLabel(i18nc("The label for the combobox: browser, terminal emulator...)", "%1:", name), this);
        label->setToolTip(cfg.group(QByteArray()).readEntry("Comment", QString()));

        formLayout->addRow(label, loadedConfigWidget);

        connect(loadedConfigWidget, &CfgPlugin::changed, this, &ComponentChooser::emitChanged);

        configWidgetMap.insert(service, loadedConfigWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &themeName : themes) {
            KIconTheme theme(themeName);

            for (const QString &iconName : iconNames) {
                QString path = theme.iconPath(QStringLiteral("%1.png").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (!path.isEmpty()) {
                    QPixmap pixmap(path);
                    pixmap.setDevicePixelRatio(dpr);
                    return pixmap;
                }

                //could not find the .png, try loading the .svg or .svgz
                path = theme.iconPath(QStringLiteral("%1.svg").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (path.isEmpty()) {
                    path = theme.iconPath(QStringLiteral("%1.svgz").arg(iconName), iconSize, KIconLoader::MatchBest);
                }

                if (path.isEmpty()) {
                    continue;
                }

                if (!renderer.load(path)) {
                    continue;
                }

                QPixmap pixmap(iconSize, iconSize);
                pixmap.setDevicePixelRatio(dpr);
                pixmap.fill(QColor(Qt::transparent));
                QPainter p(&pixmap);
                p.setViewport(0, 0, size, size);
                renderer.render(&p);
                return pixmap;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (m_action) {
            m_action->trigger();
        }
    }
```

#### AUTO 


```{c}
const auto oldUrl = readUrl(key, QUrl());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &agent : agents) {
            d->linking->LinkResourceToActivity(agent, resource.toString(),
                                               activity);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().length() == 1) {
            const QString desktopPath = selectApplicationDialogUi.treeView->model()->data(selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().first(), Qt::UserRole+1).toString();

            if (!desktopPath.isEmpty() &&QFile::exists(desktopPath) ) {
                const QString desktopFile = desktopPath.split(QLatin1Char('/')).last();

                if (!desktopPath.isEmpty()) {
                    KDesktopFile sourceDF(desktopPath);
                    KDesktopFile *destinationDF = sourceDF.copyTo(QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile);
                    qWarning()<<QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile;
                    destinationDF->sync();
                    //TODO: a DBUS call to tell the daemon to refresh desktop files


                    // Create a action collection for our current component:context
                    KActionCollection *col = new KActionCollection(q, desktopFile);

                    foreach(const QString &actionId, sourceDF.readActions()) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    //Global launch action
                    {
                        const QString friendlyName = i18n("Launch %1", sourceDF.readName());
                        QAction *action = col->addAction(QStringLiteral("_launch"));
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.desktopGroup().readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    q->addCollection(col, QDBusObjectPath(), desktopFile, sourceDF.readName());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
            KFileItem item = itemForIndex(index);
            if (!item.isNull()) {
                hasRemoteFiles |= item.localPath().isEmpty();
                items.append(item);
                urls.append(item.url());
            }
        }
```

#### AUTO 


```{c}
auto reply = timedateIface.SetTime(timeDiff * 1000, true, true);
```

#### AUTO 


```{c}
auto index = std::max(
        0, runningActivities.indexOf(m_activities.currentActivity()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &udi : knownDevices()) {
        m_devices[udi] = new DeviceSettings(sharedConfig(), udi, this);
    }
```

#### AUTO 


```{c}
auto service = KService::serviceByStorageId(addedApp.mid(0, addedApp.length() -8));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : m_data) {
        if (item.pendingDeletion) {
            pendingDeletions.append(item.themeName);
        }
    }
```

#### AUTO 


```{c}
const auto& containmentId
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const T &current) {
                return comparator(value, current);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            }
```

#### AUTO 


```{c}
auto url = m_excludeList.at(row);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : semicolons) {
        TextAttribute attr;
        const QStringList colons = s.split(QLatin1Char(':'));
        if (colons.size() < 4)
            continue;
        switch (colons.at(0).toInt()) {
        case 0:
            attr.type = TextAttribute::None;
            break;
        case 1:
            attr.type = TextAttribute::Decorate;
            break;
        case 2:
            attr.type = TextAttribute::Foreground;
            break;
        case 3:
            attr.type = TextAttribute::Background;
            break;
        default:
            attr.type = TextAttribute::None;
        }
        attr.start = colons.at(1).toInt();
        attr.length = colons.at(2).toInt();
        attr.value = colons.at(3).toInt();
        result << attr;
    }
```

#### AUTO 


```{c}
auto it = array.constBegin(), end = array.constEnd();
```

#### AUTO 


```{c}
const auto children = widget->children();
```

#### LAMBDA EXPRESSION 


```{c}
[&, watcher] {
                    QDBusPendingReply<> reply = *watcher;
                    if (!reply.isValid()) {
                        qCCritical(KCMKEYS) << "Error while saving";
                        if (reply.error().isValid()) {
                            qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                        }
                        emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                            "Error while saving shortcut %1: %2", component.friendlyName, shortcut.friendlyName));
                    } else {
                        shortcut.initialShortcuts = shortcut.activeShortcuts;
                    }
                    watcher->deleteLater();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &component : m_components) {
        for (auto &action : component.actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                QList<QKeySequence> keys(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                KStandardShortcut::saveShortcut(KStandardShortcut::findByName(action.id), keys);
                action.initialShortcuts = action.activeShortcuts;
            }
        }
    }
```

#### AUTO 


```{c}
const auto services = KServiceTypeTrader::self()->query(QStringLiteral("Application"),
                                                            QStringLiteral("exist Exec and TRUE == [X-GNOME-UsesNotifications]"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : activities) {
            m_activitiesWindows[activity] << window;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : d->windowModels) {
            windowModel->setVirtualDesktop(0);

            windowModel->setActivity(runningActivities.at(activityIndex));
            ++activityIndex;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &idx : persistentPendingDeletions) {
        const QString schemeName = idx.data(SchemeNameRole).toString();

        Q_ASSERT(schemeName != m_selectedScheme);

        const QString path = QStandardPaths::locate(QStandardPaths::GenericDataLocation,
            QStringLiteral("color-schemes/%1.colors").arg(schemeName));

        auto *job = KIO::del(QUrl::fromLocalFile(path), KIO::HideProgressInfo);
        // needs to block for it to work on "OK" where the dialog (kcmshell) closes
        job->exec();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c) {
        return c.id == uniqueName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, addDialog] (int result) {
        if (result == QDialog::Accepted) {
            m_model->addEntry(addDialog->importUrl(), addDialog->symLink());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possible_ntputility : possible_ntputilities) {
    ntpUtility = QStandardPaths::findExecutable(possible_ntputility, path);
    if (!ntpUtility.isEmpty()) {
      qDebug() << "ntpUtility = " << ntpUtility;
      return;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        switch (static_cast<UserApplyJob::Error>(job->error())) {
        case UserApplyJob::Error::PermissionDenied:
            loadData(); // Reload the old data to avoid half transactions
            Q_EMIT applyError(i18n("Could not get permission to save user %1", mName));
            break;
        case UserApplyJob::Error::Failed:
        case UserApplyJob::Error::Unknown:
            loadData(); // Reload the old data to avoid half transactions
            Q_EMIT applyError(i18n("There was an error while saving changes"));
            break;
        case UserApplyJob::Error::NoError:; // Do nothing
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : browsers) {
        addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if (browser->storageId() == service->storageId()) {
            setCurrentIndex(count() - 1);
            m_currentIndex = count() - 1;
        }
        if (service->storageId() == QStringLiteral("org.kde.falkon.desktop")) {
            m_defaultIndex = count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto service = new KDBusService(KDBusService::Unique, this);
```

#### LAMBDA EXPRESSION 


```{c}
[serviceAction]() {
            auto *job = new KIO::ApplicationLauncherJob(serviceAction);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);
            job->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.notifyrc"));
        for (const QString &file : fileNames) {
            if (notifyRcFiles.contains(file)) {
                continue;
            }

            notifyRcFiles.append(file);

            KConfig config(file, KConfig::NoGlobals);
            config.addConfigSources(QStandardPaths::locateAll(QStandardPaths::GenericDataLocation,
                                        QStringLiteral("knotifications5/") + file));

            KConfigGroup globalGroup(&config, QLatin1String("Global"));

            const QRegularExpression regExp(QStringLiteral("^Event/([^/]*)$"));
            const QStringList groups = config.groupList().filter(regExp);

            const QString notifyRcName = file.section(QLatin1Char('.'), 0, -2);
            const QString desktopEntry = globalGroup.readEntry(QStringLiteral("DesktopEntry"));
            if (!desktopEntry.isEmpty()) {
                if (desktopEntries.contains(desktopEntry)) {
                    continue;
                }

                desktopEntries.append(desktopEntry);
            }

            SourceData source{
                // The old KCM read the Name and Comment from global settings disregarding
                // any user settings and just used user-specific files for actions config
                // I'm pretty sure there's a readEntry equivalent that does that without
                // reading the config stuff twice, assuming we care about this to begin with
                globalGroup.readEntry(QStringLiteral("Name")),
                globalGroup.readEntry(QStringLiteral("Comment")),
                globalGroup.readEntry(QStringLiteral("IconName")),
                notifyRcName,
                desktopEntry,
                {} // events
            };

            QVector<EventData> events;
            for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{
                    cg.readEntry("Name"),
                    cg.readEntry("Comment"),
                    cg.readEntry("IconName"),
                    eventId,
                    // TODO Flags?
                    cg.readEntry("Action").split(QLatin1Char('|'))
                };
                events.append(event);
            }

            std::sort(events.begin(), events.end(), [&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            });

            source.events = events;

            if (!source.desktopEntry.isEmpty()) {
                appsData.append(source);
            } else {
                servicesData.append(source);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        const QString &storageId = browserCombo->itemData(index).toString();
        m_browserService = KService::serviceByStorageId(storageId);
        m_browserExec.clear();
        emit configChanged();
    }
```

#### AUTO 


```{c}
auto inputWindow = new QRasterWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPackage::Package &pkg : pkgs) {
        QStandardItem *row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginId(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("splash.png")), ScreenshotRole);
        row->setData(pkg.metadata().description(), DescriptionRole);
        row->setData(pkg.path().startsWith(writableLocation), UninstallableRole);
        row->setData(false, PendingDeletionRole);
        m_packageRoot = writableLocation + QLatin1Char('/') + pkg.defaultPackageRoot();
        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
auto accelerationProfiles = backend->supportedAccelerationProfiles();
```

#### AUTO 


```{c}
auto it = matchesForRunner.constBegin();
```

#### AUTO 


```{c}
const auto itemList = conf->items();
```

#### AUTO 


```{c}
auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
```

#### AUTO 


```{c}
const auto months = diff % 12;
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const KFileItem& item) mutable {
                    Q_UNUSED(item);
                    m_previewJobs.remove(path);

                    qWarning() << "SwitcherBackend: FAILED to get the thumbnail for "
                               << path << job->detailedErrorStrings(&file);
                    callback.call({false});
                }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        bool userDataChanged = false;
        if (mUid != m_dbusIface->uid()) {
            mUid = m_dbusIface->uid();
            userDataChanged = true;
            Q_EMIT uidChanged(mUid);
        }
        if (mName != m_dbusIface->userName()) {
            mName = m_dbusIface->userName();
            userDataChanged = true;
            Q_EMIT nameChanged(mName);
        }
        if (mFace != QUrl(m_dbusIface->iconFile())) {
            mFace = QUrl(m_dbusIface->iconFile());
            mFaceValid = QFileInfo::exists(mFace.toString());
            userDataChanged = true;
            Q_EMIT faceChanged(mFace);
            Q_EMIT faceValidChanged(mFaceValid);
        }
        if (mRealName != m_dbusIface->realName()) {
            mRealName = m_dbusIface->realName();
            userDataChanged = true;
            Q_EMIT realNameChanged(mRealName);
        }
        if (mEmail != m_dbusIface->email()) {
            mEmail = m_dbusIface->email();
            userDataChanged = true;
            Q_EMIT emailChanged(mEmail);
        }
        const auto administrator = (m_dbusIface->accountType() == 1);
        if (mAdministrator != administrator) {
            mAdministrator = administrator;
            userDataChanged = true;
            Q_EMIT administratorChanged(mAdministrator);
        }
        const auto loggedIn = (mUid == getuid());
        if (mLoggedIn != loggedIn) {
            mLoggedIn = loggedIn;
            userDataChanged = true;
        }
        if (userDataChanged) {
            Q_EMIT dataChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus);
                if (exitCode == 0) {
                    qCDebug(KCM_DESKTOP_THEME) << "Theme installed successfully :)";
                    load();
                    Q_EMIT showSuccessMessage(i18n("Theme installed successfully."));
                } else {
                    qCWarning(KCM_DESKTOP_THEME) << "Theme installation failed." << exitCode;
                    Q_EMIT showErrorMessage(i18n("Theme installation failed."));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &l : expectedMapping) {
        for (const auto &s : l) {
            if (s == m_currentActivity) {
                continue; // Missing activity ID from the old config before 5.25
            }

            seralizedMap.append(s);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : qAsConst(layouts)) {
        layoutStrings.append(layoutUnit.layout());
        variants.append(layoutUnit.variant());
        displayNames.append(layoutUnit.getRawDisplayName());
//    	shortcuts.append(layoutUnit.getShortcut().toString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[installerPath]() {
                QDesktopServices::openUrl(QUrl::fromLocalFile(installerPath));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : qAsConst(d->windowModels)) {
            windowModel->setVirtualDesktop();

            windowModel->setActivity(runningActivities.at(activityIndex));
            ++activityIndex;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const NormalizedId &item) {
                    return item.value();
                }
```

#### AUTO 


```{c}
static auto months = ki18ncp("unit of time. months to keep the history",
                                 " month", " months");
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        if (!m_contextMenu) {
            return;
        }

        QHoverEvent ev(QEvent::HoverLeave, QPoint(0, 0), QPoint(0, 0));
        QGuiApplication::sendEvent(item, &ev);

        emit showingContextMenuChanged();

        QPointer<LegacyTaskManager::BasicMenu> guard(m_contextMenu);
        m_contextMenu->exec(pos);
        if (!guard) {
            return;
        }
        if (window) {
            m_contextMenu->windowHandle()->setTransientParent(window);
        }
        m_contextMenu->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const SourceData &a, const SourceData &b) {
        return collator.compare(a.display(), b.display()) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Property &prop : props) {
        list << QVariant::fromValue(prop);
    }
```

#### AUTO 


```{c}
auto foundProgress = properties.constFind(QStringLiteral("progress"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (q->rowCount()) {
                Q_EMIT q->dataChanged(q->index(0, 0), q->index(q->rowCount() - 1, 0), QVector<int>{Qt::DisplayRole});
            }
        }
```

#### AUTO 


```{c}
auto query = UsedResources | Agent(agent) | Type::any() | Activity::current() | Url::file();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!selectApplicationDialogUi.treeView->model()) {
            KRecursiveFilterProxyModel *filterModel = new KRecursiveFilterProxyModel(selectApplicationDialogUi.treeView);
            QStandardItemModel *appModel = new QStandardItemModel(selectApplicationDialogUi.treeView);
            selectApplicationDialogUi.kfilterproxysearchline->setProxy(filterModel);
            filterModel->setSourceModel(appModel);
            appModel->setHorizontalHeaderLabels({i18n("Applications")});

            loadAppsCategory(KServiceGroup::root(), appModel, nullptr);

            selectApplicationDialogUi.treeView->setModel(filterModel);
        }
        selectApplicationDialog->show();
    }
```

#### AUTO 


```{c}
const auto mimetype = action->property("mimeType").toString();
```

#### AUTO 


```{c}
const auto days = diff % 30;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", "preview.png"), ScreenhotRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            row->setData(hasColors, HasColorsRole);
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
const auto possible_ntputilities = {"ntpdate", "rdate"};
```

#### AUTO 


```{c}
auto it =
                new QStandardItem(i18nc("model - (x,y widthxheight)", "%1 - (%2,%3 %4x%5)", screen->model(), geo.x(), geo.y(), geo.width(), geo.height()));
```

#### AUTO 


```{c}
auto cat = std::find_if(m_components.begin(), m_components.end(), [&name] (const Component &c) {
            return c.id == name;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this, action, url, desktopEntryUrl] {
            KService::Ptr service = KService::serviceByDesktopPath(desktopEntryUrl.toLocalFile());
            if (!service) {
                return;
            }

            KRun::runService(*service, {url}, QApplication::activeWindow());
        }
```

#### AUTO 


```{c}
auto uniqueValues = values.toSet().values();
```

#### AUTO 


```{c}
const auto values = actionGroups.values(keyGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *combo : qAsConst(m_combos)) {
        initCombo(combo, allLocales);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : fileManagers) {
        combofileManager->addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if (fileManager->storageId() == service->storageId()) {
            combofileManager->setCurrentIndex(combofileManager->count() -1);
            m_currentIndex = combofileManager->count() -1;
        }
        if (service->storageId() == QStringLiteral("org.kde.dolphin.desktop")) {
            m_dolphinIndex = combofileManager->count() -1;
        }
    }
```

#### AUTO 


```{c}
auto entry = entryForResource(resource);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : activities) {
            KActivities::Info info(key);
            QIcon icon;
            const QString iconStr = info.icon();
            if (iconStr.isEmpty()) {
                icon = m_clearHistoryButton->icon();
            } else if (QFileInfo::exists(iconStr)) {
                icon = QIcon(iconStr);
            } else {
                icon = QIcon::fromTheme(iconStr);
            }
            QAction *singleActivity = installMenu->addAction(icon, i18nc("delete history for this activity", "For activity \"%1\"", info.name()));
            singleActivity->setEnabled(historyKeys.contains(key)); // Otherwise there would be nothing to delete
            connect(singleActivity, &QAction::triggered, this, [this, key]() {
                deleteHistoryGroup(key);
            });
            installMenu->addAction(singleActivity);
            m_clearHistoryButton->setText(i18n("Clear History…"));
        }
```

#### AUTO 


```{c}
auto flatDefault = m_defaultPointerAccelerationProfileFlat.val;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& component : m_components) {
        if (component.pendingDeletion) {
            removeComponent(component);
        }
        for (auto& shortcut : component.shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                const QStringList actionId = buildActionId(component.uniqueName, component.friendlyName,
                        shortcut.uniqueName, shortcut.friendlyName);
                //operator int of QKeySequence
                QList<int> keys(shortcut.activeShortcuts.cbegin(), shortcut.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << shortcut.activeShortcuts << keys;
                auto watcher = new QDBusPendingCallWatcher(m_globalAccelInterface->setForeignShortcut(actionId, keys));
                connect(watcher, &QDBusPendingCallWatcher::finished, this, [&, watcher] {
                    QDBusPendingReply<> reply = *watcher;
                    if (!reply.isValid()) {
                        qCCritical(KCMKEYS) << "Error while saving";
                        if (reply.error().isValid()) {
                            qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                        }
                        emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                            "Error while saving shortcut %1: %2", component.friendlyName, shortcut.friendlyName));
                    } else {
                        shortcut.initialShortcuts = shortcut.activeShortcuts;
                    }
                    watcher->deleteLater();
                });
            }
        }
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString, const QString &, Id)
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
        if( lang.isEmpty() || layoutInfo->isLanguageSupportedByVariant(variantInfo, lang) ) {
        	layoutDialogUi->variantComboBox->addItem(variantInfo->description, variantInfo->name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::DeviceInterface::Type internalType : interfaceTypes) {
        const QString typeName = Solid::DeviceInterface::typeToString( internalType );
        KDesktopFile typeFile(QStandardPaths::GenericDataLocation, "solid/devices/solid-device-" + typeName + ".desktop" );
        KConfigGroup tConfig = typeFile.desktopGroup();

        tConfig.writeEntry( "Name", "Solid Device" );
        tConfig.writeEntry( "X-KDE-ServiceTypes", "SolidDevice" );
        tConfig.writeEntry( "Type", "Service" );

        if( !tConfig.hasKey("X-KDE-Solid-Actions-Type") ) {
            tConfig.writeEntry( "X-KDE-Solid-Actions-Type", typeName );
        }

        const QStringList typeValues = availActions->propertyInternalList( internalType );
        const QString actionText = typeValues.join(QLatin1Char(';')).append(";");
        tConfig.writeEntry( "Actions", actionText );

        for (const QString &tValue : typeValues) {
            KConfigGroup vConfig = typeFile.actionGroup( tValue );
            if( !vConfig.hasKey("Name") ) {
                vConfig.writeEntry( "Name", availActions->propertyName( internalType, tValue ) );
            }
            vConfig.sync();
        }
        tConfig.sync();
        typeFile.sync();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<bool> reply = *cleanUpWatcher;
            cleanUpWatcher->deleteLater();
            if (!reply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling cleanUp of component") + uniqueName, reply.error());
                return;
            }
             auto it =  std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
                return c.uniqueName == uniqueName;
            });
            const int row = it - m_components.begin();
            beginRemoveRows(QModelIndex(), row, row);
            m_components.remove(row);
            endRemoveRows();
        }
```

#### AUTO 


```{c}
const auto childList = root->children();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &activity) { d->onActivityRemoved(activity); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &option : xkbOpts) {
        setxkbmapCommandArguments.append(QStringLiteral("-option"));
        setxkbmapCommandArguments.append(option);
    }
```

#### AUTO 


```{c}
auto ptr = std::make_shared<Backend>();
```

#### LAMBDA EXPRESSION 


```{c}
[componentUnique, componentFriendly](const KService::Ptr service) {
            return service->name() == componentUnique || service->name() == componentFriendly;
        }
```

#### AUTO 


```{c}
const auto ucs4Str = str.toUcs4();
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : qAsConst(layouts)) {
        layoutList.append(layoutUnit.layout());
        variants.append(layoutUnit.variant());
        displayNames.append(layoutUnit.getRawDisplayName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto  &keySequence : defaultShortcuts) {
            if (!keySequence.isEmpty()) {
                action.defaultShortcuts.insert(keySequence);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotConfigTrashBin();
    }
```

#### AUTO 


```{c}
auto it = std::find(configDefaultLayouts.begin(), configDefaultLayouts.end(), layoutUnit);
```

#### LAMBDA EXPRESSION 


```{c}
[this, enable](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<void> reply = *watcher;
            watcher->deleteLater();

            checkFirmwareSetupRequested();

            KMessageWidget *message = dialog->firmwareSetupMessageWidget;

            if (reply.isError()) {
                // User likely canceled the PolKit prompt, don't show an error in this case
                if (reply.error().type() != QDBusError::AccessDenied) {
                    message->setMessageType(KMessageWidget::Error);
                    message->setText(i18n("Failed to request restart to firmware setup: %1", reply.error().message()));
                    message->animatedShow();
                }
                return;
            }

            if (!enable) {
                return;
            }

            message->setMessageType(KMessageWidget::Information);
            if (m_isUefi) {
                message->setText(i18n("Next time the computer is restarted, it will enter the UEFI setup screen."));
            } else {
                message->setText(i18n("Next time the computer is restarted, it will enter the firmware setup screen."));
            }
            message->addAction(m_rebootNowAction);
            message->animatedShow();
        }
```

#### AUTO 


```{c}
const auto shortcuts = KGlobalAccel::self()->globalShortcut(
            QStringLiteral("ActivityManager"), QStringLiteral("switch-to-activity-") + activityId);
```

#### AUTO 


```{c}
const auto url2 = m_folderModel->resolvedUrl();
```

#### AUTO 


```{c}
const auto blocked = blockedApplications.contains(name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : m_components) {
        if (component.checked) {
            KConfigGroup mainGroup(&config, component.id);
            KConfigGroup group(&mainGroup, "Global Shortcuts");
            for (const auto& action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : list) {
        const int row = indexOfType(name);

        if (row != -1) {
            m_checkedRows[row] = true;
        }
    }
```

#### AUTO 


```{c}
auto runningActivities
        = m_activities.activities(KActivities::Info::Running);
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupProperties();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &layoutUnit : std::as_const(layoutsList)) {
        ret.append({layoutUnit.layout(), Flags::getShortText(layoutUnit, keyboardConfig), Flags::getLongText(layoutUnit, rules)});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values;
            uniqueValues.erase(std::unique(uniqueValues.begin(), uniqueValues.end()), uniqueValues.end());
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        }
```

#### AUTO 


```{c}
auto activityInfo = std::make_shared<Info>(id);
```

#### AUTO 


```{c}
auto it = std::find_if(m_folderList.begin(), m_folderList.end(), [nUrl](const FolderInfo &folder) {
        return folder.url == nUrl;
    });
```

#### AUTO 


```{c}
auto job = KIO::mostLocalUrl(url);
```

#### AUTO 


```{c}
auto job = KIO::filePreview(list, QSize(width, height));
```

#### AUTO 


```{c}
const auto screenPathWithScheme = screenUrl.url();
```

#### AUTO 


```{c}
const auto timeLeft = lastUsedTime(activityLeft);
```

#### RANGE FOR STATEMENT 


```{c}
for (ComponentData *cd : qAsConst(d->components)) {
        cd->editor()->undoChanges();
    }
```

#### AUTO 


```{c}
auto activityId = config.readEntry("activityId", QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service: offers) {
		ComponentSelector->addItem(service->name());
		m_lookupDict.insert(service->name(), service->desktopEntryName());
		m_revLookupDict.insert(service->desktopEntryName(), service->name());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : autostartDirFilesInfo) {
        QString fileName = fi.absoluteFilePath();
        const bool isSymlink = fi.isSymLink();
        if (isSymlink) {
            fileName = fi.symLinkTarget();
        }

        m_entries.push_back({fi.fileName(), isSymlink ? fileName : QString(), kind, true, fi.absoluteFilePath(), false, QStringLiteral("dialog-scripts")});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& shortcut : component.shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                const QStringList actionId = buildActionId(component.uniqueName, component.friendlyName,
                        shortcut.uniqueName, shortcut.friendlyName);
                //operator int of QKeySequence
                QList<int> keys(shortcut.activeShortcuts.cbegin(), shortcut.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << shortcut.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                        "Error while saving shortcut %1: %2", component.friendlyName, shortcut.friendlyName));
                } else {
                    shortcut.initialShortcuts = shortcut.activeShortcuts;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto componentGroupName : config.groupList()) {
        auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.uniqueName == componentGroupName;
        });
        if (component == m_components.end()) {
            qCWarning(KCMKEYS) << "Ignoring unknown component" << componentGroupName;
            continue;
        }
        KConfigGroup componentGroup(&config, componentGroupName);
        if (!componentGroup.hasGroup("Global Shortcuts")) {
            qCWarning(KCMKEYS) << "Group" << componentGroupName << "has no shortcuts group";
            continue;
        }
        KConfigGroup shortcutsGroup(&componentGroup, "Global Shortcuts");
        for (const auto& key : shortcutsGroup.keyList()) {
            auto shortcut = std::find_if(component->shortcuts.begin(), component->shortcuts.end(), [&] (const Shortcut &s) {
                return s.uniqueName == key;
            });
            if (shortcut == component->shortcuts.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            shortcut->activeShortcuts = QSet<QKeySequence>(shortcuts.cbegin(), shortcuts.cend());
        }
    }
```

#### AUTO 


```{c}
auto reply = m_managerDbusInterface->GetDefaultDevice();
```

#### AUTO 


```{c}
auto info = registerActivity(id);
```

#### AUTO 


```{c}
auto savedProxy2SourceScreen0 = expectedProxy2SourceScreen0;
```

#### LAMBDA EXPRESSION 


```{c}
[](const DeviceSettings *device) {
               return device->isSaveNeeded();
           }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &mod : modules) {
		QString servicePath = mod.metaDataFileName();

		// autoload defaults to false if it is not found
		const bool autoload = mod.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();
		const QString dbusModuleName = mod.value(QStringLiteral("X-KDE-DBus-ModuleName"));
		qCDebug(KCM_KDED) << "reading kded info from" << servicePath << "autoload =" << autoload << "dbus module name =" << dbusModuleName;

		// The logic has to be identical to Kded::initModules.
		// They interpret X-KDE-Kded-autoload as false if not specified
		//                X-KDE-Kded-load-on-demand as true if not specified
		if (autoload) {
			treeitem = new QTreeWidgetItem();
			treeitem->setCheckState(StartupUse, autoloadEnabled(&kdedrc, mod) ? Qt::Checked : Qt::Unchecked);
			treeitem->setText(StartupService, mod.name());
			treeitem->setText(StartupDescription, mod.description());
			treeitem->setText(StartupStatus, NOT_RUNNING);
			if (!dbusModuleName.isEmpty()) {
				treeitem->setData(StartupService, LibraryRole, dbusModuleName);
			} else {
				qCWarning(KCM_KDED) << "X-KDE-DBUS-ModuleName not set for module " << mod.name() << "from file" << mod.metaDataFileName();
				treeitem->setData(StartupService, LibraryRole, mod.fileName());
			}
			_lvStartup->addTopLevelItem(treeitem);
		}
		else if (isModuleLoadedOnDemand(mod)) {
			treeitem = new QTreeWidgetItem();
			treeitem->setText(OnDemandService, mod.name() );
			treeitem->setText(OnDemandDescription, mod.description());
			treeitem->setText(OnDemandStatus, NOT_RUNNING);
			if (!dbusModuleName.isEmpty()) {
				treeitem->setData(OnDemandService, LibraryRole, dbusModuleName);
			} else {
				qCWarning(KCM_KDED) << "X-KDE-DBUS-ModuleName not set for module " << mod.name() << "from file" << mod.metaDataFileName();
				treeitem->setData(OnDemandService, LibraryRole, mod.fileName());
			}
			_lvLoD->addTopLevelItem(treeitem);
		}
		else {
			qCWarning(KCM_KDED) << "kcmkded: Module " << mod.name() << "from file" << mod.metaDataFileName() << " not loaded on demand or startup! Skipping.";
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAbstractItemModel *model : qAsConst(m_models)) {
        if (model == sourceModel) {
            break;
        }
        rowsPrior += model->rowCount();
    }
```

#### AUTO 


```{c}
auto clientId = d->m_clientId;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layouts) {
        keyboardConfig->layouts.append(layoutUnit);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.values) {
        scoring.call(QStringLiteral("DeleteEarlierStats"), activity, months);
    }
```

#### AUTO 


```{c}
auto sortData = [&collator](const SourceData &a, const SourceData &b) {
        return collator.compare(a.display(), b.display()) < 0;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        for (int i = 0; i < fromIndices.count(); ++i)
        {
            const int from = fromIndices[i];
            const int to = toIndices[i];
            const int sourceRow = sourceRows[i];

            if (!toIndices.contains(from)) {
                m_proxyToSource.remove(from);
            }

            updateMaps(to, sourceRow);
            changed.append(index(from, 0));

            if (to < oldCount) {
               changed.append(index(to, 0));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.kksrc"));
        for (const QString &file : fileNames) {
            if (m_schemes.contains(file)) {
                continue;
            }
            m_schemes.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&destinationScript](KIO::Job * job, const QUrl & from, const QUrl & to) {
        Q_UNUSED(job)
        Q_UNUSED(from)

        // in case the destination filename had to be renamed
        destinationScript = to;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possible_ntputility : possible_ntputilities) {
    auto ntpUtility = QStandardPaths::findExecutable(possible_ntputility, path);
    if (!ntpUtility.isEmpty()) {
      qDebug() << "ntpUtility = " << ntpUtility;
      return;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotPopupNewDir();
            }
```

#### AUTO 


```{c}
auto &pathIt
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        Plasma::Package pkg = Plasma::PluginLoader::self()->loadPackage(QStringLiteral("Plasma/LookAndFeel"));
        pkg.setPath(path);
        pkg.setFallbackPackage(Plasma::Package());
        if (component.isEmpty() || !pkg.filePath(component.toUtf8()).isEmpty()) {
            packages << pkg;
        }
    }
```

#### AUTO 


```{c}
const auto activityLeft  = sourceModel()->data(sourceLeft, KActivities::ActivitiesModel::ActivityId);
```

#### AUTO 


```{c}
auto dlg = new KCMultiDialog();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& result: results) {
            qCDebug(KICKER_DEBUG) << "Got " << result.resource() << " -->";
            addResult(result.resource(), -1, false);
        }
```

#### AUTO 


```{c}
const auto& image
```

#### AUTO 


```{c}
auto reply = xcb_grab_keyboard_reply(QX11Info::connection(), cookie, nullptr);
```

#### AUTO 


```{c}
const auto index = modelIndex.row();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& containmentId: plasmaConfigContainments().groupList()) {
                const auto containment = plasmaConfigContainments().group(containmentId);
                const auto activity    = containment.readEntry("activityId", QString());

                // Ignore the containment if the activity is not defined
                if (activity.isEmpty()) continue;

                // If we have already found the same activity from another
                // containment, we are using the new one only if
                // the previous one was a color and not a proper wallpaper
                const bool processed = !ghostActivities.contains(activity) &&
                                        newForActivity.contains(activity);

                if (processed &&
                    newForActivity[activity][0] != '#') continue;

                // Marking the current activity as processed
                ghostActivities.removeAll(activity);

                const auto background = backgroundFromConfig(containment);

                if (background.isEmpty()) continue;

                if (newForActivity[activity] != background) {
                    changedActivities << activity;
                    newForActivity[activity] = background;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        emit changed(true);
        updateExample();
    }
```

#### AUTO 


```{c}
const auto components = pool.componentsById(service->desktopEntryName()+QLatin1String(".desktop"));
```

#### LAMBDA EXPRESSION 


```{c}
[url, desktopEntryUrl] {
            KService::Ptr service = KService::serviceByDesktopPath(desktopEntryUrl.toLocalFile());
            if (!service) {
                return;
            }

            auto *job = new KIO::ApplicationLauncherJob(service);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);

            job->setUrls({url});
            job->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : dataPaths) {
        QDir dir(path + "/plasma/look-and-feel");
        paths << dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
    }
```

#### AUTO 


```{c}
auto keyrelease = reinterpret_cast<xcb_key_release_event_t*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.values) {
        scoring.call("DeleteRecentStats", activity, count,
                what == Hours  ? "h" :
                what == Days   ? "d" :
                                 "m"
            );
    }
```

#### AUTO 


```{c}
auto &list
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &shortcutContext : shortcutContexts) {

        QDBusReply< QList<KGlobalShortcutInfo> > shortcutsRc =
            component.allShortcutInfos(shortcutContext);
        if (!shortcutsRc.isValid())
            {
            //qDebug() << "allShortcutInfos() failed for " << componentPath.path() << shortcutContext;
            continue;
            }
        const QList<KGlobalShortcutInfo> shortcuts = shortcutsRc;
        // Shouldn't happen. But you never know
        if (shortcuts.isEmpty()) {
            //qDebug() << "Got shortcut context" << shortcutContext << "without shortcuts for"
                //<< componentPath.path();
            continue;
        }

        // It's safe now
        const QString componentUnique = shortcuts[0].componentUniqueName();
        QString componentContextId = componentUnique;
        // kglobalaccel knows that '|' is our separator between
        // component and context
        if (shortcutContext != QLatin1String("default")) {
            componentContextId += QLatin1String("|") + shortcutContext;
        }

        // Create a action collection for our current component:context
        KActionCollection* col = new KActionCollection(
                q,
                componentContextId);

        // Now add the shortcuts.
        for (const KGlobalShortcutInfo &shortcut : shortcuts) {

            const QString &objectName = shortcut.uniqueName();
            QAction *action = col->addAction(objectName);
            action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
            action->setProperty("componentDisplayName", shortcut.componentFriendlyName());
            action->setText(shortcut.friendlyName());

            // Always call this to enable global shortcuts for the action. The editor widget
            // checks it.
            // Also actually loads the shortcut using the KAction::Autoloading mechanism.
            // Avoid setting the default shortcut; it would just be written to the global
            // configuration so we would not get the real one below.
            KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());

            // The default shortcut will never be loaded because it's pointless in a real
            // application. There are no scarce resources [i.e. physical keys] to manage
            // so applications can set them at will and there's no autoloading.
            QList<QKeySequence> sc = shortcut.defaultKeys();
            if (sc.count()>0) {
                KGlobalAccel::self()->setDefaultShortcut(action, sc);
            }
        }

        QString componentFriendlyName = shortcuts[0].componentFriendlyName();

        if (shortcuts[0].contextUniqueName() != QLatin1String("default"))
            {
            componentFriendlyName +=
                QString('[') + shortcuts[0].contextFriendlyName() + QString(']');
            }

        q->addCollection(col, componentPath, componentContextId, componentFriendlyName );

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &idx : persistentPendingDeletions) {
        const QString pluginName = idx.data(PluginNameRole).toString();
        const QString displayName = idx.data(Qt::DisplayRole).toString();

        Q_ASSERT(pluginName != m_settings->name());

        const QStringList arguments = {QStringLiteral("-t"), QStringLiteral("theme"), QStringLiteral("-r"), pluginName};

        QProcess *process = new QProcess(this);
        connect(process, static_cast<void (QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished), this,
            [this, process, idx, pluginName, displayName](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus)
                if (exitCode == 0) {
                    m_model->removeRow(idx.row());
                } else {
                    emit showErrorMessage(i18n("Removing theme failed: %1",
                                               QString::fromLocal8Bit(process->readAllStandardOutput().trimmed())));
                    m_model->setData(idx, false, PendingDeletionRole);
                }
                process->deleteLater();
            });

        process->start(program, arguments);
        process->waitForFinished(); // needed so it deletes fine when "OK" is clicked and the dialog destroyed
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    }
```

#### AUTO 


```{c}
auto recentDescriptions = m_settings.recentDescriptions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &prop : props) {
        m_props << prop.toMap();
    }
```

#### AUTO 


```{c}
auto query = _query + limitOffsetSuffix();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : d->windowModels) {
            windowModel->setVirtualDesktop();

            windowModel->setActivity(runningActivities.at(activityIndex));
            ++activityIndex;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto device : qAsConst(m_devices)) {
        device->save();
    }
```

#### AUTO 


```{c}
const auto &shortcutInfo
```

#### AUTO 


```{c}
auto foundCount = properties.constFind(QStringLiteral("count"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &module : modules) {
        QString servicePath = module.metaDataFileName();

        // autoload defaults to false if it is not found
        const bool autoload = module.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();
        // keep estimating dbusModuleName in sync with KDEDModule (kdbusaddons) and kded (kded)
        // currently (KF5) the module name in the D-Bus object path is set by the pluginId
        const QString dbusModuleName = module.pluginId();
        qCDebug(KCM_KDED) << "reading kded info from" << servicePath << "autoload =" << autoload << "dbus module name =" << dbusModuleName;

        if (knownModules.contains(dbusModuleName)) {
            continue;
        }

        knownModules.append(dbusModuleName);

        KConfigGroup cg(&kdedrc, QStringLiteral("Module-%1").arg(dbusModuleName));
        const bool autoloadEnabled = cg.readEntry("autoload", true);

        ModulesModelData data{
            module.name(),
            module.description(),
            KDEDConfig::UnknownType,
            autoloadEnabled,
            dbusModuleName
        };

        // The logic has to be identical to Kded::initModules.
        // They interpret X-KDE-Kded-autoload as false if not specified
        //                X-KDE-Kded-load-on-demand as true if not specified
        if (autoload) {
            data.type = KDEDConfig::AutostartType;
            autostartModules << data;
        } else if (isModuleLoadedOnDemand(module)) {
            data.type = KDEDConfig::OnDemandType;
            onDemandModules << data;
        } else {
            qCWarning(KCM_KDED) << "kcmkded: Module " << module.name() << "from file" << module.metaDataFileName() << " not loaded on demand or startup! Skipping.";
            continue;
        }
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString, const QString &, Description)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : _numlockButtonGroup->buttons()) {
        setDefaultIndicatorVisible(button, m_highlightVisible && !isNumLockDefault && _numlockButtonGroup->checkedButton() == button);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activity : {m_currentActivity, m_alternativeActivity}) {
            m_screenMapper->addMapping(url, i, activity);
        }
```

#### AUTO 


```{c}
auto watcher = new QFutureWatcher<void>();
```

#### AUTO 


```{c}
const auto str = keySymToString(keysym);
```

#### AUTO 


```{c}
auto *screenMapper = ScreenMapper::instance();
```

#### AUTO 


```{c}
const auto &windows = KWindowSystem::windows();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : query) {
                return item[0].toString();
            }
```

#### AUTO 


```{c}
auto query = UsedResources | RecentlyUsedFirst | Agent(storageId) | Type::files() | Activity::current() | Url::file();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &scheme](const ColorsModelData &item) {
        return item.schemeName == scheme;
    }
```

#### AUTO 


```{c}
const auto path = QStringLiteral("desktop:/");
```

#### LAMBDA EXPRESSION 


```{c}
[](XkbDescPtr obj) {
        XkbFreeKeyboard(obj, 0, True);
    }
```

#### AUTO 


```{c}
const auto destination =
            query.ordering() == HighScoredFirst ?
                cache.lowerBound(score, member(&ResultSet::Result::score) > _) :
            query.ordering() == RecentlyUsedFirst ?
                cache.lowerBound(lastUpdate, member(&ResultSet::Result::lastUpdate) > _) :
            query.ordering() == RecentlyCreatedFirst ?
                cache.lowerBound(firstUpdate, member(&ResultSet::Result::firstUpdate) > _) :
            // otherwise
                cache.lowerBound(resource, member(&ResultSet::Result::resource) > _)
            ;
```

#### AUTO 


```{c}
auto view = new QQuickView();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : archiveEntries) {
        if (file.baseName() == scriptPrefix) {
            installerPath = file.absoluteFilePath();
            // If the name is exactly install/uninstall we immediately take it
            break;
        } else if (file.baseName().startsWith(scriptPrefix)) {
            installerPath = file.absoluteFilePath();
        }
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QKeySequence, const QKeySequence &, Shortcut)
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XIDeviceInfo *info) {
        int deviceid = info->deviceid;
        Status status;
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        //data returned is an 2 byte boolean
        status = XIGetProperty(m_dpy, deviceid, m_libinputAccelProfileAvailableAtom, 0, 2,
                                False, XA_INTEGER, &type_return, &format_return,
                                &num_items_return, &bytes_after_return, &_data);
        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;
        if (status != Success || type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 2) {
            return;
        }
        adaptiveAvailable = adaptiveAvailable || data[0];
        flatAvailable = flatAvailable || data[1];

        //data returned is an 2 byte boolean
        status = XIGetProperty(m_dpy, deviceid, m_libinputAccelProfileEnabledAtom, 0, 2,
                                False, XA_INTEGER, &type_return, &format_return,
                                &num_items_return, &bytes_after_return, &_data);
        data.reset(_data);
        _data = nullptr;
        if (status != Success || type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 2) {
            return;
        }
        adaptiveEnabled = adaptiveEnabled || data[0];
        flatEnabled = flatEnabled || data[1];
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && m_screenMapper) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = QUrl::fromUserInput(m_url, {}, QUrl::AssumeLocalFile);
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl.toString(), m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url.toString(), m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto timeRight = lastUsedTime(activityRight);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &actionInfo : info) {
        const QString &actionUnique = actionInfo.uniqueName();
        const QString &actionFriendly = actionInfo.friendlyName();
        Action action;
        action.id = actionUnique;
        action.displayName = actionFriendly;
        const QList<QKeySequence> defaultShortcuts = actionInfo.defaultKeys();
        for (const auto &keySequence : defaultShortcuts) {
            if (!keySequence.isEmpty()) {
                action.defaultShortcuts.insert(keySequence);
            }
        }
        const QList<QKeySequence> activeShortcuts = actionInfo.keys();
        for (const QKeySequence &keySequence : activeShortcuts) {
            if (!keySequence.isEmpty()) {
                action.activeShortcuts.insert(keySequence);
            }
        }
        action.initialShortcuts = action.activeShortcuts;
        c.actions.push_back(action);
    }
```

#### AUTO 


```{c}
auto newBlockEnd = newBlockStart;
```

#### AUTO 


```{c}
auto root = widget->rootObject();
```

#### AUTO 


```{c}
auto index = [](KStandardShortcut::Category category) {
        return static_cast<int>(category);
    };
```

#### AUTO 


```{c}
auto app = QCoreApplication::instance();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: query.activities()) {
        for (const auto& agent: query.agents()) {
            for (const auto& urlFilter: query.urlFilters()) {
                scoring.call("DeleteStatsForResource", activity, agent, urlFilter);
            }
        }
    }
```

#### AUTO 


```{c}
auto componentsWatcher = new  QDBusPendingCallWatcher( m_globalAccelInterface->allComponents());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QKeySequence &key : qAsConst(action.activeShortcuts)) {
                    keys.append(key[0]);
                }
```

#### AUTO 


```{c}
auto volume = devive.as<Solid::StorageVolume>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &resource) {
                    addResult(resource, -1);
                }
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), ThemeNameRole, themeName);
```

#### LAMBDA EXPRESSION 


```{c}
[nUrl](const FolderInfo& folder) {
            return folder.url == nUrl;
        }
```

#### AUTO 


```{c}
const auto screens = qGuiApp->screens();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &proxyPersistentIndex : persistentIndexList) {
        proxyIndexes << proxyPersistentIndex;
        Q_ASSERT(proxyPersistentIndex.isValid());
        const QPersistentModelIndex srcPersistentIndex = q->mapToSource(proxyPersistentIndex);
        Q_ASSERT(srcPersistentIndex.isValid());
        layoutChangePersistentIndexes << srcPersistentIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        KPackage::Package pkg = KPackage::PackageLoader::self()->loadPackage(QStringLiteral("Plasma/LookAndFeel"));
        pkg.setPath(path);
        pkg.setFallbackPackage(KPackage::Package());
        if (component.isEmpty() || !pkg.filePath(component.toUtf8()).isEmpty()) {
            packages << pkg;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            q->refresh();
        }
```

#### AUTO 


```{c}
const auto jumpListActions = service->actions();
```

#### AUTO 


```{c}
auto &action
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c) {
            return c.id == componentGroupName;
        }
```

#### AUTO 


```{c}
const auto& window
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandDevice *>(t)->applyConfig();
    }
```

#### AUTO 


```{c}
const auto sourceRow = sourceIndex.row();
```

#### AUTO 


```{c}
const auto activityRight =
          sourceModel()->data(sourceRight, KActivities::ActivitiesModel::ActivityId);
```

#### AUTO 


```{c}
const auto allShortcuts = allShortcutsCall.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &style) {
        styleSettings()->setWidgetStyle(style);
    }
```

#### AUTO 


```{c}
auto stdStrSalt = salt.toStdString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KimpanelLookupTable::Entry &entry : lookupTable.entries) {
        m_labels << entry.label;
        m_texts << entry.text;
    }
```

#### AUTO 


```{c}
auto ptr = std::make_shared<Database>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
        KStandardShortcut::StandardShortcut id = KStandardShortcut::findByName(key);
        if (id == KStandardShortcut::AccelNone) {
            qCWarning(KCMKEYS) << "Unknown standard shortcut" << key;
            continue;
        }
        QString name;
        switch (category(id)) {
        case KStandardShortcut::Category::File:
            name = "File";
            break;
        case KStandardShortcut::Category::Edit:
            name = "Edit";
            break;
        case KStandardShortcut::Category::Navigation:
            name = "Navigation";
            break;
        case KStandardShortcut::Category::View:
            name = "View";
            break;
        case KStandardShortcut::Category::Settings:
            name = "Settings";
            break;
        case KStandardShortcut::Category::Help:
            name = "Help";
            break;
        }
        auto cat = std::find_if(m_components.begin(), m_components.end(), [&name](const Component &c) {
            return c.id == name;
        });
        if (cat == m_components.end()) {
            qCWarning(KCMKEYS) << "No category for standard shortcut" << key;
            continue;
        }
        auto action = std::find_if(cat->actions.begin(), cat->actions.end(), [&](const Action &a) {
            return a.id == key;
        });
        if (action == cat->actions.end()) {
            qCWarning(KCMKEYS) << "Model doesn't include action" << key;
            continue;
        }
        const auto shortcuts = QKeySequence::listFromString(group.readEntry(key));
        const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
        if (shortcutsSet != action->activeShortcuts) {
            action->activeShortcuts = shortcutsSet;
            const QModelIndex i = index(action - cat->actions.begin(), 0, index(cat - m_components.begin(), 0));
            Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
        }
    }
```

#### AUTO 


```{c}
auto result = d->features->GetValue(QStringLiteral("org.kde.ActivityManager.Resources.Scoring/isOTR/") + activity);
```

#### LAMBDA EXPRESSION 


```{c}
[this, user, item] {
                auto idx = index(m_userList.lastIndexOf(user));
                Q_EMIT dataChanged(idx, idx, {item.second});
            }
```

#### AUTO 


```{c}
auto reply = m_fprintInterface->DeleteEnrolledFingers2();
```

#### AUTO 


```{c}
auto dialog = new Dialog(id);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx) {
        return QPersistentModelIndex(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setShouldShowSwitcher(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : it->actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                const QStringList actionId = buildActionId(it->id, it->displayName, action.id, action.displayName);
                // TODO: pass action.activeShortcuts to m_globalAccelInterface->setForeignShortcut() as a QSet<QKeySequence>
                // or QList<QKeySequence>?
                QList<int> keys;
                keys.reserve(action.activeShortcuts.size());
                for (const QKeySequence &key : qAsConst(action.activeShortcuts)) {
                    keys.append(key[0]);
                }
                qCDebug(KCMKEYS) << "Saving" << actionId << action.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                                            "Error while saving shortcut %1: %2",
                                            it->displayName,
                                            it->displayName));
                } else {
                    action.initialShortcuts = action.activeShortcuts;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &info : oldStylePlugins) {
        if (moduleIds.contains(info.pluginName())) {
            qCWarning(KCM_KDED).nospace() << "kded module " << info.pluginName() << " has already been found using "
            "JSON metadata, please don't install the now unneeded .desktop file (" << info.entryPath() << ").";
        } else {
            qCDebug(KCM_KDED).nospace() << "kded module " << info.pluginName() << " still uses .desktop files ("
            << info.entryPath() << "). Please port it to JSON metadata.";
            plugins.append(info.toMetaData());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : activities) {
            KActivities::Info info(key);
            QIcon icon;
            const QString iconStr = info.icon();
            if (iconStr.isEmpty()) {
                icon = m_clearHistoryButton->icon();
            } else if (QFileInfo::exists(iconStr)) {
                icon = QIcon(iconStr);
            } else {
                icon = QIcon::fromTheme(iconStr);
            }
            QAction *singleActivity = installMenu->addAction(icon,
                    i18nc("delete history for this activity", "For activity \"%1\"", info.name()));
            singleActivity->setEnabled(historyKeys.contains(key)); // Otherwise there would be nothing to delete
            connect(singleActivity, &QAction::triggered, this, [this, key](){ deleteHistoryGroup(key); });
            installMenu->addAction(singleActivity);
            m_clearHistoryButton->setText(i18n("Clear History..."));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &parent, int from, int to) {
                if (parent.isValid()) {
                    qWarning() << "We do not support tree models";

                } else {
                    beginRemoveRows(QModelIndex(),
                                    sourceRowToRow(from),
                                    sourceRowToRow(to));
                }
            }
```

#### AUTO 


```{c}
auto showError = [this, fileUrl]() {
        Q_EMIT showErrorMessage(i18n("%1 is not a valid GTK Theme archive.", fileUrl.fileName()));
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &iconNames : s_previewIcons) {
        const QString cacheKey = themeName + QLatin1Char('@') + QString::number(size) + QLatin1Char('@')
            + QString::number(dpr,'f',1) + QLatin1Char('@') + iconNames.join(QLatin1Char(','));

        QPixmap pix;
        if (!QPixmapCache::find(cacheKey, pix)) {
            if (!theme) {
                theme.reset(new KIconTheme(themeName));
            }

            pix = getBestIcon(*theme.data(), iconNames, size, dpr);

            // Inserting a pixmap even if null so we know whether we searched for it already
            QPixmapCache::insert(cacheKey, pix);
        }

        if (pix.isNull()) {
            continue;
        }

        pixmaps.append(pix);

        if (limit > -1 && pixmaps.count() >= limit) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (OptionInfo *optionInfo : qAsConst(optionGroupInfo->optionInfos)) {
			optionInfo->description = translate_description(optionInfo);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen* screen : screens) {
        configureScreen(screen);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addedApp : addedList) {
        // without .desktop extension
        auto service = KService::serviceByStorageId(addedApp.mid(0, addedApp.length() -8));
        if (!service) {
            service = KService::serviceByStorageId(addedApp);
        }
        if (!service) {
            continue;
        }
        // avoid duplicates entry when email clients are present in mimeapps.list's Added Associations too
        const bool isServiceAlreadyInserted = std::none_of(emailClients.constBegin(), emailClients.constEnd(), [service] (const KService::Ptr &serv) { return service->storageId() == serv->storageId(); });
        if (isServiceAlreadyInserted) {
            const auto icon = QIcon::fromTheme(!service->icon().isEmpty() ? service->icon() : QStringLiteral("application-x-shellscript"));
            addItem(icon, service->name() + " (" + KShell::tildeCollapse(service->entryPath()) + ")", service->storageId());

            if (emailClientService && emailClientService->storageId() == service->storageId()) {
                setCurrentIndex(count() - 1);
                m_currentIndex = count() - 1;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this,job] (const KFileItem& item) {
                    Q_UNUSED(item);
                    qWarning() << "SwitcherBackend: FAILED to get the thumbnail"
                               << job->errorString()
                               << job->detailedErrorStrings();
                    emit finished();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
                qDebug() << "%%% Inhibit stopped";
                m_isTriggerInhibited = false;
            }
```

#### AUTO 


```{c}
auto walResult = ptr->pragma(QStringLiteral("journal_mode = WAL"));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            if (infoReply.value().isEmpty()) {
                qCWarning(KCMKEYS()) << "New component has no shortcuts:" << reply.value().path();
                Q_EMIT errorOccured(i18nc("%1 is the name of an application", "Error while adding %1, it seems it has no actions."));
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &iconName : iconNames) {
            QString path = theme.iconPath(QStringLiteral("%1.png").arg(iconName), iconSize, KIconLoader::MatchBest);
            if (!path.isEmpty()) {
                QPixmap pixmap(path);
                pixmap.setDevicePixelRatio(dpr);
                return pixmap;
            }

            //could not find the .png, try loading the .svg or .svgz
            path = theme.iconPath(QStringLiteral("%1.svg").arg(iconName), iconSize, KIconLoader::MatchBest);
            if (path.isEmpty()) {
                path = theme.iconPath(QStringLiteral("%1.svgz").arg(iconName), iconSize, KIconLoader::MatchBest);
            }

            if (path.isEmpty()) {
                continue;
            }

            if (!renderer.load(path)) {
                continue;
            }

            QPixmap pixmap(iconSize, iconSize);
            pixmap.setDevicePixelRatio(dpr);
            pixmap.fill(QColor(Qt::transparent));
            QPainter p(&pixmap);
            p.setViewport(0, 0, size, size);
            renderer.render(&p);
            return pixmap;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, styleName] {
        if (!m_styleConfigDialog->isDirty()) {
            return;
        }

        // Force re-rendering of the preview, to apply settings
        emit styleReconfigured(styleName);

        //For now, ask all KDE apps to recreate their styles to apply the setitngs
        KGlobalSettings::self()->emitChange(KGlobalSettings::StyleChanged);

        // When user edited a style, assume they want to use it, too
        m_settings->setWidgetStyle(styleName);

        // We call setNeedsSave(true) here to make sure we force style re-creation
        setNeedsSave(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, lineEdit]() {
            Q_EMIT const_cast<LabelEditDelegate *>(this)->commitData(lineEdit);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : newEntries.first().installedFiles()) {
                    const QString fileName = path.section(QLatin1Char('/'), -1, -1);

                    const int suffixPos = fileName.indexOf(suffix);
                    if (suffixPos != fileName.length() - suffix.length()) {
                        continue;
                    }

                    installedThemes.append(fileName.left(suffixPos));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStorageInfo &si : QStorageInfo::mountedVolumes()) {
        mountPoints.append(si.rootPath());
    }
```

#### AUTO 


```{c}
auto buttons = new QDialogButtonBox(QDialogButtonBox::Yes | QDialogButtonBox::No, dialog);
```

#### AUTO 


```{c}
const auto &service
```

#### AUTO 


```{c}
const auto internal = m_dirModel->dirLister()->url().toString();
```

#### AUTO 


```{c}
const auto browser = KMimeTypeTrader::self()->preferredService("x-scheme-handler/http");
```

#### AUTO 


```{c}
const auto activityRight = sourceModel()->data(sourceRight, KActivities::ActivitiesModel::ActivityId).toString();
```

#### AUTO 


```{c}
auto w = qobject_cast<QQuickWindow *>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen* screen : qGuiApp->screens()) {
        configureScreen(screen);
    }
```

#### AUTO 


```{c}
auto cat = std::find_if(m_components.begin(), m_components.end(), [&name](const Component &c) {
            return c.id == name;
        });
```

#### AUTO 


```{c}
auto deleteShortcuts = m_action->shortcuts();
```

#### AUTO 


```{c}
auto screens = m_screensPerPath[screenUrl];
```

#### AUTO 


```{c}
auto foundEntry = m_launchers.find(storageId);
```

#### LAMBDA EXPRESSION 


```{c}
[this, process, idx, pluginName, displayName](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus)
                if (exitCode == 0) {
                    m_model->removeRow(idx.row());
                } else {
                    emit showErrorMessage(i18n("Removing theme failed: %1",
                                               QString::fromLocal8Bit(process->readAllStandardOutput().trimmed())));
                    m_model->setData(idx, false, PendingDeletionRole);
                }
                process->deleteLater();
            }
```

#### AUTO 


```{c}
auto it = std::find_if(m_folderList.begin(), m_folderList.end(),
        [nUrl](const FolderInfo& folder) {
            return folder.url == nUrl;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : qAsConst(windowModels)) {
                windowModel->setActivity(activityInfo->currentActivity());
            }
```

#### AUTO 


```{c}
auto model = const_cast<BaseModel*>(static_cast<const BaseModel*>(index.model()));
```

#### AUTO 


```{c}
auto watcher = new QFutureWatcher<_ReturnType>();
```

#### AUTO 


```{c}
const auto &addedApp
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), SchemeNameRole, schemeName);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &activity) { d->onActivityAdded(activity); }
```

#### AUTO 


```{c}
auto &component
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &window : windows) {
        KWindowInfo info(window, NET::WMVisibleName, NET::WM2Activities);
        const QStringList activities = info.activities();

        if (activities.isEmpty() || activities.contains(QLatin1String{"00000000-0000-0000-0000-000000000000"}))
            continue;

        for (const auto &activity : activities) {
            m_activitiesWindows[activity] << window;
        }
    }
```

#### AUTO 


```{c}
auto ordering = queryDefinition.ordering();
```

#### RANGE FOR STATEMENT 


```{c}
for (CfgPlugin *plugin: qAsConst(configWidgetMap)) {
        somethingChanged |= plugin->hasChanged();
        isDefaults &= plugin->isDefaults();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT changed(true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        if (folderUrl != url.adjusted(QUrl::RemoveFilename)) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](InputDevice *dev) {
        return dev->isDefaults();
    }
```

#### AUTO 


```{c}
const auto end = urlFilters.end();
```

#### AUTO 


```{c}
const auto url = stringToUrl(entry);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : settingsExcluded) {
        m_folderList.append(folderListEntry(folder, false, true));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : mimeData->urls()) {
                    m_dropTargetPositions.insert(url.fileName(), dropPos);
                    m_screenMapper->addMapping(mappableUrl(url), m_screen, ScreenMapper::DelayedSignal);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[sysName](QObject *t) {
        return static_cast<KWinWaylandTouchpad *>(t)->sysName() == sysName;
    }
```

#### AUTO 


```{c}
auto it = m_dropTargetPositions.find(url.fileName());
```

#### AUTO 


```{c}
const auto p = outline->points + i;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionDir : actionDirs) {
        QDirIterator it(actionDir, QStringList() << QStringLiteral("*.desktop"));
        while (it.hasNext()) {
            it.next();
            const QString desktop = it.filePath();
            const KService::Ptr desktopService = KService::serviceByStorageId(it.filePath());
            // Get contained services list
            const QList<KServiceAction> services = KDesktopFileActions::userDefinedServices(*desktopService, true);
            for (const KServiceAction &deviceAction : services) {
                ActionItem *actionItem = new ActionItem(desktop, deviceAction.name(), this); // Create an action
                d->actions.append(actionItem);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attribute &attr : attr_list) {
        int type = (int)attr.get_type();
        unsigned int start = attr.get_start();
        unsigned int length = attr.get_length();
        unsigned int value = attr.get_value();
        result += QString("%1:%2:%3:%4;").arg(type).arg(start).arg(length).arg(value);
    }
```

#### AUTO 


```{c}
const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        Plasma::Package pkg = Plasma::PluginLoader::self()->loadPackage("Plasma/LookAndFeel");
        pkg.setPath(path);
        if (component.isEmpty() || !pkg.filePath(component.toUtf8()).isEmpty()) {
            packages << pkg;
        }
    }
```

#### AUTO 


```{c}
const auto timeLeft  = lastUsedTime(activityLeft.toString());
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &item) {
                          return normalizedId(item).value();
                       }
```

#### AUTO 


```{c}
auto ptr = s_instance.lock();
```

#### AUTO 


```{c}
auto service = KService::serviceByStorageId(settings.terminalService());
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigSkeletonItem *i : itemList) {
        QString name(i->name());

        QWidget *child = parent->findChild<QWidget *>(kcfgPrefix + name);
        if (!child) {
            continue;
        }
        m_widgets[name] = child;

        /* FIXME: this should probably be less hackish */
        if (name == "Tapping" && !supported.contains("Tapping"))
            qobject_cast<QGroupBox *>(child)->setCheckable(false);
        else if (!supported.contains(name)) {
            child->setEnabled(false);
        }

        KCoreConfigSkeleton::ItemEnum *asEnum = dynamic_cast<KCoreConfigSkeleton::ItemEnum *>(i);
        if (!asEnum) {
            continue;
        }

        QStringList choiceList;
        const auto asEnumChoices = asEnum->choices();
        for (const auto &choice : asEnumChoices) {
            choiceList.append(!choice.label.isEmpty() ? choice.label : choice.name);
        }

        KComboBox *asComboBox = qobject_cast<KComboBox *>(child);
        if (asComboBox) {
            asComboBox->addItems(choiceList);
        }
    }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString, const QString &, Wallpaper)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : recent) {
            m_emoji += {c, recentDescriptions.at(i++), QString{}, {}};
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!m_dropTargetPositions.isEmpty()) {
            setSortMode(-1);
        }
    }
```

#### AUTO 


```{c}
auto *xkbOptionModel = dynamic_cast<XkbOptionsTreeModel *>(uiWidget->xkbOptionsTreeView->model());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c) {
                return c.uniqueName == uniqueName;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : filesInfo) {
        if (!KDesktopFile::isDesktopFile(fi.fileName())) {
            continue;
        }

        const AutostartEntry entry = loadDesktopEntry(fi.absoluteFilePath());

        if (!checkEntry(entry)) {
            continue;
        }

        m_entries.push_back(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            const QString path = dir + QLatin1Char('/') + file;
            KConfig scheme(path, KConfig::SimpleConfig);
            const QString name = KConfigGroup(&scheme, "Settings").readEntry("Name", file);
            schemes.append(QVariantMap({{"name", name}, {"url", QUrl::fromLocalFile(path)}}));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_effectsDirty = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QKeySequence &keySequence : activeShortcuts) {
            if (!keySequence.isEmpty()) {
                action.activeShortcuts.insert(keySequence);
            }
        }
```

#### AUTO 


```{c}
const auto currentRowCount = sourceModel()->rowCount();
```

#### LAMBDA EXPRESSION 


```{c}
[path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            }
```

#### AUTO 


```{c}
const auto pendingDeletions = m_model->match(m_model->index(0, 0), PendingDeletionRole, true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& key : shortcutsGroup.keyList()) {
            auto shortcut = std::find_if(component->shortcuts.begin(), component->shortcuts.end(), [&] (const Shortcut &s) {
                return s.uniqueName == key;
            });
            if (shortcut == component->shortcuts.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            shortcut->activeShortcuts = QSet<QKeySequence>(shortcuts.cbegin(), shortcuts.cend());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setDragging(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &error) {
            fail(error);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const ThemesModelData &item) {
            return item.pluginName == packageName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        (void)new KRun(url, nullptr);
    }
```

#### AUTO 


```{c}
const auto &urls = selectedUrls(true);
```

#### LAMBDA EXPRESSION 


```{c}
[this, fileUrl]() {
        Q_EMIT showErrorMessage(i18n("%1 is not a valid GTK Theme archive.", fileUrl.fileName()));
    }
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent(QStringLiteral("KTp"))
                    | Type::any()
                    | Activity::current()
                    | Url::startsWith(QStringLiteral("ktp"))
                    | Limit(15);
```

#### LAMBDA EXPRESSION 


```{c}
[&](XDeviceInfo *info) {
        Atom property = m_pointerAccelerationProfileFlat.atom;
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;
        unsigned char *_data = nullptr;

        auto status =
            XIGetProperty(m_dpy, info->id, property, 0, 1, False, XA_INTEGER, &type_return, &format_return, &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;

        if (type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 2) {
            return;
        }

        if (data[0] == 1 && data[1] == 0) {
            flatProfile = false;
        }
    }
```

#### AUTO 


```{c}
const auto destination =
            query.ordering() == HighScoredFirst      ? ORDER_BY_FULL(score):
            query.ordering() == RecentlyUsedFirst    ? ORDER_BY_FULL(lastUpdate):
            query.ordering() == RecentlyCreatedFirst ? ORDER_BY_FULL(firstUpdate):
            // otherwise
            cache.lowerBound(ORDER_BY(linkStatus) && ORDER_BY(resource))
            ;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &result: results) {
        DEBUG << "Returning" << result.linkedActivities() << "for" << id << url;
        return result.linkedActivities();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {m_lnfDirty = true;}
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setStatus(Status::Ready);
        emit listingCompleted();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &result: results) {
        qCDebug(KICKER_DEBUG) << "Returning" << result.linkedActivities() << "for" << id << url;
        return result.linkedActivities();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XIDeviceInfo *info) {
            int deviceid = info->deviceid;
            Status status;
            Atom type_return;
            int format_return;
            unsigned long num_items_return;
            unsigned long bytes_after_return;

            unsigned char *_data = nullptr;
            //data returned is an 2 byte boolean
            status = XIGetProperty(m_dpy, deviceid, m_libinputAccelProfileAvailableAtom, 0, 2,
                                    False, XA_INTEGER, &type_return, &format_return,
                                    &num_items_return, &bytes_after_return, &_data);
            QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
            _data = nullptr;
            if (status != Success || type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 2) {
                return;
            }
            adaptiveAvailable = adaptiveAvailable || data[0];
            flatAvailable = flatAvailable || data[1];

            //data returned is an 2 byte boolean
            status = XIGetProperty(m_dpy, deviceid, m_libinputAccelProfileEnabledAtom, 0, 2,
                                    False, XA_INTEGER, &type_return, &format_return,
                                    &num_items_return, &bytes_after_return, &_data);
            data.reset(_data);
            _data = nullptr;
            if (status != Success || type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 2) {
                return;
            }
            adaptiveEnabled = adaptiveEnabled || data[0];
            flatEnabled = flatEnabled || data[1];
        }
```

#### AUTO 


```{c}
const auto days    = diff % 30;
```

#### RANGE FOR STATEMENT 


```{c}
for (const int row : qAsConst(selectionRows)) {
            QModelIndex topLeft = layoutsTableModel->index(row, 0, QModelIndex());
            QModelIndex bottomRight = layoutsTableModel->index(row, layoutsTableModel->columnCount(topLeft) - 1, QModelIndex());
            selection << QItemSelectionRange(topLeft, bottomRight);
        }
```

#### AUTO 


```{c}
auto databaseRemove = qScopeGuard([&] {
        QSqlDatabase::removeDatabase(database.connectionName());
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceFile : autostartServices) {
                    KService service(serviceFile + QStringLiteral(".desktop"));
                    KAutostart as(serviceFile);
                    as.setCommand(service.exec());
                    as.setAutostarts(true);
                    if (qEnvironmentVariableIsSet("KDE_FULL_SESSION")) {
                        KRun::runApplication(service, {}, nullptr);
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().values();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(Other,   QKeySequence, const QKeySequence &, Shortcut)
```

#### LAMBDA EXPRESSION 


```{c}
[&engine](const QStringList & /*arguments*/, const QString & /*workingDirectory*/) {
        for (QObject *object : engine.rootObjects()) {
            auto w = qobject_cast<QQuickWindow *>(object);
            if (!w)
                continue;

            if (w && QX11Info::isPlatformX11())
                KStartupInfo::setNewStartupId(w, QX11Info::nextStartupId());

            w->setVisible(true);
            w->raise();
        }
    }
```

#### AUTO 


```{c}
auto cookie = xcb_grab_keyboard(QX11Info::connection(), false, w, XCB_CURRENT_TIME, XCB_GRAB_MODE_ASYNC, XCB_GRAB_MODE_ASYNC);
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandDevice *>(t)->isChangedConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : it->actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                const QStringList actionId = buildActionId(it->id, it->displayName, action.id, action.displayName);
                // TODO: pass action.activeShortcuts to m_globalAccelInterface->setForeignShortcut() as a QSet<QKeySequence>
                // or QList<QKeySequence>?
                QList<int> keys;
                keys.reserve(action.activeShortcuts.size());
                for (const QKeySequence &key : qAsConst(action.activeShortcuts)) {
                    keys.append(key[0]);
                }
                qCDebug(KCMKEYS) << "Saving" << actionId << action.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    Q_EMIT errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                                              "Error while saving shortcut %1: %2",
                                              it->displayName,
                                              it->displayName));
                } else {
                    action.initialShortcuts = action.activeShortcuts;
                }
            }
        }
```

#### AUTO 


```{c}
const auto icon = QIcon::fromTheme(!service->icon().isEmpty() ? service->icon() : QStringLiteral("application-x-shellscript"));
```

#### AUTO 


```{c}
const auto &bookmark = placesModel.bookmarkForUrl(oldUrl);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (pagerType == VirtualDesktops && windowModels.count()) {
            for (auto windowModel : qAsConst(windowModels)) {
                windowModel->setActivity(activityInfo->currentActivity());
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &resource) {
                    removeResult(resource);
                }
```

#### AUTO 


```{c}
const auto query
```

#### AUTO 


```{c}
auto &jobs = m_storageIdToJobs[storageId];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionDir : actionDirs) {
        QDirIterator it(actionDir, QStringList() << QStringLiteral("*.desktop"));
        while (it.hasNext()) {
            it.next();
            const QString desktop = it.filePath();
            // Get contained services list
            const QList<KServiceAction> services = KDesktopFileActions::userDefinedServices(desktop, true);
            for (const KServiceAction &deviceAction : services) {
                ActionItem *actionItem = new ActionItem(desktop, deviceAction.name(), this); // Create an action
                d->actions.append(actionItem);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities.values) {
        for (const auto& agent: agents.values) {
            scoring.call(QStringLiteral("DeleteStatsForResource"), activity, agent, resource);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (OptionGroupInfo *optionGroupInfo : qAsConst(rules->optionGroupInfos)) {
		std::sort(optionGroupInfo->optionInfos.begin(), optionGroupInfo->optionInfos.end(), xkbOptionLessThan);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (VariantInfo *variantInfo : qAsConst(layoutInfo->variantInfos)) {
			variantInfo->description = translate_description(variantInfo);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
            QString name = proxyModel->data(index).toString();
            q->activateComponent(name);
        }
```

#### AUTO 


```{c}
auto forceFontDPIChanged = dpiItem->isSaveNeeded();
```

#### AUTO 


```{c}
auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, url, kind](KJob *theJob) {
        if (theJob->error()) {
            qWarning() << "Could add script entry" << theJob->errorString();
            return;
        }

        beginInsertRows(QModelIndex(), index, index);

        const QUrl dest = theJob->property("finalUrl").toUrl();

        AutostartEntry entry = AutostartEntry{dest.fileName(), kind, true, dest.path(), false, QStringLiteral("dialog-scripts")};

        m_entries.insert(index, entry);

        endInsertRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : d->windowModels) {
            windowModel->setVirtualDesktop(virtualDesktop);
            ++virtualDesktop;

            windowModel->setActivity(d->activityInfo->currentActivity());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode);
        Q_UNUSED(exitStatus);

        m_testProcess->deleteLater();
        m_testProcess = nullptr;
        emit testingChanged();
    }
```

#### AUTO 


```{c}
const auto agents =
        (!agent.values.isEmpty())      ? agent.values :
        (!d->query.agents().isEmpty()) ? d->query.agents() :
                                         Terms::Agent::current().values;
```

#### AUTO 


```{c}
const auto &action
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : children) {
        if (child->isWidgetType()) {
            setStyleRecursively(static_cast<QWidget *>(child), style, palette);
        }
    }
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(QStringLiteral("org.kde.plasmashell"),
                                                  QStringLiteral("/PlasmaShell"),
                                                  QStringLiteral("org.kde.PlasmaShell"),
                                                  QStringLiteral("toggleActivityManager"));
```

#### AUTO 


```{c}
const auto& item
```

#### AUTO 


```{c}
const auto constraint = QStringLiteral("'TerminalEmulator' in Categories AND (not exist NoDisplay OR NoDisplay == false)");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto  &keySequence : defaultShortcuts) {
            if (!keySequence.isEmpty()) {
                shortcut.defaultShortcuts.insert(keySequence);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, m_currentActivity, ScreenMapper::DelayedSignal);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto timeRight = lastUsedTime(activityRight.toString());
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::DeviceInterface::Type devType : devTypeList) {
        deviceTypes << actData->nameFromInterface( devType );
    }
```

#### AUTO 


```{c}
const auto shortcuts = KGlobalAccel::self()->globalShortcut(QStringLiteral("ActivityManager"), QStringLiteral("switch-to-activity-") + activityId);
```

#### AUTO 


```{c}
auto resp = (m_dbusIface->*(x.second))(x.first);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &metaData) {
        return metaData.pluginId() == QStringLiteral("kactivitymanagerd_fileitem_linking_plugin");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](Component &c) {
        std::sort(c.actions.begin(), c.actions.end(), [&](const Action &a1, const Action &a2) {
            return collator.compare(a1.displayName, a2.displayName) < 0;
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : qAsConst(m_components)) {
        for (const auto &action : qAsConst(component.actions)) {
            if (action.defaultShortcuts != action.activeShortcuts) {
                return false;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (QDBusPendingCallWatcher *watcher) mutable {
                             QDBusPendingReply<QDBusVariant> reply = *watcher;
                             setActivityIsPrivate(reply.value().variant().toBool());
                             watcher->deleteLater();
                         }
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), PluginNameRole, pluginName, 1, Qt::MatchExactly);
```

#### AUTO 


```{c}
const auto sizeHint = m_widget->sizeHint();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const KFileItem &item) {
        Q_UNUSED(item);
        qWarning() << "SwitcherBackend: FAILED to get the thumbnail" << job->errorString() << job->detailedErrorStrings();
        emit finished();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (m_newStuffDialog->changedEntries().isEmpty()) {
                return;
            }

            // reload the display icontheme items
            KIconLoader::global()->newIconLoader();
            m_model->load();
        }
```

#### AUTO 


```{c}
auto ntpUtility = QStandardPaths::findExecutable(possible_ntputility, path);
```

#### AUTO 


```{c}
const auto activity = containment.readEntry("activityId", QString());
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
                continuation();
                watcher->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Accounts::AccountId& accountId : accountIds) {
            account = accountsManager->account(accountId);
            if (account) {
                bool completed{false};
                qCDebug(ATTICA_PLUGIN_LOG) << "Fetching data for" << accountId;
                GetCredentialsJob *job = new GetCredentialsJob(accountId, accountsManager);
                connect(job, &KJob::finished, [&completed,&accessToken,&idToken](KJob* kjob){
                    GetCredentialsJob *job = qobject_cast< GetCredentialsJob* >(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData["AccessToken"].toString();
                    idToken = credentialsData["IdToken"].toString();
                    if (!accessToken.isEmpty()) {
                        qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was gottened";
                        for (const QString& key : credentialsData.keys()) {
                            qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                        }
                    }
                    completed = true;
                });
                connect(job, &KJob::result, [&completed](){ completed = true; });
                job->start();
                while(!completed) {
                    qApp->processEvents();
                }
                if(!idToken.isEmpty()) {
                    qCDebug(ATTICA_PLUGIN_LOG) << "OpenID Access token retrieved for account" << account->id();
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto recent = m_settings.recent();
```

#### AUTO 


```{c}
const auto themeName = m_settings->theme();
```

#### AUTO 


```{c}
const auto &layoutUnit
```

#### AUTO 


```{c}
auto configureScreen = [q](QScreen* screen) {
        QObject::connect(screen, &QScreen::geometryChanged, q, &PagerModel::pagerItemSizeChanged);
        q->pagerItemSizeChanged();
    };
```

#### AUTO 


```{c}
const auto radio = ::findDolphinRadio(mDynamicRadioButtons);
```

#### AUTO 


```{c}
const auto &componentPath
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor]() {
        Q_EMIT const_cast<VariantComboDelegate *>(this)->commitData(editor);
    }
```

#### AUTO 


```{c}
auto it = configWidgetMap.constBegin();
```

#### AUTO 


```{c}
const auto token = reader.readNext();
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(
            QStringLiteral("org.kde.plasmashell"),
            QStringLiteral("/PlasmaShell"),
            QStringLiteral("org.kde.PlasmaShell"),
            QStringLiteral("toggleActivityManager"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!selectApplicationDialogUi.treeView->model()) {
            QSortFilterProxyModel *filterModel = new QSortFilterProxyModel(selectApplicationDialogUi.treeView);
            filterModel->setRecursiveFilteringEnabled(true);
            QStandardItemModel *appModel = new QStandardItemModel(selectApplicationDialogUi.treeView);
            selectApplicationDialogUi.kfilterproxysearchline->setProxy(filterModel);
            filterModel->setSourceModel(appModel);
            appModel->setHorizontalHeaderLabels({i18n("Applications")});

            loadAppsCategory(KServiceGroup::root(), appModel, nullptr);

            selectApplicationDialogUi.treeView->setModel(filterModel);
        }
        selectApplicationDialog->show();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const optional_view<QString> &activityId) {
        if (activityId.is_initialized()) {
            saveChanges(activityId.get());
        }
    }
```

#### AUTO 


```{c}
const auto allShortcuts = shortcutsReply.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto device : qAsConst(m_devices)) {
        device->defaults();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : layouts) {
                if (!layoutSetString.isEmpty()) {
                    layoutSetString += LIST_SEPARATOR_LM;
                }
                layoutSetString += layoutUnit.toString();
            }
```

#### AUTO 


```{c}
const auto activities =
        (!activity.values.isEmpty())       ? activity.values :
        (!d->query.activities().isEmpty()) ? d->query.activities() :
                                             Terms::Activity::current().values;
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        Q_UNUSED(error)
        Q_EMIT testingFailed(QString::fromLocal8Bit(m_testProcess->readAllStandardError()));
    }
```

#### AUTO 


```{c}
const auto readmes = QDir(dir).entryList({QStringLiteral("README*")});
```

#### RANGE FOR STATEMENT 


```{c}
for (auto group : qAsConst(notifyList)) {
        KIconLoader::emitChange(KIconLoader::Group(group));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &idx : selected) {
        if (idx.column() == 0) {
            keyboardConfig->layouts.removeAt(rowsRange.first);
        }
    }
```

#### AUTO 


```{c}
auto backend = MouseBackend::implementation();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QList<QKeySequence> &list) {
            return QSet<QKeySequence>{list.cbegin(), list.cend()};
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : currentLayouts) {
            extraLayouts.removeOne(layoutUnit);
        }
```

#### AUTO 


```{c}
auto it = enterList.crbegin(), end = enterList.crend();
```

#### AUTO 


```{c}
auto reply = m_fprintInterface->Claim(username);
```

#### AUTO 


```{c}
const auto destination =
            query.ordering() == HighScoredFirst      ? ORDER_BY_FULL(score):
            query.ordering() == RecentlyUsedFirst    ? ORDER_BY_FULL(lastUpdate):
            query.ordering() == RecentlyCreatedFirst ? ORDER_BY_FULL(firstUpdate):
            /* otherwise */                            ORDER_BY_FULL(resource)
            ;
```

#### AUTO 


```{c}
auto it =  std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
        return c.uniqueName == uniqueName;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this, &c](const QString &a, const QString &b) {
            return c.compare(languageCodeToName(a), languageCodeToName(b)) < 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, bool countVisible) {
        if (m_storageId == uri) {
            setCountVisible(countVisible);
        }
    }
```

#### AUTO 


```{c}
const auto results = sourceModel()->match(sourceModel()->index(0, 0), ThemesModel::PluginNameRole, m_selectedTheme);
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, fileName, desktopItem, dlg] (int result) {
            if (result == QDialog::Accepted) {

                // Entry may have change of file
                m_model->reloadEntry(index, dlg->item().localPath());

                const QString name = m_model->data(index, Qt::DisplayRole).toString();
                const QString command = m_model->data(index, AutostartModel::Roles::Command).toString();
                const bool enabled = m_model->data(index, AutostartModel::Roles::Enabled).toBool();

                updateDesktopStartItem( desktopItem, name, command, !enabled, fileName);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layoutUnits) {
            str += layoutUnit.toString() + QLatin1Char(',');
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &module : modules) {
        QString servicePath = module.metaDataFileName();

        // autoload defaults to false if it is not found
        const bool autoload = module.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();

        // keep estimating dbusModuleName in sync with KDEDModule (kdbusaddons) and kded (kded)
        // currently (KF5) the module name in the D-Bus object path is set by the pluginId
        const QString dbusModuleName = module.pluginId();
        qCDebug(KCM_KDED) << "reading kded info from" << servicePath << "autoload =" << autoload << "dbus module name =" << dbusModuleName;

        if (knownModules.contains(dbusModuleName)) {
            continue;
        }

        knownModules.append(dbusModuleName);

        KConfigGroup cg(&kdedrc, QStringLiteral("Module-%1").arg(dbusModuleName));
        const bool autoloadEnabled = cg.readEntry("autoload", true);
        const bool immutable = cg.isEntryImmutable("autoload");

        ModulesModelData data{
            module.name(),
            module.description(),
            KDEDConfig::UnknownType,
            autoloadEnabled,
            dbusModuleName,
            immutable,
            autoloadEnabled
        };

        // The logic has to be identical to Kded::initModules.
        // They interpret X-KDE-Kded-autoload as false if not specified
        //                X-KDE-Kded-load-on-demand as true if not specified
        if (autoload) {
            data.type = KDEDConfig::AutostartType;
            autostartModules << data;
        } else if (isModuleLoadedOnDemand(module)) {
            data.type = KDEDConfig::OnDemandType;
            onDemandModules << data;
        } else {
            qCWarning(KCM_KDED) << "kcmkded: Module " << module.name() << "from file" << module.metaDataFileName() << " not loaded on demand or startup! Skipping.";
            continue;
        }
    }
```

#### AUTO 


```{c}
auto oldBlockEnd = oldBlockStart;
```

#### AUTO 


```{c}
auto it =  std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
        return c.id == uniqueName;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResultSet::Result &result : results) {
        ids << QUrl(result.resource()).path();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[callback](QDBusPendingCallWatcher *watcher) mutable {
        callback.call();
        watcher->deleteLater();
    }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(QStringLiteral("plasma-interactiveconsole"), args);
```

#### RANGE FOR STATEMENT 


```{c}
for (OptionGroupInfo *optionGroupInfo : qAsConst(rules->optionGroupInfos)) {
        optionGroupInfo->description = translate_description(optionGroupInfo);

        removeEmptyItems(optionGroupInfo->optionInfos);
        for (OptionInfo *optionInfo : qAsConst(optionGroupInfo->optionInfos)) {
            optionInfo->description = translate_description(optionInfo);
        }
    }
```

#### AUTO 


```{c}
auto user
```

#### LAMBDA EXPRESSION 


```{c}
[this, owdlg](int result) {
        if (result != QDialog::Accepted) {
            return;
        }

        const KService::Ptr service = owdlg->service();

        Q_ASSERT(service);
        if (!service) {
            return; // Don't crash if KOpenWith wasn't able to create service.
        }

        addApplication(service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &app : seenApps) {
        if (desktopEntries.contains(app)) {
            continue;
        }

        KService::Ptr service = KService::serviceByDesktopName(app);
        if (!service || service->noDisplay()) {
            continue;
        }

        SourceData source{service->name(),
                          service->comment(),
                          service->icon(),
                          true,
                          QString(), // notifyRcFile
                          service->desktopEntryName(),
                          {}};
        appsData.append(source);
        desktopEntries.append(service->desktopEntryName());
    }
```

#### AUTO 


```{c}
auto infoWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
```

#### AUTO 


```{c}
auto watcher = new QFutureWatcher<decltype(future.result())>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setStatus(Status::Canceled);
        emit listingCanceled();
    }
```

#### AUTO 


```{c}
auto pos = std::lower_bound(m_components.begin(), m_components.end(), displayName, [&] (const Component &c, const QString &name) {
        return c.type != i18n("System Services") &&  collator.compare(c.displayName, name) < 0;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                    QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                    QStringLiteral("org.kde.KWin.InputDevice"),
                                    QDBusConnection::sessionBus(),
                                    this);
        QVariant reply = deviceIface.property("pointer");
        if (reply.isValid() && reply.toBool()) {
            reply = deviceIface.property("touchpad");
            if (reply.isValid() && reply.toBool()) {
                continue;
            }

            KWinWaylandDevice* dev = new KWinWaylandDevice(sn);
            if (!dev->init()) {
                qCCritical(KCM_INPUT) << "Error on creating device object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos of %1.", sn);
                return;
            }
            m_devices.append(dev);
            qCDebug(KCM_INPUT).nospace() <<  "Device found: " <<  dev->name() << " (" << dev->sysName() << ")";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& created : entry.installedFiles()) {
                        QStringList list = created.split(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        // Because we sometimes get some extra slashes in the installed files list
                        list.removeAll({});
                        // Because we'll also get the containing folder, if it was not already there
                        // we need to ignore it.
                        if (list.last() == QLatin1String(".icons")) {
                            continue;
                        }
                        m_themeModel->addTheme(QStringLiteral("/%1").arg(list.join(QLatin1Char('/'))));
                    }
```

#### AUTO 


```{c}
const auto whatToRemember = (WhatToRemember)statisticsConfig.readEntry(
        "what-to-remember", (int)AllApplications);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& urlFilter: query.urlFilters()) {
                scoring.call("DeleteStatsForResource", activity, agent, urlFilter);
            }
```

#### AUTO 


```{c}
auto result = execQuery(query);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : browsers) {
        browserCombo->addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if ((m_browserService && m_browserService->storageId() == service->storageId()) || service->exec() == m_browserExec) {
            browserCombo->setCurrentIndex(browserCombo->count() - 1);
            radioService->setChecked(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &serviceAction : jumpListActions) {
        if (serviceAction.noDisplay()) {
            continue;
        }

        QAction *action = new QAction(parent);
        action->setText(serviceAction.text());
        action->setIcon(QIcon::fromTheme(serviceAction.icon()));
        if (serviceAction.isSeparator()) {
            action->setSeparator(true);
        }

        connect(action, &QAction::triggered, this, [serviceAction]() {
            auto *job = new KIO::ApplicationLauncherJob(serviceAction);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);
            job->start();
        });

        actions << QVariant::fromValue<QAction *>(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_canPresentWindows = false;
        Q_EMIT canPresentWindowsChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandDevice*>(t)->applyConfig(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mimeCopy, x, y, dropJob](const KFileItemListProperties &) {
        Q_EMIT popupMenuAboutToShow(dropJob, mimeCopy, x, y);
        mimeCopy->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Action &a) {
            return a.id == key;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        setNeedsSave(m_fontAASettings->needsSave());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XDeviceInfo *info) {
        int deviceid = info->id;
        Status status;
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        //data returned is an 1 byte boolean
        status = XIGetProperty(dpy, deviceid, valAtom, 0, 1,
                               False, XA_INTEGER, &type_return, &format_return,
                               &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;


        if (type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 1) {
            return;
        }

        unsigned char sendVal = val ? 1 : 0;

        XIChangeProperty(dpy, deviceid, valAtom, XA_INTEGER,
                         8, XIPropModeReplace, &sendVal, 1);

    }
```

#### AUTO 


```{c}
auto updateState = [this]() {
        setNeedsSave(m_fontAASettings->needsSave());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[sysName](InputDevice *t) {
            return t->sysName() == sysName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &mod : modules) {
		qCDebug(KCM_KDED) << "saving settings for kded module" << mod.pluginId();
		// autoload defaults to false if it is not found
		const bool autoload = mod.rawData().value(QStringLiteral("X-KDE-Kded-autoload")).toVariant().toBool();
		if (autoload) {
			const QString libraryName = mod.pluginId();
			int count = _lvStartup->topLevelItemCount();
			for(int i = 0; i < count; ++i) {
				QTreeWidgetItem *treeitem = _lvStartup->topLevelItem(i);
				if ( treeitem->data(StartupService, LibraryRole ).toString() == libraryName) {
					// we found a match, now compare and see what changed
					setAutoloadEnabled(&kdedrc, mod, treeitem->checkState( StartupUse ) == Qt::Checked);
					break;
				}
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : args) {
  	  if( arg.type() == QVariant::String ) {
  		  const QString str = arg.toString();
  		  if( str == QLatin1String("--tab=layouts") ) {
  			  setCurrentIndex(TAB_LAYOUTS);
  		  }
  		  else if( str == QLatin1String("--tab=advanced") ) {
  	  		  setCurrentIndex(TAB_ADVANCED);
  	  	  }
  	  }
    }
```

#### AUTO 


```{c}
auto lstEntry = grp.readXdgListEntry("OnlyShowIn");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &component : qAsConst(mComponents)) {
        QCheckBox *cb = new QCheckBox(component);
        vb->addWidget(cb, item / 2, item % 2);
        mButtons.addButton(cb, item);
        ++item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDBusPendingCallWatcher *componentsWatcher) {
        QDBusPendingReply<QList<QDBusObjectPath>> componentsReply = *componentsWatcher;
        componentsWatcher->deleteLater();
        if (componentsReply.isError()) {
            genericErrorOccured(QStringLiteral("Error while calling allComponents()"), componentsReply.error());
            endResetModel();
            return;
        }
        const QList<QDBusObjectPath> componentPaths = componentsReply.value();
        int *pendingCalls = new int;
        *pendingCalls = componentPaths.size();
        for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else if (!reply.value().isEmpty()) {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return (matcher == ANY_ACTIVITY_TAG)     ? true :
                       (matcher == CURRENT_ACTIVITY_TAG) ? (matcher == activity || activity == ActivitiesSync::currentActivity(activities)) :
                                                           activity == matcher;
            }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString,      const QString &,      Icon)
```

#### AUTO 


```{c}
const auto attributes = reader.attributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &componentFriendly : components)
        {
        QHash<QString, ComponentData*>::Iterator iter = d->components.find(componentFriendly);
        if (iter == d->components.end())
            {
            Q_ASSERT(iter != d->components.end());
            continue;
            }
        else
            {
            KConfigGroup group(config, (*iter)->uniqueName());
            (*iter)->editor()->exportConfiguration(&group);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](KIO::Job *job, const QUrl &from, const QUrl &to) {
        Q_UNUSED(from)
        // in case the destination filename had to be renamed
        job->setProperty("finalUrl", to);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&preferredServiceAdded, preferredService, this](const KService::Ptr &service) {
        if (service->exec().isEmpty() || !service->categories().contains(m_type) || service->noDisplay()) {
            return false;
        }
        QVariantMap application;
        application["name"] = service->name();
        application["icon"] = service->icon();
        application["storageId"] = service->storageId();
        application["execLine"] = service->exec();
        m_applications += application;
        if ((!preferredService.isEmpty() && preferredService == service->exec())) {
            m_index = m_applications.length() - 1;
            preferredServiceAdded = true;
        }
        if (service->storageId() == m_defaultApplication) {
            m_defaultIndex = m_applications.length() - 1;
        }
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const FolderInfo &a, const FolderInfo &b) {
        return a.url < b.url;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &job : jobs) {
        totalProgress += m_jobProgress.value(job, 0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &prop : m_props) {
        if (prop.toMap()[QStringLiteral("key")] == property.key) {
            prop = property.toMap();
            Q_EMIT propertiesChanged();
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &parent, int first, int last) {
        for (int i = first; i <= last; ++i) {
            const auto idx = index(i, 0, parent);
            const auto url = itemForIndex(idx).url();
            auto it = m_dropTargetPositions.find(url.fileName());
            if (it != m_dropTargetPositions.end()) {
                const auto pos = it.value();
                m_dropTargetPositions.erase(it);
                emit move(pos.x(), pos.y(), {url});
            }
        }
    }
```

#### AUTO 


```{c}
const auto path2 = ScreenMapper::stringToUrl(QStringLiteral("desktop:/Foo2"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &desktopEntry) {
        return desktopEntry + QStringLiteral(".desktop");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : actions) { // We want every single action
                KConfigGroup actionType = deviceFile.actionGroup( text );
                deviceValues.insert( text, actionType.readEntry("Name") ); // Add to the type - actions map
            }
```

#### AUTO 


```{c}
auto query = UsedResources
        | RecentlyUsedFirst
        | Agent(storageId)
        | Type::any()
        | Activity::current()
        | Url::file();
```

#### AUTO 


```{c}
auto reply = timedateIface.SetTimezone(selectedTimeZone, true);
```

#### AUTO 


```{c}
const auto status = static_cast<KDEDConfig::ModuleStatus>(idx.data(ModulesModel::StatusRole).toInt());
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const ThemesModelData &a, const ThemesModelData &b) {
        return collator.compare(a.display, b.display) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[service] (const KService::Ptr &serv) { return service->storageId() == serv->storageId(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : component.actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                QList<QKeySequence> keys(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                KStandardShortcut::saveShortcut(KStandardShortcut::findByName(action.id), keys);
                action.initialShortcuts = action.activeShortcuts;
            }
        }
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, bool, bool, IsPrivate)
```

#### AUTO 


```{c}
auto idx = index(m_languages.indexOf(languageCode), 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        bool hasPendingDeletions = !pendingDeletions().isEmpty();
        setNeedsSave(m_data->settings()->isSaveNeeded() || hasPendingDeletions);
        setRepresentsDefaults(m_data->settings()->isDefaults() && !hasPendingDeletions);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setStatus(Status::Canceled);
        Q_EMIT listingCanceled();
    }
```

#### AUTO 


```{c}
const auto selectedIndexes = deviceView->selectionModel()->selectedIndexes();
```

#### AUTO 


```{c}
const auto titleLeft  = sourceModel()->data(sourceLeft, KActivitiesBackport::ActivitiesModel::ActivityName);
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            }
```

#### AUTO 


```{c}
auto result = QSqlQuery(query, d->database);
```

#### RANGE FOR STATEMENT 


```{c}
for (const T &t : set2) {
        if (!set1.contains(t))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : qAsConst(m_components)) {
        if (component.pendingDeletion) {
            return true;
        }
        for (const auto &action : qAsConst(component.actions)) {
            if (action.initialShortcuts != action.activeShortcuts) {
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
auto keypress = reinterpret_cast<xcb_key_press_event_t *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *s : qApp->screens()) {
        if (s->geometry().contains(pos)) {
            screen = s;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto pos = it.value();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().length() == 1) {
            const QString desktopPath = selectApplicationDialogUi.treeView->model()->data(selectApplicationDialogUi.treeView->selectionModel()->selectedIndexes().first(), Qt::UserRole+1).toString();

            if (!desktopPath.isEmpty() &&QFile::exists(desktopPath) ) {
                const QString desktopFile = desktopPath.split(QChar('/')).last();

                if (!desktopPath.isEmpty()) {
                    KDesktopFile sourceDF(desktopPath);
                    KDesktopFile *destinationDF = sourceDF.copyTo(QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile);
                    qWarning()<<QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/kglobalaccel/") + desktopFile;
                    destinationDF->sync();
                    //TODO: a DBUS call to tell the daemon to refresh desktop files


                    // Create a action collection for our current component:context
                    KActionCollection *col = new KActionCollection(q, desktopFile);

                    foreach(const QString &actionId, sourceDF.readActions()) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QChar(','));
                        QList<QKeySequence> sequences;
                        if (sequencesStrings.length() > 0) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (sequences.count() > 0) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    //Global launch action
                    {
                        const QString friendlyName = i18n("Launch %1", sourceDF.readName());
                        QAction *action = col->addAction(QStringLiteral("_launch"));
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        QStringList sequencesStrings = sourceDF.desktopGroup().readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QChar(','));
                        QList<QKeySequence> sequences;
                        if (sequencesStrings.length() > 0) {
                            Q_FOREACH (const QString &seqString, sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (sequences.count() > 0) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
                    q->addCollection(col, QDBusObjectPath(), desktopFile, sourceDF.readName());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : fileManagers) {
        addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if (fileManager->storageId() == service->storageId()) {
            setCurrentIndex(count() -1);
            m_currentIndex = count() -1;
        }
        if (service->storageId() == QStringLiteral("org.kde.dolphin.desktop")) {
            m_defaultIndex = count() -1;
        }
    }
```

#### AUTO 


```{c}
auto stringFromIterators = [&](const QString::const_iterator &currentStart,
                                   const QString::const_iterator &currentPosition) {
        return pattern.mid(
                std::distance(begin, currentStart),
                std::distance(currentStart, currentPosition));
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&c](AbstractEntry* a, AbstractEntry* b) {
                    if (a->type() != b->type()) {
                        return a->type() > b->type();
                    } else {
                        return c.compare(a->name(), b->name()) < 0;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto t : dialog.installedEntries())
            qDebug() << t.name();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &schemeFile : schemeFiles) {
        const QFileInfo fi(schemeFile);
        const QString baseName = fi.baseName();

        KSharedConfigPtr config = KSharedConfig::openConfig(schemeFile, KConfig::SimpleConfig);
        KConfigGroup group(config, "General");
        const QString name = group.readEntry("Name", baseName);

        const QPalette palette = KColorScheme::createApplicationPalette(config);

        KColorScheme headerColorScheme(QPalette::Active, KColorScheme::Header, config);
        KConfigGroup wmConfig(config, QStringLiteral("WM"));
        const QColor activeTitleBarBackground = wmConfig.readEntry("activeBackground", headerColorScheme.background().color());
        const QColor activeTitleBarForeground = wmConfig.readEntry("activeForeground", headerColorScheme.foreground().color());

        ColorsModelData item{
            name,
            baseName,
            palette,
            activeTitleBarBackground,
            activeTitleBarForeground,
            fi.isWritable(),
            false, // pending deletion
        };

        m_data.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PreviewCursor *c : qAsConst(list)) {
        if (c->rect().contains(e->pos())) {
            if (c != current) {
                setCursor(c->pixmap());
                current = c;
            }
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &schemeFile : schemeFiles) {
        const QFileInfo fi(schemeFile);
        const QString baseName = fi.baseName();

        KSharedConfigPtr config = KSharedConfig::openConfig(schemeFile, KConfig::SimpleConfig);
        KConfigGroup group(config, "General");
        const QString name = group.readEntry("Name", baseName);

        const QPalette palette = KColorScheme::createApplicationPalette(config);

        // from kwin/decorations/decorationpalette.cpp
        KConfigGroup wmConfig(config, QStringLiteral("WM"));
        const QColor activeTitleBarBackground = wmConfig.readEntry("activeBackground", palette.color(QPalette::Active, QPalette::Highlight));
        const QColor activeTitleBarForeground = wmConfig.readEntry("activeForeground", palette.color(QPalette::Active, QPalette::HighlightedText));

        ColorsModelData item{
            name,
            baseName,
            palette,
            activeTitleBarBackground,
            activeTitleBarForeground,
            fi.isWritable(),
            false, // pending deletion
        };

        m_data.append(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        if (!m_contextMenu) {
            return;
        }

        QHoverEvent ev(QEvent::HoverLeave, QPoint(0, 0), QPoint(0, 0));
        QGuiApplication::sendEvent(item, &ev);

        emit showingContextMenuChanged();

        QPointer<TaskManager::BasicMenu> guard(m_contextMenu);
        m_contextMenu->exec(pos);
        if (!guard) {
            return;
        }
        m_contextMenu->windowHandle()->setTransientParent(item->window());
        m_contextMenu->deleteLater();
    }
```

#### AUTO 


```{c}
auto dialog = new Dialog();
```

#### AUTO 


```{c}
const auto whatToRemember = static_cast<WhatToRemember>(d->pluginConfig->whatToRemember());
```

#### AUTO 


```{c}
const auto layoutsList = X11Helper::getLayoutsList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shortcut : defaultShortcuts) {
        if (shortcut.toString(QKeySequence::NativeText).contains(m_filter, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.id == componentGroupName;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &v : std::as_const(data)) {
                    Property prop = v.value<Property>();
                    panel_props << prop;
                    SCIM_DEBUG_MAIN(1) << "REG_PROPERTIES" << qPrintable(Property2String(v.value<Property>())) << "\n";
                }
```

#### AUTO 


```{c}
const auto &option
```

#### AUTO 


```{c}
auto activityInfoPtr = *(registeredPosition.iterator);
```

#### AUTO 


```{c}
auto verifyMapping = [](const QHash<int, int> &actual, const QHash<int, int> &expected) {

        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().toList();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    };
```

#### AUTO 


```{c}
auto begin      = this->begin();
```

#### AUTO 


```{c}
auto query = UsedResources | RecentlyUsedFirst | Agent(storageId) | Type::any() | Activity::current();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.kksrc"));
        for (const QString &file : fileNames) {
            const QString path = dir + QLatin1Char('/') + file;
            KConfig scheme(path, KConfig::SimpleConfig);
            const QString name = KConfigGroup(&scheme, "Settings").readEntry("Name", file);
            schemes.append(QVariantMap({{"name", name}, {"url", QUrl::fromLocalFile(path)}}));
        }
    }
```

#### AUTO 


```{c}
const auto activityId = ":global";
```

#### AUTO 


```{c}
auto proxyIndex = (i <= 1) ? i : i + 1;
```

#### LAMBDA EXPRESSION 


```{c}
[map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        }
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent::any()
                    | Type::any()
                    | Activity::current()
                    | Url::startsWith("applications:")
                    | Limit(15);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, bool progressVisible) {
        if (m_storageId == uri) {
            setProgressVisible(progressVisible);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XIDeviceInfo *info) {
        Status status;
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        //data returned is an 1 byte boolean
        status = XIGetProperty(dpy, info->deviceid, valAtom, 0, 1,
                               False, XA_INTEGER, &type_return, &format_return,
                               &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;


        if (type_return != XA_INTEGER || !data || format_return != 8 || num_items_return != 1) {
            return;
        }

        unsigned char sendVal = val ? 1 : 0;

        XIChangeProperty(dpy, info->deviceid, valAtom, XA_INTEGER,
                         8, XIPropModeReplace, &sendVal, 1);

    }
```

#### AUTO 


```{c}
auto container = QWidget::createWindowContainer(view, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : activities) {
        const int row = rowForActivityId(activity);
        emit rowChanged(row, {KActivities::ActivitiesModel::ActivityBackground});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, int progress) {
        if (uri.isEmpty() || m_storageId == uri) {
            setProgress(progress);
        }
    }
```

#### AUTO 


```{c}
const auto &emoji = m_emoji[index.row()];
```

#### LAMBDA EXPRESSION 


```{c}
[this, restartInSetupScreen](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<void> reply = *watcher;
        watcher->deleteLater();

        checkFirmwareSetupRequested();

        settingsChanged();

        if (reply.isError()) {
            // User likely canceled the PolKit prompt, don't show an error in this case
            if (reply.error().type() != QDBusError::AccessDenied) {
                m_error = reply.error().message();
                Q_EMIT errorChanged();
            }
            return;
        } else if (m_error.length() > 0) {
            m_error = QString();
            Q_EMIT errorChanged();
        }
        m_restartInSetupScreen = restartInSetupScreen;
        Q_EMIT restartInSetupScreenChanged();

        if (!restartInSetupScreen) {
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionGroupInfo *optionGroupInfo : std::as_const(rules->optionGroupInfos)) {
            QVERIFY(optionGroupInfo != nullptr);
            QVERIFY(!optionGroupInfo->name.isEmpty());
            QVERIFY(!optionGroupInfo->description.isEmpty());
            // optionGroupInfo->exclusive

            for (const OptionInfo *optionInfo : optionGroupInfo->optionInfos) {
                QVERIFY(optionInfo != nullptr);
                QVERIFY(!optionInfo->name.isEmpty());
                QVERIFY(!optionInfo->description.isEmpty());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ComponentData *cd : qAsConst(d->components)) {
        if (cd->editor()->isModified()) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& urlFilter: query.urlFilters()) {
                scoring.call(QStringLiteral("DeleteStatsForResource"), activity, agent, urlFilter);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPackage::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem *row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginId(), PluginNameRole);
        row->setData(pkg.metadata().description(), DescriptionRole);
        row->setData(pkg.filePath("preview"), ScreenshotRole);
        row->setData(pkg.filePath("fullscreenpreview"), FullScreenPreviewRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            row->setData(hasColors, HasColorsRole);
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
const auto *item = m_model->item(pluginIndex(lookAndFeelSettings()->lookAndFeelPackage()));
```

#### AUTO 


```{c}
auto & pathIt
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& deleted : entry.uninstalledFiles()) {
                        QVector<QStringRef> list = deleted.splitRef(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        QModelIndex idx = m_themeModel->findIndex(list.last().toString());
                        if (idx.isValid()) {
                            m_themeModel->removeTheme(idx);
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : schemeDirs) {
                    const QStringList fileNames = QDir(dir).entryList(QStringList()<<QStringLiteral("*.colors"));
                    for (const QString &file : fileNames) {
                        if (file.endsWith(colorScheme + ".colors")) {
                            setColors(colorScheme, dir + QChar('/') + file);
                            schemeFound = true;
                            break;
                        }
                    }
                    if (schemeFound) {
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto entry = m_folderList.at(row);
```

#### LAMBDA EXPRESSION 


```{c}
[this, notifySignal] {
        emit(this->*notifySignal)();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : qAsConst(layouts)) {
        layoutStrings.append(layoutUnit.layout());
        variants.append(layoutUnit.variant());
        displayNames.append(layoutUnit.getRawDisplayName());
        //    	shortcuts.append(layoutUnit.getShortcut().toString());
    }
```

#### AUTO 


```{c}
const auto entry = AutostartEntry{service->name(),
                                      AutostartModel::AutostartEntrySource::XdgAutoStart, // .config/autostart load desktop at startup
                                      true,
                                      desktopPath,
                                      false,
                                      service->icon()};
```

#### AUTO 


```{c}
auto it = m_itemsOnDisabledScreensMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profile : accelerationProfiles) {
        accelProfileComboBox->addItem(i18n(profile.toUtf8().constData()), profile);
        if (profile == settings->currentAccelProfile) {
            accelProfileComboBox->setCurrentIndex(idx);
        }
        idx++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &app : seenApps) {
        if (desktopEntries.contains(app)) {
            continue;
        }

        KService::Ptr service = KService::serviceByDesktopName(app);
        if (!service || service->noDisplay()) {
            continue;
        }

        SourceData source{
            service->name(),
            service->comment(),
            service->icon(),
            true,
            QString(), //notifyRcFile
            service->desktopEntryName(),
            {}
        };
        appsData.append(source);
        desktopEntries.append(service->desktopEntryName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : mimeData->urls()) {
                m_dropTargetPositions.insert(url.fileName(), dropPos);
                m_screenMapper->addMapping(mappableUrl(url), m_screen, ScreenMapper::DelayedSignal);
                m_screenMapper->removeItemFromDisabledScreen(mappableUrl(url));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &layoutUnit : std::as_const(layoutsList)) {
        QString displayName = layoutUnit.getDisplayName();
        const auto configDefaultLayouts = keyboardConfig->getDefaultLayouts();
        auto it = std::find(configDefaultLayouts.begin(), configDefaultLayouts.end(), layoutUnit);
        if (it != configDefaultLayouts.end()) {
            displayName = it->getDisplayName();
        } else {
            const auto configExtraLayouts = keyboardConfig->getExtraLayouts();
            it = std::find(configExtraLayouts.begin(), configExtraLayouts.end(), layoutUnit);
            if (it != configExtraLayouts.end()) {
                displayName = it->getDisplayName();
            }
        }
        ret.append({layoutUnit.layout(), displayName, Flags::getLongText(layoutUnit, rules)});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandTouchpad*>(t)->getConfig(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.metadata().comment(), DescriptionRole);
        row->setData(pkg.filePath("preview"), ScreenhotRole);
        row->setData(pkg.filePath("fullscreenpreview"), FullScreenPreviewRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            row->setData(hasColors, HasColorsRole);
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
const auto browsers = KServiceTypeTrader::self()->query(QStringLiteral("Application"), constraint);
```

#### LAMBDA EXPRESSION 


```{c}
[this, moduleName, status](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<bool> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            if (status == NotRunning) {
                Q_EMIT errorMessage(i18n("Failed to stop service: %1", reply.error().message()));
            } else {
                Q_EMIT errorMessage(i18n("Failed to start service: %1", reply.error().message()));
            }
            return;
        }

        if (!reply.value()) {
            if (status == NotRunning) {
                Q_EMIT errorMessage(i18n("Failed to stop service."));
            } else {
                Q_EMIT errorMessage(i18n("Failed to start service."));
            }
            return;
        }

        qCDebug(KCM_KDED) << "Successfully" << (status == Running ? "started" : "stopped") << moduleName;
        if (status == Running) {
            m_lastStartedModule = moduleName;
        } else {
            m_lastStartedModule.clear();
        }
        getModuleStatus();
    }
```

#### AUTO 


```{c}
const auto minutes = diff % 60;
```

#### AUTO 


```{c}
auto shortcuts = action.activeShortcuts;
```

#### AUTO 


```{c}
const auto &shortcuts = index.data(ShortcutsModel::CustomShortcutsRole).value<QSet<QKeySequence>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QKeySequence &keySequence : activeShortcuts) {
            if (!keySequence.isEmpty()) {
                shortcut.activeShortcuts.insert(keySequence);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *configWidget : configWidgetMap) {
		delete configWidget;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
                QVERIFY(variantInfo != nullptr);
                QVERIFY(!variantInfo->name.isEmpty());
                QVERIFY(!variantInfo->description.isEmpty());
            }
```

#### AUTO 


```{c}
auto reply = xcb_get_modifier_mapping_reply(QX11Info::connection(), cookie, NULL);
```

#### RANGE FOR STATEMENT 


```{c}
for (ComponentData *cd : qAsConst(d->components)) {
        cd->editor()->commit();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto user : qAsConst(m_userList)) {
        if (user->loggedIn()) {
            return user;
        }
    }
```

#### AUTO 


```{c}
auto result = d->features->GetValue(QStringLiteral("org.kde.ActivityManager.Resources.Scoring/isOTR/") + activityId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPackage::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginId(), PluginNameRole);
        row->setData(pkg.metadata().description(), DescriptionRole);
        row->setData(pkg.filePath("preview"), ScreenshotRole);
        row->setData(pkg.filePath("fullscreenpreview"), FullScreenPreviewRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            row->setData(hasColors, HasColorsRole);
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString::const_iterator &currentStart,
                                   const QString::const_iterator &currentPosition) {
        return pattern.mid(
                std::distance(begin, currentStart),
                std::distance(currentStart, currentPosition));
    }
```

#### AUTO 


```{c}
auto it =  std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
                return c.uniqueName == uniqueName;
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.notifyrc"));
        for (const QString &file : fileNames) {
            if (notifyRcFiles.contains(file)) {
                continue;
            }

            notifyRcFiles.append(file);

            KConfig config(file, KConfig::NoGlobals);
            config.addConfigSources(QStandardPaths::locateAll(QStandardPaths::GenericDataLocation,
                                        QStringLiteral("knotifications5/") + file));

            KConfigGroup globalGroup(&config, QLatin1String("Global"));

            const QRegularExpression regExp(QStringLiteral("^Event/([^/]*)$"));
            const QStringList groups = config.groupList().filter(regExp);

            const QString notifyRcName = file.section(QLatin1Char('.'), 0, -2);
            const QString desktopEntry = globalGroup.readEntry(QStringLiteral("DesktopEntry"));
            if (!desktopEntry.isEmpty()) {
                if (desktopEntries.contains(desktopEntry)) {
                    continue;
                }

                desktopEntries.append(desktopEntry);
            }

            SourceData source{
                // The old KCM read the Name and Comment from global settings disregarding
                // any user settings and just used user-specific files for actions config
                // I'm pretty sure there's a readEntry equivalent that does that without
                // reading the config stuff twice, assuming we care about this to begin with
                globalGroup.readEntry(QStringLiteral("Name")),
                globalGroup.readEntry(QStringLiteral("Comment")),
                globalGroup.readEntry(QStringLiteral("IconName")),
                true,
                notifyRcName,
                desktopEntry,
                {} // events
            };

            QVector<EventData> events;
            for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{
                    cg.readEntry("Name"),
                    cg.readEntry("Comment"),
                    cg.readEntry("IconName"),
                    eventId,
                    // TODO Flags?
                    cg.readEntry("Action").split(QLatin1Char('|'))
                };
                events.append(event);
            }

            std::sort(events.begin(), events.end(), [&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            });

            source.events = events;

            if (!source.desktopEntry.isEmpty()) {
                appsData.append(source);
            } else {
                servicesData.append(source);
            }
        }
    }
```

#### AUTO 


```{c}
auto allowedApplications = QSet<QString>::fromList(config.readEntry("allowed-applications", QStringList()));
```

#### AUTO 


```{c}
auto callFutureInterface = new DBusCallFutureInterface<_Result>(reply);
```

#### AUTO 


```{c}
const auto currentActivity = m_activities->currentActivity();
```

#### AUTO 


```{c}
auto shortcut = component->shortcuts.begin();
```

#### AUTO 


```{c}
const auto &actionInfo
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent("KTp")
                    | Type::any()
                    | Activity::current()
                    | Url::startsWith("ktp")
                    | Limit(15);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                endRemoveRows();
                emit countChanged();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionsList) {
        KActionCollection::setShortcutsConfigurable(act,true);
        if (isConfiguration) {
            act->setProperty("isConfigurationAction", true);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_model->setSelectedStyle(m_settings->widgetStyle());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possibleDevice : knownDevices) {
        if (!validDevices.contains(possibleDevice)) {
            m_settings->removeDeviceGroup(possibleDevice);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        (void) new KRun(url, Q_NULLPTR);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&name] (const Component &c) {
            return c.id == name;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &files) {
        if (!files.isEmpty()) {
            const QString guessedPluginId = QFileInfo(files.constFirst()).fileName();
            const int index = pluginIndex(guessedPluginId);
            if (index != -1) {
                m_model->removeRows(index, 1);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&completed, &accessToken, &idToken](KJob *kjob) {
                    GetCredentialsJob *job = qobject_cast<GetCredentialsJob *>(kjob);
                    const QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData[QStringLiteral("AccessToken")].toString();
                    idToken = credentialsData[QStringLiteral("IdToken")].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
                    //                     if (!accessToken.isEmpty()) {
                    //                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
                    //                         for (const QString& key : credentialsData.keys()) {
                    //                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                    //                         }
                    //                     }
                    completed = true;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        auto sm = new SessionManagement(this);
        auto doShutdown=[sm]() {
            sm->requestReboot();
            delete sm;
        };
        if (sm->state() == SessionManagement::State::Loading) {
            connect(sm, &SessionManagement::stateChanged, this, doShutdown);
        } else {
            doShutdown();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::pair<int, QString> &screen : std::as_const(screens)) {
        if (screen.second != activity) {
            continue;
        }

        if (newFirstScreen.has_value()) {
            if (newFirstScreen > screen.first) {
                newFirstScreen = screen.first;
            }
        } else {
            newFirstScreen = screen.first;
        }
    }
```

#### AUTO 


```{c}
const auto path = group.readEntryUntranslated(key, QString());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &component: components) {
        const QString componentId = component.id();

        QVariantMap appstreamAction = Kicker::createActionItem(i18nc("@action opens a software center with the application", "Manage '%1'...", component.name()), "manageApplication", QVariant(QStringLiteral("appstream://") + componentId));
        appstreamAction["icon"] = "applications-other";
        ret << appstreamAction;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[id] {
         KActivities::Info info(id);

        if (QMessageBox::question(nullptr, i18nc("@title:window", "Delete Activity"), i18n("Are you sure you want to delete '%1'?", info.name()))
            == QMessageBox::Yes) {
            KActivities::Controller().removeActivity(id);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopName, infoReply.error());
                return;
            }
            if (infoReply.value().isEmpty()) {
                qCWarning(KCMKEYS()) << "New component has no shortcuts:" << reply.value().path();
                Q_EMIT errorOccured(i18nc("%1 is the name of an application", "Error while adding %1, it seems it has no actions."));
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(), pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        }
```

#### AUTO 


```{c}
auto buttons = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString str) {
        return str.replace("%", "\\%").replace("_", "\\_");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupRestoreTrashedItems();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        emit changed(true);
        updateExample();
    }
```

#### AUTO 


```{c}
const auto entry = m_itemEntries[m_items[index].value()];
```

#### AUTO 


```{c}
auto i = urlFilters.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : qAsConst(component.actions)) {
            if (action.defaultShortcuts != action.activeShortcuts) {
                return false;
            }
        }
```

#### AUTO 


```{c}
const auto matching = combofileManager->model()->match(combofileManager->model()->index(0,0), Qt::UserRole, service->storageId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Emoji &emoji : m_emoji) {
            if (emoji.category == category)
                return emoji.content;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!m_dropTargetPositions.isEmpty()) {
            qCDebug(FOLDERMODEL) << "clearing drop target positions after timeout:" << m_dropTargetPositions;
            m_dropTargetPositions.clear();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, row, entry](KJob *theJob) {
        if (theJob->error()) {
            qWarning() << "Could not remove entry" << theJob->errorString();
            return;
        }

        beginRemoveRows(QModelIndex(), row, row);
        m_entries.remove(row);

        endRemoveRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : m_components) {
        for (const auto& shortcut : component.shortcuts) {
            if (shortcut.defaultShortcuts != shortcut.activeShortcuts) {
                return false;
            }
        }
   }
```

#### AUTO 


```{c}
const auto &c
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : items) {
        m_screenMapper->removeFromMap(item.url(), m_currentActivity);
        m_isDirCache.remove(item.url());
    }
```

#### AUTO 


```{c}
const auto &f
```

#### AUTO 


```{c}
__inline auto transformed(Member member, Args... args)
    -> decltype(boost::adaptors::transformed(
                std::bind(member, args..., std::placeholders::_1)))
{
    return boost::adaptors::transformed(
        std::bind(member, args..., std::placeholders::_1)
    );

}
```

#### AUTO 


```{c}
auto call = m_kdedInterface->reconfigure();
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : rules->layoutInfos) {
        QSet<QString> langs = QSet<QString>(layoutInfo->languages.constBegin(), layoutInfo->languages.constEnd());
        languages.unite(langs);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serviceFile : autostartServices) {
                    KService::Ptr service{new KService(serviceFile + QStringLiteral(".desktop"))};
                    KAutostart as(serviceFile);
                    as.setCommand(service->exec());
                    as.setAutostarts(true);
                    if (qEnvironmentVariableIsSet("KDE_FULL_SESSION")) {
                        auto *job = new KIO::ApplicationLauncherJob(service);
                        job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, nullptr));
                        job->start();
                    }
                }
```

#### AUTO 


```{c}
const auto &l
```

#### AUTO 


```{c}
auto dialog = new QDialog;
```

#### AUTO 


```{c}
const auto &s
```

#### AUTO 


```{c}
auto device
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : autostartDirFilesInfo) {

            QString fileName = fi.absoluteFilePath();
            const bool isSymlink = fi.isSymLink();
            if (isSymlink) {
                fileName = fi.symLinkTarget();
            }

            m_entries.push_back({
                                    fi.fileName(),
                                    isSymlink ? fileName : "",
                                    kind,
                                    true,
                                    fi.absoluteFilePath(),
                                    false
                                });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](XDeviceInfo *info) {
            int deviceid = info->id;
            if (info->type == m_touchpadAtom) {
                return;
            }
            evdevApplyReverseScroll(deviceid, m_settings->reverseScrollPolarity);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : autostartDirFilesInfo) {
        QString fileName = fi.absoluteFilePath();
        const bool isSymlink = fi.isSymLink();
        if (isSymlink) {
            fileName = fi.symLinkTarget();
        }

        m_entries.push_back({fileName, kind, true, fi.absoluteFilePath(), false, QStringLiteral("dialog-scripts")});
    }
```

#### AUTO 


```{c}
const auto components = pool.componentsById(service->desktopEntryName()+QStringLiteral(".desktop"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : components) {
        KGlobalAccelComponentInterface component(globalAccelInterface.service(), componentPath.path(),
            QDBusConnection::sessionBus());
        component.setTimeout(dbusTimeout);
        if (!component.isValid()) {
            return true;
        }
        auto allShortcutsCall = component.allShortcutInfos();
        allShortcutsCall.waitForFinished();
        if (allShortcutsCall.isError()) {
            return true;
        }
        const auto allShortcuts = allShortcutsCall.value();
        for (const auto &shortcutInfo : allShortcuts) {
            if (shortcutInfo.defaultKeys() != shortcutInfo.keys()) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &language : layoutInfo->languages) {
                QVERIFY(!language.isEmpty());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&style](const StylesModelData &item) {
        return item.styleName == style;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Accounts::AccountId &accountId : accountIds) {
            account = accountsManager->account(accountId);
            if (account) {
                bool completed{false};
                qCDebug(ATTICA_PLUGIN_LOG) << "Fetching data for" << accountId;
                GetCredentialsJob *job = new GetCredentialsJob(accountId, accountsManager);
                connect(job, &KJob::finished, [&completed, &accessToken, &idToken](KJob *kjob) {
                    GetCredentialsJob *job = qobject_cast<GetCredentialsJob *>(kjob);
                    const QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData[QStringLiteral("AccessToken")].toString();
                    idToken = credentialsData[QStringLiteral("IdToken")].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
                    //                     if (!accessToken.isEmpty()) {
                    //                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
                    //                         for (const QString& key : credentialsData.keys()) {
                    //                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                    //                         }
                    //                     }
                    completed = true;
                });
                connect(job, &KJob::result, [&completed]() {
                    completed = true;
                });
                job->start();
                while (!completed) {
                    qApp->processEvents();
                }
                if (!idToken.isEmpty()) {
                    qCDebug(ATTICA_PLUGIN_LOG) << "OpenID Access token retrieved for account" << account->id();
                    break;
                }
            }
            if (idToken.isEmpty()) {
                // If we arrived here, we did have an opendesktop account, but without the id token, which means an old version of the signon oauth2 plugin was
                // used
                qCWarning(ATTICA_PLUGIN_LOG) << "We got an OpenDesktop account, but it seems to be lacking the id token. This means an old SignOn OAuth2 "
                                                "plugin was used for logging in. The plugin may have been upgraded in the meantime, but an account created "
                                                "using the old plugin cannot be used, and you must log out and back in again.";
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[callback,result] (QDBusPendingCallWatcher* watcher) mutable {
                QDBusPendingReply<QDBusVariant> reply = *watcher;
                callback.call({reply.value().variant().toBool()});
                watcher->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activity: activities) {
        onActivityAdded(activity, false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, owdlg] (int result) {
        if (result == QDialog::Accepted) {

            KService::Ptr service = owdlg->service();

            Q_ASSERT(service);
            if (!service) {
                return; // Don't crash if KOpenWith wasn't able to create service.
            }

            m_model->addEntry(service);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[index, conflict, newSequence, oldSequence] (int result)  {
        auto model = const_cast<BaseModel*>(static_cast<const BaseModel*>(index.model()));
        if (result != QDialogButtonBox::Yes) {
            // Also emit if we are not changing anything, to force the frontend to update and be consistent
            // with the model. It is currently out of sync because it reflects the user input that
            // was rejected now.
            Q_EMIT model->dataChanged(index, index, {BaseModel::ActiveShortcutsRole, BaseModel::CustomShortcutsRole});
            return;
        }
        const_cast<BaseModel*>(static_cast<const BaseModel*>(conflict.model()))->disableShortcut(conflict, newSequence);
        if (!oldSequence.isEmpty()) {
            model->changeShortcut(index, oldSequence, newSequence);
        } else {
            model->addShortcut(index, newSequence);
        }
    }
```

#### AUTO 


```{c}
const auto &arg
```

#### AUTO 


```{c}
auto iterator = std::find_if(begin, end,
            [&] (const T &current) {
                return comparator(value, current);
            });
```

#### LAMBDA EXPRESSION 


```{c}
[=]() mutable {
        detail::pass_value(future, continuation);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : filesInfo) {
        QString filename = fi.fileName();
        bool desktopFile = filename.endsWith(QLatin1String(".desktop"));
        if (desktopFile) {
            AutostartEntry entry = loadDesktopEntry(fi.absoluteFilePath());

            if (!checkEntry(entry)) {
                continue;
            }

            m_entries.push_back(entry);
        }
    }
```

#### AUTO 


```{c}
const auto id = static_cast<KStandardShortcut::StandardShortcut>(i);
```

#### AUTO 


```{c}
const auto activityToSet =
        m_runningActivitiesModel->relativeActivity(direction == Next ? 1 : -1);
```

#### AUTO 


```{c}
auto const &x
```

#### AUTO 


```{c}
auto allowedApplications = QSet<QString>(allowedAppList.cbegin(), allowedAppList.cend());
```

#### AUTO 


```{c}
auto action = std::find_if(cat->actions.begin(), cat->actions.end(), [&](const Action &a) {
            return a.id == key;
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
        switch (static_cast<UserApplyJob::Error>(job->error())) {
        case UserApplyJob::Error::PermissionDenied:
            Q_EMIT applyError(i18n("Could not get permission to save user %1", mName));
            break;
        case UserApplyJob::Error::Failed:
        case UserApplyJob::Error::Unknown:
            Q_EMIT applyError(i18n("There was an error while saving changes"));
            break;
        case UserApplyJob::Error::NoError: ; // Do nothing
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        auto job = new KIO::OpenUrlJob(url);
        job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, nullptr));
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : apps) {
        QRadioButton *button = new QRadioButton(service->name(), this);
        connect(button, &QRadioButton::toggled, this, &CfgFileManager::configChanged);
        button->setProperty("storageId", service->storageId());
        radioLayout->addWidget(button);
        if (first) {
            button->setChecked(true);
            first = false;
        }
        mDynamicRadioButtons << button;
    }
```

#### AUTO 


```{c}
const auto url = index.data(FolderModel::UrlRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &device : mouses) {
        if (!m_mouseCombo->contains(device)) {
            m_mouseCombo->addItem(device);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPackage::Package &pkg : pkgs) {
        QStandardItem *row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginId(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("splash.png")), ScreenshotRole);
        row->setData(pkg.metadata().description(), DescriptionRole);
        m_model->appendRow(row);
    }
```

#### AUTO 


```{c}
auto cStrSalt = stdStrSalt.c_str();
```

#### LAMBDA EXPRESSION 


```{c}
[&completed,&accessToken,&idToken](KJob* kjob){
                    GetCredentialsJob *job = qobject_cast< GetCredentialsJob* >(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData["AccessToken"].toString();
                    idToken = credentialsData["IdToken"].toString();
                    if (!accessToken.isEmpty()) {
                        qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was gottened";
                        for (const QString& key : credentialsData.keys()) {
                            qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                        }
                    }
                    completed = true;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
        if (job->error() != KJob::NoError) {
            emit showErrorMessage(i18n("Unable to download the icon theme archive: %1", job->errorText()));
            return;
        }

        installThemeFile(m_tempInstallFile->fileName());
        m_tempInstallFile.reset();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandTouchpad *>(t)->applyConfig();
    }
```

#### AUTO 


```{c}
auto it = m_itemsOnDisabledScreensMap.find(screenId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& themesLocationPath : themesLocationsPaths) {
        QStringList possibleThemesDirectoriesNames = QDir(themesLocationPath).entryList(QDir::NoDotAndDotDot | QDir::AllDirs);
        for (const QString &possibleThemeDirectoryName : possibleThemesDirectoriesNames) {
            possibleThemesPaths += themesLocationPath + '/' + possibleThemeDirectoryName;
        }
    }
```

#### AUTO 


```{c}
auto dpiWaylandItem = m_settingsAA->findItem("forceFontDPIWayland");
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandDevice*>(t)->getDefaultConfig(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            const QString suffixedFileName = QLatin1String("color-schemes/") + file;
            // can't use QSet because of the transform below (passing const QString as this argument discards qualifiers)
            if (!schemeFiles.contains(suffixedFileName)) {
                schemeFiles.append(suffixedFileName);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *engine, QJSEngine * /*scriptEngine*/) {
        engine->setObjectOwnership(DevicesModel::self(), QQmlEngine::CppOwnership);
        return DevicesModel::self();
    }
```

#### AUTO 


```{c}
auto foundProperty = properties.constFind(property);
```

#### LAMBDA EXPRESSION 


```{c}
[packagePath]() {
            KIO::highlightInFileManager({QUrl::fromLocalFile(packagePath)});
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const KFileItem& item, const QPixmap& pixmap) mutable {
                    Q_UNUSED(item);
                    m_wallpaperCache->insertPixmap(pixmapKey, pixmap);
                    m_previewJobs.remove(path);

                    // qDebug() << "SwitcherBackend: Got the thumbnail for " << path << "saving under" << pixmapKey;
                    callback.call({true});
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : plugins) {
        const int row = indexOfPlugin(name);
        if (row != -1) {
            m_checkedRows[row] = true;
        }
    }
```

#### AUTO 


```{c}
auto getBestIcon = [&](const QStringList &iconNames) {
        const int iconSize = size * dpr;

        // not using initializer list as we want to unwrap inherits()
        const QStringList themes = QStringList() << theme.internalName() << theme.inherits();
        for (const QString &themeName : themes) {
            KIconTheme theme(themeName);

            for (const QString &iconName : iconNames) {
                QString path = theme.iconPath(QStringLiteral("%1.png").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (!path.isEmpty()) {
                    QPixmap pixmap(path);
                    pixmap.setDevicePixelRatio(dpr);
                    return pixmap;
                }

                //could not find the .png, try loading the .svg or .svgz
                path = theme.iconPath(QStringLiteral("%1.svg").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (path.isEmpty()) {
                    path = theme.iconPath(QStringLiteral("%1.svgz").arg(iconName), iconSize, KIconLoader::MatchBest);
                }

                if (path.isEmpty()) {
                    continue;
                }

                if (!renderer.load(path)) {
                    continue;
                }

                QPixmap pixmap(iconSize, iconSize);
                pixmap.setDevicePixelRatio(dpr);
                pixmap.fill(QColor(Qt::transparent));
                QPainter p(&pixmap);
                p.setViewport(0, 0, size, size);
                renderer.render(&p);
                return pixmap;
            }
        }

        return QPixmap();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[popupMenu]() { popupMenu->deleteLater(); }
```

#### AUTO 


```{c}
auto installJob = p.install(packagePath, packageRoot);
```

#### AUTO 


```{c}
auto query = UsedResources
                    | RecentlyUsedFirst
                    | Agent::any()
                    | Type::any()
                    | Activity::current();
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
        configureScreen(screen);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentGroupName : groupList) {
        auto component = std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
            return c.id == componentGroupName;
        });
        if (component == m_components.end()) {
            qCWarning(KCMKEYS) << "Ignoring unknown component" << componentGroupName;
            continue;
        }
        KConfigGroup componentGroup(&config, componentGroupName);
        if (!componentGroup.hasGroup("Global Shortcuts")) {
            qCWarning(KCMKEYS) << "Group" << componentGroupName << "has no shortcuts group";
            continue;
        }
        KConfigGroup shortcutsGroup(&componentGroup, "Global Shortcuts");
        const QStringList keys = shortcutsGroup.keyList();
        for (const auto &key : keys) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&](const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component - m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Prop<bool> &prop, bool defVal) {
        prop.reset(m_settings->load(prop.cfgName, defVal));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { changed(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&engine](const QStringList &/*arguments*/, const QString &/*workingDirectory*/) {
        for (QObject* object : engine.rootObjects()) {
            auto w = qobject_cast<QQuickWindow*>(object);
            if (!w)
                continue;
            w->setVisible(true);
            w->raise();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QVariant &pixmapVariant) {
        return pixmapVariant.value<QPixmap>().isNull();
    }
```

#### AUTO 


```{c}
const auto itemList = items();
```

#### AUTO 


```{c}
auto inputConfig = KSharedConfig::openConfig( QStringLiteral("kcminputrc") );
```

#### AUTO 


```{c}
const auto ratio = screen->devicePixelRatio();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &activity : qAsConst(activities)) {
                newHistory.append(m_historyConfigGroup.readEntry(activity, QStringList()));
            }
```

#### AUTO 


```{c}
auto idx = index(m_languages.indexOf(m_selectedLanguages.at(from)), 0);
```

#### AUTO 


```{c}
const auto indexes = m_selectionModel->selectedIndexes();
```

#### AUTO 


```{c}
const auto movedItem = m_folderModel->index(1, 0).data(FolderModel::UrlRole).toUrl();
```

#### AUTO 


```{c}
const auto constraint = QStringLiteral("'WebBrowser' in Categories and"
                                      " ('x-scheme-handler/http' in ServiceTypes or 'x-scheme-handler/https' in ServiceTypes)");
```

#### AUTO 


```{c}
auto config = plasmaConfigContainments().group(cont);
```

#### AUTO 


```{c}
auto ungrabMouseHack = [item]() {
        if (item && item->window() && item->window()->mouseGrabberItem()) {
            item->window()->mouseGrabberItem()->ungrabMouse();
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[menu]() {
        menu->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> &actual, const QHash<int, int> &expected) {

        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values.toSet().toList();
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandDevice *>(t)->getDefaultConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dictPath : qAsConst(dicts)) {
            GSList *list = ibus_emoji_data_load(dictPath.toUtf8().constData());
            m_emoji.reserve(g_slist_length(list));
            for (GSList *l = list; l; l = l->next) {
                IBusEmojiData *data = (IBusEmojiData *)l->data;
                if (!IBUS_IS_EMOJI_DATA(data)) {
                    qWarning() << "Your dict format is no longer supported.\n"
                                  "Need to create the dictionaries again.";
                    g_slist_free(list);
                    return;
                }

                const QString emoji = QString::fromUtf8(ibus_emoji_data_get_emoji(data));
                const QString description = ibus_emoji_data_get_description(data);
                if (description == QString::fromUtf8("↑↑↑") || description.isEmpty() || processedEmoji.contains(emoji)) {
                    continue;
                }

                QStringList annotations;
                const auto annotations_glib = ibus_emoji_data_get_annotations(data);
                for (GSList *l = annotations_glib; l; l = l->next) {
                    annotations << QString::fromUtf8((const gchar *)l->data);
                }

                const QString category = QString::fromUtf8(ibus_emoji_data_get_category(data));
                categories.insert(category);
                m_emoji += {emoji, description, category, annotations};
                processedEmoji << emoji;
            }
            g_slist_free(list);
        }
```

#### AUTO 


```{c}
auto selection = queryDefinition.selection();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        setNeedsSave(m_model->needsSave());
        setRepresentsDefaults(m_model->representsDefault());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XIDeviceInfo *info) {
        libinputApplyAccelerationProfile(info->deviceid, settings.currentAccelProfile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &disabledUrls : qAsConst(m_itemsOnDisabledScreensMap)) {
                found = disabledUrls.contains(name);
                if (found)
                    break;
            }
```

#### AUTO 


```{c}
const auto &file
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        const QString &value = grp.readEntry(key, QString());
        if (value.isEmpty()) {
            continue;
        }

        m_unityMappingRules.insert(key, value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : groupNameList)
    {

        KConfigGroup groupEffectOut(m_config, groupName);
        KConfigGroup groupEffectTheme(config, groupName);

        for (const QString &effect : effectList) {
            groupEffectOut.writeEntry(effect, groupEffectTheme.readEntry(effect));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktopEntry : group.groupList()) {
            m_behaviorSettingsList.insert(m_behaviorSettingsList.count(), new NotificationManager::BehaviorSettings(groupEntry, desktopEntry, this));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, bool countVisible) {
        if (uri.isEmpty() || m_storageId == uri) {
            setCountVisible(countVisible);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mount : qAsConst(m_mountPoints)) {
        if (url.startsWith(mount) && mount.size() > mountPoint.size())
            mountPoint = mount;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : activities) {
        for (const auto &agent : agents) {
            d->linking->LinkResourceToActivity(agent, resource.toString(),
                                               activity);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &error) {
        fail(error);
    }
```

#### AUTO 


```{c}
auto included = addTrailingSlashes(m_settings->folders());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c1, const Component &c2) {
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionInfo *optionInfo : optionGroupInfo->optionInfos) {
                QVERIFY(optionInfo != nullptr);
                QVERIFY(!optionInfo->name.isEmpty());
                QVERIFY(!optionInfo->description.isEmpty());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : qAsConst(layouts)) {
		defaultLayoutList.append(layoutUnit);
		if( layoutLoopCount != KeyboardConfig::NO_LOOPING && i >= layoutLoopCount-1 )
			break;
		i++;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        Q_UNUSED(error)
        emit testingFailed(QString::fromLocal8Bit(m_testProcess->readAllStandardError()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tValue : typeValues) {
            KConfigGroup vConfig = typeFile.actionGroup(tValue);
            if (!vConfig.hasKey("Name")) {
                vConfig.writeEntry("Name", availActions->propertyName(internalType, tValue));
            }
            vConfig.sync();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
                QString name = proxyModel->data(index).toString();
                q->activateComponent(name);
            }
```

#### AUTO 


```{c}
const auto activityToSet = m_runningActivitiesModel->relativeActivity(direction == Next ? 1 : -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity: shownActivities) {
        Private::emitActivityUpdated(this, shownActivities, activity->id(),
                                     ActivitiesModel::ActivityIsCurrent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionGroupInfo *optionGroupInfo : std::as_const(rules->optionGroupInfos)) {
            QDomElement optionGroup = doc.createElement(QStringLiteral("optionGroup"));
            optionGroup.setAttribute(QStringLiteral("name"), optionGroupInfo->name);
            optionGroup.setAttribute(QStringLiteral("description"), optionGroupInfo->description);
            optionGroup.setAttribute(QStringLiteral("exclusive"), optionGroupInfo->exclusive);

            for (const OptionInfo *optionInfo : optionGroupInfo->optionInfos) {
                QDomElement option = doc.createElement(QStringLiteral("option"));
                option.setAttribute(QStringLiteral("name"), optionInfo->name);
                option.setAttribute(QStringLiteral("description"), optionInfo->description);
                optionGroup.appendChild(option);
            }

            optionGroupList.appendChild(optionGroup);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
```

#### AUTO 


```{c}
auto action = mainActionCollection->addAction(actionName);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return (matcher == ANY_AGENT_TAG)     ? true :
                       (matcher == CURRENT_AGENT_TAG) ? (matcher == agent || agent == QCoreApplication::applicationName()) :
                                                        agent == matcher;
            }
```

#### AUTO 


```{c}
auto position = Private::activityPosition(shownActivities, id);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (!m_corona)
            return;

        auto config = m_corona->config();
        KConfigGroup group(config, QLatin1String("ScreenMapping"));
        group.writeEntry(QLatin1String("screenMapping"), screenMapping());
        config->sync();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : pendingDeletions) {
        m_model->setData(idx, false, ThemesModel::PendingDeletionRole);
    }
```

#### AUTO 


```{c}
auto extraLayouts = keyboardConfig->layouts.mid(keyboardConfig->layoutLoopCount() - 1);
```

#### AUTO 


```{c}
const auto begin     = pattern.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : qAsConst(extraLayouts)) {
				QAction* action = createAction(layoutUnit);
				actionGroup->addAction(action);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[this](int, QProcess::ExitStatus exitStatus) {
        if (exitStatus == QProcess::NormalExit) {
            Q_EMIT finished();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ComponentData *cd : qAsConst(d->components)) {
        KConfigGroup group(config, cd->uniqueName());
        if (group.exists()) {
            //qDebug() << "Importing" << cd->uniqueName();
            cd->editor()->importConfiguration(&group);
        }
    }
```

#### AUTO 


```{c}
static auto months = ki18ncp("unit of time. months to keep the history", " month", " months");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : d->windowModels) {
            windowModel->setVirtualDesktop(d->virtualDesktopInfo->desktopIds().at(virtualDesktop));
            ++virtualDesktop;

            windowModel->setActivity(d->activityInfo->currentActivity());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[menu]() { menu->deleteLater(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&preferredServiceAdded, preferredService, this](const KService::Ptr &service) {
        if (service->exec().isEmpty() || !service->categories().contains(m_type) || (!service->serviceTypes().contains(m_mimeType))) {
            return false;
        }
        QVariantMap application;
        application[QStringLiteral("name")] = service->name();
        application[QStringLiteral("icon")] = service->icon();
        application[QStringLiteral("storageId")] = service->storageId();
        m_applications += application;
        if ((preferredService && preferredService->storageId() == service->storageId())) {
            m_index = m_applications.length() - 1;
            preferredServiceAdded = true;
        }
        if (service->storageId() == m_defaultApplication) {
            m_defaultIndex = m_applications.length() - 1;
        }
        return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QDBusObjectPath &path) {
        QList<User *> toRemove;
        for (int i = 0; i < m_userList.length(); i++) {
            if (m_userList[i]->path().path() == path.path()) {
                toRemove << m_userList[i];
            }
        }
        for (auto user : toRemove) {
            auto index = m_userList.indexOf(user);
            beginRemoveRows(QModelIndex(), index, index);
            m_userList.removeOne(user);
            endRemoveRows();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () -> QString {
            using Common::Database;

            auto query
                = Database::instance(Database::ResourcesDatabase,
                                     Database::ReadOnly)
                      ->execQuery("SELECT mimetype FROM ResourceInfo WHERE "
                                  "targettedResource = '" + resource + "'");

            for (const auto &item : query) {
                return item[0].toString();
            }

            return QString();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &settings](XDeviceInfo * info) {
            int deviceid = info->id;
            evdevApplyReverseScroll(deviceid, settings.reverseScrollPolarity);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XDeviceInfo *info) {
        int deviceid = info->id;
        Status status;
        Atom float_type = XInternAtom (dpy, "FLOAT", False);
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        //data returned is an 1 byte boolean
        status = XIGetProperty(dpy, deviceid, valAtom, 0, 1,
                               False, float_type, &type_return, &format_return,
                               &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;


        if (type_return != float_type || !data || format_return != 32 || num_items_return != 1) {
            return;
        }

        unsigned char buffer[4096];
        float *sendPtr = (float*)buffer;
        *sendPtr = val;

        XIChangeProperty(dpy, deviceid, valAtom, float_type,
                         format_return, XIPropModeReplace, buffer, 1);

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &groupName : groupList) {
        if (groupName.startsWith(QStringLiteral("Module-"))) {
            KConfigGroup cg(&kdedrc, groupName);
            if (!cg.readEntry(QStringLiteral("autoload"), true)) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &idx : persistentPendingDeletions) {
        m_model->removeRow(idx.row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item: cache.m_items) {
                out << "Cache item: " << item << "\n";
            }
```

#### AUTO 


```{c}
auto layoutsList = X11Helper::getLayoutsList();
```

#### AUTO 


```{c}
const auto sourceColumn = sourceIndex.column();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QDBusObjectPath &path) {
        User *user = new User(this);
        user->setPath(path);
        beginInsertRows(QModelIndex(), m_userList.size(), m_userList.size());
        m_userList.append(user);
        endInsertRows();
    }
```

#### AUTO 


```{c}
const auto movedItem = m_folderModel->index(0, 0).data(FolderModel::UrlRole).toUrl();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shortcut : component.shortcuts) {
            if (shortcut.defaultShortcuts != shortcut.activeShortcuts) {
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        watcher->deleteLater();
        if (!reply.isValid()) {
            genericErrorOccured(QStringLiteral("Error while calling objectPath of component") + uniqueName, reply.error());
            return;
        }
        KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), reply.value().path(), m_globalAccelInterface->connection());
        qCDebug(KCMKEYS) << "Cleaning up component at" << reply.value();
        auto cleanUpWatcher = new QDBusPendingCallWatcher(component.cleanUp());
        connect(cleanUpWatcher, &QDBusPendingCallWatcher::finished, this, [=] {
            QDBusPendingReply<bool> reply = *cleanUpWatcher;
            cleanUpWatcher->deleteLater();
            if (!reply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling cleanUp of component") + uniqueName, reply.error());
                return;
            }
             auto it =  std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
                return c.uniqueName == uniqueName;
            });
            const int row = it - m_components.begin();
            beginRemoveRows(QModelIndex(), row, row);
            m_components.remove(row);
            endRemoveRows();
        });
    }
```

#### AUTO 


```{c}
auto dpiItem = m_settingsAA->findItem("forceFontDPI");
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& str : list) {
            str = normalizeTrailingSlashes(std::move(str));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() mutable {
        detail::pass_value(future, handler);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : windowIds) {
            for (int i = 0; i < d->tasksModel->rowCount(); ++i) {
                const QModelIndex &idx = d->tasksModel->index(i, 0);
                const QVariantList &winIds = idx.data(TaskManager::AbstractTasksModel::WinIdList).toList();
                if (!winIds.isEmpty() && winIds.at(0).value<typename std::remove_reference_t<decltype(windowIds)>::value_type>() == id) {
                    indices.push_back(idx);
                    break;
                }
            }
        }
```

#### AUTO 


```{c}
auto &layoutUnit
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &source, int from, int to, const QModelIndex &dest, int destRow) {
                if (source.isValid() || dest.isValid()) {
                    qWarning() << "We do not support tree models";

                } else {
                    beginMoveRows(QModelIndex(),
                                  sourceRowToRow(from),
                                  sourceRowToRow(to),
                                  QModelIndex(),
                                  sourceRowToRow(destRow));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url: urlsToRemoveFromMapping)
        removeFromMap(url);
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
                continuation(watcher->result());
                watcher->deleteLater();
            }
```

#### AUTO 


```{c}
const auto matching = model()->match(model()->index(0,0), Qt::UserRole, service->storageId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
        combo->addItem(variantInfo->description, variantInfo->name);
    }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(m_globalAccelInterface->getComponent(uniqueName));
```

#### LAMBDA EXPRESSION 


```{c}
[](const KGlobalShortcutInfo &info) {
                        return info.defaultKeys() != info.keys();
                    }
```

#### AUTO 


```{c}
auto position = Private::activityPosition(container, activity);
```

#### AUTO 


```{c}
const auto count = m_folderModel->rowCount();
```

#### AUTO 


```{c}
auto activeMods = qGuiApp->queryKeyboardModifiers();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QStringList &iconNames) {
        const int iconSize = size * dpr;

        // not using initializer list as we want to unwrap inherits()
        const QStringList themes = QStringList() << theme.internalName() << theme.inherits();
        for (const QString &themeName : themes) {
            KIconTheme theme(themeName);

            for (const QString &iconName : iconNames) {
                QString path = theme.iconPath(QStringLiteral("%1.png").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (!path.isEmpty()) {
                    QPixmap pixmap(path);
                    pixmap.setDevicePixelRatio(dpr);
                    return pixmap;
                }

                //could not find the .png, try loading the .svg or .svgz
                path = theme.iconPath(QStringLiteral("%1.svg").arg(iconName), iconSize, KIconLoader::MatchBest);
                if (path.isEmpty()) {
                    path = theme.iconPath(QStringLiteral("%1.svgz").arg(iconName), iconSize, KIconLoader::MatchBest);
                }

                if (path.isEmpty()) {
                    continue;
                }

                if (!renderer.load(path)) {
                    continue;
                }

                QPixmap pixmap(iconSize, iconSize);
                pixmap.setDevicePixelRatio(dpr);
                pixmap.fill(QColor(Qt::transparent));
                QPainter p(&pixmap);
                p.setViewport(0, 0, size, size);
                renderer.render(&p);
                return pixmap;
            }
        }

        return QPixmap();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { emit this->widgetChanged(); }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(m_globalAccelInterface->getComponent(desktopName));
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_selectedStyleDirty = true;
        setNeedsSave(true);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int dbusTimeout = 5;
```

#### AUTO 


```{c}
auto sortAlphabetically = [&collator](const ModulesModelData &a, const ModulesModelData &b) {
        return collator.compare(a.display, b.display) < 0;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionInfo *optionInfo : optionGroupInfo->optionInfos) {
                QDomElement option = doc.createElement(QStringLiteral("option"));
                option.setAttribute(QStringLiteral("name"), optionInfo->name);
                option.setAttribute(QStringLiteral("description"), optionInfo->description);
                optionGroup.appendChild(option);
            }
```

#### AUTO 


```{c}
auto applications = (blockedApplications + allowedApplications).values();
```

#### RANGE FOR STATEMENT 


```{c}
for (ActionItem *newItem : actionList) { // Lets find our new action
        if (newItem->desktopMasterPath == filePath) {
            const int position = actionList.indexOf(newItem);
            newAction = actionModel->index(position, 0); // Grab it
            break;
        }
    }
```

#### AUTO 


```{c}
const auto destination = destinationFor(*result.iterator);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog] (int result) {
        if (result == QDialog::Accepted && dialog->service()) {
            const KService::Ptr service = dialog->service();
            const QString desktopFileName = service->desktopEntryName() + ".desktop";
            if (m_shortcutsModel->match(m_shortcutsModel->index(0, 0), ShortcutsModel::ComponentRole, desktopFileName).isEmpty()) {
                const QString destination = QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + "/kglobalaccel/";
                QFile::copy(service->entryPath(), destination + desktopFileName);
                m_shortcutsModel->addApplication(desktopFileName, service->name());
            } else {
                qCDebug(KCMKEYS) << "Already have component" << service->storageId();
            }
        }
        dialog->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto user : toRemove) {
            auto index = m_userList.indexOf(user);
            beginRemoveRows(QModelIndex(), index, index);
            m_userList.removeOne(user);
            endRemoveRows();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
    		int newRowIndex = index.row() + shift;
    		keyboardConfig->layouts.move(index.row(), newRowIndex);
            selectionRows << newRowIndex;
    	}
```

#### AUTO 


```{c}
auto position = std::find_if(container.begin(), container.end(),
            [&] (const typename ActivityPosition<_Container>::ContainerElement &activity) {
                return activity->id() == activityId;
            }
        );
```

#### LAMBDA EXPRESSION 


```{c}
[](KStandardShortcut::Category category) {
        return static_cast<int>(category);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : set) {
            connect(user, item.first, [this, user, item] {
                auto idx = index(m_userList.lastIndexOf(user));
                Q_EMIT dataChanged(idx, idx, {item.second});
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : _keyboardRepeatButtonGroup->buttons()) {
        setDefaultIndicatorVisible(button, m_highlightVisible && !isKeyboardRepeatDefault && _keyboardRepeatButtonGroup->checkedButton() == button);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_canPresentWindows = true;
        Q_EMIT canPresentWindowsChanged();
    }
```

#### AUTO 


```{c}
const auto isNumLockDefault = m_settings->defaultNumLockValue() == TriStateHelper::getInt(TriStateHelper::getTriState(_numlockButtonGroup));
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(result, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &ppath : packs) {
        const QDir cd(ppath);
        const QStringList &entries = cd.entryList(QDir::Dirs | QDir::Hidden | QDir::NoDotAndDotDot);
        for (const QString &pack : entries) {
            const QString _metadata = ppath + QLatin1Char('/') + pack + QStringLiteral("/metadata.desktop");
            if (QFile::exists(_metadata)) {
                themes << _metadata;
            }
        }
    }
```

#### AUTO 


```{c}
auto index = [] (KStandardShortcut::Category category) { return static_cast<int>(category); };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : std::as_const(applications)) {
            const auto service = KService::serviceByDesktopName(name);
            const auto blocked = blockedApplications.contains(name);

            if (service) {
                d->applications << Private::ApplicationData{name, service->name(), service->icon(), blocked};
            } else {
                d->applications << Private::ApplicationData{name, name, QString(), blocked};
            }
        }
```

#### AUTO 


```{c}
auto urlVectorIt = m_itemsOnDisabledScreensMap.find(pair);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pathString : pathStrings) {
        paths.append(QUrl(pathString));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &currentActivity) {
                DEBUG << "Activity just got changed to" << currentActivity;
                Q_UNUSED(currentActivity);
                if (d) {
                    auto clientId = d->m_clientId;
                    initForClient(clientId);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath& path: users) {
        User *user = new User(this);
        user->setPath(path);

        const std::list<QPair<void(User::*const)(),int>> set = {
            {&User::uidChanged, UidRole},
            {&User::nameChanged, NameRole},
            {&User::faceValidChanged, FaceValidRole},
            {&User::realNameChanged, RealNameRole},
            {&User::emailChanged, EmailRole},
            {&User::administratorChanged, AdministratorRole},
        };

        for (const auto &item: set) {
            connect(user, item.first, [this, user, item]{
                auto idx = index(m_userList.lastIndexOf(user));
                Q_EMIT dataChanged(idx, idx, {item.second});
            });
        }

        m_userList.append(user);
    }
```

#### AUTO 


```{c}
auto sym = xcb_key_press_lookup_keysym(m_syms, keypress, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& containmentId: plasmaConfigContainments().groupList()) {
                const auto containment = plasmaConfigContainments().group(containmentId);
                const auto activity    = containment.readEntry("activityId", QString());

                // Ignore the containment if the activity is not defined
                if (activity.isEmpty()) continue;

                // If we have already found the same activity from another
                // containment, we are using the new one only if
                // the previous one was a color and not a proper wallpaper
                const bool processed = !ghostActivities.contains(activity) &&
                                        newForActivity.contains(activity);

                if (processed &&
                    newForActivity[activity][0] != '#') continue;

                // Marking the current activity as processed
                ghostActivities.removeAll(activity);

                const auto background = backgroundFromConfig(containment);

                if (newForActivity[activity] != background) {
                    changedActivities << activity;
                    if (!background.isEmpty()) {
                        newForActivity[activity] = background;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                    QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                    QStringLiteral("org.kde.KWin.InputDevice"),
                                    QDBusConnection::sessionBus(),
                                    this);
        const QVariant reply = deviceIface.property("touchpad");
        if (reply.isValid() && reply.toBool()) {
            KWinWaylandTouchpad* tp = new KWinWaylandTouchpad(sn);
            if (!tp->init()) {
                qCCritical(KCM_TOUCHPAD) << "Error on creating touchpad object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos for touchpad %1.", sn);
                return;
            }
            m_devices.append(tp);
            qCDebug(KCM_TOUCHPAD).nospace() <<  "Touchpad found: " <<  tp->name() << " (" << tp->sysName() << ")";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: set) {
            connect(user, item.first, [this, user, item]{
                auto idx = index(m_userList.lastIndexOf(user));
                Q_EMIT dataChanged(idx, idx, {item.second});
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &component : qAsConst(m_components)) {
        if (component.checked) {
            KConfigGroup mainGroup(&config, component.id);
            KConfigGroup group(&mainGroup, "Global Shortcuts");
            for (const auto &action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectedIndex) {
        if (idx.data(DeviceModel::TypeRole) == DeviceModel::Detached) {
            forgetDevice->setEnabled(true);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&cfgGroup](const KPluginMetaData &pluginData) {
            return pluginData.isEnabled(cfgGroup) != pluginData.isEnabledByDefault();
        }
```

#### AUTO 


```{c}
const auto &profile
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QDBusObjectPath &path) {
        QList<User*> toRemove;
        for (int i = 0; i < m_userList.length(); i++) {
            if (m_userList[i]->path().path() == path.path()) {
                toRemove << m_userList[i];
            }
        }
        for (auto user : toRemove) {
            auto index = m_userList.indexOf(user);
            beginRemoveRows(QModelIndex(), index, index);
            m_userList.removeOne(user);
            endRemoveRows();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&homePath] (const QString& url, bool include, bool fromConfig)
    {
        QString displayName = url;
        if (displayName.size() > 1) {
            displayName.chop(1);
        }
        if (displayName.startsWith(homePath)) {
            displayName.replace(0, homePath.length(), QStringLiteral("~/"));
        }

        QString icon = QStringLiteral("folder");
        if (url == homePath) {
            icon = QStringLiteral("user-home");
        } else if (!fromConfig) {
            icon = QStringLiteral("drive-harddisk");
        }

        return FolderInfo{url, displayName, icon, include, fromConfig};
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const NotificationManager::BehaviorSettings *settings) {
                                    return settings->isSaveNeeded();
                                }
```

#### AUTO 


```{c}
const static auto _a = QStringLiteral("apply");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : qAsConst(languages)) {
    	const IsoCodeEntry* isoCodeEntry = isoCodes.getEntry(IsoCodes::attr_iso_639_3_id, lang);
//    	const IsoCodeEntry* isoCodeEntry = isoCodes.getEntry(IsoCodes::attr_iso_639_2B_code, lang);
//    	if( isoCodeEntry == NULL ) {
//    		isoCodeEntry = isoCodes.getEntry(IsoCodes::attr_iso_639_2T_code, lang);
//    	}
    	QString name = isoCodeEntry != nullptr ? i18n(isoCodeEntry->value(IsoCodes::attr_name).toUtf8()) : lang;
    	layoutDialogUi->languageComboBox->addItem(name, lang);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog](int result) {
            if (result == QDialog::Rejected) {
                Q_EMIT indexChanged();
                Q_EMIT isDefaultsChanged();
                return;
            }

            const KService::Ptr service = dialog->service();
            // Check if the selected application is already in the list
            for (int i = 0; i < m_applications.length(); i++) {
                if (m_applications[i].toMap()["storageId"] == service->storageId()) {
                    m_index = i;
                    Q_EMIT indexChanged();
                    Q_EMIT isDefaultsChanged();
                    return;
                }
            }
            const QString icon = !service->icon().isEmpty() ? service->icon() : QStringLiteral("application-x-shellscript");
            QVariantMap application;
            application["name"] = service->name();
            application["icon"] = icon;
            application["storageId"] = service->storageId();
            application["execLine"] = service->exec();
            m_applications.insert(m_applications.length() - 1, application);
            m_index = m_applications.length() - 2;
            Q_EMIT applicationsChanged();
            Q_EMIT indexChanged();
            Q_EMIT isDefaultsChanged();
        }
```

#### AUTO 


```{c}
auto type = kamd::utils::make_lazy_val([&] () -> QString {
            using Common::Database;

            auto query
                = Database::instance(Database::ResourcesDatabase,
                                     Database::ReadOnly)
                      ->execQuery("SELECT mimetype FROM ResourceInfo WHERE "
                                  "targettedResource = '" + resource + "'");

            for (const auto &item : query) {
                return item[0].toString();
            }

            return QString();
        });
```

#### AUTO 


```{c}
auto entry = m_itemEntries[resource];
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Component &c, const QString &name) {
        return c.type != i18n("System Services") &&  collator.compare(c.displayName, name) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int screenId) {
                removeScreen(screenId, {});
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        if (folderUrl.adjusted(QUrl::StripTrailingSlash) != url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : std::as_const(rules11->layoutInfos)) {
            QVERIFY(layoutInfo != nullptr);
            QVERIFY(!layoutInfo->name.isEmpty());
            QVERIFY(!layoutInfo->description.isEmpty());

            for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
                QVERIFY(variantInfo != nullptr);
                QVERIFY(!variantInfo->name.isEmpty());
                QVERIFY(!variantInfo->description.isEmpty());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& component : m_components) {
        if (component.pendingDeletion) {
            removeComponent(component);
        }
        for (auto& shortcut : component.shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                const QStringList actionId = buildActionId(component.uniqueName, component.friendlyName,
                        shortcut.uniqueName, shortcut.friendlyName);
                //operator int of QKeySequence
                QList<int> keys(shortcut.activeShortcuts.cbegin(), shortcut.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << shortcut.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                        "Error while saving shortcut %1: %2", component.friendlyName, shortcut.friendlyName));
                } else {
                    shortcut.initialShortcuts = shortcut.activeShortcuts;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto normalized = stringToGrabInitialsOf.normalized(QString::NormalizationForm_D);
```

#### AUTO 


```{c}
const auto activity = activityIdForIndex(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (OptionGroupInfo *optionGroupInfo : qAsConst(rules->optionGroupInfos)) {
		optionGroupInfo->description = translate_description(optionGroupInfo);

		removeEmptyItems(optionGroupInfo->optionInfos);
		for (OptionInfo *optionInfo : qAsConst(optionGroupInfo->optionInfos)) {
			optionInfo->description = translate_description(optionInfo);
		}
	}
```

#### AUTO 


```{c}
const auto row = item.row();
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, conflict, newSequence, oldSequence] (int result)  {
        auto model = const_cast<BaseModel*>(static_cast<const BaseModel*>(index.model()));
        if (result != QDialogButtonBox::Yes) {
            // Also emit if we are not changing anything, to force the frontend to update and be consistent
            // with the model. It is currently out of sync because it reflects the user input that
            // was rejected now.
            Q_EMIT model->dataChanged(index, index, {BaseModel::ActiveShortcutsRole, BaseModel::CustomShortcutsRole});
            return;
        }
        const_cast<BaseModel*>(static_cast<const BaseModel*>(conflict.model()))->disableShortcut(conflict, newSequence);
        if (!oldSequence.isEmpty()) {
            model->changeShortcut(index, oldSequence, newSequence);
        } else {
            model->addShortcut(index, newSequence);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : pkgs) {
            std::cout << data.pluginId().toStdString() << std::endl;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> &actual, const QHash<int, int> &expected) {
        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            std::sort(values.begin(), values.end());
            auto uniqueValues = values;
            uniqueValues.erase(std::unique(uniqueValues.begin(), uniqueValues.end()), uniqueValues.end());
            std::sort(uniqueValues.begin(), uniqueValues.end());
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    }
```

#### AUTO 


```{c}
auto i = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDBusObjectPath& path: users) {
        User *user = new User(this);
        user->setPath(path);
        connect(user, &User::dataChanged, [=]() {
            beginResetModel();
            endResetModel();
        });
        m_userList.append(user);
    }
```

#### AUTO 


```{c}
auto listToSet = [] (const QList<QKeySequence> &list) {
            return QSet<QKeySequence>{list.cbegin(), list.cend()};
        };
```

#### AUTO 


```{c}
const auto activityRight = sourceModel()->data(sourceRight, KActivities::ActivitiesModel::ActivityId);
```

#### LAMBDA EXPRESSION 


```{c}
[path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.friendlyName, c2.friendlyName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            }
```

#### AUTO 


```{c}
const auto score       = result.score();
```

#### AUTO 


```{c}
auto &item = *result.iterator;
```

#### AUTO 


```{c}
auto reply = m_fprintInterface->EnrollStop();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                   QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                   QStringLiteral("org.kde.KWin.InputDevice"),
                                   QDBusConnection::sessionBus(),
                                   this);
        const QVariant reply = deviceIface.property("touchpad");
        if (reply.isValid() && reply.toBool()) {
            KWinWaylandTouchpad *tp = new KWinWaylandTouchpad(sn);
            if (!tp->init() || !tp->getConfig()) {
                qCCritical(KCM_TOUCHPAD) << "Error on creating touchpad object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos for touchpad %1.", sn);
                return;
            }
            m_devices.append(tp);
            qCDebug(KCM_TOUCHPAD).nospace() << "Touchpad found: " << tp->name() << " (" << tp->sysName() << ")";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& agent: agents.values) {
            scoring.call(QStringLiteral("DeleteStatsForResource"), activity, agent, resource);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (!m_corona)
            return;

        auto config = m_corona->config();
        KConfigGroup group(config, QStringLiteral("ScreenMapping"));
        group.writeEntry(QStringLiteral("screenMapping"), screenMapping());
        config->sync();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &id) {
                addFavoriteTo(id, activityId);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotConfigTrashBin();
        }
```

#### AUTO 


```{c}
const auto idx = sourceModel()->index(source_row, 0, source_parent);
```

#### AUTO 


```{c}
auto pos = target->mapToScene(dropPos).toPoint();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dev : knownDevices) {
        addNewDevice(dev);
    }
```

#### AUTO 


```{c}
auto items = it.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : serializedMap) {
        if (readingScreenId) {
            screenId = entry.toInt();
            readingScreenId = false;
        } else if (vectorSize == -1) {
            vectorSize = entry.toInt();
        } else {
            const auto url = stringToUrl(entry);
            m_itemsOnDisabledScreensMap[screenId].append(url);
            vectorCounter++;
            if (vectorCounter == vectorSize) {
                readingScreenId = true;
                screenId = -1;
                vectorCounter = 0;
                vectorSize = -1;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: newItems) {
                if (item.resource().startsWith('/') && !QFile(item.resource()).exists()) {
                    d->q->forgetResource(item.resource());
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            emit beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            emit endInsertRows();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* object : engine.rootObjects()) {
            auto w = qobject_cast<QQuickWindow*>(object);
            if (!w)
                continue;
            w->setVisible(true);
            w->raise();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : ghostActivities) {
            newForActivity.remove(activity);
        }
```

#### AUTO 


```{c}
auto it = m_components.rbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) {
        ui->firmwareSetupMessageWidget->removeAction(m_rebootNowAction);
        ui->firmwareSetupMessageWidget->animatedHide();

        QDBusMessage message = QDBusMessage::createMethodCall(m_login1Manager->service(),
                                                              m_login1Manager->path(),
                                                              m_login1Manager->interface(),
                                                              QStringLiteral("SetRebootToFirmwareSetup"));

        message.setArguments({enable});
        // This cannot be set through a generated DBus interface, so we have to create the message ourself.
        message.setInteractiveAuthorizationAllowed(true);

        QDBusPendingReply<void> call = m_login1Manager->connection().asyncCall(message);
        QDBusPendingCallWatcher *callWatcher = new QDBusPendingCallWatcher(call, this);
        connect(callWatcher, &QDBusPendingCallWatcher::finished, this, [this, enable](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<void> reply = *watcher;
            watcher->deleteLater();

            checkFirmwareSetupRequested();

            KMessageWidget *message = ui->firmwareSetupMessageWidget;

            if (reply.isError()) {
                // User likely canceled the PolKit prompt, don't show an error in this case
                if (reply.error().type() != QDBusError::AccessDenied) {
                    message->setMessageType(KMessageWidget::Error);
                    message->setText(i18n("Failed to request restart to firmware setup: %1", reply.error().message()));
                    message->animatedShow();
                }
                return;
            }

            if (!enable) {
                return;
            }

            message->setMessageType(KMessageWidget::Information);
            if (m_isUefi) {
                message->setText(i18n("Next time the computer is restarted, it will enter the UEFI setup screen."));
            } else {
                message->setText(i18n("Next time the computer is restarted, it will enter the firmware setup screen."));
            }
            message->addAction(m_rebootNowAction);
            message->animatedShow();
        });
    }
```

#### AUTO 


```{c}
auto *item = new KPropertySkeletonItem(m_pathsStore, "autostartLocation", defaultAutostartLocation());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotPopupAddToBookmark();
        }
```

#### AUTO 


```{c}
auto search = databases.find(info);
```

#### AUTO 


```{c}
auto normalized = normalizedId(resource);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Accounts::AccountId &accountId : accountIds) {
            account = accountsManager->account(accountId);
            if (account) {
                bool completed{false};
                qCDebug(ATTICA_PLUGIN_LOG) << "Fetching data for" << accountId;
                GetCredentialsJob *job = new GetCredentialsJob(accountId, accountsManager);
                connect(job, &KJob::finished, [&completed, &accessToken, &idToken](KJob *kjob) {
                    GetCredentialsJob *job = qobject_cast<GetCredentialsJob *>(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData["AccessToken"].toString();
                    idToken = credentialsData["IdToken"].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
                    //                     if (!accessToken.isEmpty()) {
                    //                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
                    //                         for (const QString& key : credentialsData.keys()) {
                    //                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
                    //                         }
                    //                     }
                    completed = true;
                });
                connect(job, &KJob::result, [&completed]() {
                    completed = true;
                });
                job->start();
                while (!completed) {
                    qApp->processEvents();
                }
                if (!idToken.isEmpty()) {
                    qCDebug(ATTICA_PLUGIN_LOG) << "OpenID Access token retrieved for account" << account->id();
                    break;
                }
            }
            if (idToken.isEmpty()) {
                // If we arrived here, we did have an opendesktop account, but without the id token, which means an old version of the signon oauth2 plugin was
                // used
                qCWarning(ATTICA_PLUGIN_LOG) << "We got an OpenDesktop account, but it seems to be lacking the id token. This means an old SignOn OAuth2 "
                                                "plugin was used for logging in. The plugin may have been upgraded in the meantime, but an account created "
                                                "using the old plugin cannot be used, and you must log out and back in again.";
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : x11layouts) {
            layouts.append(layoutUnit);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return
                    matcher == ANY_AGENT_TAG
                        ? true
                    : matcher == CURRENT_AGENT_TAG
                        ? (matcher == agent || agent == QCoreApplication::applicationName())
                    : agent == matcher;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QHash<int, int> &actual, const QHash<int, int> &expected) {

        auto ensureUnique = [](const QHash<int, int> mapping) {
            auto values = mapping.values();
            qSort(values);
            auto uniqueValues = values.toSet().toList();
            qSort(uniqueValues);
            QVERIFY(uniqueValues == values);
        };

        ensureUnique(actual);
        QCOMPARE(actual, expected);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &desktopEntry) -> QString {
        return desktopEntry + QStringLiteral(".desktop");
    }
```

#### AUTO 


```{c}
const auto bcp = locale.bcp47Name();
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const ColorsModelData &a, const ColorsModelData &b) {
        return collator.compare(a.display, b.display) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : newList) {
        if (!allLayouts.contains(layoutUnit))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pack : entries) {
            const QString _metadata = ppath + QLatin1Char('/') + pack + QStringLiteral("/metadata.desktop");
            if (QFile::exists(_metadata)) {
                themes << _metadata;
            }
        }
```

#### AUTO 


```{c}
const auto name = cg.readEntry("Name", i18n("Unknown"));
```

#### AUTO 


```{c}
const auto url = m_folderModel->resolvedUrl();
```

#### AUTO 


```{c}
auto position = Private::activityPosition(knownActivities, id);
```

#### AUTO 


```{c}
auto reply = QDBusConnection::sessionBus().call(message);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: query) {
            result.setTitle(query.value("title").toString());
            result.setMimetype(query.value("mimetype").toString());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q](QScreen* screen) {
        QObject::connect(screen, &QScreen::geometryChanged, q, &PagerModel::pagerItemSizeChanged);
        Q_EMIT q->pagerItemSizeChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &lu : keyboardConfig.layouts) {
        if( layoutUnit.layout() == lu.layout() && layoutUnit.variant() == lu.variant() ) {
			layoutText = lu.getDisplayName();
			break;
		}
	}
```

#### AUTO 


```{c}
auto c = loadComponent(infoReply.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (const OptionInfo *optionInfo : xkbGroup->optionInfos) {
                if (m_xkbOptions.indexOf(optionInfo->name) != -1)
                    return Qt::PartiallyChecked;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dictPath : qAsConst(dicts)) {
            GSList *list = ibus_emoji_data_load (dictPath.toUtf8().constData());
            m_emoji.reserve(g_slist_length(list));
            for (GSList *l = list; l; l = l->next) {
                IBusEmojiData *data = (IBusEmojiData *) l->data;
                if (!IBUS_IS_EMOJI_DATA (data)) {
                    qWarning() << "Your dict format is no longer supported.\n"
                                "Need to create the dictionaries again.";
                    g_slist_free (list);
                    return;
                }

                const QString emoji = QString::fromUtf8(ibus_emoji_data_get_emoji(data));
                const QString description = ibus_emoji_data_get_description(data);
                if (description == QString::fromUtf8("↑↑↑") || description.isEmpty() || processedEmoji.contains(emoji)) {
                    continue;
                }

                QStringList annotations;
                const auto annotations_glib = ibus_emoji_data_get_annotations(data);
                for (GSList *l = annotations_glib; l; l = l->next) {
                    annotations << QString::fromUtf8((const gchar*) l->data);
                }

                const QString category = QString::fromUtf8(ibus_emoji_data_get_category(data));
                categories.insert(category);
                m_emoji += { emoji, description, category, annotations };
                processedEmoji << emoji;
            }
            g_slist_free (list);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pathIt : m_screensPerPath) {
            pathIt.removeAll(pair);
        }
```

#### AUTO 


```{c}
const auto role = static_cast<QPalette::ColorRole>(i);
```

#### AUTO 


```{c}
const auto services =
        KServiceTypeTrader::self()->query(QStringLiteral("Application"), QStringLiteral("exist Exec and TRUE == [X-GNOME-UsesNotifications]"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : {m_devices->index(DeviceModel::RowAttached, 0), m_devices->index(DeviceModel::RowDetached, 0)}) {
        for (int j = 0; j < m_devices->rowCount(idx); ++j) {
            const QString udi = m_devices->index(j, 0, idx).data(DeviceModel::UdiRole).toString();
            validDevices << udi;
            enabled |= m_settings->deviceSettings(udi)->mountOnLogin() | m_settings->deviceSettings(udi)->mountOnAttach();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { callFinished(); }
```

#### AUTO 


```{c}
const auto time = times.readEntry(activity, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child : childList) {
        copyHelpFromBuddy(child);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString m : msgs) {
        if (!m.isNull()) {
            qCCritical(KCM_MOUSE) << "in error:" << m;
            if (!success) {
                error_msg.append("\n");
            }
            error_msg.append(m);
            success = false;
        }
    }
```

#### AUTO 


```{c}
const auto local = dropTargetFolderUrl.toString();
```

#### AUTO 


```{c}
auto it = m_itemsOnDisabledScreensMap.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, activityToSet]() {
        setCurrentActivity(activityToSet);
    }
```

#### AUTO 


```{c}
auto wallpaperPlugin = config.readEntry("wallpaperplugin");
```

#### AUTO 


```{c}
auto pathIt = m_screensPerPath.find(screenUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : layoutInfo->languages) {
                QDomElement langNode = doc.createElement(QStringLiteral("lang"));
                langNode.setAttribute(QStringLiteral("iso639Id"), lang);
                langList.appendChild(langNode);
            }
```

#### AUTO 


```{c}
const auto filesInfo = autostartdir.entryInfoList();
```

#### AUTO 


```{c}
auto action = d->mainActionCollection->action(actionName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : terminalEmulators) {
        addItem(QIcon::fromTheme(service->icon()), service->name(), service->exec());

        if (!terminal.isEmpty() && service->exec() == terminal) {
            setCurrentIndex(count() - 1);
            m_currentIndex = count() - 1;
        }
        if (service->exec() == QStringLiteral("konsole")) {
            m_defaultIndex = count() - 1;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const ModulesModelData &a, const ModulesModelData &b) {
        return collator.compare(a.display, b.display) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionId : actions) {

                        const QString friendlyName = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("Name"));
                        QAction *action = col->addAction(actionId);
                        action->setProperty("isConfigurationAction", QVariant(true)); // see KAction::~KAction
                        action->setProperty("componentDisplayName", friendlyName);
                        action->setText(friendlyName);

                        KGlobalAccel::self()->setShortcut(action, QList<QKeySequence>());
                        
                        const QStringList sequencesStrings = sourceDF.actionGroup(actionId).readEntry(QStringLiteral("X-KDE-Shortcuts"), QString()).split(QLatin1Char('/'));
                        QList<QKeySequence> sequences;
                        if (!sequencesStrings.isEmpty()) {
                            for (const QString &seqString : sequencesStrings) {
                                sequences.append(QKeySequence(seqString));
                            }
                        }

                        if (!sequences.isEmpty()) {
                            KGlobalAccel::self()->setDefaultShortcut(action, sequences);
                        }
                    }
```

#### AUTO 


```{c}
const auto &shortcuts = index.data(BaseModel::CustomShortcutsRole).value<QSet<QKeySequence>>();
```

#### AUTO 


```{c}
auto call = (status == NotRunning ? m_kdedInterface->unloadModule(moduleName)
                                      : m_kdedInterface->loadModule(moduleName));
```

#### AUTO 


```{c}
auto result = d->features->GetValue(
        "org.kde.ActivityManager.Resources.Scoring/isOTR/" + activity);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotShowOriginalFile();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        KWorkSpace::requestShutDown(KWorkSpace::ShutdownConfirmNo, KWorkSpace::ShutdownTypeReboot);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[index, conflict, newSequence, oldSequence](int result) {
        auto model = const_cast<BaseModel *>(static_cast<const BaseModel *>(index.model()));
        if (result != QDialogButtonBox::Yes) {
            // Also Q_EMIT if we are not changing anything, to force the frontend to update and be consistent
            // with the model. It is currently out of sync because it reflects the user input that
            // was rejected now.
            Q_EMIT model->dataChanged(index, index, {BaseModel::ActiveShortcutsRole, BaseModel::CustomShortcutsRole});
            return;
        }
        const_cast<BaseModel *>(static_cast<const BaseModel *>(conflict.model()))->disableShortcut(conflict, newSequence);
        if (!oldSequence.isEmpty()) {
            model->changeShortcut(index, oldSequence, newSequence);
        } else {
            model->addShortcut(index, newSequence);
        }
    }
```

#### AUTO 


```{c}
const auto idxSpecific = bcp.indexOf(QLatin1Char('-'));
```

#### AUTO 


```{c}
const auto actionsList = actions();
```

#### AUTO 


```{c}
auto dpy = QX11Info::display();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return (matcher == ANY_AGENT_TAG)     ? true :
                       (matcher == CURRENT_AGENT_TAG) ? agent == QCoreApplication::applicationName() :
                                                        agent == matcher;
            }
```

#### AUTO 


```{c}
const auto entry = AutostartEntry {service->name(),
                                       AutostartModel::AutostartEntrySource::XdgAutoStart, // .config/autostart load desktop at startup
                                       true,
                                       desktopPath,
                                       false,
                                       service->icon()};
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
const auto urls = it.value();
```

#### AUTO 


```{c}
const auto screens = QGuiApplication::screens();
```

#### AUTO 


```{c}
auto mappableUrl = [this, dropTargetFolderUrl](const QUrl &url) -> QString {
        QString mappedUrl = url.toString();
        if (dropTargetFolderUrl != m_dirModel->dirLister()->url()) {
            const auto local = dropTargetFolderUrl.toString();
            const auto internal = m_dirModel->dirLister()->url().toString();
            if (mappedUrl.startsWith(local)) {
                mappedUrl.replace(0, local.size(), internal);
            }
        }
        return mappedUrl;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) {
        dialog->firmwareSetupMessageWidget->removeAction(m_rebootNowAction);
        dialog->firmwareSetupMessageWidget->animatedHide();

        QDBusMessage message = QDBusMessage::createMethodCall(m_login1Manager->service(),
                                                              m_login1Manager->path(),
                                                              m_login1Manager->interface(),
                                                              QStringLiteral("SetRebootToFirmwareSetup"));

        message.setArguments({enable});
        // This cannot be set through a generated DBus interface, so we have to create the message ourself.
        message.setInteractiveAuthorizationAllowed(true);

        QDBusPendingReply<void> call = m_login1Manager->connection().asyncCall(message);
        QDBusPendingCallWatcher *callWatcher = new QDBusPendingCallWatcher(call, this);
        connect(callWatcher, &QDBusPendingCallWatcher::finished, this, [this, enable](QDBusPendingCallWatcher *watcher) {
            QDBusPendingReply<void> reply = *watcher;
            watcher->deleteLater();

            checkFirmwareSetupRequested();

            KMessageWidget *message = dialog->firmwareSetupMessageWidget;

            if (reply.isError()) {
                // User likely canceled the PolKit prompt, don't show an error in this case
                if (reply.error().type() != QDBusError::AccessDenied) {
                    message->setMessageType(KMessageWidget::Error);
                    message->setText(i18n("Failed to request restart to firmware setup: %1", reply.error().message()));
                    message->animatedShow();
                }
                return;
            }

            if (!enable) {
                return;
            }

            message->setMessageType(KMessageWidget::Information);
            if (m_isUefi) {
                message->setText(i18n("Next time the computer is restarted, it will enter the UEFI setup screen."));
            } else {
                message->setText(i18n("Next time the computer is restarted, it will enter the firmware setup screen."));
            }
            message->addAction(m_rebootNowAction);
            message->animatedShow();
        });
    }
```

#### AUTO 


```{c}
auto currentPosition = pattern.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Component &c, const QString &name) {
        return c.type != i18n("System Services") &&  collator.compare(c.friendlyName, name) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const KFileItem& item, const QPixmap& pixmap) mutable {
                    Q_UNUSED(item);
                    m_wallpaperCache->insertPixmap(pixmapKey, pixmap);
                    m_previewJobs.remove(file);

                    callback.call({true});
                }
```

#### AUTO 


```{c}
const auto *item = m_model->item(pluginIndex(m_settings->lookAndFeelPackage()));
```

#### LAMBDA EXPRESSION 


```{c}
[&preferredServiceAdded, preferredService, this](const KService::Ptr &service) {
        if (service->exec().isEmpty() || (!m_type.isEmpty() && !service->categories().contains(m_type)) || (!service->serviceTypes().contains(m_mimeType))) {
            return false;
        }
        QVariantMap application;
        application[QStringLiteral("name")] = service->name();
        application[QStringLiteral("icon")] = service->icon();
        application[QStringLiteral("storageId")] = service->storageId();
        m_applications += application;
        if ((preferredService && preferredService->storageId() == service->storageId())) {
            m_index = m_applications.length() - 1;
            preferredServiceAdded = true;
        }
        if (service->storageId() == m_defaultApplication) {
            m_defaultIndex = m_applications.length() - 1;
        }
        return false;
    }
```

#### AUTO 


```{c}
auto result = d->features->GetValue(
            "org.kde.ActivityManager.Resources.Scoring/isOTR/" + activityId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &plugin : pendingDeletionPlugins) {
        if (plugin == m_data->settings()->theme()) {
            Q_EMIT error(i18n("You cannot delete the currently selected splash screen"));
            m_model->setData(m_model->index(pluginIndex(plugin), 0), false, Roles::PendingDeletionRole);
            continue;
        }

        KJob *uninstallJob = Package(structure).uninstall(plugin, m_packageRoot);
        connect(uninstallJob, &KJob::result, this, [this, uninstallJob, plugin]() {
            if (uninstallJob->error()) {
                Q_EMIT error(uninstallJob->errorString());
            } else {
                m_model->removeRows(pluginIndex(plugin), 1);
            }
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            Q_EMIT error(xi18nc("@info:status", "Failed to run install script in terminal <message>%1</message>", job->errorString()));
        } else {
            Q_EMIT finished();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &coloritem : colorItemList)
        {
            groupOut.writeEntry(coloritem, groupTheme.readEntry(coloritem));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : currentLayouts) {
		QAction* action = createAction(layoutUnit);
		actionGroup->addAction(action);
	}
```

#### AUTO 


```{c}
const auto oldUrl = m_url;
```

#### AUTO 


```{c}
auto valueFutureInterface = new ValueFutureInterface<_Result>(value);
```

#### AUTO 


```{c}
const auto &browsers = KServiceTypeTrader::self()->query(QStringLiteral("Application"),
                                                             QStringLiteral("'WebBrowser' in Categories"));
```

#### AUTO 


```{c}
auto appEntry = dynamic_cast<AppEntry*>(entry);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
            serializedMap.append(url.toString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : std::as_const(rules->layoutInfos)) {
            QVERIFY(layoutInfo != nullptr);
            QVERIFY(!layoutInfo->name.isEmpty());
            //        	const char* desc = layoutInfo->name.toUtf8() ;
            //        	qDebug() << layoutInfo->name;
            QVERIFY(!layoutInfo->description.isEmpty());

            for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
                QVERIFY(variantInfo != nullptr);
                QVERIFY(!variantInfo->name.isEmpty());
                QVERIFY(!variantInfo->description.isEmpty());
            }
            for (const QString &language : layoutInfo->languages) {
                QVERIFY(!language.isEmpty());
            }
        }
```

#### AUTO 


```{c}
auto uninstallJob = p.uninstall("org.kde.test", packageRoot);
```

#### AUTO 


```{c}
auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.uniqueName == componentGroupName;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget* tab : {ui.tabBell, ui.tabModifier, ui.tabKeyFilters, ui.tabActivationGestures, ui.tabMouseKeys}) {
            ui.tab->setTabEnabled(ui.tab->indexOf(tab), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : it.value()) {
            // add the items to the new screen, if they are on a disabled screen and their
            // location is below the new screen's path
            if (name.url().startsWith(screenPathWithScheme)) {
                addMapping(name, screenId, DelayedSignal);
                items.removeAll(name);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &style) {
        m_settings->setWidgetStyle(style);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus);
                if (exitCode == 0) {
                    qCDebug(KCM_DESKTOP_THEME) << "Theme installed successfully :)";
                    load();
                    Q_EMIT showInfoMessage(i18n("Theme installed successfully."));
                } else {
                    qCWarning(KCM_DESKTOP_THEME) << "Theme installation failed." << exitCode;
                    Q_EMIT showInfoMessage(i18n("Theme installation failed."));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandDevice *>(t)->getConfig();
    }
```

#### AUTO 


```{c}
const auto movedItem = m_folderModel->index(1, 0).data(FolderModel::UrlRole).toString();
```

#### AUTO 


```{c}
const auto background = backgroundFromConfig(containment);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const IconsModelData &item) {
        return item.themeName == m_selectedTheme;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cont: plasmaConfigContainments().groupList()) {

                auto config = plasmaConfigContainments().group(cont);
                auto activityId = config.readEntry("activityId", QString());

                // Ignore if it has no assigned activity
                if (activityId.isEmpty()) continue;

                // Ignore if we have already found the background
                if (newBackgrounds.contains(activityId) &&
                    newBackgrounds[activityId][0] != '#') continue;

                auto newBackground = backgroundFromConfig(config);

                if (forActivity[activityId] != newBackground) {
                    changedBackgrounds << activityId;
                    if (!newBackground.isEmpty()) {
                        newBackgrounds[activityId] = newBackground;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : qAsConst(str)) {
            if (!c.isPrint() && !c.isNull()) {
                str = "";
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &activity : activities) {
        for (const auto &agent : agents) {
            d->linking->UnlinkResourceFromActivity(agent, resource.toString(),
                                                   activity);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
        QRect rect = screen->availableGeometry();
        rect.setSize(rect.size() * screen->devicePixelRatio());
        int thisDistance = pointToRect(x, y, rect);
        if (thisDistance < shortestDistance) {
            shortestDistance = thisDistance;
            closestScreen = screen;
        }
    }
```

#### AUTO 


```{c}
auto  shortcuts = shortcut.activeShortcuts;
```

#### LAMBDA EXPRESSION 


```{c}
[nUrl](const FolderInfo &folder) {
        return folder.url == nUrl;
    }
```

#### AUTO 


```{c}
auto *job = KIO::del(QUrl::fromLocalFile(path), KIO::HideProgressInfo);
```

#### AUTO 


```{c}
auto &item = m_data[index.row()];
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const KFileItem& item, const QPixmap& pixmap) mutable {
                    Q_UNUSED(item);
                    m_wallpaperCache->insertPixmap(pixmapKey, pixmap);
                    m_previewJobs.remove(path);

                    // qDebug() << "SwitcherBackend: Got the thumbnail for " << path << "saving under" << pixmapKey;
                    callback.call({true});

                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &xkbOption : qAsConst(xkbConfig.options)) {
            xkbOptions.append(xkbOption);
        }
```

#### AUTO 


```{c}
auto group
```

#### AUTO 


```{c}
const static auto _l = QStringLiteral("list");
```

#### AUTO 


```{c}
auto antiAliasingItem = m_settingsAA->findItem("antiAliasing");
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* object : engine.rootObjects()) {
            auto w = qobject_cast<QQuickWindow*>(object);
            if (!w)
                continue;

            if (w && QX11Info::isPlatformX11())
                KStartupInfo::setNewStartupId(w, QX11Info::nextStartupId());

            w->setVisible(true);
            w->raise();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : qAsConst(m_components)) {
        if (component.checked) {
            KConfigGroup mainGroup(&config, component.id);
            KConfigGroup group(&mainGroup, "Global Shortcuts");
            for (const auto& action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
        }
    }
```

#### AUTO 


```{c}
auto values = mapping.values();
```

#### LAMBDA EXPRESSION 


```{c}
[service]() {
            auto *job = new KIO::ApplicationLauncherJob(service);
            auto *delegate = new KNotificationJobUiDelegate;
            delegate->setAutoErrorHandlingEnabled(true);
            job->setUiDelegate(delegate);
            job->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        Q_UNUSED(error)
        emit testingFailed();
    }
```

#### AUTO 


```{c}
const auto lstEntry = grp.readXdgListEntry("OnlyShowIn");
```

#### AUTO 


```{c}
const auto fileCount = m_folderModel->rowCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groupList) {
                // do not overwrite the Settings group. That makes it possible to
                // update the standard scheme kksrc file with the editor.
                if (group == QLatin1String("Settings")) continue;
                config.deleteGroup(group);
            }
```

#### AUTO 


```{c}
auto abstractModel = qobject_cast<AbstractModel *>(m_sourceModel)
```

#### RANGE FOR STATEMENT 


```{c}
for (T *info : qAsConst(list)) {
        if (info->name == name)
            return info;
    }
```

#### AUTO 


```{c}
const auto positions = m_positioner->positions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", "splash.png"), ScreenhotRole);
        m_model->appendRow(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& component : qAsConst(m_components)) {
        for (const auto& action : qAsConst(component.actions)) {
            if (action.defaultShortcuts != action.activeShortcuts) {
                return false;
            }
        }
   }
```

#### AUTO 


```{c}
auto blockedApplications = QSet<QString>(blockedAppList.cbegin(), blockedAppList.cend());
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                   QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                   QStringLiteral("org.kde.KWin.InputDevice"),
                                   QDBusConnection::sessionBus(),
                                   this);
        const QVariant reply = deviceIface.property("touchpad");
        if (reply.isValid() && reply.toBool()) {
            KWinWaylandTouchpad *tp = new KWinWaylandTouchpad(sn);
            if (!tp->init()) {
                qCCritical(KCM_TOUCHPAD) << "Error on creating touchpad object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos for touchpad %1.", sn);
                return;
            }
            m_devices.append(tp);
            qCDebug(KCM_TOUCHPAD).nospace() << "Touchpad found: " << tp->name() << " (" << tp->sysName() << ")";
        }
    }
```

#### AUTO 


```{c}
const auto &disabledUrls
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const NormalizedId &left, const NormalizedId &right) {
                    auto leftIndex = ordering.indexOf(left.value());
                    auto rightIndex = ordering.indexOf(right.value());

                    return (leftIndex == -1 && rightIndex == -1) ?
                               left.value() < right.value() :

                           (leftIndex == -1) ?
                               false :

                           (rightIndex == -1) ?
                               true :

                           // otherwise
                               leftIndex < rightIndex;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& item: m_items) {
            ids << item.value();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &v : std::as_const(data)) {
                    PanelFactoryInfo factory_info = v.value<PanelFactoryInfo>();
                    // X                     _factory_list << factory_info;
                    list_result << Property2String(Property(String(factory_prop_prefix.toUtf8().constData()) + factory_info.uuid,
                                                            factory_info.name,
                                                            factory_info.icon,
                                                            factory_info.lang));
                }
```

#### AUTO 


```{c}
auto listToSet = [](const QList<QKeySequence> &list) {
            return QSet<QKeySequence>{list.cbegin(), list.cend()};
        };
```

#### AUTO 


```{c}
auto reply = m_dbusInterface->ListCachedUsers();
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        if (!m_contextMenu) {
            return;
        }

        QHoverEvent ev(QEvent::HoverLeave, QPoint(0, 0), QPoint(0, 0));
        QGuiApplication::sendEvent(item, &ev);

        emit showingContextMenuChanged();

        QPointer<TaskManager::BasicMenu> guard(m_contextMenu);
        m_contextMenu->exec(pos);
        if (!guard) {
            return;
        }
        if (window) {
            m_contextMenu->windowHandle()->setTransientParent(window);
        }
        m_contextMenu->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &endpoint : preferCacheEndpoints) {
        if (notConstReq.url().toString().endsWith(endpoint)) {
            QNetworkCacheMetaData cacheMeta{m_accessManager->cache()->metaData(notConstReq.url())};
            if (cacheMeta.isValid()) {
                // If the expiration date is valid, but longer than 24 hours, don't trust that things
                // haven't changed and check first, otherwise just use the cached version to relieve
                // server strain and reduce network traffic.
                const QDateTime tomorrow{QDateTime::currentDateTime().addDays(1)};
                if (cacheMeta.expirationDate().isValid() && cacheMeta.expirationDate() < tomorrow) {
                    notConstReq.setAttribute(QNetworkRequest::CacheLoadControlAttribute, QNetworkRequest::PreferCache);
                }
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
                        if (file.endsWith(colorScheme + ".colors")) {
                            setColors(colorScheme, dir + QChar('/') + file);
                            schemeFound = true;
                            break;
                        }
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        disable();
        showOsd();
    }
```

#### AUTO 


```{c}
auto component = std::find_if(m_components.begin(), m_components.end(), [&](const Component &c) {
            return c.id == componentGroupName;
        });
```

#### AUTO 


```{c}
const auto plugin = dynamic_cast<CfgPlugin*>(configWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : qAsConst(rules->layoutInfos)) {
        if (lang.isEmpty() || layoutInfo->isLanguageSupportedByLayout(lang)) {
            if (flags) {
                QIcon icon(flags->getIcon(layoutInfo->name));
                if (icon.isNull()) {
                    icon = QIcon(emptyPixmap); // align text with no icons
                }
                layoutDialogUi->layoutComboBox->addItem(icon, layoutInfo->description, layoutInfo->name);
            } else {
                layoutDialogUi->layoutComboBox->addItem(layoutInfo->description, layoutInfo->name);
            }

            // try to guess best default layout selection for given language
            if (!lang.isEmpty() && defaultIndex == -1 && layoutInfo->isLanguageSupportedByDefaultVariant(lang)) {
                defaultIndex = i;
            }
            i++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& window: windows) {
        KWindowInfo info(window, NET::WMVisibleName, NET::WM2Activities);
        const QStringList activities = info.activities();

        if (activities.isEmpty() || activities.contains("00000000-0000-0000-0000-000000000000")) continue;

        for (const auto& activity: activities) {
            m_activitiesWindows[activity] << window;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &theme : qAsConst(themes)) {
        int themeSepIndex = theme.lastIndexOf(QLatin1Char('/'), -1);
        const QString themeRoot = theme.left(themeSepIndex);
        int themeNameSepIndex = themeRoot.lastIndexOf(QLatin1Char('/'), -1);
        const QString packageName = themeRoot.right(themeRoot.length() - themeNameSepIndex - 1);

        KDesktopFile df(theme);

        if (df.noDisplay()) {
            continue;
        }

        QString name = df.readName();
        if (name.isEmpty()) {
            name = packageName;
        }
        const bool isLocal = QFileInfo(theme).isWritable();
        bool hasPluginName = std::any_of(m_data.begin(), m_data.end(), [&] (const ThemesModelData &item) {
            return item.pluginName == packageName;
        });
        if (!hasPluginName) {
            // Plasma Theme creates a KColorScheme out of the "color" file and falls back to system colors if there is none
            const QString colorsPath = themeRoot + QLatin1String("/colors");
            const bool followsSystemColors = !QFileInfo::exists(colorsPath);
            ColorType type = FollowsColorTheme;
            if (!followsSystemColors) {
                const KSharedConfig::Ptr config = KSharedConfig::openConfig(colorsPath);
                const QPalette palette  =  KColorScheme::createApplicationPalette(config);
                const int windowBackgroundGray = qGray(palette.window().color().rgb());
                if (windowBackgroundGray < 192) {
                    type = DarkTheme;
                } else {
                    type = LightTheme;
                }
            }
            ThemesModelData item {
                name,
                packageName,
                df.readComment(),
                type,
                isLocal,
                false
            };
            m_data.append(item);
        }
    }
```

#### AUTO 


```{c}
const auto row = index.row();
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), PluginNameRole, m_selectedPlugin);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Shortcut &s) {
                return s.uniqueName == key;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, bool progressVisible) {
        if (uri.isEmpty() || m_storageId == uri) {
            setProgressVisible(progressVisible);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shortcut : component.shortcuts) {
            if (shortcut.initialShortcuts != shortcut.activeShortcuts) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : actions) { // We want every single action
                KConfigGroup actionType = deviceFile.actionGroup(text);
                deviceValues.insert(text, actionType.readEntry("Name")); // Add to the type - actions map
            }
```

#### AUTO 


```{c}
auto *job = KIO::del(QUrl::fromLocalFile(theme.dir()), KIO::HideProgressInfo);
```

#### AUTO 


```{c}
const auto levelEnum = QMetaEnum::fromType<KeyCap::Level>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
            if (action->data().toInt() == alignment) {
                action->setChecked(true);
                break;
            }
        }
```

#### AUTO 


```{c}
auto query = UsedResources | RecentlyUsedFirst | Agent(storageId) | Type::any() | Activity::current() | Url::file();
```

#### AUTO 


```{c}
const auto movedItem = m_folderModel->index(0, 0).data(FolderModel::UrlRole).toString();
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, bool,         bool,                 IsPrivate)
```

#### LAMBDA EXPRESSION 


```{c}
[&font, &textColor, &offset, &rect](QString text) {
        //don't try to paint stuff on a future null pixmap because the text is empty
        if (text.isEmpty()) {
            return QPixmap();
        }

        // Draw text
        QFontMetrics fm(font);
        QRect textRect = fm.boundingRect(text);
        QPixmap textPixmap(textRect.width(), fm.height());
        textPixmap.fill(Qt::transparent);
        QPainter p(&textPixmap);
        p.setPen(textColor);
        p.setFont(font);
        // FIXME: the center alignment here is odd: the rect should be the size needed by
        //        the text, but for some fonts and configurations this is off by a pixel or so
        //        and "centering" the text painting 'fixes' that. Need to research why
        //        this is the case and determine if we should be painting it differently here,
        //        doing soething different with the boundingRect call or if it's a problem
        //        in Qt itself
        p.drawText(rect, Qt::AlignCenter, text);
        p.end();

        return textPixmap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString mountPoint : m_mountPoints) {
            if (url.startsWith(mountPoint)) {
                name = QLatin1Char('[') + mountPoint+ QLatin1String("]/") + url.mid(mountPoint.length());
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[item]() {
        if (item && item->window() && item->window()->mouseGrabberItem()) {
            item->window()->mouseGrabberItem()->ungrabMouse();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (T *info : qAsConst(list)) {
		if( info->name == name )
			return info;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : autostartDirFilesInfo) {
        QString fileName = fi.absoluteFilePath();
        const bool isSymlink = fi.isSymLink();
        if (isSymlink) {
            fileName = fi.symLinkTarget();
        }

        m_entries.push_back({fileName, isSymlink ? fileName : QString(), kind, true, fi.absoluteFilePath(), false, QStringLiteral("dialog-scripts")});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Plasma::Package &pkg : pkgs) {
        if (!pkg.metadata().isValid()) {
            continue;
        }
        QStandardItem* row = new QStandardItem(pkg.metadata().name());
        row->setData(pkg.metadata().pluginName(), PluginNameRole);
        row->setData(pkg.filePath("previews", QStringLiteral("preview.png")), ScreenhotRole);

        //What the package provides
        row->setData(!pkg.filePath("splashmainscript").isEmpty(), HasSplashRole);
        row->setData(!pkg.filePath("lockscreenmainscript").isEmpty(), HasLockScreenRole);
        row->setData(!pkg.filePath("runcommandmainscript").isEmpty(), HasRunCommandRole);
        row->setData(!pkg.filePath("logoutmainscript").isEmpty(), HasLogoutRole);

        if (!pkg.filePath("defaults").isEmpty()) {
            KSharedConfigPtr conf = KSharedConfig::openConfig(pkg.filePath("defaults"));
            KConfigGroup cg(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "General");
            bool hasColors = !cg.readEntry("ColorScheme", QString()).isEmpty();
            row->setData(hasColors, HasColorsRole);
            if (!hasColors) {
                hasColors = !pkg.filePath("colors").isEmpty();
            }
            cg = KConfigGroup(&cg, "KDE");
            row->setData(!cg.readEntry("widgetStyle", QString()).isEmpty(), HasWidgetStyleRole);
            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Icons");
            row->setData(!cg.readEntry("Theme", QString()).isEmpty(), HasIconsRole);

            cg = KConfigGroup(conf, "kdeglobals");
            cg = KConfigGroup(&cg, "Theme");
            row->setData(!cg.readEntry("name", QString()).isEmpty(), HasPlasmaThemeRole);

            cg = KConfigGroup(conf, "kcminputrc");
            cg = KConfigGroup(&cg, "Mouse");
            row->setData(!cg.readEntry("cursorTheme", QString()).isEmpty(), HasCursorsRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "WindowSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasWindowSwitcherRole);

            cg = KConfigGroup(conf, "kwinrc");
            cg = KConfigGroup(&cg, "DesktopSwitcher");
            row->setData(!cg.readEntry("LayoutName", QString()).isEmpty(), HasDesktopSwitcherRole);
        }

        m_model->appendRow(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possibleThemePath : possiblePathsToThemes()) {
        // If the directory contains any of gtk-3.X folders, it is the GTK3 theme for sure
        QDir possibleThemeDirectory(possibleThemePath);
        if (!possibleThemeDirectory.entryList(gtk3SubdirPattern, QDir::Dirs).isEmpty()) {
            gtk3ThemesNames.insert(possibleThemeDirectory.dirName(), possibleThemeDirectory.path());
        }
    }
```

#### AUTO 


```{c}
auto newBlockStart = newItems.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &l : expectedMapping) {
        m_screenMapper->addMapping(ScreenMapper::stringToUrl(l[0]), l[1].toInt(), l[2]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto windowModel : qAsConst(d->windowModels)) {
            windowModel->setVirtualDesktop(d->virtualDesktopInfo->desktopIds().at(virtualDesktop));
            ++virtualDesktop;

            windowModel->setActivity(d->activityInfo->currentActivity());
        }
```

#### AUTO 


```{c}
const auto results = m_model->match(m_model->index(0, 0), PluginNameRole, pluginName);
```

#### AUTO 


```{c}
auto componentsWatcher = new QDBusPendingCallWatcher(m_globalAccelInterface->allComponents());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : args) {
        if (arg.type() == QVariant::String) {
            const QString str = arg.toString();
            if (str == QLatin1String("--tab=layouts")) {
                setCurrentIndex(TAB_LAYOUTS);
            } else if (str == QLatin1String("--tab=advanced")) {
                setCurrentIndex(TAB_ADVANCED);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QString str) {
            return str.replace(QLatin1String("%"), QLatin1String("\\%")).replace(QLatin1String("_"), QLatin1String("\\_"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : selected) {
        rows << index.row();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : std::as_const(m_pendingChanges)) {
        if (index.row() <= last) {
            Q_EMIT dataChanged(index, index);
        }
    }
```

#### AUTO 


```{c}
const auto index = m_folderModel->index(row, 0);
```

#### AUTO 


```{c}
const auto activityLeft = sourceModel()->data(sourceLeft, KActivities::ActivitiesModel::ActivityId).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : std::as_const(indices)) {
        Q_EMIT dataChanged(index, index, roles);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi : filesInfo) {
        if (!KDesktopFile::isDesktopFile(fi.fileName())) {
            continue;
        }

        const std::optional<AutostartEntry> entry = loadDesktopEntry(fi.absoluteFilePath());

        if (!entry) {
            continue;
        }

        m_entries.push_back(entry.value());
    }
```

#### AUTO 


```{c}
const auto &jobs = m_storageIdToJobs.value(storageId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : qAsConst(rules->layoutInfos)) {
        QIcon icon;
        if (flags) {
            icon = flags->getIcon(layoutInfo->name);
            if (icon.isNull()) {
                // HACK: QListWidget->iconSize() returns an invalid size, so we can't use that to construct an empty icon
                // instead we pick a large size and QListWidget will scale it down automatically
                QPixmap emptyPixmap(QSize(48, 48));
                emptyPixmap.fill(Qt::transparent);
                icon = QIcon(emptyPixmap); // align text with no icons
            }
        }
        QListWidgetItem *defaultVariantItem = new QListWidgetItem(layoutInfo->description);
        if (flags) {
            defaultVariantItem->setIcon(icon);
        }
        defaultVariantItem->setData(LayoutNameRole, layoutInfo->name);
        defaultVariantItem->setData(VariantNameRole, QStringLiteral(""));
        layoutDialogUi->layoutListWidget->addItem(defaultVariantItem);
        for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
            QListWidgetItem *newItem = new QListWidgetItem(variantInfo->description);
            if (flags) {
                newItem->setIcon(icon);
            }
            newItem->setData(LayoutNameRole, layoutInfo->name);
            newItem->setData(VariantNameRole, variantInfo->name);
            layoutDialogUi->layoutListWidget->addItem(newItem);
        }
    }
```

#### AUTO 


```{c}
auto handedOnServer = backend->handed();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &action : it->actions) {
            if (action.initialShortcuts != action.activeShortcuts) {
                const QStringList actionId = buildActionId(it->id, it->displayName, action.id, action.displayName);
                // operator int of QKeySequence
                QList<int> keys(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                qCDebug(KCMKEYS) << "Saving" << actionId << action.activeShortcuts << keys;
                auto reply = m_globalAccelInterface->setForeignShortcut(actionId, keys);
                reply.waitForFinished();
                if (!reply.isValid()) {
                    qCCritical(KCMKEYS) << "Error while saving";
                    if (reply.error().isValid()) {
                        qCCritical(KCMKEYS) << reply.error().name() << reply.error().message();
                    }
                    emit errorOccured(i18nc("%1 is the name of the component, %2 is the action for which saving failed",
                                            "Error while saving shortcut %1: %2",
                                            it->displayName,
                                            it->displayName));
                } else {
                    action.initialShortcuts = action.activeShortcuts;
                }
            }
        }
```

#### AUTO 


```{c}
auto *e = enter;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &x: set) {
        (m_dbusIface->*(x.second))(x.first).waitForFinished();
    }
```

#### AUTO 


```{c}
auto message = QDBusMessage::createMethodCall(QStringLiteral("org.kde.plasma.emojier"),
                                                        QStringLiteral("/MainApplication"),
                                                        QStringLiteral("org.qtproject.Qt.QCoreApplication"),
                                                        QStringLiteral("quit"));
```

#### AUTO 


```{c}
const auto newEntries = m_newStuffDialog->installedEntries();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &idx : persistentPendingDeletions) {
        const QString pluginName = idx.data(PluginNameRole).toString();
        const QString displayName = idx.data(Qt::DisplayRole).toString();

        Q_ASSERT(pluginName != m_selectedPlugin);

        const QStringList arguments = {QStringLiteral("-t"), QStringLiteral("theme"), QStringLiteral("-r"), pluginName};

        QProcess *process = new QProcess(this);
        connect(process, static_cast<void (QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished), this,
            [this, process, idx, pluginName, displayName](int exitCode, QProcess::ExitStatus exitStatus) {
                Q_UNUSED(exitStatus);
                if (exitCode == 0) {
                    m_model->removeRow(idx.row());
                } else {
                    emit showErrorMessage(i18n("Removing theme failed: %1",
                                               QString::fromLocal8Bit(process->readAllStandardOutput().trimmed())));
                    m_model->setData(idx, false, PendingDeletionRole);
                }
                process->deleteLater();
            });

        process->start(program, arguments);
        process->waitForFinished(); // needed so it deletes fine when "OK" is clicked and the dialog destroyed
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *) -> QObject * {
        return new CopyHelperPrivate;
    }
```

#### AUTO 


```{c}
auto leftIndex = ordering.indexOf(left.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : mapHandler.layoutMap.keys()) {
            if (containsAll(layoutMemory.keyboardConfig.layouts, mapHandler.layoutMap[key].layouts)) {
                layoutMemory.layoutMap.insert(key, mapHandler.layoutMap[key]);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri) {
        if (uri.isEmpty() || m_storageId == uri) {
            clear();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (XDeviceInfo *info) {
        int deviceid = info->id;
        Status status;
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        //data returned is an 1 byte boolean
        status = XIGetProperty(dpy, deviceid, valAtom, 0, 1,
                               False, XA_INTEGER, &type_return, &format_return,
                               &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;


        if (type_return != XA_INTEGER || !data || format_return != 8) {
            return;
        }

        unsigned char sendVal[2] = { 0 };
        if (num_items_return == 1) {
            sendVal[0] = val;
        } else {
            // Special case for acceleration profile.
            const Atom accel = XInternAtom(dpy, LIBINPUT_PROP_ACCEL_PROFILE_ENABLED, True);
            if (num_items_return != 2 || valAtom != accel) {
                return;
            }
            sendVal[val] = 1;
        }

        XIChangeProperty(dpy, deviceid, valAtom, XA_INTEGER,
                         8, XIPropModeReplace, sendVal, num_items_return);

    }
```

#### AUTO 


```{c}
auto *s
```

#### RANGE FOR STATEMENT 


```{c}
for (const int row : qAsConst(selectionRows)) {
            QModelIndex topLeft = layoutsTableModel->index(row, 0, QModelIndex());
            QModelIndex bottomRight = layoutsTableModel->index(row, layoutsTableModel->columnCount(topLeft)-1, QModelIndex());
            selection << QItemSelectionRange(topLeft, bottomRight);
    	}
```

#### AUTO 


```{c}
const auto &attr
```

#### AUTO 


```{c}
const auto configDefaultLayouts = keyboardConfig->getDefaultLayouts();
```

#### AUTO 


```{c}
static const auto s_mimetype = QStringLiteral("x-scheme-handler/mailto");
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](KJob *job) {
        if (job->error() != KJob::NoError) {
            emit showErrorMessage(i18n("Unable to download the theme: %1", job->errorText()));
            return;
        }

        installTheme(m_tempInstallFile->fileName());
        m_tempInstallFile.reset();
    }
```

#### AUTO 


```{c}
auto job = KIO::stat(url);
```

#### AUTO 


```{c}
const auto lastScreen  = containment.readEntry("lastScreen", 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const PackageKit::Details &details) { removePackage(details.packageId()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name: it.value()) {
            // add the items to the new screen, if they are on a disabled screen and their
            // location is below the new screen's path
            if (name.url().startsWith(screenPathWithScheme)) {
                addMapping(name, screenId, DelayedSignal);
                items.removeAll(name);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, int count) {
        if (uri.isEmpty() || m_storageId == uri) {
            setCount(count);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, process]() {
            Q_EMIT error(xi18nc("@info", "Failed to run install command: <message>%1</message>", process->errorString()));
        }
```

#### AUTO 


```{c}
const auto lastScreen = containment.readEntry("lastScreen", 0);
```

#### LAMBDA EXPRESSION 


```{c}
[&preferredServiceAdded, preferredService, this](const KService::Ptr &service) {
        if (service->exec().isEmpty() || !service->categories().contains(m_type) || (!service->serviceTypes().contains(m_mimeType))) {
            return false;
        }
        QVariantMap application;
        application["name"] = service->name();
        application["icon"] = service->icon();
        application["storageId"] = service->storageId();
        m_applications += application;
        if ((preferredService && preferredService->storageId() == service->storageId())) {
            m_index = m_applications.length() - 1;
            preferredServiceAdded = true;
        }
        if (service->storageId() == m_defaultApplication) {
            m_defaultIndex = m_applications.length() - 1;
        }
        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutInfo *layoutInfo : qAsConst(rules->layoutInfos)) {
    	if( lang.isEmpty() || layoutInfo->isLanguageSupportedByLayout(lang) ) {
    		if( flags ) {
    			QIcon icon(flags->getIcon(layoutInfo->name));
    			if( icon.isNull() ) {
    				icon = QIcon(emptyPixmap);	// align text with no icons
    			}
    			layoutDialogUi->layoutComboBox->addItem(icon, layoutInfo->description, layoutInfo->name);
    		}
    		else {
    			layoutDialogUi->layoutComboBox->addItem(layoutInfo->description, layoutInfo->name);
    		}

    		// try to guess best default layout selection for given language
    		if( ! lang.isEmpty() && defaultIndex == -1 && layoutInfo->isLanguageSupportedByDefaultVariant(lang) ) {
    			defaultIndex = i;
    		}
    		i++;
    	}
    }
```

#### AUTO 


```{c}
auto trashShortcuts = m_action->shortcuts();
```

#### AUTO 


```{c}
auto uniqueValues = values.toSet().toList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : l) {
            seralizedMap.append(s);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentPath : componentPaths) {
            const QString path = componentPath.path();
            KGlobalAccelComponentInterface component(m_globalAccelInterface->service(), path, m_globalAccelInterface->connection());
            auto watcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
            connect(watcher, &QDBusPendingCallWatcher::finished, this, [path, pendingCalls, this] (QDBusPendingCallWatcher *watcher){
                QDBusPendingReply<QList<KGlobalShortcutInfo>> reply = *watcher;
                if (reply.isError()) {
                    genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos of") + path, reply.error());
                } else if (!reply.value().isEmpty()) {
                    m_components.push_back(loadComponent(reply.value()));
                }
                watcher->deleteLater();
                if (--*pendingCalls == 0) {
                    QCollator collator;
                    collator.setCaseSensitivity(Qt::CaseInsensitive);
                    collator.setNumericMode(true);
                    std::sort(m_components.begin(), m_components.end(), [&](const Component &c1, const Component &c2){
                        return c1.type != c2.type ? c1.type < c2.type : collator.compare(c1.displayName, c2.displayName) < 0;
                    });
                    endResetModel();
                    delete pendingCalls;
                }
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &coloritem : colorItemListWM)
    {
            groupWMOut.writeEntry(coloritem, groupWMTheme.readEntry(coloritem, defaultWMColors.value(i)));
            ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lang : qAsConst(languages)) {
        const IsoCodeEntry *isoCodeEntry = isoCodes.getEntry(IsoCodes::attr_iso_639_3_id, lang);
        //    	const IsoCodeEntry* isoCodeEntry = isoCodes.getEntry(IsoCodes::attr_iso_639_2B_code, lang);
        //    	if( isoCodeEntry == NULL ) {
        //    		isoCodeEntry = isoCodes.getEntry(IsoCodes::attr_iso_639_2T_code, lang);
        //    	}
        QString name = isoCodeEntry != nullptr ? i18n(isoCodeEntry->value(IsoCodes::attr_name).toUtf8()) : lang;
        layoutDialogUi->languageComboBox->addItem(name, lang);
    }
```

#### AUTO 


```{c}
auto job = KIO::stat(statUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit& layoutUnit : x11layouts) {
            layouts.append(layoutUnit);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry& entry : list) {
                if (entry.status() == KNS3::Entry::Deleted) {
                    for (const QString& deleted : entry.uninstalledFiles()) {
                        QVector<QStringRef> list = deleted.splitRef(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        QModelIndex idx = m_model->findIndex(list.last().toString());
                        if (idx.isValid()) {
                            m_model->removeTheme(idx);
                        }
                    }
                } else if (entry.status() == KNS3::Entry::Installed) {
                    for (const QString& created : entry.installedFiles()) {
                        QStringList list = created.split(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        // Because we sometimes get some extra slashes in the installed files list
                        list.removeAll({});
                        // Because we'll also get the containing folder, if it was not already there
                        // we need to ignore it.
                        if (list.last() == QLatin1String(".icons")) {
                            continue;
                        }
                        m_model->addTheme(list.join(QLatin1Char('/')));
                    }
                }
            }
```

#### AUTO 


```{c}
auto filter = [componentUnique, componentFriendly](const KService::Ptr service) {
            return service->name() == componentUnique || service->name() == componentFriendly;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (LayoutInfo *extraLayoutInfo : qAsConst(extraRules->layoutInfos)) {
		LayoutInfo* layoutInfo = findByName(rules->layoutInfos, extraLayoutInfo->name);
		if( layoutInfo != nullptr ) {
			layoutInfo->variantInfos.append( extraLayoutInfo->variantInfos );
			layoutInfo->languages.append( extraLayoutInfo->languages );
		}
		else {
			layoutsToAdd.append(extraLayoutInfo);
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Component &c) {
            return c.id == componentGroupName;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_effectsDirty = true;
        setNeedsSave(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError e) {
                qCWarning(KCM_DESKTOP_THEME) << "Theme installation failed: " << e;
                Q_EMIT showInfoMessage(i18n("Theme installation failed."));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name: it.value()) {
            // add the items to the new screen, if they are on a disabled screen and their
            // location is below the new screen's path
            if (isEmpty || name.startsWith(screenPathWithScheme)) {
                addMapping(name, screenId, DelayedSignal);
                items.removeAll(name);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[dir]() {
            QDesktopServices::openUrl(QUrl::fromLocalFile(dir));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, int count) {
        if (m_storageId == uri) {
            setCount(count);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : patterns) {
        QRegExp rx(pattern);
        rx.setPatternSyntax(QRegExp::Wildcard);
        rx.setCaseSensitivity(Qt::CaseInsensitive);
        m_regExps.append(rx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QComboBox *combo : qAsConst(m_combos)) {
        connectCombo(combo);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){ this->populateSchemeList(); }
```

#### AUTO 


```{c}
auto shortcutsWatcher = new QDBusPendingCallWatcher(component.allShortcutInfos());
```

#### AUTO 


```{c}
const auto &allowedAppList = d->pluginConfig->allowedApplications();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (pagerType == VirtualDesktops && windowModels.count()) {
                for (auto windowModel : qAsConst(windowModels)) {
                    windowModel->setActivity(activityInfo->currentActivity());
                }
            }
        }
```

#### AUTO 


```{c}
const auto name = index.data(FolderModel::UrlRole).toUrl();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& action : component.actions) {
                const QList<QKeySequence> shortcutsList(action.activeShortcuts.cbegin(), action.activeShortcuts.cend());
                group.writeEntry(action.id, QKeySequence::listToString(shortcutsList));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob* copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone,
                this, [this, map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone,
                this, [this, map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &componentGroupName : groupList) {
        auto component = std::find_if(m_components.begin(), m_components.end(), [&] (const Component &c) {
            return c.id == componentGroupName;
        });
        if (component == m_components.end()) {
            qCWarning(KCMKEYS) << "Ignoring unknown component" << componentGroupName;
            continue;
        }
        KConfigGroup componentGroup(&config, componentGroupName);
        if (!componentGroup.hasGroup("Global Shortcuts")) {
            qCWarning(KCMKEYS) << "Group" << componentGroupName << "has no shortcuts group";
            continue;
        }
        KConfigGroup shortcutsGroup(&componentGroup, "Global Shortcuts");
        const QStringList keys = shortcutsGroup.keyList();
        for (const auto& key : keys) {
            auto action = std::find_if(component->actions.begin(), component->actions.end(), [&] (const Action &a) {
                return a.id == key;
            });
            if (action == component->actions.end()) {
                qCWarning(KCMKEYS) << "Ignoring unknown action" << key;
                continue;
            }
            const auto shortcuts = QKeySequence::listFromString(shortcutsGroup.readEntry(key));
            const QSet<QKeySequence> shortcutsSet(shortcuts.cbegin(), shortcuts.cend());
            if (shortcutsSet != action->activeShortcuts) {
                action->activeShortcuts = shortcutsSet;
                const QModelIndex i = index(action - component->actions.begin(), 0, index(component-m_components.begin(), 0));
                Q_EMIT dataChanged(i, i, {CustomShortcutsRole, ActiveShortcutsRole});
            }
        }
    }
```

#### AUTO 


```{c}
const auto widget = it.value();
```

#### AUTO 


```{c}
const auto keys = m_loginForced.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &idx : indices) {
        if (!idx.isValid()) {
            return;
        }

        const CursorTheme *theme = m_themeModel->theme(idx);

        // Delete the theme from the harddrive
        KIO::del(QUrl::fromLocalFile(theme->path())); // async

        // Remove the theme from the model
        m_themeModel->removeTheme(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, items]() {
                    KPropertiesDialog::showDialog(items, Q_NULLPTR, false /*non modal*/);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](QStringList &list) {
        // we need trailing comma in case of multiple layouts but only one variant,
        // see https://github.com/xkbcommon/libxkbcommon/issues/208
        while (list.size() > 2 && list.constLast().isEmpty()) {
            list.removeLast();
        }
    }
```

#### AUTO 


```{c}
auto query = _query;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &index : selected) {
		rows << index.row();
	}
```

#### AUTO 


```{c}
auto result = handler.call({});
```

#### AUTO 


```{c}
auto pos = std::lower_bound(m_components.begin(), m_components.end(), displayName, [&](const Component &c, const QString &name) {
        return c.type != i18n("System Services") && collator.compare(c.displayName, name) < 0;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[cachePathProcess](int exitCode, QProcess::ExitStatus status) {

        if (status == QProcess::NormalExit && exitCode == 0) {
            QString path = cachePathProcess->readAllStandardOutput().trimmed();
            path.append(QLatin1String("icon-cache.kcache"));
            QFile::remove(path);
        }

        //message kde4 apps that icon theme has changed
        for (int i = 0; i < KIconLoader::LastGroup; i++) {
            QDBusMessage message = QDBusMessage::createSignal(QStringLiteral("/KGlobalSettings"),
                                                              QStringLiteral("org.kde.KGlobalSettings"),
                                                              QStringLiteral("notifyChange"));
            message.setArguments({
                4, // KGlobalSettings::IconChanged
                KIconLoader::Group(i)
            });
            QDBusConnection::sessionBus().send(message);
        }

        cachePathProcess->deleteLater();
    }
```

#### AUTO 


```{c}
auto &item = *it;
```

#### AUTO 


```{c}
auto watcher = new QDBusServiceWatcher(appViewName,
                                           QDBusConnection::sessionBus(),
                                           QDBusServiceWatcher::WatchForRegistration | QDBusServiceWatcher::WatchForUnregistration,
                                           this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &url : urls) {
        if (folderUrl.adjusted(QUrl::StripTrailingSlash)
               != url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash)) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { if (m_owner) { m_owner->entryChanged(this); } }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: activities) {
            const QString groupName =
                QStringLiteral("Favorites-") + clientId + QStringLiteral("-") + activity;

            KConfigGroup cfgGroup(cfg, groupName);

            cfgGroup.writeEntry("ordering", ids);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
            if (notifyRcFiles.contains(file)) {
                continue;
            }

            notifyRcFiles.append(file);

            KConfig config(file, KConfig::NoGlobals);
            config.addConfigSources(QStandardPaths::locateAll(QStandardPaths::GenericDataLocation,
                                        QStringLiteral("knotifications5/") + file));

            KConfigGroup globalGroup(&config, QLatin1String("Global"));

            const QRegularExpression regExp(QStringLiteral("^Event/([^/]*)$"));
            const QStringList groups = config.groupList().filter(regExp);

            const QString notifyRcName = file.section(QLatin1Char('.'), 0, -2);
            const QString desktopEntry = globalGroup.readEntry(QStringLiteral("DesktopEntry"));
            if (!desktopEntry.isEmpty()) {
                if (desktopEntries.contains(desktopEntry)) {
                    continue;
                }

                desktopEntries.append(desktopEntry);
            }

            SourceData source{
                // The old KCM read the Name and Comment from global settings disregarding
                // any user settings and just used user-specific files for actions config
                // I'm pretty sure there's a readEntry equivalent that does that without
                // reading the config stuff twice, assuming we care about this to begin with
                globalGroup.readEntry(QStringLiteral("Name")),
                globalGroup.readEntry(QStringLiteral("Comment")),
                globalGroup.readEntry(QStringLiteral("IconName")),
                true,
                notifyRcName,
                desktopEntry,
                {} // events
            };

            QVector<EventData> events;
            for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{
                    cg.readEntry("Name"),
                    cg.readEntry("Comment"),
                    cg.readEntry("IconName"),
                    eventId,
                    // TODO Flags?
                    cg.readEntry("Action").split(QLatin1Char('|'))
                };
                events.append(event);
            }

            std::sort(events.begin(), events.end(), [&collator](const EventData &a, const EventData &b) {
                return collator.compare(a.name, b.name) < 0;
            });

            source.events = events;

            if (!source.desktopEntry.isEmpty()) {
                appsData.append(source);
            } else {
                servicesData.append(source);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
            int newRowIndex = index.row() + shift;
            keyboardConfig->layouts.move(index.row(), newRowIndex);
            selectionRows << newRowIndex;
        }
```

#### AUTO 


```{c}
const auto &name
```

#### AUTO 


```{c}
const static auto _r = QStringLiteral("resetLayout");
```

#### AUTO 


```{c}
const auto componentGroupName
```

#### AUTO 


```{c}
__inline auto filtered(Member member, Args... args)
    -> decltype(boost::adaptors::filtered(
                std::bind(member, args..., std::placeholders::_1)))
{
    return boost::adaptors::filtered(
        std::bind(member, args..., std::placeholders::_1)
    );

}
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        emit this->widgetChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : recent) {
            m_emoji += { c, recentDescriptions.at(i++), QString{} };
        }
```

#### AUTO 


```{c}
auto mappableUrl = [this, dropTargetFolderUrl](const QUrl &url) -> QString {
                QString mappedUrl = url.toString();
                if (dropTargetFolderUrl != m_dirModel->dirLister()->url()) {
                    const auto local = dropTargetFolderUrl.toString();
                    const auto internal = m_dirModel->dirLister()->url().toString();
                    if (mappedUrl.startsWith(local)) {
                        mappedUrl.replace(0, local.size(), internal);
                    }
                }
                return mappedUrl;
            };
```

#### AUTO 


```{c}
const auto months  = diff % 12;
```

#### AUTO 


```{c}
auto &source = m_data[index.row()];
```

#### AUTO 


```{c}
const auto titleLeft  = sourceModel()->data(sourceLeft, KActivities::ActivitiesModel::ActivityName);
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(m_globalAccelInterface->setForeignShortcut(actionId, keys));
```

#### AUTO 


```{c}
auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = QUrl::fromUserInput(m_url, {}, QUrl::AssumeLocalFile);
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl.toString(), m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url.toString(), m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
        Plasma::Package pkg = Plasma::PluginLoader::self()->loadPackage(QStringLiteral("Plasma/LookAndFeel"));
        pkg.setPath(path);
        pkg.setFallbackPackage(Plasma::Package());
        if (components.isEmpty()) {
            packages << pkg;
        } else {
            for (const auto &component : components) {
                if (!pkg.filePath(component.toUtf8()).isEmpty()) {
                    packages << pkg;
                    break;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &matcher) {
                return (matcher == ANY_ACTIVITY_TAG)     ? true :
                       (matcher == CURRENT_ACTIVITY_TAG) ? activity == ActivitiesSync::currentActivity(activities) :
                                                           activity == matcher;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob* copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = QUrl::fromUserInput(m_url, {}, QUrl::AssumeLocalFile);
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl.toString(), m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url.toString(), m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone,
                this, [this, map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone,
                this, [this, map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto groupEntry : {QStringLiteral("Applications"), QStringLiteral("Services")}) {
        KConfigGroup group(&config, groupEntry);
        for (const QString &desktopEntry : group.groupList()) {
            m_behaviorSettingsList.insert(m_behaviorSettingsList.count(), new NotificationManager::BehaviorSettings(groupEntry, desktopEntry, this));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog] (int result) {
        if (result == QDialog::Accepted && dialog->service()) {
            const KService::Ptr service = dialog->service();
            const QString desktopFileName = service->desktopEntryName() + ".desktop";
            if (m_globalAccelModel->match(m_shortcutsModel->index(0, 0), BaseModel::ComponentRole, desktopFileName).isEmpty()) {
                m_globalAccelModel->addApplication(desktopFileName, service->name());
            } else {
                qCDebug(KCMKEYS) << "Already have component" << service->storageId();
            }
        }
        dialog->deleteLater();
    }
```

#### AUTO 


```{c}
const auto &index
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QString name = ui.components->currentText();
        QString componentUnique = components.value(name)->uniqueName();

        // The confirmation text is different when the component is active
        if (KGlobalAccel::isComponentActive(componentUnique)) {
            if (KMessageBox::questionYesNo(
                        q,
                        i18n("Component '%1' is currently active. Only global shortcuts currently not active will be removed from the list.\n"
                            "All global shortcuts will reregister themselves with their defaults when they are next started.", componentUnique),
                        i18n("Remove component")) != KMessageBox::Yes) {
                return;
            }
        } else {
            if (KMessageBox::questionYesNo(
                        q,
                        i18n("Are you sure you want to remove the registered shortcuts for component '%1'? "
                            "The component and shortcuts will reregister themselves with their default settings"
                            " when they are next started.",
                            componentUnique),
                        i18n("Remove component")) != KMessageBox::Yes) {
                return;
            }
        }

        // Initiate the removing of the component.
        if (KGlobalAccel::cleanComponent(componentUnique)) {

            // Get the objectPath BEFORE we delete the source of it
            QDBusObjectPath oPath = components.value(name)->dbusPath();
            // Remove the component from the gui
            removeComponent(componentUnique);

            // Load it again
            // #############
            if (loadComponent(oPath)) {
                // Active it
                q->activateComponent(name);
            }
        }
    }
```

#### AUTO 


```{c}
auto& component
```

#### AUTO 


```{c}
auto databaseConnectionName =
            "kactivities_db_resources_"
                // Adding the thread number to the database name
                + QString::number((quintptr)info.thread)
                // And whether it is read-only or read-write
                + (info.openMode == ReadOnly ? "_readonly" : "_readwrite");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& activity: query.activities()) {
        for (const auto& agent: query.agents()) {
            for (const auto& urlFilter: query.urlFilters()) {
                scoring.call(QStringLiteral("DeleteStatsForResource"), activity, agent, urlFilter);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &deviceAction : services) {
                ActionItem * actionItem = new ActionItem( desktop, deviceAction.name(), this ); // Create an action
                d->actions.append( actionItem );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layoutUnit : layoutsList) {
        stringList << layoutUnit.toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : themeDirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList{QStringLiteral("*.themerc")});
        for (const QString &file : fileNames) {
            const QString suffixedFileName = QLatin1String("kstyle/themes/") + file;
            if (!themeFiles.contains(suffixedFileName)) {
                themeFiles.append(suffixedFileName);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropPos, dropTargetUrl](KIO::CopyJob* copyJob) {
        auto map = [this, dropPos, dropTargetUrl](const QUrl &targetUrl) {
            m_dropTargetPositions.insert(targetUrl.fileName(), dropPos);
            m_dropTargetPositionsCleanup->start();

            if (m_usedByContainment && !m_screenMapper->sharedDesktops()) {
                // assign a screen for the item before the copy is actually done, so
                // filterAcceptsRow doesn't assign the default screen to it
                QUrl url = resolvedUrl();
                // if the folderview's folder is a standard path, just use the targetUrl for mapping
                if (targetUrl.toString().startsWith(url.toString())) {
                    m_screenMapper->addMapping(targetUrl, m_screen, ScreenMapper::DelayedSignal);
                } else if (targetUrl.toString().startsWith(dropTargetUrl.toString())) {
                    // if the folderview's folder is a special path, like desktop:// , we need to convert
                    // the targetUrl file:// path to a desktop:/ path for mapping
                    auto destPath = dropTargetUrl.path();
                    auto filePath = targetUrl.path();
                    if (filePath.startsWith(destPath)) {
                        url.setPath(filePath.remove(0, destPath.length()));
                        m_screenMapper->addMapping(url, m_screen, ScreenMapper::DelayedSignal);
                    }
                }
            }
        };
        // remember drop target position for target URL and forget about the source URL
        connect(copyJob, &KIO::CopyJob::copyingDone,
                this, [ map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        });
        connect(copyJob, &KIO::CopyJob::copyingLinkDone,
                this, [ map](KIO::Job *, const QUrl &, const QString &, const QUrl &targetUrl) {
            map(targetUrl);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dropTargetFolderUrl](const QUrl &url) -> QString {
        QString mappedUrl = url.toString();
        if (dropTargetFolderUrl != m_dirModel->dirLister()->url()) {
            const auto local = dropTargetFolderUrl.toString();
            const auto internal = m_dirModel->dirLister()->url().toString();
            if (mappedUrl.startsWith(local)) {
                mappedUrl.replace(0, local.size(), internal);
            }
        }
        return mappedUrl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
                KConfigGroup cg(&config, group);

                const QString eventId = regExp.match(group).captured(1);
                // TODO context stuff
                // TODO load defaults thing

                EventData event{cg.readEntry("Name"),
                                cg.readEntry("Comment"),
                                cg.readEntry("IconName"),
                                eventId,
                                // TODO Flags?
                                cg.readEntry("Action").split(QLatin1Char('|'))};
                events.append(event);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int screenId) {
                addScreen(screenId, {});
            }
```

#### AUTO 


```{c}
const auto shortcuts = KGlobalAccel::self()->globalShortcut(
        QStringLiteral("ActivityManager"), "switch-to-activity-" + activityId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry& entry : list) {
                if (entry.status() == KNS3::Entry::Deleted) {
                    for (const QString& deleted : entry.uninstalledFiles()) {
                        QVector<QStringRef> list = deleted.splitRef(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        QModelIndex idx = m_themeModel->findIndex(list.last().toString());
                        if (idx.isValid()) {
                            m_themeModel->removeTheme(idx);
                        }
                    }
                } else if (entry.status() == KNS3::Entry::Installed) {
                    for (const QString& created : entry.installedFiles()) {
                        QStringList list = created.split(QLatin1Char('/'));
                        if (list.last() == QLatin1Char('*')) {
                            list.takeLast();
                        }
                        // Because we sometimes get some extra slashes in the installed files list
                        list.removeAll({});
                        // Because we'll also get the containing folder, if it was not already there
                        // we need to ignore it.
                        if (list.last() == QLatin1String(".icons")) {
                            continue;
                        }
                        m_themeModel->addTheme(list.join(QLatin1Char('/')));
                    }
                }
            }
```

#### AUTO 


```{c}
auto excluded = m_settings->excludedFolders();
```

#### RANGE FOR STATEMENT 


```{c}
for (ModelInfo *modelInfo : qAsConst(rules->modelInfos)) {
		modelInfo->vendor = translate_xml_item(modelInfo->vendor);
		modelInfo->description = translate_description(modelInfo);
	}
```

#### AUTO 


```{c}
auto iterator = std::find_if(begin, end,
                [&] (const T &current) {
                    return comparator(value, current);
                });
```

#### LAMBDA EXPRESSION 


```{c}
[&completed,&accessToken,&idToken](KJob* kjob){
                    GetCredentialsJob *job = qobject_cast< GetCredentialsJob* >(kjob);
                    QVariantMap credentialsData = job->credentialsData();
                    accessToken = credentialsData["AccessToken"].toString();
                    idToken = credentialsData["IdToken"].toString();
                    // As this can be useful for more heavy duty debugging purposes, leaving this in so it doesn't have to be rewritten
//                     if (!accessToken.isEmpty()) {
//                         qCDebug(ATTICA_PLUGIN_LOG) << "Credentials data was retrieved";
//                         for (const QString& key : credentialsData.keys()) {
//                             qCDebug(ATTICA_PLUGIN_LOG) << key << credentialsData[key];
//                         }
//                     }
                    completed = true;
                }
```

#### AUTO 


```{c}
auto dpiItem = fontsAASettings()->findItem("forceFontDPI");
```

#### AUTO 


```{c}
auto groupEntry
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_shortcutsDialog->configure(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &agent : agents) {
            d->linking->UnlinkResourceFromActivity(agent, resource.toString(),
                                                   activity);
        }
```

#### AUTO 


```{c}
auto oldPosition = linkedItems.indexOf(resource);
```

#### RANGE FOR STATEMENT 


```{c}
for (KConfigSkeletonItem *i : itemList) {
        QString name(i->name());

        QWidget *child = parent->findChild<QWidget*>(kcfgPrefix + name);
        if (!child) {
            continue;
        }
        m_widgets[name] = child;

        /* FIXME: this should probably be less hackish */
        if (name == "Tapping" &&
            !supported.contains("Tapping"))
            qobject_cast<QGroupBox *>(child)->setCheckable(false);
        else if (!supported.contains(name)) {
            child->setEnabled(false);
        }

        KCoreConfigSkeleton::ItemEnum *asEnum =
                dynamic_cast<KCoreConfigSkeleton::ItemEnum *>(i);
        if (!asEnum) {
            continue;
        }

        QStringList choiceList;
        const auto asEnumChoices = asEnum->choices();
        for (const auto &choice : asEnumChoices) {
            choiceList.append(!choice.label.isEmpty() ? choice.label : choice.name);
        }

        KComboBox *asComboBox = qobject_cast<KComboBox *>(child);
        if (asComboBox) {
            asComboBox->addItems(choiceList);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, menu]() {
        menu->deleteLater();

        // Remove the event filter for swapping delete and trash action from the QCoreApplication as it is no longer needed
        if (RemoveAction *removeAction = qobject_cast<RemoveAction *>(m_actionCollection.action(QStringLiteral("remove"))))
            QCoreApplication::instance()->removeEventFilter(removeAction);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandDevice*>(t)->getConfig(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const LayoutUnit &layoutUnit : qAsConst(layouts)) {
        defaultLayoutList.append(layoutUnit);
        if (layoutLoopCount() != KeyboardConfig::NO_LOOPING && i >= layoutLoopCount() - 1) {
            break;
        }
        i++;
    }
```

#### AUTO 


```{c}
auto shadowText = [&font, &textColor, &offset, &rect](QString text) {
        //don't try to paint stuff on a future null pixmap because the text is empty
        if (text.isEmpty()) {
            return QPixmap();
        }

        // Draw text
        QFontMetrics fm(font);
        QRect textRect = fm.boundingRect(text);
        QPixmap textPixmap(textRect.width(), fm.height());
        textPixmap.fill(Qt::transparent);
        QPainter p(&textPixmap);
        p.setPen(textColor);
        p.setFont(font);
        // FIXME: the center alignment here is odd: the rect should be the size needed by
        //        the text, but for some fonts and configurations this is off by a pixel or so
        //        and "centering" the text painting 'fixes' that. Need to research why
        //        this is the case and determine if we should be painting it differently here,
        //        doing soething different with the boundingRect call or if it's a problem
        //        in Qt itself
        p.drawText(rect, Qt::AlignCenter, text);
        p.end();

        return textPixmap;
    };
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto settings : m_devices.values()) {
        saveOk &= settings->save();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectedIndex) {
        if (idx.data(DeviceModel::TypeRole) == DeviceModel::Detatched) {
            forgetDevice->setEnabled(true);
            return;
        }
    }
```

#### AUTO 


```{c}
const auto loggedIn = (mUid == getuid());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAbstractButton *button : buttons) {
        if (button->isChecked())
        {
            // Remove the '&' added by KAcceleratorManager magically
            rc.append(KLocalizedString::removeAcceleratorMarker(button->text()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *behaviorSettings : qAsConst(m_behaviorSettingsList)) {
        behaviorSettings->save();
    }
```

#### AUTO 


```{c}
const auto& urlFilter
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const Component &c) {
            return c.uniqueName == componentGroupName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (LayoutInfo *extraLayoutInfo : qAsConst(extraRules->layoutInfos)) {
        LayoutInfo *layoutInfo = findByName(rules->layoutInfos, extraLayoutInfo->name);
        if (layoutInfo != nullptr) {
            layoutInfo->variantInfos.append(extraLayoutInfo->variantInfos);
            layoutInfo->languages.append(extraLayoutInfo->languages);
        } else {
            layoutsToAdd.append(extraLayoutInfo);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QObject *t) {
        return static_cast<KWinWaylandTouchpad *>(t)->getDefaultConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(m_supported)) {
        QVariantHash::ConstIterator i = p.find(name);
        if (i == p.end()) {
            continue;
        }
        const Parameter *par = findParameter(name);
        if (par) {
            QVariant value(i.value());

            double k = getPropertyScale(name);
            if (k != 1.0) {
                bool ok = false;
                value = QVariant(value.toDouble(&ok) * k);
                if (!ok) {
                    error = true;
                    continue;
                }
            }

            if (m_negate.contains(name)) {
                QVariantHash::ConstIterator i = p.find(m_negate[name]);
                if (i != p.end() && i.value().toBool()) {
                    value = negateVariant(value);
                }
            }

            if (name == "CoastingSpeed") {
                QVariantHash::ConstIterator coastingEnabled = p.find("Coasting");
                if (coastingEnabled != p.end() &&
                        !coastingEnabled.value().toBool())
                {
                    value = QVariant(0);
                }
            }

            if (!setParameter(par, value)) {
                error = true;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        //TODO: different way to remove components that are desktop files
        //disabled desktop files need Hidden=true key
        QString name = proxyModel->data(ui.components->currentIndex()).toString();
        QString componentUnique = components.value(name)->uniqueName();

        // The confirmation text is different when the component is active
        if (KGlobalAccel::isComponentActive(componentUnique)) {
            if (KMessageBox::questionYesNo(
                        q,
                        i18n("Component '%1' is currently active. Only global shortcuts currently not active will be removed from the list.\n"
                            "All global shortcuts will reregister themselves with their defaults when they are next started.", componentUnique),
                        i18n("Remove component")) != KMessageBox::Yes) {
                return;
            }
        } else {
            if (KMessageBox::questionYesNo(
                        q,
                        i18n("Are you sure you want to remove the registered shortcuts for component '%1'? "
                            "The component and shortcuts will reregister themselves with their default settings"
                            " when they are next started.",
                            componentUnique),
                        i18n("Remove component")) != KMessageBox::Yes) {
                return;
            }
        }

        // Initiate the removing of the component.
        if (KGlobalAccel::cleanComponent(componentUnique)) {

            // Get the objectPath BEFORE we delete the source of it
            QDBusObjectPath oPath = components.value(name)->dbusPath();
            // Remove the component from the gui
            removeComponent(componentUnique);

            // Load it again
            // #############
            if (loadComponent(oPath)) {
                // Active it
                q->activateComponent(name);
            }
        }
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### AUTO 


```{c}
auto it = m_screensPerPath.find(path);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus exitStatus) {
        Q_UNUSED(exitCode);
        Q_UNUSED(exitStatus);

        const auto savedThemes = QString::fromUtf8(m_editDialogProcess->readAllStandardOutput()).split(QLatin1Char('\n'), QString::SkipEmptyParts);

        if (!savedThemes.isEmpty()) {
            m_model->load(); // would be cool to just reload/add the changed/new ones

            m_model->setSelectedScheme(savedThemes.last());
        }

        m_editDialogProcess->deleteLater();
        m_editDialogProcess = nullptr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        KConfigGroup generalConfig(m_config.group("General"));
        generalConfig.deleteEntry("history");
        generalConfig.sync();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QQmlEngine*, QJSEngine*) -> QObject* { return new CopyHelperPrivate; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, editor]() {
		Q_EMIT const_cast<KKeySequenceWidgetDelegate*>(this)->commitData(editor);
	}
```

#### AUTO 


```{c}
auto index = m_items.indexOf(normalizedId(resource));
```

#### AUTO 


```{c}
const auto entry = m_folderList.at(idx.row());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Component &c, const QString &name) {
        return c.type != i18n("System Services") && collator.compare(c.displayName, name) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_resultModel->rowCount() >= 5) {
            setSourceModel(m_resultModel);
        } else {
            setSourceModel(m_defaultModel);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, int progress) {
        if (m_storageId == uri) {
            setProgress(progress);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectedIndex) {
		if (idx.data(DeviceModel::TypeRole) == DeviceModel::Detatched) {
			forgetDevice->setEnabled(true);
			return;
		}
	}
```

#### AUTO 


```{c}
auto service = KService::serviceByStorageId(QStringLiteral("org.kde.ksysguard.desktop"));
```

#### AUTO 


```{c}
const auto terminalEmulators = KServiceTypeTrader::self()->query(QStringLiteral("Application"), constraint);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &deviceAction : services) {
                ActionItem *actionItem = new ActionItem(desktop, deviceAction.name(), this); // Create an action
                d->actions.append(actionItem);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QString &currentActivity) {
                DEBUG << "Activity just got changed to" << currentActivity;
                Q_UNUSED(currentActivity);
                auto clientId = d->m_clientId;
                initForClient(clientId);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &coloritem : colorItemListWM) {
        groupWMOut.writeEntry(coloritem, groupWMTheme.readEntry(coloritem, defaultWMColors.value(i)));
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { setShouldShowSwitcher(false); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractItemModel *model : qAsConst(m_models)) {
        const int subRowCount = model->rowCount();
        if (rowCount + subRowCount > row) {
            selection = model;
            break;
        }
        rowCount += subRowCount;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &actionInfo : info) {
        const QString &actionUnique = actionInfo.uniqueName();
        const QString &actionFriendly = actionInfo.friendlyName();
        Action action;
        action.id = actionUnique;
        action.displayName = actionFriendly;
        const QList<QKeySequence> defaultShortcuts = actionInfo.defaultKeys();
        for (const auto  &keySequence : defaultShortcuts) {
            if (!keySequence.isEmpty()) {
                action.defaultShortcuts.insert(keySequence);
            }
        }
        const QList<QKeySequence> activeShortcuts = actionInfo.keys();
        for (const QKeySequence &keySequence : activeShortcuts) {
            if (!keySequence.isEmpty()) {
                action.activeShortcuts.insert(keySequence);
            }
        }
        action.initialShortcuts = action.activeShortcuts;
        c.actions.push_back(action);
    }
```

#### AUTO 


```{c}
const auto activityLeft  = sourceModel()->data(sourceLeft, KActivitiesBackport::ActivitiesModel::ActivityId);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                if (q->rowCount()) {
                    emit q->dataChanged(q->index(0, 0), q->index(q->rowCount() - 1, 0), QVector<int>{Qt::DisplayRole});
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            QDBusPendingReply<QList<KGlobalShortcutInfo>> infoReply = *infoWatcher;
            infoWatcher->deleteLater();
            if (!infoReply.isValid()) {
                genericErrorOccured(QStringLiteral("Error while calling allShortCutInfos on new component") + desktopFileName, infoReply.error());
                return;
            }
            qCDebug(KCMKEYS) << "inserting at " << pos - m_components.begin();
            beginInsertRows(QModelIndex(), pos - m_components.begin(),  pos - m_components.begin());
            auto c = loadComponent(infoReply.value());
            m_components.insert(pos, c);
            endInsertRows();
        }
```

#### AUTO 


```{c}
auto action = activitiesActionCollection->addAction(QStringLiteral("switch-to-activity-") + activity);
```

#### RANGE FOR STATEMENT 


```{c}
for (LayoutInfo *layoutInfo : qAsConst(rules->layoutInfos)) {
		layoutInfo->description = translate_description(layoutInfo);

		removeEmptyItems(layoutInfo->variantInfos);
		for (VariantInfo *variantInfo : qAsConst(layoutInfo->variantInfos)) {
			variantInfo->description = translate_description(variantInfo);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &prop : m_props) {
        if (prop.toMap()["key"] == property.key) {
            prop = property.toMap();
            emit propertiesChanged();
            break;
        }
    }
```

#### AUTO 


```{c}
auto componentReply = m_globalAccelInterface->getComponent(uniqueName);
```

#### AUTO 


```{c}
const auto annotations_glib = ibus_emoji_data_get_annotations(data);
```

#### LAMBDA EXPRESSION 


```{c}
[&](XDeviceInfo *info) {
        int deviceid = info->id;
        Status status;
        Atom float_type = XInternAtom(dpy, "FLOAT", False);
        Atom type_return;
        int format_return;
        unsigned long num_items_return;
        unsigned long bytes_after_return;

        unsigned char *_data = nullptr;
        // data returned is an 1 byte boolean
        status = XIGetProperty(dpy, deviceid, valAtom, 0, 1, False, float_type, &type_return, &format_return, &num_items_return, &bytes_after_return, &_data);
        if (status != Success) {
            return;
        }

        QScopedArrayPointer<unsigned char, ScopedXDeleter> data(_data);
        _data = nullptr;

        if (type_return != float_type || !data || format_return != 32 || num_items_return != 1) {
            return;
        }

        unsigned char buffer[4096];
        float *sendPtr = (float *)buffer;
        *sendPtr = val;

        XIChangeProperty(dpy, deviceid, valAtom, float_type, format_return, XIPropModeReplace, buffer, 1);
    }
```

#### AUTO 


```{c}
auto cookie = xcb_grab_keyboard(QX11Info::connection(), false, w, XCB_CURRENT_TIME,
                                    XCB_GRAB_MODE_ASYNC, XCB_GRAB_MODE_ASYNC);
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(General, QString,      const QString &,      Name)
```

#### AUTO 


```{c}
const auto actions = deviceFile.readActions();
```

#### AUTO 


```{c}
const auto &key
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& shortcut : defaultShortcuts) {
        if (shortcut.toString(QKeySequence::NativeText).contains(m_filter, Qt::CaseInsensitive)
                || shortcut.toString(QKeySequence::PortableText).contains(m_filter, Qt::CaseInsensitive)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto resource =
            _resource.startsWith("/") ? QUrl::fromLocalFile(_resource).toString() : _resource;
```

#### AUTO 


```{c}
const auto componentIndex = index(i, 0);
```

#### AUTO 


```{c}
const auto activities =
        !activity.values.isEmpty()       ? activity.values :
        !d->query.activities().isEmpty() ? d->query.activities() :
                                           Terms::Activity::current().values;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *s : qApp->screens()) {
        if (s->geometry().contains(m_menuPosition)) {
            screen = s;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *w = leave;
```

#### AUTO 


```{c}
auto dialog = KNotifyConfigWidget::configure(nullptr, QStringLiteral("kaccess"));
```

#### AUTO 


```{c}
auto volume = device.as<Solid::StorageVolume>();
```

#### AUTO 


```{c}
const auto index = item.row();
```

#### AUTO 


```{c}
auto comparator = Comparator();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &locale : allLocales) {
        addLocaleToCombo(combo, locale);
    }
```

#### AUTO 


```{c}
auto image = pixmap.toImage();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : serializedMap) {
        if (readingScreenId) {
            screenId = entry.toInt();
            readingScreenId = false;
        } else if (readingActivityId) {
            // Missing activity ID in the old config before 5.25
            if (entry.toInt() > 0) {
                vectorSize = entry.toInt();
                activityId = KActivities::Consumer().currentActivity();
            } else { // When a string is a uuid, toInt() will return 0
                activityId = entry;
            }
            readingActivityId = false;
        } else if (vectorSize == -1) {
            vectorSize = entry.toInt();
        } else {
            const auto url = stringToUrl(entry);
            const auto pair = std::make_pair(screenId, activityId);
            auto urlVectorIt = m_itemsOnDisabledScreensMap.find(pair);
            if (urlVectorIt == m_itemsOnDisabledScreensMap.end()) {
                m_itemsOnDisabledScreensMap[pair] = {url};
            } else {
                urlVectorIt->append(url);
            }
            vectorCounter++;
            if (vectorCounter == vectorSize) {
                readingScreenId = true;
                readingActivityId = true;
                screenId = -1;
                vectorCounter = 0;
                vectorSize = -1;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, lineEdit]() {
            Q_EMIT const_cast<LabelEditDelegate*>(this)->commitData(lineEdit);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : browsers) {
        browserCombo->addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if (browser->storageId() == service->storageId()) {
            browserCombo->setCurrentIndex(browserCombo->count() - 1);
            m_currentIndex = browserCombo->count() - 1;
        }
        if (service->storageId() == QStringLiteral("org.kde.falkon.desktop")) {
            m_falkonIndex = browserCombo->count() - 1;
        }
    }
```

#### AUTO 


```{c}
auto reset = [this](Prop<bool> &prop, bool defVal) {
        prop.reset(m_settings->load(prop.cfgName, defVal));
    };
```

#### AUTO 


```{c}
auto config = m_corona->config();
```

#### AUTO 


```{c}
IMPLEMENT_PROPERTY(Other,   bool,         bool,                 IsPrivate)
```

#### RANGE FOR STATEMENT 


```{c}
for (const VariantInfo *variantInfo : layoutInfo->variantInfos) {
        if (lang.isEmpty() || layoutInfo->isLanguageSupportedByVariant(variantInfo, lang)) {
            layoutDialogUi->variantComboBox->addItem(variantInfo->description, variantInfo->name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : emailClients) {

        addItem(QIcon::fromTheme(service->icon()), service->name(), service->storageId());

        if (emailClientService && emailClientService->storageId() == service->storageId()) {
            setCurrentIndex(count() - 1);
            m_currentIndex = count() - 1;
        }
        if (service->storageId() == QStringLiteral("org.kde.kmail2.desktop") ||
                service->storageId() == QStringLiteral("org.kde.kmail.desktop")) {
            m_defaultIndex = count() - 1;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        bool userDataChanged = false;
        if (mUid != m_dbusIface->uid()) {
            mUid = m_dbusIface->uid();
            userDataChanged = true;
            Q_EMIT uidChanged();
        }
        if (mName != m_dbusIface->userName()) {
            mName = m_dbusIface->userName();
            userDataChanged = true;
            Q_EMIT nameChanged();
        }
        if (mFace != QUrl(m_dbusIface->iconFile())) {
            mFace = QUrl(m_dbusIface->iconFile());
            mFaceValid = QFileInfo::exists(mFace.toString());
            userDataChanged = true;
            Q_EMIT faceChanged();
            Q_EMIT faceValidChanged();
        }
        if (mRealName != m_dbusIface->realName()) {
            mRealName = m_dbusIface->realName();
            userDataChanged = true;
            Q_EMIT realNameChanged();
        }
        if (mEmail != m_dbusIface->email()) {
            mEmail = m_dbusIface->email();
            userDataChanged = true;
            Q_EMIT emailChanged();
        }
        const auto administrator = (m_dbusIface->accountType() == 1);
        if (mAdministrator != administrator) {
            mAdministrator = administrator;
            userDataChanged = true;
            Q_EMIT administratorChanged();
        }
        const auto loggedIn = (mUid == getuid());
        if (mLoggedIn != loggedIn) {
            mLoggedIn = loggedIn;
            userDataChanged = true;
        }
        if (userDataChanged) {
            Q_EMIT dataChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            loadModel();

            const auto newEntries = m_newStuffDialog->installedEntries();
            // If one new theme was installed, select the first color file in it
            if (newEntries.count() == 1) {
                QStringList installedThemes;

                const QString suffix = QStringLiteral(".colors");

                for (const QString &path : newEntries.first().installedFiles()) {
                    const QString fileName = path.section(QLatin1Char('/'), -1, -1);

                    const int suffixPos = fileName.indexOf(suffix);
                    if (suffixPos != fileName.length() - suffix.length()) {
                        continue;
                    }

                    installedThemes.append(fileName.left(suffixPos));
                }

                if (!installedThemes.isEmpty()) {
                    // The list is sorted by (potentially translated) name
                    // but that would require us parse every file, so this should be close enough
                    std::sort(installedThemes.begin(), installedThemes.end());

                    setSelectedScheme(installedThemes.constFirst());
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sn : devicesSysNames) {
        QDBusInterface deviceIface(QStringLiteral("org.kde.KWin"),
                                    QStringLiteral("/org/kde/KWin/InputDevice/") + sn,
                                    QStringLiteral("org.kde.KWin.InputDevice"),
                                    QDBusConnection::sessionBus(),
                                    this);
        QVariant reply = deviceIface.property("pointer");
        if (reply.isValid() && reply.toBool()) {
            reply = deviceIface.property("touchpad");
            if (reply.isValid() && reply.toBool()) {
                continue;
            }

            KWinWaylandDevice* dev = new KWinWaylandDevice(sn);
            if (!dev->init()) {
                qCCritical(KCM_MOUSE) << "Error on creating device object" << sn;
                m_errorString = i18n("Critical error on reading fundamental device infos of %1.", sn);
                return;
            }
            m_devices.append(dev);
            qCDebug(KCM_MOUSE).nospace() <<  "Device found: " <<  dev->name() << " (" << dev->sysName() << ")";
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[callback] (QDBusPendingCallWatcher* watcher) mutable {
                callback.call();
                watcher->deleteLater();
            }
```

#### AUTO 


```{c}
const auto url = d->normalizedId(id).value();
```

#### AUTO 


```{c}
const auto &defaultShortcuts = index.data(BaseModel::DefaultShortcutsRole).value<QSet<QKeySequence>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &x: set) {
        auto resp = (m_dbusIface->*(x.second))(x.first);
        resp.waitForFinished();
        if (resp.isError()) {
            setError(resp.error());
            qCWarning(KCMUSERS) << resp.error().name() << resp.error().message();
            emitResult();
            return;
        }
    }
```

#### AUTO 


```{c}
auto cleanTail = [](QStringList &list) {
        // we need trailing comma in case of multiple layouts but only one variant,
        // see https://github.com/xkbcommon/libxkbcommon/issues/208
        while (list.size() > 2 && list.constLast().isEmpty()) {
            list.removeLast();
        }
    };
```

#### AUTO 


```{c}
const auto cfg = KSharedConfig::openConfig("kactivitymanagerd-statsrc");
```

#### AUTO 


```{c}
const auto nonPending = match(index, PendingDeletionRole, false);
```

#### AUTO 


```{c}
auto screen
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri) {
        if (uri.isEmpty() || m_storageId == uri) {
            populate();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &uri, bool urgent) {
        if (m_storageId == uri) {
            setUrgent(urgent);
        }
    }
```

#### AUTO 


```{c}
const auto constraint = QStringLiteral("'FileManager' in Categories and 'inode/directory' in ServiceTypes");
```

#### AUTO 


```{c}
auto antiAliasingItem = fontsAASettings()->findItem("antiAliasing");
```

#### AUTO 


```{c}
auto action = activitiesActionCollection->addAction(
                "switch-to-activity-" + activity);
```

#### AUTO 


```{c}
const auto autostartDirFilesInfo = dir.entryInfoList();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QObject *t) { return static_cast<KWinWaylandTouchpad*>(t)->applyConfig(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &possibleThemePath : possiblePathsToThemes()) {
        // If the directory has a gtk-2.0 directory inside, it is the GTK2 theme for sure
        QDir possibleThemeDirectory(possibleThemePath);
        bool hasGtk2DirectoryInside = possibleThemeDirectory.exists(QStringLiteral("gtk-2.0"));
        if (hasGtk2DirectoryInside) {
            gtk2ThemesNames.insert(possibleThemeDirectory.dirName(), possibleThemeDirectory.path());
        }
    }
```

#### AUTO 


```{c}
auto it = styleData.find(styleName);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &f: dir.entryList(QStringList("*.desktop"))) {
			services += dir.absoluteFilePath(f);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Solid::DeviceInterface::Type devType : devTypeList) {
        deviceTypes << actData->nameFromInterface(devType);
    }
```

#### AUTO 


```{c}
auto view = new QQuickWidget();
```

#### AUTO 


```{c}
auto query = database->execQuery(
                "SELECT "
                "title, mimetype "
                "FROM "
                "ResourceInfo "
                "WHERE "
                "targettedResource = '" + result.resource() + "'"
                );
```

#### LAMBDA EXPRESSION 


```{c}
[ map](KIO::Job *, const QUrl &, const QUrl &targetUrl, const QDateTime &, bool, bool) {
            map(targetUrl);
        }
```

#### AUTO 


```{c}
auto query = UsedResources
            | Agent(storageId)
            | Type::any()
            | Activity::current()
            | Url::file();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name: it.value()) {
            // add the items to the new screen, if they are on a disabled screen and their
            // location is below the new screen's path
            if (isEmpty || name.url().startsWith(screenPathWithScheme)) {
                addMapping(name, screenId, DelayedSignal);
                items.removeAll(name);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const QRegExp &matcher) {
                return matcher.exactMatch(url);
            }
```

#### AUTO 


```{c}
auto propertiesEnd = properties.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int, QProcess::ExitStatus exitStatus) {
                if (exitStatus == QProcess::NormalExit) {
                    Q_EMIT finished();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, index, url, kind](KJob *theJob) {
        if (theJob->error()) {
            qWarning() << "Could add script entry" << theJob->errorString();
            return;
        }

        beginInsertRows(QModelIndex(), index, index);

        const QUrl dest = theJob->property("finalUrl").toUrl();

        AutostartEntry entry = AutostartEntry {dest.fileName(), kind, true, dest.path(), false, QStringLiteral("dialog-scripts")};

        m_entries.insert(index, entry);

        endInsertRows();
    }
```

