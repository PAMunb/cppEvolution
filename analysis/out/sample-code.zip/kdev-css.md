#### AUTO 


```{c}
auto context = NavigationContextPointer(new FieldNavigationContext(topContext, field));
```

#### AUTO 


```{c}
auto context = NavigationContextPointer(new ValueNavigationContext(topContext, value));
```

#### AUTO 


```{c}
auto context = NavigationContextPointer(new ColorNavigationContext(topContext, colorName));
```

