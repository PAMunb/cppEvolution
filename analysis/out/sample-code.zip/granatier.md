#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: qAsConst(blockElements))
                        {
                            dynamic_cast <Block*> (element)->startDestruction();
                            if (m_blockItems[nRow][nColumn] != nullptr)
                            {
                                //display bonus if available
                                if (m_bonusItems[nRow][nColumn] != nullptr)
                                {
                                    m_bonusItems[nRow][nColumn]->setUndestroyable(bomb->explosionID());
                                    m_bonusItems[nRow][nColumn]->show();
                                }
                            }
                        }
```

#### AUTO 


```{c}
auto & bomb
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: m_elements)
        {
            if(element->getType() == Granatier::Element::BLOCK ||
                (element->getType() == Granatier::Element::BOMB && (p_element == nullptr || p_element != element)) ||
                (element->getType() == Granatier::Element::PLAYER && (p_element == nullptr || p_element->getType() != Granatier::Element::PLAYER)))
            {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto* settingsDialog = new KConfigDialog(this, QStringLiteral("settings"), Settings::self());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
        {
            player->initCoordinate();
            player->init();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & bomb : m_bombs)
    {
        bomb->updateMove();
    }
```

#### AUTO 


```{c}
auto* item = new QListWidgetItem(playerIDs[i], m_list);
```

#### AUTO 


```{c}
auto settingsIterator = m_playerSettings.begin();
```

#### AUTO 


```{c}
auto* player = new Player(qreal(Granatier::CellSize * (-0.5)),qreal(Granatier::CellSize * 0.5), strPlayerIDs[i], playerSettings, m_arena);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: qAsConst(blockElements))
                {
                    Block* block = dynamic_cast <Block*> (element);
                    BlockItem* blockItem = new BlockItem(block, m_rendererArenaItems);
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    blockItem->setSpriteKey(block->getImageId());
                    blockItem->update(block->getX(), block->getY());
                    blockItem->setZValue(200);
                    if(Settings::self()->showAllTiles() == 1)
                    {
                        blockItem->setZValue(99);
                    }
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    connect(blockItem, &BlockItem::blockItemDestroyed, this, &GameScene::removeBlockItem);
                    m_blockItems[i][j] = blockItem;
                    // if the block contains a hidden bonus, create the bonus item
                    Bonus* bonus = block->getBonus();
                    if(bonus)
                    {
                        BonusItem* bonusItem = new BonusItem(bonus, m_rendererBonusItems);
                        switch(bonus->getBonusType())
                        {
                            case Granatier::Bonus::SPEED:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_speed"));
                                break;
                            case Granatier::Bonus::BOMB:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bomb"));
                                break;
                            case Granatier::Bonus::POWER:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_power"));
                                break;
                            case Granatier::Bonus::SHIELD:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_shield"));
                                break;
                            case Granatier::Bonus::THROW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_throw"));
                                break;
                            case Granatier::Bonus::KICK:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_kick"));
                                break;
                            case Granatier::Bonus::HYPERACTIVE:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_hyperactive"));
                                break;
                            case Granatier::Bonus::SLOW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_slow"));
                                break;
                            case Granatier::Bonus::MIRROR:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_mirror"));
                                break;
                            case Granatier::Bonus::SCATTY:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_scatty"));
                                break;
                            case Granatier::Bonus::RESTRAIN:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_restrain"));
                                break;
                            case Granatier::Bonus::RESURRECT:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_resurrect"));
                                break;
                            default:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        if(granatier::RNG::fromRange(0, 10) > 9 && bonusItem->spriteKey() != QStringLiteral("bonus_neutral_resurrect"))
                        {
                            bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        bonusItem->update(bonus->getX(), bonus->getY());
                        bonusItem->setZValue(100);
                        m_bonusItems[i][j] = bonusItem;

                        connect(this, &GameScene::resizeGraphics, bonusItem, &BonusItem::updateGraphics);
                        connect(bonusItem, &BonusItem::bonusItemDestroyed, this, &GameScene::removeBonusItem);

                        addItem(bonusItem);
                        if(Settings::self()->showAllTiles() == 0)
                        {
                            bonusItem->hide();
                        }
                    }
                    else
                    {
                        m_bonusItems[i][j] = nullptr;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playersGroupList)
        {
            strPlayerIDList.append(granatierConfig.group("Player").group(player).readEntry<QString>("PlayerID", QStringLiteral("")));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& dir: dirs) {
                const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
                for(const auto& file: fileNames) {
                    arenasAvailable.append(dir + QLatin1Char('/') + file);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : players)
    {
        const QString desktopPath = player->getDesktopFilePath();
        auto* theme = new KgTheme(desktopPath.toUtf8());
        theme->readFromDesktopFile(desktopPath);
        auto  playerRenderer = new KGameRenderer(theme);
        m_mapRendererPlayerItems.insert(player, playerRenderer);
        playerItem = new PlayerItem(player, playerRenderer);
        // Corrects the position of the player
        playerItem->update(player->getX(), player->getY());
        // Stops the player animation
        playerItem->stopAnim();

        m_playerItems.append(playerItem);

        connect(this, &GameScene::resizeGraphics, playerItem, &PlayerItem::updateGraphics);
        connect(playerItem, &PlayerItem::bonusItemTaken, this, &GameScene::removeBonusItem);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int badBonusTimerTimeout = 100;
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : players)
    {
        const QString desktopPath = player->getDesktopFilePath();
        KgTheme* theme = new KgTheme(desktopPath.toUtf8());
        theme->readFromDesktopFile(desktopPath);
        auto  playerRenderer = new KGameRenderer(theme);
        m_mapRendererPlayerItems.insert(player, playerRenderer);
        playerItem = new PlayerItem(player, playerRenderer);
        // Corrects the position of the player
        playerItem->update(player->getX(), player->getY());
        // Stops the player animation
        playerItem->stopAnim();

        m_playerItems.append(playerItem);

        connect(this, &GameScene::resizeGraphics, playerItem, &PlayerItem::updateGraphics);
        connect(playerItem, &PlayerItem::bonusItemTaken, this, &GameScene::removeBonusItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto arenaItem: std::as_const(m_arenaItems))
            {
                arenaItem->setRenderSize(calculateSvgSize());
                arenaItem->setScale(m_svgScaleFactor);
            }
```

#### AUTO 


```{c}
auto* arenaItem = new ArenaItem(j * Granatier::CellSize, i * Granatier::CellSize, m_renderer, QLatin1String(""));
```

#### AUTO 


```{c}
auto* theme = new KgTheme(m_themeProvider->defaultTheme()->identifier());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playersAvailable)
    {
        StructPlayerSettings settings;
        settings.strPlayerID = player;

        KConfig desktopFile(QStandardPaths::locate(QStandardPaths::AppDataLocation, QStringLiteral("players/") + settings.strPlayerID), KConfig::SimpleConfig);

        settings.strPlayerDesktopFilePath = desktopFile.name();
        settings.strPlayerName = desktopFile.group("KGameTheme").readEntry<QString>("Name", QStringLiteral(""));
        settings.strPlayerGraphicsFile = desktopFile.group("KGameTheme").readEntry<QString>("FileName", QStringLiteral(""));
        settings.enabled = false;
        
        m_playerSettings.insert(settings.strPlayerID, settings);
    }
```

#### AUTO 


```{c}
const auto& scoreItems
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: std::as_const(blockElements))
                {
                    auto* block = dynamic_cast <Block*> (element);
                    auto* blockItem = new BlockItem(block, m_rendererArenaItems);
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    blockItem->setSpriteKey(block->getImageId());
                    blockItem->update(block->getX(), block->getY());
                    blockItem->setZValue(200);
                    if(Settings::self()->showAllTiles() == 1)
                    {
                        blockItem->setZValue(99);
                    }
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    connect(blockItem, &BlockItem::blockItemDestroyed, this, &GameScene::removeBlockItem);
                    m_blockItems[i][j] = blockItem;
                    // if the block contains a hidden bonus, create the bonus item
                    Bonus* bonus = block->getBonus();
                    if(bonus)
                    {
                        auto* bonusItem = new BonusItem(bonus, m_rendererBonusItems);
                        switch(bonus->getBonusType())
                        {
                            case Granatier::Bonus::SPEED:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_speed"));
                                break;
                            case Granatier::Bonus::BOMB:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bomb"));
                                break;
                            case Granatier::Bonus::POWER:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_power"));
                                break;
                            case Granatier::Bonus::SHIELD:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_shield"));
                                break;
                            case Granatier::Bonus::THROW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_throw"));
                                break;
                            case Granatier::Bonus::KICK:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_kick"));
                                break;
                            case Granatier::Bonus::HYPERACTIVE:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_hyperactive"));
                                break;
                            case Granatier::Bonus::SLOW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_slow"));
                                break;
                            case Granatier::Bonus::MIRROR:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_mirror"));
                                break;
                            case Granatier::Bonus::SCATTY:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_scatty"));
                                break;
                            case Granatier::Bonus::RESTRAIN:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_restrain"));
                                break;
                            case Granatier::Bonus::RESURRECT:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_resurrect"));
                                break;
                            default:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        if(granatier::RNG::fromRange(0, 10) > 9 && bonusItem->spriteKey() != QStringLiteral("bonus_neutral_resurrect"))
                        {
                            bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        bonusItem->update(bonus->getX(), bonus->getY());
                        bonusItem->setZValue(100);
                        m_bonusItems[i][j] = bonusItem;

                        connect(this, &GameScene::resizeGraphics, bonusItem, &BonusItem::updateGraphics);
                        connect(bonusItem, &BonusItem::bonusItemDestroyed, this, &GameScene::removeBonusItem);

                        addItem(bonusItem);
                        if(Settings::self()->showAllTiles() == 0)
                        {
                            bonusItem->hide();
                        }
                    }
                    else
                    {
                        m_bonusItems[i][j] = nullptr;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& randomArena: m_tempRandomArenaModeArenaList) {
        if(arenasAvailable.contains(randomArena)) {
            randomArenaModeArenaList.append(randomArena);
        }
    }
```

#### AUTO 


```{c}
auto& score
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& score: m_mapScore)
    {
        for(auto& star: score)
        {
            tempItem = star;
            star = new KGameRenderedItem(renderer, tempItem->spriteKey());
            star->setZValue(tempItem->zValue());
            star->setPos(tempItem->pos());

            if(m_gameScene->items().contains(tempItem))
            {
                m_gameScene->removeItem(tempItem);
                m_gameScene->addItem(star);
            }
            delete tempItem;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& element: bombElements)
                    {
                        dynamic_cast <Bomb*> (element)->setKicked(m_direction);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& element: bombElements)
                {
                    dynamic_cast <Bomb*> (element)->setThrown(player->direction());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playerList)
    {
        QList <KGameRenderedItem*> svgItemList;
        QGraphicsTextItem* playerName = new QGraphicsTextItem(player->getPlayerName());
        playerName->setFont(QFont(QStringLiteral("Helvetica"), Granatier::CellSize * 0.35, QFont::Bold, false));
        playerName->setDefaultTextColor(QColor("#FFFF00"));
        playerName->setZValue(2001);

        for(int j = 0; j < nWinPoints; j++)
        {
            KGameRenderedItem* score = new KGameRenderedItem(renderer, QStringLiteral("score_star_disabled"));
            score->setZValue(2001);
            svgItemList.append(score);
        }
        m_mapScore.insert(player, svgItemList);
        m_mapPlayerNames.insert(player, playerName);
    }
```

#### AUTO 


```{c}
auto* score = new KGameRenderedItem(renderer, QStringLiteral("score_star_disabled"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: std::as_const(playersGroupList))
        {
            strPlayerIDList.append(granatierConfig.group("Player").group(player).readEntry<QString>("PlayerID", QStringLiteral("")));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& star: score)
        {
            tempItem = star;
            star = new KGameRenderedItem(renderer, tempItem->spriteKey());
            star->setZValue(tempItem->zValue());
            star->setPos(tempItem->pos());

            if(m_gameScene->items().contains(tempItem))
            {
                m_gameScene->removeItem(tempItem);
                m_gameScene->addItem(star);
            }
            delete tempItem;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& randomArena: randomArenaModeArenaList) {
                for(const auto& arena: arenasAvailable) {
                    if(arena.endsWith(randomArena)) {
                        m_randomArenaModeArenaList.append(arena);
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& file: arenasAvailable)
    {
      QString arenaPath = lookupDirectory + QLatin1Char('/') + file;
      auto* arenaSettings = new ArenaSettings(groupName);

      if (arenaSettings->load(arenaPath)) {
        QString arenaName; // Start with an empty QString here so that the first += allocates a reserve for future +=.
        arenaName += arenaSettings->arenaProperty(QStringLiteral("Name"));
        //Add underscores to avoid duplicate names.
        while (arenaMap.contains(arenaName))
          arenaName += QLatin1Char('_');
        arenaMap.insert(arenaName, arenaSettings);
        auto * item = new QListWidgetItem(arenaName, ui.arenaList);
        if(ui.kcfg_RandomArenaMode->isChecked())
        {
            if(m_tempRandomArenaModeArenaList.contains(file))
            {
                item->setCheckState(Qt::Checked);
            }
            else
            {
                item->setCheckState(Qt::Unchecked);
            }
            item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        }
        else
        {
            item->setCheckState(Qt::PartiallyChecked);
            item->setFlags(item->flags() & ~Qt::ItemIsUserCheckable);
        }

        //Find if this is our currently configured arena
        if (arenaPath==initialSelection) {
          initialFound = true;
          ui.arenaList->setCurrentItem(item);
          _k_updatePreview(item);
        }
      } else {
        delete arenaSettings;
      }
    }
```

#### AUTO 


```{c}
auto* bombItem = new BombItem(bomb, m_rendererBombItems);
```

#### AUTO 


```{c}
auto* delegate = new PlayerSelectorDelegate(d->m_list);
```

#### AUTO 


```{c}
auto& star
```

#### AUTO 


```{c}
auto* block = dynamic_cast <Block*> (element);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& file: arenasAvailable)
    {
      QString arenaPath = lookupDirectory + QLatin1Char('/') + file;
      ArenaSettings* arenaSettings = new ArenaSettings(groupName);

      if (arenaSettings->load(arenaPath)) {
        QString arenaName; // Start with an empty QString here so that the first += allocates a reserve for future +=.
        arenaName += arenaSettings->arenaProperty(QStringLiteral("Name"));
        //Add underscores to avoid duplicate names.
        while (arenaMap.contains(arenaName))
          arenaName += QLatin1Char('_');
        arenaMap.insert(arenaName, arenaSettings);
        QListWidgetItem * item = new QListWidgetItem(arenaName, ui.arenaList);
        if(ui.kcfg_RandomArenaMode->isChecked())
        {
            if(m_tempRandomArenaModeArenaList.contains(file))
            {
                item->setCheckState(Qt::Checked);
            }
            else
            {
                item->setCheckState(Qt::Unchecked);
            }
            item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        }
        else
        {
            item->setCheckState(Qt::PartiallyChecked);
            item->setFlags(item->flags() & ~Qt::ItemIsUserCheckable);
        }

        //Find if this is our currently configured arena
        if (arenaPath==initialSelection) {
          initialFound = true;
          ui.arenaList->setCurrentItem(item);
          _k_updatePreview(item);
        }
      } else {
        delete arenaSettings;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& dataDir: dataDirs)
        {
            QDir sourceDir(sourceBasePath + dataDir);
            if(!sourceDir.exists()) continue;
            const QStringList fileNames = sourceDir.entryList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot | QDir::NoSymLinks);
            QDir().mkpath(targetBasePath + dataDir);
            for(const auto& fileName: fileNames)
            {
                targetFilePath = targetBasePath + dataDir + QLatin1Char('/') + fileName;
                if(!QFile::exists(targetFilePath))
                {
                    QFile::copy(sourceBasePath + dataDir + QLatin1Char('/') + fileName, targetFilePath);
                }
            }
        }
```

#### AUTO 


```{c}
auto* soundAction = new KToggleAction(i18n("&Play sounds"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
    {
        player->keyReleased(p_event);
    }
```

#### AUTO 


```{c}
auto  playerRenderer = new KGameRenderer(theme);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : players)
    {
        if (m_gameScene->items().contains(m_mapPlayerNames.value(player)))
        {
            // display the player name
            m_gameScene->removeItem(m_mapPlayerNames.value(player));
        }

        for(int j = 0; j < nWinPoints; j++)
        {
            KGameRenderedItem* svgItem = m_mapScore.value(player).at(j);
            // if the score is displayed
            if (m_gameScene->items().contains(svgItem))
            {
                // remove the score
                m_gameScene->removeItem(svgItem);
            }
        }
    }
```

#### AUTO 


```{c}
auto* bombItem = dynamic_cast <BombItem*> (i);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& dir: dirs) {
         const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
         for(const auto& file: fileNames) {
                playersAvailable.append(file);
         }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: blockElements)
                        {
                            dynamic_cast <Block*> (element)->startDestruction();
                            if (m_blockItems[nRow][nColumn] != nullptr)
                            {
                                //display bonus if available
                                if (m_bonusItems[nRow][nColumn] != nullptr)
                                {
                                    m_bonusItems[nRow][nColumn]->setUndestroyable(bomb->explosionID());
                                    m_bonusItems[nRow][nColumn]->show();
                                }
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& fileName: fileNames)
            {
                targetFilePath = targetBasePath + dataDir + QLatin1Char('/') + fileName;
                if(!QFile::exists(targetFilePath))
                {
                    QFile::copy(sourceBasePath + dataDir + QLatin1Char('/') + fileName, targetFilePath);
                }
            }
```

#### AUTO 


```{c}
const auto& randomArena
```

#### RANGE FOR STATEMENT 


```{c}
for(auto arenaSettings: qAsConst(arenaMap))
      {
        if (arenaSettings->path().endsWith(defaultPath))
        {
          const QList<QListWidgetItem *> itemList = ui.arenaList->findItems(arenaSettings->arenaProperty(QStringLiteral("Name")), Qt::MatchExactly);
          // never can be != 1 but better safe than sorry
          if (itemList.count() == 1)
          {
            ui.arenaList->setCurrentItem(itemList.first());
            _k_updatePreview(itemList.first());
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: bombElements)
                    {
                        if(dynamic_cast <Bomb*> (element) != bomb && !(dynamic_cast <Bomb*> (element)->isDetonated()))
                        {
                            dynamic_cast <Bomb*> (element)->initDetonation(bomb->explosionID(), tempBombDetonationCountdown);
                            tempBombDetonationCountdown += 10;
                            increaseDetonationTimeout = true;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
    {
        player->updateMove();
        player->emitGameUpdated();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playersGroupList)
        {
            strPlayerID = granatierConfig.group("Player").group(player).readEntry<QString>("PlayerID", QStringLiteral(""));
            if(m_playerSettings.contains(strPlayerID))
            {
                m_playerSettings.find(strPlayerID).value().strPlayerName = granatierConfig.group("Player").group(player).readEntry<QString>("Name", QStringLiteral(""));
                m_playerSettings.find(strPlayerID).value().enabled = granatierConfig.group("Player").group(player).readEntry<int>("Enabled", 0);
                if(m_playerSettings.find(strPlayerID).value().enabled)
                {
                    nEnableCount++;
                }
                
                m_playerSettings.find(strPlayerID).value().keyUp = QKeySequence(granatierConfig.group("Player").group(player).readEntry<QString>("KeyUp", QStringLiteral("")));
                m_playerSettings.find(strPlayerID).value().keyRight = QKeySequence(granatierConfig.group("Player").group(player).readEntry<QString>("KeyRight", QStringLiteral("")));
                m_playerSettings.find(strPlayerID).value().keyDown = QKeySequence(granatierConfig.group("Player").group(player).readEntry<QString>("KeyDown", QStringLiteral("")));
                m_playerSettings.find(strPlayerID).value().keyLeft = QKeySequence(granatierConfig.group("Player").group(player).readEntry<QString>("KeyLeft", QStringLiteral("")));
                m_playerSettings.find(strPlayerID).value().keyPutBomb = QKeySequence(granatierConfig.group("Player").group(player).readEntry<QString>("KeyPutBomb", QStringLiteral("")));
            }
        }
```

#### AUTO 


```{c}
const auto& dataDir
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & i : collidingList)
        {
            // The arena and the points labels have a negative zValue which allows to exclude them from the treatment of collisions
            if (i->zValue() >= 300 && i->zValue() < 400)
            {
                //((ElementItem*)collidingList[i])->getModel()->doActionOnCollision((Player*)getModel());
                int nExplosionID;
                if(i->zValue() == 315)
                {
                    auto* bombItem = dynamic_cast <BombItem*> (i);
                    nExplosionID = dynamic_cast <Bomb*> (bombItem->getModel())->explosionID();
                }
                else
                {
                    nExplosionID = dynamic_cast <BombExplosionItem*> (i)->explosionID();
                }

                if(dynamic_cast <Player*> (m_model)->shield(nExplosionID) == false)
                {
                    setDead();
                    dynamic_cast <Player*> (m_model)->die();
                }
            }
            else if (i->zValue() == 100)
            {
                bonusItem = dynamic_cast <BonusItem*> (i);
                if(dynamic_cast <Bonus*> (bonusItem->getModel())->isTaken() == false)
                {
                    dynamic_cast <Bonus*> (bonusItem->getModel())->setTaken();
                    bonusItem->getModel()->doActionOnCollision(dynamic_cast <Player*> (this->getModel()));
                    Q_EMIT bonusItemTaken(bonusItem);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto arenaItem: m_arenaItems)
            {
                arenaItem->setRenderSize(calculateSvgSize());
                arenaItem->setScale(m_svgScaleFactor);
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int onIceSpeedIncrease = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
    {
        // check if a player reaches the win points
        if (player->points() >= m_winPoints)
        {
            m_gameOver = true;
            m_strWinner = player->getPlayerName();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playerList)
    {
        QList <KGameRenderedItem*> svgItemList;
        QGraphicsTextItem* playerName = new QGraphicsTextItem(player->getPlayerName());
        playerName->setFont(QFont(QStringLiteral("Helvetica"), static_cast<int>(Granatier::CellSize * 0.35), QFont::Bold, false));
        playerName->setDefaultTextColor(QColor("#FFFF00"));
        playerName->setZValue(2001);

        for(int j = 0; j < nWinPoints; j++)
        {
            KGameRenderedItem* score = new KGameRenderedItem(renderer, QStringLiteral("score_star_disabled"));
            score->setZValue(2001);
            svgItemList.append(score);
        }
        m_mapScore.insert(player, svgItemList);
        m_mapPlayerNames.insert(player, playerName);
    }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playerList)
    {
        QList <KGameRenderedItem*> svgItemList;
        auto* playerName = new QGraphicsTextItem(player->getPlayerName());
        playerName->setFont(QFont(QStringLiteral("Helvetica"), static_cast<int>(Granatier::CellSize * 0.35), QFont::Bold, false));
        playerName->setDefaultTextColor(QColor("#FFFF00"));
        playerName->setZValue(2001);

        for(int j = 0; j < nWinPoints; j++)
        {
            auto* score = new KGameRenderedItem(renderer, QStringLiteral("score_star_disabled"));
            score->setZValue(2001);
            svgItemList.append(score);
        }
        m_mapScore.insert(player, svgItemList);
        m_mapPlayerNames.insert(player, playerName);
    }
```

#### AUTO 


```{c}
auto* view = qobject_cast<QAbstractItemView*>(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : players)
    {
        if (!m_gameScene->items().contains(m_mapPlayerNames.value(player)))
        {
            // display the player name
            m_gameScene->addItem(m_mapPlayerNames.value(player));
        }

        for(int j = 0; j < nWinPoints; j++)
        {
            svgItem = m_mapScore.value(player).at(j);
            if (player->points() > j)
            {
                svgItem->setSpriteKey(QStringLiteral("score_star_enabled"));
            }

            // if the score was not displayed yet
            if (!m_gameScene->items().contains(svgItem))
            {
                // display the score
                m_gameScene->addItem(svgItem);
            }
        }
    }
```

#### AUTO 


```{c}
auto randomArenaModeArenaList = Settings::self()->randomArenaModeArenaList();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& scoreItems: std::as_const(m_mapScore))
    {
        qDeleteAll(scoreItems);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: blockElements)
            {
                dynamic_cast <Block*> (element)->startDestruction();
                if (m_blockItems[nRow][nColumn] != nullptr)
                {
                    //display bonus if available
                    if (m_bonusItems[nRow][nColumn] != nullptr)
                    {
                        m_bonusItems[nRow][nColumn]->setUndestroyable(bomb->explosionID());
                        m_bonusItems[nRow][nColumn]->show();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto arenaItem: qAsConst(m_arenaItems))
            {
                arenaItem->setRenderSize(calculateSvgSize());
                arenaItem->setScale(m_svgScaleFactor);
            }
```

#### AUTO 


```{c}
auto& dir
```

#### AUTO 


```{c}
auto player = m_playerSettings.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& dir: dirs) {
         const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
         for(auto& file: fileNames) {
                arenasAvailable.append(file);
         }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto arenaSettings: arenaMap)
      {
        if (arenaSettings->path().endsWith(defaultPath))
        {
          const QList<QListWidgetItem *> itemList = ui.arenaList->findItems(arenaSettings->arenaProperty(QStringLiteral("Name")), Qt::MatchExactly);
          // never can be != 1 but better safe than sorry
          if (itemList.count() == 1)
          {
            ui.arenaList->setCurrentItem(itemList.first());
            _k_updatePreview(itemList.first());
          }
        }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
    {
        if(!(player->isAlive()))
        {
            player->resurrect();
        }
    }
```

#### AUTO 


```{c}
const auto& player
```

#### AUTO 


```{c}
const auto& file
```

#### AUTO 


```{c}
auto* gridLayoutKeySequence = new QGridLayout();
```

#### AUTO 


```{c}
const auto& fileName
```

#### AUTO 


```{c}
auto* block = new Block((j + 0.5) * Granatier::CellSize, (i + 0.5) * Granatier::CellSize, m_arena, QStringLiteral("arena_block"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: std::as_const(blockElements))
                {
                    Block* block = dynamic_cast <Block*> (element);
                    BlockItem* blockItem = new BlockItem(block, m_rendererArenaItems);
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    blockItem->setSpriteKey(block->getImageId());
                    blockItem->update(block->getX(), block->getY());
                    blockItem->setZValue(200);
                    if(Settings::self()->showAllTiles() == 1)
                    {
                        blockItem->setZValue(99);
                    }
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    connect(blockItem, &BlockItem::blockItemDestroyed, this, &GameScene::removeBlockItem);
                    m_blockItems[i][j] = blockItem;
                    // if the block contains a hidden bonus, create the bonus item
                    Bonus* bonus = block->getBonus();
                    if(bonus)
                    {
                        BonusItem* bonusItem = new BonusItem(bonus, m_rendererBonusItems);
                        switch(bonus->getBonusType())
                        {
                            case Granatier::Bonus::SPEED:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_speed"));
                                break;
                            case Granatier::Bonus::BOMB:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bomb"));
                                break;
                            case Granatier::Bonus::POWER:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_power"));
                                break;
                            case Granatier::Bonus::SHIELD:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_shield"));
                                break;
                            case Granatier::Bonus::THROW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_throw"));
                                break;
                            case Granatier::Bonus::KICK:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_kick"));
                                break;
                            case Granatier::Bonus::HYPERACTIVE:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_hyperactive"));
                                break;
                            case Granatier::Bonus::SLOW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_slow"));
                                break;
                            case Granatier::Bonus::MIRROR:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_mirror"));
                                break;
                            case Granatier::Bonus::SCATTY:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_scatty"));
                                break;
                            case Granatier::Bonus::RESTRAIN:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_restrain"));
                                break;
                            case Granatier::Bonus::RESURRECT:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_resurrect"));
                                break;
                            default:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        if(granatier::RNG::fromRange(0, 10) > 9 && bonusItem->spriteKey() != QStringLiteral("bonus_neutral_resurrect"))
                        {
                            bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        bonusItem->update(bonus->getX(), bonus->getY());
                        bonusItem->setZValue(100);
                        m_bonusItems[i][j] = bonusItem;

                        connect(this, &GameScene::resizeGraphics, bonusItem, &BonusItem::updateGraphics);
                        connect(bonusItem, &BonusItem::bonusItemDestroyed, this, &GameScene::removeBonusItem);

                        addItem(bonusItem);
                        if(Settings::self()->showAllTiles() == 0)
                        {
                            bonusItem->hide();
                        }
                    }
                    else
                    {
                        m_bonusItems[i][j] = nullptr;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: std::as_const(bombElements))
                    {
                        if(dynamic_cast <Bomb*> (element) != bomb && !(dynamic_cast <Bomb*> (element)->isDetonated()))
                        {
                            dynamic_cast <Bomb*> (element)->initDetonation(bomb->explosionID(), tempBombDetonationCountdown);
                            tempBombDetonationCountdown += 10;
                            increaseDetonationTimeout = true;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & playerItem : m_playerItems)
        {
            playerItem->pauseAnim();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& element: bombElements)
                        {
                            dynamic_cast <Bomb*> (element)->setKicked(m_direction);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& theme: themeList)
        {
            if(QString::fromLatin1(theme->identifier()) == m_currentThemeIdentifier)
            {
                m_themeProvider->setCurrentTheme(theme);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: bombElements)
        {
            if(dynamic_cast <Bomb*> (element) != bomb && !(dynamic_cast <Bomb*> (element)->isDetonated()))
            {
                dynamic_cast <Bomb*> (element)->initDetonation(bomb->explosionID(), tempBombDetonationCountdown);
                tempBombDetonationCountdown += 10;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& file: fileNames) {
                    arenasAvailable.append(dir + QLatin1Char('/') + file);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& scoreItems: m_mapScore)
    {
        qDeleteAll(scoreItems);
    }
```

#### AUTO 


```{c}
auto& file
```

#### AUTO 


```{c}
auto* mainLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
    {
        player->keyPressed(p_event);
    }
```

#### AUTO 


```{c}
const auto& theme
```

#### AUTO 


```{c}
auto & player
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: std::as_const(blockElements))
            {
                dynamic_cast <Block*> (element)->startDestruction();
                if (m_blockItems[nRow][nColumn] != nullptr)
                {
                    //display bonus if available
                    if (m_bonusItems[nRow][nColumn] != nullptr)
                    {
                        m_bonusItems[nRow][nColumn]->setUndestroyable(bomb->explosionID());
                        m_bonusItems[nRow][nColumn]->show();
                    }
                }
            }
```

#### AUTO 


```{c}
const auto& arena
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& dataDir: dataDirs)
        {
            QDir sourceDir(sourceBasePath + dataDir);
            if(!sourceDir.exists()) continue;
            QStringList fileNames = sourceDir.entryList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot | QDir::NoSymLinks);
            QDir().mkpath(targetBasePath + dataDir);
            for(const auto& fileName: fileNames)
            {
                targetFilePath = targetBasePath + dataDir + QLatin1Char('/') + fileName;
                if(!QFile::exists(targetFilePath))
                {
                    QFile::copy(sourceBasePath + dataDir + QLatin1Char('/') + fileName, targetFilePath);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
                    {
                        player->resurrect();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: qAsConst(bombElements))
                    {
                        if(dynamic_cast <Bomb*> (element) != bomb && !(dynamic_cast <Bomb*> (element)->isDetonated()))
                        {
                            dynamic_cast <Bomb*> (element)->initDetonation(bomb->explosionID(), tempBombDetonationCountdown);
                            tempBombDetonationCountdown += 10;
                            increaseDetonationTimeout = true;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & player : m_players)
        {
            if(player->isAlive())
            {
                nPlayerAlive++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& file: fileNames) {
                arenasAvailable.append(file);
         }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto arenaSettings: std::as_const(arenaMap))
      {
        if (arenaSettings->path().endsWith(defaultPath))
        {
          const QList<QListWidgetItem *> itemList = ui.arenaList->findItems(arenaSettings->arenaProperty(QStringLiteral("Name")), Qt::MatchExactly);
          // never can be != 1 but better safe than sorry
          if (itemList.count() == 1)
          {
            ui.arenaList->setCurrentItem(itemList.first());
            _k_updatePreview(itemList.first());
          }
        }
      }
```

#### AUTO 


```{c}
auto* theme = new KgTheme(desktopPath.toUtf8());
```

#### AUTO 


```{c}
auto arenaSettings
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& bomb: m_tempBombList)
    {
        createBombItem(bomb);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & i : collidingList)
        {
            // The arena and the points labels have a negative zValue which allows to exclude them from the treatment of collisions
            if (i->zValue() >= 300 && i->zValue() < 400)
            {
                //((ElementItem*)collidingList[i])->getModel()->doActionOnCollision((Player*)getModel());
                int nExplosionID;
                if(i->zValue() == 315)
                {
                    BombItem* bombItem = dynamic_cast <BombItem*> (i);
                    nExplosionID = dynamic_cast <Bomb*> (bombItem->getModel())->explosionID();
                }
                else
                {
                    nExplosionID = dynamic_cast <BombExplosionItem*> (i)->explosionID();
                }

                if(dynamic_cast <Player*> (m_model)->shield(nExplosionID) == false)
                {
                    setDead();
                    dynamic_cast <Player*> (m_model)->die();
                }
            }
            else if (i->zValue() == 100)
            {
                bonusItem = dynamic_cast <BonusItem*> (i);
                if(dynamic_cast <Bonus*> (bonusItem->getModel())->isTaken() == false)
                {
                    dynamic_cast <Bonus*> (bonusItem->getModel())->setTaken();
                    bonusItem->getModel()->doActionOnCollision(dynamic_cast <Player*> (this->getModel()));
                    emit bonusItemTaken(bonusItem);
                }
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int badBonusCountdown = 10000;
```

#### AUTO 


```{c}
auto author = desktopFile.group("KGameTheme").readEntry<QString>("Author", QStringLiteral(""));
```

#### CONST EXPRESSION 


```{c}
constexpr int FPS = 60;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: std::as_const(bombElements))
        {
            if(dynamic_cast <Bomb*> (element) != bomb && !(dynamic_cast <Bomb*> (element)->isDetonated()))
            {
                dynamic_cast <Bomb*> (element)->initDetonation(bomb->explosionID(), tempBombDetonationCountdown);
                tempBombDetonationCountdown += 10;
            }
        }
```

#### AUTO 


```{c}
auto * item = new QListWidgetItem(arenaName, ui.arenaList);
```

#### AUTO 


```{c}
auto* arenaItem = new ArenaItem(j * Granatier::CellSize, i * Granatier::CellSize, m_rendererArenaItems, QStringLiteral(""));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: qAsConst(playersGroupList))
        {
            strPlayerIDList.append(granatierConfig.group("Player").group(player).readEntry<QString>("PlayerID", QStringLiteral("")));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& scoreItems: qAsConst(m_mapScore))
    {
        qDeleteAll(scoreItems);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& file: fileNames) {
                playersAvailable.append(file);
         }
```

#### AUTO 


```{c}
auto* verticalLayoutKeySequence = new QVBoxLayout();
```

#### CONST EXPRESSION 


```{c}
constexpr int NumberOfBadBonuses = 5;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: qAsConst(bombElements))
        {
            if(dynamic_cast <Bomb*> (element) != bomb && !(dynamic_cast <Bomb*> (element)->isDetonated()))
            {
                dynamic_cast <Bomb*> (element)->initDetonation(bomb->explosionID(), tempBombDetonationCountdown);
                tempBombDetonationCountdown += 10;
            }
        }
```

#### AUTO 


```{c}
auto& element
```

#### AUTO 


```{c}
auto & playerItem
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: m_elements)
    {
        if(element->getType() == type)
        {
            elementsFound.append(element);
        }
    }
```

#### AUTO 


```{c}
auto* blockItem = new BlockItem(block, m_rendererArenaItems);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & player : m_players)
    {
        connect(player, SIGNAL(bombDropped(Player*,qreal,qreal,bool,int)), this, SLOT(createBomb(Player*,qreal,qreal,bool,int)));
    }
```

#### AUTO 


```{c}
auto & i
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & playerItem : m_playerItems)
    {
        if(!items().contains(playerItem))
        {
            addItem(playerItem);
        }
        playerItem->resurrect();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & playerItem : m_playerItems)
    {
        if(items().contains(playerItem))
        {
            removeItem(playerItem);
        }
        playerItem->stopAnim();
        delete playerItem;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & player : m_players)
    {
        connect(player, &Player::bombDropped, this, &Game::createBomb);
    }
```

#### AUTO 


```{c}
auto* arenaSettings = new ArenaSettings(groupName);
```

#### AUTO 


```{c}
auto* gridLayoutPlayer = new QGridLayout();
```

#### AUTO 


```{c}
const auto& dir
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: std::as_const(blockElements))
                        {
                            dynamic_cast <Block*> (element)->startDestruction();
                            if (m_blockItems[nRow][nColumn] != nullptr)
                            {
                                //display bonus if available
                                if (m_bonusItems[nRow][nColumn] != nullptr)
                                {
                                    m_bonusItems[nRow][nColumn]->setUndestroyable(bomb->explosionID());
                                    m_bonusItems[nRow][nColumn]->show();
                                }
                            }
                        }
```

#### AUTO 


```{c}
auto* bonusItem = new BonusItem(bonus, m_rendererBonusItems);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& player: m_playerSettings)
        {
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("PlayerID", player.strPlayerID);
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("Name", player.strPlayerName);
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("Enabled", ( player.enabled ? 1 : 0));
            
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("KeyUp", player.keyUp.toString());
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("KeyRight", player.keyRight.toString());
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("KeyDown", player.keyDown.toString());
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("KeyLeft", player.keyLeft.toString());
            granatierConfig.group("Player").group(QStringLiteral("%1").arg(nPlayersGroupIndex)).writeEntry("KeyPutBomb", player.keyPutBomb.toString());
            
            nPlayersGroupIndex++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: qAsConst(blockElements))
            {
                dynamic_cast <Block*> (element)->startDestruction();
                if (m_blockItems[nRow][nColumn] != nullptr)
                {
                    //display bonus if available
                    if (m_bonusItems[nRow][nColumn] != nullptr)
                    {
                        m_bonusItems[nRow][nColumn]->setUndestroyable(bomb->explosionID());
                        m_bonusItems[nRow][nColumn]->show();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& element: blockElements)
                {
                    Block* block = dynamic_cast <Block*> (element);
                    BlockItem* blockItem = new BlockItem(block, m_rendererArenaItems);
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    blockItem->setSpriteKey(block->getImageId());
                    blockItem->update(block->getX(), block->getY());
                    blockItem->setZValue(200);
                    if(Settings::self()->showAllTiles() == 1)
                    {
                        blockItem->setZValue(99);
                    }
                    connect(this, &GameScene::resizeGraphics, blockItem, &BlockItem::updateGraphics);
                    connect(blockItem, &BlockItem::blockItemDestroyed, this, &GameScene::removeBlockItem);
                    m_blockItems[i][j] = blockItem;
                    // if the block contains a hidden bonus, create the bonus item
                    Bonus* bonus = block->getBonus();
                    if(bonus)
                    {
                        BonusItem* bonusItem = new BonusItem(bonus, m_rendererBonusItems);
                        switch(bonus->getBonusType())
                        {
                            case Granatier::Bonus::SPEED:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_speed"));
                                break;
                            case Granatier::Bonus::BOMB:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bomb"));
                                break;
                            case Granatier::Bonus::POWER:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_power"));
                                break;
                            case Granatier::Bonus::SHIELD:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_shield"));
                                break;
                            case Granatier::Bonus::THROW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_throw"));
                                break;
                            case Granatier::Bonus::KICK:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_kick"));
                                break;
                            case Granatier::Bonus::HYPERACTIVE:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_hyperactive"));
                                break;
                            case Granatier::Bonus::SLOW:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_slow"));
                                break;
                            case Granatier::Bonus::MIRROR:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_mirror"));
                                break;
                            case Granatier::Bonus::SCATTY:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_scatty"));
                                break;
                            case Granatier::Bonus::RESTRAIN:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_bad_restrain"));
                                break;
                            case Granatier::Bonus::RESURRECT:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_resurrect"));
                                break;
                            default:
                                bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        if(granatier::RNG::fromRange(0, 10) > 9 && bonusItem->spriteKey() != QStringLiteral("bonus_neutral_resurrect"))
                        {
                            bonusItem->setSpriteKey(QStringLiteral("bonus_neutral_pandora"));
                        }

                        bonusItem->update(bonus->getX(), bonus->getY());
                        bonusItem->setZValue(100);
                        m_bonusItems[i][j] = bonusItem;

                        connect(this, &GameScene::resizeGraphics, bonusItem, &BonusItem::updateGraphics);
                        connect(bonusItem, &BonusItem::bonusItemDestroyed, this, &GameScene::removeBonusItem);

                        addItem(bonusItem);
                        if(Settings::self()->showAllTiles() == 0)
                        {
                            bonusItem->hide();
                        }
                    }
                    else
                    {
                        m_bonusItems[i][j] = nullptr;
                    }
                }
```

#### CONST EXPRESSION 


```{c}
constexpr int NumberOfBonuses = 6;
```

#### AUTO 


```{c}
auto arenaItem
```

#### AUTO 


```{c}
auto& bomb
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& player: playersAvailable)
    {
        StructPlayerSettings settings;
        settings.strPlayerID = player;

        KConfig desktopFile(QStandardPaths::locate(QStandardPaths::AppDataLocation, QStringLiteral("players/") + settings.strPlayerID), KConfig::SimpleConfig);

        settings.strPlayerDesktopFilePath = desktopFile.name();
        settings.strPlayerName = desktopFile.group("KGameTheme").readEntry<QString>("Name", QLatin1String(""));
        settings.strPlayerGraphicsFile = desktopFile.group("KGameTheme").readEntry<QString>("FileName", QLatin1String(""));
        settings.enabled = false;
        
        m_playerSettings.insert(settings.strPlayerID, settings);
    }
```

#### AUTO 


```{c}
auto* theme = new KgTheme(QByteArray());
```

#### AUTO 


```{c}
auto* window = new MainWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & playerItem : m_playerItems)
        {
            playerItem->resumeAnim();
        }
```

#### AUTO 


```{c}
auto* playerName = new QGraphicsTextItem(player->getPlayerName());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& arena: arenasAvailable) {
                    if(arena.endsWith(randomArena)) {
                        m_randomArenaModeArenaList.append(arena);
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & i : collidingList)
        {
            // The arena and the points labels have a negative zValue which allows to exclude them from the treatment of collisions
            if (i->zValue() >= 300 && i->zValue() < 400)
            {
                //((ElementItem*)collidingList[i])->getModel()->doActionOnCollision((Player*)getModel());
                int nExplosionID;
                if(i->zValue() == 315)
                {
                    BombItem* bombItem = dynamic_cast <BombItem*> (i);
                    nExplosionID = dynamic_cast <Bomb*> (bombItem->getModel())->explosionID();
                }
                else
                {
                    nExplosionID = dynamic_cast <BombExplosionItem*> (i)->explosionID();
                }

                if(dynamic_cast <Player*> (m_model)->shield(nExplosionID) == false)
                {
                    setDead();
                    dynamic_cast <Player*> (m_model)->die();
                }
            }
            else if (i->zValue() == 100)
            {
                bonusItem = dynamic_cast <BonusItem*> (i);
                if(dynamic_cast <Bonus*> (bonusItem->getModel())->isTaken() == false)
                {
                    dynamic_cast <Bonus*> (bonusItem->getModel())->setTaken();
                    bonusItem->getModel()->doActionOnCollision(dynamic_cast <Player*> (this->getModel()));
                    Q_EMIT bonusItemTaken(bonusItem);
                }
            }
        }
```

#### AUTO 


```{c}
const auto& element
```

