#### LAMBDA EXPRESSION 


```{c}
[this]() { setValid(m_srcConnPageItem, true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : currentFilters) {
                const QString f(filter.trimmed());
                hasExtension = !f.midRef(2).isEmpty() && ext == f.midRef(2);
                if (hasExtension) {
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QMimeType &mimeType : d->mimeTypes()) {
        result += KexiFileFilters::toString(mimeType, format);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QMimeType &mimeType : d->mimeTypes()) {
        result += mimeType.globPatterns();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : correctedStandardLocations) {
        triedLocations->append(QDir::cleanPath(dir + '/' + subdirPath));
        const QString dataFile = QFileInfo(dir + QLatin1Char('/') + path).canonicalFilePath();
        if (fileReadable(dataFile)) {
            return dataFile;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &triedLocation : triedLocations) {
            KLocalizedString string;
            if (triedLocationsString.isEmpty()) {
                triedLocationsString = QDir::toNativeSeparators(triedLocation);
            } else {
#ifdef QT_ONLY
                triedLocationsString += QString::fromLatin1(", %1").arg(
                    QDir::toNativeSeparators(triedLocation));
#else
                triedLocationsString = xi18n("%1, %2", triedLocationsString,
                                             QDir::toNativeSeparators(triedLocation));
#endif
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : filters) {
                QStringList filterPatterns = filter.split('|').first().split(' ');
                for (const QString &filterPattern : filterPatterns) {
                    const QString f( filterPattern.trimmed() );
                    if (!f.mid(2).isEmpty() && ext == f.mid(2)) {
                        hasExtension = true;
                        break;
                    }
                }
                if (hasExtension) {
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDbTableSchemaChangeListener* listener : listeners) {
            openedObjectsStr += QString("<item>%1</item>").arg(listener->name());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : d->mimeTypes()) {
        result += mimeType.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QCommandLineOption &extraOption : d->extraOptions) {
        for(const QString &name : extraOption.names()) {
            args->removeOne("--" + name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAbstractScrollArea *area : page->findChildren<QAbstractScrollArea*>()) {
                area->setEnabled(set);
                area->repaint();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KexiProjectData::ObjectInfo &info : d->prj->data()->autoopenObjects) {
            KexiPart::Info *i = Kexi::partManager().infoForPluginId(info.value("type"));
            if (!i) {
                not_found_msg += "<li>";
                if (!info.value("name").isEmpty()) {
                    not_found_msg += (QString("\"") + info.value("name") + "\" - ");
                }
                if (info.value("action") == "new") {
                    not_found_msg += xi18n("cannot create object - unknown object type \"%1\"",
                                           info.value("type"));
                } else {
                    not_found_msg += xi18n("unknown object type \"%1\"", info.value("type"));
                }
                not_found_msg += internalReason(Kexi::partManager().result()) + "<br></li>";
                continue;
            }
            // * NEW
            if (info.value("action") == "new") {
                if (!newObject(i, &openingCancelled) && !openingCancelled) {
                    not_found_msg += "<li>";
                    not_found_msg
                        += (xi18n("cannot create object of type \"%1\"", info.value("type"))
                            + internalReason(d->prj->result()) + "<br></li>");
                } else {
                    d->wasAutoOpen = true;
                }
                continue;
            }

            KexiPart::Item *item = d->prj->item(i, info.value("name"));
            if (!item) {
                QString taskName;
                if (info.value("action") == "execute") {
                    taskName = xi18nc("\"executing object\" action", "executing");
#ifdef KEXI_QUICK_PRINTING_SUPPORT
                } else if (info->value("action") == "print-preview") {
                    taskName = futureI18n("making print preview for");
                } else if (info->value("action") == "print") {
                    taskName = futureI18n("printing");
#endif
                } else {
                    taskName = xi18n("opening");
                }

                not_found_msg += (QString("<li>") + taskName + " \"" + info.value("name") + "\" - ");
                if ("table" == info.value("type").toLower()) {
                    not_found_msg += xi18n("table not found");
                } else if ("query" == info.value("type").toLower()) {
                    not_found_msg += xi18n("query not found");
                } else if ("macro" == info.value("type").toLower()) {
                    not_found_msg += xi18n("macro not found");
                } else if ("script" == info.value("type").toLower()) {
                    not_found_msg += xi18n("script not found");
                } else {
                    not_found_msg += xi18n("object not found");
                }
                not_found_msg += (internalReason(d->prj->result()) + "<br></li>");
                continue;
            }
            // * EXECUTE, PRINT, PRINT PREVIEW
            if (info.value("action") == "execute") {
                tristate res = executeItem(item);
                if (false == res) {
                    not_found_msg += (QString("<li>\"") + info.value("name") + "\" - "
                                      + xi18n("cannot execute object")
                                      + internalReason(d->prj->result()) + "<br></li>");
                }
                continue;
            }
#ifdef KEXI_QUICK_PRINTING_SUPPORT
            else if (info.value("action") == "print") {
                tristate res = printItem(item);
                if (false == res) {
                    not_found_msg += (QString("<li>\"") + info.value("name") + "\" - " + futureI18n("cannot print object") +
                                      internalReason(d->prj->result()) + "<br></li>");
                }
                continue;
            }
            else if (info.value("action") == "print-preview") {
                tristate res = printPreviewForItem(item);
                if (false == res) {
                    not_found_msg += (QString("<li>\"") + info.value("name") + "\" - " + futureI18n("cannot make print preview of object") +
                                      internalReason(d->prj->result()) + "<br></li>");
                }
                continue;
            }
#endif

            Kexi::ViewMode viewMode;
            if (info.value("action") == "open") {
                viewMode = Kexi::DataViewMode;
            } else if (info.value("action") == "design") {
                viewMode = Kexi::DesignViewMode;
            } else if (info.value("action") == "edittext") {
                viewMode = Kexi::TextViewMode;
            } else {
                continue; //sanity
            }

            QString openObjectMessage;
            if (!openObject(item, viewMode, &openingCancelled, 0, &openObjectMessage)
                    && (!openingCancelled || !openObjectMessage.isEmpty()))
            {
                not_found_msg += (QString("<li>\"") + info.value("name") + "\" - ");
                if (openObjectMessage.isEmpty()) {
                    not_found_msg += xi18n("cannot open object");
                } else {
                    not_found_msg += openObjectMessage;
                }
                not_found_msg += internalReason(d->prj->result()) + "<br></li>";
                continue;
            } else {
                d->wasAutoOpen = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QCommandLineOption &option : q->options().autoopeningObjectsOptions()) {
            if (findAutoopenObjects(option, objects)) {
                atLeastOneFound = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(int size : expectedSizes) {
        QFile file(iconPath.arg(size).arg(iconName));
        if (!file.open(QIODevice::ReadOnly)) {
            return 1;
        }
        if (file.size() < 100 || file.size() > 50000) {
            return 1;
        }
        QDomDocument doc;
        if (!doc.setContent(&file)) {
            return 1;
        }
        file.seek(0);
        qDebug() << file.readAll();
        file.close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KexiMigratePluginMetaData* metaData : m_metadataBySourceDrivers.values(sourceDriverId.toLower())) {
        result.append(metaData->id());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { QDesktopServices::openUrl(QUrl(facebookUrl)); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : QStandardPaths::standardLocations(location)) {
            if (dir.indexOf(re) != -1) {
                QString realDir(dir);
                realDir.replace(re, "/kexi");
                fullPath = realDir + "/" + path;
                if (!fullPath.isEmpty() && QFileInfo(fullPath).isReadable()) {
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : patterns) {
            d->filterRegExps.append(new QRegExp(pattern, Qt::CaseInsensitive, QRegExp::Wildcard));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &pathDir : qgetenv("PATH").split(KPATH_SEPARATOR)) {
        const QString dataDirFromPath = QFileInfo(QFile::decodeName(pathDir) + QStringLiteral("/data/")
                                                  + path).canonicalFilePath();
        if (fileReadable(dataDirFromPath)) {
            return dataDirFromPath;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : standardLocations) {
            if (dir.indexOf(re) != -1) {
                QString realDir(dir);
                realDir.replace(re, QLatin1Char('/') + privateName);
                result.append(realDir);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QMimeType &mimeType : d->mimeTypes()) {
        result += globPatterns(mimeType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : q->values(option)) {
            QString typeName;
            QString objectName;
            int idx;
            bool nameRequired = true;
            if (option.names() == q->options().newObject.names()) {
                objectName.clear();
                stripQuotes(value, &typeName);
                nameRequired = false;
            } else {//open, design, text...
                QString defaultType;
                if (option.names() == q->options().execute.names()) {
#ifdef KEXI_MACROS_SUPPORT
                    defaultType = "macro";
#else
                    defaultType = "script";
#endif
                } else {
                    defaultType = "table";
                }

                //option with " " (set default type)
                if (stripQuotes(value, &objectName)) {
                    typeName = defaultType;
                } else if ((idx = value.indexOf(':')) != -1) {
                    //option with type name specified:
                    typeName = value.left(idx).toLower();
                    objectName = value.mid(idx + 1);
                    (void)stripQuotes(objectName, &objectName); // remove optional quotes
                } else {
                    //just obj. name: set default type name
                    objectName = value;
                    typeName = defaultType;
                }
            }
            if (typeName.isEmpty()) {
                continue;
            }
            if (nameRequired && objectName.isEmpty()) {
                continue;
            }
            atLeastOneFound = true;
            if (objects) {
                KexiProjectData::ObjectInfo* info = new KexiProjectData::ObjectInfo;
                info->insert("name", objectName);
                info->insert("type", typeName);
                info->insert("action", option.names().first());
                //ok, now add info for this object
                objects->append(info);
            } else {
                return true; //no need to find more because we do not have project anyway
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPluginLoader *loader : offers) {
        QScopedPointer<KexiMigratePluginMetaData> metaData(new KexiMigratePluginMetaData(*loader));
        if (m_driversMetaData.contains(metaData->id())) {
            qWarning() << "Migration driver with ID" << metaData->id() << "already found at"
                         << m_driversMetaData.value(metaData->id())->fileName()
                         << "-- skipping another at" << metaData->fileName();
            continue;
        }
//! @todo Similar version check could be merged with KDbDriverManager
        if (KexiMigration::version().major() != metaData->majorVersion()) {
            qWarning() << QString("Migration driver '%1' (%2) has version '%3' but "
                                  "KexiMigration library requires version '%4'\n"
                                  " -- skipping this driver!")
                          .arg(metaData->id()).arg(metaData->fileName())
                          .arg(metaData->majorVersion())
                          .arg(KexiMigration::version().major());
            m_possibleProblems += QString("Migration driver \"%1\" (%2) has version \"%3\" "
                                        "but required version is \"%4\"")
                          .arg(metaData->id()).arg(metaData->fileName())
                          .arg(metaData->majorVersion())
                          .arg(KexiMigration::version().major());
            continue;
        }
        foreach (const QString& mimeType, metaData->mimeTypes()) {
            m_metadata_by_mimetype.insertMulti(mimeType, metaData.data());
        }
        foreach (const QString& sourceDriverId, metaData->supportedSourceDrivers()) {
            m_metadataBySourceDrivers.insertMulti(sourceDriverId, metaData.data());
        }
        m_driversMetaData.insert(metaData->id(), metaData.data());
        KexiMigrateManagerDebug << "registered driver" << metaData->id() << '(' << metaData->fileName() << ")";
        metaData.take();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filterPattern : filterPatterns) {
                    const QString f( filterPattern.trimmed() );
                    if (!f.midRef(2).isEmpty() && ext == f.midRef(2)) {
                        hasExtension = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAbstractScrollArea *area : m_contentWidget->findChildren<QAbstractScrollArea*>()) {
            QPalette pal(area->viewport()->palette());
            pal.setBrush(QPalette::Disabled, QPalette::Base, contentWidgetPalette.brush(QPalette::Disabled, QPalette::Base));
            area->viewport()->setPalette(pal);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KexiWindow *window : windowList) {
        const tristate result = closeWindow(window);
        if (~result) {
            return result;
        }
        if (result == false) {
            alternateResult = false;
        }
    }
```

#### AUTO 


```{c}
auto orderByColumnIt(orderByColumns->constBegin());
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : correctedStandardLocations) {
        fullPath = QFileInfo(dir + QLatin1Char('/') + path).canonicalFilePath();
        if (fileReadable(fullPath)) {
            return fullPath;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filter : filters) {
                QStringList filterPatterns = filter.split('|').first().split(' ');
                for (const QString &filterPattern : filterPatterns) {
                    const QString f( filterPattern.trimmed() );
                    if (!f.midRef(2).isEmpty() && ext == f.midRef(2)) {
                        hasExtension = true;
                        break;
                    }
                }
                if (hasExtension) {
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : widgetsToResize) {
            w->setFixedHeight(h + 2);
            w->parentWidget()->setFixedHeight(h);
            w->move(0, (w->parentWidget()->height() - w->height()) / 2);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : info.fieldNames) {
        KDbField *f = new KDbField(name, KDbField::Text);
        if (!tableSchema->addField(f)) {
            delete f;
            tableSchema->clear();
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &mimeName : mimeNames) {
        result += KexiFileFilters::toString(mimeName, format);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDbTableSchemaChangeListener* listener : listeners) {
        openedObjectsStr += QString("<item>%1</item>").arg(listener->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &name : extraOption.names()) {
            args->removeOne("--" + name);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &message : s_self->possibleProblemsMessage()) {
        str += (QString::fromLatin1("<li>") + message + QString::fromLatin1("</li>"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<QVariant> &fieldRecordData : fieldRecords) {
        if (!destConn->insertRecord(kexi__fieldsTable, fieldRecordData)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filterPattern : filterPatterns) {
                    const QString f( filterPattern.trimmed() );
                    if (!f.mid(2).isEmpty() && ext == f.mid(2)) {
                        hasExtension = true;
                        break;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        setValid(m_srcConnPageItem, true);
        next();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KexiMigratePluginMetaData* metaData : metaDatas) {
        result.append(metaData->id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : tableNames) {
                    tableNamesSet.insert(name.toLower());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRegExp *regexp : *m_filterRegExps) {
            if (regexp->exactMatch(fileName)) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPluginLoader *loader : offers) {
        QScopedPointer<KexiMigratePluginMetaData> metaData(new KexiMigratePluginMetaData(*loader));
        if (m_driversMetaData.contains(metaData->id())) {
            qWarning() << "Migration driver with ID" << metaData->id() << "already found at"
                         << m_driversMetaData.value(metaData->id())->fileName()
                         << "-- skipping another at" << metaData->fileName();
            continue;
        }
//! @todo Similar version check could be merged with KDbDriverManager
        if (metaData->version() != expectedVersion) {
            qWarning() << QString("Migration driver '%1' (%2) has version '%3' but "
                                  "KexiMigration library requires version '%4'\n"
                                  " -- skipping this driver!")
                          .arg(metaData->id()).arg(metaData->fileName())
                          .arg(metaData->version())
                          .arg(expectedVersion);
            m_possibleProblems += QString("Migration driver \"%1\" (%2) has version \"%3\" "
                                        "but required version is \"%4\"")
                          .arg(metaData->id()).arg(metaData->fileName())
                          .arg(metaData->version())
                          .arg(expectedVersion);
            continue;
        }
        foreach (const QString& mimeType, metaData->mimeTypes()) {
            m_metadata_by_mimetype.insertMulti(mimeType, metaData.data());
        }
        foreach (const QString& sourceDriverId, metaData->supportedSourceDrivers()) {
            m_metadataBySourceDrivers.insertMulti(sourceDriverId, metaData.data());
        }
        m_driversMetaData.insert(metaData->id(), metaData.data());
        KexiMigrateManagerDebug << "registered driver" << metaData->id() << '(' << metaData->fileName() << ")";
        metaData.take();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KDbTableSchemaChangeListener* listener : listeners) {
            openedObjectsStr += QString("<li>%1</li>").arg(listener->name());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { QDesktopServices::openUrl(QUrl(twitterUrl)); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : standardLocations) {
        if (dir.indexOf(re) != -1) {
            QString realDir(dir);
            realDir.replace(re, QLatin1String("/kexi"));
            fullPath = realDir + '/' + path;
            if (fileReadable(fullPath)) {
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPluginLoader *loader : offers) {
        QScopedPointer<KexiMigratePluginMetaData> metaData(new KexiMigratePluginMetaData(*loader));
        if (m_driversMetaData.contains(metaData->id())) {
            qWarning() << "Migration driver with ID" << metaData->id() << "already found at"
                         << m_driversMetaData.value(metaData->id())->fileName()
                         << "-- skipping another at" << metaData->fileName();
            continue;
        }
//! @todo Similar version check could be merged with KDbDriverManager
        if (KexiMigration::version().major() != metaData->majorVersion()) {
            qWarning() << QString("Migration driver '%1' (%2) has version '%3' but "
                                  "KexiMigration library requires version '%4'\n"
                                  " -- skipping this driver!")
                          .arg(metaData->id()).arg(metaData->fileName())
                          .arg(metaData->majorVersion())
                          .arg(KexiMigration::version().major());
            m_possibleProblems += QString("Migration driver \"%1\" (%2) has version \"%3\" "
                                        "but required version is \"%4\"")
                          .arg(metaData->id()).arg(metaData->fileName())
                          .arg(metaData->majorVersion())
                          .arg(KexiMigration::version().major());
            continue;
        }
        foreach (const QString& mimeType, metaData->mimeTypes()) {
            m_metadata_by_mimetype.insertMulti(mimeType, metaData.data());
        }
        m_driversMetaData.insert(metaData->id(), metaData.data());
        KexiMigrateManagerDebug << "registered driver" << metaData->id() << '(' << metaData->fileName() << ")";
        metaData.take();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAbstractScrollArea *area : contentsWidget->findChildren<QAbstractScrollArea*>()) {
                area->setEnabled(set);
                area->repaint();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& mimeType : mimeTypes) {
        d->excludedMimeTypes.insert(mimeType.toLower());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &pathDir : qgetenv("PATH").split(KPATH_SEPARATOR)) {
        const QString dataDir = QFile::decodeName(pathDir) + QStringLiteral("/data/");
        triedLocations->append(QDir::cleanPath(dataDir + '/' + subdirPath));
        const QString dataDirFromPath = QFileInfo(dataDir + '/' + path).canonicalFilePath();
        if (fileReadable(dataDirFromPath)) {
            return dataDirFromPath;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QCommandLineOption& option : extraOptions) {
        ADD_OPTION_BASE(option)
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { next(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAbstractScrollArea *area : m_contentWidget->findChildren<QAbstractScrollArea*>()) {
            QPalette pal(area->viewport()->palette());
            pal.setBrush(QPalette::Disabled, QPalette::Base, contentWidgetPalette.brush(QPalette::Disabled, QPalette::Base));
            pal.setBrush(QPalette::Highlight, Qt::red);
            area->viewport()->setPalette(pal);
        }
```

