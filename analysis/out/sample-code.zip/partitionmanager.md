#### RANGE FOR STATEMENT 


```{c}
for (const auto &mp : mountPoints())
        delete mp.second;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : LVM::pvList) // FIXME: qAsConst
        if (p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
```

#### AUTO 


```{c}
const auto children = selectedDevice()->partitionTable()->children();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map()) {
        if (fs->supportCreate() != FileSystem::cmdSupportNone &&
            fs->type() != FileSystem::Extended &&
            fs->type() != FileSystem::Luks)
            fsNames.append(fs->name());
    }
```

#### AUTO 


```{c}
const auto operations = operationStack().operations();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pw : children) {
        if (pw->partition() == p) {
            setActiveWidget(pw);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map()) {
        if (fs->type() == FileSystem::Unknown || fs->type() == FileSystem::Extended ||
            fs->type() == FileSystem::Luks || fs->type() == FileSystem::Luks2) {
            continue;
        }

        QTreeWidgetItem* item = new QTreeWidgetItem();

        int i = 0;
        item->setText(i++, fs->name());
        item->setIcon(i++, fs->supportCreate() ? yes : no);
        item->setIcon(i++, fs->supportGrow() ? yes : no);
        item->setIcon(i++, fs->supportShrink() ? yes : no);
        item->setIcon(i++, fs->supportMove() ? yes : no);
        item->setIcon(i++, fs->supportCopy() ? yes : no);
        item->setIcon(i++, fs->supportCheck() ? yes : no);
        item->setIcon(i++, fs->supportGetLabel() ? yes : no);
        item->setIcon(i++, fs->supportSetLabel() ? yes : no);
        item->setIcon(i++, fs->supportGetUsed() ? yes : no);
        item->setIcon(i++, fs->supportBackup() ? yes : no);

        // there is no FileSystem::supportRestore(), because we currently can't tell
        // if a file is an image of a supported or unsupported (or even invalid) filesystem
        item->setIcon(i++, yes);

        item->setText(i++, fs->supportToolName().name.isEmpty() ? QStringLiteral("---") : fs->supportToolName().name);

        dialogWidget().tree().addTopLevelItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const FileSystem * fs : FileSystemFactory::map())
    {
        // If the partition isn't encrypted, skip the luks FS
        if (fs->type() == FileSystem::Luks && partition().fileSystem().type() != FileSystem::Luks)
            continue;
        if (partition().fileSystem().type() == fs->type() || (fs->supportCreate() != FileSystem::cmdSupportNone &&
                            partition().capacity() >= fs->minCapacity() && partition().capacity() <= fs->maxCapacity())) {
            QString name = fs->name();

            if (partition().fileSystem().type() == fs->type())
                selected = name;

            // If the partition isn't extended, skip the extended FS
            if (fs->type() == FileSystem::Extended && !partition().roles().has(PartitionRole::Extended))
                continue;

            // The user cannot change the filesystem back to "unformatted" once a filesystem has been created.
            if (fs->type() == FileSystem::Unformatted) {
                // .. but if the file system is unknown to us, show the unformatted option as the currently selected one
                if (partition().fileSystem().type() == FileSystem::Unknown) {
                    name = FileSystem::nameForType(FileSystem::Unformatted);
                    selected = name;
                } else if (partition().fileSystem().type() != FileSystem::Unformatted && partition().state() != Partition::StateNew)
                    continue;
            }

            fsNames.append(name);
        }
    }
```

#### AUTO 


```{c}
const auto &pvpath
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &part : partlist) {
        addPartition(part, checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &box : children)
        box->setKeyboardTracking(!align);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map()) {
        if (fs->type() == FileSystem::Unknown || fs->type() == FileSystem::Extended || fs->type() == FileSystem::Luks)
            continue;

        QTreeWidgetItem* item = new QTreeWidgetItem();

        int i = 0;
        item->setText(i++, fs->name());
        item->setIcon(i++, fs->supportCreate() ? yes : no);
        item->setIcon(i++, fs->supportGrow() ? yes : no);
        item->setIcon(i++, fs->supportShrink() ? yes : no);
        item->setIcon(i++, fs->supportMove() ? yes : no);
        item->setIcon(i++, fs->supportCopy() ? yes : no);
        item->setIcon(i++, fs->supportCheck() ? yes : no);
        item->setIcon(i++, fs->supportGetLabel() ? yes : no);
        item->setIcon(i++, fs->supportSetLabel() ? yes : no);
        item->setIcon(i++, fs->supportGetUsed() ? yes : no);
        item->setIcon(i++, fs->supportBackup() ? yes : no);

        // there is no FileSystem::supportRestore(), because we currently can't tell
        // if a file is an image of a supported or unsupported (or even invalid) filesystem
        item->setIcon(i++, yes);

        item->setText(i++, fs->supportToolName().name.isEmpty() ? QStringLiteral("---") : fs->supportToolName().name);

        dialogWidget().tree().addTopLevelItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QAction *x) { return x->text().isEmpty(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : LVM::pvList) { // FIXME: qAsConst
            if (p.isLuks())
                continue;
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &p : childWidgets()) {
        p->setVisible(false);
        p->deleteLater();
        p->setParent(nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : qAsConst(fsNames))
        comboDefaultFileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &d : m_Devices) {
        if (dynamic_cast<LvmDevice*>(d)) {
            if (d->name() == vgName) {
                m_IsValidName = false;
                break;
            }
            else
                m_IsValidName = true;
        }
    }
```

#### AUTO 


```{c}
const auto keys = boxOptions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : keys)
        if (s.second->isChecked())
            optList.append(s.first);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : m_PhysicalVolumes) {
            if (p.first == device()->name())
                dialogWidget().listPV().addPartition(*p.second, true);
            else if (p.first == QString() && !LvmDevice::s_DirtyPVs.contains(p.second)) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.second, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList::list())) {
            if (p.isLuks())
                continue;
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### AUTO 


```{c}
auto showPermissionsGroup = [this] {
        const QString currText = dialogWidget().comboFileSystem().currentText();
        const bool enablePosixPermission = QList<QString>({
                QStringLiteral("btrfs"),
                QStringLiteral("ext2"),
                QStringLiteral("ext3"),
                QStringLiteral("ext4"),
                QStringLiteral("f2fs"),
                QStringLiteral("hfsplus"),
                QStringLiteral("jfs"),
                QStringLiteral("minix"),
                QStringLiteral("ocfs2"),
                QStringLiteral("reiserfs"),
                QStringLiteral("reiser4"),
                QStringLiteral("udf"),
                QStringLiteral("xfs"),
                QStringLiteral("zfs"),}
            ).contains(currText);
        if (enablePosixPermission) {
            dialogWidget().showPosixPermissions();
        } else {
            dialogWidget().hidePosixPermissions();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : checkedPartitions)
        m_TotalSize += p->capacity() - p->capacity() % (dialogWidget().spinPESize().value() * Capacity::unitFactor(Capacity::Byte, Capacity::MiB));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : qAsConst(d->partitionTable()->children())) {
            bool alreadyInPendingVG = false;

            // Looking if there is another VG creation that contains this partition
            for (const auto &o : qAsConst(m_PendingOps)) {
                if (dynamic_cast<CreateVolumeGroupOperation *>(o) && o->targets(*p)) {
                    alreadyInPendingVG = true;
                    break;
                }
            }

            if (alreadyInPendingVG)
                continue;

            // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
            if (p->state() == Partition::State::New && p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                dialogWidget().listPV().addPartition(*p, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fs : FileSystemFactory::map())
    {
        // If the partition isn't encrypted, skip the luks FS
        if (fs->type() == FileSystem::Luks && partition().fileSystem().type() != FileSystem::Luks)
            continue;
        if (partition().fileSystem().type() == fs->type() || (fs->supportCreate() != FileSystem::cmdSupportNone &&
                            partition().capacity() >= fs->minCapacity() && partition().capacity() <= fs->maxCapacity())) {
            QString name = fs->name();

            if (partition().fileSystem().type() == fs->type())
                selected = name;

            // If the partition isn't extended, skip the extended FS
            if (fs->type() == FileSystem::Extended && !partition().roles().has(PartitionRole::Extended))
                continue;

            // The user cannot change the filesystem back to "unformatted" once a filesystem has been created.
            if (fs->type() == FileSystem::Unformatted) {
                // .. but if the file system is unknown to us, show the unformatted option as the currently selected one
                if (partition().fileSystem().type() == FileSystem::Unknown) {
                    name = FileSystem::nameForType(FileSystem::Unformatted);
                    selected = name;
                } else if (partition().fileSystem().type() != FileSystem::Unformatted && partition().state() != Partition::StateNew)
                    continue;
            }

            fsNames.append(name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : keys)
        if (boxOptions()[s]->isChecked())
            optList.append(s);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : device().smartStatus().attributes()) {
            QTreeWidgetItem* item = new QTreeWidgetItem(
                QStringList()
                << QLocale().toString(a.id())
                << QStringLiteral("<b>%1</b><br/>%2").arg(a.name()).arg(st + a.desc() + QStringLiteral("</span>"))
                << (a.failureType() == SmartAttribute::PreFailure ? xi18nc("@item:intable", "Pre-Failure") : xi18nc("@item:intable", "Old-Age"))
                << (a.updateType() == SmartAttribute::Online ? xi18nc("@item:intable", "Online") : xi18nc("@item:intable", "Offline"))
                << QLocale().toString(a.worst())
                << QLocale().toString(a.current())
                << QLocale().toString(a.threshold())
                << a.raw()
                << a.assessmentToString()
                << a.value()
            );
            item->setSizeHint(0, QSize(0, 64));
            dialogWidget().treeSmartAttributes().addTopLevelItem(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : qAsConst(d->partitionTable()->children())) {
                    // Looking if there is another VG creation that contains this partition
                    if (LvmDevice::s_DirtyPVs.contains(p))
                        continue;

                    // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                    if (p->state() == Partition::State::New) {
                        if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                        else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                            FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                            if (fs->type() == FileSystem::Type::Lvm2_PV)
                                dialogWidget().listPV().addPartition(*p, false);
                        }
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        const QString currText = dialogWidget().comboFileSystem().currentText();
        const bool enablePosixPermission = QList<QString>({
                QStringLiteral("btrfs"),
                QStringLiteral("ext2"),
                QStringLiteral("ext3"),
                QStringLiteral("ext4"),
                QStringLiteral("f2fs"),
                QStringLiteral("hfsplus"),
                QStringLiteral("jfs"),
                QStringLiteral("minix"),
                QStringLiteral("ocfs2"),
                QStringLiteral("reiserfs"),
                QStringLiteral("reiser4"),
                QStringLiteral("udf"),
                QStringLiteral("xfs"),
                QStringLiteral("zfs"),}
            ).contains(currText);
        if (enablePosixPermission) {
            dialogWidget().showPosixPermissions();
        } else {
            dialogWidget().hidePosixPermissions();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : std::as_const(m_PendingOps)) {
                if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                    toBeDeleted = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : children)
        entry->setChecked(entry->data().toString() == device_node);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : qAsConst(fsNames))
        dialogWidget().fileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### AUTO 


```{c}
const auto mp = mountPoints();
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl::fromLocalFile(file.fileName()), QStringLiteral("text/html"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : device().smartStatus().attributes()) {
            s << "<tr>\n";

            s << "<td>" << QLocale().toString(a.id()) << "</td>\n"
              << "<td>" << QStringLiteral("<b>%1</b><br/>%2").arg(a.name()).arg(st + a.desc() + QStringLiteral("</span>")) << "</td>\n"
              << "<td>" << (a.failureType() == SmartAttribute::PreFailure ? xi18nc("@item:intable", "Pre-Failure") : xi18nc("@item:intable", "Old-Age")) << "</td>\n"
              << "<td>" << (a.updateType() == SmartAttribute::Online ? xi18nc("@item:intable", "Online") : xi18nc("@item:intable", "Offline")) << "</td>\n"
              << "<td>" << QLocale().toString(a.worst()) << "</td>\n"
              << "<td>" << QLocale().toString(a.current()) << "</td>\n"
              << "<td>" << QLocale().toString(a.threshold()) << "</td>\n"
              << "<td>" << a.raw() << "</td>\n"
              << "<td>" << a.assessmentToString() << "</td>\n"
              << "<td>" << a.value() << "</td>\n";

            s << "</tr>\n";
        }
```

#### AUTO 


```{c}
const auto &var
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pvpath : FS::lvm2_pv::getFreePV()) {
            if (!LvmDevice::s_DirtyPVs.contains(pvpath)) {
                dialogWidget().listPV().addPartition(pvpath, false);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : fstabEntries()) {
        if(e.fsSpec().contains(partition().deviceNode()) || e.fsSpec().contains(partition().fileSystem().uuid()) ||
           e.fsSpec().contains(partition().fileSystem().label()) || e.fsSpec().contains(partition().label()) || e.fsSpec().contains(partition().uuid()) )
        {
            fstabEntries().removeAt(i);
            partition().setMountPoint(QString());
            i--;
        }
        i++;
    }
```

#### AUTO 


```{c}
const auto &line
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &widget : widgets)
        {
            mw = qobject_cast< MainWindow* >( widget );
            if ( mw )
                break;
        }
```

#### AUTO 


```{c}
const auto children = findChildren<PartWidget*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &me : mp)
            writeEntry(out, me);
```

#### AUTO 


```{c}
auto search = mountPoints().find(labelName().text());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : std::as_const(m_PendingOps)) {
            if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                toBeDeleted = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device *d : qAsConst(m_Devices)) {
        if (d->partitionTable() != nullptr) {
            for (const Partition *p : qAsConst(d->partitionTable()->children())) {
                // Looking if there is another VG creation that contains this partition
                if (LvmDevice::s_DirtyPVs.contains(p))
                    continue;

                // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                if (p->state() == Partition::State::New) {
                    if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                        dialogWidget().listPV().addPartition(*p, false);
                    else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                        FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                        if (fs->type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto driveNode = rootNode->child(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : device().smartStatus().attributes()) {
            s << "<tr>\n";

            s << "<td>" << QLocale().toString(a.id()) << "</td>\n"
              << "<td>" << QStringLiteral("<b>%1</b><br/>%2").arg(a.name()).arg(st + a.desc() + QStringLiteral("</span>")) << "</td>\n"
              << "<td>" << (a.failureType() == SmartAttribute::FailureType::PreFailure ? xi18nc("@item:intable", "Pre-Failure") : xi18nc("@item:intable", "Old-Age")) << "</td>\n"
              << "<td>" << (a.updateType() == SmartAttribute::UpdateType::Online ? xi18nc("@item:intable", "Online") : xi18nc("@item:intable", "Offline")) << "</td>\n"
              << "<td>" << QLocale().toString(a.worst()) << "</td>\n"
              << "<td>" << QLocale().toString(a.current()) << "</td>\n"
              << "<td>" << QLocale().toString(a.threshold()) << "</td>\n"
              << "<td>" << a.raw() << "</td>\n"
              << "<td>" << a.assessmentToString() << "</td>\n"
              << "<td>" << a.value() << "</td>\n";

            s << "</tr>\n";
        }
```

#### AUTO 


```{c}
const auto &node
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : qAsConst(d->partitionTable()->children())) {
                // Looking if there is another VG creation that contains this partition
                if (LvmDevice::s_DirtyPVs.contains(p))
                    continue;

                // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                if (p->state() == Partition::State::New) {
                    if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                        dialogWidget().listPV().addPartition(*p, false);
                    else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                        FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                        if (fs->type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {accept_(MountPointAction::Remove);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : qAsConst(d->partitionTable()->children())) {
            // Looking if there is another VG creation that contains this partition
            if (LvmDevice::s_DirtyPVs.contains(p))
                continue;

            // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
            if (p->state() == Partition::State::New) {
                if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                    dialogWidget().listPV().addPartition(*p, false);
                else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                    FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                    if (fs->type() == FileSystem::Type::Lvm2_PV)
                        dialogWidget().listPV().addPartition(*p, false);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device *d : qAsConst(m_Devices)) {
        for (const Partition *p : qAsConst(d->partitionTable()->children())) {
            bool alreadyInPendingVG = false;

            // Looking if there is another VG creation that contains this partition
            for (const auto &o : qAsConst(m_PendingOps)) {
                if (dynamic_cast<CreateVolumeGroupOperation *>(o) && o->targets(*p)) {
                    alreadyInPendingVG = true;
                    break;
                }
            }

            if (alreadyInPendingVG)
                continue;

            // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
            if (p->state() == Partition::State::New && p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                dialogWidget().listPV().addPartition(*p, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device *d : qAsConst(m_Devices)) {
        for (const Partition *p : qAsConst(d->partitionTable()->children())) {
            // Looking if there is another VG creation that contains this partition
            if (LvmDevice::s_DirtyPVs.contains(p))
                continue;

            // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
            if (p->state() == Partition::State::New) {
                if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                    dialogWidget().listPV().addPartition(*p, false);
                else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                    FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                    if (fs->type() == FileSystem::Type::Lvm2_PV)
                        dialogWidget().listPV().addPartition(*p, false);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &backend : backends)
        if (backend.pluginId() == name)
            comboBackend().setCurrentIndex(comboBackend().findText(backend.name()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : services)
        comboBackend().addItem(p->name());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fs : FileSystemFactory::map())
    {
        // If the partition isn't encrypted, skip the luks FS
        if (fs->type() == FileSystem::Type::Luks && partition().fileSystem().type() != FileSystem::Type::Luks)
            continue;
        if (partition().fileSystem().type() == fs->type() || (fs->supportCreate() != FileSystem::cmdSupportNone &&
                            partition().capacity() >= fs->minCapacity() && partition().capacity() <= fs->maxCapacity())) {
            QString name = fs->name();

            if (partition().fileSystem().type() == fs->type())
                selected = name;

            // If the partition isn't extended, skip the extended FS
            if (fs->type() == FileSystem::Type::Extended && !partition().roles().has(PartitionRole::Extended))
                continue;

            // The user cannot change the filesystem back to "unformatted" once a filesystem has been created.
            if (fs->type() == FileSystem::Type::Unformatted) {
                // .. but if the file system is unknown to us, show the unformatted option as the currently selected one
                if (partition().fileSystem().type() == FileSystem::Type::Unknown) {
                    name = FileSystem::nameForType(FileSystem::Type::Unformatted);
                    selected = name;
                } else if (partition().fileSystem().type() != FileSystem::Type::Unformatted && partition().state() != Partition::StateNew)
                    continue;
            }

            fsNames.append(name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &child : p->children()) {
                QTreeWidgetItem* childItem = createTreeWidgetItem(*child);
                item->addChild(childItem);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : qAsConst(m_PendingOps)) {
            if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                toBeDeleted = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&e, &result](PolkitQt1::Authority::Result _result) {
                result = _result;
                e.quit();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&m_collator](QString a, QString b) {
        return m_collator.compare(a, b) < 0;
    }
```

#### AUTO 


```{c}
auto &widget
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : m_fstabEntries) {
        QString canonicalEntryPath = QFileInfo(e.deviceNode()).canonicalFilePath();
        QString canonicalDevicePath = QFileInfo(m_deviceNode).canonicalFilePath();
        if (canonicalEntryPath == canonicalDevicePath) {
            entryFound = true;
            entry.push_back(&e);
            mountPointList = possibleMountPoints(e.deviceNode());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {accept_(MountPointAction::Edit);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList::list())) {
        bool toBeDeleted = false;

        // Ignore partitions that are going to be deleted
        for (const auto &o : qAsConst(m_PendingOps)) {
            if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                toBeDeleted = true;
                break;
            }
        }

        if (toBeDeleted)
            continue;

        if (!p.isLuks() && p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
    }
```

#### AUTO 


```{c}
const auto &fs
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &pw : children)
        if (pw->isActive())
            return pw;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList)) {
        bool toBeDeleted = false;

        // Ignore partitions that are going to be deleted
        for (const auto &o : qAsConst(m_PendingOps)) {
            if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                toBeDeleted = true;
                break;
            }
        }

        if (toBeDeleted)
            continue;

        if (!p.isLuks() && p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fs : FileSystemFactory::map())
    {
        // If the partition isn't encrypted, skip the luks FS
        if (fs->type() == FileSystem::Type::Luks && partition().fileSystem().type() != FileSystem::Type::Luks)
            continue;
        if (fs->type() == FileSystem::Type::Luks2 && partition().fileSystem().type() != FileSystem::Type::Luks2)
            continue;
        if (partition().fileSystem().type() == fs->type() || (fs->supportCreate() != FileSystem::cmdSupportNone &&
                            partition().capacity() >= fs->minCapacity() && partition().capacity() <= fs->maxCapacity())) {
            QString name = fs->name();

            if (partition().fileSystem().type() == fs->type())
                selected = name;

            // If the partition isn't extended, skip the extended FS
            if (fs->type() == FileSystem::Type::Extended && !partition().roles().has(PartitionRole::Extended))
                continue;

            // The user cannot change the filesystem back to "unformatted" once a filesystem has been created.
            if (fs->type() == FileSystem::Type::Unformatted) {
                // .. but if the file system is unknown to us, show the unformatted option as the currently selected one
                if (partition().fileSystem().type() == FileSystem::Type::Unknown) {
                    name = FileSystem::nameForType(FileSystem::Type::Unformatted);
                    selected = name;
                } else if (partition().fileSystem().type() != FileSystem::Type::Unformatted && partition().state() != Partition::State::New)
                    continue;
            }

            fsNames.append(name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : LVM::pvList) { // FIXME: qAsConst
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & fsName : fsNames)
        dialogWidget().fileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : qAsConst(LvmDevice::s_OrphanPVs))
        if (!LvmDevice::s_DirtyPVs.contains(p))
            dialogWidget().listPV().addPartition(*p, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : device().smartStatus().attributes()) {
            QTreeWidgetItem* item = new QTreeWidgetItem(
                QStringList()
                << QLocale().toString(a.id())
                << QStringLiteral("<b>%1</b><br/>%2").arg(a.name()).arg(st + a.desc() + QStringLiteral("</span>"))
                << (a.failureType() == SmartAttribute::PreFailure ? xi18nc("@item:intable", "Pre-Failure") : xi18nc("@item:intable", "Old-Age"))
                << (a.updateType() == SmartAttribute::Online ? xi18nc("@item:intable", "Online") : xi18nc("@item:intable", "Offline"))
                << QLocale().toString(a.worst())
                << QLocale().toString(a.current())
                << QLocale().toString(a.threshold())
                << a.raw()
                << a.assessmentToString()
                << a.value()
            );
            item->setSizeHint(0, QSize(0, 64));
            item->setToolTip(1, QTextDocumentFragment::fromHtml(a.desc()).toPlainText());
            dialogWidget().treeSmartAttributes().addTopLevelItem(item);
        }
```

#### AUTO 


```{c}
auto partitionNode = driveNode->child(e);
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {accept_(Remove);}
```

#### AUTO 


```{c}
auto menu = QMainWindow::createPopupMenu();
```

#### LAMBDA EXPRESSION 


```{c}
[&m_collator](QString a, QString b) { return m_collator.compare(a, b) < 0; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : std::as_const(LVM::pvList::list())) {
        bool toBeDeleted = false;

        // Ignore partitions that are going to be deleted
        for (const auto &o : std::as_const(m_PendingOps)) {
            if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                toBeDeleted = true;
                break;
            }
        }

        if (toBeDeleted)
            continue;

        if (!p.isLuks() && p.vgName().isEmpty() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
    }
```

#### AUTO 


```{c}
auto const &part
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : std::as_const(LvmDevice::s_OrphanPVs))
        if (!LvmDevice::s_DirtyPVs.contains(p))
            dialogWidget().listPV().addPartition(*p, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &backend : backends)
        if (backend.name() == comboBackend().currentText())
            return backend.pluginId();
```

#### AUTO 


```{c}
auto const &node
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : checkedPartitions)
        m_TotalSize += p->capacity() - p->capacity() % (dialogWidget().spinPESize().value() * Capacity::unitFactor(Capacity::Unit::Byte, Capacity::Unit::MiB));
```

#### AUTO 


```{c}
const auto previewDevices = operationStack().previewDevices();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : fsNames)
        dialogWidget().fileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : partitionTable()->children()) {
            PartWidget* w = new PartWidget(this, p);
            w->setVisible(true);
            w->setFileSystemColorCode(GuiHelpers::fileSystemColorCodesFromSettings());
        }
```

#### AUTO 


```{c}
const auto children = devicesMenu->findChildren<QAction*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device *d : qAsConst(m_Devices)) {
            if (d->partitionTable() != nullptr) {
                for (const Partition *p : qAsConst(d->partitionTable()->children())) {
                    // Looking if there is another VG creation that contains this partition
                    if (LvmDevice::s_DirtyPVs.contains(p))
                        continue;

                    // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                    if (p->state() == Partition::State::New) {
                        if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                        else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                            FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                            if (fs->type() == FileSystem::Type::Lvm2_PV)
                                dialogWidget().listPV().addPartition(*p, false);
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto rootNode = treePartitions().invisibleRootItem();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &d : previewDevices) {
        QAction* action = new QAction(d->prettyName(), devicesMenu);
        action->setCheckable(true);
        action->setChecked(d->deviceNode() == pmWidget().selectedDevice()->deviceNode());
        action->setData(d->deviceNode());
        connect(action, &QAction::triggered, this, &MainWindow::onSelectedDeviceMenuTriggered);
        devicesMenu->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &child : children)
                child->setFileSystemColorCode(GuiHelpers::fileSystemColorCodesFromSettings());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &node : parent->children()) {
        const Partition* p = dynamic_cast<const Partition*>(node);

        if (p == nullptr)
            continue;

        if (node->children().size() > 0 && !rval.isEmpty())
            rval = kxi18n("%1%2").subs(rval).subs(checkSupportInNode(node));
        else
            rval = checkSupportInNode(node);

        // TODO: Don't create HTML tables manually.
        if ((!p->fileSystem().supportToolFound() && !p->fileSystem().supportToolName().name.isEmpty()) && !rval.isEmpty())
            rval = kxi18n("%1%2").subs(rval).subs(kxi18n("<tr>"
                                   "<td>%1</td>"
                                   "<td>%2</td>"
                                   "<td>%3</td>"
                                   "<td><link>%4</link></td>"
                                   "</tr>")
                 .subs(p->deviceNode())
                 .subs(p->fileSystem().name())
                 .subs(p->fileSystem().supportToolName().name)
                 .subs(p->fileSystem().supportToolName().url.toString()));
        else if (!p->fileSystem().supportToolFound() && !p->fileSystem().supportToolName().name.isEmpty())
            rval =kxi18n("<tr>"
                                   "<td>%1</td>"
                                   "<td>%2</td>"
                                   "<td>%3</td>"
                                   "<td><link>%4</link></td>"
                                   "</tr>")
                 .subs(p->deviceNode())
                 .subs(p->fileSystem().name())
                 .subs(p->fileSystem().supportToolName().name)
                 .subs(p->fileSystem().supportToolName().url.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &op : operations)
        opList.append(op->description());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : std::as_const(LVM::pvList::list())) {
            bool toBeDeleted = false;

            // Ignore partitions that are going to be deleted
            for (const auto &o : std::as_const(m_PendingOps)) {
                if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                    toBeDeleted = true;
                    break;
                }
            }

            if (toBeDeleted)
                continue;

            if (p.isLuks())
                continue;
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName().isEmpty() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : std::as_const(fsNames))
        comboDefaultFileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : fsNames)
        comboDefaultFileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### AUTO 


```{c}
const auto widgets = qApp->topLevelWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &) {setDirty();}
```

#### LAMBDA EXPRESSION 


```{c}
[this]
            {
                m_PartWidget->setFileSystemColorCode(GuiHelpers::fileSystemColorCodesFromSettings());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map()) {
        if (fs->supportCreate() != FileSystem::cmdSupportNone &&
            fs->type() != FileSystem::Type::Extended &&
            fs->type() != FileSystem::Type::Luks &&
            fs->type() != FileSystem::Type::Luks2)
            fsNames.append(fs->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : fstabEntries()) {
       if((e.fsSpec().contains(partition().deviceNode()) && !partition().deviceNode().isEmpty() ) || (e.fsSpec().contains(partition().fileSystem().uuid()) && !partition().fileSystem().uuid().isEmpty()) ||
           (e.fsSpec().contains(partition().fileSystem().label()) && !partition().fileSystem().label().isEmpty()) || (e.fsSpec().contains(partition().label()) && !partition().label().isEmpty() ) || (e.fsSpec().contains(partition().uuid()) && !partition().uuid().isEmpty() ) )
       {
            fstabEntries().removeAt(i);
            partition().setMountPoint(QString());
            i--;
        }
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : m_fstabEntries) {
        QString canonicalEntryPath = QFileInfo(e.deviceNode()).canonicalFilePath();
        QString canonicalDevicePath = QFileInfo(m_deviceNode).canonicalFilePath();
        if (canonicalEntryPath == canonicalDevicePath) { // FIXME fix multiple mountpoints
            entryFound = true;
            entry = &e;
        }
    }
```

#### AUTO 


```{c}
const auto &box
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : services)
        if (p->library() == name)
            comboBackend().setCurrentIndex(comboBackend().findText(p->name()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : device().smartStatus().attributes()) {
            QTreeWidgetItem* item = new QTreeWidgetItem(
                QStringList()
                << QLocale().toString(a.id())
                << QStringLiteral("<b>%1</b><br/>%2").arg(a.name()).arg(st + a.desc() + QStringLiteral("</span>"))
                << (a.failureType() == SmartAttribute::FailureType::PreFailure ? xi18nc("@item:intable", "Pre-Failure") : xi18nc("@item:intable", "Old-Age"))
                << (a.updateType() == SmartAttribute::UpdateType::Online ? xi18nc("@item:intable", "Online") : xi18nc("@item:intable", "Offline"))
                << QLocale().toString(a.worst())
                << QLocale().toString(a.current())
                << QLocale().toString(a.threshold())
                << a.raw()
                << a.assessmentToString()
                << a.value()
            );
            item->setSizeHint(0, QSize(0, 64));
            item->setToolTip(1, QTextDocumentFragment::fromHtml(a.desc()).toPlainText());
            dialogWidget().treeSmartAttributes().addTopLevelItem(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : qAsConst(m_PendingOps)) {
                if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                    toBeDeleted = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map()) {
        if (fs->type() == FileSystem::Type::Unknown || fs->type() == FileSystem::Type::Extended ||
            fs->type() == FileSystem::Type::Luks || fs->type() == FileSystem::Type::Luks2) {
            continue;
        }

        QTreeWidgetItem* item = new QTreeWidgetItem();

        int i = 0;
        item->setText(i++, fs->name());
        item->setIcon(i++, fs->supportCreate() ? yes : no);
        item->setIcon(i++, fs->supportGrow() ? yes : no);
        item->setIcon(i++, fs->supportShrink() ? yes : no);
        item->setIcon(i++, fs->supportMove() ? yes : no);
        item->setIcon(i++, fs->supportCopy() ? yes : no);
        item->setIcon(i++, fs->supportCheck() ? yes : no);
        item->setIcon(i++, fs->supportGetLabel() ? yes : no);
        item->setIcon(i++, fs->supportSetLabel() ? yes : no);
        item->setIcon(i++, fs->supportGetUsed() ? yes : no);
        item->setIcon(i++, fs->supportBackup() ? yes : no);

        // there is no FileSystem::supportRestore(), because we currently can't tell
        // if a file is an image of a supported or unsupported (or even invalid) filesystem
        item->setIcon(i++, yes);

        item->setText(i++, fs->supportToolName().name.isEmpty() ? QStringLiteral("---") : fs->supportToolName().name);

        dialogWidget().tree().addTopLevelItem(item);
    }
```

#### AUTO 


```{c}
const auto keys = boxOptions().keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList::list())) {
            bool toBeDeleted = false;

            // Ignore partitions that are going to be deleted
            for (const auto &o : qAsConst(m_PendingOps)) {
                if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                    toBeDeleted = true;
                    break;
                }
            }

            if (toBeDeleted)
                continue;

            if (p.isLuks())
                continue;
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : options)
        editOptions().appendPlainText(o);
```

#### AUTO 


```{c}
const auto &fsName
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &line : lines)
        rval.append(line.simplified().toLower());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &op : ops) {
        QListWidgetItem* item = new QListWidgetItem(QIcon::fromTheme(op->iconName()).pixmap(IconSize(KIconLoader::Small)), op->description());
        item->setToolTip(op->description());
        listOperations().addItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : findResult) {
            const PartitionTreeWidgetItem* ptwItem = dynamic_cast<PartitionTreeWidgetItem*>(item);

            if (ptwItem && ptwItem->partition() == p) {
                treePartitions().setCurrentItem(item);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &var : envVars)
                if (env.contains(var))
                    argList += var + QStringLiteral("=") + env.value(var) + QStringLiteral(" ");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList::list())) {
        bool toBeDeleted = false;

        // Ignore partitions that are going to be deleted
        for (const auto &o : qAsConst(m_PendingOps)) {
            if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                toBeDeleted = true;
                break;
            }
        }

        if (toBeDeleted)
            continue;

        if (!p.isLuks() && p.vgName().isEmpty() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map())
        if (fs->supportCreate() != FileSystem::cmdSupportNone && fs->type() != FileSystem::Type::Extended && fs->type() != FileSystem::Type::Luks)
            fsNames.append(fs->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device *d : std::as_const(m_Devices)) {
        if (d->partitionTable() != nullptr) {
            for (const Partition *p : std::as_const(d->partitionTable()->children())) {
                // Looking if there is another VG creation that contains this partition
                if (LvmDevice::s_DirtyPVs.contains(p))
                    continue;

                // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                if (p->state() == Partition::State::New) {
                    if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                        dialogWidget().listPV().addPartition(*p, false);
                    else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                        FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                        if (fs->type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList::list())) {
            bool toBeDeleted = false;

            // Ignore partitions that are going to be deleted
            for (const auto &o : qAsConst(m_PendingOps)) {
                if (dynamic_cast<DeleteOperation *>(o) && o->targets(*p.partition())) {
                    toBeDeleted = true;
                    break;
                }
            }

            if (toBeDeleted)
                continue;

            if (p.isLuks())
                continue;
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName().isEmpty() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### AUTO 


```{c}
const auto children = w->childWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[=](int index){ currentEntry = entry[index];
                        spinDumpFreq().setValue(currentEntry->dumpFreq());
                        spinPassNumber().setValue(currentEntry->passNumber());
                        setupRadio(currentEntry->entryType());
                        for (iterator_BoxOptions = boxOptions().begin(); iterator_BoxOptions != boxOptions().end(); ++iterator_BoxOptions){
                            boxOptions()[iterator_BoxOptions->first]->setChecked(false);
                        }
                        setupOptions(currentEntry->options());
                      }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {accept_(Edit);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map())
        if (fs->supportCreate() != FileSystem::cmdSupportNone && fs->type() != FileSystem::Extended && fs->type() != FileSystem::Luks)
            fsNames.append(fs->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList)) {
            if (p.isLuks())
                continue;
            if (p.vgName() == device()->name())
                dialogWidget().listPV().addPartition(*p.partition(), true);
            else if (p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition())) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.partition(), false);
        }
```

#### AUTO 


```{c}
auto it = fstabEntries().begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : m_PhysicalVolumes)
        if (p.first == QString() && !LvmDevice::s_DirtyPVs.contains(p.second))
            dialogWidget().listPV().addPartition(*p.second, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & fsName : fsNames)
        comboDefaultFileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : qAsConst(LvmDevice::s_OrphanPVs))
            if (!LvmDevice::s_DirtyPVs.contains(p))
                dialogWidget().listPV().addPartition(*p, false);
```

#### AUTO 


```{c}
const auto &op
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : children)
        entry->setChecked(entry == action);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : partitionTable()->children()) {
            PartWidget* w = new PartWidget(this, p);
            w->setVisible(true);
            w->setFileSystemColorCode(GuiHelpers::fileSystemColorCodesFromSettings());
            const auto children = w->childWidgets();
            for (const auto &child : children)
                child->setFileSystemColorCode(GuiHelpers::fileSystemColorCodesFromSettings());
        }
```

#### AUTO 


```{c}
const auto &pw
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fs : FileSystemFactory::map()) {
        if (fs->supportCreate() != FileSystem::cmdSupportNone &&
            fs->type() != FileSystem::Extended &&
            fs->type() != FileSystem::Luks &&
            fs->type() != FileSystem::Luks2)
            fsNames.append(fs->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : std::as_const(d->partitionTable()->children())) {
                // Looking if there is another VG creation that contains this partition
                if (LvmDevice::s_DirtyPVs.contains(p))
                    continue;

                // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                if (p->state() == Partition::State::New) {
                    if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                        dialogWidget().listPV().addPartition(*p, false);
                    else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                        FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                        if (fs->type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                    }
                }
            }
```

#### AUTO 


```{c}
const auto &a
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
const auto &e
```

#### AUTO 


```{c}
const auto &d
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &node : parent->children()) {
        const Partition* p = dynamic_cast<const Partition*>(node);

        if (p == nullptr)
            continue;

        if (node->children().size() > 0 && !rval.isEmpty())
            rval = kxi18n("%1%2").subs(rval).subs(checkSupportInNode(node));
        else
            rval = checkSupportInNode(node);

        if ((!p->fileSystem().supportToolFound() && !p->fileSystem().supportToolName().name.isEmpty()) && !rval.isEmpty())
            rval = kxi18n("%1%2").subs(rval).subs(kxi18n("<tr>"
                                   "<td>%1</td>"
                                   "<td>%2</td>"
                                   "<td>%3</td>"
                                   "<td><link>%4</link></td>"
                                   "</tr>")
                 .subs(p->deviceNode())
                 .subs(p->fileSystem().name())
                 .subs(p->fileSystem().supportToolName().name)
                 .subs(p->fileSystem().supportToolName().url.toString()));
        else if (!p->fileSystem().supportToolFound() && !p->fileSystem().supportToolName().name.isEmpty())
            rval =kxi18n("<tr>"
                                   "<td>%1</td>"
                                   "<td>%2</td>"
                                   "<td>%3</td>"
                                   "<td><link>%4</link></td>"
                                   "</tr>")
                 .subs(p->deviceNode())
                 .subs(p->fileSystem().name())
                 .subs(p->fileSystem().supportToolName().name)
                 .subs(p->fileSystem().supportToolName().url.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fs : FileSystemFactory::map())
    {
        // If the partition isn't encrypted, skip the luks FS
        if (fs->type() == FileSystem::Type::Luks && partition().fileSystem().type() != FileSystem::Type::Luks)
            continue;
        if (partition().fileSystem().type() == fs->type() || (fs->supportCreate() != FileSystem::cmdSupportNone &&
                            partition().capacity() >= fs->minCapacity() && partition().capacity() <= fs->maxCapacity())) {
            QString name = fs->name();

            if (partition().fileSystem().type() == fs->type())
                selected = name;

            // If the partition isn't extended, skip the extended FS
            if (fs->type() == FileSystem::Type::Extended && !partition().roles().has(PartitionRole::Extended))
                continue;

            // The user cannot change the filesystem back to "unformatted" once a filesystem has been created.
            if (fs->type() == FileSystem::Type::Unformatted) {
                // .. but if the file system is unknown to us, show the unformatted option as the currently selected one
                if (partition().fileSystem().type() == FileSystem::Type::Unknown) {
                    name = FileSystem::nameForType(FileSystem::Type::Unformatted);
                    selected = name;
                } else if (partition().fileSystem().type() != FileSystem::Type::Unformatted && partition().state() != Partition::State::New)
                    continue;
            }

            fsNames.append(name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &d : m_Devices) {
        if (dynamic_cast<LvmDevice*>(d)) {
            if (d->name() == vgname) {
                m_IsValidName = false;
                break;
            }
            else
                m_IsValidName = true;
        }
    }
```

#### AUTO 


```{c}
const auto &o
```

#### AUTO 


```{c}
const auto &s
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : qAsConst(fsNames))
        dialogWidget().comboFileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### AUTO 


```{c}
const auto &p
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : std::as_const(d->partitionTable()->children())) {
                    // Looking if there is another VG creation that contains this partition
                    if (LvmDevice::s_DirtyPVs.contains(p))
                        continue;

                    // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                    if (p->state() == Partition::State::New) {
                        if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                        else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                            FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                            if (fs->type() == FileSystem::Type::Lvm2_PV)
                                dialogWidget().listPV().addPartition(*p, false);
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : qAsConst(m_PendingOps)) {
                if (dynamic_cast<CreateVolumeGroupOperation *>(o) && o->targets(*p)) {
                    alreadyInPendingVG = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto actions = menu->actions();
```

#### AUTO 


```{c}
auto *allowEveryone = new QCheckBox(i18n("Allow everyone to use this partition"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &treeWidgetItem : findResult) {
            const PartitionTreeWidgetItem* ptwItem = dynamic_cast<PartitionTreeWidgetItem*>(treeWidgetItem);

            if (ptwItem && ptwItem->partition() == p) {
                treePartitions().setCurrentItem(treeWidgetItem);
                break;
            }
        }
```

#### AUTO 


```{c}
const auto &me
```

#### AUTO 


```{c}
const auto children = dialogWidget().findChildren<QAbstractSpinBox*>() + detailsWidget().findChildren<QAbstractSpinBox*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : m_PhysicalVolumes) {
            if (p.first == device().name())
                dialogWidget().listPV().addPartition(*p.second, true);
            else if (p.first == QString() && !LvmDevice::s_DirtyPVs.contains(p.second)) // TODO: Remove LVM PVs in current VG
                dialogWidget().listPV().addPartition(*p.second, false);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] ( QListWidgetItem*) {
                updateSizeInfos();
            }
```

#### AUTO 


```{c}
auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : fstabEntries()) {
       if(editPath().count()<=1 && ((e.fsSpec().contains(partition().deviceNode()) && !partition().deviceNode().isEmpty() ) || (e.fsSpec().contains(partition().fileSystem().uuid()) && !partition().fileSystem().uuid().isEmpty()) ||
           (e.fsSpec().contains(partition().fileSystem().label()) && !partition().fileSystem().label().isEmpty()) || (e.fsSpec().contains(partition().label()) && !partition().label().isEmpty() ) || (e.fsSpec().contains(partition().uuid()) && !partition().uuid().isEmpty()  )))
       {
            fstabEntries().removeAt(i);
            partition().setMountPoint(QString());
            i--;
       }
       else if(editPath().count()>1 && ((&e == currentEntry)))
       {
            fstabEntries().removeAt(i);
            editPath().removeItem(editPath().currentIndex());
            partition().setMountPoint(editPath().itemText(editPath().currentIndex()));
            i--;
            break;
        }
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : FS::lvm2_pv::getPVs(m_Devices)) {
        if (!LvmDevice::s_DirtyPVs.contains(p->deviceNode())) {
            dialogWidget().listPV().addPartition(p->deviceNode(), false);
        }
    }
```

#### AUTO 


```{c}
const auto &mp
```

#### RANGE FOR STATEMENT 


```{c}
for (const Device *d : std::as_const(m_Devices)) {
            if (d->partitionTable() != nullptr) {
                for (const Partition *p : std::as_const(d->partitionTable()->children())) {
                    // Looking if there is another VG creation that contains this partition
                    if (LvmDevice::s_DirtyPVs.contains(p))
                        continue;

                    // Including new LVM PVs (that are currently in OperationStack and that aren't at other VG creation)
                    if (p->state() == Partition::State::New) {
                        if (p->fileSystem().type() == FileSystem::Type::Lvm2_PV)
                            dialogWidget().listPV().addPartition(*p, false);
                        else if (p->fileSystem().type() == FileSystem::Type::Luks || p->fileSystem().type() == FileSystem::Type::Luks2) {
                            FileSystem *fs = static_cast<const FS::luks *>(&p->fileSystem())->innerFS();

                            if (fs->type() == FileSystem::Type::Lvm2_PV)
                                dialogWidget().listPV().addPartition(*p, false);
                        }
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &d : devices)
        listDevices().addItem(new ListDeviceWidgetItem(*d));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Partition *p : std::as_const(LvmDevice::s_OrphanPVs))
            if (!LvmDevice::s_DirtyPVs.contains(p))
                dialogWidget().listPV().addPartition(*p, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : services)
        if (p->name() == comboBackend().currentText())
            return p->library();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pw : children)
        if (pw->isActive())
            return pw;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : qAsConst(LVM::pvList))
        if (!p.isLuks() && p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &d : previewDevices ) {
        supportInNode = checkSupportInNode(d->partitionTable());
        if (!supportInNode.isEmpty() && !supportList.isEmpty()) {
            missingSupportTools = true;
            supportList = kxi18n("%1%2").subs(supportList).subs(supportInNode);
        }
        else if (!supportInNode.isEmpty()) {
            missingSupportTools = true;
            supportList = supportInNode;
        }
    }
```

#### AUTO 


```{c}
auto search = mountPoints().find(m_deviceNode);
```

#### AUTO 


```{c}
auto const &d
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &op : ops) {
        QListWidgetItem* item = new QListWidgetItem(QIcon::fromTheme(op->iconName()), op->description());
        item->setToolTip(op->description());
        listOperations().addItem(item);
    }
```

#### AUTO 


```{c}
auto &pw
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int) {setDirty();}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &e : m_fstabEntries) {
        QString canonicalEntryPath = QFileInfo(e.deviceNode()).canonicalFilePath();
        QString canonicalDevicePath = QFileInfo(m_deviceNode).canonicalFilePath();
        if (canonicalEntryPath == canonicalDevicePath) { // FIXME fix multiple mountpoints
            entryFound = true;
            entry.append(&e);
            mountPointList = possibleMountPoints(e.deviceNode());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : LVM::pvList) // FIXME: qAsConst
        if (!p.isLuks() && p.vgName() == QString() && !LvmDevice::s_DirtyPVs.contains(p.partition()))
            dialogWidget().listPV().addPartition(*p.partition(), false);
```

#### AUTO 


```{c}
auto &e
```

#### LAMBDA EXPRESSION 


```{c}
[this] {onPropertiesDevice({});}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pvpath : FS::lvm2_pv::getFreePV()) {
        if (!LvmDevice::s_DirtyPVs.contains(pvpath)) {
            dialogWidget().listPV().addPartition(pvpath, false);
        }
    }
```

#### AUTO 


```{c}
const auto &backend
```

#### AUTO 


```{c}
const auto * p
```

#### AUTO 


```{c}
auto &p
```

#### AUTO 


```{c}
auto newFlags = PartitionTable::flagsFromList(flags);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &op : ops) {
        QListWidgetItem* item = new QListWidgetItem(QIcon::fromTheme(op->iconName()).pixmap(KIconLoader::global()->currentSize(KIconLoader::Small)), op->description());
        item->setToolTip(op->description());
        listOperations().addItem(item);
    }
```

#### AUTO 


```{c}
const auto &treeWidgetItem
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : std::as_const(fsNames))
        dialogWidget().fileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &o : options) {
        if (boxOptions().find(o) != boxOptions().end())
            boxOptions()[o]->setChecked(true);
        else
            optTmpList.append(o);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fsName : std::as_const(fsNames))
        dialogWidget().comboFileSystem().addItem(createFileSystemColor(FileSystem::typeForName(fsName), 8), fsName);
```

#### AUTO 


```{c}
const auto dialogResult = KMessageBox::warningContinueCancel(this,
                                           xi18nc("@info", "<para>Are you sure you want to save the changes you made to the system table file <filename>/etc/fstab</filename>?</para>"
                                                   "<para><warning>This will overwrite the existing file on your hard drive now. This <emphasis strong='1'>can not be undone</emphasis>.</warning></para>"),
                                           xi18nc("@title:window", "Really save changes?"),
                                           KGuiItem(xi18nc("@action:button", "Save changes"), QStringLiteral("arrow-right")),
                                           KStandardGuiItem::cancel(),
                                           QStringLiteral("reallyWriteMountPoints"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileSystem * fs : FileSystemFactory::map())
        if (fs->supportCreate() != FileSystem::cmdSupportNone && fs->type() != FileSystem::Extended && fs->type() != FileSystem::Luks)
            fsNames.append(fs->name());
```

#### AUTO 


```{c}
const auto &child
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto * p : children) {
            QTreeWidgetItem* item = createTreeWidgetItem(*p);

            for (const auto &child : p->children()) {
                QTreeWidgetItem* childItem = createTreeWidgetItem(*child);
                item->addChild(childItem);
            }

            deviceItem->addChild(item);
            item->setExpanded(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &d : previewDevices) {
        if (d->deviceNode() == deviceNode) {
            setSelectedDevice(d);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : FS::lvm2_pv::getPVs(m_Devices)) {
            if (!LvmDevice::s_DirtyPVs.contains(p->deviceNode())) {
                dialogWidget().listPV().addPartition(p->deviceNode(), false);
            }
        }
```

#### AUTO 


```{c}
const auto backends = CoreBackendManager::self()->list();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &node : parent->children()) {
        const Partition* p = dynamic_cast<const Partition*>(node);

        if (p == nullptr)
            continue;

        if (node->children().size() > 0 && !rval.isEmpty())
            rval = kxi18n("%1%2").subs(rval).subs(checkSupportInNode(node));
        else
            rval = checkSupportInNode(node);

        if ((!p->fileSystem().supportToolFound() && !p->fileSystem().supportToolName().name.isEmpty()) && !rval.isEmpty())
            rval = kxi18n("%1%2").subs(rval).subs(kxi18n("<tr>"
                                   "<td>%1</td>"
                                   "<td>%2</td>"
                                   "<td>%3</td>"
                                   "<td><link>%4</link></td>"
                                   "</tr>")
                 .subs(p->deviceNode())
                 .subs(p->fileSystem().name())
                 .subs(p->fileSystem().supportToolName().name)
                 .subs(p->fileSystem().supportToolName().url.toString()));
        else if (!p->fileSystem().supportToolFound() && !p->fileSystem().supportToolName().name.isEmpty())
            rval =kxi18n("<tr>"
                                   "<td>%1</td>"
                                   "<td>%2</td>"
                                   "<td>%3</td>"
                                   "<td><link>%4</link></td>"
                                   "</tr>")
                 .subs(p->deviceNode())
                 .subs(p->fileSystem().name())
                 .subs(p->fileSystem().supportToolName().name)
                 .subs(p->fileSystem().supportToolName().url.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &backend : backends)
        comboBackend().addItem(backend.name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &me : mp)
            writeEntry(out, me.second);
```

