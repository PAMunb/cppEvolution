#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPlugins(QStringLiteral("kf5/parts"),
                                                  [](const KPluginMetaData& metaData) {
      return metaData.pluginId() == QLatin1String("kimagemapeditorpart");
  });
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
      return metaData.pluginId() == QLatin1String("kimagemapeditorpart");
  }
```

