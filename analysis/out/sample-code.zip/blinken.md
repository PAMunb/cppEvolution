#### RANGE FOR STATEMENT 


```{c}
for (highScoreManager *hsm : std::as_const(s_allHSM))
		{
			if (hsm != this)
			{
				hsm->update();
			}
		}
```

#### AUTO 


```{c}
auto getPixmapFor = [this, sz](blinkenGame::color color, const QString& pixmapName) -> QPixmap {
		return getPixmap( m_highlighted & color ?
			QStringLiteral("%1_highlight").arg(pixmapName) :
			QStringLiteral("%1_normal").arg(pixmapName), sz);
	};
```

#### LAMBDA EXPRESSION 


```{c}
[this, sz](blinkenGame::color color, const QString& pixmapName) -> QPixmap {
		return getPixmap( m_highlighted & color ?
			QStringLiteral("%1_highlight").arg(pixmapName) :
			QStringLiteral("%1_normal").arg(pixmapName), sz);
	}
```

#### AUTO 


```{c}
const auto sz = QSize((int)(width() * xScaleButtons), (int)(height() * yScaleButtons));
```

