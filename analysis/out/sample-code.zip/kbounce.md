#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)) {
        wall->setWallVelocity(m_wallVelocity);
        wall->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)) {
        wall->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
        int x1 = static_cast<int>( ball->ballBoundingRect().x() );
        int y1 = static_cast<int>( ball->ballBoundingRect().y() );
        int x2 = static_cast<int>( ball->ballBoundingRect().right() );
        int y2 = static_cast<int>( ball->ballBoundingRect().bottom() );
        // try to fill from all edges
        // this way we can avoid most precision-related issues
        fill(x1, y1);
        fill(x1, y2);
        fill(x2, y1);
        fill(x2, y2);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)) {
        wall->hide();
        connect( wall, &KBounceWall::died, this, &KBounceBoard::wallDied );
        connect( wall, &KBounceWall::finished, this, &KBounceBoard::wallFinished );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)) {
            if ( object != wall )
            {
                if ( wall->isVisible() && rect.intersects( wall->nextBoundingRect() ) )
                {
                    KBounceHit hit;
                    hit.type = WALL;
                    hit.boundingRect = wall->nextBoundingRect();
                    hit.normal = KBounceVector::normal( rect, hit.boundingRect );
                    result += hit;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
        QRectF rect = ball->nextBoundingRect();
        KBounceCollision collision;
        collision = checkCollision( ball, rect, ALL );
        ball->collide( collision );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
        ball->resize( m_tileSize );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)) {
        wall->goForward();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
            if ( object != ball )
            {
                if ( rect.intersects( ball->nextBoundingRect() ) )
                {
                    KBounceHit hit;
                    hit.type = BALL;
                    hit.boundingRect = ball->nextBoundingRect();
                    hit.normal = KBounceVector::normal( rect, hit.boundingRect );
                    result += hit;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)){
        QRectF rect = wall->nextBoundingRect();
        KBounceCollision collision;
        collision = checkCollision( wall, rect, ALL );
        wall->collide( collision );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
        ball->resize( m_tileSize );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)) {
        wall->resize( m_tileSize );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)) {
        wall->setWallVelocity(m_wallVelocity);
        wall->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
        ball->goForward();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
        ball->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
        ball->goForward();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
        ball->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)) {
        wall->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
            if ( object != ball )
            {
                if ( rect.intersects( ball->nextBoundingRect() ) )
                {
                    KBounceHit hit;
                    hit.type = BALL;
                    hit.boundingRect = ball->nextBoundingRect();
                    hit.normal = KBounceVector::normal( rect, hit.boundingRect );
                    result += hit;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : qAsConst(m_walls)) {
        wall->goForward();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)) {
        wall->resize( m_tileSize );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBounceHit &hit : collision) {
        switch (hit.type) {
            case ALL:
                break;
            case TILE:
                finish();
                break;
            case BALL:
                if (safeEdgeHit(hit.boundingRect)) {
                    KBounceVector normal = hit.normal;
                    if (qAbs(normal.x) < qAbs(normal.y)) { // vertical
                        if (m_dir == Up || m_dir == Down) {
                            finish( true, m_dir );
                        }
                    }
                    else if (m_dir == Left || m_dir == Right) {
                        finish( true, m_dir );
                    }
                } else {
                    Q_EMIT died();
                    hide();
                }
                break;
            case WALL:
                if (safeEdgeHit(hit.boundingRect)) {
                    finish();
                }
                break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBounceHit &hit : collision) {
        if ( hit.type == TILE || hit.type == WALL )
        {
            if ( hit.normal.x > 0 && m_velocity.x < 0 )
                m_reflectX = true;
            if ( hit.normal.x < 0 && m_velocity.x > 0 )
                m_reflectX = true;
            if ( hit.normal.y > 0 && m_velocity.y < 0 )
                m_reflectY = true;
            if ( hit.normal.y < 0 && m_velocity.y > 0 )
                m_reflectY = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
        ball->setRelativePos( 4 + QRandomGenerator::global()->bounded( TILE_NUM_W - 8 ),
                4 + QRandomGenerator::global()->bounded( TILE_NUM_H - 8 ) );

        ball->setVelocity( (QRandomGenerator::global()->bounded(2)*2-1)*m_ballVelocity,
                (QRandomGenerator::global()->bounded(2)*2-1)*m_ballVelocity );
        ball->setRandomFrame();
        ball->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)) {
        wall->hide();
        connect( wall, &KBounceWall::died, this, &KBounceBoard::wallDied );
        connect( wall, &KBounceWall::finished, this, &KBounceBoard::wallFinished );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : qAsConst(m_balls)) {
        int x1 = static_cast<int>( ball->ballBoundingRect().x() );
        int y1 = static_cast<int>( ball->ballBoundingRect().y() );
        int x2 = static_cast<int>( ball->ballBoundingRect().right() );
        int y2 = static_cast<int>( ball->ballBoundingRect().bottom() );
        // try to fill from all edges
        // this way we can avoid most precision-related issues
        fill(x1, y1);
        fill(x1, y2);
        fill(x2, y1);
        fill(x2, y2);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
        QRectF rect = ball->nextBoundingRect();
        KBounceCollision collision;
        collision = checkCollision( ball, rect, ALL );
        ball->collide( collision );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)){
        QRectF rect = wall->nextBoundingRect();
        KBounceCollision collision;
        collision = checkCollision( wall, rect, ALL );
        wall->collide( collision );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceBall* ball : std::as_const(m_balls)) {
        ball->setRelativePos( 4 + QRandomGenerator::global()->bounded( TILE_NUM_W - 8 ),
                4 + QRandomGenerator::global()->bounded( TILE_NUM_H - 8 ) );

        ball->setVelocity( (QRandomGenerator::global()->bounded(2)*2-1)*m_ballVelocity,
                (QRandomGenerator::global()->bounded(2)*2-1)*m_ballVelocity );
        ball->setRandomFrame();
        ball->show();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KBounceWall* wall : std::as_const(m_walls)) {
            if ( object != wall )
            {
                if ( wall->isVisible() && rect.intersects( wall->nextBoundingRect() ) )
                {
                    KBounceHit hit;
                    hit.type = WALL;
                    hit.boundingRect = wall->nextBoundingRect();
                    hit.normal = KBounceVector::normal( rect, hit.boundingRect );
                    result += hit;
                }
            }
        }
```

