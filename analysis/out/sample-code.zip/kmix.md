#### RANGE FOR STATEMENT 


```{c}
for (QAbstractSlider *slider : ref_sliders)
	{
		slider->setVisible(!m_linked || first); // One slider (the 1st) is always shown

		const VolumeSlider *vs = qobject_cast<VolumeSlider *>(slider);
		// cesken: Not including "|| first" in the check below because the text would
		// not look nice:  it would show "Left" or "Capture Left", while it should
		// be "Playback" and "Capture" in the "linked" case.
		//
		// But the only affected situation is when we have playback AND capture on
		// the same control, where we show no label.  It would be nice to at least
		// put a "Capture" label on the capture subcontrol instead.  To achieve this
		// we would need to change the text on the first capture subcontrol dynamically.
		// This can be done, but I'll leave this open for now.
		if (vs!=nullptr) vs->subControlLabel()->setVisible(!m_linked && showSubcontrolLabels);

		first = false;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[=](){ emit unplugged(alsaUDI); }
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : *this)
   {
       if ( md->read( config, grp ) )
           have_success = true;
       else
           have_fail = true;
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProfControl *pControl : qAsConst(guiProfile()->getControls()))
	{
		QRegExp idRegExp(pControl->id());
		if ( mdwId.contains(idRegExp) )
		{
			if (pControl->satisfiesVisibility(visibility))
			{
//				qCDebug(KMIX_LOG) << "  MATCH " << (*pControl).id << " for " << mdwId << " with visibility " << pControl->getVisibility().getId() << " to " << visibility.getId();
				return pControl;
			}
			else
			{
//				qCDebug(KMIX_LOG) << "NOMATCH " << (*pControl).id << " for " << mdwId << " with visibility " << pControl->getVisibility().getId() << " to " << visibility.getId();
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(volumePlayback.getVolumes()))
      {
               int ret = 0;
               switch(vc.chid)
               {
                   case Volume::LEFT         : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_FRONT_LEFT  , vc.volume); break;
                   case Volume::RIGHT        : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_FRONT_RIGHT , vc.volume); break;
                   case Volume::CENTER       : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_FRONT_CENTER, vc.volume); break;
                   case Volume::SURROUNDLEFT : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_REAR_LEFT   , vc.volume); break;
                   case Volume::SURROUNDRIGHT: ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_REAR_RIGHT  , vc.volume); break;
                   case Volume::REARCENTER   : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_REAR_CENTER , vc.volume); break;
                   case Volume::WOOFER       : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_WOOFER      , vc.volume); break;
                   case Volume::REARSIDELEFT : ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_SIDE_LEFT   , vc.volume); break;
                   case Volume::REARSIDERIGHT: ret = snd_mixer_selem_set_playback_volume( elem, SND_MIXER_SCHN_SIDE_RIGHT  , vc.volume); break;
                   default: qCDebug(KMIX_LOG) << "FATAL: Unknown channel type for playback << " << vc.chid << " ... please report this";  break;
              }
              if ( ret != 0 )
            	  qCDebug(KMIX_LOG) << "writeVolumeToHW(" << devnum << ") [set_playback_volume] failed, errno=" << ret;
              //if (id== "Master:0" || id== "PCM:0" ) { qCDebug(KMIX_LOG) << "volumePlayback control=" << id << ", chid=" << vc.chid << ", vol=" << vc.volume; }
          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(_mixers))
	{
		if (mixer->isDynamic()) return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : qAsConst(s_mixers))
    {
        if (mixer!=nullptr && mixer->id()==_globalMasterCurrent.getCard())
            return mixer;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ adjustControlsLayout(); }
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(QIcon::fromTheme(md->iconName()), mdName, m_channelSelector);
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : vols)
	{						// for all channels of this device
		//qCDebug(KMIX_LOG) << "Add label to " << vc.chid << ": " <<  Volume::channelNameReadable(vc.chid);
		QWidget *subcontrolLabel;

		QString subcontrolTranslation;
		if ( type == 'c' ) subcontrolTranslation += i18n("Capture") + ' ';
		subcontrolTranslation += Volume::channelNameReadable(vc.chid);
		subcontrolLabel = createLabel(this, subcontrolTranslation, orientation(), true);
		volLayout->addWidget(subcontrolLabel);

		VolumeSlider *slider = new VolumeSlider(orientation(), this);
		slider->setMinimum(minvol);
		slider->setMaximum(maxvol);

		// Set the slider page step to be the same as the configured volume step.
		// If that volume step is the minimum possible value (1), then set it
		// to 2 so that it is bigger than the single step.
		int pageStep = vol.volumeStep(false);
		if (pageStep==1) pageStep = 2;
		slider->setPageStep(pageStep);
		// Don't show too many tick marks if the page step is small.
		if (pageStep<10) slider->setTickInterval(qRound((maxvol-minvol)/10.0));

		slider->setValue(vol.getVolume(vc.chid));
		volumeValues.push_back(vol.getVolume(vc.chid));

		if (orientation()==Qt::Vertical) slider->setMinimumHeight(minSliderSize);
		else slider->setMinimumWidth(minSliderSize);
		if ( !profileControl()->getBackgroundColor().isEmpty() ) {
			slider->setStyleSheet("QSlider { background-color: " + profileControl()->getBackgroundColor() + " }");
		}

		slider->setSubControlLabel(subcontrolLabel);
		slider->setChannelId(vc.chid);

		if ( type == 'p' ) {
			slider->setToolTip( tooltipText );
		}
		else {
			QString captureTip( i18n( "%1 (capture)", tooltipText ) );
			slider->setToolTip( captureTip );
		}

		volLayout->addWidget( slider ); // add to layout
		ref_sliders.append ( slider ); // add to list

		connect( slider, SIGNAL(valueChanged(int)), SLOT(volumeChange(int)) );
		connect( slider, SIGNAL(sliderPressed()), SLOT(sliderPressed()) );
		connect( slider, SIGNAL(sliderReleased()), SLOT(sliderReleased()) );
		
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(volumePlayback.getVolumes()))
        {
               int ret = 0;
               switch(vc.chid) {
                   case Volume::LEFT         : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_FRONT_LEFT  , &vol); break;
                   case Volume::RIGHT        : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_FRONT_RIGHT , &vol); break;
                   case Volume::CENTER       : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_FRONT_CENTER, &vol); break;
                   case Volume::SURROUNDLEFT : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_REAR_LEFT   , &vol); break;
                   case Volume::SURROUNDRIGHT: ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_REAR_RIGHT  , &vol); break;
                   case Volume::REARCENTER   : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_REAR_CENTER , &vol); break;
                   case Volume::WOOFER       : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_WOOFER      , &vol); break;
                   case Volume::REARSIDELEFT : ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_SIDE_LEFT   , &vol); break;
                   case Volume::REARSIDERIGHT: ret = snd_mixer_selem_get_playback_volume( elem, SND_MIXER_SCHN_SIDE_RIGHT  , &vol); break;
                   default: qCDebug(KMIX_LOG) << "FATAL: Unknown channel type for playback << " << vc.chid << " ... please report this";  break;
              }
              if ( ret != 0 )
		qCDebug(KMIX_LOG) << "readVolumeFromHW(" << devnum << ") [get_playback_volume] failed, errno=" << ret;
              else
		volumePlayback.setVolume( vc.chid, vol);
              //if (id== "Master:0" || id== "PCM:0" ) { qCDebug(KMIX_LOG) << "volumePlayback control=" << id << ", chid=" << i << ", vol=" << vol; }
       }
```

#### AUTO 


```{c}
auto *visualLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> md : qAsConst(mixer->_mixerBackend->m_mixDevices))
	{
		if (!md) continue; // invalid

		firstDevice=md;
		if ( md->id() == _globalMasterCurrent.getControl() )
		{
			mdRet = md;
			break; // found
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &busDestination : qAsConst(replyValues))
	{
		if ( busDestination.startsWith(QLatin1String("org.mpris.MediaPlayer2")) )
		{
			addMprisControlAsync(busDestination);
			qCDebug(KMIX_LOG) << "MPRIS2: Attached media player on busDestination=" << busDestination;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QToolTip::showText(QCursor::pos(), xi18nc("@info:tooltip",
"<para>Here you can select the master sound device (if there is more than one) and its master channel.</para>"
"<para>The master channel is the one that is affected by the system tray volume control, "
"the volume up/down and mute global shortcut keys, "
"and the <interface>Mute</interface> action in the system tray popup menu.</para>"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profileId : qAsConst(profileList))
			{
				// This handles the profileList form the kmixrc
				qCDebug(KMIX_LOG) << "Searching for GUI profile" << profileId;
				GUIProfile* guiprof = GUIProfile::find(mixer, profileId, true, false);// ### Card specific profile ###

				if (guiprof==nullptr)
				{
					qCWarning(KMIX_LOG) << "Cannot load profile" << profileId;
					if (profileId.startsWith(QLatin1String("MPRIS2.")))
					{
						const QString fallbackProfileId = "MPRIS2.default";
						qCDebug(KMIX_LOG) << "For MPRIS2 falling back to" << fallbackProfileId;
						guiprof = GUIProfile::find(mixer, fallbackProfileId, true, false);
					}
				}

				if (guiprof!=nullptr)
				{
					addMixerWidget(mixer->id(), guiprof->getId(), -1);
					atLeastOneProfileWasAdded = true;
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(Mixer::mixers()))
	{
            // TODO: No point in showing mixers which do not have any volume controls.
            // See checks done in ViewDockAreaPopup::initLayout()

            QListWidgetItem *item = new QListWidgetItem(m_mixerList);
            item->setText(mixer->readableName(true));
            item->setSizeHint(QSize(1, 16));
            item->setIcon(QIcon::fromTheme(mixer->iconName()));
            item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsUserCheckable|Qt::ItemNeverHasChildren);
            item->setData(Qt::UserRole, mixer->id());

            const bool mixerShouldBeShown = !hasMixerFilter || mixerIds.contains(mixer->id());
            item->setCheckState(mixerShouldBeShown ? Qt::Checked : Qt::Unchecked);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *qmdw : std::as_const(view->_mdws))
		{
			MixDeviceWidget *mdw = qobject_cast<MixDeviceWidget *>(qmdw);
			if (mdw!=nullptr)
			{
				shared_ptr<MixDevice> md = mdw->mixDevice();
				QString devgrp = md->configGroupName(grp);
				KConfigGroup devcg = config->group(devgrp);

				if (mdw->inherits("MDWSlider"))
				{
					// only sliders have the ability to split apart in multiple channels
					bool splitChannels = devcg.readEntry("Split", !mdw->isStereoLinked());
					mdw->setStereoLinked(!splitChannels);
				}

				// Future directions: "Visibility" is very dirty: It is read from either config file or
				// GUIProfile. Thus we have a lot of doubled mdw visibility code all throughout KMix.
				bool mdwEnabled = false;

				// Consult GuiProfile for visibility
				mdwEnabled = findMdw(mdw->mixDevice()->id(), guiCompl) != 0; // Match GUI complexity
//				qCWarning(KMIX_LOG) << "---------- FIRST RUN: md=" << md->id() << ", guiVisibility=" << guiCompl.getId() << ", enabled=" << mdwEnabled;

				if (mdwEnabled)
				{
					atLeastOneControlIsShown = true;
				}
				mdw->setVisible(mdwEnabled);
			} // inherits MixDeviceWidget
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(vol.getVolumes()))
                {
                    long volOld = 0;
                    long volNew = 0;
                    switch (vc.chid) {
                    case Volume::LEFT:
                        volOld = vol.getVolume(Volume::LEFT);
                        volNew = volLeft;
                        vol.setVolume(Volume::LEFT, volNew);
                        break;
                    case Volume::RIGHT:
                        volOld = vol.getVolume(Volume::RIGHT);
                        volNew = volRight;
                        vol.setVolume(Volume::RIGHT, volNew);
                        break;
                    default:
                        // not supported by OSSv3
                        break;
                    }

                    if (volOld != volNew) {
                        controlChanged = true;
                        // if ( md->id() == "0" ) qCDebug(KMIX_LOG) << "changed";
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : getMixers())
		{
			const MixSet &mixset = mixer->getMixSet();

			foreach (ProfControl *control, guiprof->getControls())
			{
				// The TabName of the control matches this View name (!! attention: Better use some ID, due to i18n() )
				QRegExp idRegexp(control->id());
				// The following for-loop could be simplified by using a std::find_if
				for (int i = 0; i<mixset.count(); ++i)
				{
					const shared_ptr<MixDevice> md = mixset[i];

					if (md->id().contains(idRegexp))
					{		// match found (by name)
						if (getMixSet().contains(md))
						{	// check for duplicate already
							continue;
						}

						// Now check whether subcontrols required
						const bool subcontrolPlaybackWanted = (control->useSubcontrolPlayback() && (md->playbackVolume().hasVolume() || md->hasMuteSwitch()));
						const bool subcontrolCaptureWanted = (control->useSubcontrolCapture() && (md->captureVolume().hasVolume() || md->captureVolume().hasSwitch()));
						const bool subcontrolEnumWanted = (control->useSubcontrolEnum() && md->isEnum());
						const bool subcontrolWanted = subcontrolPlaybackWanted || subcontrolCaptureWanted || subcontrolEnumWanted;
						if (!subcontrolWanted) continue;

						md->setControlProfile(control);
						if (!control->name().isNull())
						{
							// Apply the custom name from the profile
							// TODO:  This is the wrong place.  It only
							// applies to controls in THIS type of view.
							md->setReadableName(control->name());
						}
						if (!control->getSwitchtype().isNull())
						{
							if (control->getSwitchtype()=="On")
								md->playbackVolume().setSwitchType(Volume::OnSwitch);
							else if (control->getSwitchtype()=="Off")
								md->playbackVolume().setSwitchType(Volume::OffSwitch);
						}
						addToMixSet(md);

#ifdef TEST_MIXDEVICE_COMPOSITE
						if ( md->id() == "Front:0" || md->id() == "Surround:0")
						{	// For temporary test
							mds.append(md);
						}
#endif
						// No 'break' here, because multiple devices could match
						// the regexp (e.g. "^.*$")
					}		// name matches
				}			// loop for finding a suitable MixDevice
			}				// iteration over all controls from the Profile
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfControl *profControl : qAsConst(getControls()))
   {
      //  <control
      writer.writeStartElement("control");
      //    id=			profControl->id()
      writer.writeAttribute("id", profControl->id());
      //    name=		profControl->name()
      const QString name = profControl->name();
      if (!name.isEmpty() && name!=profControl->id()) writer.writeAttribute("name", name);
      //    subcontrols=	profControl->renderSubcontrols()
      writer.writeAttribute("subcontrols", profControl->renderSubcontrols());
      //    show=		visibilityToString(profControl->getVisibility())
      writer.writeAttribute("show", visibilityToString(profControl->getVisibility()));
      //    mandatory=		"true"
      if (profControl->isMandatory()) writer.writeAttribute("mandatory", "true");
      //    split=		"true"
      if (profControl->isSplit())  writer.writeAttribute("split", "true");
      //  />
      writer.writeEndElement();
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> &md : *ms)
    {
	act = new QAction(QIcon::fromTheme(md->iconName()), md->readableName(), m_moveMenu);
	act->setData(md->id());
	act->setCheckable(true);
	if (md->id()==cur) act->setChecked(true);
	connect(act, &QAction::triggered, this, &MDWSlider::moveStream, Qt::QueuedConnection);
	m_moveMenu->addAction(act);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : std::as_const(Mixer::mixers())) result.append(mixer->dbusPath());
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            callback(a, reinterpret_cast<pa_defer_event *>(timer), userdata);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(Mixer::mixers()))
	{
		mixerViews[mixer->id()];		// just insert a map entry
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : qAsConst(Mixer::mixers()))
	{
		bool useMixer = preferredMixersForSoundmenu.isEmpty() || preferredMixersForSoundmenu.contains(mixer->id());
		if (useMixer) addMixer(mixer);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const GUIProfile *guiprof : qAsConst(activeGuiProfiles))
	{
		const Mixer *mixer = Mixer::findMixer(guiprof->getMixerId());
		if (mixer==nullptr)
		{
			qCCritical(KMIX_LOG) << "MixerToolBox::find() hasn't found the Mixer for the profile " << guiprof->getId();
			continue;
		}
		mixerHasProfile[mixer] = true;

		KMixerWidget* kmw = findKMWforTab(guiprof->getId());
		if ( kmw == 0 )
		{
			// does not yet exist => create
			addMixerWidget(mixer->id(), guiprof->getId(), -1);
		}
		else
		{
			// did exist => remove and insert new guiprof at old position
			int indexOfTab = m_wsMixers->indexOf(kmw);
			if ( indexOfTab != -1 ) m_wsMixers->removeTab(indexOfTab);
			delete kmw;
			addMixerWidget(mixer->id(), guiprof->getId(), indexOfTab);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(Mixer::mixers()))
	{
		if ( mixerHasProfile.contains(mixer))
		{
			continue;  // OK, this mixer already has a profile => skip it
		}


		// =========================================================================================
		// No TAB YET => This should mean KMix is just started, or the user has just plugged in a card

		{
			GUIProfile* guiprof = 0;
			if (reset)
			{
				guiprof = GUIProfile::find(mixer, QString("default"), false, true); // ### Card unspecific profile ###
			}

			if ( guiprof != 0 )
			{
				guiprof->setDirty();  // All fallback => dirty
				addMixerWidget(mixer->id(), guiprof->getId(), -1);
				continue;
			}
		}


		// =========================================================================================
		// The trivial cases have not added anything => Look at [Profiles] in config file

		QStringList	profileList = pconfig.readEntry( mixer->id(), QStringList() );
		bool allProfilesRemovedByUser = pconfig.hasKey(mixer->id()) && profileList.isEmpty();
		if (allProfilesRemovedByUser)
		{
			continue; // User has explicitly hidden the views => do no further checks
		}

		{
			bool atLeastOneProfileWasAdded = false;

			for (const QString &profileId : qAsConst(profileList))
			{
				// This handles the profileList form the kmixrc
				qCDebug(KMIX_LOG) << "Searching for GUI profile" << profileId;
				GUIProfile* guiprof = GUIProfile::find(mixer, profileId, true, false);// ### Card specific profile ###

				if (guiprof==nullptr)
				{
					qCWarning(KMIX_LOG) << "Cannot load profile" << profileId;
					if (profileId.startsWith(QLatin1String("MPRIS2.")))
					{
						const QString fallbackProfileId = "MPRIS2.default";
						qCDebug(KMIX_LOG) << "For MPRIS2 falling back to" << fallbackProfileId;
						guiprof = GUIProfile::find(mixer, fallbackProfileId, true, false);
					}
				}

				if (guiprof!=nullptr)
				{
					addMixerWidget(mixer->id(), guiprof->getId(), -1);
					atLeastOneProfileWasAdded = true;
				}
			}

			if (atLeastOneProfileWasAdded)
			{
				// Continue
				continue;
			}
		}

		// =========================================================================================
		// Neither trivial cases have added something, nor the anything => Look at [Profiles] in config file

		// The we_need_a_fallback case is a bit tricky. Please ask the author (cesken) before even considering to change the code.
		bool mixerIdMatch = mixerId.isEmpty() || (mixer->id() == mixerId);
		bool thisMixerShouldBeForced = forceNewTab && mixerIdMatch;
		bool we_need_a_fallback = mixerIdMatch && thisMixerShouldBeForced;
		if ( we_need_a_fallback )
		{
			// The profileList was empty or nothing could be loaded
			//     (Hint: This means the user cannot hide a device completely

			// Lets try a bunch of fallback strategies:
			qCDebug(KMIX_LOG) << "Attempting to find a card-specific GUI Profile for the mixer " << mixer->id();
			GUIProfile* guiprof = GUIProfile::find(mixer, QString("default"), false, false);// ### Card specific profile ###
			if ( guiprof == 0 )
			{
				qCDebug(KMIX_LOG) << "Not found. Attempting to find a generic GUI Profile for the mixer " << mixer->id();
				guiprof = GUIProfile::find(mixer, QString("default"), false, true); // ### Card unspecific profile ###
			}
			if ( guiprof == 0)
			{
				qCDebug(KMIX_LOG) << "Using fallback GUI Profile for the mixer " << mixer->id();
				// This means there is neither card specific nor card unspecific profile
				// This is the case for some backends (as they don't ship profiles).
				guiprof = GUIProfile::fallbackProfile(mixer);
			}

			if ( guiprof != 0 )
			{
				guiprof->setDirty();  // All fallback => dirty
				addMixerWidget(mixer->id(), guiprof->getId(), -1);
			}
			else
			{
				qCCritical(KMIX_LOG) << "Cannot use ANY profile (including Fallback) for mixer " << mixer->id() << " . This is impossible, and thus this mixer can NOT be used.";
			}

		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractSlider *slider1 : ref_sliders)
	{
		slider1->setVisible(!m_linked || first); // One slider (the 1st) is always shown
		extraData(slider1).getSubcontrolLabel()->setVisible(!m_linked && showSubcontrolLabels); // (*)
		first = false;
		/* (*) cesken: I have excluded the "|| first" check because the text would not be nice:
		 *     It would be "Left" or "Capture Left", while it should be "Playback" and "Capture" in the "linked" case.
		 *
		 *     But the only affected situation is when we have playback AND capture on the same control, where we show no label.
		 *     It would be nice to put at least a "Capture" label on the capture subcontrol instead.
		 *     To achieve this we would need to exchange the Text on the first capture subcontrol dynamically. This can
		 *     be done, but I'll leave this open for now.
		 */
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(_mixers))
	{
		if ( mixer->getDriverName() == "PulseAudio" ) return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : *this)
	{
		if ( md->id() == id )
		{
			mdRet = md;
			break;
		}
	}
```

#### AUTO 


```{c}
auto *ql = new QLabel(label, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> md : *ms)
    {
	act = new QAction(QIcon::fromTheme(md->iconName()), md->readableName(), m_moveMenu);
	act->setData(md->id());
	act->setCheckable(true);
	if (md->id()==cur) act->setChecked(true);
	connect(act, &QAction::triggered, this, &MDWSlider::moveStream, Qt::QueuedConnection);
	m_moveMenu->addAction(act);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                                {
                                    restoreRule &rule = s_RestoreRules[dev.stream_restore_rule];
                                    pa_ext_stream_restore_info info;
                                    info.name = dev.stream_restore_rule.toUtf8().constData();
                                    info.channel_map = rule.channel_map;
                                    info.volume = genVolumeForPulse(dev, md->playbackVolume());
                                    info.device = rule.device.isEmpty() ? NULL : rule.device.toUtf8().constData();
                                    info.mute = (md->isMuted() ? 1 : 0);

                                    pa_operation *op = pa_ext_stream_restore_write(s_context, PA_UPDATE_REPLACE, &info, 1, true, NULL, NULL);
                                    if (!checkOpResult(op, "pa_ext_stream_restore_write")) return (Mixer::ERR_WRITE);

                                    return (Mixer::OK);
                                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : getMixers())
		{
			const MixSet &mixset = mixer->getMixSet();

			for (ProfControl *control : std::as_const(guiprof->getControls()))
			{
				// The TabName of the control matches this View name (!! attention: Better use some ID, due to i18n() )
				QRegExp idRegexp(control->id());
				// The following for-loop could be simplified by using a std::find_if
				for (int i = 0; i<mixset.count(); ++i)
				{
					const shared_ptr<MixDevice> md = mixset[i];

					if (md->id().contains(idRegexp))
					{		// match found (by name)
						if (getMixSet().contains(md))
						{	// check for duplicate already
							continue;
						}

						// Now check whether subcontrols required
						const bool subcontrolPlaybackWanted = (control->useSubcontrolPlayback() && (md->playbackVolume().hasVolume() || md->hasMuteSwitch()));
						const bool subcontrolCaptureWanted = (control->useSubcontrolCapture() && (md->captureVolume().hasVolume() || md->captureVolume().hasSwitch()));
						const bool subcontrolEnumWanted = (control->useSubcontrolEnum() && md->isEnum());
						const bool subcontrolWanted = subcontrolPlaybackWanted || subcontrolCaptureWanted || subcontrolEnumWanted;
						if (!subcontrolWanted) continue;

						md->setControlProfile(control);
						if (!control->name().isNull())
						{
							// Apply the custom name from the profile
							// TODO:  This is the wrong place.  It only
							// applies to controls in THIS type of view.
							md->setReadableName(control->name());
						}
						if (!control->getSwitchtype().isNull())
						{
							if (control->getSwitchtype()=="On")
								md->playbackVolume().setSwitchType(Volume::OnSwitch);
							else if (control->getSwitchtype()=="Off")
								md->playbackVolume().setSwitchType(Volume::OffSwitch);
						}
						addToMixSet(md);

#ifdef TEST_MIXDEVICE_COMPOSITE
						if ( md->id() == "Front:0" || md->id() == "Surround:0")
						{	// For temporary test
							mds.append(md);
						}
#endif
						// No 'break' here, because multiple devices could match
						// the regexp (e.g. "^.*$")
					}		// name matches
				}			// loop for finding a suitable MixDevice
			}				// iteration over all controls from the Profile
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : mdws)
    {
        MixDeviceWidget *mdw = qobject_cast<MixDeviceWidget *>(w);
        if (mdw!=nullptr) mdw->setIcons(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &controlPath : curmi->iface->controls())
		{
			createControlInfo( curmi->id, controlPath );
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : std::as_const(s_mixers))
    {
        if (mixer!=nullptr && mixer->id()==_globalMasterCurrent.getCard())
            return mixer;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractSlider *slider : m_slidersPlayback) {
                        slider->setAccessibleName(slider->toolTip()+ " (" +Volume::channelNameReadable(vols.first().chid)+')');
                        vols.pop_front();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfProduct *prd : qAsConst(_products))
   {
      //  <product
      writer.writeStartElement("product");
      //    vendor=		prd->vendor
      writer.writeAttribute("vendor", prd->vendor);
      //    name=		prd->productName
      writer.writeAttribute("name", prd->productName);
      //    release=		prd->productRelease
      if (!prd->productRelease.isEmpty()) writer.writeAttribute("release", prd->productRelease);
      //	 comment=	prd->comment
      if (!prd->comment.isEmpty()) writer.writeAttribute("comment", prd->comment);
      //  />
      writer.writeEndElement();
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : m_controls.values(mi->id))
			{
				m_controls.remove( mi->id, ci );
				removeSource( ci->mixerId + '/' + ci->id );
				delete ci->iface;
				delete ci;
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : std::as_const(Mixer::mixers()))
		{
			addMixer(mixer);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                            {
                                pa_cvolume volume = genVolumeForPulse(dev, md->playbackVolume());
                                pa_operation *op = pa_context_set_sink_volume_by_index(s_context, dev.index, &volume, NULL, NULL);
                                if (!checkOpResult(op,"pa_context_set_sink_volume_by_index")) return (Mixer::ERR_WRITE);

                                op = pa_context_set_sink_mute_by_index(s_context, dev.index, (md->isMuted() ? 1 : 0), NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_sink_mute_by_index")) return (Mixer::ERR_WRITE);
#ifdef HAVE_CANBERRA
                                if (s_ccontext!=nullptr && Mixer::getBeepOnVolumeChange())
                                {
                                    int playing = 0;
                                    // Note that '2' is simply an index we've picked.
                                    // It's mostly irrelevant.
                                    int cindex = 2;

                                    ca_context_playing(s_ccontext, cindex, &playing);

                                    // Note: Depending on how this is desired to work,
                                    // we may want to simply skip playing, or cancel the
                                    // currently playing sound and play our
                                    // new one... for now, let's do the latter.
                                    if (playing)
                                    {
                                        ca_context_cancel(s_ccontext, cindex);
                                        playing = 0;
                                    }

                                    if (playing==0)
                                    {
                                        char devnum[64];
                                        snprintf(devnum, sizeof(devnum), "%lu", (unsigned long) dev.index);
                                        ca_context_change_device(s_ccontext, devnum);

                                        // Ideally we'd use something like ca_gtk_play_for_widget()...
                                        ca_context_play(
                                            s_ccontext,
                                            cindex,
                                            CA_PROP_EVENT_DESCRIPTION, i18n("Volume Control Feedback Sound").toUtf8().constData(),
                                            CA_PROP_EVENT_ID, "audio-volume-change",
                                            CA_PROP_CANBERRA_CACHE_CONTROL, "permanent",
                                            CA_PROP_CANBERRA_ENABLE, "1",
                                            NULL);

                                        ca_context_change_device(s_ccontext, NULL);
                                    }
                                }
#endif // HAVE_CANBERRA
                                return (Mixer::OK);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &busDestination : std::as_const(replyValues))
	{
		if ( busDestination.startsWith(QLatin1String("org.mpris.MediaPlayer2")) )
		{
			addMprisControlAsync(busDestination);
			qCDebug(KMIX_LOG) << "MPRIS2: Attached media player on busDestination=" << busDestination;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfControl *control : qAsConst(oldCtlSet))
        {
            //qCDebug(KMIX_LOG) << " checking " << control->id;
            QRegExp idRegexp(control->id());
            if ( ctlId.contains(idRegexp) ) {
                // found. Create a copy
                ProfControl* newCtl = new ProfControl(*control);
                newCtl->setId('^' + ctlId + '$'); // Replace the (possible generic) regexp by the actual ID
                // We have made this an an actual control. As it is derived (from e.g. ".*") it is NOT mandatory.
                newCtl->setMandatory(false);
                newCtl->setVisible(isActiveView);
                newCtlSet.push_back(newCtl);
//                 qCDebug(KMIX_LOG) << "Added to new ControlSet (done): " << newCtl->id;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(getMixers()))
	{
		for (shared_ptr<MixDevice> md : std::as_const(mixer->getMixSet()))
		{
			if (md->isApplicationStream()) addToMixSet(md);
		}
	}
```

#### AUTO 


```{c}
auto *buttonSpacer = new QToolButton();
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : *this)
   {
       if ( md->write( config, grp ) )
           have_success = true;
       else
           have_fail = true;
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(s_mixers))
    {
        if (mixer->isDynamic()) return (true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){ emit plugged("ALSA", alsaUDI, dev); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfControl *control : std::as_const(oldCtlSet))
        {
            //qCDebug(KMIX_LOG) << " checking " << control->id;
            QRegExp idRegexp(control->id());
            if ( ctlId.contains(idRegexp) ) {
                // found. Create a copy
                ProfControl* newCtl = new ProfControl(*control);
                newCtl->setId('^' + ctlId + '$'); // Replace the (possible generic) regexp by the actual ID
                // We have made this an an actual control. As it is derived (from e.g. ".*") it is NOT mandatory.
                newCtl->setMandatory(false);
                newCtl->setVisible(isActiveView);
                newCtlSet.push_back(newCtl);
//                 qCDebug(KMIX_LOG) << "Added to new ControlSet (done): " << newCtl->id;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(getMixers()))
	{
		//qCDebug(KMIX_LOG) << "ADD? mixerId=" << mixer->id();
		// Get the configured master control for the mixer.
		shared_ptr<MixDevice> dockMD = mixer->getLocalMasterMD();
		if (dockMD==nullptr && mixer->size()>0)
		{
			// If the mixer has no local master device defined,
			// then take its first available device.
			dockMD = mixer->getMixSet().first();
		}

		if (dockMD!=nullptr)			// have a master device to dock
		{
			// Do not add application streams here, they are handled below.
			if (dockMD->isApplicationStream()) continue;

			//qCDebug(KMIX_LOG) << "ADD? mixerId=" << mixer->id() << ", md=" << dockMD->id();
			if (dockMD->playbackVolume().hasVolume() || dockMD->captureVolume().hasVolume())
			{
				//qCDebug(KMIX_LOG) << "ADD? mixerId=" << mixer->id() << ", md=" << dockMD->id() << ": YES";
				addToMixSet(dockMD);
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                        {
                            setVolumeFromPulse(md->playbackVolume(), dev);
                            md->setMuted(dev.mute);			// to cover both playback
                            md->setRecSource(!dev.mute);		// and capture channels
                            return (0);
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &newName) {
			      qDebug() << "for" << mixDevice()->readableName() << "new icon" << newName;
			      ToggleToolButton::setIndicatorIcon(newName, m_controlIcon);
		      }
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : qAsConst(controlsForMixer)) ci->unused = true;
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : std::as_const(mixer->getMixSet()))
		{
			if (md->isApplicationStream()) addToMixSet(md);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(Mixer::mixers()))
	{
            // TODO: No point in showing mixers which do not have any volume controls.
            // See checks done in ViewDockAreaPopup::initLayout()

            QListWidgetItem *item = new QListWidgetItem(m_mixerList);
            item->setText(mixer->readableName(true));
            item->setSizeHint(QSize(1, 16));
            item->setIcon(QIcon::fromTheme(mixer->iconName()));
            item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsUserCheckable|Qt::ItemNeverHasChildren);
            item->setData(Qt::UserRole, mixer->id());

            const bool mixerShouldBeShown = !hasMixerFilter || mixerIds.contains(mixer->id());
            item->setCheckState(mixerShouldBeShown ? Qt::Checked : Qt::Unchecked);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfControl *pctl : qAsConst(oldControlset))
   {
       if ( pctl->isMandatory() ) {
           ProfControl* newCtl = new ProfControl(*pctl);
           // The user has selected controls => mandatory controls (RegExp templates) should not been shown any longer
           newCtl->setVisibility(GuiVisibility::Never);
           newControlset.push_back(newCtl);
       }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : std::as_const(m_mixDevices)) md->close();
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : qAsConst(Mixer::mixers()))
		{
			addMixer(mixer);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (ProfControl *control : qAsConst(guiprof->getControls()))
			{
				// The TabName of the control matches this View name (!! attention: Better use some ID, due to i18n() )
				QRegExp idRegexp(control->id());
				// The following for-loop could be simplified by using a std::find_if
				for (int i = 0; i<mixset.count(); ++i)
				{
					const shared_ptr<MixDevice> md = mixset[i];

					if (md->id().contains(idRegexp))
					{		// match found (by name)
						if (getMixSet().contains(md))
						{	// check for duplicate already
							continue;
						}

						// Now check whether subcontrols required
						const bool subcontrolPlaybackWanted = (control->useSubcontrolPlayback() && (md->playbackVolume().hasVolume() || md->hasMuteSwitch()));
						const bool subcontrolCaptureWanted = (control->useSubcontrolCapture() && (md->captureVolume().hasVolume() || md->captureVolume().hasSwitch()));
						const bool subcontrolEnumWanted = (control->useSubcontrolEnum() && md->isEnum());
						const bool subcontrolWanted = subcontrolPlaybackWanted || subcontrolCaptureWanted || subcontrolEnumWanted;
						if (!subcontrolWanted) continue;

						md->setControlProfile(control);
						if (!control->name().isNull())
						{
							// Apply the custom name from the profile
							// TODO:  This is the wrong place.  It only
							// applies to controls in THIS type of view.
							md->setReadableName(control->name());
						}
						if (!control->getSwitchtype().isNull())
						{
							if (control->getSwitchtype()=="On")
								md->playbackVolume().setSwitchType(Volume::OnSwitch);
							else if (control->getSwitchtype()=="Off")
								md->playbackVolume().setSwitchType(Volume::OffSwitch);
						}
						addToMixSet(md);

#ifdef TEST_MIXDEVICE_COMPOSITE
						if ( md->id() == "Front:0" || md->id() == "Surround:0")
						{	// For temporary test
							mds.append(md);
						}
#endif
						// No 'break' here, because multiple devices could match
						// the regexp (e.g. "^.*$")
					}		// name matches
				}			// loop for finding a suitable MixDevice
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (ProfControl *pControl : std::as_const(guiProfile()->getControls()))
	{
		QRegExp idRegExp(pControl->id());
		if ( mdwId.contains(idRegExp) )
		{
			if (pControl->satisfiesVisibility(visibility))
			{
//				qCDebug(KMIX_LOG) << "  MATCH " << (*pControl).id << " for " << mdwId << " with visibility " << pControl->getVisibility().getId() << " to " << visibility.getId();
				return pControl;
			}
			else
			{
//				qCDebug(KMIX_LOG) << "NOMATCH " << (*pControl).id << " for " << mdwId << " with visibility " << pControl->getVisibility().getId() << " to " << visibility.getId();
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(_mixers))
	{
		if ( mixer->getDriverName() == "PulseAudio" ) return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(Mixer::mixers()))
	{
		mixerViews[mixer->id()];		// just insert a map entry
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : iconNames)
    {
        if (!QIcon::hasThemeIcon(name)) continue;
        icon = QIcon::fromTheme(name);
        break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : qAsConst(controlsForMixer))
	{
		if ( ci->unused )
		{
			m_controls.remove( curmi->id, ci );
			delete ci->iface;
			delete ci;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : qAsConst(controlsForMixer))
		{
			if ( ci->dbusPath == controlPath )
			{
				curci = ci;
				break;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &profileId : std::as_const(profileList))
			{
				// This handles the profileList form the kmixrc
				qCDebug(KMIX_LOG) << "Searching for GUI profile" << profileId;
				GUIProfile* guiprof = GUIProfile::find(mixer, profileId, true, false);// ### Card specific profile ###

				if (guiprof==nullptr)
				{
					qCWarning(KMIX_LOG) << "Cannot load profile" << profileId;
					if (profileId.startsWith(QLatin1String("MPRIS2.")))
					{
						const QString fallbackProfileId = "MPRIS2.default";
						qCDebug(KMIX_LOG) << "For MPRIS2 falling back to" << fallbackProfileId;
						guiprof = GUIProfile::find(mixer, fallbackProfileId, true, false);
					}
				}

				if (guiprof!=nullptr)
				{
					addMixerWidget(mixer->id(), guiprof->getId(), -1);
					atLeastOneProfileWasAdded = true;
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> md : qAsConst(_mixSet))
    {
        QWidget *mdw = add(md);				// a) Let the implementation do its work
        _mdws.append(mdw);				// b) Add it to the local list
        connect(mdw, SIGNAL(guiVisibilityChange(MixDeviceWidget*,bool)), SLOT(guiVisibilitySlot(MixDeviceWidget*,bool)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> &md : std::as_const(_mixerBackend->m_mixDevices))
	{
		if (!md) continue; // invalid
		if (md->id()==mixdeviceID)
		{
			mdRet = md;
			break; // found
		}
	}
```

#### AUTO 


```{c}
auto *vt = new VerticalText(parent, label);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : mdws)
    {
        MixDeviceWidget *mdw = qobject_cast<MixDeviceWidget *>(w);
        if (mdw!=nullptr) mdw->setLabeled(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : std::as_const(sel))
    {
        from->takeItem(from->row(item));
        to->addItem(item);
        to->setCurrentItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &controlPath : curmi->iface->controls())
				createControlInfo( curmi->id, controlPath );
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item : qAsConst(sel))
    {
        from->takeItem(from->row(item));
        to->addItem(item);
        to->setCurrentItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ControlInfo *ci : m_controls.values(curmi->id))
	{
		if ( ci->iface->connection().isConnected() )
		{
			controlIds.append( ci->id );
			controlReadableNames.append( ci->iface->readableName() );
			controlIcons.append( ci->iface->iconName() );
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> &md : std::as_const(mixer->_mixerBackend->m_mixDevices))
	{
		if (!md) continue; // invalid

		firstDevice=md;
		if ( md->id() == _globalMasterCurrent.getControl() )
		{
			mdRet = md;
			break; // found
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : Mixer::mixers())
	{
            QListWidgetItem *item = new QListWidgetItem(m_mixerList);
            item->setText(mixer->readableName(true));
            item->setSizeHint(QSize(1, 16));
            item->setIcon(QIcon::fromTheme(mixer->iconName()));
            item->setFlags(Qt::ItemIsEnabled|Qt::ItemIsUserCheckable|Qt::ItemNeverHasChildren);
            item->setData(Qt::UserRole, mixer->id());

            const bool mixerShouldBeShown = !hasMixerFilter || mixerIds.contains(mixer->id());
            item->setCheckState(mixerShouldBeShown ? Qt::Checked : Qt::Unchecked);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            cb(a, reinterpret_cast<pa_io_event *>(wrapper), fd, PA_IO_EVENT_ERROR, userdata);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(getMixers()))
	{
		for (shared_ptr<MixDevice> md : qAsConst(mixer->getMixSet()))
		{
			if (md->isApplicationStream()) addToMixSet(md);
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                            {
                                pa_cvolume volume = genVolumeForPulse(dev, md->captureVolume());
                                pa_operation *op = pa_context_set_source_volume_by_index(s_context, dev.index, &volume, NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_source_volume_by_index")) return (Mixer::ERR_WRITE);

                                op = pa_context_set_source_mute_by_index(s_context, dev.index, (md->isRecSource() ? 0 : 1), NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_source_mute_by_index")) return (Mixer::ERR_WRITE);

                                return (Mixer::OK);
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            cb(a, reinterpret_cast<pa_io_event *>(wrapper), fd, PA_IO_EVENT_OUTPUT, userdata);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MixerInfo *mi : qAsConst(m_mixers))
	{
		if ( mi->id == mixerId )
		{
			if ( !mi->connected )
			{
				QDBusConnection::sessionBus().connect( KMIX_DBUS_SERVICE, mi->dbusPath,
						"org.kde.KMix.Mixer", "controlChanged",
						this, SLOT(slotControlChanged()) );
				mi->connected = true;
			}
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractSlider *slider : m_slidersCapture) {
                        slider->setAccessibleName(slider->toolTip()+ " (" +Volume::channelNameReadable(vols.first().chid)+')');
                        vols.pop_front();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : m_controls.values(mixerId))
	{
		if ( ci->id == controlId ) {
			curci = ci;
			break;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                            {
                                pa_cvolume volume = genVolumeForPulse(dev, md->playbackVolume());
                                pa_operation *op = pa_context_set_sink_volume_by_index(s_context, dev.index, &volume, NULL, NULL);
                                if (!checkOpResult(op,"pa_context_set_sink_volume_by_index")) return (Mixer::ERR_WRITE);

                                op = pa_context_set_sink_mute_by_index(s_context, dev.index, (md->isMuted() ? 1 : 0), NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_sink_mute_by_index")) return (Mixer::ERR_WRITE);
#ifdef HAVE_CANBERRA
                                if (s_ccontext!=nullptr && Mixer::getBeepOnVolumeChange())
                                {
                                    int playing = 0;
                                    // Note that '2' is simply an index we've picked.
                                    // It's mostly irrelevant.
                                    int cindex = 2;

                                    ca_context_playing(s_ccontext, cindex, &playing);

                                    // Note: Depending on how this is desired to work,
                                    // we may want to simply skip playing, or cancel the
                                    // currently playing sound and play our
                                    // new one... for now, let's do the latter.
                                    if (playing)
                                    {
                                        ca_context_cancel(s_ccontext, cindex);
                                        playing = 0;
                                    }

                                    if (playing==0)
                                    {
                                        const QByteArray devnum = QByteArray::number(dev.index);
                                        ca_context_change_device(s_ccontext, devnum.constData());

                                        // Ideally we'd use something like ca_gtk_play_for_widget()...
                                        ca_context_play(
                                            s_ccontext,
                                            cindex,
                                            CA_PROP_EVENT_DESCRIPTION, i18n("Volume Control Feedback Sound").toUtf8().constData(),
                                            CA_PROP_EVENT_ID, "audio-volume-change",
                                            CA_PROP_CANBERRA_CACHE_CONTROL, "permanent",
                                            CA_PROP_CANBERRA_ENABLE, "1",
                                            NULL);

                                        ca_context_change_device(s_ccontext, NULL);
                                    }
                                }
#endif // HAVE_CANBERRA
                                return (Mixer::OK);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> md : qAsConst(_mixerBackend->m_mixDevices))
	{
		if (!md) continue; // invalid
		if (md->id()==mixdeviceID)
		{
			mdRet = md;
			break; // found
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(vol.getVolumes()))
	{
		if ( !first )  os << ",";
		else first = false;
		os << vc.volume;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(s_mixers))
    {
        if (mixer->getDriverName()=="PulseAudio") return (true);
    }
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(QIcon::fromTheme("audio-volume-high"), mdName, m_channelSelector);
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> &md : std::as_const(_mixSet))
    {
        QWidget *mdw = add(md);				// a) Let the implementation do its work
        _mdws.append(mdw);				// b) Add it to the local list
        connect(mdw, SIGNAL(guiVisibilityChange(MixDeviceWidget*,bool)), SLOT(guiVisibilitySlot(MixDeviceWidget*,bool)));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            callback(a, reinterpret_cast<pa_time_event *>(timer), tv, userdata);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &newName) {
			      qCDebug(KMIX_LOG) << "for" << mixDevice()->readableName() << "new icon" << newName;
			      ToggleToolButton::setIndicatorIcon(newName, m_controlIcon);
		      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QWidget *qw : std::as_const(_mdws))
	{
		if (qw->isVisible())
			++ visibleCount;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (ProfControl *control : std::as_const(guiprof->getControls()))
			{
				// The TabName of the control matches this View name (!! attention: Better use some ID, due to i18n() )
				QRegExp idRegexp(control->id());
				// The following for-loop could be simplified by using a std::find_if
				for (int i = 0; i<mixset.count(); ++i)
				{
					const shared_ptr<MixDevice> md = mixset[i];

					if (md->id().contains(idRegexp))
					{		// match found (by name)
						if (getMixSet().contains(md))
						{	// check for duplicate already
							continue;
						}

						// Now check whether subcontrols required
						const bool subcontrolPlaybackWanted = (control->useSubcontrolPlayback() && (md->playbackVolume().hasVolume() || md->hasMuteSwitch()));
						const bool subcontrolCaptureWanted = (control->useSubcontrolCapture() && (md->captureVolume().hasVolume() || md->captureVolume().hasSwitch()));
						const bool subcontrolEnumWanted = (control->useSubcontrolEnum() && md->isEnum());
						const bool subcontrolWanted = subcontrolPlaybackWanted || subcontrolCaptureWanted || subcontrolEnumWanted;
						if (!subcontrolWanted) continue;

						md->setControlProfile(control);
						if (!control->name().isNull())
						{
							// Apply the custom name from the profile
							// TODO:  This is the wrong place.  It only
							// applies to controls in THIS type of view.
							md->setReadableName(control->name());
						}
						if (!control->getSwitchtype().isNull())
						{
							if (control->getSwitchtype()=="On")
								md->playbackVolume().setSwitchType(Volume::OnSwitch);
							else if (control->getSwitchtype()=="Off")
								md->playbackVolume().setSwitchType(Volume::OffSwitch);
						}
						addToMixSet(md);

#ifdef TEST_MIXDEVICE_COMPOSITE
						if ( md->id() == "Front:0" || md->id() == "Surround:0")
						{	// For temporary test
							mds.append(md);
						}
#endif
						// No 'break' here, because multiple devices could match
						// the regexp (e.g. "^.*$")
					}		// name matches
				}			// loop for finding a suitable MixDevice
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mixerPath : m_kmix->mixers())
	{
		MixerInfo* curmi = m_mixers.value( mixerPath, 0 );
		// if mixer was added, we need to add one to m_mixers
		// and add all controls for this mixer to m_controls
		if ( !curmi )
		{
			curmi = createMixerInfo( mixerPath );
			for (const QString &controlPath : curmi->iface->controls())
				createControlInfo( curmi->id, controlPath );
		}
		curmi->unused = false;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : std::as_const(m_mixDevices))
	{
	  //bool debugMe = (md->id() == "PCM:0" );
	  bool debugMe = false;
	  if (debugMe) qCDebug(KMIX_LOG) << "Old PCM:0 playback state" << md->isMuted()
	    << ", vol=" << md->playbackVolume().getAvgVolumePercent(Volume::MALL);
	    
		int retLoop = readVolumeFromHW( md->id(), md );
	  if (debugMe) qCDebug(KMIX_LOG) << "New PCM:0 playback state" << md->isMuted()
	    << ", vol=" << md->playbackVolume().getAvgVolumePercent(Volume::MALL);
		if (md->isEnum() )
		{
			/*
			 * This could be reworked:
			 * Plan: Read everything (including enum's) in readVolumeFromHW().
			 * readVolumeFromHW() should then be renamed to readHW().
			 */
			md->setEnumId( enumIdHW(md->id()) );
		}

		// Transition the outer return value with the value from this loop iteration
		if ( retLoop == Mixer::OK && ret == Mixer::OK_UNCHANGED )
		{
			// Unchanged => OK (Changed)
			ret = Mixer::OK;
		}
		else if ( retLoop != Mixer::OK && retLoop != Mixer::OK_UNCHANGED )
		{
			// If current ret from loop in not OK, then transition to that: ret (Something) => retLoop (Error)
			ret = retLoop;
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { settingChanged(KMixPrefDlg::ChangedGui); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfProduct *prd : std::as_const(_products))
   {
      //  <product
      writer.writeStartElement("product");
      //    vendor=		prd->vendor
      writer.writeAttribute("vendor", prd->vendor);
      //    name=		prd->productName
      writer.writeAttribute("name", prd->productName);
      //    release=		prd->productRelease
      if (!prd->productRelease.isEmpty()) writer.writeAttribute("release", prd->productRelease);
      //	 comment=	prd->comment
      if (!prd->comment.isEmpty()) writer.writeAttribute("comment", prd->comment);
      //  />
      writer.writeEndElement();
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> md : qAsConst(m_mixDevices))
        {
            bool isRecsrc =  isRecsrcHW( md->id() );
            // qCDebug(KMIX_LOG) << "Mixer::setRecordSource(): isRecsrcHW(" <<  md->id() << ") =" <<  isRecsrc;
            md->setRecSource( isRecsrc );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(s_mixers))
    {
        if (mixer->isDynamic()) return (true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *qmdw : qAsConst(view->_mdws))
		{
			MixDeviceWidget *mdw = qobject_cast<MixDeviceWidget *>(qmdw);
			if (mdw!=nullptr)
			{
				shared_ptr<MixDevice> md = mdw->mixDevice();
				QString devgrp = md->configGroupName(grp);
				KConfigGroup devcg = config->group(devgrp);

				if (mdw->inherits("MDWSlider"))
				{
					// only sliders have the ability to split apart in multiple channels
					bool splitChannels = devcg.readEntry("Split", !mdw->isStereoLinked());
					mdw->setStereoLinked(!splitChannels);
				}

				// Future directions: "Visibility" is very dirty: It is read from either config file or
				// GUIProfile. Thus we have a lot of doubled mdw visibility code all throughout KMix.
				bool mdwEnabled = false;

				// Consult GuiProfile for visibility
				mdwEnabled = findMdw(mdw->mixDevice()->id(), guiCompl) != 0; // Match GUI complexity
//				qCWarning(KMIX_LOG) << "---------- FIRST RUN: md=" << md->id() << ", guiVisibility=" << guiCompl.getId() << ", enabled=" << mdwEnabled;

				if (mdwEnabled)
				{
					atLeastOneControlIsShown = true;
				}
				mdw->setVisible(mdwEnabled);
			} // inherits MixDeviceWidget
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : vols)
	{						// for all channels of this device
		//qCDebug(KMIX_LOG) << "Add label to " << vc.chid << ": " <<  Volume::channelNameReadable(vc.chid);
		QWidget *subcontrolLabel;

		QString subcontrolTranslation;
		if ( type == 'c' ) subcontrolTranslation += i18n("Capture") + ' ';
		subcontrolTranslation += Volume::channelNameReadable(vc.chid);
		subcontrolLabel = createLabel(this, subcontrolTranslation, orientation(), true);
		volLayout->addWidget(subcontrolLabel);

		QAbstractSlider *slider;
		if (flags() & MixDeviceWidget::SmallSize)
		{
			slider = new KSmallSlider( minvol, maxvol, (maxvol-minvol+1) / Volume::VOLUME_PAGESTEP_DIVISOR,
						   vol.getVolume( vc.chid ), orientation(), this );
		} // small
		else  {
			slider = new VolumeSlider(orientation(), this);
			slider->setMinimum(minvol);
			slider->setMaximum(maxvol);
			slider->setPageStep(maxvol / Volume::VOLUME_PAGESTEP_DIVISOR);
			slider->setValue(  vol.getVolume( vc.chid ) );
			volumeValues.push_back( vol.getVolume( vc.chid ) );
			
			extraData(slider).setSubcontrolLabel(subcontrolLabel);

			if (orientation()==Qt::Vertical) slider->setMinimumHeight(minSliderSize);
			else slider->setMinimumWidth(minSliderSize);
			if ( !profileControl()->getBackgroundColor().isEmpty() ) {
				slider->setStyleSheet("QSlider { background-color: " + profileControl()->getBackgroundColor() + " }");
			}
		} // not small

		extraData(slider).setChid(vc.chid);
//		slider->installEventFilter( this );
		if ( type == 'p' ) {
			slider->setToolTip( tooltipText );
		}
		else {
			QString captureTip( i18n( "%1 (capture)", tooltipText ) );
			slider->setToolTip( captureTip );
		}

		volLayout->addWidget( slider ); // add to layout
		ref_sliders.append ( slider ); // add to list
		//ref_slidersChids.append(vc.chid);
		connect( slider, SIGNAL(valueChanged(int)), SLOT(volumeChange(int)) );
		connect( slider, SIGNAL(sliderPressed()), SLOT(sliderPressed()) );
		connect( slider, SIGNAL(sliderReleased()), SLOT(sliderReleased()) );
		
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : qAsConst(mixer->getMixSet()))
		{
			if (md->isApplicationStream()) addToMixSet(md);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                            {
#if HAVE_SOURCE_OUTPUT_VOLUMES
                                pa_cvolume volume = genVolumeForPulse(dev, md->captureVolume());
                                pa_operation *op = pa_context_set_source_output_volume(s_context, dev.index, &volume, NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_source_output_volume")) return (Mixer::ERR_WRITE);

                                op = pa_context_set_source_output_mute(s_context, dev.index, (md->isRecSource() ? 0 : 1), NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_source_output_mute")) return (Mixer::ERR_WRITE);
#else                
                                // Note that this is different from APP_PLAYBACK in that
                                // we set the volume on the source itself.
                                pa_cvolume volume = genVolumeForPulse(dev, md->captureVolume());
                                pa_operation *op = pa_context_set_source_volume_by_index(s_context, dev.device_index, &volume, NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_source_volume_by_index")) return (Mixer::ERR_WRITE);

                                op = pa_context_set_source_mute_by_index(s_context, dev.device_index, (md->isRecSource() ? 0 : 1), NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_source_mute_by_index")) return (Mixer::ERR_WRITE);
#endif
                                return (Mixer::OK);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(s_mixers))
    {
        if (mixer->getDriverName()=="PulseAudio") return (true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : std::as_const(Mixer::mixers()))
	{
		if ( mixerHasProfile.contains(mixer))
		{
			continue;  // OK, this mixer already has a profile => skip it
		}


		// =========================================================================================
		// No TAB YET => This should mean KMix is just started, or the user has just plugged in a card

		{
			GUIProfile* guiprof = 0;
			if (reset)
			{
				guiprof = GUIProfile::find(mixer, QString("default"), false, true); // ### Card unspecific profile ###
			}

			if ( guiprof != 0 )
			{
				guiprof->setDirty();  // All fallback => dirty
				addMixerWidget(mixer->id(), guiprof->getId(), -1);
				continue;
			}
		}


		// =========================================================================================
		// The trivial cases have not added anything => Look at [Profiles] in config file

		QStringList	profileList = pconfig.readEntry( mixer->id(), QStringList() );
		bool allProfilesRemovedByUser = pconfig.hasKey(mixer->id()) && profileList.isEmpty();
		if (allProfilesRemovedByUser)
		{
			continue; // User has explicitly hidden the views => do no further checks
		}

		{
			bool atLeastOneProfileWasAdded = false;

			for (const QString &profileId : std::as_const(profileList))
			{
				// This handles the profileList form the kmixrc
				qCDebug(KMIX_LOG) << "Searching for GUI profile" << profileId;
				GUIProfile* guiprof = GUIProfile::find(mixer, profileId, true, false);// ### Card specific profile ###

				if (guiprof==nullptr)
				{
					qCWarning(KMIX_LOG) << "Cannot load profile" << profileId;
					if (profileId.startsWith(QLatin1String("MPRIS2.")))
					{
						const QString fallbackProfileId = "MPRIS2.default";
						qCDebug(KMIX_LOG) << "For MPRIS2 falling back to" << fallbackProfileId;
						guiprof = GUIProfile::find(mixer, fallbackProfileId, true, false);
					}
				}

				if (guiprof!=nullptr)
				{
					addMixerWidget(mixer->id(), guiprof->getId(), -1);
					atLeastOneProfileWasAdded = true;
				}
			}

			if (atLeastOneProfileWasAdded)
			{
				// Continue
				continue;
			}
		}

		// =========================================================================================
		// Neither trivial cases have added something, nor the anything => Look at [Profiles] in config file

		// The we_need_a_fallback case is a bit tricky. Please ask the author (cesken) before even considering to change the code.
		bool mixerIdMatch = mixerId.isEmpty() || (mixer->id() == mixerId);
		bool thisMixerShouldBeForced = forceNewTab && mixerIdMatch;
		bool we_need_a_fallback = mixerIdMatch && thisMixerShouldBeForced;
		if ( we_need_a_fallback )
		{
			// The profileList was empty or nothing could be loaded
			//     (Hint: This means the user cannot hide a device completely

			// Lets try a bunch of fallback strategies:
			qCDebug(KMIX_LOG) << "Attempting to find a card-specific GUI Profile for the mixer " << mixer->id();
			GUIProfile* guiprof = GUIProfile::find(mixer, QString("default"), false, false);// ### Card specific profile ###
			if ( guiprof == 0 )
			{
				qCDebug(KMIX_LOG) << "Not found. Attempting to find a generic GUI Profile for the mixer " << mixer->id();
				guiprof = GUIProfile::find(mixer, QString("default"), false, true); // ### Card unspecific profile ###
			}
			if ( guiprof == 0)
			{
				qCDebug(KMIX_LOG) << "Using fallback GUI Profile for the mixer " << mixer->id();
				// This means there is neither card specific nor card unspecific profile
				// This is the case for some backends (as they don't ship profiles).
				guiprof = GUIProfile::fallbackProfile(mixer);
			}

			if ( guiprof != 0 )
			{
				guiprof->setDirty();  // All fallback => dirty
				addMixerWidget(mixer->id(), guiprof->getId(), -1);
			}
			else
			{
				qCCritical(KMIX_LOG) << "Cannot use ANY profile (including Fallback) for mixer " << mixer->id() << " . This is impossible, and thus this mixer can NOT be used.";
			}

		}
	}
```

#### AUTO 


```{c}
const auto toolBarIconSize = label->style()->pixelMetric(QStyle::PM_TabBarIconSize, nullptr, label);
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                            {
                                pa_cvolume volume = genVolumeForPulse(dev, md->playbackVolume());
                                pa_operation *op = pa_context_set_sink_volume_by_index(s_context, dev.index, &volume, NULL, NULL);
                                if (!checkOpResult(op,"pa_context_set_sink_volume_by_index")) return (Mixer::ERR_WRITE);

                                op = pa_context_set_sink_mute_by_index(s_context, dev.index, (md->isMuted() ? 1 : 0), NULL, NULL);
                                if (!checkOpResult(op, "pa_context_set_sink_mute_by_index")) return (Mixer::ERR_WRITE);

                                return (Mixer::OK);
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GUIProfile *guiprof : std::as_const(activeGuiProfiles))
	{
		const Mixer *mixer = Mixer::findMixer(guiprof->getMixerId());
		if (mixer==nullptr)
		{
			qCCritical(KMIX_LOG) << "MixerToolBox::find() hasn't found the Mixer for the profile " << guiprof->getId();
			continue;
		}
		mixerHasProfile[mixer] = true;

		KMixerWidget* kmw = findKMWforTab(guiprof->getId());
		if ( kmw == 0 )
		{
			// does not yet exist => create
			addMixerWidget(mixer->id(), guiprof->getId(), -1);
		}
		else
		{
			// did exist => remove and insert new guiprof at old position
			int indexOfTab = m_wsMixers->indexOf(kmw);
			if ( indexOfTab != -1 ) m_wsMixers->removeTab(indexOfTab);
			delete kmw;
			addMixerWidget(mixer->id(), guiprof->getId(), indexOfTab);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : qAsConst(Mixer::mixers())) result.append(mixer->dbusPath());
```

#### RANGE FOR STATEMENT 


```{c}
for (const MixerInfo *mi : qAsConst(m_mixers)) mixerIds.append(mi->id);
```

#### RANGE FOR STATEMENT 


```{c}
for (MixerInfo *mi : qAsConst(m_mixers)) mi->unused = true;
```

#### AUTO 


```{c}
auto *item = new DialogViewConfigurationItem(nullptr, devicePixelRatioF(), md->id(), true, mdName, splitted, mdw->mixDevice()->iconName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &controlPath : curmi->iface->controls())
	{
		ControlInfo* curci = 0;
		for (ControlInfo *ci : qAsConst(controlsForMixer))
		{
			if ( ci->dbusPath == controlPath )
			{
				curci = ci;
				break;
			}
		}

		// If control not found then we should add a new
		if ( !curci )
			curci = createControlInfo( curmi->id, controlPath );
		curci->unused = false;
		controlIds.append( curci->id );
		controlReadableNames.append( curci->iface->readableName() );
		controlIconNames.append( curci->iface->iconName() );
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { settingChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setFocus(Qt::OtherFocusReason); }
```

#### AUTO 


```{c}
auto *behaviorLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (MixerInfo *mi : qAsConst(m_mixers))
	{
		if ( mi->id == source )
		{
			curmi = mi;
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> &md : std::as_const(m_mixer->getMixSet()))
	{
		result.append( md->dbusPath() );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : m_controls.values(curmi->id))
	{
		if (ci->updateRequired) setControlData(ci);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(getMixers()))
	{
		//qCDebug(KMIX_LOG) << "ADD? mixerId=" << mixer->id();
		// Get the configured master control for the mixer.
		shared_ptr<MixDevice> dockMD = mixer->getLocalMasterMD();
		if (dockMD==nullptr && mixer->size()>0)
		{
			// If the mixer has no local master device defined,
			// then take its first available device.
			dockMD = mixer->getMixSet().first();
		}

		if (dockMD!=nullptr)			// have a master device to dock
		{
			// Do not add application streams here, they are handled below.
			if (dockMD->isApplicationStream()) continue;

			//qCDebug(KMIX_LOG) << "ADD? mixerId=" << mixer->id() << ", md=" << dockMD->id();
			if (dockMD->playbackVolume().hasVolume() || dockMD->captureVolume().hasVolume())
			{
				//qCDebug(KMIX_LOG) << "ADD? mixerId=" << mixer->id() << ", md=" << dockMD->id() << ": YES";
				addToMixSet(dockMD);
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            destructor(reinterpret_cast<pa_mainloop_api *>(timer->parent()), e, qvariant_cast<void *>(timer->property("PA_USERDATA")));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(volumeCapture.getVolumes()))
      {
               int ret = 0;
               switch(vc.chid) {
                   case Volume::LEFT         : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_FRONT_LEFT  , vc.volume); break;
                   case Volume::RIGHT        : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_FRONT_RIGHT , vc.volume); break;
                   case Volume::CENTER       : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_FRONT_CENTER, vc.volume); break;
                   case Volume::SURROUNDLEFT : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_REAR_LEFT   , vc.volume); break;
                   case Volume::SURROUNDRIGHT: ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_REAR_RIGHT  , vc.volume); break;
                   case Volume::REARCENTER   : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_REAR_CENTER , vc.volume); break;
                   case Volume::WOOFER       : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_WOOFER      , vc.volume); break;
                   case Volume::REARSIDELEFT : ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_SIDE_LEFT   , vc.volume); break;
                   case Volume::REARSIDERIGHT: ret = snd_mixer_selem_set_capture_volume( elem, SND_MIXER_SCHN_SIDE_RIGHT  , vc.volume); break;
                   default: qCDebug(KMIX_LOG) << "FATAL: Unknown channel type for capture << " << vc.chid << " ... please report this";  break;
              }
              if ( ret != 0 ) qCDebug(KMIX_LOG) << "writeVolumeToHW(" << devnum << ") [set_capture_volume] failed, errno=" << ret;
              //if (id== "Master:0" || id== "PCM:0" ) { qCDebug(KMIX_LOG) << "volumecapture control=" << id << ", chid=" << i << ", vol=" << vc.volume; }
          }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { settingChanged(KMixPrefDlg::ChangedControls); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : std::as_const(vol.getVolumes()))
	{
		if ( !first )  os << ",";
		else first = false;
		os << vc.volume;
	}
```

#### AUTO 


```{c}
auto *item = new DialogViewConfigurationItem(nullptr, md->id(), true, mdName, splitted, mdw->mixDevice()->iconName());
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : std::as_const(Mixer::mixers()))
	{
		bool useMixer = preferredMixersForSoundmenu.isEmpty() || preferredMixersForSoundmenu.contains(mixer->id());
		if (useMixer) addMixer(mixer);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QWidget *qw : qAsConst(_mdws))
	{
		if (qw->isVisible())
			++ visibleCount;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Mixer *mixer : Mixer::mixers())
	{
		addMixer(mixer);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfControl *pctl : std::as_const(oldControlset))
   {
       if ( pctl->isMandatory() ) {
           ProfControl* newCtl = new ProfControl(*pctl);
           // The user has selected controls => mandatory controls (RegExp templates) should not been shown any longer
           newCtl->setVisibility(GuiVisibility::Never);
           newControlset.push_back(newCtl);
       }
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (MixerInfo *mi : qAsConst(m_mixers))
	{
		if ( mi->unused )
		{
			for (ControlInfo *ci : m_controls.values(mi->id))
			{
				m_controls.remove( mi->id, ci );
				removeSource( ci->mixerId + '/' + ci->id );
				delete ci->iface;
				delete ci;
			}
			m_mixers.remove( mi->dbusPath );
			removeSource( mi->id );
			delete mi->iface;
			delete mi;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (ControlInfo *ci : qAsConst(m_controls))
	{
		if ( removeSources )
			removeSource( ci->mixerId + '/' + ci->id );
		delete ci->iface;
		delete ci;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { settingChanged(KMixPrefDlg::ChangedMaster); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(_volumesL))
	{
		if (channelMask[vc.chid] & chmask )
		{
			sumOfActiveVolumes += vc.volume;
			++avgVolumeCounter;
		}
	}
```

#### AUTO 


```{c}
const auto icon = QIcon::fromTheme(iconName);
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
            cb(a, reinterpret_cast<pa_io_event *>(wrapper), fd, PA_IO_EVENT_INPUT, userdata);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : volumes)
    {							// for all channels
        config.writeEntry(getVolString(vc.chid, capture), static_cast<int>(vc.volume));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : mdws)
    {
        MixDeviceWidget *mdw = qobject_cast<MixDeviceWidget *>(w);
        if (mdw!=nullptr) mdw->setTicks(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : qAsConst(volumeCapture.getVolumes()))
        {
               int ret = 0;
               switch(vc.chid) {
                   case Volume::LEFT         : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_FRONT_LEFT  , &vol); break;
                   case Volume::RIGHT        : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_FRONT_RIGHT , &vol); break;
                   case Volume::CENTER       : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_FRONT_CENTER, &vol); break;
                   case Volume::SURROUNDLEFT : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_REAR_LEFT   , &vol); break;
                   case Volume::SURROUNDRIGHT: ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_REAR_RIGHT  , &vol); break;
                   case Volume::REARCENTER   : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_REAR_CENTER , &vol); break;
                   case Volume::WOOFER       : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_WOOFER      , &vol); break;
                   case Volume::REARSIDELEFT : ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_SIDE_LEFT   , &vol); break;
                   case Volume::REARSIDERIGHT: ret = snd_mixer_selem_get_capture_volume( elem, SND_MIXER_SCHN_SIDE_RIGHT  , &vol);     break;
                   default: qCDebug(KMIX_LOG) << "FATAL: Unknown channel type for capture << " << vc.chid << " ... please report this";  break;
              }
              if ( ret != 0 )
            	  qCDebug(KMIX_LOG) << "readVolumeFromHW(" << devnum << ") [get_capture_volume] failed, errno=" << ret;
              else volumeCapture.setVolume( vc.chid, vol);
       }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : m_kmix->mixers())
	{
		const MixerInfo *curmi = createMixerInfo( path );
		for (const QString &controlPath : curmi->iface->controls())
		{
			createControlInfo( curmi->id, controlPath );
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProfControl *profControl : std::as_const(getControls()))
   {
      //  <control
      writer.writeStartElement("control");
      //    id=			profControl->id()
      writer.writeAttribute("id", profControl->id());
      //    name=		profControl->name()
      const QString name = profControl->name();
      if (!name.isEmpty() && name!=profControl->id()) writer.writeAttribute("name", name);
      //    subcontrols=	profControl->renderSubcontrols()
      writer.writeAttribute("subcontrols", profControl->renderSubcontrols());
      //    show=		visibilityToString(profControl->getVisibility())
      writer.writeAttribute("show", visibilityToString(profControl->getVisibility()));
      //    mandatory=		"true"
      if (profControl->isMandatory()) writer.writeAttribute("mandatory", "true");
      //    split=		"true"
      if (profControl->isSplit())  writer.writeAttribute("split", "true");
      //  />
      writer.writeEndElement();
   }
```

#### LAMBDA EXPRESSION 


```{c}
[](const devinfo &dev, shared_ptr<MixDevice> md) -> int
                                {
                                    pa_cvolume volume = genVolumeForPulse(dev, md->playbackVolume());
                                    pa_operation *op = pa_context_set_sink_input_volume(s_context, dev.index, &volume, NULL, NULL);
                                    if (!checkOpResult(op, "pa_context_set_sink_input_volume")) return (Mixer::ERR_WRITE);

                                    op = pa_context_set_sink_input_mute(s_context, dev.index, (md->isMuted() ? 1 : 0), NULL, NULL);
                                    if (!checkOpResult(op, "pa_context_set_sink_input_mute")) return (Mixer::ERR_WRITE);

                                    return (Mixer::OK);
                                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : vols)		// for all channels of this device
	{
		//qCDebug(KMIX_LOG) << "Add label to " << vc.chid << ": " <<  Volume::channelNameReadable(vc.chid);
		QWidget *subcontrolLabel;

		QString subcontrolTranslation;
		if ( type == 'c' ) subcontrolTranslation += i18n("Capture") + ' ';
		subcontrolTranslation += Volume::channelNameReadable(vc.chid);
		subcontrolLabel = createLabel(this, subcontrolTranslation, orientation(), true);
		volLayout->addWidget(subcontrolLabel);

		VolumeSlider *slider = new VolumeSlider(orientation(), this);
		slider->setMinimum(minvol);
		slider->setMaximum(maxvol);

		// Set the slider page step to be the same as the configured volume step.
		// If that volume step is the minimum possible value (1), then set it
		// to 2 so that it is bigger than the single step.
		const int pageStep = qMax(static_cast<int>(vol.volumeStep(false)), 2);
		slider->setPageStep(pageStep);

		// Need to set the single step too, because some devices have a substantial
		// range (e.g. PulseAudio always returns the range as from 0 to 65536).
		// Having the single step at the default setting (i.e. 1) makes key and
		// wheel events over the slider so slow that it appears not to be moving
		// (although it actually is).  See http://bugs.kde.org/show_bug.cgi?id=416405
		// for report.
		//
		// Since volume level is always displayed as a percentage, set the single
		// step to give an increment of 1% unless the range is <100 already.  This
		// will be subject to rounding unless the range is at least 200, but it's
		// the best that can be done.
		const int volRange = maxvol-minvol;
		if (volRange>100)
		{
			const int volStep = qMax(qRound(volRange/100.0), 1);
			slider->setSingleStep(volStep);
		}

		// Don't show too many tick marks if the page step is small.
		if (pageStep<10) slider->setTickInterval(qRound(volRange/10.0));

		slider->setValue(vol.getVolume(vc.chid));
		volumeValues.push_back(vol.getVolume(vc.chid));

		if (orientation()==Qt::Vertical) slider->setMinimumHeight(minSliderSize);
		else slider->setMinimumWidth(minSliderSize);
		if ( !profileControl()->getBackgroundColor().isEmpty() ) {
			slider->setStyleSheet("QSlider { background-color: " + profileControl()->getBackgroundColor() + " }");
		}

		slider->setSubControlLabel(subcontrolLabel);
		slider->setChannelId(vc.chid);

		if ( type == 'p' ) {
			slider->setToolTip( tooltipText );
		}
		else {
			QString captureTip( i18n( "%1 (capture)", tooltipText ) );
			slider->setToolTip( captureTip );
		}

		volLayout->addWidget( slider ); // add to layout
		ref_sliders.append ( slider ); // add to list

		connect(slider, &QAbstractSlider::valueChanged, this, &MDWSlider::volumeChange);
		// TODO: Could these two connections and the tracking of m_sliderInWork
		// be replaced by slider->isSliderDown()?
		connect(slider, &QAbstractSlider::sliderPressed, this, &MDWSlider::sliderPressed);
		connect(slider, &QAbstractSlider::sliderReleased, this, &MDWSlider::sliderReleased);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : getMixers())
		{
			const MixSet &mixset = mixer->getMixSet();

			for (ProfControl *control : qAsConst(guiprof->getControls()))
			{
				// The TabName of the control matches this View name (!! attention: Better use some ID, due to i18n() )
				QRegExp idRegexp(control->id());
				// The following for-loop could be simplified by using a std::find_if
				for (int i = 0; i<mixset.count(); ++i)
				{
					const shared_ptr<MixDevice> md = mixset[i];

					if (md->id().contains(idRegexp))
					{		// match found (by name)
						if (getMixSet().contains(md))
						{	// check for duplicate already
							continue;
						}

						// Now check whether subcontrols required
						const bool subcontrolPlaybackWanted = (control->useSubcontrolPlayback() && (md->playbackVolume().hasVolume() || md->hasMuteSwitch()));
						const bool subcontrolCaptureWanted = (control->useSubcontrolCapture() && (md->captureVolume().hasVolume() || md->captureVolume().hasSwitch()));
						const bool subcontrolEnumWanted = (control->useSubcontrolEnum() && md->isEnum());
						const bool subcontrolWanted = subcontrolPlaybackWanted || subcontrolCaptureWanted || subcontrolEnumWanted;
						if (!subcontrolWanted) continue;

						md->setControlProfile(control);
						if (!control->name().isNull())
						{
							// Apply the custom name from the profile
							// TODO:  This is the wrong place.  It only
							// applies to controls in THIS type of view.
							md->setReadableName(control->name());
						}
						if (!control->getSwitchtype().isNull())
						{
							if (control->getSwitchtype()=="On")
								md->playbackVolume().setSwitchType(Volume::OnSwitch);
							else if (control->getSwitchtype()=="Off")
								md->playbackVolume().setSwitchType(Volume::OffSwitch);
						}
						addToMixSet(md);

#ifdef TEST_MIXDEVICE_COMPOSITE
						if ( md->id() == "Front:0" || md->id() == "Surround:0")
						{	// For temporary test
							mds.append(md);
						}
#endif
						// No 'break' here, because multiple devices could match
						// the regexp (e.g. "^.*$")
					}		// name matches
				}			// loop for finding a suitable MixDevice
			}				// iteration over all controls from the Profile
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mixer *mixer : qAsConst(_mixers))
	{
		if (mixer->isDynamic()) return true;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const shared_ptr<MixDevice> md : qAsConst(m_mixer->getMixSet()))
	{
		result.append( md->dbusPath() );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (MixerInfo *mi : qAsConst(m_mixers))
	{
		if ( removeSources )
			removeSource( mi->id );
		delete mi->iface;
		delete mi;
	}
```

#### AUTO 


```{c}
const auto &name
```

#### RANGE FOR STATEMENT 


```{c}
for (const VolumeChannel &vc : std::as_const(_volumesL))
	{
		if (channelMask[vc.chid] & chmask )
		{
			sumOfActiveVolumes += vc.volume;
			++avgVolumeCounter;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : qAsConst(m_mixDevices))
	{
	  //bool debugMe = (md->id() == "PCM:0" );
	  bool debugMe = false;
	  if (debugMe) qCDebug(KMIX_LOG) << "Old PCM:0 playback state" << md->isMuted()
	    << ", vol=" << md->playbackVolume().getAvgVolumePercent(Volume::MALL);
	    
		int retLoop = readVolumeFromHW( md->id(), md );
	  if (debugMe) qCDebug(KMIX_LOG) << "New PCM:0 playback state" << md->isMuted()
	    << ", vol=" << md->playbackVolume().getAvgVolumePercent(Volume::MALL);
		if (md->isEnum() )
		{
			/*
			 * This could be reworked:
			 * Plan: Read everything (including enum's) in readVolumeFromHW().
			 * readVolumeFromHW() should then be renamed to readHW().
			 */
			md->setEnumId( enumIdHW(md->id()) );
		}

		// Transition the outer return value with the value from this loop iteration
		if ( retLoop == Mixer::OK && ret == Mixer::OK_UNCHANGED )
		{
			// Unchanged => OK (Changed)
			ret = Mixer::OK;
		}
		else if ( retLoop != Mixer::OK && retLoop != Mixer::OK_UNCHANGED )
		{
			// If current ret from loop in not OK, then transition to that: ret (Something) => retLoop (Error)
			ret = retLoop;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (shared_ptr<MixDevice> md : qAsConst(m_mixDevices)) md->close();
```

