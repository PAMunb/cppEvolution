#### RANGE FOR STATEMENT 


```{c}
for (const QString & file : fileNames) {
            tilesAvailable.append(dir + QLatin1Char('/') + file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString & file : fileNames) {
            bgsAvailable.append(dir + QLatin1Char('/') + file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & file : fileNames) {
            bgsAvailable.append(dir + QLatin1Char('/') + file);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*.desktop"));
        for (const QString & file : fileNames) {
            tilesAvailable.append(dir + QLatin1Char('/') + file);
        }
    }
```

