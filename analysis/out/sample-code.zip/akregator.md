#### AUTO 


```{c}
auto *const folder = qobject_cast<Akregator::Folder *>(node);
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : std::as_const(m_children)) {
        const auto f = i->folders();
        for (const Folder *j : f) {
            foldersById.insert(j->id(), j);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : std::as_const(m_articles)) {
        if (i.isDeleted()) {
            continue;
        }

        auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
            return !matcher->matches(i);
        };
        if (std::find_if(m_filters.cbegin(), filterEnd, func) != filterEnd) {
            continue;
        }
        articles << i;
        ++num;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : f) {
        job->addSubjob(i->createMarkAsReadJob());
    }
```

#### AUTO 


```{c}
const auto *src = (const t4_byte *)_segments.GetAt(fSegIndex(from_));
```

#### AUTO 


```{c}
auto *cmd = new ExpireItemsCommand(this);
```

#### AUTO 


```{c}
const auto children = m_children;
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : qAsConst(d->children)) {
        Q_FOREACH (Folder *j, i->folders()) {
            foldersById.insert(j->id(), j);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : std::as_const(m_children)) {
        const auto f = i->feeds();
        for (const Akregator::Feed *j : f) {
            feedsById.insert(j->id(), j);
        }
    }
```

#### AUTO 


```{c}
auto v = (float)value_;
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *const candidate : namedGroups) {
        if (candidate->isGroup()) {
            group = static_cast<Folder *>(candidate);
            break;
        }
    }
```

#### AUTO 


```{c}
auto *const fld = qobject_cast<Folder *>(child);
```

#### AUTO 


```{c}
auto *h1 = (c4_HandlerSeq *)s1->HandlerContext(0);
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url, KIO::NoReload, KIO::HideProgressInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *const child : childs) {
        if (child->title() == title) {
            nodeList.append(child);
        }
        auto const fld = qobject_cast<Folder *>(child);
        if (fld) {
            nodeList += fld->namedChildren(title);
        }
    }
```

#### AUTO 


```{c}
auto *articleObj = new ArticleGrantleeObject(article.at(i), icon);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : qAsConst(m_children)) {
        children.append(i);
    }
```

#### AUTO 


```{c}
auto act = new QAction(mHashStatus.value(status).mIcon, mHashStatus.value(status).mText, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &result) {
        setFaviconUrl(result);
    }
```

#### AUTO 


```{c}
auto *job = new CompositeJob;
```

#### AUTO 


```{c}
auto grp = new QActionGroup(this);
```

#### AUTO 


```{c}
const auto fld = dynamic_cast<const Folder *>(child);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service)
        mUnityServiceAvailable = true;
        updateCount();
    }
```

#### AUTO 


```{c}
auto *dummyFactory = new Backend::StorageFactoryDummyImpl();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : str) {
        out.push_back(normalize(c));
    }
```

#### AUTO 


```{c}
auto statusMenu = coll->add<KActionMenu>(QStringLiteral("article_set_status"));
```

#### LAMBDA EXPRESSION 


```{c}
[&entriesCount, &message, maxNewArticlesShown]() {
        if ((entriesCount - maxNewArticlesShown) > 1) {
            message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
        }
    }
```

#### AUTO 


```{c}
auto viewer = new Akregator::AkrWebEngineViewer(ac, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *const i : jobs) {
        i->start();
    }
```

#### AUTO 


```{c}
auto **e1 = (c4_HandlerSeq **)NthHandler(col).Get(srcPos_, n);
```

#### AUTO 


```{c}
const auto nodeFolders = d->rootNode->folders();
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : std::as_const(feeds)) {
        i->setNotificationMode(true);
    }
```

#### AUTO 


```{c}
auto *job = new Akregator::ArticleDeleteJob;
```

#### LAMBDA EXPRESSION 


```{c}
[&entriesCount, &message]() {
                           if ((entriesCount - maxNewArticlesShown) > 1) {
                               message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
                           }
                       }
```

#### AUTO 


```{c}
auto *sf = d4_new
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : feeds) {
        if (lastcatid == i->parent()->id()) {
            if (i->xmlUrl().compare(url) == 0) {
                qCDebug(AKREGATOR_LOG) << "id:" << i->id();
                DeleteSubscriptionJob *job = new DeleteSubscriptionJob;
                job->setSubscriptionId(i->id());
                job->start();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : qAsConst(d->articles)) {
        if ((!useKeep || !i.keep()) && isExpired(i)) {
            const ArticleId aid = { feedUrl, i.guid() };
            toDelete.append(aid);
        }
    }
```

#### AUTO 


```{c}
auto job = new MoveSubscriptionJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *){
        if (!job->error()) {
            Q_EMIT signalIconChanged(this, QIcon(job->iconFile()));
        }
    }
```

#### AUTO 


```{c}
auto *buttonLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        jobFinished(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : qAsConst(m_queuedFeeds)) {
        disconnectFromFeed(i);
    }
```

#### AUTO 


```{c}
auto *job = new RenameSubscriptionJob(this);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : indexes) {
        const QUrl url(i.data(LinkRole).toString());
        if (!url.isEmpty()) {
            urls << url;
        }
    }
```

#### AUTO 


```{c}
auto const plugin = factory->create<Plugin>(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akregator::Feed *j : f) {
            feedsById.insert(j->id(), j);
        }
```

#### AUTO 


```{c}
auto job = KIO::storedPut(m_mainWidget->feedListToOPML().toString().toUtf8(), url, -1);
```

#### AUTO 


```{c}
auto const folder = qobject_cast<Akregator::Folder *>(node);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Article & art) -> bool { return !art.isDeleted(); }
```

#### AUTO 


```{c}
auto job = new DeleteSubscriptionJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : l) {
            const int row = m_articles.indexOf(i);
            //TODO: figure out how why the Article might not be found in
            //TODO: the articles list because we should need this conditional.
            if (row >= 0) {
                m_titleCache[row] = stripHtml(m_articles[row].title());
                rmin = std::min(row, rmin);
                rmax = std::max(row, rmax);
            }
        }
```

#### AUTO 


```{c}
auto *parentFolder = qobject_cast<Folder *>(m_selectedSubscription);
```

#### AUTO 


```{c}
const auto *const droppedOnNode = qobject_cast<const TreeNode *>(nodeForIndex(parent, m_feedList.data()));
```

#### AUTO 


```{c}
auto job = new ArticleModifyJob;
```

#### AUTO 


```{c}
auto cmd = new CreateFolderCommand(this);
```

#### AUTO 


```{c}
auto *fs = new Akregator::Backend::FeedStorageMK4Impl(url, q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->startDelete();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ArticleId &id : std::as_const(m_ids)) {
        Article article = m_feedList->findArticle(id.feedUrl, id.guid);
        if (article.isNull()) {
            continue;
        }

        if (Feed *const feed = m_feedList->findByURL(id.feedUrl)) {
            feeds.push_back(feed);
            feed->setNotificationMode(false);
        }
        article.setDeleted();
    }
```

#### AUTO 


```{c}
auto *seq = d4_new
```

#### AUTO 


```{c}
auto const job = new Akregator::ArticleModifyJob;
```

#### AUTO 


```{c}
auto dontRestoreSessionButton = new QPushButton(QIcon::fromTheme(QStringLiteral("dialog-close")), i18n("Do Not Restore Session"), this);
```

#### AUTO 


```{c}
auto *p = (t4_byte *)_segments.GetAt(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : qAsConst(m_articles)) {
        if (i.isDeleted()) {
            continue;
        }

        auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
                        return !matcher->matches(i);
                    };
        if (std::find_if(m_filters.cbegin(), filterEnd, func) != filterEnd) {
            continue;
        }
        articles << i;
        ++num;
    }
```

#### AUTO 


```{c}
auto cmd = new ImportFeedListCommand;
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<Akregator::DownloadArticleJob> job : std::as_const(mListDownloadArticleJobs)) {
        if (job) {
            job->forceCleanupTemporaryFile();
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *kiojob = dynamic_cast<KIO::Job *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : arts) {
        const ArticleId aid = { xmlUrl(), i.guid() };
        job->setStatus(aid, Read);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : qAsConst(ids)) {
        const auto *const asFolder = qobject_cast<const Folder *>(m_feedList->findByID(id));
        if (asFolder && (asFolder == destFolder || asFolder->subtreeContains(destFolder))) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto it = d->articles.begin(), end = d->articles.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &framePrefix : childList) {
        auto *const frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
        frame->loadConfig(config, framePrefix + QLatin1Char('_'));

        connectFrame(frame);
        Kernel::self()->frameManager()->slotAddFrame(frame);
        if (currentTabName == framePrefix) {
            currentFrameId = frame->id();
        }
    }
```

#### AUTO 


```{c}
auto *grp = new QActionGroup(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Article &art) -> bool {
            return !art.isDeleted();
        }
```

#### AUTO 


```{c}
auto *const maai = qobject_cast<KToggleAction *>(m_actionManager->action(QStringLiteral("article_set_status_important")));
```

#### LAMBDA EXPRESSION 


```{c}
[&entriesCount, &message, maxNewArticlesShown]() {
                           if ((entriesCount - maxNewArticlesShown) > 1) {
                               message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
                           }
                       }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->doCreate();
    }
```

#### AUTO 


```{c}
auto *pers = d4_new
```

#### AUTO 


```{c}
auto view = d->archiveView.GetAt(idx);
```

#### AUTO 


```{c}
auto const newFolder = new Folder(name);
```

#### AUTO 


```{c}
const auto jobs = subjobs();
```

#### AUTO 


```{c}
auto *job = new Akregator::ArticleModifyJob;
```

#### AUTO 


```{c}
auto cmd = new ExpireItemsCommand(this);
```

#### AUTO 


```{c}
auto lt = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *menu = new QMenu();
```

#### AUTO 


```{c}
auto dlg = new QFileDialog(this);
```

#### AUTO 


```{c}
auto b = (t4_byte)((v_ >> n) & 0x7F);
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QUrl &destURL) {
        if (destURL.isValid()) {
            KIO::FileCopyJob *job = KIO::file_copy(url, destURL, -1, KIO::Overwrite);
            job->addMetaData(QStringLiteral("MaxCacheSize"), QStringLiteral("0")); // Don't store in http cache.
            job->addMetaData(QStringLiteral("cache"), QStringLiteral("cache")); // Use entry from cache if available.
            KJobWidgets::setWindow(job, this);
            job->uiDelegate()->setAutoErrorHandlingEnabled(true);
        }
    }
```

#### AUTO 


```{c}
auto *job = new ArticleDeleteJob(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->createDeleteJobs();
    }
```

#### AUTO 


```{c}
auto m = qobject_cast<SubscriptionListModel *>(m_subscriptionModel->sourceModel());
```

#### AUTO 


```{c}
auto *viewer = new Akregator::AkrWebEngineViewer(ac, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::TreeNode *i : children) {
        el.appendChild(i->toOPML(el, document));
    }
```

#### AUTO 


```{c}
auto *popup = qobject_cast<QMenu *>(w);
```

#### AUTO 


```{c}
const auto positionalArguments = parser.positionalArguments();
```

#### AUTO 


```{c}
auto group = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : arts) {
        const ArticleId aid = {xmlUrl(), i.guid()};
        job->setStatus(aid, Read);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : qAsConst(ids)) {
        const TreeNode *const node = m_feedList->findByID(id);
        if (!node) {
            continue;
        }
        MoveSubscriptionJob *job = new MoveSubscriptionJob(this);
        job->setSubscriptionId(node->id());
        job->setDestination(destFolder->id(), after ? after->id() : -1);
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : qAsConst(d->children)) {
        Q_FOREACH (const Folder *j, i->folders()) {
            foldersById.insert(j->id(), j);
        }
    }
```

#### AUTO 


```{c}
auto const destFolder = qobject_cast<Folder *>(feedList->findByID(m_destFolderId));
```

#### AUTO 


```{c}
auto kiojob = dynamic_cast<KIO::Job *>(job);
```

#### AUTO 


```{c}
auto *statusMenu = coll->add<KActionMenu>(QStringLiteral("article_set_status"));
```

#### AUTO 


```{c}
const auto feeds = m_feedList->feeds();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : indexes)
        if (i.isValid()) {
            idStream << i.data(SubscriptionIdRole).toInt();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QStringList> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            return;
        }

        const QStringList &services = reply.value();

        mUnityServiceAvailable = services.contains(QLatin1String("com.canonical.Unity"));
        if (mUnityServiceAvailable) {
            updateCount();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service);
        mUnityServiceAvailable = true;
        updateCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : std::as_const(m_children)) {
        const auto f = i->folders();
        for (Folder *j : f) {
            foldersById.insert(j->id(), j);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->doCreate(); }
```

#### AUTO 


```{c}
const auto articles = storage->articles();
```

#### AUTO 


```{c}
const auto f = feeds();
```

#### AUTO 


```{c}
auto *ptr = const_cast<AbstractMatcher *>(&other);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Feed *j : f) {
            feedsById.insert(j->id(), j);
        }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool { return !matcher->matches(i); };
```

#### AUTO 


```{c}
auto &e = (c4_HandlerSeq *&)_subSeqs.ElementAt(index_);
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : qAsConst(feeds)) {
        i->setNotificationMode(true);
    }
```

#### AUTO 


```{c}
auto askMeLaterButton = new QPushButton(QIcon::fromTheme(QStringLiteral("chronometer")), i18n("Ask me later"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        jobFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : qAsConst(m_fetchingFeeds)) {
        disconnectFromFeed(i);
        i->slotAbortFetch();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *const child : childs) {
        if (child->title() == title) {
            nodeList.append(child);
        }
        auto *const fld = qobject_cast<Folder *>(child);
        if (fld) {
            nodeList += fld->namedChildren(title);
        }
    }
```

#### AUTO 


```{c}
auto it = hash.cbegin(), end = hash.cend();
```

#### AUTO 


```{c}
auto *expansionHandler = new FolderExpansionHandler(this);
```

#### AUTO 


```{c}
auto job = new KIO::FavIconRequestJob(mFeedIconUrl);
```

#### AUTO 


```{c}
auto optionV4 = qstyleoption_cast<QStyleOptionViewItem *>(option);
```

#### AUTO 


```{c}
auto *seq = (c4_Sequence *)refs.GetAt(i);
```

#### AUTO 


```{c}
auto *g = new Folder(groupName);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->startEdit();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const uint i : std::as_const(m_feeds)) {
        Feed *const feed = qobject_cast<Feed *>(feedList->findByID(i));
        if (feed) {
            addDeleteJobForFeed(feed);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Article& art) -> bool { return art.isDeleted(); }
```

#### AUTO 


```{c}
auto *filter = qobject_cast<FilterUnreadProxyModel *>(m);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
            m_dialog->addModule(metaData);
        }
```

#### AUTO 


```{c}
const auto *const folder = qobject_cast<const Akregator::Folder *const>(node);
```

#### AUTO 


```{c}
auto &hs = (c4_HandlerSeq *&)_subSeqs.ElementAt(index_);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : rootNodeFeeds) {
        constList.append(i);
    }
```

#### AUTO 


```{c}
auto mainWindow = new Akregator::MainWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (QPointer<Akregator::DownloadArticleJob> job : qAsConst(mListDownloadArticleJobs)) {
        if (job) {
            job->forceCleanupTemporaryFile();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        updateHamburgerMenu();
        // Immediately disconnect. We only need to run this once, but on demand.
        // NOTE: The nullptr at the end disconnects all connections between
        // q and mHamburgerMenu's aboutToShowMenu signal.
        disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
    }
```

#### AUTO 


```{c}
auto callWatcher = new QDBusPendingCallWatcher(listNamesCall, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Folder *const i : nodeFolders) {
        constList.append(i);
    }
```

#### AUTO 


```{c}
auto *col = (c4_Column *)_memos.GetAt(i);
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](const QString &result) {
        setFaviconUrl(result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : qAsConst(m_articles)) {
        const QString currentFeedTitle(i.feed()->title());
        if (feedTitle != currentFeedTitle) {
            // closing previous feed, if any, and resetting the counter
            feedClosure();
            entriesCount = 1;

            // starting a new feed
            feedTitle = currentFeedTitle;
            message += QStringLiteral("<p><b>%1:</b></p>").arg(feedTitle);
        }
        // check not exceeding maxNewArticlesShown per feed
        if (entriesCount <= maxNewArticlesShown) {
            message += i.title() + QLatin1String("<br>");
        }
        entriesCount++;
    }
```

#### AUTO 


```{c}
const auto n = c.toCaseFolded();
```

#### AUTO 


```{c}
auto *job = new WebEngineViewer::WebEngineExportHtmlPageJob;
```

#### AUTO 


```{c}
auto **p = (c4_HandlerSeq **)temp.Contents();
```

#### AUTO 


```{c}
auto *fg = static_cast<Folder *>(prev);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Akregator did not close correctly. Would you like to restore the previous session?"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : qAsConst(ids)) {
        const TreeNode *const node = m_feedList->findByID(id);
        if (!node) {
            continue;
        }
        auto job = new MoveSubscriptionJob(this);
        job->setSubscriptionId(node->id());
        job->setDestination(destFolder->id(), after ? after->id() : 0);
        job->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &fileName) {
            setFaviconLocalPath(fileName);
        }
```

#### AUTO 


```{c}
auto it = m_status.cbegin(), end = m_status.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const AddFeedRequest &i : qAsConst(m_requests)) {
        for (const QString &j : qAsConst(i.urls)) {
            m_mainWidget->addFeedToGroup(j, i.group);
        }
        NotificationManager::self()->slotNotifyFeeds(i.urls);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : qAsConst(m_children)) {
        const auto f = i->folders();
        for (const Folder *j : f) {
            foldersById.insert(j->id(), j);
        }
    }
```

#### AUTO 


```{c}
auto feedClosure = [&entriesCount, &message]() {
                           if ((entriesCount - maxNewArticlesShown) > 1) {
                               message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
                           }
                       };
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *const i : children) {
        body.appendChild(i->toOPML(body, doc));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
          feedsToAdd.append(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : f) {
        seq += i->articles();
    }
```

#### AUTO 


```{c}
const auto filterEnd = m_filters.cend();
```

#### AUTO 


```{c}
auto const fld = qobject_cast<Folder *>(child);
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : qAsConst(d->fetchingFeeds)) {
        disconnectFromFeed(i);
        i->slotAbortFetch();
    }
```

#### AUTO 


```{c}
auto labelLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto job = new ArticleDeleteJob(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : f) {
        ids += i->id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        if (!job->error()) {
            Q_EMIT signalIconChanged(this, QIcon(job->iconFile()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : qAsConst(m_articles)) {
        if (i.isDeleted()) {
            continue;
        }

        auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
            return !matcher->matches(i);
        };
        if (std::find_if(m_filters.cbegin(), filterEnd, func) != filterEnd) {
            continue;
        }
        articles << i;
        ++num;
    }
```

#### AUTO 


```{c}
auto fg = new Folder(e.hasAttribute(QStringLiteral("text")) ? e.attribute(QStringLiteral("text")) : e.attribute(QStringLiteral("title")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : articles) {
        writeItem(storage, i, writer);
    }
```

#### AUTO 


```{c}
auto *h2 = (c4_HandlerSeq *)s2->HandlerContext(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : std::as_const(m_articles)) {
        const QString currentFeedTitle(i.feed()->title());
        if (feedTitle != currentFeedTitle) {
            // closing previous feed, if any, and resetting the counter
            feedClosure();
            entriesCount = 1;

            // starting a new feed
            feedTitle = currentFeedTitle;
            message += QStringLiteral("<p><b>%1:</b></p>").arg(feedTitle);
        }
        // check not exceeding maxNewArticlesShown per feed
        if (entriesCount <= maxNewArticlesShown) {
            message += i.title() + QLatin1String("<br>");
        }
        entriesCount++;
    }
```

#### AUTO 


```{c}
auto &seq = (c4_HandlerSeq *&)_subSeqs.ElementAt(index_);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : qAsConst(d->articles)) {
        if ((!useKeep || !i.keep()) && isExpired(i)) {
            const ArticleId aid = {feedUrl, i.guid()};
            toDelete.append(aid);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : std::as_const(d->articles)) {
        if ((!useKeep || !i.keep()) && isExpired(i)) {
            const ArticleId aid = {feedUrl, i.guid()};
            toDelete.append(aid);
        }
    }
```

#### AUTO 


```{c}
auto *labelLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *const job(new ArticleListJob(m_selectedSubscription));
```

#### AUTO 


```{c}
auto popup = qobject_cast<QMenu *>(w);
```

#### AUTO 


```{c}
auto job = new Akregator::ArticleModifyJob;
```

#### LAMBDA EXPRESSION 


```{c}
[url, this](QDBusPendingCallWatcher *call){
            QDBusPendingReply<QString> reply = *call;
            if (reply.isError()) {
                m_favIconsModule->asyncCall(QStringLiteral("downloadHostIcon"), url.url());
                qCWarning(AKREGATOR_LOG) << "Couldn't reach favicon service. Request favicon for " << url << " failed:" << call->error().message();
            } else {
                q->slotIconChanged(false, url.host(), reply.argumentAt(0).toString());
            }
            call->deleteLater();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->doLoad(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &framePrefix : childList) {
        WebEngineFrame *const frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
        frame->loadConfig(config, framePrefix + QLatin1Char('_'));

        connectFrame(frame);
        Kernel::self()->frameManager()->slotAddFrame(frame);
        if (currentTabName == framePrefix) {
            currentFrameId = frame->id();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : qAsConst(m_children)) {
        const auto f = i->feeds();
        for (const Akregator::Feed *j : f) {
            feedsById.insert(j->id(), j);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QPrinter *printing) {
        QApplication::setOverrideCursor(Qt::WaitCursor);

        mArticleViewerNg->execPrintPreviewPage(printing, 10 * 1000);
        QApplication::restoreOverrideCursor();
    }
```

#### AUTO 


```{c}
auto *const plugin = factory->create<Plugin>(parent);
```

#### AUTO 


```{c}
auto *mimeData = new QMimeData;
```

#### AUTO 


```{c}
auto it = m_keepFlags.cbegin(), end = m_keepFlags.cend();
```

#### AUTO 


```{c}
auto *const newFolder = new Folder(name);
```

#### AUTO 


```{c}
auto filter = qobject_cast<FilterUnreadProxyModel *>(m);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ArticleId &id : qAsConst(m_ids)) {
        Article article = m_feedList->findArticle(id.feedUrl, id.guid);
        if (article.isNull()) {
            continue;
        }

        if (Feed *const feed = m_feedList->findByURL(id.feedUrl)) {
            feeds.push_back(feed);
            feed->setNotificationMode(false);
        }
        article.setDeleted();
    }
```

#### AUTO 


```{c}
auto &entry = d->entries[guid];
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : l) {
            const int row = m_articles.indexOf(i);
            // TODO: figure out how why the Article might not be found in
            // TODO: the articles list because we should need this conditional.
            if (row >= 0) {
                m_titleCache[row] = stripHtml(m_articles[row].title());
                rmin = std::min(row, rmin);
                rmax = std::max(row, rmax);
            }
        }
```

#### AUTO 


```{c}
auto job = KIO::file_copy(url, QUrl::fromLocalFile(filename), -1, KIO::Overwrite | KIO::HideProgressInfo);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateHamburgerMenu();
            // Immediately disconnect. We only need to run this once, but on demand.
            // NOTE: The nullptr at the end disconnects all connections between
            // q and mHamburgerMenu's aboutToShowMenu signal.
            disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
        }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("tab-new")), i18n("Open Link in New &Tab"), parent);
```

#### AUTO 


```{c}
auto *p = (t4_byte *)_segments.GetAt(index_);
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<KParts::Part>(md, this);
```

#### AUTO 


```{c}
auto rootNode = new Folder(i18n("All Feeds"));
```

#### AUTO 


```{c}
const auto iconSize = QApplication::style()->pixelMetric(QStyle::PM_SmallIconSize);
```

#### AUTO 


```{c}
auto fg = static_cast<Folder *>(prev);
```

#### AUTO 


```{c}
auto importantAction = coll->add<KToggleAction>(QStringLiteral("article_set_status_important"));
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString url : positionalArguments) {
            const QUrl tempUrl = QUrl::fromUserInput(url);
            if (tempUrl.isLocalFile()) {
                const QString tempLocalFile = tempUrl.toLocalFile();
                if (tempLocalFile.startsWith(QDir::tempPath())) {
                    const QString path = QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + QStringLiteral("/akregator/data/");
                    QDir().mkpath(path);
                    QFile f(tempLocalFile);
                    const QString newRssFileName = path + QFileInfo(f).fileName();
                    if (!f.copy(newRssFileName)) {
                        qCWarning(AKREGATOR_LOG) << "Impossible to copy in local folder" << newRssFileName;
                    } else {
                        url = newRssFileName;
                    }
                }
            }

            feedsToAdd.append(url);
        }
```

#### AUTO 


```{c}
const auto children = allFeedsFolder()->children();
```

#### AUTO 


```{c}
auto *const proxy2 = new FilterDeletedProxyModel(model);
```

#### AUTO 


```{c}
auto webEngineUrlInterceptor = new AkregatorRequestInterceptor();
```

#### AUTO 


```{c}
const auto plugins = queryStoragePlugins();
```

#### AUTO 


```{c}
auto *job = new KIO::FavIconRequestJob(url);
```

#### AUTO 


```{c}
const auto f = i->folders();
```

#### AUTO 


```{c}
const auto viewMode = static_cast<MainWidget::ViewMode>(Settings::viewMode());
```

#### LAMBDA EXPRESSION 


```{c}
[url, this](QDBusPendingCallWatcher * call) {
        QDBusPendingReply<QString> reply = *call;
        if (reply.isError()) {
            m_favIconsModule->asyncCall(QStringLiteral("downloadHostIcon"), url.url());
            qCWarning(AKREGATOR_LOG) << "Couldn't reach favicon service. Request favicon for " << url << " failed:" << call->error().message();
        } else {
            q->slotIconChanged(false, url.host(), reply.argumentAt(0).toString());
        }
        call->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : std::as_const(ids)) {
        const auto *const asFolder = qobject_cast<const Folder *>(m_feedList->findByID(id));
        if (asFolder && (asFolder == destFolder || asFolder->subtreeContains(destFolder))) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *vec = d4_new
```

#### RANGE FOR STATEMENT 


```{c}
for (Article i : qAsConst(articles)) {
        if (c < limit) {
            if (!i.isDeleted() && (!useKeep || !i.keep())) {
                ++c;
            }
        } else if (!useKeep || !i.keep()) {
            i.setDeleted();
        }
    }
```

#### AUTO 


```{c}
auto restoreSessionButton = new QPushButton(QIcon::fromTheme(QStringLiteral("window-new")), i18n("Restore Session"), this);
```

#### AUTO 


```{c}
auto **e2 = (c4_HandlerSeq **)dst_.NthHandler(col).Get(dstPos_, n);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : indexes) {
        const int rowIndex = i.row();
        if (seenArticles.contains(rowIndex)) {
            continue;
        }
        seenArticles.append(rowIndex);
        const QUrl url = i.data(ArticleModel::LinkRole).toUrl();
        if (url.isValid()) {
            urls.push_back(url);
        } else {
            const QUrl guid(i.data(ArticleModel::GuidRole).toString());
            if (guid.isValid()) {
                urls.push_back(guid);
            }
        }
    }
```

#### AUTO 


```{c}
auto *chg = d4_new
```

#### AUTO 


```{c}
auto *p = d4_new
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : indexes) {
        const Article a = articleForIndex(i, feedList);
        if (a.isNull()) {
            continue;
        }
        articles.append(articleForIndex(i, feedList));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        const Akregator::ArticleId aid = {i.feed()->xmlUrl(), i.guid()};
        job->setKeep(aid, !allFlagsSet);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : qAsConst(m_children)) {
        const auto f = i->feeds();
        for (Akregator::Feed *j : f) {
            feedsById.insert(j->id(), j);
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(QIcon::fromTheme(QStringLiteral("window-new")), i18n("Open Link in External &Browser"), parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame *frame : std::as_const(d->frames)) {
        frame->slotReload();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        const Akregator::ArticleId aid = { i.feed()->xmlUrl(), i.guid() };
        job->setStatus(aid, status);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPrinter * printer) {
        render(printer);
    }
```

#### AUTO 


```{c}
auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
                        return !matcher->matches(i);
                    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->startEdit(); }
```

#### AUTO 


```{c}
auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
            return !matcher->matches(i);
        };
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto job = new RenameSubscriptionJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *const child : childs) {
        if (child->title() == title) {
            nodeList.append(child);
        }
        Folder *const fld = qobject_cast<Folder *>(child);
        if (fld) {
            nodeList += fld->namedChildren(title);
        }
    }
```

#### AUTO 


```{c}
auto frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *child : childs) {
        if (child->title() == title) {
            nodeList.append(child);
        }
        const Folder *fld = dynamic_cast<const Folder *>(child);
        if (fld) {
            nodeList += fld->namedChildren(title);
        }
    }
```

#### AUTO 


```{c}
auto *mc = d4_new
```

#### AUTO 


```{c}
auto const maai = qobject_cast<KToggleAction *>(m_actionManager->action(QStringLiteral("article_set_status_important")));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->createDeleteJobs(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : l) {
        const int row = m_articles.indexOf(i);
        Q_ASSERT(row != -1);
        removeRow(row, QModelIndex());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        if (!job->error()) {
            setFavicon(QIcon(job->iconFile()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Article & art) -> bool { return art.isDeleted(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : backends) {
        Backend::StorageFactory *const factory = Backend::StorageFactoryRegistry::self()->getFactory(i);
        if (!factory) {
            continue;
        }

        m_factories.insert(factory->key(), factory);
        cbBackend->addItem(factory->name(), factory->key());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &i : offers) {
        Akregator::Plugin *plugin = PluginManager::createFromService(i, this);
        if (!plugin) {
            continue;
        }
        plugin->initialize();
        plugin->insertGuiClients(this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *child : childs) {
        if (child->title() == title) {
            nodeList.append(child);
        }
        const auto fld = dynamic_cast<const Folder *>(child);
        if (fld) {
            nodeList += fld->namedChildren(title);
        }
    }
```

#### AUTO 


```{c}
auto buttonLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        allFlagsSet = allFlagsSet && i.keep();
        if (!allFlagsSet) {
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](OpenUrlRequest &request) { slotOpenUrlRequest(request);}
```

#### AUTO 


```{c}
auto *f = d4_new
```

#### AUTO 


```{c}
auto *job = new KIO::FavIconRequestJob(mFeedIconUrl);
```

#### AUTO 


```{c}
auto *importantAction = coll->add<KToggleAction>(QStringLiteral("article_set_status_important"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &article : articles) {
        slotOpenArticleInBrowser(article);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool { return !matcher->matches(i); }
```

#### AUTO 


```{c}
auto articleObj = new ArticleGrantleeObject(article.at(i), icon);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &j : qAsConst(i.urls)) {
            m_mainWidget->addFeedToGroup(j, i.group);
        }
```

#### AUTO 


```{c}
auto *cmd = new ImportFeedListCommand;
```

#### AUTO 


```{c}
auto *cmd(new CreateFeedCommand(this));
```

#### AUTO 


```{c}
const auto folders = m_feedList->folders();
```

#### AUTO 


```{c}
auto *const frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
```

#### AUTO 


```{c}
auto *const destFolder = qobject_cast<Folder *>(feedList->findByID(m_destFolderId));
```

#### AUTO 


```{c}
auto *mainTabLayout = new QVBoxLayout(m_mainTab);
```

#### AUTO 


```{c}
auto view = static_cast<QTreeView *>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : qAsConst(d->queuedFeeds)) {
        disconnectFromFeed(i);
    }
```

#### AUTO 


```{c}
auto const newModel = new ArticleModel(m_listJob->articles());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service)
        mUnityServiceAvailable = false;
    }
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : qAsConst(m_children)) {
        const auto f = i->folders();
        for (Folder *j : f) {
            foldersById.insert(j->id(), j);
        }
    }
```

#### AUTO 


```{c}
auto layout = new QGridLayout(this);
```

#### AUTO 


```{c}
auto *cmd = new EditSubscriptionCommand(this);
```

#### AUTO 


```{c}
auto cmd = new DeleteSubscriptionCommand(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : list) {
            slotNodeAdded(i);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *const candidate : namedGroups) {
        if (candidate->isGroup()) {
            group =  static_cast<Folder *>(candidate);
            break;
        }
    }
```

#### AUTO 


```{c}
auto parentFolder = qobject_cast<Folder *>(m_selectedSubscription);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : parser.positionalArguments()) {
            feedsToAdd.append(url);
        }
```

#### AUTO 


```{c}
auto *sqf = coll->add<KToggleAction>(QStringLiteral("show_quick_filter"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const uint i : qAsConst(m_feeds)) {
        Feed *const feed = qobject_cast<Feed *>(feedList->findByID(i));
        if (feed) {
            addDeleteJobForFeed(feed);
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &j : std::as_const(i.urls)) {
            m_mainWidget->addFeedToGroup(j, i.group);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *const i : std::as_const(d->m_jobs)) {
        i->kill();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AddFeedRequest &i : std::as_const(m_requests)) {
        for (const QString &j : std::as_const(i.urls)) {
            m_mainWidget->addFeedToGroup(j, i.group);
        }
        NotificationManager::self()->slotNotifyFeeds(i.urls);
    }
```

#### AUTO 


```{c}
auto *optionV4 = qstyleoption_cast< QStyleOptionViewItem * >(option);
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : f) {
        if (i->useCustomFetchInterval()) {
            if (i->fetchInterval() != -1) {
                i->slotAddToFetchQueue(queue, intervalFetchOnly);
            } else {
                qCDebug(AKREGATOR_LOG) << " excluded feeds: " << i->description();
            }
        } else {
            i->slotAddToFetchQueue(queue, intervalFetchOnly);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : feeds) {
        if (lastcatid == i->parent()->id()) {
            if (i->xmlUrl().compare(url) == 0) {
                qCDebug(AKREGATOR_LOG) << "id:" << i->id();
                auto *job = new DeleteSubscriptionJob;
                job->setSubscriptionId(i->id());
                job->start();
            }
        }
    }
```

#### AUTO 


```{c}
auto *lt = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto const proxy2 = new FilterDeletedProxyModel(model);
```

#### AUTO 


```{c}
auto &curr = (c4_HandlerSeq *&)_subSeqs.ElementAt(index_);
```

#### AUTO 


```{c}
auto expansionHandler = new FolderExpansionHandler(this);
```

#### AUTO 


```{c}
auto job = new Akregator::DownloadFeedIconJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        const Akregator::ArticleId aid = { i.feed()->xmlUrl(), i.guid() };
        job->setKeep(aid, !allFlagsSet);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Feed *const i : rootNodeFeeds) {
        constList.append(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : indexes) {
        if (i.isValid()) {
            idStream << i.data(SubscriptionIdRole).toInt();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        Feed *const feed = i.feed();
        if (!feed) {
            continue;
        }
        const Akregator::ArticleId aid = { feed->xmlUrl(), i.guid() };
        job->appendArticleId(aid);
    }
```

#### AUTO 


```{c}
auto articleWidgetLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto rootNodeFeeds = d->rootNode->feeds();
```

#### AUTO 


```{c}
const auto f = i->feeds();
```

#### AUTO 


```{c}
auto *job = new DeleteSubscriptionJob;
```

#### AUTO 


```{c}
auto *cmd = new DeleteSubscriptionCommand(this);
```

#### AUTO 


```{c}
const auto w = (t4_i32)(_currWidth >> 3);
```

#### AUTO 


```{c}
auto myPart = static_cast<Akregator::Part *>(part());
```

#### AUTO 


```{c}
auto menu = new QMenu();
```

#### AUTO 


```{c}
auto dialog = new QPrintPreviewDialog(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : qAsConst(d->children)) {
        children.append(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *){
        if (!job->error()) {
            setFavicon(QIcon(job->iconFile()));
        }
    }
```

#### AUTO 


```{c}
auto feedClosure = [&entriesCount, &message]() {
        if ((entriesCount - maxNewArticlesShown) > 1) {
            message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : std::as_const(m_children)) {
        const auto f = i->feeds();
        for (Akregator::Feed *j : f) {
            feedsById.insert(j->id(), j);
        }
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : std::as_const(m_children)) {
        children.append(i);
    }
```

#### AUTO 


```{c}
const auto newStatus = a->data().value<StatusSearchLine::Status>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->doImport(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : qAsConst(ids)) {
        const Folder *const asFolder = qobject_cast<const Folder *>(m_feedList->findByID(id));
        if (asFolder && (asFolder == destFolder || asFolder->subtreeContains(destFolder))) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto job = new Akregator::ArticleDeleteJob;
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(QUrl::fromLocalFile(filename), QStringLiteral("text/html"));
```

#### AUTO 


```{c}
const auto arts = articles();
```

#### AUTO 


```{c}
auto status = static_cast<StatusSearchLine::Status>(i);
```

#### AUTO 


```{c}
auto trayIcon = new TrayIcon(m_mainWidget->window());
```

#### AUTO 


```{c}
auto const frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
```

#### AUTO 


```{c}
auto progressStatusBarWidget = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&entriesCount, &message]() {
        if ((entriesCount - maxNewArticlesShown) > 1) {
            message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *const i : qAsConst(d->m_jobs)) {
        i->kill();
    }
```

#### AUTO 


```{c}
auto *job = new ArticleModifyJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : std::as_const(ids)) {
        const TreeNode *const node = m_feedList->findByID(id);
        if (!node) {
            continue;
        }
        auto job = new MoveSubscriptionJob(this);
        job->setSubscriptionId(node->id());
        job->setDestination(destFolder->id(), after ? after->id() : 0);
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &article : articles) {
        const QUrl url = article.link();
        if (!url.isValid()) {
            continue;
        }

        OpenUrlRequest req(url);
        req.setOptions(OpenUrlRequest::NewTab);
        if (openInBackground) {
            req.setOpenInBackground(true);
            Kernel::self()->frameManager()->slotOpenUrlRequest(req, false /*don't use settings for open in background*/);
        } else {
            Kernel::self()->frameManager()->slotOpenUrlRequest(req);
        }
    }
```

#### AUTO 


```{c}
auto *articleWidgetLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : qAsConst(ids)) {
        const TreeNode *const node = m_feedList->findByID(id);
        if (!node) {
            continue;
        }
        auto *job = new MoveSubscriptionJob(this);
        job->setSubscriptionId(node->id());
        job->setDestination(destFolder->id(), after ? after->id() : 0);
        job->start();
    }
```

#### AUTO 


```{c}
auto *fs = new Akregator::Backend::FeedStorage(url, q);
```

#### AUTO 


```{c}
auto *job = new Akregator::DownloadFeedIconJob(this);
```

#### AUTO 


```{c}
auto g = new Folder(groupName);
```

#### AUTO 


```{c}
auto *callWatcher = new QDBusPendingCallWatcher(listNamesCall, this);
```

#### AUTO 


```{c}
auto job = new KIO::FavIconRequestJob(url);
```

#### AUTO 


```{c}
const auto c
```

#### AUTO 


```{c}
auto const columnsProxy = new FilterColumnsProxyModel(model);
```

#### AUTO 


```{c}
auto feedClosure = [&entriesCount, &message, maxNewArticlesShown]() {
                           if ((entriesCount - maxNewArticlesShown) > 1) {
                               message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
                           }
                       };
```

#### AUTO 


```{c}
auto *hs = (c4_HandlerSeq *)_subSeqs.GetAt(i);
```

#### AUTO 


```{c}
auto o = dynamic_cast<ArticleMatcher *>(ptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        Feed *const feed = i.feed();
        if (!feed) {
            continue;
        }
        const Akregator::ArticleId aid = {feed->xmlUrl(), i.guid()};
        job->appendArticleId(aid);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *i : qAsConst(d->children)) {
        Q_FOREACH (const Akregator::Feed *j, i->feeds()) {
            feedsById.insert(j->id(), j);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { jobFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : indexes) {
        const QUrl url = i.data(ArticleModel::LinkRole).toUrl();
        if (url.isValid()) {
            urls.push_back(url);
        } else {
            const QUrl guid(i.data(ArticleModel::GuidRole).toString());
            if (guid.isValid()) {
                urls.push_back(guid);
            }
        }
    }
```

#### AUTO 


```{c}
auto *menu = new QMenu(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](OpenUrlRequest &request) {
        slotOpenUrlRequest(request);
    }
```

#### AUTO 


```{c}
auto *progressStatusBarWidget = new KPIM::ProgressStatusBarWidget(statusBar(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (TreeNode *i : qAsConst(d->children)) {
        Q_FOREACH (Akregator::Feed *j, i->feeds()) {
            feedsById.insert(j->id(), j);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->doLoad();
    }
```

#### AUTO 


```{c}
const auto predicateType = static_cast<Predicate>(m_predicate & ~Negation);
```

#### AUTO 


```{c}
auto *view = static_cast< QTreeView * >(parent());
```

#### AUTO 


```{c}
auto job = new CompositeJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
            m_dialog->addModule(metaData);
#else
            m_dialog->addModule(metaData.pluginId());
#endif
        }
```

#### AUTO 


```{c}
auto ptr = const_cast<AbstractMatcher *>(&other);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : qAsConst(m_articles)) {
        if (i.isDeleted()) {
            continue;
        }

        auto func = [i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool { return !matcher->matches(i); };
        if (std::find_if(m_filters.cbegin(), filterEnd, func) != filterEnd) {
            continue;
        }
        articles << i;
        ++num;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &service) {
        Q_UNUSED(service);
        mUnityServiceAvailable = false;
    }
```

#### AUTO 


```{c}
const auto *fld = dynamic_cast<const Folder *>(child);
```

#### AUTO 


```{c}
auto *o = dynamic_cast<ArticleMatcher *>(ptr);
```

#### LAMBDA EXPRESSION 


```{c}
[i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
            return !matcher->matches(i);
        }
```

#### AUTO 


```{c}
auto *strat = d4_new
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : list) {
            const int row = articles.indexOf(i);
            //TODO: figure out how why the Article might not be found in
            //TODO: the articles list because we should need this conditional.
            if (row >= 0) {
                titleCache[row] = stripHtml(articles[row].title());
                rmin = std::min(row, rmin);
                rmax = std::max(row, rmax);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->startDelete(); }
```

#### AUTO 


```{c}
auto job = new WebEngineViewer::WebEngineExportHtmlPageJob;
```

#### AUTO 


```{c}
auto *frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Folder *j : f) {
            foldersById.insert(j->id(), j);
        }
```

#### AUTO 


```{c}
auto mainTabLayout = new QVBoxLayout(m_mainTab);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AddFeedRequest &i : qAsConst(m_requests)) {
        Q_FOREACH (const QString &j, i.urls) {
            m_mainWidget->addFeedToGroup(j, i.group);
        }
        NotificationManager::self()->slotNotifyFeeds(i.urls);
    }
```

#### AUTO 


```{c}
auto sqf = coll->add<KToggleAction>(QStringLiteral("show_quick_filter"));
```

#### AUTO 


```{c}
auto *cp = (c4_Column *)_memos.GetAt(i);
```

#### AUTO 


```{c}
auto cmd = new EditSubscriptionCommand(this);
```

#### AUTO 


```{c}
auto *const job = new Akregator::ArticleModifyJob;
```

#### AUTO 


```{c}
const auto *const asFolder = qobject_cast<const Folder *>(m_feedList->findByID(id));
```

#### AUTO 


```{c}
auto *const columnsProxy = new FilterColumnsProxyModel(model);
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TreeNode *child : childs) {
        if (child->title() == title) {
            nodeList.append(child);
        }
        const auto *fld = dynamic_cast<const Folder *>(child);
        if (fld) {
            nodeList += fld->namedChildren(title);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &fileName) {
                setFaviconLocalPath(fileName);
                }
```

#### AUTO 


```{c}
auto *field = d4_new
```

#### AUTO 


```{c}
auto *m = qobject_cast<SubscriptionListModel *>(m_subscriptionModel->sourceModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : feeds) {
        if (lastcatid == i->parent()->id()) {
            urls.insert(i->xmlUrl());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : qAsConst(ids)) {
        const TreeNode *const node = m_feedList->findByID(id);
        if (!node) {
            continue;
        }
        auto *job = new MoveSubscriptionJob(this);
        job->setSubscriptionId(node->id());
        job->setDestination(destFolder->id(), after ? after->id() : -1);
        job->start();
    }
```

#### AUTO 


```{c}
auto const job(new ArticleListJob(m_selectedSubscription));
```

#### LAMBDA EXPRESSION 


```{c}
[i](const QSharedPointer<const Filters::AbstractMatcher> &matcher) -> bool {
                        return !matcher->matches(i);
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPrinter * printer) {
        print(printer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : feeds) {
        if (lastcatid == i->parent()->id()) {
            if (i->xmlUrl().compare(url) == 0) {
                qCDebug(AKREGATOR_LOG) << "id:" << i->id();
                auto job = new DeleteSubscriptionJob;
                job->setSubscriptionId(i->id());
                job->start();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, this](KJob *) {
        if (!job->error()) {
            Q_EMIT result(job->iconFile());
        }
        deleteLater();
    }
```

#### AUTO 


```{c}
auto b = new QToolButton(mb);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { jobFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Article i : std::as_const(articles)) {
        if (c < limit) {
            if (!i.isDeleted() && (!useKeep || !i.keep())) {
                ++c;
            }
        } else if (!useKeep || !i.keep()) {
            i.setDeleted();
        }
    }
```

#### AUTO 


```{c}
auto blockTracking = new WebEngineViewer::BlockTrackingUrlInterceptor(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Frame *frame : qAsConst(d->frames)) {
        frame->slotReload();
    }
```

#### AUTO 


```{c}
auto dummyFactory = new Backend::StorageFactoryDummyImpl();
```

#### AUTO 


```{c}
const auto childs = children();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akregator::Article &i : articles) {
        const Akregator::ArticleId aid = {i.feed()->xmlUrl(), i.guid()};
        job->setStatus(aid, status);
    }
```

#### AUTO 


```{c}
auto tv = qobject_cast<QTreeView *>(m_feedSelector);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : f) {
        total += i->totalCount();
    }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(url, request.args().mimeType());
```

#### AUTO 


```{c}
auto feedClosure = [&entriesCount, &message, maxNewArticlesShown]() {
        if ((entriesCount - maxNewArticlesShown) > 1) {
            message += i18np("<i>and 1 other</i>", "<i>and %1 others</i>", entriesCount - maxNewArticlesShown - 1) + QLatin1String("<br>");
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Feed *const i : f) {
        unread += i->unread();
    }
```

#### AUTO 


```{c}
auto *group = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Folder *const i : folders) {
        cats.append(path_of_folder(i));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : str) {
        // case folding
        const auto n = c.toCaseFolded();

        // if the character has a canonical decomposition use that and skip the
        // combining diacritic markers following it
        // see https://en.wikipedia.org/wiki/Unicode_equivalence
        // see https://en.wikipedia.org/wiki/Combining_character
        if (n.decompositionTag() == QChar::Canonical) {
            out.push_back(n.decomposition().at(0));
        }
        // handle compatibility compositions such as ligatures
        // see https://en.wikipedia.org/wiki/Unicode_compatibility_characters
        else if (n.decompositionTag() == QChar::Compat && n.isLetter() && n.script() == QChar::Script_Latin) {
            out.append(n.decomposition());
        } else {
            out.push_back(n);
        }
    }
```

#### AUTO 


```{c}
auto *job = new MoveSubscriptionJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : std::as_const(m_fetchingFeeds)) {
        disconnectFromFeed(i);
        i->slotAbortFetch();
    }
```

#### AUTO 


```{c}
auto *q = d4_new
```

#### RANGE FOR STATEMENT 


```{c}
for (Folder *j : f) {
            foldersById.insert(j->id(), j);
        }
```

#### AUTO 


```{c}
auto *tv = qobject_cast<QTreeView *>(m_feedSelector);
```

#### AUTO 


```{c}
auto *trayIcon = new TrayIcon(m_mainWidget->window());
```

#### RANGE FOR STATEMENT 


```{c}
for (const int i : qAsConst(m_feeds)) {
        Feed *const feed = qobject_cast<Feed *>(feedList->findByID(i));
        if (feed) {
            addDeleteJobForFeed(feed);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->doImport();
    }
```

#### AUTO 


```{c}
auto *myPart = static_cast<Akregator::Part *>(part());
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QUrl &destURL) {
        if (destURL.isValid()) {
            KIO::FileCopyJob *job = KIO::file_copy(url, destURL, -1, KIO::Overwrite);
            job->addMetaData(QStringLiteral("MaxCacheSize"), QStringLiteral("0")); // Don't store in http cache.
            job->addMetaData(QStringLiteral("cache"), QStringLiteral("cache")); // Use entry from cache if available.
            KJobWidgets::setWindow(job, this);
            if (Settings::self()->disableSaveAsNotification()) {
                job->setFinishedNotificationHidden(true);
            }
            job->uiDelegate()->setAutoErrorHandlingEnabled(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Value &value : container) {
        values << value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Article &i : list) {
        const int row = articles.indexOf(i);
        Q_ASSERT(row != -1);
        q->removeRow(row, QModelIndex());
    }
```

#### AUTO 


```{c}
auto cmd(new CreateFeedCommand(this));
```

#### AUTO 


```{c}
auto *cmd = new CreateFolderCommand(this);
```

#### LAMBDA EXPRESSION 


```{c}
[=](QPrinter *printing) {
        QApplication::setOverrideCursor(Qt::WaitCursor);

        mArticleViewerNg->execPrintPreviewPage(printing, 10*1000);
        QApplication::restoreOverrideCursor();
    }
```

#### AUTO 


```{c}
auto job = new KIO::OpenUrlJob(currentUrl, QStringLiteral("text/html"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &i : plugins) {
        if (Plugin *const plugin = createFromService(i)) {
            plugin->initialize();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &framePrefix : childList) {
        auto const frame = new WebEngineFrame(m_actionManager->actionCollection(), m_tabWidget);
        frame->loadConfig(config, framePrefix + QLatin1Char('_'));

        connectFrame(frame);
        Kernel::self()->frameManager()->slotAddFrame(frame);
        if (currentTabName == framePrefix) {
            currentFrameId = frame->id();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Feed *const i : std::as_const(m_queuedFeeds)) {
        disconnectFromFeed(i);
    }
```

