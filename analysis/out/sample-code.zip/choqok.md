#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->shares) {
                if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, post->author).toDisplayString()
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### AUTO 


```{c}
auto newH = newPixmap.height();
```

#### RANGE FOR STATEMENT 


```{c}
for (PostWidget *pw: d->sortedPostsList) {
        pw->setUiStyle();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *filter: FilterSettings::self()->filters()) {
        if (filter->filterText().isEmpty()) {
            return;
        }
        if (filter->filterAction() == Filter::Remove && filter->dontHideReplies() &&
                (postToParse->currentPost()->replyToUser.userName.compare(postToParse->currentAccount()->username(),
                        Qt::CaseInsensitive) == 0 ||
                 postToParse->currentPost()->content.contains(QStringLiteral("@%1").arg(postToParse->currentAccount()->username())))
           ) {
            continue;
        }
        switch (filter->filterField()) {
        case Filter::Content:
            doFiltering(postToParse, filterText(postToParse->currentPost()->content, filter));
            break;
        case Filter::AuthorUsername:
            doFiltering(postToParse, filterText(postToParse->currentPost()->author.userName, filter));
            break;
        case Filter::ReplyToUsername:
            doFiltering(postToParse, filterText(postToParse->currentPost()->replyToUser.userName, filter));
            break;
        case Filter::Source:
            doFiltering(postToParse, filterText(postToParse->currentPost()->source, filter));
            break;
        default:
            break;
        };
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name: lists) {
        tms.append(name);
        addTimelineName(name);
        timelineApiPath[name] = QLatin1String("/lists/statuses.json");
    }
```

#### AUTO 


```{c}
auto newW = newPixmap.width();
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job: m_accountJobs.keys(theAccount)) {
        job->kill(KJob::EmitResult);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *curracc: d->accounts) {
        if (account->alias() == curracc->alias()) {
            d->lastError = i18n("An account with this alias already exists: a unique alias has to be specified.");
            qCDebug(CHOQOK) << "An account with this alias already exists: a unique alias has to be specified.";
            return nullptr;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *wd: d->timelines) {
        wd->markAllAsRead();
        int tabIndex = d->timelinesTabWidget->indexOf(wd);
        if (tabIndex == -1) {
            continue;
        }
        d->timelinesTabWidget->setTabText(tabIndex, wd->timelineInfoName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name: list) {
        if (microblog()->timelineNames().contains(name)) {
            d->timelineNames << name;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str: tmpList) {
        groupList.append(QDateTime::fromString(str));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
        MastodonPost *post = dynamic_cast<MastodonPost * >(wd->currentPost());
        KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
        grp.writeEntry("creationDateTime", post->creationDateTime);
        grp.writeEntry("postId", post->postId);
        grp.writeEntry("link", post->link);
        grp.writeEntry("content", post->content);
        grp.writeEntry("source", post->source);
        grp.writeEntry("favorited", post->isFavorited);
        grp.writeEntry("authorId", post->author.userId);
        grp.writeEntry("authorRealName", post->author.realName);
        grp.writeEntry("authorUserName", post->author.userName);
        grp.writeEntry("authorDescription", post->author.description);
        grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
        grp.writeEntry("authorHomePageUrl", post->author.homePageUrl);
        grp.writeEntry("isRead", post->isRead);
        grp.writeEntry("conversationId", post->conversationId);
        grp.writeEntry("replyToPostId", post->replyToPostId);
        grp.writeEntry("replyToUserId", post->replyToUser.userId);
        grp.writeEntry("repeatedFromUserId", post->repeatedFromUser.userId);
        grp.writeEntry("repeatedFromUserName", post->repeatedFromUser.userName);
        grp.writeEntry("repeatedFromUserHomePage", post->repeatedFromUser.homePageUrl);
        grp.writeEntry("repeatedPostId", post->repeatedPostId);
        grp.writeEntry("repeatedDateTime", post->repeatedDateTime);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: UrlUtils::detectUrls(txt)) {
                // Twitter does not wrapps urls with login information
                if (!url.contains(QLatin1Char('@'))) {
                    int diff = -1;
                    if (url.startsWith(QLatin1String("http://"))) {
                        diff = url.length() - d->tCoMaximumLength;
                    } else if (url.startsWith(QLatin1String("https://"))) {
                        diff = url.length() - d->tCoMaximumLengthHttps;
                    }

                    if (diff > 0) {
                        remain += diff;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: UrlUtils::detectUrls(txt)) {
                // Twitter does not wrapps urls with login informations
                if (!url.contains(QLatin1Char('@'))) {
                    int diff = -1;
                    if (url.startsWith(QLatin1String("http://"))) {
                        diff = url.length() - d->tCoMaximumLength;
                    } else if (url.startsWith(QLatin1String("https://"))) {
                        diff = url.length() - d->tCoMaximumLengthHttps;
                    }

                    if (diff > 0) {
                        remain += diff;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &servicePtr: pluginInfo.kcmServices()) {
        if (!servicePtr->noDisplay()) {
            KCModuleProxy *currentModuleProxy = new KCModuleProxy(servicePtr, moduleProxyParentWidget);

            if (currentModuleProxy->realModule()) {
                d->moduleProxyList << currentModuleProxy;
                if (mainWidget && !newTabWidget) {
                    // we already created one KCModuleProxy, so we need a tab widget.
                    // Move the first proxy into the tab widget and ensure this and subsequent
                    // proxies are in the tab widget
                    newTabWidget = new QTabWidget(configDialog);
                    moduleProxyParentWidget = newTabWidget;
                    mainWidget->setParent(newTabWidget);
                    KCModuleProxy *moduleProxy = qobject_cast<KCModuleProxy *>(mainWidget);
                    if (moduleProxy) {
                        newTabWidget->addTab(mainWidget, servicePtr->name());
                        mainWidget = newTabWidget;
                    } else {
                        delete newTabWidget;
                        newTabWidget = nullptr;
                        moduleProxyParentWidget = configDialog;
                        mainWidget->setParent(nullptr);
                    }
                }

                if (newTabWidget) {
                    newTabWidget->addTab(currentModuleProxy, servicePtr->name());
                } else {
                    mainWidget = currentModuleProxy;
                }
            } else {
                delete currentModuleProxy;
            }
        }
    }
```

#### AUTO 


```{c}
auto it = queryItems.begin(), end = queryItems.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &thumb_url: thumbList) {
        connect(Choqok::MediaManager::self(),
                SIGNAL(imageFetched(QString,QPixmap)),
                SLOT(slotImageFetched(QString,QPixmap)));

        Choqok::MediaManager::self()->fetchImage(thumb_url, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant elem: json.toVariant().toList()) {
                    postsList.prepend(readStatusesFromJsonMap(elem.toMap()));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
        PumpIOPost *post = dynamic_cast<PumpIOPost * >(wd->currentPost());
        KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
        grp.writeEntry("creationDateTime", post->creationDateTime);
        grp.writeEntry("postId", post->postId);
        grp.writeEntry("link", post->link);
        grp.writeEntry("content", post->content);
        grp.writeEntry("source", post->source);
        grp.writeEntry("favorited", post->isFavorited);
        grp.writeEntry("authorId", post->author.userId);
        grp.writeEntry("authorRealName", post->author.realName);
        grp.writeEntry("authorUserName", post->author.userName);
        grp.writeEntry("authorLocation", post->author.location);
        grp.writeEntry("authorDescription", post->author.description);
        grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
        grp.writeEntry("authorHomePageUrl", post->author.homePageUrl);
        grp.writeEntry("type", post->type);
        grp.writeEntry("media", post->media);
        grp.writeEntry("isRead", post->isRead);
        grp.writeEntry("conversationId", post->conversationId);
        grp.writeEntry("to", post->to);
        grp.writeEntry("cc", post->cc);
        grp.writeEntry("shares", post->shares);
        grp.writeEntry("replies", post->replies);
        grp.writeEntry("replyToPostId", post->replyToPostId);
        grp.writeEntry("replyToUserName", post->replyToUser.userName);
        grp.writeEntry("replyToObjectType", post->replyToObjectType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: loadedPlugins.keys()) {
            Plugin *plugin = loadedPlugins.value(p);
            qCWarning(CHOQOK) << "Deleting stale plugin '" << plugin->objectName() << "'";
            plugin->disconnect(&instance, SLOT(slotPluginDestroyed(QObject*)));
            plugin->deleteLater();;
            loadedPlugins.remove(p);
        }
```

#### AUTO 


```{c}
auto hours = (seconds - 45 * 60 + 3599) / 3600;
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *postwidget:
                   Choqok::UI::Global::mainWindow()->currentMicroBlog()->currentTimeline()->postWidgets()) {
            if (!postwidget->currentPost()->content.contains(m_filterText, Qt::CaseInsensitive)) {
                postwidget->hide();
            } else {
                postwidget->show();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *f: _filters) {
        f->writeConfig();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &datetime: groupList) {
        st = new PumpIOPost;
        KConfigGroup grp(&postsBackup, datetime.toString());
        st->creationDateTime = grp.readEntry("creationDateTime", QDateTime::currentDateTime());
        st->postId = grp.readEntry("postId", QString());
        st->link = grp.readEntry("link", QString());
        st->content = grp.readEntry("content", QString());
        st->source = grp.readEntry("source", QString());
        st->isFavorited = grp.readEntry("favorited", false);
        st->author.userId = grp.readEntry("authorId", QString());
        st->author.userName = grp.readEntry("authorUserName", QString());
        st->author.realName = grp.readEntry("authorRealName", QString());
        st->author.location = grp.readEntry("authorLocation", QString());
        st->author.description = grp.readEntry("authorDescription" , QString());
        st->author.profileImageUrl = grp.readEntry("authorProfileImageUrl", QString());
        st->author.homePageUrl = grp.readEntry("authorHomePageUrl", QString());
        st->type = grp.readEntry("type", QString());
        st->media = grp.readEntry("media"), QString();
        st->mediaSizeHeight = grp.readEntry("mediaHeight", 0);
        st->mediaSizeWidth = grp.readEntry("mediaWidth", 0);
        st->isRead = grp.readEntry("isRead", true);
        st->conversationId = grp.readEntry("conversationId", QString());
        st->to = grp.readEntry("to", QStringList());
        st->cc = grp.readEntry("cc", QStringList());
        st->shares = grp.readEntry("shares", QStringList());
        st->replies = grp.readEntry("replies", QString());
        st->replyToPostId = grp.readEntry("replyToPostId", QString());
        st->replyToUserName = grp.readEntry("replyToUserName", QString());
        st->replyToObjectType = grp.readEntry("replyToObjectType", QString());
        list.append(st);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tm: theAccount->timelineNames()) {
        requestTimeLine(theAccount, tm, mTimelineLatestId[theAccount][tm]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *post: postWidgets()) {
            post->setReadWithSignal();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: redirectList) {
        KIO::MimetypeJob *job = KIO::mimetype( QUrl::fromUserInput(url), KIO::HideProgressInfo );
        if ( !job ) {
            qCritical() << "Cannot create a http header request!";
            break;
        }
        connect( job, &KIO::MimetypeJob::permanentRedirection, this, &UnTiny::slot301Redirected );
        mParsingList.insert(job, postToParse);
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: list) {
            const QVariantMap elementMap = element.toMap();
            if (!elementMap[QLatin1String("object")].toMap().value(QLatin1String("deleted")).isNull()) {
                // Skip deleted posts
                continue;
            }
            posts.prepend(readPost(elementMap, new PumpIOPost));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModuleProxy *moduleProxy: d->moduleProxyList) {
                moduleProxy->save();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *mbw: d->timelines) {
            sum += mbw->unreadCount();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act: d->actions) {
        if (act) {
            act->setUserData(32, new PostWidgetUserData(d->parent));
            menu->addAction(act);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *acc: list) {
        if (acc->inherits("TwitterAccount")) {
            ui.accountsList->addItem(acc->alias());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: items) {
                QVariantMap e = element.toMap();
                QVariantMap list;
                list.insert(QLatin1String("id"), e.value(QLatin1String("id")).toString());
                list.insert(QLatin1String("name"), e.value(QLatin1String("displayName")).toString());
                lists.append(list);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Post *p: postList) {
        if (d->posts.keys().contains(p->postId)) {
            continue;
        }
        PostWidget *pw = d->currentAccount->microblog()->createPostWidget(d->currentAccount, p, this);
        if (pw) {
            addPostWidgetToUi(pw);
            if (!pw->isRead()) {
                ++unread;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: ImgLyRedirectList) {
        connect(Choqok::MediaManager::self(),&Choqok::MediaManager::imageFetched,
                this, &ImagePreview::slotImageFetched);
        QUrl ImgLyUrl = QUrl::fromUserInput(QStringLiteral("http://img.ly/show/thumb%1").arg(QString(url).remove(QLatin1String("http://img.ly"))));
        mParsingList.insert(ImgLyUrl, postToParse);
        mBaseUrlMap.insert(ImgLyUrl, url);
        Choqok::MediaManager::self()->fetchImage(ImgLyUrl, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: mAccount->microblog()->timelineNames()) {
        int newRow = timelinesTable->rowCount();
        timelinesTable->insertRow(newRow);
        timelinesTable->setItem(newRow, 0, new QTableWidgetItem(timeline));

        QCheckBox *enable = new QCheckBox(timelinesTable);
        enable->setChecked(mAccount->timelineNames().contains(timeline));
        timelinesTable->setCellWidget(newRow, 1, enable);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: PlixiRedirectList) {
        connect(Choqok::MediaManager::self(),
                SIGNAL(imageFetched(QString,QPixmap)),
                SLOT(slotImageFetched(QString,QPixmap)));
        QString PlixiUrl = QLatin1String("http://api.plixi.com/api/tpapi.svc/json/imagefromurl?size=thumbnail&url=") + url;
        mParsingList.insert(PlixiUrl, postToParse);
        mBaseUrlMap.insert(PlixiUrl, url);
        Choqok::MediaManager::self()->fetchImage(PlixiUrl, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: posts()) {
        wd->close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &list: json.toVariant().toList()) {
            postList.prepend(readDirectMessage(theAccount, list.toMap()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
            const Choqok::Post *post = (wd->currentPost());
            KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
            grp.writeEntry("creationDateTime", post->creationDateTime);
            grp.writeEntry("postId", post->postId);
            grp.writeEntry("text", post->content);
            grp.writeEntry("source", post->source);
            grp.writeEntry("inReplyToPostId", post->replyToPostId);
            grp.writeEntry("inReplyToUserId", post->replyToUserId);
            grp.writeEntry("favorited", post->isFavorited);
            grp.writeEntry("inReplyToUserName", post->replyToUserName);
            grp.writeEntry("authorId", post->author.userId);
            grp.writeEntry("authorUserName", post->author.userName);
            grp.writeEntry("authorRealName", post->author.realName);
            grp.writeEntry("authorHomePageUrl", post->author.homePageUrl);
            grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
            grp.writeEntry("authorDescription" , post->author.description);
            grp.writeEntry("isPrivate" , post->isPrivate);
            grp.writeEntry("authorLocation" , post->author.location);
            grp.writeEntry("isProtected" , post->author.isProtected);
            grp.writeEntry("isRead" , post->isRead);
            grp.writeEntry("repeatedFrom", post->repeatedFromUsername);
            grp.writeEntry("repeatedPostId", post->repeatedPostId);
            grp.writeEntry("repeatedDateTime", post->repeatedDateTime);
            grp.writeEntry("conversationId", post->conversationId);
            grp.writeEntry("mediaUrl", post->media);
            grp.writeEntry("quotedPostId", post->quotedPost.postId);
            grp.writeEntry("quotedProfileUrl", post->quotedPost.profileImageUrl);
            grp.writeEntry("quotedContent", post->quotedPost.content);
            grp.writeEntry("quotedUsername", post->quotedPost.username);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: _kpmp->loadedPlugins.keys()) {
        if (category.isEmpty() || p.category().compare(category) == 0) {
            result.append(_kpmp->loadedPlugins.value(p));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *ac: accList) {
            addBlog(ac, true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Filter::FilterField &field: fields.keys()) {
        ui.filterField->addItem(fields.value(field), field);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &list: json.toVariant().toList()) {
            Choqok::Post *post = readPost(theAccount, list.toMap(), new Choqok::Post);

            if (post) {
                postList.prepend(post);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &user: jsonList) {
            list << user.toMap()[QLatin1String("screen_name")].toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Account *acc: d->accountsList) {
            acc->microblog()->createPost(acc, d->submittedPost);
            d->submittedAccounts << acc;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: yfrogRedirectList) {
//         if( url.endsWith('j') || url.endsWith('p') || url.endsWith('g') ) //To check if it's Image or not!
        connect(Choqok::MediaManager::self(),
                SIGNAL(imageFetched(QString,QPixmap)),
                SLOT(slotImageFetched(QString,QPixmap)));
        QString yfrogThumbnailUrl = url + QLatin1String(".th.jpg");
        mParsingList.insert(yfrogThumbnailUrl, postToParse);
        mBaseUrlMap.insert(yfrogThumbnailUrl, url);
        Choqok::MediaManager::self()->fetchImage(yfrogThumbnailUrl, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TwitterApiSearchTimelineWidget *tm: mSearchTimelines.values()) {
        currentAccount()->configGroup()->writeEntry(QLatin1String("Search") + QString::number(i), tm->searchInfo().toString());
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &list: acc->lists()) {
                QVariantMap l = list.toMap();
                QListWidgetItem *item = new QListWidgetItem;
                item->setText(l.value(QLatin1String("name")).toString());
                item->setData(Qt::UserRole, l.value(QLatin1String("id")).toString());
                toList->addItem(item);
                ccList->addItem(item->clone());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *pw: tm->postWidgets()) {
                if (pw->currentPost()->author.userName == username) {
                    pw->close();
                }
            }
```

#### AUTO 


```{c}
auto minutes = (seconds - 45 + 59) / 60;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &user: json.array().toVariantList()) {
                followers.append(user.toMap()[QLatin1String("acct")].toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &u: json.array()) {
            const QJsonObject user = u.toObject();

            if (user.contains(QStringLiteral("statusnet_profile_url"))) {
                list.append(user.value(QLatin1String("statusnet_profile_url")).toString());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attica::Activity &act: list) {
        Choqok::Post *pst = new Choqok::Post;
        pst->postId = act.id();
        pst->content = act.message();
        pst->creationDateTime = act.timestamp();
        pst->link = act.link();
        pst->isError = !act.isValid();
        pst->author.userId = act.associatedPerson().id();
        pst->author.userName = act.associatedPerson().id();
        pst->author.homePageUrl = QUrl::fromUserInput(act.associatedPerson().homepage());
        pst->author.location = QStringLiteral("%1(%2)").arg(act.associatedPerson().country())
                               .arg(act.associatedPerson().city());
        pst->author.profileImageUrl = act.associatedPerson().avatarUrl();
        pst->author.realName = QStringLiteral("%1 %2").arg(act.associatedPerson().firstName())
                               .arg(act.associatedPerson().lastName());
        resultList.insert(0, pst);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &msg: map[QLatin1String("errors")].toList()) {
                errors.append(msg.toMap()[QLatin1String("message")].toString());
                qCCritical(CHOQOK) << "Error:" << errors.last();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->shares) {
                if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, post->author.userName).toDisplayString()
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &info: list) {
        QAction *act = new QAction(mBlogMenu);
        act->setText(info.name());
        act->setIcon(QIcon::fromTheme(info.icon()));
        act->setData(info.pluginName());
        connect(act, &QAction::triggered, this, &AccountsWidget::addAccount);
        mBlogMenu->addAction(act);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: list) {
            posts.prepend(readPost(element.toMap(), new MastodonPost));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: PumpIORedirectList) {
        connect(Choqok::MediaManager::self(), &Choqok::MediaManager::imageFetched,
                this, &ImagePreview::slotImageFetched);
        const QUrl pumpIOUrl = QUrl::fromUserInput(baseUrl + QLatin1String("_thumb") + imageExtension);
        mParsingList.insert(pumpIOUrl, postToParse);
        mBaseUrlMap.insert(pumpIOUrl, url);
        Choqok::MediaManager::self()->fetchImage(pumpIOUrl, Choqok::MediaManager::Async);
    }
```

#### AUTO 


```{c}
auto seconds = time.secsTo(QDateTime::currentDateTime());
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *filter: FilterSettings::self()->filters()) {
        if (filter->filterText().isEmpty()) {
            return;
        }
        if (filter->filterAction() == Filter::Remove && filter->dontHideReplies() &&
                (postToParse->currentPost()->replyToUserName.compare(postToParse->currentAccount()->username(),
                        Qt::CaseInsensitive) == 0 ||
                 postToParse->currentPost()->content.contains(QStringLiteral("@%1").arg(postToParse->currentAccount()->username())))
           ) {
            continue;
        }
        switch (filter->filterField()) {
        case Filter::Content:
            doFiltering(postToParse, filterText(postToParse->currentPost()->content, filter));
            break;
        case Filter::AuthorUsername:
            doFiltering(postToParse, filterText(postToParse->currentPost()->author.userName, filter));
            break;
        case Filter::ReplyToUsername:
            doFiltering(postToParse, filterText(postToParse->currentPost()->replyToUserName, filter));
            break;
        case Filter::Source:
            doFiltering(postToParse, filterText(postToParse->currentPost()->source, filter));
            break;
        default:
            break;
        };
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: m_account->microblog()->timelineNames()) {
        int newRow = timelinesTable->rowCount();
        timelinesTable->insertRow(newRow);
        timelinesTable->setItem(newRow, 0, new QTableWidgetItem(timeline));

        QCheckBox *enable = new QCheckBox(timelinesTable);
        enable->setChecked(m_account->timelineNames().contains(timeline));
        timelinesTable->setCellWidget(newRow, 1, enable);
    }
```

#### AUTO 


```{c}
auto queryItems = QUrlQuery(requestUrl.query()).queryItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: d->detectedUrls) {
        QString httpUrl(url);
        if (!httpUrl.startsWith(QLatin1String("http"), Qt::CaseInsensitive) &&
                !httpUrl.startsWith(QLatin1String("ftp"), Qt::CaseInsensitive)) {
            httpUrl.prepend(QLatin1String("http://"));
            text.replace(url, httpUrl);
        }

        text.replace(url, hrefTemplate.arg(httpUrl, url));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PostWidget *pw: d->sortedPostsList) {
            pw->setRead();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->cc) {
                if (id == PumpIOMicroBlog::PublicCollection) {
                    ss += i18n("Public") + QLatin1String(", ");
                } else if (followers.indexIn(id) != -1) {
                    ss += QLatin1String("<a href=\"") + QString(id).remove(QLatin1String("/api/user")) + QLatin1String("\">")
                          + i18n("Followers") + QLatin1String("</a>, ");
                } else if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, id)
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: availablePlugins(QString())) {
            if ((p.category().compare(QLatin1String("MicroBlogs")) == 0) ||
                    (p.category().compare(QLatin1String("Shorteners")) == 0))
            {
                continue;
            }

            const QString pluginName = p.pluginName();
            if (pluginsMap.value(pluginName, p.isPluginEnabledByDefault())) {
                if (!plugin(pluginName)) {
                    _kpmp->pluginsToLoad.push(pluginName);
                }
            } else {
                //This happens if the user unloaded plugins with the config plugin page.
                // No real need to be assync because the user usually unload few plugins
                // compared tto the number of plugin to load in a cold start. - Olivier
                if (plugin(pluginName)) {
                    unloadPlugin(pluginName);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModuleProxy *moduleProxy: moduleProxyList) {
                moduleProxy->load();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant elem: map[QLatin1String("statuses")].toList()) {
                        postsList.prepend(readStatusesFromJsonMap(elem.toMap()));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: _kpmp->plugins) {
        if (p.pluginName().compare(pluginId) == 0) {
            return p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: d->account->timelineNames()) {
        addTimelineWidgetToUi(timeline);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Account *ac: d->accounts) {
        if (ac->alias().compare(alias) == 0) {
            return ac;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job: m_createPostJobs.keys()) {
        if (m_accountJobs[job] == theAccount) {
            job->kill(KJob::EmitResult);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &elem: json.toVariant().toList()) {
                    postsList.prepend(readStatusesFromJsonMap(elem.toMap()));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *p: _kpmp->loadedPlugins.values()) {
        remaining.append(p->pluginId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: availablePlugins(QString::null)) { //krazy:exclude=nullstrassign for old broken gcc
            if ((p.category().compare(QLatin1String("MicroBlogs")) == 0) ||
                    (p.category().compare(QLatin1String("Shorteners")) == 0))
            {
                continue;
            }

            if (p.isPluginEnabledByDefault()) {
                _kpmp->pluginsToLoad.push(p.pluginName());
            }
        }
```

#### AUTO 


```{c}
auto text = prepareStatus(currentPost()->quotedPost.content);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &acc: accounts.keys()) {
        ui.accountsList->addItem(acc);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tm: account->timelineNames()) {
        ui.timelinesList->addItem(tm);
        if (accounts[acc].contains(tm)) {
            ui.timelinesList->item(ui.timelinesList->count() - 1)->setSelected(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QIcon::Mode &m: mods) {
        QPixmap pixmap = big.pixmap(result_size);
        QPainter painter(&pixmap);
        QFont font;
        font.setWeight(result_size.height() / 2);
        font.setBold(true);
        font.setItalic(true);
        painter.setFont(font);

        QString numberStr = QString::number(number);
        int textWidth = painter.fontMetrics().width(numberStr) + 6;

        if (textWidth < result_size.width() / 2) {
            textWidth = result_size.width() / 2;
        }

        QRect rct(result_size.width() - textWidth , result_size.width() / 2 ,
                  textWidth , result_size.height() / 2);
        QPointF center(rct.x() + rct.width() / 2 , rct.y() + rct.height() / 2);

        QPainterPath cyrcle_path;
        cyrcle_path.moveTo(center);
        cyrcle_path.arcTo(rct, 0, 360);

        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillPath(cyrcle_path , palette.color(QPalette::Active , QPalette::Window));
        painter.setPen(palette.color(QPalette::Active , QPalette::Text));
        painter.drawText(rct , Qt::AlignHCenter | Qt::AlignVCenter , QString::number(number));

        result.addPixmap(pixmap , m);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &servicePtr: pluginInfo.kcmServices()) {
        if (!servicePtr->noDisplay()) {
            KCModuleInfo moduleInfo(servicePtr);
            KCModuleProxy *currentModuleProxy = new KCModuleProxy(moduleInfo, moduleProxyParentWidget);
            if (currentModuleProxy->realModule()) {
                d->moduleProxyList << currentModuleProxy;
                if (mainWidget && !newTabWidget) {
                    // we already created one KCModuleProxy, so we need a tab widget.
                    // Move the first proxy into the tab widget and ensure this and subsequent
                    // proxies are in the tab widget
                    newTabWidget = new QTabWidget(configDialog);
                    moduleProxyParentWidget = newTabWidget;
                    mainWidget->setParent(newTabWidget);
                    KCModuleProxy *moduleProxy = qobject_cast<KCModuleProxy *>(mainWidget);
                    if (moduleProxy) {
                        newTabWidget->addTab(mainWidget, moduleProxy->moduleInfo().moduleName());
                        mainWidget = newTabWidget;
                    } else {
                        delete newTabWidget;
                        newTabWidget = nullptr;
                        moduleProxyParentWidget = configDialog;
                        mainWidget->setParent(nullptr);
                    }
                }

                if (newTabWidget) {
                    newTabWidget->addTab(currentModuleProxy, servicePtr->name());
                } else {
                    mainWidget = currentModuleProxy;
                }
            } else {
                delete currentModuleProxy;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::TimelineWidget *widget: timelines()) {
        if (widget->isClosable()) {
            closeSearch(widget);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *btn: buttons()) {
        if (btn) {
            btn->hide();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &list: map[QLatin1String("lists")].toList()) {
                twitterList.append(readListFromJsonMap(theAccount, list.toMap()));
            }
```

#### AUTO 


```{c}
auto origW = d->originalImage.width();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key: formdata.keys()) {
        data.append(newLine);
        data.append(header);
        data.append(formHeader.arg(key).toLatin1());
        data.append(newLine);
        data.append(newLine + formdata.value(key));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attica::Activity &act: list) {
        Choqok::Post *pst = new Choqok::Post;
        pst->postId = act.id();
        pst->content = act.message();
        pst->creationDateTime = act.timestamp();
        pst->link = act.link().toString();
        pst->isError = !act.isValid();
        pst->author.userId = act.associatedPerson().id();
        pst->author.userName = act.associatedPerson().id();
        pst->author.homePageUrl = act.associatedPerson().homepage();
        pst->author.location = QStringLiteral("%1(%2)").arg(act.associatedPerson().country())
                               .arg(act.associatedPerson().city());
        pst->author.profileImageUrl = act.associatedPerson().avatarUrl().toString();
        pst->author.realName = QStringLiteral("%1 %2").arg(act.associatedPerson().firstName())
                               .arg(act.associatedPerson().lastName());
        resultList.insert(0, pst);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *ac: accList) {
            connect(ac, &Choqok::Account::status, this, &MainWindow::updateBlog);
            addBlog(ac, true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *mbw: d->timelines) {
        connect(mbw, SIGNAL(forwardResendPost(QString)), d->composer, SLOT(setText(QString)));
        connect(mbw, &TimelineWidget::forwardReply, d->composer, &ComposerWidget::setText);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue& val : array) {
                ret += val.toString();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job: mJobsAccount.keys(theAccount)) {
        job->kill(KJob::EmitResult);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attica::Provider &p: providerList) {
        qCDebug(CHOQOK) << p.baseUrl();
        cfg_provider->addItem(p.name(), p.baseUrl());
        if (mAccount && mAccount->providerUrl() == p.baseUrl()) {
            selectedIndex = cfg_provider->count() - 1;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: PumpIORedirectList) {
        connect(Choqok::MediaManager::self(), SIGNAL(imageFetched(QString,QPixmap)),
                SLOT(slotImageFetched(QString,QPixmap)));
        const QString pumpIOUrl = baseUrl + QLatin1String("_thumb") + imageExtension;
        mParsingList.insert(pumpIOUrl, postToParse);
        mBaseUrlMap.insert(pumpIOUrl, url);
        Choqok::MediaManager::self()->fetchImage(pumpIOUrl, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dict: s.availableDictionaries().keys()) {
        const QString value = s.availableDictionaries().value(dict);
        QAction *act = new QAction(dict, d->langActions);
        act->setData(value);
        act->setCheckable(true);
        if (d->curLang == value) {
            act->setChecked(true);
        }
        connect(act, &QAction::triggered, this, &TextEdit::slotChangeSpellerLanguage);
        d->langActions->addAction(act);
        d->langActionMap.insert(value, act);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                emitResult();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *acc: Choqok::AccountManager::self()->accounts()) {
        d->accounts.insert(acc->alias(), d->accountsConf->readEntry(acc->alias(), QStringList()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name: list) {
        if (microblog()->timelineNames().contains(name)) {
            d->timelineNames.append(name);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item: ccList->selectedItems()) {
                QVariantMap user;
                QString id = item->data(Qt::UserRole).toString();
                if (id.contains(QLatin1String("acct:"))) {
                    user.insert(QLatin1String("objectType"), QLatin1String("person"));
                } else {
                    user.insert(QLatin1String("objectType"), QLatin1String("collection"));
                }
                user.insert(QLatin1String("id"), id);
                cc.append(user);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: posts().values()) {
        wd->close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &user: json.array().toVariantList()) {
                following.append(user.toMap()[QLatin1String("acct")].toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &elem: map[QLatin1String("statuses")].toList()) {
                        postsList.prepend(readStatusesFromJsonMap(elem.toMap()));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &playerName: MPRIS::getRunningPlayers()) {
            playerFound = true;
            MPRIS mprisPlayer(playerName);
            if (mprisPlayer.isValid() && mprisPlayer.isPlaying()) {
                trackInfo = mprisPlayer.getTrackMetadata();
                isPlaying = true;
                player = mprisPlayer.getPlayerIdentification().left(
                             mprisPlayer.getPlayerIdentification().lastIndexOf(QLatin1Char(' '))); //remove the version of player
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &servicePtr: pluginInfo.kcmServices()) {
        if (!servicePtr->noDisplay()) {
            KCModuleInfo moduleInfo(servicePtr);
            KCModuleProxy *currentModuleProxy = new KCModuleProxy(moduleInfo, moduleProxyParentWidget);
            if (currentModuleProxy->realModule()) {
                moduleProxyList << currentModuleProxy;
                if (mainWidget && !newTabWidget) {
                    // we already created one KCModuleProxy, so we need a tab widget.
                    // Move the first proxy into the tab widget and ensure this and subsequent
                    // proxies are in the tab widget
                    newTabWidget = new QTabWidget(configDialog);
                    moduleProxyParentWidget = newTabWidget;
                    mainWidget->setParent(newTabWidget);
                    KCModuleProxy *moduleProxy = qobject_cast<KCModuleProxy *>(mainWidget);
                    if (moduleProxy) {
                        newTabWidget->addTab(mainWidget, moduleProxy->moduleInfo().moduleName());
                        mainWidget = newTabWidget;
                    } else {
                        delete newTabWidget;
                        newTabWidget = nullptr;
                        moduleProxyParentWidget = configDialog;
                        mainWidget->setParent(nullptr);
                    }
                }

                if (newTabWidget) {
                    newTabWidget->addTab(currentModuleProxy, servicePtr->name());
                } else {
                    mainWidget = currentModuleProxy;
                }
            } else {
                delete currentModuleProxy;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: TwitgooRedirectList) {
        connect(Choqok::MediaManager::self(),
                SIGNAL(imageFetched(QString,QPixmap)),
                SLOT(slotImageFetched(QString,QPixmap)));
        QString TwitgooUrl = url + QLatin1String("/thumb");
        mParsingList.insert(TwitgooUrl, postToParse);
        mBaseUrlMap.insert(TwitgooUrl, url);
        Choqok::MediaManager::self()->fetchImage(TwitgooUrl, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *acc: list) {
        if (acc->inherits("TwitterAccount")) {
            ui.cfg_accountsList->addItem(acc->alias());
        }
    }
```

#### AUTO 


```{c}
auto pointSize = f.pointSizeF();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString url : urls) {
                iface.uploadFile(url);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: shares) {
                p->shares.append(element.toMap().value(QLatin1String("id")).toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &datetime: groupList) {
        st = new PumpIOPost;
        KConfigGroup grp(&postsBackup, datetime.toString());
        st->creationDateTime = grp.readEntry("creationDateTime", QDateTime::currentDateTime());
        st->postId = grp.readEntry("postId", QString());
        st->link = grp.readEntry("link", QUrl());
        st->content = grp.readEntry("content", QString());
        st->source = grp.readEntry("source", QString());
        st->isFavorited = grp.readEntry("favorited", false);
        st->author.userId = grp.readEntry("authorId", QString());
        st->author.userName = grp.readEntry("authorUserName", QString());
        st->author.realName = grp.readEntry("authorRealName", QString());
        st->author.location = grp.readEntry("authorLocation", QString());
        st->author.description = grp.readEntry("authorDescription" , QString());
        st->author.profileImageUrl = grp.readEntry("authorProfileImageUrl", QUrl());
        st->author.homePageUrl = grp.readEntry("authorHomePageUrl", QUrl());
        st->type = grp.readEntry("type", QString());
        st->media = grp.readEntry("media", QUrl());
        st->isRead = grp.readEntry("isRead", true);
        st->conversationId = grp.readEntry("conversationId", QString());
        st->to = grp.readEntry("to", QStringList());
        st->cc = grp.readEntry("cc", QStringList());
        st->shares = grp.readEntry("shares", QStringList());
        st->replies = grp.readEntry("replies", QUrl());
        st->replyToPostId = grp.readEntry("replyToPostId", QString());
        st->replyToUser.userName = grp.readEntry("replyToUserName", QString());
        st->replyToObjectType = grp.readEntry("replyToObjectType", QString());
        list.append(st);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &username: acc->following()) {
                QListWidgetItem *item = new QListWidgetItem;
                item->setText(PumpIOMicroBlog::userNameFromAcct(username));
                item->setData(Qt::UserRole, username);
                toList->addItem(item);
                ccList->addItem(item->clone());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
        PumpIOPost *post = dynamic_cast<PumpIOPost * >(wd->currentPost());
        KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
        grp.writeEntry("creationDateTime", post->creationDateTime);
        grp.writeEntry("postId", post->postId);
        grp.writeEntry("link", post->link);
        grp.writeEntry("content", post->content);
        grp.writeEntry("source", post->source);
        grp.writeEntry("favorited", post->isFavorited);
        grp.writeEntry("authorId", post->author.userId);
        grp.writeEntry("authorRealName", post->author.realName);
        grp.writeEntry("authorUserName", post->author.userName);
        grp.writeEntry("authorLocation", post->author.location);
        grp.writeEntry("authorDescription", post->author.description);
        grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
        grp.writeEntry("authorHomePageUrl", post->author.homePageUrl);
        grp.writeEntry("type", post->type);
        grp.writeEntry("media", post->media);
        grp.writeEntry("isRead", post->isRead);
        grp.writeEntry("conversationId", post->conversationId);
        grp.writeEntry("to", post->to);
        grp.writeEntry("cc", post->cc);
        grp.writeEntry("shares", post->shares);
        grp.writeEntry("replies", post->replies);
        grp.writeEntry("replyToPostId", post->replyToPostId);
        grp.writeEntry("replyToUserName", post->replyToUserName);
        grp.writeEntry("replyToObjectType", post->replyToObjectType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QIcon::Mode &m: mods) {
        QPixmap pixmap = big.pixmap(result_size);
        QPainter painter(&pixmap);
        QFont font;
        font.setWeight(result_size.height() / 2);
        font.setBold(true);
        font.setItalic(true);
        painter.setFont(font);

        QString numberStr = QString::number(number);
        int textWidth = painter.fontMetrics().horizontalAdvance(numberStr) + 6;

        if (textWidth < result_size.width() / 2) {
            textWidth = result_size.width() / 2;
        }

        QRect rct(result_size.width() - textWidth , result_size.width() / 2 ,
                  textWidth , result_size.height() / 2);
        QPointF center(rct.x() + rct.width() / 2 , rct.y() + rct.height() / 2);

        QPainterPath cyrcle_path;
        cyrcle_path.moveTo(center);
        cyrcle_path.arcTo(rct, 0, 360);

        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillPath(cyrcle_path , palette.color(QPalette::Active , QPalette::Window));
        painter.setPen(palette.color(QPalette::Active , QPalette::Text));
        painter.drawText(rct , Qt::AlignHCenter | Qt::AlignVCenter , QString::number(number));

        result.addPixmap(pixmap , m);
    }
```

#### AUTO 


```{c}
auto origH = d->originalImage.height();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: redirectList) {
        KJob *job = sheduleParsing(url);
        if (job) {
            mParsingList.insert(job, postToParse);
            job->start();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModuleProxy *moduleProxy: moduleProxyList) {
                moduleProxy->save();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group: postsBackup.groupList()) {
        postsBackup.deleteGroup(group);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Filter::FilterAction &action: actions.keys()) {
        ui.filterAction->addItem(actions.value(action), action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: ImgLyRedirectList) {
        connect(Choqok::MediaManager::self(),
                SIGNAL(imageFetched(QString,QPixmap)),
                SLOT(slotImageFetched(QString,QPixmap)));
        QString ImgLyUrl = QStringLiteral("http://img.ly/show/thumb%1").arg(QString(url).remove(QLatin1String("http://img.ly")));
        mParsingList.insert(ImgLyUrl, postToParse);
        mBaseUrlMap.insert(ImgLyUrl, url);
        Choqok::MediaManager::self()->fetchImage(ImgLyUrl, Choqok::MediaManager::Async);
    }
```

#### AUTO 


```{c}
const auto currentDateTime = QDateTime::currentDateTimeUtc();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: _kpmp->loadedPlugins.keys()) {
        if (_kpmp->loadedPlugins.value(p) == plugin) {
            const QString pluginName = p.pluginName();
            _kpmp->loadedPlugins.remove(p);
            Q_EMIT pluginUnloaded(pluginName);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &servicePtr: pluginInfo.kcmServices()) {
        if (!servicePtr->noDisplay()) {
            KCModuleInfo moduleInfo(servicePtr);
            KCModuleProxy *currentModuleProxy = new KCModuleProxy(moduleInfo, moduleProxyParentWidget);
            if (currentModuleProxy->realModule()) {
                moduleProxyList << currentModuleProxy;
                if (mainWidget && !newTabWidget) {
                    // we already created one KCModuleProxy, so we need a tab widget.
                    // Move the first proxy into the tab widget and ensure this and subsequent
                    // proxies are in the tab widget
                    newTabWidget = new QTabWidget(configDialog);
                    moduleProxyParentWidget = newTabWidget;
                    mainWidget->setParent(newTabWidget);
                    KCModuleProxy *moduleProxy = qobject_cast<KCModuleProxy *>(mainWidget);
                    if (moduleProxy) {
                        newTabWidget->addTab(mainWidget, moduleProxy->moduleInfo().moduleName());
                        mainWidget = newTabWidget;
                    } else {
                        delete newTabWidget;
                        newTabWidget = 0;
                        moduleProxyParentWidget = configDialog;
                        mainWidget->setParent(0);
                    }
                }

                if (newTabWidget) {
                    newTabWidget->addTab(currentModuleProxy, servicePtr->name());
                } else {
                    mainWidget = currentModuleProxy;
                }
            } else {
                delete currentModuleProxy;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *wd: d->timelines) {
        sum += wd->unreadCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: acc->timelineNames()) {
            QUrl url(acc->host());
            url = url.adjusted(QUrl::StripTrailingSlash);
            url.setPath(url.path() + QLatin1Char('/') + (m_timelinesPaths[timeline].arg(acc->username())));

            QOAuth::ParamMap oAuthParams;
            const QString lastActivityId(lastTimelineId(theAccount, timeline));
            if (!lastActivityId.isEmpty()) {
                oAuthParams.insert("count", QByteArray::number(200));
                oAuthParams.insert("since", QUrl::toPercentEncoding(lastActivityId));
            } else {
                oAuthParams.insert("count", QByteArray::number(Choqok::BehaviorSettings::countOfPosts()));
            }

            KIO::StoredTransferJob *job = KIO::storedGet(url, KIO::Reload, KIO::HideProgressInfo);
            if (!job) {
                qCDebug(CHOQOK) << "Cannot create an http GET request!";
                continue;
            }
            job->addMetaData(QLatin1String("customHTTPHeader"), authorizationMetaData(acc, url, QOAuth::GET,
                             oAuthParams));
            m_timelinesRequests[job] = timeline;
            m_accountJobs[job] = acc;
            connect(job, SIGNAL(result(KJob*)), this, SLOT(slotUpdateTimeline(KJob*)));
            job->start();
        }
```

#### AUTO 


```{c}
auto days = (seconds - 18 * 3600 + 24 * 3600 - 1) / (24 * 3600);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: to) {
            QVariantMap toElementMap = element.toMap();
            QString toElementType = toElementMap.value(QLatin1String("objectType")).toString();
            if (toElementType == QLatin1String("person") || toElementType == QLatin1String("collection")) {
                const QString toId = toElementMap.value(QLatin1String("id")).toString();

                if (toId.compare(QLatin1String("acct:")) != 0) {
                    p->to.append(toId);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *mbw: d->timelines) {
        sum += mbw->unreadCount();
    }
```

#### AUTO 


```{c}
auto q_answer = KMessageBox::questionYesNo(Choqok::UI::Global::mainWindow(), d->mBlog->repeatQuestion(),
                                               QString(), KStandardGuiItem::yes(), KStandardGuiItem::cancel(),
                                               QLatin1String("dontAskRepeatConfirm"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->shares) {
                if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, id)
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dict: s.availableDictionaries().keys()) {
        const QString value = s.availableDictionaries().value(dict);
        QAction *act = new QAction(dict, d->langActions);
        act->setData(value);
        act->setCheckable(true);
        if (d->curLang == value) {
            act->setChecked(true);
        }
        connect(act, SIGNAL(triggered(bool)), SLOT(slotChangeSpellerLanguage()));
        d->langActions->addAction(act);
        d->langActionMap.insert(value, act);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *ac: AccountManager::self()->accounts()) {
        addAccount(ac);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TwitterApiSearchTimelineWidget *searchWidget: mSearchTimelines) {
        closeSearch(searchWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: acc->timelineNames()) {
            QUrl url(acc->host());
            url = url.adjusted(QUrl::StripTrailingSlash);
            url.setPath(url.path() + QLatin1Char('/') + m_timelinesPaths[timeline]);

            QUrlQuery query;
            if (timeline.compare(QLatin1String("Local")) == 0) {
                query.addQueryItem(QLatin1String("local"), QLatin1String("true"));
            }
            url.setQuery(query);

            KIO::StoredTransferJob *job = KIO::storedGet(url, KIO::Reload, KIO::HideProgressInfo);
            if (!job) {
                qCDebug(CHOQOK) << "Cannot create an http GET request!";
                continue;
            }
            job->addMetaData(QLatin1String("customHTTPHeader"), authorizationMetaData(acc));
            m_timelinesRequests[job] = timeline;
            m_accountJobs[job] = acc;
            connect(job, &KIO::StoredTransferJob::result, this, &MastodonMicroBlog::slotUpdateTimeline);
            job->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &plugin: plugins) {
        d->ui.uploaderPlugin->addItem(QIcon::fromTheme(plugin.icon()), plugin.name(), plugin.pluginName());
        d->availablePlugins.insert(plugin.pluginName(), plugin);
    }
```

#### AUTO 


```{c}
auto dir = getDirection(currentPost()->quotedPost.content);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModuleProxy *moduleProxy: moduleProxyList) {
                QStringList parentComponents = moduleProxy->moduleInfo().service()->property(QLatin1String("X-KDE-ParentComponents")).toStringList();
                moduleProxy->save();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPushButton *btn: buttons()) {
        if (btn) { //A crash happens here :/
            btn->show();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job: mCreatePostMap.keys()) {
            if (mJobsAccount[job] == theAccount) {
                job->kill(KJob::EmitResult);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &list: json.toVariant().toList()) {
            postList.prepend(readPost(theAccount, list.toMap(), new Choqok::Post));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item: toList->selectedItems()) {
                QVariantMap user;
                QString id = item->data(Qt::UserRole).toString();
                if (id.contains(QLatin1String("acct:"))) {
                    user.insert(QLatin1String("objectType"), QLatin1String("person"));
                } else {
                    user.insert(QLatin1String("objectType"), QLatin1String("collection"));
                }
                user.insert(QLatin1String("id"), id);
                to.append(user);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->to) {
                if (id == PumpIOMicroBlog::PublicCollection) {
                    ss += i18n("Public") + QLatin1String(", ");
                } else if (followers.indexIn(id) != -1) {
                    ss += QLatin1String("<a href=\"") + QString(id).remove(QLatin1String("/api/user")) + QLatin1String("\">")
                          + i18n("Followers") + QLatin1String("</a>, ");
                } else if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, id)
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tm: timelineNames()) {
        if (tm.startsWith(QLatin1Char('@'))) {
            lists.append(tm);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group: postsBackup.groupList()) {
            postsBackup.deleteGroup(group);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url: TwitgooRedirectList) {
        connect(Choqok::MediaManager::self(), &Choqok::MediaManager::imageFetched,
                this, &ImagePreview::slotImageFetched);
        QUrl TwitgooUrl = QUrl::fromUserInput(url + QLatin1String("/thumb"));
        mParsingList.insert(TwitgooUrl, postToParse);
        mBaseUrlMap.insert(TwitgooUrl, url);
        Choqok::MediaManager::self()->fetchImage(TwitgooUrl, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: account->microblog()->timelineNames()) {
        if (account->timelineNames().contains(timeline)) {
            if (!timelines().contains(timeline)) {
                addTimelineWidgetToUi(timeline);
            }
        } else if (timelines().contains(timeline)) {
            Choqok::UI::TimelineWidget *tm = timelines().take(timeline);
            tm->deleteLater();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModuleProxy *moduleProxy: d->moduleProxyList) {
                moduleProxy->load();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
            const Choqok::Post *post = (wd->currentPost());
            KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
            grp.writeEntry("creationDateTime", post->creationDateTime);
            grp.writeEntry("postId", post->postId);
            grp.writeEntry("text", post->content);
            grp.writeEntry("source", post->source);
            grp.writeEntry("inReplyToPostId", post->replyToPostId);
            grp.writeEntry("inReplyToUserId", post->replyToUser.userId);
            grp.writeEntry("favorited", post->isFavorited);
            grp.writeEntry("inReplyToUserName", post->replyToUser.userName);
            grp.writeEntry("authorId", post->author.userId);
            grp.writeEntry("authorUserName", post->author.userName);
            grp.writeEntry("authorRealName", post->author.realName);
            grp.writeEntry("authorHomePageUrl", post->author.homePageUrl);
            grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
            grp.writeEntry("authorDescription" , post->author.description);
            grp.writeEntry("isPrivate" , post->isPrivate);
            grp.writeEntry("authorLocation" , post->author.location);
            grp.writeEntry("isProtected" , post->author.isProtected);
            grp.writeEntry("isRead" , post->isRead);
            grp.writeEntry("repeatedFrom", post->repeatedFromUser.userName);
            grp.writeEntry("repeatedFromUserHomePage", post->repeatedFromUser.homePageUrl);
            grp.writeEntry("repeatedPostId", post->repeatedPostId);
            grp.writeEntry("repeatedDateTime", post->repeatedDateTime);
            grp.writeEntry("conversationId", post->conversationId);
            grp.writeEntry("mediaUrl", post->media);
            grp.writeEntry("quotedPostId", post->quotedPost.postId);
            grp.writeEntry("quotedProfileUrl", post->quotedPost.user.profileImageUrl);
            grp.writeEntry("quotedContent", post->quotedPost.content);
            grp.writeEntry("quotedUsername", post->quotedPost.user.userName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: postWidgets()) {
        height += wd->height() + 5;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
        const Choqok::Post *post = wd->currentPost();
        KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
        grp.writeEntry("creationDateTime", post->creationDateTime);
        grp.writeEntry("postId", post->postId);
        grp.writeEntry("text", post->content);
        grp.writeEntry("authorId", post->author.userId);
        grp.writeEntry("authorUserName", post->author.userName);
        grp.writeEntry("authorRealName", post->author.realName);
        grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
        grp.writeEntry("authorDescription" , post->author.description);
        grp.writeEntry("authorLocation" , post->author.location);
        grp.writeEntry("authorUrl" , post->author.homePageUrl);
        grp.writeEntry("link", post->link);
        grp.writeEntry("isRead" , post->isRead);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: mAccount->microblog()->timelineNames()) {
        int newRow = timelinesTable->rowCount();
        timelinesTable->insertRow(newRow);
        Choqok::TimelineInfo *info = mAccount->microblog()->timelineInfo(timeline);
        QTableWidgetItem *item = new QTableWidgetItem(info->name);
        item->setData(32, timeline);
        item->setToolTip(info->description);
        timelinesTable->setItem(newRow, 0, item);

        QCheckBox *enable = new QCheckBox(timelinesTable);
        enable->setChecked(mAccount->timelineNames().contains(timeline));
        timelinesTable->setCellWidget(newRow, 1, enable);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user: list) {
            // QUrl::host() is needed to skip scheme check
            if (GNUSocialApiMicroBlog::hostFromProfileUrl(user).compare(QUrl(theAccount->host()).host()) == 0) {
                sameHost.append(GNUSocialApiMicroBlog::usernameFromProfileUrl(user));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job: mParsingList.keys()) {
        job->suspend();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &thumb_url: thumbList) {
        connect(Choqok::MediaManager::self(), &Choqok::MediaManager::imageFetched,
                this, &VideoPreview::slotImageFetched);

        Choqok::MediaManager::self()->fetchImage(thumb_url, Choqok::MediaManager::Async);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModuleProxy *moduleProxy: d->moduleProxyList) {
                QStringList parentComponents = moduleProxy->moduleInfo().service()->property(QLatin1String("X-KDE-ParentComponents")).toStringList();
                moduleProxy->save();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job: mParsingList.keys()) {
        job->kill();
    }
```

#### AUTO 


```{c}
const auto parameters = QVariantMap(oauthParams).unite(signingParameters);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &plugin: plugins) {
        shortenPlugins->addItem(QIcon::fromTheme(plugin.icon()), plugin.name(), plugin.pluginName());
        availablePlugins.insert(plugin.pluginName(), plugin);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &datetime: groupList) {
        st = new PumpIOPost;
        KConfigGroup grp(&postsBackup, datetime.toString());
        st->creationDateTime = grp.readEntry("creationDateTime", QDateTime::currentDateTime());
        st->postId = grp.readEntry("postId", QString());
        st->link = grp.readEntry("link", QString());
        st->content = grp.readEntry("content", QString());
        st->source = grp.readEntry("source", QString());
        st->isFavorited = grp.readEntry("favorited", false);
        st->author.userId = grp.readEntry("authorId", QString());
        st->author.userName = grp.readEntry("authorUserName", QString());
        st->author.realName = grp.readEntry("authorRealName", QString());
        st->author.location = grp.readEntry("authorLocation", QString());
        st->author.description = grp.readEntry("authorDescription" , QString());
        st->author.profileImageUrl = grp.readEntry("authorProfileImageUrl", QString());
        st->author.homePageUrl = grp.readEntry("authorHomePageUrl", QString());
        st->type = grp.readEntry("type", QString());
        st->media = grp.readEntry("media"), QString();
        st->isRead = grp.readEntry("isRead", true);
        st->conversationId = grp.readEntry("conversationId", QString());
        st->to = grp.readEntry("to", QStringList());
        st->cc = grp.readEntry("cc", QStringList());
        st->shares = grp.readEntry("shares", QStringList());
        st->replies = grp.readEntry("replies", QString());
        st->replyToPostId = grp.readEntry("replyToPostId", QString());
        st->replyToUserName = grp.readEntry("replyToUserName", QString());
        st->replyToObjectType = grp.readEntry("replyToObjectType", QString());
        list.append(st);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *mbw: d->timelines) {
        connect(mbw, SIGNAL(forwardResendPost(QString)), d->composer, SLOT(setText(QString)));
        connect(mbw, SIGNAL(forwardReply(QString,QString,QString)), d->composer, SLOT(setText(QString,QString,QString)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TwitterApiSearchTimelineWidget *searchWidget: mSearchTimelines.values()) {
        closeSearch(searchWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *wd: d->timelines) {
        wd->removeOldPosts();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: _kpmp->loadedPlugins.keys()) {
        if (_kpmp->loadedPlugins.value(p) == plugin) {
            return p;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: cc) {
            QVariantMap ccElementMap = element.toMap();
            QString ccElementType = ccElementMap.value(QLatin1String("objectType")).toString();
            if (ccElementType == QLatin1String("person") || ccElementType == QLatin1String("collection")) {
                const QString ccId = ccElementMap.value(QLatin1String("id")).toString();

                if (ccId.compare(QLatin1String("acct:")) != 0) {
                    p->cc.append(ccId);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &servicePtr: pluginInfo.kcmServices()) {
        if (!servicePtr->noDisplay()) {
            KCModuleProxy *currentModuleProxy = new KCModuleProxy(servicePtr, moduleProxyParentWidget);
            if (currentModuleProxy->realModule()) {
                moduleProxyList << currentModuleProxy;
                if (mainWidget && !newTabWidget) {
                    // we already created one KCModuleProxy, so we need a tab widget.
                    // Move the first proxy into the tab widget and ensure this and subsequent
                    // proxies are in the tab widget
                    newTabWidget = new QTabWidget(configDialog);
                    moduleProxyParentWidget = newTabWidget;
                    mainWidget->setParent(newTabWidget);
                    KCModuleProxy *moduleProxy = qobject_cast<KCModuleProxy *>(mainWidget);
                    if (moduleProxy) {
                        newTabWidget->addTab(mainWidget, servicePtr->name());
                        mainWidget = newTabWidget;
                    } else {
                        delete newTabWidget;
                        newTabWidget = nullptr;
                        moduleProxyParentWidget = configDialog;
                        mainWidget->setParent(nullptr);
                    }
                }

                if (newTabWidget) {
                    newTabWidget->addTab(currentModuleProxy, servicePtr->name());
                } else {
                    mainWidget = currentModuleProxy;
                }
            } else {
                delete currentModuleProxy;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &datetime: groupList) {
        st = new MastodonPost;
        KConfigGroup grp(&postsBackup, datetime.toString());
        st->creationDateTime = grp.readEntry("creationDateTime", QDateTime::currentDateTime());
        st->postId = grp.readEntry("postId", QString());
        st->link = grp.readEntry("link", QUrl());
        st->content = grp.readEntry("content", QString());
        st->source = grp.readEntry("source", QString());
        st->isFavorited = grp.readEntry("favorited", false);
        st->author.userId = grp.readEntry("authorId", QString());
        st->author.userName = grp.readEntry("authorUserName", QString());
        st->author.realName = grp.readEntry("authorRealName", QString());
        st->author.description = grp.readEntry("authorDescription" , QString());
        st->author.profileImageUrl = grp.readEntry("authorProfileImageUrl", QUrl());
        st->author.homePageUrl = grp.readEntry("authorHomePageUrl", QUrl());
        st->isRead = grp.readEntry("isRead", true);
        st->conversationId = grp.readEntry("conversationId", QString());
        st->replyToPostId = grp.readEntry("replyToPostId", QString());
        st->replyToUser.userId = grp.readEntry("replyToUserId", QString());
        st->repeatedFromUser.userId = grp.readEntry("repeatedFromUserId", QString());
        st->repeatedFromUser.userName = grp.readEntry("repeatedFromUserName", QString());
        st->repeatedFromUser.homePageUrl = grp.readEntry("repeatedFromUserHomePage", QUrl());
        st->repeatedPostId = grp.readEntry("repeatedPostId", QString());
        st->repeatedDateTime = grp.readEntry("repeatedDateTime", QDateTime());

        list.append(st);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Account *ac: d->accounts) {
        ac->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Filter *filter: filters) {
        addNewFilter(filter);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *acc: scheduledTasks.keys()) {
        switch (scheduledTasks.value(acc)) {
        case Update:
            updateTimelines(acc);
            break;
        default:
            break;
        };
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &grp: groups) {
        if (grp.startsWith(QLatin1String("Filter_"))) {
            KSharedConfig::openConfig()->deleteGroup(grp);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TimelineWidget *wd: d->timelines) {
        wd->settingsChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: acc->timelineNames()) {
            QUrl url(acc->host());
            url = url.adjusted(QUrl::StripTrailingSlash);
            url.setPath(url.path() + m_timelinesPaths[timeline].arg(acc->username()));
            QUrlQuery query;

            const QString lastActivityId(lastTimelineId(theAccount, timeline));
            if (!lastActivityId.isEmpty()) {
                query.addQueryItem(QLatin1String("count"), QString::number(200));
                query.addQueryItem(QLatin1String("since"), lastActivityId);
            } else {
                query.addQueryItem(QLatin1String("count"), QString::number(Choqok::BehaviorSettings::countOfPosts()));
            }
            url.setQuery(query);

            KIO::StoredTransferJob *job = KIO::storedGet(url, KIO::Reload, KIO::HideProgressInfo);
            if (!job) {
                qCDebug(CHOQOK) << "Cannot create an http GET request!";
                continue;
            }
            job->addMetaData(QLatin1String("customHTTPHeader"), acc->oAuth()->authorizationHeader(url, QNetworkAccessManager::GetOperation));
            m_timelinesRequests[job] = timeline;
            m_accountJobs[job] = acc;
            connect(job, &KIO::StoredTransferJob::result, this, &PumpIOMicroBlog::slotUpdateTimeline);
            job->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *postwidget:
                   Choqok::UI::Global::mainWindow()->currentMicroBlog()->currentTimeline()->postWidgets()) {
            if (!postwidget->currentPost()->author.userName.contains(m_filterUser, Qt::CaseInsensitive)) {
                postwidget->hide();
            } else {
                postwidget->show();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
            const Choqok::Post *post = (wd->currentPost());
            KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
            grp.writeEntry("creationDateTime", post->creationDateTime);
            grp.writeEntry("postId", post->postId);
            grp.writeEntry("text", post->content);
            grp.writeEntry("source", post->source);
            grp.writeEntry("inReplyToPostId", post->replyToPostId);
            grp.writeEntry("inReplyToUserId", post->replyToUserId);
            grp.writeEntry("favorited", post->isFavorited);
            grp.writeEntry("inReplyToUserName", post->replyToUserName);
            grp.writeEntry("authorId", post->author.userId);
            grp.writeEntry("authorUserName", post->author.userName);
            grp.writeEntry("authorRealName", post->author.realName);
            grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
            grp.writeEntry("authorDescription" , post->author.description);
            grp.writeEntry("isPrivate" , post->isPrivate);
            grp.writeEntry("authorLocation" , post->author.location);
            grp.writeEntry("isProtected" , post->author.isProtected);
            grp.writeEntry("isRead" , post->isRead);
            grp.writeEntry("repeatedFrom", post->repeatedFromUsername);
            grp.writeEntry("repeatedPostId", post->repeatedPostId);
            grp.writeEntry("repeatedDateTime", post->repeatedDateTime);
            grp.writeEntry("conversationId", post->conversationId);
            grp.writeEntry("mediaUrl", post->media);
            grp.writeEntry("quotedPostId", post->quotedPost.postId);
            grp.writeEntry("quotedProfileUrl", post->quotedPost.profileImageUrl);
            grp.writeEntry("quotedContent", post->quotedPost.content);
            grp.writeEntry("quotedUsername", post->quotedPost.username);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
        PumpIOPost *post = dynamic_cast<PumpIOPost * >(wd->currentPost());
        KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
        grp.writeEntry("creationDateTime", post->creationDateTime);
        grp.writeEntry("postId", post->postId);
        grp.writeEntry("link", post->link);
        grp.writeEntry("content", post->content);
        grp.writeEntry("source", post->source);
        grp.writeEntry("favorited", post->isFavorited);
        grp.writeEntry("authorId", post->author.userId);
        grp.writeEntry("authorRealName", post->author.realName);
        grp.writeEntry("authorUserName", post->author.userName);
        grp.writeEntry("authorLocation", post->author.location);
        grp.writeEntry("authorDescription", post->author.description);
        grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
        grp.writeEntry("authorHomePageUrl", post->author.homePageUrl);
        grp.writeEntry("type", post->type);
        grp.writeEntry("media", post->media);
        grp.writeEntry("mediaHeight", post->mediaSizeHeight);
        grp.writeEntry("mediaWidth", post->mediaSizeWidth);
        grp.writeEntry("isRead", post->isRead);
        grp.writeEntry("conversationId", post->conversationId);
        grp.writeEntry("to", post->to);
        grp.writeEntry("cc", post->cc);
        grp.writeEntry("shares", post->shares);
        grp.writeEntry("replies", post->replies);
        grp.writeEntry("replyToPostId", post->replyToPostId);
        grp.writeEntry("replyToUserName", post->replyToUserName);
        grp.writeEntry("replyToObjectType", post->replyToObjectType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name: lists) {
        tms.append(name);
        addTimelineName(name);
        QString url = QLatin1String("/lists/statuses");
        timelineApiPath[name] = url + QLatin1String(".%1");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &element: items) {
                following.append(element.toMap().value(QLatin1String("id")).toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &grp: accountGroups) {
        qCDebug(CHOQOK) << grp;
        KConfigGroup cg(d->conf, grp);
//         KConfigGroup pluginConfig( d->conf, QLatin1String("Plugins") );

        QString blog = cg.readEntry("MicroBlog", QString());
        Choqok::MicroBlog *mBlog = nullptr;
        if (!blog.isEmpty() && cg.readEntry("Enabled", true)) {
            mBlog = qobject_cast<MicroBlog *>(PluginManager::self()->loadPlugin(blog));
        }
        if (mBlog) {
            const QString alias = cg.readEntry("Alias", QString());
            if (alias.isEmpty()) {
                continue;    ///Unknown alias
            }
            Account *acc = mBlog->createNewAccount(alias);
            if (acc) {
                d->accounts.append(acc);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->to) {
                if (id == PumpIOMicroBlog::PublicCollection) {
                    ss += i18n("Public") + QLatin1String(", ");
                } else if (followers.indexIn(id) != -1) {
                    ss += QLatin1String("<a href=\"") + QString(id).remove(QLatin1String("/api/user")) + QLatin1String("\">")
                          + i18n("Followers") + QLatin1String("</a>, ");
                } else if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, post->author.userName).toDisplayString()
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *acc: Choqok::AccountManager::self()->accounts()) {
        d->accountsConf->writeEntry(acc->alias(), d->accounts.value(acc->alias()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Filter::FilterType &type: types.keys()) {
        ui.filterType->addItem(types.value(type), type);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Twitter::List &l: list) {
            QListWidgetItem *item = new QListWidgetItem(listWidget);
            QString iText;
            if (l.description.isEmpty()) {
                iText = l.fullname;
            } else {
                iText = QStringLiteral("%1 [%2]").arg(l.fullname).arg(l.description);
            }
            item->setText(iText);
            item->setData(32, l.slug);
            listWidget->addItem(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: _kpmp->plugins) {
        if ((p.category().compare(category) == 0) && !p.service()->noDisplay()) {
            result.append(p);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->to) {
                if (id == PumpIOMicroBlog::PublicCollection) {
                    ss += i18n("Public") + QLatin1String(", ");
                } else if (followers.indexIn(id) != -1) {
                    ss += QLatin1String("<a href=\"") + QString(id).remove(QLatin1String("/api/user")) + QLatin1String("\">")
                          + i18n("Followers") + QLatin1String("</a>, ");
                } else if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, post->author).toDisplayString()
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &list: acc->lists()) {
            QVariantMap l = list.toMap();
            QListWidgetItem *item = new QListWidgetItem;
            item->setText(l.value(QLatin1String("name")).toString());
            item->setData(Qt::UserRole, l.value(QLatin1String("id")).toString());
            toList->addItem(item);
            ccList->addItem(item->clone());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
                iface.uploadFile(url);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: acc->timelineNames()) {
            QUrl url(acc->host());
            url = url.adjusted(QUrl::StripTrailingSlash);
            url.setPath(url.path() + QLatin1Char('/') + (m_timelinesPaths[timeline].arg(acc->username())));
            QUrlQuery query;

            QVariantMap oAuthParams;
            const QString lastActivityId(lastTimelineId(theAccount, timeline));
            if (!lastActivityId.isEmpty()) {
                oAuthParams.insert(QLatin1String("count"), QByteArray::number(200));
                query.addQueryItem(QLatin1String("count"), QString::number(200));
                oAuthParams.insert(QLatin1String("since"), QUrl::toPercentEncoding(lastActivityId));
                query.addQueryItem(QLatin1String("since"), lastActivityId);
            } else {
                oAuthParams.insert(QLatin1String("count"), QByteArray::number(Choqok::BehaviorSettings::countOfPosts()));
                query.addQueryItem(QLatin1String("count"), QString::number(Choqok::BehaviorSettings::countOfPosts()));
            }
            url.setQuery(query);

            KIO::StoredTransferJob *job = KIO::storedGet(url, KIO::Reload, KIO::HideProgressInfo);
            if (!job) {
                qCDebug(CHOQOK) << "Cannot create an http GET request!";
                continue;
            }
            job->addMetaData(QLatin1String("customHTTPHeader"), authorizationMetaData(acc, url, QNetworkAccessManager::GetOperation,
                             oAuthParams));
            m_timelinesRequests[job] = timeline;
            m_accountJobs[job] = acc;
            connect(job, SIGNAL(result(KJob*)), this, SLOT(slotUpdateTimeline(KJob*)));
            job->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *wd: timeline) {
            const Choqok::Post *post = (wd->currentPost());
            KConfigGroup grp(&postsBackup, post->creationDateTime.toString());
            grp.writeEntry("creationDateTime", post->creationDateTime);
            grp.writeEntry("postId", post->postId);
            grp.writeEntry("text", post->content);
            grp.writeEntry("source", post->source);
            grp.writeEntry("inReplyToPostId", post->replyToPostId);
            grp.writeEntry("inReplyToUserId", post->replyToUserId);
            grp.writeEntry("favorited", post->isFavorited);
            grp.writeEntry("inReplyToUserName", post->replyToUserName);
            grp.writeEntry("authorId", post->author.userId);
            grp.writeEntry("authorUserName", post->author.userName);
            grp.writeEntry("authorRealName", post->author.realName);
            grp.writeEntry("authorProfileImageUrl", post->author.profileImageUrl);
            grp.writeEntry("authorDescription" , post->author.description);
            grp.writeEntry("isPrivate" , post->isPrivate);
            grp.writeEntry("authorLocation" , post->author.location);
            grp.writeEntry("isProtected" , post->author.isProtected);
            grp.writeEntry("isRead" , post->isRead);
            grp.writeEntry("repeatedFrom", post->repeatedFromUsername);
            grp.writeEntry("repeatedPostId", post->repeatedPostId);
            grp.writeEntry("repeatedDateTime", post->repeatedDateTime);
            grp.writeEntry("conversationId", post->conversationId);
            grp.writeEntry("mediaUrl", post->media);
            grp.writeEntry("mediaWidth", post->mediaSizeWidth);
            grp.writeEntry("mediaHeight", post->mediaSizeHeight);
            grp.writeEntry("quotedPostId", post->quotedPost.postId);
            grp.writeEntry("quotedProfileUrl", post->quotedPost.profileImageUrl);
            grp.writeEntry("quotedContent", post->quotedPost.content);
            grp.writeEntry("quotedUsername", post->quotedPost.username);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &user: list) {
            // QUrl::host() is needed to skip scheme check
            if (LaconicaMicroBlog::hostFromProfileUrl(user).compare(QUrl(theAccount->host()).host()) == 0) {
                sameHost.append(LaconicaMicroBlog::usernameFromProfileUrl(user));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Post *p: list) {
            PostWidget *pw = d->currentAccount->microblog()->createPostWidget(d->currentAccount, p, this);
            if (pw) {
                pw->setRead();
                addPostWidgetToUi(pw);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &timeline: acc->timelineNames()) {
            QUrl url(acc->host());
            url = url.adjusted(QUrl::StripTrailingSlash);
            url.setPath(url.path() + m_timelinesPaths[timeline].arg(acc->username()));
            QUrlQuery query;

            QVariantMap oAuthParams;
            const QString lastActivityId(lastTimelineId(theAccount, timeline));
            if (!lastActivityId.isEmpty()) {
                oAuthParams.insert(QLatin1String("count"), QByteArray::number(200));
                query.addQueryItem(QLatin1String("count"), QString::number(200));
                oAuthParams.insert(QLatin1String("since"), QUrl::toPercentEncoding(lastActivityId));
                query.addQueryItem(QLatin1String("since"), lastActivityId);
            } else {
                oAuthParams.insert(QLatin1String("count"), QByteArray::number(Choqok::BehaviorSettings::countOfPosts()));
                query.addQueryItem(QLatin1String("count"), QString::number(Choqok::BehaviorSettings::countOfPosts()));
            }
            url.setQuery(query);

            KIO::StoredTransferJob *job = KIO::storedGet(url, KIO::Reload, KIO::HideProgressInfo);
            if (!job) {
                qCDebug(CHOQOK) << "Cannot create an http GET request!";
                continue;
            }
            job->addMetaData(QLatin1String("customHTTPHeader"), authorizationMetaData(acc, url, QNetworkAccessManager::GetOperation,
                             oAuthParams));
            m_timelinesRequests[job] = timeline;
            m_accountJobs[job] = acc;
            connect(job, SIGNAL(result(KJob*)), this, SLOT(slotUpdateTimeline(KJob*)));
            job->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &grp: groups) {
        if (grp.startsWith(QLatin1String("Filter_"))) {
            Filter *f = new Filter(KSharedConfig::openConfig()->group(grp), this);
            if (f->filterText().isEmpty()) {
                continue;
            }
            _filters << f;
            //qDebug() << "REEADING A FILTER";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &username: acc->following()) {
            QListWidgetItem *item = new QListWidgetItem;
            item->setText(PumpIOMicroBlog::userNameFromAcct(username));
            item->setData(Qt::UserRole, username);
            toList->addItem(item);
            ccList->addItem(item->clone());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *item: ui.timelinesList->selectedItems()) {
        lst.append(item->text());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &grp: accountGroups) {
        qCDebug(CHOQOK) << grp;
        KConfigGroup cg(d->conf, grp);
//         KConfigGroup pluginConfig( d->conf, QLatin1String("Plugins") );

        QString blog = cg.readEntry("MicroBlog", QString());
        Choqok::MicroBlog *mBlog = 0;
        if (!blog.isEmpty() && cg.readEntry("Enabled", true)) {
            mBlog = qobject_cast<MicroBlog *>(PluginManager::self()->loadPlugin(blog));
        }
        if (mBlog) {
            const QString alias = cg.readEntry("Alias", QString());
            if (alias.isEmpty()) {
                continue;    ///Unknown alias
            }
            Account *acc = mBlog->createNewAccount(alias);
            if (acc) {
                d->accounts.append(acc);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::TimelineWidget *widget: timelines().values()) {
        if (widget->isClosable()) {
            closeSearch(widget);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::UI::PostWidget *postwidget:
                   Choqok::UI::Global::mainWindow()->currentMicroBlog()->currentTimeline()->postWidgets()) {
            postwidget->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &servicePtr: pluginInfo.kcmServices()) {
        if (!servicePtr->noDisplay()) {
            KCModuleInfo moduleInfo(servicePtr);
            KCModuleProxy *currentModuleProxy = new KCModuleProxy(moduleInfo, moduleProxyParentWidget);
            if (currentModuleProxy->realModule()) {
                d->moduleProxyList << currentModuleProxy;
                if (mainWidget && !newTabWidget) {
                    // we already created one KCModuleProxy, so we need a tab widget.
                    // Move the first proxy into the tab widget and ensure this and subsequent
                    // proxies are in the tab widget
                    newTabWidget = new QTabWidget(configDialog);
                    moduleProxyParentWidget = newTabWidget;
                    mainWidget->setParent(newTabWidget);
                    KCModuleProxy *moduleProxy = qobject_cast<KCModuleProxy *>(mainWidget);
                    if (moduleProxy) {
                        newTabWidget->addTab(mainWidget, moduleProxy->moduleInfo().moduleName());
                        mainWidget = newTabWidget;
                    } else {
                        delete newTabWidget;
                        newTabWidget = 0;
                        moduleProxyParentWidget = configDialog;
                        mainWidget->setParent(0);
                    }
                }

                if (newTabWidget) {
                    newTabWidget->addTab(currentModuleProxy, servicePtr->name());
                } else {
                    mainWidget = currentModuleProxy;
                }
            } else {
                delete currentModuleProxy;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key: entries.keys()) {
            if (key.endsWith(QLatin1String("Enabled"))) {
                pluginsMap.insert(key.left(key.length() - 7), (entries.value(key).compare(QLatin1String("true")) == 0));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *acc: Choqok::AccountManager::self()->accounts()) {
        if (acc->microblog() == this) {
            d->countOfTimelinesToSave += acc->timelineNames().count();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TwitterApiSearchTimelineWidget *tm: mSearchTimelines) {
        currentAccount()->configGroup()->writeEntry(QLatin1String("Search") + QString::number(i), tm->searchInfo().toString());
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->cc) {
                if (id == PumpIOMicroBlog::PublicCollection) {
                    ss += i18n("Public") + QLatin1String(", ");
                } else if (followers.indexIn(id) != -1) {
                    ss += QLatin1String("<a href=\"") + QString(id).remove(QLatin1String("/api/user")) + QLatin1String("\">")
                          + i18n("Followers") + QLatin1String("</a>, ");
                } else if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, post->author.userName).toDisplayString()
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Account *ac: accounts) {
        bool inserted = false;
        int i = 0;
        while (i < result.count()) {
            if (ac->priority() < result[i]->priority()) {
                result.insert(i, ac);
                inserted = true;
                break;
            }
            ++i;
        }
        if (!inserted) {
            result.insert(i, ac);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: availablePlugins(QString::null)) { //krazy:exclude=nullstrassign for old broken gcc
            if ((p.category().compare(QLatin1String("MicroBlogs")) == 0) ||
                    (p.category().compare(QLatin1String("Shorteners")) == 0))
            {
                continue;
            }

            const QString pluginName = p.pluginName();
            if (pluginsMap.value(pluginName, p.isPluginEnabledByDefault())) {
                if (!plugin(pluginName)) {
                    _kpmp->pluginsToLoad.push(pluginName);
                }
            } else {
                //This happens if the user unloaded plugins with the config plugin page.
                // No real need to be assync because the user usually unload few plugins
                // compared tto the number of plugin to load in a cold start. - Olivier
                if (plugin(pluginName)) {
                    unloadPlugin(pluginName);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id: post->cc) {
                if (id == PumpIOMicroBlog::PublicCollection) {
                    ss += i18n("Public") + QLatin1String(", ");
                } else if (followers.indexIn(id) != -1) {
                    ss += QLatin1String("<a href=\"") + QString(id).remove(QLatin1String("/api/user")) + QLatin1String("\">")
                          + i18n("Followers") + QLatin1String("</a>, ");
                } else if (id == QLatin1String("acct:") + account->webfingerID()) {
                    ss += i18n("You") + QLatin1String(", ");
                } else {
                    ss += QLatin1String("<a href=\"") + microblog->profileUrl(account, post->author).toDisplayString()
                          + QLatin1String("\">") + PumpIOMicroBlog::userNameFromAcct(id) + QLatin1String("</a>, ");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo &p: availablePlugins(QString())) {
            if ((p.category().compare(QLatin1String("MicroBlogs")) == 0) ||
                    (p.category().compare(QLatin1String("Shorteners")) == 0))
            {
                continue;
            }

            if (p.isPluginEnabledByDefault()) {
                _kpmp->pluginsToLoad.push(p.pluginName());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Choqok::Account *ac: Choqok::AccountManager::self()->accounts()) {
       addAccountToTable(ac);
    }
```

