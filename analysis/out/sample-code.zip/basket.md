#### AUTO 


```{c}
const auto groups = result.preferredGroups();
```

#### RANGE FOR STATEMENT 


```{c}
for (Tag* tag: Tag::all)
    {
        for (State* state: tag->states())
        {
            QString textEquivalent = state->textEquivalent().trimmed();
            if (textEquivalent.isEmpty()) continue;

            dictStatesByEquiv[textEquivalent] = state;
            patternAllTags.append(QRegularExpression::escape(textEquivalent)).append("|");
        }
    }
```

#### AUTO 


```{c}
const auto& obj
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& obj : parent->children()) {
        qDebug() << Q_FUNC_INFO << obj->metaObject()->className() << ": " << obj->objectName() << Qt::endl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor *ex : exList) {
        ex->extract(&result);
        const auto groups = result.preferredGroups();
        DEBUG_WIN << "Metadata Extractor result has " << QString::number(groups.count()) << " groups";

        for (const auto &group : groups) {
            if (!group.second.isEmpty()) {
                toolTip.insert(group.first, group.second);
            }
        }
    }
```

#### AUTO 


```{c}
auto *ke = dynamic_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
const auto referencePathDirTree = createDirTree(referencePath, true);
```

#### AUTO 


```{c}
auto onCopyFinished = [&](KJob* job) {
                int error = job->error();
                qDebug() << "KIO::CopyJob finished with result" << error;
                if (error != 0) {
                    qDebug() << job->errorString();
                    QMessageBox::critical(NULL, QGuiApplication::applicationDisplayName(),
                        i18n("Failed to migrate Basket data from KDE4. You will need to close Basket and copy the basket folder manually.\n" \
                        "Source: %1\nDestination: %2\nReason: %3",
                        getOldDataDir(), getNewDataDir(), job->errorString()));
                }
                copySucceeded = (error == 0);
                waitLoop.quit();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &path) {
        QDir dir(path);
        dir.removeRecursively();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor *ex : extractorCollection.fetchExtractors(mime.name())) {
        ex->extract(&result);
        const auto groups = result.preferredGroups();
        DEBUG_WIN << "Metadata Extractor result has " << QString::number(groups.count()) << " groups";

        for (const auto &group : groups) {
            if (!group.second.isEmpty()) {
                toolTip.insert(group.first, group.second);
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(binaryPath);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &entry) {
        archive.addLocalFile(source.absolutePath() + QDir::separator() + entry, entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (State* state: tag->states())
        {
            QString textEquivalent = state->textEquivalent().trimmed();
            if (textEquivalent.isEmpty()) continue;

            dictStatesByEquiv[textEquivalent] = state;
            patternAllTags.append(QRegularExpression::escape(textEquivalent)).append("|");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertWizard(3); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : mSourcePath.entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        archive.addLocalDirectory(entry, entry);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &path) {
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly)) {
            hashTest.addData(&file);
            file.close();
        }
    }
```

#### AUTO 


```{c}
const auto sourceDirectories = source.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : mSourcePath.entryList(QDir::Files)) {
        archive.addLocalFile(entry, entry);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob* job) {
                int error = job->error();
                qDebug() << "KIO::CopyJob finished with result" << error;
                if (error != 0) {
                    qDebug() << job->errorString();
                    QMessageBox::critical(NULL, QGuiApplication::applicationDisplayName(),
                        i18n("Failed to migrate Basket data from KDE4. You will need to close Basket and copy the basket folder manually.\n" \
                        "Source: %1\nDestination: %2\nReason: %3",
                        getOldDataDir(), getNewDataDir(), job->errorString()));
                }
                copySucceeded = (error == 0);
                waitLoop.quit();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertEmpty(NoteType::Html); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &group : groups) {
            if (!group.second.isEmpty()) {
                toolTip.insert(group.first, group.second);
            }
        }
```

#### AUTO 


```{c}
const auto &group
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor *ex : extractorCollection.fetchExtractors(mime.name())) {
        ex->extract(&result);
        auto groups = result.preferredGroups();
        DEBUG_WIN << "Metadata Extractor result has " << QString::number(groups.count()) << " groups";

        int i = 0;
        for (auto it = groups.begin(); i < 6 && it != groups.end(); ++it) {
            if (!it->second.isEmpty()) {
                keys->append(it->first);
                values->append(it->second);
                i++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor* ex : extractorCollection.fetchExtractors(mime.name()))
    {
        ex->extract(&result);
        auto groups = result.preferredGroups();
        DEBUG_WIN << "Metadata Extractor result has " << QString::number(groups.count()) << " groups";

        int i = 0;
        for (auto it = groups.begin();
                i < 6 && it != groups.end();
                ++it) {
            if (!it->second.isEmpty()) {
                keys->append(it->first);
                values->append(it->second);
                i++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (State* state: states)
    {
        note()->addState(state, true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QDBusObjectPath> reply = *watcher;
        if (reply.isError()) {
            qWarning() << "Couldn't get reply";
            qWarning() << "Error: " << reply.error().message();
        } else {
            QDBusConnection::sessionBus().connect(QString(),
                                                  reply.value().path(),
                                                  QLatin1String("org.freedesktop.portal.Request"),
                                                  QLatin1String("Response"),
                                                  this,
                                                  SLOT(gotColorResponse(uint, QVariantMap)));
        }
    }
```

#### AUTO 


```{c}
auto *mevent = dynamic_cast<QMouseEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &entry) {
        archive.addLocalDirectory(source.absolutePath() + QDir::separator() + entry, entry);
    }
```

#### AUTO 


```{c}
auto onCopyFinished = [&](KJob* job) {
                int error = job->error();
                qDebug() << "KIO::CopyJob finished with result" << error;
                copySucceeded = (error == 0);
                waitLoop.quit();
            };
```

#### AUTO 


```{c}
auto *audioOutput = new Phonon::AudioOutput(Phonon::MusicCategory, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&textEdit]() { textEdit->setFocus(); }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
const auto testPathDirTree = createDirTree(toTestPath, true);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &path) {
        QFile file(path);
        file.remove();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertEmpty(NoteType::Image); }
```

#### AUTO 


```{c}
const auto testPathDirTree = createDirTree(toTestPath, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : toolTip.keys()) {
                message += "<br>" + i18nc("of the form 'key: value'", "<b>%1</b>: %2", key, toolTip.value(key));
            }
```

#### AUTO 


```{c}
auto groups = result.preferredGroups();
```

#### RANGE FOR STATEMENT 


```{c}
for (State* state: tags)
    {
        note->addState(state, true);
    }
```

#### AUTO 


```{c}
const auto toolTip = QMap<QString, QString> {
                { i18n("Added"), note->addedStringDate() },
                { i18n("Last Modification"), note->lastModificationStringDate() }
            }.unite(note->content()->toolTipInfos());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &bskt : containedBaskets) {
        const QString bsktPath = basketsDirectory + QDir::separator() + "baskets" + QDir::separator() + bskt;
        if (!QFileInfo::exists(bsktPath)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : availablePlugins) {
#if KCMUTILS_VERSION >= QT_VERSION_CHECK(5, 84, 0)
        addModule(metaData);
#else
        addModule(metaData.pluginId());
#endif
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertEmpty(NoteType::CrossReference); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertEmpty(NoteType::Color); }
```

#### AUTO 


```{c}
auto sourceFiles = source.entryList(QDir::Files);
```

#### AUTO 


```{c}
auto it = groups.begin();
```

#### AUTO 


```{c}
auto mismatched = std::mismatch(testPathDirTree.begin(), testPathDirTree.end(), referencePathDirTree.begin());
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob* job) {
                int error = job->error();
                qDebug() << "KIO::CopyJob finished with result" << error;
                copySucceeded = (error == 0);
                waitLoop.quit();
            }
```

#### AUTO 


```{c}
const auto referencePathDirTree = createDirTree(referencePath, false);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertEmpty(NoteType::Link); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertWizard(2); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job) {
                int error = job->error();
                qDebug() << "KIO::CopyJob finished with result" << error;
                if (error != 0) {
                    qDebug() << job->errorString();
                    QMessageBox::critical(nullptr,
                                          QGuiApplication::applicationDisplayName(),
                                          i18n("Failed to migrate Basket data from KDE4. You will need to close Basket and copy the basket folder manually.\n"
                                               "Source: %1\nDestination: %2\nReason: %3",
                                               getOldDataDir(),
                                               getNewDataDir(),
                                               job->errorString()));
                }
                copySucceeded = (error == 0);
                waitLoop.quit();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { guessTitle(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertEmpty(NoteType::Launcher); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { guessIcon(); }
```

#### AUTO 


```{c}
const auto &entry
```

#### AUTO 


```{c}
const auto toolTip = QMultiMap<QString, QString> {
                { i18n("Added"), note->addedStringDate() },
                { i18n("Last Modification"), note->lastModificationStringDate() }
            }.unite(note->content()->toolTipInfos());
```

#### AUTO 


```{c}
auto onCopyFinished = [&](KJob *job) {
                int error = job->error();
                qDebug() << "KIO::CopyJob finished with result" << error;
                if (error != 0) {
                    qDebug() << job->errorString();
                    QMessageBox::critical(nullptr,
                                          QGuiApplication::applicationDisplayName(),
                                          i18n("Failed to migrate Basket data from KDE4. You will need to close Basket and copy the basket folder manually.\n"
                                               "Source: %1\nDestination: %2\nReason: %3",
                                               getOldDataDir(),
                                               getNewDataDir(),
                                               job->errorString()));
                }
                copySucceeded = (error == 0);
                waitLoop.quit();
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { this->populateTagsMenu(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { insertWizard(1); }
```

