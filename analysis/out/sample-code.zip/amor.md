#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : fileNames) {
                files.append(dir + QLatin1Char('/') + file);
            }
```

#### AUTO 


```{c}
auto l = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto dpr = qApp->devicePixelRatio();
```

#### AUTO 


```{c}
auto img = mask.toImage().convertToFormat(QImage::Format_MonoLSB);
```

#### AUTO 


```{c}
const auto reply = xcb_query_tree_reply(QX11Info::connection(), cookie, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for( const AmorAnimationGroup &group : mAnimations ) {
        qDeleteAll( group );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs) {
            const QStringList fileNames = QDir(dir).entryList(QStringList() << QStringLiteral("*rc"));
            for (const QString& file : fileNames) {
                files.append(dir + QLatin1Char('/') + file);
            }
        }
```

#### AUTO 


```{c}
const auto mask = m_pixmap->scaled(m_pixmap->width() * dpr, m_pixmap->height() * dpr,
                                           Qt::KeepAspectRatio, Qt::FastTransformation).mask();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folder : folders) {
        QDir amorDir(folder);
        const auto files = amorDir.entryList({ QStringLiteral("*rc") }, QDir::Files, QDir::NoSort);

        for (const auto &file : files) {
            addTheme(folder, file);
        }
    }
```

#### AUTO 


```{c}
const auto folders = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("amor"),
                                        QStandardPaths::LocateDirectory);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : files) {
        addTheme(file);
    }
```

#### AUTO 


```{c}
auto mask = m_pixmap->mask();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Apply | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
const auto cookie = xcb_query_tree(QX11Info::connection(), sibling);
```

#### AUTO 


```{c}
const auto files = amorDir.entryList({ QStringLiteral("*rc") }, QDir::Files, QDir::NoSort);
```

#### AUTO 


```{c}
const auto &file
```

#### RANGE FOR STATEMENT 


```{c}
for (const WId windowId : KWindowSystem::windows()) {
            windowInfo = KWindowInfo( windowId, NET::WMFrameExtents | NET::WMGeometry );

            if( windowInfo.frameGeometry().y() - mCurrAnim->hotspot().y() + mConfig.mOffset < desktopArea.y() ) {
                continue;
            }

            win = windowId;
            break;
        }
```

#### AUTO 


```{c}
const auto conn = QX11Info::connection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : files) {
            addTheme(folder, file);
        }
```

#### AUTO 


```{c}
auto bitmap = xcb_create_pixmap_from_bitmap_data(conn, winId(),
                                                             (uint8_t*) img.constBits(),
                                                             mask.width(), mask.height(), mask.depth(),
                                                             0, 0, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this, buttonBox](QAbstractButton *btn) {
                if (btn == buttonBox->button(QDialogButtonBox::Ok)) {
                    slotOk();
                } else if (btn == buttonBox->button(QDialogButtonBox::Apply)) {
                    slotApply();
                } else if (btn == buttonBox->button(QDialogButtonBox::Cancel)) {
                    slotCancel();
                }
            }
```

#### AUTO 


```{c}
const auto &folder
```

