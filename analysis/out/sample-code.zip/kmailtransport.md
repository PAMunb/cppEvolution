#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(d->transports)) {
        if (t->name() == name) {
            return t;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[forceRefresh, this](KGAPI2::AccountPromise *promise) {
                    if (promise->account()) {
                        if (forceRefresh) {
                            promise = KGAPI2::AccountManager::instance()->refreshTokens(
                                GOOGLE_API_KEY, GOOGLE_API_SECRET, transport()->userName());
                        } else {
                            onTokenRequestFinished(promise);
                            return;
                        }
                    } else {
                        promise = KGAPI2::AccountManager::instance()->getAccount(
                            GOOGLE_API_KEY, GOOGLE_API_SECRET, transport()->userName(),
                            { KGAPI2::Account::mailScopeUrl() });
                    }
                    connect(promise, &KGAPI2::AccountPromise::finished,
                            this, &SmtpJob::onTokenRequestFinished);
                }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto dA = item.attribute<DispatchModeAttribute>();
```

#### AUTO 


```{c}
auto b = new QPushButton(QStringLiteral("&Send Now"), this);
```

#### AUTO 


```{c}
auto readJob = new ReadPasswordJob(WALLET_FOLDER, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::TransportAbstractPluginInfo &info : lstPluginInfo) {
            qDebug() << "Plugin name " << info.name;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->jobResult(job);
    }
```

#### AUTO 


```{c}
auto acc = KGAPI2::AccountPtr::create(transport()->userName(),
                                          QString(), refreshToken,
                                          QList<QUrl>() << QUrl(QStringLiteral("https://mail.google.com/")));
```

#### AUTO 


```{c}
auto *t = new AddTransportDialogNG_gui();
```

#### AUTO 


```{c}
auto *a = new SentActionAttribute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &line : lines) {
            if (line.compare(QLatin1String("STARTTLS"), Qt::CaseInsensitive) == 0) {
                *shouldStartTLS = true;
            } else if (line.startsWith(QLatin1String("AUTHINFO "), Qt::CaseInsensitive)) {
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), QString::SkipEmptyParts);
                const QString s(QStringLiteral("USER"));
                const QStringRef ref(&s);
                if (authinfos.contains(ref)) {
                    authenticationResults[type].append(Transport::EnumAuthenticationType::CLEAR); // XXX
                }
            } else if (line.startsWith(QLatin1String("SASL "), Qt::CaseInsensitive)) {
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), QString::SkipEmptyParts);
                authenticationResults[type] += parseAuthenticationList(auths);
            } else if (line == QLatin1Char('.')) {
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) {
        return md.serviceTypes().contains(QLatin1String("MailTransport/Plugin"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotStarted();
    }
```

#### AUTO 


```{c}
auto t = new MessageQueuer();
```

#### AUTO 


```{c}
auto eA = item.attribute<ErrorAttribute>();
```

#### AUTO 


```{c}
const auto fjobItems{fjob->items()};
```

#### RANGE FOR STATEMENT 


```{c}
for (MailTransport::TransportAbstractPlugin *plugin : lstPlugins) {
        if (plugin->names().isEmpty()) {
            qCDebug(MAILTRANSPORT_LOG) << "Plugin " << plugin << " doesn't provide plugin";
        }
        const QVector<TransportAbstractPluginInfo> lstInfos = plugin->names();
        for (const MailTransport::TransportAbstractPluginInfo &info : lstInfos) {
            TransportType type;
            type.d->mName = info.name;
            type.d->mDescription = info.description;
            type.d->mIdentifier = info.identifier;
            type.d->mIsAkonadiResource = info.isAkonadi;
            types << type;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            editClicked();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &line : lines) {
            if (line.compare(QLatin1String("STARTTLS"), Qt::CaseInsensitive) == 0) {
                *shouldStartTLS = true;
            } else if (line.startsWith(QLatin1String("AUTHINFO "), Qt::CaseInsensitive)) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), QString::SkipEmptyParts);
#else
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif
                const QString s(QStringLiteral("USER"));
                const QStringRef ref(&s);
                if (authinfos.contains(ref)) {
                    authenticationResults[type].append(Transport::EnumAuthenticationType::CLEAR); // XXX
                }
            } else if (line.startsWith(QLatin1String("SASL "), Qt::CaseInsensitive)) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), QString::SkipEmptyParts);
#else
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif
                authenticationResults[type] += parseAuthenticationList(auths);
            } else if (line == QLatin1Char('.')) {
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                defaultClicked();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &variant : std::as_const(list)) {
        const QVariantMap map = variant.toMap();
        QMap<QString, QVariant>::const_iterator it = map.cbegin();
        const QMap<QString, QVariant>::const_iterator itEnd = map.cend();
        for (; it != itEnd; ++it) {
            d->mActions << Action(static_cast<Action::Type>(it.key().toInt()), it.value());
        }
    }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->outboxRequestResult(job);}
```

#### AUTO 


```{c}
auto send = new KSmtp::SendJob(d->session);
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<SpecialMailCollectionsRequestJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *old : oldTransports) {
            if (old->currentGroup() == QLatin1String("Transport ") + match.captured(1)) {
                qCDebug(MAILTRANSPORT_LOG) << "reloading existing transport:" << s;
                t = old;
                t->d->passwordNeedsUpdateFromWallet = true;
                t->load();
                oldTransports.removeAll(old);
                break;
            }
        }
```

#### AUTO 


```{c}
auto *mjob
        = new FilterActionJob(outbox, new DispatchManualTransportAction(transportId), sInstance);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *selecteditem : selectedItems) {
        TransportManager::self()->removeTransport(selecteditem->data(0, Qt::UserRole).toInt());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : fJobItems) {
        QVERIFY(item.hasAttribute<TestAttribute>());
        const QByteArray data = item.attribute<TestAttribute>()->data;
        if (data == unacceptable) {
            QVERIFY(unacc.contains(item));
            unacc.removeAll(item);
        } else if (data == modified) {
            QVERIFY(acc.contains(item));
            acc.removeAll(item);
        } else {
            QVERIFY2(false, QByteArray(QByteArray("Got bad data \"") + data + QByteArray("\"")));
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(dialog);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        d->slotError(error);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            removeClicked();
        }
```

#### AUTO 


```{c}
auto tA = item.attribute<TransportAttribute>();
```

#### AUTO 


```{c}
auto job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### LAMBDA EXPRESSION 


```{c}
[forceRefresh, this](KGAPI2::AccountPromise *promise) {
            if (promise->account()) {
                if (forceRefresh) {
                    promise = KGAPI2::AccountManager::instance()->refreshTokens(
                        GOOGLE_API_KEY, GOOGLE_API_SECRET, transport()->userName());
                } else {
                    onTokenRequestFinished(promise);
                    return;
                }
            } else {
                promise = KGAPI2::AccountManager::instance()->getAccount(
                    GOOGLE_API_KEY, GOOGLE_API_SECRET, transport()->userName(),
                    { KGAPI2::Account::mailScopeUrl() });
            }
            connect(promise, &KGAPI2::AccountPromise::finished,
                    this, &SmtpJob::onTokenRequestFinished);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->renameClicked(); }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(d->transports)) {
        rv << t->id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        QTreeWidgetItem *treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setData(0, Qt::UserRole, QVariant::fromValue(type));     // the transport type
        if (type.type() == TransportBase::EnumType::SMTP)
            treeItem->setSelected(true); // select SMTP by default
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateOkButton();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(d->transports)) {
        if (!t->isComplete()) {
            found = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool status) {
                d->slotWalletOpened(status);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::TransportAbstractPluginInfo &info : plugin->names()) {
            TransportType type;
            type.d->mName = info.name;
            type.d->mDescription = info.description;
            type.d->mIdentifier = info.identifier;
            type.d->mIsAkonadiResource = info.isAkonadi;
            types << type;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPoint p) {
        d->slotCustomContextMenuRequested(p);
    }
```

#### AUTO 


```{c}
auto passwd = transport()->password();
```

#### LAMBDA EXPRESSION 


```{c}
[](){
        qApp->restoreOverrideCursor();
    }
```

#### AUTO 


```{c}
auto authJob = new KGAPI2::AuthJob(acc, GOOGLE_API_KEY, GOOGLE_API_SECRET, this);
```

#### AUTO 


```{c}
auto *socket = qobject_cast<QTcpSocket *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : fjobItems) {
        QVERIFY(item.hasAttribute<TestAttribute>());
        const QByteArray data = item.attribute<TestAttribute>()->data;
        if (data == unacceptable) {
            QVERIFY(unacc.contains(item));
            unacc.removeAll(item);
        } else if (data == modified) {
            QVERIFY(acc.contains(item));
            acc.removeAll(item);
        } else {
            QVERIFY2(false, QByteArray(QByteArray("Got bad data \"") + data + QByteArray("\"")));
        }
    }
```

#### AUTO 


```{c}
auto mjob = new FilterActionJob(outbox, new DispatchManualTransportAction(transportId), sInstance);
```

#### AUTO 


```{c}
auto *attribute = new SentActionAttribute;
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        QTreeWidgetItem *treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setToolTip(1, type.description());
        treeItem->setData(0, Qt::UserRole, type.identifier());     // the transport type
        if (type.identifier() == QStringLiteral("SMTP")) {
            treeItem->setSelected(true); // select SMTP by default
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        auto dlg = new MailTransport::AddTransportDialogNG(this);
        dlg->exec();
        delete dlg;
    }
```

#### AUTO 


```{c}
auto a = new TransportAttribute(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(d->transports)) {
        if (t->id() == id) {
            return t;
        }
    }
```

#### AUTO 


```{c}
auto *t = new TransportMgr();
```

#### AUTO 


```{c}
auto *a = new DispatchModeAttribute(mode);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { removeClicked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        MailTransport::AddTransportDialogNG *dlg = new MailTransport::AddTransportDialogNG(this);
        dlg->exec();
        delete dlg;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) {
        return md.serviceTypes().contains(QStringLiteral("MailTransport/Plugin"));
    }
```

#### AUTO 


```{c}
auto fjob = dynamic_cast<ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : lstTransports) {
        auto item = new QTreeWidgetItem(this);
        item->setData(0, Qt::UserRole, t->id());
        QString name = t->name();
        if (TransportManager::self()->defaultTransportId() == t->id()) {
            name += i18nc("@label the default mail transport", " (Default)");
            QFont font(item->font(0));
            font.setBold(true);
            item->setFont(0, font);
        }
        item->setText(0, name);
        item->setText(1, t->transportType().name());
        if (t->id() == selected) {
            setCurrentItem(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        QTreeWidgetItem *treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setToolTip(1, type.description());
        treeItem->setData(0, Qt::UserRole, type.identifier());     // the transport type
        if (type.identifier() == QLatin1String("SMTP")) {
            treeItem->setSelected(true); // select SMTP by default
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentType &atype : AgentManager::self()->types()) {
        // TODO probably the string "MailTransport" should be #defined somewhere
        // and used like that in the resources (?)
        if (atype.capabilities().contains(QStringLiteral("MailTransport"))) {
            MailTransport::TransportAbstractPluginInfo info;
            info.name = atype.name();
            info.description = atype.description();
            info.identifier = atype.identifier();
            info.isAkonadi = true;
            lst << info;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(d->transports)) {
        rv << t->name();
    }
```

#### AUTO 


```{c}
auto *rjob = new SpecialMailCollectionsRequestJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->dbusServiceUnregistered(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->dbusServiceUnregistered();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { editClicked(); }
```

#### AUTO 


```{c}
auto job = new MessageQueueJob();
```

#### AUTO 


```{c}
const auto nbItems{ui.transportList->selectedItems().count()};
```

#### AUTO 


```{c}
auto *t = new MessageQueuer();
```

#### AUTO 


```{c}
const auto lstTransports = TransportManager::self()->transports();
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : lstTransports) {
        QTreeWidgetItem *item = new QTreeWidgetItem(this);
        item->setData(0, Qt::UserRole, t->id());
        QString name = t->name();
        if (TransportManager::self()->defaultTransportId() == t->id()) {
            name += i18nc("@label the default mail transport", " (Default)");
            QFont font(item->font(0));
            font.setBold(true);
            item->setFont(0, font);
        }
        item->setText(0, name);
        item->setText(1, t->transportType().name());
        if (t->id() == selected) {
            setCurrentItem(item);
        }
    }
```

#### AUTO 


```{c}
auto *qjob = new MessageQueueJob;
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(d->transports)) {
        t->readPassword();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Action &action : std::as_const(d->mActions)) {
        QVariantMap map;
        map.insert(QString::number(action.type()), action.value());

        list << QVariant(map);
    }
```

#### AUTO 


```{c}
const auto types{AgentManager::self()->types()};
```

#### AUTO 


```{c}
auto *requestJob
        = qobject_cast<SpecialMailCollectionsRequestJob *>(job);
```

#### AUTO 


```{c}
auto mjob = new FilterActionJob(outbox, new ClearErrorAction, sInstance);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::TransportAbstractPluginInfo &info : lstInfos) {
            TransportType type;
            type.d->mName = info.name;
            type.d->mDescription = info.description;
            type.d->mIdentifier = info.identifier;
            type.d->mIsAkonadiResource = info.isAkonadi;
            types << type;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &scenario : std::as_const(m_scenarios)) {
        if (!scenario.isEmpty()) {
            qDebug() << scenario;
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val, QProcess::ExitStatus status) {
        d->slotFinished(val, status);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[session](KSmtp::Session::State state) {
                if (state == KSmtp::Session::Disconnected) {
                    session->deleteLater();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QVector<int> &encs) {
        qDebug() << encs;
        QCoreApplication::quit();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->doubleClicked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](const int result) {
            if (result == QDialog::Rejected) {
                setError(KilledJobError);
                emitResult();
                return;
            }

            transport()->setUserName(dlg->username());
            transport()->setPassword(dlg->password());
            transport()->setStorePassword(dlg->keepPassword());
            transport()->save();

            d->doLogin();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateOkButton(); }
```

#### AUTO 


```{c}
const auto &scenario
```

#### AUTO 


```{c}
auto *edit = dynamic_cast<QLineEdit *>(editor);
```

#### AUTO 


```{c}
auto *fjob = new ItemFetchJob(d->collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(d->transports)) {
        rv << t->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailTransport::TransportAbstractPlugin *plugin : lst) {
        const QVector<MailTransport::TransportAbstractPluginInfo> lstPluginInfo = plugin->names();
        for (const MailTransport::TransportAbstractPluginInfo &info : lstPluginInfo) {
            qDebug() << "Plugin name " << info.name;
        }
    }
```

#### AUTO 


```{c}
auto addrA = item.attribute<AddressAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool status) { d->slotWalletOpened(status);}
```

#### AUTO 


```{c}
auto dlg = new MailTransport::AddTransportDialogNG(this);
```

#### AUTO 


```{c}
const auto fJobItems{fjob->items()};
```

#### AUTO 


```{c}
auto fjob = new ItemFetchJob(d->collection, this);
```

#### AUTO 


```{c}
auto b = new QPushButton(QStringLiteral("&Edit"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : lstTransports) {
        if (t->id() != id()) {
            existingNames << t->name();
        }
    }
```

#### AUTO 


```{c}
auto *const cloned = new DispatchModeAttribute(d->mMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &line : lines) {
            if (line.compare(QLatin1String("STARTTLS"), Qt::CaseInsensitive) == 0) {
                *shouldStartTLS = true;
            } else if (line.startsWith(QLatin1String("AUTHINFO "), Qt::CaseInsensitive)) {
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
                const QString s(QStringLiteral("USER"));
                const QStringRef ref(&s);
                if (authinfos.contains(ref)) {
                    authenticationResults[type].append(Transport::EnumAuthenticationType::CLEAR); // XXX
                }
            } else if (line.startsWith(QLatin1String("SASL "), Qt::CaseInsensitive)) {
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), Qt::SkipEmptyParts);
                authenticationResults[type] += parseAuthenticationList(auths);
            } else if (line == QLatin1Char('.')) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(transports)) {
        usedIds << t->id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : bcc()) {
        destinationQuery.addQueryItem(QStringLiteral("bcc"), str);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { addClicked(); }
```

#### AUTO 


```{c}
auto promise = KGAPI2::AccountManager::instance()->findAccount(GOOGLE_API_KEY, transport()->userName(), {KGAPI2::Account::mailScopeUrl()});
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(transports)) {
        if (t->needsWalletMigration()) {
            names << t->name();
        }
    }
```

#### AUTO 


```{c}
auto acc = KGAPI2::AccountPtr::create(transport()->userName(),
                                          QString(), QString(),
                                          QList<QUrl>() << QUrl(QStringLiteral("https://mail.google.com/")));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->removeClicked(); }
```

#### AUTO 


```{c}
auto button = new QPushButton(QStringLiteral("Add transport"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentType &atype : types) {
        // TODO probably the string "MailTransport" should be #defined somewhere
        // and used like that in the resources (?)
        if (atype.capabilities().contains(QLatin1String("MailTransport"))) {
            MailTransport::TransportAbstractPluginInfo info;
            info.name = atype.name();
            info.description = atype.description();
            info.identifier = atype.identifier();
            info.isAkonadi = true;
            lst << info;
        }
    }
```

#### AUTO 


```{c}
const auto tokens = transport()->password();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &err) {
        setError(KJob::UserDefinedError);
        setErrorText(err);
        s_sessionPool->removeSession(d->session);
        emitResult();
    }
```

#### AUTO 


```{c}
auto *cjob = new AgentInstanceCreateJob(identifier);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->addClicked(); }
```

#### AUTO 


```{c}
auto *sA = item.attribute<SentBehaviourAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotStarted(); }
```

#### AUTO 


```{c}
auto const cloned = new DispatchModeAttribute(d->mMode);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(transports)) {
        usedIds << t->id();
    }
```

#### AUTO 


```{c}
auto t = new TransportMgr();
```

#### AUTO 


```{c}
const auto transportTypes = TransportManager::self()->types();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::TransportAbstractPluginInfo &info : lstPluginInfo) {
            if (info.identifier == identifier) {
                return p;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(d->transports)) {
        if (t->name() == name) {
            return t;
        }
    }
```

#### AUTO 


```{c}
auto *djob = new ItemDeleteJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateButtonState();
    }
```

#### AUTO 


```{c}
auto socket = qobject_cast<QTcpSocket *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->defaultClicked(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &line : lines) {
            if (line.compare(QLatin1String("STARTTLS"), Qt::CaseInsensitive) == 0) {
                *shouldStartTLS = true;
            } else if (line.startsWith(QLatin1String("AUTHINFO "), Qt::CaseInsensitive)) {
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), QString::SkipEmptyParts);
                const QString s(QStringLiteral("USER"));
                const QStringRef ref(&s);
                if (authinfos.contains(ref)) {
                    authenticationResults[type].append(Transport::EnumAuthenticationType::CLEAR); // XXX
                }
            } else if (line.startsWith(QLatin1String("SASL "), Qt::CaseInsensitive)) {
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), QString::SkipEmptyParts);
                authenticationResults[type] += parseAuthenticationList(auths);
            } else if (line == QLatin1String(".")) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto plugin = MailTransport::TransportPluginManager::self()->plugin(t->identifier());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->fetchResult(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransportJob *job : copy) {
        job->start();
    }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto edit = dynamic_cast<QLineEdit *>(editor);
```

#### AUTO 


```{c}
auto a = new SentBehaviourAttribute(beh, Collection(id));
```

#### AUTO 


```{c}
auto a = new SentActionAttribute();
```

#### AUTO 


```{c}
auto job = new PrecommandJob(transport()->precommand(), this);
```

#### AUTO 


```{c}
auto watcher = new QDBusServiceWatcher(DBUS_SERVICE_NAME, QDBusConnection::sessionBus(), QDBusServiceWatcher::WatchForUnregistration, this);
```

#### AUTO 


```{c}
auto mjob = new FilterActionJob(outbox, new SendQueuedAction, sInstance);
```

#### AUTO 


```{c}
auto a = new AddressAttribute(from, to, cc, bcc);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *old : oldTransports) {
            if (old->currentGroup() == checkString) {
                qCDebug(MAILTRANSPORT_LOG) << "reloading existing transport:" << s;
                t = old;
                t->load();
                oldTransports.removeAll(old);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringView line : lines) {
#else
        const QVector<QStringRef> lines = response.splitRef(QStringLiteral("\r\n"), Qt::SkipEmptyParts);
        for (const QStringRef &line : lines) {
#endif
            if (line.compare(QLatin1String("STARTTLS"), Qt::CaseInsensitive) == 0) {
                *shouldStartTLS = true;
            } else if (line.startsWith(QLatin1String("AUTHINFO "), Qt::CaseInsensitive)) {
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
#else
                const QVector<QStringView> authinfos = QStringView(line).split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif
                const QString s(QStringLiteral("USER"));
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
                const QStringRef ref(&s);
#else
                const QStringView ref(s);
#endif
                if (authinfos.contains(ref)) {
                    authenticationResults[type].append(Transport::EnumAuthenticationType::CLEAR); // XXX
                }
            } else if (line.startsWith(QLatin1String("SASL "), Qt::CaseInsensitive)) {
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), Qt::SkipEmptyParts);
                authenticationResults[type] += parseAuthenticationList(auths);
            } else if (line == QLatin1Char('.')) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { defaultClicked(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : groups) {
        if (re.indexIn(s) == -1) {
            continue;
        }
        Transport *t = nullptr;

        // see if we happen to have that one already
        foreach (Transport *old, oldTransports) {
            if (old->currentGroup() == QLatin1String("Transport ") + re.cap(1)) {
                qCDebug(MAILTRANSPORT_LOG) << "reloading existing transport:" << s;
                t = old;
                t->d->passwordNeedsUpdateFromWallet = true;
                t->load();
                oldTransports.removeAll(old);
                break;
            }
        }

        if (!t) {
            t = new Transport(re.cap(1));
        }
        if (t->id() <= 0) {
            t->setId(createId());
            t->save();
        }
        transports.append(t);
    }
```

#### AUTO 


```{c}
auto t = new Transport(QString::number(id));
```

#### AUTO 


```{c}
auto box = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, dialog);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            renameClicked();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(transports)) {
        if (t->needsWalletMigration()) {
            names << t->name();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob*job) {d->jobResult(job);}
```

#### AUTO 


```{c}
auto box = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto *job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(transports)) {
        if (t->needsWalletMigration()) {
            t->migrateToWallet();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(d->transports)) {
        if (!t->isComplete()) {
            found = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailTransport::TransportAbstractPlugin *p : lstPlugins) {
        const QVector<TransportAbstractPluginInfo> lstPluginInfo = p->names();
        for (const MailTransport::TransportAbstractPluginInfo &info : lstPluginInfo) {
            if (info.identifier == identifier) {
                return p;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QList<int> &encs) {
        qDebug() << encs;
        QCoreApplication::quit();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(items)) {
        if (functor->itemAccepted(item)) {
            functor->itemAction(item, q);
            qCDebug(MAILTRANSPORTAKONADI_LOG) << "Added subjob for item" << item.id();
        }
    }
```

#### AUTO 


```{c}
auto *item = new QTreeWidgetItem(this);
```

#### AUTO 


```{c}
auto a = new ErrorAttribute(msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (int res : qAsConst(connectionResults)) {
        resultsAsVector.append(res);
    }
```

#### AUTO 


```{c}
auto *job = new MessageQueueJob();
```

#### AUTO 


```{c}
auto rjob = new SpecialMailCollectionsRequestJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int authType : qAsConst(capa)) {
            addAuthenticationItem(ui.authCombo, authType);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : groups) {
        QRegularExpressionMatch match = re.match(s);
        if (!match.hasMatch()) {
            continue;
        }
        Transport *t = nullptr;
        // see if we happen to have that one already
        for (Transport *old : oldTransports) {
            if (old->currentGroup() == QLatin1String("Transport ") + match.captured(1)) {
                qCDebug(MAILTRANSPORT_LOG) << "reloading existing transport:" << s;
                t = old;
                t->d->passwordNeedsUpdateFromWallet = true;
                t->load();
                oldTransports.removeAll(old);
                break;
            }
        }

        if (!t) {
            t = new Transport(match.captured(1));
        }
        if (t->id() <= 0) {
            t->setId(createId());
            t->save();
        }
        transports.append(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(d->transports)) {
        rv << t->id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        auto treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setToolTip(1, type.description());
        treeItem->setData(0, Qt::UserRole, type.identifier()); // the transport type
        if (type.identifier() == QLatin1String("SMTP")) {
            treeItem->setSelected(true); // select SMTP by default
        }
    }
```

#### AUTO 


```{c}
auto *job = new MessageQueueJob;
```

#### AUTO 


```{c}
auto treeItem = new QTreeWidgetItem(d->ui.typeListView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &scenario : qAsConst(m_scenarios)) {
        if (!scenario.isEmpty()) {
            qDebug() << scenario;
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : lstTransports) {
        auto *item = new QTreeWidgetItem(this);
        item->setData(0, Qt::UserRole, t->id());
        QString name = t->name();
        if (TransportManager::self()->defaultTransportId() == t->id()) {
            name += i18nc("@label the default mail transport", " (Default)");
            QFont font(item->font(0));
            font.setBold(true);
            item->setFont(0, font);
        }
        item->setText(0, name);
        item->setText(1, t->transportType().name());
        if (t->id() == selected) {
            setCurrentItem(item);
        }
    }
```

#### AUTO 


```{c}
const auto account = authJob->account();
```

#### AUTO 


```{c}
auto qjob = new MessageQueueJob;
```

#### AUTO 


```{c}
auto plugin =
            KPluginFactory::instantiatePlugin<MailTransport::TransportAbstractPlugin>(item->data, q, QVariantList() << item->metaDataFileNameBaseName).plugin
```

#### AUTO 


```{c}
auto authJob = qobject_cast<KGAPI2::AuthJob*>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (int res : std::as_const(connectionResults)) {
        resultsAsVector.append(res);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qApp->restoreOverrideCursor();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateButtonState(); }
```

#### AUTO 


```{c}
auto a = new DispatchModeAttribute(mode);
```

#### AUTO 


```{c}
auto *cjob = new ItemCreateJob(item, collection);
```

#### AUTO 


```{c}
auto cjob = new ItemCreateJob(item, collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Action &action : qAsConst(d->mActions)) {
        QVariantMap map;
        map.insert(QString::number(action.type()), action.value());

        list << QVariant(map);
    }
```

#### AUTO 


```{c}
auto widget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        qApp->restoreOverrideCursor();
    }
```

#### AUTO 


```{c}
auto *mjob = new FilterActionJob(outbox, new SendQueuedAction, sInstance);
```

#### AUTO 


```{c}
auto *treeItem = new QTreeWidgetItem(d->ui.typeListView);
```

#### LAMBDA EXPRESSION 


```{c}
[forceRefresh, this](KGAPI2::AccountPromise *promise) {
            if (promise->account()) {
                if (forceRefresh) {
                    promise = KGAPI2::AccountManager::instance()->refreshTokens(GOOGLE_API_KEY, GOOGLE_API_SECRET, transport()->userName());
                } else {
                    onTokenRequestFinished(promise);
                    return;
                }
            } else {
                promise = KGAPI2::AccountManager::instance()->getAccount(GOOGLE_API_KEY,
                                                                         GOOGLE_API_SECRET,
                                                                         transport()->userName(),
                                                                         {KGAPI2::Account::mailScopeUrl()});
            }
            connect(promise, &KGAPI2::AccountPromise::finished, this, &SmtpJob::onTokenRequestFinished);
        }
```

#### AUTO 


```{c}
auto dt = new QDateTimeEdit(dialog);
```

#### AUTO 


```{c}
auto *tA = item.attribute<TransportAttribute>();
```

#### AUTO 


```{c}
auto sA = item.attribute<SentBehaviourAttribute>();
```

#### AUTO 


```{c}
auto deleteJob = new DeletePasswordJob(WALLET_FOLDER);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->editClicked();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(items)) {
        if (functor->itemAccepted(item)) {
            functor->itemAction(item, q);
            qCDebug(MAILTRANSPORTAKONADI_LOG) << "Added subjob for item" << item.id();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        QTreeWidgetItem *treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setData(0, Qt::UserRole, QVariant::fromValue(type));     // the transport type
        if (type.type() == TransportBase::EnumType::SMTP) {
            treeItem->setSelected(true); // select SMTP by default
        }
    }
```

#### AUTO 


```{c}
auto *dlg = new MailTransport::AddTransportDialogNG(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(d->transports)) {
        t->readPassword();
    }
```

#### AUTO 


```{c}
auto djob = new ItemDeleteJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (MailTransport::TransportAbstractPlugin *p : pluginsList()) {
        for (const MailTransport::TransportAbstractPluginInfo &info : p->names()) {
            if (info.identifier == identifier) {
                return p;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { renameClicked(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(items)) {
        if (functor->itemAccepted(item)) {
            functor->itemAction(item, q);
            qCDebug(MAILTRANSPORT_LOG) << "Added subjob for item" << item.id();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->doubleClicked();
    }
```

#### AUTO 


```{c}
auto cjob = new AgentInstanceCreateJob(identifier);
```

#### AUTO 


```{c}
auto *a = new TransportAttribute(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        auto *treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setToolTip(1, type.description());
        treeItem->setData(0, Qt::UserRole, type.identifier());     // the transport type
        if (type.identifier() == QLatin1String("SMTP")) {
            treeItem->setSelected(true); // select SMTP by default
        }
    }
```

#### AUTO 


```{c}
auto promise = KGAPI2::AccountManager::instance()->findAccount(
            GOOGLE_API_KEY, transport()->userName(), { KGAPI2::Account::mailScopeUrl() });
```

#### AUTO 


```{c}
const auto account = promise->account();
```

#### AUTO 


```{c}
auto plugin = (*it).plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : std::as_const(transports)) {
        if (t->needsWalletMigration()) {
            t->migrateToWallet();
        }
    }
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto transport = TransportManager::self()->transportById(index);
```

#### AUTO 


```{c}
auto *a = new AddressAttribute(from, to, cc, bcc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringView line : lines) {
#else
        const QVector<QStringRef> lines = response.splitRef(QStringLiteral("\r\n"), Qt::SkipEmptyParts);
        for (const QStringRef &line : lines) {
#endif
            if (line.compare(QLatin1String("STARTTLS"), Qt::CaseInsensitive) == 0) {
                *shouldStartTLS = true;
            } else if (line.startsWith(QLatin1String("AUTHINFO "), Qt::CaseInsensitive)) {
                const QVector<QStringRef> authinfos = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
                const QString s(QStringLiteral("USER"));
                const QStringRef ref(&s);
                if (authinfos.contains(ref)) {
                    authenticationResults[type].append(Transport::EnumAuthenticationType::CLEAR); // XXX
                }
            } else if (line.startsWith(QLatin1String("SASL "), Qt::CaseInsensitive)) {
                const QStringList auths = line.mid(5).toString().split(QLatin1Char(' '), Qt::SkipEmptyParts);
                authenticationResults[type] += parseAuthenticationList(auths);
            } else if (line == QLatin1Char('.')) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto login = new KSmtp::LoginJob(session);
```

#### AUTO 


```{c}
auto login = new KSmtp::LoginJob(d->session);
```

#### RANGE FOR STATEMENT 


```{c}
for (Transport *t : qAsConst(d->transports)) {
        if (t->id() == id) {
            return t;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val, QProcess::ExitStatus status) { d->slotFinished(val,status); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {  d->slotError(error); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->editClicked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->outboxRequestResult(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : groups) {
        const QRegularExpressionMatch match = re.match(s);
        if (!match.hasMatch()) {
            continue;
        }
        Transport *t = nullptr;
        // see if we happen to have that one already
        const QString capturedString = match.captured(1);
        const QString checkString = QLatin1String("Transport ") + capturedString;
        for (Transport *old : oldTransports) {
            if (old->currentGroup() == checkString) {
                qCDebug(MAILTRANSPORT_LOG) << "reloading existing transport:" << s;
                t = old;
                t->load();
                oldTransports.removeAll(old);
                break;
            }
        }

        if (!t) {
            t = new Transport(capturedString);
        }
        if (t->id() <= 0) {
            t->setId(createId());
            t->save();
        }
        transports.append(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentType &atype : AgentManager::self()->types()) {
        // TODO probably the string "MailTransport" should be #defined somewhere
        // and used like that in the resources (?)
        if (atype.capabilities().contains(QLatin1String("MailTransport"))) {
            MailTransport::TransportAbstractPluginInfo info;
            info.name = atype.name();
            info.description = atype.description();
            info.identifier = atype.identifier();
            info.isAkonadi = true;
            lst << info;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qApp->restoreOverrideCursor(); }
```

#### AUTO 


```{c}
auto *dt = new QDateTimeEdit(dialog);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QPoint p) { d->slotCustomContextMenuRequested(p);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::TransportAbstractPluginInfo &info : p->names()) {
            if (info.identifier == identifier) {
                return p;
            }
        }
```

#### AUTO 


```{c}
auto transport = MailTransport::TransportManager::self()->createTransport();
```

#### AUTO 


```{c}
auto *eA = item.attribute<ErrorAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const TransportType &type : transportTypes) {
        auto treeItem = new QTreeWidgetItem(d->ui.typeListView);
        treeItem->setText(0, type.name());
        treeItem->setText(1, type.description());
        treeItem->setToolTip(1, type.description());
        treeItem->setData(0, Qt::UserRole, type.identifier());     // the transport type
        if (type.identifier() == QLatin1String("SMTP")) {
            treeItem->setSelected(true); // select SMTP by default
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            d->fetchResult(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : groups) {
        QRegularExpressionMatch match = re.match(s);
        if (!match.hasMatch()) {
            continue;
        }
        Transport *t = nullptr;
        // see if we happen to have that one already
        foreach (Transport *old, oldTransports) {
            if (old->currentGroup() == QLatin1String("Transport ") + match.captured(1)) {
                qCDebug(MAILTRANSPORT_LOG) << "reloading existing transport:" << s;
                t = old;
                t->d->passwordNeedsUpdateFromWallet = true;
                t->load();
                oldTransports.removeAll(old);
                break;
            }
        }

        if (!t) {
            t = new Transport(match.captured(1));
        }
        if (t->id() <= 0) {
            t->setId(createId());
            t->save();
        }
        transports.append(t);
    }
```

#### AUTO 


```{c}
auto user = transport()->userName();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        auto *dlg = new MailTransport::AddTransportDialogNG(this);
        dlg->exec();
        delete dlg;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &variant : qAsConst(list)) {
        const QVariantMap map = variant.toMap();
        QMap<QString, QVariant>::const_iterator it = map.cbegin();
        const QMap<QString, QVariant>::const_iterator itEnd = map.cend();
        for (; it != itEnd; ++it) {
            d->mActions << Action(static_cast<Action::Type>(it.key().toInt()), it.value());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : cc()) {
        destinationQuery.addQueryItem(QStringLiteral("cc"), str);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->addClicked();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : to()) {
        destinationQuery.addQueryItem(QStringLiteral("to"), str);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MailTransport::TransportAbstractPlugin *plugin : MailTransport::TransportPluginManager::self()->pluginsList()) {
        if (plugin->names().isEmpty()) {
            qCDebug(MAILTRANSPORT_LOG) << "Plugin " << plugin << " doesn't provide plugin";
        }
        for (const MailTransport::TransportAbstractPluginInfo &info : plugin->names()) {
            TransportType type;
            type.d->mName = info.name;
            type.d->mDescription = info.description;
            type.d->mIdentifier = info.identifier;
            type.d->mIsAkonadiResource = info.isAkonadi;
            types << type;
        }
    }
```

#### AUTO 


```{c}
auto attribute = new SentActionAttribute;
```

#### AUTO 


```{c}
auto t = new AddTransportDialogNG_gui();
```

#### AUTO 


```{c}
auto job = new CollectionStatisticsJob(outbox);
```

#### AUTO 


```{c}
auto *dA = item.attribute<DispatchModeAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (int authType : std::as_const(capa)) {
            addAuthenticationItem(ui.authCombo, authType);
        }
```

#### AUTO 


```{c}
auto *job = new CollectionStatisticsJob(outbox);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        addClicked();
    }
```

#### AUTO 


```{c}
auto *mjob = new FilterActionJob(outbox, new ClearErrorAction, sInstance);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->defaultClicked();
    }
```

#### AUTO 


```{c}
auto *fjob = dynamic_cast<ItemFetchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->renameClicked();
    }
```

#### AUTO 


```{c}
auto *addrA = item.attribute<AddressAttribute>();
```

#### AUTO 


```{c}
auto job = new MessageQueueJob;
```

#### AUTO 


```{c}
const auto nbAccount{selectedItems.count()};
```

#### AUTO 


```{c}
auto fjob = new ItemFetchJob(SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::Outbox));
```

#### AUTO 


```{c}
auto fjob = qobject_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *a = new ErrorAttribute(msg);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->removeClicked();
    }
```

#### AUTO 


```{c}
const auto selectedItems{ui.transportList->selectedItems()};
```

