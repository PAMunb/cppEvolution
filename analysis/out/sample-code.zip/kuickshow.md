#### AUTO 


```{c}
auto model = view->selectionModel();
```

#### AUTO 


```{c}
auto *view
```

#### AUTO 


```{c}
auto slist = view->selectionModel()->selectedIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *view : findChildren<QAbstractItemView *>(QRegularExpression("^(?:treeView|listView)$"))) {
        // allow selection of multiple entries
        view->setSelectionMode(QAbstractItemView::ExtendedSelection);

        // we have to manually set the enabled-state of the "Open" button when the selection changes, because
        // the default only enables it when a directory is selected
        auto model = view->selectionModel();
        connect(model, SIGNAL(selectionChanged(const QItemSelection&, const QItemSelection&)), mapper, SLOT(map()));
        mapper->setMapping(model, view);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto url : urls ) {
        KFileItem item( url );
        if ( FileWidget::isImage( item ) )
            showImage( item, true );
        else
            fileWidget->setUrl( url, true );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto url : urls ) {
        KFileItem item( KFileItem::Unknown, KFileItem::Unknown, url );
        if ( FileWidget::isImage( item ) )
            showImage( item, true );
        else
            fileWidget->setUrl( url, true );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl& url : list) {
            if(url.isValid()) {
                loadImage(url);
                break;
            }
        }
```

#### AUTO 


```{c}
auto url
```

#### LAMBDA EXPRESSION 


```{c}
[job, &mostLocal]() {
            if(!job->error()) mostLocal = job->mostLocalUrl();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[item, this]() { setCurrentItem(item); }
```

#### LAMBDA EXPRESSION 


```{c}
[job, &name]() {
                    if(!job->error()) name = job->mimetype();
                }
```

#### AUTO 


```{c}
auto view
```

#### RANGE FOR STATEMENT 


```{c}
for(auto view : findChildren<QAbstractItemView*>(QRegExp("^(?:treeView|listView)$"))) {
        // allow selection of multiple entries
        view->setSelectionMode(QAbstractItemView::ExtendedSelection);

        // we have to manually set the enabled-state of the "Open" button when the selection changes, because
        // the default only enables it when a directory is selected
        auto model = view->selectionModel();
        connect(model, SIGNAL(selectionChanged(const QItemSelection&, const QItemSelection&)), mapper, SLOT(map()));
        mapper->setMapping(model, view);
    }
```

