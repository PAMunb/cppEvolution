#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QPushButton *button = box->button(QDialogButtonBox::Help);
        QPoint pos = button->pos();
        pos.ry() += button->height();
        pos = box->mapToGlobal(pos);
        help->menu()->exec(pos);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
      QPushButton *button = box->button(QDialogButtonBox::Help);
      QPoint pos = button->pos();
      pos.ry() += button->height();
      pos = box->mapToGlobal(pos);
      help->menu()->exec(pos);
  }
```

