#### AUTO 


```{c}
auto stream = pw_stream_new(pwRemote, "krfb-fb-consume-stream", reuseProps);
```

#### AUTO 


```{c}
auto builder = SPA_POD_BUILDER_INIT(buffer, sizeof(buffer));
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        { QStringLiteral("types"), QVariant::fromValue<uint>(1) }, // only MONITOR is supported
        { QStringLiteral("multiple"), false },
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &tile : tiles) {
        tile.adjust(-30, -30, 30, 30);
        if (tile.top() < d->area.top()) {
            tile.setTop(d->area.top());
        }
        if (tile.bottom() > d->area.bottom()) {
            tile.setBottom(d->area.bottom());
        }
        //
        if (tile.left() < d->area.left()) {
            tile.setLeft(d->area.left());
        }
        if (tile.right() > d->area.right()) {
            tile.setRight(d->area.right());
        }
        // move update rects so that they are positioned relative to
        //   framebuffer image, not whole screen
        tile.moveTo(tile.left() - d->area.left(),
                    tile.top() - d->area.top());
    }
```

#### AUTO 


```{c}
auto dialog = new InvitationsConnectionDialog(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto notifier : {d->ipv4notifier, d->ipv6notifier}) {
            if (notifier) {
                notifier->setEnabled(false);
                notifier->deleteLater();
            }
        }
```

#### AUTO 


```{c}
auto dialog = qobject_cast<InvitationsConnectionDialog *>(sender());
```

#### AUTO 


```{c}
auto si = (struct sockaddr_in *)&sa;
```

#### AUTO 


```{c}
auto startParameters = QVariantMap {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto selectorReply = dbusXdpScreenCastService->SelectSources(sessionPath, selectionOptions);
```

#### AUTO 


```{c}
auto flags = static_cast<pw_stream_flags>(PW_STREAM_FLAG_AUTOCONNECT | PW_STREAM_FLAG_INACTIVE | PW_STREAM_FLAG_MAP_BUFFERS);
```

#### RANGE FOR STATEMENT 


```{c}
for (RfbServer* server : std::as_const(d->servers)) {
        server->updateScreen(rects);
        server->updateCursorPosition(currentCursorPos);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RfbServer* server : qAsConst(d->servers)) {
        server->updateScreen(rects);
        server->updateCursorPosition(currentCursorPos);
    }
```

#### AUTO 


```{c}
const auto resSplit = res.split(QLatin1Char('x'));
```

#### AUTO 


```{c}
auto sessionParameters = QVariantMap {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QLatin1String("session_handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) },
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QLatin1String("session_handle_token"), QStringLiteral("krfb%1").arg(qrand()) },
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto sessionReply = dbusXdpRemoteDesktopService->CreateSession(sessionParameters);
```

#### AUTO 


```{c}
auto *d = static_cast<PWFrameBuffer::Private *>(data);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface& interface : interfaceList) {
        if(interface.flags() & QNetworkInterface::IsLoopBack)
            continue;

        if(interface.flags() & QNetworkInterface::IsRunning &&
                !interface.addressEntries().isEmpty()) {
            const QString hostName = QHostInfo::localHostName();
            const QString ipAddress = interface.addressEntries().constFirst().ip().toString();
            const QString addressLabelText = hostName.isEmpty()
                ? QStringLiteral("%1 : %2").arg(ipAddress).arg(port)
                : QStringLiteral("%1 (%2) : %3").arg(hostName, ipAddress).arg(port);
            m_ui.addressDisplayLabel->setText(addressLabelText);
        }
    }
```

#### AUTO 


```{c}
auto it = m_plugins.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                accept(new VirtualMonitorRfbClient(m_rfbClient, parent()));
            }
```

#### AUTO 


```{c}
auto *spaBuffer = pwBuffer->buffer;
```

#### AUTO 


```{c}
auto startReply = dbusXdpRemoteDesktopService->Start(sessionPath, QString(), startParameters);
```

#### AUTO 


```{c}
auto notifier
```

#### AUTO 


```{c}
auto it = buttons.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (quint32 nodeId) {
            d->pwStreamNodeId = nodeId;
            d->initPw();
        }
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        // We have to specify it's an uint, otherwise xdg-desktop-portal will not forward it to backend implementation
        { QStringLiteral("types"), QVariant::fromValue<uint>(7) }, // request all (KeyBoard, Pointer, TouchScreen)
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
    };
```

#### AUTO 


```{c}
auto sessionParameters = QVariantMap {
        { QStringLiteral("session_handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) },
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
    };
```

#### AUTO 


```{c}
const auto bufferTypes = (1 << SPA_DATA_MemFd) | (1 << SPA_DATA_MemPtr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& r : std::as_const(tiles)) {
                // I did not find XGetSubImage() analog in XCB!!
                // need function that copies pixels from one image to another
                xcb_image_t *damagedImage = xcb_image_get(
                            QX11Info::connection(),
                            this->win,
                            r.left(),
                            r.top(),
                            r.width(),
                            r.height(),
                            0xFFFFFFFF, // AllPlanes
                            XCB_IMAGE_FORMAT_Z_PIXMAP);
                // manually copy pixels
                int pxsize =  d->framebufferImage->bpp / 8;
                char *dest = fb + ((d->framebufferImage->stride * r.top()) + (r.left() * pxsize));
                char *src = (char *)damagedImage->data;
                // loop every row in damaged image
                for (int i = 0; i < damagedImage->height; i++) {
                    // copy whole row of pixels from src image to dest
                    memcpy(dest, src, damagedImage->stride);
                    dest += d->framebufferImage->stride;  // move 1 row down in dest
                    src += damagedImage->stride;          // move 1 row down in src
                }
                //
                xcb_image_destroy(damagedImage);
            }
```

#### AUTO 


```{c}
auto selectorReply = dbusXdpRemoteDesktopService->SelectDevices(sessionPath, selectionOptions);
```

#### AUTO 


```{c}
auto streamReply = dbusXdpScreenCastService->OpenPipeWireRemote(sessionPath, QVariantMap());
```

#### LAMBDA EXPRESSION 


```{c}
[map, spaBuffer] {
            munmap(map, spaBuffer->datas->maxsize + spaBuffer->datas->mapoffset);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metadata : plugins) {
            cb_preferredFrameBufferPlugin->addItem(metadata.pluginId());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
            walletWarning->setVisible(!checked);
        }
```

#### AUTO 


```{c}
auto client = new InvitationsRfbClient(m_rfbClient, parent());
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        // We have to specify it's an uint, otherwise xdg-desktop-portal will not forward it to backend implementation
        { QLatin1String("types"),QVariant::fromValue<uint>(7) }, // request all (KeyBoard, Pointer, TouchScreen)
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto width = d->videoFormat->size.width;
```

#### RANGE FOR STATEMENT 


```{c}
for (RfbClient* client : clients) {
        client->update();
    }
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        { QLatin1String("types"), QVariant::fromValue<uint>(1) }, // only MONITOR is supported
        { QLatin1String("multiple"), false },
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto d = static_cast<PWFrameBuffer::Private *>(data);
```

#### AUTO 


```{c}
auto version = dbusXdpScreenCastService->version();
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked){
            walletWarning->setVisible(checked);
        }
```

#### AUTO 


```{c}
auto plugin = factory->create<EventsPlugin>(this);
```

#### AUTO 


```{c}
auto client = static_cast<PendingRfbClient*>(cl->clientData);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface& interface : interfaceList) {
        if(interface.flags() & QNetworkInterface::IsLoopBack)
            continue;

        if(interface.flags() & QNetworkInterface::IsRunning &&
                !interface.addressEntries().isEmpty())
            m_ui.addressDisplayLabel->setText(QStringLiteral("%1 : %2")
                    .arg(interface.addressEntries().first().ip().toString())
                    .arg(port));
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto startParameters = QVariantMap {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData & md) {
            return md.serviceTypes().contains(QStringLiteral("krfb/events"));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, registry, name, dpr, resolution] (const QByteArray &interfaceName, quint32 wlname, quint32 version) {
        if (interfaceName != "zkde_screencast_unstable_v1")
            return;

        auto screencasting = new Screencasting(registry, wlname, version, this);
        auto r = screencasting->createVirtualMonitorStream(name, resolution, dpr, Screencasting::Metadata);
        connect(r, &ScreencastingStream::created, this, [this] (quint32 nodeId) {
            d->pwStreamNodeId = nodeId;
            d->initPw();
        });
    }
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        // We have to specify it's an uint, otherwise xdg-desktop-portal will not forward it to backend implementation
        { QLatin1String("types"), QVariant::fromValue<uint>(7) }, // request all (KeyBoard, Pointer, TouchScreen)
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto r = screencasting->createVirtualMonitorStream(name, resolution, dpr, Screencasting::Metadata);
```

#### AUTO 


```{c}
auto startParameters = QVariantMap {
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
    };
```

#### AUTO 


```{c}
auto dialog = new KConfigDialog(this, QStringLiteral("settings"), KrfbConfig::self());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& r : qAsConst(tiles)) {
                // I did not find XGetSubImage() analog in XCB!!
                // need function that copies pixels from one image to another
                xcb_image_t *damagedImage = xcb_image_get(
                            QX11Info::connection(),
                            this->win,
                            r.left(),
                            r.top(),
                            r.width(),
                            r.height(),
                            0xFFFFFFFF, // AllPlanes
                            XCB_IMAGE_FORMAT_Z_PIXMAP);
                // manually copy pixels
                int pxsize =  d->framebufferImage->bpp / 8;
                char *dest = fb + ((d->framebufferImage->stride * r.top()) + (r.left() * pxsize));
                char *src = (char *)damagedImage->data;
                // loop every row in damaged image
                for (int i = 0; i < damagedImage->height; i++) {
                    // copy whole row of pixels from src image to dest
                    memcpy(dest, src, damagedImage->stride);
                    dest += d->framebufferImage->stride;  // move 1 row down in dest
                    src += damagedImage->stride;          // move 1 row down in src
                }
                //
                xcb_image_destroy(damagedImage);
            }
```

#### AUTO 


```{c}
auto stream = pw_stream_new(pwCore, "krfb-fb-consume-stream", reuseProps);
```

#### AUTO 


```{c}
auto registry = new Registry(this);
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        { QStringLiteral("types"), QVariant::fromValue<uint>(1) }, // only MONITOR is supported
        { QStringLiteral("multiple"), false },
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto screencasting = new Screencasting(registry, wlname, version, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QNetworkInterface& interface : interfaceList) {
        if(interface.flags() & QNetworkInterface::IsLoopBack)
            continue;

        if(interface.flags() & QNetworkInterface::IsRunning &&
                !interface.addressEntries().isEmpty()) {
            const QString hostName = QHostInfo::localHostName();
            const QString ipAddress = interface.addressEntries().first().ip().toString();
            const QString addressLabelText = hostName.isEmpty()
                ? QStringLiteral("%1 : %2").arg(ipAddress).arg(port)
                : QStringLiteral("%1 (%2) : %3").arg(hostName, ipAddress).arg(port);
            m_ui.addressDisplayLabel->setText(addressLabelText);
        }
    }
```

#### AUTO 


```{c}
auto d = static_cast<PWFrameBuffer::Private*>(data);
```

#### AUTO 


```{c}
auto size = height * stride;
```

#### AUTO 


```{c}
auto pwfb = new PWFrameBuffer(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &tile : tiles) {
                // if current rect has intersection with tile, unite them
                if (ri.intersects(tile)) {
                    tile |= ri;
                    inserted = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto plugin = factory->create<FrameBufferPlugin>(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData & md) {
            return md.serviceTypes().contains(QStringLiteral("krfb/framebuffer"));
        }
```

#### AUTO 


```{c}
auto stride = SPA_ROUND_UP_N(width * BYTES_PER_PIXEL, 4);
```

#### RANGE FOR STATEMENT 


```{c}
for (RfbServer *server : std::as_const(d->servers)) {
        server->updateFrameBuffer(d->fb->data(), d->fb->width(), d->fb->height(), d->fb->depth());
    }
```

#### AUTO 


```{c}
auto client = static_cast<RfbClient*>(cl->clientData);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        // check if framebuffer plugin config has changed
        if (s_prevFramebufferPlugin != KrfbConfig::preferredFrameBufferPlugin()) {
            KMessageBox::information(this, i18n("To apply framebuffer plugin setting, "
                                                "you need to restart the program."));
        }
    }
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        { QLatin1String("types"), 1 }, // only MONITOR is supported
        { QLatin1String("multiple"), false },
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QLatin1String("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto connection = ConnectionThread::fromApplication(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        // check if framebuffer plugin config has changed
        if (s_prevFramebufferPlugin != KrfbConfig::preferredFrameBufferPlugin()) {
            KMessageBox::information(this, i18n("To apply framebuffer plugin setting, "
                                                "you need to restart the program."));
        }
        // check if kwallet config has changed
        if (s_prevNoWallet != KrfbConfig::noWallet()) {
            // try to apply settings immediately
            if (KrfbConfig::noWallet()) {
                InvitationsRfbServer::instance->closeKWallet();
            } else {
                InvitationsRfbServer::instance->openKWallet();
                // erase stored passwords from krfbconfig file
                KConfigGroup securityConfigGroup(KSharedConfig::openConfig(), "Security");
                securityConfigGroup.deleteEntry("desktopPassword");
                securityConfigGroup.deleteEntry("unattendedPassword");
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool checked) {
            walletWarning->setVisible(checked);
        }
```

#### AUTO 


```{c}
auto spaBuffer = pwBuffer->buffer;
```

#### AUTO 


```{c}
auto stream = new ScreencastingStream(this);
```

#### AUTO 


```{c}
auto selectionOptions = QVariantMap {
        // We have to specify it's an uint, otherwise xdg-desktop-portal will not forward it to backend implementation
        { QStringLiteral("types"), QVariant::fromValue<uint>(7) }, // request all (KeyBoard, Pointer, TouchScreen)
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

#### AUTO 


```{c}
auto stride = SPA_ROUND_UP_N(width * bpp, 4);
```

#### AUTO 


```{c}
auto ev = static_cast<xcb_generic_event_t *>(message);
```

#### AUTO 


```{c}
auto server = static_cast<RfbServer*>(cl->screen->screenData);
```

#### AUTO 


```{c}
auto xdevt = (xcb_damage_notify_event_t *)xevent;
```

#### AUTO 


```{c}
auto stream = createWindowStream(QString::fromUtf8(window->uuid()), mode);
```

#### AUTO 


```{c}
auto reuseProps = pw_properties_new("pipewire.client.reuse", "1", nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[&mainWindow](const QStringList & /*arguments*/, const QString & /*workdir*/) {
        if (!mainWindow.isVisible()) {
            mainWindow.setVisible(true);
        } else {
            KWindowSystem::updateStartupId(mainWindow.windowHandle());
            KWindowSystem::activateWindow(mainWindow.windowHandle());
        }
    }
```

#### AUTO 


```{c}
auto &tile
```

#### AUTO 


```{c}
auto height = d->videoFormat->size.height;
```

#### AUTO 


```{c}
auto sessionParameters = QVariantMap {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 10, 0))
        { QStringLiteral("session_handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) },
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(QRandomGenerator::global()->generate()) }
#else
        { QStringLiteral("session_handle_token"), QStringLiteral("krfb%1").arg(qrand()) },
        { QStringLiteral("handle_token"), QStringLiteral("krfb%1").arg(qrand()) }
#endif
    };
```

