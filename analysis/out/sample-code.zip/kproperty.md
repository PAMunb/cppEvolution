#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : *propertyNames) {
                    KProperty *property = d->set_d()->property(propertyName);
                    if (property->isVisible()) {
                        ++visiblePropertiesForGroup;
                    }
                    if (visiblePropertiesForGroup == row) {
                        childItem = property;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemName : d->listData.namesAsStringList()) {
        addItem(itemName);
        if (d->options.iconProvider) {
            QIcon icon = d->options.iconProvider->icon(index);
            setItemIcon(index, icon);
        }
        index++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : correctedStandardLocations) {
        fullPath = QFileInfo(dir + QLatin1Char('/') + path).canonicalFilePath();
        if (fileReadable(fullPath)) {
            return fullPath;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupName : d->set_d()->groupNames) {
            const QList<QByteArray>* propertyNames = d->set_d()->propertiesOfGroup.value(groupName);
            if (!propertyNames) {
                continue;
            }
            int row = 0; // row within the group
            //! @todo Care about sorting
            for (const QByteArray &propertyName : *propertyNames) {
                d->indicesForNames.insert(propertyName,
                                          QPersistentModelIndex(createIndex(row, 0, d->set_d()->property(propertyName))));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KProperty* p : *d->children) {
            p->clearModifiedFlag();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : *propertyNames) {
                d->indicesForNames.insert(propertyName,
                                          QPersistentModelIndex(createIndex(row, 0, d->set_d()->property(propertyName))));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : standardLocations) {
            if (dir.indexOf(re) != -1) {
                QString realDir(dir);
                realDir.replace(re, QLatin1Char('/') + privateName);
                result.insert(realDir);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &shape : keys()) {
            if (shape.toInt() == _shape)
                return index;
            index++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &name : d->names) {
        result.append(name.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &groupName : d->set_d()->groupNames()) {
            const QList<QByteArray>* propertyNames = d->set_d()->propertyNamesForGroup(groupName);
            if (!propertyNames) {
                continue;
            }
            int row = 0; // row within the group
            //! @todo Care about sorting
            for (const QByteArray &propertyName : *propertyNames) {
                d->indicesForNames.insert(propertyName,
                                          QPersistentModelIndex(createIndex(row, 0, d->set_d()->property(propertyName))));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &propertyName : *propertyNames) {
            if (d->set_d()->property(propertyName)->isVisible()) {
                ++visiblePropertiesForGroup;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &propertyName : *propertyNames) {
            if (d->set_d()->property(propertyName)->isVisible()) {
                return true; // at least one visible property in this group
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &pathDir : qgetenv("PATH").split(KPATH_SEPARATOR)) {
        const QString dataDirFromPath = QFileInfo(QFile::decodeName(pathDir) + QStringLiteral("/data/")
                                                  + path).canonicalFilePath();
        if (fileReadable(dataDirFromPath)) {
            return dataDirFromPath;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        d->keys.append(key);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &path) {
                         return QDir::toNativeSeparators(path);
                       }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &key : d->keys) {
        result.append(key.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : names) {
        d->names.append(name);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { emit commitData(this); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KProperty* p : *d->children) {
            if (p->isModified()) {
                return true;
            }
        }
```

