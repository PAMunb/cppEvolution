#### AUTO 


```{c}
auto* job = new KIO::OpenUrlJob(frameUrl, QL1S("text/plain"));
```

#### AUTO 


```{c}
auto* job = new KIO::OpenUrlJob(QUrl::fromLocalFile(tempFile.fileName()), QL1S("text/plain"));
```

#### AUTO 


```{c}
auto* job = new KIO::OpenUrlJob(pageUrl, QL1S("text/plain"));
```

