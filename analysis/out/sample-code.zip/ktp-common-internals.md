#### RANGE FOR STATEMENT 


```{c}
for(uint id: ids) {
        auto found = messages.find(id);
        if(found == messages.end()) {
            kDebug() << "Client trying to acknowledge non existing message with id" << id;
            context->setFinishedWithError(TP_QT_ERROR_INVALID_ARGUMENT,
                    QLatin1String("Message with given ID is not present in the message queue"));
            return;
        } else {
            toAcknowledge << *found;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(uint id: ids) {
        auto found = messages.find(id);
        if(found == messages.end()) {
            qCDebug(KTP_PROXY) << "Client trying to acknowledge non existing message with id" << id;
            context->setFinishedWithError(TP_QT_ERROR_INVALID_ARGUMENT,
                    QLatin1String("Message with given ID is not present in the message queue"));
            return;
        } else {
            toAcknowledge << *found;
        }
    }
```

#### AUTO 


```{c}
const auto& mp
```

#### AUTO 


```{c}
auto usIt = userStates.find(ctx.accountId);
```

#### AUTO 


```{c}
auto tpAccountsList = accountManager->validAccounts()->accounts();
```

#### LAMBDA EXPRESSION 


```{c}
[this, accountId](Tp::PendingOperation *op) {
                    if (op->isError()) {
                        qWarning() << "Failed to create KDE Telepathy account -" << op->errorName() << op->errorMessage();
                    } else {
                        Tp::PendingAccount *pendingAccount = qobject_cast<Tp::PendingAccount*>(op);
                        if (!pendingAccount) {
                            qWarning() << "Cannot cast operation to PendingAccount!";
                            return;
                        }
                        KConfigGroup ktpKaccountsGroup = d->kaccountsConfig->group(QStringLiteral("kaccounts-ktp"));
                        ktpKaccountsGroup.writeEntry(QString::number(accountId), pendingAccount->account()->objectPath());

                        KConfigGroup kaccountsKtpGroup = d->kaccountsConfig->group(QStringLiteral("ktp-kaccounts"));
                        kaccountsKtpGroup.writeEntry(pendingAccount->account()->objectPath(), accountId);

                        d->kaccountsConfig->sync();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fpInfo: infoList) {
        QVERIFY(!fpInfo.isVerified);
        QVERIFY(fpInfo.inUse);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KTp::Presence &presence, const KTp::Presence &other) {
            if (KTp::Presence::sortPriority(presence.type()) == KTp::Presence::sortPriority(other.type())) {
                return (QString::localeAwareCompare(presence.statusMessage(), other.statusMessage()) < 0);
            } else {
                return (KTp::Presence::sortPriority(presence.type()) < KTp::Presence::sortPriority(other.type()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &contactId: person.contactUris()) {
        if (!contactId.startsWith(QStringLiteral("ktp://"))) {
            continue;
        }
        PersonData contact(contactId);
        const QString tpcontactId = contact.contactCustomProperty(QStringLiteral("telepathy-contactId")).toString();
        const QString accountPath = contact.contactCustomProperty(QStringLiteral("telepathy-accountPath")).toString(); //probably unused till we fix everything properly

        Tp::AccountPtr account = KTp::accountManager()->accountForObjectPath(accountPath);
        if (!account) {
            continue;
        }

        QLabel *iconLabel = new QLabel(root);
        const int iconSize = root->style()->pixelMetric(QStyle::PM_SmallIconSize);
        iconLabel->setPixmap(QIcon::fromTheme(account->iconName()).pixmap(iconSize, iconSize));
        layout->addWidget(iconLabel, row, 0);

        QLabel *label = new QLabel(tpcontactId, root);
        label->setTextInteractionFlags(Qt::TextSelectableByMouse);
        layout->addWidget(label, row, 1);

        row++;
        //FUTURE - presence here + blocked + presence subscription
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : m_enabledAccounts->accounts()) {
            accountConnectionStatuses << ConnectionStatus(account->connectionStatus());
            if (!account->connectionError().isEmpty()) {
                hasConnectionError = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &&mes: enqueuedMessages) {
            onMessageReceived(mes);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool changed) {
        m_buttonBox->button(QDialogButtonBox::Apply)->setEnabled(changed);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](Tp::PendingOperation *op) {
        if (op->isError()) {
            qWarning() << "AccountManager failed to become ready!" << op->errorMessage();
            return;
        }

        m_isReady = true;

        Q_EMIT ready();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, accountId](KJob *job) {

        if (job->error()) {
            qWarning() << "Failed at receiving credentials, aborting creating new Telepathy account";
            return;
        }

        Tp::ProtocolInfo protocolInfo = d->connectionManager->protocol(d->profile->protocolName());
        Tp::ProtocolParameterList parameters = protocolInfo.parameters();
        Tp::Profile::ParameterList profileParameters = d->profile->parameters();

        QVariantMap credentials = qobject_cast<GetCredentialsJob*>(job)->credentialsData();
        QVariantMap values;

        Q_FOREACH (const Tp::ProtocolParameter &parameter, parameters) {
            //try and find the correct profile parameter, if it can't be found leave it as empty.
            Q_FOREACH (const Tp::Profile::Parameter &profileParameter, profileParameters) {
                if (profileParameter.name() == parameter.name()) {
                    values.insert(parameter.name(), profileParameter.value());
                    break;
                }
            }
        }

        values.insert(QStringLiteral("account"), credentials.value(QStringLiteral("UserName")));

        // FIXME: In some next version of tp-qt4 there should be a convenience class for this
        // https://bugs.freedesktop.org/show_bug.cgi?id=33153
        QVariantMap properties;

        if (d->accountManager->supportedAccountProperties().contains(QLatin1String("org.freedesktop.Telepathy.Account.Service"))) {
            properties.insert(QLatin1String("org.freedesktop.Telepathy.Account.Service"), d->profile->serviceName());
        }
        if (d->accountManager->supportedAccountProperties().contains(QLatin1String("org.freedesktop.Telepathy.Account.Enabled"))) {
            properties.insert(QLatin1String("org.freedesktop.Telepathy.Account.Enabled"), true);
        }

        qDebug() << "Sending account manager request to create new account";

        Tp::PendingAccount *pa = d->accountManager->createAccount(d->profile->cmName(),
                                                                  d->profile->protocolName(),
                                                                  credentials.value(QStringLiteral("UserName")).toString(),
                                                                  values,
                                                                  properties);

        connect(pa,
                &Tp::PendingAccount::finished, [this, accountId](Tp::PendingOperation *op) {
                    if (op->isError()) {
                        qWarning() << "Failed to create KDE Telepathy account -" << op->errorName() << op->errorMessage();
                    } else {
                        Tp::PendingAccount *pendingAccount = qobject_cast<Tp::PendingAccount*>(op);
                        if (!pendingAccount) {
                            qWarning() << "Cannot cast operation to PendingAccount!";
                            return;
                        }
                        KConfigGroup ktpKaccountsGroup = d->kaccountsConfig->group(QStringLiteral("kaccounts-ktp"));
                        ktpKaccountsGroup.writeEntry(QString::number(accountId), pendingAccount->account()->objectPath());

                        KConfigGroup kaccountsKtpGroup = d->kaccountsConfig->group(QStringLiteral("ktp-kaccounts"));
                        kaccountsKtpGroup.writeEntry(pendingAccount->account()->objectPath(), accountId);

                        d->kaccountsConfig->sync();
                    }
                });

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        bool isPerson = index.data(KTp::RowTypeRole).toUInt() == KTp::PersonRowType;
        QString personString = isPerson ? QStringLiteral("Yes, ") + QString::number(index.model()->rowCount(index)) + QStringLiteral(" subcontacts") : QStringLiteral("No");

        qDebug() << "Contact info";
        qDebug() << "------------";
        qDebug() << "        ID:" << index.data(KTp::IdRole).toString();
        qDebug() << " Person ID:" << index.data(KTp::PersonIdRole).toString();
        qDebug() << "  Username:" << index.data(Qt::DisplayRole).toString();
        qDebug() << "   Blocked:" << index.data(KTp::ContactIsBlockedRole).toString();
        qDebug() << "    Groups:" << index.data(KTp::ContactGroupsRole).toStringList();
        qDebug() << " Is Person:" << personString;
        qDebug();
    }
```

#### AUTO 


```{c}
auto it = message[0].find(QLatin1String("message-sender"));
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Tp::AccountPtr &account, const Tp::AccountPtr &other) {
            if (account->serviceName() == other->serviceName()) {
                return (QString::localeAwareCompare(account->normalizedName(), other->normalizedName()) < 0);
            } else {
                return (QString::localeAwareCompare(account->serviceName(), other->serviceName()) < 0);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (Tp::PendingOperation* op) {
        if (op->isError()) {
            qCDebug(KTP_COMMONINTERNALS) << op->errorName();
            qCDebug(KTP_COMMONINTERNALS) << op->errorMessage();

            qCDebug(KTP_COMMONINTERNALS) << "Something unexpected happened to"
              << "the core part of your Instant Messaging system and it couldn't"
              << "be initialized. Try restarting the client.";

            return;
        }

        setAccountManager(accountManager);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, accountId](KJob *job) {

        if (job->error()) {
            qWarning() << "Failed at receiving credentials, aborting creating new Telepathy account";
            return;
        }

        Tp::ProtocolInfo protocolInfo = d->connectionManager->protocol(d->profile->protocolName());
        Tp::ProtocolParameterList parameters = protocolInfo.parameters();
        Tp::Profile::ParameterList profileParameters = d->profile->parameters();

        QVariantMap credentials = qobject_cast<GetCredentialsJob*>(job)->credentialsData();
        QVariantMap values;

        Q_FOREACH (const Tp::ProtocolParameter &parameter, parameters) {
            //try and find the correct profile parameter, if it can't be found leave it as empty.
            Q_FOREACH (const Tp::Profile::Parameter &profileParameter, profileParameters) {
                if (profileParameter.name() == parameter.name()) {
                    values.insert(parameter.name(), profileParameter.value());
                    break;
                }
            }
        }

        values.insert(QStringLiteral("account"), credentials.value(QStringLiteral("UserName")));

        // FIXME: In some next version of tp-qt4 there should be a convenience class for this
        // https://bugs.freedesktop.org/show_bug.cgi?id=33153
        QVariantMap properties;

        if (d->accountManager->supportedAccountProperties().contains(QLatin1String("org.freedesktop.Telepathy.Account.Service"))) {
            properties.insert(QLatin1String("org.freedesktop.Telepathy.Account.Service"), d->profile->serviceName());
        }
        if (d->accountManager->supportedAccountProperties().contains(QLatin1String("org.freedesktop.Telepathy.Account.Enabled"))) {
            properties.insert(QLatin1String("org.freedesktop.Telepathy.Account.Enabled"), true);
        }

        Tp::PendingAccount *pa = d->accountManager->createAccount(d->profile->cmName(),
                                                                  d->profile->protocolName(),
                                                                  credentials.value(QStringLiteral("UserName")).toString(),
                                                                  values,
                                                                  properties);

        connect(pa,
                &Tp::PendingAccount::finished, [this, accountId](Tp::PendingOperation *op) {
                    if (op->isError()) {
                        qWarning() << "Failed to create KDE Telepathy account -" << op->errorName() << op->errorMessage();
                    } else {
                        Tp::PendingAccount *pendingAccount = qobject_cast<Tp::PendingAccount*>(op);
                        if (!pendingAccount) {
                            qWarning() << "Cannot cast operation to PendingAccount!";
                            return;
                        }
                        KConfigGroup ktpKaccountsGroup = d->kaccountsConfig->group(QStringLiteral("kaccounts-ktp"));
                        ktpKaccountsGroup.writeEntry(QString::number(accountId), pendingAccount->account()->objectPath());

                        KConfigGroup kaccountsKtpGroup = d->kaccountsConfig->group(QStringLiteral("ktp-kaccounts"));
                        kaccountsKtpGroup.writeEntry(pendingAccount->account()->objectPath(), accountId);

                        d->kaccountsConfig->sync();
                    }
                });

    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        Q_FOREACH (Conversation *c, m_conversations.values()) {
            if (!c->textChannel().isNull()) {
                c->textChannel()->requestClose();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &contactId: person.contactUris()) {
        if (!contactId.startsWith("ktp://")) {
            continue;
        }
        PersonData contact(contactId);
        const QString tpcontactId = contact.contactCustomProperty(QStringLiteral("telepathy-contactId")).toString();
        const QString accountPath = contact.contactCustomProperty(QStringLiteral("telepathy-accountPath")).toString(); //probably unused till we fix everything properly

        Tp::AccountPtr account = KTp::accountManager()->accountForObjectPath(accountPath);
        if (!account) {
            continue;
        }

        QLabel *iconLabel = new QLabel(root);
        const int iconSize = root->style()->pixelMetric(QStyle::PM_SmallIconSize);
        iconLabel->setPixmap(QIcon::fromTheme(account->iconName()).pixmap(iconSize, iconSize));
        layout->addWidget(iconLabel, row, 0);

        QLabel *label = new QLabel(tpcontactId, root);
        label->setTextInteractionFlags(Qt::TextSelectableByMouse);
        layout->addWidget(label, row, 1);

        row++;
        //FUTURE - presence here + blocked + presence subscription
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : m_enabledAccounts->accounts()) {
            if (KTp::Presence(account->currentPresence()) > highestCurrentPresence) {
                highestCurrentPresence = KTp::Presence(account->currentPresence());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : m_enabledAccounts->accounts()) {
            if (KTp::Presence(account->requestedPresence()) > highestRequestedPresence) {
                highestRequestedPresence = KTp::Presence(account->requestedPresence());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : m_enabledAccounts->accounts()) {
            changing = account->isChangingPresence();

            if (account->isChangingPresence()) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto samePin = [pin](const KTp::PersistentContactPtr &p) -> bool { return p->contactId() == pin->contactId(); };
```

#### AUTO 


```{c}
auto found = messages.find(id);
```

#### AUTO 


```{c}
auto it = message[1].find(QLatin1String("content"));
```

#### AUTO 


```{c}
auto presenceMessageGreaterThan = [] (const KTp::Presence &presence, const KTp::Presence &other) {
            if (KTp::Presence::sortPriority(presence.type()) == KTp::Presence::sortPriority(other.type())) {
                return (QString::localeAwareCompare(presence.statusMessage(), other.statusMessage()) < 0);
            } else {
                return (KTp::Presence::sortPriority(presence.type()) < KTp::Presence::sortPriority(other.type()));
            }
        };
```

#### AUTO 


```{c}
const auto &fpInfo
```

#### AUTO 


```{c}
auto it = message[0].find(header);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &contactId: person.contactIds()) {
        PersonData contact(contactId);
        const QString tpcontactId = contact.contactCustomProperty(QStringLiteral("telepathy-contactId")).toString();
        const QString accountPath = contact.contactCustomProperty(QStringLiteral("telepathy-accountPath")).toString(); //probably unused till we fix everything properly

        Tp::AccountPtr account = KTp::accountManager()->accountForObjectPath(accountPath);
        if (!account) {
            continue;
        }

        QLabel *iconLabel = new QLabel(root);
        const int iconSize = root->style()->pixelMetric(QStyle::PM_SmallIconSize);
        iconLabel->setPixmap(QIcon::fromTheme(account->iconName()).pixmap(iconSize, iconSize));
        layout->addWidget(iconLabel, row, 0);

        QLabel *label = new QLabel(tpcontactId, root);
        label->setTextInteractionFlags(Qt::TextSelectableByMouse);
        layout->addWidget(label, row, 1);

        row++;
        //FUTURE - presence here + blocked + presence subscription
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](Tp::PendingOperation *op) {
        if (op->isError()) {
            qWarning() << "Requesting text channel failed:" << op->errorName() << op->errorMessage();
            return;
        }

        Tp::PendingChannel *pc = qobject_cast<Tp::PendingChannel*>(op);
        if (pc) {
            Tp::TextChannel *channel = qobject_cast<Tp::TextChannel*>(pc->channel().data());
            handleChannel(account, Tp::TextChannelPtr(channel));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& mp: messages) {
        pending << mp.parts();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        bool isPerson = index.data(KTp::RowTypeRole).toUInt() == KTp::PersonRowType;
        QString personString = isPerson ? QStringLiteral("Yes, ") + QString::number(index.model()->rowCount(index)) + QStringLiteral(" subcontacts") : QStringLiteral("No");

        qDebug() << "Contact info";
        qDebug() << "------------";
        qDebug() << "        ID:" << index.data(KTp::IdRole).toString();
        qDebug() << " Person ID:" << index.data(KTp::PersonIdRole).toString();
        qDebug() << "  Username:" << index.data(Qt::DisplayRole).toString();
        qDebug() << " Is Person:" << personString;
        qDebug();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Tp::PendingOperation *op) {
        if (op->isError()) {
            qWarning() << "Unable to enable account -" << op->errorName() << op->errorMessage();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fpInfo: infoList) {
        QVERIFY(!fpInfo.isVerified);
        QVERIFY(fpInfo.inUse);
        if(fpInfo.contactName == alice.context().recipientName) {
            QCOMPARE(fpInfo.fingerprint, alice.remoteFingerprint());
        }
        if(fpInfo.contactName == aliceJ.context().recipientName) {
            QCOMPARE(fpInfo.fingerprint, aliceJ.remoteFingerprint());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : m_enabledAccounts->accounts()) {
        onAccountEnabledChanged(account);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const QString &accountUID) {
            if (accountUID == account->uniqueIdentifier()) {
                onAccountUpdated();
            }
        }
```

#### AUTO 


```{c}
auto it = message[0].find(QLatin1String("message-sent"));
```

#### AUTO 


```{c}
auto kaccountsList = KAccounts::accountsManager()->accountList();
```

#### LAMBDA EXPRESSION 


```{c}
[](Tp::PendingOperation *op) {
        if (op->isError()) {
            qWarning() << "Unable to disable account -" << op->errorName() << op->errorMessage();
        }
    }
```

#### AUTO 


```{c}
auto &&mes
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fpInfo: infoList) {
        QVERIFY(fpInfo.isVerified);
        QVERIFY(fpInfo.inUse);
    }
```

#### AUTO 


```{c}
auto it = message[1].find(QLatin1String("content-type"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &contactId: person.contactUris()) {
        PersonData contact(contactId);
        const QString tpcontactId = contact.contactCustomProperty(QStringLiteral("telepathy-contactId")).toString();
        const QString accountPath = contact.contactCustomProperty(QStringLiteral("telepathy-accountPath")).toString(); //probably unused till we fix everything properly

        Tp::AccountPtr account = KTp::accountManager()->accountForObjectPath(accountPath);
        if (!account) {
            continue;
        }

        QLabel *iconLabel = new QLabel(root);
        const int iconSize = root->style()->pixelMetric(QStyle::PM_SmallIconSize);
        iconLabel->setPixmap(QIcon::fromTheme(account->iconName()).pixmap(iconSize, iconSize));
        layout->addWidget(iconLabel, row, 0);

        QLabel *label = new QLabel(tpcontactId, root);
        label->setTextInteractionFlags(Qt::TextSelectableByMouse);
        layout->addWidget(label, row, 1);

        row++;
        //FUTURE - presence here + blocked + presence subscription
    }
```

#### AUTO 


```{c}
auto it = message[0].find(QLatin1String("message-sender-id"));
```

#### AUTO 


```{c}
auto accountIdentifiersLessThan = [] (const Tp::AccountPtr &account, const Tp::AccountPtr &other) {
            if (account->serviceName() == other->serviceName()) {
                return (QString::localeAwareCompare(account->normalizedName(), other->normalizedName()) < 0);
            } else {
                return (QString::localeAwareCompare(account->serviceName(), other->serviceName()) < 0);
            }
        };
```

#### AUTO 


```{c}
auto usIt = userStates.find(accountId);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &fpInfo: infoList) {
        QVERIFY(!fpInfo.inUse);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Tp::ReceivedMessage &m: chan->messageQueue()) {
        onMessageReceived(m);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[pin](const KTp::PersistentContactPtr &p) -> bool { return p->contactId() == pin->contactId(); }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        d->profile = Tp::Profile::createForServiceName(providerName);

        d->connectionManager = Tp::ConnectionManager::create(d->profile->cmName());
        Tp::PendingReady *op = d->connectionManager->becomeReady();
        op->setProperty("accountId", accountId);
        connect(op, SIGNAL(finished(Tp::PendingOperation*)),
                this, SLOT(onConnectionManagerReady(Tp::PendingOperation*)));

        delayTimer->deleteLater();
    }
```

