#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(entryActions)) {
            action->setEnabled(false);
        }
```

#### AUTO 


```{c}
auto *jots = new KJotsMain;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : qAsConst(list)) {
        Akonadi::AgentInstance instance = Akonadi::AgentManager::self()->instance(col.resource());
        if (instance.type().identifier() == akonadiNotesInstanceName()) {
            Akonadi::CollectionFetchJob *collectionFetchJob = new Akonadi::CollectionFetchJob(col, Akonadi::CollectionFetchJob::FirstLevel, this);
            collectionFetchJob->setProperty("FetchedCollection", col.id());
            connect(collectionFetchJob, &Akonadi::CollectionFetchJob::result, this, &LocalResourceCreator::topLevelFetchFinished);
            return;
        }
    }
```

#### AUTO 


```{c}
auto *eda = col.attribute<EntityDisplayAttribute>();
```

#### AUTO 


```{c}
auto linkDialog = std::make_unique<KJotsLinkDialog>(const_cast<QAbstractItemModel*>(d->index.model()), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            if (m_editorWidget->isVisible()) {
                m_editorWidget->slotFind();
            } else {
                m_browserWidget->slotFind();
            }
        }
```

#### AUTO 


```{c}
auto *bookmarkMenu = actionCollection->add<KActionMenu>(QStringLiteral("bookmarks"));
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(pageActions)) {
                if (action->objectName() == QString::fromLatin1(name(KStandardAction::Cut))) {
                    action->setEnabled(activeEditor()->textCursor().hasSelection());
                } else {
                    action->setEnabled(true);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->slotLockUnlockNoteBook(); }
```

#### AUTO 


```{c}
auto item = idx.data(EntityTreeModel::ItemRole).value<Item>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(bookActions)) {
            action->setEnabled(false);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            activeEditor()->setFocus();
        }
```

#### AUTO 


```{c}
const auto &attachment
```

#### AUTO 


```{c}
auto *validator = new KJotsBookshelfEntryValidator(proxyModel, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
                const QString text = textCursor().hasSelection() ? textCursor().selectedText() : document()->toPlainText();
                Q_EMIT say(text);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            activeEditor()->selectAll();
        }
```

#### AUTO 


```{c}
auto *completer = new QCompleter(proxyModel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : instances) {
        if (instance.type().identifier() == akonadiNotesInstanceName()) {
            found = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(editorActions)) {
        action->setEnabled(itemsSelected == 1);
    }
```

#### AUTO 


```{c}
auto linkDialog = std::make_unique<KJotsLinkDialog>(const_cast<QAbstractItemModel*>(m_index->model()), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(bookActions)) {
                if (action->objectName() == QLatin1String("del_folder") && colIsRootCollection) {
                    action->setEnabled(false);
                } else {
                    action->setEnabled(true);
                }

            }
```

#### AUTO 


```{c}
auto model = const_cast<QAbstractItemModel *>(m_index->model());
```

#### AUTO 


```{c}
auto printer = std::make_unique<QPrinter>(mode);
```

#### AUTO 


```{c}
auto *bookmarks = new KJotsBookmarks(m_collectionView->selectionModel(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            exportSelection(QStringLiteral("default"), QStringLiteral("template.html"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(anySelectionActions)) {
        action->setEnabled(selectionSize >= 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx){
                return idx.data(KJotsModel::GrantleeObjectRole);
            }
```

#### AUTO 


```{c}
auto *proxyModel = new KDescendantsProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(pageActions)) {
            action->setEnabled(false);
        }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(entries);
```

#### AUTO 


```{c}
auto *linkLayout = new QGridLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            const QModelIndex idx = previousNextEntity(m_collectionView, +1);
            m_collectionView->selectionModel()->select(idx, QItemSelectionModel::SelectCurrent);
            m_collectionView->expand(idx);
        }
```

#### AUTO 


```{c}
auto *model = const_cast<QAbstractItemModel *>(m_index->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selection) {
        Collection col = idx.data(EntityTreeModel::CollectionRole).value<Collection>();
        if (col.isValid()) {
            collections << col;
        } else {
            Item item = idx.data(EntityTreeModel::ItemRole).value<Item>();
            if (item.isValid()) {
                items << item;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            if (m_collectionView->hasFocus()) {
                m_actionManager->action(StandardActionManager::DeleteCollections)->trigger();
            } else {
                m_actionManager->action(StandardActionManager::DeleteItems)->trigger();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : list) {
            if (0 == QString::compare(m_model->data(index).toString(), input, Qt::CaseInsensitive)) {
                return Acceptable;
            }
            return Intermediate;
        }
```

#### AUTO 


```{c}
auto *entries = new QWidget(this);
```

#### AUTO 


```{c}
auto printer = setupPrinter(QPrinter::HighResolution);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::AgentInstance &instance) {
                                    return instance.type().identifier() == akonadiNotesInstanceName();
                                }
```

#### LAMBDA EXPRESSION 


```{c}
[&input](const QModelIndex &index) {
            return QString::compare(index.data().toString(), input, Qt::CaseInsensitive);
        }
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<Akonadi::ItemCreateJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            m_itemView->selectionModel()->select(previousNextEntity(m_itemView, +1), QItemSelectionModel::SelectCurrent | QItemSelectionModel::Rows);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            exportSelection(QStringLiteral("plain_text"), QStringLiteral("template.txt"));
        }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto *bookmarks = new KJotsBookmarks(treeview->selectionModel(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, action](int index){
            action->setEnabled(m_stackedWidget->widget(index) == m_editorWidget);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->slotLockUnlockNote(); }
```

#### AUTO 


```{c}
auto cursor = document->property("textCursor").value<QTextCursor>();
```

#### AUTO 


```{c}
auto printer = setupPrinter(QPrinter::ScreenResolution);
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(entryActions)) {
            action->setEnabled(true);
        }
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(KJotsModel::updateItem(idx, m_editor->document()));
```

#### AUTO 


```{c}
auto *displayAttribute = item.attribute<EntityDisplayAttribute>();
```

#### AUTO 


```{c}
auto *obj = new KJotsEntity(childIndex);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(pageActions)) {
                action->setEnabled(false);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (url.scheme() == QStringLiteral("akonadi")) {
                QModelIndex idx = KJotsModel::modelIndexForUrl(m_index->model(), url);
                if (idx.isValid()) {
                    insertHtml(QStringLiteral("<a href=\"%1\">%2</a>").arg(idx.data(KJotsModel::EntityUrlRole).toString(),
                                                                           idx.data().toString()));
                }
            } else {
                QString text = source->hasText() ? source->text() : url.toString(QUrl::RemovePassword);
                insertHtml(QStringLiteral("<a href=\"%1\">%2</a>").arg(QString::fromUtf8(url.toEncoded()), text));
            }
        }
```

#### AUTO 


```{c}
auto *layout2 = new QGridLayout(replaceDialog->findExtension());
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            insertPlainText(QLocale().toString(QDateTime::currentDateTime(), QLocale::ShortFormat));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &header : qAsConst(entryHeaders)) {
                if (line.startsWith(QLatin1String(header))) {
                    qDebug() << "init" << line << header;
                    line = line.right(line.size() - header.size()).trimmed();
                    qDebug() << "header tag removed: " << line;

                    QStringList list = line.split(QLatin1Char(' '));
                    int startOfTitle = line.indexOf(QLatin1Char(' '));
                    bool ok = false;

                    qDebug() << "depth" << list.at(0).trimmed();

                    int depth = list.at(0).trimmed().toInt(&ok);
                    qDebug() << ok << "valid depth";
                    if (ok) {
                        QString title = line.right(line.size() - startOfTitle).trimmed();
                        KnowItNote n;
                        n.title = title;
                        n.depth = depth;
                        n.id = id;
                        if (depth == 0) {
                            n.parent = 0;
                        } else {
                            n.parent = m_lastNoteAtLevel[depth - 1].id;
                        }

                        QString contentLine = in.readLine();
                        //QList< QPair <QString, QString> > links;
                        QString contents;
                        QString url;
                        QString target;
                        while ((!in.atEnd()) && (!contentLine.trimmed().isEmpty())) {
                            qDebug() << contentLine;
                            if (contentLine.startsWith(QLatin1String("\\Link"))) {
                                url = contentLine.right(contentLine.size() - 5).trimmed();
                                contentLine = in.readLine();
                                continue;
                            }
                            if (contentLine.startsWith(QLatin1String("\\Descr"))) {
                                target = contentLine.right(contentLine.size() - 6).trimmed();
                                contentLine = in.readLine();
                                continue;
                            }
                            if (!url.isEmpty() && !target.isEmpty()) {
                                QPair< QString, QString > link;
                                link.first = url;
                                link.second = target;
                                n.links << link;
                                url.clear();
                                target.clear();
                            }
                            contents.append(contentLine);
                            contentLine = in.readLine();
                        }

                        n.content = contents;

                        m_noteHash.insert(id, n);
                        m_childNotes[n.parent].append(id);
                        id++;

                        if (m_lastNoteAtLevel.size() == depth) {
                            m_lastNoteAtLevel.append(n);
                        } else {
                            m_lastNoteAtLevel[depth] = n;
                        }

                        if (depth == 0) {
                            m_notes.append(n);
                        }
                    }
                    break; // If found first header, don't check for second one.
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            const QModelIndex idx = previousNextEntity(m_collectionView, -1);
            m_collectionView->selectionModel()->select(idx, QItemSelectionModel::SelectCurrent);
            m_collectionView->expand(idx);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : rows) {
            model()->setData(idx, myColor, Qt::BackgroundRole);
        }
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *bookmarks = new KJotsBookmarks(m_treeview->selectionModel(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->richTextActionList)) {
        action->setEnabled(enable);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (url.isValid()) {
                QString html = QString::fromLatin1("<a href='%1'>%2</a> ")
                               .arg(QString::fromUtf8(url.toEncoded()))
                               .arg(url.toString(QUrl::RemovePassword));
                insertHtml(html);
            }
        }
```

#### AUTO 


```{c}
auto item = d->index.data(EntityTreeModel::ItemRole).value<Item>();
```

#### AUTO 


```{c}
auto *exportMenu = actionCollection->add<KActionMenu>(QStringLiteral("save_to"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->editorActionList)) {
        action->setEnabled(enable);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action){
            setViewMode(action->data().toInt());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->slotChangeNoteColor(); }
```

#### AUTO 


```{c}
auto document = new QTextDocument();
```

#### AUTO 


```{c}
const auto item = idx.data(EntityTreeModel::ItemRole).value<Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
           d->slotCreateNote();
        }
```

#### AUTO 


```{c}
auto *bmm = new KBookmarkMenu(
        KBookmarkManager::managerForFile(
            QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + QStringLiteral("/kjots/bookmarks.xml"),
            QStringLiteral("kjots")),
        bookmarks, bookmarkMenu->menu());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(bookActions)) {
                action->setEnabled(true);
            }
```

#### AUTO 


```{c}
auto miscPage = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : qAsConst(widgets)) {
        if (w->objectName().isEmpty()) {
            continue;
        }
        PROCESS_TYPE(QSplitter);
        PROCESS_TYPE(QTabWidget);
        PROCESS_TYPE(QTreeView);
        PROCESS_TYPE(QComboBox);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &_item : qAsConst(m_items)) {
        Akonadi::Item item = _item;
        if (m_type == LockJob) {
            item.addAttribute(new NoteShared::NoteLockAttribute());
        } else {
            item.removeAttribute<NoteShared::NoteLockAttribute>();
        }

        new Akonadi::ItemModifyJob(item, this);
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemCreateJob(newItem, Collection(m_containerCollectionId), this);
```

#### AUTO 


```{c}
auto *document = new QTextDocument();
```

#### AUTO 


```{c}
auto message = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto item = m_index->data(EntityTreeModel::ItemRole).value<Item>();
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(KJotsModel::updateItem(idx, editor->document()));
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->slotPinUnpinNote(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(multiselectionActions)) {
            action->setEnabled(true);
        }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            EntityTreeView *activeView;
            if (m_collectionView->hasFocus()) {
                activeView = m_collectionView;
            } else {
                activeView = m_itemView;
            }

            const QModelIndexList rows = activeView->selectionModel()->selectedRows();
            if (rows.size() != 1) {
                return;
            }
            activeView->edit(rows.first());
        }
```

#### AUTO 


```{c}
auto* dialog = new KConfigDialog(this, QStringLiteral("kjotssettings"), KJotsSettings::self());
```

#### AUTO 


```{c}
const auto col = Collection::fromUrl(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : ids) {
            QDomElement e = addNote(m_noteHash.value(id));
            newElement.appendChild(e);
        }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout(searchDialog->findExtension());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selection) {
        const QPersistentModelIndex persistent(index);
        m_sortProxyModel->sortChildrenAlphabetically(m_orderProxy->mapToSource(index));
        m_orderProxy->clearOrder(persistent);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            m_itemView->selectionModel()->select(previousNextEntity(m_itemView, -1), QItemSelectionModel::SelectCurrent | QItemSelectionModel::Rows);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(multiselectionActions)) {
            action->setEnabled(false);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotLockUnlock(false);
        }
```

#### AUTO 


```{c}
auto *document = m_index.data(KJotsModel::DocumentRole).value<QTextDocument *>();
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(KJotsModel::updateItem(idx.data(EntityTreeModel::ItemRole).value<Item>(), m_editor->document()));
```

#### AUTO 


```{c}
auto *monitor = new ChangeRecorder(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            if (m_editorWidget->isVisible()) {
                m_editorWidget->slotReplace();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &_col : qAsConst(m_collections)) {
        Akonadi::Collection col = _col;
        if (m_type == LockJob) {
            col.addAttribute(new NoteShared::NoteLockAttribute());
        } else {
            col.removeAttribute<NoteShared::NoteLockAttribute>();
        }
        new Akonadi::CollectionModifyJob(col, this);
    }
```

#### AUTO 


```{c}
auto document = m_index->data(KJotsModel::DocumentRole).value<QTextDocument *>();
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto *obj = new KJotsEntity(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(bookActions)) {
                action->setEnabled(false);
            }
```

#### AUTO 


```{c}
auto obj = new KJotsEntity(childIndex);
```

#### AUTO 


```{c}
auto itemJob = new Akonadi::ItemCreateJob(item,  collectionCreateJob->collection(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            if (m_editorWidget->isVisible()) {
                m_editorWidget->slotFindNext();
            } else {
                m_browserWidget->slotFindNext();
            }
        }
```

#### AUTO 


```{c}
auto *saver = new ETMViewStateSaver;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KnowItNote &n : qAsConst(m_notes)) {
        QDomElement e = addNote(n);
        parent.appendChild(e);
        qDebug() << n.title;
    }
```

#### AUTO 


```{c}
const auto images = document->property("images").value<KPIMTextEdit::ImageList>();
```

#### AUTO 


```{c}
auto *doc = m_index->data(KJotsModel::DocumentRole).value<QTextDocument *>();
```

#### AUTO 


```{c}
auto *action = new QAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("&Configure KJots..."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url){
        if (!url.toString().startsWith(QLatin1Char('#'))) {
            // QTextBrowser tries to automatically handle the url. We only want it for anchor navigation
            // (i.e. "#page12" links). This can be overridden by setting the source to an invalid QUrl
            setSource(QUrl());
            Q_EMIT linkClicked(url);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<KPIMTextEdit::EmbeddedImage> &img) {
            NoteUtils::Attachment attachment(img->image, QStringLiteral("image/png"));
            attachment.setDataBase64Encoded(true);
            attachment.setContentID(img->contentID);
            return attachment;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selection) {
        const QPersistentModelIndex persistent(index);
        m_sortProxyModel->sortChildrenByCreationTime(m_orderProxy->mapToSource(index));
        m_orderProxy->clearOrder(persistent);
    }
```

#### AUTO 


```{c}
auto *doc = d->index.data(KJotsModel::DocumentRole).value<QTextDocument *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url){
        if (!url.toString().startsWith(QLatin1Char('#'))) {
            // QTextBrowser tries to automatically handle the url. We only want it for anchor navigation
            // (i.e. "#page12" links). This can be overriden by setting the source to an invalid QUrl
            setSource(QUrl());
            Q_EMIT linkClicked(url);
        }
    }
```

#### AUTO 


```{c}
auto *completer = new QCompleter(m_descendantsProxyModel.get(), this);
```

#### AUTO 


```{c}
const auto collection = idx.data(EntityTreeModel::CollectionRole).value<Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            d->slotChangeColor();
        }
```

#### AUTO 


```{c}
const auto item = Item::fromUrl(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attachment : attachments) {
            if (attachment.mimetype() == QStringLiteral("image/png") && !attachment.contentID().isEmpty()) {
                QImage img = QImage::fromData(attachment.data(), "PNG");
                document->addResource(QTextDocument::ImageResource,
                                      QUrl(QStringLiteral("cid:")+attachment.contentID()), img);
            }
        }
```

#### AUTO 


```{c}
auto cursor = doc->property("textCursor").value<QTextCursor>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotLockUnlock(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateActions();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(pageActions)) {
                if (action->objectName() == QLatin1String(name(KStandardAction::Cut))) {
                    action->setEnabled(activeEditor()->textCursor().hasSelection());
                } else {
                    action->setEnabled(true);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, itemJob](KJob*){
                if (itemJob->error()) {
                    qWarning() << "Failed to create a note:" << itemJob->errorString();
                }
                deleteLater();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ d->slotChangeNoteBookColor(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            activeEditor()->copy();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            if (url.scheme() == QStringLiteral("akonadi")) {
                QModelIndex idx = KJotsModel::modelIndexForUrl(d->model, url);
                if (idx.isValid()) {
                    insertHtml(QStringLiteral("<a href=\"%1\">%2</a>").arg(idx.data(KJotsModel::EntityUrlRole).toString(),
                                                                           idx.data().toString()));
                }
            } else {
                QString text = source->hasText() ? source->text() : url.toString(QUrl::RemovePassword);
                insertHtml(QStringLiteral("<a href=\"%1\">%2</a>").arg(QString::fromUtf8(url.toEncoded()), text));
            }
        }
```

#### AUTO 


```{c}
auto collection = idx.data(EntityTreeModel::CollectionRole).value<Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
            const QModelIndexList rows = m_treeview->selectionModel()->selectedRows();
            if (rows.size() != 1) {
                return;
            }
            m_treeview->edit(rows.first());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedRows) {
        bool ok;
        qlonglong id = index.data(EntityTreeModel::ItemIdRole).toLongLong(&ok);
        Q_ASSERT(ok);
        if (id >= 0) {
            new ItemDeleteJob(Item(id), this);
        } else {
            id = index.data(EntityTreeModel::CollectionIdRole).toLongLong(&ok);
            Q_ASSERT(ok);
            if (id >= 0) {
                new CollectionDeleteJob(Collection(id), this);
            }
        }
    }
```

#### AUTO 


```{c}
auto *popup = new QMenu(this);
```

