#### AUTO 


```{c}
auto it=m_actions.begin();
```

#### AUTO 


```{c}
auto list = m_transQueue.values();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::SourceEntry &sEntry : m_sourcesList.entries()) {
        if (!sEntry.isValid())
            continue;

        SourceItem* newSource = sourceForUri(sEntry.uri());
        EntryItem* entry = new EntryItem(sEntry);
        newSource->appendRow(entry);
    }
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arch : archList) {
        QStandardItem *archItem = new QStandardItem;
        archItem->setEditable(false);
        archItem->setText(arch);
        archItem->setData(arch, Qt::UserRole+1);
        appendRow(archItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDeclarativeError &error : m_view->errors()) {
            errors.append(error.toString() + QLatin1String("\n"));
        }
```

#### AUTO 


```{c}
auto it = m_jobHash.constBegin();
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, list);
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_searchResults) {
            if(res == leftPackage)
                return true;
            else if(res == rightPackage)
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListView *view : m_listViews) {
        view->setAlternatingRowColors(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid()) {
            if ((pkg) && !pkgBlacklist.contains(pkg->name())) {
                appList << app;
                added = true;
            }
        }

        if(added)
            app->moveToThread(thread);
        else
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pkgid: m_updatesPackageId) {
        if (PackageKit::Daemon::packageName(pkgid) == name)
            return pkgid;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : backendNames) {
        QString file = KGlobal::dirs()->findResource("data", "libmuon/categories/"+name+"-categories.xml");
        if (file.isEmpty()) {
            qWarning() << "Couldn't find a category for " << name;
            continue;
        }
        QList<Category*> cats = loadCategoriesFile(file);

        if(ret.isEmpty()) {
            ret += cats;
        } else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FilterModel *filterModel : m_filterModels) {
        filterModel->populate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += module->updatesCount();
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : cats)
                Category::addSubcategory(ret, c);
```

#### RANGE FOR STATEMENT 


```{c}
for(const Appstream::Component& component: m_appdata.allComponents()) {
        const QString name = component.packageNames().first();
        m_updatingPackages[name] = new AppPackageKitResource(component, this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
        sm.setRestartHint(QSessionManager::RestartNever);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int requested_sort_magic = (QApt::Package::ToInstall
                                         | QApt::Package::ToRemove
                                         | QApt::Package::ToKeep);
```

#### RANGE FOR STATEMENT 


```{c}
for(const Appstream::Component& component: m_appdata.allComponents()) {
        m_updatingPackages[component.id()] = new AppPackageKitResource(component, this);
        foreach (const QString& pkg, component.packageNames()) {
            m_updatingTranslationPackageToApp[pkg] += component.id();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new MuonNotifier; }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListView *view : m_listViews) {
        selectFirstRow(view);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAction *action : m_actions) {
        action->setEnabled(enabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QQmlError &error : m_view->errors()) {
            errors.append(error.toString() + QLatin1String("\n"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archive : m_package->archives()) {
        if (archive.contains(QLatin1String("security"))) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](PackageKit::Transaction::Error, const QString& msg){ qWarning() << "error fetching details" << msg; }
```

#### AUTO 


```{c}
auto it = m_initial.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : transaction->addons().addonsToInstall()) {
        QApt::Package *addon = m_backend->package(pkgStr);

        if (addon)
            excluded.append(addon);
    }
```

#### AUTO 


```{c}
auto iter = addons.constBegin();
```

#### AUTO 


```{c}
auto it=m_resources.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : addons.addonsToInstall()) {
        QApt::Package *package = m_backend->package(pkgStr);
        package->setInstall();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            m_toUpdate += res;
        }
```

#### AUTO 


```{c}
auto it = data.constBegin(), itEnd=data.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<FilterType, QString> &filter : m_notFilters) {
        if(shouldFilter(res, filter))
            return false;
    }
```

#### AUTO 


```{c}
auto pkgList
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        security |= module->securityUpdatesCount()>0;
        normal |= security || module->updatesCount()>0;
        if (security)
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Transaction *t : list) {
        if (t->transactionId() == active) {
            trans = t;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        resourcesModel->addResourcesBackend(backend);
        backend->integrateMainWindow(this);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](PackageKit::Transaction::Error err, const QString & error) {
        qWarning() << "error fetching updates:" << err << error;
        emit changelogFetched(QString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QStringLiteral("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res) {
                if (res->state() == Application::Upgradeable)
                    m_toUpdate += res;
            } else {
                qWarning() << "Couldn't find the package:" << it->name();
            }
            Q_ASSERT(res);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        resourcesModel->addResourcesBackend(backend);
        backend->integrateMainWindow(this);
        
        if(backend->metaObject()->className()==QLatin1String("ApplicationBackend")) {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()),
                    this, SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadStarted()), //TODO: use ResourcesModel signals
                    this, SLOT(removeProgressItem()));
            connect(m_appBackend, SIGNAL(reloadFinished()),
                    this, SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(startingFirstTransaction()),
                    this, SLOT(addProgressItem()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()),
                    this, SLOT(sourcesEditorFinished()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *subItem : item->children()) {
            QApt::Package *pkg = subItem->retrievePackage();
            if (!pkg)
                continue;

            subItem->setChecked(pkg->state() & QApt::Package::ToInstall);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appList) {
        app->setParent(this);
        pkg = app->package();
        if (pkg->isInstalled())
            m_instOriginList << pkg->origin();
        else
            m_originList << pkg->origin();
    }
```

#### AUTO 


```{c}
auto iter = m_transQueue.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            m_toUpdate += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *item : items) {
        item->setEditable(false);
        appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : transList) {
        addTransaction(trans);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int rating : ratings)
            tot_ratings = rating + tot_ratings;
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid() && pkg)
        {
            appList << app;
            app->moveToThread(thread);
            added = true;
        }

        if(!added)
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application* app : m_appList)
        app->setParent(this);
```

#### AUTO 


```{c}
auto prev = iter;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if(!m_appBackend &&
            backend->metaObject()->className()==QLatin1String("ApplicationBackend"))
        {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(fetchingChanged()), SLOT(aptFetchingChanged()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()), SLOT(sourcesEditorFinished()));
            populateViews();
        }
    }
```

#### AUTO 


```{c}
auto iter = m_transQueue.find(m_currentTransaction);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : m_actions) {
        action->setEnabled(enabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PackageState &addon : m_availableAddons) {
        // Check if we have an application for the addon
        AbstractResource *addonResource = 0;

        for (AbstractResource *resource : m_resource->backend()->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }

        QStandardItem *addonItem = new QStandardItem;
        addonItem->setData(addon.name());
        QString resourceName = QLatin1String(" (") % addon.name() % ')';
        if (addonResource) {
            addonItem->setText(addonResource->name() % resourceName);
            addonItem->setIcon(KIcon(addonResource->icon()));
        } else {
            addonItem->setText(addon.description() % resourceName);
            addonItem->setIcon(KIcon("applications-other"));
        }

        addonItem->setEditable(false);
        addonItem->setCheckable(true);

        if (addon.isInstalled()) {
            addonItem->setCheckState(Qt::Checked);
        } else {
            addonItem->setCheckState(Qt::Unchecked);
        }

        m_addonsModel->appendRow(addonItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        bool locked = setLocked(package, lock);
        if (!locked) {
            // TODO: report error
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * app : apps) {
        m_toUpgrade.removeAll(app);
    }
```

#### AUTO 


```{c}
auto pkr = qobject_cast<PackageKitResource*>(it.value());
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
            item = new QStandardItem;
            item->setText(package->name());
            item->setEditable(false);
            item->setIcon(KIcon("muon"));

            root->appendRow(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appList) {
        pkg = app->package();
        if (pkg->isInstalled()) {
            m_instOriginList << pkg->origin();
        }

        m_originList << pkg->origin();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : addons.addonsToRemove()) {
        QApt::Package *package = m_backend->package(pkgStr);
        package->setRemove();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[chunk]() { return PackageKit::Daemon::getDetails(chunk); }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += module->securityUpdatesCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_toUpgrade) {
        PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
        QString pkgid = m_backend->upgradeablePackageId(app);
        m_packageIds.insert(pkgid);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { updatePlugState(job->isPlugged()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appList) {
        app->setParent(this);
        QApt::Package* pkg = app->package();
        if (pkg->isInstalled())
            m_instOriginList << pkg->origin();
        else
            m_originList << pkg->origin();
    }
```

#### AUTO 


```{c}
auto it = m_updatingPackages.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractSourcesBackend* b: m_sources) {
        for(QAction* action: b->actions())
            ret.append(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pkgid : m_updatesPackageId) {
        const QString pkgname = PackageKit::Daemon::packageName(pkgid);
        ret += resourcesByPackageName(pkgname, false);
        if (ret.isEmpty()) {
            qWarning() << "couldn't find resource for" << pkgid;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->setPackage(package);

        if (tab->shouldShow()) {
            addTab(tab, tab->name());
        } else {
            if (currentIndex() == indexOf(tab)) {
                setCurrentIndex(0);
            }
            removeTab(indexOf(tab));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *resource : m_resource->backend()->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid() && pkg) {
            appList << app;
            app->moveToThread(thread);
            added = true;
        }

        if(!added)
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : subs) {
            Category* ret = recFindCategory(c, name);
            if(ret)
                return ret;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::HistoryItem &item : m_history->historyItems()) {
        QDateTime startDateTime = item.startDate();
        QString formattedTime = KGlobal::locale()->formatTime(startDateTime.time());
        QString category;

        QString date = startDateTime.date().toString();
        if (categoryHash.contains(date)) {
            category = categoryHash.value(date);
        } else {
            category = KGlobal::locale()->formatDate(startDateTime.date(), KLocale::FancyShortDate);
            categoryHash[date] = category;
        }

        QStandardItem *parentItem = 0;

        if (!m_categoryHash.contains(category)) {
            parentItem = new QStandardItem;
            parentItem->setEditable(false);
            parentItem->setText(category);
            parentItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);

            m_historyModel->appendRow(parentItem);
            m_categoryHash[category] = parentItem;
        } else {
            parentItem = m_categoryHash.value(category);
        }

        foreach (const QString &package, item.installedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(InstalledAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToInstall, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.upgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(UpgradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToUpgrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.downgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(DowngradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToDowngrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.removedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(RemovedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToRemove, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.purgedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(PurgedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToPurge, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : m_appsTemp)
    {
        app->clearPackage();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::SourceEntry &sEntry : m_sourcesList.entries()) {
        if (!sEntry.isValid())
            continue;

        Source* newSource = sourceForUri(sEntry.uri());
        Entry* entry = new Entry(this, sEntry);
        newSource->addEntry(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archive : package->archives()) {
            if (archive.contains(QLatin1String("security"))) {
                securityFound = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive)) {
            ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& toRemove : addons.addonsToRemove()) {
        setAddonInstalled(toRemove, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid()) {
            if ((pkg) && !pkgBlacklist.contains(pkg->name())) {
                appList << app;
                app->moveToThread(thread);
                added = true;
            }
        }

        if(!added)
            delete app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res)
                m_toUpdate += res;
            else
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* cat : cats) {
        Category* ret = recFindCategory(cat, name);
        if(ret)
            return ret;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int requested_sort_magic = (QApt::Package::ToInstall
                                         | QApt::Package::ToUpgrade
                                         | QApt::Package::ToRemove
                                         | QApt::Package::ToPurge
                                         | QApt::Package::ToReInstall
                                         | QApt::Package::ToDowngrade
                                         | QApt::Package::ToKeep);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& e : vals.keys()) {
                if(vals[e]>1)
                    ret.append(e);
                else
                    ret.append(i18n("%1 (Binary)", e));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            if(!res)
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
            m_toUpdate += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application* app : m_appList) {
        ret += app;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->state() == AbstractResource::Upgradeable && !res->isTechnical()) {
            ret++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        module->recheckSystemUpdateNeeded();
```

#### RANGE FOR STATEMENT 


```{c}
for (FilterModel *filterModel : m_filterModels) {
        filterModel->clear();
    }
```

#### AUTO 


```{c}
auto i = changes.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &MuonNotifier::updatesChanged);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->refresh();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action: highActions) {
        if(!containsAction(action, qobject_cast<QBoxLayout*>(centralWidget()->layout()))) {
            KActionMessageWidget* w = new KActionMessageWidget(action, centralWidget());
            qobject_cast<QBoxLayout*>(centralWidget()->layout())->insertWidget(1, w);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* {return ResourcesModel::global();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &archive : package->archives()) {
                if (archive.contains(QLatin1String("security"))) {
                    securityFound = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->state() == AbstractResource::Upgradeable) {
            ret+=res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransactionListener *listener : m_transactions) {
        if(listener->resource() == trans->resource()) {
            toRemove = listener;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : backendNames) {
        QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, "libmuon/categories/"+name+"-categories.xml");
        if (file.isEmpty()) {
            qWarning() << "Couldn't find a category for " << name;
            continue;
        }
        QList<Category*> cats = loadCategoriesFile(file);

        if(ret.isEmpty()) {
            ret += cats;
        } else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### AUTO 


```{c}
auto reasonIter = failedReasons.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(KService::Ptr exe : exes) {
        ret += exe->exec();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if(backend->metaObject()->className()==QLatin1String("ApplicationBackend")) {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()),
                    this, SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadFinished()),
                    this, SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()),
                    this, SLOT(sourcesEditorFinished()));
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int status_sort_magic = (QApt::Package::Installed |
                                   QApt::Package::Upgradeable |
                                   QApt::Package::NowBroken |
                                   QApt::Package::New);
```

#### RANGE FOR STATEMENT 


```{c}
for (QStringList &list : m_list) {
        list.removeAll(addon);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "action triggered!"; }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& path : QCoreApplication::instance()->libraryPaths()) {
        QDir dir(path+"/muon-notifier/");
        for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : m_transactions) {
        if (trans->resource() == resource) {
            ret = trans;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& exec : execs) {
        KService::Ptr service = KService::serviceByStorageId(exec);

        QString name = service->property("Name").toString();
        if (!service->genericName().isEmpty())
            name += QLatin1String(" - ") % service->genericName();

        QStandardItem *item = new QStandardItem(name);
        item->setIcon(QIcon::fromTheme(service->icon()));
        item->setData(service->desktopEntryPath(), Qt::UserRole);
        items += item;
    }
```

#### AUTO 


```{c}
auto iter = m_jobHash.constBegin();
```

#### AUTO 


```{c}
auto iter = m_subViewHash.begin();
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, selectedPackages());
```

#### LAMBDA EXPRESSION 


```{c}
[importantAction](){
        importantAction->setEnabled(false);
        qDebug() << "important action triggered";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        resourcesModel->addResourcesBackend(backend);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int status_sort_magic = (QApt::Package::Installed |
                                   QApt::Package::New);
```

#### RANGE FOR STATEMENT 


```{c}
for(Application* a : m_appList) {
            a->setHasScreenshot(packages.contains(a->packageName()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction* action: b->actions())
            ret.append(action);
```

#### AUTO 


```{c}
auto it=changes.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive) || res->comment().contains(searchText, Qt::CaseInsensitive))
            result << res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        int s = (m_state+1) % 4;
        setState(State(s));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        if(!module->isSystemUpToDate())
            return false;
    }
```

#### AUTO 


```{c}
auto filter = m_orFilters.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_packages.values()) {
        if (!res->isTechnical() && res->canUpgrade())
            resources << res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* {return TransactionModel::global();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : backendNames) {
        QList<Category*> cats = loadCategoriesFile(name);

        if(ret.isEmpty()) {
            ret += cats;
        } else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive)) {
            kDebug() << "Got one" << res->name();
            ret += res;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](){ qDebug() << "random action triggered"; }
```

#### RANGE FOR STATEMENT 


```{c}
for (Application *app : tempList) {
        bool added = false;
        QApt::Package *pkg = app->package();
        if (app->isValid()) {
            if ((pkg) && !pkgBlacklist.contains(pkg->name())
                    && !(pkg->state() & uninstallable)) {
                appList << app;
                added = true;
            }
        }

        if(added)
            app->moveToThread(thread);
        else
            delete app;
    }
```

#### AUTO 


```{c}
auto it = m_resources.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pkgid : m_updatesPackageId) {
        ret += m_packages[PackageKit::Daemon::packageName(pkgid)];
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction *trans : resource->backend()->transactions()) {
                if (trans->resource() == resource) {
                    t = trans;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : files) {
        QList<Category*> cats = loadCategoriesFile(file);
        if(ret.isEmpty())
            ret += cats;
        else {
            for(Category* c : cats)
                addSubcategory(ret, c);
        }
    }
```

#### AUTO 


```{c}
auto i = m_jobFilenames.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QStringLiteral("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res) {
                if (res->state() == Application::Upgradeable)
                    m_toUpdate += res;
            } else {
                qWarning() << "Couldn't find the package:" << it->name();
            }
            Q_ASSERT(res);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DetailsTab *tab : m_detailsTabs) {
        tab->setBackend(backend);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Solid::Device device_ac : acAdapters) {
        Solid::AcAdapter* acAdapter = device_ac.as<Solid::AcAdapter>();
        isPlugged |= acAdapter->isPlugged();
        connect(acAdapter, SIGNAL(plugStateChanged(bool,QString)),
                this, SLOT(updatePlugState(bool)), Qt::UniqueConnection);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : list) {
        if(c->name() == newcat->name()) {
            if(c->icon() != newcat->icon()
                || c->shouldShowTechnical() != newcat->shouldShowTechnical()
                || c->m_andFilters != newcat->andFilters())
            {
                qWarning() << "the following categories seem to be the same but they're not entirely"
                    << c->name() << newcat->name();
                break;
            } else {
                c->m_orFilters += newcat->orFilters();
                c->m_notFilters += newcat->notFilters();
                for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
                delete newcat;
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction* t : m_transactions) {
        PKTransaction* pkt = qobject_cast<PKTransaction*>(t);
        if (pkt->resource() == app) {
            if (pkt->transaction()->allowCancel()) {
                pkt->transaction()->cancel();
                int count = m_transactions.removeAll(t);
                Q_ASSERT(count==1);
                Q_UNUSED(count)
                //TransactionModel::global()->cancelTransaction(t);
            } else {
                qWarning() << "trying to cancel a non-cancellable transaction: " << app->name();
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : *i) {
            root->appendRow(new QStandardItem(QIcon::fromTheme("muon"), package->name()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_toUpgrade) {
        PackageKitResource * app = qobject_cast<PackageKitResource*>(res);
        m_packageIds.insert(app->availablePackageId());
        qDebug() << "Upgrade" << app->availablePackageId() << app->installedPackageId();
    }
```

#### AUTO 


```{c}
auto m_window = new KXmlGuiWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        if (m_stop) {
            m_backend->setCompressEvents(false);
            QApplication::restoreOverrideCursor();
            break;
        }

        switch (action) {
        case QApt::Package::ToInstall:
            setInstall(package);
            break;
        case QApt::Package::ToRemove:
            setRemove(package);
            break;
        case QApt::Package::ToUpgrade:
            setUpgrade(package);
            break;
        case QApt::Package::ToReInstall:
            setReInstall(package);
            break;
        case QApt::Package::ToKeep:
            setKeep(package);
            break;
        case QApt::Package::ToPurge:
            setPurge(package);
            break;
        default:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& path : QCoreApplication::instance()->libraryPaths()) {
        QDir dir(path+"/muon-notifier/");
        for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransactionListener *listener : m_transactions) {
        if(listener->resource() == app) {
            toRemove = listener;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->name()==name || res->packageName()==name) {
            ret = res;
            break;
        }
    }
```

#### AUTO 


```{c}
auto changes = m_aptBackend->stateChanges(m_updatesCache, QApt::PackageList());
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->state() == AbstractResource::Upgradeable) {
            ret+=res;
        }
    }
```

#### AUTO 


```{c}
auto filter = m_notFilters.constBegin();
```

#### AUTO 


```{c}
auto changes = m_aptBackend->stateChanges(cache, QApt::PackageList());
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource * res : m_packages.values()) {
        if (!res->isTechnical() && res->canUpgrade())
            count++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : files) {
        QList<Category*> cats = loadCategoriesFile(file);
        if(ret.isEmpty())
            ret += cats;
        else {
            for(Category* c : cats)
                Category::addSubcategory(ret, c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Appstream::Provides p : m_appdata.provides())
        if (p.kind() == Appstream::Provides::KindBinary)
            ret += p.value();
```

#### AUTO 


```{c}
auto it = names.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->state() == AbstractResource::Upgradeable) {
            ret++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& exec : execs) {
        KService::Ptr service = KService::serviceByStorageId(exec);

        QString name = service->property("Name").toString();
        if (!service->genericName().isEmpty())
            name += QLatin1String(" - ") % service->genericName();

        QStandardItem *item = new QStandardItem(name);
        item->setIcon(KIcon(service->icon()));
        item->setData(service->desktopEntryPath(), Qt::UserRole);
        items += item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : list) {
        if(c->name() == newcat->name()) {
            if(c->icon() != newcat->icon()
                || c->shouldShowTechnical() != newcat->shouldShowTechnical()
                || c->m_andFilters != newcat->andFilters())
            {
                kWarning() << "the following categories seem to be the same but they're not entirely"
                    << c->name() << newcat->name();
                break;
            } else {
                c->m_orFilters += newcat->orFilters();
                c->m_notFilters += newcat->notFilters();
                for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
                delete newcat;
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : list) {
        if(c->name() == newcat->name()) {
            if(c->icon() != newcat->icon()
                || c->shouldShowTechnical() != newcat->shouldShowTechnical()
                || c->m_andFilters != newcat->andFilters())
            {
                qWarning() << "the following categories seem to be the same but they're not entirely"
                    << c->name() << newcat->name();
                break;
            } else {
                c->m_orFilters += newcat->orFilters();
                c->m_notFilters += newcat->notFilters();
                c->m_plugins.unite(newcat->m_plugins);
                for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
                delete newcat;
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->name().contains(searchText, Qt::CaseInsensitive)) {
//             kDebug() << "Got one" << res->name();
            ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with 
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
    }
```

#### AUTO 


```{c}
auto iter = transaction->addons().constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages) {
        if(res->name().contains(searchText, Qt::CaseInsensitive))
            ret += res;
    }
```

#### AUTO 


```{c}
auto it = m_categories.begin();
```

#### AUTO 


```{c}
auto filter = m_andFilters.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](bool b){
        if(!b)
            QCoreApplication::instance()->quit();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<FilterType, QString> &filter : m_andFilters) {
        if(!shouldFilter(res, filter))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::HistoryItem &item : m_history->historyItems()) {
        QDateTime startDateTime = item.startDate();
        QString formattedTime = startDateTime.toString();
        QString category;

        QString date = startDateTime.date().toString();
        if (categoryHash.contains(date)) {
            category = categoryHash.value(date);
        } else {
            category = startDateTime.date().toString(Qt::DefaultLocaleShortDate);
            categoryHash[date] = category;
        }

        QStandardItem *parentItem = 0;

        if (!m_categoryHash.contains(category)) {
            parentItem = new QStandardItem;
            parentItem->setEditable(false);
            parentItem->setText(category);
            parentItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);

            m_historyModel->appendRow(parentItem);
            m_categoryHash[category] = parentItem;
        } else {
            parentItem = m_categoryHash.value(category);
        }

        foreach (const QString &package, item.installedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(InstalledAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToInstall, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.upgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(UpgradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToUpgrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.downgradedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(DowngradedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToDowngrade, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.removedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(RemovedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToRemove, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }

        foreach (const QString &package, item.purgedPackages()) {
            QStandardItem *historyItem = new QStandardItem;
            historyItem->setEditable(false);
            historyItem->setIcon(itemIcon);

            QString action = actionHash.value(PurgedAction);
            QString text = i18nc("@item example: muon installed at 16:00", "%1 %2 at %3",
                                 package, action, formattedTime);
            historyItem->setText(text);
            historyItem->setData(startDateTime, HistoryProxyModel::HistoryDateRole);
            historyItem->setData(QApt::Package::ToPurge, HistoryProxyModel::HistoryActionRole);

            parentItem->appendRow(historyItem);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto pkgList : changes.values()) {
        for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));

            if(res)
                m_toUpdate += res;
            else
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PackageState state : m_availableAddons) {
        if (state.name() == addonName) {
            addon = &state;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractBackendUpdater* upd : m_updaters) {
            if (upd->hasUpdates())
                QMetaObject::invokeMethod(upd, "start", Qt::QueuedConnection);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResource *resource : m_backend->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with 
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            Q_ASSERT(res);
            ret += res;
        }
```

#### AUTO 


```{c}
auto iter = m_jobFilenames.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appstream::Image &i : s.images()) {
            if (i.kind() == kind) {
                ret = i.url();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : *i) {
            root->appendRow(new QStandardItem(KIcon("muon"), package->name()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PackageState &addon : m_availableAddons) {
        // Check if we have an application for the addon
        AbstractResource *addonResource = 0;

        for (AbstractResource *resource : m_backend->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }

        QStandardItem *addonItem = new QStandardItem;
        addonItem->setData(addon.name());
        QString resourceName = QLatin1String(" (") % addon.name() % ')';
        if (addonResource) {
            addonItem->setText(addonResource->name() % resourceName);
            addonItem->setIcon(KIcon(addonResource->icon()));
        } else {
            addonItem->setText(addon.description() % resourceName);
            addonItem->setIcon(KIcon("applications-other"));
        }

        addonItem->setEditable(false);
        addonItem->setCheckable(true);

        if (addon.isInstalled()) {
            addonItem->setCheckState(Qt::Checked);
        } else {
            addonItem->setCheckState(Qt::Unchecked);
        }

        m_addonsModel->appendRow(addonItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (UpdateItem *item : m_rootItem->children()) {
        for (UpdateItem *subItem : item->children()) {
            QApt::Package *pkg = subItem->retrievePackage();
            if (!pkg)
                continue;

            subItem->setChecked(pkg->state() & QApt::Package::ToInstall);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<FilterType, QString>& filter : m_orFilters) {
            if(shouldFilter(res, filter)) {
                orValue = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new SystemFonts; }
```

#### AUTO 


```{c}
auto it=sortedResources.constBegin(), itEnd=sortedResources.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : *it) {
                pkgList << package->name();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Transaction* t : m_transactions) {
        PKTransaction* pkt = qobject_cast<PKTransaction*>(t);
        if (pkt->resource() == app) {
            if (pkt->transaction()->allowCancel()) {
                pkt->transaction()->cancel();
                int count = m_transactions.removeAll(t);
                Q_ASSERT(count==1);
                Q_UNUSED(count)
                //TransactionModel::global()->cancelTransaction(t);
            } else {
                kWarning() << "trying to cancel a non-cancellable transaction: " << app->name();
            }
            break;
        }
    }
```

#### AUTO 


```{c}
auto iter = m_transQueue.begin();
```

#### AUTO 


```{c}
auto & elem
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends)
        ret += module->metaObject()->className();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& toInstall : addons.addonsToInstall()) {
        setAddonInstalled(toInstall, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        if(!m_appBackend &&
            backend->metaObject()->className()==QLatin1String("ApplicationBackend"))
        {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()), SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadFinished()), SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()), SLOT(sourcesEditorFinished()));
            populateViews();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* c : cats)
                addSubcategory(ret, c);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractResourcesBackend *backend : backends) {
        backend->integrateMainWindow(this);
        
        if(backend->metaObject()->className()==QLatin1String("ApplicationBackend")) {
            m_appBackend = backend;
            connect(m_appBackend, SIGNAL(backendReady()),
                    this, SLOT(populateViews()));
            connect(m_appBackend, SIGNAL(reloadStarted()), //TODO: use ResourcesModel signals
                    this, SLOT(removeProgressItem()));
            connect(m_appBackend, SIGNAL(reloadFinished()),
                    this, SLOT(showLauncherMessage()));
            connect(m_appBackend, SIGNAL(startingFirstTransaction()),
                    this, SLOT(addProgressItem()));
            connect(m_appBackend, SIGNAL(sourcesEditorFinished()),
                    this, SLOT(sourcesEditorFinished()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        if (!m_backend->setPackagePinned(package, lock)) {
            QString title = i18nc("@title:window", "Failed to Lock Package");
            QString text = i18nc("@info Error text", "The package %1 could not "
                                 "be locked. Failed to write lock file.",
                                 package->name());
            KMessageBox::error(this, text, title);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVector<AbstractResource*>& resources : m_resources)
        ret += resources.size();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selected) {
        packages << m_proxyModel->packageAt(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QApt::Package *package : packages) {
        if (m_stop) {
            m_backend->setCompressEvents(false);
            QApplication::restoreOverrideCursor();
            break;
        }

        switch (action) {
        case QApt::Package::ToInstall:
            setInstall(package);
            break;
        case QApt::Package::ToRemove:
            setRemove(package);
            break;
        case QApt::Package::ToUpgrade:
            setUpgrade(package);
            break;
        case QApt::Package::ToReInstall:
            if (package->isInstalled())
                setReInstall(package);
            break;
        case QApt::Package::ToKeep:
            setKeep(package);
            break;
        case QApt::Package::ToPurge:
            setPurge(package);
            break;
        default:
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(AbstractResource* res : m_packages.values()) {
        if (res->state() == AbstractResource::Upgradeable) {
            ret++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TransactionListener *listener : m_transactions) {
        if(listener->application() == app) {
            toRemove = listener;
            break;
        }
    }
```

#### AUTO 


```{c}
auto roles = roleNames();
```

#### RANGE FOR STATEMENT 


```{c}
for(BackendNotifierModule* module : m_backends) {
        connect(module, &BackendNotifierModule::foundUpdates, this, &MuonNotifier::updateStatusNotifier);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](UpdateItem *a, UpdateItem *b) { return a->name() < b->name(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pkgStr : transaction->addons().addonsToRemove()) {
        QApt::Package *addon = m_backend->package(pkgStr);

        if (addon)
            excluded.append(addon);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appstream::Screenshot &s : comp.screenshots()) {
        for (const Appstream::Image &i : s.images()) {
            if (i.kind() == kind) {
                ret = i.url();
            }
        }
        if (s.isDefault() && !ret.isEmpty())
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            loader.load();
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PackageState &addon : m_availableAddons) {
        // Check if we have an application for the addon
        AbstractResource *addonResource = 0;

        for (AbstractResource *resource : m_resource->backend()->allResources()) {
            if (!resource)
                continue;

            if (resource->packageName() == addon.name()) {
                addonResource = resource;
                break;
            }
        }

        QStandardItem *addonItem = new QStandardItem;
        addonItem->setData(addon.name());
        QString resourceName = QLatin1String(" (") % addon.name() % ')';
        if (addonResource) {
            addonItem->setText(addonResource->name() % resourceName);
            addonItem->setIcon(QIcon::fromTheme(addonResource->icon()));
        } else {
            addonItem->setText(addon.description() % resourceName);
            addonItem->setIcon(QIcon::fromTheme("applications-other"));
        }

        addonItem->setEditable(false);
        addonItem->setCheckable(true);

        if (addon.isInstalled()) {
            addonItem->setCheckState(Qt::Checked);
        } else {
            addonItem->setCheckState(Qt::Unchecked);
        }

        m_addonsModel->appendRow(addonItem);
    }
```

#### AUTO 


```{c}
auto packageIter = failReason.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(QApt::Package* it : pkgList) {
            AbstractResource* res = m_appBackend->resourceByPackageName(it->name());
            if(!res) //If we couldn't find it by its name, try with
                res = m_appBackend->resourceByPackageName(QString("%1:%2").arg(it->name()).arg(it->architecture()));
            if(!res)
                qWarning() << "Couldn't find the package:" << it->name();
            Q_ASSERT(res);
            m_toUpdate += res;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDeclarativeError &error : m_view->errors()) {
            errors.append(error.toString() + QLatin1String("\n\n"));
        }
```

#### AUTO 


```{c}
auto iter = changes.constBegin();
```

#### AUTO 


```{c}
auto changes = m_backend->stateChanges(m_oldCacheState, upgradeable);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arch : archList) {
        QStandardItem *archItem = new QStandardItem;
        archItem->setEditable(false);
        archItem->setText(MuonStrings::global()->archString(arch));
        archItem->setData(arch, Qt::UserRole+1);
        appendRow(archItem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& file : dir.entryList(QDir::Files)) {
            QString fullPath = dir.absoluteFilePath(file);
            QPluginLoader loader(fullPath);
            ret += qobject_cast<BackendNotifierModule*>(loader.instance());
            if (ret.last() == nullptr) {
                qWarning() << "couldn't load" << fullPath << "because" << loader.errorString();
                ret.removeLast();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Appstream::Provides p : m_appdata.provides())
        if (p.kind() == kind)
            ret += p.value();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto & elem : m_addons) {
        if(elem.name() == addon) {
            elem.setInstalled(installed);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& pkgid : m_updatesPackageId) {
        ret += m_packages[PackageKit::Daemon::packageName(pkgid)];
        if (!ret.last()) {
            qWarning() << "couldn't find resource for" << pkgid;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Category* nc : newcat->subCategories())
                    addSubcategory(c->m_subCategories, nc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QApt::MarkingErrorInfo &reason : failedReasons)
        dialogText += digestReason(package, reason);
```

