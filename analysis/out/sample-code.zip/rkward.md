#### AUTO 


```{c}
const auto kac
```

#### AUTO 


```{c}
auto source_packages_box = source_packages.makeCheckbox(i18n ("Build packages from source"), this);
```

#### AUTO 


```{c}
auto keepsource_input = options_keepsource.makeDropDown(RKConfigBase::LabelList({{1, i18n("TRUE (default)")}, {0, i18n("FALSE")}}), this);
```

#### AUTO 


```{c}
auto oldiface = RInterface::instance();
```

#### LAMBDA EXPRESSION 


```{c}
[=] () { follow_working_directory = true; syncToWD(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { button(QDialogButtonBox::Apply)->setEnabled(false); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto kate_ac : qAsConst(kate_acs)) {
					const auto kate_actions = kate_ac->actions();
					for (auto kate_action : kate_actions) {
						auto action_shortcuts = kate_ac->defaultShortcuts(kate_action);
						for (int pos = 0; pos < action_shortcuts.size(); ++pos) {
							const auto &kate_sc = action_shortcuts[pos];
							if (own_sc.matches(kate_sc) != QKeySequence::NoMatch || kate_sc.matches(own_sc) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kate_sc.toString()), qPrintable(kate_action->objectName()), qPrintable(own_action->objectName()));
								action_shortcuts.removeAt(pos);
								kate_ac->setDefaultShortcuts(kate_action, action_shortcuts);
								break;
							}
						}
					}
				}
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.get().removeAll(legacy_libloc);
									QString new_loc = legacy_libloc + '-' + RKSessionVars::RVersion (true);
									RInterface::issueCommand (QString ("file.rename(%1, %2)\n").arg(RObject::rQuote(legacy_libloc), RObject::rQuote (new_loc)), RCommand::App);
									liblocs.get().prepend (legacy_libloc + QStringLiteral ("-%v"));
									RInterface::issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### AUTO 


```{c}
auto blayout = qobject_cast<QVBoxLayout*> (layout());
```

#### AUTO 


```{c}
const auto ac
```

#### AUTO 


```{c}
auto val = all_maps[ordered_ids[i]];
```

#### AUTO 


```{c}
auto own_actions = part->actionCollection()->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { slotOpenCommandEditor(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		QString message = i18n("<p>This feature is primarily targetted at advanced users working on scripts or packages. Please proceed with caution.</p><p><b>All unsaved data in this workspace will be lost!</b> All data editors, and graphics windows will be closed.</p><p>Are you sure you want to proceed?</p>");
		if (suppressModalDialogsForTesting() || (KMessageBox::warningContinueCancel(this, message, i18n("Restart R backend"), KGuiItem(i18n("Restart R backend"))) == KMessageBox::Continue)) {
			bool forced = RInterface::instance()->backendIsDead();
			while (!RInterface::instance()->backendIsDead() && !RInterface::instance()->backendIsIdle()) {
				message = i18n("<p>One or more operations are pending.</p><p>If you have recently chosen to save your workspace, and you see this message, <b>your data may not be saved, yet!</b></p><p>How do you want to proceed?</p>");
				auto res = KMessageBox::warningYesNoCancel(this, message, i18n("R commands still pending"), KGuiItem(i18n("Force restart now")), KGuiItem(i18n("Check again")), KGuiItem(i18n("Cancel restarting")));
				if (res == KMessageBox::Yes) {
					forced = true;
					break;
				} else if (res == KMessageBox::Cancel) {
					return;
				}
				// KMessageBox::No means to loop: Commands may have finished, meanwhile. This is not really pretty, a proper progress control would be nicer,
				// but then, this is a corner case to a feature that is not really targetted at a mainstream audience, anyway.
			}

			RKWorkplace::mainWorkplace()->closeAll(RKMDIWindow::X11Window);
			slotCloseAllEditors();
			auto restart_now = [this]() {
				delete RInterface::instance();  // NOTE: Do not use deleteLater(), here. It is important to fully tear down the old backend, before creating the new one,
				                                //       as code is written around the assumption that RInterface and friends are singletons. (RInterface::instance(), etc.)
				RKWorkplace::mainWorkplace()->setWorkspaceURL(QUrl());
				startR();
			};
			if (forced) {
				RKConsole::mainConsole()->resetConsole();
				restart_now();
			} else {
				RCommand *c = new RCommand(QString(), RCommand::QuitCommand);
				c->whenFinished(this, [this, restart_now]() { QTimer::singleShot(0, this, restart_now); });
				RInterface::issueCommand(c);
			}
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			QVERIFY(command->failed());
			QVERIFY(command->errorSyntax());
		}
```

#### AUTO 


```{c}
const auto own_actions = ac->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[confint](bool val) { confint->setConfigValue("dynamic-word-wrap", val); }
```

#### LAMBDA EXPRESSION 


```{c}
[](RKSetupWizard*) { RKSettingsModulePlugins::registerDefaultPluginMaps(RKSettingsModulePlugins::AutoActivate); }
```

#### AUTO 


```{c}
auto changes = RKRShadowEnvironment::diffAndUpdate(R_GlobalEnv);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { plugin_resources.remove(plugin); }
```

#### AUTO 


```{c}
auto v = package_repositories.get();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool val) { value=val; }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { RKSettings::configureSettings(RKSettings::PageR); }
```

#### AUTO 


```{c}
auto chain2 = RInterface::startChain(chain);
```

#### LAMBDA EXPRESSION 


```{c}
[this, scroll_pos, connection](){
			QObject::disconnect(*connection);
			delete connection;
			page->setScrollPosition (scroll_pos);
		}
```

#### AUTO 


```{c}
auto firstpageref = addPage (firstpage, i18n("RKWard Setup Assistant"));
```

#### LAMBDA EXPRESSION 


```{c}
[](bool){}
```

#### AUTO 


```{c}
auto modified_outputs = RKOutputDirectory::modifiedOutputDirectories();
```

#### AUTO 


```{c}
auto ret = save(save_filename);
```

#### AUTO 


```{c}
auto completion_object_qualification_box = settings->completion_options.makeDropDown(RKConfigBase::LabelList(
			{{RObject::IncludeEnvirIfMasked, i18n("For masked objects, only")}, {RObject::IncludeEnvirIfNotGlobalEnv, i18n("For objects outside of <i>.GlobalEnv</i>, only")}, {RObject::IncludeEnvirIfNotGlobalEnv | RObject::IncludeEnvirForGlobalEnv, i18n("Always")}}
		), this, RObject::IncludeEnvirIfNotGlobalEnv | RObject::IncludeEnvirForGlobalEnv | RObject::IncludeEnvirIfMasked);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { preview_timer.start (500); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *) {
		emit loadUnloadDone();
	}
```

#### AUTO 


```{c}
auto &handle = plugin_maps.all_maps[id];
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand* command) {
		if (command->failed()) {
			KMessageBox::error(0, i18n("There has been an error opening file '%1':\n%2", RKWorkplace::mainWorkplace()->workspaceURL().path(), command->warnings() + command->error()), i18n("Error loading workspace"));
			RKWorkplace::mainWorkplace()->setWorkspaceURL(QUrl());
		} else {
			RKWorkplace::mainWorkplace ()->restoreWorkplace (0, _merge);
			if (RKSettingsModuleGeneral::cdToWorkspaceOnLoad ()) {
				if (RKWorkplace::mainWorkplace ()->workspaceURL ().isLocalFile ()) {
					RInterface::issueCommand ("setwd (" + RObject::rQuote (RKWorkplace::mainWorkplace ()->workspaceURL ().adjusted (QUrl::RemoveFilename).path ()) + ')', RCommand::App);
				}
			}
		}

		RInterface::whenAllFinished(this, [this]() {
			RKWardMainWindow::getMain()->slotSetStatusReady();
			RKWardMainWindow::getMain()->setWorkspaceMightBeModified(false);
			RKOutputDirectory::getCurrentOutput();  // make sure some output file exists

			deleteLater();
		});
		RKWardMainWindow::getMain ()->setCaption (QString ());	// trigger update of caption
	}
```

#### AUTO 


```{c}
auto item = new RKSetupWizardItem(i18n("Unversioned library location"), i18n("The configured library locations (where R packages will be installed on this system) contains the directory '%1', "
			                                  "which was suggested as a default library location in earlier versions of RKWard. Use of this directory is no longer "
			                                  "recommended, as it is not accessible to R sessions outside of RKWard (unless configured, explicitly). Also due to the lack "
			                                  "of an R version number in the directory name, it offers no protection against using packages built for an incompatible "
			                                  "version of R.", legacy_libloc), RKSetupWizardItem::Warning);
```

#### AUTO 


```{c}
const auto kate_ac
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto k : ac->defaultShortcuts(a)) {
				for (const auto kac : kate_acs) {
					for (auto ka : kac->actions()) {
						auto action_shortcuts = kac->defaultShortcuts(ka);
						for (const auto kk : action_shortcuts) {
							if (k.matches(kk) != QKeySequence::NoMatch || kk.matches(k) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kk.toString()), qPrintable(ka->objectName()), qPrintable(a->objectName()));
								action_shortcuts.removeAll(k);
								kac->setDefaultShortcuts(ka, action_shortcuts);
								break;
							}
						}
					}
				}
			}
```

#### AUTO 


```{c}
auto command = new RCommand(".rk.get.installed.packages()", RCommand::App | RCommand::Sync | RCommand::GetStructuredData);
```

#### AUTO 


```{c}
auto it = known_plugins.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		QString message = startup_errors;
		if (startup_phase2_error) message.append (i18n ("<p>\t-An unspecified error occurred that is not yet handled by RKWard. Likely RKWard will not function properly. Please check your setup.</p>\n"));
		if (!message.isEmpty ()) {
			message.prepend (i18n ("<p>There was a problem starting the R backend. The following error(s) occurred:</p>\n"));

			QString details = command->fullOutput().replace('<', "&lt;").replace('\n', "<br>");
			if (!details.isEmpty ()) {
				// WORKAROUND for stupid KMessageBox behavior. (kdelibs 4.2.3)
				// If length of details <= 512, it tries to show the details as a QLabel.
				details = details.leftJustified (513);
			}
			KMessageBox::detailedError (0, message, details, i18n ("Error starting R"), KMessageBox::Notify | KMessageBox::AllowLink);
		}

		startup_errors.clear ();
	}
```

#### AUTO 


```{c}
auto pluginmaps = new RKSetupWizardItem(i18n("RKWard plugins"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, plugin]() { plugin_resources.remove(plugin); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &own_sc : own_scs) {
				for (const auto kate_ac : qAsConst(kate_acs)) {
					const auto kate_actions = kate_ac->actions();
					for (auto kate_action : kate_actions) {
						auto action_shortcuts = kate_ac->defaultShortcuts(kate_action);
						for (int pos = 0; pos < action_shortcuts.size(); ++pos) {
							const auto &kate_sc = action_shortcuts[pos];
							if (own_sc.matches(kate_sc) != QKeySequence::NoMatch || kate_sc.matches(own_sc) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kate_sc.toString()), qPrintable(kate_action->objectName()), qPrintable(own_action->objectName()));
								action_shortcuts.removeAt(pos);
								kate_ac->setDefaultShortcuts(kate_action, action_shortcuts);
								break;
							}
						}
					}
				}
			}
```

#### AUTO 


```{c}
auto realbar = RKWorkplace::mainWorkplace()->statusBar();
```

#### AUTO 


```{c}
const auto own_action
```

#### AUTO 


```{c}
auto out = getOutputById(params.value(2));
```

#### AUTO 


```{c}
auto warn_input = options_warn.makeDropDown(RKConfigBase::LabelList(
		{{-1, i18n("Suppress warnings")}, {0, i18n("Print warnings later (default)")}, {1, i18n("Print warnings immediately")}, {2, i18n ("Convert warnings to errors")}}
	), this);
```

#### AUTO 


```{c}
auto action_shortcuts = kac->defaultShortcuts(ka);
```

#### AUTO 


```{c}
auto save_chain = RKGlobals::rInterface()->startChain(0);
```

#### AUTO 


```{c}
auto win = openOutputWindow(url, false);
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *c) {
			if (c->failed()) {
				QString msg = c->fullOutput();
				if (msg.isEmpty()) msg = i18n("Command failed to parse. Try using <i>Edit->Paste special...</i> in the R Console window for better diagnostics.");
				KMessageBox::detailedError(RKWardMainWindow::getMain(), i18n("Pasting object from clipboard data failed."), msg, i18n("Paste failed"));
			}
		}
```

#### AUTO 


```{c}
auto res = outputs.constBegin().value()->purge(Force);
```

#### AUTO 


```{c}
auto verb = RKParsedVersion(candidates[i]->getAboutData ().version);
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.get().removeAll(legacy_libloc);
									RInterface::issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### LAMBDA EXPRESSION 


```{c}
[&priority_command_done](RCommand *) {
			priority_command_done = true;
			RInterface::instance()->cancelAll();
		}
```

#### AUTO 


```{c}
const auto &handle = plugin_maps.all_maps.value(id);
```

#### LAMBDA EXPRESSION 


```{c}
[](RKSetupWizard* wizard) { wizard->markExternalPackageForInstallation(QStringLiteral("kate"), false); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
				delete RInterface::instance();  // NOTE: Do not use deleteLater(), here. It is important to fully tear down the old backend, before creating the new one,
				                                //       as code is written around the assumption that RInterface and friends are singletons. (RInterface::instance(), etc.)
				RKWorkplace::mainWorkplace()->setWorkspaceURL(QUrl());
				startR();
			}
```

#### AUTO 


```{c}
auto bottom_box = new QHBoxLayout();
```

#### AUTO 


```{c}
auto pipe_user_commands_through_console_box = pipe_user_commands_through_console.makeCheckbox(i18n("Run commands from script editor through console"), this);
```

#### AUTO 


```{c}
const auto own_scs = ac->defaultShortcuts(own_action);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setStatusMessage (shortStatusLabel ()); }
```

#### AUTO 


```{c}
auto ka
```

#### AUTO 


```{c}
auto action_shortcuts = kate_ac->defaultShortcuts(kate_action);
```

#### AUTO 


```{c}
auto tabkey_invokes_completion_box = settings->tabkey_invokes_completion.makeCheckbox(QString(), this);
```

#### AUTO 


```{c}
auto about = xml.getChildElement(de, "about", DL_WARNING);
```

#### AUTO 


```{c}
auto res = KEncodingFileDialog::getOpenUrlsAndEncoding(QString(), RKRecentUrls::mostRecentUrl(RKRecentUrls::scriptsId()).adjusted(QUrl::RemoveFilename), QString("%1|R Script Files (%1)\n*|All Files (*)").arg(RKSettingsModuleCommandEditor::scriptFileFilter()), this, i18n("Open script file(s)"));
```

#### LAMBDA EXPRESSION 


```{c}
[](RKSetupWizard*) { RKSettingsModulePlugins::registerDefaultPluginMaps(RKSettingsModulePlugins::AddIfDefault); }
```

#### AUTO 


```{c}
auto auto_completion_timeout_box = settings->auto_completion_timeout.makeSpinBox(0, INT_MAX, this);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto delegate = new InstallPackagesDelegate(packages_view);
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand* command) {
		if (command->failed ()) {
			RK_DEBUG (OBJECTS, DL_INFO, "command failed while trying to update object '%s'. No longer present?", getShortName ().toLatin1 ().data ());
			// this may happen, if the object has been removed in the workspace in between
			RKModificationTracker::instance()->removeObject (this, 0, true);
			return;
		}
		if (parent && parent->isContainer()) {
			static_cast<RContainerObject*>(parent)->updateChildStructure(this, command);		// this may result in a delete, so nothing after this!
		} else {
			updateStructure(command);		// no (container) parent can happen for RObjectList and pseudo objects
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool found) { if (!found) this->findbar->indicateSearchFail(); }
```

#### AUTO 


```{c}
const auto &own_sc
```

#### AUTO 


```{c}
auto w = new KMessageWidget(i18n("RKWard comes with several import dialogs, but none seem to be loaded, at present. Check your settings."));
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.get().removeAll(legacy_libloc);
									QString new_loc = legacy_libloc + '-' + RKSessionVars::RVersion (true);
									RKGlobals::rInterface ()->issueCommand (QString ("file.rename(%1, %2)\n").arg (RObject::rQuote (legacy_libloc)).arg (RObject::rQuote (new_loc)), RCommand::App);
									liblocs.get().prepend (legacy_libloc + QStringLiteral ("-%v"));
									RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### AUTO 


```{c}
auto ret = RKRBackend::this_pointer->handleRequestWithSubcommands(list);
```

#### AUTO 


```{c}
auto wizard = new RKSetupWizard(RKWardMainWindow::getMain());
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, which]() { dialog->done (which); }
```

#### AUTO 


```{c}
auto *a = new RKSearchOnlineHelpAction (window, context_provider);
```

#### LAMBDA EXPRESSION 


```{c}
[initial_dir_chooser, this]() { this->initial_dir_custom_chooser->setEnabled(initial_dir_chooser->currentData()==CustomDirectory); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto own_action : own_actions) {
			const auto own_scs = ac->defaultShortcuts(own_action);
			for (const auto &own_sc : own_scs) {
				for (const auto kate_ac : qAsConst(kate_acs)) {
					const auto kate_actions = kate_ac->actions();
					for (auto kate_action : kate_actions) {
						auto action_shortcuts = kate_ac->defaultShortcuts(kate_action);
						for (int pos = 0; pos < action_shortcuts.size(); ++pos) {
							const auto &kate_sc = action_shortcuts[pos];
							if (own_sc.matches(kate_sc) != QKeySequence::NoMatch || kate_sc.matches(own_sc) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kate_sc.toString()), qPrintable(kate_action->objectName()), qPrintable(own_action->objectName()));
								action_shortcuts.removeAt(pos);
								kate_ac->setDefaultShortcuts(kate_action, action_shortcuts);
								break;
							}
						}
					}
				}
			}
		}
```

#### AUTO 


```{c}
auto it = modules.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		setText(command->fullOutput());
		update_button->setEnabled (_object != 0);
	}
```

#### AUTO 


```{c}
auto *globalenv = object_list->globalenv;
```

#### LAMBDA EXPRESSION 


```{c}
[ret, connection]() {
			QObject::disconnect(*connection);
			delete connection;
			ret->acceptNavigationRequest (ret->url (), QWebEnginePage::NavigationTypeLinkClicked, true);
		}
```

#### AUTO 


```{c}
auto ret = QAbstractProxyModel::flags(index).setFlag(Qt::ItemNeverHasChildren, false);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(wrapper);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateSavedHash(); }
```

#### AUTO 


```{c}
auto out = findOutputById(id);
```

#### AUTO 


```{c}
auto settingsbox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto screen = QGuiApplication::primaryScreen();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateFromR(0); }
```

#### AUTO 


```{c}
auto w = list[0];
```

#### AUTO 


```{c}
auto cg = config();
```

#### AUTO 


```{c}
const auto kate_actions = kate_ac->actions();
```

#### AUTO 


```{c}
auto ret = action(id);
```

#### AUTO 


```{c}
auto it = package_repositories.get().constBegin ();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &url) { RKWorkplace::mainWorkplace()->openAnyUrl(QUrl(url)); }
```

#### AUTO 


```{c}
auto ret = save();
```

#### AUTO 


```{c}
const auto keys = known_plugins.keys();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		emit installedPackagesChanged();
	}
```

#### AUTO 


```{c}
auto output = f.readAll();
```

#### AUTO 


```{c}
auto &c = contexts.last();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		RK_TRACE(APP);
		QTimer::singleShot(0, this, &RKQuitAgent::doQuitNow);
	}
```

#### AUTO 


```{c}
const auto k
```

#### AUTO 


```{c}
auto obj = globalenv->findChildByIndex(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto ac : own_acs) {
		const auto own_actions = ac->actions();
		for (const auto own_action : own_actions) {
			const auto own_scs = ac->defaultShortcuts(own_action);
			for (const auto &own_sc : own_scs) {
				for (const auto kate_ac : qAsConst(kate_acs)) {
					const auto kate_actions = kate_ac->actions();
					for (auto kate_action : kate_actions) {
						auto action_shortcuts = kate_ac->defaultShortcuts(kate_action);
						for (int pos = 0; pos < action_shortcuts.size(); ++pos) {
							const auto &kate_sc = action_shortcuts[pos];
							if (own_sc.matches(kate_sc) != QKeySequence::NoMatch || kate_sc.matches(own_sc) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kate_sc.toString()), qPrintable(kate_action->objectName()), qPrintable(own_action->objectName()));
								action_shortcuts.removeAt(pos);
								kate_ac->setDefaultShortcuts(kate_action, action_shortcuts);
								break;
							}
						}
					}
				}
			}
		}
	}
```

#### AUTO 


```{c}
auto act = new KRecentFilesAction(nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWebEngineDownloadItem* item) {
		QString defpath;
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
		defpath = QDir(item->downloadDirectory()).absoluteFilePath(item->downloadFileName());
#else
		defpath = item->path();
#endif
		QString path = QFileDialog::getSaveFileName(this, i18n("Save as"), defpath);
		if (path.isEmpty()) return;
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
		QFileInfo fi(path);
		item->setDownloadDirectory(fi.absolutePath());
		item->setDownloadFileName(fi.fileName());
#else
		item->setPath(path);
#endif
		item->accept();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		if (command->failed()) return;
		RK_ASSERT (command->getDataType () == RData::StringVector);
		QStringList data = command->stringVector ();
		for (int i=0; i < data.size (); ++i) {
			QTreeWidgetItem* item = new QTreeWidgetItem (loaded_view);
			item->setText (0, data.at (i));
			if (RKSettingsModuleRPackages::essentialPackages ().contains (data.at (i))) {
				item->setFlags (Qt::NoItemFlags);
			}
		}
		loaded_view->resizeColumnToContents (0);
		loaded_view->setSortingEnabled (true);
		loaded_view->sortItems (0, Qt::AscendingOrder);
		updateCurrentList ();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand*) {
		RK_ASSERT (update_chain);
		RInterface::closeChain (update_chain);
		update_chain = 0;

		RK_DEBUG (OBJECTS, DL_DEBUG, "object list update complete");
		emit updateComplete();
	}
```

#### AUTO 


```{c}
auto priority_command = new RCommand("cat(\"something\\n\")", RCommand::PriorityCommand | RCommand::App);
```

#### AUTO 


```{c}
auto wizard = new RKSetupWizard(RKWardMainWindow::getMain(), reason, settings_items);
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18n("Startup behavior"));
```

#### AUTO 


```{c}
auto p = qobject_cast<RKComponent*>(parentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		QString message = i18n("<p>This feature is primarily targetted at advanced users working on scripts or packages. Please proceed with caution.</p><p><b>All unsaved data in this workspace will be lost!</b> All data editors, and graphics windows will be closed.</p><p>Are you sure you want to proceed?</p>");
		if (KMessageBox::warningContinueCancel(this, message, i18n("Restart R backend"), KGuiItem(i18n("Restart R backend"))) == KMessageBox::Continue) {
			bool forced = RInterface::instance()->backendIsDead();
			while (!RInterface::instance()->backendIsDead() && !RInterface::instance()->backendIsIdle()) {
				message = i18n("<p>One or more operations are pending.</p><p>If you have recently chosen to save your workspace, and you see this message, <b>your data may not be saved, yet!</b></p><p>How do you want to proceed?</p>");
				auto res = KMessageBox::warningYesNoCancel(this, message, i18n("R commands still pending"), KGuiItem(i18n("Force restart now")), KGuiItem(i18n("Check again")), KGuiItem(i18n("Cancel restarting")));
				if (res == KMessageBox::Yes) {
					forced = true;
					break;
				} else if (res == KMessageBox::Cancel) {
					return;
				}
				// KMessageBox::No means to loop: Commands may have finished, meanwhile. This is not really pretty, a proper progress control would be nicer,
				// but then, this is a corner case to a feature that is not really targetted at a mainstream audience, anyway.
			}

			RKWorkplace::mainWorkplace()->closeAll(RKMDIWindow::X11Window);
			slotCloseAllEditors();
			auto restart_now = [this]() {
				delete RInterface::instance();  // NOTE: Do not use deleteLater(), here. It is important to fully tear down the old backend, before creating the new one,
				                                //       as code is written around the assumption that RInterface and friends are singletons. (RInterface::instance(), etc.)
				RKWorkplace::mainWorkplace()->setWorkspaceURL(QUrl());
				startR();
			};
			if (forced) {
				RKConsole::mainConsole()->resetConsole();
				restart_now();
			} else {
				RCommand *c = new RCommand(QString(), RCommand::QuitCommand);
				c->whenFinished(this, [this, restart_now]() { QTimer::singleShot(0, this, restart_now); });
				RInterface::issueCommand(c);
			}
		}
	}
```

#### AUTO 


```{c}
auto callback = [&output, extractnumber](RCommand *command) {
			auto res = extractnumber.match(command->fullOutput());
			QVERIFY(res.hasMatch());
			output.append(res.captured());
		};
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *) {}
```

#### AUTO 


```{c}
auto mdi_focus_policy_chooser = mdi_focus_policy.makeDropDown(RKConfigBase::LabelList(
		{{RKMDIClickFocus, i18n("Click to focus")}, {RKMDIFocusFollowsMouse, i18n("Focus follows mouse")}}
	), this);
```

#### AUTO 


```{c}
const auto a
```

#### LAMBDA EXPRESSION 


```{c}
[exename, downloadurl](RKSetupWizard *wizard) { wizard->markSoftwareForInstallation(exename, downloadurl, true); }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
			auto a = RObjectList::getGlobalEnv()->findObject("a");
			QVERIFY(a != nullptr);
			QVERIFY(a->isContainer());
			auto ac = static_cast<RContainerObject*>(a);
			QCOMPARE(ac->numChildren(), 3);
			QCOMPARE(ac->findChildByIndex(0)->getDataType(), RObject::DataNumeric);
			QCOMPARE(ac->findChildByIndex(1)->getDataType(), RObject::DataCharacter);
			QVERIFY(ac->findChildByIndex(2)->isDataFrame());
		}
```

#### AUTO 


```{c}
auto r2htmlpackage = makeRPackageCheck("R2HTML", i18n("The R2HTML package is used by nearly all RKWard output functions, and thus required."), RKSetupWizardItem::Error, wizard);
```

#### AUTO 


```{c}
auto ed = KTextEditor::Editor::instance();
```

#### AUTO 


```{c}
auto startup_action_choser = startup_action.makeDropDown(RKConfigBase::LabelList(
		{{StartupDialog::EmptyWorkspace, i18n("Start with an empty workspace")}, {StartupDialog::RestoreFromWD, i18n("Load .RData-file from current directory, if available (R option '--restore')")}, {StartupDialog::EmptyTable, i18n("Start with an empty table")}, {StartupDialog::ChoseFile, i18n("Ask for a file to open")}, {StartupDialog::NoSavedSetting, i18n("Show selection dialog (default)")}}
	), this);
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.removeAll(legacy_libloc);
									RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### AUTO 


```{c}
auto it = outputs_copy.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.get().removeAll(legacy_libloc);
									RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### AUTO 


```{c}
auto inf = RKSettingsModulePlugins::parsePluginMapBasics(files[i]);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { actionmenu_preview->setCurrentItem (NoPreview); discardPreview (); }
```

#### LAMBDA EXPRESSION 


```{c}
[keepbutton, renamebutton, legacy_libloc, &liblocs]() {
				if (keepbutton->isChecked ()) return;

				liblocs.removeAll (legacy_libloc);
				if (renamebutton->isChecked ()) {
					QString new_loc = legacy_libloc + '/' + RKSessionVars::RVersion (true);
					RKGlobals::rInterface ()->issueCommand (QString ("file.rename(%1, %2)\n").arg (RObject::rQuote (legacy_libloc)).arg (RObject::rQuote (new_loc)), RCommand::App);
					liblocs.prepend (legacy_libloc + QStringLiteral ("/%v"));
				}

				RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[id]() { RKRecentUrls::actions.remove(id); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateCaption(); setGlobalContextProperty ("current_filename", m_doc->url ().url ()); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const PluginMapStoredInfo &a, const PluginMapStoredInfo &b) { return a.betterThan(b); }
```

#### AUTO 


```{c}
auto firstpageref = wizard->addPage (firstpage, i18n("RKWard Setup Assistant"));
```

#### AUTO 


```{c}
auto it = actions.constBegin();
```

#### AUTO 


```{c}
auto list = RKRecentUrls::allRecentUrls(category);
```

#### LAMBDA EXPRESSION 


```{c}
[_done, callback](RCommand *command) { *_done = true; callback(command); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		// Force a good width for the icon column, particularly for MacOS X.
		packages_view->header ()->resizeSection (0, packages_view->sizeHintForIndex (model->index (0, 0, model->index (RKRPackageInstallationStatus::NewPackages, 0, QModelIndex ()))).width () + packages_view->indentation ());
		for (int i = 1; i <= RKRPackageInstallationStatus::PackageName; ++i) {
			packages_view->resizeColumnToContents (i);
		}
		// For whatever reason, we have to re-set these, here.
		for (int i = 0; i < model->rowCount (); ++i) {
			packages_view->setFirstColumnSpanned (i, QModelIndex (), true);
		}
		window()->raise(); // needed on Mac, otherwise the dialog may go hiding behind the main app window, after the progress control window closes, for some reason
		clearChanged();
		updateStatus();
	}
```

#### AUTO 


```{c}
auto it = values.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[target]() { RKWorkplace::mainWorkplace()->openAnyUrl(target); }
```

#### AUTO 


```{c}
auto inf2 = parsePluginMapBasics(inf.filename);
```

#### AUTO 


```{c}
auto t = new QTimer(this);
```

#### AUTO 


```{c}
auto scheme = RKStyle::viewScheme();
```

#### AUTO 


```{c}
auto ret = new RKSetupWizardItem(exename, explanation);
```

#### AUTO 


```{c}
auto checkbounds_input = options_checkbounds.makeDropDown(RKConfigBase::LabelList({{1, i18n("TRUE")}, {0, i18n("FALSE (default)")}}), this);
```

#### AUTO 


```{c}
auto a = RObjectList::getGlobalEnv()->findObject("a");
```

#### AUTO 


```{c}
auto ret = RKRBackend::this_pointer->handleHistoricalSubstackRequest(list);
```

#### AUTO 


```{c}
auto restart_action = RKWardMainWindow::getMain()->actionCollection()->action("restart_r");
```

#### AUTO 


```{c}
auto save_chain = RInterface::startChain(0);
```

#### LAMBDA EXPRESSION 


```{c}
[ret, this]() { this->value = ret->isChecked(); }
```

#### AUTO 


```{c}
auto ret = ki18ndp(catalog_name, msgid_singular.toUtf8(), msgid_plural.toUtf8()).subs(count);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto kate_action : kate_actions) {
						auto action_shortcuts = kate_ac->defaultShortcuts(kate_action);
						for (int pos = 0; pos < action_shortcuts.size(); ++pos) {
							const auto &kate_sc = action_shortcuts[pos];
							if (own_sc.matches(kate_sc) != QKeySequence::NoMatch || kate_sc.matches(own_sc) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kate_sc.toString()), qPrintable(kate_action->objectName()), qPrintable(own_action->objectName()));
								action_shortcuts.removeAt(pos);
								kate_ac->setDefaultShortcuts(kate_action, action_shortcuts);
								break;
							}
						}
					}
```

#### AUTO 


```{c}
auto list = allRecentUrls(id);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		for (QStringList::const_iterator it = object_names.constBegin (); it != object_names.constEnd (); ++it) {
			QString object_name = *it;
			RObject *obj = RObjectList::getObjectList ()->findObject (object_name);
			if (!(obj && RKWorkplace::mainWorkplace()->editObject (obj))) {
				KMessageBox::information (0, i18n ("The object '%1', could not be opened for editing. Either it does not exist, or RKWard does not support editing this type of object, yet.", object_name), i18n ("Cannot edit '%1'", object_name));
			}
		}

		// we're done
		deleteLater ();
	}
```

#### AUTO 


```{c}
auto *button = new QRadioButton(filters[i]);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
			QVERIFY(RObjectList::getGlobalEnv()->findObject("a") == nullptr);
			QCOMPARE(RObjectList::getGlobalEnv()->findObject("b")->getDataType(), RObject::DataNumeric);
			QCOMPARE(RObjectList::getGlobalEnv()->findObject("c")->getDataType(), RObject::DataCharacter);
			QCOMPARE(RObjectList::getGlobalEnv()->findObject(".d")->getDimensions(), RObjectList::getGlobalEnv()->findObject("c")->getDimensions());
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		RK_ASSERT (command->getDataType() == RData::StringVector);
		RK_ASSERT (command->getDataLength() > 0);
		// NOTE: The problem is that e.g. R_LIBS_USER is not in .libPaths() if it does not exist, yet. But it should be available as an option, of course
		library_locations = command->stringVector();
		emit libraryLocationsChanged(library_locations);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			QVERIFY(command->failed());
			QEXPECT_FAIL("", "Syntax error detection for User commands known to be broken, but doesn't really matter", Continue);
			QVERIFY(command->errorSyntax());
		}
```

#### LAMBDA EXPRESSION 


```{c}
[connection, container](){
						// connection must self-destruct, as it will be re-created from refresh()
						QObject::disconnect(*connection);
						delete connection;
						// also, delay the actual refresh, in case, e.g. several script files are opened at once
						QTimer::singleShot(0, container, &RKHTMLWindow::refresh);
					}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
			wrapper->resize(display_area->size());
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWebEngineDownloadItem* item) {
		QString path = QFileDialog::getSaveFileName (this, i18n ("Save as"), item->path ());
		if (path.isEmpty ()) return;
		item->setPath (path);
		item->accept ();
	}
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Install from git"));
```

#### AUTO 


```{c}
auto it = ids_to_remove.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand* command) {
		if (!data) return;	// this can happen, if the editor is closed while a data update is still queued.

		// prevent resyncing of data
		lockSyncing (true);

		RK_ASSERT (command->getDataType () == RData::StructureVector);
		RK_ASSERT (command->getDataLength () == 3);

		RData::RDataStorage top = command->structureVector ();
		RData *cdata = top.at (0);
		RData *levels = top.at (1);
		RData *invalids = top.at (2);

		// set factor levels first
		RK_ASSERT (levels->getDataType () == RData::StringVector);
		QStringList new_levels = levels->stringVector ();
		int levels_len = new_levels.size ();
		RK_ASSERT (levels_len >= 1);
		delete data->value_labels;
		data->value_labels = new RObject::ValueLabels;
		if ((levels_len == 1) && new_levels.at (0).isEmpty ()) {
			// no levels
		} else {
			for (int i=0; i < levels_len; ++i) {
				data->value_labels->insert (QString::number (i+1), new_levels.at (i));
			}
		}

		// now set the data
		RK_ASSERT (cdata->getDataLength () == (unsigned int) getLength ()); // not really a problem due to the line below, I'd still like to know if / when this happens.
		extendToLength (cdata->getDataLength ());
		if (cdata->getDataType () == RData::StringVector) {
			setCharacterFromR (0, getLength () - 1, cdata->stringVector ());
		} else if (cdata->getDataType () == RData::RealVector) {
			setNumericFromR (0, getLength () - 1, cdata->realVector ());
		} else if (cdata->getDataType () == RData::IntVector) {
			RData::IntStorage int_data = cdata->intVector ();
			unsigned int len = getLength ();
			QVector<double> dd;
			dd.reserve (len);
			for (unsigned int i = 0; i < len; ++i) {
				if (RInterface::isNaInt (int_data.at (i))) dd.append (NAN);
				else dd.append ((double) int_data.at (i));
			}
			setNumericFromR (0, getLength () - 1, dd);
		}

		// now set the invalid fields (only if they are still NAs in the R data)
		data->invalid_fields.clear ();
		if (invalids->getDataLength () <= 1) {
			// no invalids
		} else {
			RK_ASSERT (invalids->getDataType () == RData::StringVector);
			QStringList invalids_list = invalids->stringVector ();
			int invalids_length = invalids_list.size ();
			RK_ASSERT ((invalids_length % 2) == 0);
			int invalids_count = invalids_length / 2;
			for (int i=0; i < invalids_count; ++i) {
				int row = invalids_list.at (i).toInt () - 1;
				if (data->cell_states[row] & RKVarEditData::NA) {	// NOTE: Do *not* use setText(), here. It tries too hard to set a valid value.
					data->invalid_fields.insert (row, invalids_list.at (invalids_count + i));
					data->cell_states[row] = RKVarEditData::Invalid;
				}
			}
		}
		data->previously_valid = data->invalid_fields.isEmpty ();
		data->formatting_options = parseFormattingOptionsString (getMetaProperty ("format"));

		ChangeSet *set = new ChangeSet (0, getLength (), true);
		RKModificationTracker::instance()->objectDataChanged (this, set);
		RKModificationTracker::instance()->objectMetaChanged (this);
		type -= (type & NeedDataUpdate);
		discardUnsyncedChanges ();
		lockSyncing (false);
	}
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(group);
```

#### AUTO 


```{c}
auto it = all_maps.constBegin();
```

#### AUTO 


```{c}
auto new_win = windows.value(path);
```

#### AUTO 


```{c}
auto *box = settings->completion_type_enabled[i].makeCheckbox(labels[i], this);
```

#### AUTO 


```{c}
auto it = switch_convert_sources.constBegin();
```

#### AUTO 


```{c}
auto it = command_stack.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { wrapper_widget->hide (); emit (previewClosed(this)); }
```

#### AUTO 


```{c}
auto keepsourcepkgs_input = options_keepsourcepkgs.makeDropDown(RKConfigBase::LabelList({{1, i18n("TRUE")}, {0, i18n("FALSE (default)")}}), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto kk : action_shortcuts) {
							if (k.matches(kk) != QKeySequence::NoMatch || kk.matches(k) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kk.toString()), qPrintable(ka->objectName()), qPrintable(a->objectName()));
								action_shortcuts.removeAll(k);
								kac->setDefaultShortcuts(ka, action_shortcuts);
								break;
							}
						}
```

#### AUTO 


```{c}
auto ret = ki18nd(catalog_name, msgid.toUtf8());
```

#### AUTO 


```{c}
auto c = all_current_commands.takeLast();
```

#### AUTO 


```{c}
auto it = outputs.constBegin ();
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			RK_ASSERT (command->getDataType () == RData::StringVector);
			RK_ASSERT (command->getDataLength () == 1);
			RKSettingsModuleR::help_base_url = command->stringVector ().value (0);
		}
```

#### LAMBDA EXPRESSION 


```{c}
[target]() { RKWardMainWindow::getMain()->askOpenWorkspace(target); }
```

#### AUTO 


```{c}
auto obj = RObjectList::getObjectList()->findObject(symbol);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### LAMBDA EXPRESSION 


```{c}
[&priority_command_done](RCommand *command) {
			QVERIFY(priority_command_done);
			QVERIFY(command->failed());
			QVERIFY(command->wasCanceled());
		}
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			QCOMPARE(command->getDataType(), RData::IntVector);
			QCOMPARE(command->getDataLength(), 3);
			QCOMPARE(command->intVector().value(1), 2);
		}
```

#### AUTO 


```{c}
auto res = KMessageBox::questionYesNoCancel(RKWardMainWindow::getMain(), i18n("The output has been modified, and closing it will discard all changes. What do you want to do?"), i18n("Discard unsaved changes?"), KStandardGuiItem::discard(), KStandardGuiItem::save(), KStandardGuiItem::cancel());
```

#### AUTO 


```{c}
auto it = windows.constBegin();
```

#### AUTO 


```{c}
auto label = new QLabel();
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.removeAll(legacy_libloc);
									QString new_loc = legacy_libloc + '-' + RKSessionVars::RVersion (true);
									RKGlobals::rInterface ()->issueCommand (QString ("file.rename(%1, %2)\n").arg (RObject::rQuote (legacy_libloc)).arg (RObject::rQuote (new_loc)), RCommand::App);
									liblocs.prepend (legacy_libloc + QStringLiteral ("-%v"));
									RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### AUTO 


```{c}
auto it = outputdir_checklist.constBegin();
```

#### AUTO 


```{c}
auto outputs = RKOutputDirectory::allOutputs();
```

#### AUTO 


```{c}
auto ret = contexts.takeLast();
```

#### AUTO 


```{c}
auto it = outputs.constBegin();
```

#### AUTO 


```{c}
auto ret = ki18ndcp(catalog_name, msgctxt.toUtf8(), msgid_singular.toUtf8(), msgid_plural.toUtf8()).subs(count);
```

#### AUTO 


```{c}
auto restart_now = [this]() {
				delete RInterface::instance();  // NOTE: Do not use deleteLater(), here. It is important to fully tear down the old backend, before creating the new one,
				                                //       as code is written around the assumption that RInterface and friends are singletons. (RInterface::instance(), etc.)
				RKWorkplace::mainWorkplace()->setWorkspaceURL(QUrl());
				startR();
			};
```

#### LAMBDA EXPRESSION 


```{c}
[&success, command]() { success = command->succeeded(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val){this->value = (T) val;}
```

#### LAMBDA EXPRESSION 


```{c}
[this, done_when_finished](RCommand* command) {
			outstanding_commands.removeAll(command);
			if (done_when_finished) done();
		}
```

#### AUTO 


```{c}
auto control = new RKInlineProgressControl(this, true);
```

#### AUTO 


```{c}
auto pf = w->persistentGuiClient()->factory();
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand* command) {
		if (command->failed ()) {
			KMessageBox::sorry (this, i18n ("No help found on '%1'. Maybe the corresponding package is not installed/loaded, or maybe you mistyped the command. Try using Help->Search R Help for more options.", command->command ().section ('\"', 1, 1)), i18n ("No help found"));
		}
	}
```

#### AUTO 


```{c}
auto dir = zip.directory()->entry("rkward_output");
```

#### AUTO 


```{c}
auto rmarkdownpackage = makeRPackageCheck("rmarkdown", i18n("The rmarkdown package is required for rendering .Rmd files (including preview rendering), which is an optional but recommended feature."), RKSetupWizardItem::Warning, wizard);
```

#### AUTO 


```{c}
auto *button = new QRadioButton(i18n("None of the above / try another method"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) { return md.serviceTypes().contains(QLatin1String("KTextEditor/Plugin")); }
```

#### AUTO 


```{c}
auto label = RKCommonFunctions::wordWrappedLabel(i18n("Some add-on packages are not available in the CRAN repository, but can be installed from development repositories. Use the button \"%1\", to install such packages, comfortably.", button->text()));
```

#### AUTO 


```{c}
const auto &inf = handle.list.first();
```

#### LAMBDA EXPRESSION 


```{c}
[ret, this]() { this->value = ret->realValue(); }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { RKSettings::validateSettingsInteractive (); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &key : keys) {
		auto info = known_plugins.value(key);
		if (plugins.contains(key)) {
			if (!info.plugin) {
				loadPlugin(key);
				changes = true;
			}
		} else {
			if (info.plugin) {
				unloadPlugin(key);
				changes = true;
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto ka : kac->actions()) {
						auto action_shortcuts = kac->defaultShortcuts(ka);
						for (const auto kk : action_shortcuts) {
							if (k.matches(kk) != QKeySequence::NoMatch || kk.matches(k) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kk.toString()), qPrintable(ka->objectName()), qPrintable(a->objectName()));
								action_shortcuts.removeAll(k);
								kac->setDefaultShortcuts(ka, action_shortcuts);
								break;
							}
						}
					}
```

#### AUTO 


```{c}
auto ret = get(filename, !QFileInfo(filename).exists(), chain);
```

#### LAMBDA EXPRESSION 


```{c}
[ret, this]() { this->value = ret->intValue(); }
```

#### AUTO 


```{c}
auto box = new QWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](){ kioJobFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto kac : kate_acs) {
					for (auto ka : kac->actions()) {
						auto action_shortcuts = kac->defaultShortcuts(ka);
						for (const auto kk : action_shortcuts) {
							if (k.matches(kk) != QKeySequence::NoMatch || kk.matches(k) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kk.toString()), qPrintable(ka->objectName()), qPrintable(a->objectName()));
								action_shortcuts.removeAll(k);
								kac->setDefaultShortcuts(ka, action_shortcuts);
								break;
							}
						}
					}
				}
```

#### AUTO 


```{c}
auto idir = new RKSetupWizardItem(i18n("Installation directory"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto a : own_actions) {
			for (const auto k : ac->defaultShortcuts(a)) {
				for (const auto kac : kate_acs) {
					for (auto ka : kac->actions()) {
						auto action_shortcuts = kac->defaultShortcuts(ka);
						for (const auto kk : action_shortcuts) {
							if (k.matches(kk) != QKeySequence::NoMatch || kk.matches(k) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kk.toString()), qPrintable(ka->objectName()), qPrintable(a->objectName()));
								action_shortcuts.removeAll(k);
								kac->setDefaultShortcuts(ka, action_shortcuts);
								break;
							}
						}
					}
				}
			}
		}
```

#### LAMBDA EXPRESSION 


```{c}
[details, layout]() { KMessageBox::information(layout->parentWidget(), details, QString(), QString(), KMessageBox::Notify | KMessageBox::AllowLink); }
```

#### AUTO 


```{c}
auto waiting_to_start_label = RKCommonFunctions::wordWrappedLabel(i18n("<b>Waiting for R backend...</b>") + "<p>&nbsp;</p><p>&nbsp;</p>");
```

#### AUTO 


```{c}
auto command = new RCommand("save.image(" + RObject::rQuote(url.toLocalFile()) + ')', RCommand::App);
```

#### AUTO 


```{c}
auto df = w->dynamicGuiClient()->factory();
```

#### AUTO 


```{c}
auto res = RKRShadowEnvironment::diffAndUpdate(a);
```

#### AUTO 


```{c}
auto ret = new RKSetupWizardItem(packagename, explanation);
```

#### AUTO 


```{c}
auto firstpage = new QWidget();
```

#### AUTO 


```{c}
auto auto_show_box = auto_show.makeCheckbox(i18n("show window on new output"), this);
```

#### AUTO 


```{c}
auto info = known_plugins.value(key);
```

#### LAMBDA EXPRESSION 


```{c}
[this, index](){
		packages_view->setExpanded(model->mapFromSource(index), true);
		packages_view->scrollTo(model->mapFromSource(index));
	}
```

#### AUTO 


```{c}
auto &sublist = it.value();
```

#### AUTO 


```{c}
auto ret = RKRBackend::this_pointer->handleRequestWithSubcommands(call, RKRSupport::SEXPToNestedStrings(_args));
```

#### AUTO 


```{c}
auto manager = new RKCompletionManager (view, RKSettingsModuleConsole::completionSettings());
```

#### AUTO 


```{c}
auto add_piped_commands_to_history_box = add_piped_commands_to_history.makeDropDown(RKConfigBase::LabelList(
		{{(int) DontAdd, i18n("Do not add")}, {(int) AddSingleLine, i18n("Add only if single line")}, {(int) AlwaysAdd, i18n("Add all commands")}}
	), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&output, extractnumber](RCommand *command) {
			auto res = extractnumber.match(command->fullOutput());
			QVERIFY(res.hasMatch());
			output.append(res.captured());
		}
```

#### AUTO 


```{c}
auto dir = outputs[i];
```

#### AUTO 


```{c}
auto p = QWebEngineProfile::defaultProfile();
```

#### AUTO 


```{c}
auto d = new RKOutputDirectory();
```

#### AUTO 


```{c}
auto candidate = existing_editors[i];
```

#### AUTO 


```{c}
auto it = outputdir_checklist.constBegin ();
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			QVERIFY(command->failed());
			QVERIFY(command->error().contains("123test"));
		}
```

#### AUTO 


```{c}
auto legacy_output = new RKSetupWizardItem(i18n("Pre 0.7.3 output file"));
```

#### LAMBDA EXPRESSION 


```{c}
[packagename](RKSetupWizard *wizard) { wizard->markRPackageForInstallation(packagename, false); }
```

#### AUTO 


```{c}
auto label = entries[i].label;
```

#### AUTO 


```{c}
auto new_list = RKSettingsModulePlugins::setPluginMaps(model->pluginMaps());
```

#### AUTO 


```{c}
auto ret = RKRBackend::this_pointer->handlePlainGenericRequest(RKRSupport::SEXPToStringList(call), RKRSupport::SEXPToInt(synchronous));
```

#### AUTO 


```{c}
auto outputs_copy = outputs;
```

#### AUTO 


```{c}
auto screen = for_widget->screen();
```

#### AUTO 


```{c}
auto it = outstanding_commands.cbegin ();
```

#### LAMBDA EXPRESSION 


```{c}
[legacy_libloc](RKSetupWizard*) {
									liblocs.get().removeAll(legacy_libloc);
									QString new_loc = legacy_libloc + '-' + RKSessionVars::RVersion (true);
									RKGlobals::rInterface ()->issueCommand (QString ("file.rename(%1, %2)\n").arg(RObject::rQuote(legacy_libloc), RObject::rQuote (new_loc)), RCommand::App);
									liblocs.get().prepend (legacy_libloc + QStringLiteral ("-%v"));
									RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
								}
```

#### AUTO 


```{c}
auto max_history_length_spinner = max_history_length.makeSpinBox(0, 10000, this);
```

#### LAMBDA EXPRESSION 


```{c}
[keepbutton, renamebutton, legacy_libloc]() {
				if (keepbutton->isChecked ()) return;

				liblocs.removeAll (legacy_libloc);
				if (renamebutton->isChecked ()) {
					QString new_loc = legacy_libloc + '-' + RKSessionVars::RVersion (true);
					RKGlobals::rInterface ()->issueCommand (QString ("file.rename(%1, %2)\n").arg (RObject::rQuote (legacy_libloc)).arg (RObject::rQuote (new_loc)), RCommand::App);
					liblocs.prepend (legacy_libloc + QStringLiteral ("-%v"));
				}

				RKGlobals::rInterface ()->issueCommand (libLocsCommand(), RCommand::App);
			}
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			RK_ASSERT (command->getDataType () == RData::StringVector);
			RK_ASSERT (command->getDataLength () == 1);
			RKSessionVars::setRVersion (command->stringVector ().value (0));
		}
```

#### AUTO 


```{c}
auto chain = RInterface::startChain();
```

#### LAMBDA EXPRESSION 


```{c}
[details, layout]() { KMessageBox::information(layout->parentWidget(), details); }
```

#### LAMBDA EXPRESSION 


```{c}
[](RKSetupWizard*) {}
```

#### AUTO 


```{c}
auto auto_raise_box = auto_raise.makeCheckbox(i18n("raise window on new output"), this);
```

#### AUTO 


```{c}
auto vera = RKParsedVersion(candidate->getAboutData().version);
```

#### AUTO 


```{c}
auto ktexteditorpages = RKSettingsModuleCommandEditor::kateConfigPages(this, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[]() { RKComponentMap::getMap()->invokeComponent("rkward::install_from_git", QStringList()); }
```

#### LAMBDA EXPRESSION 


```{c}
[confint](bool val) { confint->setConfigValue("scrollbar-minimap", val); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, restart_now]() { QTimer::singleShot(0, this, restart_now); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, command]() { this->sendReply(command); }
```

#### AUTO 


```{c}
auto completion_all_filetypes = settings->tabkey_invokes_completion.makeCheckbox(QString(), this);
```

#### AUTO 


```{c}
auto cursor_navigates_completions_box = settings->cursor_navigates_completions.makeDropDown(RKConfigBase::LabelList(
		{{1, i18n("Up/down cursor keys")}, {0, i18n("Alt+Up/down cursor keys")}}
	), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotOpenCommandEditor(); }
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, which]() { dialog->done(which); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
			RK_TRACE(APP);
			current_command = nullptr;

			if (command->errorSyntax() && command->error().isEmpty()) {
				doc->insertLine(doc->lines() - 1, i18n("Syntax error\n"));
			}
			if (command->errorIncomplete()) {
				prefix = iprefix;
				incomplete_command = command->remainingCommand();
			} else {
				prefix = nprefix;
				incomplete_command.clear();
			}

			commands_history.goToEnd();
			showPrompt();
			tryNextInBuffer();
		}
```

#### AUTO 


```{c}
auto res = dialog->exec ();
```

#### AUTO 


```{c}
auto it = component_ids.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[exename, downloadurl](RKSetupWizard *wizard) { wizard->markSoftwareForInstallation(exename, downloadurl, false); }
```

#### AUTO 


```{c}
auto factory = KPluginLoader(service->library()).factory();
```

#### AUTO 


```{c}
const auto keys = pluginapp->known_plugins.keys();
```

#### AUTO 


```{c}
auto ver = RKParsedVersion(version);
```

#### AUTO 


```{c}
auto own_actions = ac->actions();
```

#### AUTO 


```{c}
auto ret = ki18ndc(catalog_name, msgctxt.toUtf8(), msgid.toUtf8());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
			RKWardMainWindow::getMain()->slotSetStatusReady();
			RKWardMainWindow::getMain()->setWorkspaceMightBeModified(false);
			RKOutputDirectory::getCurrentOutput();  // make sure some output file exists

			deleteLater();
		}
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ askOpenWorkspace(); }
```

#### AUTO 


```{c}
auto initial_dir_chooser = initial_dir.makeDropDown(RKConfigBase::LabelList(
		{{CurrentDirectory, i18n("Do not change current directory on startup")}, {RKWardDirectory, i18n("RKWard files directory (as specified, above)")}, {UserHomeDirectory, i18n("User home directory")}, {LastUsedDirectory, i18n("Last used directory")}, {CustomDirectory, i18n("The following directory (please specify):")}}
	), this);
```

#### AUTO 


```{c}
const auto id = plugin_maps.ordered_ids.value(index.row());
```

#### AUTO 


```{c}
auto it = all_maps.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto ac : own_acs) {
		auto own_actions = ac->actions();
		for (const auto a : own_actions) {
			for (const auto k : ac->defaultShortcuts(a)) {
				for (const auto kac : kate_acs) {
					for (auto ka : kac->actions()) {
						auto action_shortcuts = kac->defaultShortcuts(ka);
						for (const auto kk : action_shortcuts) {
							if (k.matches(kk) != QKeySequence::NoMatch || kk.matches(k) != QKeySequence::NoMatch) {
								RK_DEBUG(EDITOR, DL_WARNING, "Removing conflicting shortcut %s in kate part (%s, conflicting with %s)", qPrintable(kk.toString()), qPrintable(ka->objectName()), qPrintable(a->objectName()));
								action_shortcuts.removeAll(k);
								kac->setDefaultShortcuts(ka, action_shortcuts);
								break;
							}
						}
					}
				}
			}
		}
	}
```

#### AUTO 


```{c}
auto l = new QVBoxLayout(firstpage);
```

#### AUTO 


```{c}
auto ret = get(filename, !QFileInfo::exists(filename), chain);
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand*){}
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback](RCommand* command) { // clazy:exclude=connect-3arg-lambda
			if (object) {
				callback(command);
			}
			if (--command_count <= 0) delete this;
		}
```

#### AUTO 


```{c}
auto con = connection;
```

#### AUTO 


```{c}
auto res = outputs.constBegin().value()->purge(Force, nullptr, false);
```

#### AUTO 


```{c}
auto scheme = KColorScheme(QPalette::Normal);
```

#### AUTO 


```{c}
auto out = getOutputById(id);
```

#### AUTO 


```{c}
auto kate_acs = m_view->findChildren<KActionCollection*>();
```

#### AUTO 


```{c}
auto c = new RCommand(s, RCommand::App | RCommand::Sync | RCommand::GetStringVector);
```

#### AUTO 


```{c}
auto list = RKOutputWindowManager::self()->existingOutputWindows(workPath());
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
			RK_ASSERT (command->getDataType () == RData::StringVector);
			RKSettingsModuleRPackages::r_libs_user = command->stringVector ().value (0);
			RKSettingsModuleRPackages::defaultliblocs += command->stringVector ().mid (1);

			RCommandChain *chain = command->parent;
			RK_ASSERT (chain);
			RK_ASSERT (!chain->isClosed ());

			// apply user configurable run time options
			auto runtimeopt_callback = [](RCommand *) {}; // No special handling. Any failure will be recorded with runStartupCommand().
			QStringList commands = RKSettingsModuleR::makeRRunTimeOptionCommands () + RKSettingsModuleRPackages::makeRRunTimeOptionCommands () + RKSettingsModuleOutput::makeRRunTimeOptionCommands () + RKSettingsModuleGraphics::makeRRunTimeOptionCommands ();
			for (QStringList::const_iterator it = commands.cbegin (); it != commands.cend (); ++it) {
				runStartupCommand(new RCommand(*it, RCommand::App | RCommand::Sync), chain, runtimeopt_callback);
			}
			// initialize output file
			RKOutputDirectory::getCurrentOutput(chain);

#ifdef Q_OS_MACOS
			// On MacOS, the backend is started from inside R home to allow resolution of dynamic libs. Re-set to frontend wd, here.
			runStartupCommand(new RCommand("setwd (" + RKRSharedFunctionality::quote(QDir::currentPath()) + ")\n", RCommand::App | RCommand::Sync), chain, runtimeopt_callback);
#endif
			// Workaround for https://bugs.kde.org/show_bug.cgi?id=421958
			if (RKSessionVars::compareRVersion("4.0.0") < 1 && RKSessionVars::compareRVersion("4.0.1") > 0) {
				runStartupCommand(new RCommand("if(compiler::enableJIT(-1) > 2) compiler::enableJIT(2)\n", RCommand::App | RCommand::Sync), chain, runtimeopt_callback);
			}

			closeChain (chain);
		}
```

#### AUTO 


```{c}
auto it = windows.constBegin ();
```

#### AUTO 


```{c}
auto c = new RCommand("c(1, 2, 3)", RCommand::GetIntVector);
```

#### AUTO 


```{c}
auto val = all_maps.value(id);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { status_popup_container->resize (QSize(width(), status_popup->height () + 20)); }
```

#### AUTO 


```{c}
auto n = createOutputDirectoryInternal();
```

#### AUTO 


```{c}
const auto &kate_sc = action_shortcuts[pos];
```

#### AUTO 


```{c}
auto max_console_lines_spinner = max_console_lines.makeSpinBox(0, 10000, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *c) {
		unfinished_commands.removeAll(c);
		if (c->failed()) {
			any_failed = true;
		}
		if (unfinished_commands.isEmpty()) {
			done();
		}
	}
```

#### AUTO 


```{c}
auto res = callback_obj.call(engine.globalObject(), args);
```

#### AUTO 


```{c}
auto res = wizard->exec();
```

#### AUTO 


```{c}
auto w = new KMessageWidget(i18n("The generic import plugin (shipped with RKWard) is not presently loaded. Check your settings."));
```

#### LAMBDA EXPRESSION 


```{c}
[this, package_names]() {
		QStringList failed_names;
		for (int i = 0; i < package_names.size(); ++i) {
			QModelIndex index = packages_status->markPackageForInstallation(package_names[i]);
			if (!index.isValid()) {
				failed_names.append(package_names[i]);
			} else {
				packages_view->scrollTo(model->mapFromSource(index));
			}
		}
		if (!failed_names.isEmpty()) {
			KMessageBox::sorry (0, i18n ("The following package(s) requested by the backend have not been found in the package repositories: \"%1\". Maybe the package name was mis-spelled. Or maybe you need to add additional repositories via the \"Configure Repositories\" button.", failed_names.join("\", \"")), i18n ("Package not available"));
		}
	}
```

#### AUTO 


```{c}
auto auto_completion_min_chars_box = settings->auto_completion_min_chars.makeSpinBox(1, INT_MAX, this);
```

#### AUTO 


```{c}
auto kate_action
```

#### LAMBDA EXPRESSION 


```{c}
[]() { RKPasteSpecialDialog dia(RKWardMainWindow::getMain(), true); dia.exec(); }
```

#### AUTO 


```{c}
auto old_win = windows.value(current_default_path);
```

#### LAMBDA EXPRESSION 


```{c}
[this, bit_flag_mask](int val){this->value = (T) ((this->value & ~bit_flag_mask) + val);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		if (is_done) return;
		animation_step = (animation_step + 1) % 2;
		if (animation_step) {
			message_widget->setIcon(QIcon::fromTheme("computer-symbolic"));
		} else {
			message_widget->setIcon(RKStandardIcons::getIcon(RKStandardIcons::RKWardIcon));
		}
	}
```

#### AUTO 


```{c}
auto kateplugins = new RKSetupWizardItem(i18n("Kate plugins"));
```

#### AUTO 


```{c}
auto control = new RKInlineProgressControl(install_packages_widget, true);
```

#### AUTO 


```{c}
auto res = KMessageBox::warningYesNoCancel(this, message, i18n("R commands still pending"), KGuiItem(i18n("Force restart now")), KGuiItem(i18n("Check again")), KGuiItem(i18n("Cancel restarting")));
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *) {
		clearChanged();
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, pos, connection](){
			QObject::disconnect(*connection);
			delete connection;
			setScrollPosition(pos);
		}
```

#### AUTO 


```{c}
auto handle = engine->newQObject (new RKMessageCatalogObject (catalog, engine));
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand*) {
			QCOMPARE(RObjectList::getGlobalEnv()->numChildren(), 0);
		}
```

#### AUTO 


```{c}
auto completion_list_member_operator_box = settings->completion_options.makeDropDown(RKConfigBase::LabelList(
			{{RObject::DollarExpansion, i18n("'$'-operator (list$member)")}, {0, i18n("'[['-operator (list[[\"member\"]])")}}
		), this, RObject::DollarExpansion);
```

#### AUTO 


```{c}
auto res = callback_obj.call(args);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString url) { RKWorkplace::mainWorkplace()->openAnyUrl(QUrl(url)); }
```

#### LAMBDA EXPRESSION 


```{c}
[dialog, package_names]() { dialog->automatedInstall(package_names); }
```

#### LAMBDA EXPRESSION 


```{c}
[](RKSetupWizard* wizard) { wizard->markExternalPackageForInstallation(QStringLiteral("kate"), true); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
		RInterface::closeChain (open_chain);
		open_chain = nullptr;
		enableEditing (true);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		QStringList res;
		if (command->failed ()) {
			RK_ASSERT (false);
		} else {
			RK_ASSERT (command->getDataType () == RData::StringVector);
			res = command->stringVector ();
		}
		results->setResults (res);

		for (int i = 0; i < COL_COUNT; ++i) results_view->resizeColumnToContents (i);
		setEnabled(true);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
		QTreeWidgetItem *item = new QTreeWidgetItem();
		KPluginMetaData plugindata = pluginapp->known_plugins.value(key).data;
		item->setData(1, Qt::DisplayRole, plugindata.name());
		if (recommended_plugins.contains(key)) item->setData(1, Qt::FontRole, boldfont); 
		item->setData(2, Qt::DisplayRole, plugindata.description());
		item->setData(1, Qt::DecorationRole, QIcon::fromTheme(plugindata.iconName()));
		item->setData(1, Qt::UserRole, key);
		item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsUserCheckable);
		item->setCheckState(0, plugins_to_load.get().contains(key) ? Qt::Checked : Qt::Unchecked);
		plugin_table->addTopLevelItem(item);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[ret, setter, module]() {
		module->change();
		setter(ret->currentData().toInt());
	}
```

#### AUTO 


```{c}
auto all = allOutputs();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setStatusMessage(shortStatusLabel()); }
```

#### AUTO 


```{c}
const auto kk
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { wrapper_widget->hide(); emit previewClosed(this); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { RKRecentUrls::addRecentUrl(RKRecentUrls::workspaceId(), url); setCaption(QString()); }
```

#### AUTO 


```{c}
auto c = new RCommand(command, RCommand::App | RCommand::GetStringVector, i18n("Find HTML help for %1", function_name));
```

#### AUTO 


```{c}
auto runtimeopt_callback = [](RCommand *) {};
```

#### LAMBDA EXPRESSION 


```{c}
[](RKSetupWizard* wizard) { wizard->r_commands_to_run.append("rk.import.legacy.output()\n"); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { button(QDialogButtonBox::Apply)->setEnabled(true); }
```

#### AUTO 


```{c}
auto iface = qobject_cast<KTextEditor::TextHintInterface*>(view);
```

#### AUTO 


```{c}
auto w = mainWindow();
```

#### AUTO 


```{c}
auto command = makeCommand();
```

#### LAMBDA EXPRESSION 


```{c}
[packagename](RKSetupWizard *wizard) { wizard->markRPackageForInstallation(packagename, true); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		if (command->failed()) return;
		RK_ASSERT (command->getDataLength () == 5);

		RData::RDataStorage data = command->structureVector ();
		QStringList package = data.at (0)->stringVector ();
		QStringList title = data.at (1)->stringVector ();
		QStringList version = data.at (2)->stringVector ();
		QStringList libpath = data.at (3)->stringVector ();

		int count = package.size ();
		RK_ASSERT (count == title.size ());
		RK_ASSERT (count == version.size ());
		RK_ASSERT (count == libpath.size ());
		for (int i=0; i < count; ++i) {
			QTreeWidgetItem* item = new QTreeWidgetItem (installed_view);
			item->setText (0, package.at (i));
			item->setText (1, title.at (i));
			item->setText (2, version.at (i));
			item->setText (3, libpath.at (i));
		}
		installed_view->resizeColumnToContents (0);
		installed_view->setSortingEnabled (true);
		installed_view->sortItems (0, Qt::AscendingOrder);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback](RCommand* command) {
		RK_TRACE(RBACKEND);
		if (command->failed()) {
			startup_phase2_error = true;
		} else {
			callback(command);
		}
	}
```

#### AUTO 


```{c}
auto ac = static_cast<RContainerObject*>(a);
```

#### LAMBDA EXPRESSION 


```{c}
[](RCommand *command) {
			QVERIFY(command->failed());
			QVERIFY(command->errorIncomplete());
		}
```

#### AUTO 


```{c}
auto res = extractnumber.match(command->fullOutput());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message) {
		if(message.isEmpty()) updateCWD();
		else statusbar_cwd->setText(message);
		// realbar->showMessage(message);  // why doesn't this work, instead? Qt 5.12.8
	}
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto ret = engine->newArray(list.size());
```

#### AUTO 


```{c}
auto &sublist = it.value().list;
```

#### AUTO 


```{c}
auto c = popContext();
```

#### AUTO 


```{c}
auto completion_slot_operator_box = settings->completion_options.makeDropDown(RKConfigBase::LabelList(
			{{0, i18n("'@'-operator (object@member)")}, {RObject::ExplicitSlotsExpansion, i18n("'slot()'-function (slot(object, member))")}}
		), this, RObject::ExplicitSlotsExpansion);
```

#### AUTO 


```{c}
const auto &maps = it.value().list;
```

#### AUTO 


```{c}
auto ptype = R_GE_patternType(pattern);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &newlist) {
		libloc_selector->clear();
		libloc_selector->insertItems(0, RKSettingsModuleRPackages::addUserLibLocTo(newlist));
	}
```

#### LAMBDA EXPRESSION 


```{c}
[ret, connection, this]() {  // capturing "this" makes MSVC happy
			QObject::disconnect(*connection);
			delete connection;
			ret->acceptNavigationRequest (ret->url (), QWebEnginePage::NavigationTypeLinkClicked, true);
		}
```

#### AUTO 


```{c}
auto info = new QPushButton();
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *, const ROutput *o) {
		addOutput(o->output, o->type != ROutput::Output);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand *command) {
		if (command->succeeded()) {
			RK_ASSERT(command->getDataLength() >= 1);
			cran_mirror_input->setText(command->stringVector().value(0));
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this](RCommand* command) {
		RK_ASSERT (command->getDataType () == RData::StructureVector);
		const RData::RDataStorage & data = command->structureVector ();
		RK_ASSERT (data.size () == 2);

		QStringList new_environments = data[0]->stringVector ();
		RK_ASSERT (new_environments.size () >= 2);

		updateEnvironments (new_environments, true);
		updateNamespaces (data[1]->stringVector ());

		makeUpdateCompleteCallback();
	}
```

#### AUTO 


```{c}
auto num_recent_files_box = num_recent_files.makeSpinBox(1, INT_MAX, this);
```

#### AUTO 


```{c}
auto key = entries[i].key;
```

#### AUTO 


```{c}
auto connection = new QMetaObject::Connection;
```

