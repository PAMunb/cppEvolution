#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setLDAPPort();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s) { gotSearchResult(s); }
```

#### AUTO 


```{c}
auto job = new LdapSearchClientReadConfigServerJob;
```

#### AUTO 


```{c}
auto spacer = new QWidget(upDownBox);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *ldapItem = dynamic_cast<LdapWidgetItem *>(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        result();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &data) {
        d->slotData(job, data);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotDataTimer();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setLDAPSPort();
        }
```

#### AUTO 


```{c}
auto *item = dynamic_cast<LdapWidgetItem *>(mHostListView->item(i));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSelectionChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotUnselectAll();
    }
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(btgroup);
```

#### AUTO 


```{c}
auto *above = static_cast<LdapWidgetItem *>(mHostListView->item(mHostListView->row(item) - 1));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s) {
        loadResult(s);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    result();
                }
```

#### AUTO 


```{c}
auto ldapClient = new LdapClient(j, q);
```

#### AUTO 


```{c}
auto horizontalLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto item = dynamic_cast<LdapWidgetItem *>(mHostListView->item(i));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const LdapClient &client, const KLDAP::LdapObject &obj) {
                slotLDAPResult(client, obj);
            }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto hBoxHBoxLayout = new QHBoxLayout(hBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                queryDNClicked();
            }
```

#### AUTO 


```{c}
auto upDownBox = new QWidget(hBox);
```

#### AUTO 


```{c}
auto *job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->result(); }
```

#### AUTO 


```{c}
auto *ldapClient = new LdapClient(j, q);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s, const KLDAP::LdapObject &obj) {
        gotSearchData(s, obj);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setLDAPPort(); }
```

#### AUTO 


```{c}
auto writeJob = new WritePasswordJob(QStringLiteral("ldapclient"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job, const QString &str, const QString &val) {
        d->slotInfoMessage(job, str, val);
    }
```

#### AUTO 


```{c}
auto above = static_cast<LdapWidgetItem *>(mHostListView->item(mHostListView->row(item) - 1));
```

#### AUTO 


```{c}
auto ldapItem = dynamic_cast<LdapWidgetItem *>(item);
```

#### AUTO 


```{c}
auto job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### AUTO 


```{c}
auto job = new LdapWidgetItemReadConfigServerJob(this);
```

#### AUTO 


```{c}
auto *above = static_cast<LDAPItem *>(mHostListView->item(mHostListView->row(item) - 1));
```

#### AUTO 


```{c}
auto *item = dynamic_cast<LdapWidgetItem *>(mHostListView->currentItem());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setLDAPSPort(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QKeychain::Job *baseJob) {
            if (baseJob->error()) {
                qCWarning(LDAPCLIENT_LOG) << "Error writing password using QKeychain:" << baseJob->errorString();
            }
        }
```

#### AUTO 


```{c}
auto job = new LdapClientSearchConfigWriteConfigJob;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->result();
    }
```

#### AUTO 


```{c}
auto item = new LdapWidgetItem(mHostListView, true);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch*s) { loadResult(s); }
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox(i18n("LDAP Servers"));
```

#### AUTO 


```{c}
auto job = new LdapClientSearchConfigReadConfigJob(this);
```

#### AUTO 


```{c}
auto hBox = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
            setSimple(b);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &filename) {
        d->slotFileChanged(filename);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                slotLDAPError(str);
            }
```

#### AUTO 


```{c}
auto *hBoxHBoxLayout = new QHBoxLayout(hBox);
```

#### LAMBDA EXPRESSION 


```{c}
[dnquery](const QString &text) {
                dnquery->setEnabled(!text.trimmed().isEmpty());
            }
```

#### AUTO 


```{c}
auto *item = new LdapWidgetItem(mHostListView, true);
```

#### AUTO 


```{c}
auto btgroup = new QWidget(mParent);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                queryMechClicked();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                slotLDAPDone();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &err) {
                slotError(err);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s, const KLDAP::LdapObject &obj) {gotSearchData(s, obj); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotSelectAll();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KLDAP::LdapClient *client : qAsConst(mLdapClientList)) {
        client->startQuery(filter);
    }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout;
```

#### AUTO 


```{c}
auto *buttons = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto authbox = new QGroupBox(i18n("Authentication"), mParent);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            result();
        }
```

#### AUTO 


```{c}
const auto components = QStringView(rdn).split(QLatin1Char('='));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Check all servers that should be used:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (KLDAP::LdapClient *client : qAsConst(mLdapClientList)) {
        client->cancelQuery();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { queryMechClicked(); }
```

#### AUTO 


```{c}
auto *ldapItem = dynamic_cast<LDAPItem *>(item);
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto item = dynamic_cast<LdapWidgetItem *>(mHostListView->currentItem());
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s, const KLDAP::LdapObject &obj) {loadData(s, obj); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KLDAP::LdapClient *client : qAsConst(mLdapClientList)) {
        if (rec) {
            client->setScope(QStringLiteral("sub"));
        } else {
            client->setScope(QStringLiteral("one"));
        }
    }
```

#### AUTO 


```{c}
auto dnquery = new QPushButton(i18n("Query Server"), mParent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &filename) {
        slotFileChanged(filename);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { result(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
            setAnonymous(b);
        }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool b) { setAnonymous(b); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
            setSASL(b);
        }
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(page);
```

#### AUTO 


```{c}
auto upDownBoxVBoxLayout = new QVBoxLayout(upDownBox);
```

#### AUTO 


```{c}
auto page = new QWidget(this);
```

#### AUTO 


```{c}
auto *upDownBoxVBoxLayout = new QVBoxLayout(upDownBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool b) { setSimple(b); }
```

#### AUTO 


```{c}
auto *item = new LDAPItem(mHostListView, server, true);
```

#### AUTO 


```{c}
auto *item = dynamic_cast<LDAPItem *>(mHostListView->currentItem());
```

#### AUTO 


```{c}
auto *item = dynamic_cast<LDAPItem *>(mHostListView->item(i));
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(authbox);
```

#### LAMBDA EXPRESSION 


```{c}
[](QKeychain::Job *baseJob) {
            if (baseJob->error()) {
                qCWarning(LDAPCLIENT_LOG) << "Error writing password using QKeychain:" << baseJob->errorString();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s, const KLDAP::LdapObject &obj) {
        loadData(s, obj);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KLDAP::LdapSearch *s) {
        gotSearchResult(s);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { queryDNClicked(); }
```

#### AUTO 


```{c}
auto below = static_cast<LdapWidgetItem *>(mHostListView->item(mHostListView->row(item) + 1));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(page);
```

#### AUTO 


```{c}
auto authbox = new QWidget(mParent);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->slotDone();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KLDAP::LdapClient *client : qAsConst(mLdapClientList)) {
        if (client->isActive()) {
            return;
        }
    }
```

#### AUTO 


```{c}
auto *below = static_cast<LdapWidgetItem *>(mHostListView->item(mHostListView->row(item) + 1));
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto item = new LdapWidgetItem(mHostListView);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool b) { setSASL(b); }
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool state) {
        d->slotSetScope(state);
    }
```

#### AUTO 


```{c}
auto btgroup = new QGroupBox(i18n("Security"), mParent);
```

#### AUTO 


```{c}
auto *below = static_cast<LDAPItem *>(mHostListView->item(mHostListView->row(item) + 1));
```

#### RANGE FOR STATEMENT 


```{c}
for (LdapModelNode *child : children) {
            if (child->nodeType() == nodeType) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto buttons = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto readJob = new ReadPasswordJob(QStringLiteral("ldapclient"), this);
```

