#### RANGE FOR STATEMENT 


```{c}
for ( const Piece* p : qAsConst(m_pieces) ) {
        if ( p->isEnabled() ) {
            ++remain;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Piece* p : std::as_const(m_pieces) ) {
        if ( p->m_highlighter->isVisible() ) {
            ++marked;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & piece : qAsConst(m_pieces)) {
        removeItem( piece );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Piece* p : std::as_const(m_pieces) ) {
        if ( p->isEnabled() ) {
            ++remain;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Piece* p : qAsConst(m_pieces) ) {
        if ( p->m_highlighter->isVisible() ) {
            ++marked;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { newGame(QRandomGenerator::global()->bounded(RAND_MAX)); }
```

#### AUTO 


```{c}
auto & piece
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & piece : std::as_const(m_pieces)) {
        removeItem( piece );
    }
```

