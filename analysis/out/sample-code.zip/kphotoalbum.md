#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
            auto cluster = subCluster->regionForPoint(pos, viewPortParams);
            if (cluster && !cluster->isEmpty())
                return cluster;
        }
```

#### AUTO 


```{c}
const auto tokensInUse = MainWindow::TokenEditor::tokensInUse();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatchSetting &matcher : categoryMatchSettings) {
        myCategories.append(matcher.DBCategoryName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &newFile : selected()) {
            newFile.info()->addCategoryInfo(Settings::SettingsData::instance()->untaggedCategory(),
                                            Settings::SettingsData::instance()->untaggedTag());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &tag : positionableTagCandidates) {
                    submenu->addAction(createAssociateTagAction(tag));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
            auto cluster = subCluster->regionForPoint(pos);
            if (cluster && !cluster->isEmpty())
                return cluster;
        }
```

#### AUTO 


```{c}
const auto f2tCmd = QString::fromLatin1("ffmpeg2theora -v 7 -o %1 -x %2 %3")
                                    .arg(destName.replace(QRegExp(QString::fromLatin1("\\..*")), QString::fromLatin1(".ogg")))
                                    .arg(QString::fromLatin1("320"))
                                    .arg(fileName.absolute());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
        libvlc_audio_set_mute(m_player, b);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : members) {
                    DB::CategoryPtr catPtr = m_db->m_categoryCollection.categoryForName(categoryName);
                    XMLCategory *category = static_cast<XMLCategory *>(catPtr.data());
                    if (category->idForName(member) == 0)
                        qCWarning(XMLDBLog) << "Member" << member << "in group" << categoryName << "->" << groupMapIt.key() << "has no id!";
                    idList.append(QString::number(category->idForName(member)));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Marble::RenderPlugin *plugin : m_mapWidget->renderPlugins()) {
        if (plugin->renderType() != Marble::RenderPlugin::PanelRenderType) {
            continue;
        }

        const QString name = plugin->name();
        if (!WANTED_FLOATERS.contains(name)) {
            continue;
        }

        QPushButton *button = new QPushButton;
        button->setCheckable(true);
        button->setFlat(true);
        button->setChecked(plugin->action()->isChecked());
        button->setToolTip(plugin->description());
        button->setProperty("floater", name);

        QPixmap icon = plugin->action()->icon().pixmap(QSize(20, 20));
        if (icon.isNull()) {
            icon = QPixmap(20, 20);
            icon.fill(palette().button().color());
        }
        button->setIcon(icon);

        connect(plugin->action(), &QAction::toggled, button, &QPushButton::setChecked);
        connect(button, &QPushButton::toggled, plugin->action(), &QAction::setChecked);
        floatersLayout->addWidget(button);
        const QVariant checked = group.readEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX + name,
                                                 true);
        button->setChecked(checked.toBool());
    }
```

#### AUTO 


```{c}
const auto allAreas = findChildren<TaggedArea *>();
```

#### AUTO 


```{c}
const auto correctFN = FileName::fromRelativePath(relativeFilePath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category: DB::ImageDB::instance()->categoryCollection()->categories()) {
        if(!category->isSpecialCategory()) {
            m_categoryBox->addItem(category->text(), category->name());
            if ( category->name() == QString::fromUtf8("Persons"))
                defaultIndex = index;
            ++index;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& key : sorted ) {
            const int subrow = (count % perCol);
            const QColor color  = (subrow & 1) ? Qt::white : QColor(226, 235, 250);
            QPair<QLabel*, QLabel*> pair = infoLabelPair( exifNameNoGroup( key ), items[key].join( QLatin1String(", ")), color );

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row+subrow, col);
            layout->addWidget(pair.second,row+subrow,col+1);
            count++;
        }
```

#### AUTO 


```{c}
constexpr auto v4IndexHexData {
    "00000004" // version
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A007000670000000000007BAD00001D" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A007000670000000000000000000022" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F" // "blackie.jpg"
};
```

#### AUTO 


```{c}
const auto images = DB::ImageDB::instance()->search(searchInfo);
```

#### LAMBDA EXPRESSION 


```{c}
[&app, returnValue]() { app.exit(returnValue); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const DB::FileName& fileName) {
        return m_imageNameStore[fileName];
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *topLevelCluster : m_geoClusters) {
                const auto subCluster = topLevelCluster->regionForPoint(mapPos);
                if (subCluster && !subCluster->isEmpty()) {
                    qCDebug(MapLog) << "Cluster preselected/clicked.";
                    m_preselectedCluster = subCluster;
                    event->accept();
                    return;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&ret]() -> int { return ret; }
```

#### AUTO 


```{c}
const auto allActions = m_actions->actions();
```

#### CONST EXPRESSION 


```{c}
constexpr int DB_VERSION = 3;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& group : groups ) {
                if ( !countedGroupDict.contains( group ) ) {
                    countedGroupDict.insert( group );
                    (_groupCount[group])++;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->isSpecialCategory()) {
            continue;
        }
        m_categoryBox->addItem(category->name());
        if (category->name() == i18n("People")) {
            defaultIndex = index;
        }
        ++index;
    }
```

#### AUTO 


```{c}
const auto viewPort = viewPortParams.viewLatLonAltBox();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &image : m_images) {
        const Marble::GeoDataCoordinates pos(image->coordinates().lon(), image->coordinates().lat(),
                                             image->coordinates().alt(),
                                             Marble::GeoDataCoordinates::Degree);
        if (viewPort.contains(pos)) {
            if (style == MapStyle::ShowPins) {
                painter->drawPixmap(pos, thumbs.alternatePixmap);
            } else {
                if (!m_scaledThumbnailCache.contains(image)) {
                    QPixmap thumb = thumbs.cache->lookup(image->fileName()).scaled(QSize(MARKER_SIZE_PX, MARKER_SIZE_PX), Qt::KeepAspectRatio);
                    m_scaledThumbnailCache.insert(image, thumb);
                }
                painter->drawPixmap(pos, m_scaledThumbnailCache.value(image));
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const DB::FileName &file) {
                            // Only include unstacked images, and the top of stacked images.
                            // And also exclude videos
                            return DB::ImageDB::instance()->info(file)->stackOrder() > 1 || DB::ImageDB::instance()->info(file)->isVideo();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &members : membersForGroup) {
            if (members.contains(group)) {
                isSubGroup = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QueueType &queue : m_jobs) {
        if (!queue.isEmpty())
            return queue.dequeue();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : qAsConst(members)) {
                    ElementWriter dummy(writer, _member_);
                    writer.writeAttribute(_category_, memberMapIt.key());
                    writer.writeAttribute(_groupname_, groupMapIt.key());
                    writer.writeAttribute(_member_, member);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &filename : qAsConst(m_fileList)) {
            cmdOnce = cmdString;
            cmdOnce.replace(replaceeach, filename.absolute());
            auto *uiParent = MainWindow::Window::theMainWindow();
#if KIO_VERSION <= QT_VERSION_CHECK(5, 69, 0)
            KRun::runCommand(cmdOnce, uiParent);
#else
            KIO::CommandLauncherJob *job = new KIO::CommandLauncherJob(cmdOnce);
            job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, uiParent));
            job->start();
#endif
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& group : groups ) {
        layout->addWidget(headerLabel(group),row++,0,1,4);

        // Items of group
        const QMap<QString,QStringList> items = itemsForGroup( group, map );
        QStringList sorted = items.keys();
        sorted.sort();
        int elements = sorted.size();
        int perCol = (elements + 1) / 2;
        int count = 0;
        for ( const QString& key : sorted ) {
            const int subrow = (count % perCol);
            const QColor color  = (subrow & 1) ? Qt::white : QColor(226, 235, 250);
            QPair<QLabel*, QLabel*> pair = infoLabelPair( exifNameNoGroup( key ), items[key].join( QLatin1String(", ")), color );

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row+subrow, col);
            layout->addWidget(pair.second,row+subrow,col+1);
            count++;
        }
        row += perCol;
    }
```

#### AUTO 


```{c}
auto it = categories.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *child : orMacther->mp_elements) {
            result.append(extractAndMatcher(child));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : fileNameList)
        infoList.append(fileName.info());
```

#### RANGE FOR STATEMENT 


```{c}
for (const DatabaseElement *e : elms) {
            formalList.append(e->queryString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &selectedFile : selected().toStringList(DB::AbsolutePath)) {
            allSelectedFiles << QUrl::fromLocalFile(selectedFile);
        }
```

#### AUTO 


```{c}
auto setToolTip = [this](QWidget *widget, QString tooltip, const char *key) {
        QKeySequence shortcut = m_actions->action(QString::fromLatin1(key))->shortcut();
        if (!shortcut.isEmpty())
            tooltip += QString::fromLatin1(" (%1)").arg(shortcut.toString());
        widget->setToolTip(tooltip);
    };
```

#### AUTO 


```{c}
const auto currentInfo = DB::ImageDB::instance()->info(current);
```

#### RANGE FOR STATEMENT 


```{c}
for (QDockWidget* dock: m_dockWidgets ) {
        if ( dock->isFloating() )
        {
            Debug() << "Showing dock: " << dock->objectName();
            dock->show();
        }
    }
```

#### AUTO 


```{c}
const auto imageDir = QDir { args.first() };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &memberItem : members) {
                    DB::CategoryPtr catPtr = m_db->m_categoryCollection.categoryForName(category);
                    if (!catPtr) { // category was not declared in "Categories"
                        qCWarning(XMLDBLog) << "File corruption in index.xml. Inserting missing category: " << category;
                        catPtr = new XMLCategory(category, QString::fromUtf8("dialog-warning"), DB::Category::TreeView, 32, false);
                        m_db->m_categoryCollection.addCategory(catPtr);
                    }
                    XMLCategory *cat = static_cast<XMLCategory *>(catPtr.data());
                    QString member = cat->nameForId(memberItem.toInt());
                    if (member.isNull()) {
                        qCWarning(XMLDBLog) << "Tag group" << category << "references non-existing tag with id"
                                            << memberItem << "!";
                        continue;
                    }
                    m_db->m_members.addMemberToGroup(category, group, member);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : qAsConst(members)) {
                    ElementWriter dummy(writer, QStringLiteral("member"));
                    writer.writeAttribute(QStringLiteral("category"), memberMapIt.key());
                    writer.writeAttribute(QStringLiteral("group-name"), groupMapIt.key());
                    writer.writeAttribute(QStringLiteral("member"), member);
                }
```

#### CONST EXPRESSION 


```{c}
constexpr int MARKER_SIZE_STEP_PX = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (QString fileName : files) {
        QFile::copy(categoryImagesPath + QString::fromUtf8("/") + fileName,
                    categoryImagesBackupPath + fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fs : filesystemsToRemove) {
            tmpFsMap.remove(fs);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : categories() ) {
        QMap<QString, uint> items = DB::ImageDB::instance()->classify( BrowserPage::searchInfo(), category->name(), DB::anyMediaType );
        m_count[row] = items.count();
        ++row;
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if ( wasCancelled() )
            return false;

        if ( count % cols == 0 ) {
            row = doc.createElement( QString::fromLatin1( "tr" ) );
            row.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-row" ) );
            doc.appendChild( row );
            count = 0;
        }

        col = doc.createElement( QString::fromLatin1( "td" ) );
        col.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-col" ) );
        row.appendChild( col );

        if (first.isEmpty())
            first = namePage( width, height, fileName);
        else
            last = namePage( width, height, fileName);

        if (!Utilities::isVideo(fileName))
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"%4\", \"" ).arg( nameImage( fileName, width ) ).arg( nameImage( fileName, m_setup.thumbSize() )
                        ).arg( nameImage( fileName, maxImageSize() ) ).arg( KMimeType::findByUrl( nameImage(
                                    fileName, maxImageSize() ) )->name() );
        else {
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\"" ).arg( nameImage( fileName, m_setup.thumbSize() ) ).arg( nameImage( fileName, m_setup.thumbSize() ) ).arg( nameImage( fileName, maxImageSize() ) );
            if ( m_setup.html5VideoGenerate() )
                images += QString::fromLatin1( ", \"%1\", \"" ).arg( QString::fromLatin1( "video/ogg" ) );
            else
                images += QString::fromLatin1( ", \"%1\", \"" ).arg( KMimeType::findByPath( fileName.relative(), 0, true)->name() );
            enableVideo = 1;
        }

        // -------------------------------------------------- Description
        if ( !info->description().isEmpty() && m_setup.includeCategory( QString::fromLatin1( "**DESCRIPTION**" )) )
            images += QString::fromLatin1( "%1\", \"" ).arg( info->description().replace( QString::fromLatin1( "\n$" ), QString::fromLatin1( "" ) ).replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) ).replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) ) );
        else
            images += QString::fromLatin1( "\", \"" );
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if ( !description.isEmpty() )
            description = QString::fromLatin1 ( "<ul>%1</ul>" ).arg ( description );
        else
            description = QString::fromLatin1 ( "" );

        description.replace( QString::fromLatin1( "\n$" ), QString::fromLatin1 ( "" ) );
        description.replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) );
        description.replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) );

        images += description;
        images += QString::fromLatin1( "\"]);\n" );

        QDomElement href = doc.createElement( QString::fromLatin1( "a" ) );
        href.setAttribute( QString::fromLatin1( "href" ),
                           namePage( width, height, fileName));
        col.appendChild( href );

        QDomElement img = doc.createElement( QString::fromLatin1( "img" ) );
        img.setAttribute( QString::fromLatin1( "src" ),
                          nameImage( fileName, m_setup.thumbSize() ) );
        img.setAttribute( QString::fromLatin1( "alt" ),
                          nameImage( fileName, m_setup.thumbSize() ) );
        href.appendChild( img );
        ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResizableFrame *area : allAreas) {
        const auto tagData = area->tagData();
        if (tagData.first == category && tagData.second == tag)
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fs : filesystemsToRemove) {
            tmpFsMap.remove( fs );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatch *match : matchers) {
            if (match->m_checkbox->isChecked()) {
                matcher = createCategoryPage(match->m_combobox->currentText(), match->m_text);
                m_matchers.append(matcher);
            }
        }
```

#### AUTO 


```{c}
const auto fileName2 = DB::FileName::fromRelativePath(relativeFilePath2);
```

#### AUTO 


```{c}
const auto subCluster = topLevelCluster->regionForPoint(event->pos(), *viewPortParams);
```

#### AUTO 


```{c}
auto answer = KMessageBox::questionYesNo(this, msg, title, KStandardGuiItem::yes(), KStandardGuiItem::no(), dialogId);
```

#### AUTO 


```{c}
constexpr auto v5IndexHexData {
    "00000005" // version
    "00000100" // v5: thumbnailsize
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
};
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        VideoPlayerSelectorDialog dialog(this);
        dialog.exec();
        m_videoBackend = dialog.backend();
        m_videoBackendButton->setText(videoBackendTextFromEnum(m_videoBackend));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &cacheName : qAsConst(newCache)) {
                    DB::ImageInfoPtr cacheInfo = info(cacheName);
                    cacheInfo->setStackId(0);
                    cacheInfo->setStackOrder(0);
                }
```

#### AUTO 


```{c}
const auto inputFileName = inputUrl.toLocalFile();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : types) {
        const KService::List offers = KMimeTypeTrader::self()->query(type, QLatin1String("Application"));
        for (const KService::Ptr &offer : offers) {
            res.insert(offer);
            m_appToMimeTypeMap[offer->name()].insert(type);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
            m_size += subCluster->size();
        }
```

#### AUTO 


```{c}
auto history = cfgGroup.readEntry(historyEntry, QStringList());
```

#### CONST EXPRESSION 


```{c}
static constexpr int DBVersion();
```

#### AUTO 


```{c}
auto res = std::find_if(list.begin(), list.end(),
                            [&category, &item] (const CategoryItemDetails& candidate) {
        return candidate.name == item;
    } );
```

#### AUTO 


```{c}
auto *label = new QLabel;
```

#### CONST EXPRESSION 


```{c}
constexpr auto v5IndexHexData {
    "00000005" // version
    "000001c4" // v5: thumbnailsize
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A007000670000000000007BAD00001D" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A007000670000000000000000000022" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F" // "blackie.jpg"
};
```

#### AUTO 


```{c}
const auto outsideFN = FileName::fromAbsolutePath(outsidePath);
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : fields )
    {
        fieldList.append( e->columnName() );
    }
```

#### AUTO 


```{c}
auto tags = m_filter.categoryMatchText(category).split(QLatin1String("&"), QString::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : m_sortedList) {
        if (tmp.contains(fileName)) {
            answer << fileName;
            tmp.remove(fileName);
        } else if (tmp.contains(m_path + fileName)) {
            answer << m_path + fileName;
            tmp.remove(m_path + fileName);
        }
    }
```

#### AUTO 


```{c}
const auto mainWindowGeometry = Settings::SettingsData::instance()->windowGeometry(Settings::MainWindow);
```

#### AUTO 


```{c}
constexpr auto CFG_HISTORY { "_crashHistory" };
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(CategoryListResult)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category : ImageDB::instance()->categoryCollection()->categories()) {
        if (category->isSpecialCategory())
            continue;
        for (const auto &tag : category->itemsInclCategories()) {
            if (m_re.match(tag).hasMatch()) {
                m_matchingTags[category->name()] += tag;
            }
        }
    }
```

#### AUTO 


```{c}
auto memIt = membersForGroup.constBegin();
```

#### AUTO 


```{c}
const auto schemeCfg = KSharedConfig::openConfig(schemePath);
```

#### AUTO 


```{c}
auto backends = m_mapWidget->availableBackends();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &image : images) {
        const DB::ImageInfoPtr info = image.info();
        if (!info->isVideo())
            continue;
        // silently ignore videos not (currently) on disk:
        if (!info->fileName().exists())
            continue;
        int length = info->videoLength();
        if (length == -1) {
            BackgroundTaskManager::JobManager::instance()->addJob(
                new BackgroundJobs::ReadVideoLengthJob(info->fileName(), BackgroundTaskManager::BackgroundVideoPreviewRequest));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (StringSet &items : groupMap) {
        items.remove(name);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (!shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, QString::fromUtf8("Category"));
        writer.writeAttribute(QString::fromUtf8("name"), name);
        writer.writeAttribute(QString::fromUtf8("icon"), category->iconName());
        writer.writeAttribute(QString::fromUtf8("show"), QString::number(category->doShow()));
        writer.writeAttribute(QString::fromUtf8("viewtype"), QString::number(category->viewType()));
        writer.writeAttribute(QString::fromUtf8("thumbnailsize"), QString::number(category->thumbnailSize()));
        writer.writeAttribute(QString::fromUtf8("positionable"), QString::number(category->positionable()));
        if (category == tokensCategory) {
            writer.writeAttribute(QString::fromUtf8("meta"), QString::fromUtf8("tokens"));
        }

        // FIXME (l3u):
        // Correct me if I'm wrong, but we don't need this, as the tags used as groups are
        // added to the respective category anyway when they're created, so there's no need to
        // re-add them here. Apart from this, adding an empty group (one without members) does
        // add an empty tag ("") doing so.
        /*
        QStringList list =
                Utilities::mergeListsUniqly(category->items(),
                                            m_db->_members.groups(name));
        */

        const auto categoryItems = category->items();
        for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), tagName);
            writer.writeAttribute(QString::fromLatin1("id"),
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(QString::fromUtf8("birthDate"), birthDate.toString(Qt::ISODate));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QRadioButton *candidate = nullptr;
        switch (backend) {
        case VideoBackend::Phonon:
            candidate = m_phonon;
            break;
        case VideoBackend::QtAV:
            candidate = m_qtav;
            break;
        case VideoBackend::VLC:
            candidate = m_vlc;
            break;
        default:
            Q_UNREACHABLE();
        }
        return candidate;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : categories() ) {
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( BrowserPage::searchInfo(), category->name(), DB::Image );
        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( BrowserPage::searchInfo(), category->name(), DB::Video );
        DB::MediaCount count( images.count(), videos.count() );
        _count[row] = count;
        ++row;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : info->itemsOfCategory(m_category))
        if (!matchedTags[m_category].contains(item))
            return false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ListSelect *ls : qAsConst(m_optionList)) {
            if (!(changedOptions(ls).isEmpty()))
                return true;
        }
```

#### AUTO 


```{c}
const auto allImages = DB::ImageDB::instance()->files();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto tag : selectedTags) {
                bool alreadyAssociated = false;

                for (ResizableFrame* area : allAreas) {
                    if (area->tagData().first == category && area->tagData().second == tag) {
                        alreadyAssociated = true;
                        break;
                    }
                }

                if (! alreadyAssociated) {
                    addTagToCandidateList(category, tag);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_list)) {
        DB::ImageInfoPtr info = fileName.info();
        // Skipping images that do not have exact time stamp
        if (info->date().start() != info->date().end())
            continue;
        if (prev && (prev->date().start().secsTo(info->date().start()) < m_continuousThreshold->value())) {
            DB::FileNameList stack;

            if (!DB::ImageDB::instance()->getStackFor(prev->fileName()).isEmpty()) {
                if (m_autostackUnstack->isChecked())
                    DB::ImageDB::instance()->unstack(DB::FileNameList() << prev->fileName());
                else if (m_autostackSkip->isChecked())
                    continue;
            }

            if (!DB::ImageDB::instance()->getStackFor(fileName).isEmpty()) {
                if (m_autostackUnstack->isChecked())
                    DB::ImageDB::instance()->unstack(DB::FileNameList() << fileName);
                else if (m_autostackSkip->isChecked())
                    continue;
            }

            stack.append(prev->fileName());
            stack.append(info->fileName());
            if (!toBeShown.isEmpty()) {
                if (toBeShown.at(toBeShown.size() - 1).info()->fileName() != prev->fileName())
                    toBeShown.append(prev->fileName());
            } else {
                // if this is first insert, we have to include also the stacked images from previuous image
                if (!DB::ImageDB::instance()->getStackFor(info->fileName()).isEmpty()) {
                    const auto stackedImages = DB::ImageDB::instance()->getStackFor(prev->fileName());
                    for (const DB::FileName &a : stackedImages)
                        toBeShown.append(a);
                } else
                    toBeShown.append(prev->fileName());
            }
            // Inserting stacked images from the current image
            if (!DB::ImageDB::instance()->getStackFor(info->fileName()).isEmpty()) {
                const auto stackedImages = DB::ImageDB::instance()->getStackFor(fileName);
                for (const DB::FileName &a : stackedImages)
                    toBeShown.append(a);
            } else
                toBeShown.append(info->fileName());
            DB::ImageDB::instance()->stack(stack);
        }

        prev = info;
    }
```

#### AUTO 


```{c}
auto *exifWidgetLayout = new QVBoxLayout(exifWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
        ImageInfoPtr iInfo = info(fileName);

        ImageDate::MatchType match = iInfo->date().isIncludedIn(range);
        if (match == DB::ImageDate::ExactMatch || (includeRanges && match == DB::ImageDate::RangeMatch)) {
            if (candidate.isNull() || iInfo->date().start() < candidateDateStart) {
                candidate = fileName;
                // Looking at this, can't this just be iInfo->date().start()?
                // Just in the middle of refactoring other stuff, so leaving
                // this alone now. TODO(hzeller): revisit.
                candidateDateStart = info(candidate)->date().start();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &categoryName: items)
            {
                if ( !alreadyMatched.contains(categoryName) ) // We do not want to match "Jesper & Jesper"
                    map[categoryName].add(imageInfo->date());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( QTreeWidgetItem* item: items ) {
        QTreeWidgetItem* parent = item->parent();
        QString parentText = parent ? parent->text(0) : QString();
        selected.insert( CategoryListView::DragItemInfo( parentText, item->text(0) ) );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[imageId,size,type,timer,client, this] () {
        ThumbnailRequest request(imageId, size, type);

        RemoteInterface::instance().sendCommand(request);

        RequestType key = qMakePair(imageId,type);
        m_requestMap.insert(key, client);
        m_reverseRequestMap.insert(client, key);

        connect(client, &QObject::destroyed, this, &ImageStore::clientDeleted);
        timer->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        area->setVisible(showAreas);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SeekInfo &info : list) {
        if (count++ == 5) {
            QAction *sep = new QAction(menu);
            sep->setSeparator(true);
            menu->addAction(sep);
        }

        QAction *seek = m_actions->addAction(QString::fromLatin1(info.name), m_videoDisplay, &VideoDisplay::seek);
        seek->setText(info.title);
        seek->setData(info.value);
        seek->setShortcut(info.key);
        m_actions->setShortcutsConfigurable(seek, false);
        menu->addAction(seek);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this,categoryName] (const QString itemName) {
            return m_imageNameStore.idForCategory(categoryName,itemName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
        const QString mappedFile = nameMap->uniqNameFor(fileName);
        QDomElement elm = save(doc, fileName.info());
        elm.setAttribute(QString::fromLatin1("file"), mappedFile);
        top.appendChild(elm);
    }
```

#### AUTO 


```{c}
auto filename
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *topLevelCluster : m_geoClusters) {
                const auto subCluster = topLevelCluster->regionForPoint(mapPos);
                // Note(jzarl) unfortunately we cannot use QWidget::setCursor here
                if (subCluster) {
                    QGuiApplication::setOverrideCursor(Qt::ArrowCursor);
                } else {
                    QGuiApplication::restoreOverrideCursor();
                }
            }
```

#### AUTO 


```{c}
const auto absoluteFilePath1 = m_tmpDir.filePath(relativeFilePath1);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            short rating = i * 2;
            if (static_cast<short>(m_rating->rating()) == rating)
                rating = -1;
            emit ratingChanged(rating);
        }
```

#### AUTO 


```{c}
const auto &categoryName
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexSelection) {
        const DB::FileName currFileName = model()->imageAt(index.row());
        bool includeAllStacks = false;
        switch (mode) {
        case IncludeAllStacks:
            includeAllStacks = true;
            /* FALLTHROUGH */
        case ExpandCollapsedStacks: {
            // if the selected image belongs to a collapsed thread,
            // imply that all images in the stack are selected:
            DB::ImageInfoPtr imageInfo = currFileName.info();
            if (imageInfo && imageInfo->isStacked()
                && (includeAllStacks || !model()->isItemInExpandedStack(imageInfo->stackId()))) {
                // add all images in the same stack
                res.append(DB::ImageDB::instance()->getStackFor(currFileName));
            } else
                res.append(currFileName);
        } break;
        case NoExpandCollapsedStacks:
            res.append(currFileName);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Marble::RenderPlugin *plugin : m_mapWidget->renderPlugins()) {
        if (plugin->renderType() != Marble::RenderPlugin::PanelRenderType) {
            continue;
        }

        const QString name = plugin->nameId();
        if (!WANTED_FLOATERS.contains(name)) {
            continue;
        }

        QPushButton *button = new QPushButton;
        button->setCheckable(true);
        button->setFlat(true);
        button->setChecked(plugin->action()->isChecked());
        button->setToolTip(plugin->description());
        button->setProperty("floater", name);

        QPixmap icon = plugin->action()->icon().pixmap(QSize(20, 20));
        if (icon.isNull()) {
            icon = QPixmap(20, 20);
            icon.fill(palette().button().color());
        }
        button->setIcon(icon);

        connect(plugin->action(), &QAction::toggled, button, &QPushButton::setChecked);
        connect(button, &QPushButton::toggled, plugin->action(), &QAction::setChecked);
        floatersLayout->addWidget(button);
        const QVariant checked = group.readEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX + name,
                                                 true);
        button->setChecked(checked.toBool());
    }
```

#### AUTO 


```{c}
const auto filename = QStringLiteral("filename.jpg");
```

#### AUTO 


```{c}
const auto cacheFile = fileNameForIndex(i);
```

#### AUTO 


```{c}
auto answer = uiDelegate().questionYesNo(logMsg, txt, i18n("Trust Time Stamps?"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString& word) { return word.startsWith( _text.toLower()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (DuplicateMatch *selector : qAsConst(m_selectors)) {
        selector->execute(method);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &filename : qAsConst(m_fileList)) {
            cmdOnce = cmdString;
            cmdOnce.replace(replaceeach, filename.absolute());
            KRun::runCommand(cmdOnce, MainWindow::Window::theMainWindow());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* child : orMacther->mp_elements) {
            result.append( extractAndMatcher( child ) );
        }
```

#### AUTO 


```{c}
const auto emptyString = QString();
```

#### AUTO 


```{c}
auto& areasOfCategory
```

#### RANGE FOR STATEMENT 


```{c}
for (const DockPair &pair : m_docks) {
        QDockWidget *dock = pair.first;
        QWidget *widget = pair.second;
        QString title = dock->windowTitle();
        for (int index = 0; index < title.length(); ++index) {
            const QChar ch = title[index].toLower();
            if (!m_taken.contains(ch)) {
                m_taken.insert(ch);
                dock->setWindowTitle(title.left(index) + QString::fromLatin1("&") + title.mid(index));
                new QShortcut(QString::fromLatin1("Alt+") + ch, widget, SLOT(setFocus()));
                break;
            }
        }
    }
```

#### AUTO 


```{c}
const auto *cluster
```

#### AUTO 


```{c}
const auto fileName1 = DB::FileName::fromRelativePath(relativeFilePath1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &categoryName : info->availableCategories()) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(categoryName);
        CategoryItemDetailsList list;
        for (const QString &item : info->itemsOfCategory(categoryName)) {
            const QString age = Utilities::formatAge(category, item, info);
            list.append(CategoryItemDetails(item, age));
        }
        result.categories[categoryName] = list;
    }
```

#### AUTO 


```{c}
const auto &name
```

#### AUTO 


```{c}
const auto untaggedTag = Settings::SettingsData::instance()->untaggedTag();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selectedFiles) {
        if (Utilities::isVideo(fileName))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_thumbnailsToBuild) {
        m_preloadQueue->enqueue(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QCheckBox *box : qAsConst(m_checkBoxes)) {
        box->setChecked(false);
        QString txt = box->text().remove(QString::fromLatin1("&"));
        box->setEnabled(tokens.contains(txt));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : grps) {
        if (!shouldSaveCategory(name))
            continue;

        ElementWriter categoryElm(writer, QStringLiteral("option"), false);

#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
        const auto itemsOfCategory = info->itemsOfCategory(name);
        QStringList items(itemsOfCategory.begin(), itemsOfCategory.end());
#else
        QStringList items = info->itemsOfCategory(name).toList();
#endif
        std::sort(items.begin(), items.end());
        if (!items.isEmpty()) {
            topElm.writeStartElement();
            categoryElm.writeStartElement();
            writer.writeAttribute(QStringLiteral("name"), name);
        }

        for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, QStringLiteral("value"));
            writer.writeAttribute(QStringLiteral("value"), itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(QStringLiteral("area"), areaToString(area));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject* obj : list ) {
        QWidget* current = static_cast<QWidget*>( obj );
        if ( !current->property("WantsFocus").isValid() || !current->isVisible() )
            continue;

        int cx = current->mapToGlobal( QPoint(0,0) ).x();
        int cy = current->mapToGlobal( QPoint(0,0) ).y();

        bool inserted = false;
        // Iterate through the ordered list of widgets, and insert the current one, so it is in the right position in the tab chain.
        for( QList<QWidget*>::Iterator orderedIt = orderedList.begin(); orderedIt != orderedList.end(); ++orderedIt ) {
            const QWidget* w = *orderedIt;
            int wx = w->mapToGlobal( QPoint(0,0) ).x();
            int wy = w->mapToGlobal( QPoint(0,0) ).y();

            if ( wy > cy || ( wy == cy && wx >= cx ) ) {
                orderedList.insert( orderedIt, current );
                inserted = true;
                break;
            }
        }
        if (!inserted)
            orderedList.append( current );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &block : qAsConst(blockList)) {
        ElementWriter dummy(writer, QStringLiteral("block"));
        writer.writeAttribute(QStringLiteral("file"), block.relative());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatchSetting &match : matches) {
        QString XMLCategoryName = match.XMLCategoryName();
        QString DBCategoryName = match.DBCategoryName();
        ImportSettings::ImportAction action = m_settings.importAction(DBCategoryName);

        const Utilities::StringSet items = XMLInfo->itemsOfCategory(XMLCategoryName);
        DB::CategoryPtr DBCategoryPtr = DB::ImageDB::instance()->categoryCollection()->categoryForName(DBCategoryName);

        if (!forceReplace && action == ImportSettings::Replace)
            DBInfo->setCategoryInfo(DBCategoryName, Utilities::StringSet());

        if (action == ImportSettings::Merge || action == ImportSettings::Replace || forceReplace) {
            for (const QString &item : items) {
                if (match.XMLtoDB().contains(item)) {
                    DBInfo->addCategoryInfo(DBCategoryName, match.XMLtoDB()[item]);
                    DBCategoryPtr->addItem(match.XMLtoDB()[item]);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString str : andParts) {
                static const QRegExp regexp(QString::fromLatin1("^\\s*!\\s*(.*)$"));
                if (regexp.exactMatch(str)) { // str is preceded with NOT
                    negate = true;
                    str = regexp.cap(1);
                }
                str = str.trimmed();
                CategoryMatcher *valueMatcher;
                if (str == ImageDB::NONE()) { // mark AND-group as containing a "No other" condition
                    exactMatch = true;
                    continue;
                } else {
                    valueMatcher = new DB::ValueCategoryMatcher(category, str);
                    if (negate) {
                        valueMatcher = new DB::NegationCategoryMatcher(valueMatcher);
                        negate = false;
                    }
                }
                andMatcher->addElement(valueMatcher);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const CategoryMatchSetting& match : matches ) {
        QString XMLCategoryName = match.XMLCategoryName();
        QString DBCategoryName = match.DBCategoryName();
        ImportSettings::ImportAction action = m_settings.importAction(DBCategoryName);

        const Utilities::StringSet items = XMLInfo->itemsOfCategory(XMLCategoryName);
        DB::CategoryPtr DBCategoryPtr =  DB::ImageDB::instance()->categoryCollection()->categoryForName( DBCategoryName );

        if ( !forceReplace && action == ImportSettings::Replace )
            DBInfo->setCategoryInfo( DBCategoryName, Utilities::StringSet() );

        if ( action == ImportSettings::Merge || action == ImportSettings::Replace || forceReplace ) {
            for ( const QString& item : items ) {
                if (match.XMLtoDB().contains( item ) ) {
                    DBInfo->addCategoryInfo( DBCategoryName, match.XMLtoDB()[item] );
                    DBCategoryPtr->addItem( match.XMLtoDB()[item] );
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : search(searchInfo)) {
        if ( info(fileName)->mediaType() == Image )
            ++images;
        else
            ++videos;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString comment : commentsToStrip) {
        // separate comments with "-,-" and escape existing commas by doubling
        if (!comment.isEmpty())
            commentsToStripString += comment.replace(QString::fromLatin1(","), QString::fromLatin1(",,")) + QString::fromLatin1("-,-");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DatabaseElement *element : allElements) {
        attributes.append(element->createString());
    }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, _value_);
            writer.writeAttribute(_value_, tagName);
            writer.writeAttribute(_id_,
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(_birthdate_, birthDate.toString(Qt::ISODate));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : m_fileList) {
        QString dir = getDirName(fileName);
        if (!dirMap.contains(dir)) {
            StringSet newDir;
            dirMap.insert(dir, newDir);
            dirList << dir;
        }
        dirMap[dir] << fileName;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto v5IndexHexData {
    "00000005" // version
    "000001c4" // v5: thumbnailsize
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
};
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : GpsElements())
        {
            query.prepare( QString::fromLatin1( "alter table exif add column %1")
                           .arg( e->createString()) );
            if ( !query.exec())
                showError( query );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &currentTag : qAsConst(tagpath)) {
                        if (!cat->items().contains(currentTag)) {
                            qCDebug(PluginsLog) << "Adding tag " << currentTag << " to category " << categoryName;
                            // before we can use a tag, we have to add it
                            cat->addItem(currentTag);
                        }
                        if (!previousTag.isNull()) {
                            if (!memberMap.isGroup(categoryName, previousTag)) {
                                // create a group for the parent tag, so we can add a sub-category
                                memberMap.addGroup(categoryName, previousTag);
                            }
                            if (memberMap.canAddMemberToGroup(categoryName, previousTag, currentTag)) {
                                // make currentTag a member of the previousTag group
                                memberMap.addMemberToGroup(categoryName, previousTag, currentTag);
                            } else {
                                qCWarning(PluginsLog) << "Cannot make " << currentTag << " a subcategory of "
                                                      << categoryName << "/" << previousTag << "!";
                            }
                        }
                        previousTag = currentTag;
                    }
```

#### AUTO 


```{c}
constexpr auto v4IndexHexData {
    "00000004" // version
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &categoryName : positionableCategories) {
        m_defaultAreaCategory->addItem(categoryName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryItem *item : qAsConst(m_deletedCategories)) {
        item->removeFromDatabase();
    }
```

#### AUTO 


```{c}
auto res = std::find_if(list.begin(), list.end(),
                            [&category, &item](const CategoryItemDetails &candidate) {
                                return candidate.name == item;
                            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &infoPtr : qAsConst(list)) {
            save(writer, infoPtr);
        }
```

#### AUTO 


```{c}
const auto selectionCount = selected().count();
```

#### CONST EXPRESSION 


```{c}
constexpr int TERMINATION_WAIT_MS = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        if (category->isSpecialCategory()) {
            continue;
        }

        // Add the real categories as top-level items
        QTreeWidgetItem *topLevelItem = new QTreeWidgetItem;
        topLevelItem->setText(0, category->name());
        topLevelItem->setFlags(topLevelItem->flags() & Qt::ItemIsEnabled);
        QFont font = topLevelItem->font(0);
        font.setWeight(QFont::Bold);
        topLevelItem->setFont(0, font);
        m_categoryTreeWidget->addTopLevelItem(topLevelItem);

        // Build a map with all members for each group
        QMap<QString, QStringList> membersForGroup;
        const QStringList allGroups = m_memberMap.groups(category->name());
        foreach (const QString &group, allGroups) {
            // FIXME: Why does the member map return an empty category?!
            if (group.isEmpty()) {
                continue;
            }

            QStringList allMembers = m_memberMap.members(category->name(), group, true);
            membersForGroup[group] = allMembers;
        }

        // Add all groups (their sub-groups will be added recursively)
        addSubCategories(topLevelItem, membersForGroup, allGroups);
    }
```

#### AUTO 


```{c}
auto cluster = subCluster->regionForPoint(pos, viewPortParams);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : qAsConst(orderedList)) {
        if (prev) {
            setTabOrder(prev, widget);
        } else {
            first = widget;
        }
        prev = widget;
    }
```

#### AUTO 


```{c}
const auto info = DB::ImageDB::instance()->info(image);
```

#### AUTO 


```{c}
const auto backendName = backendEnum.valueToKey(static_cast<int>(Settings::SettingsData::instance()->videoBackend()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        const QString categoryName = category->name();
        if (category->doShow()) {
            StringSet items = info->itemsOfCategory(categoryName);

            if (DB::ImageDB::instance()->untaggedCategoryFeatureConfigured()
                && !Settings::SettingsData::instance()->untaggedImagesTagVisible()) {

                if (categoryName == Settings::SettingsData::instance()->untaggedCategory()) {
                    if (items.contains(Settings::SettingsData::instance()->untaggedTag())) {
                        items.remove(Settings::SettingsData::instance()->untaggedTag());
                    }
                }
            }

            if (!items.empty()) {
                QString title = QString::fromUtf8("<b>%1: </b> ").arg(category->name());
                QString infoText;
                bool first = true;
                for (const QString &item : qAsConst(items)) {
                    if (first)
                        first = false;
                    else
                        infoText += QString::fromLatin1(", ");

                    if (linkMap) {
                        ++link;
                        (*linkMap)[link] = QPair<QString, QString>(categoryName, item);
                        infoText += QString::fromLatin1("<a href=\"%1\">%2</a>").arg(link).arg(item);
                        infoText += formatAge(category, item, info);
                    } else
                        infoText += item;
                }
                AddNonEmptyInfo(title, infoText, &result);
            }
        }
    }
```

#### AUTO 


```{c}
const auto someImageFileName = DB::FileName::fromRelativePath(QStringLiteral("someImage.jpg"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &existingTag : tags) {
        if (tag == existingTag.trimmed()) {
            qCDebug(ThumbnailViewLog) << "Filter removed: category(" << category << "," << tag << ")";
            tags.removeAll(existingTag);
            m_filter.setCategoryMatchText(category, tags.join(QLatin1String(" & ")));
            m_filter.checkIfNull();
            emit filterChanged(m_filter);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DatabaseElement *e : fields) {
        fieldList.append(e->columnName());
    }
```

#### AUTO 


```{c}
const auto message = i18n(
                    "<p>It seems that KPhotoAlbum previously crashed during video playback. "
                    "On some platforms, this is a common problem with some video players.</p>"
                    "<p>Press <i>Continue</i> to let KPhotoAlbum try a different backend...</p>");
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        if (Utilities::isVideo(fileName))
            update(fileName, direction);
    }
```

#### AUTO 


```{c}
const auto backendEnum = QMetaEnum::fromType<Settings::VideoBackend>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QCheckBox *box : qAsConst(m_checkBoxes)) {
        box->setChecked(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto tag : selectedTags ) {
                QRect area = _editList[_current].areaForTag(category, tag);
                if (area.isNull()) {
                    // no associated area yet
                    addTagToCandidateList(category, tag);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &areasOfCategory : m_taggedAreas) {
            for (auto &area : areasOfCategory) {
                QRect rotatedArea;

                // parameter order for QRect::setCoords:
                // setCoords( left, top, right, bottom )
                // keep in mind that _size is already transposed
                switch (degrees) {
                case 90:
                    rotatedArea.setCoords(
                        m_size.width() - area.bottom(),
                        area.left(),
                        m_size.width() - area.top(),
                        area.right());
                    break;
                case 180:
                    rotatedArea.setCoords(
                        m_size.width() - area.right(),
                        m_size.height() - area.bottom(),
                        m_size.width() - area.left(),
                        m_size.height() - area.top());
                    break;
                case 270:
                    rotatedArea.setCoords(
                        area.top(),
                        m_size.height() - area.right(),
                        area.bottom(),
                        m_size.height() - area.left());
                    break;
                default:
                    // degrees==0; "odd" values won't happen.
                    rotatedArea = area;
                    break;
                }

                // update _taggedAreas[category][tag]:
                area = rotatedArea;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : _setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if ( wasCanceled() )
            return false;

        if ( count % cols == 0 ) {
            row = doc.createElement( QString::fromLatin1( "tr" ) );
            row.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-row" ) );
            doc.appendChild( row );
            count = 0;
        }

        col = doc.createElement( QString::fromLatin1( "td" ) );
        col.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-col" ) );
        row.appendChild( col );

        if (first.isEmpty())
            first = namePage( width, height, fileName);
        else
            last = namePage( width, height, fileName);

    if (!Utilities::isVideo(fileName))
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"" )
                  .arg( nameImage( fileName, width ) ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, maxImageSize() ) );
    else
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"" )
                    .arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( QFileInfo(fileName.absolute()).fileName() );

        // -------------------------------------------------- Description
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if ( !description.isEmpty() )
            description = QString::fromLatin1 ( "<ul>%1</ul>" ).arg ( description );
        else
            description = QString::fromLatin1 ( "" );

        description.replace( QString::fromLatin1( "\n$" ), QString::fromLatin1 ( "" ) );
        description.replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) );
        description.replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) );

        images += description;
        images += QString::fromLatin1( "\"]);\n" );

        QDomElement href = doc.createElement( QString::fromLatin1( "a" ) );
        href.setAttribute( QString::fromLatin1( "href" ),
                           namePage( width, height, fileName));
        col.appendChild( href );

        QDomElement img = doc.createElement( QString::fromLatin1( "img" ) );
        img.setAttribute( QString::fromLatin1( "src" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        img.setAttribute( QString::fromLatin1( "alt" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        href.appendChild( img );
        ++count;
    }
```

#### AUTO 


```{c}
auto history = cfgGroup.readEntry(historyEntry, QList<QByteArray>());
```

#### AUTO 


```{c}
const auto currentTagData = m_area->tagData();
```

#### LAMBDA EXPRESSION 


```{c}
[](QPair<QString, QRect> a, QPair<QString, QRect> b) { return a.first < b.first; }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (!shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, QString::fromUtf8("Category"));
        writer.writeAttribute(QString::fromUtf8("name"), name);
        writer.writeAttribute(QString::fromUtf8("icon"), category->iconName());
        writer.writeAttribute(QString::fromUtf8("show"), QString::number(category->doShow()));
        writer.writeAttribute(QString::fromUtf8("viewtype"), QString::number(category->viewType()));
        writer.writeAttribute(QString::fromUtf8("thumbnailsize"), QString::number(category->thumbnailSize()));
        writer.writeAttribute(QString::fromUtf8("positionable"), QString::number(category->positionable()));
        if (category == tokensCategory) {
            writer.writeAttribute(QString::fromUtf8("meta"), QString::fromUtf8("tokens"));
        }

        // FIXME (l3u):
        // Correct me if I'm wrong, but we don't need this, as the tags used as groups are
        // added to the respective category anyway when they're created, so there's no need to
        // re-add them here. Apart from this, adding an empty group (one without members) does
        // add an empty tag ("") doing so.
        /*
        QStringList list =
                Utilities::mergeListsUniqly(category->items(),
                                            m_db->_members.groups(name));
        */

        Q_FOREACH (const QString &tagName, category->items()) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), tagName);
            writer.writeAttribute(QString::fromLatin1("id"),
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(QString::fromUtf8("birthDate"), birthDate.toString(Qt::ISODate));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(CategoryItemsResult)
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_BOTTOM = 0b00000010;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto filename : imageList) {
        m_list.removeAll(filename);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int BUF_SIZE = 64;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Category& category : categories) {
        stream << category.name << category.text << category.enabled << (int) category.viewType;
        encodeImageWithTransparentPixels(stream, category.icon);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        const QString categoryName = category->name();
        if (category->doShow()) {
            StringSet items = info->itemsOfCategory(categoryName);

            if (Settings::SettingsData::instance()->hasUntaggedCategoryFeatureConfigured()
                && !Settings::SettingsData::instance()->untaggedImagesTagVisible()) {

                if (categoryName == Settings::SettingsData::instance()->untaggedCategory()) {
                    if (items.contains(Settings::SettingsData::instance()->untaggedTag())) {
                        items.remove(Settings::SettingsData::instance()->untaggedTag());
                    }
                }
            }

            if (!items.empty()) {
                QString title = QString::fromUtf8("<b>%1: </b> ").arg(category->name());
                QString infoText;
                bool first = true;
                for (const QString &item : qAsConst(items)) {
                    if (first)
                        first = false;
                    else
                        infoText += QString::fromLatin1(", ");

                    if (linkMap) {
                        ++link;
                        (*linkMap)[link] = QPair<QString, QString>(categoryName, item);
                        infoText += QString::fromLatin1("<a href=\"%1\">%2</a>").arg(link).arg(item);
                        infoText += formatAge(category, item, info);
                    } else
                        infoText += item;
                }
                AddNonEmptyInfo(title, infoText, &result);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &info : list) {
        if (!DB::ImageDB::instance()->md5Map()->contains(info->MD5Sum()))
            continue;

        const DB::FileName name = DB::ImageDB::instance()->md5Map()->lookup(info->MD5Sum());
        DB::ImageInfoPtr other = DB::ImageDB::instance()->info(name);
        if (info->label() != other->label())
            res.label = true;
        if (info->description() != other->description())
            res.description = true;

        if (info->angle() != other->angle())
            res.orientation = true;

        if (info->date() != other->date())
            res.date = true;

        const auto categoryMatchSettings = settings.categoryMatchSetting();
        for (const CategoryMatchSetting &matcher : categoryMatchSettings) {
            const QString XMLFileCategory = matcher.XMLCategoryName();
            const QString DBCategory = matcher.DBCategoryName();
            if (mapCategoriesToDB(matcher, info->itemsOfCategory(XMLFileCategory)) != other->itemsOfCategory(DBCategory))
                res.categories[DBCategory] = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : qAsConst(members)) {
                    ElementWriter dummy(writer, QString::fromLatin1("member"));
                    writer.writeAttribute(QString::fromLatin1("category"), memberMapIt.key());
                    writer.writeAttribute(QString::fromLatin1("group-name"), groupMapIt.key());
                    writer.writeAttribute(QString::fromLatin1("member"), member);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel* label : m_labelWidgets) {
        const QString title = label->text();
        for ( int index = 0; index < title.length(); ++index ) {
            const QChar ch = title[index].toLower();
            if ( !m_taken.contains(ch) ) {
                m_taken.insert( ch );
                label->setText( title.left(index) + QString::fromLatin1("&") + title.mid(index) );
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto map = MainWindow::Window::theMainWindow()->positionBrowserWidget();
```

#### AUTO 


```{c}
const auto tag
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elements() )
    {
        query->bindValue( i++, e->valueFromExif(data));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : DB::ImageDB::instance()->images()) {
        m_lastId++;
        m_idToNameMap.insert(m_lastId,fileName);
        m_nameToIdMap.insert(fileName,m_lastId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &cacheName : qAsConst(newCache)) {
                    DB::ImageInfoPtr cacheInf = cacheName.info();
                    cacheInf->setStackId(0);
                    cacheInf->setStackOrder(0);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (TaggedArea *area : areas) {
        const QRect actualGeometry = area->actualGeometry();
        QRect screenGeometry;

        screenGeometry.setWidth(actualGeometry.width() * scaleWidth);
        screenGeometry.setHeight(actualGeometry.height() * scaleHeight);
        screenGeometry.moveTo(
            actualGeometry.left() * scaleWidth + outerOffsetLeft + innerOffsetLeft,
            actualGeometry.top() * scaleHeight + outerOffsetTop + innerOffsetTop);

        area->setGeometry(screenGeometry);
    }
```

#### AUTO 


```{c}
auto *action = new QAction(title);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : DB::ImageDB::instance()->images()) {
        loadedFiles.insert(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(items)) {
        const int imageCount = m_images.contains(name) ? m_images[name].count : 0;
        const int videoCount = m_videos.contains(name) ? m_videos[name].count : 0;

        if (imageCount + videoCount > 0)
            m_items.append(name);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
        const QString mappedFile = nameMap->uniqNameFor(fileName);
        const auto info = DB::ImageDB::instance()->info(fileName);
        QDomElement elm = save(doc, info);
        elm.setAttribute(QString::fromLatin1("file"), mappedFile);
        top.appendChild(elm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString tag : category->items()) {
        if (! groups.contains(tag)) {
            tags << tag;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl url : list)
        thumbnail( url, size );
```

#### AUTO 


```{c}
const auto closure = calculateClosure(resultSoFar, category, *it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : tagspaths) {
                qCDebug(PluginsLog) << "Adding tags: " << path;
                QStringList tagpath = path.split(QLatin1String("/"), QString::SkipEmptyParts);
                // Note: maybe tagspaths with only one component or with unknown first component
                //  should be added to the "keywords"/"Events" category?
                if (tagpath.size() < 2) {
                    qCWarning(PluginsLog) << "Ignoring incompatible tag: " << path;
                    continue;
                }

                // first component is the category,
                const QString categoryName = tagpath.takeFirst();
                DB::CategoryPtr cat = categories->categoryForName(categoryName);
                if (cat) {
                    QString previousTag;
                    // last component is the tag:
                    // others define hierarchy:
                    for (const QString &currentTag : qAsConst(tagpath)) {
                        if (!cat->items().contains(currentTag)) {
                            qCDebug(PluginsLog) << "Adding tag " << currentTag << " to category " << categoryName;
                            // before we can use a tag, we have to add it
                            cat->addItem(currentTag);
                        }
                        if (!previousTag.isNull()) {
                            if (!memberMap.isGroup(categoryName, previousTag)) {
                                // create a group for the parent tag, so we can add a sub-category
                                memberMap.addGroup(categoryName, previousTag);
                            }
                            if (memberMap.canAddMemberToGroup(categoryName, previousTag, currentTag)) {
                                // make currentTag a member of the previousTag group
                                memberMap.addMemberToGroup(categoryName, previousTag, currentTag);
                            } else {
                                qCWarning(PluginsLog) << "Cannot make " << currentTag << " a subcategory of "
                                                      << categoryName << "/" << previousTag << "!";
                            }
                        }
                        previousTag = currentTag;
                    }
                    qCDebug(PluginsLog) << "Adding tag " << previousTag << " in category " << categoryName
                                        << " to image " << m_info->label();
                    // previousTag must be a valid category (see addItem() above...)
                    m_info->addCategoryInfo(categoryName, previousTag);
                } else {
                    qCWarning(PluginsLog) << "Unknown category: " << categoryName;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto item : container ) {
        res += fn(item);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto CFG_GROUP { "CrashInfo" };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        if (!m_idMap.contains(group))
            setIdMapping(group, ++i);
    }
```

#### AUTO 


```{c}
const auto categoryCollection = DB::ImageDB::instance()->categoryCollection();
```

#### AUTO 


```{c}
auto tags = m_filter.categoryMatchText(category).split(QString::fromLatin1("&"), QString::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &infoPtr : clipBoardImages) {
        list.append(infoPtr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *bin : m_geoClusters) {
        bin->render(painter, *viewPortParams, thumbs, m_showThumbnails ? MapStyle::ShowThumbnails : MapStyle::ShowPins);
    }
```

#### AUTO 


```{c}
auto cfgGroup = KSharedConfig::openConfig()->group(CFG_GROUP);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        if (!category->isSpecialCategory()) {
            bool categoryMenuEnabled = false;
            const QString categoryName = category->name();
            QMenu *categoryMenu = new QMenu(this);
            categoryMenu->setTitle(category->name());

            // add category members
            const Utilities::StringSet members = m_imageInfo->itemsOfCategory(categoryName);
            for (const QString &member : members) {
                QAction *action = categoryMenu->addAction(member);
                action->setObjectName(categoryName);
                action->setData(member);
                categoryMenuEnabled = true;
            }

            categoryMenu->setEnabled(categoryMenuEnabled);
            addMenu(categoryMenu);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : list) {
        QWidget *current = static_cast<QWidget *>(obj);
        if (!current->property("WantsFocus").isValid() || !current->isVisible())
            continue;

        int cx = current->mapToGlobal(QPoint(0, 0)).x();
        int cy = current->mapToGlobal(QPoint(0, 0)).y();

        bool inserted = false;
        // Iterate through the ordered list of widgets, and insert the current one, so it is in the right position in the tab chain.
        for (QList<QWidget *>::iterator orderedIt = orderedList.begin(); orderedIt != orderedList.end(); ++orderedIt) {
            const QWidget *w = *orderedIt;
            int wx = w->mapToGlobal(QPoint(0, 0)).x();
            int wy = w->mapToGlobal(QPoint(0, 0)).y();

            if (wy > cy || (wy == cy && wx >= cx)) {
                orderedList.insert(orderedIt, current);
                inserted = true;
                break;
            }
        }
        if (!inserted)
            orderedList.append(current);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : areas()) {
                QPair<QString, QString> tagData = area->tagData();

                if (tagData.first == category) {
                    if (!selectedTags.contains(tagData.second)) {
                        // The linked tag is not selected anymore, so remove it
                        area->removeTagData();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( DB::CategoryPtr category : DB::ImageDB::instance()->categoryCollection()->categories() )
        {
            if ( category->positionable() )
            {
                usePositionableTags = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DatabaseElement *e : fields) {
            e->setValue(query.value(i++));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ListSelect *ls : qAsConst(m_optionList)) {
            StringSet changes = changedOptions(ls);
            if (!(changes.isEmpty())) {
                anyChanges = true;
                StringSet newItemsOn = ls->itemsOn() & changes;
                StringSet newItemsOff = ls->itemsOff() & changes;
                for (DB::ImageInfoListConstIterator it = m_origList.constBegin(); it != m_origList.constEnd(); ++it) {
                    DB::ImageInfoPtr info = *it;
                    info->addCategoryInfo(ls->category(), newItemsOn);
                    info->removeCategoryInfo(ls->category(), newItemsOff);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &image : m_images) {
        const Marble::GeoDataCoordinates pos(image->coordinates().lon(), image->coordinates().lat(),
                                             image->coordinates().alt(),
                                             Marble::GeoDataCoordinates::Degree);
        if (viewPort.contains(pos)) {
            if (style == MapStyle::ShowPins) {
                painter->drawPixmap(pos, alternatePixmap);
            } else {
                // FIXME(l3u) Maybe we should cache the scaled thumbnails?
                painter->drawPixmap(pos, ImageManager::ThumbnailCache::instance()->lookup(image->fileName()).scaled(QSize(MARKER_SIZE_PX, MARKER_SIZE_PX), Qt::KeepAspectRatio));
            }
        }
    }
```

#### AUTO 


```{c}
constexpr auto msgPreconditionFailed = "Precondition for test failed - please fix unit test!";
```

#### LAMBDA EXPRESSION 


```{c}
[] (CategoryItemDetails& item) { return item.name; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : searchUrls) {
        QUrl src(url);
        src.setPath(src.path() + fileName.relative());

        std::unique_ptr<KIO::StatJob> statJob { KIO::stat(src, KIO::StatJob::SourceSide, 0 /* just query for existence */) };
        KJobWidgets::setWindow(statJob.get(), MainWindow::Window::theMainWindow());
        if (statJob->exec()) {
            QUrl dest = QUrl::fromLocalFile(m_fileMapper->uniqNameFor(fileName));
            m_job = KIO::file_copy(src, dest, -1, KIO::HideProgressInfo);
            connect(m_job, &KIO::FileCopyJob::result, this, &ImportHandler::aCopyJobCompleted);
            succeeded = true;
            qCDebug(ImportExportLog) << "Copying" << src << "to" << dest;
            break;
        } else
            tried << src.toDisplayString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString& word) { return word.startsWith( m_text.toLower()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRadioButton *button : qAsConst(m_buttons)) {
        if (button->isChecked()) {
            destination = button->property("data").value<DB::FileName>();
            break;
        }
    }
```

#### AUTO 


```{c}
auto *externalCommandsAction = menu.addMenu(&externalCommands);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &file : qAsConst(m_list)) {
            if (service && m_appToMimeTypeMap[service->name()].contains(mimeType(file)))
                lst.append(QUrl(file.absolute()));
        }
```

#### AUTO 


```{c}
const auto count = files.count();
```

#### AUTO 


```{c}
const auto be = static_cast<Settings::VideoBackend>(backendEnum.keyToValue(badBackend.constData(), &ok));
```

#### RANGE FOR STATEMENT 


```{c}
for( QDockWidget* dock : m_dockWidgets ) {
        if ( dock->isFloating() )
        {
            Debug() << "Hiding dock: " << dock->objectName();
            dock->hide();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRadioButton *button : qAsConst(m_buttons)) {
        if (button->isChecked())
            continue;
        DB::FileName fileName = button->property("data").value<DB::FileName>();
        DB::ImageDB::instance()->copyData(fileName, destination);
        // can we safely delete the file?
        if (fileName != destination)
            deleteList.append(fileName);
        else
            dupList.append(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
        urls.append(QUrl::fromLocalFile(fileName.absolute()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categoryList) {
        QString categoryName = category->name();

        if (!shouldSaveCategory(categoryName))
            continue;

        const StringSet items = info->itemsOfCategory(categoryName);
        if (!items.empty()) {
            QStringList idList;

            for (const QString &itemValue : items) {
                QRect area = info->areaForTag(categoryName, itemValue);

                if (area.isValid()) {
                    // Positioned tags can't be stored in the "fast" format
                    // so we have to handle them separately
                    positionedTags[categoryName] << QPair<QString, QRect>(itemValue, area);
                } else {
                    int id = static_cast<const XMLCategory *>(category.data())->idForName(itemValue);
                    idList.append(QString::number(id));
                }
            }

            // Possibly all ids of a category have area information, so only
            // write the category attribute if there are actually ids to write
            if (!idList.isEmpty()) {
                std::sort(idList.begin(), idList.end());
                writer.writeAttribute(escape(categoryName), idList.join(_comma_));
            }
        }
    }
```

#### AUTO 


```{c}
const auto correctFN = FileName::fromAbsolutePath(absoluteFilePath);
```

#### AUTO 


```{c}
const auto someImageCacheData = thumbnailCache.lookupRawData(someImageFileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageInfoPtr &info : *this)
        res.append(info->fileName());
```

#### AUTO 


```{c}
const auto absoluteUrl2 = QUrl::fromLocalFile(absoluteFilePath2).toString();
```

#### AUTO 


```{c}
const auto allElements = elements();
```

#### AUTO 


```{c}
constexpr auto CFG_GROUP { "CrashInfo" };
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_TOP = 0b00000001;
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& part : tagParts) {
        part.replace(QString::fromUtf8("//"), QString::fromUtf8("/"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : sorted) {
            const int subrow = (count % perCol);
            const QPalette::ColorRole role = (subrow & 1) ? QPalette::Base : QPalette::AlternateBase;
            QPair<QLabel *, QLabel *> pair = infoLabelPair(exifNameNoGroup(key), items[key].join(QLatin1String(", ")), role);

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row + subrow, col);
            layout->addWidget(pair.second, row + subrow, col + 1);
            count++;
        }
```

#### AUTO 


```{c}
auto *scrollWidget = new QWidget;
```

#### CONST EXPRESSION 


```{c}
constexpr int SCROLL_ACCELERATION = 10;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &title, const char *name, int value, const QKeySequence &key) {
        if (count++ == 5) {
            QAction *sep = new QAction(menu);
            sep->setSeparator(true);
            menu->addAction(sep);
        }

        QAction *seek = m_actions->addAction(QString::fromLatin1(name));
        seek->setText(title);
        seek->setShortcut(key);
        m_actions->setShortcutsConfigurable(seek, false);
        connect(seek, &QAction::triggered, [this, value] {
            m_videoDisplay->relativeSeek(value);
        });
        menu->addAction(seek);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &fileName : m_sortedList ) {
        if ( tmp.contains( fileName ) ) {
            answer << fileName;
            tmp.remove( fileName );
        } else if ( tmp.contains( m_path + fileName ) ) {
            answer << m_path + fileName;
            tmp.remove( m_path + fileName );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& category : categories )
        this->categories[category] = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        action->setShortcutContext(Qt::WindowShortcut);
        addAction(action);
    }
```

#### AUTO 


```{c}
const auto choice = KMessageBox::warningContinueCancelDetailed(parent, message, QString(), KStandardGuiItem::cont(), KStandardGuiItem::cancel(), QString(), KMessageBox::Notify, messageDetails);
```

#### CONST EXPRESSION 


```{c}
constexpr int BORDER_AROUND_WIDGET = 0;
```

#### AUTO 


```{c}
const auto length = libvlc_media_player_get_length(m_player);
```

#### AUTO 


```{c}
const auto filterShortcut = new QShortcut(Qt::AltModifier + Qt::Key_F, m_filter, SLOT(setFocus()));
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::CategoryPtr category : categories) {
        if (!category->isSpecialCategory())
            m_category->addItem(category->name(), category->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        const DB::FileNameList allInStack = getStackFor(fileName);
        if (allInStack.size() <= 2) {
            // we're destroying stack here
            for (const DB::FileName &stackFileName : allInStack) {
                DB::ImageInfoPtr imgInfo = info(stackFileName);
                Q_ASSERT(imgInfo);
                if (imgInfo->isStacked()) {
                    m_stackMap.remove(imgInfo->stackId());
                    imgInfo->setStackId(0);
                    imgInfo->setStackOrder(0);
                }
            }
        } else {
            DB::ImageInfoPtr imgInfo = info(fileName);
            Q_ASSERT(imgInfo);
            if (imgInfo->isStacked()) {
                m_stackMap[imgInfo->stackId()].removeAll(fileName);
                imgInfo->setStackId(0);
                imgInfo->setStackOrder(0);
            }
        }
    }
```

#### AUTO 


```{c}
const auto relativePath = QStringLiteral("dirname/otherdir");
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString fileName : m_fileList ) {
        QString dir = getDirName(fileName);
        if (! dirMap.contains( dir ) ) {
            StringSet newDir;
            dirMap.insert(dir, newDir);
            dirList << dir;
        }
        dirMap[ dir ] << fileName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : itemsOnThisImage) {
                if (!itemsOnAllImages.contains(item) && !itemsOnSomeImages.contains(item)) {
                    itemsOnSomeImages += item;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files)
        dir.remove(file);
```

#### AUTO 


```{c}
const auto INDEXFILE_NAME = QString::fromLatin1("thumbnailindex");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tagName : selectedTags) {
                addTagToCandidateList(ls->category(), tagName);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileName &fileName : list) {
        if (count % 10 == 0) {
            dialog.setValue(count); // ensure to call setProgress(0)
            qApp->processEvents(QEventLoop::AllEvents);

            if (dialog.wasCanceled()) {
                if (wasCanceled)
                    *wasCanceled = true;
                return dirty;
            }
        }

        MD5 md5 = MD5Sum(fileName);
        if (md5.isNull()) {
            cantRead << fileName;
            continue;
        }

        ImageInfoPtr info = ImageDB::instance()->info(fileName);
        if (info->MD5Sum() != md5) {
            info->setMD5Sum(md5);
            dirty = true;
            ImageManager::ThumbnailCache::instance()->removeThumbnail(fileName);
        }

        md5Map->insert(md5, fileName);

        ++count;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int DEFAULT_SCOUT_BUFFER_SIZE = 1048576;
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
const auto images = model()->imageList(ViewOrder);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
        subCluster->render(painter, viewPortParams, thumbs, style);
    }
```

#### AUTO 


```{c}
auto selectedFiles = QList<QUrl> { QUrl::fromLocalFile(m_list.value(m_current).absolute()) };
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &comment : commentsToStrip)
        comment.replace(QString::fromLatin1(",,"), QString::fromLatin1(","));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : list) {
            if (txt.indexOf(word, 0, Qt::CaseInsensitive) == -1)
                return false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
            const DB::ImageInfoPtr info = DB::ImageDB::instance()->info(fileName);
            int grps = info->availableCategories().length();
            if (grps > maxCatsInText - 2) {
                grps -= info->itemsOfCategory(folder).empty() ? 1 : 2;
                if (grps > maxCatsInText)
                    maxCatsInText = grps;
            }
        }
```

#### AUTO 


```{c}
const auto group = groupForDatabase("Privacy Settings");
```

#### RANGE FOR STATEMENT 


```{c}
for(ResizableFrame *area : areas()) {
                QPair<QString, QString> tagData = area->tagData();

                if (tagData.first == category) {
                    if (! selectedTags.contains(tagData.second)) {
                        // The linked tag is not selected anymore, so remove it
                        area->removeTagData();
                    }
                }
            }
```

#### AUTO 


```{c}
const auto relativeFilePath1 = QStringLiteral("image.jpg");
```

#### AUTO 


```{c}
auto filename = DB::FileName::fromAbsolutePath(output[QStringLiteral("url")].toString());
```

#### AUTO 


```{c}
auto i;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &current : others) {
        if (current == image) {
            current.info()->setStackOrder(1);
        } else if (current.info()->stackOrder() < oldOrder) {
            current.info()->setStackOrder(current.info()->stackOrder() + 1);
        }
    }
```

#### AUTO 


```{c}
const auto matchers = m_categoryMatcher->m_matchers;
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *optionMatcher : m_categoryMatchers) {
        if (!optionMatcher->eval(info, alreadyMatched))
            return false;
    }
```

#### AUTO 


```{c}
const auto groupMapItValue = groupMapIt.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(QString::fromLatin1("area"), areaToString(area));
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr bool sortByName(const QByteArray &path);
```

#### RANGE FOR STATEMENT 


```{c}
for( const DockPair& pair : m_docks ) {
        QDockWidget* dock = pair.first;
        QWidget* widget = pair.second;
        QString title = dock->windowTitle();
        for ( int index = 0; index < title.length(); ++index ) {
            const QChar ch = title[index].toLower();
            if ( !m_taken.contains(ch) ) {
                m_taken.insert( ch );
                dock->setWindowTitle( title.left(index) + QString::fromLatin1("&") + title.mid(index) );
                new QShortcut( QString::fromLatin1( "Alt+")+ch , widget, SLOT(setFocus()) );
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *cluster : m_geoClusters) {
        const Marble::GeoDataLatLonBox region = cluster->regionForPoint(event->pos(), *viewPortParams);
        if (!region.isEmpty()) {
            qCDebug(MapLog) << "Cluster selected by mouse click.";
            updateRegionSelection(region);
            event->accept();
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( ImportMatcher* match : m_matchers )
        settings.addCategoryMatchSetting( match->settings() );
```

#### CONST EXPRESSION 


```{c}
constexpr int MAP_CLUSTER_LEVELS = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &file : qAsConst(m_list)) {
            if (m_appToMimeTypeMap[name].contains(mimeType(file)))
                lst.append(QUrl(file.absolute()));
        }
```

#### AUTO 


```{c}
const auto opacity = painter->opacity();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fileName : allImageFiles) {
        progressIndicator.setValue(i++);
        add(fileName);
        if (i % 10) {
            auto app = QCoreApplication::instance();
            if (app)
                app->processEvents();
        }
        if (progressIndicator.wasCanceled())
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &name : qAsConst(m_imageList)) {
        if (name == fileName)
            break;
        ++i;
    }
```

#### AUTO 


```{c}
const auto existingFN = FileName::fromRelativePath(existingFile.fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::ImageInfoPtr info : qAsConst(images)) {
        info->setStackOrder(stackOrder);
        info->setStackId(stackId);
        m_stackMap[stackId].append(info->fileName());
        ++changed;
        ++stackOrder;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &positionedTag : qAsConst(areas)) {
                ElementWriter dummy(writer, QString::fromLatin1("value"));
                writer.writeAttribute(QString::fromLatin1("value"), positionedTag.first);
                writer.writeAttribute(QString::fromLatin1("area"), areaToString(positionedTag.second));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::CategoryMatcher *matcher : mp_elements)
        matcher->setShouldCreateMatchedSet(b);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &block : qAsConst(blockList)) {
        ElementWriter dummy(writer, _block_);
        writer.writeAttribute(_file_, block.relative());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* child : orMacther->_elements) {
            result.append( extractAndMatcher( child ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
        const DB::ImageInfoPtr info = DB::ImageDB::instance()->info(fileName);
        const DB::MD5 md5 = info->MD5Sum();
        m_matches[md5].append(fileName);
    }
```

#### AUTO 


```{c}
auto *jobIndicator = new BackgroundTaskManager::StatusIndicator( indicators );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : grps) {
        if (!shouldSaveCategory(name))
            continue;

        ElementWriter categoryElm(writer, _option_, false);

#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
        const auto itemsOfCategory = info->itemsOfCategory(name);
        QStringList items(itemsOfCategory.begin(), itemsOfCategory.end());
#else
        QStringList items = info->itemsOfCategory(name).toList();
#endif
        std::sort(items.begin(), items.end());
        if (!items.isEmpty()) {
            topElm.writeStartElement();
            categoryElm.writeStartElement();
            writer.writeAttribute(_name_, name);
        }

        for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, _value_);
            writer.writeAttribute(_value_, itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(_area_, areaToString(area));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( DatabaseElement *e : fields )
            {
                e->setValue( QVariant() );
		i++;
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int ARROW_LENGTH = 20;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &fileName : tmp ) {
            qDebug() << fileName;
            answer << fileName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<SimpleCategoryMatcher *> resultIt : oldResult) {
            for (QList<SimpleCategoryMatcher *> currentIt : current) {
                QList<SimpleCategoryMatcher *> tmp;
                tmp += resultIt;
                tmp += currentIt;
                result.append(tmp);
            }
        }
```

#### AUTO 


```{c}
const auto emptyFN = FileName::fromRelativePath({});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPushButton *button : buttons) {
        group.writeEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX
                             + button->property("floater").toString(),
                         button->isChecked());
    }
```

#### AUTO 


```{c}
const auto *treeModel = qobject_cast<TreeCategoryModel *>(model);
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(StaticImageResult)
```

#### AUTO 


```{c}
auto *jobIndicator = new BackgroundTaskManager::StatusIndicator(indicators);
```

#### AUTO 


```{c}
const auto thumbnailDir = imageDir.absoluteFilePath(ImageManager::defaultThumbnailDirectory());
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : list) {
        ImageManager::ImageRequest* request = new ImageManager::ImageRequest( fileName, QSize( 128, 128 ), fileName.info()->angle(), this );
        request->setPriority( ImageManager::BatchTask );
        ImageManager::AsyncLoader::instance()->load( request );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &stackFileName : allInStack) {
                DB::ImageInfoPtr imgInfo = stackFileName.info();
                Q_ASSERT(imgInfo);
                if (imgInfo->isStacked()) {
                    m_stackMap.remove(imgInfo->stackId());
                    imgInfo->setStackId(0);
                    imgInfo->setStackOrder(0);
                }
            }
```

#### AUTO 


```{c}
const auto &imageInfo
```

#### AUTO 


```{c}
auto foo(int i) -> int {
	return i - 1;
}
```

#### AUTO 


```{c}
auto filterWidget = new FilterWidget(parent);
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(ThumbnailCancelRequest)
```

#### AUTO 


```{c}
const auto message = i18n(
                    "<p>KPhotoAlbum has tried out all available video backends, but every one crashed at some point.</p>"
                    "<p>Crash detection is now turned off.</p>");
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* optionMatcher : _categoryMatchers) {
        ok = ok && optionMatcher->eval(info, alreadyMatched);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<QLabel *, QLabel *> tuple : m_labels) {
        const bool matches = tuple.first->text().contains(search, Qt::CaseInsensitive) && search.length() != 0;
        const auto fgRole = matches ? QPalette::HighlightedText : QPalette::Text;
        const auto bgRole = matches ? QPalette::Highlight : QPalette::Base;
        tuple.first->setForegroundRole(fgRole);
        tuple.first->setBackgroundRole(bgRole);
        tuple.second->setForegroundRole(fgRole);
        tuple.second->setBackgroundRole(bgRole);
        QFont fnt = tuple.first->font();
        fnt.setBold(matches);
        tuple.first->setFont(fnt);
        tuple.second->setFont(fnt);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
            setUpCategoryListBoxForMultiImageSelection(ls, list);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : list) {
        const QString nm = part.trimmed();
        if (!nm.contains(QString::fromLatin1("!")))
            result.insert(nm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &part : tagParts) {
        part.replace(QString::fromLatin1("//"), QString::fromLatin1("/"));
    }
```

#### AUTO 


```{c}
const auto otherCategoryInfomationKeys = other.m_categoryInfomation.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& item : items ) {
                if (match.XMLtoDB().contains( item ) ) {
                    DBInfo->addCategoryInfo( DBCategoryName, match.XMLtoDB()[item] );
                    DBCategoryPtr->addItem( match.XMLtoDB()[item] );
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QDockWidget* dock: m_dockWidgets ) {
        if ( dock->isFloating() )
            dock->show();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int THUMBNAIL_FILE_VERSION=4;
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
            ls->slotReturn();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
                QPair<QString, QString> tagData = area->tagData();

                if (tagData.first == category) {
                    if (!selectedTags.contains(tagData.second)) {
                        // The linked tag is not selected anymore, so remove it
                        area->removeTagData();
                    }
                }
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int BUTTON_WIDTH = 22;
```

#### AUTO 


```{c}
constexpr auto v4IndexHexData {
    "00000004" // version
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
};
```

#### AUTO 


```{c}
const auto& ignoredComment
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elements(version))
        {
            query.prepare( QString::fromLatin1( "alter table exif add column %1")
                           .arg( e->createString()) );
            if ( !query.exec())
                showErrorAndFail( query );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : fileNameList)
        infoList.append(info(fileName));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
                    DB::ImageInfoPtr info = DB::ImageDB::instance()->info(fileName);
                    info->setRating(rating);
                }
```

#### AUTO 


```{c}
const auto cfgGroup = KSharedConfig::openConfig()->group(CFG_GROUP);
```

#### AUTO 


```{c}
const auto emptyFN = FileName::fromAbsolutePath({});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& category : info->availableCategories()) {
        if (!DB::ImageDB::instance()->categoryCollection()->categoryForName(category)->isSpecialCategory())
            result.categories[category] = info->itemsOfCategory(category).toList();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MARKER_SIZE_PX = 40;
```

#### AUTO 


```{c}
const auto absoluteOutsideUrl = QUrl::fromLocalFile(absoluteOutsideFilePath).toString();
```

#### AUTO 


```{c}
auto *remoteIndicator = new RemoteControl::ConnectionIndicator(indicators);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *cluster : m_geoClusters) {
        const Marble::GeoDataLatLonBox region = cluster->regionForPoint(event->pos(), *viewPortParams);
        if (!region.isEmpty()) {
            qCDebug(MapLog) << "Cluster selected by mouse click.";
            updateRegionSelection(region);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &info : list) {
        if (!DB::ImageDB::instance()->md5Map()->contains(info->MD5Sum()))
            continue;

        const DB::FileName name = DB::ImageDB::instance()->md5Map()->lookup(info->MD5Sum());
        const DB::ImageInfoPtr other = DB::ImageDB::instance()->info(name);
        if (other->isNull())
            continue;
        if (info->label() != other->label())
            res.label = true;
        if (info->description() != other->description())
            res.description = true;

        if (info->angle() != other->angle())
            res.orientation = true;

        if (info->date() != other->date())
            res.date = true;

        const auto categoryMatchSettings = settings.categoryMatchSetting();
        for (const CategoryMatchSetting &matcher : categoryMatchSettings) {
            const QString XMLFileCategory = matcher.XMLCategoryName();
            const QString DBCategory = matcher.DBCategoryName();
            if (mapCategoriesToDB(matcher, info->itemsOfCategory(XMLFileCategory)) != other->itemsOfCategory(DBCategory))
                res.categories[DBCategory] = true;
        }
    }
```

#### AUTO 


```{c}
const auto areas = findChildren<TaggedArea *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QCheckBox *box : qAsConst(m_checkBoxes)) {
        if (box->isChecked() && box->isEnabled()) {
            QString txt = box->text().remove(QString::fromLatin1("&"));
            tokensCategory->removeItem(txt);
            // re-add the token so that it is still available e.g. in the annotation dialog list select:
            tokensCategory->addItem(txt);
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_RIGHT  = 0b00000100;
```

#### CONST EXPRESSION 


```{c}
constexpr int IMAGE_SCOUT_THREAD_COUNT = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto category : m_db->categoryCollection()->categories()) {
            XMLCategory *xmlCategory = static_cast<XMLCategory *>(category.data());
            QStringList tags = xmlCategory->namesForId(0);
            if (tags.size() > 1) {
                manualRepairNeeded = true;
                message += i18nc("repair merged tags", "<li>%1:<br/>", category->name());
                for (auto tagName : tags) {
                    message += i18nc("repair merged tags", "%1<br/>", tagName);
                    logSummary += QString::fromLatin1("%1/%2\n").arg(category->name(), tagName);
                }
                message += i18nc("repair merged tags", "</li>");
            }
            xmlCategory->clearNullIds();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &newFile : selectedFiles) {
        newFile.info()->copyExtraData(*originalInfo, false);
    }
```

#### AUTO 


```{c}
const auto *keyEvent = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
const auto schemeCfg = KSharedConfig::openConfig(Settings::SettingsData::instance()->colorScheme());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &categoryName : items) {
                if (!alreadyMatched.contains(categoryName)) // We do not want to match "Jesper & Jesper"
                    map[categoryName].add(imageInfo->date());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : orderedStack) {
                    m_displayList.append(fileName);
                }
```

#### AUTO 


```{c}
auto *tabWidget = new QTabWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elms )
	{
	    formalList.append( e->queryString() );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &subKey : subKeys) {
            if (!path.isEmpty())
                path += QString::fromLatin1(".");
            path += subKey;
            if (tree.contains(path))
                parent = tree[path];
            else {
                if (parent == nullptr)
                    parent = new QTreeWidgetItem(this, QStringList(subKey));
                else
                    parent = new QTreeWidgetItem(parent, QStringList(subKey));
                parent->setText(1, path); // This is simply to make the implementation of selected easier.
                parent->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
                parent->setCheckState(0, Qt::Unchecked);
                tree.insert(path, parent);
            }
        }
```

#### AUTO 


```{c}
auto hLay = new QHBoxLayout(this);
```

#### AUTO 


```{c}
const auto &itemWord
```

#### AUTO 


```{c}
const auto selection = widget()->selection(NoExpandCollapsedStacks);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &image : images) {
        const DB::ImageInfoPtr info = image.info();
        if (!info->isVideo())
            continue;

        // silently ignore videos not (currently) on disk:
        if (!info->fileName().exists())
            continue;

        const DB::FileName thumbnailName = BackgroundJobs::HandleVideoThumbnailRequestJob::frameName(info->fileName(), 9);
        if (thumbnailName.exists())
            continue;

        BackgroundJobs::ReadVideoLengthJob *readVideoLengthJob = new BackgroundJobs::ReadVideoLengthJob(info->fileName(), BackgroundTaskManager::BackgroundVideoPreviewRequest);

        for (int i = 0; i < 10; ++i) {
            ExtractOneThumbnailJob *extractJob = new ExtractOneThumbnailJob(info->fileName(), i, BackgroundTaskManager::BackgroundVideoPreviewRequest);
            extractJob->addDependency(readVideoLengthJob);
        }

        BackgroundTaskManager::JobManager::instance()->addJob(readVideoLengthJob);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryMatchSetting &matcher : categoryMatchSettings) {
            const QString XMLFileCategory = matcher.XMLCategoryName();
            const QString DBCategory = matcher.DBCategoryName();
            if (mapCategoriesToDB(matcher, info->itemsOfCategory(XMLFileCategory)) != other->itemsOfCategory(DBCategory))
                res.categories[DBCategory] = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_imageList)) {
        const DB::ImageInfoPtr imageInfo = DB::ImageDB::instance()->info(fileName);
        if (imageInfo && imageInfo->isStacked()) {
            DB::StackID stackid = imageInfo->stackId();
            stackContents[stackid].append(fileName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        ImageManager::ImageRequest *request = new ImageManager::ImageRequest(fileName, QSize(128, 128), fileName.info()->angle(), this);
        request->setPriority(ImageManager::BatchTask);
        ImageManager::AsyncLoader::instance()->load(request);
    }
```

#### AUTO 


```{c}
const auto fgRole = matches ? QPalette::HighlightedText : QPalette::Text;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &file : files) {
        const DB::FileName baseFileName = file;
        const int extStart = baseFileName.relative().lastIndexOf(QChar::fromLatin1('.'));
        const QString ext = baseFileName.relative().mid(extStart);
        if (!extensions.contains(ext)) {
            res.insert(mimeType(file));
            extensions.insert(ext);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->type() == DB::Category::MediaTypeCategory)
            continue;
        QMap<QString, DB::CountWithRange> images = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Image );

        QMap<QString, DB::CountWithRange> videos = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Video );
        const bool enabled = (images.count() /*+ videos.count()*/ > 1);
        CategoryViewType type =
                (category->viewType() == DB::Category::IconView || category->viewType() == DB::Category::ThumbedIconView)
                ? Types::CategoryIconView : Types::CategoryListView;

        const QImage icon = category->icon(search.size, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({category->name(), icon, enabled, type});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &imageInfo : m_images) {
        bool match = ((imageInfo)->mediaType() & typemask) && !(imageInfo)->isLocked() && info.match(imageInfo) && rangeInclude(imageInfo);
        if (match) { // If the given image is currently matched.

            // Now iterate through all the categories the current image
            // contains, and increase them in the map mapping from category
            // to count.
            StringSet items = (imageInfo)->itemsOfCategory(category);
            counter.count(items, imageInfo->date());
            for (const auto &categoryName : items) {
                if (!alreadyMatched.contains(categoryName)) // We do not want to match "Jesper & Jesper"
                    map[categoryName].add(imageInfo->date());
            }

            // Find those with no other matches
            if (noMatchInfo.match(imageInfo))
                map[DB::ImageDB::NONE()].count++;

            // this is a shortcut for the browser overview page,
            // where we are only interested whether there are sub-categories to a category
            if (mode == DB::ClassificationMode::PartialCount && map.size() > 1) {
                qCInfo(TimingLog) << "Database::classify(partial): " << timer.restart() << "ms.";
                return map;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elms )
    {
        e->bindValues( &query, i, data );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUrl url : list)
       thumbnail( url, size );
```

#### LAMBDA EXPRESSION 


```{c}
[](CategoryItemDetails &item) { return item.name; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
        if (!m_thumbnailCache->contains(fileName))
            needed.append(fileName);
    }
```

#### AUTO 


```{c}
const auto categoryItems = Utilities::mergeListsUniqly(category->items(), m_db->memberMap().groups(name));
```

#### AUTO 


```{c}
auto it = tempUnsavedHash.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Image );
        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Video );
        const bool enabled = (images.count() + videos.count() > 1);

        const QImage icon = category->icon(THUMBNAILSIZE, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({category->name(), category->text(), icon, enabled});
    }
```

#### AUTO 


```{c}
const auto messageDetails = i18n(
                    "<p>Video backend that was interrupted: <tt>%1</tt></p>"
                    "<p>Video backend that will be used instead: <tt>%2</tt></p>",
                    Settings::localizedEnumName(backend), Settings::localizedEnumName(preferredBackend));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &image : m_images) {
        const Marble::GeoDataCoordinates pos(image->coordinates().lon(), image->coordinates().lat(),
                                             image->coordinates().alt(),
                                             Marble::GeoDataCoordinates::Degree);
        if (viewPort.contains(pos)) {
            if (style == MapStyle::ShowPins) {
                painter->drawPixmap(pos, thumbs.alternatePixmap);
            } else {
                // FIXME(l3u) Maybe we should cache the scaled thumbnails?
                painter->drawPixmap(pos, thumbs.cache->lookup(image->fileName()).scaled(QSize(MARKER_SIZE_PX, MARKER_SIZE_PX), Qt::KeepAspectRatio));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_list)) {
        const auto info = DB::ImageDB::instance()->info(fileName);
        // Skipping images that do not have exact time stamp
        if (info->date().start() != info->date().end())
            continue;
        if (prev && (prev->date().start().secsTo(info->date().start()) < m_continuousThreshold->value())) {
            DB::FileNameList stack;

            if (!DB::ImageDB::instance()->getStackFor(prev->fileName()).isEmpty()) {
                if (m_autostackUnstack->isChecked())
                    DB::ImageDB::instance()->unstack(DB::FileNameList() << prev->fileName());
                else if (m_autostackSkip->isChecked())
                    continue;
            }

            if (!DB::ImageDB::instance()->getStackFor(fileName).isEmpty()) {
                if (m_autostackUnstack->isChecked())
                    DB::ImageDB::instance()->unstack(DB::FileNameList() << fileName);
                else if (m_autostackSkip->isChecked())
                    continue;
            }

            stack.append(prev->fileName());
            stack.append(info->fileName());
            if (!toBeShown.isEmpty()) {
                if (toBeShown.at(toBeShown.size() - 1) != prev->fileName())
                    toBeShown.append(prev->fileName());
            } else {
                // if this is first insert, we have to include also the stacked images from previuous image
                if (!DB::ImageDB::instance()->getStackFor(info->fileName()).isEmpty()) {
                    const auto stackedImages = DB::ImageDB::instance()->getStackFor(prev->fileName());
                    for (const DB::FileName &a : stackedImages)
                        toBeShown.append(a);
                } else
                    toBeShown.append(prev->fileName());
            }
            // Inserting stacked images from the current image
            if (!DB::ImageDB::instance()->getStackFor(info->fileName()).isEmpty()) {
                const auto stackedImages = DB::ImageDB::instance()->getStackFor(fileName);
                for (const DB::FileName &a : stackedImages)
                    toBeShown.append(a);
            } else
                toBeShown.append(info->fileName());
            DB::ImageDB::instance()->stack(stack);
        }

        prev = info;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        m_categoryInfomation[key].unite(other.m_categoryInfomation[key]);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int defaultMaxSeekAhead = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (StringSet &items : groupMap) {
        if (items.contains(oldName)) {
            items.remove(oldName);
            items.insert(newName);
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(service);
```

#### AUTO 


```{c}
const auto categoryItems = category->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : sorted) {
            const int subrow = (count % perCol);
            const QColor color = (subrow & 1) ? Qt::white : QColor(226, 235, 250);
            QPair<QLabel *, QLabel *> pair = infoLabelPair(exifNameNoGroup(key), items[key].join(QLatin1String(", ")), color);

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row + subrow, col);
            layout->addWidget(pair.second, row + subrow, col + 1);
            count++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &file : list) {
        if (file.exists()) {
            someFileExists = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : qAsConst(cacheEntries)) {
        Q_ASSERT(entry.info.fileIndex != -1);
        if (entry.info.fileIndex != currentFileIndex) {
            currentFileIndex = entry.info.fileIndex;
            if (currentFile)
                delete currentFile;
            currentFile = new ThumbnailMapping(fileNameForIndex(currentFileIndex) + backupSuffix);
        }

        const QByteArray imageData(currentFile->map.mid(entry.info.offset, entry.info.size));
        insert(entry.name, imageData);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        layout->addWidget(headerLabel(group), row++, 0, 1, 4);

        // Items of group
        const QMap<QString, QStringList> items = itemsForGroup(group, map);
        QStringList sorted = items.keys();
        sorted.sort();
        int elements = sorted.size();
        int perCol = (elements + 1) / 2;
        int count = 0;
        for (const QString &key : sorted) {
            const int subrow = (count % perCol);
            const QColor color = (subrow & 1) ? palette().base().color() : palette().alternateBase().color();
            QPair<QLabel *, QLabel *> pair = infoLabelPair(exifNameNoGroup(key), items[key].join(QLatin1String(", ")), color);

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row + subrow, col);
            layout->addWidget(pair.second, row + subrow, col + 1);
            count++;
        }
        row += perCol;
    }
```

#### AUTO 


```{c}
const auto absoluteFN = FileName::fromRelativePath(absoluteFilePath);
```

#### AUTO 


```{c}
const auto &badBackend
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (!shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, QString::fromUtf8("Category"));
        writer.writeAttribute(QString::fromUtf8("name"), name);
        writer.writeAttribute(QString::fromUtf8("icon"), category->iconName());
        writer.writeAttribute(QString::fromUtf8("show"), QString::number(category->doShow()));
        writer.writeAttribute(QString::fromUtf8("viewtype"), QString::number(category->viewType()));
        writer.writeAttribute(QString::fromUtf8("thumbnailsize"), QString::number(category->thumbnailSize()));
        writer.writeAttribute(QString::fromUtf8("positionable"), QString::number(category->positionable()));
        if (category == tokensCategory) {
            writer.writeAttribute(QString::fromUtf8("meta"), QString::fromUtf8("tokens"));
        }

        // As bug 423334 shows, it is easy to forget to add a group to the respective category
        // when it's created. We can not enforce correct creation of member groups in our API,
        // but we can prevent incorrect data from entering index.xml.
        const auto categoryItems = Utilities::mergeListsUniqly(category->items(), m_db->memberMap().groups(name));
        for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), tagName);
            writer.writeAttribute(QString::fromLatin1("id"),
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(QString::fromUtf8("birthDate"), birthDate.toString(Qt::ISODate));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : _setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if ( wasCancelled() )
            return false;

        if ( count % cols == 0 ) {
            row = doc.createElement( QString::fromLatin1( "tr" ) );
            row.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-row" ) );
            doc.appendChild( row );
            count = 0;
        }

        col = doc.createElement( QString::fromLatin1( "td" ) );
        col.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-col" ) );
        row.appendChild( col );

        if (first.isEmpty())
            first = namePage( width, height, fileName);
        else
            last = namePage( width, height, fileName);

        if (!Utilities::isVideo(fileName))
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"%4\", \"" ).arg( nameImage( fileName, width ) ).arg( nameImage( fileName, _setup.thumbSize() )
                        ).arg( nameImage( fileName, maxImageSize() ) ).arg( KMimeType::findByUrl( nameImage(
                                    fileName, maxImageSize() ) )->name() );
        else {
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\"" ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( fileName.relative() );
            if ( _setup.html5VideoGenerate() )
                images += QString::fromLatin1( ", \"%1\", \"" ).arg( QString::fromLatin1( "video/ogg" ) );
            else
                images += QString::fromLatin1( ", \"%1\", \"" ).arg( KMimeType::findByPath( fileName.relative(), 0, true)->name() );
            enableVideo = 1;
        }

        // -------------------------------------------------- Description
        if ( !info->description().isEmpty() && _setup.includeCategory( QString::fromLatin1( "**DESCRIPTION**" )) )
            images += QString::fromLatin1( "%1\", \"" ).arg( info->description().replace( QString::fromLatin1( "\n$" ), QString::fromLatin1( "" ) ).replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) ).replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) ) );
        else
            images += QString::fromLatin1( "\", \"" );
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if ( !description.isEmpty() )
            description = QString::fromLatin1 ( "<ul>%1</ul>" ).arg ( description );
        else
            description = QString::fromLatin1 ( "" );

        description.replace( QString::fromLatin1( "\n$" ), QString::fromLatin1 ( "" ) );
        description.replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) );
        description.replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) );

        images += description;
        images += QString::fromLatin1( "\"]);\n" );

        QDomElement href = doc.createElement( QString::fromLatin1( "a" ) );
        href.setAttribute( QString::fromLatin1( "href" ),
                           namePage( width, height, fileName));
        col.appendChild( href );

        QDomElement img = doc.createElement( QString::fromLatin1( "img" ) );
        img.setAttribute( QString::fromLatin1( "src" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        img.setAttribute( QString::fromLatin1( "alt" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        href.appendChild( img );
        ++count;
    }
```

#### AUTO 


```{c}
const auto existingFN = FileName::fromAbsolutePath(existingFile.fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const DuplicateMatch *selector : qAsConst(m_selectors)) {
        ++total;
        if (selector->selected())
            ++selected;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Category& category : categories)
        stream << category.name << category.text << category.icon << category.enabled << (int) category.viewType;
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<QLabel *, QLabel *> tuple : m_labels) {
        const bool matches = tuple.first->text().contains(search, Qt::CaseInsensitive) && search.length() != 0;
        QPalette pal = tuple.first->palette();
        pal.setBrush(QPalette::Foreground, matches ? Qt::red : palette().text());
        tuple.first->setPalette(pal);
        tuple.second->setPalette(pal);
        QFont fnt = tuple.first->font();
        fnt.setBold(matches);
        tuple.first->setFont(fnt);
        tuple.second->setFont(fnt);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ImportMatcher *match : m_matchers)
        settings.addCategoryMatchSetting(match->settings());
```

#### AUTO 


```{c}
const auto &subCluster
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* child : andMatcher->_elements) {
            SimpleCategoryMatcher* simpleMatcher = dynamic_cast<SimpleCategoryMatcher*>( child );
            Q_ASSERT( simpleMatcher );
            result.append( simpleMatcher );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& ignoredComment :  Settings::SettingsData::instance()->EXIFCommentsToStrip() )
            {
                if ( desc == ignoredComment )
                {
                    doSetDescription = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( CategoryMatch* match : m_matchers ) {
        if ( match->m_checkbox->isChecked() )
            res.add( match->m_combobox->currentText(),match->m_text );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &imageInfo : qAsConst(newImages))
            m_imageCache.insert(imageInfo->fileName().absolute(), imageInfo);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { setMuted(!m_isMuted); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& oldFileName : matchingFiles) {
            categoryImagesDirectory.rename(oldFileName,
                                           oldName + oldFileName.mid(newName.length()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : grps) {
        if (!shouldSaveCategory(name))
            continue;

        ElementWriter categoryElm(writer, QString::fromLatin1("option"), false);

        QStringList items = info->itemsOfCategory(name).toList();
        std::sort(items.begin(), items.end());
        if (!items.isEmpty()) {
            topElm.writeStartElement();
            categoryElm.writeStartElement();
            writer.writeAttribute(QString::fromLatin1("name"), name);
        }

        for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(QString::fromLatin1("area"), areaToString(area));
            }
        }
    }
```

#### AUTO 


```{c}
auto it = m_baseBins.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (SerializerInterface *serializer : m_serializers)
        serializer->encode(stream);
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *optionMatcher : m_compiled.categoryMatchers) {
        optionMatcher->debug(1);
    }
```

#### AUTO 


```{c}
const auto config = KSharedConfig::openConfig(configFile)->group(group);
```

#### CONST EXPRESSION 


```{c}
constexpr int MARKER_SIZE_MAX_PX = 400;
```

#### AUTO 


```{c}
const auto permissions = QFile::permissions(fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &image : images)
    {
        urls.append(QUrl(image).toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : searchUrls) {
        QUrl src(url);
        src.setPath(src.path() + fileName.relative());

#if KIO_VERSION < QT_VERSION_CHECK(5, 69, 0)
        std::unique_ptr<KIO::StatJob> statJob { KIO::stat(src, KIO::StatJob::SourceSide, 0 /* just query for existence */) };
#else
        std::unique_ptr<KIO::StatJob> statJob { KIO::statDetails(src, KIO::StatJob::SourceSide, KIO::StatDetail::StatNoDetails) };
#endif
        KJobWidgets::setWindow(statJob.get(), MainWindow::Window::theMainWindow());
        if (statJob->exec()) {
            QUrl dest = QUrl::fromLocalFile(m_fileMapper->uniqNameFor(fileName));
            m_job = KIO::file_copy(src, dest, -1, KIO::HideProgressInfo);
            connect(m_job, &KIO::FileCopyJob::result, this, &ImportHandler::aCopyJobCompleted);
            succeeded = true;
            qCDebug(ImportExportLog) << "Copying" << src << "to" << dest;
            break;
        } else
            tried << src.toDisplayString();
    }
```

#### AUTO 


```{c}
const auto &image
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category: DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->isSpecialCategory()) {
            continue;
        }
        m_categoryBox->addItem(category->name());
        if (category->name() == i18n("People")) {
            defaultIndex = index;
        }
        ++index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& category : info->availableCategories()) {
        result.categories[category] = info->itemsOfCategory(category).toList();
    }
```

#### AUTO 


```{c}
const auto relativeUrl2 = QUrl::fromLocalFile(relativeFilePath2).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for( QDockWidget* dock : _dockWidgets ) {
        if ( dock->isFloating() )
            dock->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *subMatcher : qAsConst(mp_elements)) {
        if (!subMatcher->eval(info, alreadyMatched))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto& positionedTag : categoryWithAreas.value() ) {
                ElementWriter dummy( writer, QString::fromLatin1("value") );
                writer.writeAttribute( QString::fromLatin1("value"), positionedTag.first );
                writer.writeAttribute( QString::fromLatin1("area"), areaToString(positionedTag.second) );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QCheckBox *box : qAsConst(m_checkBoxes)) {
        box->setChecked(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->name() == QString::fromLatin1("Media Type"))
            continue;
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Image );

        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Video );
        const bool enabled = (images.count() /*+ videos.count()*/ > 1);
        CategoryViewType type =
                (category->viewType() == DB::Category::IconView || category->viewType() == DB::Category::ThumbedIconView)
                ? Types::CategoryIconView : Types::CategoryListView;

        const QImage icon = category->icon(search.size, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({category->name(), category->text(), icon, enabled, type});
    }
```

#### AUTO 


```{c}
auto octalPermissions = QString::number(hex, 16);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &member : members) {
            m_memberToGroup[member].append(group);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString tag : category->items()) {
        if (!groups.contains(tag)) {
            tags << tag;
        }
    }
```

#### AUTO 


```{c}
auto cluster = subCluster->regionForPoint(pos);
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
        ls->slotReturn();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto& areasOfCategory : _taggedAreas )
        {
            for ( auto& area : areasOfCategory )
            {
                QRect rotatedArea;

                // parameter order for QRect::setCoords:
                // setCoords( left, top, right, bottom )
                // keep in mind that _size is already transposed
                switch (degrees) {
                    case 90:
                        rotatedArea.setCoords(
                                _size.width() - area.bottom(),
                                area.left(),
                                _size.width() - area.top(),
                                area.right()
                                );
                        break;
                    case 180:
                        rotatedArea.setCoords(
                                _size.width() - area.right(),
                                _size.height() - area.bottom(),
                                _size.width() - area.left(),
                                _size.height() - area.top()
                                );
                        break;
                    case 270:
                        rotatedArea.setCoords(
                                area.top(),
                                _size.height() - area.right(),
                                area.bottom(),
                                _size.height() - area.left()
                                );
                        break;
                    default:
                        // degrees==0; "odd" values won't happen.
                        rotatedArea = area;
                        break;
                }

                // update _taggedAreas[category][tag]:
                area = rotatedArea;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto tagName : tags) {
                    message += i18nc("repair merged tags", "%1<br/>", tagName);
                    logSummary += QString::fromLatin1("%1/%2\n").arg(category->name(), tagName);
                }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(SearchResult)
```

#### AUTO 


```{c}
constexpr auto INDEXFILE_NAME = "thumbnailindex";
```

#### AUTO 


```{c}
auto* myerr = (myjpeg_error_mgr*) cinfo->err;
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<SimpleCategoryMatcher*> currentIt : current) {
                QList<SimpleCategoryMatcher*> tmp;
                tmp += resultIt;
                tmp += currentIt;
                result.append( tmp );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        if (category->type() == DB::Category::PlainCategory
            || category->type() == DB::Category::TokensCategory) {
            Settings::CategoryItem *item = new CategoryItem(category->name(),
                                                            category->iconName(),
                                                            category->viewType(),
                                                            category->thumbnailSize(),
                                                            m_categoriesListWidget,
                                                            category->positionable());
            Q_UNUSED(item)
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : images) {
        if (!info->isVideo())
            continue;

        // silently ignore videos not (currently) on disk:
        if (!info->fileName().exists())
            continue;

        const DB::FileName thumbnailName = BackgroundJobs::HandleVideoThumbnailRequestJob::frameName(info->fileName(), 9);
        if (thumbnailName.exists())
            continue;

        BackgroundJobs::ReadVideoLengthJob *readVideoLengthJob = new BackgroundJobs::ReadVideoLengthJob(info->fileName(), BackgroundTaskManager::BackgroundVideoPreviewRequest);

        for (int i = 0; i < 10; ++i) {
            ExtractOneThumbnailJob *extractJob = new ExtractOneThumbnailJob(info->fileName(), i, BackgroundTaskManager::BackgroundVideoPreviewRequest);
            extractJob->addDependency(readVideoLengthJob);
        }

        BackgroundTaskManager::JobManager::instance()->addJob(readVideoLengthJob);
    }
```

#### AUTO 


```{c}
const auto &members = m_members[category][memberGroup];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &tag : positionableTagCandidates) {
                QAction *action = new QAction(
                    tag.second + QString::fromLatin1(" (") +
                    m_dialog->localizedCategory(tag.first) +
                    QString::fromLatin1(")"), this
                );

                QStringList data;
                data << tag.first << tag.second;
                action->setData(data);

                submenu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *topLevelCluster : qAsConst(m_geoClusters)) {
                const auto subCluster = topLevelCluster->regionForPoint(mapPos);
                if (subCluster && !subCluster->isEmpty()) {
                    qCDebug(MapLog) << "Cluster preselected/clicked.";
                    m_preselectedCluster = subCluster;
                    event->accept();
                    return;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if ( wasCanceled() )
            return false;

        if ( count % cols == 0 ) {
            row = doc.createElement( QString::fromLatin1( "tr" ) );
            row.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-row" ) );
            doc.appendChild( row );
            count = 0;
        }

        col = doc.createElement( QString::fromLatin1( "td" ) );
        col.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-col" ) );
        row.appendChild( col );

        if (first.isEmpty())
            first = namePage( width, height, fileName);
        else
            last = namePage( width, height, fileName);

        if (!Utilities::isVideo(fileName))
        {
            QMimeDatabase db;
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"%4\", \"" )
                    .arg( nameImage( fileName, width ) )
                    .arg( nameImage( fileName, m_setup.thumbSize()) )
                    .arg( nameImage( fileName, maxImageSize()) )
                    .arg( db.mimeTypeForFile( nameImage( fileName, maxImageSize() ) ).name() );
        } else {
            QMimeDatabase db;
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\"" )
                    .arg( nameImage( fileName, m_setup.thumbSize() ) )
                    .arg( nameImage( fileName, m_setup.thumbSize() ) )
                    .arg( nameImage( fileName, maxImageSize() ) );
            if ( m_setup.html5VideoGenerate() )
            {
                images += QString::fromLatin1( ", \"%1\", \"" )
                        .arg( QString::fromLatin1( "video/ogg" ) );
            } else {
                images += QString::fromLatin1( ", \"%1\", \"" )
                        .arg( db.mimeTypeForFile( fileName.relative(), QMimeDatabase::MatchExtension).name() );
            }
            enableVideo = 1;
        }

        // -------------------------------------------------- Description
        if ( !info->description().isEmpty() && m_setup.includeCategory( QString::fromLatin1( "**DESCRIPTION**" )) )
        {
            images += QString::fromLatin1( "%1\", \"" )
                    .arg( info->description()
                          .replace( QString::fromLatin1( "\n$" ), QString::fromLatin1( "" ) )
                          .replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) )
                          .replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) ) );
        } else {
            images += QString::fromLatin1( "\", \"" );
        }
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if ( !description.isEmpty() )
        {
            description = QString::fromLatin1 ( "<ul>%1</ul>" ).arg ( description );
        } else {
            description = QString::fromLatin1 ( "" );
        }

        description.replace( QString::fromLatin1( "\n$" ), QString::fromLatin1 ( "" ) );
        description.replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) );
        description.replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) );

        images += description;
        images += QString::fromLatin1( "\"]);\n" );

        QDomElement href = doc.createElement( QString::fromLatin1( "a" ) );
        href.setAttribute( QString::fromLatin1( "href" ),
                           namePage( width, height, fileName));
        col.appendChild( href );

        QDomElement img = doc.createElement( QString::fromLatin1( "img" ) );
        img.setAttribute( QString::fromLatin1( "src" ),
                          nameImage( fileName, m_setup.thumbSize() ) );
        img.setAttribute( QString::fromLatin1( "alt" ),
                          nameImage( fileName, m_setup.thumbSize() ) );
        href.appendChild( img );
        ++count;
    }
```

#### AUTO 


```{c}
const auto *bin
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : allActions) {
        action->setShortcutContext(Qt::WindowShortcut);
        addAction(action);
    }
```

#### AUTO 


```{c}
const auto sameFN = FileName::fromAbsolutePath(absoluteFilePath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : categoriesForImage) {
            auto catPtr = DB::ImageDB::instance()->categoryCollection()->categoryForName(category);
            if (!categories.contains(category) && !(catPtr && catPtr->isSpecialCategory())) {
                categories.append(category);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        const QString categoryName = category->name();
        if (category->isSpecialCategory())
            continue;
        // I don't know why any categories except the above should be excluded
        //if ( category->doShow() ) {
        const Utilities::StringSet items = m_info->itemsOfCategory(categoryName);
        for (const QString &tag : items) {
            tags.append(tag);
            // digikam compatible tag path:
            // note: this produces a semi-flattened hierarchy.
            // instead of "Places/France/Paris" this will yield "Places/Paris"
            tagspath.append(categoryName + sep + tag);
        }
        //}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &tag : positionableTagCandidates) {
                QAction *action = new QAction(
                    tag.second + QString::fromLatin1(" (") +
                    _dialog->localizedCategory(tag.first) +
                    QString::fromLatin1(")"), this
                );

                QStringList data;
                data << tag.first << tag.second;
                action->setData(data);

                submenu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, QStringLiteral("value"));
            writer.writeAttribute(QStringLiteral("value"), tagName);
            writer.writeAttribute(QStringLiteral("id"),
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(QStringLiteral("birthDate"), birthDate.toString(Qt::ISODate));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : DB::ImageDB::instance()->files()) {
        loadedFiles.insert(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : allImages) {
        if (!fileName.exists())
            notOnDisk.append(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
        ls->populate();
    }
```

#### AUTO 


```{c}
const auto actions = m_actions->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : qAsConst(orderedList)) {
        if (widget->property("FocusCandidate").isValid() && widget->isVisible()) {
            widget->setFocus();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        DB::ImageInfoPtr imgInfo = fileName.info();
        Q_ASSERT(imgInfo);
        if (imgInfo->isStacked()) {
            stacks << imgInfo->stackId();
            stackOrder = qMax(stackOrder, imgInfo->stackOrder() + 1);
        } else {
            images << imgInfo;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Marble::RenderPlugin *plugin : renderPlugins) {
        if (plugin->renderType() != Marble::RenderPlugin::PanelRenderType) {
            continue;
        }

        const QString name = plugin->nameId();
        if (!WANTED_FLOATERS.contains(name)) {
            continue;
        }

        QPushButton *button = new QPushButton;
        button->setCheckable(true);
        button->setFlat(true);
        button->setChecked(plugin->action()->isChecked());
        button->setToolTip(plugin->description());
        button->setProperty("floater", name);

        QPixmap icon = plugin->action()->icon().pixmap(QSize(20, 20));
        if (icon.isNull()) {
            icon = QPixmap(20, 20);
            icon.fill(palette().button().color());
        }
        button->setIcon(icon);

        connect(plugin->action(), &QAction::toggled, button, &QPushButton::setChecked);
        connect(button, &QPushButton::toggled, plugin->action(), &QAction::setChecked);
        floatersLayout->addWidget(button);
        const QVariant checked = group.readEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX + name,
                                                 true);
        button->setChecked(checked.toBool());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : categories)
        this->categories[category] = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &oldFileName : matchingFiles) {
            dir.rename(oldFileName, oldName + oldFileName.mid(newName.length()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, QStringLiteral("value"));
            writer.writeAttribute(QStringLiteral("value"), itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(QStringLiteral("area"), areaToString(area));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
            res.insert(qMakePair(offer->name(), offer->icon()));
            m_appToMimeTypeMap[offer->name()].insert(type);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tagString : list) {
                int id = tagString.toInt();
                if (id != 0 || categoryPtr->isSpecialCategory()) {
                    const QString name = static_cast<const XMLCategory *>(categoryPtr.data())->nameForId(id);
                    info->addCategoryInfo(categoryName, name);
                } else {
                    QStringList tags = static_cast<const XMLCategory *>(categoryPtr.data())->namesForId(id);
                    if (tags.size() == 1) {
                        qCInfo(XMLDBLog) << "Fixing tag " << categoryName << "/" << tags[0] << "with id=0 for image" << info->fileName().relative();
                    } else {
                        // insert marker category
                        QString markerTag = i18n("KPhotoAlbum - manual repair needed (%1)",
                                                 tags.join(i18nc("Separator in a list of tags", ", ")));
                        categoryPtr->addItem(markerTag);
                        info->addCategoryInfo(categoryName, markerTag);
                        qCWarning(XMLDBLog) << "Manual fix required for image" << info->fileName().relative();
                        qCWarning(XMLDBLog) << "Image was marked with tag " << categoryName << "/" << markerTag;
                    }
                    for (const auto &name : tags) {
                        info->addCategoryInfo(categoryName, name);
                    }
                }
            }
```

#### AUTO 


```{c}
const auto name = (*it)->name();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        QString file = fileName.absolute();
        QString zippedName = m_filenameMapper.uniqNameFor(fileName);

        if (m_maxSize == -1 || Utilities::isVideo(fileName) || isRAW(fileName)) {
            if (QFileInfo(file).isSymLink())
                file = QFileInfo(file).readLink();

            if (m_location == Inline)
                m_zip->addLocalFile(file, QString::fromLatin1("Images/") + zippedName);
            else if (m_location == AutoCopy)
                Utilities::copyOrOverwrite(file, m_destdir + QString::fromLatin1("/") + zippedName);
            else if (m_location == Link)
                Utilities::makeHardLink(file, m_destdir + QString::fromLatin1("/") + zippedName);
            else if (m_location == Symlink)
                Utilities::makeSymbolicLink(file, m_destdir + QString::fromLatin1("/") + zippedName);

            m_steps++;
            m_progressDialog->setValue(m_steps);
        } else {
            m_filesRemaining++;
            ImageManager::ImageRequest *request = new ImageManager::ImageRequest(DB::FileName::fromAbsolutePath(file), QSize(m_maxSize, m_maxSize), 0, this);
            request->setPriority(ImageManager::BatchTask);
            ImageManager::AsyncLoader::instance()->load(request);
        }

        // Test if the cancel button was pressed.
        qApp->processEvents(QEventLoop::AllEvents);

        if (m_progressDialog->wasCanceled()) {
            *m_ok = false;
            return;
        }
    }
```

#### AUTO 


```{c}
const auto categories = db->m_categoryCollection.categories();
```

#### CONST EXPRESSION 


```{c}
constexpr int IMAGE_SCOUT_THREAD_COUNT = 1;
```

#### AUTO 


```{c}
const auto stackedImages = DB::ImageDB::instance()->getStackFor(prev->fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : qAsConst(items)) {
                    if (first)
                        first = false;
                    else
                        infoText += QString::fromLatin1(", ");

                    if (linkMap) {
                        ++link;
                        (*linkMap)[link] = QPair<QString, QString>(categoryName, item);
                        infoText += QString::fromLatin1("<a href=\"%1\">%2</a>").arg(link).arg(item);
                        infoText += formatAge(category, item, info);
                    } else
                        infoText += item;
                }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("<html><h1>Missing back-end</h1>"
                                     "The back-ends which are not available are due to the system configuration at compile time of KPhotoAlbum. "
                                     "If you compiled KPhotoAlbum yourself, then search for the developer packages of the back-ends. "
                                     "If you on the other hand got KPhotoAlbum from your system, then please talk to the maintainer of the package.</html>"));
```

#### RANGE FOR STATEMENT 


```{c}
for( DatabaseElement *e : fields )
            {
                e->setValue( query.value(i++) );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ImageDecoder *decoder : *decoders()) {
        if (decoder->_decode(img, imageFile, fullSize, dim))
            return true;
    }
```

#### AUTO 


```{c}
const auto categoryInfomationKeys = m_categoryInfomation.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : files) {
        tmp << fileName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &fileName : files ) {
        tmp << fileName;
    }
```

#### AUTO 


```{c}
auto key = qMakePair(category,item);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const DB::ImageInfo &item) -> bool {
                                                  return item.description() == m_firstDescription;
                                              }
```

#### AUTO 


```{c}
const auto itemsInclCategories = DB::ImageDB::instance()->categoryCollection()->categoryForName(category)->itemsInclCategories();
```

#### AUTO 


```{c}
const auto targetDirectory = QUrl::fromLocalFile(QFileDialog::getExistingDirectory(parent, title, m_lastTarget, QFileDialog::ShowDirsOnly));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &block : qAsConst(blockList)) {
        ElementWriter dummy(writer, QString::fromLatin1("block"));
        writer.writeAttribute(QString::fromLatin1("file"), block.relative());
    }
```

#### AUTO 


```{c}
const auto category = categoryCollection->categoryForName(action->data().value<QString>());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& remoteImage : keys) {
        remoteImage->update(); // Clear the image and request it anew
    }
```

#### AUTO 


```{c}
const auto categoryMatchSettings = settings.categoryMatchSetting();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &current : others) {
        const auto currentInfo = DB::ImageDB::instance()->info(current);
        if (current == image) {
            currentInfo->setStackOrder(1);
        } else if (currentInfo->stackOrder() < oldOrder) {
            currentInfo->setStackOrder(currentInfo->stackOrder() + 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( StringSet &set: groupMap ) {
        if ( set.contains( oldName ) ) {
            set.remove( oldName );
            set.insert( newName );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_imageList)) {
        const DB::ImageInfoPtr imageInfo = DB::ImageDB::instance()->info(fileName);
        if (!m_filter.match(imageInfo))
            continue;
        if (imageInfo && imageInfo->isStacked()) {
            DB::StackID stackid = imageInfo->stackId();
            if (alreadyShownStacks.contains(stackid))
                continue;
            StackMap::iterator found = stackContents.find(stackid);
            Q_ASSERT(found != stackContents.end());
            const StackList &orderedStack = *found;
            if (m_expandedStacks.contains(stackid)) {
                for (const DB::FileName &fileName : orderedStack) {
                    m_displayList.append(fileName);
                }
            } else {
                m_displayList.append(orderedStack.at(0));
            }
            alreadyShownStacks.insert(stackid);
        } else {
            m_displayList.append(fileName);
        }
    }
```

#### AUTO 


```{c}
const auto images = DB::ImageDB::instance()->files();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& categoryName : info->availableCategories()) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(categoryName);
        CategoryItemDetailsList list;
        for ( const QString& item : info->itemsOfCategory(categoryName) ) {
            const QString age = Utilities::formatAge(category, item, info);
            list.append(CategoryItemDetails(item, age));
        }
        result.categories[categoryName] = list;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QPair<QLabel*,QLabel*> tuple : m_labels ) {
        const bool matches = tuple.first->text().contains( search, Qt::CaseInsensitive ) && search.length() != 0;
        QPalette pal = tuple.first->palette();
        pal.setBrush(QPalette::Foreground, matches ? Qt::red : Qt::black);
        tuple.first->setPalette(pal);
        tuple.second->setPalette(pal);
        QFont fnt = tuple.first->font();
        fnt.setBold(matches);
        tuple.first->setFont(fnt);
        tuple.second->setFont(fnt);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const DB::FileName &fileName) {
                       return m_imageNameStore[fileName];
                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files)
        append(DB::FileName::fromAbsolutePath(file));
```

#### AUTO 


```{c}
auto info = DB::ImageDB::instance()->info(fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        QPair<QString, QString> tagData = area->tagData();
        if (!tagData.first.isEmpty()) {
            taggedAreas[tagData.first][tagData.second] = area->actualCoordinates();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int volume) { m_audioDevice->setVolume(volume / 100.0); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : items) {
            QDomElement val = doc.createElement(QString::fromLatin1("value"));
            val.setAttribute(QString::fromLatin1("value"), item);
            opt.appendChild(val);
            any = true;
            anyAtAll = true;
        }
```

#### AUTO 


```{c}
auto *col = new CategoryImageCollection(context, category, it.key());
```

#### AUTO 


```{c}
auto &areasOfCategory
```

#### AUTO 


```{c}
constexpr auto CFG_DISABLED { "_disabled" };
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : images) {
        ImageInfoPtr iInfo = info(fileName);

        ImageDate::MatchType match = iInfo->date().isIncludedIn(range);
        if (match == DB::ImageDate::ExactMatch ||
            (includeRanges && match == DB::ImageDate::RangeMatch)) {
            if (candidate.isNull() ||
                iInfo->date().start() < candidateDateStart) {
                candidate = fileName;
                // Looking at this, can't this just be iInfo->date().start()?
                // Just in the middle of refactoring other stuff, so leaving
                // this alone now. TODO(hzeller): revisit.
                candidateDateStart = info(candidate)->date().start();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        this->slotOptions();
        m_settingsDialog->activatePage(Settings::SettingsPage::ThumbnailsPage);
    }
```

#### AUTO 


```{c}
const auto &positionedTag
```

#### AUTO 


```{c}
const auto allAreas = areas();
```

#### CONST EXPRESSION 


```{c}
constexpr int THUMBNAIL_FILE_VERSION_MIN = 4;
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Marble::RenderPlugin *plugin : m_mapWidget->renderPlugins()) {
        if (plugin->renderType() != Marble::RenderPlugin::PanelRenderType) {
            continue;
        }

        QPushButton *button = new QPushButton;
        button->setCheckable(true);
        button->setFlat(true);
        button->setChecked(plugin->action()->isChecked());
        button->setToolTip(plugin->description());
        const QString name = plugin->name();
        button->setProperty("floater", name);

        QPixmap icon = plugin->action()->icon().pixmap(QSize(20, 20));
        if (icon.isNull()) {
            icon = QPixmap(20, 20);
            icon.fill(Qt::white);
        }
        button->setIcon(icon);

        connect(plugin->action(), &QAction::toggled, button, &QPushButton::setChecked);
        connect(button, &QPushButton::toggled, plugin->action(), &QAction::setChecked);
        floatersLayout->addWidget(button);

        const QString value = group.readEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX + name);
        if (! value.isEmpty()) {
            button->setChecked(value == QStringLiteral("true") ? true : false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : namesForId(0)) {
        m_idMap.remove(tag);
    }
```

#### AUTO 


```{c}
auto keys = ::Settings::SettingsData::instance()->exifForDialog();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress &address : QNetworkInterface::allAddresses()) {
        if (address.isLoopback() || address.toIPv4Address() == 0)
            continue;
        result.append(address.toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : _setup.imageList()) {
        if ( wasCancelled() )
            return;

        createImage(fileName, _setup.thumbSize());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        if (category->type() == DB::Category::MediaTypeCategory
            || category->type() == DB::Category::FolderCategory) {
            continue;
        }
        m_category->addItem(category->name(), category->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        const DB::ImageInfoPtr info = fileName.info();
        if (info && info->isStacked())
            m_allStacks << info->stackId();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category : m_categories) {
        if (include == IncludeSpecialCategories::Yes || !category->isSpecialCategory())
            res.append(category->name());
    }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(TimeCommand)
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : search(searchInfo)) {
        if (info(fileName)->mediaType() == Image)
            ++images;
        else
            ++videos;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QString &category : categories ) {
                QString oldName = category;
                category = m_newToOldName.key(oldName,oldName );
                QString lockEntry = privacyConfig.readEntry<QString>(oldName, QString());
                if (! lockEntry.isEmpty() )
                {
                    privacyConfig.writeEntry<QString>(category, lockEntry);
                    privacyConfig.deleteEntry(oldName);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : members) {
                QAction *action = categoryMenu->addAction(member);
                action->setObjectName(categoryName);
                action->setData(member);
                categoryMenuEnabled = true;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[imageId, size, type, timer, client, this]() {
        ThumbnailRequest request(imageId, size, type);

        RemoteInterface::instance().sendCommand(request);

        RequestType key = qMakePair(imageId, type);
        m_requestMap.insert(key, client);
        m_reverseRequestMap.insert(client, key);

        connect(client, &QObject::destroyed, this, &ImageStore::clientDeleted);
        timer->deleteLater();
    }
```

#### AUTO 


```{c}
const auto avCmd = QString::fromLatin1("%1 -y -i %2  -vcodec libx264 -b 250k -bt 50k -acodec libfaac -ab 56k -ac 2 -s %3 %4")
                                   .arg(m_avconv)
                                   .arg(fileName.absolute())
                                   .arg(QString::fromLatin1("320x240"))
                                   .arg(destName.replace(QRegExp(QString::fromLatin1("\\..*")), QString::fromLatin1(".mp4")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        layout->addWidget(headerLabel(group), row++, 0, 1, 4);

        // Items of group
        const QMap<QString, QStringList> items = itemsForGroup(group, map);
        QStringList sorted = items.keys();
        sorted.sort();
        int elements = sorted.size();
        int perCol = (elements + 1) / 2;
        int count = 0;
        for (const QString &key : sorted) {
            const int subrow = (count % perCol);
            const QPalette::ColorRole role = (subrow & 1) ? QPalette::Base : QPalette::AlternateBase;
            QPair<QLabel *, QLabel *> pair = infoLabelPair(exifNameNoGroup(key), items[key].join(QLatin1String(", ")), role);

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row + subrow, col);
            layout->addWidget(pair.second, row + subrow, col + 1);
            count++;
        }
        row += perCol;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MAX_FILE_SIZE=32*1024*1024;
```

#### AUTO 


```{c}
auto* col = new CategoryImageCollection( context, category, it.key() );
```

#### AUTO 


```{c}
auto d = 3.14159;
```

#### AUTO 


```{c}
auto answer = KMessageBox::warningContinueCancel(this, msg, title, KStandardGuiItem::cont(), KStandardGuiItem::cancel(), dialogId);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { QTimer::singleShot(0, this, SLOT(updateLayout())); }
```

#### AUTO 


```{c}
const auto clipBoardImages = m_db->m_clipboard;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &filename : qAsConst(m_imageList)) {
        if (filename == info->fileName())
            break;
        ++m_curIndex;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MAX_FILE_SIZE = 32 * 1024 * 1024;
```

#### AUTO 


```{c}
auto page = m_pages.value(pageId, nullptr);
```

#### AUTO 


```{c}
const auto slash = QStringLiteral("/");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& text : items) {
        if (! m_filter->text().isEmpty()
            && text.indexOf(m_filter->text(), 0, Qt::CaseInsensitive) == -1) {
            continue;
        }

        QTableWidgetItem* nameItem = new QTableWidgetItem(text);
        nameItem->setFlags(nameItem->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
        m_dataView->setItem(row, 0, nameItem);

        QDate dateForItem;
        if (m_changedData.contains(categoryName)) {
            if (m_changedData[categoryName].contains(text)) {
                dateForItem = m_changedData[categoryName][text];
            } else {
                dateForItem = category->birthDate(text);
            }
        } else {
            dateForItem = category->birthDate(text);
        }

        DateTableWidgetItem* dateItem = new DateTableWidgetItem(textForDate(dateForItem));
        dateItem->setData(Qt::UserRole, dateForItem);
        dateItem->setFlags(dateItem->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
        m_dataView->setItem(row, 1, dateItem);

        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
            const DB::ImageInfoPtr info = fileName.info();
            int grps = info->availableCategories().length();
            if (grps > maxCatsInText - 2) {
                grps -= info->itemsOfCategory(folder).empty() ? 1 : 2;
                if (grps > maxCatsInText)
                    maxCatsInText = grps;
            }
        }
```

#### AUTO 


```{c}
auto backend = preferredVideoBackend(SettingsData::instance()->videoBackend());
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Image );

        // FIXME: exclude videos
        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Video );
        const bool enabled = (images.count() + videos.count() > 1);
        CategoryViewType type =
                (category->viewType() == DB::Category::IconView || category->viewType() == DB::Category::ThumbedIconView)
                ? Types::CategoryIconView : Types::CategoryListView;

        const QImage icon = category->icon(search.size, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({category->name(), category->text(), icon, enabled, type});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : allImages) {
        dialog.setValue(i++);
        if (info->mediaType() == DB::Image) {
            add(info->fileName());
        }
        if (i % 10)
            qApp->processEvents();
        if (dialog.wasCanceled())
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_list)) {
        if (modifiedFileCompString.length() >= 0 && fileName.relative().contains(modifiedFileComponent)) {

            for (QStringList::const_iterator it = originalFileComponents.constBegin();
                 it != originalFileComponents.constEnd(); ++it) {
                QString tmp = fileName.relative();
                tmp.replace(modifiedFileComponent, (*it));
                DB::FileName originalFileName = DB::FileName::fromRelativePath(tmp);

                if (originalFileName != fileName && m_list.contains(originalFileName)) {
                    const auto info = DB::ImageDB::instance()->info(fileName);
                    DB::MD5 sum = info->MD5Sum();
                    if (tostack[sum].isEmpty()) {
                        if (m_origTop->isChecked()) {
                            tostack.insert(sum, DB::FileNameList() << originalFileName);
                            tostack[sum].append(fileName);
                        } else {
                            tostack.insert(sum, DB::FileNameList() << fileName);
                            tostack[sum].append(originalFileName);
                        }
                    } else
                        tostack[sum].append(fileName);
                    break;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        this->slotOptions();
        m_settingsDialog->activatePage(Settings::SettingsPage::ThumbnailsPage);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* child : andMatcher->mp_elements) {
            SimpleCategoryMatcher* simpleMatcher = dynamic_cast<SimpleCategoryMatcher*>( child );
            Q_ASSERT( simpleMatcher );
            result.append( simpleMatcher );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DB::FileName& tmp : oldStack ) {
                tostack.append( tmp );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : kpaDemoDirs) {
        QDirIterator it(dir, QStringList() << QStringLiteral("*.jpg") << QStringLiteral("*.avi"));
        while (it.hasNext()) {
            images.append(it.next());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ImageInfoPtr& info : *this)
        res.append(info->fileName());
```

#### AUTO 


```{c}
const auto nullComparisonWarning = "FileName for comparison is null!";
```

#### AUTO 


```{c}
const auto &fileName
```

#### RANGE FOR STATEMENT 


```{c}
for (const Breadcrumb& item : latest() )
        list.append( item.text() );
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        try {
            Exiv2::Image::AutoPtr image = Exiv2::ImageFactory::open(fileName.absolute().toLocal8Bit().data());
            Q_ASSERT(image.get() != nullptr);
            image->readMetadata();
            map << DBExifInfo(fileName, image->exifData());
        } catch (...) {
            qCWarning(ExifLog, "Error while reading exif information from %s", qPrintable(fileName.absolute()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const DB::FileName& fileName) { return fileName.relative(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SeekInfo &info : list) {
        if (count++ == 5) {
            QAction *sep = new QAction(menu);
            sep->setSeparator(true);
            menu->addAction(sep);
        }

        QAction *seek = m_actions->addAction(QString::fromLatin1(info.name), m_videoDisplay, SLOT(seek()));
        seek->setText(info.title);
        seek->setData(info.value);
        seek->setShortcut(info.key);
        m_actions->setShortcutsConfigurable(seek, false);
        menu->addAction(seek);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (!shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, QStringLiteral("Category"));
        writer.writeAttribute(QStringLiteral("name"), name);
        writer.writeAttribute(QStringLiteral("icon"), category->iconName());
        writer.writeAttribute(QStringLiteral("show"), QString::number(category->doShow()));
        writer.writeAttribute(QStringLiteral("viewtype"), QString::number(category->viewType()));
        writer.writeAttribute(QStringLiteral("thumbnailsize"), QString::number(category->thumbnailSize()));
        writer.writeAttribute(QStringLiteral("positionable"), QString::number(category->positionable()));
        if (category == tokensCategory) {
            writer.writeAttribute(QStringLiteral("meta"), QStringLiteral("tokens"));
        }

        // As bug 423334 shows, it is easy to forget to add a group to the respective category
        // when it's created. We can not enforce correct creation of member groups in our API,
        // but we can prevent incorrect data from entering index.xml.
        const auto categoryItems = Utilities::mergeListsUniqly(category->items(), m_db->memberMap().groups(name));
        for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, QStringLiteral("value"));
            writer.writeAttribute(QStringLiteral("value"), tagName);
            writer.writeAttribute(QStringLiteral("id"),
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(QStringLiteral("birthDate"), birthDate.toString(Qt::ISODate));
        }
    }
```

#### AUTO 


```{c}
auto *layout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        add(fileName.info()->date());
    }
```

#### AUTO 


```{c}
constexpr auto v5IndexHexData {
    "00000005" // version
    "000001c4" // v5: thumbnailsize
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
};
```

#### CONST EXPRESSION 


```{c}
constexpr int terminationWait = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (QLabel *label : m_labelWidgets) {
        const QString title = label->text();
        for (int index = 0; index < title.length(); ++index) {
            const QChar ch = title[index].toLower();
            if (!m_taken.contains(ch)) {
                m_taken.insert(ch);
                label->setText(title.left(index) + QString::fromLatin1("&") + title.mid(index));
                break;
            }
        }
    }
```

#### AUTO 


```{c}
const auto absoluteUrl1 = QUrl::fromLocalFile(absoluteFilePath1).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : container) {
        res += fn(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
                DB::ImageInfoPtr info = DB::ImageDB::instance()->info(fileName);
                if (!hadHit) {
                    mustRemoveToken = info->hasCategoryInfo(tokensCategory->name(), token);
                    hadHit = true;
                }

                if (mustRemoveToken)
                    info->removeCategoryInfo(tokensCategory->name(), token);
                else
                    info->addCategoryInfo(tokensCategory->name(), token);

                model()->updateCell(fileName);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::CategoryPtr category : categories) {
        if (!category->isSpecialCategory()) {
            m_category->addItem(category->name(), category->name());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category : categories) {
        KToggleAction *taction = actions->add<KToggleAction>(category->name());
        m_actionList.append(taction);
        taction->setText(category->name());
        taction->setData(category->name());
        addAction(taction);
        connect(taction, &KToggleAction::toggled, this, &VisibleOptionsMenu::toggleShowCategory);
    }
```

#### AUTO 


```{c}
auto addRotateAction = [this](const QString &title, int angle, const QKeySequence &shortcut, const QString &actionName) {
        auto *action = new QAction(title);
        connect(action, &QAction::triggered, [this, angle] { rotate(angle); });
        action->setShortcut(shortcut);
        m_actions->setShortcutsConfigurable(action, false);
        m_actions->addAction(actionName, action);
        m_rotateMenu->addAction(action);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &image : list) {
        add(image->date());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto tag : selectedTags ) {
                QRect area = m_editList[m_current].areaForTag(category, tag);
                if (area.isNull()) {
                    // no associated area yet
                    addTagToCandidateList(category, tag);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto category : m_db->categoryCollection()->categories()) {
            XMLCategory *xmlCategory = static_cast<XMLCategory *>(category.data());
            xmlCategory->clearNullIds();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( DatabaseElement *e : fields )
        {
            e->setValue( query.value(i++) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &fileName : m_fileList ) {
        QString dir = getDirName(fileName);
        if (! dirMap.contains( dir ) ) {
            StringSet newDir;
            dirMap.insert(dir, newDir);
            dirList << dir;
        }
        dirMap[ dir ] << fileName;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int v4FileVersion = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &text : items) {
        if (!m_filter->text().isEmpty()
            && text.indexOf(m_filter->text(), 0, Qt::CaseInsensitive) == -1) {
            m_dataView->setRowCount(m_dataView->rowCount() - 1);
            continue;
        }

        QTableWidgetItem *nameItem = new QTableWidgetItem(text);
        nameItem->setFlags(nameItem->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
        m_dataView->setItem(row, 0, nameItem);

        QDate dateForItem;
        if (m_changedData.contains(categoryName)) {
            if (m_changedData[categoryName].contains(text)) {
                dateForItem = m_changedData[categoryName][text];
            } else {
                dateForItem = category->birthDate(text);
            }
        } else {
            dateForItem = category->birthDate(text);
        }

        DateTableWidgetItem *dateItem = new DateTableWidgetItem(textForDate(dateForItem));
        dateItem->setData(Qt::UserRole, dateForItem);
        dateItem->setFlags(dateItem->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
        m_dataView->setItem(row, 1, dateItem);

        row++;
    }
```

#### AUTO 


```{c}
auto backend = Settings::SettingsData::instance()->videoBackend();
```

#### AUTO 


```{c}
const auto &members = m_closureMembers[category][memberGroup];
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryItem& item : items) {
        stream << item.text;
        encodeImage(stream,item.icon);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_setup.imageList()) {
        if ( wasCanceled() )
            return;

        createImage(fileName, m_setup.thumbSize());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_thumbnailsToBuild) {
        DB::ImageInfoPtr info = fileName.info();
        if (ImageManager::AsyncLoader::instance()->isExiting()) {
            cancelRequests();
            break;
        }
        if (info->isNull()) {
            m_loadedCount++;
            m_count++;
            continue;
        }

        ImageManager::ImageRequest *request
            = new ImageManager::PreloadRequest(fileName,
                                               ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                               this);
        request->setIsThumbnailRequest(true);
        request->setPriority(ImageManager::BuildThumbnails);
        if (ImageManager::AsyncLoader::instance()->load(request))
            ++numberOfThumbnailsToBuild;
    }
```

#### AUTO 


```{c}
auto it = tempHash.constBegin();
```

#### AUTO 


```{c}
auto it = m_hash.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, offer, which] {
                runService(offer, relevantUrls(which, offer));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileName& fileName : list) {
        if ( count % 10 == 0 ) {
            dialog.setValue( count ); // ensure to call setProgress(0)
            qApp->processEvents( QEventLoop::AllEvents );

            if ( dialog.wasCanceled() ) {
                if ( wasCanceled )
                    *wasCanceled = true;
                return dirty;
            }
        }

        MD5 md5 = Utilities::MD5Sum( fileName );
        if (md5.isNull()) {
            cantRead << fileName;
            continue;
        }

        ImageInfoPtr info = ImageDB::instance()->info(fileName);
        if  ( info->MD5Sum() != md5 ) {
            info->setMD5Sum( md5 );
            dirty = true;
            ImageManager::ThumbnailCache::instance()->removeThumbnail(fileName);
        }

        md5Map->insert( md5, fileName );

        ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        const auto info = DB::ImageDB::instance()->info(fileName);
        ImageManager::ImageRequest *request = new ImageManager::ImageRequest(fileName, QSize(128, 128), info->angle(), this);
        request->setPriority(ImageManager::BatchTask);
        ImageManager::AsyncLoader::instance()->load(request);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& item: info->itemsOfCategory(m_category))
        if ( !matchedTags[m_category].contains(item) )
            return false;
```

#### LAMBDA EXPRESSION 


```{c}
[this, which] {
            const QList<QUrl> urls = relevantUrls(which, {});

            auto *uiParent = MainWindow::Window::theMainWindow();
#if KIO_VERSION < QT_VERSION_CHECK(5, 71, 0)
            KRun::displayOpenWithDialog(urls, uiParent);
#else
                auto job = new KIO::ApplicationLauncherJob();
                job->setUrls(urls);
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, uiParent));
                job->start();
#endif
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->name() == i18n("Media Type"))
            continue;
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Image );

        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Video );
        const bool enabled = (images.count() /*+ videos.count()*/ > 1);
        CategoryViewType type =
                (category->viewType() == DB::Category::IconView || category->viewType() == DB::Category::ThumbedIconView)
                ? Types::CategoryIconView : Types::CategoryListView;

        const QImage icon = category->icon(search.size, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({category->name(), icon, enabled, type});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, _value_);
            writer.writeAttribute(_value_, itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(_area_, areaToString(area));
            }
        }
```

#### AUTO 


```{c}
const auto subCluster = topLevelCluster->regionForPoint(mapPos);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->type() == DB::Category::MediaTypeCategory)
            continue;
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Image );

        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( dbSearchInfo, category->name(), DB::Video );
        const bool enabled = (images.count() /*+ videos.count()*/ > 1);
        CategoryViewType type =
                (category->viewType() == DB::Category::IconView || category->viewType() == DB::Category::ThumbedIconView)
                ? Types::CategoryIconView : Types::CategoryListView;

        const QImage icon = category->icon(search.size, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({category->name(), icon, enabled, type});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
        subCluster->render(painter, viewPortParams, alternatePixmap, style);
    }
```

#### AUTO 


```{c}
auto it = m_matchingTags.constKeyValueBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for( QDockWidget* dock : m_dockWidgets ) {
        if ( dock->isFloating() )
        {
            qCDebug(AnnotationDialogLog) << "Hiding dock: " << dock->objectName();
            dock->hide();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& group : groups ) {
                if ( !countedGroupDict.contains( group ) ) {
                    countedGroupDict.insert( group );
                    (m_groupCount[group])++;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<SimpleCategoryMatcher *> currentIt : current) {
                QList<SimpleCategoryMatcher *> tmp;
                tmp += resultIt;
                tmp += currentIt;
                result.append(tmp);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *optionMatcher : m_compiled.categoryMatchers) {
        if (!optionMatcher->eval(info, alreadyMatched))
            return false;
    }
```

#### AUTO 


```{c}
const auto relativeFN = FileName::fromAbsolutePath(cwd.relativeFilePath(m_tmpDir.path() + QStringLiteral("/test.jpg")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &image : m_images) {
        const Marble::GeoDataCoordinates pos(image->coordinates().lon(), image->coordinates().lat(),
                                             image->coordinates().alt(),
                                             Marble::GeoDataCoordinates::Degree);
        if (viewPort.contains(pos)) {
            if (style == MapStyle::ShowPins) {
                painter->drawPixmap(pos, thumbs.alternatePixmap);
            } else {
                if (thumbs.thumbnailSizePx != m_thumbnailSizePx) {
                    m_scaledThumbnailCache.clear();
                    m_thumbnailSizePx = thumbs.thumbnailSizePx;
                }
                if (!m_scaledThumbnailCache.contains(image)) {
                    QPixmap thumb = thumbs.cache->lookup(image->fileName()).scaled(QSize(thumbs.thumbnailSizePx, thumbs.thumbnailSizePx), Qt::KeepAspectRatio);
                    m_scaledThumbnailCache.insert(image, thumb);
                }
                painter->drawPixmap(pos, m_scaledThumbnailCache.value(image));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : sorted) {
            const int subrow = (count % perCol);
            const QColor color = (subrow & 1) ? palette().base().color() : palette().alternateBase().color();
            QPair<QLabel *, QLabel *> pair = infoLabelPair(exifNameNoGroup(key), items[key].join(QLatin1String(", ")), color);

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row + subrow, col);
            layout->addWidget(pair.second, row + subrow, col + 1);
            count++;
        }
```

#### AUTO 


```{c}
auto newInfo = DB::ImageDB::instance()->info(newFile);
```

#### AUTO 


```{c}
const auto relativeCorrectFN = FileName::fromRelativePath(imageRoot.relativeFilePath(absoluteFilePath));
```

#### AUTO 


```{c}
const auto absoluteOutsideFilePath = QStringLiteral("/external/path/to/image.jpg");
```

#### AUTO 


```{c}
const auto backupSuffix = QChar::fromLatin1('~');
```

#### AUTO 


```{c}
const auto stackedImages = DB::ImageDB::instance()->getStackFor(a);
```

#### CONST EXPRESSION 


```{c}
constexpr int SCROLL_AMOUNT = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &memberItem : members) {
                    DB::CategoryPtr catPtr = m_db->m_categoryCollection.categoryForName(category);
                    if (!catPtr) { // category was not declared in "Categories"
                        qCWarning(XMLDBLog) << "File corruption in index.xml. Inserting missing category: " << category;
                        catPtr = new XMLCategory(category, QString::fromUtf8("dialog-warning"), DB::Category::TreeView, 32, false);
                        m_db->m_categoryCollection.addCategory(catPtr);
                    }
                    XMLCategory *cat = static_cast<XMLCategory *>(catPtr.data());
                    QString member = cat->nameForId(memberItem.toInt());
                    if (member.isNull())
                        continue;
                    m_db->m_members.addMemberToGroup(category, group, member);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DatabaseElement *e : elements()) {
            query->bindValue(i++, e->valueFromExif(elt.second));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { QTimer::singleShot(0, this, SLOT(updateLayout())); }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* optionMatcher : m_categoryMatchers) {
        ok = ok && optionMatcher->eval(info, alreadyMatched);
    }
```

#### AUTO 


```{c}
const auto absoluteFilePath = imageRoot.absoluteFilePath(QStringLiteral("atest.jpg"));
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *subMatcher : qAsConst(mp_elements)) {
        if (subMatcher->eval(info, alreadyMatched))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_thumbnailsToBuild ) {
        DB::ImageInfoPtr info = fileName.info();
        if ( info->isNull())
        {
            m_count++;
            continue;
        }

        ImageManager::ImageRequest* request
            = new ImageManager::PreloadRequest( fileName,
                                              ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                              this );
        request->setIsThumbnailRequest(true);
        request->setPriority( ImageManager::BuildThumbnails );
        if (ImageManager::AsyncLoader::instance()->load( request ))
            ++numberOfThumbnailsToBuild;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_thumbnailsToBuild) {
        const auto info = DB::ImageDB::instance()->info(fileName);
        if (ImageManager::AsyncLoader::instance()->isExiting()) {
            cancelRequests();
            break;
        }
        if (info->isNull()) {
            m_loadedCount++;
            m_count++;
            continue;
        }

        ImageManager::ImageRequest *request
            = new ImageManager::PreloadRequest(fileName,
                                               preferredThumbnailSize(), info->angle(),
                                               this, m_thumbnailCache);
        request->setIsThumbnailRequest(true);
        request->setPriority(ImageManager::BuildThumbnails);
        if (ImageManager::AsyncLoader::instance()->load(request))
            ++numberOfThumbnailsToBuild;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_thumbnailsToBuild ) {
        DB::ImageInfoPtr info = fileName.info();
        if ( info->isNull())
            continue;

        ImageManager::ImageRequest* request
            = new ImageManager::PreloadRequest( fileName,
                                              ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                              this );
        request->setIsThumbnailRequest(true);
        request->setPriority( ImageManager::BuildThumbnails );
        if (ImageManager::AsyncLoader::instance()->load( request ))
            ++numberOfThumbnailsToBuild;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString& category : oldCategories) {
        QString oldName = category;
        category = sanitizedCategoryName(oldName);
        categories << category;
        QString lockEntry = privacyConfig.readEntry<QString>(oldName, QString());
        if (! lockEntry.isEmpty()) {
            privacyConfig.writeEntry<QString>(category, lockEntry);
            privacyConfig.deleteEntry(oldName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame* area : allAreas) {
                    if (area->tagData().first == category && area->tagData().second == tag) {
                        alreadyAssociated = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (int value : values) {
            orArgs << QString::fromLatin1("(%1 == %2)").arg(key).arg(value);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KService::Ptr offer : qAsConst(offers)) {
            action = submenu->addAction(offer->name());
            action->setIcon(QIcon::fromTheme(offer->icon()));
            action->setEnabled(enabled);
            connect(action, &QAction::triggered, this, [this, offer, which] {
                runService(offer, relevantUrls(which, offer));
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Marble::RenderPlugin *plugin : m_mapWidget->renderPlugins()) {
        if (plugin->renderType() != Marble::RenderPlugin::PanelRenderType) {
            continue;
        }

        const QString name = plugin->name();
        if (!WANTED_FLOATERS.contains(name)) {
            continue;
        }

        QPushButton *button = new QPushButton;
        button->setCheckable(true);
        button->setFlat(true);
        button->setChecked(plugin->action()->isChecked());
        button->setToolTip(plugin->description());
        button->setProperty("floater", name);

        QPixmap icon = plugin->action()->icon().pixmap(QSize(20, 20));
        if (icon.isNull()) {
            icon = QPixmap(20, 20);
            icon.fill(Qt::white);
        }
        button->setIcon(icon);

        connect(plugin->action(), &QAction::toggled, button, &QPushButton::setChecked);
        connect(button, &QPushButton::toggled, plugin->action(), &QAction::setChecked);
        floatersLayout->addWidget(button);
        const QVariant checked = group.readEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX + name,
                                                 true);
        button->setChecked(checked.toBool());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QDockWidget *dock : m_dockWidgets) {
        if (dock->isFloating()) {
            qCDebug(AnnotationDialogLog) << "Hiding dock: " << dock->objectName();
            dock->hide();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        if (area->tagData() == oldTagData) {
            area->setTagData(category, newTag);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &dirName : dirList ) {
        const StringSet &files(dirMap[dirName]);
        FastDir dir(dirName);
        QStringList sortedList = dir.sortFileList(files);
        QString fsName( QString::fromLatin1( "NULLFS" ) );
        if ( stat( QByteArray(QFile::encodeName(dirName)).constData(), &statbuf ) == 0 ) {
            QCryptographicHash md5calculator(QCryptographicHash::Md5);
            QByteArray md5Buffer((const char *) &(statbuf.st_dev), sizeof(statbuf.st_dev));
            md5calculator.addData(md5Buffer);
            fsName = QString::fromLatin1(md5calculator.result().toHex());
        }
        if ( ! m_fsMap.contains( fsName ) ) {
            QStringList newList;
            m_fsMap.insert(fsName, newList);
        }
        m_fsMap[ fsName ] += sortedList;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::ImageInfoPtr info : list) {
        if (DB::ImageDB::instance()->md5Map()->contains(info->MD5Sum()))
            ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
        ls->setSelection(old_info.itemsOfCategory(ls->category()));

        // Also set all positionable tag candidates

        if (ls->positionable()) {
            const QString category = ls->category();
            const QSet<QString> selectedTags = old_info.itemsOfCategory(category);
            const QSet<QString> positionedTagSet = positionedTags(category);

            // Add the tag to the positionable candiate list, if no area is already associated with it
            for (const auto &tag : selectedTags) {
                if (!positionedTagSet.contains(tag)) {
                    addTagToCandidateList(category, tag);
                }
            }

            // Check all areas for a linked tag in this category that is probably not selected anymore
            const auto allAreas = areas();
            for (ResizableFrame *area : allAreas) {
                QPair<QString, QString> tagData = area->tagData();

                if (tagData.first == category) {
                    if (!selectedTags.contains(tagData.second)) {
                        // The linked tag is not selected anymore, so remove it
                        area->removeTagData();
                    }
                }
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto v5IndexHexData {
    "00000005" // version
    "00000100" // v5: thumbnailsize
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageInfoPtr &info : *this) {
        if (info->mediaType() & type) {
            res.append(info->fileName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QueueType &queue : m_jobs) {
        if (index - offset < queue.count())
            return queue[index - offset];
        else
            offset += queue.count();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *action : qAsConst(m_actionList)) {
        action->setChecked(DB::ImageDB::instance()->categoryCollection()->categoryForName(action->data().value<QString>())->doShow());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SerializerInterface* serializer : m_serializers)
        serializer->decode(stream);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *bin : qAsConst(m_geoClusters)) {
        bin->render(painter, *viewPortParams, thumbs, mapStyle());
    }
```

#### AUTO 


```{c}
auto tuple = m_imageNameStore.categoryForId(command.imageId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : list) {
        if (member.isEmpty()) {
            // This can happen if we add group that currently has no members.
            continue;
        }

        if (!alreadyAdded.contains(member)) {
            alreadyAdded << member;

            if (DB::ImageDB::instance()->untaggedCategoryFeatureConfigured()
                && !Settings::SettingsData::instance()->untaggedImagesTagVisible()) {

                if (name == Settings::SettingsData::instance()->untaggedCategory()) {
                    if (member == Settings::SettingsData::instance()->untaggedTag()) {
                        continue;
                    }
                }
            }

            QListWidgetItem *newItem = new QListWidgetItem(member, m_membersListWidget);
            newItem->setFlags(newItem->flags() | Qt::ItemIsUserCheckable);
            newItem->setCheckState(Qt::Unchecked);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(ToggleTokenRequest)
```

#### AUTO 


```{c}
constexpr auto v5IndexHexData {
    "00000005" // version
    "000001c4" // v5: thumbnailsize
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A007000670000000000007BAD00001D" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A007000670000000000000000000022" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F" // "blackie.jpg"
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& text : items) {
        if (!m_filter->text().isEmpty() && text.indexOf(m_filter->text(), 0, Qt::CaseInsensitive) == -1)
            continue;

        QLabel* label = new QLabel(text);
        const QDate date = category->birthDate(text);
        QPushButton* button = new QPushButton(textForDate(date));
        button->setProperty("date", date);
        button->setProperty("name", text);
        connect(button,SIGNAL(clicked()),this,SLOT(editDate()));
        grid->addWidget(label,row,0);
        grid->addWidget(button,row,1);
        ++row;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto CFG_HISTORY { "_crashHistory" };
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            static RunDialog *dialog = new RunDialog(MainWindow::Window::theMainWindow());
            dialog->setImageList(m_list);
            dialog->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_thumbnailsToBuild) {
        const auto info = DB::ImageDB::instance()->info(fileName);
        if (ImageManager::AsyncLoader::instance()->isExiting()) {
            cancelRequests();
            break;
        }
        if (info->isNull()) {
            m_loadedCount++;
            m_count++;
            continue;
        }

        ImageManager::ImageRequest *request
            = new ImageManager::PreloadRequest(fileName,
                                               ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                               this, m_thumbnailCache);
        request->setIsThumbnailRequest(true);
        request->setPriority(ImageManager::BuildThumbnails);
        if (ImageManager::AsyncLoader::instance()->load(request))
            ++numberOfThumbnailsToBuild;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ImageRow *row : qAsConst(m_imagesSelect)) {
        row->m_checkbox->setChecked(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &itemValue : items) {
                QRect area = info->areaForTag(categoryName, itemValue);

                if (area.isValid()) {
                    // Positioned tags can't be stored in the "fast" format
                    // so we have to handle them separately
                    positionedTags[categoryName] << QPair<QString, QRect>(itemValue, area);
                } else {
                    int id = static_cast<const XMLCategory *>(category.data())->idForName(itemValue);
                    idList.append(QString::number(id));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &info : images) {
        info->addCategoryInfo(i18n("Media Type"),
                              info->mediaType() == DB::Image ? i18n("Image") : i18n("Video"));
        m_delayedCache.insert(info->fileName().absolute(), info);
        m_delayedUpdate << info;
    }
```

#### AUTO 


```{c}
auto imageInfo = DB::ImageDB::instance()->info(fileName);
```

#### AUTO 


```{c}
const auto correctFNZ = DB::FileName::fromRelativePath(QStringLiteral("z.jpg"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &badBackend : badBackends) {
            bool ok = false;
            const auto be = static_cast<Settings::VideoBackend>(backendEnum.keyToValue(badBackend.constData(), &ok));
            if (ok) {
                exclusions |= be;
            } else {
                qCWarning(ViewerLog) << "Could not parse crash data:" << badBackend << "is an unknown video backend value! Ignoring...";
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DatabaseElement *e : elements(version)) {
            query.prepare(QString::fromLatin1("alter table exif add column %1")
                              .arg(e->createString()));
            if (!query.exec())
                showErrorAndFail(query);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileName &fileName : *this) {
        res.prepend(fileName);
    }
```

#### AUTO 


```{c}
auto hex = 0x0000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
        m_thumbnailCache->removeThumbnail(fileName);
        BackgroundJobs::HandleVideoThumbnailRequestJob::removeFullScaleFrame(fileName);
        m_model->updateCell(fileName);
    }
```

#### AUTO 


```{c}
const auto re = m_freeformMatcher.regularExpression();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
                    DB::ImageInfoPtr info = fileName.info();
                    info->setRating(rating);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (! shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, QString::fromUtf8("Category"));
        writer.writeAttribute(QString::fromUtf8("name"),  name);
        writer.writeAttribute(QString::fromUtf8("icon"), category->iconName());
        writer.writeAttribute(QString::fromUtf8("show"), QString::number(category->doShow()));
        writer.writeAttribute(QString::fromUtf8("viewtype"), QString::number(category->viewType()));
        writer.writeAttribute(QString::fromUtf8("thumbnailsize"), QString::number(category->thumbnailSize()));
        writer.writeAttribute(QString::fromUtf8("positionable"), QString::number(category->positionable()));

        // FIXME (l3u):
        // Correct me if I'm wrong, but we don't need this, as the tags used as groups are
        // added to the respective category anyway when they're created, so there's no need to
        // re-add them here. Apart from this, adding an empty group (one without members) does
        // add an empty tag ("") doing so.
        /*
        QStringList list =
                Utilities::mergeListsUniqly(category->items(),
                                            m_db->_members.groups(name));
        */

        Q_FOREACH(const QString &tagName, category->items()) {
            ElementWriter dummy( writer, QString::fromLatin1("value") );
            writer.writeAttribute( QString::fromLatin1("value"), tagName );
            writer.writeAttribute( QString::fromLatin1( "id" ),
                                    QString::number(static_cast<XMLCategory*>( category.data() )->idForName( tagName ) ));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute( QString::fromUtf8("birthDate"), birthDate.toString(Qt::ISODate) );
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_LEFT = 0b00001000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &image : images) {
        urls.append(QUrl(image).toString());
    }
```

#### AUTO 


```{c}
auto iterator = m_nameToIdMap.find(fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : *this) {
        if (type == DB::RelativeToImageRoot)
            res.append(fileName.relative());
        else
            res.append(fileName.absolute());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if (wasCanceled())
            return false;

        if (count % cols == 0) {
            row = doc.createElement(QString::fromLatin1("tr"));
            row.setAttribute(QString::fromLatin1("class"), QString::fromLatin1("thumbnail-row"));
            doc.appendChild(row);
            count = 0;
        }

        col = doc.createElement(QString::fromLatin1("td"));
        col.setAttribute(QString::fromLatin1("class"), QString::fromLatin1("thumbnail-col"));
        row.appendChild(col);

        if (first.isEmpty())
            first = namePage(width, height, fileName);
        else
            last = namePage(width, height, fileName);

        if (!Utilities::isVideo(fileName)) {
            QMimeDatabase db;
            images += QString::fromLatin1("gallery.push([\"%1\", \"%2\", \"%3\", \"%4\", \"")
                          .arg(nameImage(fileName, width))
                          .arg(nameImage(fileName, m_setup.thumbSize()))
                          .arg(nameImage(fileName, maxImageSize()))
                          .arg(db.mimeTypeForFile(nameImage(fileName, maxImageSize())).name());
        } else {
            QMimeDatabase db;
            images += QString::fromLatin1("gallery.push([\"%1\", \"%2\", \"%3\"")
                          .arg(nameImage(fileName, m_setup.thumbSize()))
                          .arg(nameImage(fileName, m_setup.thumbSize()))
                          .arg(nameImage(fileName, maxImageSize()));
            if (m_setup.html5VideoGenerate()) {
                images += QString::fromLatin1(", \"%1\", \"")
                              .arg(QString::fromLatin1("video/ogg"));
            } else {
                images += QString::fromLatin1(", \"%1\", \"")
                              .arg(db.mimeTypeForFile(fileName.relative(), QMimeDatabase::MatchExtension).name());
            }
            enableVideo = 1;
        }

        // -------------------------------------------------- Description
        if (!info->description().isEmpty() && m_setup.includeCategory(QString::fromLatin1("**DESCRIPTION**"))) {
            images += QString::fromLatin1("%1\", \"")
                          .arg(info->description()
                                   .replace(QString::fromLatin1("\n$"), QString::fromLatin1(""))
                                   .replace(QString::fromLatin1("\n"), QString::fromLatin1(" "))
                                   .replace(QString::fromLatin1("\""), QString::fromLatin1("\\\"")));
        } else {
            images += QString::fromLatin1("\", \"");
        }
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if (!description.isEmpty()) {
            description = QString::fromLatin1("<ul>%1</ul>").arg(description);
        } else {
            description = QString::fromLatin1("");
        }

        description.replace(QString::fromLatin1("\n$"), QString::fromLatin1(""));
        description.replace(QString::fromLatin1("\n"), QString::fromLatin1(" "));
        description.replace(QString::fromLatin1("\""), QString::fromLatin1("\\\""));

        images += description;
        images += QString::fromLatin1("\"]);\n");

        QDomElement href = doc.createElement(QString::fromLatin1("a"));
        href.setAttribute(QString::fromLatin1("href"),
                          namePage(width, height, fileName));
        col.appendChild(href);

        QDomElement img = doc.createElement(QString::fromLatin1("img"));
        img.setAttribute(QString::fromLatin1("src"),
                         nameImage(fileName, m_setup.thumbSize()));
        img.setAttribute(QString::fromLatin1("alt"),
                         nameImage(fileName, m_setup.thumbSize()));
        href.appendChild(img);
        ++count;
    }
```

#### AUTO 


```{c}
auto *scrollArea = new QScrollArea;
```

#### AUTO 


```{c}
const auto args = parser.positionalArguments();
```

#### AUTO 


```{c}
auto key = qMakePair(category, item);
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto& area : areasOfCategory )
            {
                QRect rotatedArea;

                // parameter order for QRect::setCoords:
                // setCoords( left, top, right, bottom )
                // keep in mind that _size is already transposed
                switch (degrees) {
                    case 90:
                        rotatedArea.setCoords(
                                m_size.width() - area.bottom(),
                                area.left(),
                                m_size.width() - area.top(),
                                area.right()
                                );
                        break;
                    case 180:
                        rotatedArea.setCoords(
                                m_size.width() - area.right(),
                                m_size.height() - area.bottom(),
                                m_size.width() - area.left(),
                                m_size.height() - area.top()
                                );
                        break;
                    case 270:
                        rotatedArea.setCoords(
                                area.top(),
                                m_size.height() - area.right(),
                                area.bottom(),
                                m_size.height() - area.left()
                                );
                        break;
                    default:
                        // degrees==0; "odd" values won't happen.
                        rotatedArea = area;
                        break;
                }

                // update _taggedAreas[category][tag]:
                area = rotatedArea;
            }
```

#### AUTO 


```{c}
const auto &tag
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
        ls->setMode(m_setup);
    }
```

#### AUTO 


```{c}
auto array = lookupRawData(name);
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_LEFT   = 0b00001000;
```

#### AUTO 


```{c}
auto answer = uiDelegate().questionYesNo(DB::LogMessage { BaseLog(), logMsg }, txt, i18n("Trust Time Stamps?"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &stackFileName : allInStack) {
                DB::ImageInfoPtr imgInfo = info(stackFileName);
                Q_ASSERT(imgInfo);
                if (imgInfo->isStacked()) {
                    m_stackMap.remove(imgInfo->stackId());
                    imgInfo->setStackId(0);
                    imgInfo->setStackOrder(0);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& newFile : selected()) {
            newFile.info()->addCategoryInfo(Settings::SettingsData::instance()->untaggedCategory(),
                                            Settings::SettingsData::instance()->untaggedTag());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& item : info->itemsOfCategory(categoryName) ) {
            const QString age = Utilities::formatAge(category, item, info);
            list.append(CategoryItemDetails(item, age));
        }
```

#### AUTO 


```{c}
const auto &member
```

#### AUTO 


```{c}
const auto selectedFiles = selected();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : allImages) {
        const DB::ImageInfoPtr info = fileName.info();
        dialog.setValue(i++);
        if (info->mediaType() == DB::Image) {
            add(fileName);
        }
        if (i % 10)
            qApp->processEvents();
        if (dialog.wasCanceled())
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
            DB::ImageDB::instance()->info(fileName)->rotate(angle);
            thumbnailCache()->removeThumbnail(fileName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& text : items) {
        if (! m_filter->text().isEmpty()
            && text.indexOf(m_filter->text(), 0, Qt::CaseInsensitive) == -1) {
            m_dataView->setRowCount(m_dataView->rowCount() - 1);
            continue;
        }

        QTableWidgetItem* nameItem = new QTableWidgetItem(text);
        nameItem->setFlags(nameItem->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
        m_dataView->setItem(row, 0, nameItem);

        QDate dateForItem;
        if (m_changedData.contains(categoryName)) {
            if (m_changedData[categoryName].contains(text)) {
                dateForItem = m_changedData[categoryName][text];
            } else {
                dateForItem = category->birthDate(text);
            }
        } else {
            dateForItem = category->birthDate(text);
        }

        DateTableWidgetItem* dateItem = new DateTableWidgetItem(textForDate(dateForItem));
        dateItem->setData(Qt::UserRole, dateForItem);
        dateItem->setFlags(dateItem->flags() & ~Qt::ItemIsEditable & ~Qt::ItemIsSelectable);
        m_dataView->setItem(row, 1, dateItem);

        row++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( DB::CategoryMatcher* matcher : mp_elements )
        matcher->setShouldCreateMatchedSet( b );
```

#### AUTO 


```{c}
const auto badBackends = sentinel.crashHistory();
```

#### AUTO 


```{c}
auto errorPalette = m_dateInput->palette();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_thumbnailsToBuild ) {
        DB::ImageInfoPtr info = fileName.info();
        if ( ImageManager::AsyncLoader::instance()->isExiting() ) {
            cancelRequests();
            break;
        }
        if ( info->isNull())
        {
            m_count++;
            continue;
        }

        ImageManager::ImageRequest* request
            = new ImageManager::PreloadRequest( fileName,
                                              ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                              this );
        request->setIsThumbnailRequest(true);
        request->setPriority( ImageManager::BuildThumbnails );
        if (ImageManager::AsyncLoader::instance()->load( request ))
            ++numberOfThumbnailsToBuild;
    }
```

#### AUTO 


```{c}
auto tagIt = tags.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : images) {
        dialog.setValue(++progress);
        qApp->processEvents(QEventLoop::AllEvents);
        if (dialog.wasCanceled())
            break;
        if (info->isNull())
            continue;

        DB::ImageDate date = info->date();
        bool show = false;
        if (m_dateNotTime->isChecked()) {
            DB::FileInfo fi = DB::FileInfo::read(info->fileName(), DB::EXIFMODE_DATE);
            if (fi.dateTime().date() == date.start().date())
                show = (fi.dateTime().time() != date.start().time());
            if (show) {
                edit->append(QString::fromLatin1("%1:<br/>existing = %2<br>new..... = %3")
                                 .arg(info->fileName().relative())
                                 .arg(date.start().toString())
                                 .arg(fi.dateTime().toString()));
            }
        } else if (m_missingDate->isChecked()) {
            show = !date.start().isValid();
        } else if (m_partialDate->isChecked()) {
            show = (date.start() != date.end());
        }

        if (show)
            toBeShown.append(info->fileName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elms )
        {
            formalList.append( e->queryString() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : list) {
        if (member.isEmpty()) {
            // This can happen if we add group that currently has no members.
            continue;
        }

        if (!alreadyAdded.contains(member)) {
            alreadyAdded << member;

            if (Settings::SettingsData::instance()->hasUntaggedCategoryFeatureConfigured()
                && !Settings::SettingsData::instance()->untaggedImagesTagVisible()) {

                if (name == Settings::SettingsData::instance()->untaggedCategory()) {
                    if (member == Settings::SettingsData::instance()->untaggedTag()) {
                        continue;
                    }
                }
            }

            QListWidgetItem *newItem = new QListWidgetItem(member, m_membersListWidget);
            newItem->setFlags(newItem->flags() | Qt::ItemIsUserCheckable);
            newItem->setCheckState(Qt::Unchecked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VideoBackend candidate : { VideoBackend::Phonon, VideoBackend::VLC, VideoBackend::QtAV }) {
        if (availableVideoBackends().testFlag(candidate) && !exclusions.testFlag(candidate)) {
            qCDebug(SettingsLog) << "preferredVideoBackend(): backend is viable:" << candidate;
            return candidate;
        }
        qCDebug(SettingsLog) << "preferredVideoBackend(): backend is not viable:" << candidate;
    }
```

#### AUTO 


```{c}
const auto allImageFiles = DB::ImageDB::instance()->files(DB::MediaType::Image);
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_TOP    = 0b00000001;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResizableFrame *area : allAreas) {
        const auto tagData = area->tagData();
        if (tagData.first == category)
            tags += tagData.second;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MARKER_SIZE_MIN_PX = 20;
```

#### AUTO 


```{c}
auto category
```

#### AUTO 


```{c}
const auto emptyUrl = QUrl::fromLocalFile(emptyString).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileName &fileName : list) {
        if (count % 10 == 0) {
            dialog.setValue(count); // ensure to call setProgress(0)
            qApp->processEvents(QEventLoop::AllEvents);

            if (dialog.wasCanceled()) {
                if (wasCanceled)
                    *wasCanceled = true;
                return dirty;
            }
        }

        MD5 md5 = MD5Sum(fileName);
        if (md5.isNull()) {
            cantRead << fileName;
            continue;
        }

        ImageInfoPtr info = ImageDB::instance()->info(fileName);
        if (info->MD5Sum() != md5) {
            info->setMD5Sum(md5);
            dirty = true;
            MainWindow::Window::theMainWindow()->thumbnailCache()->removeThumbnail(fileName);
        }

        md5Map->insert(md5, fileName);

        ++count;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int BORDER_ABOVE_HISTOGRAM = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
            m_boundingRegion |= subCluster->boundingRegion();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        area->markTidied();
        area->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categoryList) {
        QString categoryName = category->name();

        if (!shouldSaveCategory(categoryName))
            continue;

        const StringSet items = info->itemsOfCategory(categoryName);
        if (!items.empty()) {
            QStringList idList;

            for (const QString &itemValue : items) {
                QRect area = info->areaForTag(categoryName, itemValue);

                if (area.isValid()) {
                    // Positioned tags can't be stored in the "fast" format
                    // so we have to handle them separately
                    positionedTags[categoryName] << QPair<QString, QRect>(itemValue, area);
                } else {
                    int id = static_cast<const XMLCategory *>(category.data())->idForName(itemValue);
                    idList.append(QString::number(id));
                }
            }

            // Possibly all ids of a category have area information, so only
            // write the category attribute if there are actually ids to write
            if (!idList.isEmpty()) {
                std::sort(idList.begin(), idList.end());
                writer.writeAttribute(escape(categoryName), idList.join(QString::fromLatin1(",")));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories()) {
        QMap<QString, DB::CountWithRange> items = DB::ImageDB::instance()->classify(BrowserPage::searchInfo(), category->name(), DB::anyMediaType, DB::ClassificationMode::PartialCount);
        m_rowHasSubcategories[row] = items.count() > 1;
        ++row;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWidget *widget, QString tooltip, const char *key) {
        QKeySequence shortcut = m_actions->action(QString::fromLatin1(key))->shortcut();
        if (!shortcut.isEmpty())
            tooltip += QString::fromLatin1(" (%1)").arg(shortcut.toString());
        widget->setToolTip(tooltip);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_imageList)) {
        const DB::ImageInfoPtr imageInfo = fileName.info();
        if (!m_filter.match(imageInfo))
            continue;
        if (imageInfo && imageInfo->isStacked()) {
            DB::StackID stackid = imageInfo->stackId();
            if (alreadyShownStacks.contains(stackid))
                continue;
            StackMap::iterator found = stackContents.find(stackid);
            Q_ASSERT(found != stackContents.end());
            const StackList &orderedStack = *found;
            if (m_expandedStacks.contains(stackid)) {
                for (const DB::FileName &fileName : orderedStack) {
                    m_displayList.append(fileName);
                }
            } else {
                m_displayList.append(orderedStack.at(0));
            }
            alreadyShownStacks.insert(stackid);
        } else {
            m_displayList.append(fileName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) { m_player->audio()->setVolume(value / 100.0); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : _setup.imageList()) {
        if ( wasCanceled() )
            return;

        createImage(fileName, _setup.thumbSize());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &imageInfo : m_images)
    {
        bool match = ( (imageInfo)->mediaType() & typemask ) && !(imageInfo)->isLocked() && info.match( imageInfo ) && rangeInclude( imageInfo );
        if ( match ) { // If the given image is currently matched.

            // Now iterate through all the categories the current image
            // contains, and increase them in the map mapping from category
            // to count.
            StringSet items = (imageInfo)->itemsOfCategory(category);
            counter.count( items, imageInfo->date() );
            for (const auto &categoryName: items)
            {
                if ( !alreadyMatched.contains(categoryName) ) // We do not want to match "Jesper & Jesper"
                    map[categoryName].add(imageInfo->date());
            }

            // Find those with no other matches
            if ( noMatchInfo.match( imageInfo ) )
                map[DB::ImageDB::NONE()].count++;

            // this is a shortcut for the browser overview page,
            // where we are only interested whether there are sub-categories to a category
            if (mode == DB::ClassificationMode::PartialCount && map.size()>1)
            {
                qCInfo(TimingLog) << "Database::classify(partial): " << timer.restart() << "ms.";
                return map;
            }
        }
    }
```

#### AUTO 


```{c}
const auto size = info.size();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_thumbnailsToBuild ) {
        DB::ImageInfoPtr info = fileName.info();
        if ( info->isNull())
            continue;

        ++numberOfThumbnailsToBuild;
        ImageManager::ImageRequest* request
            = new ImageManager::PreloadRequest( fileName,
                                              ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                              this );
        request->setIsThumbnailRequest(true);
        request->setPriority( ImageManager::BuildThumbnails );
        ImageManager::AsyncLoader::instance()->load( request );
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MARKER_SIZE_DEFAULT_PX = 40;
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &comment : commentsToStrip )
        comment.replace( QString::fromLatin1(",,"), QString::fromLatin1(",") );
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* optionMatcher : _categoryMatchers) {
        optionMatcher->debug(1);
    }
```

#### AUTO 


```{c}
const auto info = DB::ImageDB::instance()->info(fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *videoAction : qAsConst(m_videoActions)) {
        videoAction->setVisible(isVideo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : selection) {
        selectedFiles.append(QUrl::fromLocalFile(path));
    }
```

#### AUTO 


```{c}
const auto size = image.size();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        QString file = fileName.absolute();
        QString zippedName = m_filenameMapper.uniqNameFor(fileName);

        if (m_maxSize == -1 || Utilities::isVideo(fileName) || isRAW(fileName)) {
            const QFileInfo fileInfo(file);
            if (fileInfo.isSymLink()) {
                file = fileInfo.symLinkTarget();
            }
            if (m_location == Inline)
                m_zip->addLocalFile(file, QStringLiteral("Images/") + zippedName);
            else if (m_location == AutoCopy)
                Utilities::copyOrOverwrite(file, m_destdir + QLatin1String("/") + zippedName);
            else if (m_location == Link)
                Utilities::makeHardLink(file, m_destdir + QLatin1String("/") + zippedName);
            else if (m_location == Symlink)
                Utilities::makeSymbolicLink(file, m_destdir + QLatin1String("/") + zippedName);

            m_steps++;
            m_progressDialog->setValue(m_steps);
        } else {
            m_filesRemaining++;
            ImageManager::ImageRequest *request = new ImageManager::ImageRequest(DB::FileName::fromAbsolutePath(file), QSize(m_maxSize, m_maxSize), 0, this);
            request->setPriority(ImageManager::BatchTask);
            ImageManager::AsyncLoader::instance()->load(request);
        }

        // Test if the cancel button was pressed.
        qApp->processEvents(QEventLoop::AllEvents);

        if (m_progressDialog->wasCanceled()) {
            *m_ok = false;
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : list) {
        QString file = fileName.absolute();
        QString zippedName = m_filenameMapper.uniqNameFor(fileName);

        if ( m_maxSize == -1 || Utilities::isVideo( fileName ) || Utilities::isRAW( fileName )) {
            if ( QFileInfo( file ).isSymLink() )
                file = QFileInfo(file).readLink();

            if ( m_location == Inline )
                m_zip->addLocalFile( file, QString::fromLatin1( "Images/" ) + zippedName );
            else if ( m_location == AutoCopy )
                Utilities::copy( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( m_location == Link )
                Utilities::makeHardLink( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( m_location == Symlink )
                Utilities::makeSymbolicLink( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );

            m_steps++;
            m_progressDialog->setValue( m_steps );
        }
        else {
            m_filesRemaining++;
            ImageManager::ImageRequest* request =
                new ImageManager::ImageRequest( DB::FileName::fromAbsolutePath(file), QSize( m_maxSize, m_maxSize ), 0, this );
            request->setPriority( ImageManager::BatchTask );
            ImageManager::AsyncLoader::instance()->load( request );
        }

        // Test if the cancel button was pressed.
        qApp->processEvents( QEventLoop::AllEvents );

        if ( m_progressDialog->wasCanceled() ) {
            *m_ok = false;
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_imageList)) {
        const DB::ImageInfoPtr imageInfo = fileName.info();
        if (imageInfo && imageInfo->isStacked()) {
            DB::StackID stackid = imageInfo->stackId();
            stackContents[stackid].append(fileName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &newFile : selectedFiles) {
        auto newInfo = DB::ImageDB::instance()->info(newFile);
        newInfo->copyExtraData(*originalInfo, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        if (category->type() == DB::Category::MediaTypeCategory
            || category->type() == DB::Category::FolderCategory) {
            continue;
        }

        const QMap<QString, DB::CountWithRange> tags = DB::ImageDB::instance()->classify(info, category->name(), DB::anyMediaType);
        int total = 0;
        for (auto tagIt = tags.constBegin(); tagIt != tags.constEnd(); ++tagIt) {
            // Don't count the NONE tag, and the OK tag
            if (tagIt.key() != DB::ImageDB::NONE() && (category->name() != m_category->currentText() || tagIt.key() != m_tag->currentText()))
                total += tagIt.value().count;
        }

        addRow(category->name(), tags.count() - 1, total, imageCount, top);
        tagsTotal += tags.count() - 1;
        grantTotal += total;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( DB::CategoryMatcher* matcher : _elements )
        matcher->setShouldCreateMatchedSet( b );
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<QLabel *, QLabel *> tuple : m_labels) {
        const bool matches = tuple.first->text().contains(search, Qt::CaseInsensitive) && search.length() != 0;
        QPalette pal = tuple.first->palette();
        pal.setBrush(QPalette::Foreground, matches ? Qt::red : Qt::black);
        tuple.first->setPalette(pal);
        tuple.second->setPalette(pal);
        QFont fnt = tuple.first->font();
        fnt.setBold(matches);
        tuple.first->setFont(fnt);
        tuple.second->setFont(fnt);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPushButton *button : m_floaters->findChildren<QPushButton *>()) {
        group.writeEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX
                         + button->property("floater").toString(), button->isChecked());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        DB::ImageInfoPtr inf = fileName.info();
        StackMap::iterator found = m_stackMap.find(inf->stackId());
        if (inf->isStacked() && found != m_stackMap.end()) {
            const DB::FileNameList origCache = found.value();
            DB::FileNameList newCache;
            for (const DB::FileName &cacheName : origCache) {
                if (fileName != cacheName)
                    newCache.append(cacheName);
            }
            if (newCache.size() <= 1) {
                // we're destroying a stack
                for (const DB::FileName &cacheName : qAsConst(newCache)) {
                    DB::ImageInfoPtr cacheInf = cacheName.info();
                    cacheInf->setStackId(0);
                    cacheInf->setStackOrder(0);
                }
                m_stackMap.remove(inf->stackId());
            } else {
                m_stackMap.insert(inf->stackId(), newCache);
            }
        }
        m_imageCache.remove(inf->fileName().absolute());
        m_images.remove(inf);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        const DB::FileNameList allInStack = getStackFor(fileName);
        if (allInStack.size() <= 2) {
            // we're destroying stack here
            for (const DB::FileName &stackFileName : allInStack) {
                DB::ImageInfoPtr imgInfo = stackFileName.info();
                Q_ASSERT(imgInfo);
                if (imgInfo->isStacked()) {
                    m_stackMap.remove(imgInfo->stackId());
                    imgInfo->setStackId(0);
                    imgInfo->setStackOrder(0);
                }
            }
        } else {
            DB::ImageInfoPtr imgInfo = fileName.info();
            Q_ASSERT(imgInfo);
            if (imgInfo->isStacked()) {
                m_stackMap[imgInfo->stackId()].removeAll(fileName);
                imgInfo->setStackId(0);
                imgInfo->setStackOrder(0);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DB::FileName& fileName : images ) {
        if ( ! ImageManager::ThumbnailCache::instance()->contains( fileName ) )
            needed.append( fileName );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &categoryPtr : categories) {
        const QString categoryName = categoryPtr->name();
        QString oldCategoryName;
        if (newToOldCategory) {
            // translate to old categoryName, defaulting to the original name if not found:
            oldCategoryName = newToOldCategory->value(categoryName, categoryName);
        } else {
            oldCategoryName = categoryName;
        }
        QString str = reader->attribute(FileWriter::escape(oldCategoryName));
        if (!str.isEmpty()) {
            const QStringList list = str.split(QString::fromLatin1(","), QString::SkipEmptyParts);
            for (const QString &tagString : list) {
                int id = tagString.toInt();
                if (id != 0 || categoryPtr->isSpecialCategory()) {
                    const QString name = static_cast<const XMLCategory *>(categoryPtr.data())->nameForId(id);
                    info->addCategoryInfo(categoryName, name);
                } else {
                    QStringList tags = static_cast<const XMLCategory *>(categoryPtr.data())->namesForId(id);
                    if (tags.size() == 1) {
                        qCInfo(XMLDBLog) << "Fixing tag " << categoryName << "/" << tags[0] << "with id=0 for image" << info->fileName().relative();
                    } else {
                        // insert marker category
                        QString markerTag = i18n("KPhotoAlbum - manual repair needed (%1)",
                                                 tags.join(i18nc("Separator in a list of tags", ", ")));
                        categoryPtr->addItem(markerTag);
                        info->addCategoryInfo(categoryName, markerTag);
                        qCWarning(XMLDBLog) << "Manual fix required for image" << info->fileName().relative();
                        qCWarning(XMLDBLog) << "Image was marked with tag " << categoryName << "/" << markerTag;
                    }
                    for (const auto &name : tags) {
                        info->addCategoryInfo(categoryName, name);
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : files) {
        m_hash.remove(fileName);
    }
```

#### AUTO 


```{c}
const auto nullImageFileName = DB::FileName::fromRelativePath(QStringLiteral("nullImage.jpg"));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& group : groups ) {
                if ( !countedGroupDict.contains( group ) ) {
                    countedGroupDict.insert( group );
                    m_groupCount[group].add(date);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : tmp) {
            qCDebug(FastDirLog) << fileName;
            answer << fileName;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : images) {
        if (!ImageManager::ThumbnailCache::instance()->contains(fileName))
            needed.append(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatch *match : m_matchers) {
        if (match->m_checkbox->isChecked())
            res.add(match->m_combobox->currentText(), match->m_text);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_list)) {
        DB::MD5 sum = fileName.info()->MD5Sum();
        if (DB::ImageDB::instance()->md5Map()->contains(sum)) {
            if (tostack[sum].isEmpty())
                tostack.insert(sum, DB::FileNameList() << fileName);
            else
                tostack[sum].append(fileName);
        }
    }
```

#### AUTO 


```{c}
auto it = m_categoryToIdMap.find(key);
```

#### CONST EXPRESSION 


```{c}
constexpr auto v4IndexHexData {
    "00000004" // version
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A007000670000000000007BAD00001D" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A007000670000000000000000000022" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F" // "blackie.jpg"
};
```

#### AUTO 


```{c}
const auto relativeFilePath = imageRoot.relativeFilePath(absoluteFilePath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : allGroups) {
            // FIXME: Why does the member map return an empty category?!
            if (group.isEmpty()) {
                continue;
            }

            QStringList allMembers = m_memberMap.members(category->name(), group, true);
            membersForGroup[group] = allMembers;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QString &category : oldCategories ) {
                QString oldName = category;
                category = sanitizedCategoryName(oldName );
                categories << category;
                QString lockEntry = privacyConfig.readEntry<QString>(oldName, QString());
                if (! lockEntry.isEmpty() )
                {
                    privacyConfig.writeEntry<QString>(category, lockEntry);
                    privacyConfig.deleteEntry(oldName);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : qAsConst(m_items)) {
        if (!m_idMap.contains(tag))
            setIdMapping(tag, ++i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( StringSet &items: groupMap ) {
        items.remove( name );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elements() )
    {
        query.bindValue( i++, e->valueFromExif(data));
    }
```

#### AUTO 


```{c}
const auto fileInfo = QFileInfo(fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
        ImageManager::ThumbnailCache::instance()->removeThumbnail(fileName);
        BackgroundJobs::HandleVideoThumbnailRequestJob::removeFullScaleFrame(fileName);
        m_model->updateCell(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPushButton *button : m_floaters->findChildren<QPushButton *>()) {
        group.writeEntry(MAPVIEW_FLOATER_VISIBLE_CONFIG_PREFIX
                             + button->property("floater").toString(),
                         button->isChecked());
    }
```

#### AUTO 


```{c}
const auto mapPos = event->pos() - m_mapWidget->pos();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->type() == DB::Category::MediaTypeCategory)
            continue;
        QMap<QString, DB::CountWithRange> images = DB::ImageDB::instance()->classify(dbSearchInfo, category->name(), DB::Image);

        QMap<QString, DB::CountWithRange> videos = DB::ImageDB::instance()->classify(dbSearchInfo, category->name(), DB::Video);
        const bool enabled = (images.count() /*+ videos.count()*/ > 1);
        CategoryViewType type = (category->viewType() == DB::Category::IconView || category->viewType() == DB::Category::ThumbedIconView)
            ? Types::CategoryIconView
            : Types::CategoryListView;

        const QImage icon = category->icon(search.size, enabled ? KIconLoader::DefaultState : KIconLoader::DisabledState).toImage();
        command.categories.append({ category->name(), icon, enabled, type });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { this->slotOptions(); m_settingsDialog->activatePage(Settings::SettingsPage::ThumbnailsPage); }
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
        ls->setSelection(info.itemsOfCategory(ls->category()));
        ls->rePopulate();

        // Get all selected positionable tags and add them to the candidate list
        if (ls->positionable()) {
            const QSet<QString> selectedTags = ls->itemsOn();

            for (const QString &tagName : selectedTags) {
                addTagToCandidateList(ls->category(), tagName);
            }
        }

        // ... create a list of all categories and their positionability ...
        categoryIsPositionable[ls->category()] = ls->positionable();

        if (ls->positionable()) {
            positionableCategories << ls->category();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *child : andMatcher->mp_elements) {
            SimpleCategoryMatcher *simpleMatcher = dynamic_cast<SimpleCategoryMatcher *>(child);
            Q_ASSERT(simpleMatcher);
            result.append(simpleMatcher);
        }
```

#### AUTO 


```{c}
const auto allImages = DB::ImageDB::instance()->images();
```

#### AUTO 


```{c}
const auto absolutePath = QStringLiteral("/path/to/imageroot");
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : allImages) {
        const DB::ImageInfoPtr info = fileName.info();
        dialog.setValue(i++);
        if (info->mediaType() == DB::Image) {
            add(fileName);
        }
        if ( i % 10 )
            qApp->processEvents();
        if (dialog.wasCanceled())
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( ImportMatcher* match : _matchers )
        settings.addCategoryMatchSetting( match->settings() );
```

#### AUTO 


```{c}
auto& area
```

#### LAMBDA EXPRESSION 


```{c}
[] (const DB::FileName& file) {
        // Only include unstacked images, and the top of stacked images.
        return DB::ImageDB::instance()->info(file)->stackOrder() > 1;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto msgPreconditionFailed = "Precondition for test failed - please fix unit test!";
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DB::FileName& fileName : DB::ImageDB::instance()->images()) {
        loadedFiles.insert(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QueueType& queue : m_jobs ) {
        if ( !queue.isEmpty() )
            return queue.dequeue();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( StringSet &items: groupMap ) {
        if (items.contains( oldName ) ) {
            items.remove( oldName );
            items.insert( newName );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &imageInfo : images) {
        total++;
        if (addImage(imageInfo))
            count++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(StaticImageRequest)
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& key : keys) {
        _categoryInfomation[key].unite(other._categoryInfomation[key]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& file : files )
        dir.remove(file);
```

#### AUTO 


```{c}
auto add = [&](const QString &title, const char *name, int value, const QKeySequence &key) {
        if (count++ == 5) {
            QAction *sep = new QAction(menu);
            sep->setSeparator(true);
            menu->addAction(sep);
        }

        QAction *seek = m_actions->addAction(QString::fromLatin1(name));
        seek->setText(title);
        seek->setShortcut(key);
        m_actions->setShortcutsConfigurable(seek, false);
        connect(seek, &QAction::triggered, m_videoDisplay, [this, value] {
            m_videoDisplay->relativeSeek(value);
        });
        menu->addAction(seek);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : categories() ) {
        QMap<QString, uint> images = DB::ImageDB::instance()->classify( BrowserPage::searchInfo(), category->name(), DB::Image );
        QMap<QString, uint> videos = DB::ImageDB::instance()->classify( BrowserPage::searchInfo(), category->name(), DB::Video );
        DB::MediaCount count( images.count(), videos.count() );
        m_count[row] = count;
        ++row;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QObject* obj : list ) {
        QWidget* current = static_cast<QWidget*>( obj );
        if ( !current->property("WantsFocus").isValid() || !current->isVisible() )
            continue;

        int cx = current->mapToGlobal( QPoint(0,0) ).x();
        int cy = current->mapToGlobal( QPoint(0,0) ).y();

        bool inserted = false;
        // Iterate through the ordered list of widgets, and insert the current one, so it is in the right position in the tab chain.
        for( QList<QWidget*>::iterator orderedIt = orderedList.begin(); orderedIt != orderedList.end(); ++orderedIt ) {
            const QWidget* w = *orderedIt;
            int wx = w->mapToGlobal( QPoint(0,0) ).x();
            int wy = w->mapToGlobal( QPoint(0,0) ).y();

            if ( wy > cy || ( wy == cy && wx >= cx ) ) {
                orderedList.insert( orderedIt, current );
                inserted = true;
                break;
            }
        }
        if (!inserted)
            orderedList.append( current );
    }
```

#### AUTO 


```{c}
const auto& remoteImage
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : category->itemsInclCategories()) {
            if (m_re.match(tag).hasMatch()) {
                m_matchingTags[category->name()] += tag;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ListSelect *ls : qAsConst(m_optionList)) {
        ls->setText(info.categoryMatchText(ls->category()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &a : stackedImages)
                    toBeShown.append(a);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) { m_player->audio()->setMute(b); }
```

#### AUTO 


```{c}
const auto fileName = model()->imageAt(index.row());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &title, const char *name, int value, const QKeySequence &key) {
        if (count++ == 5) {
            QAction *sep = new QAction(menu);
            sep->setSeparator(true);
            menu->addAction(sep);
        }

        QAction *seek = m_actions->addAction(QString::fromLatin1(name));
        seek->setText(title);
        seek->setShortcut(key);
        m_actions->setShortcutsConfigurable(seek, false);
        connect(seek, &QAction::triggered, m_videoDisplay, [this, value] {
            m_videoDisplay->relativeSeek(value);
        });
        menu->addAction(seek);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QList<SimpleCategoryMatcher*> resultIt : oldResult) {
            for (QList<SimpleCategoryMatcher*> currentIt : current) {
                QList<SimpleCategoryMatcher*> tmp;
                tmp += resultIt;
                tmp += currentIt;
                result.append( tmp );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : files) {

        if (DB::ImageInfo::imageOnDisk(fileName)) {
            if (method == DeleteFromDisk || method == MoveToTrash) {
                filesToDelete.append(QUrl::fromLocalFile(fileName.absolute()));
                filenamesToRemove.append(fileName);
            } else {
                filenamesToRemove.append(fileName);
            }
        } else
            filenamesToRemove.append(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : images) {
        if (!info->isVideo())
            continue;
        // silently ignore videos not (currently) on disk:
        if (!info->fileName().exists())
            continue;
        int length = info->videoLength();
        if (length == -1) {
            BackgroundTaskManager::JobManager::instance()->addJob(
                new BackgroundJobs::ReadVideoLengthJob(info->fileName(), BackgroundTaskManager::BackgroundVideoPreviewRequest));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto& area : areasOfCategory )
            {
                QRect rotatedArea;

                // parameter order for QRect::setCoords:
                // setCoords( left, top, right, bottom )
                // keep in mind that _size is already transposed
                switch (degrees) {
                    case 90:
                        rotatedArea.setCoords(
                                _size.width() - area.bottom(),
                                area.left(),
                                _size.width() - area.top(),
                                area.right()
                                );
                        break;
                    case 180:
                        rotatedArea.setCoords(
                                _size.width() - area.right(),
                                _size.height() - area.bottom(),
                                _size.width() - area.left(),
                                _size.height() - area.top()
                                );
                        break;
                    case 270:
                        rotatedArea.setCoords(
                                area.top(),
                                _size.height() - area.right(),
                                area.bottom(),
                                _size.height() - area.left()
                                );
                        break;
                    default:
                        // degrees==0; "odd" values won't happen.
                        rotatedArea = area;
                        break;
                }

                // update _taggedAreas[category][tag]:
                area = rotatedArea;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &name : tags) {
                        info->addCategoryInfo(categoryName, name);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SerializerInterface* serializer : m_serializers)
        serializer->encode(stream);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dirName : dirList) {
        const StringSet &files(dirMap[dirName]);
        FastDir dir(dirName);
        QStringList sortedList = dir.sortFileList(files);
        QString fsName(QString::fromLatin1("NULLFS"));
        if (stat(QByteArray(QFile::encodeName(dirName)).constData(), &statbuf) == 0) {
            QCryptographicHash md5calculator(QCryptographicHash::Md5);
            QByteArray md5Buffer((const char *)&(statbuf.st_dev), sizeof(statbuf.st_dev));
            md5calculator.addData(md5Buffer);
            fsName = QString::fromLatin1(md5calculator.result().toHex());
        }
        if (!m_fsMap.contains(fsName)) {
            QStringList newList;
            m_fsMap.insert(fsName, newList);
        }
        m_fsMap[fsName] += sortedList;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
            auto info = DB::ImageDB::instance()->info(fileName);
            images.append(info);
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int seekAheadWait = 10;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { this->reloadThumbnails(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &newFile : selected()) {
            DB::ImageDB::instance()->info(newFile)->addCategoryInfo(Settings::SettingsData::instance()->untaggedCategory(),
                                                                    Settings::SettingsData::instance()->untaggedTag());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_setup.imageList()) {
        const DB::ImageInfoPtr info = DB::ImageDB::instance()->info(fileName);
        if (wasCanceled())
            return false;

        if (count % cols == 0) {
            row = doc.createElement(QString::fromLatin1("tr"));
            row.setAttribute(QString::fromLatin1("class"), QString::fromLatin1("thumbnail-row"));
            doc.appendChild(row);
            count = 0;
        }

        col = doc.createElement(QString::fromLatin1("td"));
        col.setAttribute(QString::fromLatin1("class"), QString::fromLatin1("thumbnail-col"));
        row.appendChild(col);

        if (first.isEmpty())
            first = namePage(width, height, fileName);
        else
            last = namePage(width, height, fileName);

        if (!Utilities::isVideo(fileName)) {
            QMimeDatabase db;
            images += QString::fromLatin1("gallery.push([\"%1\", \"%2\", \"%3\", \"%4\", \"")
                          .arg(nameImage(fileName, width))
                          .arg(nameImage(fileName, m_setup.thumbSize()))
                          .arg(nameImage(fileName, maxImageSize()))
                          .arg(db.mimeTypeForFile(nameImage(fileName, maxImageSize())).name());
        } else {
            QMimeDatabase db;
            images += QString::fromLatin1("gallery.push([\"%1\", \"%2\", \"%3\"")
                          .arg(nameImage(fileName, m_setup.thumbSize()))
                          .arg(nameImage(fileName, m_setup.thumbSize()))
                          .arg(nameImage(fileName, maxImageSize()));
            if (m_setup.html5VideoGenerate()) {
                images += QString::fromLatin1(", \"%1\", \"")
                              .arg(QString::fromLatin1("video/ogg"));
            } else {
                images += QString::fromLatin1(", \"%1\", \"")
                              .arg(db.mimeTypeForFile(fileName.relative(), QMimeDatabase::MatchExtension).name());
            }
            enableVideo = 1;
        }

        // -------------------------------------------------- Description
        if (!info->description().isEmpty() && m_setup.includeCategory(QString::fromLatin1("**DESCRIPTION**"))) {
            images += QString::fromLatin1("%1\", \"")
                          .arg(info->description()
                                   .replace(QString::fromLatin1("\n$"), QString::fromLatin1(""))
                                   .replace(QString::fromLatin1("\n"), QString::fromLatin1(" "))
                                   .replace(QString::fromLatin1("\""), QString::fromLatin1("\\\"")));
        } else {
            images += QString::fromLatin1("\", \"");
        }
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if (!description.isEmpty()) {
            description = QString::fromLatin1("<ul>%1</ul>").arg(description);
        } else {
            description = QString::fromLatin1("");
        }

        description.replace(QString::fromLatin1("\n$"), QString::fromLatin1(""));
        description.replace(QString::fromLatin1("\n"), QString::fromLatin1(" "));
        description.replace(QString::fromLatin1("\""), QString::fromLatin1("\\\""));

        images += description;
        images += QString::fromLatin1("\"]);\n");

        QDomElement href = doc.createElement(QString::fromLatin1("a"));
        href.setAttribute(QString::fromLatin1("href"),
                          namePage(width, height, fileName));
        col.appendChild(href);

        QDomElement img = doc.createElement(QString::fromLatin1("img"));
        img.setAttribute(QString::fromLatin1("src"),
                         nameImage(fileName, m_setup.thumbSize()));
        img.setAttribute(QString::fromLatin1("alt"),
                         nameImage(fileName, m_setup.thumbSize()));
        href.appendChild(img);
        ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        const DB::ImageInfoPtr info = DB::ImageDB::instance()->info(fileName);
        if (info && info->isStacked())
            m_allStacks << info->stackId();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : m_setup.imageList()) {
        if (wasCanceled())
            return;

        createImage(fileName, m_setup.thumbSize());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : DB::ImageDB::instance()->images()) {
        m_lastId++;
        m_idToNameMap.insert(m_lastId, fileName);
        m_nameToIdMap.insert(fileName, m_lastId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &positionedTag : qAsConst(areas)) {
                ElementWriter dummy(writer, _value_);
                writer.writeAttribute(_value_, positionedTag.first);
                writer.writeAttribute(_area_, areaToString(positionedTag.second));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Breadcrumb &item : latest())
        list.append(item.text());
```

#### AUTO 


```{c}
auto *box = new QDialogButtonBox(QDialogButtonBox::Ok);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString orPart : orParts) {
            // Split by " & ", not only by "&", so that the doubled "&"s won't be used as a split point
            const QStringList andParts = orPart.split(QString::fromLatin1(" & "), QString::SkipEmptyParts);

            DB::ContainerCategoryMatcher *andMatcher;
            bool exactMatch = false;
            bool negate = false;
            andMatcher = new DB::AndCategoryMatcher;

            for (QString str : andParts) {
                static const QRegExp regexp(QString::fromLatin1("^\\s*!\\s*(.*)$"));
                if (regexp.exactMatch(str)) { // str is preceded with NOT
                    negate = true;
                    str = regexp.cap(1);
                }
                str = str.trimmed();
                CategoryMatcher *valueMatcher;
                if (str == ImageDB::NONE()) { // mark AND-group as containing a "No other" condition
                    exactMatch = true;
                    continue;
                } else {
                    valueMatcher = new DB::ValueCategoryMatcher(category, str);
                    if (negate) {
                        valueMatcher = new DB::NegationCategoryMatcher(valueMatcher);
                        negate = false;
                    }
                }
                andMatcher->addElement(valueMatcher);
            }
            if (exactMatch) {
                DB::CategoryMatcher *exactMatcher = nullptr;
                // if andMatcher has exactMatch set, but no CategoryMatchers, then
                // matching "category / None" is what we want:
                if (andMatcher->mp_elements.count() == 0) {
                    exactMatcher = new DB::NoTagCategoryMatcher(category);
                } else {
                    ExactCategoryMatcher *noOtherMatcher = new ExactCategoryMatcher(category);
                    if (andMatcher->mp_elements.count() == 1)
                        noOtherMatcher->setMatcher(andMatcher->mp_elements[0]);
                    else
                        noOtherMatcher->setMatcher(andMatcher);
                    exactMatcher = noOtherMatcher;
                }
                if (negate)
                    exactMatcher = new DB::NegationCategoryMatcher(exactMatcher);
                orMatcher->addElement(exactMatcher);
            } else if (andMatcher->mp_elements.count() == 1)
                orMatcher->addElement(andMatcher->mp_elements[0]);
            else if (andMatcher->mp_elements.count() > 1)
                orMatcher->addElement(andMatcher);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *topLevelCluster : m_geoClusters) {
            const auto subCluster = topLevelCluster->regionForPoint(event->pos(), *viewPortParams);
            if (subCluster && !subCluster->isEmpty()) {
                qCDebug(MapLog) << "Cluster preselected/clicked.";
                m_preselectedCluster = subCluster;
                event->accept();
                return;
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr auto v4IndexHexData {
    "00000004" // version
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        query.bindValue(0, fileName.absolute());
        if (!query.exec()) {
            d->m_db.rollback();
            d->showErrorAndFail(query);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* optionMatcher : m_categoryMatchers) {
        if ( ! optionMatcher->eval(info, alreadyMatched) )
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::CategoryPtr categoryPtr : qAsConst(m_categories)) {
        static_cast<XMLCategory *>(categoryPtr.data())->initIdMap();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &positionedTag : qAsConst(areas)) {
                ElementWriter dummy(writer, QStringLiteral("value"));
                writer.writeAttribute(QStringLiteral("value"), positionedTag.first);
                writer.writeAttribute(QStringLiteral("area"), areaToString(positionedTag.second));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : m_dateFormats) {
        parsedDate = QDate::fromString(date, format);
        if (parsedDate.isValid()) {
            return parsedDate;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DB::FileName& image : images ) {
        const DB::ImageInfoPtr info = image.info();
        if ( !info->isVideo() )
            continue;

        // silently ignore videos not (currently) on disk:
        if ( ! info->fileName().exists() )
            continue;

        const DB::FileName thumbnailName = BackgroundJobs::HandleVideoThumbnailRequestJob::frameName(info->fileName(),9);
        if ( thumbnailName.exists() )
            continue;

        BackgroundJobs::ReadVideoLengthJob* readVideoLengthJob = new BackgroundJobs::ReadVideoLengthJob(info->fileName(), BackgroundTaskManager::BackgroundVideoPreviewRequest);

        for (int i=0; i<10;++i) {
            ExtractOneThumbnailJob* extractJob = new ExtractOneThumbnailJob( info->fileName(), i, BackgroundTaskManager::BackgroundVideoPreviewRequest );
            extractJob->addDependency(readVideoLengthJob);
        }

        BackgroundTaskManager::JobManager::instance()->addJob( readVideoLengthJob);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileName& fileName : *this) {
        res.prepend(fileName);
    }
```

#### AUTO 


```{c}
const auto indexSelection = selectedIndexes();
```

#### AUTO 


```{c}
auto it = map.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_thumbnailsToBuild ) {
        m_preloadQueue->enqueue(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &offer : offers) {
            res.insert(offer);
            m_appToMimeTypeMap[offer->name()].insert(type);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointer<BackgroundJobs::ExtractOneThumbnailJob>& job : m_activeRequests ) {
        if (! job.isNull() )
            job->cancel();
    }
```

#### AUTO 


```{c}
const auto filename = it.key();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subCluster : m_subClusters) {
            const Marble::GeoDataLatLonBox box = subCluster->regionForPoint(pos, viewPortParams);
            if (!box.isEmpty())
                return box;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fileName,size,type,timer,client, this] () {
        ThumbnailRequest request(fileName, size, type);

        // The category is used when asking for category item images
        request.category = RemoteInterface::instance().currentCategory();
        RemoteInterface::instance().sendCommand(request);

        RequestType key = qMakePair(fileName,type);
        m_requestMap.insert(key, client);
        m_reverseRequestMap.insert(client, key);

        connect(client, &QObject::destroyed, this, &ImageStore::clientDeleted);
        timer->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(ThumbnailResult)
```

#### AUTO 


```{c}
auto list = m_categories[category];
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(ThumbnailRequest)
```

#### AUTO 


```{c}
auto catIt = existingAreas.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QHostAddress& address : QNetworkInterface::allAddresses()) {
        if (address.isLoopback() || address.toIPv4Address() == 0)
            continue;
        result.append(address.toString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonObject &output, int error, const QString &message) {
        if (error) {
            qCDebug(PluginsLog) << "Failed to share image:" << message;
            emit imageSharingFailed(message);
        } else {
            // Note: most plugins don't seem to actually return anything in the url field...
            const QUrl returnUrl = QUrl(output[QStringLiteral("url")].toString(), QUrl::ParsingMode::StrictMode);
            qCDebug(PluginsLog) << "Image shared successfully.";
            qCDebug(PluginsLog) << "Raw json data: " << output;
            emit imageShared(returnUrl);
        }
    }
```

#### AUTO 


```{c}
auto widget = new FilterWidget(parent);
```

#### AUTO 


```{c}
auto jpegData = lookupRawData(filename);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_list)) {
        const auto info = DB::ImageDB::instance()->info(fileName);
        DB::MD5 sum = info->MD5Sum();
        if (DB::ImageDB::instance()->md5Map()->contains(sum)) {
            if (tostack[sum].isEmpty())
                tostack.insert(sum, DB::FileNameList() << fileName);
            else
                tostack[sum].append(fileName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ImageDecoder *decoder : *decoders()) {
        if (decoder->_mightDecode(imageFile))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( CategoryMatch* match : _matchers ) {
        if ( match->_checkbox->isChecked() )
            res.add( match->_combobox->currentText(),match->_text );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(ResizableFrame *area : allAreas) {
                QPair<QString, QString> tagData = area->tagData();

                if (tagData.first == category) {
                    if (! selectedTags.contains(tagData.second)) {
                        // The linked tag is not selected anymore, so remove it
                        area->removeTagData();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &category : categoriesForImage) {
            if (!categories.contains(category) && category != i18n("Folder") && category != i18n("Tokens") && category != i18n("Media Type"))
                categories.append(category);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        layout->addWidget(headerLabel(group), row++, 0, 1, 4);

        // Items of group
        const QMap<QString, QStringList> items = itemsForGroup(group, map);
        QStringList sorted = items.keys();
        sorted.sort();
        int elements = sorted.size();
        int perCol = (elements + 1) / 2;
        int count = 0;
        for (const QString &key : sorted) {
            const int subrow = (count % perCol);
            const QColor color = (subrow & 1) ? Qt::white : QColor(226, 235, 250);
            QPair<QLabel *, QLabel *> pair = infoLabelPair(exifNameNoGroup(key), items[key].join(QLatin1String(", ")), color);

            int col = (count / perCol) * 2;
            layout->addWidget(pair.first, row + subrow, col);
            layout->addWidget(pair.second, row + subrow, col + 1);
            count++;
        }
        row += perCol;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString str : andParts) {
                static const QRegExp regexp(QString::fromLatin1("^\\s*!\\s*(.*)$"));
                if (regexp.exactMatch(str)) { // str is preceded with NOT
                    negate = true;
                    str = regexp.cap(1);
                }
                str = str.trimmed();
                CategoryMatcher *valueMatcher;
                if (str == ImageDB::NONE()) { // mark AND-group as containing a "No other" condition
                    exactMatch = true;
                    continue;
                } else {
                    valueMatcher = new DB::ValueCategoryMatcher(category, str);
                    if (negate)
                        valueMatcher = new DB::NegationCategoryMatcher(valueMatcher);
                }
                andMatcher->addElement(valueMatcher);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( QDockWidget* dock : m_dockWidgets ) {
        if ( dock->isFloating() )
            dock->hide();
    }
```

#### AUTO 


```{c}
const auto correctFNA = DB::FileName::fromRelativePath(QStringLiteral("a.jpg"));
```

#### CONST EXPRESSION 


```{c}
constexpr int SEEKAHEAD_WAIT_MS = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (QString orPart : orParts) {
            // Split by " & ", not only by "&", so that the doubled "&"s won't be used as a split point
            const QStringList andParts = orPart.split(QString::fromLatin1(" & "), QString::SkipEmptyParts);

            DB::ContainerCategoryMatcher *andMatcher;
            bool exactMatch = false;
            bool negate = false;
            andMatcher = new DB::AndCategoryMatcher;

            for (QString str : andParts) {
                static const QRegExp regexp(QString::fromLatin1("^\\s*!\\s*(.*)$"));
                if (regexp.exactMatch(str)) { // str is preceded with NOT
                    negate = true;
                    str = regexp.cap(1);
                }
                str = str.trimmed();
                CategoryMatcher *valueMatcher;
                if (str == ImageDB::NONE()) { // mark AND-group as containing a "No other" condition
                    exactMatch = true;
                    continue;
                } else {
                    valueMatcher = new DB::ValueCategoryMatcher(category, str);
                    if (negate)
                        valueMatcher = new DB::NegationCategoryMatcher(valueMatcher);
                }
                andMatcher->addElement(valueMatcher);
            }
            if (exactMatch) {
                DB::CategoryMatcher *exactMatcher = nullptr;
                // if andMatcher has exactMatch set, but no CategoryMatchers, then
                // matching "category / None" is what we want:
                if (andMatcher->mp_elements.count() == 0) {
                    exactMatcher = new DB::NoTagCategoryMatcher(category);
                } else {
                    ExactCategoryMatcher *noOtherMatcher = new ExactCategoryMatcher(category);
                    if (andMatcher->mp_elements.count() == 1)
                        noOtherMatcher->setMatcher(andMatcher->mp_elements[0]);
                    else
                        noOtherMatcher->setMatcher(andMatcher);
                    exactMatcher = noOtherMatcher;
                }
                if (negate)
                    exactMatcher = new DB::NegationCategoryMatcher(exactMatcher);
                orMatcher->addElement(exactMatcher);
            } else if (andMatcher->mp_elements.count() == 1)
                orMatcher->addElement(andMatcher->mp_elements[0]);
            else if (andMatcher->mp_elements.count() > 1)
                orMatcher->addElement(andMatcher);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : types) {
#if KSERVICE_VERSION < QT_VERSION_CHECK(5, 68, 0)
        const KService::List offers = KMimeTypeTrader::self()->query(type, QLatin1String("Application"));
#else
        const KService::List offers = KApplicationTrader::queryByMimeType(type);
#endif
        for (const KService::Ptr &offer : offers) {
            res.insert(offer);
            m_appToMimeTypeMap[offer->name()].insert(type);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &tmp : oldStack) {
                tostack.append(tmp);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QDockWidget* dock: m_dockWidgets ) {
        if ( dock->isFloating() )
        {
            qCDebug(AnnotationDialogLog) << "Showing dock: " << dock->objectName();
            dock->show();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : items) {
            tags.append(tag);
            // digikam compatible tag path:
            // note: this produces a semi-flattened hierarchy.
            // instead of "Places/France/Paris" this will yield "Places/Paris"
            tagspath.append(categoryName + sep + tag);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto& areasOfCategory : m_taggedAreas )
        {
            for ( auto& area : areasOfCategory )
            {
                QRect rotatedArea;

                // parameter order for QRect::setCoords:
                // setCoords( left, top, right, bottom )
                // keep in mind that _size is already transposed
                switch (degrees) {
                    case 90:
                        rotatedArea.setCoords(
                                m_size.width() - area.bottom(),
                                area.left(),
                                m_size.width() - area.top(),
                                area.right()
                                );
                        break;
                    case 180:
                        rotatedArea.setCoords(
                                m_size.width() - area.right(),
                                m_size.height() - area.bottom(),
                                m_size.width() - area.left(),
                                m_size.height() - area.top()
                                );
                        break;
                    case 270:
                        rotatedArea.setCoords(
                                area.top(),
                                m_size.height() - area.right(),
                                area.bottom(),
                                m_size.height() - area.left()
                                );
                        break;
                    default:
                        // degrees==0; "odd" values won't happen.
                        rotatedArea = area;
                        break;
                }

                // update _taggedAreas[category][tag]:
                area = rotatedArea;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (RemoteCommand* command : commands )
             map.insert(command->id(), command);
```

#### AUTO 


```{c}
const auto &category
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_displayList)) {
        if (fileName.isNull())
            continue;

        if (ImageManager::ThumbnailCache::instance()->contains(fileName))
            continue;
        const_cast<ThumbnailView::ThumbnailModel *>(this)->requestThumbnail(fileName, ImageManager::ThumbnailInvisible);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
                if (!countedGroupDict.contains(group)) {
                    countedGroupDict.insert(group);
                    m_groupCount[group].add(date);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : items) {
                if (match.XMLtoDB().contains(item)) {
                    DBInfo->addCategoryInfo(DBCategoryName, match.XMLtoDB()[item]);
                    DBCategoryPtr->addItem(match.XMLtoDB()[item]);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ListSelect *ls : qAsConst(m_optionList)) {
            m_oldSearch.setCategoryMatchText(ls->category(), ls->text());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : list) {
        QString file = fileName.absolute();
        QString zippedName = m_filenameMapper.uniqNameFor(fileName);

        if ( m_maxSize == -1 || Utilities::isVideo( fileName ) || isRAW( fileName )) {
            if ( QFileInfo( file ).isSymLink() )
                file = QFileInfo(file).readLink();

            if ( m_location == Inline )
                m_zip->addLocalFile( file, QString::fromLatin1( "Images/" ) + zippedName );
            else if ( m_location == AutoCopy )
                Utilities::copy( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( m_location == Link )
                Utilities::makeHardLink( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( m_location == Symlink )
                Utilities::makeSymbolicLink( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );

            m_steps++;
            m_progressDialog->setValue( m_steps );
        }
        else {
            m_filesRemaining++;
            ImageManager::ImageRequest* request =
                new ImageManager::ImageRequest( DB::FileName::fromAbsolutePath(file), QSize( m_maxSize, m_maxSize ), 0, this );
            request->setPriority( ImageManager::BatchTask );
            ImageManager::AsyncLoader::instance()->load( request );
        }

        // Test if the cancel button was pressed.
        qApp->processEvents( QEventLoop::AllEvents );

        if ( m_progressDialog->wasCanceled() ) {
            *m_ok = false;
            return;
        }
    }
```

#### AUTO 


```{c}
const auto &searchWord
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : *this) {
        if ( type == DB::RelativeToImageRoot )
            res.append( fileName.relative() );
        else
            res.append( fileName.absolute());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& item: info->itemsOfCategory(_category))
        if ( !matchedTags[_category].contains(item) )
            return false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &searchWord : searchWords) {
            bool found = false;
            // ... must match at least one word of the item
            for (const auto &itemWord : itemWords) {
                if (itemWord.startsWith(searchWord)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
```

#### AUTO 


```{c}
const auto absoluteFilePath2 = m_tmpDir.filePath(relativeFilePath2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &existingTag : tags) {
        if (tag == existingTag.trimmed()) {
            qCDebug(ThumbnailViewLog) << "Filter removed: category(" << category << "," << tag << ")";
            tags.removeAll(existingTag);
            m_filter.setCategoryMatchText(category, tags.join(QString::fromLatin1(" & ")));
            m_filter.checkIfNull();
            emit filterChanged(m_filter);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, angle] { rotate(angle); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (!shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, _category_);
        writer.writeAttribute(_name_, name);
        writer.writeAttribute(_icon_, category->iconName());
        writer.writeAttribute(_show_, QString::number(category->doShow()));
        writer.writeAttribute(_viewtype_, QString::number(category->viewType()));
        writer.writeAttribute(_thumbnailsize_, QString::number(category->thumbnailSize()));
        writer.writeAttribute(_positionable_, QString::number(category->positionable()));
        if (category == tokensCategory) {
            writer.writeAttribute(_meta_, _tokens_);
        }

        // As bug 423334 shows, it is easy to forget to add a group to the respective category
        // when it's created. We can not enforce correct creation of member groups in our API,
        // but we can prevent incorrect data from entering index.xml.
        const auto categoryItems = Utilities::mergeListsUniqly(category->items(), m_db->memberMap().groups(name));
        for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, _value_);
            writer.writeAttribute(_value_, tagName);
            writer.writeAttribute(_id_,
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(_birthdate_, birthDate.toString(Qt::ISODate));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : areas) {
        if (area->isTidied()) {
            continue;
        }

        if (area->tagData() == selectedData) {
            if (KMessageBox::Cancel == KMessageBox::warningContinueCancel(m_preview, i18n("<p>%1 has already been tagged in another area on this image.</p>"
                                                                                          "<p>If you continue, the previous tag will be removed...</p>",
                                                                                          tag),
                                                                          i18n("Replace existing area?"))) {
                // don't execute setTagData
                return;
            }
            // replace existing tag
            area->removeTagData();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CategoryItem *subcategory : qAsConst(mp_subcategories)) {
        if (subcategory->hasChild(child))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : types) {
        const KService::List offers = KMimeTypeTrader::self()->query(type, QLatin1String("Application"));
        for (const KService::Ptr &offer : offers) {
            res.insert(qMakePair(offer->name(), offer->icon()));
            m_appToMimeTypeMap[offer->name()].insert(type);
        }
    }
```

#### AUTO 


```{c}
auto &area
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        const DB::ImageInfoPtr imageInfo = info(fileName);
        StackMap::iterator found = m_stackMap.find(imageInfo->stackId());
        if (imageInfo->isStacked() && found != m_stackMap.end()) {
            const DB::FileNameList origCache = found.value();
            DB::FileNameList newCache;
            for (const DB::FileName &cacheName : origCache) {
                if (fileName != cacheName)
                    newCache.append(cacheName);
            }
            if (newCache.size() <= 1) {
                // we're destroying a stack
                for (const DB::FileName &cacheName : qAsConst(newCache)) {
                    DB::ImageInfoPtr cacheInfo = info(cacheName);
                    cacheInfo->setStackId(0);
                    cacheInfo->setStackOrder(0);
                }
                m_stackMap.remove(imageInfo->stackId());
            } else {
                m_stackMap.insert(imageInfo->stackId(), newCache);
            }
        }
        m_imageCache.remove(imageInfo->fileName().absolute());
        m_images.remove(imageInfo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TaggedArea *area : allAreas) {
        area->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DuplicateMatch *selector : qAsConst(m_selectors)) {
        selector->setSelected(b);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, which] {
            const QList<QUrl> urls = relevantUrls(which, {});

            auto *uiParent = MainWindow::Window::theMainWindow();
#if KIO_VERSION < QT_VERSION_CHECK(5, 71, 0)
            KRun::displayOpenWithDialog(lst, uiParent);
#else
                auto job = new KIO::ApplicationLauncherJob();
                job->setUrls(urls);
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, uiParent));
                job->start();
#endif
        }
```

#### AUTO 


```{c}
auto i = 5;
```

#### AUTO 


```{c}
const auto &ignoredComment
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_displayList)) {
        if (fileName.isNull())
            continue;

        if (m_thumbnailCache->contains(fileName))
            continue;
        const_cast<ThumbnailView::ThumbnailModel *>(this)->requestThumbnail(fileName, ImageManager::ThumbnailInvisible);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr auto INDEXFILE_NAME = "thumbnailindex";
```

#### AUTO 


```{c}
const auto incorrectDimensions = cache.findIncorrectlySizedThumbnails();
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        const int w = m_player->statistics().video_only.coded_width;
        const int h = m_player->statistics().video_only.coded_height;
        if (w != 0 && h != 0)
            return static_cast<int>(1.0 * width * h / w);
        else
            return width;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
        QRadioButton *candidate = nullptr;

#if Phonon4Qt5_FOUND
        if (backend == VideoBackend::Phonon)
            return m_phonon;
        candidate = m_phonon;
#endif
#if QtAV_FOUND
        if (backend == VideoBackend::QtAV)
            return m_qtav;
        candidate = m_qtav;
#endif

#if LIBVLC_FOUND
        if (backend == VideoBackend::VLC)
            return m_vlc;
        candidate = m_vlc;
#endif
        return candidate;
    }
```

#### AUTO 


```{c}
const auto renderPlugins = m_mapWidget->renderPlugins();
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *optionMatcher : m_categoryMatchers) {
        optionMatcher->debug(1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const T &x : l2)
        if (!r.contains(x))
            r.append(x);
```

#### AUTO 


```{c}
const auto message = i18n(
                    "<p>It seems that KPhotoAlbum previously crashed during video playback."
                    "On some platforms, this is a common problem with some video players.</p>"
                    "<p>Press <i>Continue</i> to let KPhotoAlbum try a different backend...</p>");
```

#### AUTO 


```{c}
auto f = 3.14159f;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& categoryName : positionableCategories) {
        m_defaultAreaCategory->addItem(categoryName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &area : areasOfCategory) {
                QRect rotatedArea;

                // parameter order for QRect::setCoords:
                // setCoords( left, top, right, bottom )
                // keep in mind that _size is already transposed
                switch (degrees) {
                case 90:
                    rotatedArea.setCoords(
                        m_size.width() - area.bottom(),
                        area.left(),
                        m_size.width() - area.top(),
                        area.right());
                    break;
                case 180:
                    rotatedArea.setCoords(
                        m_size.width() - area.right(),
                        m_size.height() - area.bottom(),
                        m_size.width() - area.left(),
                        m_size.height() - area.top());
                    break;
                case 270:
                    rotatedArea.setCoords(
                        area.top(),
                        m_size.height() - area.right(),
                        area.bottom(),
                        m_size.height() - area.left());
                    break;
                default:
                    // degrees==0; "odd" values won't happen.
                    rotatedArea = area;
                    break;
                }

                // update _taggedAreas[category][tag]:
                area = rotatedArea;
            }
```

#### CONST EXPRESSION 


```{c}
constexpr int SCALE_RIGHT = 0b00000100;
```

#### AUTO 


```{c}
auto *uiParent = MainWindow::Window::theMainWindow();
```

#### RANGE FOR STATEMENT 


```{c}
for ( DB::ImageInfoPtr info : list ) {
        if ( DB::ImageDB::instance()->md5Map()->contains(info->MD5Sum()) )
            ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DatabaseElement *e : elements()) {
        query->bindValue(i++, e->valueFromExif(data));
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MD5_BUFFER_SIZE = 262144;
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher *child : orMatcher->mp_elements) {
            result.append(extractAndMatcher(child));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_displayList)) {
        m_fileNameToIndex[fileName] = index;
        ++index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *topLevelCluster : qAsConst(m_geoClusters)) {
                const auto subCluster = topLevelCluster->regionForPoint(mapPos);
                // Note(jzarl) unfortunately we cannot use QWidget::setCursor here
                if (subCluster) {
                    QGuiApplication::setOverrideCursor(Qt::ArrowCursor);
                } else {
                    QGuiApplication::restoreOverrideCursor();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : _setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if ( wasCancelled() )
            return false;

        if ( count % cols == 0 ) {
            row = doc.createElement( QString::fromLatin1( "tr" ) );
            row.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-row" ) );
            doc.appendChild( row );
            count = 0;
        }

        col = doc.createElement( QString::fromLatin1( "td" ) );
        col.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-col" ) );
        row.appendChild( col );

        if (first.isEmpty())
            first = namePage( width, height, fileName);
        else
            last = namePage( width, height, fileName);

        if (!Utilities::isVideo(fileName))
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"%4\", \"" ).arg( nameImage( fileName, width ) ).arg( nameImage( fileName, _setup.thumbSize() )
                        ).arg( nameImage( fileName, maxImageSize() ) ).arg( KMimeType::findByUrl( nameImage(
                                    fileName, maxImageSize() ) )->name() );
        else {
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\"" ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, maxImageSize() ) );
            if ( _setup.html5VideoGenerate() )
                images += QString::fromLatin1( ", \"%1\", \"" ).arg( QString::fromLatin1( "video/ogg" ) );
            else
                images += QString::fromLatin1( ", \"%1\", \"" ).arg( KMimeType::findByPath( fileName.relative(), 0, true)->name() );
            enableVideo = 1;
        }

        // -------------------------------------------------- Description
        if ( !info->description().isEmpty() && _setup.includeCategory( QString::fromLatin1( "**DESCRIPTION**" )) )
            images += QString::fromLatin1( "%1\", \"" ).arg( info->description().replace( QString::fromLatin1( "\n$" ), QString::fromLatin1( "" ) ).replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) ).replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) ) );
        else
            images += QString::fromLatin1( "\", \"" );
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if ( !description.isEmpty() )
            description = QString::fromLatin1 ( "<ul>%1</ul>" ).arg ( description );
        else
            description = QString::fromLatin1 ( "" );

        description.replace( QString::fromLatin1( "\n$" ), QString::fromLatin1 ( "" ) );
        description.replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) );
        description.replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) );

        images += description;
        images += QString::fromLatin1( "\"]);\n" );

        QDomElement href = doc.createElement( QString::fromLatin1( "a" ) );
        href.setAttribute( QString::fromLatin1( "href" ),
                           namePage( width, height, fileName));
        col.appendChild( href );

        QDomElement img = doc.createElement( QString::fromLatin1( "img" ) );
        img.setAttribute( QString::fromLatin1( "src" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        img.setAttribute( QString::fromLatin1( "alt" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        href.appendChild( img );
        ++count;
    }
```

#### AUTO 


```{c}
const auto sameFN = FileName::fromRelativePath(relativeFilePath);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& key : sorted ) {
            const int index = row * 2 + col;
            const QColor color  = (index % 4 == 0 || index % 4 == 3)? Qt::white : QColor(226, 235, 250);
            QPair<QLabel*, QLabel*> pair = infoLabelPair( exifNameNoGroup( key ), items[key].join( QLatin1String(", ")), color );

            col = (col +1) % 4;
            if ( col == 0 )
                ++row;
            layout->addWidget(pair.first, row, col);
            layout->addWidget(pair.second,row,++col);
        }
```

#### AUTO 


```{c}
const auto buttons = m_floaters->findChildren<QPushButton *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_thumbnailsToBuild ) {
        DB::ImageInfoPtr info = fileName.info();
        if ( ImageManager::AsyncLoader::instance()->isExiting() ) {
            cancelRequests();
            break;
        }
        if ( info->isNull())
        {
            m_loadedCount++;
            m_count++;
            continue;
        }

        ImageManager::ImageRequest* request
            = new ImageManager::PreloadRequest( fileName,
                                              ThumbnailView::CellGeometry::preferredIconSize(), info->angle(),
                                              this );
        request->setIsThumbnailRequest(true);
        request->setPriority( ImageManager::BuildThumbnails );
        if (ImageManager::AsyncLoader::instance()->load( request ))
            ++numberOfThumbnailsToBuild;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl url : list)
        thumbnail(url, size);
```

#### RANGE FOR STATEMENT 


```{c}
for (DB::CategoryPtr category : categories) {
        if (!category->isSpecialCategory())
            m_category->addItem(category->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : allImages) {
        const DB::ImageInfoPtr info = fileName.info();
        dialog.setValue(i++);
        if (info->mediaType() == DB::Image) {
            success &= add(fileName);
        }
        if ( i % 10 )
            qApp->processEvents();
        if (dialog.wasCanceled())
            break;
    }
```

#### AUTO 


```{c}
const auto stackedImages = DB::ImageDB::instance()->getStackFor(fileName);
```

#### LAMBDA EXPRESSION 


```{c}
[](RichCacheFileInfo a, RichCacheFileInfo b) { return a.info.fileIndex < b.info.fileIndex || (a.info.fileIndex == b.info.fileIndex && a.info.offset < b.info.offset); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointer<BackgroundJobs::ExtractOneThumbnailJob> &job : m_activeRequests) {
        if (!job.isNull())
            job->cancel();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QCheckBox *box : qAsConst(m_checkBoxes)) {
        if (box->isChecked() && box->isEnabled()) {
            QString txt = box->text().remove(QString::fromLatin1("&"));
            tokensCategory->removeItem(txt);
        }
    }
```

#### AUTO 


```{c}
auto catPtr = DB::ImageDB::instance()->categoryCollection()->categoryForName(category);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &title, int angle, const QKeySequence &shortcut, const QString &actionName) {
        auto *action = new QAction(title);
        connect(action, &QAction::triggered, [this, angle] { rotate(angle); });
        action->setShortcut(shortcut);
        m_actions->setShortcutsConfigurable(action, false);
        m_actions->addAction(actionName, action);
        m_rotateMenu->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QDockWidget* dock: _dockWidgets ) {
        if ( dock->isFloating() )
            dock->show();
    }
```

#### AUTO 


```{c}
const auto outsidePath = QStringLiteral("/notarealdirectory/test.jpg");
```

#### RANGE FOR STATEMENT 


```{c}
for (PopupAction which : { PopupAction::OpenCurrent, PopupAction::OpenAllSelected, PopupAction::CopyAndOpenAllSelected }) {
        if (which == PopupAction::OpenCurrent && !current)
            continue;

        const bool multiple = (m_list.count() > 1);
        const bool enabled = (which != PopupAction::OpenAllSelected && m_currentInfo) || (which == PopupAction::OpenAllSelected && multiple);

        // Submenu
        QString menuLabel;
        switch (which) {
        case PopupAction::OpenCurrent:
            menuLabel = i18n("Current Item");
            break;
        case PopupAction::OpenAllSelected:
            menuLabel = i18n("All Selected Items");
            break;
        case PopupAction::CopyAndOpenAllSelected:
            menuLabel = i18n("Copy and Open");
        }
        Q_ASSERT(!menuLabel.isNull());

        QMenu *submenu = addMenu(menuLabel);
        submenu->setEnabled(enabled);

        // Fetch set of offers
        OfferType offers;
        if (which == PopupAction::OpenCurrent)
            offers = appInfos(DB::FileNameList() << current->fileName());
        else
            offers = appInfos(imageList);

        for (KService::Ptr offer : qAsConst(offers)) {
            action = submenu->addAction(offer->name());
            action->setIcon(QIcon::fromTheme(offer->icon()));
            action->setEnabled(enabled);
            connect(action, &QAction::triggered, this, [this, offer, which] {
                runService(offer, relevantUrls(which, offer));
            });
        }

        // A personal command
        action = submenu->addAction(i18n("Open With..."));
        // XXX: action->setIcon( QIcon::fromTheme((*offerIt).second) );
        action->setEnabled(enabled);
        connect(action, &QAction::triggered, this, [this, which] {
            const QList<QUrl> urls = relevantUrls(which, {});

            auto *uiParent = MainWindow::Window::theMainWindow();
#if KIO_VERSION < QT_VERSION_CHECK(5, 71, 0)
            KRun::displayOpenWithDialog(urls, uiParent);
#else
                auto job = new KIO::ApplicationLauncherJob();
                job->setUrls(urls);
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, uiParent));
                job->start();
#endif
        });

        // A personal command
        // XXX: see kdialog.h for simple usage
        action = submenu->addAction(i18n("Your Command Line"));
        // XXX: action->setIcon( QIcon::fromTheme((*offerIt).second) );
        action->setEnabled(enabled);
        connect(action, &QAction::triggered, this, [this] {
            static RunDialog *dialog = new RunDialog(MainWindow::Window::theMainWindow());
            dialog->setImageList(m_list);
            dialog->show();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        area->setActualCoordinates(rotateArea(area->actualCoordinates(), angle));
    }
```

#### AUTO 


```{c}
const auto& key
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& group : groups ) {
        layout->addWidget(headerLabel(group),row++,0,1,4);

        int col = -1;
        // Items of group
        const QMap<QString,QStringList> items = itemsForGroup( group, map );
        QStringList sorted = items.keys();
        sorted.sort();
        for ( const QString& key : sorted ) {
            const int index = row * 2 + col;
            const QColor color  = (index % 4 == 0 || index % 4 == 3)? Qt::white : QColor(226, 235, 250);
            QPair<QLabel*, QLabel*> pair = infoLabelPair( exifNameNoGroup( key ), items[key].join( QLatin1String(", ")), color );

            col = (col +1) % 4;
            if ( col == 0 )
                ++row;
            layout->addWidget(pair.first, row, col);
            layout->addWidget(pair.second,row,++col);
        }
        ++row;
    }
```

#### AUTO 


```{c}
const auto untaggedCategory = Settings::SettingsData::instance()->untaggedCategory();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : selectedTags) {
                if (!positionedTagSet.contains(tag)) {
                    addTagToCandidateList(category, tag);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const DB::ImageInfo& item) -> bool {
                                   return item.description() == _firstDescription;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &item] (const CategoryItemDetails& candidate) {
        return candidate.name == item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file: files)
        append(DB::FileName::fromAbsolutePath(file));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DB::FileName& image :  images ) {
        const DB::ImageInfoPtr info = image.info();
        if ( !info->isVideo() )
            continue;
        // silently ignore videos not (currently) on disk:
        if ( ! info->fileName().exists() )
            continue;
        int length = info->videoLength();
        if ( length == -1 ) {
            BackgroundTaskManager::JobManager::instance()->addJob(
                        new BackgroundJobs::ReadVideoLengthJob(info->fileName(), BackgroundTaskManager::BackgroundVideoPreviewRequest));
        }
    }
```

#### AUTO 


```{c}
auto tagName
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : list) {
        QString file = fileName.absolute();
        QString zippedName = _filenameMapper.uniqNameFor(fileName);

        if ( _maxSize == -1 || Utilities::isVideo( fileName ) || Utilities::isRAW( fileName )) {
            if ( QFileInfo( file ).isSymLink() )
                file = QFileInfo(file).readLink();

            if ( _location == Inline )
                _zip->addLocalFile( file, QString::fromLatin1( "Images/" ) + zippedName );
            else if ( _location == AutoCopy )
                Utilities::copy( file, _destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( _location == Link )
                Utilities::makeHardLink( file, _destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( _location == Symlink )
                Utilities::makeSymbolicLink( file, _destdir + QString::fromLatin1( "/" ) + zippedName );

            _steps++;
            _progressDialog->setValue( _steps );
        }
        else {
            _filesRemaining++;
            ImageManager::ImageRequest* request =
                new ImageManager::ImageRequest( DB::FileName::fromAbsolutePath(file), QSize( _maxSize, _maxSize ), 0, this );
            request->setPriority( ImageManager::BatchTask );
            ImageManager::AsyncLoader::instance()->load( request );
        }

        // Test if the cancel button was pressed.
        qApp->processEvents( QEventLoop::AllEvents );

        if ( _progressDialog->wasCanceled() ) {
            *_ok = false;
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selection) {
                DB::ImageInfoPtr info = fileName.info();
                if (!hadHit) {
                    mustRemoveToken = info->hasCategoryInfo(tokensCategory->name(), token);
                    hadHit = true;
                }

                if (mustRemoveToken)
                    info->removeCategoryInfo(tokensCategory->name(), token);
                else
                    info->addCategoryInfo(tokensCategory->name(), token);

                model()->updateCell(fileName);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DBExifInfo elt : map) {
        query->bindValue(0, elt.first.absolute());
        int i = 1;
        for (const DatabaseElement *e : elements()) {
            query->bindValue(i++, e->valueFromExif(elt.second));
        }

        if (!query->exec()) {
            showErrorAndFail(*query);
        }
    }
```

#### AUTO 


```{c}
const auto relativeUrl1 = QUrl::fromLocalFile(relativeFilePath1).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *bin : m_geoClusters) {
        bin->render(painter, *viewPortParams, thumbs, mapStyle());
    }
```

#### AUTO 


```{c}
auto tagIt = tags.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_list)) {
        if (modifiedFileCompString.length() >= 0 && fileName.relative().contains(modifiedFileComponent)) {

            for (QStringList::const_iterator it = originalFileComponents.constBegin();
                 it != originalFileComponents.constEnd(); ++it) {
                QString tmp = fileName.relative();
                tmp.replace(modifiedFileComponent, (*it));
                DB::FileName originalFileName = DB::FileName::fromRelativePath(tmp);

                if (originalFileName != fileName && m_list.contains(originalFileName)) {
                    DB::MD5 sum = originalFileName.info()->MD5Sum();
                    if (tostack[sum].isEmpty()) {
                        if (m_origTop->isChecked()) {
                            tostack.insert(sum, DB::FileNameList() << originalFileName);
                            tostack[sum].append(fileName);
                        } else {
                            tostack.insert(sum, DB::FileNameList() << fileName);
                            tostack[sum].append(originalFileName);
                        }
                    } else
                        tostack[sum].append(fileName);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto tags = (*it).second;
```

#### RANGE FOR STATEMENT 


```{c}
for( QString &category : oldCategories ) {
        QString oldName = category;
        category = sanitizedCategoryName(oldName );
        categories << category;
        QString lockEntry = privacyConfig.readEntry<QString>(oldName, QString());
        if (! lockEntry.isEmpty() )
        {
            privacyConfig.writeEntry<QString>(category, lockEntry);
            privacyConfig.deleteEntry(oldName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &oldFileName : matchingFiles) {
                    dir.rename(oldFileName, oldName + oldFileName.mid(newName.length()));
                }
```

#### AUTO 


```{c}
const auto &info
```

#### LAMBDA EXPRESSION 


```{c}
[] (const DB::FileName& file) {
        // Only include unstacked images, and the top of stacked images.
        // And also exclude videos
        return DB::ImageDB::instance()->info(file)->stackOrder() > 1 ||
                DB::ImageDB::instance()->info(file)->isVideo();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MOVE         = 0b10000000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &image : m_images) {
        const Marble::GeoDataCoordinates pos(image->coordinates().lon(), image->coordinates().lat(),
                                             image->coordinates().alt(),
                                             Marble::GeoDataCoordinates::Degree);
        if (m_showThumbnails) {
            // FIXME(l3u) Maybe we should cache the scaled thumbnails?
            painter->drawPixmap(pos, ImageManager::ThumbnailCache::instance()->lookup(image->fileName()).scaled(QSize(40, 40), Qt::KeepAspectRatio));
        } else {
            painter->drawPixmap(pos, m_pin);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : grps) {
        if (!shouldSaveCategory(name))
            continue;

        ElementWriter categoryElm(writer, QString::fromLatin1("option"), false);

#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
        const auto itemsOfCategory = info->itemsOfCategory(name);
        QStringList items(itemsOfCategory.begin(), itemsOfCategory.end());
#else
        QStringList items = info->itemsOfCategory(name).toList();
#endif
        std::sort(items.begin(), items.end());
        if (!items.isEmpty()) {
            topElm.writeStartElement();
            categoryElm.writeStartElement();
            writer.writeAttribute(QString::fromLatin1("name"), name);
        }

        for (const QString &itemValue : qAsConst(items)) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), itemValue);

            QRect area = info->areaForTag(name, itemValue);
            if (!area.isNull()) {
                writer.writeAttribute(QString::fromLatin1("area"), areaToString(area));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : m_setup.imageList()) {
        if ( wasCancelled() )
            return;

        createImage(fileName, m_setup.thumbSize());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : items) {
        if (matcher.XMLtoDB().contains(item))
            res.insert(matcher.XMLtoDB()[item]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        QModelIndex index = model()->fileNameToIndex(fileName);
        if (count == 0) {
            start = index;
            end = index;
        } else if (index.row() == end.row() + 1) {
            end = index;
        } else {
            selection.merge(QItemSelection(start, end), QItemSelectionModel::Select);
            start = index;
            end = index;
        }
        count++;
    }
```

#### AUTO 


```{c}
const auto images = DB::ImageDB::instance()->images();
```

#### AUTO 


```{c}
const auto datum = data.findKey(Exiv2::ExifKey("Exif.CanonCs.Lens"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        if (category->isSpecialCategory()) {
            continue;
        }

        // Add the real categories as top-level items
        QTreeWidgetItem *topLevelItem = new QTreeWidgetItem;
        topLevelItem->setText(0, category->name());
        topLevelItem->setFlags(topLevelItem->flags() & Qt::ItemIsEnabled);
        QFont font = topLevelItem->font(0);
        font.setWeight(QFont::Bold);
        topLevelItem->setFont(0, font);
        m_categoryTreeWidget->addTopLevelItem(topLevelItem);

        // Build a map with all members for each group
        QMap<QString, QStringList> membersForGroup;
        const QStringList allGroups = m_memberMap.groups(category->name());
        for (const QString &group : allGroups) {
            // FIXME: Why does the member map return an empty category?!
            if (group.isEmpty()) {
                continue;
            }

            QStringList allMembers = m_memberMap.members(category->name(), group, true);
            membersForGroup[group] = allMembers;
        }

        // Add all groups (their sub-groups will be added recursively)
        addSubCategories(topLevelItem, membersForGroup, allGroups);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& key : keys) {
        emit imageUpdated(key.first, key.second); // Clear the image and request it anew
    }
```

#### AUTO 


```{c}
const auto nonlocalUrl = QStringLiteral("https://example.com/image.jpg");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &imageInfo : search(searchInfo)) {
        if (imageInfo->mediaType() == Image)
            ++images;
        else
            ++videos;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &imageInfo : qAsConst(m_images))
        m_imageCache.insert(imageInfo->fileName().absolute(), imageInfo);
```

#### AUTO 


```{c}
auto *myerr = (myjpeg_error_mgr *)cinfo->err;
```

#### AUTO 


```{c}
auto filterWidget = m_thumbnailView->filterWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elms )
    {
        formalList.append( e->queryString() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &a : qAsConst(showIfStacked)) {
                    if (!DB::ImageDB::instance()->getStackFor(a).isEmpty()) {
                        const auto stackedImages = DB::ImageDB::instance()->getStackFor(a);
                        for (const DB::FileName &b : stackedImages)
                            toBeShown.append(b);
                    } else
                        toBeShown.append(a);
                }
```

#### AUTO 


```{c}
auto it = m_hash.constKeyValueBegin();
```

#### AUTO 


```{c}
const auto emptyFN = DB::FileName();
```

#### AUTO 


```{c}
const auto historyEntry = m_component + QString::fromUtf8(CFG_HISTORY);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : kpaDemoCatDirs) {
        QDirIterator it(dir, QStringList() << QStringLiteral("*.jpg"));
        while (it.hasNext()) {
            catImages.append(it.next());
        }
    }
```

#### AUTO 


```{c}
const auto &existingTag
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &selectedPath : selected().toStringList(DB::AbsolutePath)) {
            allSelectedFiles << QUrl::fromLocalFile(selectedPath);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &tag : positionableTagCandidates) {
                if (tag == m_proposedTagData) {
                    continue;
                }

                QAction *action = new QAction(
                    tag.second + QString::fromLatin1(" (") +
                    m_dialog->localizedCategory(tag.first) +
                    QString::fromLatin1(")"), this
                );

                QStringList data;
                data << tag.first << tag.second;
                action->setData(data);

                submenu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &a : stackedImages)
                        toBeShown.append(a);
```

#### AUTO 


```{c}
const auto tagData = area->tagData();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : qAsConst(m_fileList))
        fileList.append(fileName.absolute());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &groupName : allGroups) {
                if (membersForGroup[group].contains(groupName)) {
                    subGroups[groupName] = membersForGroup[groupName];
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : list) {
        QString file = fileName.absolute();
        QString zippedName = m_filenameMapper.uniqNameFor(fileName);

        if ( m_maxSize == -1 || Utilities::isVideo( fileName ) || isRAW( fileName )) {
            if ( QFileInfo( file ).isSymLink() )
                file = QFileInfo(file).readLink();

            if ( m_location == Inline )
                m_zip->addLocalFile( file, QString::fromLatin1( "Images/" ) + zippedName );
            else if ( m_location == AutoCopy )
                Utilities::copyOrOverwrite( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( m_location == Link )
                Utilities::makeHardLink( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );
            else if ( m_location == Symlink )
                Utilities::makeSymbolicLink( file, m_destdir + QString::fromLatin1( "/" ) + zippedName );

            m_steps++;
            m_progressDialog->setValue( m_steps );
        }
        else {
            m_filesRemaining++;
            ImageManager::ImageRequest* request =
                new ImageManager::ImageRequest( DB::FileName::fromAbsolutePath(file), QSize( m_maxSize, m_maxSize ), 0, this );
            request->setPriority( ImageManager::BatchTask );
            ImageManager::AsyncLoader::instance()->load( request );
        }

        // Test if the cancel button was pressed.
        qApp->processEvents( QEventLoop::AllEvents );

        if ( m_progressDialog->wasCanceled() ) {
            *m_ok = false;
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ImageDecoder *decoder : *decoders()) {
        if (decoder->_decode(img, request, fullSize, dim))
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString dirName : dirList ) {
        const StringSet &files(dirMap[dirName]);
        FastDir dir(dirName);
        QStringList sortedList = dir.sortFileList(files);
        QString fsName( QString::fromLatin1( "NULLFS" ) );
        if ( statfs( QByteArray(QFile::encodeName(dirName)).constData(), &statbuf ) == 0 ) {
            QCryptographicHash md5calculator(QCryptographicHash::Md5);
            QByteArray md5Buffer((const char *) &(statbuf.f_fsid), sizeof(statbuf.f_fsid));
            md5calculator.addData(md5Buffer);
            fsName = QString::fromLatin1(md5calculator.result().toHex());
        }
        if ( ! m_fsMap.contains( fsName ) ) {
            QStringList newList;
            m_fsMap.insert(fsName, newList);
        }
        m_fsMap[ fsName ] += sortedList;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int THUMBNAIL_CACHE_SAVE_INTERNAL_MS = (5 * 1000);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString fs : filesystemsToRemove) {
            tmpFsMap.remove( fs );
        }
```

#### AUTO 


```{c}
const auto areas = m_dialog->areas();
```

#### AUTO 


```{c}
auto *exifWidget = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (SerializerInterface *serializer : m_serializers)
        serializer->decode(stream);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &itemWord : itemWords) {
                if (itemWord.startsWith(searchWord)) {
                    found = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName& fileName : _setup.imageList()) {
        const DB::ImageInfoPtr info = fileName.info();
        if ( wasCancelled() )
            return false;

        if ( count % cols == 0 ) {
            row = doc.createElement( QString::fromLatin1( "tr" ) );
            row.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-row" ) );
            doc.appendChild( row );
            count = 0;
        }

        col = doc.createElement( QString::fromLatin1( "td" ) );
        col.setAttribute( QString::fromLatin1( "class" ), QString::fromLatin1( "thumbnail-col" ) );
        row.appendChild( col );

        if (first.isEmpty())
            first = namePage( width, height, fileName);
        else
            last = namePage( width, height, fileName);

    if (!Utilities::isVideo(fileName))
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"" )
                  .arg( nameImage( fileName, width ) ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, maxImageSize() ) );
    else
            images += QString::fromLatin1( "gallery.push([\"%1\", \"%2\", \"%3\", \"" )
                    .arg( nameImage( fileName, _setup.thumbSize() ) ).arg( nameImage( fileName, _setup.thumbSize() ) ).arg( QFileInfo(fileName.absolute()).fileName() );

        // -------------------------------------------------- Description
        QString description = populateDescription(DB::ImageDB::instance()->categoryCollection()->categories(), info);

        if ( !description.isEmpty() )
            description = QString::fromLatin1 ( "<ul>%1</ul>" ).arg ( description );
        else
            description = QString::fromLatin1 ( "" );

        description.replace( QString::fromLatin1( "\n$" ), QString::fromLatin1 ( "" ) );
        description.replace( QString::fromLatin1( "\n" ), QString::fromLatin1 ( " " ) );
        description.replace( QString::fromLatin1( "\"" ), QString::fromLatin1 ( "\\\"" ) );

        images += description;
        images += QString::fromLatin1( "\"]);\n" );

        QDomElement href = doc.createElement( QString::fromLatin1( "a" ) );
        href.setAttribute( QString::fromLatin1( "href" ),
                           namePage( width, height, fileName));
        col.appendChild( href );

        QDomElement img = doc.createElement( QString::fromLatin1( "img" ) );
        img.setAttribute( QString::fromLatin1( "src" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        img.setAttribute( QString::fromLatin1( "alt" ),
                          nameImage( fileName, _setup.thumbSize() ) );
        href.appendChild( img );
        ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *bin : m_geoClusters) {
        bin->render(painter, *viewPortParams, m_pin, m_showThumbnails ? MapStyle::ShowThumbnails : MapStyle::ShowPins);
    }
```

#### AUTO 


```{c}
auto lockData = Settings::SettingsData::instance()->currentLock();
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
            fileName.info()->rotate(angle);
            ImageManager::ThumbnailCache::instance()->removeThumbnail(fileName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &cacheName : origCache) {
                if (fileName != cacheName)
                    newCache.append(cacheName);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        if (area != areaToExclude
            && area->proposedTagData() == tagData
            && area->tagData().first.isEmpty()) {
            area->removeProposedTagData();
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int PRELOAD_MD5 = 1;
```

#### AUTO 


```{c}
const auto rootFN = FileName::fromAbsolutePath(imageRoot.path() + QStringLiteral("/"));
```

#### RANGE FOR STATEMENT 


```{c}
for (StringSet &set : groupMap) {
        if (set.contains(oldName)) {
            set.remove(oldName);
            set.insert(newName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QueueType& queue : m_jobs) {
        if ( index-offset < queue.count() )
            return queue[index-offset];
        else
            offset += queue.count();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : selectedFiles) {
        urls.append(QUrl::fromLocalFile(fileName.absolute()));
        urlcount++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::ImageInfoPtr &image: m_images) {
        const Marble::GeoDataCoordinates pos(image->coordinates().lon(), image->coordinates().lat(),
                                             image->coordinates().alt(),
                                             Marble::GeoDataCoordinates::Degree);
        if (m_showThumbnails) {
            // FIXME(l3u) Maybe we should cache the scaled thumbnails?
            painter->drawPixmap(pos, ImageManager::ThumbnailCache::instance()->lookup(
                                         image->fileName()).scaled(QSize(40, 40),
                                                                   Qt::KeepAspectRatio));
        } else {
            painter->drawPixmap(pos, m_pin);
        }
    }
```

#### AUTO 


```{c}
const auto categoryName = (*it).first;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ListSelect *ls : qAsConst(m_optionList)) {
        info.setCategoryInfo(ls->category(), ls->itemsOn());
        if (ls->positionable()) {
            info.setPositionedTags(ls->category(), areas[ls->category()]);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &imageInfo : images) {
        total++;
        if (addImage(imageInfo.info()))
            count++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QJsonObject &output, int error, const QString &message) {
        if (error) {
            emit imageSharingFailed(message);
        } else {
            auto filename = DB::FileName::fromAbsolutePath(output[QStringLiteral("url")].toString());
            emit imageShared(filename);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : grps) {
        QDomElement opt = doc.createElement(QString::fromLatin1("option"));
        opt.setAttribute(QString::fromLatin1("name"), name);

        const StringSet items = info->itemsOfCategory(name);
        bool any = false;
        for (const QString &item : items) {
            QDomElement val = doc.createElement(QString::fromLatin1("value"));
            val.setAttribute(QString::fromLatin1("value"), item);
            opt.appendChild(val);
            any = true;
            anyAtAll = true;
        }
        if (any)
            elm.appendChild(opt);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categoryList) {
        QString categoryName = category->name();

        if (!shouldSaveCategory(categoryName))
            continue;

        const StringSet items = info->itemsOfCategory(categoryName);
        if (!items.empty()) {
            QStringList idList;

            for (const QString &itemValue : items) {
                QRect area = info->areaForTag(categoryName, itemValue);

                if (area.isValid()) {
                    // Positioned tags can't be stored in the "fast" format
                    // so we have to handle them separately
                    positionedTags[categoryName] << QPair<QString, QRect>(itemValue, area);
                } else {
                    int id = static_cast<const XMLCategory *>(category.data())->idForName(itemValue);
                    idList.append(QString::number(id));
                }
            }

            // Possibly all ids of a category have area information, so only
            // write the category attribute if there are actually ids to write
            if (!idList.isEmpty()) {
                std::sort(idList.begin(), idList.end());
                writer.writeAttribute(escape(categoryName), idList.join(QStringLiteral(",")));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tagName : categoryItems) {
            ElementWriter dummy(writer, QString::fromLatin1("value"));
            writer.writeAttribute(QString::fromLatin1("value"), tagName);
            writer.writeAttribute(QString::fromLatin1("id"),
                                  QString::number(static_cast<XMLCategory *>(category.data())->idForName(tagName)));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute(QString::fromUtf8("birthDate"), birthDate.toString(Qt::ISODate));
        }
```

#### AUTO 


```{c}
const auto bgRole = matches ? QPalette::Highlight : QPalette::Base;
```

#### LAMBDA EXPRESSION 


```{c}
[this, categoryName](const QString itemName) {
                           return m_imageNameStore.idForCategory(categoryName, itemName);
                       }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &fileName : tmp ) {
            qCDebug(FastDirLog) << fileName;
            answer << fileName;
        }
```

#### AUTO 


```{c}
const auto categories = DB::ImageDB::instance()->categoryCollection()->categories();
```

#### AUTO 


```{c}
const auto availableKeys = Exif::Info::instance()->availableKeys();
```

#### CONST EXPRESSION 


```{c}
constexpr int MOVE = 0b10000000;
```

#### AUTO 


```{c}
auto app = QCoreApplication::instance();
```

#### CONST EXPRESSION 


```{c}
constexpr int THUMBNAIL_FILE_VERSION = 5;
```

#### AUTO 


```{c}
auto preferredBackend = Settings::preferredVideoBackend(backend, exclusions);
```

#### CONST EXPRESSION 


```{c}
constexpr int THUMBNAIL_FILE_VERSION = 4;
```

#### AUTO 


```{c}
const auto allAreas = this->findChildren<ResizableFrame *>();
```

#### AUTO 


```{c}
const auto otherImageFileName = DB::FileName::fromRelativePath(QStringLiteral("otherImage.jpg"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileName& fileName : list) {
        if ( count % 10 == 0 ) {
            dialog.setValue( count ); // ensure to call setProgress(0)
            qApp->processEvents( QEventLoop::AllEvents );

            if ( dialog.wasCanceled() ) {
                if ( wasCanceled )
                    *wasCanceled = true;
                return dirty;
            }
        }

        MD5 md5 = MD5Sum( fileName );
        if (md5.isNull()) {
            cantRead << fileName;
            continue;
        }

        ImageInfoPtr info = ImageDB::instance()->info(fileName);
        if  ( info->MD5Sum() != md5 ) {
            info->setMD5Sum( md5 );
            dirty = true;
            ImageManager::ThumbnailCache::instance()->removeThumbnail(fileName);
        }

        md5Map->insert( md5, fileName );

        ++count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : info->itemsOfCategory(categoryName)) {
            const QString age = Utilities::formatAge(category, item, info);
            list.append(CategoryItemDetails(item, age));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : files) {
        QHBoxLayout *lay = new QHBoxLayout;
        optionsLayout->addLayout(lay);
        QRadioButton *button = new QRadioButton(fileName.relative());
        button->setProperty("data", QVariant::fromValue(fileName));
        lay->addWidget(button);
        if (first) {
            button->setChecked(true);
            first = false;
        }
        QToolButton *details = new QToolButton;
        details->setText(i18nc("i for info", "i"));
        details->installEventFilter(this);
        details->setProperty("data", QVariant::fromValue(fileName));
        lay->addWidget(details);
        m_buttons.append(button);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KToggleAction *action : qAsConst(m_actionList)) {
        const auto category = categoryCollection->categoryForName(action->data().value<QString>());
        action->setChecked(category->doShow());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DatabaseElement *e : elements(version))
        {
            query.prepare( QString::fromLatin1( "alter table exif add column %1")
                           .arg( e->createString()) );
            if ( !query.exec())
                showError( query );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filename : incorrectDimensions) {
                    console << filename.absolute() << "\n";
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        if (DB::ImageInfo::imageOnDisk(fileName))
            listOnDisk.append(fileName);
    }
```

#### AUTO 


```{c}
auto labelPalette = m_outputLabel->palette();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Category& category : categories)
        stream << category.name << category.text << category.icon << category.enabled;
```

#### CONST EXPRESSION 


```{c}
constexpr int DEFAULT_MAX_SEEKAHEAD_IMAGES = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (QDockWidget *dock : m_dockWidgets) {
        if (dock->isFloating()) {
            qCDebug(AnnotationDialogLog) << "Showing dock: " << dock->objectName();
            dock->show();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        if (area->tagData() == tagData) {
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PopupAction which : { PopupAction::OpenCurrent, PopupAction::OpenAllSelected, PopupAction::CopyAndOpenAllSelected }) {
        if (which == PopupAction::OpenCurrent && !current)
            continue;

        const bool multiple = (m_list.count() > 1);
        const bool enabled = (which != PopupAction::OpenAllSelected && m_currentInfo) || (which == PopupAction::OpenAllSelected && multiple);

        // Submenu
        QString menuLabel;
        switch (which) {
        case PopupAction::OpenCurrent:
            menuLabel = i18n("Current Item");
            break;
        case PopupAction::OpenAllSelected:
            menuLabel = i18n("All Selected Items");
            break;
        case PopupAction::CopyAndOpenAllSelected:
            menuLabel = i18n("Copy and Open");
        }
        Q_ASSERT(!menuLabel.isNull());

        QMenu *submenu = addMenu(menuLabel);
        submenu->setEnabled(enabled);

        // Fetch set of offers
        OfferType offers;
        if (which == PopupAction::OpenCurrent)
            offers = appInfos(DB::FileNameList() << current->fileName());
        else
            offers = appInfos(imageList);

        for (KService::Ptr offer : qAsConst(offers)) {
            action = submenu->addAction(offer->name());
            action->setIcon(QIcon::fromTheme(offer->icon()));
            action->setEnabled(enabled);
            connect(action, &QAction::triggered, this, [this, offer, which] {
                runService(offer, relevantUrls(which, offer));
            });
        }

        // A personal command
        action = submenu->addAction(i18n("Open With..."));
        // XXX: action->setIcon( QIcon::fromTheme((*offerIt).second) );
        action->setEnabled(enabled);
        connect(action, &QAction::triggered, this, [this, which] {
            const QList<QUrl> urls = relevantUrls(which, {});

            auto *uiParent = MainWindow::Window::theMainWindow();
#if KIO_VERSION < QT_VERSION_CHECK(5, 71, 0)
            KRun::displayOpenWithDialog(lst, uiParent);
#else
                auto job = new KIO::ApplicationLauncherJob();
                job->setUrls(urls);
                job->setUiDelegate(new KIO::JobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, uiParent));
                job->start();
#endif
        });

        // A personal command
        // XXX: see kdialog.h for simple usage
        action = submenu->addAction(i18n("Your Command Line"));
        // XXX: action->setIcon( QIcon::fromTheme((*offerIt).second) );
        action->setEnabled(enabled);
        connect(action, &QAction::triggered, this, [this] {
            static RunDialog *dialog = new RunDialog(MainWindow::Window::theMainWindow());
            dialog->setImageList(m_list);
            dialog->show();
        });
    }
```

#### AUTO 


```{c}
const auto selection = selected();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &filename : incorrectDimensions) {
                console << filename.absolute() << "\n";
            }
```

#### CONST EXPRESSION 


```{c}
constexpr auto CFG_DISABLED { "_disabled" };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString>& tag : positionableTagCandidates) {
                    submenu->addAction(createAssociateTagAction(tag));
                }
```

#### AUTO 


```{c}
const auto absoluteCorrectFN = FileName::fromAbsolutePath(absoluteFilePath);
```

#### CONST EXPRESSION 


```{c}
constexpr auto v4IndexHexData {
    "00000004" // version
    "00000003" // current file
    "00033714" // offset in file
    "00000003" // number of thumbnails
    "000000160062006C00610063006B00690065002E006A00700067000000000000462C00001F0B" // "blackie.jpg"
    "0000001600730070006900660066005F0032002E006A0070006700000000000038A900001DFD" // "spiff_2.jpg"
    "0000001C006E00650077005F0077006100760065005F0032002E006A0070006700000000000000000000229D" // "new_wave_2.jpg"
};
```

#### AUTO 


```{c}
auto backend = SettingsData::instance()->videoBackend();
```

#### RANGE FOR STATEMENT 


```{c}
for (CategoryMatcher* optionMatcher : m_categoryMatchers) {
        optionMatcher->debug(1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ignoredComment : Settings::SettingsData::instance()->EXIFCommentsToStrip()) {
                if (desc == ignoredComment) {
                    doSetDescription = false;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto *topLevelCluster
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& key : keys) {
        m_categoryInfomation[key].unite(other.m_categoryInfomation[key]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &b : stackedImages)
                            toBeShown.append(b);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr &category : categories) {
        m_albumCategory->addItem(category->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexSelection) {
        const DB::FileName currFileName = model()->imageAt(index.row());
        bool includeAllStacks = false;
        switch (mode) {
        case IncludeAllStacks:
            includeAllStacks = true;
            /* FALLTHROUGH */
        case ExpandCollapsedStacks: {
            // if the selected image belongs to a collapsed thread,
            // imply that all images in the stack are selected:
            const DB::ImageInfoPtr imageInfo = DB::ImageDB::instance()->info(currFileName);
            if (imageInfo && imageInfo->isStacked()
                && (includeAllStacks || !model()->isItemInExpandedStack(imageInfo->stackId()))) {
                // add all images in the same stack
                res.append(DB::ImageDB::instance()->getStackFor(currFileName));
            } else
                res.append(currFileName);
        } break;
        case NoExpandCollapsedStacks:
            res.append(currFileName);
            break;
        }
    }
```

#### AUTO 


```{c}
auto add = [&](const QString &title, const char *name, int value, const QKeySequence &key) {
        if (count++ == 5) {
            QAction *sep = new QAction(menu);
            sep->setSeparator(true);
            menu->addAction(sep);
        }

        QAction *seek = m_actions->addAction(QString::fromLatin1(name));
        seek->setText(title);
        seek->setShortcut(key);
        m_actions->setShortcutsConfigurable(seek, false);
        connect(seek, &QAction::triggered, [this, value] {
            m_videoDisplay->relativeSeek(value);
        });
        menu->addAction(seek);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        m_displayList.removeAll(fileName);
        m_imageList.removeAll(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        m_blockList.insert(fileName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category : categories() ) {
        QMap<QString, DB::CountWithRange> items = DB::ImageDB::instance()->classify( BrowserPage::searchInfo(), category->name(), DB::anyMediaType, DB::ClassificationMode::PartialCount );
        m_rowHasSubcategories[row] = items.count()>1;
        ++row;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
            images.append(fileName.info());
        }
```

#### AUTO 


```{c}
const auto &filename
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
            if (area->tagData() == deselectedTag) {
                area->removeTagData();
                m_areasChanged = true;
                // Only one area can be associated with the tag, so we can return here
                return;
            }
        }
```

#### AUTO 


```{c}
const auto inputUrl = QUrl::fromUserInput(fileName, Settings::SettingsData::instance()->imageDirectory(), QUrl::AssumeLocalFile);
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(ImageDetailsRequest)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : searchInfo.values()) {
        std::tie(category, value) = item;
        dbSearchInfo.addAnd(category, value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : DB::ImageDB::instance()->files()) {
        m_lastId++;
        m_idToNameMap.insert(m_lastId, fileName);
        m_nameToIdMap.insert(fileName, m_lastId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString name : categories) {
        DB::CategoryPtr category = DB::ImageDB::instance()->categoryCollection()->categoryForName(name);

        if (! shouldSaveCategory(name)) {
            continue;
        }

        ElementWriter dummy(writer, QString::fromUtf8("Category"));
        writer.writeAttribute(QString::fromUtf8("name"),  name);
        writer.writeAttribute(QString::fromUtf8("icon"), category->iconName());
        writer.writeAttribute(QString::fromUtf8("show"), QString::number(category->doShow()));
        writer.writeAttribute(QString::fromUtf8("viewtype"), QString::number(category->viewType()));
        writer.writeAttribute(QString::fromUtf8("thumbnailsize"), QString::number(category->thumbnailSize()));
        writer.writeAttribute(QString::fromUtf8("positionable"), QString::number(category->positionable()));
        if (category == tokensCategory) {
            writer.writeAttribute(QString::fromUtf8("meta"),QString::fromUtf8("tokens"));
        }

        // FIXME (l3u):
        // Correct me if I'm wrong, but we don't need this, as the tags used as groups are
        // added to the respective category anyway when they're created, so there's no need to
        // re-add them here. Apart from this, adding an empty group (one without members) does
        // add an empty tag ("") doing so.
        /*
        QStringList list =
                Utilities::mergeListsUniqly(category->items(),
                                            m_db->_members.groups(name));
        */

        Q_FOREACH(const QString &tagName, category->items()) {
            ElementWriter dummy( writer, QString::fromLatin1("value") );
            writer.writeAttribute( QString::fromLatin1("value"), tagName );
            writer.writeAttribute( QString::fromLatin1( "id" ),
                                    QString::number(static_cast<XMLCategory*>( category.data() )->idForName( tagName ) ));
            QDate birthDate = category->birthDate(tagName);
            if (!birthDate.isNull())
                writer.writeAttribute( QString::fromUtf8("birthDate"), birthDate.toString(Qt::ISODate) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category: DB::ImageDB::instance()->categoryCollection()->categories()) {
        if (category->isSpecialCategory()) {
            continue;
        }
        m_categoryBox->addItem(category->text(), category->name());
        if (category->name() == QString::fromUtf8("People")) {
            defaultIndex = index;
        }
        ++index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fileName : allImageFiles) {
        dialog.setValue(i++);
        add(fileName);
        if (i % 10)
            qApp->processEvents();
        if (dialog.wasCanceled())
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : items) {
        QTreeWidgetItem *parent = item->parent();
        QString parentText = parent ? parent->text(0) : QString();
        selected.insert(CategoryListView::DragItemInfo(parentText, item->text(0)));
    }
```

#### AUTO 


```{c}
const auto angleDelta = event->angleDelta() / 5;
```

#### AUTO 


```{c}
const auto relativeFilePath2 = QStringLiteral("subdir/image.jpg");
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString comment : commentsToStrip )
    {
        // separate comments with "-,-" and escape existing commas by doubling
        if ( !comment.isEmpty() )
            commentsToStripString += comment.replace( QString::fromLatin1(","), QString::fromLatin1(",,") ) + QString::fromLatin1("-,-");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResizableFrame *area : allAreas) {
        area->setGeometry(areaActualToPreview(area->actualCoordinates()));
    }
```

#### AUTO 


```{c}
const auto itemsOfCategory = info->itemsOfCategory(name);
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(SearchRequest)
```

#### CONST EXPRESSION 


```{c}
constexpr int defaultScoutBufSize = 1048576;
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : items) {
        DB::ImageInfoPtr imgInfo = info(fileName);
        Q_ASSERT(imgInfo);
        if (imgInfo->isStacked()) {
            stacks << imgInfo->stackId();
            stackOrder = qMax(stackOrder, imgInfo->stackOrder() + 1);
        } else {
            images << imgInfo;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (const DB::ImageInfo& item) -> bool {
                                   return item.description() == m_firstDescription;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&category, &item](const CategoryItemDetails &candidate) {
                                return candidate.name == item;
                            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, value] {
            m_videoDisplay->relativeSeek(value);
        }
```

#### AUTO 


```{c}
const auto& positionedTag
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::CategoryPtr& category: DB::ImageDB::instance()->categoryCollection()->categories()) {
        if(!category->isSpecialCategory()) {
            m_categoryBox->addItem(category->text(), category->name());
            if ( category->name() == QString::fromUtf8("Persons") || category->name() == QString::fromUtf8("People"))
                defaultIndex = index;
            ++index;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        query.bindValue(0, fileName.absolute());
        if (!query.exec()) {
            m_db.rollback();
            showErrorAndFail(query);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
ADDFACTORY(ImageDetailsResult)
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(scrollWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString fileName : files)
        answer << DB::FileName::fromAbsolutePath(fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DB::FileName &fileName : list) {
        dialog.setValue(++progress);
        qApp->processEvents(QEventLoop::AllEvents);
        if (dialog.wasCanceled())
            break;
        if (fileName.info()->isNull())
            continue;

        DB::ImageDate date = fileName.info()->date();
        bool show = false;
        if (m_dateNotTime->isChecked()) {
            DB::FileInfo fi = DB::FileInfo::read(fileName, DB::EXIFMODE_DATE);
            if (fi.dateTime().date() == date.start().date())
                show = (fi.dateTime().time() != date.start().time());
            if (show) {
                edit->append(QString::fromLatin1("%1:<br/>existing = %2<br>new..... = %3")
                                 .arg(fileName.relative())
                                 .arg(date.start().toString())
                                 .arg(fi.dateTime().toString()));
            }
        } else if (m_missingDate->isChecked()) {
            show = !date.start().isValid();
        } else if (m_partialDate->isChecked()) {
            show = (date.start() != date.end());
        }

        if (show)
            toBeShown.append(fileName);
    }
```

