#### LAMBDA EXPRESSION 


```{c}
[events] {
        for (auto *event : events) {
            event->reloadConfig();
        }
    }
```

#### AUTO 


```{c}
auto apportDirWatch =  new KDirWatch(this);
```

#### AUTO 


```{c}
auto hooksDirWatch = new KDirWatch(this);
```

#### AUTO 


```{c}
auto installWatcher = new InstallDBusWatcher(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *event : events) {
            event->reloadConfig();
        }
```

#### AUTO 


```{c}
auto stampDirWatch = new KDirWatch(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &application, const QString &package) { getInfo(application, package); }
```

#### AUTO 


```{c}
auto *event
```

#### RANGE FOR STATEMENT 


```{c}
for (QString locale_combo: locale.combinations()) {
        value = m_fields.value(prefix + locale_combo);
        if (!value.isEmpty()) {
            break;
        }
    }
```

