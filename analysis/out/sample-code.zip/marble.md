#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: placemarks) {
        QPoint position = placemark->symbolRect().bottomLeft().toPoint() + QPoint(0, qRound(0.8 * height));
        auto const popularity = placemark->placemark()->popularity();
        painter->drawText(position, QStringLiteral("p: %1").arg(popularity));
        position -= QPoint(0, placemark->symbolRect().height() + height);
        auto const zoomLevel = placemark->placemark()->zoomLevel();
        painter->drawText(position, QStringLiteral("z: %1").arg(zoomLevel));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto place: places) {
        auto const places = candidatesFor(place);
        bool hasMatch = false;
        bool isValid = false;
        QString const placeName = place->name();
        if (!places.isEmpty()) {
            auto match = places.first();
            if (match->name() == place->name()) {
                ++validated;
                isValid = true;
            } else {
                if (distanceSphere(match->coordinate(), place->coordinate()) < maxDistance) {
                    if (levenshteinDistance(places.first()->name(), placeName) < 6) {
                        if (m_verbose) {
                            qDebug() << "Correcting" << placeName << "to" << match->name();
                        }
                        place->setName(match->name());
                        place->osmData().removeTag("name");
                        place->osmData().addTag("name", match->name());
                        hasMatch = true;
                    }
                }

                if (m_verbose && !hasMatch) {
                    qDebug() << "No match for " << placeName << ", candidates: ";
                    for (auto candidate: places) {
                        qDebug() << distanceSphere(candidate->coordinate(), place->coordinate()) * EARTH_RADIUS << " m, "
                                 << "levenshtein distance " << levenshteinDistance(placeName, candidate->name()) << ":" << candidate->name();
                    }
                }
            }
        } else if (m_verbose) {
            qDebug() << "No match for " << placeName << " at " << place->coordinate().toString(GeoDataCoordinates::Decimal) << " and no candidates for replacement";
        }
        hits += hasMatch ? 1 : 0;
        misses += (hasMatch || isValid) ? 0 : 1;
    }
```

#### AUTO 


```{c}
const auto polygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0))
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems.negative) {
            if (item->contains(curpos, viewport)) {
                result << item->feature();
            }
        }
```

#### AUTO 


```{c}
auto const nodeIter = nodes.constFind(nodeId);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &ds: dsList ) {
        mDebug() << "Loading satellite data from:" << ds;
        m_satModel->downloadFile( QUrl( ds ), ds );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto peak: peaks) {
        if (visited.contains(peak)) {
            continue;
        }
        visited << peak;
        auto neighbors = peaksNear(peak, peaks, maxDistance);
        if (neighbors.size() < minPoints) {
            noise << peak;
        } else {
            PeakCluster* fit = nullptr;
            for (auto &cluster: clusters) {
                for (auto placemark: cluster) {
                    if (distanceSphere(peak->coordinate(), placemark->coordinate()) < maxDistance) {
                        fit = &cluster;
                    }
                }
            }
            if (!fit) {
                clusters << PeakCluster();
                fit = &clusters.last();
            }

            while (!neighbors.isEmpty()) {
                auto neighbor = neighbors.front();
                neighbors.pop_front();
                if (!visited.contains(neighbor)) {
                    visited << neighbor;
                    auto const moreNeighbors = peaksNear(neighbor, peaks, maxDistance);
                    if (moreNeighbors.size() >= minPoints) {
                        neighbors += moreNeighbors;
                    }
                }
                if (associations[neighbor] == nullptr) {
                    *fit << neighbor;
                    associations[neighbor] = fit;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& pluginName: settings.childGroups() ) {
             settings.beginGroup( pluginName );
             settings.remove(QString()); //remove all keys
             settings.endGroup();
         }
```

#### AUTO 


```{c}
auto playlist = geodata_cast<GeoDataPlaylist>(rootObject)
```

#### AUTO 


```{c}
auto const height = parser.attribute(kmlTag_height).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for( EclipsesItem *item: m_items ) {
        if( item->index() == index ) {
            return item;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const OsmLineString &a, const OsmLineString &b) { return a.second.id() < b.second.id(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: files ) {
                        if ( file.endsWith( QLatin1String( ".dgml" ) ) ) {
                            QFileInfo dgmlFile( file );
                            QDir baseDir = dgmlFile.dir();
                            baseDir.cdUp();
                            baseDir.cdUp();
                            int const index = baseDir.absolutePath().size();
                            QString const mapTheme = dgmlFile.absoluteFilePath().mid( index+1 );
                            m_marbleWidget->setMapThemeId( mapTheme );
                            return true;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto place: places) {
        auto const places = candidatesFor(place);
        bool hasMatch = false;
        bool isValid = false;
        QString const placeName = place->name();
        if (!places.isEmpty()) {
            auto match = places.first();
            if (match->name() == place->name()) {
                ++validated;
                isValid = true;
            } else {
                if (match->coordinate().sphericalDistanceTo(place->coordinate()) < maxDistance) {
                    if (levenshteinDistance(places.first()->name(), placeName) < 6) {
                        if (m_verbose) {
                            qDebug() << "Correcting" << placeName << "to" << match->name();
                        }
                        place->setName(match->name());
                        place->osmData().removeTag("name");
                        place->osmData().addTag("name", match->name());
                        hasMatch = true;
                    }
                }

                if (m_verbose && !hasMatch) {
                    qDebug() << "No match for " << placeName << ", candidates: ";
                    for (auto candidate: places) {
                        qDebug() << candidate->coordinate().sphericalDistanceTo(place->coordinate()) * EARTH_RADIUS << " m, "
                                 << "levenshtein distance " << levenshteinDistance(placeName, candidate->name()) << ":" << candidate->name();
                    }
                }
            }
        } else if (m_verbose) {
            qDebug() << "No match for " << placeName << " at " << place->coordinate().toString(GeoDataCoordinates::Decimal) << " and no candidates for replacement";
        }
        hits += hasMatch ? 1 : 0;
        misses += (hasMatch || isValid) ? 0 : 1;
    }
```

#### AUTO 


```{c}
auto const roleNames = QAbstractItemModel::roleNames();
```

#### AUTO 


```{c}
auto const tile = tileFor(zoomLevel, tileX, tileY);
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoSceneVectorTileDataset *layer: textures) {
        d->m_tileModels << new VectorTileModel(&d->m_loader, layer, d->m_treeModel, &d->m_threadPool);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( TrackerPluginItem *obj: items() ) {
        SatellitesMSCItem *oItem = dynamic_cast<SatellitesMSCItem*>(obj);
        if( oItem != nullptr ) {
            bool enabled = ( ( oItem->relatedBody().toLower() == m_lcPlanet ) &&
                             ( m_enabledIds.contains( oItem->id() ) ) );
            oItem->setEnabled( enabled );

            if( enabled ) {
                oItem->update();
            }
        }

        SatellitesTLEItem *eItem = dynamic_cast<SatellitesTLEItem*>(obj);
        if( eItem != nullptr ) {
            // TLE satellites are always earth satellites
            bool enabled = (m_lcPlanet == QLatin1String("earth"));
            eItem->setEnabled( enabled );

            if( enabled ) {
                eItem->update();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &member : d->m_features) {
        if (member->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            result << static_cast<const GeoDataPlacemark*>(member)->osmData().oid();
        } else if (member->nodeType() == GeoDataTypes::GeoDataRelationType) {
            result << static_cast<const GeoDataRelation*>(member)->osmData().oid();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSharedPointer<LinkedPoint>& A, QSharedPointer<LinkedPoint>& B) {
                return A->point().y() < B->point().y();
            }
```

#### AUTO 


```{c}
auto polygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0));
```

#### AUTO 


```{c}
const auto building = geodata_cast<GeoDataBuilding>(geometry)
```

#### AUTO 


```{c}
auto tile = TileDirectory::open(file, manager);
```

#### AUTO 


```{c}
const auto placemark
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataFolder *folder: folders ) {
            QMenu *subMenu = bookmarksListMenu->addMenu(QIcon(QStringLiteral(":/icons/folder-bookmark.png")), folder->name());
            createFolderList( subMenu, folder );
            connect( subMenu, SIGNAL(triggered(QAction*)),
                                      this, SLOT(lookAtBookmark(QAction*)) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFloatItem *item: d->m_map.floatItems()) {
            if (item->nameId() == QLatin1String("license")) {
                item->setPosition(QPointF(5.0, -10.0));
            } else {
                item->hide();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF & clippedPolyObject: clippedPolyObjects ) { 
            if ( clippedPolyObject.size() > 1 ) {
                if (d->m_debugPolygonsLevel) {
                    QPen pen = QPainter::pen();
                    QPen originalPen = pen;
                    QColor color = pen.color();
                    color.setAlpha(color.alpha()*0.75);
                    pen.setColor(color);
                    QPainter::setPen(pen);

                    QPainter::drawPolyline ( clippedPolyObject );

                    QPainter::setPen(originalPen);

                    d->debugDrawNodes( clippedPolyObject );
                }
                else {
                    QPainter::drawPolyline ( clippedPolyObject );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* innerPolygonPerBoundary: innerPolygonsPerBoundary ) {
            innerPolygons << innerPolygonPerBoundary;
        }
```

#### AUTO 


```{c}
auto const values = line.split('\t');
```

#### RANGE FOR STATEMENT 


```{c}
for( const ParseRunnerPlugin *plugin: plugins ) {
        QStringList const extensions = plugin->fileExtensions();
        if ( extensions.contains( suffix ) || extensions.contains( completeSuffix ) ) {
            ParsingRunner* runner = plugin->newRunner();
            QString error;
            GeoDataDocument* document = runner->parseFile(fileName, UserDocument, error);
            if (!document && !error.isEmpty()) {
                mDebug() << QString("Failed to open vector tile %1: %2").arg(fileName).arg(error);
            }
            delete runner;
            return document;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRectF& rect: d->boundingRects()) {
        if( rect.contains( point ) )
            return true;
    }
```

#### AUTO 


```{c}
auto const routes = references.join(", ");
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter) {
        ++count;
        QString const outputDir = QString("%1/%2").arg(m_baseDir).arg(tileId.x());
        QString const outputFile = QString("%1/%2.o5m").arg(outputDir).arg(tileId.y());
        if (QFileInfo(outputFile).exists()) {
            continue;
        }

        printProgress(count / double(iter.total()));
        cout << " Creating landmass cache tile " << count << "/" << iter.total() << " (";
        cout << m_zoomLevel << "/" << tileId.x() << "/" << tileId.y() << ')' << string(20, ' ') << '\r';
        cout.flush();

        QDir().mkpath(outputDir);
        if (!clipper) {
            map = open(m_inputFile, m_manager);
            if (!map) {
                qCritical() << "Failed to open " << m_inputFile << ". This can happen when Marble was compiled without shapelib (libshp), when the system has too little memory (RAM + swap need to be at least 8G), or when the download of the landmass data file failed.";
            }
            clipper = QSharedPointer<VectorClipper>(new VectorClipper(map.data(), m_zoomLevel));
        }
        std::unique_ptr<GeoDataDocument> tile(clipper->clipTo(m_zoomLevel, tileId.x(), tileId.y()));
        if (!GeoDataDocumentWriter::write(outputFile, *tile)) {
            qWarning() << "Failed to write tile" << outputFile;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin* renderPlugin: renderPlugins ) {
            Q_ASSERT( renderPlugin );
            if (renderPlugin->nameId() == QLatin1String("positionMarker")) {
                renderPlugin->setEnabled( true );
                renderPlugin->setVisible( visible );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractWeatherService* service: m_services ) {
        service->getItem( id );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon: m_cachedOuterRoofPolygons) {
        if (polygon->containsPoint(point, Qt::OddEvenFill)) {
            for (auto polygon: m_cachedInnerRoofPolygons) {
                if (polygon->containsPoint(point, Qt::OddEvenFill)) {
                    return false;
                }
            }
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto multiGeometry = geodata_cast<GeoDataMultiGeometry>(d->m_geometry)
```

#### AUTO 


```{c}
auto tagIter = osmData.findTag(QStringLiteral("building"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & reference: osmData.nodeReferences()) {
            removeAnnotationTags(reference);
        }
```

#### AUTO 


```{c}
auto n = recvfrom(m_commandSocketFd, data.data(), 0xffff, MSG_DONTWAIT, reinterpret_cast<sockaddr*>(&req.addr), &req.addrSize);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto placemark : folder->placemarkList()) {
                importPlacemark(outline, segments, placemark);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto additionalOsmTag: additionalOsmTags) {
        if (filter.contains(additionalOsmTag.first)) {
            recommendedTags += additionalOsmTag;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( SatellitesConfigAbstractItem *item: m_children ) {         
            switch ( item->data( column, Qt::CheckStateRole ).toInt() ) {
            case Qt::Checked:
                oneChecked = true;
                if ( oneUnchecked ) {
                    return Qt::PartiallyChecked;
                }
                break;
            case Qt::PartiallyChecked:
                return Qt::PartiallyChecked;
            case Qt::Unchecked:
                oneUnchecked = true;
                if ( oneChecked ) {
                    return Qt::PartiallyChecked;
                }
            }
        }
```

#### AUTO 


```{c}
auto map = open(inputFileName, manager);
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(addContainer->child(i))
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: selectedPlacemarks ) {
        for (auto tileIter = d->m_features.find(placemark); tileIter != d->m_features.end() && tileIter.key() == placemark; ++tileIter) {
            auto const & clickedItems = d->m_tiledItems[*tileIter];
            auto iter = clickedItems.find(placemark);
            if (iter != clickedItems.end()) {
                GeoDataObject *parent = placemark->parent();
                if ( parent ) {
                    auto item = *iter;
                    if ( parent->nodeType() == GeoDataTypes::GeoDataDocumentType ) {
                        GeoDataDocument *doc = static_cast<GeoDataDocument*>( parent );
                        QString styleUrl = placemark->styleUrl();
                        styleUrl.remove(QLatin1Char('#'));
                        if ( !styleUrl.isEmpty() ) {
                            GeoDataStyleMap const &styleMap = doc->styleMap( styleUrl );
                            GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                            if ( style ) {
                                d->selectItem( item );
                                d->applyHighlightStyle( item, style );
                            }
                        }

                        /**
                            * If a placemark is using an inline style instead of a shared
                            * style ( e.g in case when theme file specifies the colorMap
                            * attribute ) then highlight it if any of the style maps have a
                            * highlight styleId
                            */
                        else {
                            for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto & items = m_osmLineStringItems[placemark->osmData().oid()];
```

#### RANGE FOR STATEMENT 


```{c}
for(auto id: usedNodes) {
        if (nodes[id].osmData().isEmpty()) {
            nodes.remove(id);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* innerPolygon:  m_cachedInnerPolygons ) {
                painter->drawPolyline( *innerPolygon );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str: PlanetFactory::planetList()) {
            if ( world.contains(str, Qt::CaseInsensitive) ) {
                m_planet = PlanetFactory::construct( str );
                break;
            }
        }
```

#### AUTO 


```{c}
auto const &member
```

#### RANGE FOR STATEMENT 


```{c}
for (auto candidate: places) {
                        qDebug() << distanceSphere(candidate->coordinate(), place->coordinate()) * EARTH_RADIUS << " m, "
                                 << "levenshtein distance " << levenshteinDistance(placeName, candidate->name()) << ":" << candidate->name();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& file: files ) {
                    if( progressDialog.wasCanceled() ) {
                        return;
                    }

                    const QString sourceFilePath = sourceDirPath + QLatin1Char('/') + file;

                    if( !sourceFilePath.startsWith( sourcePath ) ) {
                        continue;
                    }

                    QString targetFilePath = sourceFilePath;
                    targetFilePath.remove( 0, sourcePathLength );
                    targetFilePath.prepend( target );

                    QFile::copy( sourceFilePath, targetFilePath );
                    QFile::remove( sourceFilePath );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneProperty *property: currentMapTheme->settings()->allProperties() ) {
            if ( property->available() ) {
                d->m_checkBoxMap[ property->name() ] = property->value();
            }
        }
```

#### AUTO 


```{c}
auto flyTo = geodata_cast<GeoDataFlyTo>(object);
```

#### AUTO 


```{c}
const auto container = dynamic_cast<const GeoDataContainer *>(parent)
```

#### AUTO 


```{c}
const auto document = (placemark.parent() ? geodata_cast<GeoDataDocument>(placemark.parent()) : nullptr)
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLinearRing & box: m_tiles ) {
        if ( box.contains( flatPosition ) ) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto polygon
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for( const RouteItem &item: routeList ) {
            d->m_routeList.append( item );
        }
```

#### AUTO 


```{c}
const auto marbleDataPath = settings.value("marbleDataPath", "").toString();
```

#### AUTO 


```{c}
auto const items = d->m_scene.items(box, maxZoomLevel);
```

#### AUTO 


```{c}
auto const finalSize = imageSize.scaled(size, m_aspectRatioMode);
```

#### AUTO 


```{c}
const auto midIdx = data.indexOf('=', nextIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for( Marble::GeoDataPlacemark * placemark: folder->placemarkList() ) {
            if ( distanceSphere( placemark->coordinate(), compareTo ) * planetRadius < 5 ) {
                manager->removeBookmark( placemark );
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* innerRoof: m_cachedInnerRoofPolygons ) {
                painter->drawPolyline( *innerRoof );
            }
```

#### AUTO 


```{c}
auto d = substring.d_func();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon: m_cachedPolygons) {
        if (polygon->containsPoint(screenPosition, Qt::OddEvenFill)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto feature
```

#### AUTO 


```{c}
const auto document = (placemark.parent() ? geodata_cast<GeoDataDocument>(placemark.parent()) : 0)
```

#### AUTO 


```{c}
auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry());
```

#### AUTO 


```{c}
auto const startId = osmData.nodeReference(lineString.first()).id();
```

#### AUTO 


```{c}
const auto tag = StyleBuilder::OsmTag(key, value);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneVectorTileDataset *const vectorTile = dynamic_cast<GeoSceneVectorTileDataset const *>( pos );
                    if ( !vectorTile )
                        continue;

                    const QString sourceDir = vectorTile->sourceDir();
                    const QString installMap = vectorTile->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *vectorTile )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( vectorTile->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, nullptr );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                            qDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qDebug() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                        vectorTiles.append( vectorTile );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        vectorTileLayersOk = false;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon : m_screenPolygons) {
                QVariantList m_polyline;
                QPolygonF screenPolygon = *polygon;
                for (auto node : screenPolygon) {
                    QVariantMap vmap;
                    vmap["x"] = node.x();
                    vmap["y"] = node.y();
                    m_polyline.append(vmap);
                }
                m_screenCoordinates.insert(i, m_polyline);
                ++i;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoSceneLayer* layer: m_model->mapTheme()->map()->layers() ){
            if ( layer->backend() == dgml::dgmlValue_texture ){

                for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneTextureTileDataset *const texture = dynamic_cast<GeoSceneTextureTileDataset const *>( pos );
                    if ( !texture )
                        continue;

                    const QString sourceDir = texture->sourceDir();
                    const QString installMap = texture->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *texture )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( texture->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, 0 );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *texture ) ) {
                            mDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qWarning() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *texture ) ) {
                        textures.append( texture );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        textureLayersOk = false;
                    }
                }
            }
            else if ( layer->backend() == dgml::dgmlValue_vectortile ){

                for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneVectorTileDataset *const vectorTile = dynamic_cast<GeoSceneVectorTileDataset const *>( pos );
                    if ( !vectorTile )
                        continue;

                    const QString sourceDir = vectorTile->sourceDir();
                    const QString installMap = vectorTile->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *vectorTile )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( vectorTile->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, 0 );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                            qDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qDebug() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                        vectorTiles.append( vectorTile );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        vectorTileLayersOk = false;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: relations) {
        if (relation.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x12); // relation start indicator
        OsmPlacemarkData const & osmData = relation.second;

        bufferData.clear();
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        lastId = osmData.id();
        writeVersion(osmData, bufferStream);

        referencesBufferData.clear();
        referencesBuffer.open(QIODevice::WriteOnly);
        QDataStream referencesStream(&referencesBuffer);
        if (const auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)) {
            if (const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry())) {
                auto polygon = geodata_cast<GeoDataPolygon>(& static_cast<const GeoDataMultiGeometry*>(building->multiGeometry())->at(0));
                Q_ASSERT(polygon);
                writeMultipolygonMembers(*polygon, lastReferenceId, osmData, stringTable, referencesStream);
            } else {
                auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry());
                Q_ASSERT(polygon);
                writeMultipolygonMembers(*polygon, lastReferenceId, osmData, stringTable, referencesStream);
            }
        } else if (const auto placemark = geodata_cast<GeoDataRelation>(relation.first)) {
            writeRelationMembers(placemark, lastReferenceId, osmData, stringTable, referencesStream);
        } else {
            Q_ASSERT(false);
        }
        referencesBuffer.close();
        writeUnsigned(referencesBufferData.size(), bufferStream);
        bufferStream.writeRawData(referencesBufferData.constData(), referencesBufferData.size());

        writeTags(osmData, stringTable, bufferStream);

        buffer.close();
        writeUnsigned(bufferData.size(), stream);
        stream.writeRawData(bufferData.constData(), bufferData.size());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &include: includes) {
        QFile includeFile(QLatin1String(":/htmlfeatures/includes/") + include + QLatin1String(".inc"));
        if (includeFile.open(QIODevice::ReadOnly)) {
            input.replace(QLatin1String("%!{") + include + QLatin1String("}%"), includeFile.readAll());
        } else {
            mDebug() << "[WARNING] Can't process template include" << include;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto *layer: layers ) {
            timer.start();
            layer->render( painter, viewport, renderPosition, 0 );
            d->m_renderState.addChild( layer->renderState() );
            traceList.append( QString("%2 ms %3").arg( timer.elapsed(),3 ).arg( layer->runtimeTrace() ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractWeatherService *service: m_services ) {
        service->getAdditionalItems( box, number );
    }
```

#### AUTO 


```{c}
const auto relation = geodata_cast<GeoDataRelation>(feature)
```

#### AUTO 


```{c}
auto iter = m_osmData.nodeReferencesBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneTextureTileDataset *const texture = dynamic_cast<GeoSceneTextureTileDataset const *>( pos );
                    if ( !texture )
                        continue;

                    const QString sourceDir = texture->sourceDir();
                    const QString installMap = texture->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *texture )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( texture->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, 0 );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *texture ) ) {
                            mDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qWarning() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *texture ) ) {
                        textures.append( texture );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        textureLayersOk = false;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const MovieFormat &format: m_supportedFormats ) {
            QString type = format.type();
            QStringList args;
            args << "-h" << QLatin1String("muxer=") + type;
            encoder.start( d->encoderExec, args );
            encoder.waitForFinished();
            QString output = encoder.readAll();
            bool isFormatAvailable = !output.contains(QLatin1String("Unknown format"));
            if( isFormatAvailable ) {
                availableFormats << format;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingRunnerPlugin* plugin: d->m_pluginManager->routingRunnerPlugins() ) {
        if ( plugin->supportsTemplate( tpl ) ) {
            profile.pluginSettings()[plugin->nameId()] = plugin->templateSettings( tpl );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmRegionTree & child: m_children ) {
        if ( child.node().geometry().contains( coordinates ) ) {
            int childLevel = level;
            int id = child.smallestRegionId( coordinates, childLevel );
            if ( childLevel >= maxLevel ) {
                maxLevel = childLevel;
                minId = id;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag: buildingTags()) {
        s_visualCategories[tag]                                 = GeoDataPlacemark::Building;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *layer: textureLayers ) {
        const TileId tileId( layer->sourceDir(), stackedTileId.zoomLevel(),
                             stackedTileId.x(), stackedTileId.y() );

        mDebug() << Q_FUNC_INFO << layer->sourceDir() << tileId << layer->tileSize() << layer->fileFormat();

        // Blending (how to merge the images into an only image)
        const Blending *blending = d->m_blendingFactory.findBlending( layer->blending() );
        if ( blending == nullptr && !layer->blending().isEmpty() ) {
            mDebug() << Q_FUNC_INFO << "could not find blending" << layer->blending();
        }

        const GeoSceneTextureTileDataset *const textureLayer = static_cast<const GeoSceneTextureTileDataset *>( layer );
        const QImage tileImage = d->m_tileLoader->loadTileImage( textureLayer, tileId, DownloadBrowse );

        QSharedPointer<TextureTile> tile( new TextureTile( tileId, tileImage, blending ) );
        tiles.append( tile );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* placemark: container->placemarkList() ) {
        if (EARTH_RADIUS * placemark->coordinate().sphericalDistanceTo(bookmark.coordinate()) <= 1) {
            return placemark;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &planet: planets ) {
        m_settings.insert(QLatin1String("path_") + planet, m_svgPaths[planet]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *candidate: m_textures ) {
        bool enabled = true;
        if ( m_textureLayerSettings ) {
            const bool propertyExists = m_textureLayerSettings->propertyValue( candidate->name(), enabled );
            enabled |= !propertyExists; // if property doesn't exist, enable texture nevertheless
        }
        if ( enabled ) {
            result.append( candidate );
            mDebug() << "enabling texture" << candidate->name();
        } else {
            mDebug() << "disabling texture" << candidate->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &databaseFile: m_databaseFiles ) {
        database.setDatabaseName( databaseFile );
        if ( !database.open() ) {
            qWarning() << "Failed to connect to database" << databaseFile;
        }

        QString regionRestriction;
        if ( !userQuery.region().isEmpty() ) {
            QTime regionTimer;
            regionTimer.start();
            // Nested set model to support region hierarchies, see http://en.wikipedia.org/wiki/Nested_set_model
            const QString regionsQueryString = QLatin1String("SELECT lft, rgt FROM regions WHERE name LIKE '%") + userQuery.region() + QLatin1String("%';");
            QSqlQuery regionsQuery( regionsQueryString, database );
            if ( regionsQuery.lastError().isValid() ) {
                qWarning() << regionsQuery.lastError() << "in" << databaseFile << "with query" << regionsQuery.lastQuery();
            }
            regionRestriction = " AND (";
            int regionCount = 0;
            while ( regionsQuery.next() ) {
                if ( regionCount > 0 ) {
                    regionRestriction += QLatin1String(" OR ");
                }
                regionRestriction += QLatin1String(" (regions.lft >= ") + regionsQuery.value( 0 ).toString() +
                                     QLatin1String(" AND regions.lft <= ") + regionsQuery.value( 1 ).toString() + QLatin1Char(')');
                regionCount++;
            }
            regionRestriction += QLatin1Char(')');

            mDebug() << Q_FUNC_INFO << "region query in" << databaseFile << "with query" << regionsQueryString
                     << "took" << regionTimer.elapsed() << "ms for" << regionCount << "results";

            if ( regionCount == 0 ) {
                continue;
            }
        }

        QString queryString;

        queryString = " SELECT regions.name,"
                " places.name, places.number,"
                " places.category, places.lon, places.lat"
                " FROM regions, places";

        if ( userQuery.queryType() == DatabaseQuery::CategorySearch ) {
            queryString += QLatin1String(" WHERE regions.id = places.region");
            if( userQuery.category() == OsmPlacemark::UnknownCategory ) {
                // search for all pois which are not street nor address
                queryString += QLatin1String(" AND places.category <> 0 AND places.category <> 6");
            } else {
                // search for specific category
                queryString += QLatin1String(" AND places.category = %1");
                queryString = queryString.arg( (qint32) userQuery.category() );
            }
            if ( userQuery.position().isValid() && userQuery.region().isEmpty() ) {
                // sort by distance
                queryString += QLatin1String(" ORDER BY ((places.lat-%1)*(places.lat-%1)+(places.lon-%2)*(places.lon-%2))");
                GeoDataCoordinates position = userQuery.position();
                queryString = queryString.arg( position.latitude( GeoDataCoordinates::Degree ), 0, 'f', 8 )
                        .arg( position.longitude( GeoDataCoordinates::Degree ), 0, 'f', 8 );
            } else {
                queryString += regionRestriction;
            }
        } else if ( userQuery.queryType() == DatabaseQuery::BroadSearch ) {
            queryString += QLatin1String(" WHERE regions.id = places.region"
                    " AND places.name ") + wildcardQuery(userQuery.searchTerm());
        } else {
            queryString += QLatin1String(" WHERE regions.id = places.region"
                    "   AND places.name ") + wildcardQuery(userQuery.street());
            if ( !userQuery.houseNumber().isEmpty() ) {
                queryString += QLatin1String(" AND places.number ") + wildcardQuery(userQuery.houseNumber());
            } else {
                queryString += QLatin1String(" AND places.number IS NULL");
            }
            queryString += regionRestriction;
        }

        queryString += QLatin1String(" LIMIT 50;");

        /** @todo: sort/filter results from several databases */

        QSqlQuery query( database );
        query.setForwardOnly( true );
        QTime queryTimer;
        queryTimer.start();
        if ( !query.exec( queryString ) ) {
            qWarning() << query.lastError() << "in" << databaseFile << "with query" << query.lastQuery();
            continue;
        }

        int resultCount = 0;
        while ( query.next() ) {
            OsmPlacemark placemark;
            if ( userQuery.resultFormat() == DatabaseQuery::DistanceFormat ) {
                GeoDataCoordinates coordinates( query.value(4).toFloat(), query.value(5).toFloat(), 0.0, GeoDataCoordinates::Degree );
                placemark.setAdditionalInformation( formatDistance( coordinates, userQuery.position() ) );
            } else {
                placemark.setAdditionalInformation( query.value( 0 ).toString() );
            }
            placemark.setName( query.value(1).toString() );
            placemark.setHouseNumber( query.value(2).toString() );
            placemark.setCategory( (OsmPlacemark::OsmCategory) query.value(3).toInt() );
            placemark.setLongitude( query.value(4).toFloat() );
            placemark.setLatitude( query.value(5).toFloat() );

            result.push_back( placemark );
            resultCount++;
        }

        mDebug() << Q_FUNC_INFO << "query in" << databaseFile << "with query" << queryString
                 << "took" << queryTimer.elapsed() << "ms for" << resultCount << "results";
    }
```

#### AUTO 


```{c}
auto const buildingTag = QStringLiteral("building");
```

#### AUTO 


```{c}
const auto container = dynamic_cast<const GeoDataContainer*>(feature)
```

#### RANGE FOR STATEMENT 


```{c}
for (VectorTileModel *mapper: d->m_activeTileModels) {
        mapper->setViewport(viewport->viewLatLonAltBox());
        level = qMax(level, mapper->tileZoomLevel());
    }
```

#### AUTO 


```{c}
auto const &list
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin *plugin: m_controlView->marbleWidget()->renderPlugins() ) {
        KConfigGroup group = sharedConfig->group( QString( "plugin_" ) + plugin->nameId() );

        const QHash<QString,QVariant> hash = plugin->settings();

        QHash<QString,QVariant>::const_iterator it = hash.begin();
        while( it != hash.end() ) {
            group.writeEntry( it.key(), it.value() );
            ++it;
        }
        group.sync();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( int j: candidates ) {
                GeoDataLinearRing const & outer = m_osmOsmRegions[j].region.geometry().outerBoundary();
                if ( contains<GeoDataLinearRing, GeoDataLinearRing>( outer, ring ) ) {
                    if ( parent == 0 || contains<GeoDataLinearRing, GeoDataLinearRing>( parent->region.geometry().outerBoundary(), outer ) ) {
                        qDebug() << "Parent found: " << m_osmOsmRegions[i].region.name() << ", level " << m_osmOsmRegions[i].region.adminLevel()
                                   << "is a child of " << m_osmOsmRegions[j].region.name() << ", level " << m_osmOsmRegions[j].region.adminLevel();
                        parent = &m_osmOsmRegions[j];
                        break;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& key: group.keyList() ) {
            hash.insert( key, group.readEntry( key ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin *plugin: renderPlugins() ) {
        settings.beginGroup(QLatin1String("plugin_") + plugin->nameId());

        QHash<QString,QVariant> hash;

        for ( const QString& key: settings.childKeys() ) {
            hash.insert( key, settings.value( key ) );
        }

        plugin->setSettings( hash );

        settings.endGroup();
    }
```

#### AUTO 


```{c}
auto feature = item->feature();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &point: path) {
            GeoDataCoordinates const coordinates = point.coordinates();
            outerRing << coordinates;
            auto const originalOsmData = outerRingOsmData.nodeReference(coordinates);
            if (originalOsmData.id() > 0) {
                newOuterRingOsmData.addNodeReference(coordinates, originalOsmData);
            }
            ++nodeIndex;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tileId: tileLevels[m_zoomLevel]) {
        auto const outputFile = osmFileFor(tileId);
        if (!QFileInfo(outputFile).exists()) {
            hasAllTiles = false;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: items) {
            item->resetStyle();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataSimpleData& data: schemaData->simpleDataList() ) {
        writeElement( &data, writer );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &node: nodes) {
        auto placemark = node.create();
        if (placemark) {
            document->append(placemark);
            placemarks[placemark->osmData().oid()] = placemark;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DownloadPolicy *policy: texture->downloadPolicies() )
    {
        writer.writeStartElement( dgml::dgmlTag_DownloadPolicy );
        
        if( policy->key().usage() == DownloadBrowse )
        {
            writer.writeAttribute( "usage", "Browse" );
            writer.writeAttribute( "maximumConnections", QString::number( policy->maximumConnections() ) );
        }
        
        else if( policy->key().usage()  == DownloadBulk )
        {
            writer.writeAttribute( "usage", "Bulk" );
            writer.writeAttribute( "maximumConnections", QString::number( policy->maximumConnections() ) );
        }
        
        writer.writeEndElement();    
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &layer: d->m_styleBuilder->renderOrder()) {
        auto & layerItems = d->m_cachedPaintFragments[layer];
        AbstractGeoPolygonGraphicsItem::s_previousStyle = 0;
        GeoLineStringGraphicsItem::s_previousStyle = 0;
        for (auto item: layerItems) {
            item->paint(painter, viewport, layer, d->m_tileLevel);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemB: m_diffB ) {
                if( EARTH_RADIUS * distanceSphere( itemA.m_placemarkA.coordinate(), itemB.m_placemarkA.coordinate() ) <= 1 ) {
                    if( itemB.m_action == DiffItem::Deleted ) {
                        deleted = true;
                    } else if( itemB.m_action == DiffItem::Changed ) {
                        changed = true;
                        other = itemB;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* newPlacemark: newFolder->placemarkList() ) {
            bool added = skipAll;

            GeoDataCoordinates newCoordinate = newPlacemark->coordinate();
            GeoDataPlacemark *existingPlacemark = m_manager->bookmarkAt( m_manager->document(), newCoordinate );
            if ( existingPlacemark ) {
                if ( skipAll ) {
                    continue;
                }

                // Avoid message boxes for equal bookmarks, just skip them
                if ( existingPlacemark->name() == newPlacemark->name() &&
                    existingPlacemark->description() == newPlacemark->description() ) {
                    continue;
                }

                QPointer<QMessageBox> messageBox = new QMessageBox( m_parent );
                QString const intro = tr( "The file contains a bookmark that already exists among your Bookmarks." );
                QString const newBookmark = tr( "Imported bookmark" );
                QString const existingBookmark = tr( "Existing bookmark" );
                QString const question = tr( "Do you want to replace the existing bookmark with the imported one?" );
                QString html = QLatin1String("<p>%1</p><table><tr><td>%2</td><td><b>%3 / %4</b></td></tr>"
                                                "<tr><td>%5</td><td><b>%6 / %7</b></td></tr></table><p>%8</p>");
                html = html.arg( intro ).arg( existingBookmark ).arg( existingFolder->name() );
                html = html.arg( existingPlacemark->name() ).arg( newBookmark ).arg( newFolder->name() );
                html = html.arg( newPlacemark->name() ).arg( question );
                messageBox->setText( html );

                QAbstractButton *replaceButton    = messageBox->addButton(tr( "Replace" ),     QMessageBox::ActionRole );
                QAbstractButton *replaceAllButton = messageBox->addButton(tr( "Replace All" ), QMessageBox::ActionRole );
                QAbstractButton *skipButton       = messageBox->addButton(tr( "Skip" ),        QMessageBox::ActionRole );
                QAbstractButton *skipAllButton    = messageBox->addButton(tr( "Skip All" ),    QMessageBox::ActionRole );
                                                    messageBox->addButton( QMessageBox::Cancel );
                messageBox->setIcon( QMessageBox::Question );

                if ( !replaceAll ) {
                    messageBox->exec();
                }
                if ( messageBox->clickedButton() == replaceAllButton ) {
                    replaceAll = true;
                } else if ( messageBox->clickedButton() == skipAllButton ) {
                    skipAll = true;
                    added = true;
                } else if ( messageBox->clickedButton() == skipButton ) {
                    delete messageBox;
                    continue;
                } else if ( messageBox->clickedButton() != replaceButton ) {
                    delete messageBox;
                    return;
                }

                if ( messageBox->clickedButton() == replaceButton || replaceAll ) {
                    m_manager->removeBookmark( existingPlacemark );
                    m_manager->addBookmark( existingFolder, *newPlacemark );

                    mDebug() << "Placemark " << newPlacemark->name() << " replaces " << existingPlacemark->name();
                    delete messageBox;
                    break;
                }
                delete messageBox;
            }

            if ( !added ) {
                m_manager->addBookmark( existingFolder, *newPlacemark );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPolygonF *outline: m_cachedInnerPolygons) {
            if (outline->isEmpty()) {
                continue;
            }
            // draw the building sides
            int const size = outline->size();
            QPolygonF * innerRoof = new QPolygonF;
            innerRoof->reserve(outline->size());
            QPointF a = (*outline)[0];
            QPointF shiftA = a + buildingOffset(a, viewport);
            innerRoof->append(shiftA);
            for (int i=1; i<size; ++i) {
                QPointF const & b = (*outline)[i];
                QPointF const shiftB = b + buildingOffset(b, viewport);
                // perform backface culling
                bool backface = (b.x() - a.x()) * (shiftA.y() - a.y())
                        - (b.y() - a.y()) * (shiftA.x() - a.x()) >= 0;
                if (backface) {
                    QPolygonF buildingSide;
                    buildingSide.reserve(4);
                    buildingSide << a << shiftA << shiftB << b;
                    painter->drawPolygon(buildingSide);
                }
                a = b;
                shiftA = shiftB;
                innerRoof->append(shiftA);
            }
            m_cachedInnerRoofPolygons.append(innerRoof);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &placemark: m_wayPlacemarks) {
        document->append(placemark->clone());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const RouteItem &item: d->m_routeList ) {
            cachedRoutes.append( item.identifier() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoSceneLayer *layer: m_mapTheme->map()->layers() ) {
        if ( layer->backend() == dgml::dgmlValue_geodata 
             || layer->backend() == dgml::dgmlValue_vector )
        {
            for( GeoSceneAbstractDataset *dataset: layer->datasets() ) {
                GeoSceneGeodata *data = static_cast<GeoSceneGeodata*>( dataset );
                if ( data ) {
                    if ( data->sourceFile() == filePath ) {
                        GeoDataDocument *doc = m_fileManager.at( filePath );
                        Q_ASSERT( doc );

                        addHighlightStyle( doc );

                        QPen pen = data->pen();
                        QBrush brush = data->brush();
                        const QVector<QColor> colors = data->colors();
                        GeoDataLineStyle lineStyle( pen.color() );
                        lineStyle.setPenStyle( pen.style() );
                        lineStyle.setWidth( pen.width() );

                        if ( !colors.isEmpty() ) {
                            qreal alpha = data->alpha();
                            QVector<GeoDataFeature*>::iterator it = doc->begin();
                            QVector<GeoDataFeature*>::iterator const itEnd = doc->end();
                            for ( ; it != itEnd; ++it ) {
                                GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>( *it );
                                if ( placemark ) {
                                    GeoDataStyle::Ptr style(new GeoDataStyle);
                                    style->setId(QStringLiteral("normal"));
                                    style->setLineStyle( lineStyle );
                                    quint8 colorIndex = placemark->style()->polyStyle().colorIndex();
                                    GeoDataPolyStyle polyStyle;
                                    // Set the colorIndex so that it's not lost after setting new style.
                                    polyStyle.setColorIndex( colorIndex );
                                    QColor color;
                                    // color index having value 99 is undefined
                                    Q_ASSERT( colors.size() );
                                    if ( colorIndex > colors.size() || ( colorIndex - 1 ) < 0 )
                                    {
                                        color = colors[0];      // Assign the first color as default
                                    }
                                    else {
                                        color = colors[colorIndex-1];
                                    }
                                    color.setAlphaF( alpha );
                                    polyStyle.setColor( color );
                                    polyStyle.setFill( true );
                                    style->setPolyStyle( polyStyle );
                                    placemark->setStyle( style );
                                }
                            }
                        }
                        else {
                            GeoDataStyle::Ptr style(new GeoDataStyle);
                            GeoDataPolyStyle polyStyle( brush.color() );
                            polyStyle.setFill( true );
                            style->setLineStyle( lineStyle );
                            style->setPolyStyle( polyStyle );
                            style->setId(QStringLiteral("default"));
                            GeoDataStyleMap styleMap;
                            styleMap.setId(QStringLiteral("default-map"));
                            styleMap.insert(QStringLiteral("normal"), QLatin1Char('#') + style->id());
                            doc->addStyle( style );
                            doc->addStyleMap( styleMap );

                            const QString styleUrl = QLatin1Char('#') + styleMap.id();
                            QVector<GeoDataFeature*>::iterator iter = doc->begin();
                            QVector<GeoDataFeature*>::iterator const end = doc->end();

                            for ( ; iter != end; ++iter ) {
                                if (auto placemark = geodata_cast<GeoDataPlacemark>(*iter)) {
                                    if (!geodata_cast<GeoDataTrack>(placemark->geometry()) &&
                                        !geodata_cast<GeoDataPoint>(placemark->geometry()))
                                    {
                                        placemark->setStyleUrl(styleUrl);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto const &way
```

#### AUTO 


```{c}
auto category
```

#### AUTO 


```{c}
auto const tagMap = StyleBuilder::osmTagMapping();
```

#### AUTO 


```{c}
auto const ref = m_relations.at(index.row())->osmData().tagValue(QStringLiteral("ref"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & ring : m_polygon->innerBoundaries()) {
            if (viewport->resolves(ring.latLonAltBox(), 4)) {
               innerResolved = true;
               break;
            }
        }
```

#### AUTO 


```{c}
auto const colorValue = parameters.relation->osmData().tagValue(QStringLiteral("colour"));
```

#### AUTO 


```{c}
auto iter = d->m_relationTypeConverter.cbegin(), end = d->m_relationTypeConverter.cend();
```

#### AUTO 


```{c}
auto place
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: *lineString) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
```

#### AUTO 


```{c}
const auto &point
```

#### AUTO 


```{c}
const auto &layer
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF& position: d->positions()) {
            painter->save();

            painter->translate( position );
            paint( painter );

            // Paint children
            for (MarbleGraphicsItem *item: d->m_children) {
                item->paintEvent( painter, viewport );
            }

            painter->restore();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileInfo& fi: allFiles) {
        const QString absPath = destinationDir + QDir::separator() + fi.filePath;
        if (fi.isSymLink) {
            QString destination = QFile::decodeName(fileData(fi.filePath));
            if (destination.isEmpty())
                return false;
            QFileInfo linkFi(absPath);
            if (!QFile::exists(linkFi.absolutePath()))
                QDir::root().mkpath(linkFi.absolutePath());
            if (!QFile::link(destination, absPath))
                return false;
            /* cannot change permission of links
            if (!QFile::setPermissions(absPath, fi.permissions))
                return false;
            */
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataPlacemark *placemark: folder->placemarkList() ) {
                routeName += placemark->name() + QLatin1String(" - ");
            }
```

#### AUTO 


```{c}
const auto keyLen = midIdx - nextIdx;
```

#### AUTO 


```{c}
auto orange = QColor(255, 165, 0);
```

#### AUTO 


```{c}
const auto flyTo = geodata_cast<GeoDataFlyTo>(primitive)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &segment: segments) {
        if (segment.first >= segment.second) {
            ++wraps;
        }
        if (segment.first < 0 || segment.second < 0 || segment.first+1 > length || segment.second+1 > length) {
            qDebug() << "Wrong border points sequence for length " << length << ":" <<  borderPoints << ", intermediate " << segments;
            return;
        }
    }
```

#### AUTO 


```{c}
auto const screen = QApplication::screens().first();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto feature: features) {
            if (feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
                placemarks << static_cast<const GeoDataPlacemark*>(feature);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::GeoDataFolder* folder: bookmarks->folderList() ) {
        for( const Marble::GeoDataPlacemark * const placemark: folder->placemarkList() ) {
            if ( distanceSphere( placemark->coordinate(), compareTo ) * planetRadius < 5 ) {
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto &osmData = ways[wayId].osmData();
```

#### AUTO 


```{c}
auto pfolder = geodata_cast<GeoDataFolder>(feature->parent())
```

#### AUTO 


```{c}
auto *layer
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileInfo& fi: allFiles) {
        const QString absPath = destinationDir + QDir::separator() + fi.filePath;
        if (fi.isFile) {
            QDir::root().mkpath(QFileInfo(absPath).dir().absolutePath());
            QFile f(absPath);
            if (!f.open(QIODevice::WriteOnly))
                return false;
            f.write(fileData(fi.filePath));
            f.setPermissions(fi.permissions);
            f.close();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : lineStringItems) {
        item->setVisible(visible);
        if (visible) {
            item->setMergedLineString(merged);
            visible = merged.isEmpty();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* placemark: container->placemarkList() ) {
        placemark->setVisualCategory(GeoDataPlacemark::Bookmark);
        placemark->setZoomLevel( 1 );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &innerRing: polygon->innerBoundaries() ) {
                    ++index;
                    const OsmPlacemarkData innerRingOsmData = osmData.memberReference( index );
                    for (auto const &coordinates: innerRing) {
                        m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
                    }
                    m_ways << OsmConverter::Way(&innerRing, innerRingOsmData);
                }
```

#### AUTO 


```{c}
const auto feature = dynamic_cast<const GeoDataFeature *>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str: PlanetFactory::planetList()) {
                        if ( geoUriRegexp.captureCount() < i+1 ) {
                            i = geoUriRegexp.captureCount() + 1;
                            break;
                        }
                        if ( geoUriRegexp.capturedTexts()[i+1].contains(str, Qt::CaseInsensitive) ) {
                            m_planet = PlanetFactory::construct( str );
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QRectF &geoRect: geoRects ) {
        TileId key;
        QRect rect;

        key = TileId::fromCoordinates( GeoDataCoordinates(geoRect.left(), north, 0), zoomLevel);
        rect.setLeft( key.x() );
        rect.setTop( key.y() );

        key = TileId::fromCoordinates( GeoDataCoordinates(geoRect.right(), south, 0), zoomLevel);
        rect.setRight( key.x() );
        rect.setBottom( key.y() );

        TileCoordsPyramid pyramid(0, zoomLevel );
        pyramid.setBottomLevelCoords( rect );

        for ( int level = pyramid.topLevel(); level <= pyramid.bottomLevel(); ++level ) {
        QRect const coords = pyramid.coords( level );
        int x1, y1, x2, y2;
        coords.getCoords( &x1, &y1, &x2, &y2 );
            for ( int x = x1; x <= x2; ++x ) {
                for ( int y = y1; y <= y2; ++y ) {
                    TileId const tileId( 0, level, x, y );
                    tileIdSet.insert(tileId);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &layer: d->m_styleBuilder->renderOrder()) {
        auto & layerItems = d->m_cachedPaintFragments[layer];
        AbstractGeoPolygonGraphicsItem::s_previousStyle = 0;
        GeoLineStringGraphicsItem::s_previousStyle = 0;
        for (auto item: layerItems) {
            if (d->m_levelTagDebugModeEnabled) {
                if (const auto placemark = geodata_cast<GeoDataPlacemark>(item->feature())) {
                    if (placemark->hasOsmData()) {
                        QHash<QString, QString>::const_iterator tagIter = placemark->osmData().findTag(QStringLiteral("level"));
                        if (tagIter != placemark->osmData().tagsEnd()) {
                            const int val = tagIter.value().toInt();
                            if (val != d->m_debugLevelTag) {
                                continue;
                            }
                        }
                    }
                }
            }
            item->paint(painter, viewport, layer, d->m_tileLevel);
        }
    }
```

#### AUTO 


```{c}
const auto ring = geodata_cast<GeoDataLinearRing>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &value: values) {
        bool canParse(false);
        int const tileLevel = value.trimmed().toInt(&canParse);
        if (canParse && tileLevel >= 0 && tileLevel < 100) {
            m_tileLevels << tileLevel;
        } else {
            mDebug() << "Cannot parse tile level part " << value << " in " << tileLevels << ", ignoring it.";
        }
    }
```

#### AUTO 


```{c}
auto ring
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark *placemark: folder->placemarkList() ) {
        DiffItem diffItem;
        diffItem.m_path = path;
        diffItem.m_placemarkA = *placemark;
        switch ( diffDirection ) {
        case DiffItem::Source:
            diffItem.m_origin = DiffItem::Destination;
            break;
        case DiffItem::Destination:
            diffItem.m_origin = DiffItem::Source;
            break;
        default:
            break;
        }

        determineDiffStatus( diffItem, other );

        if( !( diffItem.m_action == DiffItem::NoAction && diffItem.m_origin == DiffItem::Destination )
                && !( diffItem.m_action == DiffItem::Changed && diffItem.m_origin == DiffItem::Source ) ) {
            diffItems.append( diffItem );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLineString & hole: inner ) {
            if ( contains<GeoDataLinearRing, GeoDataLineString>( polygon.outerBoundary(), hole ) ) {
                polygon.appendInnerBoundary(GeoDataLinearRing(hole));
            }
        }
```

#### AUTO 


```{c}
auto polygon = static_cast<const GeoDataPolygon*>(placemark->geometry());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &relation: relations) {
        relation.createMultipolygon(document, ways, nodes, usedNodes, usedWays);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto &text: traceList ) {
            painter->setPen( Qt::black );
            painter->drawText( QPoint(10,top+1+lineHeight*i), text );
            painter->setPen( Qt::white );
            painter->drawText( QPoint(9,top+lineHeight*i), text );
            ++i;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( SoundTrack* track: d->m_soundTracks ){
        track->seek( offset );
    }
```

#### AUTO 


```{c}
const auto lineString = geodata_cast<GeoDataLineString>(d->m_geometry)
```

#### RANGE FOR STATEMENT 


```{c}
for (VectorTileModel * candidate: m_activeTileModels) {
        Q_ASSERT( candidate );
        const GeoSceneVectorTileDataset * vectorTileDataset = candidate->layer();
        // check, if layer provides tiles for the current level
        if ( !vectorTileDataset->hasMaximumTileLevel() ||
             vectorTileDataset->maximumTileLevel() >= tileId.zoomLevel() ) {
            //check if the tile intersects with texture bounds
            if (vectorTileDataset->latLonBox().isNull()) {
                result.append(vectorTileDataset);
            }
            else {
                const GeoDataLatLonBox bbox = vectorTileDataset->tileProjection()->geoCoordinates(tileId);

                if (vectorTileDataset->latLonBox().intersects(bbox)) {
                    result.append( vectorTileDataset );
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto *plugin
```

#### AUTO 


```{c}
auto playlist = geodata_cast<GeoDataPlaylist>(parentObject)
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<LinkedPoint>& A, const QSharedPointer<LinkedPoint>& B) {
                return B->point().y() < A->point().y();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: relations) {
            if (relation->relationType() >= GeoDataRelation::RouteRoad && relation->relationType() <= GeoDataRelation::RouteSled) {
                m_relations << new GeoDataRelation(*relation);
            }
        }
```

#### AUTO 


```{c}
auto const tagMap = osmTagMapping();
```

#### AUTO 


```{c}
const auto linearRing = geodata_cast<GeoDataLinearRing>(placemark->geometry())
```

#### AUTO 


```{c}
auto map = open(parser.value("landmass"), manager);
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction *action: ag->actions() ) {
                   m_viewMenu->addAction( action );
                   m_pluginMenus.append( action );
               }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataFeature *child: container->featureList()) {
            removeGraphicsItems(child);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataStyle::ConstPtr &style: document->styles() ) {
        writeElement( style.data(), writer );
    }
```

#### AUTO 


```{c}
auto const versionOption = parser.addVersionOption();
```

#### AUTO 


```{c}
const auto building = geodata_cast<GeoDataBuilding>(object)
```

#### AUTO 


```{c}
auto & fragment = iter.value();
```

#### AUTO 


```{c}
auto zoomLevel
```

#### RANGE FOR STATEMENT 


```{c}
for( QActionGroup* ag: *tmp_toolbarActionGroups ) {
                toolbar->addActions( ag->actions() );
                if ( tmp_toolbarActionGroups->last() != ag ) {
                    toolbar->addSeparator();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataLinearRing &innerRing: polygon->innerBoundaries() ) {
                const OsmPlacemarkData &innerRingOsmData = osmData.memberReference( ++memberIndex );
                writer.writeStartElement( kml::kmlTag_nameSpaceMx, kml::kmlTag_member );
                writer.writeAttribute( "index", QString::number( memberIndex ) );
                writeOsmData( &innerRing, innerRingOsmData, writer );
                writer.writeEndElement();
            }
```

#### AUTO 


```{c}
auto const originalOsmData = outerRingOsmData.nodeReference(coordinates);
```

#### RANGE FOR STATEMENT 


```{c}
for (MarbleGraphicsItem *item: d->m_children) {
                item->paintEvent( &pixmapPainter, viewport );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( int id: nodes ) {
                if ( database.contains( id ) ) {
                    const Coordinate &node = database[id];
                    GeoDataCoordinates coordinates( node.lon, node.lat, 0.0, GeoDataCoordinates::Degree );
                    ring << coordinates;
                } else {
                    qDebug() << "Missing node " << id << " in database";
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction* action: (*itW)->actions() ) {
            d->m_lmbMenu.addAction( action );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & reference: osmData.memberReferences()) {
            removeAnnotationTags(reference);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataSchemaData &schemaData: extended->schemaDataList() ) {
        writeElement( &schemaData, writer );
    }
```

#### AUTO 


```{c}
const auto camera = geodata_cast<GeoDataCamera>(flyTo->view())
```

#### AUTO 


```{c}
const auto socketFd = getenv("TIREX_BACKEND_SOCKET_FILENO");
```

#### RANGE FOR STATEMENT 


```{c}
for( TrackerPluginItem *obj: m_satModel->items() ) {
        // catalog items
        SatellitesMSCItem *item = dynamic_cast<SatellitesMSCItem*>( obj );
        if( ( item != NULL ) && ( item->catalog() == source ) ) {
            m_configDialog->addSatelliteItem(
                item->relatedBody(),
                item->category(),
                item->name(),
                item->id() );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& renderPosition: renderPositions ) {
        QList<LayerInterface*> layers;

        // collect all RenderPlugins of current renderPosition
        for( auto *renderPlugin: d->m_renderPlugins ) {
            if ( renderPlugin && renderPlugin->renderPosition().contains( renderPosition ) ) {
                if ( renderPlugin->enabled() && renderPlugin->visible() ) {
                    if ( !renderPlugin->isInitialized() ) {
                        renderPlugin->initialize();
                        emit renderPluginInitialized( renderPlugin );
                    }
                    layers.push_back( renderPlugin );
                }
            }
        }

        // collect all internal LayerInterfaces of current renderPosition
        for( auto *layer: d->m_internalLayers ) {
            if ( layer && layer->renderPosition().contains( renderPosition ) ) {
                layers.push_back( layer );
            }
        }

        // sort them according to their zValue()s
        std::sort( layers.begin(), layers.end(), [] ( const LayerInterface * const one, const LayerInterface * const two ) -> bool {
            Q_ASSERT( one && two );
            return one->zValue() < two->zValue();
        } );

        // render the layers of the current renderPosition
        QTime timer;
        for( auto *layer: layers ) {
            timer.start();
            layer->render( painter, viewport, renderPosition, nullptr );
            d->m_renderState.addChild( layer->renderState() );
            traceList.append( QString("%2 ms %3").arg( timer.elapsed(),3 ).arg( layer->runtimeTrace() ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataGroundOverlay *overlay: m_groundOverlayFrames.keys() ) {
        GroundOverlayFrame *frame = static_cast<GroundOverlayFrame *>( m_groundOverlayFrames.value( overlay ) );
        m_graphicsItems.removeAll( m_groundOverlayFrames.value( overlay ) );
        m_marbleWidget->model()->treeModel()->removeFeature( frame->placemark() );
        delete frame->placemark();
        delete frame;
    }
```

#### AUTO 


```{c}
auto soundCue = geodata_cast<GeoDataSoundCue>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QFileInfo &info: dir.entryInfoList(
            QDir::NoDotAndDotDot | QDir::System | QDir::Hidden |
            QDir::AllDirs | QDir::Files,
            QDir::DirsFirst ) ) {

            if ( info.isDir() ) {
                result = deleteDirectory( info.absoluteFilePath() );
            } else {
                result = QFile::remove( info.absoluteFilePath() );
            }

            if ( !result ) {
                return result;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSharedPointer<LinkedPoint>& A, QSharedPointer<LinkedPoint>& B) {
                return B->point().y() < A->point().y();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto item : coordinates) {
            QVariantMap map = item.toMap();
            m_lineString << GeoDataCoordinates(
                                map["lon"].toReal(),
                                map["lat"].toReal(),
                                map["alt"].toReal(),
                                GeoDataCoordinates::Degree
                            );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const RequestRegion &region: m_alternativeRouteRegions ) {
         if ( region.region.contains( point ) ) {
             return true;
         }
     }
```

#### AUTO 


```{c}
auto lineString
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmRegionTree & child: m_children ) {
        child.enumerate( list );
    }
```

#### AUTO 


```{c}
auto styling = StyleParameters(placemark, d->m_renderContext.tileLevel());
```

#### AUTO 


```{c}
auto const color = m_relations.at(index.row())->osmData().tagValue(QStringLiteral("colour"));
```

#### AUTO 


```{c}
auto const & clickedItems = d->m_tiledItems[*tileIter];
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Way &a, const Way &b) { return a.second.id() < b.second.id(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const MonavStuffEntry &map: m_remoteMaps ) {
        Q_ASSERT( map.isValid() );
        if ( map.continent() == continent ) {
            states << map.state();
        }
    }
```

#### AUTO 


```{c}
auto tourControl = geodata_cast<GeoDataTourControl>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataFolder *folder: folders ) {
        for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            importPlacemark( outline, segments, placemark );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
        GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
        newPlacemark->setVisible(placemark->isVisible());
        newPlacemark->setVisualCategory(placemark->visualCategory());
        GeoDataLinearRing outerRing;
        OsmPlacemarkData const & placemarkOsmData = placemark->osmData();
        OsmPlacemarkData & newPlacemarkOsmData = newPlacemark->osmData();
        int index = -1;
        OsmPlacemarkData const & outerRingOsmData = placemarkOsmData.memberReference(index);
        OsmPlacemarkData & newOuterRingOsmData = newPlacemarkOsmData.memberReference(index);
        int nodeIndex = 0;
        for(const auto &point: path) {
            GeoDataCoordinates const coordinates = point.coordinates();
            outerRing << coordinates;
            auto const originalOsmData = outerRingOsmData.nodeReference(coordinates);
            if (originalOsmData.id() > 0) {
                newOuterRingOsmData.addNodeReference(coordinates, originalOsmData);
            }
            ++nodeIndex;
        }

        GeoDataPolygon* newPolygon = new GeoDataPolygon;
        newPolygon->setOuterBoundary(outerRing);
        if (isBuilding) {
            const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
            GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
            newBuilding->multiGeometry()->clear();
            newBuilding->multiGeometry()->append(newPolygon);
            newPlacemark->setGeometry(newBuilding);
        } else {
            newPlacemark->setGeometry(newPolygon);
        }
        if (placemarkOsmData.id() > 0) {
            newPlacemarkOsmData.addTag(QStringLiteral("mx:oid"), QString::number(placemarkOsmData.id()));
        }
        copyTags(placemarkOsmData, newPlacemarkOsmData);
        copyTags(outerRingOsmData, newOuterRingOsmData);
        if (outerRingOsmData.id() > 0) {
            newOuterRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(outerRingOsmData.id()));
        }

        auto const & innerBoundaries = polygon->innerBoundaries();
        for (index = 0; index < innerBoundaries.size(); ++index) {
            auto const & innerBoundary = innerBoundaries.at(index);
            if (minArea > 0.0 && area(innerBoundary) < minArea) {
                continue;
            }

            auto const & innerRingOsmData = placemarkOsmData.memberReference(index);
            clipper.Clear();
            clipper.AddPath(path, ptClip, true);
            Path innerPath;
            for(auto const & node: innerBoundary) {
                innerPath << IntPoint(&node);
            }
            clipper.AddPath(innerPath, ptSubject, true);
            Paths innerPaths;
            clipper.Execute(ctIntersection, innerPaths);
            for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                nodeIndex = 0;
                for(const auto &point: innerPath) {
                    GeoDataCoordinates const coordinates = point.coordinates();
                    innerRing << coordinates;
                    auto const originalOsmData = innerRingOsmData.nodeReference(coordinates);
                    if (originalOsmData.id() > 0) {
                        newInnerRingOsmData.addNodeReference(coordinates, originalOsmData);
                    }
                    ++nodeIndex;
                }
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
        }

        OsmObjectManager::initializeOsmData(newPlacemark);
        document->append(newPlacemark);
        osmIds << placemark->osmData().id();
    }
```

#### AUTO 


```{c}
const auto photoOverlay = geodata_cast<GeoDataPhotoOverlay>(overlay)
```

#### AUTO 


```{c}
auto const allRoutes = namesList.join(QStringLiteral("; "));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key: addressItemKeys) {
        const QString item = data.tagValue(QLatin1String("addr:") + key);
        if (!item.isEmpty()) {
            hasAddressItem = true;
        }
        addressItems << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *dataset: layer->datasets() ) {
            const GeoSceneGeodata *data = dynamic_cast<const GeoSceneGeodata*>( dataset );
            Q_ASSERT( data );
            skip = false;
            sourceFileMatch = false;
            for ( int i = 0; i < currentDatasets.size(); ++i ) {
                if ( currentDatasets[i] == *data ) {
                    currentDatasets.removeAt( i );
                    skip = true;
                    break;
                }
                /**
                 * If the sourcefile of data matches any in the currentDatasets then there
                 * is no need to parse the file again just update the style
                 * i.e. <brush> and <pen> values of already parsed file. assignNewStyle() does that
                 */
                if ( currentDatasets[i].sourceFile() == data->sourceFile() ) {
                    sourceFileMatch = true;
                    datasetIndex = i;
                }
            }
            if ( skip ) {
                continue;
            }

            QString filename = data->sourceFile();
            QString property = data->property();
            QPen pen = data->pen();
            QBrush brush = data->brush();
            GeoDataStyle::Ptr style;
            int renderOrder = data->renderOrder();

            /**
             * data->colors() are the colorMap values from dgml file. If this is not
             * empty then we are supposed to assign every placemark a different style
             * by giving it a color from colorMap values based on color index
             * of that placemark. See assignFillColors() for details. So, we need to
             * send an empty style to fileManeger otherwise the FileLoader::createFilterProperties()
             * will overwrite the parsed value of color index ( GeoDataPolyStyle::d->m_colorIndex ).
             */
            if ( data->colors().isEmpty() ) {
                GeoDataLineStyle lineStyle( pen.color() );
                lineStyle.setPenStyle( pen.style() );
                lineStyle.setWidth( pen.width() );
                GeoDataPolyStyle polyStyle( brush.color() );
                polyStyle.setFill( true );
                style = GeoDataStyle::Ptr(new GeoDataStyle);
                style->setLineStyle( lineStyle );
                style->setPolyStyle( polyStyle );
                style->setId(QStringLiteral("default"));
            }
            if ( sourceFileMatch && !currentDatasets[datasetIndex].colors().isEmpty() ) {
                /**
                 * if new theme file doesn't specify any colorMap for data
                 * then assignNewStyle otherwise assignFillColors.
                 */
                currentDatasets.removeAt( datasetIndex );
                if ( style ) {
                    qDebug() << "setMapThemeId-> color: " << style->polyStyle().color() << " file: " << filename;
                    d->assignNewStyle( filename, style );
                    style = GeoDataStyle::Ptr();
                }
                else {
                    d->assignFillColors( data->sourceFile() );
                }
            }
            else {
                fileList << filename;
                propertyList << property;
                styleList << style;
                renderOrderList << renderOrder;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingRunnerPlugin* plugin: m_pluginManager->routingRunnerPlugins() ) {
            if ( plugin->supportsTemplate( tpl ) ) {
                profile.pluginSettings()[plugin->nameId()] = plugin->templateSettings( tpl );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FileLoader *loader: d->m_loaderList ) {
        if ( loader->path() == key ) {
            disconnect( loader, 0, this, 0 );
            loader->wait();
            d->m_loaderList.removeAll( loader );
            delete loader->document();
            return;
        }
    }
```

#### AUTO 


```{c}
auto iter = lineString->begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& val : hash.values()) {
        if (m_debugModeEnabled) {
//            qDebug() << "Batches" << val.symbolId << val.count;
            QPixmap debugPixmap(val.pixmap.size());
            QColor backgroundColor;
            QString idStr = val.symbolId.section('/', -1);
            if (idStr.length() > 2) {
              idStr.remove("shop_");
              backgroundColor = QColor(
                          (10 * (int)(idStr[0].toLatin1()))%255,
                          (10 * (int)(idStr[1].toLatin1()))%255,
                          (10 * (int)(idStr[2].toLatin1()))%255 );
            }
            else {
              backgroundColor = QColor((quint64)(&val.symbolId));
            }
            debugPixmap.fill(backgroundColor);
            QPainter pixpainter;
            pixpainter.begin(&debugPixmap);
            pixpainter.drawPixmap(0, 0, val.pixmap);
            pixpainter.end();
            val.pixmap = debugPixmap;
        }
        painter->drawPixmapFragments(val.fragments.data(), val.count, val.pixmap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon: m_cachedPolygons) {
            painterPath.addPolygon(*polygon);
        }
```

#### AUTO 


```{c}
auto const width = qMax(fontmet.width(m_labelText), m_pixmap_open.width());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& point : m_leftEdge) {
                intersectionsLeft << QSharedPointer<LinkedPoint>(new LinkedPoint(point));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const WeatherData &forecast: d->m_forecastWeather ) {
        forecastNumber++;
        const QString suffix = QString::number(forecastNumber);
        QDate date = forecast.dataDate();
        html.replace(QLatin1String("%day_f") + suffix + QLatin1Char('%'),
                     locale.standaloneDayName(date.dayOfWeek()));
        html.replace(QLatin1String("%weather_situation_f") + suffix + QLatin1Char('%'),
                     QLatin1String("file://")+forecast.iconSource());
        html.replace(QLatin1String("%max_temp_f") + suffix + QLatin1Char('%'),
                      forecast.maxTemperatureString(WeatherData::Celsius));
        html.replace(QLatin1String("%min_temp_f") + suffix + QLatin1Char('%'),
                      forecast.minTemperatureString(WeatherData::Celsius));
        html.replace(QLatin1String("%condition_f") + suffix + QLatin1Char('%'), forecast.conditionString());
        html.replace(QLatin1String("%wind_direction_f") + suffix + QLatin1Char('%'), forecast.windDirectionString());
        html.replace(QLatin1String("%wind_speed_f") + suffix + QLatin1Char('%'), forecast.windSpeedString());
        html.replace(QLatin1String("%publish_time_f") + suffix + QLatin1Char('%'), forecast.publishingTime().toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dir: directories ) {
        QDir::root().rmdir( dir );
    }
```

#### AUTO 


```{c}
auto const levels = parser.value("zoom-level").split(',');
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: outdated) {
            delete m_visiblePlacemarks.take(placemark->placemark());
        }
```

#### AUTO 


```{c}
auto end = osmData.tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & style: d->m_styleHash.values()) {
        result << style;
    }
```

#### AUTO 


```{c}
auto category = Private::s_visualCategories.value(tag, GeoDataPlacemark::None);
```

#### AUTO 


```{c}
auto dataset
```

#### AUTO 


```{c}
auto route = routes[0].toObject();
```

#### AUTO 


```{c}
const auto folder = geodata_cast<GeoDataFolder>(object)
```

#### AUTO 


```{c}
const auto address = parser.readElementText().trimmed();
```

#### AUTO 


```{c}
auto const extendedBox = viewLatLonAltBox.scaled(2.0, 2.0);
```

#### RANGE FOR STATEMENT 


```{c}
for( const Way & way: ways ) {
            if ( other.compatible( way ) ) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto iter = tiles.begin(), end = tiles.end();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto wayId: roleMembers) {
        GeoDataLinearRing ring;
        OsmWay const & way = ways[wayId];
        if (way.references().isEmpty()) {
            continue;
        }
        if (way.references().first() != way.references().last()) {
            unclosedWays.append(way);
            continue;
        }

        OsmPlacemarkData placemarkData = way.osmData();
        for(auto id: way.references()) {
            if (!nodes.contains(id)) {
                // A node is missing. Return nothing.
                return OsmRings();
            }
            const auto &node = nodes[id];
            ring << node.coordinates();
            placemarkData.addNodeReference(node.coordinates(), node.osmData());
        }
        Q_ASSERT(ways.contains(wayId));
        currentWays << wayId;
        result << OsmRing(GeoDataLinearRing(ring.optimized()), placemarkData);
    }
```

#### AUTO 


```{c}
auto const width = parser.attribute(kmlTag_width).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (TrackerPluginItem *obj: m_satModel->items() ) {
                    if( obj->placemark() == placemark ) {
                        m_showOrbitAction->data() = m_trackerList.size();
                        m_showOrbitAction->setChecked( obj->isTrackVisible() );
                        widget->popupMenu()->addAction( Qt::LeftButton, m_showOrbitAction );

                        m_trackPlacemarkAction->data() = m_trackerList.size();
                        widget->popupMenu()->addAction( Qt::LeftButton, m_trackPlacemarkAction );

                        m_trackerList.append( obj );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems.negative) {
            if (item->contains(curpos, viewport)) {
                result << item->feature();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &fileName: fileNames ) {
        openUrl( QUrl::fromLocalFile(fileName) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmRegion &candidate: regions ) {
        if ( candidate.parentIdentifier() == m_node.identifier() ) {
            m_children << OsmRegionTree( candidate );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
            labelNodes.clear();
            ClipPainter::labelPosition( *itPolygon, labelNodes, labelPositionFlags );
            if (!labelNodes.isEmpty()) {
                for ( const QPointF& labelNode: labelNodes ) {
                    QPointF labelPosition = labelNode + QPointF( 3.0, -2.0 );

                    // FIXME: This is a Q&D fix.
                    qreal xmax = viewport().width() - 10.0 - labelWidth;
                    if ( labelPosition.x() > xmax ) labelPosition.setX( xmax );
                    qreal ymin = 10.0 + labelAscent;
                    if ( labelPosition.y() < ymin ) labelPosition.setY( ymin );
                    qreal ymax = viewport().height() - 10.0 - labelAscent;
                    if ( labelPosition.y() > ymax ) labelPosition.setY( ymax );

                    drawText( QRectF( labelPosition, fontMetrics().size( 0, labelText) ), labelText );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &lang: QStringList() << lang << code ) {
            QFileInfo translations = QFileInfo( path + QLatin1String("/routing-instructions_") + lang + QLatin1String(".qm"));
            if ( translations.exists() && translator.load( translations.absoluteFilePath() ) ) {
                app.installTranslator( &translator );
                return;
            }
        }
```

#### AUTO 


```{c}
auto const &entry
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& point : m_rightEdge) {
                intersectionsRight << QSharedPointer<LinkedPoint>(new LinkedPoint(point));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems.negative) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RenderPlugin *renderPlugin: d->m_widget->renderPlugins()) {
        if (renderPlugin->nameId() == QLatin1String("crosshairs")) {
            d->m_hasCrosshairsPlugin = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter.value()) {
                ++count;
                int const zoomLevel = tileId.zoomLevel();
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles) {
                    if (zoomLevel > 13 && mbtileWriter && mbtileWriter->hasTile(tileId.x(), tileId.y(), zoomLevel)) {
                        continue;
                    } else if (QFileInfo(filename).exists()) {
                        continue;
                    }
                }

                typedef QSharedPointer<GeoDataDocument> GeoDocPtr;
                GeoDocPtr tile2 = GeoDocPtr(loader.clip(zoomLevel, tileId.x(), tileId.y()));
                if (tile2->size() > 0) {
                    GeoDocPtr tile1 = GeoDocPtr(mapTiles.clip(zoomLevel, tileId.x(), tileId.y()));
                    TagsFilter::removeAnnotationTags(tile1.data());
                    int originalWays = 0;
                    int mergedWays = 0;
                    if (zoomLevel < 17) {
                        WayConcatenator concatenator(tile1.data());
                        originalWays = concatenator.originalWays();
                        mergedWays = concatenator.mergedWays();
                    }
                    NodeReducer nodeReducer(tile1.data(), tileId);
                    if (tile1->size() > 0 && tile2->size() > 0) {
                        GeoDocPtr combined = GeoDocPtr(mergeDocuments(tile1.data(), tile2.data()));

                        if (writeBoundaries && boundaryTiles.contains(iter.key())) {
                            writeBoundaryTile(tile1.data(), region, parser, tileId.x(), tileId.y(), zoomLevel);
                            if (mergeTiles) {
                                combined = mergeBoundaryTiles(tile2, manager, parser, tileId.x(), tileId.y(), zoomLevel);
                            }
                        }

                        if (zoomLevel > 13 && mbtileWriter) {
                            QBuffer buffer;
                            buffer.open(QBuffer::ReadWrite);
                            if (GeoDataDocumentWriter::write(&buffer, *combined, extension)) {
                                buffer.seek(0);
                                mbtileWriter->addTile(&buffer, tileId.x(), tileId.y(), zoomLevel);
                            } else {
                                qWarning() << "Could not write the tile " << combined->name();
                            }
                        } else {
                            if (!writeTile(combined.data(), filename)) {
                                return 4;
                            }
                        }

                        TileDirectory::printProgress(count / double(total));
                        std::cout << "  Tile " << count << "/" << total << " (";
                        std::cout << combined->name().toStdString() << ").";
                        double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                        std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                        if (originalWays > 0) {
                            std::cout << " , " << originalWays << " ways merged to " << mergedWays;
                        }
                    } else {
                        TileDirectory::printProgress(count / double(total));
                        std::cout << "  Skipping empty tile " << count << "/" << total << " (" << tile1->name().toStdString() << ").";
                    }
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << "  Skipping sea tile " << count << "/" << total << " (" << tile2->name().toStdString() << ").";
                }

                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & clickedItems: clickedItemsList) { //iterate through FeatureItemMap clickedItems (QHash)
                for (auto iter = clickedItems.find(placemark); iter != clickedItems.end(); ++iter) {
                    if ( iter.key() == placemark ) {
                const GeoDataObject *parent = placemark->parent();
                if ( parent ) {
                    auto item = *iter;
                    if (const GeoDataDocument *doc = geodata_cast<GeoDataDocument>(parent)) {
                        QString styleUrl = placemark->styleUrl();
                        styleUrl.remove(QLatin1Char('#'));
                        if ( !styleUrl.isEmpty() ) {
                            GeoDataStyleMap const &styleMap = doc->styleMap( styleUrl );
                            GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                            if ( style ) {
                                d->selectItem( item );
                                d->applyHighlightStyle( item, style );
                            }
                        }

                        /**
                            * If a placemark is using an inline style instead of a shared
                            * style ( e.g in case when theme file specifies the colorMap
                            * attribute ) then highlight it if any of the style maps have a
                            * highlight styleId
                            */
                        else {
                            for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
                        }
                            }
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(RenderPlugin *renderPlugin: widget->renderPlugins())
            {
                if(renderPlugin->isInitialized())
                {
                    installPluginEventFilter(renderPlugin);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataStyleMap &map: document->styleMaps() ) {
        writeElement( &map, writer );
    }
```

#### AUTO 


```{c}
auto & layerItems = d->m_cachedPaintFragments[layer];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& additionalOsmTag: additionalOsmTags) {
        if (filter.contains(additionalOsmTag.first)) {
            recommendedTags += additionalOsmTag;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &id: m_favoriteItems ) {
            if ( !m_parent->findItem( id ) ) {
                m_parent->getItem( id );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ModelRegion &region: m_instructionRegions ) {
        if ( region.region.contains( e->pos() ) && m_selectionModel ) {
            if ( e->button() == Qt::LeftButton ) {
                QItemSelectionModel::SelectionFlag command = QItemSelectionModel::ClearAndSelect;
                if ( m_selectionModel->isSelected( region.index ) ) {
                    command = QItemSelectionModel::Clear;
                }
                m_selectionModel->select( region.index, command );
                m_dropStopOver = e->pos();
                storeDragPosition( e->pos() );
                // annotation and old annotation are dirty, large region
                emit q->repaintNeeded();
                return true;
            } else if ( e->button() == Qt::RightButton ) {
                m_removeViaPointAction->setEnabled( false );
                m_contextMenu->showRmbMenu( e->x(), e->y() );
                return true;
            } else
                return false;
        }
    }
```

#### AUTO 


```{c}
auto labelStyle = style->labelStyle();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: cluster) {
                    if (distanceSphere(peak->coordinate(), placemark->coordinate()) < maxDistance) {
                        fit = &cluster;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: document->placemarkList()) {
        auto & osmData = placemark->osmData();
        removeAnnotationTags(osmData);
        for (auto & reference: osmData.nodeReferences()) {
            removeAnnotationTags(reference);
        }
        for (auto & reference: osmData.memberReferences()) {
            removeAnnotationTags(reference);
        }
    }
```

#### AUTO 


```{c}
auto const tileId = TileId (0, req.tile.z, x + req.tile.x, y + req.tile.y);
```

#### AUTO 


```{c}
auto const value = m_tags.value(QStringLiteral("mx:oid")).toLong();
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingRunnerPlugin* plugin: plugins ) {
        if ( !profile.name().isEmpty() && !profile.pluginSettings().contains( plugin->nameId() ) ) {
            continue;
        }

        RoutingTask* task = new RoutingTask( plugin->newRunner(), this, request );
        connect( task, SIGNAL(finished(RoutingTask*)), this, SLOT(cleanupRoutingTask(RoutingTask*)) );
        mDebug() << "route task" << plugin->nameId() << " " << (quintptr)task;
        d->m_routingTasks << task;
    }
```

#### AUTO 


```{c}
const auto & item
```

#### RANGE FOR STATEMENT 


```{c}
for( const QFileInfo & file: files() ) {
        result += file.size();
    }
```

#### AUTO 


```{c}
auto black = QColor("#151515");
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataFolder *folder: folders ) {
        for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            const GeoDataGeometry* geometry = placemark->geometry();
            const GeoDataLineString* lineString = dynamic_cast<const GeoDataLineString*>( geometry );
            if ( lineString ) {
                return lineString;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tag: tagsList) {
                    bool contains;
                    if (tag.second == QLatin1String("*")) {
                        contains = osmData.containsTagKey(tag.first);
                    } else {
                        contains = osmData.containsTag(tag.first, tag.second);
                    }
                    if (contains) {
                        acceptPlacemark = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str: stringlist ) {
            // qDebug()<<str;
            float  x;
            float  y;
            x = str.section(QLatin1Char(','), 0, 0).toFloat();
            y = str.section(QLatin1Char(','), 1, 1).toFloat();
			
            // qDebug() << "x:" << x << "y:" << y;
			
            short  header;
            short  lat;
            short  lng;	

            if ( firstheader ) {
                header      = m_header;
                firstheader = false;
            }
            else {
                if ( stringlist.size() > 14 ) {
                    if ( count % 9 == 0 ) 
                        header = 5;
                    else if ( count % 5 == 0 )
                        header = 3;
                    else if ( count % 2 == 0 )
                        header = 2;
                    else
                        header = 1;
                }
                else if ( stringlist.size() > 6 ) {
                    if ( count % 2 == 0 )
                        header = 3;
                    else
                        header = 1;
                }
                else {
                    header = 2;
                }
            }
            if ( count == stringlist.size() - 1 )
                header = 5;

            lng =  (int)( x * 50 - 10800 );
            lat = -(int)( y * 50 - 5400 );

            qDebug() << "lng:" << lng << "lat:" << lat << "header:"
                     << header << "node#:" << m_pointnum;

            stream << header << lat << lng;	
            m_pointnum++;	
            count++;		
        }
```

#### AUTO 


```{c}
const auto folder
```

#### AUTO 


```{c}
auto item
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointF& labelNode: labelNodes ) {
                    QPointF labelPosition = labelNode + QPointF( 3.0, -2.0 );

                    // FIXME: This is a Q&D fix.
                    qreal xmax = viewport().width() - 10.0 - labelWidth;
                    if ( labelPosition.x() > xmax ) labelPosition.setX( xmax );
                    qreal ymin = 10.0 + labelAscent;
                    if ( labelPosition.y() < ymin ) labelPosition.setY( ymin );
                    qreal ymax = viewport().height() - 10.0 - labelAscent;
                    if ( labelPosition.y() > ymax ) labelPosition.setY( ymax );

                    drawText( QRectF( labelPosition, fontMetrics().size( 0, labelText) ), labelText );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: innerRing) {
            m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *dataset: layer->datasets() ) {
            const GeoSceneGeodata *data = dynamic_cast<const GeoSceneGeodata*>( dataset );
            Q_ASSERT( data );
            bool skip = false;
            GeoDataDocument *doc = nullptr;
            for ( int i = 0; i < currentDatasets.size(); ++i ) {
                if ( currentDatasets[i] == *data ) {
                    currentDatasets.removeAt( i );
                    skip = true;
                    break;
                }
                /*
                 * If the sourcefile of data matches any in the currentDatasets then there
                 * is no need to parse the file again just update the style
                 * i.e. <brush> and <pen> values of already parsed file. assignNewStyle() does that
                 */
                if ( currentDatasets[i].sourceFile() == data->sourceFile() ) {
                    doc = d->m_fileManager.at(data->sourceFile());
                    currentDatasets.removeAt(i);
                }
            }
            if ( skip ) {
                continue;
            }

            if (doc) {
                d->assignFillColors(doc, *data);
            }
            else {
                const QString filename = data->sourceFile();
                const QString property = data->property();
                const QPen pen = data->pen();
                const QBrush brush = data->brush();
                GeoDataStyle::Ptr style;
                const int renderOrder = data->renderOrder();

                /*
                 * data->colors() are the colorMap values from dgml file. If this is not
                 * empty then we are supposed to assign every placemark a different style
                 * by giving it a color from colorMap values based on color index
                 * of that placemark. See assignFillColors() for details. So, we need to
                 * send an empty style to fileManeger otherwise the FileLoader::createFilterProperties()
                 * will overwrite the parsed value of color index ( GeoDataPolyStyle::d->m_colorIndex ).
                 */
                if ( data->colors().isEmpty() ) {
                    GeoDataLineStyle lineStyle( pen.color() );
                    lineStyle.setPenStyle( pen.style() );
                    lineStyle.setWidth( pen.width() );
                    GeoDataPolyStyle polyStyle( brush.color() );
                    polyStyle.setFill( true );
                    style = GeoDataStyle::Ptr(new GeoDataStyle);
                    style->setLineStyle( lineStyle );
                    style->setPolyStyle( polyStyle );
                    style->setId(QStringLiteral("default"));
                }

                fileList << filename;
                propertyList << property;
                styleList << style;
                renderOrderList << renderOrder;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<LinkedPoint>& A, const QSharedPointer<LinkedPoint>& B) {
                return A->point().y() < B->point().y();
            }
```

#### AUTO 


```{c}
auto const network = m_relations.at(index.row())->osmData().tagValue(QStringLiteral("network"));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& planet: PlanetFactory::planetList() ) {
        QString mapFile = MarbleDirs::path(QLatin1String("svg/") + planet + QLatin1String("map.svg"));

        if (planet == QLatin1String("moon")) {
            mapFile = MarbleDirs::path(QStringLiteral("svg/lunarmap.svg"));
        }
        else if (planet == QLatin1String("earth") || mapFile.isEmpty()) {
            mapFile = MarbleDirs::path(QStringLiteral("svg/worldmap.svg"));
        }

        const QString id = QLatin1String("path_") + planet;
        m_settings.insert(id, settings.value(id, mapFile));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const RequestRegion &region: m_regions ) {
        if ( region.region.contains( e->pos() ) ) {
            if ( e->button() == Qt::LeftButton ) {
                m_movingIndex = region.index;
                m_dropStopOver = QPoint();
                m_dragStopOver = QPoint();
                return true;
            } else if ( e->button() == Qt::RightButton ) {
                m_removeViaPointAction->setEnabled( true );
                m_activeMenuIndex = region.index;
                m_contextMenu->showRmbMenu( e->x(), e->y() );
                return true;
            } else
                return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemB: m_diffB ) {
        if( itemB.m_action == DiffItem::Created ) {
            m_merged.append( itemB );
        }
    }
```

#### AUTO 


```{c}
auto const y0 = polygon[i].y();
```

#### AUTO 


```{c}
auto points = lineNodeGeo->vertexDataAsPoint2D();
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLinearRing &innerRing: polygon->innerBoundaries() ) {
            ++index;
            OsmPlacemarkData &innerRingData = osmData.memberReference( index );
            if (innerRingData.isNull()) {
                innerRingData.setId(--m_minId);
            }

            // Inner boundary nodes
            QVector<GeoDataCoordinates>::const_iterator it =  innerRing.constBegin();
            QVector<GeoDataCoordinates>::ConstIterator const end = innerRing.constEnd();

            for ( ; it != end; ++it ) {
                if (innerRingData.nodeReference(*it).isNull()) {
                    innerRingData.nodeReference(*it).setId(--m_minId);
                }
            }
        }
```

#### AUTO 


```{c}
const auto animatedUpdate = geodata_cast<GeoDataAnimatedUpdate>(primitive)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto dataset: layer->datasets()) {
            auto sceneData = dynamic_cast<const GeoSceneGeodata *>(dataset);
            if (sceneData != nullptr && sceneData->sourceFile() == filePath) {
                data = sceneData;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingRunnerPlugin* plugin: allPlugins ) {
        m_plugins << plugin;
        RoutingRunnerPlugin::ConfigWidget* configWidget = plugin->configWidget();
        if ( configWidget ) {
            m_configWidgets.insert( plugin, configWidget );
            m_ui->settingsStack->addWidget( configWidget );
        }
    }
```

#### AUTO 


```{c}
const auto polygon = geodata_cast<GeoDataPolygon>(m_placemark->geometry())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &field: fields) {
            auto iter = m_networks.find(field);
            if (iter != m_networks.end()) {
                return *iter;
            }
        }
```

#### AUTO 


```{c}
const auto lineString = geodata_cast<GeoDataLinearRing>(placemark->geometry())
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataDocument* route: d->m_restrainedRoutes ) {
        if ( !d->filter( route ) ) {
            int affected = d->m_routes.size();
            beginInsertRows( QModelIndex(), affected, affected );
//            GeoDataDocument* base = d->m_routes.isEmpty() ? 0 : d->m_routes.first();
            d->m_routes.push_back( route );
            endInsertRows();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinate: *reducedLine) {
            if (touchesTileBorder(coordinate)) {
                borderPoints << index;
            }
            ++index;
        }
```

#### AUTO 


```{c}
auto playlist = (parent.isValid() ? geodata_cast<GeoDataPlaylist>(parentObject) : nullptr)
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataPlacemark>(item->feature())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: outerRing) {
        m_nodes << OsmConverter::Node(coordinates, outerRingOsmData.nodeReference(coordinates));
    }
```

#### AUTO 


```{c}
auto const end = p()->m_styleHash.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmOsmRegion & region: m_osmOsmRegions ) {
        regions << region.region;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tileId: tiles) {
                ++count;
                QString const inputFile = first ? m_inputFile : QString("%1/osm/%2/%3/%4.o5m").
                                                  arg(m_cacheDir).arg(tileId.zoomLevel()-1).arg(tileId.x()>>1).arg(tileId.y()>>1);
                QString const outputFile = osmFileFor(tileId);
                if (QFileInfo(outputFile).exists()) {
                    continue;
                }

                printProgress(count / double(maxCount));
                cout << " Creating osm cache tile " << count << "/" << maxCount << " (";
                cout << tileId.zoomLevel() << "/" << tileId.x() << "/" << tileId.y() << ')' << string(20, ' ') << '\r';
                cout.flush();

                QDir().mkpath(QFileInfo(outputFile).absolutePath());
                QString const output = QString("-o=%1").arg(outputFile);

                const GeoDataLatLonBox tileBoundary = m_tileProjection.geoCoordinates(tileId.zoomLevel(), tileId.x(), tileId.y());

                double const minLon = tileBoundary.west(GeoDataCoordinates::Degree);
                double const maxLon = tileBoundary.east(GeoDataCoordinates::Degree);
                double const maxLat = tileBoundary.north(GeoDataCoordinates::Degree);
                double const minLat = tileBoundary.south(GeoDataCoordinates::Degree);
                QString const bbox = QString("-b=%1,%2,%3,%4").arg(minLon).arg(minLat).arg(maxLon).arg(maxLat);
                QProcess osmconvert;
                osmconvert.start("osmconvert", QStringList() << "--drop-author" << "--drop-version"
                                 << "--complete-ways" << "--complex-ways" << bbox << output << inputFile);
                osmconvert.waitForFinished(10*60*1000);
                if (osmconvert.exitCode() != 0) {
                    qWarning() << osmconvert.readAllStandardError();
                    qWarning() << "osmconvert failed: " << osmconvert.errorString();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : lineStringItems) {
            lineStrings << item->lineString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder* folder: container->folderList() ) {
        setVisualCategory( folder );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFeature *feature: other.m_vector) {
            m_vector.append(feature->clone());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (RenderPlugin* plugin: d->m_map.renderPlugins()) {
            if (plugin->nameId() == pluginId) {
                plugin->setSetting(key, value);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoSceneLayer* layer: m_model->mapTheme()->map()->layers() ){
            if ( layer->backend() == dgml::dgmlValue_texture ){

                for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneTextureTileDataset *const texture = dynamic_cast<GeoSceneTextureTileDataset const *>( pos );
                    if ( !texture )
                        continue;

                    const QString sourceDir = texture->sourceDir();
                    const QString installMap = texture->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *texture )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( texture->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, nullptr );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *texture ) ) {
                            mDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qWarning() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *texture ) ) {
                        textures.append( texture );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        textureLayersOk = false;
                    }
                }
            }
            else if ( layer->backend() == dgml::dgmlValue_vectortile ){

                for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneVectorTileDataset *const vectorTile = dynamic_cast<GeoSceneVectorTileDataset const *>( pos );
                    if ( !vectorTile )
                        continue;

                    const QString sourceDir = vectorTile->sourceDir();
                    const QString installMap = vectorTile->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *vectorTile )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( vectorTile->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, nullptr );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                            qDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qDebug() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                        vectorTiles.append( vectorTile );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        vectorTileLayersOk = false;
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto peak: noise) {
        peak->osmData().addTag(QLatin1String("marbleZoomLevel"), QLatin1String("11"));
    }
```

#### AUTO 


```{c}
auto const & clickedItems
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* placemark: instructions )
    {
        result->append( placemark );
    }
```

#### AUTO 


```{c}
const auto& additionalOsmTag
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &theme: themes ) {
        Marble::GeoSceneDocument* document = Marble::MapThemeManager::loadMapTheme( theme );
        if ( document && document->head()->zoom()->maximum() > 3000 ) {
            m_streetMapThemeIds << document->head()->mapThemeId();
            delete document;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &coordinate: bounds) {
            if (m_boundingBox.contains(coordinate)) {
                ++innerNodes;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* outerRoof: m_cachedOuterRoofPolygons ) {
                painter->drawPolygon( *outerRoof );
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr const int m_metatileRows = 8;
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* outerPolygon:  m_cachedOuterPolygons ) {
                painter->drawPolygon( *outerPolygon );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction *action: m_contextMenu->actions() ) {
            if ( action->text() == tr( "&Configure..." ) ) {
                m_contextMenu->removeAction( action );
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
            GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
            newPlacemark->setVisible(placemark->isVisible());
            newPlacemark->setVisualCategory(placemark->visualCategory());
            T* newRing = new T;
            pathToRing(path, newRing, osmData, newPlacemark->osmData(), coordMap);

            if (isBuilding) {
                const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
                GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
                newBuilding->multiGeometry()->clear();
                newBuilding->multiGeometry()->append(newRing);
                newPlacemark->setGeometry(newBuilding);
            } else {
                newPlacemark->setGeometry(newRing);
            }
            if (placemark->osmData().id() > 0) {
                newPlacemark->osmData().addTag(QStringLiteral("mx:oid"), QString::number(placemark->osmData().id()));
            }
            copyTags(*placemark, *newPlacemark);
            OsmObjectManager::initializeOsmData(newPlacemark);
            document->append(newPlacemark);
            osmIds << placemark->osmData().id();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Way & way: m_ways ) {
        if ( way.save ) {
            if ( !way.name.isEmpty() && !way.nodes.isEmpty() ) {
                waysByName.insert( way.name, way );
            }

            if ( !way.street.isEmpty() && way.name != way.street && !way.nodes.isEmpty() ) {
                waysByName.insert( way.street, way );
            }
        } else {
            ++m_statistic.uselessWays;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PositionProviderPlugin* plugin: plugins) {
            if ( plugin->nameId() == positionProvider) {
                PositionProviderPlugin * newPlugin = plugin->newInstance();
                d->m_model.positionTracking()->setPositionProviderPlugin(newPlugin);
                connect(newPlugin, SIGNAL(statusChanged(PositionProviderStatus)), this, SLOT(positionDataStatusChanged(PositionProviderStatus)));
                connect(newPlugin, SIGNAL(positionChanged(GeoDataCoordinates,GeoDataAccuracy)), this, SLOT(updateCurrentPosition(GeoDataCoordinates)));
                connect(newPlugin, SIGNAL(positionChanged(GeoDataCoordinates,GeoDataAccuracy)), this, SIGNAL(speedChanged()));
                connect(newPlugin, SIGNAL(positionChanged(GeoDataCoordinates,GeoDataAccuracy)), this, SIGNAL(angleChanged()));
                emit positionProviderChanged(positionProvider);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneSection *section: currentMapTheme->legend()->sections() ) {
        // Each section is divided into the "well"
        // Well is like a block of data with rounded corners
        customLegendString += QLatin1String("<div class=\"well well-small well-legend\">");

        const QString heading = QCoreApplication::translate("DGML", section->heading().toUtf8().constData());
        QString checkBoxString;
        if (section->checkable()) {
            // If it's needed to make a checkbox here, we will
            QString const checked = d->m_checkBoxMap[section->connectTo()] ? "checked" : "";
            /* Important comment:
             * We inject Marble object into JavaScript of each legend html file
             * This is only one way to handle checkbox changes we see, so
             * Marble.setCheckedProperty is a function that does it
             */
            if(!section->radio().isEmpty()) {
                checkBoxString = QLatin1String(
                        "<label class=\"section-head\">"
                        "<input style=\"position: relative; top: -4px;\" type=\"radio\" "
                        "onchange=\"Marble.setRadioCheckedProperty(this.value, this.name ,this.checked);\" ") +
                        checked + QLatin1String(" value=\"") + section->connectTo() + QLatin1String("\" name=\"") + section->radio() + QLatin1String("\" /><span>")
                        + heading +
                        QLatin1String("</span></label>");

            } else {
                checkBoxString = QLatin1String(
                        "<label class=\"section-head\">"
                        "<input style=\"position: relative; top: -4px;\" type=\"checkbox\" "
                        "onchange=\"Marble.setCheckedProperty(this.name, this.checked);\" ") + checked + QLatin1String(" name=\"") + section->connectTo() + QLatin1String("\" /><span>")
                        + heading +
                        QLatin1String("</span></label>");

            }
            customLegendString += checkBoxString;

        } else {
            customLegendString += QLatin1String("<h4 class=\"section-head\">") + heading + QLatin1String("</h4>");
        }

        for (const GeoSceneItem *item: section->items()) {

            // checkbox for item
            QString checkBoxString;
            if (item->checkable()) {
                QString const checked = d->m_checkBoxMap[item->connectTo()] ? "checked" : "";
                checkBoxString = QLatin1String(
                        "<input type=\"checkbox\" "
                        "onchange=\"Marble.setCheckedProperty(this.name, this.checked);\" ")
                        + checked + QLatin1String(" name=\"") + item->connectTo() + QLatin1String("\" />");

            }

            // pixmap and text
            QString src;
            QString styleDiv;
            int pixmapWidth = 24;
            int pixmapHeight = 12;
            if (!item->icon()->pixmap().isEmpty()) {
                QString path = MarbleDirs::path( item->icon()->pixmap() );
                const QPixmap oncePixmap(path);
                pixmapWidth = oncePixmap.width();
                pixmapHeight = oncePixmap.height();
                src = QUrl::fromLocalFile( path ).toString();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px;");
            } else {
              // Workaround for rendered border around empty images in webkit
              src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
            }
            // NOTICE. There are some pixmaps without image, so we should
            //         create just a plain rectangle with set color
            if (QColor(item->icon()->color()).isValid()) {
                const QColor color = item->icon()->color();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px; background-color: ") + color.name() + QLatin1Char(';');
            }
            styleDiv += " position: relative; top: -3px;";
            const QString text = QCoreApplication::translate("DGML", item->text().toUtf8().constData());
            QString html = QLatin1String(
                    "<div class=\"legend-entry\">"
                    "  <label>") + checkBoxString + QLatin1String(
                    "    <img class=\"image-pic\" src=\"") + src + QLatin1String("\" style=\"") + styleDiv + QLatin1String("\"/>"
                    "    <span class=\"kotation\" >") + text + QLatin1String("</span>"
                    "  </label>"
                    "</div>");
            customLegendString += html;
        }
        customLegendString += QLatin1String("</div>"); // <div class="well">
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction* action: m_panelActions ) {
        m_panelVisibility << action->isVisible();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &cluster: clusters) {
                for (auto placemark: cluster) {
                    if (peak->coordinate().sphericalDistanceTo(placemark->coordinate()) < maxDistance) {
                        fit = &cluster;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tiles: tileLevels) {
            for (auto const &tileId: tiles) {
                ++count;
                QString const inputFile = first ? m_inputFile : QString("%1/osm/%2/%3/%4.o5m").
                                                  arg(m_cacheDir).arg(tileId.zoomLevel()-1).arg(tileId.x()>>1).arg(tileId.y()>>1);
                QString const outputFile = osmFileFor(tileId);
                if (QFileInfo(outputFile).exists()) {
                    continue;
                }

                printProgress(count / double(maxCount));
                cout << " Creating osm cache tile " << count << "/" << maxCount << " (";
                cout << tileId.zoomLevel() << "/" << tileId.x() << "/" << tileId.y() << ')' << string(20, ' ') << '\r';
                cout.flush();

                QDir().mkpath(QFileInfo(outputFile).absolutePath());
                QString const output = QString("-o=%1").arg(outputFile);

                const GeoDataLatLonBox tileBoundary = m_tileProjection.geoCoordinates(tileId.zoomLevel(), tileId.x(), tileId.y());

                double const minLon = tileBoundary.west(GeoDataCoordinates::Degree);
                double const maxLon = tileBoundary.east(GeoDataCoordinates::Degree);
                double const maxLat = tileBoundary.north(GeoDataCoordinates::Degree);
                double const minLat = tileBoundary.south(GeoDataCoordinates::Degree);
                QString const bbox = QString("-b=%1,%2,%3,%4").arg(minLon).arg(minLat).arg(maxLon).arg(maxLat);
                QProcess osmconvert;
                osmconvert.start("osmconvert", QStringList() << "--drop-author" << "--drop-version"
                                 << "--complete-ways" << "--complex-ways" << bbox << output << inputFile);
                osmconvert.waitForFinished(10*60*1000);
                if (osmconvert.exitCode() != 0) {
                    qWarning() << osmconvert.readAllStandardError();
                    qWarning() << "osmconvert failed: " << osmconvert.errorString();
                }
            }
            first = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const BBCStation &station: m_items ) {
        if ( bbcIdTemplate.arg( station.bbcId() ) == id ) {
            return station;
        }
    }
```

#### AUTO 


```{c}
auto document = geodata_cast<GeoDataDocument>(feature)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems.negative) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### AUTO 


```{c}
auto doc = geodata_cast<GeoDataDocument>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& pluginName: settings.childGroups() ) {
                settings.beginGroup( pluginName );
                profile.pluginSettings().insert( pluginName, QHash<QString, QVariant>() );
                for ( const QString& key: settings.childKeys() ) {
                    if (key != QLatin1String("Enabled")) {
                        profile.pluginSettings()[ pluginName ].insert( key, settings.value( key ) );
                    }
                }
                settings.endGroup();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( AnimatedUpdateTrack* track: d->m_animatedUpdateTracks) {
        track->play();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] ( const LayerInterface * const one, const LayerInterface * const two ) -> bool {
            Q_ASSERT( one && two );
            return one->zValue() < two->zValue();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tiles: tileLevels) {
        for (auto const &tileId: tiles) {
            QFile::remove(osmFileFor(tileId));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmRegion & region: regions ) {
        for( Writer * writer: m_writers ) {
            writer->addOsmRegion( region );
        }
    }
```

#### AUTO 


```{c}
auto const refB = b->osmData().tagValue(QStringLiteral("ref"));
```

#### AUTO 


```{c}
auto const &field
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoGraphicsItem* item: items) {
            QStringList paintLayers = item->paintLayers();
            if (paintLayers.isEmpty()) {
                mDebug() << item << " provides no paint layers, so I force one onto it.";
                paintLayers << QString();
            }
            for (const auto &layer: paintLayers) {
                if (knownLayers.contains(layer)) {
                    GeometryLayerPrivate::PaintFragments &fragments = paintFragments[layer];
                    double const zValue = item->zValue();
                    // assign subway stations
                    if (zValue == 0.0) {
                        fragments.null << item;
                        // assign areas and streets
                    } else if (zValue < 0.0) {
                        fragments.negative << item;
                        // assign buildings
                    } else {
                        fragments.positive << item;
                    }
                } else {
                    // assign symbols
                    d->m_cachedDefaultLayer << GeometryLayerPrivate::LayerItem(layer, item);
                    static QSet<QString> missingLayers;
                    if (!missingLayers.contains(layer)) {
                        mDebug() << "Missing layer " << layer << ", in render order, will render it on top";
                        missingLayers << layer;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto const & chunk = matchItr.value();
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingRunnerPlugin* plugin: m_pluginManager->routingRunnerPlugins() ) {
            if ( plugin->supportsTemplate( tpl ) ) {
                profileSupportedByAtLeastOnePlugin = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto object = parent();
```

#### AUTO 


```{c}
auto const tags = QStringList() << "website" << "contact:website" << "facebook" << "contact:facebook" << "url";
```

#### AUTO 


```{c}
auto placemark = iter.value().create(nodes, usedNodes);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems.null) {
            if (item->contains(curpos, viewport)) {
                result << item->feature();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& colorName: colorString) {
                colorList.append(QColor(colorName));
            }
```

#### AUTO 


```{c}
auto const &relation
```

#### AUTO 


```{c}
auto const size = lineString->size();
```

#### AUTO 


```{c}
const auto x = blockX * blockSize + tileX;
```

#### AUTO 


```{c}
auto linearRing = geodata_cast<GeoDataLinearRing>(placemark->geometry())
```

#### AUTO 


```{c}
auto coordinates = m_coordinates;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString & path: pathList)
            out << path << endl;
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataFolder *folder: folders ) {
        for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            const GeoDataGeometry* geometry = placemark->geometry();
            if ( geometry->geometryId() == GeoDataLineStringId ) {
                const GeoDataLineString* lineString = dynamic_cast<const GeoDataLineString*>( geometry );
                Q_ASSERT( lineString && "Internal error: geometry ID does not match class type" );
                return lineString->length( EARTH_RADIUS );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( TrackerPluginItem *obj: m_satModel->items() ) {
        // catalog items
        SatellitesMSCItem *item = dynamic_cast<SatellitesMSCItem*>( obj );
        if( ( item != nullptr ) && ( item->catalog() == source ) ) {
            m_configDialog->addSatelliteItem(
                item->relatedBody(),
                item->category(),
                item->name(),
                item->id() );
        }
    }
```

#### AUTO 


```{c}
auto green = QColor("#006600");
```

#### AUTO 


```{c}
auto const isRoute = relation->osmData().tagValue(QStringLiteral("type")) == QStringLiteral("route");
```

#### AUTO 


```{c}
auto style = createPOIStyle(font, path, textColor, color, color, true, true);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: parser.positionalArguments() ) {
        // FIXME: Use openUrl( args->url(i) ) instead?
        if ( QFile::exists( file ) ) {
            window->marbleControl()->addGeoDataFile( file );
        }
    }
```

#### AUTO 


```{c}
auto iter=osmTagMapping.begin(), end=osmTagMapping.end() ;
```

#### AUTO 


```{c}
auto hash = tagWriterHash();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: m_relations) {
        bool const hasMember =
#if QT_VERSION >= 0x050600 // intersects was introduced in Qt 5.6.
        relation->memberIds().intersects(osmIds);
#else
        !relation->memberIds().intersect(osmIds).isEmpty();
#endif
        if (hasMember) {
            GeoDataRelation* multi = new GeoDataRelation;
            multi->osmData() = relation->osmData();
            tile->append(multi);
        }
    }
```

#### AUTO 


```{c}
auto & reference
```

#### AUTO 


```{c}
auto const width = qMax(fontmet.horizontalAdvance(m_labelText), m_pixmap_open.width());
```

#### AUTO 


```{c}
auto features = d->m_map.whichFeatureAt(QPoint(x, y));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<LinkedPoint>& A, const QSharedPointer<LinkedPoint>& B) {
                return B->point().x() < A->point().x();
            }
```

#### AUTO 


```{c}
auto const renderOrder = d->m_styleBuilder->renderOrder();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature : *doc) {
            auto placemark = geodata_cast<GeoDataPlacemark>(feature);
            if (placemark == nullptr) {
                continue;
            }

            GeoDataStyle::Ptr style(new GeoDataStyle);
            style->setId(QStringLiteral("normal"));
            style->setLineStyle( lineStyle );
            quint8 colorIndex = placemark->style()->polyStyle().colorIndex();
            GeoDataPolyStyle polyStyle;
            // Set the colorIndex so that it's not lost after setting new style.
            polyStyle.setColorIndex( colorIndex );
            QColor color;
            // color index having value 99 is undefined
            Q_ASSERT( colors.size() );
            if (colorIndex > colors.size() || (colorIndex - 1) < 0) {
                color = colors[0];      // Assign the first color as default
            }
            else {
                color = colors[colorIndex-1];
            }
            color.setAlphaF( alpha );
            polyStyle.setColor( color );
            polyStyle.setFill( true );
            style->setPolyStyle( polyStyle );
            placemark->setStyle( style );
        }
```

#### AUTO 


```{c}
auto const osmTagMapping = StyleBuilder::osmTagMapping();
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataSchema &schema: document->schemas() ) {
        writeElement( &schema, writer );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( TrackerPluginItem *obj: items() ) {
        SatellitesMSCItem *oItem = dynamic_cast<SatellitesMSCItem*>(obj);
        if( oItem != NULL ) {
            bool enabled = ( ( oItem->relatedBody().toLower() == m_lcPlanet ) &&
                             ( m_enabledIds.contains( oItem->id() ) ) );
            oItem->setEnabled( enabled );

            if( enabled ) {
                oItem->update();
            }
        }

        SatellitesTLEItem *eItem = dynamic_cast<SatellitesTLEItem*>(obj);
        if( eItem != NULL ) {
            // TLE satellites are always earth satellites
            bool enabled = (m_lcPlanet == QLatin1String("earth"));
            eItem->setEnabled( enabled );

            if( enabled ) {
                eItem->update();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto zoomLevel: zoomLevels) {
            TileIterator iter(mapTiles.boundingBox(), zoomLevel);
            total += iter.total();
            for(auto const &tileId: iter) {
                auto const tile = TileId(0, zoomLevel, tileId.x(), tileId.y());
                int const innerNodes = mapTiles.innerNodes(tile);
                if (innerNodes > 0) {
                    auto const mapTile = mapTiles.tileFor(zoomLevel, tileId.x(), tileId.y());
                    auto const name = QString("%1/%2/%3").arg(mapTile.zoomLevel()).arg(mapTile.x()).arg(mapTile.y());
                    tiles[name] << tile;
                    if (innerNodes < 4) {
                        boundaryTiles << name;
                    }
                } else {
                    --total;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPolygonF* itPolygon: polygons) {
            QPolygonF const & polygon = *itPolygon;
            QVector<QVector2D> normals;
            int segmentCount = itPolygon->size() - 1;
            normals.reserve(segmentCount);
            for(int i = 0; i < segmentCount; ++i) {
                normals << QVector2D(polygon[i+1] - polygon[i]).normalized();
            }
            QSGGeometryNode* lineNode = new QSGGeometryNode;

            QSGGeometry * lineNodeGeo = new QSGGeometry(QSGGeometry::defaultAttributes_Point2D(), segmentCount*4);
            lineNodeGeo->setDrawingMode(GL_TRIANGLE_STRIP);
            lineNodeGeo->allocate(segmentCount*4);

            QSGFlatColorMaterial *material = new QSGFlatColorMaterial;
            material->setColor(standardRouteColor);

            lineNode->setGeometry(lineNodeGeo);
            lineNode->setFlag(QSGNode::OwnsGeometry);
            lineNode->setMaterial(material);
            lineNode->setFlag(QSGNode::OwnsMaterial);

            auto points = lineNodeGeo->vertexDataAsPoint2D();
            int k = -1;
            for(int i = 0; i < segmentCount; ++i) {
                auto const & a = polygon[i];
                auto const & b = polygon[i+1];
                auto const & n = normals[i];
                points[++k].set(a.x() - halfWidth * n.y(), a.y() + halfWidth * n.x());
                points[++k].set(a.x() + halfWidth * n.y(), a.y() - halfWidth * n.x());
                points[++k].set(b.x() - halfWidth * n.y(), b.y() + halfWidth * n.x());
                points[++k].set(b.x() + halfWidth * n.y(), b.y() - halfWidth * n.x());
            }

            oldNode->appendChildNode(lineNode);
        }
```

#### AUTO 


```{c}
const auto tag = OsmTag(item->text(0), item->text(1));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneVectorTileDataset *vectorLayer: vectorLayers ) {
        if (vectorLayer->tileLevels().isEmpty() || vectorLayer->tileLevels().contains(id.zoomLevel())) {
            if ( TileLoader::tileStatus( vectorLayer, id ) != TileLoader::Available ) {
                d->m_loader.downloadTile( vectorLayer, id, DownloadBulk );
            }
        }
    }
```

#### AUTO 


```{c}
auto const &tile
```

#### AUTO 


```{c}
auto region = open(inputFileName, manager);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            write(m_heartbeatFd, "alive", 5);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto ring : m_polygon->innerBoundaries()) {
            if (viewport->resolves(ring.latLonAltBox(), 4)) {
               innerResolved = true;
               break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &state: renderStates) {
        const QStringList stateList = state.split(QLatin1Char(':'));
        if (stateList.size() == 2)
            m_renderPlanet[stateList[0]] = (bool)stateList[1].toInt();
    }
```

#### AUTO 


```{c}
auto & layerItems = d->m_cachedPaintFragments[renderOrder[i]];
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataLinearRing &ring: innerRings ) {
        m_boundariesList.append( painter->regionFromPolygon( ring, Qt::OddEvenFill ) );
    }
```

#### AUTO 


```{c}
const auto pipeFd = getenv("TIREX_BACKEND_PIPE_FILENO");
```

#### AUTO 


```{c}
auto iter = m_networks.find(network);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems.null) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### AUTO 


```{c}
auto iter = osmData.relationReferencesBegin(), end = osmData.relationReferencesEnd();
```

#### AUTO 


```{c}
auto const &route
```

#### AUTO 


```{c}
auto const &dir
```

#### RANGE FOR STATEMENT 


```{c}
for( const RouteItem &item: routeList ) {
            if( !cachedRoutes.contains( item.identifier() ) ) {
                d->m_routeList.append( item );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( Writer * writer: m_writers ) {
            writer->addOsmRegion( region );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPolygonF* itPolygon: polygons) {
        ClipPainter::drawPolyline(*itPolygon);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &via: viaList) {
            via = via.trimmed();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const PositionProviderPlugin *plugin: d->m_positionProviderPlugins ) {
        d->m_currentLocationUi.positionTrackingComboBox->addItem( plugin->guiString() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uiLanguage: uiLanguages) {
        for (auto tagIter = osmData.tagsBegin(), end = osmData.tagsEnd(); tagIter != end; ++tagIter) {
            if (tagIter.key().startsWith(tag)) {
                QStringRef const tagLanguage = tagIter.key().midRef(tag.length());
                if (tagLanguage == uiLanguage) {
                    append(m_wheelchairInfo, tagIter.value());
                    return m_wheelchairInfo;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataDocument *doc: m_landDocuments ) {
        painter->setPen( QPen( Qt::NoPen ) );
        painter->setBrush( QBrush( m_landColor ) );
        drawIndividualDocument( painter, doc );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto jsonRef : jsonArray) {
            QJsonObject jsonObj = jsonRef.toObject();
            QJsonObject geometry = jsonObj.value(QStringLiteral("geometry")).toObject();
            QJsonArray coordinates = geometry.value(QStringLiteral("coordinates")).toArray();
            double longitude = coordinates.at(0).toDouble();
            double latitude = coordinates.at(1).toDouble();

            GeoDataCoordinates coordinateset(longitude, latitude, 0.0, GeoDataCoordinates::Degree);
            QString id = QString::number(jsonObj.value(QStringLiteral("properties")).toObject().value(QStringLiteral("id")).toInt());

            NotesItem *item = new NotesItem(this);
            item->setId(id);
            item->setCoordinate(coordinateset);

            items << item;
        }
```

#### AUTO 


```{c}
auto const piste = d->m_osmData.tagValue(QStringLiteral("piste:type"));
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLinearRing &ring: innerBoundaries() ) {
        if ( ring.contains( coordinates ) ) {
            // Inside the polygon, but in one of its holes
            return false;
        }
    }
```

#### AUTO 


```{c}
auto document = geodata_cast<GeoDataDocument>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
            if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
                auto relation = static_cast<const GeoDataRelation*>(feature);
                allRelations << relation;
                if (relation->memberIds().contains(osmData.oid())) {
                    relevantRelations << relation;
                    auto const isRoute = relation->osmData().tagValue(QStringLiteral("type")) == QStringLiteral("route");
                    searchRelations &= !isRoute;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ReverseGeocodingRunnerPlugin* plugin: plugins ) {
        ReverseGeocodingTask* task = new ReverseGeocodingTask( plugin->newRunner(), this, d->m_marbleModel, coordinates );
        connect( task, SIGNAL(finished(ReverseGeocodingTask*)), this, SLOT(cleanupReverseGeocodingTask(ReverseGeocodingTask*)) );
        mDebug() << "reverse task " << plugin->nameId() << " " << (quintptr)task;
        d->m_reverseTasks << task;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark const * placemark: potentialIntersections(tileBoundary)) {
        GeoDataGeometry const * const geometry = placemark ? placemark->geometry() : nullptr;
        if (geometry && tileBoundary.intersects(geometry->latLonAltBox())) {
            if (geodata_cast<GeoDataPolygon>(geometry)) {
                clipPolygon(placemark, clip, minArea, tile, osmIds);
            } else if (geodata_cast<GeoDataLineString>(geometry)) {
                clipString<GeoDataLineString>(placemark, clip, minArea, tile, osmIds);
            } else if (geodata_cast<GeoDataLinearRing>(geometry)) {
                clipString<GeoDataLinearRing>(placemark, clip, minArea, tile, osmIds);
            } else if (const auto building = geodata_cast<GeoDataBuilding>(geometry)) {
                if (geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0))) {
                    clipPolygon(placemark, clip, minArea, tile, osmIds);
                } else if (geodata_cast<GeoDataLinearRing>(&building->multiGeometry()->at(0))) {
                    clipString<GeoDataLinearRing>(placemark, clip, minArea, tile, osmIds);
                }
            } else {
                tile->append(placemark->clone());
                osmIds << placemark->osmData().id();
            }
        }
    }
```

#### AUTO 


```{c}
auto const reference = stringTable.size() - iter.value();
```

#### AUTO 


```{c}
auto tileInfo = tileIter.fileInfo();
```

#### RANGE FOR STATEMENT 


```{c}
for( Marble::GeoDataFolder* const folder: bookmarks->folderList() ) {
            if ( folder->name() == folderName ) {
                target = folder;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataFolder *folder: folders ) {
        for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            if ( !blacklist.contains( placemark->name() ) ) {
                hasInstructions = true;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: files ) {
        arguments << inputDirectory.filePath( file );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction *action: m_contextMenu->actions() ) {
            if ( action->text() == tr( "&Configure..." ) ) {
                m_contextMenu->removeAction( action );
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uiLanguage: uiLanguages) {
            for (auto tagIter = data.tagsBegin(), end = data.tagsEnd(); tagIter != end; ++tagIter) {
                if (tagIter.key().startsWith(QLatin1String("name:"))) {
                    QStringRef const tagLanguage = tagIter.key().midRef(5);
                    if (tagLanguage == uiLanguage) {
                        return tagIter.value();
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int i: niceIntervals ) {
        const qreal numTicks = tickRange / i;
        if ( numTicks < m_minTickCount || numTicks > m_maxTickCount ) {
            continue;
        }
        const qreal newError = qAbs( numTicks - qRound( numTicks ) );
        if ( newError < error ) {
            error = newError;
            stepWidth = i;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Action &action: m_actionQueue ) {
        if ( action.first == index ) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &fileName: pluginFileNameList ) {
        QString const baseName = QFileInfo(fileName).baseName();
        if (!m_whitelist.isEmpty() && !m_whitelist.contains(baseName)) {
            mDebug() << "Ignoring non-whitelisted plugin " << fileName;
            continue;
        }
        if (m_blacklist.contains(baseName)) {
            mDebug() << "Ignoring blacklisted plugin " << fileName;
            continue;
        }

        // mDebug() << fileName << " - " << MarbleDirs::pluginPath( fileName );
        QString const path = MarbleDirs::pluginPath( fileName );
#ifdef Q_OS_ANDROID
        QFileInfo targetFile( path );
        if ( !m_pluginPaths.contains( targetFile.canonicalFilePath() ) ) {
            // @todo Delete the file here?
            qDebug() << "Ignoring file " << path << " which is not among the currently installed plugins";
            continue;
        }
#endif
        QPluginLoader* loader = new QPluginLoader( path, m_parent );

        QObject * obj = loader->instance();

        if ( obj ) {
            bool isPlugin = addPlugin(obj, loader);
            if (!isPlugin) {
                delete loader;
            } else {
                foundPlugin = true;
            }
        } else {
            qWarning() << "Ignoring to load the following file since it doesn't look like a valid Marble plugin:" << path << endl
                       << "Reason:" << loader->errorString();
            delete loader;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDataPluginItem* item: d->m_displayedItems ) {
        if (item && item->contains(curposF)) {
            itemsAt.append( item );
        }
    }
```

#### AUTO 


```{c}
auto area = 0.0;
```

#### AUTO 


```{c}
auto const & point
```

#### AUTO 


```{c}
auto placemark = parser.parentElement(1).nodeAs<GeoDataPlacemark>();
```

#### AUTO 


```{c}
auto iter = hash.find(mark->symbolId());
```

#### AUTO 


```{c}
auto intersection = d->m_memberIds;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex& index: resultList ) {
                if( !index.isValid() ) {
                    mDebug() << "invalid index!!!";
                    continue;
                }
                GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>(qvariant_cast<GeoDataObject*>( index.data( MarblePlacemarkModel::ObjectPointerRole )));
                if ( placemark &&
                     ( searchEverywhere || preferred.contains( placemark->coordinate() ) ) ) {
                    vector.append( new GeoDataPlacemark( *placemark ));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataFolder *subFolder: folder->folderList() ) {
        QString newPath = QString( "%0/%1" ).arg( path, subFolder->name() );
        diffItems.append( getPlacemarks( subFolder, newPath, other, diffDirection ) );
    }
```

#### AUTO 


```{c}
auto otherChunk = wayChunk(*placemark, lastId);
```

#### RANGE FOR STATEMENT 


```{c}
for ( MarbleGraphicsItem *item: m_children ) {
            item->d_func()->updateChildPositions();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dir: path.split( QLatin1Char( ':' ) ) ) {
            QFileInfo executable( QDir( dir ), application );
            if ( executable.exists() ) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto memberId
```

#### RANGE FOR STATEMENT 


```{c}
for( const RouteSegment &segment: segments ) {
            route.addRouteSegment( segment );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& planetName: manager->mapThemeIds()) {
                if ( planetName.startsWith(uriParser.planet().id(), Qt::CaseInsensitive)) {
                    m_marbleWidget->setMapThemeId(planetName);
                    break;
                }
            }
```

#### AUTO 


```{c}
auto const & style
```

#### RANGE FOR STATEMENT 


```{c}
for( const QRectF &rect: list[j]->boundingRects() ) {
                    for( const QRectF &itemRect: (*i)->boundingRects() ) {
                        if ( rect.intersects( itemRect ) )
                            collides = true;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *candidate: m_textureLayers ) {
        Q_ASSERT( candidate );
        // check, if layer provides tiles for the current level
        if ( !candidate->hasMaximumTileLevel() ||
             candidate->maximumTileLevel() >= stackedTileId.zoomLevel() ) {
            //check if the tile intersects with texture bounds
            if (candidate->latLonBox().isNull()) {
                result.append(candidate);
            }
            else {
                const GeoDataLatLonBox bbox = candidate->tileProjection()->geoCoordinates(stackedTileId);

                if (candidate->latLonBox().intersects(bbox)) {
                    result.append( candidate );
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: d->m_relations) {
                if (relation->isVisible()) {
                    styling.relation = relation;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto const tileZoomLevel = qMax(d->m_textureLayer.tileZoomLevel(), d->m_vectorTileLayer.tileZoomLevel());
```

#### AUTO 


```{c}
auto chunk = wayChunk(*placemark, lastId);
```

#### AUTO 


```{c}
const auto& renderPosition
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark *placemark: placemarks) {
        m_searchResult->append( new GeoDataPlacemark( *placemark ) );
    }
```

#### AUTO 


```{c}
auto const imageSize = imageReader.size();
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataGeometry *geometry: other.m_vector ) {
            GeoDataGeometry *newGeometry;

            // This piece of code has been used for a couple of times. Isn't it possible
            // to add a virtual method copy() similar to how abstract view does this?
            if ( geometry->nodeType() == GeoDataTypes::GeoDataLineStringType ) {
                newGeometry = new GeoDataLineString( *geometry );
            } else if ( geometry->nodeType() == GeoDataTypes::GeoDataPointType ) {
                // FIXME: Doesn't have a constructor which creates the object from a
                // GeoDataGeometry so cast is needed.
                newGeometry = new GeoDataPoint( *static_cast<GeoDataPoint*>( geometry ) );
            } else if ( geometry->nodeType() == GeoDataTypes::GeoDataModelType ) {
                // FIXME: Doesn't have a constructor which creates the object from a
                // GeoDataGeometry so cast is needed.
                newGeometry = new GeoDataModel( *static_cast<GeoDataModel*>( geometry ) );
            } else if ( geometry->nodeType() == GeoDataTypes::GeoDataTrackType ) {
                newGeometry = new GeoDataTrack( *static_cast<GeoDataTrack*>( geometry ) );
            } else if ( geometry->nodeType() == GeoDataTypes::GeoDataMultiTrackType ) {
                newGeometry = new GeoDataMultiTrack( *geometry );
            } else if ( geometry->nodeType() == GeoDataTypes::GeoDataPolygonType ) {
                newGeometry = new GeoDataPolygon( *geometry );
            } else if ( geometry->nodeType() == GeoDataTypes::GeoDataLinearRingType ) {
                newGeometry = new GeoDataLinearRing( *geometry );
            } else {
                qFatal("Unexpected type '%s'", geometry->nodeType() );
            }

            m_vector.append( newGeometry );
        }
```

#### AUTO 


```{c}
auto wait = geodata_cast<GeoDataWait>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& key: settings.childKeys() ) {
                    if (key != QLatin1String("Enabled")) {
                        profile.pluginSettings()[ pluginName ].insert( key, settings.value( key ) );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingRunnerPlugin *plugin:  m_plugins ) {
        QStandardItem *item = new QStandardItem( plugin->guiString() );
        item->setCheckable( true );
        if ( profiles[ profileIndex ].pluginSettings().contains( plugin->nameId() ) ) {
            item->setCheckState( Qt::Checked );
            QHash<QString, QVariant> settings = profiles[ profileIndex ].pluginSettings()[ plugin->nameId() ];
            mDebug() << settings;
            if ( m_configWidgets[plugin] ) {
                m_configWidgets[plugin]->loadSettings( settings );
            }
        }
        m_servicesModel->invisibleRootItem()->appendRow( item );
    }
```

#### AUTO 


```{c}
auto containers = QVector<Container*>() << &clipPolygon << &basePolygon << &intersections;
```

#### AUTO 


```{c}
auto const moreNeighbors = peaksNear(neighbor, peaks, maxDistance);
```

#### AUTO 


```{c}
auto mapper
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &route: visibleRelationTypes) {
            d->m_enabledRelationTypes |= d->m_relationTypeConverter.value(route, GeoDataRelation::UnknownType);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark* placemark: doc->placemarkList()) {
                if (placemark->geometry() && placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType) {
                    GeoDataPolygon *polygon = static_cast<GeoDataPolygon*>(placemark->geometry());
                    polygon->setRenderOrder(m_renderOrder);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto id: way.references()) {
            if (!nodes.contains(id)) {
                // A node is missing. Return nothing.
                return OsmRings();
            }
            const auto &node = nodes[id];
            ring << node.coordinates();
            placemarkData.addNodeReference(node.coordinates(), node.osmData());
        }
```

#### AUTO 


```{c}
auto iter = d->m_styleHash.constBegin();
```

#### AUTO 


```{c}
auto iter=m_osmData.tagsBegin(), end=m_osmData.tagsEnd();
```

#### AUTO 


```{c}
auto viaList = viaValue.split(';', QString::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoSceneTextureTileDataset *t: m_customTextures)
    {
        m_textures.append(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::GeoDataFolder* folder: bookmarks->folderList() ) {
        for( const Marble::GeoDataPlacemark * const placemark: folder->placemarkList() ) {
            if (placemark->coordinate().sphericalDistanceTo(compareTo) * planetRadius < 5) {
                return true;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * a, const GeoDataRelation * b) {
            return *a < *b;
        }
```

#### AUTO 


```{c}
auto appendToIntersectionKind = [&](QSharedPointer<LinkedPoint>& intersection) {
        switch(borderSector(intersection->point())) {
        case 1:
            intersectionsTop << intersection;
            break;
        case 3:
            intersectionsLeft << intersection;
            break;
        case 5:
            intersectionsRight << intersection;
            break;
        case 7:
            intersectionsBottom << intersection;
            break;
        default: break;
        }
    };
```

#### AUTO 


```{c}
const auto tag = StyleBuilder::OsmTag(iter.key(), iter.value());
```

#### AUTO 


```{c}
const auto cmdSocketResult = m_commandSocket.setSocketDescriptor(std::atoi(socketFd));
```

#### AUTO 


```{c}
auto const coordinate = GeoDataCoordinates(lon, lat, ele, GeoDataCoordinates::Degree);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto candidate: places) {
                        qDebug() << candidate->coordinate().sphericalDistanceTo(place->coordinate()) * EARTH_RADIUS << " m, "
                                 << "levenshtein distance " << levenshteinDistance(placeName, candidate->name()) << ":" << candidate->name();
                    }
```

#### AUTO 


```{c}
auto const & innerRingOsmData = placemarkOsmData.memberReference(index);
```

#### AUTO 


```{c}
auto const strip = 1+tileDir.absolutePath().size();
```

#### AUTO 


```{c}
auto iter = placemark->osmData().nodeReferencesBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for( SatellitesConfigAbstractItem *item: m_children ) {
            fullIdList.append( item->data( column, role ).toStringList() );
        }
```

#### AUTO 


```{c}
auto iter = roleNames.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const MarbleZipReader::FileInfo &zipFileInfo : zipReader.fileInfoList()) {
            if (zipFileInfo.filePath.toLower().endsWith(QLatin1String(".kml"))) {
                kmlFiles.append(zipFileInfo.filePath);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFloatItem *floatItem: floatItems)
        {
            if ( floatItem->enabled() && floatItem->visible()
                 && floatItem->contains( event->pos() ) )
            {
                d->m_pressAndHoldTimer.stop();
                d->m_lmbTimer.stop();
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
            if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
                auto relation = static_cast<GeoDataRelation*>(feature);
                for (auto member: relation->members()) {
                    relations[member] << relation;
                }
            }
        }
```

#### AUTO 


```{c}
auto const &ring
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &planet: m_renderPlanet.keys()) {
            if (m_renderPlanet[planet])
                renderPlanet(planet, painter, sys, viewport, skyRadius, skyAxisMatrix);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: *linearRing) {
        m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
    }
```

#### AUTO 


```{c}
auto playlist = geodata_cast<GeoDataPlaylist>(parent)
```

#### AUTO 


```{c}
auto places = cityPlaces(placemarks);
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* placemark: container->placemarkList() ) {
        if ( EARTH_RADIUS * distanceSphere( placemark->coordinate(), bookmark.coordinate() ) <= 1 ) {
            return placemark;
        }
    }
```

#### AUTO 


```{c}
auto tile = clipper->clipTo(m_zoomLevel, tileId.x(), tileId.y());
```

#### AUTO 


```{c}
auto iter = m_osmData.tagsBegin(), end=m_osmData.tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmOsmRegion & region: osmOsmRegions ) {
            if ( region.region.name() == city ) {
                placemark.setRegionId( region.region.identifier() );
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: selectedPlacemarks ) {
        for (auto tileIter = d->m_features.find(placemark); tileIter != d->m_features.end() && tileIter.key() == placemark; ++tileIter) {
            auto const & clickedItems = d->m_tiledItems[*tileIter];
            auto iter = clickedItems.find(placemark);
            if (iter != clickedItems.end()) {
                const GeoDataObject *parent = placemark->parent();
                if ( parent ) {
                    auto item = *iter;
                    if ( parent->nodeType() == GeoDataTypes::GeoDataDocumentType ) {
                        const GeoDataDocument *doc = static_cast<const GeoDataDocument *>(parent);
                        QString styleUrl = placemark->styleUrl();
                        styleUrl.remove(QLatin1Char('#'));
                        if ( !styleUrl.isEmpty() ) {
                            GeoDataStyleMap const &styleMap = doc->styleMap( styleUrl );
                            GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                            if ( style ) {
                                d->selectItem( item );
                                d->applyHighlightStyle( item, style );
                            }
                        }

                        /**
                            * If a placemark is using an inline style instead of a shared
                            * style ( e.g in case when theme file specifies the colorMap
                            * attribute ) then highlight it if any of the style maps have a
                            * highlight styleId
                            */
                        else {
                            for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QFileInfo &file: entries ) {
            QFile( file.absoluteFilePath() ).remove();
        }
```

#### AUTO 


```{c}
auto y = req.tile.y;
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
        ClipPainter::drawPolygon( *itPolygon, fillRule );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TileId &id: d->m_tileLoader.visibleTiles() ) {
        // it's debatable here, whether DownloadBulk or DownloadBrowse should be used
        // but since "reload" or "refresh" seems to be a common action of a browser and it
        // allows for more connections (in our model), use "DownloadBrowse"
        d->m_layerDecorator.downloadStackedTile( id, DownloadBrowse );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLinearRing& itInnerBoundary: innerBoundaries ) {
                QVector<QPolygonF*> innerPolygonsPerBoundary;

                d->m_viewport->screenCoordinates( itInnerBoundary, innerPolygonsPerBoundary );

                for( QPolygonF* innerPolygonPerBoundary: innerPolygonsPerBoundary ) {
                    innerPolygons << innerPolygonPerBoundary;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MarbleGraphicsItem *item: d->m_children) {
                item->paintEvent( painter, viewport );
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * relation) {
                return relation->isVisible();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (GeoDataPlacemark const *a, GeoDataPlacemark const *b) {
            int const left = a->visualCategory() == GeoDataFeature::Bookmark ? -1 : a->visualCategory();
            int const right = b->visualCategory() == GeoDataFeature::Bookmark ? -1 : b->visualCategory();
            return left > right;
        }
```

#### AUTO 


```{c}
const auto playlist = geodata_cast<GeoDataPlaylist>(parentItem)
```

#### LAMBDA EXPRESSION 


```{c}
[](const Comment & a, const Comment & b) {
        return a.date() > b.date();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataPlacemark *placemark: placemarkList ) {
            const GeoDataCoordinates coordinates = placemarkIconCoordinates( placemark );
            if ( !coordinates.isValid() ) {
                continue;
            }

            int zoomLevel = placemark->zoomLevel();
            if ( zoomLevel > 20 ) {
                break;
            }

            qreal x = 0;
            qreal y = 0;

            if ( !viewLatLonAltBox.contains( coordinates ) ||
                 ! viewport->screenCoordinates( coordinates, x, y )) {
                    continue;
                }

            if ( !placemark->isGloballyVisible() ) {
                continue;
            }

            const GeoDataPlacemark::GeoDataVisualCategory visualCategory = placemark->visualCategory();

            // Skip city marks if we're not showing cities.
            if ( !m_showCities
                 && visualCategory >= GeoDataPlacemark::SmallCity
                 && visualCategory <= GeoDataPlacemark::Nation )
                continue;

            // Skip terrain marks if we're not showing terrain.
            if ( !m_showTerrain
                 && visualCategory >= GeoDataPlacemark::Mountain
                 && visualCategory <= GeoDataPlacemark::OtherTerrain )
                continue;

            // Skip other places if we're not showing other places.
            if ( !m_showOtherPlaces
                 && visualCategory >= GeoDataPlacemark::GeographicPole
                 && visualCategory <= GeoDataPlacemark::Observatory )
                continue;

            // Skip landing sites if we're not showing landing sites.
            if ( !m_showLandingSites
                 && visualCategory >= GeoDataPlacemark::MannedLandingSite
                 && visualCategory <= GeoDataPlacemark::UnmannedHardLandingSite )
                continue;

            // Skip craters if we're not showing craters.
            if ( !m_showCraters
                 && visualCategory == GeoDataPlacemark::Crater )
                continue;

            // Skip maria if we're not showing maria.
            if ( !m_showMaria
                 && visualCategory == GeoDataPlacemark::Mare )
                continue;

            if ( !m_showPlaces
                 && visualCategory >= GeoDataPlacemark::GeographicPole
                 && visualCategory <= GeoDataPlacemark::Observatory )
                continue;

            // We handled selected placemarks already, so we skip them here...
            // Assuming that only a small amount of places is selected
            // we check for the selected state after all other filters
            bool isSelected = false;
            for ( const QModelIndex &index: selection.indexes() ) {
                const GeoDataPlacemark *mark = static_cast<GeoDataPlacemark*>(qvariant_cast<GeoDataObject*>(index.data( MarblePlacemarkModel::ObjectPointerRole ) ));
                if (mark == placemark ) {
                    isSelected = true;
                    break;
                }
            }
            if ( isSelected )
                continue;

            if( layoutPlacemark( placemark, coordinates, x, y, isSelected ) ) {
                // Make sure not to draw more placemarks on the screen than
                // specified by placemarksOnScreenLimit().
                if ( placemarksOnScreenLimit( viewport->size() ) )
                    break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( EclipsesItem *item: m_model->items() ) {
            if( item->takesPlaceAt( marbleModel()->clock()->dateTime() ) ) {
                return renderItem( painter, item );
            }
        }
```

#### AUTO 


```{c}
const auto polygon = geodata_cast<GeoDataPolygon>(d->m_placemark->geometry())
```

#### AUTO 


```{c}
const auto key = dgram.data().constData() + nextIdx;
```

#### AUTO 


```{c}
auto placemark
```

#### AUTO 


```{c}
auto iter = p()->m_styleHash.constBegin();
```

#### AUTO 


```{c}
auto const & innerBoundary = innerBoundaries.at(index);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &path: m_commandlineFilePaths ) {
        m_controlView->marbleModel()->addGeoDataFile( path );
    }
```

#### AUTO 


```{c}
auto red = QColor("#cc0000");
```

#### AUTO 


```{c}
auto const & node
```

#### AUTO 


```{c}
auto const iter = placemarks.find(member.reference);
```

#### AUTO 


```{c}
auto fallBack = Qt::lightGray;
```

#### AUTO 


```{c}
auto const &tileId
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: placemarks) {
        painter->drawRect(placemark->boundingBox());
    }
```

#### AUTO 


```{c}
auto const data = originalOsmData.nodeReference(*it.value());
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &a, const QModelIndex &b) { return b < a; }
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataRelation>(feature)
```

#### RANGE FOR STATEMENT 


```{c}
for( const ReverseGeocodingRunnerPlugin *plugin: plugins ) {
        if ( ( m_marbleModel && m_marbleModel->workOffline() && !plugin->canWorkOffline() ) ) {
            continue;
        }

        if ( !plugin->canWork() ) {
            continue;
        }

        if ( m_marbleModel && !plugin->supportsCelestialBody( m_marbleModel->planet()->id() ) )
        {
            continue;
        }

        result << plugin;
    }
```

#### AUTO 


```{c}
auto const & relation
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFloatItem *item: m_floatItems) {
        if (!item->enabled()) {
            continue;
        }

        if (!item->isInitialized()) {
            item->initialize();
            emit renderPluginInitialized(item);
        }

        if (item->visible()) {
            item->paintEvent(painter, viewport);
        }
    }
```

#### AUTO 


```{c}
const auto folder = geodata_cast<GeoDataFolder>(feature->parent())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &segment: segments) {
        int diff = segment.second - segment.first;
        diff = diff > 0 ? diff : length + diff;
        value = value % QStringLiteral(";") % QString::number(segment.first) % QStringLiteral("+") % QString::number(diff);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
            GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
            newPlacemark->setVisible(placemark->isVisible());
            newPlacemark->setVisualCategory(placemark->visualCategory());
            T* newRing = new T;
            int index = 0;
            for(const auto &point: path) {
                GeoDataCoordinates const coordinates = point.coordinates();
                *newRing << coordinates;
                auto const originalOsmData = osmData.nodeReference(coordinates);
                if (originalOsmData.id() > 0) {
                    newPlacemark->osmData().addNodeReference(coordinates, originalOsmData);
                }
                ++index;
            }

            if (isBuilding) {
                const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
                GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
                newBuilding->multiGeometry()->clear();
                newBuilding->multiGeometry()->append(newRing);
                newPlacemark->setGeometry(newBuilding);
            } else {
                newPlacemark->setGeometry(newRing);
            }
            if (placemark->osmData().id() > 0) {
                newPlacemark->osmData().addTag(QStringLiteral("mx:oid"), QString::number(placemark->osmData().id()));
            }
            copyTags(*placemark, *newPlacemark);
            OsmObjectManager::initializeOsmData(newPlacemark);
            document->append(newPlacemark);
            osmIds << placemark->osmData().id();
        }
```

#### AUTO 


```{c}
const auto poly = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0))
```

#### RANGE FOR STATEMENT 


```{c}
for ( const OsmPlacemarkData &relationData: m_allRelations->values() ) {
        const QString relationText = relationData.tagValue("name") + QLatin1String(" (") + relationData.tagValue("type") + QLatin1Char(')');

        // Don't suggest relations the placemark is already part of
        if ( m_placemark->hasOsmData() && m_placemark->osmData().containsRelation( relationData.id() ) ) {
            continue;
        }
        QAction *newAction = new QAction( m_relationDropMenu );
        newAction->setText( relationText );
        newAction->setData( relationData.id() );
        m_relationDropMenu->addAction( newAction );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const MonavStuffEntry &entry: d->m_remoteMaps ) {
            if (entry.payload().endsWith(QLatin1Char('/') + payload)) {
                d->m_currentDownload = entry.payload();
                d->install();
                return;
            }
        }
```

#### AUTO 


```{c}
auto routes = routeGeometryValue.toArray();
```

#### AUTO 


```{c}
auto tagIter = osmData.findTag(QStringLiteral("religion"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: background->placemarkList()) {
        GeoDataPlacemark* land = new GeoDataPlacemark(*placemark);
        if (geodata_cast<GeoDataPolygon>(land->geometry())) {
            land->setOsmData(marbleLand);
        }
        mergedMap->append(land);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &cluster: clusters) {
                for (auto placemark: cluster) {
                    if (distanceSphere(peak->coordinate(), placemark->coordinate()) < maxDistance) {
                        fit = &cluster;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto tour = geodata_cast<GeoDataTour>(parentItem)
```

#### RANGE FOR STATEMENT 


```{c}
for(const PendingJob &job: m_pendingJobs) {
        resume = resume || job.m_region.id() == m_resumeId;
        if (resume) {
            addJob(job);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
        GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
        newPlacemark->setVisible(placemark->isVisible());
        newPlacemark->setVisualCategory(placemark->visualCategory());
        GeoDataLinearRing outerRing;
        OsmPlacemarkData const & placemarkOsmData = placemark->osmData();
        OsmPlacemarkData & newPlacemarkOsmData = newPlacemark->osmData();
        int index = -1;
        OsmPlacemarkData const & outerRingOsmData = placemarkOsmData.memberReference(index);
        OsmPlacemarkData & newOuterRingOsmData = newPlacemarkOsmData.memberReference(index);
        int nodeIndex = 0;
        for(const auto &point: path) {
            GeoDataCoordinates const coordinates = point.coordinates();
            outerRing << coordinates;
            auto const originalOsmData = outerRingOsmData.nodeReference(coordinates);
            if (originalOsmData.id() > 0) {
                newOuterRingOsmData.addNodeReference(coordinates, originalOsmData);
            }
            ++nodeIndex;
        }

        GeoDataPolygon* newPolygon = new GeoDataPolygon;
        newPolygon->setOuterBoundary(outerRing);
        newPlacemark->setGeometry(newPolygon);
        if (placemarkOsmData.id() > 0) {
            newPlacemarkOsmData.addTag(QStringLiteral("mx:oid"), QString::number(placemarkOsmData.id()));
        }
        copyTags(placemarkOsmData, newPlacemarkOsmData);
        copyTags(outerRingOsmData, newOuterRingOsmData);
        if (outerRingOsmData.id() > 0) {
            newOuterRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(outerRingOsmData.id()));
        }

        auto const & innerBoundaries = polygon->innerBoundaries();
        for (index = 0; index < innerBoundaries.size(); ++index) {
            auto const & innerBoundary = innerBoundaries.at(index);
            if (minArea > 0.0 && area(innerBoundary) < minArea) {
                continue;
            }

            auto const & innerRingOsmData = placemarkOsmData.memberReference(index);
            clipper.Clear();
            clipper.AddPath(path, ptClip, true);
            Path innerPath;
            for(auto const & node: innerBoundary) {
                innerPath << IntPoint(&node);
            }
            clipper.AddPath(innerPath, ptSubject, true);
            Paths innerPaths;
            clipper.Execute(ctIntersection, innerPaths);
            for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                nodeIndex = 0;
                for(const auto &point: innerPath) {
                    GeoDataCoordinates const coordinates = point.coordinates();
                    innerRing << coordinates;
                    auto const originalOsmData = innerRingOsmData.nodeReference(coordinates);
                    if (originalOsmData.id() > 0) {
                        newInnerRingOsmData.addNodeReference(coordinates, originalOsmData);
                    }
                    ++nodeIndex;
                }
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
        }

        OsmObjectManager::initializeOsmData(newPlacemark);
        document->append(newPlacemark);
        osmIds << placemark->osmData().id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLineString & string: outer ) {
        if ( string.isEmpty() || !( string.first() == string.last() ) ) {
            qDebug() << "Ignoring open polygon in relation " << relation.name << ". Check data.";
            continue;
        }

        GeoDataPolygon polygon;
        polygon.setOuterBoundary(GeoDataLinearRing(string));
        Q_ASSERT( polygon.outerBoundary().size() > 0 );

        for( const GeoDataLineString & hole: inner ) {
            if ( contains<GeoDataLinearRing, GeoDataLineString>( polygon.outerBoundary(), hole ) ) {
                polygon.appendInnerBoundary(GeoDataLinearRing(hole));
            }
        }

        OsmOsmRegion region;
        region.region.setName( relation.name );
        region.region.setGeometry( polygon );
        region.region.setAdminLevel( relation.adminLevel );
        qDebug() << "Adding administrative region " << relation.name;
        m_osmOsmRegions.push_back( region );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( RenderPlugin *plugin: renderPlugins() ) {
        if (plugin->nameId() == QLatin1String("atmosphere")) {
            plugin->setVisible( visible );
        }
    }
```

#### AUTO 


```{c}
auto centroid = QPointF(0.0, 0.0);
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractWeatherService *service: m_services ) {
        service->parseFile( file );
    }
```

#### AUTO 


```{c}
auto msg = dgram.makeReply(errorMsg);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: cluster) {
                    if (peak->coordinate().sphericalDistanceTo(placemark->coordinate()) < maxDistance) {
                        fit = &cluster;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &format: formats ) {
        QString const result = MarbleDirs::path( audioTemplate.arg( name ).arg( format ) );
        if ( !result.isEmpty() ) {
            return result;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: converter.relations()) {
        if (relation.first->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            auto placemark = static_cast<const GeoDataPlacemark*>(relation.first);
            Q_ASSERT(placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType);
            auto polygon = static_cast<const GeoDataPolygon*>(placemark->geometry());
            OsmRelationTagWriter::writeMultipolygon(*polygon, relation.second, writer );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmPlacemark &placemark: placemarks ) {
        GeoDataPlacemark* hit = new GeoDataPlacemark;
        hit->setName( placemark.name() );
        if ( placemark.category() == OsmPlacemark::Address && !placemark.houseNumber().isEmpty() ) {
            hit->setName(hit->name() + QLatin1Char(' ') + placemark.houseNumber());
        }
        if ( !placemark.additionalInformation().isEmpty() ) {
            hit->setName(hit->name() + QLatin1Char('(') + placemark.additionalInformation() + QLatin1Char(')'));
        }
        if ( placemark.category() != OsmPlacemark::UnknownCategory ) {
            hit->setVisualCategory( m_categoryMap[placemark.category()] );
        }
        hit->setGeometry( new GeoDataPoint( placemark.longitude(), placemark.latitude(), 0.0, GeoDataCoordinates::Degree ) );
        result << hit;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &member: m_members) {
        if (roles.contains(member.role)) {
            if (!ways.contains(member.reference)) {
                // A way is missing. Return nothing.
                return OsmRings();
            }
            roleMembers << member.reference;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
            if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
                auto relation = static_cast<GeoDataRelation*>(feature);
                relation->setVisible(showRelation(relation));
                for (auto member: relation->members()) {
                    relations[member] << relation;
                }
            }
        }
```

#### AUTO 


```{c}
auto & tileList = d->m_tiledItems[key];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index: indexes) {
        sourceIndexes << mapToSource(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* placemark: instructions ) {
        result->append( placemark );
    }
```

#### AUTO 


```{c}
auto const iter = stringTable.constFind(pair);
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
            painterPath.addPolygon( *itPolygon );
        }
```

#### AUTO 


```{c}
const auto &text
```

#### AUTO 


```{c}
auto const end = d->m_styleHash.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &layer: d->m_styleBuilder->renderOrder()) {
            GeometryLayerPrivate::PaintFragments & layerItems = paintFragments[layer];
            std::sort(layerItems.negative.begin(), layerItems.negative.end(), GeoGraphicsItem::zValueLessThan);
            // The idea here is that layerItems.null has most items and does not need to be sorted by z-value
            // since they are all equal (=0). We do sort them by style pointer though for batch rendering
            std::sort(layerItems.null.begin(), layerItems.null.end(), GeoGraphicsItem::styleLessThan);
            std::sort(layerItems.positive.begin(), layerItems.positive.end(), GeoGraphicsItem::zValueAndStyleLessThan);
            auto const count = layerItems.negative.size() + layerItems.null.size() + layerItems.positive.size();
            d->m_cachedPaintFragments[layer].reserve(count);
            d->m_cachedPaintFragments[layer] << layerItems.negative;
            d->m_cachedPaintFragments[layer] << layerItems.null;
            d->m_cachedPaintFragments[layer] << layerItems.positive;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QActionGroup *ag: *tmp_actionGroups ) {
                plugActionList( "plugins_menuactionlist", ag->actions() );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &baseDir: baseDirs ) {
        const QString base = baseDir + QLatin1String("/audio/speakers/");

        QDir::Filters filter = QDir::Readable | QDir::Dirs | QDir::NoDotAndDotDot;
        QFileInfoList subdirs = QDir( base ).entryInfoList( filter, QDir::Name );
        for( const QFileInfo &file: subdirs ) {
            SpeakersModelItem item;
            item.m_file = file;
            m_speakers << item;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[categories] (GeoDataPlacemark* placemark) {
        return categories.contains(placemark->visualCategory()); }
```

#### RANGE FOR STATEMENT 


```{c}
for(QString const &line: output) {
        if (line.startsWith("lon min:")) {
            boundingBox.setWest(line.mid(8).toDouble(), GeoDataCoordinates::Degree);
        } else if (line.startsWith("lon max")) {
            boundingBox.setEast(line.mid(8).toDouble(), GeoDataCoordinates::Degree);
        } else if (line.startsWith("lat min:")) {
            boundingBox.setSouth(line.mid(8).toDouble(), GeoDataCoordinates::Degree);
        } else if (line.startsWith("lat max:")) {
            boundingBox.setNorth(line.mid(8).toDouble(), GeoDataCoordinates::Degree);
        }
    }
```

#### AUTO 


```{c}
auto const boundingBox = loader.boundingBox(inputFileName);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QSharedPointer<LinkedPoint>& A, const QSharedPointer<LinkedPoint>& B) {
                return A->point().x() < B->point().x();
            }
```

#### AUTO 


```{c}
const auto track = geodata_cast<GeoDataTrack>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto layer : m_mapTheme->map()->layers()) {
        if (layer->backend() != dgml::dgmlValue_geodata
            && layer->backend() != dgml::dgmlValue_vector) {
            continue;
        }

        for (auto dataset: layer->datasets()) {
            auto sceneData = dynamic_cast<const GeoSceneGeodata *>(dataset);
            if (sceneData != nullptr && sceneData->sourceFile() == filePath) {
                data = sceneData;
                break;
            }
        }

        if (data) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto *renderPlugin: d->m_renderPlugins ) {
            if ( renderPlugin && renderPlugin->renderPosition().contains( renderPosition ) ) {
                if ( renderPlugin->enabled() && renderPlugin->visible() ) {
                    if ( !renderPlugin->isInitialized() ) {
                        renderPlugin->initialize();
                        emit renderPluginInitialized( renderPlugin );
                    }
                    layers.push_back( renderPlugin );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoSceneItem *item: section->items()) {

            // checkbox for item
            QString checkBoxString;
            if (item->checkable()) {
                QString const checked = d->m_checkBoxMap[item->connectTo()] ? "checked" : "";
                checkBoxString = QLatin1String(
                        "<input type=\"checkbox\" "
                        "onchange=\"Marble.setCheckedProperty(this.name, this.checked);\" ")
                        + checked + QLatin1String(" name=\"") + item->connectTo() + QLatin1String("\" />");

            }

            // pixmap and text
            QString src;
            QString styleDiv;
            int pixmapWidth = 24;
            int pixmapHeight = 12;
            if (!item->icon()->pixmap().isEmpty()) {
                QString path = MarbleDirs::path( item->icon()->pixmap() );
                const QPixmap oncePixmap(path);
                pixmapWidth = oncePixmap.width();
                pixmapHeight = oncePixmap.height();
                src = QUrl::fromLocalFile( path ).toString();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px;");
            }
            // NOTICE. There are some pixmaps without image, so we should
            //         create just a plain rectangle with set color
            else if (item->icon()->color().isValid()) {
                const QColor color = item->icon()->color();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px; background-color: ") + color.name() + QLatin1Char(';');
            }
            const QString text = QCoreApplication::translate("DGML", item->text().toUtf8().constData());
            QString html = QLatin1String(
                    "<div class=\"legend-entry\">"
                    "  <label>") + checkBoxString + QLatin1String(
                    "    <img class=\"image-pic\" src=\"") + src + QLatin1String("\" style=\"") + styleDiv + QLatin1String("\"/>"
                    "    <span class=\"notation\">") + text + QLatin1String("</span>"
                    "  </label>"
                    "</div>");
            customLegendString += html;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for( int node: way.nodes ) {
                m_referencedNodes << node;
            }
```

#### AUTO 


```{c}
auto & items = m_osmLineStringItems[placemark->osmData().id()];
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* newPlacemark: newFolder->placemarkList() ) {
            bool added = skipAll;

            GeoDataCoordinates newCoordinate = newPlacemark->coordinate();
            GeoDataPlacemark *existingPlacemark = m_manager->bookmarkAt( m_manager->document(), newCoordinate );
            if ( existingPlacemark ) {
                if ( skipAll ) {
                    continue;
                }

                // Avoid message boxes for equal bookmarks, just skip them
                if ( existingPlacemark->name() == newPlacemark->name() &&
                    existingPlacemark->description() == newPlacemark->description() ) {
                    added = true;
                    continue;
                }

                QPointer<QMessageBox> messageBox = new QMessageBox( m_parent );
                QString const intro = tr( "The file contains a bookmark that already exists among your Bookmarks." );
                QString const newBookmark = tr( "Imported bookmark" );
                QString const existingBookmark = tr( "Existing bookmark" );
                QString const question = tr( "Do you want to replace the existing bookmark with the imported one?" );
                QString html = QLatin1String("<p>%1</p><table><tr><td>%2</td><td><b>%3 / %4</b></td></tr>"
                                                "<tr><td>%5</td><td><b>%6 / %7</b></td></tr></table><p>%8</p>");
                html = html.arg( intro ).arg( existingBookmark ).arg( existingFolder->name() );
                html = html.arg( existingPlacemark->name() ).arg( newBookmark ).arg( newFolder->name() );
                html = html.arg( newPlacemark->name() ).arg( question );
                messageBox->setText( html );

                QAbstractButton *replaceButton    = messageBox->addButton(tr( "Replace" ),     QMessageBox::ActionRole );
                QAbstractButton *replaceAllButton = messageBox->addButton(tr( "Replace All" ), QMessageBox::ActionRole );
                QAbstractButton *skipButton       = messageBox->addButton(tr( "Skip" ),        QMessageBox::ActionRole );
                QAbstractButton *skipAllButton    = messageBox->addButton(tr( "Skip All" ),    QMessageBox::ActionRole );
                                                    messageBox->addButton( QMessageBox::Cancel );
                messageBox->setIcon( QMessageBox::Question );

                if ( !replaceAll ) {
                    messageBox->exec();
                }
                if ( messageBox->clickedButton() == replaceAllButton ) {
                    replaceAll = true;
                } else if ( messageBox->clickedButton() == skipAllButton ) {
                    skipAll = true;
                    added = true;
                } else if ( messageBox->clickedButton() == skipButton ) {
                    added = true;
                    delete messageBox;
                    continue;
                } else if ( messageBox->clickedButton() != replaceButton ) {
                    delete messageBox;
                    return;
                }

                if ( messageBox->clickedButton() == replaceButton || replaceAll ) {
                    m_manager->removeBookmark( existingPlacemark );
                    m_manager->addBookmark( existingFolder, *newPlacemark );

                    mDebug() << "Placemark " << newPlacemark->name() << " replaces " << existingPlacemark->name();
                    added = true;
                    delete messageBox;
                    break;
                }
                delete messageBox;
            }

            if ( !added ) {
                m_manager->addBookmark( existingFolder, *newPlacemark );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
            GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
            newPlacemark->setVisible(placemark->isVisible());
            newPlacemark->setVisualCategory(placemark->visualCategory());
            T* newRing = new T;
            int index = 0;
            for(const auto &point: path) {
                GeoDataCoordinates const coordinates = point.coordinates();
                *newRing << coordinates;
                auto const originalOsmData = osmData.nodeReference(coordinates);
                if (originalOsmData.id() > 0) {
                    newPlacemark->osmData().addNodeReference(coordinates, originalOsmData);
                }
                ++index;
            }

            newPlacemark->setGeometry(newRing);
            if (placemark->osmData().id() > 0) {
                newPlacemark->osmData().addTag(QStringLiteral("mx:oid"), QString::number(placemark->osmData().id()));
            }
            copyTags(*placemark, *newPlacemark);
            OsmObjectManager::initializeOsmData(newPlacemark);
            document->append(newPlacemark);
            osmIds << placemark->osmData().id();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::GeoDataFolder* folder: bookmarks->folderList() ) {
        for( Marble::GeoDataPlacemark * placemark: folder->placemarkList() ) {
            if ( distanceSphere( placemark->coordinate(), compareTo ) * planetRadius < 5 ) {
                manager->removeBookmark( placemark );
                return;
            }
        }
    }
```

#### AUTO 


```{c}
auto const & tag
```

#### AUTO 


```{c}
auto lineStyle = style->lineStyle();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &format: formats ) {
            QString const result = audioTemplate.arg( m_speaker ).arg( name ).arg( format );
            QFileInfo audioFile( result );
            if ( audioFile.exists() ) {
                return result;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &key: profile.pluginSettings().keys() ) {
             settings.beginGroup( key );
             settings.setValue( "Enabled", true );
             for ( const QString& settingKey: profile.pluginSettings()[ key ].keys() ) {
                 Q_ASSERT(settingKey != QLatin1String("Enabled"));
                 settings.setValue( settingKey, profile.pluginSettings()[ key ][ settingKey ] );
             }
             settings.endGroup();
         }
```

#### AUTO 


```{c}
const auto cacheDirectory = backend.configValue(QStringLiteral("cache-directory")).toString();
```

#### AUTO 


```{c}
auto const category = GeoDataPlacemark::GeoDataVisualCategory(i);
```

#### AUTO 


```{c}
auto const & outerRing = outer[i];
```

#### RANGE FOR STATEMENT 


```{c}
for(const RenderPlugin *existing: m_renderPlugins) {
            if (existing->nameId() == factory->nameId()) {
                alreadyCreated = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const PositionProviderPlugin* plugin: m_positionProviderPlugins ) {
        if ( plugin->guiString() == provider ) {
            m_currentLocationUi.locationLabel->setEnabled( true );
            PositionProviderPlugin* instance = plugin->newInstance();
            PositionTracking *tracking = m_widget->model()->positionTracking();
            tracking->setPositionProviderPlugin( instance );
            m_widget->update();
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataLinearRing &innerBoundary: innerBoundaries) {
        QVector<QPolygonF*> innerPolygonsPerBoundary;
        viewport->screenCoordinates(innerBoundary, innerPolygonsPerBoundary);

        innerPolygons.reserve(innerPolygons.size() + innerPolygonsPerBoundary.size());
        for( QPolygonF* innerPolygonPerBoundary: innerPolygonsPerBoundary ) {
            innerPolygons << innerPolygonPerBoundary;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (VectorTileModel *mapper: m_activeTileModels) {
        mapper->updateTile(tileId, document);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction* action: m_panelActions ) {
        panelMenuActions << action;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataPlacemark *placemark: bookmarks ) {
        QAction *bookmarkAction = new QAction( placemark->name(), this );
        QVariant var;

        const GeoDataLookAt* lookAt = placemark->lookAt();
        if ( !lookAt ) {
            GeoDataCoordinates coordinates = placemark->coordinate();
            GeoDataLookAt coordinateToLookAt;
            coordinateToLookAt.setCoordinates( coordinates );
            coordinateToLookAt.setRange( marbleWidget()->lookAt().range() );
            var.setValue( coordinateToLookAt );
        } else {
            var.setValue( *lookAt );
        }
        bookmarkAction->setData( var );
        bookmarksListMenu->addAction( bookmarkAction );
    }
```

#### AUTO 


```{c}
auto const visualCategory = parameters.placemark->visualCategory();
```

#### AUTO 


```{c}
auto const viewLatLonAltBox = viewport->viewLatLonAltBox();
```

#### AUTO 


```{c}
auto it=p()->m_vector.constBegin(), end = p()->m_vector.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoSceneLayer *layer: d->m_mapTheme->map()->layers() ) {
        if ( layer->backend() != dgml::dgmlValue_geodata
             && layer->backend() != dgml::dgmlValue_vector )
            continue;

        // look for datasets which are different from currentDatasets
        for ( const GeoSceneAbstractDataset *dataset: layer->datasets() ) {
            const GeoSceneGeodata *data = dynamic_cast<const GeoSceneGeodata*>( dataset );
            Q_ASSERT( data );
            bool skip = false;
            GeoDataDocument *doc = nullptr;
            for ( int i = 0; i < currentDatasets.size(); ++i ) {
                if ( currentDatasets[i] == *data ) {
                    currentDatasets.removeAt( i );
                    skip = true;
                    break;
                }
                /*
                 * If the sourcefile of data matches any in the currentDatasets then there
                 * is no need to parse the file again just update the style
                 * i.e. <brush> and <pen> values of already parsed file. assignNewStyle() does that
                 */
                if ( currentDatasets[i].sourceFile() == data->sourceFile() ) {
                    doc = d->m_fileManager.at(data->sourceFile());
                    currentDatasets.removeAt(i);
                }
            }
            if ( skip ) {
                continue;
            }

            if (doc) {
                d->assignFillColors(doc, *data);
            }
            else {
                const QString filename = data->sourceFile();
                const QString property = data->property();
                const QPen pen = data->pen();
                const QBrush brush = data->brush();
                GeoDataStyle::Ptr style;
                const int renderOrder = data->renderOrder();

                /*
                 * data->colors() are the colorMap values from dgml file. If this is not
                 * empty then we are supposed to assign every placemark a different style
                 * by giving it a color from colorMap values based on color index
                 * of that placemark. See assignFillColors() for details. So, we need to
                 * send an empty style to fileManeger otherwise the FileLoader::createFilterProperties()
                 * will overwrite the parsed value of color index ( GeoDataPolyStyle::d->m_colorIndex ).
                 */
                if ( data->colors().isEmpty() ) {
                    GeoDataLineStyle lineStyle( pen.color() );
                    lineStyle.setPenStyle( pen.style() );
                    lineStyle.setWidth( pen.width() );
                    GeoDataPolyStyle polyStyle( brush.color() );
                    polyStyle.setFill( true );
                    style = GeoDataStyle::Ptr(new GeoDataStyle);
                    style->setLineStyle( lineStyle );
                    style->setPolyStyle( polyStyle );
                    style->setId(QStringLiteral("default"));
                }

                fileList << filename;
                propertyList << property;
                styleList << style;
                renderOrderList << renderOrder;
            }
        }
    }
```

#### AUTO 


```{c}
auto reply = std::move(req.reply);
```

#### AUTO 


```{c}
auto mergeMap = open(parser.value("merge"), manager);
```

#### AUTO 


```{c}
auto const paths = QStringList() << i18nDir << relativeDir << QDir::currentPath();
```

#### AUTO 


```{c}
auto placemark = static_cast<const GeoDataRelation*>(relation.first);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *layer: textureLayers ) {
        const TileId tileId( layer->sourceDir(), stackedTileId.zoomLevel(),
                             stackedTileId.x(), stackedTileId.y() );

        mDebug() << Q_FUNC_INFO << layer->sourceDir() << tileId << layer->tileSize() << layer->fileFormat();

        // Blending (how to merge the images into an only image)
        const Blending *blending = d->m_blendingFactory.findBlending( layer->blending() );
        if ( blending == 0 && !layer->blending().isEmpty() ) {
            mDebug() << Q_FUNC_INFO << "could not find blending" << layer->blending();
        }

        const GeoSceneTextureTileDataset *const textureLayer = static_cast<const GeoSceneTextureTileDataset *>( layer );
        const QImage tileImage = d->m_tileLoader->loadTileImage( textureLayer, tileId, DownloadBrowse );

        QSharedPointer<TextureTile> tile( new TextureTile( tileId, tileImage, blending ) );
        tiles.append( tile );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const OsmPolygon &a, const OsmPolygon &b) { return a.second.id() < b.second.id(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & item: d->m_cachedDefaultLayer) {
        item.second->paint(painter, viewport, item.first, d->m_tileLevel);
    }
```

#### AUTO 


```{c}
auto const viaValue = m_relations.at(index.row())->osmData().tagValue(QStringLiteral("via"));
```

#### AUTO 


```{c}
auto const coordinates = GeoDataCoordinates(lon, lat);
```

#### AUTO 


```{c}
const auto prevRing = geodata_cast<GeoDataLinearRing>(&building->multiGeometry()->at(0))
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataPlacemark>(object)
```

#### LAMBDA EXPRESSION 


```{c}
[](GeoDataPlacemark* a, GeoDataPlacemark* b) {
            return a->coordinate().altitude() > b->coordinate().altitude();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &placemark: m_wayPlacemarks) {
        document()->append(new GeoDataPlacemark(*placemark));
    }
```

#### AUTO 


```{c}
auto const name = QString("%1/%2/%3").arg(mapTile.zoomLevel()).arg(mapTile.x()).arg(mapTile.y());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: hidden) {
        bool const inside = latLonAltBox.contains(placemark->coordinates());
        painter->setPen(QPen(QColor(inside ? Qt::red : Qt::darkYellow)));
        painter->drawRect(placemark->boundingBox());
    }
```

#### AUTO 


```{c}
auto const iter = m_tags.constFind(key);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
        if (auto placemark = geodata_cast<GeoDataPlacemark>(feature)) {
            // If the placemark's osmData is not complete, it is initialized by the OsmObjectManager
            OsmObjectManager::initializeOsmData( placemark );
            const OsmPlacemarkData & osmData = placemark->osmData();

            if (geodata_cast<GeoDataPoint>(placemark->geometry())) {
                m_nodes << OsmConverter::Node(placemark->coordinate(), osmData);
            } else if (const auto lineString = geodata_cast<GeoDataLineString>(placemark->geometry())) {
                for (auto const &coordinates: *lineString) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(lineString, osmData);
            } else if (const auto linearRing = geodata_cast<GeoDataLinearRing>(placemark->geometry())) {
                processLinearRing(linearRing, osmData);
            } else if (const auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry())) {
                processPolygon(polygon, osmData, placemark);
            } else if (const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry())) {
                if (const auto linearRing = geodata_cast<GeoDataLinearRing>(&building->multiGeometry()->at(0))) {
                    processLinearRing(linearRing, osmData);
                } else if (const auto polygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0))) {
                    processPolygon(polygon, osmData, placemark);
                }
            }
        } else if (const auto placemark = geodata_cast<GeoDataRelation>(feature)) {
            m_relations.append(OsmConverter::Relation(placemark, placemark->osmData()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const GeoSceneGeodata &data: currentDatasets) {
        d->m_fileManager.removeFile( data.sourceFile() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: innerRing) {
                        m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
                    }
```

#### AUTO 


```{c}
auto style = new OutlinedStyle;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex &index: selection.indexes() ) {
                const GeoDataPlacemark *mark = static_cast<GeoDataPlacemark*>(qvariant_cast<GeoDataObject*>(index.data( MarblePlacemarkModel::ObjectPointerRole ) ));
                if (mark == placemark ) {
                    isSelected = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto const now = QDateTime::currentDateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: files ) {
            QDomNode fileNode = node.appendChild( m_registryDocument.createElement( "installedfile" ) );
            fileNode.appendChild(m_registryDocument.createTextNode(m_targetDirectory + QLatin1Char('/') + file));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QRectF &itemRect: (*i)->boundingRects() ) {
                        if ( rect.intersects( itemRect ) )
                            collides = true;
                    }
```

#### AUTO 


```{c}
auto plugin = qobject_cast<Plugin>( obj );
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* outerPolygon:  m_cachedOuterPolygons ) {
                painter->drawPolyline( *outerPolygon );
            }
```

#### AUTO 


```{c}
auto jsonRef
```

#### AUTO 


```{c}
auto iter = relation->osmData().relationReferencesBegin(), end = relation->osmData().relationReferencesEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: polygon->outerBoundary()) {
        path << IntPoint(&node);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(VisiblePlacemark* mark: m_paintOrder) {
        if (mark->labelRect().contains(pos) || mark->symbolRect().contains(pos)) {
            m_lastPlacemarkLabelRect = mark->labelRect();
            m_lastPlacemarkSymbolRect = mark->symbolRect();
            m_lastPlacemarkAvailable = true;
            return true;
        }
    }
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(container->child(i))
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &point: path) {
            const auto it = coordMap.find(std::make_pair(point.X, point.Y));
            if (it != coordMap.end()) {
                *ring << *it.value();
                auto const data = originalOsmData.nodeReference(*it.value());
                if (data.id() > 0) {
                    newOsmData.addNodeReference(*it.value(), data);
                }
            } else {
                *ring << pointToCoordinate(point);
            }
            ++index;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QActionGroup* ag: *tmp_toolbarActionGroups ) {
                plugActionList( "plugins_actionlist", ag->actions() );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems.positive) {
            if (item->contains(curpos, viewport)) {
                result << item->feature();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& childDir: childDirs ) {
                    dirs.push(sourceDirPath + QLatin1Char('/') + childDir);
                    progressSliceSizeStack.push( childSliceSize );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( int node: m_ways[id].nodes ) {
        if ( !m_coordinates.contains( node ) ) {
            qDebug() << "Skipping unknown node " << node << ". Check data.";
        } else {
            const Coordinate &nd = m_coordinates[node];
            GeoDataCoordinates coordinates( nd.lon, nd.lat, 0.0, GeoDataCoordinates::Degree );
            way << coordinates;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataCoordinates & itCoords : d->m_vector ) {
        QVariantMap map;
        map.insert("lon", itCoords.longitude(GeoDataCoordinates::Degree));
        map.insert("lat", itCoords.latitude(GeoDataCoordinates::Degree));
        map.insert("alt", itCoords.altitude());
        variantList << map;
    }
```

#### AUTO 


```{c}
auto iter=originalPlacemarkData.tagsBegin(), end=originalPlacemarkData.tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QFileInfo& fileInfo: fileInfoList ) {
            QFile file( fileInfo.absoluteFilePath() );
            bool removed = file.remove();
            if( !removed ) {
                mDebug() << "Could not delete" << file.fileName() <<
                         "Make sure you have sufficient permissions.";
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataLinearRing &innerRing: innerRings ) {
        QVector<GeoDataCoordinates>::ConstIterator itBegin = innerRing.constBegin();
        QVector<GeoDataCoordinates>::ConstIterator itEnd = innerRing.constEnd();
        QVector<PolylineNode> innerNodes;
        innerNodes.reserve(innerRing.size());

        for ( ; itBegin != itEnd; ++itBegin ) {
            const PolylineNode newNode = PolylineNode( painter->regionFromEllipse( *itBegin, regularDim, regularDim ) );
            innerNodes.append( newNode );
        }
        m_innerNodesList.append( innerNodes );
    }
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(feature)
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &subdir: subdirs ) {
        removeDirectoryRecursively(path + QLatin1Char('/') + subdir);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon: m_cachedOuterPolygons) {
        if (polygon->containsPoint(point, Qt::OddEvenFill)) {
            for (auto polygon: m_cachedInnerPolygons) {
                if (polygon->containsPoint(point, Qt::OddEvenFill)) {
                    return false;
                }
            }
            return true;
        }
    }
```

#### AUTO 


```{c}
auto const & b = polygon[i+1];
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataFolder *folder: container->folderList() ) {
        GeoDataPlacemark *placemark = bookmarkAt(folder, coordinate);
        if ( placemark )
            return placemark;
    }
```

#### AUTO 


```{c}
const auto container = dynamic_cast<const GeoDataContainer *>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: outerRing) {
                    m_nodes << OsmConverter::Node(coordinates, outerRingOsmData.nodeReference(coordinates));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& symbol: m_minutesLocale) {
        m_minutesExp += QLatin1Char('|') + QRegularExpression::escape(symbol);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder *newFolder: source->folderList() ) {
        GeoDataFolder *existingFolder = m_manager->addNewBookmarkFolder(destination, newFolder->name());
        importBookmarksRecursively(newFolder, existingFolder, skipAll, replaceAll);
        for( GeoDataPlacemark* newPlacemark: newFolder->placemarkList() ) {
            bool added = skipAll;

            GeoDataCoordinates newCoordinate = newPlacemark->coordinate();
            GeoDataPlacemark *existingPlacemark = m_manager->bookmarkAt( m_manager->document(), newCoordinate );
            if ( existingPlacemark ) {
                if ( skipAll ) {
                    continue;
                }

                // Avoid message boxes for equal bookmarks, just skip them
                if ( existingPlacemark->name() == newPlacemark->name() &&
                    existingPlacemark->description() == newPlacemark->description() ) {
                    continue;
                }

                QPointer<QMessageBox> messageBox = new QMessageBox( m_parent );
                QString const intro = tr( "The file contains a bookmark that already exists among your Bookmarks." );
                QString const newBookmark = tr( "Imported bookmark" );
                QString const existingBookmark = tr( "Existing bookmark" );
                QString const question = tr( "Do you want to replace the existing bookmark with the imported one?" );
                QString html = QLatin1String("<p>%1</p><table><tr><td>%2</td><td><b>%3 / %4</b></td></tr>"
                                                "<tr><td>%5</td><td><b>%6 / %7</b></td></tr></table><p>%8</p>");
                html = html.arg( intro ).arg( existingBookmark ).arg( existingFolder->name() );
                html = html.arg( existingPlacemark->name() ).arg( newBookmark ).arg( newFolder->name() );
                html = html.arg( newPlacemark->name() ).arg( question );
                messageBox->setText( html );

                QAbstractButton *replaceButton    = messageBox->addButton(tr( "Replace" ),     QMessageBox::ActionRole );
                QAbstractButton *replaceAllButton = messageBox->addButton(tr( "Replace All" ), QMessageBox::ActionRole );
                QAbstractButton *skipButton       = messageBox->addButton(tr( "Skip" ),        QMessageBox::ActionRole );
                QAbstractButton *skipAllButton    = messageBox->addButton(tr( "Skip All" ),    QMessageBox::ActionRole );
                                                    messageBox->addButton( QMessageBox::Cancel );
                messageBox->setIcon( QMessageBox::Question );

                if ( !replaceAll ) {
                    messageBox->exec();
                }
                if ( messageBox->clickedButton() == replaceAllButton ) {
                    replaceAll = true;
                } else if ( messageBox->clickedButton() == skipAllButton ) {
                    skipAll = true;
                    added = true;
                } else if ( messageBox->clickedButton() == skipButton ) {
                    delete messageBox;
                    continue;
                } else if ( messageBox->clickedButton() != replaceButton ) {
                    delete messageBox;
                    return;
                }

                if ( messageBox->clickedButton() == replaceButton || replaceAll ) {
                    m_manager->removeBookmark( existingPlacemark );
                    m_manager->addBookmark( existingFolder, *newPlacemark );

                    mDebug() << "Placemark " << newPlacemark->name() << " replaces " << existingPlacemark->name();
                    delete messageBox;
                    break;
                }
                delete messageBox;
            }

            if ( !added ) {
                m_manager->addBookmark( existingFolder, *newPlacemark );
            }
        }
    }
```

#### AUTO 


```{c}
auto const popularity = placemark->placemark()->popularity();
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& dir: dirs) {
        // collect simple letters
        if ((dir.length() == 1) && (QLatin1Char('a')<=dir.at(0)) && (dir.at(0)<=QLatin1Char('z'))) {
            simpleLetters += dir;
            continue;
        }

        // okay to add '|' also for last, separates from firstLetters
        fullNamesExp += QRegularExpression::escape(dir) + QLatin1Char('|');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* outerRoof: m_cachedOuterRoofPolygons ) {
                painter->drawPolyline( *outerRoof );
            }
```

#### AUTO 


```{c}
auto lookAt = geodata_cast<GeoDataLookAt>(flyToElement()->view())
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileInfo& fi: allFiles) {
        const QString absPath = destinationDir + QDir::separator() + fi.filePath;
        if (fi.isDir) {
            if (!baseDir.mkpath(fi.filePath))
                return false;
            if (!QFile::setPermissions(absPath, fi.permissions))
                return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: doc->featureList()) {
                if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
                    auto relation = static_cast<GeoDataRelation*>(feature);
                    relation->setVisible(showRelation(relation));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractWeatherService* service: m_services ) {
        service->setMarbleWidget( widget );
    }
```

#### AUTO 


```{c}
const auto polygon = geodata_cast<GeoDataPolygon>(placemark()->geometry())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
        if (feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            GeoDataPlacemark* placemark = static_cast<GeoDataPlacemark*>(feature);
            // If the placemark's osmData is not complete, it is initialized by the OsmObjectManager
            OsmObjectManager::initializeOsmData( placemark );
            const OsmPlacemarkData & osmData = placemark->osmData();

            if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPointType ) {
                m_nodes << OsmConverter::Node(placemark->coordinate(), osmData);
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataLineStringType ) {
                const GeoDataLineString* lineString = static_cast<const GeoDataLineString*>( placemark->geometry() );
                for (auto const &coordinates: *lineString) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(lineString, osmData);
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataLinearRingType ) {
                const GeoDataLinearRing* linearRing = static_cast<const GeoDataLinearRing*>( placemark->geometry() );
                for (auto const &coordinates: *linearRing) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(linearRing, osmData);
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType ) {
                const GeoDataPolygon *polygon = static_cast<const GeoDataPolygon*>( placemark->geometry() );
                int index = -1;

                // Writing all the outerRing's nodes
                const GeoDataLinearRing &outerRing = polygon->outerBoundary();
                const OsmPlacemarkData outerRingOsmData = osmData.memberReference( index );
                for (auto const &coordinates: outerRing) {
                    m_nodes << OsmConverter::Node(coordinates, outerRingOsmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(&outerRing, outerRingOsmData);

                // Writing all nodes for each innerRing
                for (auto const &innerRing: polygon->innerBoundaries() ) {
                    ++index;
                    const OsmPlacemarkData innerRingOsmData = osmData.memberReference( index );
                    for (auto const &coordinates: innerRing) {
                        m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
                    }
                    m_ways << OsmConverter::Way(&innerRing, innerRingOsmData);
                }
                m_relations.append(OsmConverter::Relation(placemark, osmData));
            }
        } else if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
            GeoDataRelation* placemark = static_cast<GeoDataRelation*>(feature);
            m_relations.append(OsmConverter::Relation(placemark, placemark->osmData()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRegion &region: m_regionList ) {
        if ( region.contains( eventPos ) ) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto const coordinates = GeoDataCoordinates(lon, lat, 0.0, GeoDataCoordinates::Degree);
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemB: m_diffB ) {
                if (EARTH_RADIUS * itemA.m_placemarkB.coordinate().sphericalDistanceTo(itemB.m_placemarkB.coordinate()) <= 1) {
                    if( ( itemA.m_action == DiffItem::Changed && ( itemB.m_action == DiffItem::Changed || itemB.m_action == DiffItem::Deleted ) )
                            || ( itemA.m_action == DiffItem::Deleted && itemB.m_action == DiffItem::Changed ) ) {
                        conflict = true;
                        other = itemB;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto &entryInfo
```

#### AUTO 


```{c}
auto obj
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder *otherFolder: container->folderList() ) {
            if( otherFolder->name() == name ) {
                folder = otherFolder;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString & file: fileNames ) {
        files << QFileInfo(m_directory, QLatin1String("GPSGrid_") + file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
            if (auto relation = geodata_cast<GeoDataRelation>(feature)) {
                relation->setVisible(showRelation(relation));
                for (auto member: relation->members()) {
                    relations[member] << relation;
                }
            }
        }
```

#### AUTO 


```{c}
auto const clip = clipPath(tileBoundary, zoomLevel);
```

#### AUTO 


```{c}
auto iter=tagMap.begin(), end=tagMap.end();
```

#### RANGE FOR STATEMENT 


```{c}
for ( RenderPlugin *plugin: d->m_renderPlugins ) {
        plugin->retrieveItemState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( int i: candidates ) {
            qreal const dist = m_segments[i].distanceTo( m_position, closest, interpolated );
            if ( distance < 0.0 || dist < distance ) {
                distance = dist;
                m_closestSegmentIndex = i;
                m_positionOnRoute = interpolated;
                m_currentWaypoint = closest;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmRegionTree & child: m_children ) {
        regions.removeAll( child.node() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( SceneGraphicsItem *item: m_graphicsItems ) {
        item->setState( newState );
        m_marbleWidget->model()->treeModel()->updateFeature( item->placemark() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* outerPolygon: outerPolygons ) {
                ClipPainter::drawPolyline( *outerPolygon );
            }
```

#### AUTO 


```{c}
auto const &innerRing
```

#### AUTO 


```{c}
auto const hoveredColor = selectedColor;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: converter.relations()) {
        if (auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)) {
            if (const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry())) {
                auto polygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0));
                Q_ASSERT(polygon);
                OsmRelationTagWriter::writeMultipolygon(*polygon, relation.second, writer );
            } else {
                auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry());
                Q_ASSERT(polygon);
                OsmRelationTagWriter::writeMultipolygon(*polygon, relation.second, writer );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( int j: candidates ) {
                GeoDataLinearRing const & outer = m_osmOsmRegions[j].region.geometry().outerBoundary();
                if ( contains<GeoDataLinearRing, GeoDataLinearRing>( outer, ring ) ) {
                    if ( parent == nullptr || contains<GeoDataLinearRing, GeoDataLinearRing>( parent->region.geometry().outerBoundary(), outer ) ) {
                        qDebug() << "Parent found: " << m_osmOsmRegions[i].region.name() << ", level " << m_osmOsmRegions[i].region.adminLevel()
                                   << "is a child of " << m_osmOsmRegions[j].region.name() << ", level " << m_osmOsmRegions[j].region.adminLevel();
                        parent = &m_osmOsmRegions[j];
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
const auto &backend
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const jsonRef : jsonArray) {
            QJsonObject jsonObj = jsonRef.toObject();
            QJsonObject geometry = jsonObj.value(QStringLiteral("geometry")).toObject();
            QJsonArray coordinates = geometry.value(QStringLiteral("coordinates")).toArray();
            double lon = coordinates.at(0).toDouble();
            double lat = coordinates.at(1).toDouble();

            QJsonObject noteProperties = jsonObj.value(QStringLiteral("properties")).toObject();
            QJsonArray noteComments = noteProperties.value(QStringLiteral("comments")).toArray();

            QString id = QString::number(noteProperties.value(QStringLiteral("id")).toInt());

            QDateTime dateCreated = QDateTime::fromString(noteProperties.value(QStringLiteral("date_created")).toString(), Qt::ISODate);
            QDateTime dateClosed = QDateTime::fromString(noteProperties.value(QStringLiteral("closed_at")).toString(), Qt::ISODate);
            QString noteStatus = noteProperties.value(QStringLiteral("status")).toString();

            NotesItem *item = new NotesItem(this);
            item->setId(id);
            item->setCoordinate(GeoDataCoordinates(lon, lat, 0.0, GeoDataCoordinates::Degree));
            item->setDateCreated(dateCreated);
            item->setNoteStatus(noteStatus);
            item->setDateClosed(dateClosed);

            for (auto const commentRef : noteComments) {
                QJsonObject commentObj = commentRef.toObject();
                QDateTime date = QDateTime::fromString(commentObj.value("date").toString(), Qt::ISODate);
                QString user = commentObj.value("user").toString();
                QString text = commentObj.value("text").toString();
                int uid = commentObj.value("uid").toInt();
                Comment comment(date, text, user, uid);
                item->addComment(comment);
            }

            items << item;
        }
```

#### AUTO 


```{c}
auto i=0, n=polygon.size();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & point: path) {
        if (point.X < minX) {
            minX = point.X;
        } else if (point.X > maxX) {
            maxX = point.X;
        }
        if (point.Y < minY) {
            minY = point.Y;
        } else if (point.Y > maxY) {
            maxY = point.Y;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: map2->placemarkList()) {
        GeoDataPlacemark* land = new GeoDataPlacemark(*placemark);
        if(land->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType) {
            land->setOsmData(marbleLand);
        }
        mergedMap->append(land);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDataPluginItem* item: d->m_itemSet ) {
            if ( item->initialized() && item->isFavorite() ) {
                if ( count == row ) {
                    QString const roleName = roleNames().value( role );
                    return item->property(roleName.toLatin1().constData());
                }
                ++count;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &file: files) {
            QFile::remove(file.absoluteFilePath());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: tile->placemarkList()) {
                    mergedMap->append(placemark->clone());
                }
```

#### AUTO 


```{c}
auto relation = static_cast<GeoDataRelation*>(feature);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto id: way.references()) {
            if (!nodes.contains(id)) {
                // A node is missing. Return nothing.
                return OsmRings();
            }
            ring << nodes[id].coordinates();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl& url: mimeData->urls()) {
            uriParser.setGeoUri(url.url());
            success = uriParser.parse();
            if (success) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDataPluginItem* item: d->m_itemSet ) {
        if ( item->initialized() && item->isFavorite() ) {
            ++count;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &tag: tags) {
        websiteData = data.tagValue(tag);
        if (!websiteData.isEmpty()) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& line: coordinatesLines ) {
            const QStringList coordinates = line.trimmed().split(QLatin1Char(','));
            if ( parentItem.represents( kmlTag_Point ) && parentItem.is<GeoDataFeature>() ) {
                GeoDataCoordinates coord;
                if ( coordinates.size() == 2 ) {
                    coord.set( coordinates.at( 0 ).toDouble(),
                              coordinates.at( 1 ).toDouble(), 0.0, GeoDataCoordinates::Degree );
                } else if( coordinates.size() == 3 ) {
                    coord.set( coordinates.at( 0 ).toDouble(),
                               coordinates.at( 1 ).toDouble(),
                               coordinates.at( 2 ).toDouble(),
                               GeoDataCoordinates::Degree );
                }
                parentItem.nodeAs<GeoDataPlacemark>()->setCoordinate( coord );
            } else {
                GeoDataCoordinates coord;
                if ( coordinates.size() == 2 ) {
                    coord.set( DEG2RAD * coordinates.at( 0 ).toDouble(),
                              DEG2RAD * coordinates.at( 1 ).toDouble() );
                } else if( coordinates.size() == 3 ) {
                    coord.set( DEG2RAD * coordinates.at( 0 ).toDouble(),
                              DEG2RAD * coordinates.at( 1 ).toDouble(),
                              coordinates.at( 2 ).toDouble() );
                }

                if ( parentItem.represents( kmlTag_LineString ) ) {
                    parentItem.nodeAs<GeoDataLineString>()->append( coord );
                } else if ( parentItem.represents( kmlTag_LinearRing ) ) {
                    parentItem.nodeAs<GeoDataLinearRing>()->append( coord );
                } else if ( parentItem.represents( kmlTag_MultiGeometry ) ) {
                    GeoDataPoint *point = new GeoDataPoint( coord );
                    parentItem.nodeAs<GeoDataMultiGeometry>()->append( point );
                } else if ( parentItem.represents( kmlTag_Model) ) {
                    parentItem.nodeAs<GeoDataModel>()->setCoordinates( coord);
                } else if ( parentItem.represents( kmlTag_Point ) ) {
                    // photo overlay
                    parentItem.nodeAs<GeoDataPoint>()->setCoordinates( coord );
                } else if ( parentItem.represents( kmlTag_LatLonQuad ) ) {
                    switch ( coordinatesIndex ) {
                    case 0:
                        parentItem.nodeAs<GeoDataLatLonQuad>()->setBottomLeft( coord );
                        break;
                    case 1:
                        parentItem.nodeAs<GeoDataLatLonQuad>()->setBottomRight( coord );
                        break;
                    case 2:
                        parentItem.nodeAs<GeoDataLatLonQuad>()->setTopRight( coord );
                        break;
                    case 3:
                        parentItem.nodeAs<GeoDataLatLonQuad>()->setTopLeft( coord );
                        break;
                    case 4:
                        mDebug() << "Ignoring excessive coordinates in LatLonQuad (must not have more than 4 pairs)";
                        break;
                    default:
                        // Silently ignore any more coordinates
                        break;
                    }
                } else {
                    // raise warning as coordinates out of valid parents found
                }
            }

            ++coordinatesIndex;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto id: usedWays) {
        ways.remove(id);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MarbleZipReader::FileInfo &fileInfo: zipReader.fileInfoList()) {
        files << fileInfo.filePath;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto wayId: outerWays) {
        Q_ASSERT(ways.contains(wayId));
        GeoDataPlacemark::GeoDataVisualCategory const category = StyleBuilder::determineVisualCategory(ways[wayId].osmData());
        if (category == GeoDataPlacemark::None || category == outerCategory) {
            // Schedule way for removal: It's a non-styled way only used to create the outer boundary in this polygon
            usedWays << wayId;
        } // else we keep it

        for(auto nodeId: ways[wayId].references()) {
            ways[wayId].osmData().addNodeReference(nodes[nodeId].coordinates(), nodes[nodeId].osmData());
        }
    }
```

#### AUTO 


```{c}
auto const &coordinates
```

#### RANGE FOR STATEMENT 


```{c}
for( const RenderState &child: state.d->m_children ) {
        result += toString( child, level+1 );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( SatellitesConfigAbstractItem *item: m_children ) {
        item->loadSettings( settings );
    }
```

#### AUTO 


```{c}
auto const & box = viewport->viewLatLonAltBox();
```

#### AUTO 


```{c}
auto const applications = QStringList() << "monav-daemon" << "MoNavD";
```

#### RANGE FOR STATEMENT 


```{c}
for( const QRectF& childRect: childRects ) {
                        if( childRect.toRect().contains( shiftedPos ) ) {
                            if( child->eventFilter( object, e ) ) {
                                return true;
                            }
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tiles: tileLevels) {
            for (auto const &tileId: tiles) {
                ++count;
                QString const inputFile = first ? m_inputFile : QString("%1/osm/%2/%3/%4.o5m").
                                                  arg(m_cacheDir).arg(tileId.zoomLevel()-1).arg(tileId.x()>>1).arg(tileId.y()>>1);
                QString const outputFile = osmFileFor(tileId);
                if (QFileInfo(outputFile).exists()) {
                    continue;
                }

                printProgress(count / double(maxCount));
                cout << " Creating osm cache tile " << count << "/" << maxCount << " (";
                cout << tileId.zoomLevel() << "/" << tileId.x() << "/" << tileId.y() << ')' << string(20, ' ') << '\r';
                cout.flush();

                QDir().mkpath(QFileInfo(outputFile).absolutePath());
                QString const output = QString("-o=%1").arg(outputFile);

                GeoDataLatLonBox tileBoundary;
                m_tileProjection.geoCoordinates(tileId.zoomLevel(), tileId.x(), tileId.y(), tileBoundary);

                double const minLon = tileBoundary.west(GeoDataCoordinates::Degree);
                double const maxLon = tileBoundary.east(GeoDataCoordinates::Degree);
                double const maxLat = tileBoundary.north(GeoDataCoordinates::Degree);
                double const minLat = tileBoundary.south(GeoDataCoordinates::Degree);
                QString const bbox = QString("-b=%1,%2,%3,%4").arg(minLon).arg(minLat).arg(maxLon).arg(maxLat);
                QProcess osmconvert;
                osmconvert.start("osmconvert", QStringList() << "--drop-author" << "--drop-version"
                                 << "--complete-ways" << "--complex-ways" << bbox << output << inputFile);
                osmconvert.waitForFinished(10*60*1000);
                if (osmconvert.exitCode() != 0) {
                    qWarning() << osmconvert.readAllStandardError();
                    qWarning() << "osmconvert failed: " << osmconvert.errorString();
                }
            }
            first = false;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * relation) {
            return relation->relationType() >= GeoDataRelation::RouteRoad && relation->relationType() <= GeoDataRelation::RouteSled;
        }
```

#### AUTO 


```{c}
const auto track = geodata_cast<GeoDataTrack>(d->m_geometry)
```

#### RANGE FOR STATEMENT 


```{c}
for( EclipsesItem *item: m_model->items() ) {
            QAction *action = m_eclipsesListMenu->addAction(
                        item->dateMaximum().date().toString() );
            action->setData( QVariant( 1000 * item->dateMaximum().date().year() +  item->index() ) );
            action->setIcon( item->icon() );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Relation &a, const Relation &b) { return a.second.id() < b.second.id(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MarbleZipReader::FileInfo &fileInfo: zip.fileInfoList()) {
        //if (!fileInfo.isFile) {
        //    continue;
        //}
        QString file = filename + QLatin1Char('/') + fileInfo.filePath;
        m_kmzFiles << fileInfo.filePath;
        if (file.endsWith(QLatin1String(".kml"), Qt::CaseInsensitive)) {
            if ( !m_kmlFile.isEmpty() ) {
                mDebug() << "File" << kmz << "contains more than one .kml files";
            }
            m_kmlFile = file;
        }
    }
```

#### AUTO 


```{c}
auto const tile = TileId::fromCoordinates(placemark->coordinate(), m_tileLevel);
```

#### AUTO 


```{c}
auto const visualCategory = parameters.feature->visualCategory();
```

#### RANGE FOR STATEMENT 


```{c}
for( const ModelRegion &region: m_placemarks ) {
        if ( region.region.contains( e->pos() ) ) {
            emit q->placemarkSelected( region.index );
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &ring: m_boundingPolygon) {
            if (ring.contains(coordinate)) {
                ++innerNodes;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &node: nodes) {
        if (node.second.id() != lastId) {
            writeNode(node, writer);
            lastId = node.second.id();
        } // else duplicate/shared node
    }
```

#### AUTO 


```{c}
auto const j = i == n-1 ? 0 : i+1;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const FileLoader *loader: d->m_loaderList ) {
        if ( loader->path() == filepath )
            return;  // currently loading
    }
```

#### AUTO 


```{c}
auto match = places.first();
```

#### AUTO 


```{c}
auto linearRing = geodata_cast<GeoDataLinearRing>(*multiIter)
```

#### AUTO 


```{c}
auto const object = qvariant_cast<GeoDataObject*>(index.data(MarblePlacemarkModel::ObjectPointerRole));
```

#### AUTO 


```{c}
auto lineStrings = lineStrings_;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: lineStringItems) {
            lineStrings << item->lineString();
        }
```

#### AUTO 


```{c}
auto const refA = a->osmData().tagValue(QStringLiteral("ref"));
```

#### AUTO 


```{c}
const auto &path
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFeature *feature: document->featureList()) {
        if (feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            GeoDataPlacemark* original = static_cast<GeoDataPlacemark*>(feature);
            bool isWay = false;
            if (original->geometry()->nodeType() == GeoDataTypes::GeoDataLineStringType) {
                PlacemarkPtr placemark = PlacemarkPtr(new GeoDataPlacemark(*original));
                OsmObjectManager::initializeOsmData(placemark.data());
                OsmPlacemarkData const & osmData = placemark->osmData();
                isWay = osmData.containsTagKey("highway") ||
                        osmData.containsTagKey("railway") ||
                        osmData.containsTagKey("waterway");
                if (isWay) {
                    GeoDataLineString *line = static_cast<GeoDataLineString*>(placemark->geometry());
                    qint64 firstId = osmData.nodeReference(line->first()).oid();
                    qint64 lastId = osmData.nodeReference(line->last()).oid();
                    if (firstId > 0 && lastId > 0) {
                        ++m_originalWays;
                        bool containsFirst = m_hash.contains(firstId);
                        bool containsLast = m_hash.contains(lastId);

                        if (!containsFirst && !containsLast) {
                            createWayChunk(placemark, firstId, lastId);
                        } else if (containsFirst && !containsLast) {
                            auto chunk = wayChunk(*placemark, firstId);
                            if (chunk != nullptr) {
                                concatFirst(placemark, chunk);
                            } else {
                                createWayChunk(placemark, firstId, lastId);
                            }
                        } else if (!containsFirst && containsLast) {
                            auto chunk = wayChunk(*placemark, lastId);
                            if (chunk != nullptr) {
                                concatLast(placemark, chunk);
                            } else {
                                createWayChunk(placemark, firstId, lastId);
                            }
                        } else if (containsFirst && containsLast) {
                            auto chunk = wayChunk(*placemark, firstId);
                            auto otherChunk = wayChunk(*placemark, lastId);

                            if (chunk != nullptr && otherChunk != nullptr) {
                                if(chunk == otherChunk) {
                                    m_wayPlacemarks.append(placemark);
                                } else {
                                    concatBoth(placemark, chunk, otherChunk);
                                }
                            } else if(chunk != nullptr && otherChunk == nullptr) {
                                concatFirst(placemark, chunk);
                            } else if(chunk == nullptr && otherChunk != nullptr) {
                                concatLast(placemark, otherChunk);
                            } else {
                                createWayChunk(placemark, firstId, lastId);
                            }
                        }
                    } else {
                        isWay = false;
                    }
                }
            }

            if (!isWay) {
                m_otherPlacemarks << feature->clone();
            }
        } else {
            m_otherPlacemarks << feature->clone();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QFileInfo & file: files() ) {
        QFile ( file.absoluteFilePath() ).remove();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: lineStringItems) {
        item->setVisible(visible);
        if (visible) {
            item->setMergedLineString(merged);
            visible = merged.isEmpty();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo &file: files) {
            if (!QFile::rename(file.absoluteFilePath(), monavDir().absoluteFilePath() + QLatin1Char('/') + file.fileName())) {
                changeStatus(Error, "Unable to move monav files to target directory.");
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &key: profile.pluginSettings().keys() ) {
            KConfigGroup pluginGroup = profileGroup.group( key );
            pluginGroup.writeEntry( "Enabled", true );
            for ( const QString& settingKey: profile.pluginSettings()[ key ].keys() ) {
                Q_ASSERT(settingKey != QLatin1String("Enabled"));
                pluginGroup.writeEntry( settingKey, profile.pluginSettings()[ key ][ settingKey ] );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFeature* feature: m_deletedObjects ) {
        if( feature->targetId().isEmpty() ) {
            continue;
        }
        GeoDataFeature* target = findFeature( m_rootDocument, feature->targetId() );
        if ( target ) {
            /** @todo Do we have to note the original row position and restore it? */
            Q_ASSERT( dynamic_cast<GeoDataContainer*>( target ) );
            emit added( static_cast<GeoDataContainer*>( target ), feature, -1 );
            if (auto placemark = geodata_cast<GeoDataPlacemark>(feature))
            {
                if( placemark->isBalloonVisible() ) {
                    emit balloonShown( placemark );
                }
            }
        } // else the root document was modified in an unfortunate way and we cannot restore it at this point
    }
```

#### AUTO 


```{c}
auto const key = QString("1%1").arg(iter.value());
```

#### AUTO 


```{c}
auto iter=ways.constBegin(), end=ways.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems) {
            if (d->m_levelTagDebugModeEnabled) {
                if (const auto placemark = geodata_cast<GeoDataPlacemark>(item->feature())) {
                    if (placemark->hasOsmData()) {
                        QHash<QString, QString>::const_iterator tagIter = placemark->osmData().findTag(QStringLiteral("level"));
                        if (tagIter != placemark->osmData().tagsEnd()) {
                            const int val = tagIter.value().toInt();
                            if (val != d->m_debugLevelTag) {
                                continue;
                            }
                        }
                    }
                }
            }
            item->paint(painter, viewport, layer, d->m_tileLevel);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto nodeId: m_references) {
            auto const nodeIter = nodes.constFind(nodeId);
            if (nodeIter == nodes.constEnd()) {
                return nullptr;
            }

            OsmNode const & node = nodeIter.value();
            osmData.addNodeReference(node.coordinates(), node.osmData());
            lineString.append(node.coordinates());
            usedNodes << nodeId;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFolder* folder: bookmarkManager.folders()) {
        collectMatches(matches, query, folder);
    }
```

#### AUTO 


```{c}
const auto doc = geodata_cast<GeoDataDocument>(object)
```

#### AUTO 


```{c}
auto placemark = static_cast<const GeoDataPlacemark*>(object);
```

#### AUTO 


```{c}
auto const commentRef
```

#### RANGE FOR STATEMENT 


```{c}
for( const RouteItem &item: routeList ) {
            cloudRoutes.append( item.identifier() );
        }
```

#### AUTO 


```{c}
auto const outputFile = osmFileFor(tileId);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: *ring) {
            subject << IntPoint(&node);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoSceneLayer *layer: d->m_mapTheme->map()->layers() ) {
        if ( layer->backend() != dgml::dgmlValue_geodata
             && layer->backend() != dgml::dgmlValue_vector )
            continue;

        // look for datasets which are different from currentDatasets
        for ( const GeoSceneAbstractDataset *dataset: layer->datasets() ) {
            const GeoSceneGeodata *data = dynamic_cast<const GeoSceneGeodata*>( dataset );
            Q_ASSERT( data );
            skip = false;
            sourceFileMatch = false;
            for ( int i = 0; i < currentDatasets.size(); ++i ) {
                if ( currentDatasets[i] == *data ) {
                    currentDatasets.removeAt( i );
                    skip = true;
                    break;
                }
                /**
                 * If the sourcefile of data matches any in the currentDatasets then there
                 * is no need to parse the file again just update the style
                 * i.e. <brush> and <pen> values of already parsed file. assignNewStyle() does that
                 */
                if ( currentDatasets[i].sourceFile() == data->sourceFile() ) {
                    sourceFileMatch = true;
                    datasetIndex = i;
                }
            }
            if ( skip ) {
                continue;
            }

            QString filename = data->sourceFile();
            QString property = data->property();
            QPen pen = data->pen();
            QBrush brush = data->brush();
            GeoDataStyle::Ptr style;
            int renderOrder = data->renderOrder();

            /**
             * data->colors() are the colorMap values from dgml file. If this is not
             * empty then we are supposed to assign every placemark a different style
             * by giving it a color from colorMap values based on color index
             * of that placemark. See assignFillColors() for details. So, we need to
             * send an empty style to fileManeger otherwise the FileLoader::createFilterProperties()
             * will overwrite the parsed value of color index ( GeoDataPolyStyle::d->m_colorIndex ).
             */
            if ( data->colors().isEmpty() ) {
                GeoDataLineStyle lineStyle( pen.color() );
                lineStyle.setPenStyle( pen.style() );
                lineStyle.setWidth( pen.width() );
                GeoDataPolyStyle polyStyle( brush.color() );
                polyStyle.setFill( true );
                style = GeoDataStyle::Ptr(new GeoDataStyle);
                style->setLineStyle( lineStyle );
                style->setPolyStyle( polyStyle );
                style->setId(QStringLiteral("default"));
            }
            if ( sourceFileMatch && !currentDatasets[datasetIndex].colors().isEmpty() ) {
                /**
                 * if new theme file doesn't specify any colorMap for data
                 * then assignNewStyle otherwise assignFillColors.
                 */
                currentDatasets.removeAt( datasetIndex );
                if ( style ) {
                    qDebug() << "setMapThemeId-> color: " << style->polyStyle().color() << " file: " << filename;
                    d->assignNewStyle( filename, style );
                    style = GeoDataStyle::Ptr();
                }
                else {
                    d->assignFillColors( data->sourceFile() );
                }
            }
            else {
                fileList << filename;
                propertyList << property;
                styleList << style;
                renderOrderList << renderOrder;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OsmTag &tag: tags) {
        QTreeWidgetItem *tagItem = tagWidgetItem( tag );
        m_recommendedTagsList->addTopLevelItem( tagItem );
    }
```

#### AUTO 


```{c}
auto const styling = StyleParameters(placemark, d->m_renderContext.tileLevel());
```

#### AUTO 


```{c}
const auto visualCategory = StyleBuilder::determineVisualCategory(m_osmData);
```

#### AUTO 


```{c}
auto layer
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataFeature *feature: document->featureList() ) {

        if (const GeoDataPlacemark *placemark = geodata_cast<GeoDataPlacemark>(feature)) {
            GeoDataPlacemark *newPlacemark = new GeoDataPlacemark( *placemark );

            if (geodata_cast<GeoDataPoint>(placemark->geometry())) {
                PlacemarkTextAnnotation *placemark = new PlacemarkTextAnnotation( newPlacemark );
                m_graphicsItems.append( placemark );
            } else if (geodata_cast<GeoDataPolygon>(placemark->geometry())) {
                newPlacemark->setParent( m_annotationDocument );
                if ( !placemark->styleUrl().isEmpty() ) {
                    newPlacemark->setStyleUrl( placemark->styleUrl() );
                }
                AreaAnnotation *polygonAnnotation = new AreaAnnotation( newPlacemark );
                m_graphicsItems.append( polygonAnnotation );
            } else if (geodata_cast<GeoDataLineString>(placemark->geometry())) {
                newPlacemark->setParent( m_annotationDocument );
                if ( !placemark->styleUrl().isEmpty() ) {
                    newPlacemark->setStyleUrl( placemark->styleUrl() );
                }
                PolylineAnnotation *polylineAnnotation = new PolylineAnnotation( newPlacemark );
                m_graphicsItems.append( polylineAnnotation );
            }
            m_marbleWidget->model()->treeModel()->addFeature( m_annotationDocument, newPlacemark );
        } else if (const GeoDataGroundOverlay *overlay = geodata_cast<GeoDataGroundOverlay>(feature)) {
            GeoDataGroundOverlay *newOverlay = new GeoDataGroundOverlay( *overlay );
            m_marbleWidget->model()->treeModel()->addFeature( m_annotationDocument, newOverlay );
            displayOverlayFrame( newOverlay );
        }
    }
```

#### AUTO 


```{c}
auto multiGeometry = geodata_cast<GeoDataMultiGeometry>(parent)
```

#### AUTO 


```{c}
auto const path = iconPath.isEmpty() ? iconPath : MarbleDirs::path(iconPath);
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction* action: panelActions ) {
            m_panelMenu->addAction( action );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoSceneAbstractDataset *dataset: layer->datasets() ) {
                GeoSceneGeodata *data = static_cast<GeoSceneGeodata*>( dataset );
                if ( data ) {
                    if ( data->sourceFile() == filePath ) {
                        GeoDataDocument *doc = m_fileManager.at( filePath );
                        Q_ASSERT( doc );

                        addHighlightStyle( doc );

                        QPen pen = data->pen();
                        QBrush brush = data->brush();
                        const QVector<QColor> colors = data->colors();
                        GeoDataLineStyle lineStyle( pen.color() );
                        lineStyle.setPenStyle( pen.style() );
                        lineStyle.setWidth( pen.width() );

                        if ( !colors.isEmpty() ) {
                            qreal alpha = data->alpha();
                            QVector<GeoDataFeature*>::iterator it = doc->begin();
                            QVector<GeoDataFeature*>::iterator const itEnd = doc->end();
                            for ( ; it != itEnd; ++it ) {
                                GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>( *it );
                                if ( placemark ) {
                                    GeoDataStyle::Ptr style(new GeoDataStyle);
                                    style->setId(QStringLiteral("normal"));
                                    style->setLineStyle( lineStyle );
                                    quint8 colorIndex = placemark->style()->polyStyle().colorIndex();
                                    GeoDataPolyStyle polyStyle;
                                    // Set the colorIndex so that it's not lost after setting new style.
                                    polyStyle.setColorIndex( colorIndex );
                                    QColor color;
                                    // color index having value 99 is undefined
                                    Q_ASSERT( colors.size() );
                                    if ( colorIndex > colors.size() || ( colorIndex - 1 ) < 0 )
                                    {
                                        color = colors[0];      // Assign the first color as default
                                    }
                                    else {
                                        color = colors[colorIndex-1];
                                    }
                                    color.setAlphaF( alpha );
                                    polyStyle.setColor( color );
                                    polyStyle.setFill( true );
                                    style->setPolyStyle( polyStyle );
                                    placemark->setStyle( style );
                                }
                            }
                        }
                        else {
                            GeoDataStyle::Ptr style(new GeoDataStyle);
                            GeoDataPolyStyle polyStyle( brush.color() );
                            polyStyle.setFill( true );
                            style->setLineStyle( lineStyle );
                            style->setPolyStyle( polyStyle );
                            style->setId(QStringLiteral("default"));
                            GeoDataStyleMap styleMap;
                            styleMap.setId(QStringLiteral("default-map"));
                            styleMap.insert(QStringLiteral("normal"), QLatin1Char('#') + style->id());
                            doc->addStyle( style );
                            doc->addStyleMap( styleMap );

                            const QString styleUrl = QLatin1Char('#') + styleMap.id();
                            QVector<GeoDataFeature*>::iterator iter = doc->begin();
                            QVector<GeoDataFeature*>::iterator const end = doc->end();

                            for ( ; iter != end; ++iter ) {
                                if ( (*iter)->nodeType() == GeoDataTypes::GeoDataPlacemarkType ) {
                                    GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>( *iter );
                                    Q_ASSERT( placemark );
                                    if ( placemark->geometry()->nodeType() != GeoDataTypes::GeoDataTrackType &&
                                        placemark->geometry()->nodeType() != GeoDataTypes::GeoDataPointType )
                                    {
                                        placemark->setStyleUrl(styleUrl);
                                    }
                                }
                            }
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto feature = dynamic_cast<GeoDataFeature *>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &resource: paths ) {
        if ( !directories.contains( resource ) && !files.contains( resource ) ) {
            m_fileSystemWatcher.addPath( resource );
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * a, const GeoDataRelation * b) {
        return *a < *b;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: doc->featureList()) {
                if (auto relation = geodata_cast<GeoDataRelation>(feature)) {
                    relation->setVisible(showRelation(relation));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFeature *feature: other.m_vector )
        {
            m_vector.append(feature->clone());
        }
```

#### AUTO 


```{c}
auto time = QTime(0, 0, 0);
```

#### AUTO 


```{c}
auto const &key
```

#### AUTO 


```{c}
auto const marbleWidget = window->marbleControl()->marbleWidget();
```

#### AUTO 


```{c}
auto const route = d->m_osmData.tagValue(QStringLiteral("route"));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& key: settings.childKeys() ) {
            hash.insert( key, settings.value( key ) );
        }
```

#### AUTO 


```{c}
auto const defaultRelationTypes = QStringList() << "ferry" << "train" << "subway" << "tram" << "bus" << "trolley-bus" << "hiking";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto node : screenPolygon) {
                    QVariantMap vmap;
                    vmap["x"] = node.x();
                    vmap["y"] = node.y();
                    m_polyline.append(vmap);
                }
```

#### AUTO 


```{c}
const auto& point
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataPlacemark>(parentItem)
```

#### AUTO 


```{c}
auto relation = geodata_cast<GeoDataRelation>(feature)
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFeature *feature: d->m_treeModel.rootDocument()->featureList()) {
        if( feature->nodeType() == GeoDataTypes::GeoDataDocumentType ) {
            GeoDataDocument *document = static_cast<GeoDataDocument*>( feature );
            if( document->property() == property ){
                document->setVisible( value );
                d->m_treeModel.updateFeature( document );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder* folder: container->folderList() ) {
        const GeoDataPlacemark* placemark = findPlacemark( folder, bookmark );
        if ( placemark ) {
            return placemark;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
        GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
        newPlacemark->setVisible(placemark->isVisible());
        newPlacemark->setVisualCategory(placemark->visualCategory());
        GeoDataLinearRing outerRing;
        OsmPlacemarkData const & placemarkOsmData = placemark->osmData();
        OsmPlacemarkData & newPlacemarkOsmData = newPlacemark->osmData();
        int index = -1;
        OsmPlacemarkData const & outerRingOsmData = placemarkOsmData.memberReference(index);
        OsmPlacemarkData & newOuterRingOsmData = newPlacemarkOsmData.memberReference(index);
        int nodeIndex = 0;
        for(const auto &point: path) {
            GeoDataCoordinates const coordinates = point.coordinates();
            outerRing << coordinates;
            auto const originalOsmData = outerRingOsmData.nodeReference(coordinates);
            if (originalOsmData.id() > 0) {
                newOuterRingOsmData.addNodeReference(coordinates, originalOsmData);
            }
            ++nodeIndex;
        }

        GeoDataPolygon* newPolygon = new GeoDataPolygon;
        newPolygon->setOuterBoundary(outerRing);
        if (isBuilding) {
            const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
            GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
            newBuilding->multiGeometry()->clear();
            newBuilding->multiGeometry()->append(newPolygon);
            newPlacemark->setGeometry(newBuilding);
        } else {
            newPlacemark->setGeometry(newPolygon);
        }
        if (placemarkOsmData.id() > 0) {
            newPlacemarkOsmData.addTag(QStringLiteral("mx:oid"), QString::number(placemarkOsmData.id()));
        }
        copyTags(placemarkOsmData, newPlacemarkOsmData);
        copyTags(outerRingOsmData, newOuterRingOsmData);
        if (outerRingOsmData.id() > 0) {
            newOuterRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(outerRingOsmData.id()));
        }

        auto const & innerBoundaries = qAsConst(polygon)->innerBoundaries();
        for (index = 0; index < innerBoundaries.size(); ++index) {
            auto const & innerBoundary = innerBoundaries.at(index);
            if (minArea > 0.0 && area(innerBoundary) < minArea) {
                continue;
            }

            auto const & innerRingOsmData = placemarkOsmData.memberReference(index);
            clipper.Clear();
            clipper.AddPath(path, ptClip, true);
            Path innerPath;
            for(auto const & node: innerBoundary) {
                innerPath << IntPoint(&node);
            }
            clipper.AddPath(innerPath, ptSubject, true);
            Paths innerPaths;
            clipper.Execute(ctIntersection, innerPaths);
            for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                nodeIndex = 0;
                for(const auto &point: innerPath) {
                    GeoDataCoordinates const coordinates = point.coordinates();
                    innerRing << coordinates;
                    auto const originalOsmData = innerRingOsmData.nodeReference(coordinates);
                    if (originalOsmData.id() > 0) {
                        newInnerRingOsmData.addNodeReference(coordinates, originalOsmData);
                    }
                    ++nodeIndex;
                }
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
        }

        OsmObjectManager::initializeOsmData(newPlacemark);
        document->append(newPlacemark);
        osmIds << placemark->osmData().id();
    }
```

#### AUTO 


```{c}
auto it =lineString->constBegin(), end = lineString->constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &value: iconStateTextList ) {
            if (value == QLatin1String("open")) {
                itemIconState |= GeoDataItemIcon::Open;
            } else if (value == QLatin1String("closed")) {
                itemIconState |= GeoDataItemIcon::Closed;
            } else if (value == QLatin1String("error")) {
                itemIconState |= GeoDataItemIcon::Error;
            } else if (value == QLatin1String("fetching0")) {
                itemIconState |= GeoDataItemIcon::Fetching0;
            } else if (value == QLatin1String("fetching1")) {
                itemIconState |= GeoDataItemIcon::Fetching1;
            } else if (value == QLatin1String("fetching2")) {
                itemIconState |= GeoDataItemIcon::Fetching2;
            }
            else {
                mDebug() << "Cannot parse state value" << value;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
        if (const auto placemark = geodata_cast<GeoDataPlacemark>(feature)) {
            // Select zoom level such that the placemark fits in a single tile
            int zoomLevel;
            qreal north, south, east, west;
            placemark->geometry()->latLonAltBox().boundaries(north, south, east, west);
            for (zoomLevel = maxZoomLevel; zoomLevel >= 0; --zoomLevel) {
                if (TileId::fromCoordinates(GeoDataCoordinates(west, north), zoomLevel) ==
                        TileId::fromCoordinates(GeoDataCoordinates(east, south), zoomLevel)) {
                    break;
                }
            }
            TileId const key = TileId::fromCoordinates(GeoDataCoordinates(west, north), zoomLevel);
            m_items[key] << placemark;
        } else if (GeoDataRelation *relation = geodata_cast<GeoDataRelation>(feature)) {
            m_relations << relation;
        } else {
            Q_ASSERT(false && "only placemark variants are supported so far");
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& path, const QString& error) {
            QMessageBox::warning(this, tr("Marble"), // krazy:exclude=qclasses
                   tr("Sorry, unable to open '%1':\n'%2'").arg(path).arg(error),
                   QMessageBox::Ok);
        }
```

#### AUTO 


```{c}
auto const boundingBox = mapTiles.boundingBox();
```

#### AUTO 


```{c}
auto lineString = geodata_cast<GeoDataLineString>(placemark->geometry())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: relations) {
        if (relation.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x12); // relation start indicator
        OsmPlacemarkData const & osmData = relation.second;

        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        lastId = osmData.id();
        writeVersion(osmData, bufferStream);

        QBuffer referencesBuffer;
        referencesBuffer.open(QIODevice::WriteOnly);
        QDataStream referencesStream(&referencesBuffer);
        if (relation.first->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            auto placemark = static_cast<const GeoDataPlacemark*>(relation.first);
            Q_ASSERT(placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType);
            auto polygon = static_cast<const GeoDataPolygon*>(placemark->geometry());
            writeMultipolygonMembers(*polygon, lastReferenceId, osmData, stringTable, referencesStream);
        } else if (relation.first->nodeType() == GeoDataTypes::GeoDataRelationType) {
            auto placemark = static_cast<const GeoDataRelation*>(relation.first);
            writeRelationMembers(placemark, lastReferenceId, osmData, stringTable, referencesStream);
        } else {
            Q_ASSERT(false);
        }
        writeUnsigned(referencesBuffer.size(), bufferStream);
        bufferStream.writeRawData(referencesBuffer.data().constData(), referencesBuffer.size());

        writeTags(osmData, stringTable, bufferStream);

        writeUnsigned(buffer.size(), stream);
        stream.writeRawData(buffer.data().constData(), buffer.size());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter) {
                ++count;
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles && QFileInfo(filename).exists()) {
                    continue;
                }
                GeoDataDocument* tile = processor.clipTo(zoomLevel, tileId.x(), tileId.y());
                if (tile->size() > 0) {
                    NodeReducer nodeReducer(tile, TileId(0, zoomLevel, tileId.x(), tileId.y()));
                    if (!writeTile(tile, filename)) {
                        return 4;
                    }
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Tile " << count << "/" << total << " (" << tile->name().toStdString() << ") done.";
                    double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                    std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Skipping empty tile " << count << "/" << total << " (" << tile->name().toStdString() << ").";
                }
                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
                delete tile;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &point: path) {
                GeoDataCoordinates const coordinates = point.coordinates();
                *newRing << coordinates;
                auto const originalOsmData = osmData.nodeReference(coordinates);
                if (originalOsmData.id() > 0) {
                    newPlacemark->osmData().addNodeReference(coordinates, originalOsmData);
                }
                ++index;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: innerBoundary) {
                auto p = coordinateToPoint(node);
                coordMap.insert(std::make_pair(p.X, p.Y), &node);
                innerPath.push_back(std::move(p));
            }
```

#### AUTO 


```{c}
auto it = d->m_vector.constBegin(), end = d->m_vector.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataLinearRing& itInnerBoundary: innerBoundaries ) {
            if ( viewLatLonAltBox.intersects(itInnerBoundary.latLonAltBox())
                 && d->m_viewport->resolves(itInnerBoundary.latLonAltBox()), 4 )  {
                innerBoundariesOnScreen = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* fillPolygon: fillPolygons ) {
                ClipPainter::drawPolygon(*fillPolygon, fillRule);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: background->placemarkList()) {
        GeoDataPlacemark* land = new GeoDataPlacemark(*placemark);
        if(land->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType) {
            land->setOsmData(marbleLand);
        }
        mergedMap->append(land);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &point: d->m_positions) {
        rects << QRectF(point, size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto placemark : document->placemarkList()) {
            importPlacemark(outline, segments, placemark);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                pathToRing(innerPath, &innerRing, innerRingOsmData, newInnerRingOsmData, coordMap);
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
```

#### AUTO 


```{c}
auto iter = osmData.tagsBegin(), end=osmData.tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &format: formats ) {
            QString const result = audioTemplate.arg( m_speaker, name, format );
            QFileInfo audioFile( result );
            if ( audioFile.exists() ) {
                return result;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const TirexMetatileRequest &req) {
        // load bigger tiles at high-z levels, it's more efficient there
        // that however assumes we are rendering square power of two meta-tiles with proper alignment
        int loadZ = req.tile.z;
        if (backend.metatileColumns() == backend.metatileRows() && backend.metatileRows() == 8 && req.tile.z <= 15) {
            loadZ = req.tile.z - 3;
        }
        TileDirectory mapTiles(cacheDirectory, QStringLiteral("planet.osmx"), manager, req.tile.z, loadZ);
        TileDirectory landTiles(TileDirectory::Landmass, cacheDirectory, manager, req.tile.z);

        QSaveFile f(backend.metatileFileName(req));
        if (!f.open(QFile::WriteOnly)) {
            backend.tileError(req, f.errorString());
            return;
        }

        backend.writeMetatileHeader(&f, req.tile);
        for (int x = 0; x < backend.metatileColumns(); ++x) {
            for (int y = 0; y < backend.metatileRows(); ++y) {
                auto const tileId = TileId (0, req.tile.z, x + req.tile.x, y + req.tile.y);
                using GeoDocPtr = QSharedPointer<GeoDataDocument>;
                GeoDocPtr tile1 = GeoDocPtr(mapTiles.clip(tileId.zoomLevel(), tileId.x(), tileId.y()));
                TagsFilter::removeAnnotationTags(tile1.data());
                if (tileId.zoomLevel() < 17) {
                    WayConcatenator concatenator(tile1.data());
                }
                NodeReducer nodeReducer(tile1.data(), tileId);
                GeoDocPtr tile2 = GeoDocPtr(landTiles.clip(tileId.zoomLevel(), tileId.x(), tileId.y()));
                GeoDocPtr combined = GeoDocPtr(mergeDocuments(tile1.data(), tile2.data()));

                const auto offset = f.pos();
                if (GeoDataDocumentWriter::write(&f, *combined, QStringLiteral("o5m"))) {
                    backend.writeMetatileEntry(&f, x * backend.metatileColumns() + y, offset, f.pos() - offset);
                } else {
                    qWarning() << "Could not write the tile " << combined->name();
                }
            }
        }
        f.commit();
        backend.tileDone(req);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::GeoDataPlacemark * const placemark: folder->placemarkList() ) {
            if ( distanceSphere( placemark->coordinate(), compareTo ) * planetRadius < 5 ) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoSceneAbstractDataset *dataset: layer->datasets() ) {
                GeoSceneGeodata *data = static_cast<GeoSceneGeodata*>( dataset );
                if ( data ) {
                    if ( data->sourceFile() == filePath ) {
                        GeoDataDocument *doc = m_fileManager.at( filePath );
                        Q_ASSERT( doc );

                        addHighlightStyle( doc );

                        QPen pen = data->pen();
                        QBrush brush = data->brush();
                        const QVector<QColor> colors = data->colors();
                        GeoDataLineStyle lineStyle( pen.color() );
                        lineStyle.setPenStyle( pen.style() );
                        lineStyle.setWidth( pen.width() );

                        if ( !colors.isEmpty() ) {
                            qreal alpha = data->alpha();
                            QVector<GeoDataFeature*>::iterator it = doc->begin();
                            QVector<GeoDataFeature*>::iterator const itEnd = doc->end();
                            for ( ; it != itEnd; ++it ) {
                                GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>( *it );
                                if ( placemark ) {
                                    GeoDataStyle::Ptr style(new GeoDataStyle);
                                    style->setId(QStringLiteral("normal"));
                                    style->setLineStyle( lineStyle );
                                    quint8 colorIndex = placemark->style()->polyStyle().colorIndex();
                                    GeoDataPolyStyle polyStyle;
                                    // Set the colorIndex so that it's not lost after setting new style.
                                    polyStyle.setColorIndex( colorIndex );
                                    QColor color;
                                    // color index having value 99 is undefined
                                    Q_ASSERT( colors.size() );
                                    if ( colorIndex > colors.size() || ( colorIndex - 1 ) < 0 )
                                    {
                                        color = colors[0];      // Assign the first color as default
                                    }
                                    else {
                                        color = colors[colorIndex-1];
                                    }
                                    color.setAlphaF( alpha );
                                    polyStyle.setColor( color );
                                    polyStyle.setFill( true );
                                    style->setPolyStyle( polyStyle );
                                    placemark->setStyle( style );
                                }
                            }
                        }
                        else {
                            GeoDataStyle::Ptr style(new GeoDataStyle);
                            GeoDataPolyStyle polyStyle( brush.color() );
                            polyStyle.setFill( true );
                            style->setLineStyle( lineStyle );
                            style->setPolyStyle( polyStyle );
                            style->setId(QStringLiteral("default"));
                            GeoDataStyleMap styleMap;
                            styleMap.setId(QStringLiteral("default-map"));
                            styleMap.insert(QStringLiteral("normal"), QLatin1Char('#') + style->id());
                            doc->addStyle( style );
                            doc->addStyleMap( styleMap );

                            const QString styleUrl = QLatin1Char('#') + styleMap.id();
                            QVector<GeoDataFeature*>::iterator iter = doc->begin();
                            QVector<GeoDataFeature*>::iterator const end = doc->end();

                            for ( ; iter != end; ++iter ) {
                                if (auto placemark = geodata_cast<GeoDataPlacemark>(*iter)) {
                                    if (!geodata_cast<GeoDataTrack>(placemark->geometry()) &&
                                        !geodata_cast<GeoDataPoint>(placemark->geometry()))
                                    {
                                        placemark->setStyleUrl(styleUrl);
                                    }
                                }
                            }
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems) {
            item->paint(painter, viewport, layer, d->m_tileLevel);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            importPlacemark( outline, segments, placemark );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QList<int> &currentRouteSegment: routeSegments ) {
        if ( currentRouteSegment.size() > maxLenght ) {
            maxLenght = currentRouteSegment.size() ;
            m_firstVisiblePoint = currentRouteSegment.first();
            m_lastVisiblePoint  = currentRouteSegment.last();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( RoutingTask* task: d->m_routingTasks ) {
        QThreadPool::globalInstance()->start( task );
    }
```

#### AUTO 


```{c}
auto const & n = normals[qMin(i, segmentCount - 1)].toPointF();
```

#### RANGE FOR STATEMENT 


```{c}
for( const MonavStuffEntry &map: m_remoteMaps ) {
        Q_ASSERT( map.isValid() );
        continents << map.continent();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FileLoader *loader: d->m_loaderList ) {
        if ( loader->path() == key ) {
            disconnect( loader, nullptr, this, nullptr );
            loader->wait();
            d->m_loaderList.removeAll( loader );
            delete loader->document();
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPointF &point: parentPositions ) {
            absolutePositions.append( point + relativePosition );
        }
```

#### AUTO 


```{c}
auto style = presetStyle(visualCategory);
```

#### AUTO 


```{c}
auto const input = args.first().split('/');
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder * folder: manager->folders() ) {
        QVector<GeoDataPlacemark*> bookmarks = folder->placemarkList();
        QVector<GeoDataPlacemark*>::const_iterator iter = bookmarks.constBegin();
        QVector<GeoDataPlacemark*>::const_iterator end = bookmarks.constEnd();

        for ( ; iter != end; ++iter ) {
            m_bookmarks.push_back( *iter );
        }
    }
```

#### AUTO 


```{c}
auto const & a = polygon[i];
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            if ( !blacklist.contains( placemark->name() ) ) {
                hasInstructions = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto endIdx = dgram.data().indexOf('\n', nextIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto popularity : popularities) {
            StyleBuilder::Private::s_popularities[popularity] = value;
            value -= offset;
        }
```

#### AUTO 


```{c}
auto const visualCategory = static_cast<const GeoDataPlacemark*>(feature())->visualCategory();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter) {
                auto const tile = TileId(0, zoomLevel, tileId.x(), tileId.y());
                int const innerNodes = mapTiles.innerNodes(tile);
                if (innerNodes > 0) {
                    auto const mapTile = mapTiles.tileFor(zoomLevel, tileId.x(), tileId.y());
                    auto const name = QString("%1/%2/%3").arg(mapTile.zoomLevel()).arg(mapTile.x()).arg(mapTile.y());
                    tiles[name] << tile;
                    if (innerNodes < 4) {
                        boundaryTiles << name;
                    }
                } else {
                    --total;
                }
            }
```

#### AUTO 


```{c}
auto nodeId
```

#### AUTO 


```{c}
auto placemark = static_cast<const GeoDataPlacemark*>(relation.first);
```

#### AUTO 


```{c}
auto const jsonRef
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            const GeoDataGeometry* geometry = placemark->geometry();
            if ( geometry->geometryId() == GeoDataLineStringId ) {
                const GeoDataLineString* lineString = dynamic_cast<const GeoDataLineString*>( geometry );
                Q_ASSERT( lineString && "Internal error: geometry ID does not match class type" );
                return lineString->length( EARTH_RADIUS );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ModelRegion &region: m_instructionRegions ) {
        if ( region.region.contains( point ) ) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)
```

#### RANGE FOR STATEMENT 


```{c}
for( const WayMerger & merger: mergers ) {
        result << merger.ways;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataFeature *feature: vector) {
            const GeoDataPlacemark* placemark = dynamic_cast<const GeoDataPlacemark*>(feature);
            if ( placemark ) {
                for (TrackerPluginItem *obj: m_satModel->items() ) {
                    if( obj->placemark() == placemark ) {
                        m_showOrbitAction->data() = m_trackerList.size();
                        m_showOrbitAction->setChecked( obj->isTrackVisible() );
                        widget->popupMenu()->addAction( Qt::LeftButton, m_showOrbitAction );

                        m_trackPlacemarkAction->data() = m_trackerList.size();
                        widget->popupMenu()->addAction( Qt::LeftButton, m_trackPlacemarkAction );

                        m_trackerList.append( obj );
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (VectorTileModel *mapper: d->m_tileModels) {
        mapper->clear();
    }
```

#### AUTO 


```{c}
auto const end = placemark->osmData().nodeReferencesEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
            if (!itPolygon->boundingRect().intersects(viewportRect)) {
                continue;
            }

            labelNodes.clear();

            QPainterPath path;
            path.addPolygon(*itPolygon);
            qreal pathLength = path.length();
            if (pathLength == 0) continue;

            int maxNumLabels = static_cast<int>(pathLength / labelWidth);

            if (maxNumLabels > 0) {
                qreal textRelativeLength = labelWidth / pathLength;
                int numLabels = 1;
                if (maxNumLabels > 1) {
                    numLabels = maxNumLabels/2;
                }
                qreal offset = (1.0 - numLabels*textRelativeLength)/numLabels;
                qreal startPercent = offset/2.0;

                for (int k = 0; k < numLabels; ++k, startPercent += textRelativeLength + offset) {
                    QPointF point = path.pointAtPercent(startPercent);
                    QPointF endPoint = path.pointAtPercent(startPercent + textRelativeLength);

                    if ( viewport().contains(point.toPoint()) || viewport().contains(endPoint.toPoint()) ) {
                        qreal angle = -path.angleAtPercent(startPercent);
                        qreal angle2 = -path.angleAtPercent(startPercent + textRelativeLength);
                        angle = GeoPainterPrivate::normalizeAngle(angle);
                        angle2 = GeoPainterPrivate::normalizeAngle(angle2);
                        bool upsideDown = angle > 90.0 && angle < 270.0;

                        if ( qAbs(angle - angle2) < 3.0 ) {
                            if ( upsideDown ) {
                                angle += 180.0;
                                point = path.pointAtPercent(startPercent + textRelativeLength);
                            }

                            d->drawTextRotated(point, angle, labelText);
                        } else {
                            for (int i = 0; i < labelText.length(); ++i) {
                                qreal currentGlyphTextLength = fontMetrics().width(labelText.left(i)) / pathLength;

                                if ( !upsideDown ) {
                                    angle = -path.angleAtPercent(startPercent + currentGlyphTextLength);
                                    point = path.pointAtPercent(startPercent + currentGlyphTextLength);
                                }
                                else {
                                    angle = -path.angleAtPercent(startPercent + textRelativeLength - currentGlyphTextLength) + 180;
                                    point = path.pointAtPercent(startPercent + textRelativeLength - currentGlyphTextLength);
                                }

                                d->drawTextRotated(point, angle, labelText.at(i));
                            }
                        }
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (GeoDataPlacemark const *a, GeoDataPlacemark const *b) {
            int const left = a->visualCategory() == GeoDataPlacemark::Bookmark ? -1 : a->visualCategory();
            int const right = b->visualCategory() == GeoDataPlacemark::Bookmark ? -1 : b->visualCategory();
            return left > right;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FileLoader *loader: m_loaderList ) {
            if ( loader ) {
                loader->wait();
            }
        }
```

#### AUTO 


```{c}
auto const styling = StyleParameters(d->m_feature, d->m_renderContext.tileLevel());
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder* folder: result->folderList() ) {
        BookmarkManagerPrivate::setVisualCategory( folder );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemB: m_diffB ) {
                if( EARTH_RADIUS * distanceSphere( itemA.m_placemarkB.coordinate(), itemB.m_placemarkB.coordinate() ) <= 1 ) {
                    if( ( itemA.m_action == DiffItem::Changed && ( itemB.m_action == DiffItem::Changed || itemB.m_action == DiffItem::Deleted ) )
                            || ( itemA.m_action == DiffItem::Deleted && itemB.m_action == DiffItem::Changed ) ) {
                        conflict = true;
                        other = itemB;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(Placemark* placemark: d->m_searchResultPlacemarks) {
        placemark->deleteLater();
    }
```

#### AUTO 


```{c}
auto country = QLocale::system().country();
```

#### AUTO 


```{c}
auto const last = std::unique(references.begin(), references.end());
```

#### AUTO 


```{c}
auto const osmTag = StyleBuilder::OsmTag(iter.key(), iter.value());
```

#### AUTO 


```{c}
auto currentMaxLabelHeight = m_maxLabelHeight;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &member: m_members) {
        auto const iter = placemarks.find(member.reference);
        if (iter != placemarks.constEnd()) {
            relation->addMember(*iter, member.reference, stringToType(member.type), member.role);
        }
    }
```

#### AUTO 


```{c}
auto node
```

#### AUTO 


```{c}
const auto tag = OsmTag(iter.key(), iter.value());
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &level: levels) {
        int const zoomLevel = level.toInt();
        maxZoomLevel = qMax(zoomLevel, maxZoomLevel);
        zoomLevels << zoomLevel;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &tag: tags ) {
        const QStringList tagSplit = tag.split(QLatin1Char('='));

        // Only "key=value" mappings should be checked
        Q_ASSERT( tagSplit.size() == 2  );

        QString key = tagSplit.at( 0 );
        QString value = tagSplit.at( 1 );

        if (value == QLatin1String("*") && osmData.containsTagKey(key)) {
            return true;
        }
        else if (value != QLatin1String("*") && osmData.containsTag(key, value)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& point : m_bottomEdge) {
                intersectionsBottom << QSharedPointer<LinkedPoint>(new LinkedPoint(point));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                nodeIndex = 0;
                for(const auto &point: innerPath) {
                    GeoDataCoordinates const coordinates = point.coordinates();
                    innerRing << coordinates;
                    auto const originalOsmData = innerRingOsmData.nodeReference(coordinates);
                    if (originalOsmData.id() > 0) {
                        newInnerRingOsmData.addNodeReference(coordinates, originalOsmData);
                    }
                    ++nodeIndex;
                }
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( SoundTrack* track: d->m_soundTracks ){
        track->stop();
        track->setPaused( false );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( VisiblePlacemark* mark: m_paintOrder ) {
        if ( mark->labelRect().contains( curpos ) || mark->symbolRect().contains( curpos ) ) {
            ret.append( mark->placemark() );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &baseDir: baseDirs ) {
            const QString base = baseDir + QLatin1String("/maps/earth/monav/");
            loadMap( base );
            QDir::Filters filters = QDir::AllDirs | QDir::Readable | QDir::NoDotAndDotDot;
            QDirIterator::IteratorFlags flags = QDirIterator::Subdirectories | QDirIterator::FollowSymlinks;
            QDirIterator iter( base, filters, flags );
            while ( iter.hasNext() ) {
                iter.next();
                loadMap( iter.filePath() );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *dataset: layer->datasets() ) {
            const GeoSceneGeodata *data = static_cast<const GeoSceneGeodata*>( dataset );
            QString containername = data->sourceFile();
            QString colorize = data->colorize();
            if( key == containername ) {
                if (colorize == QLatin1String("land")) {
                    m_textureLayer.addLandDocument( doc );
                }
                if (colorize == QLatin1String("sea")) {
                    m_textureLayer.addSeaDocument( doc );
                }

                // set visibility according to theme property
                if( !data->property().isEmpty() ) {
                    bool value;
                    m_model->mapTheme()->settings()->propertyValue( data->property(), value );
                    doc->setVisible( value );
                    m_model->treeModel()->updateFeature( doc );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto placemark: placemarks) {
            if (d->m_placemark && placemark->coordinate() == d->m_placemark->placemark().coordinate()) {
                d->m_placemark->deleteLater();
                d->m_placemark = nullptr;
            } else {
                if (d->m_placemark) {
                    d->m_placemark->deleteLater();
                }
                d->m_placemark = new Placemark(this);
                d->m_placemark->setGeoDataPlacemark(*placemark);
            }
            delete d->m_placemarkItem;
            d->m_placemarkItem = nullptr;
            updatePlacemarks();
            return;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto memberId: memberIds) {
        if (d->m_memberIds.contains(memberId)) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto aliveTimeout = getenv("TIREX_BACKEND_ALIVE_TIMEOUT");
```

#### AUTO 


```{c}
auto const category = m_placemark.visualCategory();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& settingKey: profile.pluginSettings()[ key ].keys() ) {
                 Q_ASSERT(settingKey != QLatin1String("Enabled"));
                 settings.setValue( settingKey, profile.pluginSettings()[ key ][ settingKey ] );
             }
```

#### LAMBDA EXPRESSION 


```{c}
[placeName] (GeoDataPlacemark* a, GeoDataPlacemark* b) {
        return levenshteinDistance(a->name(), placeName) < levenshteinDistance(b->name(), placeName);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( SearchTask *task: d->m_searchTasks ) {
        QThreadPool::globalInstance()->start( task );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QRectF &rect: boundingRects() ) {
        if( rect.contains( point ) )
            return rect;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TileId &tileId: visibleTiles( viewport, tileLevel ) ) {
            placemarkList += m_placemarkCache.value( tileId );
        }
```

#### AUTO 


```{c}
auto iter = m_networks.find(field);
```

#### AUTO 


```{c}
auto greatparentContainer = dynamic_cast<GeoDataContainer *>(greatParentObject)
```

#### RANGE FOR STATEMENT 


```{c}
for( SatellitesConfigAbstractItem *item: m_children ) {
                item->setData( column, role, data );
            }
```

#### AUTO 


```{c}
const auto key = data.constData() + nextIdx;
```

#### RANGE FOR STATEMENT 


```{c}
for( const Way & way: ways ) {
        mergers << WayMerger( way );
    }
```

#### AUTO 


```{c}
const auto lookAt = (flyTo->view() ? geodata_cast<GeoDataLookAt>(flyTo->view()) : 0)
```

#### RANGE FOR STATEMENT 


```{c}
for(QQuickItem* item: d->m_searchResultItems) {
        item->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: map2->placemarkList()) {
        GeoDataPlacemark* land = new GeoDataPlacemark(*placemark);
        if (geodata_cast<GeoDataPolygon>(land->geometry())) {
            land->setOsmData(marbleLand);
        }
        mergedMap->append(land);
    }
```

#### AUTO 


```{c}
const auto screenOverlay = geodata_cast<GeoDataScreenOverlay>(overlay)
```

#### AUTO 


```{c}
auto const document = m_documents.take(id);
```

#### AUTO 


```{c}
auto const &level
```

#### RANGE FOR STATEMENT 


```{c}
for (auto layer : m_mapTheme->map()->layers()) {
        if (layer->backend() != dgml::dgmlValue_geodata
            && layer->backend() != dgml::dgmlValue_vector) {
            continue;
        }

        for (auto dataset: layer->datasets()) {
            data = dynamic_cast<const GeoSceneGeodata *>(dataset);
            if (data != nullptr && data->sourceFile() == filePath) {
                break;
            }
        }

        if (data) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto const size = QSize(width, height);
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
            regions += QRegion ( (*itPolygon).toPolygon(), fillRule );
        }
```

#### AUTO 


```{c}
auto const & a = mapFromItem(m_map, polygon->at(i));
```

#### AUTO 


```{c}
const auto &node = nodes[id];
```

#### AUTO 


```{c}
auto const difficulty = osmData.tagValue("piste:difficulty");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems.positive) {
            if (item->contains(curpos, viewport)) {
                result << item->feature();
            }
        }
```

#### AUTO 


```{c}
auto &via
```

#### RANGE FOR STATEMENT 


```{c}
for( AnimatedUpdateTrack* track: d->m_animatedUpdateTracks) {
        track->pause();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &routeFilename: cachedRoutes ) {
        QFile file(d->m_cacheDir.absolutePath() + QLatin1Char('/') + routeFilename);
        file.open( QFile::ReadOnly );

        GeoDataParser parser( GeoData_KML );
        if( !parser.read( &file ) ) {
            mDebug() << QLatin1String("Could not read ") + routeFilename;
        }

        file.close();

        QString routeName;
        GeoDocument *geoDoc = parser.releaseDocument();
        GeoDataDocument *container = dynamic_cast<GeoDataDocument*>( geoDoc );
        if ( container && container->size() > 0 ) {
            GeoDataFolder *folder = container->folderList().at( 0 );
            for ( GeoDataPlacemark *placemark: folder->placemarkList() ) {
                routeName += placemark->name() + QLatin1String(" - ");
            }
        }

        routeName = routeName.left( routeName.length() - 3 );
        QString timestamp = routeFilename.left( routeFilename.length() - 4 );
        QString distance(QLatin1Char('0'));
        QString duration(QLatin1Char('0'));

        QString previewPath = QString( "%0/preview/%1.jpg" ).arg( d->m_cacheDir.absolutePath(), timestamp );
        QIcon preview;

        if( QFile( previewPath ).exists() ) {
            preview = QIcon( previewPath );
        }

        // Would that work on Windows?
        QUrl previewUrl( QString( "file://%0" ).arg( previewPath ) );

        RouteItem item;
        item.setIdentifier( timestamp );
        item.setName( routeName );
        item.setDistance( distance );
        item.setDistance( duration );
        item.setPreview( preview );
        item.setPreviewUrl( previewUrl );
        item.setOnCloud( false );
        routeList.append( item );
    }
```

#### AUTO 


```{c}
const auto multigeo = geodata_cast<GeoDataMultiGeometry>(object)
```

#### AUTO 


```{c}
auto tagIter = osmData.findTag(QStringLiteral("width"));
```

#### AUTO 


```{c}
const auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry())
```

#### AUTO 


```{c}
auto i = 0;
```

#### LAMBDA EXPRESSION 


```{c}
[&](QSharedPointer<LinkedPoint>& intersection) {
        switch(borderSector(intersection->point())) {
        case 1:
            intersectionsTop << intersection;
            break;
        case 3:
            intersectionsLeft << intersection;
            break;
        case 5:
            intersectionsRight << intersection;
            break;
        case 7:
            intersectionsBottom << intersection;
            break;
        default: break;
        }
    }
```

#### AUTO 


```{c}
auto yellow = Qt::yellow;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &filename: filelist ) {

        QLinearGradient  gradient( 0, 0, 256, 0 );

        QFile  file( filename );
        file.open( QIODevice::ReadOnly );
        QTextStream  stream( &file );  // read the data from the file

        QString      evalstrg;

        while ( !stream.atEnd() ) {
            stream >> evalstrg;
            if (!evalstrg.isEmpty() && evalstrg.contains(QLatin1Char('='))) {
                QString  colorValue = evalstrg.left(evalstrg.indexOf(QLatin1Char('=')));
                QString  colorPosition = evalstrg.mid(evalstrg.indexOf(QLatin1Char('=')) + 1);
                gradient.setColorAt( colorPosition.toDouble(),
                                     QColor( colorValue ) );
            }
        }
        gradientPainter.setBrush( gradient );
        gradientPainter.drawRect( 0, 0, 256, 1 );

        QLinearGradient  shadeGradient( - shadingStart, 0, 256 - shadingStart, 0 );

        shadeGradient.setColorAt(0.00, QColor(Qt::white));
        shadeGradient.setColorAt(0.15, QColor(Qt::white));
        shadeGradient.setColorAt(0.75, QColor(Qt::black));
        shadeGradient.setColorAt(1.00, QColor(Qt::black));

        const QRgb * gradientScanLine  = (QRgb*)( gradientImage.scanLine( 0 ) );
        const QRgb * shadingScanLine   = (QRgb*)( shadingImage.scanLine( 0 ) );

        for ( int i = 0; i < 256; ++i ) {

            QRgb shadeColor = *(gradientScanLine + i );
            shadeGradient.setColorAt(0.496, shadeColor);
            shadeGradient.setColorAt(0.504, shadeColor);
            shadingPainter.setBrush( shadeGradient );
            shadingPainter.drawRect( 0, 0, 16, 1 );

            // populate texturepalette[][]
            for ( int j = 0; j < 16; ++j ) {
                texturepalette[j][offset + i] = *(shadingScanLine + j );
            }
        }

        offset += 256;
    }
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(*iter)
```

#### RANGE FOR STATEMENT 


```{c}
for( auto *layer: d->m_internalLayers ) {
            if ( layer && layer->renderPosition().contains( renderPosition ) ) {
                layers.push_back( layer );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto peak: peaks) {
        if (visited.contains(peak)) {
            continue;
        }
        visited << peak;
        auto neighbors = peaksNear(peak, peaks, maxDistance);
        if (neighbors.size() < minPoints) {
            noise << peak;
        } else {
            PeakCluster* fit = nullptr;
            for (auto &cluster: clusters) {
                for (auto placemark: cluster) {
                    if (peak->coordinate().sphericalDistanceTo(placemark->coordinate()) < maxDistance) {
                        fit = &cluster;
                    }
                }
            }
            if (!fit) {
                clusters << PeakCluster();
                fit = &clusters.last();
            }

            while (!neighbors.isEmpty()) {
                auto neighbor = neighbors.front();
                neighbors.pop_front();
                if (!visited.contains(neighbor)) {
                    visited << neighbor;
                    auto const moreNeighbors = peaksNear(neighbor, peaks, maxDistance);
                    if (moreNeighbors.size() >= minPoints) {
                        neighbors += moreNeighbors;
                    }
                }
                if (associations[neighbor] == nullptr) {
                    *fit << neighbor;
                    associations[neighbor] = fit;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *mapper: d->m_activeTileModels) {
        tiles += mapper->cachedDocuments();
    }
```

#### AUTO 


```{c}
auto style = m_styleBuilder->createStyle(parameters);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: m_relations) {
        if (relation->containsAnyOf(osmIds)) {
            GeoDataRelation* multi = new GeoDataRelation;
            multi->osmData() = relation->osmData();
            tile->append(multi);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( RenderPlugin *plugin: d->m_renderPlugins ) {
        parentItem->appendRow( plugin->item() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TileId &tileId: visibleTiles(*viewport, tileLevel)) {
            placemarkList += m_placemarkCache.value( tileId );
        }
```

#### AUTO 


```{c}
auto relation = static_cast<const GeoDataRelation*>(feature);
```

#### AUTO 


```{c}
auto const & items
```

#### AUTO 


```{c}
auto const landmassZip = QString("%1/%2").arg(m_cacheDir).arg(m_landmassFile);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Node &a, const Node &b) { return a.second.id() < b.second.id(); }
```

#### AUTO 


```{c}
const auto folders = document->folderList();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto feature: features) {
            if (const auto placemark = geodata_cast<GeoDataPlacemark>(feature)) {
                placemarks << placemark;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const MonavStuffEntry &map: m_remoteMaps ) {
        Q_ASSERT( map.isValid() );
        if ( map.continent() == continent && map.state() == state ) {
            QString item = "%1 - %2";
            if ( map.region().isEmpty() ) {
                item = item.arg( map.state() );
                comboBox->addItem( item.arg( map.transport() ), map.payload() );
            } else {
                item = item.arg( map.region(), map.transport() );
                regions.insert( item, map.payload() );
            }
        }
    }
```

#### AUTO 


```{c}
const auto *mapper
```

#### RANGE FOR STATEMENT 


```{c}
for (auto wayId: outerWays) {
        Q_ASSERT(ways.contains(wayId));
        const auto &osmData = ways[wayId].osmData();
        GeoDataPlacemark::GeoDataVisualCategory const category = StyleBuilder::determineVisualCategory(osmData);
        if ((category == GeoDataPlacemark::None || category == outerCategory) && osmData.isEmpty()) {
            // Schedule way for removal: It's a non-styled way only used to create the outer boundary in this polygon
            usedWays << wayId;
        } // else we keep it

        for(auto nodeId: ways[wayId].references()) {
            ways[wayId].osmData().addNodeReference(nodes[nodeId].coordinates(), nodes[nodeId].osmData());
        }
    }
```

#### AUTO 


```{c}
auto const latLonAltBox = viewport->viewLatLonAltBox();
```

#### RANGE FOR STATEMENT 


```{c}
for( const Coordinate & node: m_coordinates ) {
        minLon.first  = qMin( node.lon, minLon.first );
        minLon.second = qMax( node.lon, minLon.second );
        minLat.first  = qMin( node.lat, minLat.first );
        minLat.second = qMax( node.lat, minLat.second );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoGraphicsItem *item: d->m_selectedItems ) {
        item->setHighlighted( false );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter) {
        ++count;
        QString const outputDir = QString("%1/%2").arg(m_baseDir).arg(tileId.x());
        QString const outputFile = QString("%1/%2.o5m").arg(outputDir).arg(tileId.y());
        if (QFileInfo(outputFile).exists()) {
            continue;
        }

        printProgress(count / double(iter.total()));
        cout << " Creating landmass cache tile " << count << "/" << iter.total() << " (";
        cout << m_zoomLevel << "/" << tileId.x() << "/" << tileId.y() << ')' << string(20, ' ') << '\r';
        cout.flush();

        QDir().mkpath(outputDir);
        if (!clipper) {
            map = open(m_inputFile, m_manager);
            if (!map) {
                qCritical() << "Failed to open " << m_inputFile << ". This can happen when Marble was compiled without shapelib (libshp), when the system has too little memory (RAM + swap need to be at least 8G), or when the download of the landmass data file failed.";
            }
            clipper = QSharedPointer<VectorClipper>(new VectorClipper(map.data(), m_zoomLevel));
        }
        auto tile = clipper->clipTo(m_zoomLevel, tileId.x(), tileId.y());
        if (!GeoDataDocumentWriter::write(outputFile, *tile)) {
            qWarning() << "Failed to write tile" << outputFile;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dir: dirs) {
            QString fileName = m_sourceDir + QLatin1Char('/') + dir + QLatin1Char('/');
            if ( lat < 0 ) lat *= -1;
            fileName += QString( "%1%2%3%4.hgt" ).arg( NS ).arg( lat<0 ? lat*-1 : lat, 2, 10, QLatin1Char('0') )
                                        .arg( EW ).arg( lng<0 ? lng*-1 : lng, 3, 10, QLatin1Char('0' ) );
            //qDebug() << fileName;

            if (!QFile::exists(fileName) && QFile::exists(fileName + QLatin1String(".zip"))) {
                qDebug() << "zip found, unzipping";
                QProcess p;
                p.execute("unzip", QStringList() << fileName + QLatin1String(".zip"));
                p.waitForFinished();
                QFile(QDir::currentPath() + QLatin1Char('/') + QFileInfo(fileName).fileName()).rename(fileName);
            }
            if ( QFile::exists( fileName ) ) {
                return fileName;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: relations) {
                if (relation->isVisible()) {
                    styling.relation = relation;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoSceneLayer *layer: m_mapTheme->map()->layers() ) {
        if ( layer->backend() == dgml::dgmlValue_geodata 
             || layer->backend() == dgml::dgmlValue_vector )
        {
            for( GeoSceneAbstractDataset *dataset: layer->datasets() ) {
                GeoSceneGeodata *data = static_cast<GeoSceneGeodata*>( dataset );
                if ( data ) {
                    if ( data->sourceFile() == filePath ) {
                        GeoDataDocument *doc = m_fileManager.at( filePath );
                        Q_ASSERT( doc );

                        addHighlightStyle( doc );

                        QPen pen = data->pen();
                        QBrush brush = data->brush();
                        const QVector<QColor> colors = data->colors();
                        GeoDataLineStyle lineStyle( pen.color() );
                        lineStyle.setPenStyle( pen.style() );
                        lineStyle.setWidth( pen.width() );

                        if ( !colors.isEmpty() ) {
                            qreal alpha = data->alpha();
                            QVector<GeoDataFeature*>::iterator it = doc->begin();
                            QVector<GeoDataFeature*>::iterator const itEnd = doc->end();
                            for ( ; it != itEnd; ++it ) {
                                GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>( *it );
                                if ( placemark ) {
                                    GeoDataStyle::Ptr style(new GeoDataStyle);
                                    style->setId(QStringLiteral("normal"));
                                    style->setLineStyle( lineStyle );
                                    quint8 colorIndex = placemark->style()->polyStyle().colorIndex();
                                    GeoDataPolyStyle polyStyle;
                                    // Set the colorIndex so that it's not lost after setting new style.
                                    polyStyle.setColorIndex( colorIndex );
                                    QColor color;
                                    // color index having value 99 is undefined
                                    Q_ASSERT( colors.size() );
                                    if ( colorIndex > colors.size() || ( colorIndex - 1 ) < 0 )
                                    {
                                        color = colors[0];      // Assign the first color as default
                                    }
                                    else {
                                        color = colors[colorIndex-1];
                                    }
                                    color.setAlphaF( alpha );
                                    polyStyle.setColor( color );
                                    polyStyle.setFill( true );
                                    style->setPolyStyle( polyStyle );
                                    placemark->setStyle( style );
                                }
                            }
                        }
                        else {
                            GeoDataStyle::Ptr style(new GeoDataStyle);
                            GeoDataPolyStyle polyStyle( brush.color() );
                            polyStyle.setFill( true );
                            style->setLineStyle( lineStyle );
                            style->setPolyStyle( polyStyle );
                            style->setId(QStringLiteral("default"));
                            GeoDataStyleMap styleMap;
                            styleMap.setId(QStringLiteral("default-map"));
                            styleMap.insert(QStringLiteral("normal"), QLatin1Char('#') + style->id());
                            doc->addStyle( style );
                            doc->addStyleMap( styleMap );

                            const QString styleUrl = QLatin1Char('#') + styleMap.id();
                            QVector<GeoDataFeature*>::iterator iter = doc->begin();
                            QVector<GeoDataFeature*>::iterator const end = doc->end();

                            for ( ; iter != end; ++iter ) {
                                if ( (*iter)->nodeType() == GeoDataTypes::GeoDataPlacemarkType ) {
                                    GeoDataPlacemark *placemark = dynamic_cast<GeoDataPlacemark*>( *iter );
                                    Q_ASSERT( placemark );
                                    if ( placemark->geometry()->nodeType() != GeoDataTypes::GeoDataTrackType &&
                                        placemark->geometry()->nodeType() != GeoDataTypes::GeoDataPointType )
                                    {
                                        placemark->setStyleUrl(styleUrl);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto const level = tileZoomLevel();
```

#### AUTO 


```{c}
auto const & osmData = parameters.placemark->osmData();
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFeature* feature: m_deletedObjects ) {
        if( feature->targetId().isEmpty() ) {
            continue;
        }
        GeoDataFeature* target = findFeature( m_rootDocument, feature->targetId() );
        if ( target ) {
            /** @todo Do we have to note the original row position and restore it? */
            Q_ASSERT( dynamic_cast<GeoDataContainer*>( target ) );
            emit added( static_cast<GeoDataContainer*>( target ), feature, -1 );
            if( feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType )
            {
                GeoDataPlacemark *placemark = static_cast<GeoDataPlacemark*>( feature );
                if( placemark->isBalloonVisible() ) {
                    emit balloonShown( placemark );
                }
            }
        } // else the root document was modified in an unfortunate way and we cannot restore it at this point
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& pluginName: profileGroup.groupList() ) {
                KConfigGroup pluginGroup = profileGroup.group( pluginName );
                profile.pluginSettings().insert( pluginName, QHash<QString, QVariant>() );
                for ( const QString& key: pluginGroup.keyList() ) {
                    if (key != QLatin1String("Enabled")) {
                        profile.pluginSettings()[ pluginName ].insert( key, pluginGroup.readEntry( key ) );
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneLayer *layer: m_model->mapTheme()->map()->layers() ) {
        if ( layer->backend() != dgml::dgmlValue_geodata
             && layer->backend() != dgml::dgmlValue_vector )
            continue;

        // look for documents
        for ( const GeoSceneAbstractDataset *dataset: layer->datasets() ) {
            const GeoSceneGeodata *data = static_cast<const GeoSceneGeodata*>( dataset );
            QString containername = data->sourceFile();
            QString colorize = data->colorize();
            if( key == containername ) {
                if (colorize == QLatin1String("land")) {
                    m_textureLayer.addLandDocument( doc );
                }
                if (colorize == QLatin1String("sea")) {
                    m_textureLayer.addSeaDocument( doc );
                }

                // set visibility according to theme property
                if( !data->property().isEmpty() ) {
                    bool value;
                    m_model->mapTheme()->settings()->propertyValue( data->property(), value );
                    doc->setVisible( value );
                    m_model->treeModel()->updateFeature( doc );
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
        GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
        newPlacemark->setVisible(placemark->isVisible());
        newPlacemark->setVisualCategory(placemark->visualCategory());
        GeoDataLinearRing outerRing;
        OsmPlacemarkData const & placemarkOsmData = placemark->osmData();
        OsmPlacemarkData & newPlacemarkOsmData = newPlacemark->osmData();
        int index = -1;
        OsmPlacemarkData const & outerRingOsmData = placemarkOsmData.memberReference(index);
        OsmPlacemarkData & newOuterRingOsmData = newPlacemarkOsmData.memberReference(index);
        pathToRing(path, &outerRing, outerRingOsmData, newOuterRingOsmData, coordMap);

        GeoDataPolygon* newPolygon = new GeoDataPolygon;
        newPolygon->setOuterBoundary(outerRing);
        if (isBuilding) {
            const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
            GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
            newBuilding->multiGeometry()->clear();
            newBuilding->multiGeometry()->append(newPolygon);
            newPlacemark->setGeometry(newBuilding);
        } else {
            newPlacemark->setGeometry(newPolygon);
        }
        if (placemarkOsmData.id() > 0) {
            newPlacemarkOsmData.addTag(QStringLiteral("mx:oid"), QString::number(placemarkOsmData.id()));
        }
        copyTags(placemarkOsmData, newPlacemarkOsmData);
        copyTags(outerRingOsmData, newOuterRingOsmData);
        if (outerRingOsmData.id() > 0) {
            newOuterRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(outerRingOsmData.id()));
        }

        auto const & innerBoundaries = qAsConst(polygon)->innerBoundaries();
        for (index = 0; index < innerBoundaries.size(); ++index) {
            auto const & innerBoundary = innerBoundaries.at(index);
            if (minArea > 0.0 && area(innerBoundary) < minArea) {
                continue;
            }

            auto const & innerRingOsmData = placemarkOsmData.memberReference(index);
            clipper.Clear();
            clipper.AddPath(path, ptClip, true);
            Path innerPath;
            coordMap.clear();
            for(auto const & node: innerBoundary) {
                auto p = coordinateToPoint(node);
                coordMap.insert(std::make_pair(p.X, p.Y), &node);
                innerPath.push_back(std::move(p));
            }
            clipper.AddPath(innerPath, ptSubject, true);
            Paths innerPaths;
            clipper.Execute(ctIntersection, innerPaths);
            for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                pathToRing(innerPath, &innerRing, innerRingOsmData, newInnerRingOsmData, coordMap);
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
        }

        OsmObjectManager::initializeOsmData(newPlacemark);
        document->append(newPlacemark);
        osmIds << placemark->osmData().id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QFileInfo &file: subdirs ) {
            SpeakersModelItem item;
            item.m_file = file;
            m_speakers << item;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataStyleMap &styleMap: doc->styleMaps()) {
                if (styleMap.contains(QStringLiteral("highlight"))) {
                    isHighlight = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto soundCue = geodata_cast<GeoDataSoundCue>(primitive)
```

#### AUTO 


```{c}
auto multiGeometry = geodata_cast<GeoDataMultiGeometry>(placemark->geometry())
```

#### AUTO 


```{c}
const auto end = osmData.nodeReferencesEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataFolder *folder: document->folderList() ) {
        QString path = QString( "/%0" ).arg( folder->name() );
        diffItems.append( getPlacemarks( folder, path, other, diffDirection ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *mapper: d->m_activeTileModels) {
        level = qMax(level, mapper->tileZoomLevel());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin* plugin: m_marbleMap.renderPlugins() ) {
        plugin->setEnabled( false );
    }
```

#### AUTO 


```{c}
const auto parentfolder = geodata_cast<GeoDataFolder>(parent)
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::GeoDataPlacemark * const placemark: folder->placemarkList() ) {
            if (placemark->coordinate().sphericalDistanceTo(compareTo) * planetRadius < 5) {
                return true;
            }
        }
```

#### AUTO 


```{c}
const auto staticPlugins = QPluginLoader::staticInstances();
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: document->placemarkList() ) {
        const GeoDataGeometry* geometry = placemark->geometry();
        const GeoDataLineString* lineString = dynamic_cast<const GeoDataLineString*>( geometry );
        if ( lineString ) {
            return lineString;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( TrackerPluginItem *item: m_itemVector ) {
            item->update();
        }
```

#### AUTO 


```{c}
auto &map = GeoDataRelationPrivate::s_relationTypes;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tileId: tiles) {
            QFile::remove(osmFileFor(tileId));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &databaseFile: m_databaseFiles ) {
        database.setDatabaseName( databaseFile );
        if ( !database.open() ) {
            qWarning() << "Failed to connect to database" << databaseFile;
        }

        QString regionRestriction;
        if ( !userQuery.region().isEmpty() ) {
            QTime regionTimer;
            regionTimer.start();
            // Nested set model to support region hierarchies, see https://en.wikipedia.org/wiki/Nested_set_model
            const QString regionsQueryString = QLatin1String("SELECT lft, rgt FROM regions WHERE name LIKE '%") + userQuery.region() + QLatin1String("%';");
            QSqlQuery regionsQuery( regionsQueryString, database );
            if ( regionsQuery.lastError().isValid() ) {
                qWarning() << regionsQuery.lastError() << "in" << databaseFile << "with query" << regionsQuery.lastQuery();
            }
            regionRestriction = " AND (";
            int regionCount = 0;
            while ( regionsQuery.next() ) {
                if ( regionCount > 0 ) {
                    regionRestriction += QLatin1String(" OR ");
                }
                regionRestriction += QLatin1String(" (regions.lft >= ") + regionsQuery.value( 0 ).toString() +
                                     QLatin1String(" AND regions.lft <= ") + regionsQuery.value( 1 ).toString() + QLatin1Char(')');
                regionCount++;
            }
            regionRestriction += QLatin1Char(')');

            mDebug() << Q_FUNC_INFO << "region query in" << databaseFile << "with query" << regionsQueryString
                     << "took" << regionTimer.elapsed() << "ms for" << regionCount << "results";

            if ( regionCount == 0 ) {
                continue;
            }
        }

        QString queryString;

        queryString = " SELECT regions.name,"
                " places.name, places.number,"
                " places.category, places.lon, places.lat"
                " FROM regions, places";

        if ( userQuery.queryType() == DatabaseQuery::CategorySearch ) {
            queryString += QLatin1String(" WHERE regions.id = places.region");
            if( userQuery.category() == OsmPlacemark::UnknownCategory ) {
                // search for all pois which are not street nor address
                queryString += QLatin1String(" AND places.category <> 0 AND places.category <> 6");
            } else {
                // search for specific category
                queryString += QLatin1String(" AND places.category = %1");
                queryString = queryString.arg( (qint32) userQuery.category() );
            }
            if ( userQuery.position().isValid() && userQuery.region().isEmpty() ) {
                // sort by distance
                queryString += QLatin1String(" ORDER BY ((places.lat-%1)*(places.lat-%1)+(places.lon-%2)*(places.lon-%2))");
                GeoDataCoordinates position = userQuery.position();
                queryString = queryString.arg( position.latitude( GeoDataCoordinates::Degree ), 0, 'f', 8 )
                        .arg( position.longitude( GeoDataCoordinates::Degree ), 0, 'f', 8 );
            } else {
                queryString += regionRestriction;
            }
        } else if ( userQuery.queryType() == DatabaseQuery::BroadSearch ) {
            queryString += QLatin1String(" WHERE regions.id = places.region"
                    " AND places.name ") + wildcardQuery(userQuery.searchTerm());
        } else {
            queryString += QLatin1String(" WHERE regions.id = places.region"
                    "   AND places.name ") + wildcardQuery(userQuery.street());
            if ( !userQuery.houseNumber().isEmpty() ) {
                queryString += QLatin1String(" AND places.number ") + wildcardQuery(userQuery.houseNumber());
            } else {
                queryString += QLatin1String(" AND places.number IS NULL");
            }
            queryString += regionRestriction;
        }

        queryString += QLatin1String(" LIMIT 50;");

        /** @todo: sort/filter results from several databases */

        QSqlQuery query( database );
        query.setForwardOnly( true );
        QTime queryTimer;
        queryTimer.start();
        if ( !query.exec( queryString ) ) {
            qWarning() << query.lastError() << "in" << databaseFile << "with query" << query.lastQuery();
            continue;
        }

        int resultCount = 0;
        while ( query.next() ) {
            OsmPlacemark placemark;
            if ( userQuery.resultFormat() == DatabaseQuery::DistanceFormat ) {
                GeoDataCoordinates coordinates( query.value(4).toFloat(), query.value(5).toFloat(), 0.0, GeoDataCoordinates::Degree );
                placemark.setAdditionalInformation( formatDistance( coordinates, userQuery.position() ) );
            } else {
                placemark.setAdditionalInformation( query.value( 0 ).toString() );
            }
            placemark.setName( query.value(1).toString() );
            placemark.setHouseNumber( query.value(2).toString() );
            placemark.setCategory( (OsmPlacemark::OsmCategory) query.value(3).toInt() );
            placemark.setLongitude( query.value(4).toFloat() );
            placemark.setLatitude( query.value(5).toFloat() );

            result.push_back( placemark );
            resultCount++;
        }

        mDebug() << Q_FUNC_INFO << "query in" << databaseFile << "with query" << queryString
                 << "took" << queryTimer.elapsed() << "ms for" << resultCount << "results";
    }
```

#### AUTO 


```{c}
auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
```

#### AUTO 


```{c}
auto container = dynamic_cast<GeoDataContainer *>(parentItem)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &key: keys) {
        if (addTagValue(target, key)) {
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto nodeId: ways[wayId].references()) {
            ways[wayId].osmData().addNodeReference(nodes[nodeId].coordinates(), nodes[nodeId].osmData());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDataPluginItem *item: items ) {
        if( !item ) {
            continue;
        }

        // If the item is already in our list, don't add it.
        if ( d->m_itemSet.contains( item ) ) {
            continue;
        }

        if( itemExists( item->id() ) ) {
            item->deleteLater();
            continue;
        }

        mDebug() << "New item " << item->id();

        // This find the right position in the sorted to insert the new item
        QList<AbstractDataPluginItem*>::iterator i = std::lower_bound( d->m_itemSet.begin(),
                                                                  d->m_itemSet.end(),
                                                                  item,
                                                                  lessThanByPointer );
        // Insert the item on the right position in the list
        d->m_itemSet.insert( i, item );

        connect( item, SIGNAL(stickyChanged()), this, SLOT(scheduleItemSort()) );
        connect( item, SIGNAL(destroyed(QObject*)), this, SLOT(removeItem(QObject*)) );
        connect( item, SIGNAL(updated()), this, SIGNAL(itemsUpdated()) );
        connect( item, SIGNAL(favoriteChanged(QString,bool)), this,
                 SLOT(favoriteItemChanged(QString,bool)) );

        if ( !needsUpdate && item->initialized() ) {
            needsUpdate = true;
        }

        if ( !favoriteChanged && item->initialized() && item->isFavorite() ) {
            favoriteChanged = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &cluster: clusters) {
        Q_ASSERT(!cluster.isEmpty());
        std::sort(cluster.begin(), cluster.end(), [](GeoDataPlacemark* a, GeoDataPlacemark* b) {
            return a->coordinate().altitude() > b->coordinate().altitude();
        });
        bool first = true;
        for (auto peak: cluster) {
            peak->osmData().addTag(QLatin1String("marbleZoomLevel"), first ? QLatin1String("11") : QLatin1String("13"));
            first = false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const commentRef : noteComments) {
                QJsonObject commentObj = commentRef.toObject();
                QDateTime date = QDateTime::fromString(commentObj.value("date").toString(), Qt::ISODate);
                QString user = commentObj.value("user").toString();
                QString text = commentObj.value("text").toString();
                int uid = commentObj.value("uid").toInt();
                Comment comment(date, text, user, uid);
                item->addComment(comment);
            }
```

#### AUTO 


```{c}
auto const pluginSystemPath = MarbleDirs::pluginSystemPath();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : items) {
                if (item->feature() == feature) {
                    items.removeOne(item);
                    removed = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto endIdx = data.indexOf('\n', nextIdx);
```

#### AUTO 


```{c}
const auto dgram = m_commandSocket.receiveDatagram();
```

#### RANGE FOR STATEMENT 


```{c}
for( const ParseRunnerPlugin *plugin: plugins ) {
        QStringList const extensions = plugin->fileExtensions();
        if ( extensions.contains( suffix ) || extensions.contains( completeSuffix ) ) {
            ParsingRunner* runner = plugin->newRunner();
            QString error;
            GeoDataDocument* document = runner->parseFile(fileName, UserDocument, error);
            if (!document && !error.isEmpty()) {
                mDebug() << QString("Failed to open vector tile %1: %2").arg(fileName, error);
            }
            delete runner;
            return document;
        }
    }
```

#### AUTO 


```{c}
auto const &tiles
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &format: formats ) {
        QString const result = MarbleDirs::path( audioTemplate.arg( name, format ) );
        if ( !result.isEmpty() ) {
            return result;
        }
    }
```

#### AUTO 


```{c}
auto item = iter.value();
```

#### AUTO 


```{c}
auto const features = d->m_map.whichFeatureAt(QPoint(x, y));
```

#### AUTO 


```{c}
const auto visiblePlacemarks = m_layout.visiblePlacemarks();
```

#### AUTO 


```{c}
auto itr = m_chunks.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &backend: s_backends) {
            if (backend.first == documentIdentifier) {
                backend.second->write(device, document);
                return true;
            }
        }
```

#### AUTO 


```{c}
auto chunk = matchItr.value();
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder *newFolder: source->folderList() ) {
        GeoDataFolder *existingFolder = m_manager->addNewBookmarkFolder(destination, newFolder->name());
        importBookmarksRecursively(newFolder, existingFolder, skipAll, replaceAll);
        for( GeoDataPlacemark* newPlacemark: newFolder->placemarkList() ) {
            bool added = skipAll;

            GeoDataCoordinates newCoordinate = newPlacemark->coordinate();
            GeoDataPlacemark *existingPlacemark = m_manager->bookmarkAt( m_manager->document(), newCoordinate );
            if ( existingPlacemark ) {
                if ( skipAll ) {
                    continue;
                }

                // Avoid message boxes for equal bookmarks, just skip them
                if ( existingPlacemark->name() == newPlacemark->name() &&
                    existingPlacemark->description() == newPlacemark->description() ) {
                    continue;
                }

                QPointer<QMessageBox> messageBox = new QMessageBox( m_parent );
                QString const intro = tr( "The file contains a bookmark that already exists among your Bookmarks." );
                QString const newBookmark = tr( "Imported bookmark" );
                QString const existingBookmark = tr( "Existing bookmark" );
                QString const question = tr( "Do you want to replace the existing bookmark with the imported one?" );
                QString html = QLatin1String("<p>%1</p><table><tr><td>%2</td><td><b>%3 / %4</b></td></tr>"
                                                "<tr><td>%5</td><td><b>%6 / %7</b></td></tr></table><p>%8</p>");
                html = html.arg( intro, existingBookmark, existingFolder->name(),
                                 existingPlacemark->name(), newBookmark, newFolder->name(),
                                 newPlacemark->name(), question );
                messageBox->setText( html );

                QAbstractButton *replaceButton    = messageBox->addButton(tr( "Replace" ),     QMessageBox::ActionRole );
                QAbstractButton *replaceAllButton = messageBox->addButton(tr( "Replace All" ), QMessageBox::ActionRole );
                QAbstractButton *skipButton       = messageBox->addButton(tr( "Skip" ),        QMessageBox::ActionRole );
                QAbstractButton *skipAllButton    = messageBox->addButton(tr( "Skip All" ),    QMessageBox::ActionRole );
                                                    messageBox->addButton( QMessageBox::Cancel );
                messageBox->setIcon( QMessageBox::Question );

                if ( !replaceAll ) {
                    messageBox->exec();
                }
                if ( messageBox->clickedButton() == replaceAllButton ) {
                    replaceAll = true;
                } else if ( messageBox->clickedButton() == skipAllButton ) {
                    skipAll = true;
                    added = true;
                } else if ( messageBox->clickedButton() == skipButton ) {
                    delete messageBox;
                    continue;
                } else if ( messageBox->clickedButton() != replaceButton ) {
                    delete messageBox;
                    return;
                }

                if ( messageBox->clickedButton() == replaceButton || replaceAll ) {
                    m_manager->removeBookmark( existingPlacemark );
                    m_manager->addBookmark( existingFolder, *newPlacemark );

                    mDebug() << "Placemark " << newPlacemark->name() << " replaces " << existingPlacemark->name();
                    delete messageBox;
                    break;
                }
                delete messageBox;
            }

            if ( !added ) {
                m_manager->addBookmark( existingFolder, *newPlacemark );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ParseRunnerPlugin *plugin: plugins ) {
        QStringList const extensions = plugin->fileExtensions();
        if ( extensions.isEmpty() || extensions.contains( suffix ) || extensions.contains( completeSuffix ) ) {
            ParsingTask *task = new ParsingTask( plugin->newRunner(), this, fileName, role );
            connect( task, SIGNAL(finished()), this, SLOT(cleanupParsingTask()) );
            mDebug() << "parse task " << plugin->nameId() << " " << (quintptr)task;
            ++d->m_parsingTasks;
            QThreadPool::globalInstance()->start( task );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF& position: d->positions()) {
            painter->drawPixmap(position, d->m_pixmap);
        }
```

#### AUTO 


```{c}
auto const tileId = TileId (0, centerTile.zoomLevel(), x, y);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &fallback: fallBackThemes) {
        if (installedThemes.contains(fallback)) {
            return fallback;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( T* plugin: plugins ) {
        if ( ( m_marbleModel && m_marbleModel->workOffline() && !plugin->canWorkOffline() ) ) {
            continue;
        }

        if ( !plugin->canWork() ) {
            continue;
        }

        if ( m_marbleModel && !plugin->supportsCelestialBody( m_marbleModel->planet()->id() ) )
        {
            continue;
        }

        result << plugin;
    }
```

#### AUTO 


```{c}
const auto value = dgram.data().constData() + midIdx + 1;
```

#### AUTO 


```{c}
const auto category = StyleBuilder::determineVisualCategory(data);
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * a, const GeoDataRelation * b) {
            if (a->relationType() == b->relationType()) {
                auto const refA = a->osmData().tagValue(QStringLiteral("ref"));
                auto const refB = b->osmData().tagValue(QStringLiteral("ref"));
                if (refA == refB) {
                    return a->name() < b->name();
                }
                return refA < refB;
            }
            return a->relationType() < b->relationType();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & items: d->m_tiledItems) {
        for (auto item: items) {
            item->resetStyle();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &item: mergedList ) {
        GeoDataPlacemark *placemark = new GeoDataPlacemark( item.m_placemarkA );
        QStringList splitten = item.m_path.split(QLatin1Char('/'), QString::SkipEmptyParts);
        GeoDataFolder *folder = createFolders( document, splitten );
        folder->append( placemark );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems.positive) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dir: path.split( QLatin1Char( ':' ) ) ) {
        QFileInfo const executable( QDir( dir ), program );
        if ( executable.exists() && executable.isExecutable() ) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder *folder: container->folderList() ) {
        QVariant folderVariant;
        folderVariant.setValue(folder);
        QString name = QString(' ').repeated(4*level) + folder->name();
        m_ui.m_folders->addItem( name, folderVariant );
        if( !folder->folderList().isEmpty() ) {
            initComboBox( folder, level+1 );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: m_visiblePlacemarks) {
                if (!extendedBox.contains(placemark->coordinates())) {
                    outdated << placemark;
                }
            }
```

#### AUTO 


```{c}
const auto tagIter = iter.value().findTag(QStringLiteral("addr:housenumber"));
```

#### AUTO 


```{c}
auto lineStringItem = new GeoLineStringGraphicsItem( placemark, line );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PluginAuthor& author: authors ) {
        string += author.name +  QLatin1String("\n    ") +
                  author.email + QLatin1String("\n    ") +
                  author.task +  QLatin1String("\n\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon : m_screenPolygons) {
                    polygons << *polygon;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl& url: mimeData->urls()) {
            success = openGeoUri(url.url());
            if (success) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoSceneItem *item: section->items()) {

            // checkbox for item
            QString checkBoxString;
            if (item->checkable()) {
                QString const checked = d->m_checkBoxMap[item->connectTo()] ? "checked" : "";
                checkBoxString = QLatin1String(
                        "<input type=\"checkbox\" "
                        "onchange=\"Marble.setCheckedProperty(this.name, this.checked);\" ")
                        + checked + QLatin1String(" name=\"") + item->connectTo() + QLatin1String("\" />");

            }

            // pixmap and text
            QString src;
            QString styleDiv;
            int pixmapWidth = 24;
            int pixmapHeight = 12;
            if (!item->icon()->pixmap().isEmpty()) {
                QString path = MarbleDirs::path( item->icon()->pixmap() );
                const QPixmap oncePixmap(path);
                pixmapWidth = oncePixmap.width();
                pixmapHeight = oncePixmap.height();
                src = QUrl::fromLocalFile( path ).toString();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px;");
            } else {
              // Workaround for rendered border around empty images in webkit
              src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
            }
            // NOTICE. There are some pixmaps without image, so we should
            //         create just a plain rectangle with set color
            if (QColor(item->icon()->color()).isValid()) {
                const QColor color = item->icon()->color();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px; background-color: ") + color.name() + QLatin1Char(';');
            }
            styleDiv += " position: relative; top: -3px;";
            const QString text = QCoreApplication::translate("DGML", item->text().toUtf8().constData());
            QString html = QLatin1String(
                    "<div class=\"legend-entry\">"
                    "  <label>") + checkBoxString + QLatin1String(
                    "    <img class=\"image-pic\" src=\"") + src + QLatin1String("\" style=\"") + styleDiv + QLatin1String("\"/>"
                    "    <span class=\"kotation\" >") + text + QLatin1String("</span>"
                    "  </label>"
                    "</div>");
            customLegendString += html;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QActionGroup *ag: *tmp_actionGroups ) {
               if( !ag->actions().isEmpty() ) {
                   m_pluginMenus.append( m_viewMenu->addSeparator() );
               }
               for( QAction *action: ag->actions() ) {
                   m_viewMenu->addAction( action );
                   m_pluginMenus.append( action );
               }
           }
```

#### AUTO 


```{c}
auto const refB = other.osmData().tagValue(QStringLiteral("ref"));
```

#### AUTO 


```{c}
const auto prevRing = geodata_cast<GeoDataLinearRing>(geometry)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: relations) {
        if (relation.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x12); // relation start indicator
        OsmPlacemarkData const & osmData = relation.second;

        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        lastId = osmData.id();
        writeVersion(osmData, bufferStream);

        QBuffer referencesBuffer;
        referencesBuffer.open(QIODevice::WriteOnly);
        QDataStream referencesStream(&referencesBuffer);
        if (const auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)) {
            if (const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry())) {
                auto polygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0));
                Q_ASSERT(polygon);
                writeMultipolygonMembers(*polygon, lastReferenceId, osmData, stringTable, referencesStream);
            } else {
                auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry());
                Q_ASSERT(polygon);
                writeMultipolygonMembers(*polygon, lastReferenceId, osmData, stringTable, referencesStream);
            }
        } else if (const auto placemark = geodata_cast<GeoDataRelation>(relation.first)) {
            writeRelationMembers(placemark, lastReferenceId, osmData, stringTable, referencesStream);
        } else {
            Q_ASSERT(false);
        }
        writeUnsigned(referencesBuffer.size(), bufferStream);
        bufferStream.writeRawData(referencesBuffer.data().constData(), referencesBuffer.size());

        writeTags(osmData, stringTable, bufferStream);

        writeUnsigned(buffer.size(), stream);
        stream.writeRawData(buffer.data().constData(), buffer.size());
    }
```

#### AUTO 


```{c}
auto & tileList = d->m_tiledItems[*tileIter];
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction *action: m_eclipsesListMenu->actions() ) {
            m_eclipsesListMenu->removeAction( action );
            delete action;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &fileName: pluginFileNameList ) {
        QString const baseName = QFileInfo(fileName).baseName();
        if (!m_whitelist.isEmpty() && !m_whitelist.contains(baseName)) {
            mDebug() << "Ignoring non-whitelisted plugin " << fileName;
            continue;
        }
        if (m_blacklist.contains(baseName)) {
            mDebug() << "Ignoring blacklisted plugin " << fileName;
            continue;
        }

        // mDebug() << fileName << " - " << MarbleDirs::pluginPath( fileName );
        QString const path = MarbleDirs::pluginPath( fileName );
#ifdef Q_OS_ANDROID
        QFileInfo targetFile( path );
        if ( !m_pluginPaths.contains( targetFile.canonicalFilePath() ) ) {
            // @todo Delete the file here?
            qDebug() << "Ignoring file " << path << " which is not among the currently installed plugins";
            continue;
        }
#endif
        QPluginLoader* loader = new QPluginLoader( path, m_parent );

        QObject * obj = loader->instance();

        if ( obj ) {
            bool isPlugin = appendPlugin<RenderPlugin, RenderPluginInterface>
                       ( obj, loader, m_renderPluginTemplates );
            isPlugin = isPlugin || appendPlugin<PositionProviderPlugin, PositionProviderPluginInterface>
                       ( obj, loader, m_positionProviderPluginTemplates );
            isPlugin = isPlugin || appendPlugin<SearchRunnerPlugin, SearchRunnerPlugin>
                       ( obj, loader, m_searchRunnerPlugins ); // intentionally T==U
            isPlugin = isPlugin || appendPlugin<ReverseGeocodingRunnerPlugin, ReverseGeocodingRunnerPlugin>
                       ( obj, loader, m_reverseGeocodingRunnerPlugins ); // intentionally T==U
            isPlugin = isPlugin || appendPlugin<RoutingRunnerPlugin, RoutingRunnerPlugin>
                       ( obj, loader, m_routingRunnerPlugins ); // intentionally T==U
            isPlugin = isPlugin || appendPlugin<ParseRunnerPlugin, ParseRunnerPlugin>
                       ( obj, loader, m_parsingRunnerPlugins ); // intentionally T==U
            if ( !isPlugin ) {
                qWarning() << "Ignoring the following plugin since it couldn't be loaded:" << path;
                mDebug() << "Plugin failure:" << path << "is a plugin, but it does not implement the "
                        << "right interfaces or it was compiled against an old version of Marble. Ignoring it.";
                delete loader;
            } else {
                foundPlugin = true;
            }
        } else {
            qWarning() << "Ignoring to load the following file since it doesn't look like a valid Marble plugin:" << path << endl
                       << "Reason:" << loader->errorString();
            delete loader;
        }
    }
```

#### AUTO 


```{c}
auto playlist = (parent.isValid() ? geodata_cast<GeoDataPlaylist>(parentObject) : 0)
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &mapThemeId: stringlist ) {
        const QString celestialBodyId = mapThemeId.section(QLatin1Char('/'), 0, 0);
        QString celestialBodyName = PlanetFactory::localizedName( celestialBodyId );

        QList<QStandardItem*> matchingItems = m_celestialList.findItems( celestialBodyId, Qt::MatchExactly, 1 );
        if ( matchingItems.isEmpty() ) {
            m_celestialList.appendRow( QList<QStandardItem*>()
                                << new QStandardItem( celestialBodyName )
                                << new QStandardItem( celestialBodyId ) );
        }
    }
```

#### AUTO 


```{c}
auto const & innerBoundaries = polygon->innerBoundaries();
```

#### AUTO 


```{c}
auto feature = dynamic_cast<GeoDataContainer *>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &line: lines ) {
        const QStringList fields = line.split(QLatin1Char(','));
        if (fields.size() >= 5) {
            qreal lon = fields.at(1).toDouble();
            qreal lat = fields.at(0).toDouble();
            GeoDataCoordinates coordinates( lon, lat, 0.0, GeoDataCoordinates::Degree );
            routeWaypoints.append( coordinates );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoSceneProperty* property: mapTheme->settings()->allProperties() ) {
            properties << property->name();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* innerPolygon: innerPolygons ) {
            *fillPolygon << *innerPolygon;
            *fillPolygon << innerPolygon->first();
            *fillPolygon << outerPolygon->first();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneProperty *property: m_properties ) {
        result << property;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& intersection : intersections) {
                if(intersection->isEntering() && !intersection->isProcessed()) {
                    iterateBasePolygon = true;

                    QSharedPointer<LinkedPoint> it = intersection;
                    clippedPolyObject << it->point();
                    it->setProcessed(true);

                    do {
                        if(iterateBasePolygon) {
                            it = it->nextBasePolygonPoint();
                            if(it->isLeaving()) {
                                iterateBasePolygon = false;
                                it->setProcessed(true);
                            } else if(it->isEntering()) {
                                it->setProcessed(true);
                            }
                        }  else {
                            it = it->nextClipPolygonPoint();
                            if(it->isEntering()) {
                                iterateBasePolygon = true;
                                it->setProcessed(true);
                            } else if(it->isLeaving()) {
                                it->setProcessed(true);
                            }
                        }
                        clippedPolyObject << it->point();
                        Q_ASSERT(clippedPolyObject.size() <= 2 * basePolygon.size());

                        //                        // To avoid crashes because of infinite loop.
                        //                        // Needs to be investigated
                        //                        if(clippedPolyObject.size() > basePolygon.size()) {
                        //                            qDebug() << "Something went wrong, exiting current clipping loop...";
                        //                            break;
                        //                        }

                    } while(clippedPolyObject.first() != clippedPolyObject.last());

                    clippedPolyObjects << clippedPolyObject;
                    clippedPolyObject = QPolygonF();
                }
            }
```

#### AUTO 


```{c}
auto style = d->createRelationStyle(parameters);
```

#### LAMBDA EXPRESSION 


```{c}
[](GeoDataPlacemark* placemark) {
        return placemark->visualCategory() == GeoDataPlacemark::NaturalPeak; }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF & clippedPolyObject: clippedPolyObjects ) { 
            if ( clippedPolyObject.size() > 2 ) {
                // mDebug() << "Size: " << clippedPolyObject.size();
                if (d->m_debugPolygonsLevel) {
                    QBrush brush = QPainter::brush();
                    QBrush originalBrush = brush;
                    QColor color = brush.color();
                    color.setAlpha(color.alpha()*0.75);
                    brush.setColor(color);
                    QPainter::setBrush(brush);

                    QPainter::drawPolygon ( clippedPolyObject, fillRule );

                    QPainter::setBrush(originalBrush);

                    d->debugDrawNodes( clippedPolyObject );
                }
                else {
                    QPainter::drawPolygon ( clippedPolyObject, fillRule );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & way: ways) {
        Q_ASSERT(way.first);
        if (way.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x11); // way start indicator
        OsmPlacemarkData const & osmData = way.second;

        bufferData.clear();
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        lastId = osmData.id();
        writeVersion(osmData, bufferStream);

        referencesBufferData.clear();
        referencesBuffer.open(QIODevice::WriteOnly);
        QDataStream referencesStream(&referencesBuffer);
        writeReferences(*way.first, lastReferenceId, osmData, referencesStream);
        referencesBuffer.close();
        writeUnsigned(referencesBufferData.size(), bufferStream);
        bufferStream.writeRawData(referencesBufferData.constData(), referencesBufferData.size());

        writeTags(osmData, stringTable, bufferStream);

        buffer.close();
        writeUnsigned(bufferData.size(), stream);
        stream.writeRawData(bufferData.constData(), bufferData.size());
    }
```

#### AUTO 


```{c}
auto const tags = tagsFilteredIn(m_tagZoomLevel);
```

#### RANGE FOR STATEMENT 


```{c}
for( const RequestRegion &region: m_regions ) {
        if ( region.region.contains( point ) ) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto seekPos = io->pos();
```

#### AUTO 


```{c}
auto const relation = d->m_relationTypeConverter.value(relationType, GeoDataRelation::UnknownType);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &innerRing: polygon->innerBoundaries() ) {
        ++index;
        const OsmPlacemarkData innerRingOsmData = osmData.memberReference( index );
        for (auto const &coordinates: innerRing) {
            m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
        }
        m_ways << OsmConverter::Way(&innerRing, innerRingOsmData);
    }
```

#### AUTO 


```{c}
auto const tile = TileId::fromCoordinates(coordinate, m_tileLevel);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const RoutingPoint &point: i.intersectionPoints() ) {
            stream << ',' << point.lat() << ',' << point.lon();
        }
```

#### AUTO 


```{c}
auto camera = geodata_cast<GeoDataCamera>(flyToElement()->view())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & way: ways) {
        Q_ASSERT(way.first);
        if (way.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x11); // way start indicator
        OsmPlacemarkData const & osmData = way.second;

        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        lastId = osmData.id();
        writeVersion(osmData, bufferStream);

        QBuffer referencesBuffer;
        referencesBuffer.open(QIODevice::WriteOnly);
        QDataStream referencesStream(&referencesBuffer);
        writeReferences(*way.first, lastReferenceId, osmData, referencesStream);
        writeUnsigned(referencesBuffer.size(), bufferStream);
        bufferStream.writeRawData(referencesBuffer.data().constData(), referencesBuffer.size());

        writeTags(osmData, stringTable, bufferStream);

        writeUnsigned(buffer.size(), stream);
        stream.writeRawData(buffer.data().constData(), buffer.size());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( TrackerPluginItem *item: m_itemVector ) {
            int idx = m_document->childPosition( item->placemark() );
            if( item->isEnabled() && idx == -1 ) {
                m_document->append( item->placemark() );
            }
            if( !item->isEnabled() && idx > -1 ) {
                m_document->remove( idx );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &line: lines ) {
        if (line.startsWith(QLatin1Char('#'))) {
            //skip comment
            continue;
        }
        const QStringList fields = line.split(QLatin1Char('\t'));
        if ( fields.size() >= 10 ) {
            qreal lon = fields.at(1).trimmed().toDouble();
            qreal lat = fields.at(0).trimmed().toDouble();
            GeoDataCoordinates coordinates( lon, lat, 0.0, GeoDataCoordinates::Degree );
            routeWaypoints->append( coordinates );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: qAsConst(polygon)->outerBoundary()) {
        path << IntPoint(&node);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto peak: peaks) {
        if (peak->coordinate().sphericalDistanceTo(placemark->coordinate()) < maxDistance) {
            neighbors << peak;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataItemIcon* icon: listStyle->itemIconList() ) {
        writer.writeStartElement(kml::kmlTag_ItemIcon);
        QString const state = iconStateToString( icon->state() );
        writer.writeOptionalElement( kml::kmlTag_state, state, "open" );
        writer.writeOptionalElement( kml::kmlTag_href, icon->iconPath() );
        writer.writeEndElement();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems.null) {
            if (item->contains(curpos, viewport)) {
                result << item->feature();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& path, const QString& error) {
           m_hadErrors = true;
           m_outtimer.stop();
           m_eventLoop.quit();
        }
```

#### AUTO 


```{c}
auto const & osmData = m_placemark.osmData();
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark* placemark: document->placemarkList()) {
        GeoDataGeometry const * const geometry = placemark->geometry();
        auto const visualCategory = placemark->visualCategory();
        if(geometry->nodeType() == GeoDataTypes::GeoDataLineStringType) {
            GeoDataLineString const * prevLine = static_cast<GeoDataLineString const *>(geometry);
            GeoDataLineString* reducedLine = new GeoDataLineString;
            reduce(*prevLine, placemark->osmData(), visualCategory, reducedLine);
            placemark->setGeometry(reducedLine);
        } else if (m_zoomLevel < 17) {
            if(geometry->nodeType() == GeoDataTypes::GeoDataLinearRingType) {
                GeoDataLinearRing const * prevRing = static_cast<GeoDataLinearRing const *>(geometry);
                GeoDataLinearRing* reducedRing = new GeoDataLinearRing;
                reduce(*prevRing, placemark->osmData(), visualCategory, reducedRing);
                placemark->setGeometry(reducedRing);
            } else if(geometry->nodeType() == GeoDataTypes::GeoDataPolygonType) {
                GeoDataPolygon* reducedPolygon = new GeoDataPolygon;
                GeoDataPolygon const * prevPolygon = static_cast<GeoDataPolygon const *>(geometry);
                GeoDataLinearRing const * prevRing = &(prevPolygon->outerBoundary());
                GeoDataLinearRing reducedRing;
                reduce(*prevRing, placemark->osmData().memberReference(-1), visualCategory, &reducedRing);
                reducedPolygon->setOuterBoundary(reducedRing);
                QVector<GeoDataLinearRing> const & innerBoundaries = prevPolygon->innerBoundaries();
                for(int i = 0; i < innerBoundaries.size(); i++) {
                    prevRing = &innerBoundaries[i];
                    GeoDataLinearRing reducedInnerRing;
                    reduce(*prevRing, placemark->osmData().memberReference(i), visualCategory, &reducedInnerRing);
                    reducedPolygon->appendInnerBoundary(reducedInnerRing);
                }
                placemark->setGeometry(reducedPolygon);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFeature *feature: document->featureList()) {
        if (const auto original = geodata_cast<GeoDataPlacemark>(feature)) {
            bool isWay = false;
            if (geodata_cast<GeoDataLineString>(original->geometry())) {
                PlacemarkPtr placemark = PlacemarkPtr(new GeoDataPlacemark(*original));
                OsmObjectManager::initializeOsmData(placemark.data());
                OsmPlacemarkData const & osmData = placemark->osmData();
                isWay = osmData.containsTagKey("highway") ||
                        osmData.containsTagKey("railway") ||
                        osmData.containsTagKey("waterway");
                if (isWay) {
                    GeoDataLineString *line = static_cast<GeoDataLineString*>(placemark->geometry());
                    qint64 firstId = osmData.nodeReference(line->first()).oid();
                    qint64 lastId = osmData.nodeReference(line->last()).oid();
                    if (firstId > 0 && lastId > 0) {
                        ++m_originalWays;
                        bool containsFirst = m_hash.contains(firstId);
                        bool containsLast = m_hash.contains(lastId);

                        if (!containsFirst && !containsLast) {
                            createWayChunk(placemark, firstId, lastId);
                        } else if (containsFirst && !containsLast) {
                            auto chunk = wayChunk(*placemark, firstId);
                            if (chunk != nullptr) {
                                concatFirst(placemark, chunk);
                            } else {
                                createWayChunk(placemark, firstId, lastId);
                            }
                        } else if (!containsFirst && containsLast) {
                            auto chunk = wayChunk(*placemark, lastId);
                            if (chunk != nullptr) {
                                concatLast(placemark, chunk);
                            } else {
                                createWayChunk(placemark, firstId, lastId);
                            }
                        } else if (containsFirst && containsLast) {
                            auto chunk = wayChunk(*placemark, firstId);
                            auto otherChunk = wayChunk(*placemark, lastId);

                            if (chunk != nullptr && otherChunk != nullptr) {
                                if(chunk == otherChunk) {
                                    m_wayPlacemarks.append(placemark);
                                } else {
                                    concatBoth(placemark, chunk, otherChunk);
                                }
                            } else if(chunk != nullptr && otherChunk == nullptr) {
                                concatFirst(placemark, chunk);
                            } else if(chunk == nullptr && otherChunk != nullptr) {
                                concatLast(placemark, otherChunk);
                            } else {
                                createWayChunk(placemark, firstId, lastId);
                            }
                        }
                    } else {
                        isWay = false;
                    }
                }
            }

            if (!isWay) {
                m_otherPlacemarks << feature->clone();
            }
        } else {
            m_otherPlacemarks << feature->clone();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin *plugin: m_controlView->marbleWidget()->renderPlugins() ) {
        KConfigGroup group = sharedConfig->group( QString( "plugin_" ) + plugin->nameId() );

        QHash<QString,QVariant> hash;

        for ( const QString& key: group.keyList() ) {
            hash.insert( key, group.readEntry( key ) );
        }

        plugin->setSettings( hash );
    }
```

#### AUTO 


```{c}
auto const marbleWidget = window.marbleControl()->marbleWidget();
```

#### AUTO 


```{c}
const auto lookAt = (flyTo->view() ? geodata_cast<GeoDataLookAt>(flyTo->view()) : nullptr)
```

#### AUTO 


```{c}
auto neighbors = peaksNear(peak, peaks, maxDistance);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: converter.relations()) {
        if (auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)) {
            auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry());
            Q_ASSERT(polygon);
            OsmRelationTagWriter::writeMultipolygon(*polygon, relation.second, writer );
        }
    }
```

#### AUTO 


```{c}
auto tagIter = outerWayData.findTag(ele);
```

#### AUTO 


```{c}
auto popularity
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter) {
            tileLevels[zoomLevel] << TileId(0, zoomLevel, tileId.x(), tileId.y());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPolygonF* itPolygon: m_cachedPolygons) {
          painter->drawPolyline(*itPolygon);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
            if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
                auto relation = static_cast<const GeoDataRelation*>(feature);
                allRelations << relation;
                if (searchRelations && relation->memberIds().contains(osmData.oid())) {
                    if (relation->osmData().containsTag(QStringLiteral("type"), QStringLiteral("public_transport")) &&
                        relation->osmData().containsTag(QStringLiteral("public_transport"), QStringLiteral("stop_area"))) {
                        for (auto iter = relation->osmData().relationReferencesBegin(), end = relation->osmData().relationReferencesEnd();
                             iter != end; ++iter) {
                            if (iter.value() == QStringLiteral("stop") || iter.value() == QStringLiteral("platform")) {
                                placemarkIds << iter.key();
                            }
                        }
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: innerBoundary) {
                innerPath << IntPoint(&node);
            }
```

#### AUTO 


```{c}
auto iterator = outerWays.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::PositionProviderPlugin *plugin: pluginManager->positionProviderPlugins() ) {
        if ( m_source.isEmpty() || plugin->nameId() == m_source ) {
            PositionProviderPlugin* instance = plugin->newInstance();
            PositionTracking *tracking = m_marbleQuickItem->model()->positionTracking();
            tracking->setPositionProviderPlugin( instance );
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &pluginName: profileGroup.groupList() ) {
            profileGroup.group( pluginName ).deleteGroup();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &backend: s_backends) {
        if (backend.first == fileExtension) {
            return backend.first;
        }
    }
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataRelation>(relation.first)
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& point : m_topEdge) {
                intersectionsTop << QSharedPointer<LinkedPoint>(new LinkedPoint(point));
            }
```

#### AUTO 


```{c}
auto const &innerPath
```

#### AUTO 


```{c}
const auto line = geodata_cast<GeoDataLineString>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (PlaybackItem* item: m_items) {
        duration += item->duration();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const WeatherData& data: m_forecastWeather ) {
                QDate date = data.dataDate();
                if( date >= minDate
                    && data.hasValidCondition()
                    && data.hasValidMinTemperature()
                    && data.hasValidMaxTemperature() )
                {
                    toolTip += QLatin1Char('\n') +
                               tr( "%1: %2, %3 to %4", "DayOfWeek: Condition, MinTemp to MaxTemp" )
                               .arg( locale.standaloneDayName( date.dayOfWeek() ) )
                               .arg( data.conditionString() )
                               .arg( data.minTemperatureString( temperatureUnit() ) )
                               .arg( data.maxTemperatureString( temperatureUnit() ) );
                }
            }
```

#### AUTO 


```{c}
const auto prevPolygon = geodata_cast<GeoDataPolygon>(geometry)
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractFloatItem *floatItem: widget->floatItems() ) {
                if ( floatItem->enabled() && floatItem->visible()
                     && floatItem->contains( menuEvent->pos() ) )
                {
                    return false;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: nodes) {
        if (node.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x10); // node section start indicator

        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        OsmPlacemarkData const & osmData = node.second;
        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        writeVersion(osmData, bufferStream);
        GeoDataCoordinates const & coordinates = node.first;
        double const lon = coordinates.longitude(GeoDataCoordinates::Degree);
        double const lat = coordinates.latitude(GeoDataCoordinates::Degree);
        writeSigned(deltaTo(lon, lastLon), bufferStream);
        writeSigned(deltaTo(lat, lastLat), bufferStream);
        writeTags(osmData, stringTable, bufferStream);

        writeUnsigned(buffer.size(), stream);
        stream.writeRawData(buffer.data().constData(), buffer.size());

        lastId = osmData.id();
        lastLon = lon;
        lastLat = lat;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin* plugin: mapWidget->renderPlugins() ) {
        if ( !features.contains( plugin->nameId() ) ) {
            plugin->setEnabled( false );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &tag: recognizedTags) {
            if (data.containsTagKey(tag)) {
                hasOsmData = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QSharedPointer<TextureTile> &tile: tiles ) {

        // Image blending. If there are several images in the same tile (like clouds
        // or hillshading images over the map) blend them all into only one image

        const Blending *const blending =  tile->blending();
        if ( blending ) {

            mDebug() << Q_FUNC_INFO << "blending";

            if ( resultImage.isNull() ) {
                resultImage = QImage( tile->image()->size(), QImage::Format_ARGB32_Premultiplied );
            }

            blending->blend( &resultImage, tile.data() );
        }
        else {
            mDebug() << Q_FUNC_INFO << "no blending defined => copying top over bottom image";
            if ( withConversion ) {
                resultImage = tile->image()->convertToFormat( QImage::Format_ARGB32_Premultiplied );
            } else {
                resultImage = tile->image()->copy();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( SceneGraphicsItem *item: m_graphicsItems ) {
        if ( !item->containsPoint( mouseEvent->pos() ) ) {
            continue;
        }

        // If an edit dialog is visible, do not permit right clicking on items.
        if ( m_editingDialogIsShown && mouseEvent->type() == QEvent::MouseButtonPress &&
             mouseEvent->button() == Qt::RightButton) {
            return true;
        }

        if ( !item->hasFocus() &&
             item->graphicType() != SceneGraphicsTypes::SceneGraphicGroundOverlay ) {
            if ( mouseEvent->type() == QEvent::MouseButtonPress &&
                 mouseEvent->button() == Qt::LeftButton ) {
                item->setFocus( true );
                disableFocusActions();
                enableActionsOnItemType( item->graphicType() );

                if ( m_focusItem && m_focusItem != item ) {
                    m_focusItem->setFocus( false );
                    if ( m_focusItem->graphicType() == SceneGraphicsTypes::SceneGraphicGroundOverlay ) {
                        clearOverlayFrames();
                    }
                }
                m_focusItem = item;
                m_marbleWidget->model()->treeModel()->updateFeature( item->placemark() );
                return true;
            }

            return false;
        }

        if ( item->sceneEvent( event ) ) {
            setupCursor( item );

            if ( mouseEvent->type() == QEvent::MouseButtonPress ) {
                handleSuccessfulPressEvent( mouseEvent, item );
            } else if ( mouseEvent->type() == QEvent::MouseMove ) {
                handleSuccessfulHoverEvent( mouseEvent, item );
            } else if ( mouseEvent->type() == QEvent::MouseButtonRelease ) {
                handleSuccessfulReleaseEvent( mouseEvent, item );
            }

            handleRequests( mouseEvent, item );
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter) {
                ++count;
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles && QFileInfo(filename).exists()) {
                    continue;
                }
                GeoDataDocument* tile = processor.clipTo(zoomLevel, tileId.x(), tileId.y());
                if (!tile->isEmpty()) {
                    NodeReducer nodeReducer(tile, TileId(0, zoomLevel, tileId.x(), tileId.y()));
                    if (!writeTile(tile, filename)) {
                        return 4;
                    }
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Tile " << count << "/" << total << " (" << tile->name().toStdString() << ") done.";
                    double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                    std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Skipping empty tile " << count << "/" << total << " (" << tile->name().toStdString() << ").";
                }
                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
                delete tile;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFeature *feature: document->featureList()) {
        if (feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            GeoDataPlacemark* placemark = static_cast<GeoDataPlacemark*>(feature);
            bool acceptPlacemark = false;
            auto const & osmData = placemark->osmData();

            if (filterFlag == FilterRailwayService &&
                    osmData.containsTagKey(QStringLiteral("railway")) &&
                    osmData.containsTagKey(QStringLiteral("service"))) {
                acceptPlacemark = false;
            } else {
                for (auto const &tag: tagsList) {
                    bool contains;
                    if (tag.second == QLatin1String("*")) {
                        contains = osmData.containsTagKey(tag.first);
                    } else {
                        contains = osmData.containsTag(tag.first, tag.second);
                    }
                    if (contains) {
                        acceptPlacemark = true;
                        break;
                    }
                }
            }

            if (acceptPlacemark) {
                m_accepted->append(placemark->clone());
            } else {
                m_rejectedObjects.append(placemark->clone());
            }
        }
        else {
            m_accepted->append(feature->clone());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &dir: QDir(boundaryDir).entryList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        QString const file = QString("%1/%2/%3/%4/%5.%6").arg(boundaryDir).arg(dir).arg(zoomLevel).arg(x).arg(y).arg(extension);
        if (QFileInfo(file).exists()) {
            auto tile = TileDirectory::open(file, manager);
            if (tile) {
                for (auto placemark: tile->placemarkList()) {
                    mergedMap->append(placemark->clone());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Job* job: allJobs) {
        if (*job == *newJob) {
            qDebug() << "Ignoring job, still running";
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin* plugin: mapWidget.renderPlugins() ) {
        plugin->setEnabled( false );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: files ) {
        QString const filePath = inputDirectory.filePath( file );
        zipArguments <<  filePath;
    }
```

#### AUTO 


```{c}
const auto tagIter = osmData.findTag(QStringLiteral("name"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: qAsConst(polygon)->outerBoundary()) {
        auto p = coordinateToPoint(node);
        coordMap.insert(std::make_pair(p.X, p.Y), &node);
        path.push_back(std::move(p));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark *placemark: locations ) {
        m_document->append( new GeoDataPlacemark( *placemark ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto dataset: layer->datasets()) {
            data = dynamic_cast<const GeoSceneGeodata *>(dataset);
            if (data != nullptr && data->sourceFile() == filePath) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* outerPolygon: outerPolygons ) {
        QPolygonF* fillPolygon = new QPolygonF;
        *fillPolygon << *outerPolygon;
        *fillPolygon << outerPolygon->first();

        for( const QPolygonF* innerPolygon: innerPolygons ) {
            *fillPolygon << *innerPolygon;
            *fillPolygon << innerPolygon->first();
            *fillPolygon << outerPolygon->first();
        }

        fillPolygons << fillPolygon;
    }
```

#### AUTO 


```{c}
auto const selectedColor = QApplication::palette().highlight().color();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter.value()) {
                ++count;
                int const zoomLevel = tileId.zoomLevel();
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles) {
                    if (zoomLevel > 13 && mbtileWriter && mbtileWriter->hasTile(tileId.x(), tileId.y(), zoomLevel)) {
                        continue;
                    } else if (QFileInfo(filename).exists()) {
                        continue;
                    }
                }

                using GeoDocPtr = QSharedPointer<GeoDataDocument>;
                GeoDocPtr tile2 = GeoDocPtr(loader.clip(zoomLevel, tileId.x(), tileId.y()));
                if (!tile2->isEmpty()) {
                    GeoDocPtr tile1 = GeoDocPtr(mapTiles.clip(zoomLevel, tileId.x(), tileId.y()));
                    TagsFilter::removeAnnotationTags(tile1.data());
                    int originalWays = 0;
                    int mergedWays = 0;
                    if (zoomLevel < 17) {
                        WayConcatenator concatenator(tile1.data());
                        originalWays = concatenator.originalWays();
                        mergedWays = concatenator.mergedWays();
                    }
                    NodeReducer nodeReducer(tile1.data(), tileId);
                    if (!tile1->isEmpty() && !tile2->isEmpty()) {
                        GeoDocPtr combined = GeoDocPtr(mergeDocuments(tile1.data(), tile2.data()));

                        if (writeBoundaries && boundaryTiles.contains(iter.key())) {
                            writeBoundaryTile(tile1.data(), region, parser, tileId.x(), tileId.y(), zoomLevel);
                            if (mergeTiles) {
                                combined = mergeBoundaryTiles(tile2, manager, parser, tileId.x(), tileId.y(), zoomLevel);
                            }
                        }

                        if (zoomLevel > 13 && mbtileWriter) {
                            QBuffer buffer;
                            buffer.open(QBuffer::ReadWrite);
                            if (GeoDataDocumentWriter::write(&buffer, *combined, extension)) {
                                buffer.seek(0);
                                mbtileWriter->addTile(&buffer, tileId.x(), tileId.y(), zoomLevel);
                            } else {
                                qWarning() << "Could not write the tile " << combined->name();
                            }
                        } else {
                            if (!writeTile(combined.data(), filename)) {
                                return 4;
                            }
                        }

                        TileDirectory::printProgress(count / double(total));
                        std::cout << "  Tile " << count << "/" << total << " (";
                        std::cout << combined->name().toStdString() << ").";
                        double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                        std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                        if (originalWays > 0) {
                            std::cout << " , " << originalWays << " ways merged to " << mergedWays;
                        }
                    } else {
                        TileDirectory::printProgress(count / double(total));
                        std::cout << "  Skipping empty tile " << count << "/" << total << " (" << tile1->name().toStdString() << ").";
                    }
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << "  Skipping sea tile " << count << "/" << total << " (" << tile2->name().toStdString() << ").";
                }

                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneSection *section: currentMapTheme->legend()->sections() ) {
        // Each section is divided into the "well"
        // Well is like a block of data with rounded corners
        customLegendString += QLatin1String("<div class=\"well well-small well-legend\">");

        const QString heading = QCoreApplication::translate("DGML", section->heading().toUtf8().constData());
        QString checkBoxString;
        if (section->checkable()) {
            // If it's needed to make a checkbox here, we will
            QString const checked = d->m_checkBoxMap[section->connectTo()] ? "checked" : "";
            /* Important comment:
             * We inject Marble object into JavaScript of each legend html file
             * This is only one way to handle checkbox changes we see, so
             * Marble.setCheckedProperty is a function that does it
             */
            if(!section->radio().isEmpty()) {
                checkBoxString = QLatin1String(
                        "<label class=\"section-head\">"
                        "<input type=\"radio\" "
                        "onchange=\"Marble.setRadioCheckedProperty(this.value, this.name ,this.checked);\" ") +
                        checked + QLatin1String(" value=\"") + section->connectTo() + QLatin1String("\" name=\"") + section->radio() + QLatin1String("\" /><span>")
                        + heading +
                        QLatin1String("</span></label>");

            } else {
                checkBoxString = QLatin1String(
                        "<label class=\"section-head\">"
                        "<input type=\"checkbox\" "
                        "onchange=\"Marble.setCheckedProperty(this.name, this.checked);\" ") + checked + QLatin1String(" name=\"") + section->connectTo() + QLatin1String("\" /><span>")
                        + heading +
                        QLatin1String("</span></label>");

            }
            customLegendString += checkBoxString;

        } else {
            customLegendString += QLatin1String("<h4 class=\"section-head\">") + heading + QLatin1String("</h4>");
        }

        for (const GeoSceneItem *item: section->items()) {

            // checkbox for item
            QString checkBoxString;
            if (item->checkable()) {
                QString const checked = d->m_checkBoxMap[item->connectTo()] ? "checked" : "";
                checkBoxString = QLatin1String(
                        "<input type=\"checkbox\" "
                        "onchange=\"Marble.setCheckedProperty(this.name, this.checked);\" ")
                        + checked + QLatin1String(" name=\"") + item->connectTo() + QLatin1String("\" />");

            }

            // pixmap and text
            QString src;
            QString styleDiv;
            int pixmapWidth = 24;
            int pixmapHeight = 12;
            if (!item->icon()->pixmap().isEmpty()) {
                QString path = MarbleDirs::path( item->icon()->pixmap() );
                const QPixmap oncePixmap(path);
                pixmapWidth = oncePixmap.width();
                pixmapHeight = oncePixmap.height();
                src = QUrl::fromLocalFile( path ).toString();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px;");
            }
            // NOTICE. There are some pixmaps without image, so we should
            //         create just a plain rectangle with set color
            else if (item->icon()->color().isValid()) {
                const QColor color = item->icon()->color();
                styleDiv = QLatin1String("width: ") + QString::number(pixmapWidth) + QLatin1String("px; height: ") +
                        QString::number(pixmapHeight) + QLatin1String("px; background-color: ") + color.name() + QLatin1Char(';');
            }
            const QString text = QCoreApplication::translate("DGML", item->text().toUtf8().constData());
            QString html = QLatin1String(
                    "<div class=\"legend-entry\">"
                    "  <label>") + checkBoxString + QLatin1String(
                    "    <img class=\"image-pic\" src=\"") + src + QLatin1String("\" style=\"") + styleDiv + QLatin1String("\"/>"
                    "    <span class=\"notation\">") + text + QLatin1String("</span>"
                    "  </label>"
                    "</div>");
            customLegendString += html;
        }
        customLegendString += QLatin1String("</div>"); // <div class="well">
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex &proxyPersistentIndex: q->persistentIndexList()) {
        m_proxyIndexes << proxyPersistentIndex;
        Q_ASSERT(proxyPersistentIndex.isValid());
        srcPersistentIndex = q->mapToSource(proxyPersistentIndex);
        Q_ASSERT(srcPersistentIndex.isValid());
        m_layoutChangePersistentIndexes << srcPersistentIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractFloatItem * floatItem: floatItems() ) {
        if ( floatItem && floatItem->nameId() == nameId ) {
            return floatItem;
        }
    }
```

#### AUTO 


```{c}
auto const visibleRelationTypes = settings.value(QStringLiteral("visibleRelationTypes"), defaultRelationTypes).toStringList();
```

#### AUTO 


```{c}
auto const & fragment = iter.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (MarbleGraphicsItem *child: d->m_children) {
                    const QVector<QRectF> childRects = child->d_func()->boundingRects();
                    
                    for( const QRectF& childRect: childRects ) {
                        if( childRect.toRect().contains( shiftedPos ) ) {
                            if( child->eventFilter( object, e ) ) {
                                return true;
                            }
                        }
                    }
                }
```

#### AUTO 


```{c}
auto const zoomLevel = placemark->placemark()->zoomLevel();
```

#### AUTO 


```{c}
auto candidate
```

#### AUTO 


```{c}
auto file = fopen(filename.toStdString().c_str(), "rb");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &member: m_members) {
        auto const iter = placemarks.find(member.reference);
        if (iter != placemarks.constEnd()) {
            relation->addMember(*iter, member.reference, member.role);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Marble::GeoDataFolder* folder: bookmarks->folderList() ) {
        for( Marble::GeoDataPlacemark * placemark: folder->placemarkList() ) {
            if (placemark->coordinate().sphericalDistanceTo(compareTo) * planetRadius < 5) {
                manager->removeBookmark( placemark );
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& settingKey: profile.pluginSettings()[ key ].keys() ) {
                Q_ASSERT(settingKey != QLatin1String("Enabled"));
                pluginGroup.writeEntry( settingKey, profile.pluginSettings()[ key ][ settingKey ] );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& renderPosition: renderPositions ) {
        QList<LayerInterface*> layers;

        // collect all RenderPlugins of current renderPosition
        for( auto *renderPlugin: d->m_renderPlugins ) {
            if ( renderPlugin && renderPlugin->renderPosition().contains( renderPosition ) ) {
                if ( renderPlugin->enabled() && renderPlugin->visible() ) {
                    if ( !renderPlugin->isInitialized() ) {
                        renderPlugin->initialize();
                        emit renderPluginInitialized( renderPlugin );
                    }
                    layers.push_back( renderPlugin );
                }
            }
        }

        // collect all internal LayerInterfaces of current renderPosition
        for( auto *layer: d->m_internalLayers ) {
            if ( layer && layer->renderPosition().contains( renderPosition ) ) {
                layers.push_back( layer );
            }
        }

        // sort them according to their zValue()s
        std::sort( layers.begin(), layers.end(), [] ( const LayerInterface * const one, const LayerInterface * const two ) -> bool {
            Q_ASSERT( one && two );
            return one->zValue() < two->zValue();
        } );

        // render the layers of the current renderPosition
        QTime timer;
        for( auto *layer: layers ) {
            timer.start();
            layer->render( painter, viewport, renderPosition, 0 );
            d->m_renderState.addChild( layer->renderState() );
            traceList.append( QString("%2 ms %3").arg( timer.elapsed(),3 ).arg( layer->runtimeTrace() ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter.value()) {
                ++count;
                int const zoomLevel = tileId.zoomLevel();
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles) {
                    if (zoomLevel > 13 && mbtileWriter && mbtileWriter->hasTile(tileId.x(), tileId.y(), zoomLevel)) {
                        continue;
                    } else if (QFileInfo(filename).exists()) {
                        continue;
                    }
                }

                typedef QSharedPointer<GeoDataDocument> GeoDocPtr;
                GeoDocPtr tile2 = GeoDocPtr(loader.clip(zoomLevel, tileId.x(), tileId.y()));
                if (!tile2->isEmpty()) {
                    GeoDocPtr tile1 = GeoDocPtr(mapTiles.clip(zoomLevel, tileId.x(), tileId.y()));
                    TagsFilter::removeAnnotationTags(tile1.data());
                    int originalWays = 0;
                    int mergedWays = 0;
                    if (zoomLevel < 17) {
                        WayConcatenator concatenator(tile1.data());
                        originalWays = concatenator.originalWays();
                        mergedWays = concatenator.mergedWays();
                    }
                    NodeReducer nodeReducer(tile1.data(), tileId);
                    if (!tile1->isEmpty() && !tile2->isEmpty()) {
                        GeoDocPtr combined = GeoDocPtr(mergeDocuments(tile1.data(), tile2.data()));

                        if (writeBoundaries && boundaryTiles.contains(iter.key())) {
                            writeBoundaryTile(tile1.data(), region, parser, tileId.x(), tileId.y(), zoomLevel);
                            if (mergeTiles) {
                                combined = mergeBoundaryTiles(tile2, manager, parser, tileId.x(), tileId.y(), zoomLevel);
                            }
                        }

                        if (zoomLevel > 13 && mbtileWriter) {
                            QBuffer buffer;
                            buffer.open(QBuffer::ReadWrite);
                            if (GeoDataDocumentWriter::write(&buffer, *combined, extension)) {
                                buffer.seek(0);
                                mbtileWriter->addTile(&buffer, tileId.x(), tileId.y(), zoomLevel);
                            } else {
                                qWarning() << "Could not write the tile " << combined->name();
                            }
                        } else {
                            if (!writeTile(combined.data(), filename)) {
                                return 4;
                            }
                        }

                        TileDirectory::printProgress(count / double(total));
                        std::cout << "  Tile " << count << "/" << total << " (";
                        std::cout << combined->name().toStdString() << ").";
                        double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                        std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                        if (originalWays > 0) {
                            std::cout << " , " << originalWays << " ways merged to " << mergedWays;
                        }
                    } else {
                        TileDirectory::printProgress(count / double(total));
                        std::cout << "  Skipping empty tile " << count << "/" << total << " (" << tile1->name().toStdString() << ").";
                    }
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << "  Skipping sea tile " << count << "/" << total << " (" << tile2->name().toStdString() << ").";
                }

                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
            }
```

#### AUTO 


```{c}
const auto document = geodata_cast<GeoDataDocument>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: relations) {
        auto const ref = relation->osmData().tagValue(QStringLiteral("ref"));
        if (relation->isVisible() && !ref.isEmpty()) {
            names[relation->relationType()] << ref;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &tileId: iter.value()) {
                ++count;
                int const zoomLevel = tileId.zoomLevel();
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles) {
                    if (zoomLevel > 13 && mbtileWriter && mbtileWriter->hasTile(tileId.x(), tileId.y(), zoomLevel)) {
                        continue;
                    } else if (QFileInfo(filename).exists()) {
                        continue;
                    }
                }

                typedef QSharedPointer<GeoDataDocument> GeoDocPtr;
                GeoDocPtr tile1 = GeoDocPtr(mapTiles.clip(zoomLevel, tileId.x(), tileId.y()));
                TagsFilter::removeAnnotationTags(tile1.data());
                int originalWays = 0;
                int mergedWays = 0;
                if (zoomLevel < 17) {
                    WayConcatenator concatenator(tile1.data());
                    originalWays = concatenator.originalWays();
                    mergedWays = concatenator.mergedWays();
                }
                NodeReducer nodeReducer(tile1.data(), tileId);
                GeoDocPtr tile2 = GeoDocPtr(loader.clip(zoomLevel, tileId.x(), tileId.y()));
                if (tile1->size() > 0 && tile2->size() > 0) {
                    GeoDocPtr combined = GeoDocPtr(mergeDocuments(tile1.data(), tile2.data()));

                    if (boundaryTiles.contains(iter.key())) {
                        writeBoundaryTile(tile1.data(), region, parser, tileId.x(), tileId.y(), zoomLevel);
                        if (mergeTiles) {
                            combined = mergeBoundaryTiles(tile2, manager, parser, tileId.x(), tileId.y(), zoomLevel);
                        }
                    }

                    if (zoomLevel > 13 && mbtileWriter) {
                        QBuffer buffer;
                        buffer.open(QBuffer::ReadWrite);
                        if (GeoDataDocumentWriter::write(&buffer, *combined, extension)) {
                            buffer.seek(0);
                            mbtileWriter->addTile(&buffer, tileId.x(), tileId.y(), zoomLevel);
                        } else {
                            qWarning() << "Could not write the tile " << combined->name();
                        }
                    } else {
                        if (!writeTile(combined.data(), filename)) {
                            return 4;
                        }
                    }

                    TileDirectory::printProgress(count / double(total));
                    std::cout << "  Tile " << count << "/" << total << " (";
                    std::cout << combined->name().toStdString() << ").";
                    double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                    std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                    if (originalWays > 0) {
                        std::cout << " , " << originalWays << " ways merged to " << mergedWays;
                    }
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << "  Skipping empty tile " << count << "/" << total << " (" << tile1->name().toStdString() << ").";
                }

                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemA: m_diffA ) {
        if( itemA.m_action == DiffItem::NoAction ) {
            bool deleted = false;
            bool changed = false;
            DiffItem other;

            for( const DiffItem &itemB: m_diffB ) {
                if( EARTH_RADIUS * distanceSphere( itemA.m_placemarkA.coordinate(), itemB.m_placemarkA.coordinate() ) <= 1 ) {
                    if( itemB.m_action == DiffItem::Deleted ) {
                        deleted = true;
                    } else if( itemB.m_action == DiffItem::Changed ) {
                        changed = true;
                        other = itemB;
                    }
                }
            }
            if( changed ) {
                m_merged.append( other );
            } else if( !deleted ) {
                m_merged.append( itemA );
            }
        } else if( itemA.m_action == DiffItem::Created ) {
            m_merged.append( itemA );
        } else if( itemA.m_action == DiffItem::Changed || itemA.m_action == DiffItem::Deleted ) {
            bool conflict = false;
            DiffItem other;

            for( const DiffItem &itemB: m_diffB ) {
                if( EARTH_RADIUS * distanceSphere( itemA.m_placemarkB.coordinate(), itemB.m_placemarkB.coordinate() ) <= 1 ) {
                    if( ( itemA.m_action == DiffItem::Changed && ( itemB.m_action == DiffItem::Changed || itemB.m_action == DiffItem::Deleted ) )
                            || ( itemA.m_action == DiffItem::Deleted && itemB.m_action == DiffItem::Changed ) ) {
                        conflict = true;
                        other = itemB;
                    }
                }
            }

            if( !conflict && itemA.m_action == DiffItem::Changed ) {
                m_merged.append( itemA );
            } else if ( conflict ) {
                m_conflictItem = other;
                MergeItem *mergeItem = new MergeItem();
                mergeItem->setPathA( itemA.m_path );
                mergeItem->setPathB( other.m_path );
                mergeItem->setPlacemarkA( itemA.m_placemarkA );
                mergeItem->setPlacemarkB( other.m_placemarkA );

                switch( itemA.m_action ) {
                case DiffItem::Changed:
                    mergeItem->setActionA( MergeItem::Changed );
                    break;
                case DiffItem::Deleted:
                    mergeItem->setActionA( MergeItem::Deleted );
                    break;
                default:
                    break;
                }

                switch( other.m_action ) {
                case DiffItem::Changed:
                    mergeItem->setActionB( MergeItem::Changed );
                    break;
                case DiffItem::Deleted:
                    mergeItem->setActionB( MergeItem::Deleted );
                    break;
                default:
                    break;
                }

                emit m_q->mergeConflict( mergeItem );
                return;
            }
        }

        if( !m_diffA.isEmpty() ) {
            m_diffA.removeFirst();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& str: stringlist ) {
            float  x;
            float  y;
            x = str.section(QLatin1Char(','), 0, 0).toFloat();
            y = str.section(QLatin1Char(','), 1, 1).toFloat();
						
            short  header;
            short  lat;
            short  lng;	

            if ( firstheader ) {
                header      = m_header;
                firstheader = false;
            }
            else {
                if ( stringlist.size() > 14 ) {
                    if ( count % 9 == 0 ) 
                        header = 5;
                    else if ( count % 5 == 0 )
                        header = 3;
                    else if ( count % 2 == 0 )
                        header = 2;
                    else
                        header = 1;
                }
                else if ( stringlist.size() > 6 ) {
                    if ( count % 2 == 0 )
                        header = 3;
                    else
                        header = 1;
                }
                else {
                    header = 2;
                }
            }
            if ( count == stringlist.size() - 1 )
                header = 5;

            lng =  (int)( x * 50 - 10800 );
            lat = -(int)( y * 50 - 5400 );

            *m_stream << header << lat << lng;
            count++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Node & node: database ) {
            if ( node.category >= OsmPlacemark::PlacesRegion &&
                    node.category <= OsmPlacemark::PlacesIsland &&
                    node.name == city ) {
                qDebug() << "Creating a new implicit region from " << node.name << " at " << node.lon << "," << node.lat;
                OsmOsmRegion region;
                region.region.setName( city );
                region.region.setLongitude( node.lon );
                region.region.setLatitude( node.lat );
                placemark.setRegionId( region.region.identifier() );
                osmOsmRegions.push_back( region );
                return;
            }
        }
```

#### AUTO 


```{c}
const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry())
```

#### AUTO 


```{c}
auto const places = candidatesFor(place);
```

#### RANGE FOR STATEMENT 


```{c}
for( const RouteItem &item: cachedRoutes ) {
        d->m_routeList.append( item );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &planet: planets ) {
        m_svgPaths.insert(planet, m_settings.value(QLatin1String("path_") + planet, QString()).toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto wayId: outerWays) {
            GeoDataPlacemark::GeoDataVisualCategory const category =
                    StyleBuilder::determineVisualCategory(ways[wayId].osmData());
            if( category != firstCategory ) {
                categoriesAreSame = false;
                break;
            }
        }
```

#### AUTO 


```{c}
auto const y1 = polygon[j].y();
```

#### AUTO 


```{c}
const auto tileBox = m_tileProjection.geoCoordinates(tile);
```

#### AUTO 


```{c}
auto *renderPlugin
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: selectedPlacemarks ) {
        for (auto tileIter = d->m_features.find(placemark); tileIter != d->m_features.end() && tileIter.key() == placemark; ++tileIter) {
            auto const & clickedItems = d->m_tiledItems[*tileIter];
            auto iter = clickedItems.find(placemark);
            if (iter != clickedItems.end()) {
                const GeoDataObject *parent = placemark->parent();
                if ( parent ) {
                    auto item = *iter;
                    if (const GeoDataDocument *doc = geodata_cast<GeoDataDocument>(parent)) {
                        QString styleUrl = placemark->styleUrl();
                        styleUrl.remove(QLatin1Char('#'));
                        if ( !styleUrl.isEmpty() ) {
                            GeoDataStyleMap const &styleMap = doc->styleMap( styleUrl );
                            GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                            if ( style ) {
                                d->selectItem( item );
                                d->applyHighlightStyle( item, style );
                            }
                        }

                        /**
                            * If a placemark is using an inline style instead of a shared
                            * style ( e.g in case when theme file specifies the colorMap
                            * attribute ) then highlight it if any of the style maps have a
                            * highlight styleId
                            */
                        else {
                            for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto tagIter = osmData.findTag(QStringLiteral("ele"));
```

#### AUTO 


```{c}
auto member
```

#### AUTO 


```{c}
auto iter = relationConverter.cbegin(), end = relationConverter.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto peak: cluster) {
            peak->osmData().addTag(QLatin1String("marbleZoomLevel"), first ? QLatin1String("11") : QLatin1String("13"));
            first = false;
        }
```

#### AUTO 


```{c}
auto iter = m_placemark.osmData().tagsBegin(), end = m_placemark.osmData().tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark* placemark: document->placemarkList()) {
        GeoDataGeometry const * const geometry = placemark->geometry();
        auto const visualCategory = placemark->visualCategory();
        if (const auto prevLine = geodata_cast<GeoDataLineString>(geometry)) {
            GeoDataLineString* reducedLine = new GeoDataLineString;
            reduce(*prevLine, placemark->osmData(), visualCategory, reducedLine);
            placemark->setGeometry(reducedLine);
        } else if (m_zoomLevel < 17) {
            if (const auto prevRing = geodata_cast<GeoDataLinearRing>(geometry)) {
                placemark->setGeometry(reducedRing(*prevRing, placemark, visualCategory));
            } else if (const auto prevPolygon = geodata_cast<GeoDataPolygon>(geometry)) {
                placemark->setGeometry(reducedPolygon(*prevPolygon, placemark, visualCategory));
            } else if (const auto building = geodata_cast<GeoDataBuilding>(geometry)) {
                if (const auto prevRing = geodata_cast<GeoDataLinearRing>(&building->multiGeometry()->at(0))) {
                    GeoDataLinearRing* ring = reducedRing(*prevRing, placemark, visualCategory);
                    GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
                    newBuilding->multiGeometry()->clear();
                    newBuilding->multiGeometry()->append(ring);
                    placemark->setGeometry(newBuilding);
                } else if (const auto prevPolygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0))) {
                    GeoDataPolygon* poly = reducedPolygon(*prevPolygon, placemark, visualCategory);
                    GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
                    newBuilding->multiGeometry()->clear();
                    newBuilding->multiGeometry()->append(poly);
                    placemark->setGeometry(newBuilding);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark const * placemark: potentialIntersections(tileBoundary)) {
        GeoDataGeometry const * const geometry = placemark ? placemark->geometry() : nullptr;
        if (geometry && tileBoundary.intersects(geometry->latLonAltBox())) {
            if (geodata_cast<GeoDataPolygon>(geometry)) {
                clipPolygon(placemark, clip, minArea, tile, osmIds);
            } else if (geodata_cast<GeoDataLineString>(geometry)) {
                clipString<GeoDataLineString>(placemark, clip, minArea, tile, osmIds);
            } else if (geodata_cast<GeoDataLinearRing>(geometry)) {
                clipString<GeoDataLinearRing>(placemark, clip, minArea, tile, osmIds);
            } else if (const auto building = geodata_cast<GeoDataBuilding>(geometry)) {
                if (geodata_cast<GeoDataPolygon>(&static_cast<const GeoDataMultiGeometry*>(building->multiGeometry())->at(0))) {
                    clipPolygon(placemark, clip, minArea, tile, osmIds);
                } else if (geodata_cast<GeoDataLinearRing>(&static_cast<const GeoDataMultiGeometry*>(building->multiGeometry())->at(0))) {
                    clipString<GeoDataLinearRing>(placemark, clip, minArea, tile, osmIds);
                }
            } else {
                tile->append(placemark->clone());
                osmIds << placemark->osmData().id();
            }
        }
    }
```

#### AUTO 


```{c}
auto routeGeometryValue = route.value(QStringLiteral("geometry"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon: m_cachedInnerPolygons) {
                if (polygon->containsPoint(point, Qt::OddEvenFill)) {
                    return false;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneProperty *property: d->m_properties ) {
        allProperties << property;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneTextureTileDataset *const texture = dynamic_cast<GeoSceneTextureTileDataset const *>( pos );
                    if ( !texture )
                        continue;

                    const QString sourceDir = texture->sourceDir();
                    const QString installMap = texture->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *texture )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( texture->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, nullptr );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *texture ) ) {
                            mDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qWarning() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *texture ) ) {
                        textures.append( texture );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        textureLayersOk = false;
                    }
                }
```

#### AUTO 


```{c}
auto id
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &path: paths) {
        GeoDataPlacemark* newPlacemark = new GeoDataPlacemark;
        newPlacemark->setVisible(placemark->isVisible());
        newPlacemark->setVisualCategory(placemark->visualCategory());
        GeoDataLinearRing outerRing;
        OsmPlacemarkData const & placemarkOsmData = placemark->osmData();
        OsmPlacemarkData & newPlacemarkOsmData = newPlacemark->osmData();
        int index = -1;
        OsmPlacemarkData const & outerRingOsmData = placemarkOsmData.memberReference(index);
        OsmPlacemarkData & newOuterRingOsmData = newPlacemarkOsmData.memberReference(index);
        pathToRing(path, &outerRing, outerRingOsmData, newOuterRingOsmData, coordMap);

        GeoDataPolygon* newPolygon = new GeoDataPolygon;
        newPolygon->setOuterBoundary(outerRing);
        if (isBuilding) {
            const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
            GeoDataBuilding* newBuilding = new GeoDataBuilding(*building);
            newBuilding->multiGeometry()->clear();
            newBuilding->multiGeometry()->append(newPolygon);
            newPlacemark->setGeometry(newBuilding);
        } else {
            newPlacemark->setGeometry(newPolygon);
        }
        if (placemarkOsmData.id() > 0) {
            newPlacemarkOsmData.addTag(QStringLiteral("mx:oid"), QString::number(placemarkOsmData.id()));
        }
        copyTags(placemarkOsmData, newPlacemarkOsmData);
        copyTags(outerRingOsmData, newOuterRingOsmData);
        if (outerRingOsmData.id() > 0) {
            newOuterRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(outerRingOsmData.id()));
            osmIds.insert(outerRingOsmData.id());
        }

        auto const & innerBoundaries = qAsConst(polygon)->innerBoundaries();
        for (index = 0; index < innerBoundaries.size(); ++index) {
            auto const & innerBoundary = innerBoundaries.at(index);
            if (minArea > 0.0 && area(innerBoundary) < minArea) {
                continue;
            }

            auto const & innerRingOsmData = placemarkOsmData.memberReference(index);
            clipper.Clear();
            clipper.AddPath(path, ptClip, true);
            Path innerPath;
            coordMap.clear();
            for(auto const & node: innerBoundary) {
                auto p = coordinateToPoint(node);
                coordMap.insert(std::make_pair(p.X, p.Y), &node);
                innerPath.push_back(std::move(p));
            }
            clipper.AddPath(innerPath, ptSubject, true);
            Paths innerPaths;
            clipper.Execute(ctIntersection, innerPaths);
            for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                pathToRing(innerPath, &innerRing, innerRingOsmData, newInnerRingOsmData, coordMap);
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                    osmIds.insert(innerRingOsmData.id());
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
        }

        OsmObjectManager::initializeOsmData(newPlacemark);
        document->append(newPlacemark);
        osmIds << placemark->osmData().id();
    }
```

#### AUTO 


```{c}
auto const color = QColor(colorValue.isEmpty() ? QStringLiteral("white") : colorValue);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &databaseFile: m_databaseFiles ) {
        database.setDatabaseName( databaseFile );
        if ( !database.open() ) {
            qWarning() << "Failed to connect to database" << databaseFile;
        }

        QString regionRestriction;
        if ( !userQuery.region().isEmpty() ) {
            QElapsedTimer regionTimer;
            regionTimer.start();
            // Nested set model to support region hierarchies, see https://en.wikipedia.org/wiki/Nested_set_model
            const QString regionsQueryString = QLatin1String("SELECT lft, rgt FROM regions WHERE name LIKE '%") + userQuery.region() + QLatin1String("%';");
            QSqlQuery regionsQuery( regionsQueryString, database );
            if ( regionsQuery.lastError().isValid() ) {
                qWarning() << regionsQuery.lastError() << "in" << databaseFile << "with query" << regionsQuery.lastQuery();
            }
            regionRestriction = " AND (";
            int regionCount = 0;
            while ( regionsQuery.next() ) {
                if ( regionCount > 0 ) {
                    regionRestriction += QLatin1String(" OR ");
                }
                regionRestriction += QLatin1String(" (regions.lft >= ") + regionsQuery.value( 0 ).toString() +
                                     QLatin1String(" AND regions.lft <= ") + regionsQuery.value( 1 ).toString() + QLatin1Char(')');
                regionCount++;
            }
            regionRestriction += QLatin1Char(')');

            mDebug() << Q_FUNC_INFO << "region query in" << databaseFile << "with query" << regionsQueryString
                     << "took" << regionTimer.elapsed() << "ms for" << regionCount << "results";

            if ( regionCount == 0 ) {
                continue;
            }
        }

        QString queryString;

        queryString = " SELECT regions.name,"
                " places.name, places.number,"
                " places.category, places.lon, places.lat"
                " FROM regions, places";

        if ( userQuery.queryType() == DatabaseQuery::CategorySearch ) {
            queryString += QLatin1String(" WHERE regions.id = places.region");
            if( userQuery.category() == OsmPlacemark::UnknownCategory ) {
                // search for all pois which are not street nor address
                queryString += QLatin1String(" AND places.category <> 0 AND places.category <> 6");
            } else {
                // search for specific category
                queryString += QLatin1String(" AND places.category = %1");
                queryString = queryString.arg( (qint32) userQuery.category() );
            }
            if ( userQuery.position().isValid() && userQuery.region().isEmpty() ) {
                // sort by distance
                queryString += QLatin1String(" ORDER BY ((places.lat-%1)*(places.lat-%1)+(places.lon-%2)*(places.lon-%2))");
                GeoDataCoordinates position = userQuery.position();
                queryString = queryString.arg( position.latitude( GeoDataCoordinates::Degree ), 0, 'f', 8 )
                        .arg( position.longitude( GeoDataCoordinates::Degree ), 0, 'f', 8 );
            } else {
                queryString += regionRestriction;
            }
        } else if ( userQuery.queryType() == DatabaseQuery::BroadSearch ) {
            queryString += QLatin1String(" WHERE regions.id = places.region"
                    " AND places.name ") + wildcardQuery(userQuery.searchTerm());
        } else {
            queryString += QLatin1String(" WHERE regions.id = places.region"
                    "   AND places.name ") + wildcardQuery(userQuery.street());
            if ( !userQuery.houseNumber().isEmpty() ) {
                queryString += QLatin1String(" AND places.number ") + wildcardQuery(userQuery.houseNumber());
            } else {
                queryString += QLatin1String(" AND places.number IS NULL");
            }
            queryString += regionRestriction;
        }

        queryString += QLatin1String(" LIMIT 50;");

        /** @todo: sort/filter results from several databases */

        QSqlQuery query( database );
        query.setForwardOnly( true );
        QElapsedTimer queryTimer;
        queryTimer.start();
        if ( !query.exec( queryString ) ) {
            qWarning() << query.lastError() << "in" << databaseFile << "with query" << query.lastQuery();
            continue;
        }

        int resultCount = 0;
        while ( query.next() ) {
            OsmPlacemark placemark;
            if ( userQuery.resultFormat() == DatabaseQuery::DistanceFormat ) {
                GeoDataCoordinates coordinates( query.value(4).toFloat(), query.value(5).toFloat(), 0.0, GeoDataCoordinates::Degree );
                placemark.setAdditionalInformation( formatDistance( coordinates, userQuery.position() ) );
            } else {
                placemark.setAdditionalInformation( query.value( 0 ).toString() );
            }
            placemark.setName( query.value(1).toString() );
            placemark.setHouseNumber( query.value(2).toString() );
            placemark.setCategory( (OsmPlacemark::OsmCategory) query.value(3).toInt() );
            placemark.setLongitude( query.value(4).toFloat() );
            placemark.setLatitude( query.value(5).toFloat() );

            result.push_back( placemark );
            resultCount++;
        }

        mDebug() << Q_FUNC_INFO << "query in" << databaseFile << "with query" << queryString
                 << "took" << queryTimer.elapsed() << "ms for" << resultCount << "results";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
        if (auto placemark = geodata_cast<GeoDataPlacemark>(feature)) {
            // If the placemark's osmData is not complete, it is initialized by the OsmObjectManager
            OsmObjectManager::initializeOsmData( placemark );
            const OsmPlacemarkData & osmData = placemark->osmData();

            if (geodata_cast<GeoDataPoint>(placemark->geometry())) {
                m_nodes << OsmConverter::Node(placemark->coordinate(), osmData);
            } else if (const auto lineString = geodata_cast<GeoDataLineString>(placemark->geometry())) {
                for (auto const &coordinates: *lineString) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(lineString, osmData);
            } else if (const auto linearRing = geodata_cast<GeoDataLinearRing>(placemark->geometry())) {
                for (auto const &coordinates: *linearRing) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(linearRing, osmData);
            } else if (const auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry())) {
                int index = -1;

                // Writing all the outerRing's nodes
                const GeoDataLinearRing &outerRing = polygon->outerBoundary();
                const OsmPlacemarkData outerRingOsmData = osmData.memberReference( index );
                for (auto const &coordinates: outerRing) {
                    m_nodes << OsmConverter::Node(coordinates, outerRingOsmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(&outerRing, outerRingOsmData);

                // Writing all nodes for each innerRing
                for (auto const &innerRing: polygon->innerBoundaries() ) {
                    ++index;
                    const OsmPlacemarkData innerRingOsmData = osmData.memberReference( index );
                    for (auto const &coordinates: innerRing) {
                        m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
                    }
                    m_ways << OsmConverter::Way(&innerRing, innerRingOsmData);
                }
                m_relations.append(OsmConverter::Relation(placemark, osmData));
            }
        } else if (const auto placemark = geodata_cast<GeoDataRelation>(feature)) {
            m_relations.append(OsmConverter::Relation(placemark, placemark->osmData()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * a, const GeoDataRelation * b) {
            return a->relationType() < b->relationType();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const PositionProviderPlugin* plugin: pluginManager->positionProviderPlugins() ) {
            if ( plugin->nameId() == positionProvider ) {
                PositionProviderPlugin* instance = plugin->newInstance();
                tracking->setPositionProviderPlugin( instance );
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &point: innerPath) {
                    GeoDataCoordinates const coordinates = point.coordinates();
                    innerRing << coordinates;
                    auto const originalOsmData = innerRingOsmData.nodeReference(coordinates);
                    if (originalOsmData.id() > 0) {
                        newInnerRingOsmData.addNodeReference(coordinates, originalOsmData);
                    }
                    ++nodeIndex;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* innerPolygonPerBoundary: innerPolygonsPerBoundary ) {
                    innerPolygons << innerPolygonPerBoundary;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataCoordinates& coord: coordinates ) {

        const qreal lon = coord.longitude();
        const qreal lat = coord.latitude();

        const qreal rotatedLon = ( lon - centerLon ) * cosRotation - ( lat - centerLat ) * sinRotation + centerLon;
        const qreal rotatedLat = ( lon - centerLon ) * sinRotation + ( lat - centerLat ) * cosRotation + centerLat;

        if ( !northSet || rotatedLat > box.north() ) {
            northSet = true;
            box.setNorth( rotatedLat );
        }

        if ( !southSet || rotatedLat < box.south() ) {
            southSet = true;
            box.setSouth( rotatedLat );
        }

        if ( !westSet || rotatedLon < box.west() ) {
            westSet = true;
            box.setWest( rotatedLon );
        }

        if ( !eastSet || rotatedLon > box.east() ) {
            eastSet = true;
            box.setEast( rotatedLon );
        }
    }
```

#### AUTO 


```{c}
auto document = static_cast<const GeoDataDocument*>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &tag: tags) {
        QString const value = m_placemark.osmData().tagValue(tag);
        if (!value.isEmpty()) {
            QUrl url = QUrl(value);
            if (url.isValid()) {
                if (url.scheme().isEmpty()) {
                    m_website = QStringLiteral("http://%1").arg(value);
                } else {
                    m_website = value;
                }
                if (!m_website.isEmpty()) {
                    return m_website;
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto& osmData = m_placemark.osmData();
```

#### AUTO 


```{c}
auto iter = m_documents.begin();
```

#### AUTO 


```{c}
const auto configFiles = getenv("TIREX_BACKEND_MAP_CONFIGS");
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: files ) {
        if (file.endsWith(QLatin1Char('/'))) {
            directories << file;
        } else {
            QFile::remove( file );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &tag: tags ) {
        const QStringList tagSplit = tag.split(QLatin1Char('='));
        QString key = tagSplit.at( 0 );
        if ( !osmData.containsTagKey( key ) ) {
            filter << key;
        }
    }
```

#### AUTO 


```{c}
const auto end = placemark->osmData().nodeReferencesEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & tag: StyleBuilder::buildingTags()) {
            s_buildingTags.insert(tag);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &relation: relations) {
        relation.createRelation(document, placemarks);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataStyleMap &map: d->m_document.styleMaps() ) {
        document->addStyleMap( map );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemA: m_diffA ) {
        if( itemA.m_action == DiffItem::NoAction ) {
            bool deleted = false;
            bool changed = false;
            DiffItem other;

            for( const DiffItem &itemB: m_diffB ) {
                if( EARTH_RADIUS * itemA.m_placemarkA.coordinate().sphericalDistanceTo(itemB.m_placemarkA.coordinate()) <= 1 ) {
                    if( itemB.m_action == DiffItem::Deleted ) {
                        deleted = true;
                    } else if( itemB.m_action == DiffItem::Changed ) {
                        changed = true;
                        other = itemB;
                    }
                }
            }
            if( changed ) {
                m_merged.append( other );
            } else if( !deleted ) {
                m_merged.append( itemA );
            }
        } else if( itemA.m_action == DiffItem::Created ) {
            m_merged.append( itemA );
        } else if( itemA.m_action == DiffItem::Changed || itemA.m_action == DiffItem::Deleted ) {
            bool conflict = false;
            DiffItem other;

            for( const DiffItem &itemB: m_diffB ) {
                if (EARTH_RADIUS * itemA.m_placemarkB.coordinate().sphericalDistanceTo(itemB.m_placemarkB.coordinate()) <= 1) {
                    if( ( itemA.m_action == DiffItem::Changed && ( itemB.m_action == DiffItem::Changed || itemB.m_action == DiffItem::Deleted ) )
                            || ( itemA.m_action == DiffItem::Deleted && itemB.m_action == DiffItem::Changed ) ) {
                        conflict = true;
                        other = itemB;
                    }
                }
            }

            if( !conflict && itemA.m_action == DiffItem::Changed ) {
                m_merged.append( itemA );
            } else if ( conflict ) {
                m_conflictItem = other;
                MergeItem *mergeItem = new MergeItem();
                mergeItem->setPathA( itemA.m_path );
                mergeItem->setPathB( other.m_path );
                mergeItem->setPlacemarkA( itemA.m_placemarkA );
                mergeItem->setPlacemarkB( other.m_placemarkA );

                switch( itemA.m_action ) {
                case DiffItem::Changed:
                    mergeItem->setActionA( MergeItem::Changed );
                    break;
                case DiffItem::Deleted:
                    mergeItem->setActionA( MergeItem::Deleted );
                    break;
                default:
                    break;
                }

                switch( other.m_action ) {
                case DiffItem::Changed:
                    mergeItem->setActionB( MergeItem::Changed );
                    break;
                case DiffItem::Deleted:
                    mergeItem->setActionB( MergeItem::Deleted );
                    break;
                default:
                    break;
                }

                emit m_q->mergeConflict( mergeItem );
                return;
            }
        }

        if( !m_diffA.isEmpty() ) {
            m_diffA.removeFirst();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const SearchRunnerPlugin *plugin: plugins ) {
        SearchTask *task = new SearchTask( plugin->newRunner(), this, d->m_marbleModel, searchTerm, preferred );
        connect( task, SIGNAL(finished(SearchTask*)), this, SLOT(cleanupSearchTask(SearchTask*)) );
        d->m_searchTasks << task;
        mDebug() << "search task " << plugin->nameId() << " " << (quintptr)task;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& intersection : intersections) {
                if(intersection->isEntering() && !intersection->isProcessed()) {
                    iterateBasePolygon = true;

                    QSharedPointer<LinkedPoint> it = intersection;
                    clippedPolyObject << it->point();
                    it->setProcessed(true);

                    do {
                        if(iterateBasePolygon) {
                            it = it->nextBasePolygonPoint();
                            if(it->isLeaving()) {
                                iterateBasePolygon = false;
                                it->setProcessed(true);
                            } else if(it->isEntering()) {
                                it->setProcessed(true);
                            }
                        }  else {
                            it = it->nextClipPolygonPoint();
                            if(it->isEntering()) {
                                iterateBasePolygon = true;
                                it->setProcessed(true);
                            } else if(it->isLeaving()) {
                                it->setProcessed(true);
                            }
                        }
                        clippedPolyObject << it->point();

//                        // To avoid crashes because of infinite loop.
//                        // Needs to be investigated
//                        if(clippedPolyObject.size() > basePolygon.size()) {
//                            qDebug() << "Something went wrong, exiting current clipping loop...";
//                            break;
//                        }

                    } while(clippedPolyObject.first() != clippedPolyObject.last());

                    clippedPolyObjects << clippedPolyObject;
                    clippedPolyObject = QPolygonF();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& oldLocalPath: oldLocalPaths ) {
        QDir oldLocalDir( oldLocalPath );

        if( oldLocalDir.entryList( QDir::AllEntries | QDir::NoDotAndDotDot ).size() == 0 ) {
            continue;
        }

        QPointer<QDialog> dialog = new QDialog();
        Ui::DataMigrationWidget dataMigrationWidget;

        dataMigrationWidget.setupUi( dialog );
        if( dialog->exec() == QDialog::Accepted ) {
            DataMigration::moveFiles( oldLocalPath, currentLocalPath );
        }
        delete dialog;

        return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const AxisTick &tick: m_axisX.ticks() ) {
        const int posX = m_leftGraphMargin + tick.position;
        painter->setPen( dashedPen );
        painter->drawLine( posX, 0, posX, m_eleGraphHeight );

        intervalStr.setNum( tick.value * m_axisX.scale() );
        if ( tick.position == m_axisX.ticks().last().position ) {
            intervalStr += QLatin1Char(' ') + m_axisX.unit();
        }
        labelRect.setWidth( QFontMetricsF( font() ).width( intervalStr ) * 1.5 );
        labelRect.moveCenter( QPoint( posX, labelRect.center().y() ) );
        if ( labelRect.right() > m_leftGraphMargin + m_eleGraphWidth ) {
            // don't cut off rightmost label
            labelRect.moveRight( m_leftGraphMargin + m_eleGraphWidth );
        }
        if ( labelRect.left() <= lastStringEnds ) {
            // Don't print overlapping labels
            continue;
        }
        lastStringEnds = labelRect.right();
        painter->setPen( QColor( Qt::black ) );
        painter->drawText( labelRect, Qt::AlignCenter, intervalStr );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto popularity: popularities) {
            StyleBuilder::Private::s_popularities[popularity] = value;
            value -= offset;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action: m_selectionActions) {
        m_contextMenu->addAction(action);
    }
```

#### AUTO 


```{c}
auto const pisteType = osmData.tagValue(QStringLiteral("piste:type"));
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &path: paths ) {
        for( const QString &lang: QStringList() << lang << code ) {
            QFileInfo translations = QFileInfo( path + QLatin1String("/routing-instructions_") + lang + QLatin1String(".qm"));
            if ( translations.exists() && translator.load( translations.absoluteFilePath() ) ) {
                app.installTranslator( &translator );
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
                if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
                    auto relation = static_cast<const GeoDataRelation*>(feature);
                    if (relevantRelations.contains(relation) &&
                            relation->osmData().containsTag(QStringLiteral("type"), QStringLiteral("public_transport")) &&
                            relation->osmData().containsTag(QStringLiteral("public_transport"), QStringLiteral("stop_area"))) {
                        for (auto iter = relation->osmData().relationReferencesBegin(), end = relation->osmData().relationReferencesEnd();
                             iter != end; ++iter) {
                            if (iter.value() == QStringLiteral("stop") || iter.value() == QStringLiteral("platform")) {
                                placemarkIds << iter.key();
                            }
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(RenderPlugin *renderPlugin: m_renderPlugins) {
        if ( name == renderPlugin->nameId() ) {
            if ( renderPlugin->visible() == show ) {
                break;
            }

            renderPlugin->setVisible( show );

            break;
        }
    }
```

#### AUTO 


```{c}
auto & lineStringItems = m_osmLineStringItems[osmId];
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action: m_selectionActions) {
        m_contextMenu->removeAction( action );
    }
```

#### AUTO 


```{c}
auto const & way
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &coordinate: bounds) {
        for(auto const &ring: m_boundingPolygon) {
            if (ring.contains(coordinate)) {
                ++innerNodes;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & relation: relations) {
        if (relation.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x12); // relation start indicator
        OsmPlacemarkData const & osmData = relation.second;

        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        lastId = osmData.id();
        writeVersion(osmData, bufferStream);

        QBuffer referencesBuffer;
        referencesBuffer.open(QIODevice::WriteOnly);
        QDataStream referencesStream(&referencesBuffer);
        if (const auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)) {
            auto polygon = geodata_cast<GeoDataPolygon>(placemark->geometry());
            Q_ASSERT(polygon);
            writeMultipolygonMembers(*polygon, lastReferenceId, osmData, stringTable, referencesStream);
        } else if (const auto placemark = geodata_cast<GeoDataRelation>(relation.first)) {
            writeRelationMembers(placemark, lastReferenceId, osmData, stringTable, referencesStream);
        } else {
            Q_ASSERT(false);
        }
        writeUnsigned(referencesBuffer.size(), bufferStream);
        bufferStream.writeRawData(referencesBuffer.data().constData(), referencesBuffer.size());

        writeTags(osmData, stringTable, bufferStream);

        writeUnsigned(buffer.size(), stream);
        stream.writeRawData(buffer.data().constData(), buffer.size());
    }
```

#### AUTO 


```{c}
const auto& intersection
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: parser.positionalArguments() ) {
        // FIXME: Use openUrl( args->url(i) ) instead?
        if ( QFile::exists( file ) ) {
            window.marbleControl()->addGeoDataFile( file );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: *ring) {
            auto p = coordinateToPoint(node);
            coordMap.insert(std::make_pair(p.X, p.Y), &node);
            subject.push_back(std::move(p));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataPlacemark *placemark: container->placemarkList() ) {
        if ( placemark->coordinate() == coordinate )
            return placemark;
    }
```

#### AUTO 


```{c}
const auto wait = geodata_cast<GeoDataWait>(primitive)
```

#### AUTO 


```{c}
auto const iter = m_areas.find(&ring);
```

#### AUTO 


```{c}
auto iter = m_tags.begin(), end = m_tags.end();
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataTourPrimitive* m_primitive: m_primitives ){
            if( m_primitive->nodeType() != other.m_primitives.at( index )->nodeType() ){
                return false;
            }else{
                const char* node = m_primitive->nodeType();
                if ( node ==  GeoDataTypes::GeoDataAnimatedUpdateType ){
                    GeoDataAnimatedUpdate* update1 = static_cast<GeoDataAnimatedUpdate*>( m_primitive );
                    GeoDataAnimatedUpdate* update2 = static_cast<GeoDataAnimatedUpdate*>( other.m_primitives.at( index ) );
                    if( *update1 != *update2 ){
                        return false;
                    }
                }
                else if( node == GeoDataTypes::GeoDataSoundCueType ){
                    GeoDataSoundCue* cue1 = static_cast<GeoDataSoundCue*>( m_primitive );
                    GeoDataSoundCue* cue2 = static_cast<GeoDataSoundCue*>( other.m_primitives.at( index ) );
                    if ( *cue1 != *cue2 ){
                        return false;
                    }
                }
                else if( node == GeoDataTypes::GeoDataTourControlType ){
                    GeoDataTourControl* control1 = static_cast<GeoDataTourControl*>( m_primitive );
                    GeoDataTourControl* control2 = static_cast<GeoDataTourControl*>( other.m_primitives.at( index ) );
                    if( *control1 != *control2 ){
                        return false;
                    }
                }
                else if( node == GeoDataTypes::GeoDataWaitType ){
                    GeoDataWait* wait1 = static_cast<GeoDataWait*>( m_primitive );
                    GeoDataWait* wait2 = static_cast<GeoDataWait*>( other.m_primitives.at( index ) );
                    if( *wait1 != *wait2 ){
                        return false;
                    }
                }
                else if( node == GeoDataTypes::GeoDataFlyToType ){
                    GeoDataFlyTo* flyTo1 = static_cast<GeoDataFlyTo*>( m_primitive );
                    GeoDataFlyTo* flyTo2 = static_cast<GeoDataFlyTo*>( other.m_primitives.at( index ) );
                    if( *flyTo1 != *flyTo2 ){
                        return false;
                    }
                }
                index++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFeature *feature: document->featureList()) {
        if (const auto placemark = geodata_cast<GeoDataPlacemark>(feature)) {
            bool acceptPlacemark = false;
            auto const & osmData = placemark->osmData();

            if (filterFlag == FilterRailwayService &&
                    osmData.containsTagKey(QStringLiteral("railway")) &&
                    osmData.containsTagKey(QStringLiteral("service"))) {
                acceptPlacemark = false;
            } else {
                for (auto const &tag: tagsList) {
                    bool contains;
                    if (tag.second == QLatin1String("*")) {
                        contains = osmData.containsTagKey(tag.first);
                    } else {
                        contains = osmData.containsTag(tag.first, tag.second);
                    }
                    if (contains) {
                        acceptPlacemark = true;
                        break;
                    }
                }
            }

            if (acceptPlacemark) {
                m_accepted->append(placemark->clone());
            } else {
                m_rejectedObjects.append(placemark->clone());
            }
        }
        else {
            m_accepted->append(feature->clone());
        }
    }
```

#### AUTO 


```{c}
auto const & clickedItemsList = d->m_tiledItems.values(*tileIter);
```

#### LAMBDA EXPRESSION 


```{c}
[=](bool){}
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &value: input ) {
                if (!region.continent().isEmpty() && !region.name().isEmpty()) {
                    PendingJob job;
                    job.m_region = region;
                    job.m_transport = value.trimmed();
                    if (job.m_transport == QLatin1String("Motorcar")) {
                        job.m_profile = "motorcar";
                        m_pendingJobs << job;
                    } else if (job.m_transport == QLatin1String("Bicycle")) {
                        job.m_profile = "bicycle";
                        m_pendingJobs << job;
                    } else if (job.m_transport == QLatin1String("Pedestrian")) {
                        job.m_profile = "foot";
                        m_pendingJobs << job;
                    } else {
                        qDebug() << "Invalid transport type " << job.m_transport
                                 << " in .xml file, ignoring. Valid types are Motorcar, Bicycle and Pedestrian.";
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &item: diffList ) {
                if( item.m_action != DiffItem::NoAction ) {
                    localModified = true;
                }
            }
```

#### AUTO 


```{c}
const auto prevPolygon = geodata_cast<GeoDataPolygon>(&building->multiGeometry()->at(0))
```

#### AUTO 


```{c}
auto iter=osmData.tagsBegin(), end = osmData.tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataStyle::Ptr &style: d->m_document.styles() ) {
        document->addStyle( style );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RenderPlugin *renderPlugin: m_renderPlugins) {
        bool propertyAvailable = false;
        m_model->mapTheme()->settings()->propertyAvailable( renderPlugin->nameId(), propertyAvailable );
        bool propertyValue = false;
        m_model->mapTheme()->settings()->propertyValue( renderPlugin->nameId(), propertyValue );

        if ( propertyAvailable ) {
            renderPlugin->setVisible( propertyValue );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: m_files ) {
        if ( !QFile::remove( file ) ) {
            mDebug() << "Failed to remove temporary file" << file;
        }
    }
```

#### AUTO 


```{c}
auto placemark = node.create();
```

#### AUTO 


```{c}
const auto lineString = geodata_cast<GeoDataLineString>(d->m_placemark->geometry())
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
        if (feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            GeoDataPlacemark* placemark = static_cast<GeoDataPlacemark*>(feature);
            // If the placemark's osmData is not complete, it is initialized by the OsmObjectManager
            OsmObjectManager::initializeOsmData( placemark );
            const OsmPlacemarkData & osmData = placemark->osmData();

            if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPointType ) {
                m_nodes << OsmConverter::Node(placemark->coordinate(), osmData);
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataLineStringType ) {
                const GeoDataLineString* lineString = static_cast<const GeoDataLineString*>( placemark->geometry() );
                foreach(const GeoDataCoordinates &coordinates, *lineString) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(lineString, osmData);
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataLinearRingType ) {
                const GeoDataLinearRing* linearRing = static_cast<const GeoDataLinearRing*>( placemark->geometry() );
                foreach(const GeoDataCoordinates &coordinates, *linearRing) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(linearRing, osmData);
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType ) {
                const GeoDataPolygon *polygon = static_cast<const GeoDataPolygon*>( placemark->geometry() );
                int index = -1;

                // Writing all the outerRing's nodes
                const GeoDataLinearRing &outerRing = polygon->outerBoundary();
                const OsmPlacemarkData outerRingOsmData = osmData.memberReference( index );
                foreach(const GeoDataCoordinates &coordinates, outerRing) {
                    m_nodes << OsmConverter::Node(coordinates, outerRingOsmData.nodeReference(coordinates));
                }
                m_ways << OsmConverter::Way(&outerRing, outerRingOsmData);

                // Writing all nodes for each innerRing
                foreach ( const GeoDataLinearRing &innerRing, polygon->innerBoundaries() ) {
                    ++index;
                    const OsmPlacemarkData innerRingOsmData = osmData.memberReference( index );
                    foreach(const GeoDataCoordinates &coordinates, innerRing) {
                        m_nodes << OsmConverter::Node(coordinates, innerRingOsmData.nodeReference(coordinates));
                    }
                    m_ways << OsmConverter::Way(&innerRing, innerRingOsmData);
                }
                m_relations.append(OsmConverter::Relation(placemark, osmData));
            }
        } else if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
            GeoDataRelation* placemark = static_cast<GeoDataRelation*>(feature);
            m_relations.append(OsmConverter::Relation(placemark, placemark->osmData()));
        }
    }
```

#### AUTO 


```{c}
auto const originalPlacemarkData = source.osmData();
```

#### AUTO 


```{c}
auto const &coordinate
```

#### AUTO 


```{c}
auto tagIter = m_osmData.findTag(QStringLiteral("addr:housename"));
```

#### AUTO 


```{c}
const auto midIdx = dgram.data().indexOf('=', nextIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &filterString : m_idFilter ) {
                if( filterString.startsWith( newId ) ) {
                    filter.append( filterString );
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScreenOverlayGraphicsItem* item: d->m_screenOverlays) {
        item->paintEvent(painter, viewport);
    }
```

#### AUTO 


```{c}
auto const clip = clipPath(tileBoundary);
```

#### RANGE FOR STATEMENT 


```{c}
for( const RelationPair & pair: relation.ways ) {
        if ( pair.second == Outer ) {
            importWay( outer, pair.first );
        } else if ( pair.second == Inner ) {
            importWay( inner, pair.first );
        } else {
            qDebug() << "Ignoring way " << pair.first << " with unknown relation role.";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
                if (const auto relation = geodata_cast<GeoDataRelation>(feature)) {
                    if (relevantRelations.contains(relation) &&
                            relation->osmData().containsTag(QStringLiteral("type"), QStringLiteral("public_transport")) &&
                            relation->osmData().containsTag(QStringLiteral("public_transport"), QStringLiteral("stop_area"))) {
                        for (auto iter = relation->osmData().relationReferencesBegin(), end = relation->osmData().relationReferencesEnd();
                             iter != end; ++iter) {
                            if (iter.value() == QStringLiteral("stop") || iter.value() == QStringLiteral("platform")) {
                                placemarkIds << iter.key();
                            }
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto const & innerBoundaries = qAsConst(polygon)->innerBoundaries();
```

#### AUTO 


```{c}
const auto data = f.map(0, f.size());
```

#### AUTO 


```{c}
auto const count = layerItems.negative.size() + layerItems.null.size() + layerItems.positive.size();
```

#### AUTO 


```{c}
auto const applications = QStringList() << merkaartor << josm;
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataDocument *doc: m_seaDocuments ) {
        if ( doc->isVisible() ) {
            painter->setPen( Qt::NoPen );
            painter->setBrush( QBrush( m_seaColor ) );
            drawIndividualDocument( painter, doc );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: m_otherPlacemarks) {
        document()->append(placemark);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QSharedPointer<LinkedPoint>& A, QSharedPointer<LinkedPoint>& B) {
                return A->point().x() < B->point().x();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( Marble::GeoDataFolder* const folder: bookmarks->folderList() ) {
        if ( folder->name() == folderName ) {
            target = folder;
            break;
        }
    }
```

#### AUTO 


```{c}
auto const & ring
```

#### AUTO 


```{c}
const auto ring = geodata_cast<GeoDataLinearRing>(&building->multiGeometry()->at(0))
```

#### AUTO 


```{c}
const auto tagIter = osmData.findTag(QStringLiteral("ele"));
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString & key: keys ) {
        QList<QList<Way> > merged = merge( waysByName.values( key ) );
        for( const QList<Way> & ways: merged ) {
            Q_ASSERT( !ways.isEmpty() );
            OsmPlacemark placemark = ways.first();
            ways.first().setPosition( m_coordinates, placemark );
            ways.first().setRegion( m_nodes, regionTree, m_osmOsmRegions, placemark );

            if ( placemark.category() != OsmPlacemark::Address && !ways.first().name.isEmpty() ) {
                placemark.setHouseNumber( QString() );
                m_placemarks.push_back( placemark );
            }

            if ( !ways.first().isBuilding || !ways.first().houseNumber.isEmpty() ) {
                placemark.setCategory( OsmPlacemark::Address );
                QString name = ways.first().street.isEmpty() ? ways.first().name : ways.first().street;
                if ( !name.isEmpty() ) {
                    placemark.setName( name.trimmed() );
                    placemark.setHouseNumber( ways.first().houseNumber.trimmed() );
                    m_placemarks.push_back( placemark );
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto iter = tileList.find(feature);
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
            if (!itPolygon->boundingRect().intersects(viewportRect)) {
                continue;
            }

            labelNodes.clear();

            QPainterPath path;
            path.addPolygon(*itPolygon);
            qreal pathLength = path.length();
            if (pathLength == 0) continue;

            int maxNumLabels = static_cast<int>(pathLength / labelWidth);

            if (maxNumLabels > 0) {
                qreal textRelativeLength = labelWidth / pathLength;
                int numLabels = 1;
                if (maxNumLabels > 1) {
                    numLabels = maxNumLabels/2;
                }
                qreal offset = (1.0 - numLabels*textRelativeLength)/numLabels;
                qreal startPercent = offset/2.0;

                for (int k = 0; k < numLabels; ++k, startPercent += textRelativeLength + offset) {
                    QPointF point = path.pointAtPercent(startPercent);
                    QPointF endPoint = path.pointAtPercent(startPercent + textRelativeLength);

                    if ( viewport().contains(point.toPoint()) || viewport().contains(endPoint.toPoint()) ) {
                        qreal angle = -path.angleAtPercent(startPercent);
                        qreal angle2 = -path.angleAtPercent(startPercent + textRelativeLength);
                        angle = GeoPainterPrivate::normalizeAngle(angle);
                        angle2 = GeoPainterPrivate::normalizeAngle(angle2);
                        bool upsideDown = angle > 90.0 && angle < 270.0;

                        if ( qAbs(angle - angle2) < 3.0 ) {
                            if ( upsideDown ) {
                                angle += 180.0;
                                point = path.pointAtPercent(startPercent + textRelativeLength);
                            }

                            d->drawTextRotated(point, angle, labelText);
                        } else {
                            for (int i = 0; i < labelText.length(); ++i) {
                                qreal currentGlyphTextLength = fontMetrics().horizontalAdvance(labelText.left(i)) / pathLength;

                                if ( !upsideDown ) {
                                    angle = -path.angleAtPercent(startPercent + currentGlyphTextLength);
                                    point = path.pointAtPercent(startPercent + currentGlyphTextLength);
                                }
                                else {
                                    angle = -path.angleAtPercent(startPercent + textRelativeLength - currentGlyphTextLength) + 180;
                                    point = path.pointAtPercent(startPercent + textRelativeLength - currentGlyphTextLength);
                                }

                                d->drawTextRotated(point, angle, labelText.at(i));
                            }
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto feature = geodata_cast<GeoDataPlacemark>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto folder : folders) {
            for (const auto placemark : folder->placemarkList()) {
                importPlacemark(outline, segments, placemark);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataGeometry *geometry: other.m_vector) {

            m_vector.append(geometry->copy());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( SoundTrack* track: d->m_soundTracks) {
        track->stop();
    }
```

#### AUTO 


```{c}
auto polygon = geodata_cast<GeoDataPolygon>(& static_cast<const GeoDataMultiGeometry*>(building->multiGeometry())->at(0));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &innerPath: innerPaths) {
                int const newIndex = newPolygon->innerBoundaries().size();
                auto & newInnerRingOsmData = newPlacemarkOsmData.memberReference(newIndex);
                GeoDataLinearRing innerRing;
                pathToRing(innerPath, &innerRing, innerRingOsmData, newInnerRingOsmData, coordMap);
                newPolygon->appendInnerBoundary(innerRing);
                if (innerRingOsmData.id() > 0) {
                    newInnerRingOsmData.addTag(QStringLiteral("mx:oid"), QString::number(innerRingOsmData.id()));
                    osmIds.insert(innerRingOsmData.id());
                }
                copyTags(innerRingOsmData, newInnerRingOsmData);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoScenePalette *curPalette: palette ) {

                    if (curPalette->type() == QLatin1String("sea")) {
                        seafile = MarbleDirs::path( curPalette->file() );
                    } else if (curPalette->type() == QLatin1String("land")) {
                        landfile = MarbleDirs::path( curPalette->file() );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: items) {
                if (item->feature() == feature) {
                    items.removeOne(item);
                    removed = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
const auto offset = f.pos();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: placemarks) {
        painter->drawRect(placemark->labelRect());
        painter->drawRect(placemark->symbolRect());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature : *doc) {
            auto placemark = geodata_cast<GeoDataPlacemark>(feature);
            if (placemark == nullptr) {
                continue;
            }

            if (geodata_cast<GeoDataTrack>(placemark->geometry()) ||
                geodata_cast<GeoDataPoint>(placemark->geometry())) {
                continue;
            }

            placemark->setStyleUrl(styleUrl);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (VectorTileModel *candidate: m_tileModels) {
        bool enabled = true;
        if (m_layerSettings) {
            const bool propertyExists = m_layerSettings->propertyValue(candidate->name(), enabled);
            enabled |= !propertyExists; // if property doesn't exist, enable layer nevertheless
        }
        if (enabled) {
            m_activeTileModels.append(candidate);
            mDebug() << "enabling vector layer" << candidate->name();
        } else {
            candidate->clear();
            mDebug() << "disabling vector layer" << candidate->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( SoundTrack* track: d->m_soundTracks) {
        track->play();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Way & way: ways ) {
            if ( way.nodes.first() == aWay.nodes.first() ) return true;
            if ( way.nodes.last()  == aWay.nodes.first() ) return true;
            if ( way.nodes.first() == aWay.nodes.last() ) return true;
            if ( way.nodes.last()  == aWay.nodes.last() ) return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataPlacemark *placemark: folder->placemarkList() ) {
            routeName.append( placemark->name() );
            routeName.append( " - " );
        }
```

#### AUTO 


```{c}
auto const & osmData = placemark.osmData();
```

#### RANGE FOR STATEMENT 


```{c}
for( int distance: distances ) {
            QString file = audioFile( QString::number( distance ) );
            qreal currentDistance = qAbs( distance - dest );
            if ( !file.isEmpty() && ( minDistance == 0.0 || currentDistance < minDistance ) ) {
                minDistance = currentDistance;
                targetDistance = distance;
            }
        }
```

#### AUTO 


```{c}
const auto lineString = geodata_cast<GeoDataLineString>(m_placemark->geometry())
```

#### LAMBDA EXPRESSION 


```{c}
[=]( QString document ) {
            d->m_marbleModel->setLegend( new QTextDocument(document) );
        }
```

#### AUTO 


```{c}
auto const tag = OsmTag(QStringLiteral("piste:type"), pisteType);
```

#### AUTO 


```{c}
const auto tag = OsmPresetLibrary::OsmTag(propertyIterator.name().toLower(), propertyIterator.value().toString().toLower());
```

#### AUTO 


```{c}
auto iter = osmData.nodeReferencesBegin();
```

#### AUTO 


```{c}
const auto prevLine = geodata_cast<GeoDataLineString>(geometry)
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoDataLinearRing &innerRing: innerRings ) {
        for ( int i = 0; i < innerRing.size(); ++i ) {
            if ( !poly->outerBoundary().contains( innerRing.at(i) ) ) {
                return false;
            }
        }
    }
```

#### AUTO 


```{c}
auto cacheDirectory = backend.configValue(QStringLiteral("cache-directory")).toString();
```

#### AUTO 


```{c}
const auto linearRing = geodata_cast<GeoDataLinearRing>(&building->multiGeometry()->at(0))
```

#### AUTO 


```{c}
auto iter = placemark.osmData().nodeReferencesBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dir: path.split( QLatin1Char( ':' ) ) ) {
        QFileInfo application( QDir( dir ), executable );
        if ( application.exists() ) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *layer: textureLayers ) {
        const TileId tileId( layer->sourceDir(), stackedTileId.zoomLevel(),
                             stackedTileId.x(), stackedTileId.y() );
        RenderStatus tileStatus = Complete;
        switch ( TileLoader::tileStatus( layer, tileId ) ) {
        case TileLoader::Available:
            tileStatus = Complete;
            break;
        case TileLoader::Expired:
            tileStatus = WaitingForUpdate;
            break;
        case TileLoader::Missing:
            tileStatus = WaitingForData;
            break;
        }

        state.addChild( RenderState( layer->name(), tileStatus ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: selectedPlacemarks ) {
        for (auto tileIter = d->m_features.find(placemark); tileIter != d->m_features.end() && tileIter.key() == placemark; ++tileIter) {
            auto const & clickedItemsList = d->m_tiledItems.values(*tileIter);
            for (auto const & clickedItems: clickedItemsList) { //iterate through FeatureItemMap clickedItems (QHash)
                for (auto iter = clickedItems.find(placemark); iter != clickedItems.end(); ++iter) {
                    if ( iter.key() == placemark ) {
                const GeoDataObject *parent = placemark->parent();
                if ( parent ) {
                    auto item = *iter;
                    if (const GeoDataDocument *doc = geodata_cast<GeoDataDocument>(parent)) {
                        QString styleUrl = placemark->styleUrl();
                        styleUrl.remove(QLatin1Char('#'));
                        if ( !styleUrl.isEmpty() ) {
                            GeoDataStyleMap const &styleMap = doc->styleMap( styleUrl );
                            GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                            if ( style ) {
                                d->selectItem( item );
                                d->applyHighlightStyle( item, style );
                            }
                        }

                        /**
                            * If a placemark is using an inline style instead of a shared
                            * style ( e.g in case when theme file specifies the colorMap
                            * attribute ) then highlight it if any of the style maps have a
                            * highlight styleId
                            */
                        else {
                            for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
                        }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto blue = QColor("#000099");
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* innerPolygon: innerPolygons ) {
                ClipPainter::drawPolyline( *innerPolygon );
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoDataRelation * a, const GeoDataRelation * b) {
                return *a < *b;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QList<Way> & ways: merged ) {
            Q_ASSERT( !ways.isEmpty() );
            OsmPlacemark placemark = ways.first();
            ways.first().setPosition( m_coordinates, placemark );
            ways.first().setRegion( m_nodes, regionTree, m_osmOsmRegions, placemark );

            if ( placemark.category() != OsmPlacemark::Address && !ways.first().name.isEmpty() ) {
                placemark.setHouseNumber( QString() );
                m_placemarks.push_back( placemark );
            }

            if ( !ways.first().isBuilding || !ways.first().houseNumber.isEmpty() ) {
                placemark.setCategory( OsmPlacemark::Address );
                QString name = ways.first().street.isEmpty() ? ways.first().name : ways.first().street;
                if ( !name.isEmpty() ) {
                    placemark.setName( name.trimmed() );
                    placemark.setHouseNumber( ways.first().houseNumber.trimmed() );
                    m_placemarks.push_back( placemark );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataTrack *track: other.m_vector ) {
            m_vector.append( new GeoDataTrack( *track ) );
        }
```

#### AUTO 


```{c}
auto tileIter = d->m_features.find(feature), end = d->m_features.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : layerItems.positive) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### AUTO 


```{c}
auto &cluster
```

#### AUTO 


```{c}
auto const &segment
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: layerItems.null) {
            if (item->contains(curpos, viewport)) {
                d->m_lastFeatureAt = item;
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPolygonF *outline: m_cachedOuterPolygons) {
            if (outline->isEmpty()) {
                continue;
            }
            // draw the building sides
            int const size = outline->size();
            QPolygonF * outerRoof = new QPolygonF;
            outerRoof->reserve(outline->size());
            QPointF a = (*outline)[0];
            QPointF shiftA = a + buildingOffset(a, viewport);
            outerRoof->append(shiftA);
            for (int i=1; i<size; ++i) {
                QPointF const & b = (*outline)[i];
                QPointF const shiftB = b + buildingOffset(b, viewport);
                // perform backface culling
                bool backface = (b.x() - a.x()) * (shiftA.y() - a.y())
                        - (b.y() - a.y()) * (shiftA.x() - a.x()) >= 0;
                if (!backface) {
                    QPolygonF buildingSide;
                    buildingSide.reserve(4);
                    buildingSide << a << shiftA << shiftB << b;
                    painter->drawPolygon(buildingSide);
                }
                a = b;
                shiftA = shiftB;
                outerRoof->append(shiftA);
            }
            m_cachedOuterRoofPolygons.append(outerRoof);
        }
```

#### AUTO 


```{c}
auto const document = static_cast<const GeoDataDocument*>(placemark.parent());
```

#### CONST EXPRESSION 


```{c}
static constexpr const int m_metatileCols = 8;
```

#### AUTO 


```{c}
auto iter = osmData.tagsBegin(), end = osmData.tagsEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const TirexMetatileRequest &req) {
        // assuming the requested meta tile is a square power of two, we break that down into square power-of-two blocks
        // for high zoom levels using few (or even just one block is most efficient), for lower zoom levels we need to use
        // more blocks to reduce memory use
        // to avoid TileDirectory reloading the same block multiple times, we need to do the below processing in the proper order
        int loadZ = req.tile.z;
        if (backend.metatileColumns() == backend.metatileRows() && backend.metatileRows() == 8) {
            loadZ = req.tile.z - 3;
            loadZ = std::max(11, loadZ);
            loadZ = std::min(req.tile.z, loadZ);
        }
        const int blockSize = 1 << (req.tile.z - loadZ);
        const int blockColumns = backend.metatileColumns() / blockSize;
        const int blockRows = backend.metatileRows() / blockSize;

        TileDirectory mapTiles(cacheDirectory, QStringLiteral("planet.osmx"), manager, req.tile.z, loadZ);
        TileDirectory landTiles(TileDirectory::Landmass, cacheDirectory, manager, req.tile.z);

        QSaveFile f(backend.metatileFileName(req));
        if (!f.open(QFile::WriteOnly)) {
            backend.tileError(req, f.errorString());
            return;
        }

        backend.writeMetatileHeader(&f, req.tile);
        for (int blockX = 0; blockX < blockColumns; ++blockX) {
            for (int blockY = 0; blockY < blockRows; ++blockY) {
                for (int tileX = 0; tileX < blockSize; ++tileX) {
                    for (int tileY = 0; tileY < blockSize; ++tileY) {
                        const auto x = blockX * blockSize + tileX;
                        const auto y = blockY * blockSize + tileY;

                        auto const tileId = TileId (0, req.tile.z, x + req.tile.x, y + req.tile.y);
                        using GeoDocPtr = QSharedPointer<GeoDataDocument>;
                        GeoDocPtr tile1 = GeoDocPtr(mapTiles.clip(tileId.zoomLevel(), tileId.x(), tileId.y()));
                        TagsFilter::removeAnnotationTags(tile1.data());
                        if (tileId.zoomLevel() < 17) {
                            WayConcatenator concatenator(tile1.data());
                        }
                        NodeReducer nodeReducer(tile1.data(), tileId);
                        GeoDocPtr tile2 = GeoDocPtr(landTiles.clip(tileId.zoomLevel(), tileId.x(), tileId.y()));
                        GeoDocPtr combined = GeoDocPtr(mergeDocuments(tile1.data(), tile2.data()));

                        const auto offset = f.pos();
                        if (GeoDataDocumentWriter::write(&f, *combined, QStringLiteral("o5m"))) {
                            backend.writeMetatileEntry(&f, x * backend.metatileColumns() + y, offset, f.pos() - offset);
                        } else {
                            qWarning() << "Could not write the tile " << combined->name();
                        }
                    }
                }
            }
        }

        f.commit();
        backend.tileDone(req);
    }
```

#### AUTO 


```{c}
auto const &node
```

#### AUTO 


```{c}
auto& val
```

#### AUTO 


```{c}
auto const & osmData = placemark->osmData();
```

#### AUTO 


```{c}
auto const colorValue = m_relations.at(index.row())->osmData().tagValue(QStringLiteral("colour"));
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &line: lines ) {
        if ( !line.trimmed().isEmpty() &&
             !line.trimmed().startsWith(QLatin1Char('#')) &&
             !line.startsWith( QLatin1String( "Content-Type: text/plain" ) ) ) {
            QStringList entries = line.split( m_fieldSeparator );
            if ( entries.size() >= 1 + m_fieldIndices[RoadName] ) {
                qreal lon = readField<qreal>( Longitude, entries );
                qreal lat = readField<qreal>( Latitude, entries );
                RoutingPoint point( lon, lat );
                QString junctionTypeRaw = readField<QString>( JunctionType, entries, QString() );
                RoutingWaypoint::JunctionType junctionType = RoutingWaypoint::Other;
                if ( m_junctionTypeMapping.contains( junctionTypeRaw ) ) {
                  junctionType = m_junctionTypeMapping[junctionTypeRaw];
                }
                QString roadType = readField<QString>( RoadType, entries, QString() );
                int secondsRemaining = readField<int>( TotalSecondsRemaining, entries, -1 );
                QString roadName = readField<QString>( RoadName, entries, QString() );

                // Road names may contain the field separator
                for (int i = 2 + m_fieldIndices[RoadName]; i<entries.size(); ++i)
                {
                  roadName += m_fieldSeparator + entries.at(i);
                }

                RoutingWaypoint item( point, junctionType, junctionTypeRaw, roadType, secondsRemaining, roadName );
                result.push_back( item );
            } else {
                qDebug() << "Cannot parse " << line << "(detected " << entries.size() << " fields)";
            }
        }
    }
```

#### AUTO 


```{c}
const auto geometry = geodata_cast<GeoDataMultiGeometry>(parentItem)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto category: categories) {
            for (auto iter=tagMap.begin(), end=tagMap.end(); iter != end; ++iter) {
                if (iter.value() == category) {
                    int zoomLevel = StyleBuilder::minimumZoomLevel(category);
                    if (zoomLevel < 17) {
                        m_tags[zoomLevel] << iter.key();
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto end = osmData.relationReferencesEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( const DiffItem &itemB: m_diffB ) {
                if( EARTH_RADIUS * itemA.m_placemarkA.coordinate().sphericalDistanceTo(itemB.m_placemarkA.coordinate()) <= 1 ) {
                    if( itemB.m_action == DiffItem::Deleted ) {
                        deleted = true;
                    } else if( itemB.m_action == DiffItem::Changed ) {
                        changed = true;
                        other = itemB;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* itPolygon: polygons ) {
        painterPath.addPolygon( *itPolygon );
    }
```

#### AUTO 


```{c}
auto it = osmData.tagsBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for( RenderPlugin *plugin: renderPlugins() ) {
        settings.beginGroup(QLatin1String("plugin_") + plugin->nameId());

        QHash<QString,QVariant> hash = plugin->settings();

        QHash<QString,QVariant>::iterator it = hash.begin();
        while( it != hash.end() ) {
            settings.setValue( it.key(), it.value() );
            ++it;
        }

        settings.endGroup();
    }
```

#### AUTO 


```{c}
const auto valueLen = endIdx - midIdx - 1;
```

#### RANGE FOR STATEMENT 


```{c}
for( const RenderState &child: m_children ) {
        status = minimumStatus( status, child.status() );
    }
```

#### AUTO 


```{c}
const auto &tag
```

#### AUTO 


```{c}
const auto poly = geodata_cast<GeoDataPolygon>(object)
```

#### AUTO 


```{c}
auto target = clipper.clipTo(region->latLonAltBox());
```

#### RANGE FOR STATEMENT 


```{c}
for( const RequestRegion &region: m_alternativeRouteRegions ) {
        if ( region.region.contains( e->pos() ) ) {
            m_alternativeRoutesModel->setCurrentRoute( region.index );
            return true;
        }
    }
```

#### AUTO 


```{c}
auto x = req.tile.x;
```

#### AUTO 


```{c}
auto neighbor = neighbors.front();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &coordinates: *linearRing) {
                    m_nodes << OsmConverter::Node(coordinates, osmData.nodeReference(coordinates));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( auto *plugin: d->m_dataPlugins ) {
        itemList.append( plugin->whichItemAt( curpos ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &entryInfo: tileDir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot)) {
        bool isNumber;
        int const z = entryInfo.baseName().toInt(&isNumber);
        if (isNumber && tileLevels.first <= z && z <= tileLevels.second) {
            QDirIterator tileIter(entryInfo.absoluteFilePath(), QDirIterator::Subdirectories);
            for (; tileIter.hasNext(); tileIter.next()) {
                auto tileInfo = tileIter.fileInfo();
                if (!tileInfo.isFile() || tileInfo.completeSuffix() != extension) {
                    continue;
                }

                QString const tileId = tileInfo.absoluteFilePath().mid(strip);
                QStringList const tileEntries = tileId.split(QLatin1Char('/'));
                if (tileEntries.size() == 3) {
                    int const x = tileEntries[1].toInt(&isNumber);
                    if (isNumber && x >= 0) {
                        int const y = tileInfo.baseName().toInt(&isNumber);
                        if (isNumber && y >= 0) {
                            tileWriter.addTile(tileInfo, x, y, z);
                        }
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractWeatherService *service: m_services ) {
            service->setFavoriteItems( list );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QFileInfo& info: dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst)) {
            if (info.isDir()) {
                result = deleteTheme(info.absoluteFilePath());
            } else {
                result = QFile::remove(info.absoluteFilePath());
            }
 
            if (!result) {
                return result;
            }
        }
```

#### AUTO 


```{c}
auto it = osmData.relationReferencesBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for( SatellitesConfigAbstractItem *item: m_children ) {
            if ( item->data( column, Qt::CheckStateRole ).toInt() != Qt::Unchecked ) {
                list.append( item->data( column, role).toStringList() );
            }
        }
```

#### AUTO 


```{c}
const auto tag = OsmPresetLibrary::OsmTag(iter.key(), iter.value());
```

#### RANGE FOR STATEMENT 


```{c}
for( SoundTrack* track: d->m_soundTracks) {
        track->pause();
    }
```

#### AUTO 


```{c}
const auto end = placemark.osmData().nodeReferencesEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for( ReverseGeocodingTask* task: d->m_reverseTasks ) {
        QThreadPool::globalInstance()->start( task );
    }
```

#### AUTO 


```{c}
auto item = *iter;
```

#### RANGE FOR STATEMENT 


```{c}
for( const auto& renderPosition: renderPositions ) {
        QList<LayerInterface*> layers;

        // collect all RenderPlugins of current renderPosition
        for( auto *renderPlugin: d->m_renderPlugins ) {
            if ( renderPlugin && renderPlugin->renderPosition().contains( renderPosition ) ) {
                if ( renderPlugin->enabled() && renderPlugin->visible() ) {
                    if ( !renderPlugin->isInitialized() ) {
                        renderPlugin->initialize();
                        emit renderPluginInitialized( renderPlugin );
                    }
                    layers.push_back( renderPlugin );
                }
            }
        }

        // collect all internal LayerInterfaces of current renderPosition
        for( auto *layer: d->m_internalLayers ) {
            if ( layer && layer->renderPosition().contains( renderPosition ) ) {
                layers.push_back( layer );
            }
        }

        // sort them according to their zValue()s
        std::sort( layers.begin(), layers.end(), [] ( const LayerInterface * const one, const LayerInterface * const two ) -> bool {
            Q_ASSERT( one && two );
            return one->zValue() < two->zValue();
        } );

        // render the layers of the current renderPosition
        QElapsedTimer timer;
        for( auto *layer: layers ) {
            timer.start();
            layer->render( painter, viewport, renderPosition, nullptr );
            d->m_renderState.addChild( layer->renderState() );
            traceList.append( QString("%2 ms %3").arg( timer.elapsed(),3 ).arg( layer->runtimeTrace() ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFeature *feature: d->m_treeModel.rootDocument()->featureList()) {
        if (auto document = geodata_cast<GeoDataDocument>(feature)) {
            if( document->property() == property ){
                document->setVisible( value );
                d->m_treeModel.updateFeature( document );
            }
        }
    }
```

#### AUTO 


```{c}
auto tagIter = osmData.findTag(QStringLiteral("addr:housename"));
```

#### AUTO 


```{c}
const auto building = geodata_cast<GeoDataBuilding>(placemark->geometry());
```

#### AUTO 


```{c}
const auto tag = OsmPresetLibrary::OsmTag(key, value);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tag: tagsList) {
                bool contains;
                if (tag.second == QLatin1String("*")) {
                    contains = osmData.containsTagKey(tag.first);
                } else {
                    contains = osmData.containsTag(tag.first, tag.second);
                }
                if (contains) {
                    acceptPlacemark = true;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto const mapTile = mapTiles.tileFor(zoomLevel, tileId.x(), tileId.y());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto relation: allRelations) {
            if (relation->containsAnyOf(placemarkIds)) {
                relevantRelations << relation;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &fileName: fileNames ) {
        m_controlView->marbleModel()->addGeoDataFile( fileName );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
        if (feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType) {
            GeoDataPlacemark* placemark = static_cast<GeoDataPlacemark*>(feature);
            // Select zoom level such that the placemark fits in a single tile
            int zoomLevel;
            qreal north, south, east, west;
            placemark->geometry()->latLonAltBox().boundaries(north, south, east, west);
            for (zoomLevel = maxZoomLevel; zoomLevel >= 0; --zoomLevel) {
                if (TileId::fromCoordinates(GeoDataCoordinates(west, north), zoomLevel) ==
                        TileId::fromCoordinates(GeoDataCoordinates(east, south), zoomLevel)) {
                    break;
                }
            }
            TileId const key = TileId::fromCoordinates(GeoDataCoordinates(west, north), zoomLevel);
            m_items[key] << placemark;
        } else if (feature->nodeType() == GeoDataTypes::GeoDataRelationType) {
            m_relations << static_cast<GeoDataRelation*>(feature);
        } else {
            Q_ASSERT(false && "only placemark variants are supported so far");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: document->placemarkList() ) {
        if ( !blacklist.contains( placemark->name() ) ) {
            hasInstructions = true;

            if (placemark->extendedData().contains(QStringLiteral("turnType"))) {
                return 1.0;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Polygon &a, const Polygon &b) { return a.second.id() < b.second.id(); }
```

#### AUTO 


```{c}
auto const &tag
```

#### RANGE FOR STATEMENT 


```{c}
for( Writer * writer: m_writers ) {
            Q_ASSERT( !placemark.name().isEmpty() );
            writer->addOsmPlacemark( placemark );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto zoomLevel: zoomLevels) {
            TileIterator iter(world, zoomLevel);
            qint64 count = 0;
            qint64 const total = iter.total();
            for(auto const &tileId: iter) {
                ++count;
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles && QFileInfo(filename).exists()) {
                    continue;
                }
                GeoDataDocument* tile = processor.clipTo(zoomLevel, tileId.x(), tileId.y());
                if (!tile->isEmpty()) {
                    NodeReducer nodeReducer(tile, TileId(0, zoomLevel, tileId.x(), tileId.y()));
                    if (!writeTile(tile, filename)) {
                        return 4;
                    }
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Tile " << count << "/" << total << " (" << tile->name().toStdString() << ") done.";
                    double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                    std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Skipping empty tile " << count << "/" << total << " (" << tile->name().toStdString() << ").";
                }
                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
                delete tile;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Node & node: m_nodes ) {
        if ( node.save ) {
            OsmPlacemark placemark = node;
            GeoDataCoordinates position( node.lon, node.lat, 0.0, GeoDataCoordinates::Degree );
            placemark.setRegionId( regionTree.smallestRegionId( position ) );

            if ( !node.name.isEmpty() ) {
                placemark.setHouseNumber( QString() );
                m_placemarks.push_back( placemark );
            }

            if ( !node.street.isEmpty() && node.name != node.street ) {
                placemark.setCategory( OsmPlacemark::Address );
                placemark.setName( node.street.trimmed() );
                placemark.setHouseNumber( node.houseNumber.trimmed() );
                m_placemarks.push_back( placemark );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *textureLayer: textureLayers ) {
        if (textureLayer->tileLevels().isEmpty() || textureLayer->tileLevels().contains(id.zoomLevel())) {
            if ( TileLoader::tileStatus( textureLayer, id ) != TileLoader::Available || usage == DownloadBrowse ) {
                d->m_tileLoader->downloadTile( textureLayer, id, usage );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto lineString: lineStrings) {
            if (canMerge(result.first(), lineString->first())) {
                result.remove(0);
                result.reverse();
                result << *lineString;
                lineStrings.removeOne(lineString);
                matched = true;
                break;
            } else if (canMerge(result.last(), lineString->first())) {
                result.remove(result.size()-1);
                result << *lineString;
                lineStrings.removeOne(lineString);
                matched = true;
                break;
            } else if (canMerge(result.first(), lineString->last())) {
                GeoDataLineString behind = result;
                result = *lineString;
                behind.remove(0);
                result << behind;
                lineStrings.removeOne(lineString);
                matched = true;
                break;
            } else if (canMerge(result.last(), lineString->last())) {
                GeoDataLineString behind = *lineString;
                behind.reverse();
                behind.remove(0);
                result << behind;
                lineStrings.removeOne(lineString);
                matched = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFeature *child: container->featureList() ) {
            if ( child->parent() != container ) {
                qWarning() << "Parenting mismatch for " << child->name();
                Q_ASSERT( 0 );
            }
        }
```

#### AUTO 


```{c}
auto const fields = network.split(':', QString::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& symbol: m_degreeLocale) {
        m_degreeExp += QLatin1Char('|') + QRegularExpression::escape(symbol);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RenderPlugin * plugin: plugins) {
            if (plugin->nameId() == QLatin1String("positionMarker")) {
                return plugin->visible();
            }
        }
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataPlacemark>(feature)
```

#### RANGE FOR STATEMENT 


```{c}
for( auto *layer: layers ) {
            timer.start();
            layer->render( painter, viewport, renderPosition, nullptr );
            d->m_renderState.addChild( layer->renderState() );
            traceList.append( QString("%2 ms %3").arg( timer.elapsed(),3 ).arg( layer->runtimeTrace() ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataTourPrimitive* m_primitive: m_primitives ){
            if (*m_primitive != *other.m_primitives.at(index)) {
                return false;
            }

            index++;
        }
```

#### AUTO 


```{c}
const auto document = geodata_cast<GeoDataDocument>(object);
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(feature);
```

#### AUTO 


```{c}
auto const &placemark
```

#### RANGE FOR STATEMENT 


```{c}
for (auto polygon: m_cachedInnerRoofPolygons) {
                if (polygon->containsPoint(point, Qt::OddEvenFill)) {
                    return false;
                }
            }
```

#### AUTO 


```{c}
auto const floatItems = MarbleInputHandler::d->m_marblePresenter->map()->floatItems();
```

#### AUTO 


```{c}
const auto additionalOsmTag
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataSimpleField &simpleField: schema->simpleFields() ) {
        writeElement( &simpleField, writer );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString& key: pluginGroup.keyList() ) {
                    if (key != QLatin1String("Enabled")) {
                        profile.pluginSettings()[ pluginName ].insert( key, pluginGroup.readEntry( key ) );
                    }
                }
```

#### AUTO 


```{c}
const auto tourControl = geodata_cast<GeoDataTourControl>(primitive)
```

#### RANGE FOR STATEMENT 


```{c}
for(auto wayId: roleMembers) {
        GeoDataLinearRing ring;
        OsmWay const & way = ways[wayId];
        if (way.references().isEmpty()) {
            continue;
        }
        if (way.references().first() != way.references().last()) {
            unclosedWays.append(way);
            continue;
        }
        for(auto id: way.references()) {
            if (!nodes.contains(id)) {
                // A node is missing. Return nothing.
                return OsmRings();
            }
            ring << nodes[id].coordinates();
        }
        Q_ASSERT(ways.contains(wayId));
        currentWays << wayId;
        result << OsmRing(GeoDataLinearRing(ring.optimized()), way.osmData());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( RenderPlugin *plugin: d->m_renderPlugins ) {
        plugin->applyItemState();
    }
```

#### AUTO 


```{c}
auto tileIter = d->m_features.find(placemark);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const AxisTick &tick: m_axisY.ticks() ) {
        const int posY = m_eleGraphHeight - tick.position;
        painter->setPen( dashedPen );
        painter->drawLine( m_leftGraphMargin, posY, contentSize().width(), posY );

        labelRect.moveCenter( QPoint( labelRect.center().x(), posY ) );
        if ( labelRect.top() < 0 ) {
            // don't cut off uppermost label
            labelRect.moveTop( 0 );
        }
        if ( labelRect.bottom() >= lastStringEnds ) {
            // Don't print overlapping labels
            continue;
        }
        lastStringEnds = labelRect.top();
        painter->setPen( QColor( Qt::black ) );
        intervalStr.setNum( tick.value * m_axisY.scale() );
        painter->drawText( labelRect, Qt::AlignRight, intervalStr );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( RenderPlugin * plugin: plugins ) {
            if (plugin->nameId() == QLatin1String("positionMarker")) {
                plugin->setVisible(showPositionMarker);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark* placemark: document->placemarkList()) {
        GeoDataGeometry const * const geometry = placemark->geometry();
        auto const visualCategory = placemark->visualCategory();
        if (const auto prevLine = geodata_cast<GeoDataLineString>(geometry)) {
            GeoDataLineString* reducedLine = new GeoDataLineString;
            reduce(*prevLine, placemark->osmData(), visualCategory, reducedLine);
            placemark->setGeometry(reducedLine);
        } else if (m_zoomLevel < 17) {
            if (const auto prevRing = geodata_cast<GeoDataLinearRing>(geometry)) {
                GeoDataLinearRing* reducedRing = new GeoDataLinearRing;
                reduce(*prevRing, placemark->osmData(), visualCategory, reducedRing);
                placemark->setGeometry(reducedRing);
            } else if (const auto prevPolygon = geodata_cast<GeoDataPolygon>(geometry)) {
                GeoDataPolygon* reducedPolygon = new GeoDataPolygon;
                GeoDataLinearRing const * prevRing = &(prevPolygon->outerBoundary());
                GeoDataLinearRing reducedRing;
                reduce(*prevRing, placemark->osmData().memberReference(-1), visualCategory, &reducedRing);
                reducedPolygon->setOuterBoundary(reducedRing);
                QVector<GeoDataLinearRing> const & innerBoundaries = prevPolygon->innerBoundaries();
                for(int i = 0; i < innerBoundaries.size(); i++) {
                    prevRing = &innerBoundaries[i];
                    GeoDataLinearRing reducedInnerRing;
                    reduce(*prevRing, placemark->osmData().memberReference(i), visualCategory, &reducedInnerRing);
                    reducedPolygon->appendInnerBoundary(reducedInnerRing);
                }
                placemark->setGeometry(reducedPolygon);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &application: applications ) {
        for( const QString &dir: path.split( QLatin1Char( ':' ) ) ) {
            QFileInfo executable( QDir( dir ), application );
            if ( executable.exists() ) {
                return true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
                if (const auto relation = geodata_cast<GeoDataRelation>(feature)) {
                    if (relevantRelations.contains(relation) &&
                            relation->osmData().containsTag(QStringLiteral("type"), QStringLiteral("public_transport")) &&
                            relation->osmData().containsTag(QStringLiteral("public_transport"), QStringLiteral("stop_area"))) {
                        for (auto iter = relation->osmData().relationReferencesBegin(), end = relation->osmData().relationReferencesEnd();
                             iter != end; ++iter) {
                            if (iter.value() == QStringLiteral("stop") || iter.value() == QStringLiteral("platform")) {
                                placemarkIds << iter.key().id;
                            }
                        }
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const Coordinate &a, const Coordinate &b) { return a.second.id() < b.second.id(); }
```

#### AUTO 


```{c}
auto const a = x0*y1 - x1*y0;
```

#### RANGE FOR STATEMENT 


```{c}
for( const QSize& buttonSize: elementSize ) {
        if( buttonSize.height() > size.height() )
            size.setHeight( buttonSize.height() );
        size.setWidth( size.width() + buttonSize.width() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto zoomLevel: zoomLevels) {
            TileIterator iter(world, zoomLevel);
            qint64 count = 0;
            qint64 const total = iter.total();
            for(auto const &tileId: iter) {
                ++count;
                QString const filename = tileFileName(parser, tileId.x(), tileId.y(), zoomLevel);
                if (!overwriteTiles && QFileInfo(filename).exists()) {
                    continue;
                }
                GeoDataDocument* tile = processor.clipTo(zoomLevel, tileId.x(), tileId.y());
                if (tile->size() > 0) {
                    NodeReducer nodeReducer(tile, TileId(0, zoomLevel, tileId.x(), tileId.y()));
                    if (!writeTile(tile, filename)) {
                        return 4;
                    }
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Tile " << count << "/" << total << " (" << tile->name().toStdString() << ") done.";
                    double const reduction = nodeReducer.removedNodes() / qMax(1.0, double(nodeReducer.remainingNodes() + nodeReducer.removedNodes()));
                    std::cout << " Node reduction: " << qRound(reduction * 100.0) << "%";
                } else {
                    TileDirectory::printProgress(count / double(total));
                    std::cout << " Skipping empty tile " << count << "/" << total << " (" << tile->name().toStdString() << ").";
                }
                std::cout << std::string(20, ' ') << '\r';
                std::cout.flush();
                delete tile;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RenderPlugin *factory: m_model->pluginManager()->renderPlugins()) {
        bool alreadyCreated = false;
        for(const RenderPlugin *existing: m_renderPlugins) {
            if (existing->nameId() == factory->nameId()) {
                alreadyCreated = true;
                break;
            }
        }

        if (alreadyCreated) {
            continue;
        }

        RenderPlugin *const renderPlugin = factory->newInstance(m_model);
        Q_ASSERT(renderPlugin && "Plugin must not return null when requesting a new instance.");
        m_renderPlugins << renderPlugin;

        if (AbstractFloatItem *const floatItem = qobject_cast<AbstractFloatItem *>(renderPlugin)) {
            m_floatItemsLayer.addFloatItem(floatItem);
        }
        else {
            m_layerManager.addRenderPlugin(renderPlugin);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &innerRing: inner) {
            if (innerRing.first.isEmpty() || !outerRing.first.contains(innerRing.first.first())) {
                // Simple check to see if this inner ring is inside the outer ring
                continue;
            }

            if (StyleBuilder::determineVisualCategory(innerRing.second) == GeoDataPlacemark::None) {
                // Schedule way for removal: It's a non-styled way only used to create the inner boundary in this polygon
                usedWays << innerRing.second.id();
            }
            polygon->appendInnerBoundary(innerRing.first);
            osmData.addMemberReference(index, innerRing.second);
            ++index;
        }
```

#### AUTO 


```{c}
auto iter = hash.begin(), end = hash.end();
```

#### RANGE FOR STATEMENT 


```{c}
for(GeoGraphicsItem *object: d->m_tiledItems.value( tileId )) {
                    if (object->minZoomLevel() <= zoomLevel && object->visible()) {
                        if (!isBorder || object->latLonAltBox().intersects(box)) {
                            result.push_back(object);
                        }
                    }
                }
```

#### AUTO 


```{c}
auto relation
```

#### AUTO 


```{c}
auto const & layerItem = layerItems[j];
```

#### AUTO 


```{c}
auto iter = clickedItems.find(placemark);
```

#### AUTO 


```{c}
auto const tileZoomLevel = q->tileZoomLevel();
```

#### RANGE FOR STATEMENT 


```{c}
for( QPolygonF* fillPolygon: fillPolygons ) {
                painter->drawPolygon(*fillPolygon);
            }
```

#### AUTO 


```{c}
auto const end = lineString->end() - 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark* placemark: doc->placemarkList()) {
                if (GeoDataPolygon *polygon = geodata_cast<GeoDataPolygon>(placemark->geometry())) {
                    polygon->setRenderOrder(m_renderOrder);
                }
            }
```

#### AUTO 


```{c}
auto const endId = osmData.nodeReference(lineString.last()).id();
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: folder->placemarkList() ) {
            const GeoDataGeometry* geometry = placemark->geometry();
            const GeoDataLineString* lineString = dynamic_cast<const GeoDataLineString*>( geometry );
            if ( lineString ) {
                return lineString;
            }
        }
```

#### AUTO 


```{c}
const auto &entry
```

#### AUTO 


```{c}
auto itemStyle = style();
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataLinearRing &innerBoundary: innerBoundaries) {
        QVector<QPolygonF*> innerPolygonsPerBoundary;
        viewport.screenCoordinates(innerBoundary, innerPolygonsPerBoundary);

        innerPolygons.reserve(innerPolygons.size() + innerPolygonsPerBoundary.size());
        for( QPolygonF* innerPolygonPerBoundary: innerPolygonsPerBoundary ) {
            innerPolygons << innerPolygonPerBoundary;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ParseRunnerPlugin *plugin: pluginManager->parsingRunnerPlugins() ) {
        if (plugin->nameId() == QLatin1String("Cache"))
            continue;

        const QStringList fileExtensions = plugin->fileExtensions().replaceInStrings( QRegExp( "^" ), "*." );
        const QString filter = plugin->fileFormatDescription() + QLatin1String(" (") + fileExtensions.join(QLatin1Char(' ')) + QLatin1Char(')');
        filters << filter;
        allFileExtensions << fileExtensions;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF & clippedPolyObject: clippedPolyObjects ) { 
            if (d->m_debugPolygonsLevel) {
                QPen pen = QPainter::pen();
                QPen originalPen = pen;
                QColor color = pen.color();
                color.setAlpha(color.alpha()*0.75);
                pen.setColor(color);
                QPainter::setPen(pen);

                QPainter::drawPolyline ( clippedPolyObject );

                QPainter::setPen(originalPen);

                d->debugDrawNodes( clippedPolyObject );
            }
            else {
                QPainter::drawPolyline ( clippedPolyObject );
            }
        }
```

#### AUTO 


```{c}
auto wayId
```

#### AUTO 


```{c}
auto const x1 = polygon[j].x();
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoDataFeature *feature: document->featureList() ) {

        if ( feature->nodeType() == GeoDataTypes::GeoDataPlacemarkType ) {
            GeoDataPlacemark *placemark = static_cast<GeoDataPlacemark*>( feature );
            GeoDataPlacemark *newPlacemark = new GeoDataPlacemark( *placemark );

            if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPointType ) {
                PlacemarkTextAnnotation *placemark = new PlacemarkTextAnnotation( newPlacemark );
                m_graphicsItems.append( placemark );
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataPolygonType ) {
                newPlacemark->setParent( m_annotationDocument );
                if ( !placemark->styleUrl().isEmpty() ) {
                    newPlacemark->setStyleUrl( placemark->styleUrl() );
                }
                AreaAnnotation *polygonAnnotation = new AreaAnnotation( newPlacemark );
                m_graphicsItems.append( polygonAnnotation );
            } else if ( placemark->geometry()->nodeType() == GeoDataTypes::GeoDataLineStringType ) {
                newPlacemark->setParent( m_annotationDocument );
                if ( !placemark->styleUrl().isEmpty() ) {
                    newPlacemark->setStyleUrl( placemark->styleUrl() );
                }
                PolylineAnnotation *polylineAnnotation = new PolylineAnnotation( newPlacemark );
                m_graphicsItems.append( polylineAnnotation );
            }
            m_marbleWidget->model()->treeModel()->addFeature( m_annotationDocument, newPlacemark );
        } else if ( feature->nodeType() == GeoDataTypes::GeoDataGroundOverlayType ) {
            GeoDataGroundOverlay *overlay = static_cast<GeoDataGroundOverlay*>( feature );
            GeoDataGroundOverlay *newOverlay = new GeoDataGroundOverlay( *overlay );
            m_marbleWidget->model()->treeModel()->addFeature( m_annotationDocument, newOverlay );
            displayOverlayFrame( newOverlay );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto mapper : d->m_activeTileModels) {
        mapper->reload();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const & tag: StyleBuilder::buildingTags()) {
            s_areaTags.insert(tag);
        }
```

#### AUTO 


```{c}
auto const ref = relation->osmData().tagValue(QStringLiteral("ref"));
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoSceneLayer *layer: d->m_mapTheme->map()->layers() ) {
            if ( layer->backend() != dgml::dgmlValue_geodata
                 && layer->backend() != dgml::dgmlValue_vector )
                continue;

            // look for documents
            for ( GeoSceneAbstractDataset *dataset: layer->datasets() ) {
                GeoSceneGeodata *data = dynamic_cast<GeoSceneGeodata*>( dataset );
                Q_ASSERT( data );
                currentDatasets << *data;
            }
        }
```

#### AUTO 


```{c}
auto placemark = geodata_cast<GeoDataPlacemark>(*i)
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &application: applications ) {
        m_installedEditors[application] = false;
        /** @todo: what's the qt way to get the path entry separator? Will be a semicolon on Windows */
        for( const QString &dir: path.split( QLatin1Char( ':' ) ) ) {
            QFileInfo executable( QDir( dir ), application );
            if ( executable.exists() ) {
                m_installedEditors[application] = true;
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto feature: document->featureList()) {
            if (const auto relation = geodata_cast<GeoDataRelation>(feature)) {
                allRelations << relation;
                if (relation->memberIds().contains(osmData.oid())) {
                    relevantRelations << relation;
                    auto const isRoute = relation->osmData().tagValue(QStringLiteral("type")) == QStringLiteral("route");
                    searchRelations &= !isRoute;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &way: converter.ways()) {
        if (way.second.id() != lastId) {
            OsmWayTagWriter::writeWay(*way.first, way.second, writer);
            lastId = way.second.id();
        }
    }
```

#### AUTO 


```{c}
const auto y = blockY * blockSize + tileY;
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& possibleOldPath: possibleOldPaths ) {
        if( !QDir().exists( possibleOldPath ) ) {
            continue;
        }

        QString canonicalPossibleOldPath = QDir( possibleOldPath ).canonicalPath();
        if( canonicalPossibleOldPath == currentLocalPath ) {
            continue;
        }

        oldPaths.append( canonicalPossibleOldPath );
    }
```

#### AUTO 


```{c}
auto const refA = d->m_osmData.tagValue(QStringLiteral("ref"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &layer: paintLayers) {
                if (knownLayers.contains(layer)) {
                    GeometryLayerPrivate::PaintFragments &fragments = paintFragments[layer];
                    double const zValue = item->zValue();
                    // assign subway stations
                    if (zValue == 0.0) {
                        fragments.null << item;
                        // assign areas and streets
                    } else if (zValue < 0.0) {
                        fragments.negative << item;
                        // assign buildings
                    } else {
                        fragments.positive << item;
                    }
                } else {
                    // assign symbols
                    d->m_cachedDefaultLayer << GeometryLayerPrivate::LayerItem(layer, item);
                    static QSet<QString> missingLayers;
                    if (!missingLayers.contains(layer)) {
                        mDebug() << "Missing layer " << layer << ", in render order, will render it on top";
                        missingLayers << layer;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPolygonF* itPolygon: m_cachedPolygons) {
            painter->drawPolyline(*itPolygon);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: m_otherPlacemarks) {
        document->append(placemark);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &entry: building()->entries()) {
            qreal x, y;
            viewport->screenCoordinates(entry.point, x, y);
            QPointF point(x, y);
            point += buildingOffset(point, viewport);
            painter->drawTextFragment(point.toPoint(),
                                     building()->name(), painter->font().pointSize(), painter->brush().color(),
                                     GeoPainter::RoundFrame);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataFeature *feature: m_vector) {
            feature->setParent(parent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &baseDir: baseDirs ) {
        const QString base = baseDir + QLatin1String("/maps/earth/placemarks/");
        addDatabaseDirectory( base );
        QDir::Filters filters = QDir::AllDirs | QDir::Readable | QDir::NoDotAndDotDot;
        QDirIterator::IteratorFlags flags = QDirIterator::Subdirectories | QDirIterator::FollowSymlinks;
        QDirIterator iter( base, filters, flags );
        while ( iter.hasNext() ) {
            iter.next();
            addDatabaseDirectory( iter.filePath() );
        }
    }
```

#### AUTO 


```{c}
const auto it = coordMap.find(std::make_pair(point.X, point.Y));
```

#### AUTO 


```{c}
const auto multitrack = geodata_cast<GeoDataMultiTrack>(object)
```

#### AUTO 


```{c}
auto const height = painter->fontMetrics().height();
```

#### AUTO 


```{c}
auto const originalOsmData = innerRingOsmData.nodeReference(coordinates);
```

#### RANGE FOR STATEMENT 


```{c}
for( const OsmPlacemark & placemark: m_placemarks ) {
        for( Writer * writer: m_writers ) {
            Q_ASSERT( !placemark.name().isEmpty() );
            writer->addOsmPlacemark( placemark );
        }
    }
```

#### AUTO 


```{c}
auto chunk = wayChunk(*placemark, firstId);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto member: relation->members()) {
                    relations[member] << relation;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key: m_renderPlanet.keys())
        planetState += key + QLatin1Char(':') + QString::number((int)m_renderPlanet[key]);
```

#### AUTO 


```{c}
auto placemark = static_cast<GeoDataPlacemark*>(extendedData->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& symbol: m_secondsLocale) {
        m_secondsExp += QLatin1Char('|') + QRegularExpression::escape(symbol);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& planet: m_planetID ) {
        if ( m_svgWidgets.contains( planet) ) {
            m_svgWidgets[planet]->load( m_svgPaths[planet] );
        } else {
            m_svgWidgets[planet] = new QSvgWidget( m_svgPaths[planet] );
        }
    }
```

#### AUTO 


```{c}
auto const helpOption = parser.addHelpOption();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &entry: m_commentsList) {
        QString const date = entry.date().toString(Qt::SystemLocaleShortDate);
        QString const user = entry.user().isEmpty() ? tr("anonymous", "The author name is not known") : entry.user();
        toolTip << QStringLiteral("%1\n--%2, %3").arg(entry.text().trimmed()).arg(user).arg(date);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: selectedPlacemarks ) {
        for (auto tileIter = d->m_features.find(placemark); tileIter != d->m_features.end(); ++tileIter) {
            auto const & clickedItems = d->m_tiledItems[*tileIter];
            auto iter = clickedItems.find(placemark);
            if (iter != clickedItems.end()) {
                GeoDataObject *parent = placemark->parent();
                if ( parent ) {
                    auto item = *iter;
                    if ( parent->nodeType() == GeoDataTypes::GeoDataDocumentType ) {
                        GeoDataDocument *doc = static_cast<GeoDataDocument*>( parent );
                        QString styleUrl = placemark->styleUrl();
                        styleUrl.remove(QLatin1Char('#'));
                        if ( !styleUrl.isEmpty() ) {
                            GeoDataStyleMap const &styleMap = doc->styleMap( styleUrl );
                            GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                            if ( style ) {
                                d->selectItem( item );
                                d->applyHighlightStyle( item, style );
                            }
                        }

                        /**
                            * If a placemark is using an inline style instead of a shared
                            * style ( e.g in case when theme file specifies the colorMap
                            * attribute ) then highlight it if any of the style maps have a
                            * highlight styleId
                            */
                        else {
                            for ( const GeoDataStyleMap &styleMap: doc->styleMaps() ) {
                                GeoDataStyle::Ptr style = d->highlightStyle( doc, styleMap );
                                if ( style ) {
                                    d->selectItem( item );
                                    d->applyHighlightStyle( item, style );
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto animatedUpdate = geodata_cast<GeoDataAnimatedUpdate>(object);
```

#### RANGE FOR STATEMENT 


```{c}
for ( AbstractDataPluginItem *item: d->m_itemSet ) {
        if( item->id() == id ) {
            return item;
        }
    }
```

#### AUTO 


```{c}
const auto lineString = geodata_cast<GeoDataLineString>(placemark->geometry())
```

#### LAMBDA EXPRESSION 


```{c}
[](QSharedPointer<LinkedPoint>& A, QSharedPointer<LinkedPoint>& B) {
                return B->point().x() < A->point().x();
            }
```

#### AUTO 


```{c}
const auto document = geodata_cast<GeoDataDocument>(parentItem)
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString & file: fileNames ) {
        files << QFileInfo(m_directory, QLatin1String("Contraction Hierarchies_") + file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPolygonF* fillPolygon: fillPolygons ) {
                painter->drawPolygon(*fillPolygon);
            }
```

#### AUTO 


```{c}
auto j = layerItems.size()-1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &layer: d->m_styleBuilder->renderOrder()) {
        auto & layerItems = d->m_cachedPaintFragments[layer];
        AbstractGeoPolygonGraphicsItem::s_previousStyle = nullptr;
        GeoLineStringGraphicsItem::s_previousStyle = nullptr;
        for (auto item: layerItems) {
            if (d->m_levelTagDebugModeEnabled) {
                if (const auto placemark = geodata_cast<GeoDataPlacemark>(item->feature())) {
                    if (placemark->hasOsmData()) {
                        QHash<QString, QString>::const_iterator tagIter = placemark->osmData().findTag(QStringLiteral("level"));
                        if (tagIter != placemark->osmData().tagsEnd()) {
                            const int val = tagIter.value().toInt();
                            if (val != d->m_debugLevelTag) {
                                continue;
                            }
                        }
                    }
                }
            }
            item->paint(painter, viewport, layer, d->m_tileLevel);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &point: positions) {
        QRectF rect( point, m_size );
        if( rect.x() < 0 )
            rect.setLeft( 0 );
        if( rect.y() < 0 )
            rect.setTop( 0 );

        list.append( rect );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const MonavStuffEntry &entry: m_remoteMaps ) {
        if ( continent == entry.continent() && state == entry.state() && region == entry.region() ) {
            return entry;
        }
    }
```

#### AUTO 


```{c}
auto tagIter = osmData.tagsBegin(), end = osmData.tagsEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const & node: nodes) {
        if (node.second.id() == lastId) {
            continue;
        }

        stream << qint8(0x10); // node section start indicator

        bufferData.clear();
        buffer.open(QIODevice::WriteOnly);
        QDataStream bufferStream(&buffer);

        OsmPlacemarkData const & osmData = node.second;
        qint64 idDiff = osmData.id() - lastId;
        writeSigned(idDiff, bufferStream);
        writeVersion(osmData, bufferStream);
        GeoDataCoordinates const & coordinates = node.first;
        double const lon = coordinates.longitude(GeoDataCoordinates::Degree);
        double const lat = coordinates.latitude(GeoDataCoordinates::Degree);
        writeSigned(deltaTo(lon, lastLon), bufferStream);
        writeSigned(deltaTo(lat, lastLat), bufferStream);
        writeTags(osmData, stringTable, bufferStream);

        buffer.close();
        writeUnsigned(bufferData.size(), stream);
        stream.writeRawData(bufferData.constData(), bufferData.size());

        lastId = osmData.id();
        lastLon = lon;
        lastLat = lat;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: outdated) {
                delete m_visiblePlacemarks.take(placemark->placemark());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction *action: tmp_actionGroups->first()->actions() ) {
            if (action->objectName() == QLatin1String("toolbarSeparator")) {
                firstToolbarFilled = true;
            } else {
                if( !firstToolbarFilled ) {
                    firstToolbar->addAction( action );
                } else {
                    secondToolbar->addAction( action );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPointF& absolutePosition: absolutePositions ) {
            QPoint shiftedPos = event->pos() - absolutePosition.toPoint();
            
            if ( QRect( QPoint( 0, 0 ), size().toSize() ).contains( shiftedPos ) ) {
                for (MarbleGraphicsItem *child: d->m_children) {
                    const QVector<QRectF> childRects = child->d_func()->boundingRects();
                    
                    for( const QRectF& childRect: childRects ) {
                        if( childRect.toRect().contains( shiftedPos ) ) {
                            if( child->eventFilter( object, e ) ) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataPlacemark* newPlacemark: newFolder->placemarkList() ) {
            bool added = skipAll;

            GeoDataCoordinates newCoordinate = newPlacemark->coordinate();
            GeoDataPlacemark *existingPlacemark = m_manager->bookmarkAt( m_manager->document(), newCoordinate );
            if ( existingPlacemark ) {
                if ( skipAll ) {
                    continue;
                }

                // Avoid message boxes for equal bookmarks, just skip them
                if ( existingPlacemark->name() == newPlacemark->name() &&
                    existingPlacemark->description() == newPlacemark->description() ) {
                    continue;
                }

                QPointer<QMessageBox> messageBox = new QMessageBox( m_parent );
                QString const intro = tr( "The file contains a bookmark that already exists among your Bookmarks." );
                QString const newBookmark = tr( "Imported bookmark" );
                QString const existingBookmark = tr( "Existing bookmark" );
                QString const question = tr( "Do you want to replace the existing bookmark with the imported one?" );
                QString html = QLatin1String("<p>%1</p><table><tr><td>%2</td><td><b>%3 / %4</b></td></tr>"
                                                "<tr><td>%5</td><td><b>%6 / %7</b></td></tr></table><p>%8</p>");
                html = html.arg( intro, existingBookmark, existingFolder->name(),
                                 existingPlacemark->name(), newBookmark, newFolder->name(),
                                 newPlacemark->name(), question );
                messageBox->setText( html );

                QAbstractButton *replaceButton    = messageBox->addButton(tr( "Replace" ),     QMessageBox::ActionRole );
                QAbstractButton *replaceAllButton = messageBox->addButton(tr( "Replace All" ), QMessageBox::ActionRole );
                QAbstractButton *skipButton       = messageBox->addButton(tr( "Skip" ),        QMessageBox::ActionRole );
                QAbstractButton *skipAllButton    = messageBox->addButton(tr( "Skip All" ),    QMessageBox::ActionRole );
                                                    messageBox->addButton( QMessageBox::Cancel );
                messageBox->setIcon( QMessageBox::Question );

                if ( !replaceAll ) {
                    messageBox->exec();
                }
                if ( messageBox->clickedButton() == replaceAllButton ) {
                    replaceAll = true;
                } else if ( messageBox->clickedButton() == skipAllButton ) {
                    skipAll = true;
                    added = true;
                } else if ( messageBox->clickedButton() == skipButton ) {
                    delete messageBox;
                    continue;
                } else if ( messageBox->clickedButton() != replaceButton ) {
                    delete messageBox;
                    return;
                }

                if ( messageBox->clickedButton() == replaceButton || replaceAll ) {
                    m_manager->removeBookmark( existingPlacemark );
                    m_manager->addBookmark( existingFolder, *newPlacemark );

                    mDebug() << "Placemark " << newPlacemark->name() << " replaces " << existingPlacemark->name();
                    delete messageBox;
                    break;
                }
                delete messageBox;
            }

            if ( !added ) {
                m_manager->addBookmark( existingFolder, *newPlacemark );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const WeatherData& data: forecasts ) {
        QDate date = data.dataDate();
        WeatherData other = d->m_forecastWeather.value( date );
        if ( !other.isValid() ) {
            d->m_forecastWeather.insert( date, data );
        }
        else if ( other.publishingTime() < data.publishingTime() ) {
            d->m_forecastWeather.remove( date );
            d->m_forecastWeather.insert( date, data );
        }
    }
```

#### AUTO 


```{c}
auto lineStringItem = new GeoLineStringGraphicsItem(placemark, line);
```

#### AUTO 


```{c}
auto const originalOsmData = osmData.nodeReference(coordinates);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tile : m_documents.keys()) {
        m_loader->downloadTile(m_layer, tile, DownloadBrowse);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AnimatedUpdateTrack* track: d->m_animatedUpdateTracks ){
        track->seek( offset );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: parser.positionalArguments() ) {
        // FIXME: Use openUrl( args->url(i) ) instead?
        if ( QFile::exists( file ) ) {
            window->marbleControl()->addGeoDataFile(file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(VisiblePlacemark* mark: m_paintOrder) {
        if (mark->labelRect().contains(pos) || mark->symbolRect().contains(pos)) {
            m_lastPlacemarkAt = mark;
            return true;
        }
    }
```

#### AUTO 


```{c}
auto peak
```

#### AUTO 


```{c}
auto iconStyle = style->iconStyle();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneTextureTileDataset *textureLayer: textureLayers ) {
        if ( TileLoader::tileStatus( textureLayer, id ) != TileLoader::Available || usage == DownloadBrowse ) {
            d->m_tileLoader->downloadTile( textureLayer, id, usage );
        }
    }
```

#### AUTO 


```{c}
auto pair = QPair<QString, GeoWriterBackend*>(fileExtension, writer);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &file: files ) {
        m_databaseFiles << directory.filePath( file );
    }
```

#### AUTO 


```{c}
auto folder = geodata_cast<GeoDataFolder>(object)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto obj : staticPlugins) {
        if (addPlugin(obj, nullptr)) {
            foundPlugin = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( GeoDataFolder *newFolder: source->folderList() ) {
        GeoDataFolder *existingFolder = m_manager->addNewBookmarkFolder(destination, newFolder->name());
        importBookmarksRecursively(newFolder, existingFolder, skipAll, replaceAll);
        for( GeoDataPlacemark* newPlacemark: newFolder->placemarkList() ) {
            bool added = skipAll;

            GeoDataCoordinates newCoordinate = newPlacemark->coordinate();
            GeoDataPlacemark *existingPlacemark = m_manager->bookmarkAt( m_manager->document(), newCoordinate );
            if ( existingPlacemark ) {
                if ( skipAll ) {
                    continue;
                }

                // Avoid message boxes for equal bookmarks, just skip them
                if ( existingPlacemark->name() == newPlacemark->name() &&
                    existingPlacemark->description() == newPlacemark->description() ) {
                    added = true;
                    continue;
                }

                QPointer<QMessageBox> messageBox = new QMessageBox( m_parent );
                QString const intro = tr( "The file contains a bookmark that already exists among your Bookmarks." );
                QString const newBookmark = tr( "Imported bookmark" );
                QString const existingBookmark = tr( "Existing bookmark" );
                QString const question = tr( "Do you want to replace the existing bookmark with the imported one?" );
                QString html = QLatin1String("<p>%1</p><table><tr><td>%2</td><td><b>%3 / %4</b></td></tr>"
                                                "<tr><td>%5</td><td><b>%6 / %7</b></td></tr></table><p>%8</p>");
                html = html.arg( intro ).arg( existingBookmark ).arg( existingFolder->name() );
                html = html.arg( existingPlacemark->name() ).arg( newBookmark ).arg( newFolder->name() );
                html = html.arg( newPlacemark->name() ).arg( question );
                messageBox->setText( html );

                QAbstractButton *replaceButton    = messageBox->addButton(tr( "Replace" ),     QMessageBox::ActionRole );
                QAbstractButton *replaceAllButton = messageBox->addButton(tr( "Replace All" ), QMessageBox::ActionRole );
                QAbstractButton *skipButton       = messageBox->addButton(tr( "Skip" ),        QMessageBox::ActionRole );
                QAbstractButton *skipAllButton    = messageBox->addButton(tr( "Skip All" ),    QMessageBox::ActionRole );
                                                    messageBox->addButton( QMessageBox::Cancel );
                messageBox->setIcon( QMessageBox::Question );

                if ( !replaceAll ) {
                    messageBox->exec();
                }
                if ( messageBox->clickedButton() == replaceAllButton ) {
                    replaceAll = true;
                } else if ( messageBox->clickedButton() == skipAllButton ) {
                    skipAll = true;
                    added = true;
                } else if ( messageBox->clickedButton() == skipButton ) {
                    added = true;
                    delete messageBox;
                    continue;
                } else if ( messageBox->clickedButton() != replaceButton ) {
                    delete messageBox;
                    return;
                }

                if ( messageBox->clickedButton() == replaceButton || replaceAll ) {
                    m_manager->removeBookmark( existingPlacemark );
                    m_manager->addBookmark( existingFolder, *newPlacemark );

                    mDebug() << "Placemark " << newPlacemark->name() << " replaces " << existingPlacemark->name();
                    added = true;
                    delete messageBox;
                    break;
                }
                delete messageBox;
            }

            if ( !added ) {
                m_manager->addBookmark( existingFolder, *newPlacemark );
            }
        }
    }
```

#### AUTO 


```{c}
auto const & n = normals[i];
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark const * placemark: potentialIntersections(tileBoundary)) {
        GeoDataGeometry const * const geometry = placemark ? placemark->geometry() : nullptr;
        if (geometry && tileBoundary.intersects(geometry->latLonAltBox())) {
            if(geometry->nodeType() == GeoDataTypes::GeoDataPolygonType) {
                clipPolygon(placemark, clip, minArea, tile, osmIds);
            } else if (geometry->nodeType() == GeoDataTypes::GeoDataLineStringType) {
                clipString<GeoDataLineString>(placemark, clip, minArea, tile, osmIds);
            } else if (geometry->nodeType() == GeoDataTypes::GeoDataLinearRingType) {
                clipString<GeoDataLinearRing>(placemark, clip, minArea, tile, osmIds);
            } else {
                tile->append(placemark->clone());
                osmIds << placemark->osmData().id();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const MovieFormat &format: formats) {
        if (destination.endsWith(QLatin1Char('.') + format.extension())) {
            supported = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto popularity: popularities) {
            m_popularities[popularity] = value;
            value -= offset;
        }
```

#### AUTO 


```{c}
auto map = TileDirectory::open(inputFileName, manager);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto& intersection : intersections) {
                if(intersection->isEntering() && !intersection->isProcessed()) {
                    iterateBasePolygon = true;

                    QSharedPointer<LinkedPoint> it = intersection;
                    clippedPolyObject << it->point();
                    it->setProcessed(true);

                    do {
                        if(iterateBasePolygon) {
                            it = it->nextBasePolygonPoint();
                            if(it->isLeaving()) {
                                iterateBasePolygon = false;
                                it->setProcessed(true);
                            } else if(it->isEntering()) {
                                it->setProcessed(true);
                            }
                        }  else {
                            it = it->nextClipPolygonPoint();
                            if(it->isEntering()) {
                                iterateBasePolygon = true;
                                it->setProcessed(true);
                            } else if(it->isLeaving()) {
                                it->setProcessed(true);
                            }
                        }
                        clippedPolyObject << it->point();
                        Q_ASSERT(clippedPolyObject.size() <= 20 * basePolygon.size());

                        //                        // To avoid crashes because of infinite loop.
                        //                        // Needs to be investigated
                        //                        if(clippedPolyObject.size() > basePolygon.size()) {
                        //                            qDebug() << "Something went wrong, exiting current clipping loop...";
                        //                            break;
                        //                        }

                    } while(clippedPolyObject.first() != clippedPolyObject.last());

                    clippedPolyObjects << clippedPolyObject;
                    clippedPolyObject = QPolygonF();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& key: queryStrings.keys()){
		urlQuery.addQueryItem(key, queryStrings.value(key));
	}
```

#### AUTO 


```{c}
const auto value = data.constData() + midIdx + 1;
```

#### AUTO 


```{c}
auto const tile = TileId(0, zoomLevel, tileId.x(), tileId.y());
```

#### LAMBDA EXPRESSION 


```{c}
[](const GeoGraphicsItem* a, const GeoGraphicsItem* b) {
            return a->zValue() < b->zValue();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const GeoSceneAbstractDataset *pos: layer->datasets() ) {
                    const GeoSceneVectorTileDataset *const vectorTile = dynamic_cast<GeoSceneVectorTileDataset const *>( pos );
                    if ( !vectorTile )
                        continue;

                    const QString sourceDir = vectorTile->sourceDir();
                    const QString installMap = vectorTile->installMap();
                    const QString role = layer->role();

                    // If the tiles aren't already there, put up a progress dialog
                    // while creating them.
                    if ( !TileLoader::baseTilesAvailable( *vectorTile )
                         && !installMap.isEmpty() )
                    {
                        mDebug() << "Base tiles not available. Creating Tiles ... \n"
                                 << "SourceDir: " << sourceDir << "InstallMap:" << installMap;

                        TileCreator *tileCreator = new TileCreator(
                                    sourceDir,
                                    installMap,
                                    (role == QLatin1String("dem")) ? "true" : "false" );
                        tileCreator->setTileFormat( vectorTile->fileFormat().toLower() );

                        QPointer<TileCreatorDialog> tileCreatorDlg = new TileCreatorDialog( tileCreator, 0 );
                        tileCreatorDlg->setSummary( m_model->mapTheme()->head()->name(),
                                                    m_model->mapTheme()->head()->description() );
                        tileCreatorDlg->exec();
                        if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                            qDebug() << "Base tiles for" << sourceDir << "successfully created.";
                        } else {
                            qDebug() << "Some or all base tiles for" << sourceDir << "could not be created.";
                        }

                        delete tileCreatorDlg;
                    }

                    if ( TileLoader::baseTilesAvailable( *vectorTile ) ) {
                        vectorTiles.append( vectorTile );
                    } else {
                        qWarning() << "Base tiles for" << sourceDir << "not available. Skipping all texture layers.";
                        vectorTileLayersOk = false;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( GeoSceneAbstractDataset *dataset: layer->datasets() ) {
                GeoSceneGeodata *data = dynamic_cast<GeoSceneGeodata*>( dataset );
                Q_ASSERT( data );
                currentDatasets << *data;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataItemIcon *icon: folder->style()->listStyle().itemIconList()) {
        if ( ! expandedState ) {
            if ( icon->state() == GeoDataItemIcon::Closed ) {
                return icon->icon();
            }
        } else {
            if ( icon->state() == GeoDataItemIcon::Open ) {
                return icon->icon();
            }
        }
    }
```

#### AUTO 


```{c}
auto p = coordinateToPoint(node);
```

#### AUTO 


```{c}
auto const visualCategory = placemark->visualCategory();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto placemark: m_visiblePlacemarks) {
            if (!extendedBox.contains(placemark->coordinates())) {
                outdated << placemark;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( int key: remove ) {
            ways.remove( key );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &dir: path.split( QLatin1Char( ':' ) ) ) {
            QFileInfo executable( QDir( dir ), application );
            if ( executable.exists() ) {
                m_installedEditors[application] = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto child = dynamic_cast<GeoDataContainer *>(*i)
```

#### RANGE FOR STATEMENT 


```{c}
for(auto const &list: d->m_tiledItems.values()) {
        qDeleteAll(list.values());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataLatLonBox &geoRect : geoRects) {
        TileId key;
        QRect rect;

        key = TileId::fromCoordinates(GeoDataCoordinates(geoRect.west(), north), zoomLevel);
        rect.setLeft( key.x() );
        rect.setTop( key.y() );

        key = TileId::fromCoordinates(GeoDataCoordinates(geoRect.east(), south), zoomLevel);
        rect.setRight( key.x() );
        rect.setBottom( key.y() );

        TileCoordsPyramid pyramid(0, zoomLevel );
        pyramid.setBottomLevelCoords( rect );

        for ( int level = pyramid.topLevel(); level <= pyramid.bottomLevel(); ++level ) {
        QRect const coords = pyramid.coords( level );
        int x1, y1, x2, y2;
        coords.getCoords( &x1, &y1, &x2, &y2 );
            for ( int x = x1; x <= x2; ++x ) {
                for ( int y = y1; y <= y2; ++y ) {
                    TileId const tileId( 0, level, x, y );
                    tileIdSet.insert(tileId);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tileId: tiles) {
                ++count;
                QString const inputFile = first ? m_inputFile : QString("%1/osm/%2/%3/%4.o5m").
                                                  arg(m_cacheDir).arg(tileId.zoomLevel()-1).arg(tileId.x()>>1).arg(tileId.y()>>1);
                QString const outputFile = osmFileFor(tileId);
                if (QFileInfo(outputFile).exists()) {
                    continue;
                }

                printProgress(count / double(maxCount));
                cout << " Creating osm cache tile " << count << "/" << maxCount << " (";
                cout << tileId.zoomLevel() << "/" << tileId.x() << "/" << tileId.y() << ')' << string(20, ' ') << '\r';
                cout.flush();

                QDir().mkpath(QFileInfo(outputFile).absolutePath());
                QString const output = QString("-o=%1").arg(outputFile);

                GeoDataLatLonBox tileBoundary;
                m_tileProjection.geoCoordinates(tileId.zoomLevel(), tileId.x(), tileId.y(), tileBoundary);

                double const minLon = tileBoundary.west(GeoDataCoordinates::Degree);
                double const maxLon = tileBoundary.east(GeoDataCoordinates::Degree);
                double const maxLat = tileBoundary.north(GeoDataCoordinates::Degree);
                double const minLat = tileBoundary.south(GeoDataCoordinates::Degree);
                QString const bbox = QString("-b=%1,%2,%3,%4").arg(minLon).arg(minLat).arg(maxLon).arg(maxLat);
                QProcess osmconvert;
                osmconvert.start("osmconvert", QStringList() << "--drop-author" << "--drop-version"
                                 << "--complete-ways" << "--complex-ways" << bbox << output << inputFile);
                osmconvert.waitForFinished(10*60*1000);
                if (osmconvert.exitCode() != 0) {
                    qWarning() << osmconvert.readAllStandardError();
                    qWarning() << "osmconvert failed: " << osmconvert.errorString();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const GeoDataPlacemark *placemark: document->placemarkList() ) {
        importPlacemark( outline, segments, placemark );
    }
```

#### AUTO 


```{c}
const auto placemark = geodata_cast<GeoDataPlacemark>(relation.first)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto peak: peaks) {
        if (distanceSphere(peak->coordinate(), placemark->coordinate()) < maxDistance) {
            neighbors << peak;
        }
    }
```

#### AUTO 


```{c}
const auto folder = geodata_cast<GeoDataFolder>(parentItem)
```

#### AUTO 


```{c}
const auto original = geodata_cast<GeoDataPlacemark>(feature)
```

#### AUTO 


```{c}
const auto end = m_osmData.nodeReferencesEnd();
```

#### AUTO 


```{c}
const auto flyTo = geodata_cast<GeoDataFlyTo>(object)
```

#### AUTO 


```{c}
auto sceneData = dynamic_cast<const GeoSceneGeodata *>(dataset);
```

#### RANGE FOR STATEMENT 


```{c}
for (GeoDataPlacemark const * placemark: potentialIntersections(tileBoundary)) {
        GeoDataGeometry const * const geometry = placemark ? placemark->geometry() : nullptr;
        if (geometry && tileBoundary.intersects(geometry->latLonAltBox())) {
            if (geodata_cast<GeoDataPolygon>(geometry)) {
                clipPolygon(placemark, clip, minArea, tile, osmIds);
            } else if (geodata_cast<GeoDataLineString>(geometry)) {
                clipString<GeoDataLineString>(placemark, clip, minArea, tile, osmIds);
            } else if (geodata_cast<GeoDataLinearRing>(geometry)) {
                clipString<GeoDataLinearRing>(placemark, clip, minArea, tile, osmIds);
            } else {
                tile->append(placemark->clone());
                osmIds << placemark->osmData().id();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { updateScreenPosition(); }
```

#### AUTO 


```{c}
auto & osmData = placemark->osmData();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &entry: m_entries) {
            qreal x, y;
            viewport->screenCoordinates(entry.point, x, y);
            QPointF point(x, y);
            point += buildingOffset(point, viewport);
            painter->drawTextFragment(point.toPoint(),
                                     m_buildingText, painter->font().pointSize(), painter->brush().color(),
                                     GeoPainter::RoundFrame);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScreenOverlayGraphicsItem  *item: m_screenOverlays) {
            if (item->screenOverlay() == feature) {
                m_screenOverlays.removeAll(item);
            }
        }
```

#### AUTO 


```{c}
auto const x0 = polygon[i].x();
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &fileName: pluginFileNameList ) {
        QString const baseName = QFileInfo(fileName).baseName();
        QString const libBaseName = MARBLE_SHARED_LIBRARY_PREFIX + QFileInfo(fileName).baseName();
        if (!m_whitelist.isEmpty() && !m_whitelist.contains(baseName) && !m_whitelist.contains(libBaseName)) {
            mDebug() << "Ignoring non-whitelisted plugin " << fileName;
            continue;
        }
        if (m_blacklist.contains(baseName) || m_blacklist.contains(libBaseName)) {
            mDebug() << "Ignoring blacklisted plugin " << fileName;
            continue;
        }

        // mDebug() << fileName << " - " << MarbleDirs::pluginPath( fileName );
        QString const path = MarbleDirs::pluginPath( fileName );
#ifdef Q_OS_ANDROID
        QFileInfo targetFile( path );
        if ( !m_pluginPaths.contains( targetFile.canonicalFilePath() ) ) {
            // @todo Delete the file here?
            qDebug() << "Ignoring file " << path << " which is not among the currently installed plugins";
            continue;
        }
#endif
        QPluginLoader* loader = new QPluginLoader( path, m_parent );

        QObject * obj = loader->instance();

        if ( obj ) {
            bool isPlugin = addPlugin(obj, loader);
            if (!isPlugin) {
                delete loader;
            } else {
                foundPlugin = true;
            }
        } else {
            qWarning() << "Ignoring to load the following file since it doesn't look like a valid Marble plugin:" << path << endl
                       << "Reason:" << loader->errorString();
            delete loader;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value: shopValues()) {
        s_visualCategories[OsmTag("shop", value)]               = GeoDataPlacemark::Shop;
    }
```

#### AUTO 


```{c}
auto tagIter = data.tagsBegin(), end = data.tagsEnd();
```

#### AUTO 


```{c}
auto iter = names.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for( Marble::GeoDataPlacemark * placemark: folder->placemarkList() ) {
            if (placemark->coordinate().sphericalDistanceTo(compareTo) * planetRadius < 5) {
                manager->removeBookmark( placemark );
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString &mapDir: alternatives ) {
        if ( retrieveData( route, mapDir, reply ) ) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GeoDataCoordinates &coordinates: values) {
        d->m_vector.append(coordinates);
    }
```

