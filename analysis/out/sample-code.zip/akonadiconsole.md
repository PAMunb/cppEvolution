#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("Item Fetch Scope"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addedRelation : addedRelations) {
        auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                                          QString::number(addedRelation.leftId),
                                          QString::number(addedRelation.rightId),
                                          addedRelation.type));
        relationsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto *model = new QStandardItemModel(this);
```

#### AUTO 


```{c}
const auto &pair
```

#### AUTO 


```{c}
auto query = new QueryNode;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
        mCheckedApps.clear();
        mCheckedApps.reserve(items.count());
        for (const auto &item : items) {
            mCheckedApps.insert(item);
        }
        if (!mInvalidateTimer.isActive()) {
            mInvalidateTimer.start();
        }
    }
```

#### AUTO 


```{c}
auto *store = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
const auto ancestors = item.ancestors();
```

#### AUTO 


```{c}
auto xapianStore = store.objectCast<Akonadi::Search::XapianSearchStore>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : mTypeFilter->checkedItems(Qt::UserRole)) {
            mCheckedTypes.insert(static_cast<Akonadi::ChangeNotification::Type>(item.toInt()));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) {
        Q_EMIT enabledChanged(toggled);
    }
```

#### AUTO 


```{c}
auto tagItem = new QStandardItem(QStringLiteral("Tag"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : set) {
        switch (v) {
        case Akonadi::Monitor::Items:
            rv << QStringLiteral("Items");
            break;
        case Akonadi::Monitor::Collections:
            rv << QStringLiteral("Collections");
            break;
        case Akonadi::Monitor::Tags:
            rv << QStringLiteral("Tags");
            break;
        case Akonadi::Monitor::Relations:
            rv << QStringLiteral("Relations");
            break;
        case Akonadi::Monitor::Subscribers:
            rv << QStringLiteral("Subscribers");
            break;
        case Akonadi::Monitor::Notifications:
            rv << QStringLiteral("Notification");
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : std::as_const(selectedRows)) {
        rows.append(index.row());
    }
```

#### AUTO 


```{c}
auto out = new QStandardItem(QStringLiteral("->"));
```

#### AUTO 


```{c}
const auto subscriber = mData[index.row()];
```

#### AUTO 


```{c}
const auto removedRelations = ntf.removedRelations();
```

#### AUTO 


```{c}
auto mDataView = new QTableView(this);
```

#### AUTO 


```{c}
auto *layout2 = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *connection = static_cast<ConnectionNode *>(childNode->parent->parent);
```

#### AUTO 


```{c}
auto dlg = new QueryViewDialog(
        index.data(QueryTreeModel::QueryRole).toString(),
        index.data(QueryTreeModel::QueryValuesRole).value<QMap<QString,QVariant>>(),
        index.data(QueryTreeModel::QueryResultsCountRole).toInt(),
        index.data(QueryTreeModel::QueryResultsRole).value<QList<QList<QVariant>>>(),
        this);
```

#### AUTO 


```{c}
auto clearGeneralButton = new QPushButton(QStringLiteral("Clear Information View"), this);
```

#### AUTO 


```{c}
const auto &identifer
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto tag : tags) {
        auto item = new QStandardItem(QString::number(tag.id()));
        populateTagTree(item, tag);
        tagItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                                          QString::number(removedRelation.leftId),
                                          QString::number(removedRelation.rightId),
                                          removedRelation.type));
```

#### AUTO 


```{c}
auto model = new QStandardItemModel(this);
```

#### AUTO 


```{c}
const auto item = model->findItems(identifier).constFirst();
```

#### AUTO 


```{c}
auto *user2Button = new QPushButton;
```

#### AUTO 


```{c}
const auto parts = item.parts();
```

#### AUTO 


```{c}
const auto &store
```

#### AUTO 


```{c}
const auto &msg
```

#### AUTO 


```{c}
auto tagItem = new QStandardItem(QStringLiteral("Tags"));
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("Collection"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex &parent) {
        if (!parent.isValid()) {
            QCOMPARE(model.rowCount(), 1);
            QVERIFY(model.index(0, 0).isValid());
        } else {
            QCOMPARE(model.rowCount(parent), 1);
        }
    }
```

#### AUTO 


```{c}
const auto state = m_ntfView->header()->saveState();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &del : qAsConst(mDeleted)) {
        col.removeAttribute(del.toLatin1());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &identifer : mSenderCache.keys()) {
        bool found = false;
        for (const auto &msg : qAsConst(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
        if (!found) {
            toDelete.push_back(identifer);
        }
    }
```

#### AUTO 


```{c}
auto &sessions = mData[subscriber.sessionId()];
```

#### AUTO 


```{c}
auto tabWidget = new QTabWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const auto list = ui.instanceWidget->selectedAgentInstances();
        for (auto agent : list) {
            agent.synchronizeRelations();
        }
    }
```

#### AUTO 


```{c}
auto *buttonLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto it = cache.constFind(str);
```

#### AUTO 


```{c}
auto *job = new XmlWriteJob(root, fileName, this);
```

#### AUTO 


```{c}
const auto listeners = msg.listeners();
```

#### AUTO 


```{c}
const auto cfs = subscriber.collectionFetchScope();
```

#### AUTO 


```{c}
auto con = static_cast<ConnectionNode*>(node);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : allServices) {
        if (!service.startsWith(lockService)) {
            continue;
        }
        insts.push_back(service.mid(lockService.length() + 1));
    }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : toDelete) {
        const auto &item = mSenderFilterModel->findItems(displaySender(i));
        if (!item.isEmpty()) {
            const auto &index = item.first()->index();
            mSenderFilterModel->removeRows(index.row(), 1);
        }
        mSenderCache.remove(i);
    }
```

#### AUTO 


```{c}
const auto &query
```

#### AUTO 


```{c}
auto action = parent->actionCollection()->addAction(QStringLiteral("akonadiconsole_akonadi2xml"));
```

#### AUTO 


```{c}
const auto leftMail = leftItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto *mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto ntfModel = qobject_cast<QStandardItemModel *>(m_ntfView->model());
```

#### AUTO 


```{c}
auto type = new QStandardItem(QString::fromLatin1(attr->type()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
                    mCheckedSenders.insert(item);
                }
```

#### AUTO 


```{c}
const auto idx0 = ntfModel->index(r, 0);
```

#### AUTO 


```{c}
const auto parentTag = action->parent()->property("Tag").value<Akonadi::Tag>();
```

#### AUTO 


```{c}
const auto &ancestor
```

#### AUTO 


```{c}
auto mainLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
const auto &addedRelation
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto cfsItem = new QStandardItem(QStringLiteral("Collection Fetch Scope"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ancestor : ancestors) {
        i = populateAncestorTree(i, ancestor);
    }
```

#### AUTO 


```{c}
auto ifsItem = new QStandardItem(QStringLiteral("Item Fetch Scope"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &query : qAsConst(queries)) {
        auto tab = addTab();
        tab->setQuery(query);
    }
```

#### AUTO 


```{c}
const auto &msg = mModel->data(mModel->index(row,2)).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto v : set) {
        switch (v) {
        case Akonadi::Monitor::Items:
            rv << QStringLiteral("Items");
            break;
        case Akonadi::Monitor::Collections:
            rv << QStringLiteral("Collections");
            break;
        case Akonadi::Monitor::Tags:
            rv << QStringLiteral("Tags");
            break;
        case Akonadi::Monitor::Relations:
            rv << QStringLiteral("Relations");
            break;
        case Akonadi::Monitor::Subscribers:
            rv << QStringLiteral("Subscribers");
            break;
        }
    }
```

#### AUTO 


```{c}
auto iface = new org::freedesktop::Akonadi::TracerNotification(QString(), QStringLiteral("/tracing/notifications"), QDBusConnection::sessionBus(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) {
                Q_EMIT enabledChanged(toggled);
            }
```

#### AUTO 


```{c}
auto button = new QPushButton(QStringLiteral("Search"));
```

#### AUTO 


```{c}
const auto subscribers = mData.value(session);
```

#### AUTO 


```{c}
const auto attr
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &agent : list) {
            agent.abortCurrentTask();
        }
```

#### AUTO 


```{c}
const auto doc = mDatabase->get_document(docId);
```

#### AUTO 


```{c}
auto *item = new QStandardItem;
```

#### AUTO 


```{c}
auto model = qobject_cast<QStandardItemModel*>(m_ntfView->model());
```

#### AUTO 


```{c}
auto i = new QStandardItem(QString::number(item->id()));
```

#### AUTO 


```{c}
auto comboModel = qobject_cast<QStandardItemModel *>(mTypeFilter->model());
```

#### AUTO 


```{c}
auto store = mStoreCombo->itemData(idx, Qt::UserRole).value<QSharedPointer<Akonadi::Search::SearchStore> >();
```

#### RANGE FOR STATEMENT 


```{c}
for (AgentInstance agent : list) {
            agent.synchronize();
        }
```

#### AUTO 


```{c}
const auto contentUiTagsItems = contentUi.tags->items();
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto item = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
                mCheckedApps.clear();
                mCheckedApps.reserve(items.count());
                for (const auto &item : items) {
                    mCheckedApps.insert(item);
                }
                if (!mInvalidateTimer.isActive()) {
                    mInvalidateTimer.start();
                }
            }
```

#### AUTO 


```{c}
auto *mProxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto tab = addTab();
```

#### AUTO 


```{c}
const auto &index = item.first()->index();
```

#### AUTO 


```{c}
auto user1Button = new QPushButton;
```

#### AUTO 


```{c}
const auto &tag
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
        mCheckedTypes.clear();
        mCheckedTypes.reserve(items.count());
        for (const auto &item : mTypeFilter->checkedItems(Qt::UserRole)) {
            mCheckedTypes.insert(static_cast<QtMsgType>(item.toInt()));
        }
        if (!mInvalidateTimer.isActive()) {
            mInvalidateTimer.start();
        }
    }
```

#### AUTO 


```{c}
auto i = new QStandardItem(QString::number(item.id()));
```

#### AUTO 


```{c}
const auto &identifier = mModel->data(mModel->index(row,0)).toString();
```

#### AUTO 


```{c}
auto *mSearchLineEdit = w.findChild<QLineEdit *>(QStringLiteral("searchline"));
```

#### AUTO 


```{c}
const auto ifs = ntf.itemFetchScope();
```

#### AUTO 


```{c}
auto clearFilteredButton = new QPushButton(QStringLiteral("Clear Filtered Messages"), this);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Close, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &removedRelation : removedRelations) {
        auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                    QString::number(removedRelation.leftId),
                    QString::number(removedRelation.rightId),
                    removedRelation.type));
        relationsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto *splitter = new QSplitter(Qt::Vertical, this);
```

#### AUTO 


```{c}
const auto message = mMessages.at(index.row());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &msg: qAsConst(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            mCheckedCategories.insert(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &query : std::as_const(queries)) {
        auto tab = addTab();
        tab->setQuery(query);
    }
```

#### AUTO 


```{c}
const auto state = mSubscriberView->header()->saveState();
```

#### AUTO 


```{c}
auto *fetch = static_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *mainLayout = w.findChild<QHBoxLayout *>(QStringLiteral("mainlayout"));
```

#### AUTO 


```{c}
const auto &job
```

#### AUTO 


```{c}
auto item = new QStandardItem(QString::fromUtf8(part.payloadName()));
```

#### AUTO 


```{c}
auto proxy = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
const auto tags = item.tags();
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(QString::number(relation.left()), QString::number(relation.right()), QString::fromUtf8(relation.type())));
```

#### AUTO 


```{c}
const auto subscriber = subscribers.at(index.row());
```

#### AUTO 


```{c}
auto addTabButton = new QPushButton(QIcon::fromTheme(QStringLiteral("tab-new")), QString());
```

#### AUTO 


```{c}
auto incidence = item.payload<KCalCore::Incidence::Ptr>();
```

#### AUTO 


```{c}
const auto notification = sourceModel()->data(source_idx, NotificationModel::NotificationRole).value<Akonadi::ChangeNotification>();
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(w);
```

#### AUTO 


```{c}
auto itemsItem = new QStandardItem(QStringLiteral("Items"));
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                                          QString::number(addedRelation.leftId),
                                          QString::number(addedRelation.rightId),
                                          addedRelation.type));
```

#### AUTO 


```{c}
auto *dlg = qobject_cast<TagPropertiesDialog *>(sender());
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto arg = var.value<QList<QPair<int, int>>>();
```

#### AUTO 


```{c}
auto mProxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
const auto *attr
```

#### AUTO 


```{c}
auto user2Button = new QPushButton;
```

#### AUTO 


```{c}
const auto &row = results[r];
```

#### AUTO 


```{c}
auto valuesRoot = new QStandardItem(QStringLiteral("Values"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : set) {
        rv << QVariant(v).toString();
    }
```

#### AUTO 


```{c}
const auto typesSet = ntf.types();
```

#### RANGE FOR STATEMENT 


```{c}
for (AgentInstance agent : list) {
        agent.synchronizeCollectionTree();
    }
```

#### AUTO 


```{c}
const auto leftInc = leftItem.payload<IncidencePtr>();
```

#### AUTO 


```{c}
const auto &relation
```

#### AUTO 


```{c}
auto l = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto tab = qobject_cast<DbConsoleTab *>(mTabWidget->widget(i));
```

#### AUTO 


```{c}
auto tab = qobject_cast<DbConsoleTab*>(mTabWidget->widget(i));
```

#### AUTO 


```{c}
const auto ancestors = collection.ancestors();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : arg) {
        if (!ret.isEmpty()) {
            ret += QLatin1Char(' ');
        }
        ret += QString::number(pair.first) + QLatin1Char(',') + QString::number(pair.second);
    }
```

#### AUTO 


```{c}
const auto arg = var.value<QList<QPair<int, int>>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &removedRelation : removedRelations) {
        auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                                          QString::number(removedRelation.leftId),
                                          QString::number(removedRelation.rightId),
                                          removedRelation.type));
        relationsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto mSelectOnlyError = w.findChild<QCheckBox *>(QStringLiteral("selectonlyerror"));
```

#### AUTO 


```{c}
auto out = new QStandardItem(QStringLiteral("<-"));
```

#### AUTO 


```{c}
auto incidence = item.payload<KCalendarCore::Incidence::Ptr>();
```

#### AUTO 


```{c}
auto store = mStoreCombo->itemData(idx, Qt::UserRole).value<QSharedPointer<Akonadi::Search::SearchStore>>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : typesSet) {
        switch (type) {
        case Akonadi::Protocol::ModifySubscriptionCommand::ItemChanges:
            types.push_back(QStringLiteral("Items"));
            break;
        case Akonadi::Protocol::ModifySubscriptionCommand::CollectionChanges:
            types.push_back(QStringLiteral("Collections"));
            break;
        case Akonadi::Protocol::ModifySubscriptionCommand::TagChanges:
            types.push_back(QStringLiteral("Tags"));
            break;
        case Akonadi::Protocol::ModifySubscriptionCommand::RelationChanges:
            types.push_back(QStringLiteral("Relations"));
            break;
        case Akonadi::Protocol::ModifySubscriptionCommand::SubscriptionChanges:
            types.push_back(QStringLiteral("Subscriptions"));
            break;
        case Akonadi::Protocol::ModifySubscriptionCommand::ChangeNotifications:
            types.push_back(QStringLiteral("Changes"));
            break;
        case Akonadi::Protocol::ModifySubscriptionCommand::NoType:
            types.push_back(QStringLiteral("No Type"));
            break;
        }
    }
```

#### AUTO 


```{c}
auto con = mConnectionById.value(connectionId);
```

#### AUTO 


```{c}
const auto end = mDatabase->postlist_end(q);
```

#### AUTO 


```{c}
auto query = static_cast<QueryNode*>(node);
```

#### AUTO 


```{c}
auto *comboModel = qobject_cast<QStandardItemModel *>(mTypeFilter->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            mCheckedApps.insert(item);
        }
```

#### AUTO 


```{c}
auto *user1Button = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &res : qAsConst(mChangedRIDs)) {
                query.addBindValue(res);
            }
```

#### AUTO 


```{c}
const auto relation
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(w);
```

#### AUTO 


```{c}
const auto group = item.payload<KContacts::ContactGroup>();
```

#### AUTO 


```{c}
auto con = new ConnectionNode;
```

#### AUTO 


```{c}
const auto &part
```

#### AUTO 


```{c}
auto key = static_cast<QKeyEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &relation : relations) {
        auto item = new QStandardItem(
            QStringLiteral("%lld-%lld %s").arg(QString::number(relation.left()), QString::number(relation.right()), QString::fromUtf8(relation.type())));
        relationItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto trx = new TransactionNode;
```

#### AUTO 


```{c}
const auto msg = mModel->data(mModel->index(row, 0), LoggingModel::MessageRole).value<LoggingModel::Message>();
```

#### AUTO 


```{c}
const auto tag
```

#### AUTO 


```{c}
auto item = new QStandardItem(value);
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                    QString::number(removedRelation.leftId),
                    QString::number(removedRelation.rightId),
                    removedRelation.type));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
                mCheckedTypes.clear();
                mCheckedTypes.reserve(items.count());
                // it sucks a bit that KCheckComboBox::checkedItems can't return a QVariantList instead of a QStringList
                for (const QString &item : mTypeFilter->checkedItems(Qt::UserRole)) {
                    mCheckedTypes.insert(static_cast<Akonadi::ChangeNotification::Type>(item.toInt()));
                }
                if (!mInvalidateTimer.isActive()) {
                    mInvalidateTimer.start();
                }
            }
```

#### AUTO 


```{c}
const auto addedRelations = ntf.addedRelations();
```

#### AUTO 


```{c}
auto job = new XmlWriteJob(root, fileName, this);
```

#### AUTO 


```{c}
auto widget = new QWidget(this);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto tfsItem = new QStandardItem(QStringLiteral("Tag Fetch Scope"));
```

#### AUTO 


```{c}
auto partsItem = new QStandardItem(QStringLiteral("Parts"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        mTabWidget->removeTab(index);
        saveQueries();
    }
```

#### AUTO 


```{c}
auto *widget = new QWidget(this);
```

#### AUTO 


```{c}
const auto docId = index.data(Qt::UserRole).value<Xapian::docid>();
```

#### AUTO 


```{c}
auto tagScope = new QStandardItem(QStringLiteral("Tag Fetch Scope"));
```

#### AUTO 


```{c}
const auto list = ui.instanceWidget->selectedAgentInstances();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
                    rv.push_back(QString::number(item->id()));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &msg : std::as_const(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto mWindow = new MainWindow;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag : tags) {
        auto item = new QStandardItem(QString::number(tag.id()));
        populateTagTree(item, tag);
        tagItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(
            QStringLiteral("%lld-%lld %s").arg(QString::number(relation.left()), QString::number(relation.right()), QString::fromUtf8(relation.type())));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
                mCheckedTypes.clear();
                mCheckedTypes.reserve(items.count());
                for (const auto &item : mTypeFilter->checkedItems(Qt::UserRole)) {
                    mCheckedTypes.insert(static_cast<QtMsgType>(item.toInt()));
                }
                if (!mInvalidateTimer.isActive()) {
                    mInvalidateTimer.start();
                }
            }
```

#### AUTO 


```{c}
const auto &type
```

#### AUTO 


```{c}
auto dlg = new QueryViewDialog(index.data(QueryTreeModel::QueryRole).toString(),
                                   index.data(QueryTreeModel::QueryValuesRole).value<QMap<QString, QVariant>>(),
                                   index.data(QueryTreeModel::QueryResultsCountRole).toInt(),
                                   index.data(QueryTreeModel::QueryResultsRole).value<QList<QList<QVariant>>>(),
                                   this);
```

#### AUTO 


```{c}
const auto arg = var.value<QList<QPair<int, int> > >();
```

#### AUTO 


```{c}
const auto addr = item.payload<KContacts::Addressee>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addedRelation : addedRelations) {
        auto item = new QStandardItem(
            QStringLiteral("%lld-%lld %s").arg(QString::number(addedRelation.leftId), QString::number(addedRelation.rightId), addedRelation.type));
        relationsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
const auto tag = action->parent()->property("Tag").value<Akonadi::Tag>();
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &removedRelation : removedRelations) {
        auto item = new QStandardItem(
            QStringLiteral("%lld-%lld %s").arg(QString::number(removedRelation.leftId), QString::number(removedRelation.rightId), removedRelation.type));
        relationsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto *enableCB = new QCheckBox(this);
```

#### AUTO 


```{c}
auto trx = static_cast<TransactionNode *>(node);
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
const auto file = message.file.mid(message.file.lastIndexOf(QDir::separator()) + 1, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &identifer: mSenderCache.keys()) {
        bool found = false;
        for (const auto &msg: qAsConst(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
        if (!found) {
            toDelete.push_back(identifer);
        }
    }
```

#### AUTO 


```{c}
auto agent
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &msg : qAsConst(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
const auto items = mSenderFilter->checkedItems(DebugModel::IdentifierRole);
```

#### AUTO 


```{c}
auto *tabWidget = new QTabWidget(this);
```

#### AUTO 


```{c}
auto cpItem = new QStandardItem(QStringLiteral("Cache Policy"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &i: toDelete) {

        const auto &item = mSenderFilterModel->findItems(displaySender(i));
        if (!item.isEmpty()) {
            const auto &index = item.first()->index();
            mSenderFilterModel->removeRows(index.row(),1);
        }
        mSenderCache.remove(i);
    }
```

#### AUTO 


```{c}
const auto items = Protocol::cmdCast<Protocol::ItemChangeNotification>(msg.notification()).items();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : mTypeFilter->checkedItems(Qt::UserRole)) {
                    mCheckedTypes.insert(static_cast<QtMsgType>(item.toInt()));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &identifer: mSenderCache.keys()) {
        bool found = false;
        for(const auto &msg: mMessages) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
        if (!found) {
            toDelete.push_back(identifer);
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(query.value(0).toString());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &l : listeners) {
                rv.push_back(QString::fromUtf8(l));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inst : insts) {
            auto *item = new QStandardItem;
            item->setText(inst.isEmpty() ? QStringLiteral("<global>") : inst);
            item->setData(inst, Qt::UserRole);
            model->appendRow(item);
        }
```

#### AUTO 


```{c}
auto v
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &query : queries) {
        auto tab = addTab();
        tab->setQuery(query);
    }
```

#### AUTO 


```{c}
const auto idx = index(row, 0, sessionIdx);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : std::as_const(widgets)) {
        if (w->objectName().isEmpty()) {
            continue;
        }
        PROCESS_TYPE(QSplitter);
        PROCESS_TYPE(QTabWidget);
        PROCESS_TYPE(QTreeView);
        PROCESS_TYPE(QComboBox);
    }
```

#### AUTO 


```{c}
const auto &item = mSenderFilterModel->findItems(displaySender(i));
```

#### AUTO 


```{c}
auto dlg = new QueryViewDialog(
        index.data(QueryTreeModel::QueryRole).toString(),
        index.data(QueryTreeModel::QueryValuesRole).value<QMap<QString, QVariant> >(),
        index.data(QueryTreeModel::QueryResultsCountRole).toInt(),
        index.data(QueryTreeModel::QueryResultsRole).value<QList<QList<QVariant> > >(),
        this);
```

#### AUTO 


```{c}
auto &tfs = job->fetchScope().tagFetchScope();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &part : parts) {
        auto item = new QStandardItem(QString::fromUtf8(part.payloadName()));
        QString type;
        switch (part.metaData().storageType()) {
        case Akonadi::Protocol::PartMetaData::External:
            type = QStringLiteral("External");
            break;
        case Akonadi::Protocol::PartMetaData::Internal:
            type = QStringLiteral("Internal");
            break;
        case Akonadi::Protocol::PartMetaData::Foreign:
            type = QStringLiteral("Foreign");
            break;
        }
        appendRow(item, QStringLiteral("Size"), QString::number(part.metaData().size()));
        appendRow(item, QStringLiteral("Storage Type"), type);
        appendRow(item, QStringLiteral("Version"), QString::number(part.metaData().version()));
        appendRow(item, QStringLiteral("Data"), QString::fromUtf8(part.data().toHex()));

        partsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
const auto relations = item.relations();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &removedAttr : qAsConst(mRemovedAttrs)) {
        mTag.removeAttribute(removedAttr.toLatin1());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &agent : list) {
                AgentManager::self()->removeInstance(agent);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        uidList << QString::number(item.id());
    }
```

#### AUTO 


```{c}
auto dlg = new TagPropertiesDialog(this);
```

#### AUTO 


```{c}
const auto &removedRelation
```

#### AUTO 


```{c}
auto pos = str.lastIndexOf(QLatin1Char('('));
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                    QString::number(addedRelation.leftId),
                    QString::number(addedRelation.rightId),
                    addedRelation.type));
```

#### AUTO 


```{c}
const auto ifs = subscriber.itemFetchScope();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const AgentInstance::List list = ui.instanceWidget->selectedAgentInstances();
        for (auto agent : list) {
            agent.synchronizeTags();
        }
    }
```

#### AUTO 


```{c}
auto attributesItem = new QStandardItem(QStringLiteral("Attributes"));
```

#### AUTO 


```{c}
auto btn = new QPushButton(QStringLiteral("Save to File..."));
```

#### AUTO 


```{c}
auto menu = new QMenu(this);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::ItemFetchJob(Akonadi::Item(docId));
```

#### AUTO 


```{c}
const auto itemFlags = item.flags();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto agent : list) {
            agent.synchronizeTags();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : arg) {
        if (!ret.isEmpty()) {
            ret += ' ';
        }
        ret += QString::number(pair.first) + "," + QString::number(pair.second);
    }
```

#### AUTO 


```{c}
const auto &direction = mModel->data(mModel->index(row,1)).toString();
```

#### AUTO 


```{c}
auto relationItem = new QStandardItem(QStringLiteral("Relations"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i: toDelete) {
        const auto &item = mSenderFilterModel->findItems(displaySender(i));
        if (!item.isEmpty()) {
            const auto &index = item.first()->index();
            mSenderFilterModel->removeRows(index.row(), 1);
        }
        mSenderCache.remove(i);
    }
```

#### AUTO 


```{c}
auto termsRoot = new QStandardItem(QStringLiteral("Terms"));
```

#### AUTO 


```{c}
auto *mSelectColumn = w.findChild<QComboBox *>(QStringLiteral("selectcolumn"));
```

#### AUTO 


```{c}
const auto contentUiItemFlags = contentUi.flags->items();
```

#### AUTO 


```{c}
auto layout2 = new QHBoxLayout;
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto ancestorItem = new QStandardItem(QStringLiteral("Ancestor"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item::Flag &f : currentItemFlags) {
        item.clearFlag(f);
    }
```

#### AUTO 


```{c}
auto it = sessions.begin(), end = sessions.end();
```

#### AUTO 


```{c}
const auto &con
```

#### AUTO 


```{c}
auto trx = static_cast<TransactionNode*>(con->queries.last());
```

#### AUTO 


```{c}
const auto &sender = model->data(model->index(row, DebugModel::SenderColumn)).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
                    mCheckedApps.insert(item);
                }
```

#### AUTO 


```{c}
const auto &i
```

#### AUTO 


```{c}
auto con = mConnectionById.value(id);
```

#### AUTO 


```{c}
const auto q = mQueryWidget->toPlainText().toStdString();
```

#### AUTO 


```{c}
auto buttonLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto &l
```

#### AUTO 


```{c}
auto it = mData.begin(), end = mData.end();
```

#### AUTO 


```{c}
auto model = qobject_cast<QStandardItemModel*>(mSubscriberView->model());
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto group = config->group("DBConsole");
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
        mCheckedTypes.clear();
        mCheckedTypes.reserve(items.count());
        // it sucks a bit that KCheckComboBox::checkedItems can't return a QVariantList instead of a QStringList
        for (const QString &item : mTypeFilter->checkedItems(Qt::UserRole)) {
            mCheckedTypes.insert(static_cast<Akonadi::ChangeNotification::Type>(item.toInt()));
        }
        if (!mInvalidateTimer.isActive()) {
            mInvalidateTimer.start();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto agent : list) {
            agent.synchronizeRelations();
        }
```

#### AUTO 


```{c}
auto trx = static_cast<TransactionNode*>(node);
```

#### AUTO 


```{c}
auto trx = static_cast<TransactionNode *>(con->queries.last());
```

#### AUTO 


```{c}
auto *dlg = new TagPropertiesDialog(this);
```

#### AUTO 


```{c}
auto i = new QStandardItem(QStringLiteral("Ancestor"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &del : std::as_const(mDeleted)) {
        col.removeAttribute(del.toLatin1());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto attr : list) {
        auto type = new QStandardItem(QString::fromLatin1(attr->type()));
        type->setEditable(false);
        mAttrModel->appendRow({type, new QStandardItem(QString::fromLatin1(attr->serialized()))});
    }
```

#### AUTO 


```{c}
auto it = mDatabase->postlist_begin(q);
```

#### AUTO 


```{c}
const auto tag = mTagModel->data(index, TagModel::TagRole).value<Akonadi::Tag>();
```

#### AUTO 


```{c}
const auto &v
```

#### AUTO 


```{c}
const auto &headers = results[0];
```

#### AUTO 


```{c}
auto model = qobject_cast<QStandardItemModel *>(mSubscriberView->model());
```

#### AUTO 


```{c}
auto sessions = mData[subscriber.sessionId()];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &part : parts) {
        auto item = new QStandardItem(QString::fromUtf8(part.payloadName()));
        QString type;
        switch (part.metaData().storageType()) {
        case Akonadi::Protocol::PartMetaData::External:
            type = QStringLiteral("External");
            break;
        case Akonadi::Protocol::PartMetaData::Internal:
            type = QStringLiteral("Internal");
            break;
        case Akonadi::Protocol::PartMetaData::Foreign:
            type = QStringLiteral("Foreign");
            break;
        }
        appendRow(item, QStringLiteral("Size"), QString::number(part.metaData().size()));
        appendRow(item, QStringLiteral("Storage Type"), type);
        appendRow(item, QStringLiteral("Version"), QString::number(part.metaData().version()));
        appendRow(item, QStringLiteral("Data"), QString::fromUtf8( part.data().toHex()));

        partsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto item = model->findItems(identifier).first();
```

#### AUTO 


```{c}
auto action = qobject_cast<QAction *>(sender());
```

#### AUTO 


```{c}
const auto contentUiItemTags = mCurrentItem.tags();
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *w : qAsConst(widgets)) {
        if (w->objectName().isEmpty()) {
            continue;
        }
        PROCESS_TYPE(QSplitter);
        PROCESS_TYPE(QTabWidget);
        PROCESS_TYPE(QTreeView);
        PROCESS_TYPE(QComboBox);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &con : conns) {
            mQueryTree->addConnection(con.id, con.name, con.start);
            if (con.transactionStart > 0) {
                mQueryTree->addTransaction(con.id, con.trxName, con.transactionStart, 0, QString());
            }
        }
```

#### AUTO 


```{c}
const auto stats = collection.statistics();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : mTypeFilter->checkedItems(Qt::UserRole)) {
                    mCheckedTypes.insert(static_cast<Akonadi::ChangeNotification::Type>(item.toInt()));
                }
```

#### AUTO 


```{c}
auto splitter = new QSplitter(Qt::Vertical, this);
```

#### AUTO 


```{c}
const auto rightMail = rightItem.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : set) {
        rv << toString(v);
    }
```

#### AUTO 


```{c}
auto it = attributes.cbegin(), end = attributes.cend();
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(item, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &_items) {
        Q_UNUSED(_items)
        const auto items = mSenderFilter->checkedItems(DebugModel::IdentifierRole);
        mCheckedSenders.clear();
        mCheckedSenders.reserve(items.count());
        for (const auto &item : items) {
            mCheckedSenders.insert(item);
        }
        if (!mInvalidateTimer.isActive()) {
            mInvalidateTimer.start();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
                mCheckedCategories.clear();
                mCheckedCategories.reserve(items.count());
                for (const auto &item : items) {
                    mCheckedCategories.insert(item);
                }
                if (!mInvalidateTimer.isActive()) {
                    mInvalidateTimer.start();
                }
            }
```

#### AUTO 


```{c}
const auto source_idx = sourceModel()->index(source_row, 0);
```

#### AUTO 


```{c}
const auto itemTags = item.tags();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close | QDialogButtonBox::Apply, this);
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto ancestorFs = cfs.ancestorFetchScope();
```

#### AUTO 


```{c}
auto *mSelectOnlyError = w.findChild<QCheckBox *>(QStringLiteral("selectonlyerror"));
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto w = new QWidget;
```

#### AUTO 


```{c}
auto saveRichtextEverythingButton = new QPushButton(QStringLiteral("Save All Messages ..."), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto v : set) {
        switch (v) {
        case Akonadi::Monitor::Items:
            rv << QStringLiteral("Items");
            break;
        case Akonadi::Monitor::Collections:
            rv << QStringLiteral("Collections");
            break;
        case Akonadi::Monitor::Tags:
            rv << QStringLiteral("Tags");
            break;
        case Akonadi::Monitor::Relations:
            rv << QStringLiteral("Relations");
            break;
        case Akonadi::Monitor::Subscribers:
            rv << QStringLiteral("Subscribers");
            break;
        case Akonadi::Monitor::Notifications:
            rv << QStringLiteral("Debug Notifications");
            break;
        }
    }
```

#### AUTO 


```{c}
auto tab = new DbConsoleTab(mTabCounter, mTabWidget);
```

#### AUTO 


```{c}
const auto end = doc.values_end();
```

#### AUTO 


```{c}
const auto msg = sourceModel()->data(source_idx, DebugModel::MessageRole).value<DebugModel::Message>();
```

#### AUTO 


```{c}
auto store = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
auto connection = static_cast<ConnectionNode *>(childNode->parent->parent);
```

#### AUTO 


```{c}
const auto session = mSessions.at(index.parent().row());
```

#### AUTO 


```{c}
auto *h = new QHBoxLayout;
```

#### AUTO 


```{c}
auto mSearchLineEdit = w.findChild<QLineEdit *>(QStringLiteral("searchline"));
```

#### AUTO 


```{c}
const auto subscriber = index.data(MonitorsModel::SubscriberRole).value<Akonadi::NotificationSubscriber>();
```

#### AUTO 


```{c}
const auto ntf = index.data(NotificationModel::NotificationRole).value<Akonadi::ChangeNotification>();
```

#### AUTO 


```{c}
auto item = new QStandardItem(str);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &identifer: mSenderCache.keys()) {
        bool found = false;
        for(const auto &msg: qAsConst(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
        if (!found) {
            toDelete.push_back(identifer);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &relation : relations) {
        auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(QString::number(relation.left()), QString::number(relation.right()), QString::fromUtf8(relation.type())));
        relationItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto job = new AgentInstanceCreateJob(agentType, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : contentUiItemTags) {
        item.clearTag(tag);
    }
```

#### AUTO 


```{c}
auto saveRichtextButton = new QPushButton(QStringLiteral("Save Filtered Messages ..."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &_items) {
        Q_UNUSED(_items);
        const auto items = mSenderFilter->checkedItems(DebugModel::IdentifierRole);
        mCheckedSenders.clear();
        mCheckedSenders.reserve(items.count());
        for (const auto &item : items) {
            mCheckedSenders.insert(item);
        }
        if (!mInvalidateTimer.isActive()) {
            mInvalidateTimer.start();
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(text);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex & parent) {
        // rowsAboutToBeInserted is supposed to be emitted before the insert
        if (!parent.isValid()) {
            QCOMPARE(model.rowCount(), 0);
        } else {
            QCOMPARE(model.rowCount(parent), 0);
        }
    }
```

#### AUTO 


```{c}
const auto cfs = ntf.collectionFetchScope();
```

#### AUTO 


```{c}
auto enableCB = new QCheckBox(this);
```

#### AUTO 


```{c}
auto *dlg = new TagPropertiesDialog(tag, this);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto incidence = item.payload<IncidencePtr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        auto i = new QStandardItem(QString::number(item.id()));
        populateItemTree(i, item);
        itemsItem->appendRow(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : contentUiTagsItems) {
        Tag tag;
        tag.setGid(s.toLatin1());
        item.setTag(tag);
    }
```

#### AUTO 


```{c}
auto clearAllButton = new QPushButton(QStringLiteral("Clear All Messages"), this);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inst : insts) {
            QStandardItem *item = new QStandardItem;
            item->setText(inst.isEmpty() ? QStringLiteral("<global>") : inst);
            item->setData(inst, Qt::UserRole);
            model->appendRow(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex & parent) {
        if (!parent.isValid()) {
            QCOMPARE(model.rowCount(), 1);
            QVERIFY(model.index(0, 0).isValid());
        } else {
            QCOMPARE(model.rowCount(parent), 1);
        }
    }
```

#### AUTO 


```{c}
const auto msg = sourceModel()->data(source_idx, LoggingModel::MessageRole).value<LoggingModel::Message>();
```

#### AUTO 


```{c}
auto *action = qobject_cast<QAction *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &removedRid : std::as_const(mRemovedRIDs)) {
            query.addBindValue(removedRid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *attr : list) {
        auto type = new QStandardItem(QString::fromLatin1(attr->type()));
        type->setEditable(false);
        mAttrModel->appendRow({type, new QStandardItem(QString::fromLatin1(attr->serialized()))});
    }
```

#### AUTO 


```{c}
auto it = doc.values_begin();
```

#### AUTO 


```{c}
auto *proxy = new QSortFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &msg: mMessages) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
const auto rel = ntf.relation();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto relation : relations) {
        auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(QString::number(relation.left()), QString::number(relation.right()), QString::fromUtf8(relation.type())));
        relationItem->appendRow(item);
    }
```

#### AUTO 


```{c}
auto *key = static_cast<QKeyEvent *>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : arg) {
        if (!ret.isEmpty()) {
            ret += ' ';
        }
        ret += QString::number(pair.first) + ',' + QString::number(pair.second);
    }
```

#### AUTO 


```{c}
const auto currentItemFlags = mCurrentItem.flags();
```

#### AUTO 


```{c}
auto item = new QStandardItem(displaySender(identifier));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &removedAttr : std::as_const(mRemovedAttrs)) {
        mTag.removeAttribute(removedAttr.toLatin1());
    }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item::Flag &f : itemFlags) {
        flags << QString::fromUtf8(f);
    }
```

#### AUTO 


```{c}
const auto idx1 = ntfModel->index(r, 1);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
                mTabWidget->removeTab(index);
                saveQueries();
            }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok, this);
```

#### AUTO 


```{c}
const auto stores = Akonadi::Search::SearchStore::searchStores();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : mTypeFilter->checkedItems(Qt::UserRole)) {
            mCheckedTypes.insert(static_cast<QtMsgType>(item.toInt()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addedRelation : addedRelations) {
        auto item = new QStandardItem(QStringLiteral("%lld-%lld %s").arg(
                    QString::number(addedRelation.leftId),
                    QString::number(addedRelation.rightId),
                    addedRelation.type));
        relationsItem->appendRow(item);
    }
```

#### AUTO 


```{c}
const auto message = model->data(model->index(row, 0), DebugModel::MessageRole).value<DebugModel::Message>();
```

#### AUTO 


```{c}
auto h = new QHBoxLayout;
```

#### AUTO 


```{c}
auto button = new QPushButton(QStringLiteral("Save to file..."), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : qAsConst(selectedRows)) {
        rows.append(index.row());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inst : insts) {
            auto item = new QStandardItem;
            item->setText(inst.isEmpty() ? QStringLiteral("<global>") : inst);
            item->setData(inst, Qt::UserRole);
            model->appendRow(item);
        }
```

#### AUTO 


```{c}
auto *menu = new QMenu(this);
```

#### AUTO 


```{c}
auto dlg = qobject_cast<TagPropertiesDialog *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &items) {
        mCheckedCategories.clear();
        mCheckedCategories.reserve(items.count());
        for (const auto &item : items) {
            mCheckedCategories.insert(item);
        }
        if (!mInvalidateTimer.isActive()) {
            mInvalidateTimer.start();
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QString::number(tag.id()));
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto items = ntf.items();
```

#### AUTO 


```{c}
auto item = new QStandardItem(QStringLiteral("Relation"));
```

#### AUTO 


```{c}
const auto &items = ntf.items();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        auto i = new QStandardItem(QString::number(item->id()));
        populateItemTree(i, *item);
        itemsItem->appendRow(i);
    }
```

#### AUTO 


```{c}
auto query = static_cast<QueryNode *>(node);
```

#### AUTO 


```{c}
auto iter = mData.cbegin() + row;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &removedRid : qAsConst(mRemovedRIDs)) {
            query.addBindValue(removedRid);
        }
```

#### AUTO 


```{c}
auto model = qobject_cast<QStandardItemModel *>(m_ntfView->model());
```

#### AUTO 


```{c}
auto ancestorItem = new QStandardItem(QStringLiteral("Ancestor Fetch Scope"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &job : jobs) {
        infoList << d->infoList.value(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &store : stores) {
        mStoreCombo->addItem(store->types().last(), QVariant::fromValue(store));
    }
```

#### AUTO 


```{c}
const auto filename = QFileDialog::getSaveFileName(this, QStringLiteral("Save to File..."));
```

#### AUTO 


```{c}
const auto msg = m_data.at(index.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : contentUiItemFlags) {
        item.setFlag(s.toUtf8());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &identifer : mSenderCache.keys()) {
        bool found = false;
        for (const auto &msg : std::as_const(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
        if (!found) {
            toDelete.push_back(identifer);
        }
    }
```

#### AUTO 


```{c}
auto fetch = static_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *mWindow = new MainWindow;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &job : jobs) {
        const int pos = job.first;
        const int parentId = job.second;
        QModelIndex parentIdx;
        if (parentId != -1) {
            const int row = d->rowForParentId(parentId);
            if (row >= 0) {
                parentIdx = createIndex(row, 0, parentId);
            }
        }
        dataChanged(index(pos, 0, parentIdx), index(pos, 3, parentIdx));
    }
```

#### AUTO 


```{c}
auto dlg = new TagPropertiesDialog(tag, this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(QString::number(*it));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
                    rv.push_back(QString::number(item.id()));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QModelIndex &parent) {
        // rowsAboutToBeInserted is supposed to be emitted before the insert
        if (!parent.isValid()) {
            QCOMPARE(model.rowCount(), 0);
        } else {
            QCOMPARE(model.rowCount(parent), 0);
        }
    }
```

#### AUTO 


```{c}
auto it = doc.termlist_begin(), end = doc.termlist_end();
```

#### AUTO 


```{c}
auto filterModel = new LoggingFilterModel(this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(
            QStringLiteral("%lld-%lld %s").arg(QString::number(removedRelation.leftId), QString::number(removedRelation.rightId), removedRelation.type));
```

#### AUTO 


```{c}
auto con = static_cast<ConnectionNode *>(node);
```

#### AUTO 


```{c}
auto item = new QStandardItem(
            QStringLiteral("%lld-%lld %s").arg(QString::number(addedRelation.leftId), QString::number(addedRelation.rightId), addedRelation.type));
```

#### AUTO 


```{c}
const auto ridCount = QStringLiteral("SELECT COUNT(*) FROM PimItemTable WHERE collectionId=%1 AND remoteId=''").arg(coll.id());
```

#### AUTO 


```{c}
const auto session = mSessions.at(parent.row());
```

#### AUTO 


```{c}
auto *job = new AgentInstanceCreateJob(agentType, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : itemTags) {
        tags << QLatin1String(tag.gid());
    }
```

#### AUTO 


```{c}
auto relationsItem = new QStandardItem(QStringLiteral("Added Relations"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &_items) {
                Q_UNUSED(_items);
                const auto items = mSenderFilter->checkedItems(DebugModel::IdentifierRole);
                mCheckedSenders.clear();
                mCheckedSenders.reserve(items.count());
                for (const auto &item : items) {
                    mCheckedSenders.insert(item);
                }
                if (!mInvalidateTimer.isActive()) {
                    mInvalidateTimer.start();
                }
            }
```

#### AUTO 


```{c}
auto ntfModel = qobject_cast<QStandardItemModel*>(m_ntfView->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &res : std::as_const(mChangedRIDs)) {
                query.addBindValue(res);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &con : conns) {
            mQueryTree->addConnection(con.id, con.name, con.start);
            if (con.transactionStart > 0) {
                mQueryTree->addTransaction(con.id, con.transactionStart, 0, QString());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
                    mCheckedCategories.insert(item);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &agent : list) {
        agent.abortCurrentTask();
    }
```

#### AUTO 


```{c}
auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Close | QDialogButtonBox::Apply, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
            mCheckedSenders.insert(item);
        }
```

#### AUTO 


```{c}
auto *mainLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto mSelectColumn = w.findChild<QComboBox *>(QStringLiteral("selectcolumn"));
```

#### AUTO 


```{c}
auto identifier = str;
```

#### AUTO 


```{c}
const auto mail = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto sessionIdx = indexForSession(subscriber.sessionId());
```

#### AUTO 


```{c}
const auto cp = collection.cachePolicy();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &msg: qAsConst(mMessages)) {
            if (msg.sender == identifer) {
                found = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto mainLayout = w.findChild<QHBoxLayout *>(QStringLiteral("mainlayout"));
```

#### AUTO 


```{c}
const auto rightInc = rightItem.payload<IncidencePtr>();
```

#### AUTO 


```{c}
auto statsItem = new QStandardItem(QStringLiteral("Statistics"));
```

#### RANGE FOR STATEMENT 


```{c}
for (AgentInstance agent : list) {
            agent.synchronizeCollectionTree();
        }
```

#### AUTO 


```{c}
auto cb = new QCheckBox(QStringLiteral("Enable debugger"), this);
```

