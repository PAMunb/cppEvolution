#### RANGE FOR STATEMENT 


```{c}
for (const KMime::Types::Mailbox &mbox : mb) {
        stream << mbox.name() << mbox.addrSpec().localPart << mbox.addrSpec().domain;
    }
```

#### AUTO 


```{c}
auto m = item.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        auto ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        const auto items = ifj->items();
        for (const Item &item : items) {
            a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::ItemFetchJob(d->mFolders[d->mFolderListJobCount - 1], parent());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotEmptyTrash(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
```

#### AUTO 


```{c}
auto *isj = new ItemModifyJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        if (type.status() == Akonadi::AgentInstance::Broken) {
            continue;
        }
        if (type.identifier().contains(IMAP_RESOURCE_IDENTIFIER)) {
            OrgKdeAkonadiImapSettingsInterface *iface = Util::createImapSettingsInterface(type.identifier());
            if (iface->isValid()) {
                if (iface->trashCollection() == col.id()) {
                    delete iface;
                    return true;
                }
            }
            delete iface;
        }
    }
```

#### AUTO 


```{c}
auto *vcardTest = new TestVCard(vcarddir);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(collection, mParent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                    slotDeleteDone(job);
                }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemMoveJob(d->mMessages, d->mDestFolder, this);
```

#### AUTO 


```{c}
auto *mailDirTest = new TestMailDir(maildir);
```

#### AUTO 


```{c}
auto command = new MarkAsCommand(targetStatus, collections, invert, recursive, mParent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMime::Types::Mailbox &mbox : mb) {
        stream << mbox.name()
               << mbox.addrSpec().localPart
               << mbox.addrSpec().domain;
    }
```

#### AUTO 


```{c}
auto *ifj = new ItemFetchJob(collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &instance : std::as_const(instances)) {
        QVERIFY(!types.contains(instance.type()));
    }
```

#### AUTO 


```{c}
const auto items = ifj->items();
```

#### AUTO 


```{c}
const auto msg = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto *job = new AgentInstanceCreateJob(type);
```

#### AUTO 


```{c}
auto *idj = new ItemDeleteJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list4) {
        auto ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        const auto items = ifj->items();
        for (const Item &item : items) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                auto idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotMarkAllAs(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
        const QByteArray &upperedFlag = flag.toUpper();
        if (upperedFlag == Akonadi::MessageFlags::Deleted) {
            setDeleted();
        } else if (upperedFlag == Akonadi::MessageFlags::Seen) {
            setRead();
        } else if (upperedFlag == Akonadi::MessageFlags::Answered) {
            setReplied();
        } else if (upperedFlag == Akonadi::MessageFlags::Flagged) {
            setImportant();

            // non standard flags
        } else if (upperedFlag == Akonadi::MessageFlags::Sent) {
            setSent();
        } else if (upperedFlag == Akonadi::MessageFlags::Queued) {
            setQueued();
        } else if (upperedFlag == Akonadi::MessageFlags::Replied) {
            setReplied();
        } else if (upperedFlag == Akonadi::MessageFlags::Forwarded) {
            setForwarded();
        } else if (upperedFlag == Akonadi::MessageFlags::ToAct) {
            setToAct();
        } else if (upperedFlag == Akonadi::MessageFlags::Watched) {
            setWatched();
        } else if (upperedFlag == Akonadi::MessageFlags::Ignored) {
            setIgnored();
        } else if (upperedFlag == Akonadi::MessageFlags::HasAttachment) {
            setHasAttachment();
        } else if (upperedFlag == Akonadi::MessageFlags::HasInvitation) {
            setHasInvitation();
        } else if (upperedFlag == Akonadi::MessageFlags::Signed) {
            setSigned();
        } else if (upperedFlag == Akonadi::MessageFlags::Encrypted) {
            setEncrypted();
        } else if (upperedFlag == Akonadi::MessageFlags::Spam) {
            setSpam();
        } else if (upperedFlag == Akonadi::MessageFlags::Ham) {
            setHam();
        } else if (upperedFlag == Akonadi::MessageFlags::HasError) {
            setHasError();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotMoveToTrash();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotRemoveDuplicates(); }
```

#### AUTO 


```{c}
auto clj = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
            if (type.identifier().contains(IMAP_RESOURCE_IDENTIFIER)) {
                if (type.status() == Akonadi::AgentInstance::Broken) {
                    continue;
                }
                OrgKdeAkonadiImapSettingsInterface *iface = Util::createImapSettingsInterface(type.identifier());
                if (iface->isValid()) {
                    const int trashImap = iface->trashCollection();
                    if (trashImap != trash.id()) {
                        trashFolder << Akonadi::Collection(trashImap);
                    }
                }
                delete iface;
            }
        }
```

#### AUTO 


```{c}
auto *fjob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto msg = item.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        auto *ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        const auto items = ifj->items();
        for (const Item &item : items) {
            a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotEmptyTrash();
        }
```

#### AUTO 


```{c}
auto *attr = new Pop3ResourceAttribute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : std::as_const(selectedCollections)) {
                if (collection.isValid()) {
                    const Akonadi::CollectionStatistics stats = collection.statistics();
                    if (!enableMarkAllAsRead) {
                        enableMarkAllAsRead = (stats.unreadCount() > 0);
                    }
                    if (!enableMarkAllAsUnread) {
                        enableMarkAllAsUnread = (stats.count() != stats.unreadCount());
                    }
                    if (canDeleteItem) {
                        canDeleteItem = collection.rights() & Akonadi::Collection::CanDeleteItem;
                    }
                    if (!isSystemFolder) {
                        isSystemFolder = (collection == SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::Inbox)
                                          || collection == SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::Outbox)
                                          || collection == SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::SentMail)
                                          || collection == SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::Trash)
                                          || collection == SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::Drafts)
                                          || collection == SpecialMailCollections::self()->defaultCollection(SpecialMailCollections::Templates));
                    }
                    // We will not change after that.
                    if (enableMarkAllAsRead && enableMarkAllAsUnread && !canDeleteItem && isSystemFolder) {
                        break;
                    }
                }
            }
```

#### AUTO 


```{c}
auto attr = new Pop3ResourceAttribute();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotEmptyAllTrash(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Collection::List &selectedCollections, const Collection::List &selectedFavoriteCollections, const Item::List &selectedItems) {
                // Optimization: pass along the lists to avoid recalculating them here
                updateActions(selectedCollections, selectedFavoriteCollections, selectedItems);
            }
```

#### AUTO 


```{c}
auto delCmd = new Akonadi::ItemDeleteJob(mDuplicateItems, mParent);
```

#### AUTO 


```{c}
auto command = new EmptyTrashCommand(const_cast<QAbstractItemModel *>(mCollectionSelectionModel->model()), mParent);
```

#### AUTO 


```{c}
auto idj = new ItemDeleteJob(item, this);
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::ItemModifyJob(listElement, this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(d->mMessages, this);
```

#### AUTO 


```{c}
auto rjob = new SpecialMailCollectionsRequestJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : selectedItems) {
                Akonadi::MessageStatus status;
                status.setStatusFromFlags(item.flags());
                if (!status.isImportant()) {
                    allMarkedAsImportant = false;
                }
                if (!status.isRead()) {
                    allMarkedAsRead = false;
                } else {
                    allMarkedAsUnread = false;
                }
                if (!status.isToAct()) {
                    allMarkedAsActionItem = false;
                }
            }
```

#### AUTO 


```{c}
auto *attr = new NewMailNotifierAttribute();
```

#### AUTO 


```{c}
auto job = new RemoveDuplicatesJob(collections, mParent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &instance : std::as_const(instances)) {
        if (types.contains(instance.type())) {
            qDebug() << "Removing instance of type" << instance.type().identifier();
            AgentManager::self()->removeInstance(instance);
            QSignalSpy removedSpy(AgentManager::self(), SIGNAL(instanceRemoved(Akonadi::AgentInstance)));
            QVERIFY(removedSpy.wait());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list3) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        foreach (const Item &item, ifj->items()) {
            // filter read messages
            if (!item.hasFlag("\\SEEN")) {
                a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        const auto items = ifj->items();
        for (const Item &item : items) {
            a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        foreach (const Item &item, ifj->items()) {
            a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(d->mFolders.constFirst());
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobDelete]() {
            if (jobDelete->error()) {
                Util::showJobError(jobDelete);
                emitResult(Failed);
            }
            emitResult(OK);
        }
```

#### AUTO 


```{c}
auto clj4 = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto *kiojob = qobject_cast<KIO::Job *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &instance : qAsConst(instances)) {
        QVERIFY(!types.contains(instance.type()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            // filter read messages
            if (!item.hasFlag("\\SEEN")) {
                a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        Akonadi::MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (d->mInvertMark) {
            if (status & d->mTargetStatus) {
                d->mMessages.append(item);
            }
        } else if (!(status & d->mTargetStatus)) {
            d->mMessages.append(item);
        }
    }
```

#### AUTO 


```{c}
auto configIface = new QDBusInterface(QLatin1String("org.freedesktop.Akonadi.Resource.") + currentInstance.identifier(),
                                          QStringLiteral("/Settings"),
                                          QLatin1String("org.kde.Akonadi.") + name + QLatin1String(".Settings"),
                                          QDBusConnection::sessionBus(),
                                          this);
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::ItemModifyJob(itemsToModify, this);
```

#### AUTO 


```{c}
auto s = msg->from(false)
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(mFolders[mFolderListJobCount - 1], parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list4) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        const auto items = ifj->items();
        for (const Item &item : items) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                ItemDeleteJob *idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
    }
```

#### AUTO 


```{c}
auto m = new Message;
```

#### AUTO 


```{c}
auto *m = new Message;
```

#### AUTO 


```{c}
auto s = msg->to(false)
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list2) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        Item::List itemlist = ifj->items();
        for (int i = ifj->items().count() - 1; i >= 0; i -= 5) {
            Item item = itemlist[i];
            item.setFlag("\\SEEN");
            ItemModifyJob *isj = new ItemModifyJob(item, this);
            isj->exec();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            qDebug() << item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
```

#### AUTO 


```{c}
auto fjob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
        const QByteArray &upperedFlag = flag.toUpper();
        if (upperedFlag ==  Akonadi::MessageFlags::Deleted) {
            setDeleted();
        } else if (upperedFlag == Akonadi::MessageFlags::Seen) {
            setRead();
        } else if (upperedFlag == Akonadi::MessageFlags::Answered) {
            setReplied();
        } else if (upperedFlag == Akonadi::MessageFlags::Flagged) {
            setImportant();

            // non standard flags
        } else if (upperedFlag == Akonadi::MessageFlags::Sent) {
            setSent();
        } else if (upperedFlag == Akonadi::MessageFlags::Queued) {
            setQueued();
        } else if (upperedFlag == Akonadi::MessageFlags::Replied) {
            setReplied();
        } else if (upperedFlag == Akonadi::MessageFlags::Forwarded) {
            setForwarded();
        } else if (upperedFlag == Akonadi::MessageFlags::ToAct) {
            setToAct();
        } else if (upperedFlag == Akonadi::MessageFlags::Watched) {
            setWatched();
        } else if (upperedFlag == Akonadi::MessageFlags::Ignored) {
            setIgnored();
        } else if (upperedFlag ==  Akonadi::MessageFlags::HasAttachment) {
            setHasAttachment();
        } else if (upperedFlag ==  Akonadi::MessageFlags::HasInvitation) {
            setHasInvitation();
        } else if (upperedFlag == Akonadi::MessageFlags::Signed) {
            setSigned();
        } else if (upperedFlag == Akonadi::MessageFlags::Encrypted) {
            setEncrypted();
        } else if (upperedFlag == Akonadi::MessageFlags::Spam) {
            setSpam();
        } else if (upperedFlag == Akonadi::MessageFlags::Ham) {
            setHam();
        } else if (upperedFlag == Akonadi::MessageFlags::HasError) {
            setHasError();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotRemoveDuplicates();
        }
```

#### AUTO 


```{c}
auto job = new AgentInstanceCreateJob(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list3) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        const auto items = ifj->items();
        for (const Item &item : items) {
            // filter read messages
            if (!item.hasFlag("\\SEEN")) {
                a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
            }
        }
    }
```

#### AUTO 


```{c}
auto *serializer = new SerializerPluginMail();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
            if (type.identifier().contains(IMAP_RESOURCE_IDENTIFIER)) {
                if (type.status() == Akonadi::AgentInstance::Broken) {
                    continue;
                }
                QScopedPointer<OrgKdeAkonadiImapSettingsInterface> iface{Util::createImapSettingsInterface(type.identifier())};
                if (iface->isValid()) {
                    const int trashImap = iface->trashCollection();
                    if (trashImap != trash.id()) {
                        trashFolder << Akonadi::Collection(trashImap);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto helper = new Akonadi::MarkAsCommandHelper(this);
```

#### AUTO 


```{c}
auto cdj = new CollectionDeleteJob(collection, this);
```

#### AUTO 


```{c}
auto mailDirTest = new TestMailDir(maildir);
```

#### AUTO 


```{c}
auto serializer = new SerializerPluginMail();
```

#### AUTO 


```{c}
auto attr = new NewMailNotifierAttribute();
```

#### AUTO 


```{c}
auto command = new MoveToTrashCommand(mCollectionSelectionModel->model(), items, mParent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : instances) {
        if (instance.type().mimeTypes().contains(KMime::Message::mimeType())
            && instance.type().capabilities().contains(QLatin1String("Resource"))
            && !instance.type().capabilities().contains(QLatin1String("Virtual"))) {
            relevantInstances << instance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        if (multipart) {
            ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        } else {
            ifj->fetchScope().fetchFullPayload();
        }
        ifj->exec();
        qDebug() << "  Listing" << ifj->items().count() << "item headers.";
        foreach (const Item &item, ifj->items()) {
            qDebug() << item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### AUTO 


```{c}
auto clj2 = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto s = msg->date(false)
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list2) {
        auto *ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        Item::List itemlist = ifj->items();
        for (int i = ifj->items().count() - 1; i >= 0; i -= 5) {
            Item item = itemlist[i];
            item.setFlag("\\SEEN");
            auto *isj = new ItemModifyJob(item, this);
            isj->exec();
        }
    }
```

#### AUTO 


```{c}
auto *rjob = new SpecialMailCollectionsRequestJob(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemMoveJob(d->mMessages, d->mDestFolder, this);
```

#### AUTO 


```{c}
auto message = item.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list3) {
        auto ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        const auto items = ifj->items();
        for (const Item &item : items) {
            // filter read messages
            if (!item.hasFlag("\\SEEN")) {
                a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
            }
        }
    }
```

#### AUTO 


```{c}
auto jobDelete = new Akonadi::ItemDeleteJob(col, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : std::as_const(d->mMessages)) {
        Akonadi::Item item(it);

        // be careful to only change the flags we want to change, not to overwrite them
        // otherwise ItemModifyJob will not do what we expect
        if (d->mInvertMark) {
            if (item.hasFlag(flag)) {
                item.clearFlag(flag);
                itemsToModify.push_back(item);
            }
        } else {
            if (!item.hasFlag(flag)) {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotMarkAs(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        if (multipart) {
            ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        } else {
            ifj->fetchScope().fetchFullPayload();
        }
        ifj->exec();
        qDebug() << "  Listing" << ifj->items().count() << "item headers.";
        const auto items = ifj->items();
        for (const Item &item : items) {
            qDebug() << item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### AUTO 


```{c}
auto *msg = new Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                auto idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
```

#### AUTO 


```{c}
auto kiojob = qobject_cast<KIO::Job *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateActions(); }
```

#### AUTO 


```{c}
auto command = new MoveToTrashCommand(mCollectionSelectionModel->model(), collections, mParent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : instances) {
        if (instance.type().mimeTypes().contains(KMime::Message::mimeType())
            && instance.type().capabilities().contains(QStringLiteral("Resource"))
            && !instance.type().capabilities().contains(QStringLiteral("Virtual"))) {
            relevantInstances << instance;
        }
    }
```

#### AUTO 


```{c}
auto moveCommand = new MoveCommand(findTrashFolder(folder), mMessages, this);
```

#### AUTO 


```{c}
auto *modifyJob = new Akonadi::ItemModifyJob(itemsToModify, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &type : lst) {
        if (type.status() == Akonadi::AgentInstance::Broken) {
            continue;
        }
        if (type.identifier().contains(IMAP_RESOURCE_IDENTIFIER)) {
            QScopedPointer<OrgKdeAkonadiImapSettingsInterface> iface{Util::createImapSettingsInterface(type.identifier())};
            if (iface->isValid()) {
                if (iface->trashCollection() == col.id()) {
                    return true;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list4) {
        auto *ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        const auto items = ifj->items();
        for (const Item &item : items) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                auto *idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
    }
```

#### AUTO 


```{c}
auto configIface = new QDBusInterface(QLatin1String("org.freedesktop.Akonadi.Resource.") + currentInstance.identifier(),
                                                     QStringLiteral("/Settings"), QLatin1String("org.kde.Akonadi.") + name + QLatin1String(".Settings"), QDBusConnection::sessionBus(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance &instance : qAsConst(instances)) {
        if (types.contains(instance.type())) {
            qDebug() << "Removing instance of type" << instance.type().identifier();
            AgentManager::self()->removeInstance(instance);
            QSignalSpy removedSpy(AgentManager::self(), SIGNAL(instanceRemoved(Akonadi::AgentInstance)));
            QVERIFY(removedSpy.wait());
        }
    }
```

#### AUTO 


```{c}
auto msg = new Message();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(d->mFolders[d->mFolderListJobCount - 1], parent());
```

#### AUTO 


```{c}
auto *fjob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto clj5 = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto listElement = mItemsToModify.mid(mIndex, qMin(mIndex + sNumberMaxElement, mItemsToModify.count()));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotMoveToTrash(); }
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::ItemFetchJob(mFolders[mFolderListJobCount - 1], parent());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            slotJobFinished(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list5) {
        auto *cdj = new CollectionDeleteJob(collection, this);
        cdj->exec();
    }
```

#### AUTO 


```{c}
auto msg = i.payload<KMime::Message::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                ItemDeleteJob *idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        auto ifj = new ItemFetchJob(collection, this);
        if (multipart) {
            ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        } else {
            ifj->fetchScope().fetchFullPayload();
        }
        ifj->exec();
        qDebug() << "  Listing" << ifj->items().count() << "item headers.";
        const auto items = ifj->items();
        for (const Item &item : items) {
            qDebug() << item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            slotFetchDone(job);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotMoveAllToTrash();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list2) {
        auto ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        Item::List itemlist = ifj->items();
        for (int i = ifj->items().count() - 1; i >= 0; i -= 5) {
            Item item = itemlist[i];
            item.setFlag("\\SEEN");
            auto isj = new ItemModifyJob(item, this);
            isj->exec();
        }
    }
```

#### AUTO 


```{c}
auto command = new EmptyTrashCommand(collections.first(), mParent);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemDeleteJob(d->mMessages, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotMarkAllAs();}
```

#### AUTO 


```{c}
auto ifj = new ItemFetchJob(collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                auto *idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
```

#### AUTO 


```{c}
auto *cdj = new CollectionDeleteJob(collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : qAsConst(d->mMessages)) {
        Akonadi::Item item(it);

        // be careful to only change the flags we want to change, not to overwrite them
        // otherwise ItemModifyJob will not do what we expect
        if (d->mInvertMark) {
            if (item.hasFlag(flag)) {
                item.clearFlag(flag);
                itemsToModify.push_back(item);
            }
        } else {
            if (!item.hasFlag(flag)) {
                item.setFlag(flag);
                itemsToModify.push_back(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(collection, this);
```

#### AUTO 


```{c}
auto vcardTest = new TestVCard(vcarddir);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list5) {
        auto cdj = new CollectionDeleteJob(collection, this);
        cdj->exec();
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(mFolders[mFolderListJobCount - 1], parent());
```

#### AUTO 


```{c}
auto command = new MarkAsCommand(targetStatus, items, invert, mParent);
```

#### AUTO 


```{c}
auto m = new Message();
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(collection, this);
```

#### AUTO 


```{c}
auto *m = new  Message();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list) {
        auto *ifj = new ItemFetchJob(collection, this);
        if (multipart) {
            ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        } else {
            ifj->fetchScope().fetchFullPayload();
        }
        ifj->exec();
        qDebug() << "  Listing" << ifj->items().count() << "item headers.";
        const auto items = ifj->items();
        for (const Item &item : items) {
            qDebug() << item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : instances) {
        if (instance.type().mimeTypes().contains(KMime::Message::mimeType()) && instance.type().capabilities().contains(QLatin1String("Resource"))
            && !instance.type().capabilities().contains(QLatin1String("Virtual"))) {
            relevantInstances << instance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list5) {
        CollectionDeleteJob *cdj = new CollectionDeleteJob(collection, this);
        cdj->exec();
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(d->mFolders[d->mFolderListJobCount - 1], parent());
```

#### AUTO 


```{c}
const auto instances = Akonadi::AgentManager::self()->instances();
```

#### AUTO 


```{c}
auto isj = new ItemModifyJob(item, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotMoveAllToTrash(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotMarkAs();
        }
```

#### AUTO 


```{c}
auto *jobDelete = new Akonadi::ItemDeleteJob(col, this);
```

#### AUTO 


```{c}
auto s = msg->subject(false)
```

#### AUTO 


```{c}
const auto items = fjob->items();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateActions();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, jobDelete]() {
                    if (jobDelete->error()) {
                        Util::showJobError(jobDelete);
                        emitResult(Failed);
                    }
                    emitResult(OK);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotEmptyAllTrash();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list3) {
        auto *ifj = new ItemFetchJob(collection, this);
        ifj->fetchScope().fetchPayloadPart(MessagePart::Envelope);
        ifj->exec();
        QString a;
        const auto items = ifj->items();
        for (const Item &item : items) {
            // filter read messages
            if (!item.hasFlag("\\SEEN")) {
                a = item.payload<KMime::Message::Ptr>()->subject()->asUnicodeString();
            }
        }
    }
```

#### AUTO 


```{c}
auto clj3 = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto fjob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : list4) {
        ItemFetchJob *ifj = new ItemFetchJob(collection, this);
        ifj->exec();
        foreach (const Item &item, ifj->items()) {
            // delete read messages
            if (item.hasFlag("\\SEEN")) {
                ItemDeleteJob *idj = new ItemDeleteJob(item, this);
                idj->exec();
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionFetchJob(d->mFolders.constFirst());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotMarkAllAs();
        }
```

