#### RANGE FOR STATEMENT 


```{c}
for (bitmap *characterBitmap : characterBitmaps) {
        delete characterBitmap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields)) {
        if (f->type() == oldField->type() && qFuzzyCompare(f->rect().left, oldField->rect().left) && qFuzzyCompare(f->rect().top, oldField->rect().top) && qFuzzyCompare(f->rect().right, oldField->rect().right) &&
            qFuzzyCompare(f->rect().bottom, oldField->rect().bottom)) {
            return f;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &proxyIndex : proxyIndexes) {
        if (!isAuthorItem(proxyIndex)) {
            sourceSelection << QItemSelectionRange(mapToSource(proxyIndex));
        }
    }
```

#### AUTO 


```{c}
auto fingerprintFormLayout = new QFormLayout(fingerprintBox);
```

#### RANGE FOR STATEMENT 


```{c}
for ( QToolButton *button : qAsConst(m_buttons) )
        if ( button )
        {
            button->menu()->addAction( action );
            if ( setDefault )
                button->setDefaultAction( action );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Okular::Action *action, Okular::FormFieldText *fft ) {
                          document->processFocusAction( action, fft );
                          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& file: files)
     {
         shell->openUrl( file );
     }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Okular::FormField *form) {
        Okular::FormFieldText *fft = reinterpret_cast<Okular::FormFieldText *>(form);
        if (fft)
            m_formattedText = fft->text();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toolXml : items) {
        QDomDocument entryParser;
        if (!entryParser.setContent(toolXml)) {
            qWarning() << "Skipping malformed tool XML string";
            break;
        }

        QDomElement toolElement = entryParser.documentElement();
        if (toolElement.tagName() == QLatin1String("tool")) {
            // Create list item and attach the source XML string as data
            QString itemText = toolElement.attribute(QStringLiteral("name"));
            if (itemText.isEmpty()) {
                itemText = PageViewAnnotator::defaultToolName(toolElement);
            }
            QListWidgetItem *listEntry = new QListWidgetItem(itemText, m_list);
            listEntry->setData(ToolXmlRole, QVariant::fromValue(toolXml));
            listEntry->setIcon(PageViewAnnotator::makeToolPixmap(toolElement));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
                if (!item->isVisible())
                    continue;

                const QRect &itemRect = item->croppedGeometry();
                if (selectionRect.intersects(itemRect)) {
                    // request the textpage if there isn't one
                    okularPage = item->page();
                    qCDebug(OkularUiDebug) << "checking if page" << item->pageNumber() << "has text:" << okularPage->hasTextPage();
                    if (!okularPage->hasTextPage())
                        d->document->requestTextPage(okularPage->number());
                    // grab text in the rect that intersects itemRect
                    QRect relativeRect = selectionRect.intersected(itemRect);
                    relativeRect.translate(-item->uncroppedGeometry().topLeft());
                    Okular::RegularAreaRect rects;
                    rects.append(Okular::NormalizedRect(relativeRect, item->uncroppedWidth(), item->uncroppedHeight()));
                    selectedText += okularPage->text(&rects);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const KBookmark &bm : bmarks )
    {
        DocumentViewport vp( bm.url().fragment(QUrl::FullyDecoded) );
        if ( vp.isValid() && vp.pageNumber == page )
        {
            return bm;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : quickToolActions) {
        if (action->isCheckable()) {
            aQuickTools->removeAction(action);
            delete action;
        }
    }
```

#### AUTO 


```{c}
const auto &toolbar
```

#### LAMBDA EXPRESSION 


```{c}
[this, req] { d->document->refreshPixmaps(req); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(paths))
            {
                QVERIFY(openUrls.contains(QStringLiteral("file://%1").arg(path)));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if (m_sidebar->currentItem() != m_signaturePanel) {
            m_sidebar->setCurrentItem(m_signaturePanel);
        }
        m_showLeftPanel->setChecked(true);
        slotShowLeftPanel();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, searchText]{Q_EMIT triggerSearch(searchText);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldSignature *signature : signatureFormFields) {
                    const Okular::SignatureInfo &info = signature->signatureInfo();
                    if (info.signatureStatus() != SignatureInfo::SignatureValid) {
                        allSignaturesValid = false;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
        QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
        selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
        // should check whether this is on-screen here?
        updatedRect = updatedRect.united(selectionPartRect);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TileNode &tile : d->tiles) {
        d->rankTiles(tile, rankedTiles, visibleRect, visiblePageNumber);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::OutlineItem &outlineItem : outlineItems) {
        QDomElement item = docSyn.createElement(outlineItem.name());
        parentDestination->appendChild(item);

        item.setAttribute(QStringLiteral("ExternalFileName"), outlineItem.externalFileName());
        const QSharedPointer<const Poppler::LinkDestination> outlineDestination = outlineItem.destination();
        if (outlineDestination) {
            const QString destinationName = outlineDestination->destinationName();
            if (!destinationName.isEmpty()) {
                item.setAttribute(QStringLiteral("ViewportName"), destinationName);
            } else {
                Okular::DocumentViewport vp;
                fillViewportFromLinkDestination(vp, *outlineDestination);
                item.setAttribute(QStringLiteral("Viewport"), vp.toString());
            }
        }
        item.setAttribute(QStringLiteral("Open"), outlineItem.isOpen());
        item.setAttribute(QStringLiteral("URL"), outlineItem.uri());

        if (outlineItem.hasChildren()) {
            addSynopsisChildren(outlineItem.children(), &item);
        }
    }
```

#### AUTO 


```{c}
auto *parentItem = new SignatureItem( root, sf, SignatureItem::RevisionInfo, currentPage );
```

#### RANGE FOR STATEMENT 


```{c}
for (RegularAreaRect *match : it.value()) {
                it.key()->d->setHighlight(searchID, match, search->cachedColor);
                delete match;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Okular::Action *action, Okular::FormFieldText *fft, bool &ok) { document->processKeystrokeAction(action, fft, ok); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedPoint &p : annotPoints) {
        points.append(normPointToPointF(p));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page * page : pageVector)
    {
        if (!page->label().isEmpty())
        {
            if (page->label().toInt() != (page->number() + 1))
            {
                labelsDiffer = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double row : qAsConst(d->tableSelectionRows)) {
                    if (row >= tsp.rectInSelection.top && row <= tsp.rectInSelection.bottom) {
                        row = (row - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                        const int y =  selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                        screenPainter->drawLine(
                            selectionPartRectInternal.left(), y,
                            selectionPartRectInternal.left() + selectionPartRectInternal.width(), y
                        );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
    {
        if (md.rawData()[QStringLiteral("X-KDE-okularHasInternalSettings")].toBool())
        {
            result << md;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MatchColor &mc : matches) {
                delete mc.first;
            }
```

#### AUTO 


```{c}
auto showBtn = m_fields[QStringLiteral( "ShowActionButton" )];
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex &oldIndex : qAsConst(d->m_oldTocExpandedIndexes) )
        {
            const QModelIndex index = indexForIndex( oldIndex, this );
            if ( !index.isValid() )
                continue;

            // TODO misusing parent() here, fix
            QMetaObject::invokeMethod( QObject::parent(), "expand", Qt::QueuedConnection, Q_ARG( QModelIndex, index ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField * ff : pageFields )
        {
            FormWidgetIface * w = FormWidgetFactory::createWidget( ff, viewport() );
            if ( w )
            {
                w->setPageItem( item );
                w->setFormWidgetsController( d->formWidgetsController() );
                w->setVisibility( false );
                w->setCanBeFilled( allowfillforms );
                item->formWidgets().insert( w );
                hasformwidgets = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : qAsConst(m_frames[previousPage]->videoWidgets)) {
            vw->stop();
            vw->pageLeft();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->aToolBarVisibility->setChecked(false); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( TileNode &tile : d->tiles )
    {
        d->tilesAt( rotatedRect, tile, result, tileLeaf );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<NormalizedPoint> &path : m_transformedInkPaths) {
        const double thisDistance = ::distanceSqr(x, y, xScale, yScale, path);
        if (thisDistance < distance) {
            distance = thisDistance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Document &doc : qAsConst(minDocs)) {
		fileName =  docList[ (int)doc.docNumber ];
		if ( searchForPhrases( termSeq, seqWords, fileName, chmFile ) )
			results << fileName;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : childrenNumberAndMoreStuff) {
          if (c.isDigit()) ++indexOfFirstNonDigit;
          else break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *fwi : qAsConst(m_formWidgets)) {
        fwi->setVisibility(fwi->formField()->isVisible() && FormWidgetsController::shouldFormWidgetBeShown(fwi->formField()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->aShowToolBar->setChecked(false); }
```

#### AUTO 


```{c}
const auto symbolSize = style()->pixelMetric(QStyle::PM_SmallIconSize);
```

#### AUTO 


```{c}
auto connectionId = connect( this, &Document::aboutToClose, [&executeNextActions] { executeNextActions = false; } );
```

#### AUTO 


```{c}
auto widget = win2->window()->childAt(win2->mapTo(win2->window(), QPoint(10, 10)));
```

#### LAMBDA EXPRESSION 


```{c}
[=](){ doc->executeScript( function ); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect &r : geom )
                        {
                            if ( newrect.isNull() )
                                newrect = r;
                            else
                                newrect |= r;
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : paths) {
        // Copy stdin to temporary file which can be opened by the existing
        // window. The temp file is automatically deleted after it has been
        // opened. Not sure if this behavior is safe on all platforms.
        QScopedPointer<QTemporaryFile> tempFile;
        QString path;
        if (arg == QLatin1String("-")) {
            tempFile.reset(new QTemporaryFile);
            QFile stdinFile;
            if (!tempFile->open() || !stdinFile.open(stdin, QIODevice::ReadOnly))
                return false;

            const size_t bufSize = 1024 * 1024;
            QScopedPointer<char, QScopedPointerArrayDeleter<char>> buf(new char[bufSize]);
            size_t bytes;
            do {
                bytes = stdinFile.read(buf.data(), bufSize);
                tempFile->write(buf.data(), bytes);
            } while (bytes != 0);

            path = tempFile->fileName();
        } else {
            // Page only makes sense if we are opening one file
            const QString page = ShellUtils::page(serializedOptions);
            path = ShellUtils::urlFromArg(arg, ShellUtils::qfileExistFunc(), page).url();
        }

        // Returns false if it can't fit another document
        const QDBusReply<bool> reply = bestService->call(QStringLiteral("openDocument"), path, serializedOptions);
        if (!reply.isValid() || !reply.value())
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int req : qAsConst(d->refreshPages))
    {
        QTimer::singleShot(0, this, [this, req] { d->document->refreshPixmaps(req); });
    }
```

#### AUTO 


```{c}
auto m_editor = new QLabel(editStr, this);
```

#### LAMBDA EXPRESSION 


```{c}
[] (QQmlEngine*, QJSEngine*) -> QObject* { return new OkularSingleton; }
```

#### RANGE FOR STATEMENT 


```{c}
for (MiniBar *miniBar : qAsConst(m_miniBars)) {
        // resize width of widgets
        miniBar->resizeForPage(pages);

        // update child widgets
        miniBar->m_pageLabelEdit->setPageLabels(pageVector);
        miniBar->m_pageNumberEdit->setPagesNumber(pages);
        miniBar->m_pagesButton->setText(pagesString);
        miniBar->m_prevButton->setEnabled(false);
        miniBar->m_nextButton->setEnabled(false);
        miniBar->m_pageLabelEdit->setVisible(labelsDiffer);
        miniBar->m_pageNumberLabel->setVisible(labelsDiffer);
        miniBar->m_pageNumberEdit->setVisible(!labelsDiffer);

        miniBar->adjustSize();

        miniBar->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto exportBtn = new QPushButton( i18n("Export...") );
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * item : qAsConst( d->visibleItems ) )
        {
            item->reloadFormWidgetsState();
        }
```

#### AUTO 


```{c}
auto itToolBar = std::find_if(toolbars.begin(), toolbars.end(), [](const KToolBar *toolBar) { return toolBar->objectName() == QStringLiteral("annotationToolBar"); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageVector) {
        if (!page->label().isEmpty()) {
            if (page->label().toInt() != (page->number() + 1)) {
                labelsDiffer = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers))
        if (o != excludeObserver)
            o->notifyZoom(factor);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &oldIndex : qAsConst(d->m_oldTocExpandedIndexes)) {
            const QModelIndex index = indexForIndex(oldIndex, this);
            if (!index.isValid()) {
                continue;
            }

            // TODO misusing parent() here, fix
            QMetaObject::invokeMethod(QObject::parent(), "expand", Qt::QueuedConnection, Q_ARG(QModelIndex, index));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: page->formFields() )
    {
        fields.insert( ff->name(), static_cast< Okular::FormField* >( ff ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
                doRemovePageAnnotation(pair);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QPointer< QToolButton > &button : qAsConst( m_buttons ) )
    {
        if ( button )
        {
            button->setDefaultAction( defaultAction() );

            // Override some properties of the default action,
            // where the property of this menu makes more sense.
            button->setEnabled( isEnabled() );

            if ( delayed() )
            {
                button->setPopupMode( QToolButton::DelayedPopup );
            }
            else if ( stickyMenu() )
            {
                button->setPopupMode( QToolButton::InstantPopup );
            }
            else
            {
                button->setPopupMode( QToolButton::MenuButtonPopup );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect &r : pe->region() )
    {
        if ( !r.isValid() )
            continue;
#ifdef ENABLE_PROGRESS_OVERLAY
        const QRect dR(QRectF(r.x() * dpr, r.y() * dpr, r.width() * dpr, r.height() * dpr).toAlignedRect());
        if ( Okular::Settings::slidesShowProgress() && r.intersects( m_overlayGeometry ) )
        {
            // backbuffer the overlay operation
            QPixmap backPixmap( dR.size() );
            backPixmap.setDevicePixelRatio( dpr );
            QPainter pixPainter( &backPixmap );

            // first draw the background on the backbuffer
            pixPainter.drawPixmap( QPoint(0,0), m_lastRenderedPixmap, dR );

            // then blend the overlay (a piece of) over the background
            QRect ovr = m_overlayGeometry.intersected( r );
            pixPainter.drawPixmap( (ovr.left() - r.left()), (ovr.top() - r.top()),
                m_lastRenderedOverlay, (ovr.left() - m_overlayGeometry.left()) * dpr,
                (ovr.top() - m_overlayGeometry.top()) * dpr, ovr.width() * dpr, ovr.height() * dpr );

            // finally blit the pixmap to the screen
            pixPainter.end();
            const QRect backPixmapRect = backPixmap.rect();
            const QRect dBackPixmapRect(QRectF(backPixmapRect.x() * dpr, backPixmapRect.y() * dpr, backPixmapRect.width() * dpr, backPixmapRect.height() * dpr).toAlignedRect());
            painter.drawPixmap( r.topLeft(), backPixmap, dBackPixmapRect );
        } else
#endif
        // copy the rendered pixmap to the screen
        painter.drawPixmap( r.topLeft(), m_lastRenderedPixmap, dR );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (d->aViewContinuous && !d->document->isOpened()) {
            d->aViewContinuous->setChecked(Okular::Settings::viewContinuous());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->currentPage)) {
        QModelIndex index = d->indexForItem(item);
        if (!index.isValid()) {
            continue;
        }

        item->highlight = true;
        Q_EMIT dataChanged(index, index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->currentPage)) {
        QModelIndex index = d->indexForItem(item);
        if (!index.isValid())
            continue;

        item->highlight = true;
        emit dataChanged(index, index);
    }
```

#### AUTO 


```{c}
auto dpr = devicePixelRatioF();
```

#### AUTO 


```{c}
auto cbMakeRO = dynamic_cast<Okular::FormFieldButton *>(fields[QStringLiteral("CBMakeRO")]);
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction* action : d->aViewMode->menu()->actions() ) {
        QVariant mode_id = action->data();
        if (mode_id.toInt() == nr) {
            action->trigger();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &stamp : StampAnnotationWidget::defaultStamps()) {
        KToggleAction *ann = new KToggleAction(d->stampIcon(stamp.second), stamp.first, this);
        d->aStamp->addAction(ann);
        d->agTools->addAction(ann);
        // action group workaround: connecting to toggled instead of triggered
        // (because deselectAllAnnotationActions has to call triggered)
        connect(ann, &QAction::toggled, this, [this, stamp](bool checked) {
            if (checked)
                d->slotStampToolSelected(stamp.second);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
        if (screen->geometry().contains(cursorPos)) {
            s_lastScreen = screen;
            return screen;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &supported : mimetypes) {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type && !exactMatches.contains(md)) {
                exactMatches << md;
            }

            if (type.inherits(supported) && !offers.contains(md)) {
                offers << md;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &mimeName: mimeTypes) {
            for (const auto &suffix: md.mimeTypeForName(mimeName).suffixes())
                supportedPatterns += QStringLiteral("*.") + suffix;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Action *a : additionalActions) {
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &entry : mainDirEntries )
    {
        if ( mainDir->entry( entry )->isDirectory() )
        {
            qWarning() << "Warning: Found a directory inside" << archivePath << " - Okular does not create files like that so it is most probably forged.";
            return nullptr;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&userCancelled](const char *element) -> char * {
        bool ok;
        const QString pwd = QInputDialog::getText(nullptr, i18n("Enter Password"), i18n("Enter password to open %1:", QString::fromUtf8(element)), QLineEdit::Password, QString(), &ok);
        *userCancelled = !ok;
        return ok ? strdup(pwd.toUtf8().constData()) : nullptr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains go-to link action
        QAction *goToAction = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("GoToAction")));
        QVERIFY(goToAction);

        // check if the "follow this link" action is not visible
        QAction *processLinkAction = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("ProcessLinkAction")));
        QVERIFY(!processLinkAction);

        // check if the "copy link address" action is not visible
        QAction *copyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("CopyLinkLocationAction")));
        QVERIFY(!copyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedPoint &inkPoint : inkPath) {
                            Okular::NormalizedPoint point;
                            point.x = (inkPoint.x - xOffset) * xScale;
                            point.y = (inkPoint.y - yOffset) * yScale;
                            path.append(point);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLinkedList<NormalizedPoint> &path : m_transformedInkPaths) {
        const double thisDistance = ::distanceSqr(x, y, xScale, yScale, path);
        if (thisDistance < distance) {
            distance = thisDistance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *visibleItem : qAsConst(d->visibleItems)) {
        if (visibleItem->pageNumber() == pageNumber && visibleItem->isVisible()) {
            // update item's rectangle plus the little outline
            QRect expandedRect = visibleItem->croppedGeometry();
            // a PageViewItem is placed in the global page layout,
            // while we need to map its position in the viewport coordinates
            // (to get the correct area to repaint)
            expandedRect.translate(-contentAreaPosition());
            expandedRect.adjust(-1, -1, 3, 3);
            viewport()->update(expandedRect);

            // if we were "zoom-dragging" do not overwrite the "zoom-drag" cursor
            if (cursor().shape() != Qt::SizeVerCursor) {
                // since the page has been regenerated below cursor, update it
                updateCursor();
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &drawingXml : drawingTools )
    {
        QDomDocument entryParser;
        if ( entryParser.setContent( drawingXml ) )
            drawingDefinition.appendChild( doc.importNode( entryParser.documentElement(), true ) );
        else
            qCWarning(OkularUiDebug) << "Skipping malformed quick selection XML in QuickSelectionTools setting";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const XpsPathFigure *figure : qAsConst(pathdata->paths) ) {
        m_painter->setBrush( figure->isFilled ? brush : QBrush() );
        m_painter->drawPath( figure->path );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<WordsWithCharacters, QRect> &sortedLine : qAsConst(sortedLines)) {
            tmpList += sortedLine.first;
        }
```

#### AUTO 


```{c}
auto curatedViewMenu = menu->addMenu(QIcon::fromTheme(QStringLiteral("page-2sides")), menuBar ? menuBar->actions().at(1)->text() : QStringLiteral("View"));
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_pagesVector)) {
            const QLinkedList<ObjectRect *> &oRects = p->objectRects();
            for (ObjectRect *oRect : oRects) {
                if (oRect->objectType() == ObjectRect::Action) {
                    const Action *a = static_cast<const Action *>(oRect->object());
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }

            const QList<FormField *> forms = p->formFields();
            for (const FormField *form : forms) {
                const QList<Action *> additionalActions = form->additionalActions();
                for (const Action *a : additionalActions) {
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto generalPage = new QFrame( this );
```

#### RANGE FOR STATEMENT 


```{c}
for (const int p : pageList) {
        if (!pl.isEmpty()) {
            pl += QLatin1String(",");
        }
        pl += QString::number(p);
    }
```

#### AUTO 


```{c}
auto newDoc = new Okular::Document(nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageVector) {
        if (!page->label().isEmpty()) {
            m_labelPageMap.insert(page->label(), page->number());
            bool ok;
            page->label().toInt(&ok);
            if (!ok) {
                // Only add to the completion objects labels that are not numbers
                completionObject()->addItem(page->label());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsRenderNode &child : qAsConst(node.children)) {
        bool isStroked = true;
        att = node.attributes.value(QStringLiteral("IsStroked"));
        if (!att.isEmpty()) {
            isStroked = att == QLatin1String("true");
        }
        if (!isStroked) {
            continue;
        }

        // PolyLineSegment
        if (child.name == QLatin1String("PolyLineSegment")) {
            att = child.attributes.value(QStringLiteral("Points"));
            if (!att.isEmpty()) {
                const QStringList points = att.split(QLatin1Char(' '), QString::SkipEmptyParts);
                for (const QString &p : points) {
                    QPointF point = getPointFromString(p);
                    path.lineTo(point);
                }
            }
        }
        // PolyBezierSegment
        else if (child.name == QLatin1String("PolyBezierSegment")) {
            att = child.attributes.value(QStringLiteral("Points"));
            if (!att.isEmpty()) {
                const QStringList points = att.split(QLatin1Char(' '), QString::SkipEmptyParts);
                if (points.count() % 3 == 0) {
                    for (int i = 0; i < points.count();) {
                        QPointF firstControl = getPointFromString(points.at(i++));
                        QPointF secondControl = getPointFromString(points.at(i++));
                        QPointF endPoint = getPointFromString(points.at(i++));
                        path.cubicTo(firstControl, secondControl, endPoint);
                    }
                }
            }
        }
        // PolyQuadraticBezierSegment
        else if (child.name == QLatin1String("PolyQuadraticBezierSegment")) {
            att = child.attributes.value(QStringLiteral("Points"));
            if (!att.isEmpty()) {
                const QStringList points = att.split(QLatin1Char(' '), QString::SkipEmptyParts);
                if (points.count() % 2 == 0) {
                    for (int i = 0; i < points.count();) {
                        QPointF point1 = getPointFromString(points.at(i++));
                        QPointF point2 = getPointFromString(points.at(i++));
                        path.quadTo(point1, point2);
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int p : qAsConst(affectedItemsSet)) {
            if (p < tmpmin) {
                tmpmin = p;
            }
            if (p > tmpmax) {
                tmpmax = p;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsGradient &grad : gradients) {
        qgrad->setColorAt(grad.offset, grad.color);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Action *a : action->nextActions() )
    {
        processAction( a );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : qAsConst(m_frames[ m_frameIndex ]->videoWidgets) ) {
            vw->pageEntered();
        }
```

#### AUTO 


```{c}
auto newDoc = new Okular::Document( nullptr );
```

#### RANGE FOR STATEMENT 


```{c}
for (View *view : qAsConst(m_views)) {
        QDomElement viewEntry = doc.createElement(QStringLiteral("view"));
        viewEntry.setAttribute(QStringLiteral("name"), view->name());
        viewsNode.appendChild(viewEntry);
        saveViewsInfo(view, viewEntry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation * a : annotations )
    {
        if ( a->subType() == Okular::Annotation::AMovie )
        {
            Okular::MovieAnnotation * movieAnn = static_cast< Okular::MovieAnnotation * >( a );
            VideoWidget * vw = new VideoWidget( movieAnn, movieAnn->movie(), d->document, viewport() );
            item->videoWidgets().insert( movieAnn->movie(), vw );
            vw->pageInitialized();
        }
        else if ( a->subType() == Okular::Annotation::ARichMedia )
        {
            Okular::RichMediaAnnotation * richMediaAnn = static_cast< Okular::RichMediaAnnotation * >( a );
            VideoWidget * vw = new VideoWidget( richMediaAnn, richMediaAnn->movie(), d->document, viewport() );
            item->videoWidgets().insert( richMediaAnn->movie(), vw );
            vw->pageInitialized();
        }
        else if ( a->subType() == Okular::Annotation::AScreen )
        {
            const Okular::ScreenAnnotation * screenAnn = static_cast< Okular::ScreenAnnotation * >( a );
            Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation( screenAnn );
            if ( movie )
            {
                VideoWidget * vw = new VideoWidget( screenAnn, movie, d->document, viewport() );
                item->videoWidgets().insert( movie, vw );
                vw->pageInitialized();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TileNode &tile : qAsConst(d->tiles)) {
        if (!d->hasPixmap(rotatedRect, tile))
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::Annotation *popplerRevision : popplerRevisions) {
            bool deletePopplerRevision;
            Okular::Annotation::Revision okularRevision;
            okularRevision.setAnnotation(createAnnotationFromPopplerAnnotation(popplerRevision, popplerPage, &deletePopplerRevision));
            okularRevision.setScope(okularRevisionScopeFromPopplerRevisionScope(popplerRevision->revisionScope()));
            okularRevision.setType(okularRevisionTypeFromPopplerRevisionType(popplerRevision->revisionType()));
            okularRevisions << okularRevision;

            if (deletePopplerRevision) {
                delete popplerRevision;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : rgn) {
        if (useSubdivision) {
            // set 'contentsRect' to a part of the sub-divided region
            contentsRect = r.translated(areaPos).intersected(viewportRect);
            if (!contentsRect.isValid()) {
                continue;
            }
        }
#ifdef PAGEVIEW_DEBUG
        qCDebug(OkularUiDebug) << contentsRect;
#endif

        // note: this check will take care of all things requiring alpha blending (not only selection)
        bool wantCompositing = !selectionRect.isNull() && contentsRect.intersects(selectionRect);
        // also alpha-blend when there is a table selection...
        wantCompositing |= !d->tableSelectionParts.isEmpty();

        if (wantCompositing && Okular::Settings::enableCompositing()) {
            // create pixmap and open a painter over it (contents{left,top} becomes pixmap {0,0})
            QPixmap doubleBuffer(contentsRect.size() * devicePixelRatioF());
            doubleBuffer.setDevicePixelRatio(devicePixelRatioF());
            QPainter pixmapPainter(&doubleBuffer);

            pixmapPainter.translate(-contentsRect.left(), -contentsRect.top());

            // 1) Layer 0: paint items and clear bg on unpainted rects
            drawDocumentOnPainter(contentsRect, &pixmapPainter);
            // 2a) Layer 1a: paint (blend) transparent selection (rectangle)
            if (!selectionRect.isNull() && selectionRect.intersects(contentsRect) && !selectionRectInternal.contains(contentsRect)) {
                QRect blendRect = selectionRectInternal.intersected(contentsRect);
                // skip rectangles covered by the selection's border
                if (blendRect.isValid()) {
                    // grab current pixmap into a new one to colorize contents
                    QPixmap blendedPixmap(blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF());
                    blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                    QPainter p(&blendedPixmap);

                    p.drawPixmap(0,
                                 0,
                                 doubleBuffer,
                                 (blendRect.left() - contentsRect.left()) * devicePixelRatioF(),
                                 (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                 blendRect.width() * devicePixelRatioF(),
                                 blendRect.height() * devicePixelRatioF());

                    QColor blCol = selBlendColor.darker(140);
                    blCol.setAlphaF(0.2);
                    p.fillRect(blendedPixmap.rect(), blCol);
                    p.end();
                    // copy the blended pixmap back to its place
                    pixmapPainter.drawPixmap(blendRect.left(), blendRect.top(), blendedPixmap);
                }
                // draw border (red if the selection is too small)
                pixmapPainter.setPen(selBlendColor);
                pixmapPainter.drawRect(selectionRect.adjusted(0, 0, -1, -1));
            }
            // 2b) Layer 1b: paint (blend) transparent selection (table)
            for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust(1, 1, -1, -1);
                if (!selectionPartRect.isNull() && selectionPartRect.intersects(contentsRect) && !selectionPartRectInternal.contains(contentsRect)) {
                    QRect blendRect = selectionPartRectInternal.intersected(contentsRect);
                    // skip rectangles covered by the selection's border
                    if (blendRect.isValid()) {
                        // grab current pixmap into a new one to colorize contents
                        QPixmap blendedPixmap(blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF());
                        blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                        QPainter p(&blendedPixmap);
                        p.drawPixmap(0,
                                     0,
                                     doubleBuffer,
                                     (blendRect.left() - contentsRect.left()) * devicePixelRatioF(),
                                     (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                     blendRect.width() * devicePixelRatioF(),
                                     blendRect.height() * devicePixelRatioF());

                        QColor blCol = d->mouseSelectionColor.darker(140);
                        blCol.setAlphaF(0.2);
                        p.fillRect(blendedPixmap.rect(), blCol);
                        p.end();
                        // copy the blended pixmap back to its place
                        pixmapPainter.drawPixmap(blendRect.left(), blendRect.top(), blendedPixmap);
                    }
                    // draw border (red if the selection is too small)
                    pixmapPainter.setPen(d->mouseSelectionColor);
                    pixmapPainter.drawRect(selectionPartRect.adjusted(0, 0, -1, -1));
                }
            }
            drawTableDividers(&pixmapPainter);
            // 3a) Layer 1: give annotator painting control
            if (d->annotator && d->annotator->routePaints(contentsRect)) {
                d->annotator->routePaint(&pixmapPainter, contentsRect);
            }
            // 3b) Layer 1: give mouseAnnotation painting control
            d->mouseAnnotation->routePaint(&pixmapPainter, contentsRect);

            // 4) Layer 2: overlays
            if (Okular::Settings::debugDrawBoundaries()) {
                pixmapPainter.setPen(Qt::blue);
                pixmapPainter.drawRect(contentsRect);
            }

            // finish painting and draw contents
            pixmapPainter.end();
            screenPainter.drawPixmap(contentsRect.left(), contentsRect.top(), doubleBuffer);
        } else {
            // 1) Layer 0: paint items and clear bg on unpainted rects
            drawDocumentOnPainter(contentsRect, &screenPainter);
            // 2a) Layer 1a: paint opaque selection (rectangle)
            if (!selectionRect.isNull() && selectionRect.intersects(contentsRect) && !selectionRectInternal.contains(contentsRect)) {
                screenPainter.setPen(palette().color(QPalette::Active, QPalette::Highlight).darker(110));
                screenPainter.drawRect(selectionRect);
            }
            // 2b) Layer 1b: paint opaque selection (table)
            for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust(1, 1, -1, -1);
                if (!selectionPartRect.isNull() && selectionPartRect.intersects(contentsRect) && !selectionPartRectInternal.contains(contentsRect)) {
                    screenPainter.setPen(palette().color(QPalette::Active, QPalette::Highlight).darker(110));
                    screenPainter.drawRect(selectionPartRect);
                }
            }
            drawTableDividers(&screenPainter);
            // 3a) Layer 1: give annotator painting control
            if (d->annotator && d->annotator->routePaints(contentsRect)) {
                d->annotator->routePaint(&screenPainter, contentsRect);
            }
            // 3b) Layer 1: give mouseAnnotation painting control
            d->mouseAnnotation->routePaint(&screenPainter, contentsRect);

            // 4) Layer 2: overlays
            if (Okular::Settings::debugDrawBoundaries()) {
                screenPainter.setPen(Qt::red);
                screenPainter.drawRect(contentsRect);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *form : pageFields) {
            if (form->fullyQualifiedName() == cName) {
                return JSField::wrapField(context, form, *pIt);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : termStyles) {
            const QIcon icon = endStyleIcon(item.first, QGuiApplication::palette().color(QPalette::WindowText));
            m_startStyleCombo->addItem(icon, item.second);
            m_endStyleCombo->addItem(icon, item.second);
        }
```

#### AUTO 


```{c}
const auto ffIt = pageFields.begin() + numField;
```

#### RANGE FOR STATEMENT 


```{c}
for (int fontId : qAsConst(m_fontCache)) {
        m_fontDatabase.removeApplicationFont(fontId);
    }
```

#### AUTO 


```{c}
auto subjectFormLayout = new QFormLayout(subjectBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
            Q_ASSERT(request->observer() == requesterObserver);
            requestedPages.insert(request->pageNumber());
        }
```

#### AUTO 


```{c}
auto btnBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### AUTO 


```{c}
auto childItem3 = new SignatureItem(parentItem, nullptr, SignatureItem::Reason, pageNumber);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { pixmapGenerationFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TextDocumentGeneratorPrivate::LinkInfo &info : linkInfos) {
        // in case that the converter report bogus link info data, do not assert here
        if (info.page < 0 || info.page >= objects.count())
            continue;

        const QRectF rect = info.boundingRect;
        if (info.ownsLink) {
            objects[info.page].append(new Okular::ObjectRect(rect.left(), rect.top(), rect.right(), rect.bottom(), false, Okular::ObjectRect::Action, info.link));
        } else {
            objects[info.page].append(new Okular::NonOwningObjectRect(rect.left(), rect.top(), rect.right(), rect.bottom(), false, Okular::ObjectRect::Action, info.link));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int p) { d->slotFontReadingProgress(p); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &allDocumentsI : qAsConst(alldocuments)) {
        const QString docpath = allDocumentsI.path();

        if (docpath.endsWith(QLatin1String(".html"), Qt::CaseInsensitive) || docpath.endsWith(QLatin1String(".htm"), Qt::CaseInsensitive) || docpath.endsWith(QLatin1String(".xhtml"), Qt::CaseInsensitive))
            documents.push_back(allDocumentsI);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
            if (!mDocument->canRemovePageAnnotation(pair.annotation))
                action->setEnabled(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *f :  formFields )
        {
            if ( f->type() == Okular::FormField::FormSignature )
            {
                signatureFormFields.append( static_cast<Okular::FormFieldSignature*>( f ) );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : paths) {
        // Copy stdin to temporary file which can be opened by the existing
        // window. The temp file is automatically deleted after it has been
        // opened. Not sure if this behavior is safe on all platforms.
        QScopedPointer<QTemporaryFile> tempFile;
        QString path;
        if (arg == QLatin1String("-")) {
            tempFile.reset(new QTemporaryFile);
            QFile stdinFile;
            if (!tempFile->open() || !stdinFile.open(stdin, QIODevice::ReadOnly)) {
                return false;
            }

            const size_t bufSize = 1024 * 1024;
            QScopedPointer<char, QScopedPointerArrayDeleter<char>> buf(new char[bufSize]);
            size_t bytes;
            do {
                bytes = stdinFile.read(buf.data(), bufSize);
                tempFile->write(buf.data(), bytes);
            } while (bytes != 0);

            path = tempFile->fileName();
        } else {
            // Page only makes sense if we are opening one file
            const QString page = ShellUtils::page(serializedOptions);
            path = ShellUtils::urlFromArg(arg, ShellUtils::qfileExistFunc(), page).url();
        }

        // Returns false if it can't fit another document
        const QDBusReply<bool> reply = bestService->call(QStringLiteral("openDocument"), path, serializedOptions);
        if (!reply.isValid() || !reply.value()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto extraInfoFormLayout = new QFormLayout(extraInfoBox);
```

#### AUTO 


```{c}
auto sha1Label = new QLabel(QString(QCryptographicHash::hash(certData, QCryptographicHash::Sha1).toHex(' ')));
```

#### LAMBDA EXPRESSION 


```{c}
[this, colorType]() { slotSetColor(colorType); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(m_fileList)) {
        QFile::remove(file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *executingRequest : qAsConst( m_executingPixmapRequests ) )
                executingRequest->d->mShouldAbortRender = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &drawingXml : drawingTools) {
        QDomDocument entryParser;
        if (entryParser.setContent(drawingXml))
            drawingDefinition.appendChild(doc.importNode(entryParser.documentElement(), true));
        else
            qCWarning(OkularUiDebug) << "Skipping malformed quick selection XML in QuickSelectionTools setting";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const WordWithCharacters &word : list )
            {
                const QRect wordRect = word.area().geometry(pageWidth,pageHeight);

                if(leftRect.intersects(wordRect))
                    list1.append(word);
                else 
                    list2.append(word);
            }
```

#### AUTO 


```{c}
auto verticalScaling = painterWindow.height() / pageSize.height();
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());

                    // This will update the whole table rather than just the added/removed divider
                    // (which can span more than one part).
                    updatedRect = updatedRect.united(selectionPartRect);

                    if (!selectionPartRect.contains(eventPos)) {
                        continue;
                    }

                    // At this point it's clear we're either adding or removing a divider manually, so obviously the user is happy with the guess (if any).
                    d->tableDividersGuessed = false;

                    // There's probably a neat trick to finding which edge it's closest to,
                    // but this way has the advantage of simplicity.
                    const int fromLeft = abs(selectionPartRect.left() - eventPos.x());
                    const int fromRight = abs(selectionPartRect.left() + selectionPartRect.width() - eventPos.x());
                    const int fromTop = abs(selectionPartRect.top() - eventPos.y());
                    const int fromBottom = abs(selectionPartRect.top() + selectionPartRect.height() - eventPos.y());
                    const int colScore = fromTop < fromBottom ? fromTop : fromBottom;
                    const int rowScore = fromLeft < fromRight ? fromLeft : fromRight;

                    if (colScore < rowScore) {
                        bool deleted = false;
                        for (int i = 0; i < d->tableSelectionCols.length(); i++) {
                            const double col = (d->tableSelectionCols[i] - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                            const int colX = selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                            if (abs(colX - eventPos.x()) <= 3) {
                                d->tableSelectionCols.removeAt(i);
                                deleted = true;

                                break;
                            }
                        }
                        if (!deleted) {
                            double col = eventPos.x() - selectionPartRect.left();
                            col /= selectionPartRect.width(); // at this point, it's normalised within the part
                            col *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                            col += tsp.rectInSelection.left; // at this point, it's normalised within the whole table

                            d->tableSelectionCols.append(col);
                            std::sort(d->tableSelectionCols.begin(), d->tableSelectionCols.end());
                        }
                    } else {
                        bool deleted = false;
                        for (int i = 0; i < d->tableSelectionRows.length(); i++) {
                            const double row = (d->tableSelectionRows[i] - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                            const int rowY = selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                            if (abs(rowY - eventPos.y()) <= 3) {
                                d->tableSelectionRows.removeAt(i);
                                deleted = true;

                                break;
                            }
                        }
                        if (!deleted) {
                            double row = eventPos.y() - selectionPartRect.top();
                            row /= selectionPartRect.height(); // at this point, it's normalised within the part
                            row *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                            row += tsp.rectInSelection.top; // at this point, it's normalised within the whole table

                            d->tableSelectionRows.append(row);
                            std::sort(d->tableSelectionRows.begin(), d->tableSelectionRows.end());
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Annotation *annotation : annotationsList) {
            Okular::Action *action = nullptr;

            if (annotation->subType() == Okular::Annotation::AScreen)
                action = static_cast<const Okular::ScreenAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageOpening);
            else if (annotation->subType() == Okular::Annotation::AWidget)
                action = static_cast<const Okular::WidgetAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageOpening);

            if (action)
                m_document->processAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Action *a : action->nextActions() )
        {
            processAction( a );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annot : annots) {
            q->beginInsertRows(indexForItem(annItem), newid, newid);
            new AnnItem(annItem, annot);
            q->endInsertRows();
            ++newid;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NormalizedPoint &p : qAsConst(transformedLinePoints))
            polygon.append(QPointF(p.x, p.y));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
                if (url == m_document->currentDocument()) {
                    m_tree->addTopLevelItems(createItems(url, m_document->bookmarkManager()->bookmarks(url)));
                    m_currentDocumentItem = m_tree->invisibleRootItem();
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormWidgetIface *w : formWidgetsList )
                    w->setCanBeFilled( allowfillforms );
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString& searchText){
           m_findBar->startSearch(searchText);
           slotShowFindBar();
       }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::PageSize &p : sizes )
                items.append( p.name() );
```

#### RANGE FOR STATEMENT 


```{c}
for (FormFieldButton *oldFormButton : oldFormButtons) {
        FormFieldButton *button = dynamic_cast<FormFieldButton *>(Okular::PagePrivate::findEquivalentForm(newPagesVector[m_pageNumber], oldFormButton));
        if (!button) {
            return false;
        }
        m_formButtons << button;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double col : qAsConst(d->tableSelectionCols)) {
                if (col >= tsp.rectInSelection.left && col <= tsp.rectInSelection.right) {
                    col = (col - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                    const int x = selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                    screenPainter->drawLine(x, selectionPartRectInternal.top(), x, selectionPartRectInternal.top() + selectionPartRectInternal.height());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QUrl &url : urls )
        {
            if ( url == m_document->currentDocument() )
            {
                m_tree->addTopLevelItems( createItems( url, m_document->bookmarkManager()->bookmarks( url ) ) );
                m_currentDocumentItem = m_tree->invisibleRootItem();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MiniBar *miniBar : qAsConst(m_miniBars)) {
            // update prev/next button state
            miniBar->m_prevButton->setEnabled(currentPage > 0);
            miniBar->m_nextButton->setEnabled(currentPage < (pages - 1));
            // update text on widgets
            miniBar->m_pageNumberEdit->setText(pageNumber);
            miniBar->m_pageNumberLabel->setText(pageNumber);
            miniBar->m_pageLabelEdit->setText(pageLabel);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto width : d->widthStandardValues) {
        KToggleAction *ann = new KToggleAction(d->widthIcon(width), i18nc("@item:inlistbox", "Width %1", width), this);
        d->aWidth->addAction(ann);
        connect(ann, &QAction::triggered, this, [this, width]() { d->annotator->setAnnotationWidth(width); });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            if (annotation->subType() == Okular::Annotation::AWidget) {
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation *>(annotation);
                d->document->processAction(widgetAnnotation->additionalAction(Okular::Annotation::PageClosing));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::Annotation *annotation : annotationsList )
        {
            Okular::Action *action = nullptr;

            if ( annotation->subType() == Okular::Annotation::AScreen )
                action = static_cast<const Okular::ScreenAnnotation*>( annotation )->additionalAction( Okular::Annotation::PageOpening );
            else if ( annotation->subType() == Okular::Annotation::AWidget )
                action = static_cast<const Okular::WidgetAnnotation*>( annotation )->additionalAction( Okular::Annotation::PageOpening );

            if ( action )
                m_document->processAction( action );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList) {
        action->setChecked(false);
        action->setEnabled(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Page *p : qAsConst(d->m_pagesVector) )
        p->d->m_doc = d;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cert : certs) {
            new QTreeWidgetItem(m_tree,
                                {cert->subjectInfo(Okular::CertificateInfo::EntityInfoKey::CommonName), cert->subjectInfo(Okular::CertificateInfo::EntityInfoKey::EmailAddress), cert->validityEnd().toString(QStringLiteral("yyyy-MM-dd"))});
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FontInfo &fi : list) {
            emit gotFont(fi);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AnnotWindow *aw : qAsConst(d->m_annowindows))
    {
        if ( aw->annotation() == annotation )
        {
            existWindow = aw;
            break;
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(StampAnnotationWidget::defaultStamps.begin(), StampAnnotationWidget::defaultStamps.end(), [&stampIconName](const QPair<QString, QString> &element) { return element.second == stampIconName; });
```

#### RANGE FOR STATEMENT 


```{c}
for (AnnotWindow *aw : qAsConst(d->m_annowindows)) {
        if (aw->annotation() == annotation) {
            existWindow = aw;
            break;
        }
    }
```

#### AUTO 


```{c}
auto itMainWindow = std::find_if(widgets.begin(), widgets.end(), [](const QWidget *widget) { return qobject_cast<const KParts::MainWindow *>(widget) != nullptr; });
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
            AllocatedPixmap *p = searchLowestPriorityPixmap(false, true, observer);
            if (!p) { // No pixmap to remove
                continue;
            }

            clean_hits++;

            TilesManager *tilesManager = m_pagesVector.at(p->page)->d->tilesManager(observer);
            if (tilesManager && tilesManager->totalMemory() > 0) {
                qulonglong memoryDiff = p->memory;
                NormalizedRect visibleRect;
                if (visibleRects.contains(p->page)) {
                    visibleRect = visibleRects[p->page]->rect;
                }

                // Free non visible tiles
                tilesManager->cleanupPixmapMemory(memoryToFree, visibleRect, currentViewportPage);

                p->memory = tilesManager->totalMemory();
                memoryDiff -= p->memory;
                memoryToFree = (memoryDiff < memoryToFree) ? (memoryToFree - memoryDiff) : 0;
                m_allocatedPixmapsTotalMemory -= memoryDiff;

                if (p->memory > 0) {
                    pixmapsToKeep.append(p);
                } else {
                    delete p;
                }
            } else {
                pixmapsToKeep.append(p);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FormFieldButton *formButton : formButtons) {
        left = qMin<double>(left, formButton->rect().left);
        top = qMin<double>(top, formButton->rect().top);
        right = qMax<double>(right, formButton->rect().right);
        bottom = qMax<double>(bottom, formButton->rect().bottom);
    }
```

#### AUTO 


```{c}
auto programFeaturesLabel = [&programFeaturesLabelPlaced]() -> QString {
        if (programFeaturesLabelPlaced) {
            return QString();
        } else {
            programFeaturesLabelPlaced = true;
            return i18nc("@title:group Config dialog, general page", "Program features:");
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResizeHandle &handle : qAsConst(m_resizeHandleList)) {
            QRect rect = getHandleRect(handle, m_focusedAnnotation);
            painter->drawRect(rect);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction *action : actionsList )
    {
        action->setChecked( false );
        action->setEnabled( false );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageSet) {
        PageViewItem *item = new PageViewItem(page);
        d->items.push_back(item);
#ifdef PAGEVIEW_DEBUG
        qCDebug(OkularUiDebug).nospace() << "cropped geom for " << d->items.last()->pageNumber() << " is " << d->items.last()->croppedGeometry();
#endif
        const QLinkedList<Okular::FormField *> pageFields = page->formFields();
        for (Okular::FormField *ff : pageFields) {
            FormWidgetIface *w = FormWidgetFactory::createWidget(ff, this);
            if (w) {
                w->setPageItem(item);
                w->setFormWidgetsController(d->formWidgetsController());
                w->setVisibility(false);
                w->setCanBeFilled(allowfillforms);
                item->formWidgets().insert(w);
                hasformwidgets = true;
            }
        }

        createAnnotationsVideoWidgets(item, page->annotations());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedPoint &p : path) {
            points.append(normPointToPointF(p));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields)) {
        if (f->type() == oldField->type() && f->id() == oldField->id() && qFuzzyCompare(f->rect().left, oldField->rect().left) && qFuzzyCompare(f->rect().top, oldField->rect().top) &&
            qFuzzyCompare(f->rect().right, oldField->rect().right) && qFuzzyCompare(f->rect().bottom, oldField->rect().bottom)) {
            return f;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NormalizedPoint &point : path) {
            QDomElement pointElement = document.createElement(QStringLiteral("point"));
            pathElement.appendChild(pointElement);
            pointElement.setAttribute(QStringLiteral("x"), QString::number(point.x));
            pointElement.setAttribute(QStringLiteral("y"), QString::number(point.y));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ParsedEntry &e : parsedList )
	{
		if ( e.urls.empty() )
			continue;

		EBookIndexEntry entry;
		entry.name = e.name;
		entry.urls = e.urls;
		entry.seealso = e.seealso;

        // If the index array is empty, make sure the first entry is on root offset
        if ( index.isEmpty() )
            entry.indent = root_offset;
        else
            entry.indent = e.indent - root_offset;

		index.append( entry );
        printf("%d: %s\n", entry.indent, qPrintable(entry.name));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (AnnotWindow *aw : qAsConst(d->m_annowindows))
                {
                    Okular::Annotation *newA = d->document->page( aw->pageNumber() )->annotation( aw->annotation()->uniqueName() );
                    aw->updateAnnotation( newA );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : services) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            bestService.reset(new QDBusInterface(service, QStringLiteral("/okularshell"), QStringLiteral("org.kde.okular")));

            // Find a window that can handle our documents
            const QDBusReply<bool> reply = bestService->call(QStringLiteral("canOpenDocs"), paths.count(), desktop);
            if (reply.isValid() && reply.value())
                break;

            bestService.reset();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *newRequest : requests) {
                if (newRequest->pageNumber() == executingRequest->pageNumber() && requesterObserver == executingRequest->observer()) {
                    newRequestsContainExecutingRequestPage = true;
                }

                if (shouldCancelRenderingBecauseOf(*executingRequest, *newRequest)) {
                    requestCancelled = d->cancelRenderingBecauseOf(executingRequest, newRequest);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pagesToNotify, pageMatches, searchID, words] { d->doContinueGooglesDocumentSearch(pagesToNotify, pageMatches, 0, searchID, words); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: page->formFields() )
    {
        if ( ff->name().startsWith( QStringLiteral( "Target" ) ) )
        {
            QCOMPARE( ff->isVisible(), false );
            anyChecked = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int c : qAsConst(choices)) {
            list.append(QString::number(c));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString &t : result )
    {
        t.replace( QLatin1String("\\,"), QLatin1String(",") );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *videoWidget : videoWidgetsList  )
                videoWidget->pageLeft();
```

#### AUTO 


```{c}
auto saveBtn = new QPushButton(i18n("Save As"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : anchors) 
    targets[QLatin1Char('#')+name]=it;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines) {
        const WordsWithCharacters list = sortedLine.first;
        QList<QRect> line_space_rects;
        int maxSpace = 0, minSpace = pageWidth;

        // for every TinyTextEntity element in the line
        WordsWithCharacters::ConstIterator it = list.begin(), itEnd = list.end();
        QRect max_area1, max_area2;
        QString before_max, after_max;

        // for every line
        for (; it != itEnd; it++) {
            const QRect area1 = (*it).area().roundedGeometry(pageWidth, pageHeight);
            if (it + 1 == itEnd)
                break;

            const QRect area2 = (*(it + 1)).area().roundedGeometry(pageWidth, pageHeight);
            int space = area2.left() - area1.right();

            if (space > maxSpace) {
                max_area1 = area1;
                max_area2 = area2;
                maxSpace = space;
                before_max = (*it).text();
                after_max = (*(it + 1)).text();
            }

            if (space < minSpace && space != 0)
                minSpace = space;

            // if we found a real space, whose length is not zero and also less than the pageWidth
            if (space != 0 && space != pageWidth) {
                // increase the count of the space amount
                if (hor_space_stat.contains(space))
                    hor_space_stat[space]++;
                else
                    hor_space_stat[space] = 1;

                int left, right, top, bottom;

                left = area1.right();
                right = area2.left();

                top = area2.top() < area1.top() ? area2.top() : area1.top();
                bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                QRect rect(left, top, right - left, bottom - top);
                line_space_rects.append(rect);
            }
        }

        space_rects.append(line_space_rects);

        if (hor_space_stat.contains(maxSpace)) {
            if (hor_space_stat[maxSpace] != 1)
                hor_space_stat[maxSpace]--;
            else
                hor_space_stat.remove(maxSpace);
        }

        if (maxSpace != 0) {
            if (col_space_stat.contains(maxSpace))
                col_space_stat[maxSpace]++;
            else
                col_space_stat[maxSpace] = 1;

            // store the max rect of each line
            const int left = max_area1.right();
            const int right = max_area2.left();
            const int top = (max_area1.top() > max_area2.top()) ? max_area2.top() : max_area1.top();
            const int bottom = (max_area1.bottom() < max_area2.bottom()) ? max_area2.bottom() : max_area1.bottom();

            const QRect rect(left, top, right - left, bottom - top);
            max_hor_space_rects.append(rect);
        } else
            max_hor_space_rects.append(QRect(0, 0, 0, 0));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[doc = m_document] {
            // We need a QueuedConnection because undoing may end up destroying the menu this action is on
            // because it will undo the addition of the annotation. If it's not queued things gets unhappy
            // because the menu is destroyed in the middle of processing the click on the menu itself
            QMetaObject::invokeMethod(doc, &Okular::Document::undo, Qt::QueuedConnection);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Page * pIt : qAsConst(doc->m_pagesVector) )
    {
        const QLinkedList< Okular::FormField * > pageFields = pIt->formFields();
        
        if(numField < pageFields.size())
        {
            const auto ffIt = pageFields.begin() + numField;
            
            return KJSString( (*ffIt)->fullyQualifiedName() );
        }

        numField -= pageFields.size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
            observer->notifySetup(m_pagesVector, 0);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect & r : rgn )
        {
            if ( useSubdivision )
            {
                // set 'contentsRect' to a part of the sub-divided region
                contentsRect = r.translated( areaPos ).intersected( viewportRect );
                if ( !contentsRect.isValid() )
                    continue;
            }
#ifdef PAGEVIEW_DEBUG
            qCDebug(OkularUiDebug) << contentsRect;
#endif

            // note: this check will take care of all things requiring alpha blending (not only selection)
            bool wantCompositing = !selectionRect.isNull() && contentsRect.intersects( selectionRect );
            // also alpha-blend when there is a table selection...
            wantCompositing |= !d->tableSelectionParts.isEmpty();

            if ( wantCompositing && Okular::Settings::enableCompositing() )
            {
                // create pixmap and open a painter over it (contents{left,top} becomes pixmap {0,0})
                QPixmap doubleBuffer( contentsRect.size() * devicePixelRatioF() );
                doubleBuffer.setDevicePixelRatio(devicePixelRatioF());
                QPainter pixmapPainter( &doubleBuffer );

                pixmapPainter.translate( -contentsRect.left(), -contentsRect.top() );

                // 1) Layer 0: paint items and clear bg on unpainted rects
                drawDocumentOnPainter( contentsRect, &pixmapPainter );
                // 2a) Layer 1a: paint (blend) transparent selection (rectangle)
                if ( !selectionRect.isNull() && selectionRect.intersects( contentsRect ) &&
                    !selectionRectInternal.contains( contentsRect ) )
                {
                    QRect blendRect = selectionRectInternal.intersected( contentsRect );
                    // skip rectangles covered by the selection's border
                    if ( blendRect.isValid() )
                    {
                        // grab current pixmap into a new one to colorize contents
                        QPixmap blendedPixmap( blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );
                        blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                        QPainter p( &blendedPixmap );

                        p.drawPixmap( 0, 0, doubleBuffer,
                                    (blendRect.left() - contentsRect.left()) * devicePixelRatioF(), (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                    blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );

                        QColor blCol = selBlendColor.darker( 140 );
                        blCol.setAlphaF( 0.2 );
                        p.fillRect( blendedPixmap.rect(), blCol );
                        p.end();
                        // copy the blended pixmap back to its place
                        pixmapPainter.drawPixmap( blendRect.left(), blendRect.top(), blendedPixmap );
                    }
                    // draw border (red if the selection is too small)
                    pixmapPainter.setPen( selBlendColor );
                    pixmapPainter.drawRect( selectionRect.adjusted( 0, 0, -1, -1 ) );
                }
                // 2b) Layer 1b: paint (blend) transparent selection (table)
                for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                    QRect selectionPartRectInternal = selectionPartRect;
                    selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                    if ( !selectionPartRect.isNull() && selectionPartRect.intersects( contentsRect ) &&
                        !selectionPartRectInternal.contains( contentsRect ) )
                    {
                        QRect blendRect = selectionPartRectInternal.intersected( contentsRect );
                        // skip rectangles covered by the selection's border
                        if ( blendRect.isValid() )
                        {
                            // grab current pixmap into a new one to colorize contents
                            QPixmap blendedPixmap( blendRect.width()  * devicePixelRatioF(), blendRect.height()  * devicePixelRatioF() );
                            blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                            QPainter p( &blendedPixmap );
                            p.drawPixmap( 0, 0, doubleBuffer,
                                        (blendRect.left() - contentsRect.left()) * devicePixelRatioF(), (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                        blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );

                            QColor blCol = d->mouseSelectionColor.darker( 140 );
                            blCol.setAlphaF( 0.2 );
                            p.fillRect( blendedPixmap.rect(), blCol );
                            p.end();
                            // copy the blended pixmap back to its place
                            pixmapPainter.drawPixmap( blendRect.left(), blendRect.top(), blendedPixmap );
                        }
                        // draw border (red if the selection is too small)
                        pixmapPainter.setPen( d->mouseSelectionColor );
                        pixmapPainter.drawRect( selectionPartRect.adjusted( 0, 0, -1, -1 ) );
                    }
                }
                drawTableDividers( &pixmapPainter );
                // 3a) Layer 1: give annotator painting control
                if ( d->annotator && d->annotator->routePaints( contentsRect ) )
                    d->annotator->routePaint( &pixmapPainter, contentsRect );
                // 3b) Layer 1: give mouseAnnotation painting control
                d->mouseAnnotation->routePaint( &pixmapPainter, contentsRect );

                // 4) Layer 2: overlays
                if ( Okular::Settings::debugDrawBoundaries() )
                {
                    pixmapPainter.setPen( Qt::blue );
                    pixmapPainter.drawRect( contentsRect );
                }

                // finish painting and draw contents
                pixmapPainter.end();
                screenPainter.drawPixmap( contentsRect.left(), contentsRect.top(), doubleBuffer );
            }
            else
            {
                // 1) Layer 0: paint items and clear bg on unpainted rects
                drawDocumentOnPainter( contentsRect, &screenPainter );
                // 2a) Layer 1a: paint opaque selection (rectangle)
                if ( !selectionRect.isNull() && selectionRect.intersects( contentsRect ) &&
                    !selectionRectInternal.contains( contentsRect ) )
                {
                    screenPainter.setPen( palette().color( QPalette::Active, QPalette::Highlight ).darker(110) );
                    screenPainter.drawRect( selectionRect );
                }
                // 2b) Layer 1b: paint opaque selection (table)
                for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                    QRect selectionPartRectInternal = selectionPartRect;
                    selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                    if ( !selectionPartRect.isNull() && selectionPartRect.intersects( contentsRect ) &&
                        !selectionPartRectInternal.contains( contentsRect ) )
                    {
                        screenPainter.setPen( palette().color( QPalette::Active, QPalette::Highlight ).darker(110) );
                        screenPainter.drawRect( selectionPartRect );
                    }
                }
                drawTableDividers( &screenPainter );
                // 3a) Layer 1: give annotator painting control
                if ( d->annotator && d->annotator->routePaints( contentsRect ) )
                    d->annotator->routePaint( &screenPainter, contentsRect );
                // 3b) Layer 1: give mouseAnnotation painting control
                d->mouseAnnotation->routePaint( &screenPainter, contentsRect );

                // 4) Layer 2: overlays
                if ( Okular::Settings::debugDrawBoundaries() )
                {
                    screenPainter.setPen( Qt::red );
                    screenPainter.drawRect( contentsRect );
                }
            }
        }
```

#### AUTO 


```{c}
auto cert
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *) -> QObject * { return new QObject; }
```

#### LAMBDA EXPRESSION 


```{c}
[=] ( QAction * a, const QString &name, Okular::Settings::EnumViewMode::type id ) {
        a->setCheckable( true );
        a->setData( int( id ) );
        d->aViewModeMenu->addAction( a );
        ac->addAction( name, a );
        d->viewModeActionGroup->addAction( a );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &stamp : StampAnnotationWidget::defaultStamps) {
        KToggleAction *ann = new KToggleAction(d->stampIcon(stamp.second), stamp.first, this);
        if (!d->aStamp->defaultAction())
            d->aStamp->setDefaultAction(ann);
        d->aStamp->addAction(ann);
        d->agTools->addAction(ann);
        // action group workaround: connecting to toggled instead of triggered
        // (because deselectAllAnnotationActions has to call triggered)
        connect(ann, &QAction::toggled, this, [this, stamp](bool checked) {
            if (checked)
                d->slotStampToolSelected(stamp.second);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EBookTocEntry &e : qAsConst(toc_parser.entries)) {
            // Add into url-title map
            m_urlTitleMap[e.url] = e.name;
            m_tocEntries.push_back(e);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *videoWidget : videoWidgetsList) {
                videoWidget->pageLeft();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bm : bmarks) {
        DocumentViewport vp(bm.url().fragment(QUrl::FullyDecoded));
        if (vp.isValid() && vp.pageNumber == page) {
            ret.append(bm);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pagesToNotify, pageMatches, searchID] { d->doContinueAllDocumentSearch(pagesToNotify, pageMatches, 0, searchID); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsRenderNode &child : qAsConst(node.children)) {
        if (child.data.canConvert<XpsPathFigure *>()) {
            XpsPathFigure *figure = child.data.value<XpsPathFigure *>();
            geom->paths.append(figure);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int formId : formCalculateOrder) {
        for (uint pageIdx = 0; pageIdx < m_parent->pages(); pageIdx++) {
            const Page *p = m_parent->page(pageIdx);
            if (p) {
                bool pageNeedsRefresh = false;
                const QList<Okular::FormField *> forms = p->formFields();
                for (FormField *form : forms) {
                    if (form->id() == formId) {
                        Action *action = form->additionalAction(FormField::CalculateField);
                        if (action) {
                            FormFieldText *fft = dynamic_cast<FormFieldText *>(form);
                            std::shared_ptr<Event> event;
                            QString oldVal;
                            if (fft) {
                                // Prepare text calculate event
                                event = Event::createFormCalculateEvent(fft, m_pagesVector[pageIdx]);
                                if (!m_scripter) {
                                    m_scripter = new Scripter(this);
                                }
                                m_scripter->setEvent(event.get());
                                // The value maybe changed in javascript so save it first.
                                oldVal = fft->text();
                            }

                            m_parent->processAction(action);
                            if (event && fft) {
                                // Update text field from calculate
                                m_scripter->setEvent(nullptr);
                                const QString newVal = event->value().toString();
                                if (newVal != oldVal) {
                                    fft->setText(newVal);
                                    fft->setAppearanceText(newVal);
                                    if (const Okular::Action *action = fft->additionalAction(Okular::FormField::FormatField)) {
                                        // The format action handles the refresh.
                                        m_parent->processFormatAction(action, fft);
                                    } else {
                                        Q_EMIT m_parent->refreshFormWidget(fft);
                                        pageNeedsRefresh = true;
                                    }
                                }
                            }
                        } else {
                            qWarning() << "Form that is part of calculate order doesn't have a calculate action";
                        }
                    }
                }
                if (pageNeedsRefresh) {
                    refreshPixmaps(p->number());
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : anchors) {
                    targets[QLatin1Char('#') + name] = it;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FormField *f : formfields) {
            QString newvalue = f->d_ptr->value();
            if (f->d_ptr->m_default == newvalue) {
                continue;
            }

            // append an filled-up element called 'annotation' to the list
            QDomElement formElement = document.createElement(QStringLiteral("form"));
            formElement.setAttribute(QStringLiteral("id"), f->id());
            formElement.setAttribute(QStringLiteral("value"), newvalue);
            formListElement.appendChild(formElement);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int p : pageList )
    {
        if ( !pl.isEmpty() )
            pl += QLatin1String( "," );
        pl += QString::number( p );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation *annotation : annotations )
        {
            if ( annotation->subType() == Okular::Annotation::AWidget )
            {
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation*>( annotation );
                d->document->processAction( widgetAnnotation->additionalAction( Okular::Annotation::PageOpening ) );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *ref : annots) {
            bool found = false;
            int count = annItem->children.count();
            for (int i = 0; !found && i < count; ++i) {
                if (ref == annItem->children.at(i)->annotation) {
                    found = true;
                }
            }
            if (!found) {
                q->beginInsertRows(indexForItem(annItem), count, count);
                new AnnItem(annItem, ref);
                q->endInsertRows();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]( const QImage &image ) { setPosterImage( image ); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : available) {
        if (md.rawData()[QStringLiteral("X-KDE-okularHasInternalSettings")].toBool()) {
            result << md;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedPoint &p : path) {
                points.append(normPointToPointF(p));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &qurl : qAsConst(pageList)) {
        QString url = qurl.toString();
        const QString urlLower = url.toLower();
        if (!urlLower.endsWith(QLatin1String(".html")) && !urlLower.endsWith(QLatin1String(".htm"))) {
            continue;
        }

        int pos = url.indexOf(QLatin1Char(('#')));
        // insert the url into the maps, but insert always the variant without the #ref part
        QString tmpUrl = pos == -1 ? url : url.left(pos);

        // url already there, abort insertion
        if (m_urlPage.contains(tmpUrl)) {
            continue;
        }

        int foundPage = tmpPageList.value(tmpUrl, -1);
        if (foundPage != -1) {
            m_urlPage.insert(tmpUrl, foundPage);
            m_pageUrl[foundPage] = tmpUrl;
        } else {
            // add pages not present in toc
            m_urlPage.insert(tmpUrl, pageNum);
            m_pageUrl.append(tmpUrl);
            pageNum++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annot : annots) {
            new AnnItem(annItem, annot);
        }
```

#### AUTO 


```{c}
const auto& highlight
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *pr : qAsConst(pixmapsToRequest)) {
        QLinkedList<Okular::PixmapRequest *> requestedPixmaps;
        requestedPixmaps.push_back(pr);
        m_parent->requestPixmaps(requestedPixmaps, Okular::Document::NoOption);
    }
```

#### AUTO 


```{c}
auto nextIterator = QLinkedList< DocumentViewport >::const_iterator(d->m_viewportIterator);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(orderedProperties)) {
        const QString titleString = info.getKeyTitle(key);
        const QString valueString = info.get(key);
        if (titleString.isNull() || valueString.isNull())
            continue;

        // create labels and layout them
        QWidget *value = nullptr;
        if (key == Okular::DocumentInfo::getKeyString(Okular::DocumentInfo::MimeType)) {
            /// for mime type fields, show icon as well
            value = new QWidget(page);
            /// place icon left of mime type's name
            QHBoxLayout *hboxLayout = new QHBoxLayout(value);
            hboxLayout->setContentsMargins(0, 0, 0, 0);
            /// retrieve icon and place it in a QLabel
            QMimeDatabase db;
            QMimeType mimeType = db.mimeTypeForName(valueString);
            KSqueezedTextLabel *squeezed;
            if (mimeType.isValid()) {
                /// retrieve icon and place it in a QLabel
                QLabel *pixmapLabel = new QLabel(value);
                hboxLayout->addWidget(pixmapLabel, 0);
                pixmapLabel->setPixmap(KIconLoader::global()->loadMimeTypeIcon(mimeType.iconName(), KIconLoader::Small));
                /// mime type's name and label
                squeezed = new KSqueezedTextLabel(i18nc("mimetype information, example: \"PDF Document (application/pdf)\"", "%1 (%2)", mimeType.comment(), valueString), value);
            } else {
                /// only mime type name
                squeezed = new KSqueezedTextLabel(valueString, value);
            }
            squeezed->setTextInteractionFlags(Qt::TextSelectableByMouse);
            hboxLayout->addWidget(squeezed, 1);
        } else {
            /// default for any other document information
            KSqueezedTextLabel *label = new KSqueezedTextLabel(valueString, page);
            label->setTextInteractionFlags(Qt::TextSelectableByMouse);
            value = label;
        }
        layout->addRow(new QLabel(i18n("%1:", titleString)), value);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item]() { Q_EMIT welcomeScreen()->forgetRecentItem(item->url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, opacity]() { d->annotator->setAnnotationOpacity(opacity); }
```

#### LAMBDA EXPRESSION 


```{c}
[&backColor](double t) { return QColor(t * backColor.red(), t * backColor.green(), t * backColor.blue()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
        const bool hadfocus = item->setFormWidgetsVisible(on);
        somehadfocus = somehadfocus || hadfocus;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]{
                    widget->setDummyMode( false );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Page * pIt : qAsConst(doc->m_pagesVector) )
    {
        const QLinkedList< Okular::FormField * > pageFields = pIt->formFields();
        
        if(numField < pageFields.size())
        {
            const auto ffIt = pageFields.begin() + numField;
            
            return KJSString( (*ffIt)->name() );
        }

        numField -= pageFields.size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Annotation *annotation : annotationsList) {
            Okular::Action *action = nullptr;

            if (annotation->subType() == Okular::Annotation::AScreen) {
                action = static_cast<const Okular::ScreenAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageOpening);
            } else if (annotation->subType() == Okular::Annotation::AWidget) {
                action = static_cast<const Okular::WidgetAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageOpening);
            }

            if (action) {
                m_document->processAction(action);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int p : qAsConst(affectedItemsSet) )
        {
            if ( p < tmpmin ) tmpmin = p;
            if ( p > tmpmax ) tmpmax = p;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormWidgetIface *fw : fwi )
        {
            if ( fw->formField() == form )
            {
                SignatureEdit *widget = static_cast< SignatureEdit * >( fw );
                widget->setDummyMode( true );
                QTimer::singleShot( 250, this, [=]{
                    widget->setDummyMode( false );
                });
                return;
            }
        }
```

#### AUTO 


```{c}
const auto &suffix
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ks : info.keys()) {
        if ( !orderedProperties.contains( ks ) ) {
            orderedProperties << ks;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : m_region_wordWithCharacters) {
            res += word.text();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_redrawTimer->start(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SignatureItem *child : qAsConst(item->children)) {
        updateFormFieldSignaturePointer(child, pages);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( int p : qAsConst(pagesWithSelectionSet) )
        {
            d->document->setPageTextSelection( p, selections[ p - first ], palette().color( QPalette::Active, QPalette::Highlight ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedRect &r : qAsConst(*selection)) {
                painter->drawRect(r.geometry((int)xScale, (int)yScale));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFields) {
            FormWidgetIface *w = FormWidgetFactory::createWidget(ff, viewport());
            if (w) {
                w->setPageItem(item);
                w->setFormWidgetsController(d->formWidgetsController());
                w->setVisibility(false);
                w->setCanBeFilled(allowfillforms);
                item->formWidgets().insert(w);
                hasformwidgets = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::Link *popplerLink : popplerLinks) {
        QRectF linkArea = popplerLink->linkArea();
        double nl = linkArea.left(), nt = linkArea.top(), nr = linkArea.right(), nb = linkArea.bottom();
        // create the rect using normalized coords and attach the Okular::Link to it
        Okular::ObjectRect *rect = new Okular::ObjectRect(nl, nt, nr, nb, false, Okular::ObjectRect::Action, createLinkFromPopplerLink(popplerLink));
        // add the ObjectRect to the container
        links.push_front(rect);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attribute : attributes) {
            const QRegularExpression re(QStringLiteral("%1=\"(.*)\"").arg(attribute));
            const QRegularExpressionMatch match = re.match(t);
            if (match.hasMatch()) {
                t = attribute + '=' + match.captured(1);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto& colorNameValue : colorList ) {
        QColor color( colorNameValue.second );
        QAction * aColor = new QAction( colorIcon( color ), i18nc("@item:inlistbox Color name", "%1", colorNameValue.first ), q);
        aColorPicker->addAction( aColor );
        QObject::connect( aColor, &QAction::triggered, q, [this, colorType, color] () {
            slotSetColor( colorType, color );
        } );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : pe->region()) {
        if (!r.isValid())
            continue;
#ifdef ENABLE_PROGRESS_OVERLAY
        const QRect dR(QRectF(r.x() * dpr, r.y() * dpr, r.width() * dpr, r.height() * dpr).toAlignedRect());
        if (Okular::Settings::slidesShowProgress() && r.intersects(m_overlayGeometry)) {
            // backbuffer the overlay operation
            QPixmap backPixmap(dR.size());
            backPixmap.setDevicePixelRatio(dpr);
            QPainter pixPainter(&backPixmap);

            // first draw the background on the backbuffer
            pixPainter.drawPixmap(QPoint(0, 0), m_lastRenderedPixmap, dR);

            // then blend the overlay (a piece of) over the background
            QRect ovr = m_overlayGeometry.intersected(r);
            pixPainter.drawPixmap((ovr.left() - r.left()), (ovr.top() - r.top()), m_lastRenderedOverlay, (ovr.left() - m_overlayGeometry.left()) * dpr, (ovr.top() - m_overlayGeometry.top()) * dpr, ovr.width() * dpr, ovr.height() * dpr);

            // finally blit the pixmap to the screen
            pixPainter.end();
            const QRect backPixmapRect = backPixmap.rect();
            const QRect dBackPixmapRect(QRectF(backPixmapRect.x() * dpr, backPixmapRect.y() * dpr, backPixmapRect.width() * dpr, backPixmapRect.height() * dpr).toAlignedRect());
            painter.drawPixmap(r.topLeft(), backPixmap, dBackPixmapRect);
        } else
#endif
            // copy the rendered pixmap to the screen
            painter.drawPixmap(r.topLeft(), m_lastRenderedPixmap, dR);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( View *view : qAsConst(m_views) )
                            {
                                if ( view->name() == viewName )
                                {
                                    loadViewsInfo( view, viewElement );
                                    loadedAnything = true;
                                    break;
                                }
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for(glyph &g : glyphtable)
        g.shrunkenCharacter = QImage();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : qAsConst(content_parser.manifest))
        m_ebookManifest.push_back(pathToUrl(f));
```

#### AUTO 


```{c}
auto *widget
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cert : certs) {
            items.append(cert->nickName());
            nickToCert[cert->nickName()] = cert;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Shell *shell : qAsConst(shells) )
        {
            shell->savePropertiesInternal( &config, ++numWindows );
            // Windows aren't necessarily closed on shutdown, but we'll use
            // this as a way to trigger the destructor code, which is normally
            // connected to the aboutToQuit signal
            shell->close();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDomNode &nd : qAsConst(imgNodes)) {
                        svgs.at(i).parentNode().replaceChild(nd, svgs.at(i));
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& highlight : *bufferedHighlights)
            {
                const Okular::NormalizedRect & r = highlight.second;
                // find out the rect to highlight on pixmap
                QRect highlightRect = r.geometry( scaledWidth, scaledHeight ).translated( -scaledCrop.topLeft() ).intersected( limits );
                highlightRect.translate( -limits.left(), -limits.top() );

                const QColor highlightColor = highlight.first;
                QPainter painter(&backImage);
                painter.setCompositionMode(QPainter::CompositionMode_Multiply);
                painter.fillRect(highlightRect, highlightColor);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QAction* action : actions )
                {
                    if (action->isChecked())
                    {
                        return action->data();
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (fix_word &fw : widthTable_in_units_of_design_size) {
        fw.value = 0;
    }
```

#### AUTO 


```{c}
auto revisionBtn = new QPushButton(i18n("View Signed Version..."));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &toolXml : items )
    {
        QDomDocument entryParser;
        if ( !entryParser.setContent( toolXml ) )
        {
            qWarning() << "Skipping malformed tool XML string";
            break;
        }

        const QDomElement toolElement = entryParser.documentElement();
        if ( toolElement.tagName() == QLatin1String("tool") )
        {
            const QString name = toolElement.attribute( QStringLiteral("name") );
            QString itemText;
            if ( toolElement.attribute( QStringLiteral("default"), QStringLiteral("false") ) == QLatin1String("true") )
                itemText = i18n( name.toLatin1().constData() );
            else
                itemText = name;

            QListWidgetItem * listEntry = new QListWidgetItem( itemText, m_list );
            listEntry->setData( ToolXmlRole, QVariant::fromValue( toolXml ) );
            listEntry->setData( Qt::DecorationRole, colorDecorationFromToolDescription( toolXml ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * visibleItem : qAsConst( d->visibleItems ) )
            if ( abs( visibleItem->pageNumber() - pageNumber ) <= 1 )
                return false;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex &idx : annotations )
        {
            const QModelIndex authorIndex = m_authorProxy->mapToSource( idx );
            const QModelIndex filterIndex = m_groupProxy->mapToSource( authorIndex );
            const QModelIndex annotIndex = m_filterProxy->mapToSource( filterIndex );
            Okular::Annotation *annotation = m_model->annotationForIndex( annotIndex );
            if ( annotation )
            {
                const int pageNumber = m_model->data( annotIndex, AnnotationModel::PageRole ).toInt();
                popup.addAnnotation( annotation, pageNumber );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &engine: engines) {
        m_dlg->kcfg_ttsEngine->addItem (engine);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int p : pageList )
    {
        pages += QStringLiteral(",%1").arg(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &toolButton : findChildren<QToolButton *>()) {
        layout()->removeWidget(toolButton);
        delete toolButton;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &searchProvider : searchProviders) {
                action = new QAction(searchProvider, webShortcutsMenu);
                action->setIcon(QIcon::fromTheme(filterData.iconNameForPreferredSearchProvider(searchProvider)));
                action->setData(filterData.queryForPreferredSearchProvider(searchProvider));
                connect(action, &QAction::triggered, this, &PageView::slotHandleWebShortcutAction);
                webShortcutsMenu->addAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * ann : tools ) {
        ann->setEnabled( on );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(orderedProperties)) {
        const QString titleString = info.getKeyTitle(key);
        const QString valueString = info.get(key);
        if (titleString.isNull() || valueString.isNull()) {
            continue;
        }

        // create labels and layout them
        QWidget *value = nullptr;
        if (key == Okular::DocumentInfo::getKeyString(Okular::DocumentInfo::MimeType)) {
            /// for mime type fields, show icon as well
            value = new QWidget(page);
            /// place icon left of mime type's name
            QHBoxLayout *hboxLayout = new QHBoxLayout(value);
            hboxLayout->setContentsMargins(0, 0, 0, 0);
            /// retrieve icon and place it in a QLabel
            QMimeDatabase db;
            QMimeType mimeType = db.mimeTypeForName(valueString);
            KSqueezedTextLabel *squeezed;
            if (mimeType.isValid()) {
                /// retrieve icon and place it in a QLabel
                QLabel *pixmapLabel = new QLabel(value);
                hboxLayout->addWidget(pixmapLabel, 0);
                const QIcon icon = QIcon::fromTheme(mimeType.iconName(), QIcon::fromTheme(QStringLiteral("application-octet-stream")));
                pixmapLabel->setPixmap(icon.pixmap(KIconLoader::SizeSmall));
                /// mime type's name and label
                squeezed = new KSqueezedTextLabel(i18nc("mimetype information, example: \"PDF Document (application/pdf)\"", "%1 (%2)", mimeType.comment(), valueString), value);
            } else {
                /// only mime type name
                squeezed = new KSqueezedTextLabel(valueString, value);
            }
            squeezed->setTextInteractionFlags(Qt::TextSelectableByMouse);
            hboxLayout->addWidget(squeezed, 1);
        } else {
            /// default for any other document information
            KSqueezedTextLabel *label = new KSqueezedTextLabel(valueString, page);
            label->setTextInteractionFlags(Qt::TextSelectableByMouse);
            value = label;
        }
        layout->addRow(new QLabel(i18n("%1:", titleString)), value);
    }
```

#### AUTO 


```{c}
auto fingerprintBox = new QGroupBox(i18n("Fingerprints"), generalPage);
```

#### LAMBDA EXPRESSION 


```{c}
[link]() {
                const Okular::BrowseAction *browseLink = static_cast<const Okular::BrowseAction *>(link);
                QClipboard *cb = QApplication::clipboard();
                cb->setText(browseLink->url().toDisplayString(), QClipboard::Clipboard);
                if (cb->supportsSelection()) {
                    cb->setText(browseLink->url().toDisplayString(), QClipboard::Selection);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
    {
        if (triedOffers.contains(md))
            continue;

        foreach (const QString& supported, md.mimeTypes())
        {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type) {
                exactMatches << md;
            }

            if (type.inherits(supported))
            {
                offers << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cert : qAsConst(certs)) {
        items.append(cert->nickName());
        nickToCert[cert->nickName()] = cert;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(mEntries)) {
        if ( mArchive ) {
            const KArchiveFile *entry = static_cast<const KArchiveFile*>( mArchiveDir->entry( file ) );
            if ( entry ) {
                dev.reset( entry->createDevice() );
            }
        } else if ( mDirectory ) {
            dev.reset( mDirectory->createDevice( file ) );
        } else {
            dev.reset( mUnrar->createDevice( file ) );
        }

        if ( ! dev.isNull() ) {
            reader.setDevice( dev.data() );
            if ( reader.canRead() )
            {
                QSize pageSize = reader.size();
                if (reader.transformation() & QImageIOHandler::TransformationRotate90) {
                    pageSize.transpose();
                }
                if ( !pageSize.isValid() ) {
                    const QImage i = reader.read();
                    if ( !i.isNull() )
                        pageSize = i.size();
                }
                if ( pageSize.isValid() ) {
                    pagesVector->replace( count, new Okular::Page( count, pageSize.width(), pageSize.height(), Okular::Rotation0 ) );
                    mPageMap.append(file);
                    count++;
                } else {
                    qCDebug(OkularComicbookDebug) << "Ignoring" << file << "doesn't seem to be an image even if QImageReader::canRead returned true";
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::Page * page : pageSet )
    {
        PageViewItem * item = new PageViewItem( page );
        d->items.push_back( item );
#ifdef PAGEVIEW_DEBUG
        qCDebug(OkularUiDebug).nospace() << "cropped geom for " << d->items.last()->pageNumber() << " is " << d->items.last()->croppedGeometry();
#endif
        const QLinkedList< Okular::FormField * > pageFields = page->formFields();
        for ( Okular::FormField * ff : pageFields )
        {
            FormWidgetIface * w = FormWidgetFactory::createWidget( ff, viewport() );
            if ( w )
            {
                w->setPageItem( item );
                w->setFormWidgetsController( d->formWidgetsController() );
                w->setVisibility( false );
                w->setCanBeFilled( allowfillforms );
                item->formWidgets().insert( w );
                hasformwidgets = true;
            }
        }

        createAnnotationsVideoWidgets( item, page->annotations() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *tmpItem : qAsConst(d->items)) {
        if (tmpItem->pageNumber() == vp.pageNumber) {
            item = tmpItem;
            break;
        }
    }
```

#### AUTO 


```{c}
auto nextIterator = QLinkedList<DocumentViewport>::const_iterator(d->m_viewportIterator);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const KBookmark &bm : qAsConst(bmarks) )
    {
        DocumentViewport vp( bm.url().fragment(QUrl::FullyDecoded) );
        if ( viewport < vp )
        {
            bookmark = bm;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * item : qAsConst( d->items ) )
    {
        Okular::RegularAreaRect * area = textSelectionForItem( item );
        d->pagesWithTextSelection.insert( item->pageNumber() );
        d->document->setPageTextSelection( item->pageNumber(), area, palette().color( QPalette::Active, QPalette::Highlight ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bookmark : bMarks) {
        list << bookmark.url().toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        if (action == d->agLastAction) {
            d->agLastAction = nullptr;
            d->agTools->checkedAction()->setChecked(false);
            d->selectTool(-1);
        } else {
            d->agLastAction = action;
            // Show the annotation toolbar whenever actions are triggered (e.g using shortcuts)
            d->aShowToolBar->setChecked(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : childrenNumberAndMoreStuff) {
                    if (c.isDigit())
                        ++indexOfFirstNonDigit;
                    else
                        break;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Okular::Action *action, Okular::FormFieldText *fft, bool &ok) { document->processValidateAction(action, fft, ok); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, newid]() {
                    finished(newid);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(observersPixmapCleared))
        o->notifyContentsCleared(Okular::DocumentObserver::Pixmap);
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields)) {
        if (f->rect() == oldField->rect() && f->type() == oldField->type() && f->id() == oldField->id())
            return f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::NormalizedRect &r : qAsConst(*selection) )
                {
                    painter->drawRect( r.geometry( (int)xScale, (int)yScale ) );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : qAsConst(videoWidgets) )
        {
            const Okular::NormalizedRect r = vw->normGeometry();
            QRect vwgeom = r.geometry( geometry.width(), geometry.height() );
            vw->resize( vwgeom.size() );
            vw->move( geometry.topLeft() + vwgeom.topLeft() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *ff : qAsConst(d->formfields)) {
        ff->d_ptr->setDefault();
    }
```

#### AUTO 


```{c}
auto childItem1 = new SignatureItem(parentItem, nullptr, SignatureItem::ValidityStatus, currentPage);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &characterBitmap : characterBitmaps)
    characterBitmap = nullptr;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QListWidgetItem * item : selection ) {
        rows.append( row( item ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TextDocumentGeneratorPrivate::LinkInfo &info : linkInfos ) {
        // in case that the converter report bogus link info data, do not assert here
        if ( info.page < 0 || info.page >= objects.count() )
          continue;

        const QRectF rect = info.boundingRect;
        if ( info.ownsLink ) {
            objects[ info.page ].append( new Okular::ObjectRect( rect.left(), rect.top(), rect.right(), rect.bottom(), false,
                                                                 Okular::ObjectRect::Action, info.link ) );
        } else {
            objects[ info.page ].append( new Okular::NonOwningObjectRect( rect.left(), rect.top(), rect.right(), rect.bottom(), false,
                                                                          Okular::ObjectRect::Action, info.link ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormFieldButton *oldFormButton : oldFormButtons) {
        FormFieldButton *button = dynamic_cast<FormFieldButton *>(Okular::PagePrivate::findEquivalentForm(newPagesVector[m_pageNumber], oldFormButton));
        if (!button)
            return false;
        m_formButtons << button;
    }
```

#### AUTO 


```{c}
auto frameColor = highlightColor.darker(150);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QLinkedList<NormalizedPoint> &path : m_transformedInkPaths )
    {
        const double thisDistance = ::distanceSqr( x, y, xScale, yScale, path );
        if ( thisDistance < distance )
            distance = thisDistance;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int p : qAsConst(pagesWithSelectionSet)) {
            d->document->setPageTextSelection(p, selections[p - first], palette().color(QPalette::Active, QPalette::Highlight));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MiniBar *miniBar : qAsConst(m_miniBars)) {
        // resize width of widgets
        miniBar->resizeForPage(pages, pagesOrLabelString);

        // update child widgets
        miniBar->m_pageLabelEdit->setPageLabels(pageVector);
        miniBar->m_pageNumberEdit->setPagesNumber(pages);
        miniBar->m_pagesButton->setText(pagesString);
        miniBar->m_prevButton->setEnabled(false);
        miniBar->m_nextButton->setEnabled(false);
        miniBar->m_pageLabelEdit->setVisible(labelsDiffer);
        miniBar->m_pageNumberLabel->setVisible(labelsDiffer);
        miniBar->m_pageNumberEdit->setVisible(!labelsDiffer);

        miniBar->adjustSize();

        miniBar->setEnabled(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, newid]() { finished(newid); }
```

#### RANGE FOR STATEMENT 


```{c}
for (fix_word &fw : widthTable_in_units_of_design_size)
        fw.value = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::Annotation *a : popplerAnnotations)
    {
        bool doDelete = true;
        Okular::Annotation * newann = createAnnotationFromPopplerAnnotation( a, &doDelete );
        if (newann)
        {
            page->addAnnotation(newann);

            if ( a->subType() == Poppler::Annotation::AScreen )
            {
                Poppler::ScreenAnnotation *annotScreen = static_cast<Poppler::ScreenAnnotation*>( a );
                Okular::ScreenAnnotation *screenAnnotation = static_cast<Okular::ScreenAnnotation*>( newann );

                // The activation action
                const Poppler::Link *actionLink = annotScreen->action();
                if ( actionLink )
                    screenAnnotation->setAction( createLinkFromPopplerLink( actionLink ) );

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotScreen->additionalAction( Poppler::Annotation::PageOpeningAction );
                if ( pageOpeningLink )
                    screenAnnotation->setAdditionalAction( Okular::Annotation::PageOpening, createLinkFromPopplerLink( pageOpeningLink ) );

                const Poppler::Link *pageClosingLink = annotScreen->additionalAction( Poppler::Annotation::PageClosingAction );
                if ( pageClosingLink )
                    screenAnnotation->setAdditionalAction( Okular::Annotation::PageClosing, createLinkFromPopplerLink( pageClosingLink ) );
            }

            if ( a->subType() == Poppler::Annotation::AWidget )
            {
                Poppler::WidgetAnnotation *annotWidget = static_cast<Poppler::WidgetAnnotation*>( a );
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation*>( newann );

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotWidget->additionalAction( Poppler::Annotation::PageOpeningAction );
                if ( pageOpeningLink )
                    widgetAnnotation->setAdditionalAction( Okular::Annotation::PageOpening, createLinkFromPopplerLink( pageOpeningLink ) );

                const Poppler::Link *pageClosingLink = annotWidget->additionalAction( Poppler::Annotation::PageClosingAction );
                if ( pageClosingLink )
                    widgetAnnotation->setAdditionalAction( Okular::Annotation::PageClosing, createLinkFromPopplerLink( pageClosingLink ) );
            }

            if ( !doDelete )
                annotationsOnOpenHash.insert( newann, a );
        }
        if ( doDelete )
            delete a;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::ObjectRect *rect : page->m_rects) {
            if ((enhanceLinks && rect->objectType() == Okular::ObjectRect::Action) || (enhanceImages && rect->objectType() == Okular::ObjectRect::Image)) {
                if (limitsEnlarged.intersects(rect->boundingRect(scaledWidth, scaledHeight).translated(-scaledCrop.topLeft()))) {
                    mixedPainter->strokePath(rect->region(), QPen(normalColor, 0));
                }
            }
        }
```

#### AUTO 


```{c}
auto revisionLayout = new QHBoxLayout( revisionBox );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::FormField *f : formFields )
            {
                if ( f->type() == Okular::FormField::FormSignature )
                    return true;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation *annotation : annotations )
    {
        if ( annotation->subType() == Okular::Annotation::AWidget )
            continue;

        result.append( annotation );
    }
```

#### AUTO 


```{c}
auto cbMakeRW = dynamic_cast<Okular::FormFieldButton *>(fields[QStringLiteral("CBMakeRW")]);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (!PDFSettings::useDefaultCertDB()) {
                warnRestartNeeded();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : available) {
        if (triedOffers.contains(md))
            continue;

        const QStringList mimetypes = md.mimeTypes();
        for (const QString &supported : mimetypes) {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type && !exactMatches.contains(md)) {
                exactMatches << md;
            }

            if (type.inherits(supported) && !offers.contains(md)) {
                offers << md;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {m_redrawTimer->start(); }
```

#### AUTO 


```{c}
auto subjectBox = new QGroupBox(i18n("Issued To"), generalPage);
```

#### AUTO 


```{c}
auto detailsPageLayout = new QVBoxLayout(detailsFrame);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QUrl &url : urls )
    {
        openUrl( url );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::Annotation *a : popplerAnnotations) {
        bool doDelete = true;
        Okular::Annotation *newann = createAnnotationFromPopplerAnnotation(a, *popplerPage, &doDelete);
        if (newann) {
            page->addAnnotation(newann);

            if (a->subType() == Poppler::Annotation::AScreen) {
                Poppler::ScreenAnnotation *annotScreen = static_cast<Poppler::ScreenAnnotation *>(a);
                Okular::ScreenAnnotation *screenAnnotation = static_cast<Okular::ScreenAnnotation *>(newann);

                // The activation action
                const Poppler::Link *actionLink = annotScreen->action();
                if (actionLink) {
                    screenAnnotation->setAction(createLinkFromPopplerLink(actionLink));
                }

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotScreen->additionalAction(Poppler::Annotation::PageOpeningAction);
                if (pageOpeningLink) {
                    screenAnnotation->setAdditionalAction(Okular::Annotation::PageOpening, createLinkFromPopplerLink(pageOpeningLink));
                }

                const Poppler::Link *pageClosingLink = annotScreen->additionalAction(Poppler::Annotation::PageClosingAction);
                if (pageClosingLink) {
                    screenAnnotation->setAdditionalAction(Okular::Annotation::PageClosing, createLinkFromPopplerLink(pageClosingLink));
                }
            }

            if (a->subType() == Poppler::Annotation::AWidget) {
                Poppler::WidgetAnnotation *annotWidget = static_cast<Poppler::WidgetAnnotation *>(a);
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation *>(newann);

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotWidget->additionalAction(Poppler::Annotation::PageOpeningAction);
                if (pageOpeningLink) {
                    widgetAnnotation->setAdditionalAction(Okular::Annotation::PageOpening, createLinkFromPopplerLink(pageOpeningLink));
                }

                const Poppler::Link *pageClosingLink = annotWidget->additionalAction(Poppler::Annotation::PageClosingAction);
                if (pageClosingLink) {
                    widgetAnnotation->setAdditionalAction(Okular::Annotation::PageClosing, createLinkFromPopplerLink(pageClosingLink));
                }
            }

            if (!doDelete) {
                annotationsOnOpenHash.insert(newann, a);
            }
        }
        if (doDelete) {
            delete a;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Okular::FormField *form) { slotRefresh(form); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : qAsConst(paths)) {
                QVERIFY(openUrls.contains(QStringLiteral("file://%1").arg(path)));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * i : qAsConst( d->items ) )
    {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for ( FormWidgetIface *fwi :  formWidgetsList)
        {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for ( VideoWidget *vw : videoWidgets )
        {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );

            if ( vw->isPlaying() && viewportRectAtZeroZero.intersected( vw->geometry() ).isEmpty() ) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if ( !i->isVisible() )
            continue;
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking page" << i->pageNumber();
        kWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects( i->croppedGeometry() );
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected( i->croppedGeometry() );
        if ( intersectionRect.isEmpty() )
        {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back( i );
        Okular::VisiblePageRect * vItem = new Okular::VisiblePageRect( i->pageNumber(), Okular::NormalizedRect( intersectionRect.translated( -i->uncroppedGeometry().topLeft() ), i->uncroppedWidth(), i->uncroppedHeight() ) );
        visibleRects.push_back( vItem );
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap( this, i->uncroppedWidth(), i->uncroppedHeight() );
        kWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if ( i->page()->hasTilesManager( this ) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low )
        {
            double rectMargin = pixelsToExpand/(double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax( 0.0, vItem->rect.left - rectMargin );
            expandedVisibleRect.top = qMax( 0.0, vItem->rect.top - rectMargin );
            expandedVisibleRect.right = qMin( 1.0, vItem->rect.right + rectMargin );
            expandedVisibleRect.bottom = qMin( 1.0, vItem->rect.bottom + rectMargin );
        }

        // if the item has not the right pixmap, add a request for it
        if ( !i->page()->hasPixmap( this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect ) )
        {
#ifdef PAGEVIEW_DEBUG
            kWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest * p = new Okular::PixmapRequest( this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous );
            requestedPixmaps.push_back( p );

            if ( i->page()->hasTilesManager( this ) )
            {
                p->setNormalizedRect( expandedVisibleRect );
                p->setTile( true );
            }
            else
                p->setNormalizedRect( vItem->rect );
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if ( isEvent )
        {
            const QRect & geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            const double distance = hypot( (geometry.left() + geometry.right()) / 2.0 - (viewportCenterX - 4),
                                           (geometry.top() + geometry.bottom()) / 2.0 - viewportCenterY );
            if ( distance >= minDistance && nearPageNumber != -1 )
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if ( geometry.height() > 0 && geometry.width() > 0 )
            {
                focusedX = ( viewportCenterX - (double)geometry.left() ) / (double)geometry.width();
                focusedY = ( viewportCenterY - (double)geometry.top() ) / (double)geometry.height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::OutlineItem &outlineItem : outlineItems) {
        QDomElement item = docSyn.createElement(outlineItem.name());
        parentDestination->appendChild(item);

        item.setAttribute(QStringLiteral("ExternalFileName"), outlineItem.externalFileName());
        const QSharedPointer<const Poppler::LinkDestination> outlineDestination = outlineItem.destination();
        if (outlineDestination) {
            const QString destinationName = outlineDestination->destinationName();
            if (!destinationName.isEmpty()) {
                item.setAttribute(QStringLiteral("ViewportName"), destinationName);
            } else {
                Okular::DocumentViewport vp;
                fillViewportFromLinkDestination(vp, *outlineDestination);
                item.setAttribute(QStringLiteral("Viewport"), vp.toString());
            }
        }
        item.setAttribute(QStringLiteral("Open"), outlineItem.isOpen());
        item.setAttribute(QStringLiteral("URL"), outlineItem.uri());

        if (outlineItem.hasChildren())
            addSynopsisChildren(outlineItem.children(), &item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLinkedList<Okular::NormalizedPoint> &path : inkPathsList) {
            QLinkedList<QPointF> points;
            for (const Okular::NormalizedPoint &p : path) {
                points.append(normPointToPointF(p));
            }
            paths.append(points);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(RegionText &tmpRegion : tree)
    {
        // Step 01
        QList< QPair<WordsWithCharacters, QRect> > sortedLines = makeAndSortLines(tmpRegion.text(), pageWidth, pageHeight);

        // Step 02
        for(QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines)
        {
            WordsWithCharacters &list = sortedLine.first;
            for(int k = 0 ; k < list.length() ; k++ )
            {
                const QRect area1 = list.at(k).area().roundedGeometry(pageWidth,pageHeight);
                if( k+1 >= list.length() ) break;

                const QRect area2 = list.at(k+1).area().roundedGeometry(pageWidth,pageHeight);
                const int space = area2.left() - area1.right();

                if(space != 0)
                {
                    // Make a TinyTextEntity of string space and push it between it and it+1
                    const int left = area1.right();
                    const int right = area2.left();
                    const int top = area2.top() < area1.top() ? area2.top() : area1.top();
                    const int bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                    const QString spaceStr(QStringLiteral(" "));
                    const QRect rect(QPoint(left,top),QPoint(right,bottom));
                    const NormalizedRect entRect(rect,pageWidth,pageHeight);
                    TinyTextEntity *ent1 = new TinyTextEntity(spaceStr, entRect);
                    TinyTextEntity *ent2 = new TinyTextEntity(spaceStr, entRect);
                    WordWithCharacters word(ent1, QList<TinyTextEntity*>() << ent2);

                    list.insert(k+1, word);

                    // Skip the space
                    k++;
                }
            }
        }

        WordsWithCharacters tmpList;
        for(const QPair<WordsWithCharacters, QRect> &sortedLine : qAsConst(sortedLines))
        {
            tmpList += sortedLine.first;
        }
        tmpRegion.setText(tmpList);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *twi : selected)
	{
		Okular::EmbeddedFile* ef = qvariant_cast< Okular::EmbeddedFile* >( twi->data( 0, EmbeddedFileRole ) );
		saveFile(ef);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
        // update internal page size (leaving a little margin in case of Fit* modes)
        updateItemSize(item, colWidth[cIdx] - kcolWidthMargin, viewportHeight - krowHeightMargin);
        // find row's maximum height and column's max width
        if (item->croppedWidth() + kcolWidthMargin > colWidth[cIdx])
            colWidth[cIdx] = item->croppedWidth() + kcolWidthMargin;
        if (item->croppedHeight() + krowHeightMargin > rowHeight[rIdx])
            rowHeight[rIdx] = item->croppedHeight() + krowHeightMargin;
        // handle the 'centering on first row' stuff
        // update col/row indices
        if (++cIdx == nCols) {
            cIdx = 0;
            rIdx++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pair] { doOpenAnnotationWindow(pair); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int index : selectedItems )
            if ( index >= 0 && index < count() )
                item( index )->setSelected( true );
```

#### AUTO 


```{c}
auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, currentPage);
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: pageFormFields )
    {
        m_fields.insert( ff->name(),  ff );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldButton *formButton : formButtons) {
        int id = formButton->id();
        QAbstractButton *button = m_buttons[id];
        CheckBoxEdit *check = qobject_cast<CheckBoxEdit *>(button);
        if (check) {
            Q_EMIT refreshFormWidget(check->formField());
        }
        // temporarily disable exclusiveness of the button group
        // since it breaks doing/redoing steps into which all the checkboxes
        // are unchecked
        const bool wasExclusive = button->group()->exclusive();
        button->group()->setExclusive(false);
        bool checked = formButton->state();
        button->setChecked(checked);
        button->group()->setExclusive(wasExclusive);
        button->setFocus();
    }
```

#### AUTO 


```{c}
auto showBtn = m_fields[QStringLiteral("ShowActionButton")];
```

#### LAMBDA EXPRESSION 


```{c}
[&stampIconName] (const QPair<QString, QString>& element) {
                                return element.second == stampIconName;
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Annotation *a : qAsConst(m_page->m_annotations)) {
            // only save okular annotations (not the embedded in file ones)
            if (!(a->flags() & Annotation::External)) {
                // append an filled-up element called 'annotation' to the list
                QDomElement annElement = document.createElement(QStringLiteral("annotation"));
                AnnotationUtils::storeAnnotation(a, annElement, document);
                annotListElement.appendChild(annElement);
                qCDebug(OkularCoreDebug) << "save annotation:" << a->uniqueName();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, favToolId]() { slotQuickToolSelected(favToolId); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            if (!annotation)
                continue;

            annotation->setCreationDate(QDateTime::currentDateTime());
            annotation->setModificationDate(QDateTime::currentDateTime());
            annotation->setAuthor(Okular::Settings::identityAuthor());
            m_document->addPageAnnotation(m_lockedItem->pageNumber(), annotation);

            if (annotation->openDialogAfterCreation())
                m_pageView->openAnnotationWindow(annotation, m_lockedItem->pageNumber());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ks : infoKeys) {
        if (!orderedProperties.contains(ks)) {
            orderedProperties << ks;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dummy] {
                delete dummy;
                d_ptr->textPageGenerationThread()->startGeneration();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ParsedEntry &e : qAsConst(parsed)) {
        if (root_offset == -1) {
            root_offset = e.indent;
        }

        EBookTocEntry entry;
        entry.iconid = (EBookTocEntry::Icon)e.iconid;
        entry.indent = e.indent - root_offset;
        entry.name = e.name;

        if (!e.urls.empty()) {
            entry.url = e.urls[0];
        }

        toc.append(entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FormField *form : forms) {
                const QList<Action *> additionalActions = form->additionalActions();
                for (const Action *a : additionalActions) {
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &stamp : StampAnnotationWidget::defaultStamps) {
        KToggleAction *ann = new KToggleAction(d->stampIcon(stamp.second), stamp.first, this);
        d->aStamp->addAction(ann);
        d->agTools->addAction(ann);
        // action group workaround: connecting to toggled instead of triggered
        // (because deselectAllAnnotationActions has to call triggered)
        connect(ann, &QAction::toggled, this, [this, stamp](bool checked) {
            if (checked)
                d->slotStampToolSelected(stamp.second);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int size : {16, 22, 24, 32, 48}) {
        QPixmap pixmap(QSize(size, size) * qApp->devicePixelRatio());
        pixmap.setDevicePixelRatio(qApp->devicePixelRatio());
        pixmap.fill(Qt::transparent);
        QPainter painter(&pixmap);
        painter.setPen(Qt::NoPen);
        painter.setBrush(qApp->palette().color(QPalette::Active, QPalette::WindowText));

        // Checkerboard pattern
        painter.drawRect(QRectF(QPoint(0, 0), QPoint(size, size) / 2));
        painter.drawRect(QRectF(QPoint(size, size) / 2, QPoint(size, size)));

        // Opacity
        painter.setOpacity(opacity);
        painter.drawRect(QRect(QPoint(0, 0), QPoint(size, size)));

        painter.end();
        opacityIcon.addPixmap(pixmap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());

                    // This will update the whole table rather than just the added/removed divider
                    // (which can span more than one part).
                    updatedRect = updatedRect.united(selectionPartRect);

                    if (!selectionPartRect.contains(eventPos))
                        continue;

                    // At this point it's clear we're either adding or removing a divider manually, so obviously the user is happy with the guess (if any).
                    d->tableDividersGuessed = false;

                    // There's probably a neat trick to finding which edge it's closest to,
                    // but this way has the advantage of simplicity.
                    const int fromLeft = abs(selectionPartRect.left() - eventPos.x());
                    const int fromRight = abs(selectionPartRect.left() + selectionPartRect.width() - eventPos.x());
                    const int fromTop = abs(selectionPartRect.top() - eventPos.y());
                    const int fromBottom = abs(selectionPartRect.top() + selectionPartRect.height() - eventPos.y());
                    const int colScore = fromTop < fromBottom ? fromTop : fromBottom;
                    const int rowScore = fromLeft < fromRight ? fromLeft : fromRight;

                    if (colScore < rowScore) {
                        bool deleted = false;
                        for (int i = 0; i < d->tableSelectionCols.length(); i++) {
                            const double col = (d->tableSelectionCols[i] - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                            const int colX = selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                            if (abs(colX - eventPos.x()) <= 3) {
                                d->tableSelectionCols.removeAt(i);
                                deleted = true;

                                break;
                            }
                        }
                        if (!deleted) {
                            double col = eventPos.x() - selectionPartRect.left();
                            col /= selectionPartRect.width(); // at this point, it's normalised within the part
                            col *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                            col += tsp.rectInSelection.left; // at this point, it's normalised within the whole table

                            d->tableSelectionCols.append(col);
                            std::sort(d->tableSelectionCols.begin(), d->tableSelectionCols.end());
                        }
                    } else {
                        bool deleted = false;
                        for (int i = 0; i < d->tableSelectionRows.length(); i++) {
                            const double row = (d->tableSelectionRows[i] - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                            const int rowY = selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                            if (abs(rowY - eventPos.y()) <= 3) {
                                d->tableSelectionRows.removeAt(i);
                                deleted = true;

                                break;
                            }
                        }
                        if (!deleted) {
                            double row = eventPos.y() - selectionPartRect.top();
                            row /= selectionPartRect.height(); // at this point, it's normalised within the part
                            row *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                            row += tsp.rectInSelection.top; // at this point, it's normalised within the whole table

                            d->tableSelectionRows.append(row);
                            std::sort(d->tableSelectionRows.begin(), d->tableSelectionRows.end());
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Annotation::Revision &revision : qAsConst(m_revisions)) {
        delete revision.annotation();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page * page : pageVector)
    {
        if ( !page->label().isEmpty() )
        {
            m_labelPageMap.insert( page->label(), page->number() );
            bool ok;
            page->label().toInt( &ok );
            if ( !ok )
            {
                // Only add to the completion objects labels that are not numbers
                completionObject()->addItem( page->label() );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : list) {
                const QRect wordRect = word.area().geometry(pageWidth, pageHeight);

                if (leftRect.intersects(wordRect))
                    list1.append(word);
                else
                    list2.append(word);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMainWindow *kmw : mainWindows) {
        Shell *shell = qobject_cast<Shell *>(kmw);
        if (shell) {
            shells.append(shell);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, favToolId] () {
            slotQuickToolSelected( favToolId );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) { emit preferredScreenChanged(index - k_specialScreenCount); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int page :  qAsConst(affectedItemsIds) )
            {
                ret.append( textSelectionForItem( d->items[ page ] ) );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &colorNameValue : colorList) {
        QColor color(colorNameValue.second);
        QAction *aColor = new QAction(GuiUtils::createColorIcon({color}, QIcon(), GuiUtils::VisualizeTransparent), i18nc("@item:inlistbox Color name", "%1", colorNameValue.first), q);
        aColorPicker->addAction(aColor);
        QObject::connect(aColor, &QAction::triggered, q, [this, colorType, color]() { slotSetColor(colorType, color); });
    }
```

#### AUTO 


```{c}
auto sha1Label = new QLabel( QString( QCryptographicHash::hash( certData, QCryptographicHash::Sha1 ).toHex(' ') ) );
```

#### AUTO 


```{c}
auto linkIt = internalLinks.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&fullyQualifiedName](const Okular::FormField *off) { return off->fullyQualifiedName() == fullyQualifiedName; }
```

#### RANGE FOR STATEMENT 


```{c}
for (QToolButton *button : qAsConst(m_buttons)) {
        if (button) {
            button->setDefaultAction(this->defaultAction());

            if (delayed()) { // TODO deprecated interface.
                button->setPopupMode(QToolButton::DelayedPopup);
            } else if (stickyMenu()) {
                button->setPopupMode(QToolButton::InstantPopup);
            } else {
                button->setPopupMode(QToolButton::MenuButtonPopup);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedPoint &p : annotPoints) {
            points.append(normPointToPointF(p));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains go-to link action
        QAction *goToAction = qobject_cast<QAction*>(menu->findChild<QAction*>("GoToAction"));
        QVERIFY(goToAction);

        // check if the "follow this link" action is not visible
        QAction *processLinkAction = qobject_cast<QAction*>(menu->findChild<QAction*>("ProcessLinkAction"));
        QVERIFY(!processLinkAction);

        // check if the "copy link address" action is not visible
        QAction *copyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyLinkLocationAction"));
        QVERIFY(!copyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        // check if a piece of the page intersects the contents rect
        if (!item->isVisible() || !item->croppedGeometry().intersects(checkRect))
            continue;

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry();

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate(itemGeometry.left(), itemGeometry.top());

        // draw the page outline (black border and bottom-right shadow)
        if (!itemGeometry.contains(contentsRect)) {
            int itemWidth = itemGeometry.width();
            int itemHeight = itemGeometry.height();
            // draw simple outline
            QPen pen(Qt::black);
            pen.setWidth(0);
            p->setPen(pen);

            QRectF outline(-1.0 / dpr, -1.0 / dpr, itemWidth + 1.0 / dpr, itemHeight + 1.0 / dpr);
            p->drawRect(outline);

            // draw bottom/right gradient
            for (int i = 1; i <= shadowWidth; i++) {
                pen.setColor(interpolateColor(double(i) / (shadowWidth + 1)));
                p->setPen(pen);
                QPointF left((i - 1) / dpr, itemHeight + i / dpr);
                QPointF up(itemWidth + i / dpr, (i - 1) / dpr);
                QPointF corner(itemWidth + i / dpr, itemHeight + i / dpr);
                p->drawLine(left, corner);
                p->drawLine(up, corner);
            }
        }

        p->restore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *visibleItem : qAsConst(d->visibleItems))
        if (visibleItem->pageNumber() == pageNumber && visibleItem->isVisible()) {
            // update item's rectangle plus the little outline
            QRect expandedRect = visibleItem->croppedGeometry();
            // a PageViewItem is placed in the global page layout,
            // while we need to map its position in the viewport coordinates
            // (to get the correct area to repaint)
            expandedRect.translate(-contentAreaPosition());
            expandedRect.adjust(-1, -1, 3, 3);
            viewport()->update(expandedRect);

            // if we were "zoom-dragging" do not overwrite the "zoom-drag" cursor
            if (cursor().shape() != Qt::SizeVerCursor) {
                // since the page has been regenerated below cursor, update it
                updateCursor();
            }
            break;
        }
```

#### AUTO 


```{c}
const auto &action
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &stamp : StampAnnotationWidget::defaultStamps()) {
        KToggleAction *ann = new KToggleAction(d->stampIcon(stamp.second), stamp.first, this);
        d->aStamp->addAction(ann);
        d->agTools->addAction(ann);
        // action group workaround: connecting to toggled instead of triggered
        // (because deselectAllAnnotationActions has to call triggered)
        connect(ann, &QAction::toggled, this, [this, stamp](bool checked) {
            if (checked) {
                d->slotStampToolSelected(stamp.second);
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TabState &tab : qAsConst(m_tabs)) {
        urls.append(tab.part->url().url());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ParsedEntry &e : parsedList )
    {
        if ( e.urls.empty() )
            continue;

        root_offset = qMin( root_offset, e.indent );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation *annotation : annotations )
        {
            if ( annotation->subType() == Okular::Annotation::AWidget )
            {
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation*>( annotation );
                d->document->processAction( widgetAnnotation->additionalAction( Okular::Annotation::PageClosing ) );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::RichMediaAnnotation::Asset *asset : assets) {
        if (asset->name() == sourceId) {
            matchingAsset = asset;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stamp](bool checked) {
            if (checked)
                d->slotStampToolSelected(stamp.second);
        }
```

#### AUTO 


```{c}
auto targetDefaultRW = dynamic_cast<Okular::FormFieldText *>(fields[QStringLiteral("TargetDefaultRw")]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &flashVar : flashVars) {
        const int pos = flashVar.indexOf(QLatin1Char('='));
        if (pos == -1) {
            continue;
        }

        const QString key = flashVar.left(pos);
        const QString value = flashVar.mid(pos + 1);

        if (key == QLatin1String("source")) {
            sourceId = value;
        } else if (key == QLatin1String("loop")) {
            playbackLoops = (value == QLatin1String("true") ? true : false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&executeNextActions] { executeNextActions.b = false; }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &mimeName : qAsConst(m_fileformats) ) {
        QMimeType mimeType = mimeDatabase.mimeTypeForName( mimeName );
        const QStringList globs( mimeType.globPatterns() );
        if ( globs.isEmpty() ) {
            continue;
        }

        globPatterns.unite( globs.toSet() ) ;

        namedGlobs[ mimeType.comment() ].append( globs );

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDomNode &nd : qAsConst(imgNodes)) {
              svgs.at(i).parentNode().replaceChild(nd,svgs.at(i));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect &rect : rgn )
        viewport()->update( rect );
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
    {
        foreach (const QString& supported, md.mimeTypes())
        {
            if (type.inherits(supported))
            {
                offers << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLinkedList<NormalizedPoint> &path : m_transformedInkPaths) {
        const double thisDistance = ::distanceSqr(x, y, xScale, yScale, path);
        if (thisDistance < distance)
            distance = thisDistance;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines)
        {
            WordsWithCharacters &list = sortedLine.first;
            for(int k = 0 ; k < list.length() ; k++ )
            {
                const QRect area1 = list.at(k).area().roundedGeometry(pageWidth,pageHeight);
                if( k+1 >= list.length() ) break;

                const QRect area2 = list.at(k+1).area().roundedGeometry(pageWidth,pageHeight);
                const int space = area2.left() - area1.right();

                if(space != 0)
                {
                    // Make a TinyTextEntity of string space and push it between it and it+1
                    const int left = area1.right();
                    const int right = area2.left();
                    const int top = area2.top() < area1.top() ? area2.top() : area1.top();
                    const int bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                    const QString spaceStr(QStringLiteral(" "));
                    const QRect rect(QPoint(left,top),QPoint(right,bottom));
                    const NormalizedRect entRect(rect,pageWidth,pageHeight);
                    TinyTextEntity *ent1 = new TinyTextEntity(spaceStr, entRect);
                    TinyTextEntity *ent2 = new TinyTextEntity(spaceStr, entRect);
                    WordWithCharacters word(ent1, QList<TinyTextEntity*>() << ent2);

                    list.insert(k+1, word);

                    // Skip the space
                    k++;
                }
            }
        }
```

#### AUTO 


```{c}
const auto& colorNameValue
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toolXml : items) {
        QDomDocument entryParser;
        if (!entryParser.setContent(toolXml)) {
            qWarning() << "Skipping malformed tool XML string";
            break;
        }

        const QDomElement toolElement = entryParser.documentElement();
        if (toolElement.tagName() == QLatin1String("tool")) {
            const QString name = toolElement.attribute(QStringLiteral("name"));
            QString itemText;
            if (toolElement.attribute(QStringLiteral("default"), QStringLiteral("false")) == QLatin1String("true"))
                itemText = i18n(name.toLatin1().constData());
            else
                itemText = name;

            QListWidgetItem *listEntry = new QListWidgetItem(itemText, m_list);
            listEntry->setData(ToolXmlRole, QVariant::fromValue(toolXml));
            listEntry->setData(Qt::DecorationRole, colorDecorationFromToolDescription(toolXml));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_pagesVector)) {
            const QLinkedList<ObjectRect *> &oRects = p->objectRects();
            for (ObjectRect *oRect : oRects) {
                if (oRect->objectType() == ObjectRect::Action) {
                    const Action *a = static_cast<const Action *>(oRect->object());
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }

            const QLinkedList<FormField *> forms = p->formFields();
            for (const FormField *form : forms) {
                const QList<Action *> additionalActions = form->additionalActions();
                for (const Action *a : additionalActions) {
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *videoWidget : videoWidgetsList)
                videoWidget->pageLeft();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &arg : args) {
        if (arg.type() == QVariant::String) {
            QString argString = arg.toString();
            int separatorIndex = argString.indexOf(QStringLiteral("="));
            if (separatorIndex >= 0 && argString.left(separatorIndex) == QLatin1String("ConfigFileName")) {
                return argString.mid(separatorIndex + 1);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto client : clients) {
            if (QAction *act = client->actionCollection()->action(actionName)) {
                if (Action *castedAction = qobject_cast<Action *>(act)) {
                    return castedAction;
                }
            }
        }
```

#### AUTO 


```{c}
auto btnBox = new QDialogButtonBox( QDialogButtonBox::Close, this );
```

#### RANGE FOR STATEMENT 


```{c}
for (const TextDocumentGeneratorPrivate::AnnotationPosition &annPos : qAsConst(d->mAnnotationPositions)) {
            delete annPos.annotation;
        }
```

#### AUTO 


```{c}
auto childItem4 = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, currentPage);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &key : qAsConst(orderedProperties) )
    {
        const QString titleString = info.getKeyTitle( key );
        const QString valueString = info.get( key );
        if ( titleString.isNull() || valueString.isNull() )
            continue;

        // create labels and layout them
        QWidget *value = nullptr;
        if ( key == Okular::DocumentInfo::getKeyString( Okular::DocumentInfo::MimeType ) ) {
            /// for mime type fields, show icon as well
            value = new QWidget( page );
            /// place icon left of mime type's name
            QHBoxLayout *hboxLayout = new QHBoxLayout( value );
            hboxLayout->setContentsMargins( 0, 0, 0, 0 );
            /// retrieve icon and place it in a QLabel
            QMimeDatabase db;
            QMimeType mimeType = db.mimeTypeForName( valueString );
            KSqueezedTextLabel *squeezed;
            if (mimeType.isValid()) {
                /// retrieve icon and place it in a QLabel
                QLabel *pixmapLabel = new QLabel( value );
                hboxLayout->addWidget( pixmapLabel, 0 );
                pixmapLabel->setPixmap( KIconLoader::global()->loadMimeTypeIcon( mimeType.iconName(), KIconLoader::Small ) );
                /// mime type's name and label
                squeezed = new KSqueezedTextLabel( i18nc( "mimetype information, example: \"PDF Document (application/pdf)\"", "%1 (%2)", mimeType.comment(), valueString ), value );
            } else {
                /// only mime type name
                squeezed = new KSqueezedTextLabel( valueString, value );
            }
            squeezed->setTextInteractionFlags( Qt::TextSelectableByMouse );
            hboxLayout->addWidget( squeezed, 1 );
        } else {
            /// default for any other document information
            KSqueezedTextLabel *label = new KSqueezedTextLabel( valueString, page );
            label->setTextInteractionFlags( Qt::TextSelectableByMouse );
            value = label;
        }
        layout->addRow( new QLabel( i18n( "%1:", titleString ) ), value);
    }
```

#### AUTO 


```{c}
const auto toolbars = mainWindow->toolBars();
```

#### RANGE FOR STATEMENT 


```{c}
for (Annotation *a : m_annotations) {
        if (a->uniqueName() == uniqueName) {
            return a;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormField *ff : part.m_document->page( 0 )->formFields() )
    {
        if ( ff->id() == 65537 )
        {
            QCOMPARE( ff->type(), FormField::FormText );
            FormFieldText *fft = static_cast<FormFieldText *>( ff );
            part.m_document->editFormText( 0, fft, QStringLiteral("BlaBla"), 6, 0, 0 );
        }
        else if ( ff->id() == 65538 )
        {
            QCOMPARE( ff->type(), FormField::FormButton );
            FormFieldButton *ffb = static_cast<FormFieldButton *>( ff );
            QCOMPARE( ffb->buttonType(), FormFieldButton::Radio );
            part.m_document->editFormButtons( 0, QList< FormFieldButton* >() << ffb, QList< bool >() << true );
        }
        else if ( ff->id() == 65542 )
        {
            QCOMPARE( ff->type(), FormField::FormChoice );
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>( ff );
            QCOMPARE( ffc->choiceType(), FormFieldChoice::ListBox );
            part.m_document->editFormList( 0, ffc, QList< int >() << 1 );
        }
        else if ( ff->id() == 65543 )
        {
            QCOMPARE( ff->type(), FormField::FormChoice );
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>( ff );
            QCOMPARE( ffc->choiceType(), FormFieldChoice::ComboBox );
            part.m_document->editFormCombo( 0, ffc, QStringLiteral("combo2"), 3, 0, 0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : colorModeActions) {
        if (a != m_aNormal && a->data().toInt() == rm) {
            a->setChecked(true);
            setDefaultAction(a);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Page *p : qAsConst(pagesVector)) {
                const QLinkedList<Okular::FormField *> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end()) {
                    delete s;
                    createSignature = false;
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
            menu.addAction(new OKMenuTitle(&menu, GuiUtils::captionForAnnotation(pair.annotation)));

            action = menu.addAction(QIcon::fromTheme(QStringLiteral("comment")), i18n("&Open Pop-up Note"));
            action->setData(QVariant::fromValue(pair));
            action->setProperty(actionTypeId, openId);

            action = menu.addAction(QIcon::fromTheme(QStringLiteral("list-remove")), i18n("&Delete"));
            action->setEnabled(mDocument->isAllowed(Okular::AllowNotes) && mDocument->canRemovePageAnnotation(pair.annotation));
            action->setData(QVariant::fromValue(pair));
            action->setProperty(actionTypeId, deleteId);

            action = menu.addAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("&Properties"));
            action->setData(QVariant::fromValue(pair));
            action->setProperty(actionTypeId, propertiesId);

            if (annotationHasFileAttachment(pair.annotation)) {
                const Okular::EmbeddedFile *embeddedFile = embeddedFileFromAnnotation(pair.annotation);
                if (embeddedFile) {
                    const QString saveText = i18nc("%1 is the name of the file to save", "&Save '%1'...", embeddedFile->name());

                    menu.addSeparator();
                    action = menu.addAction(QIcon::fromTheme(QStringLiteral("document-save")), saveText);
                    action->setData(QVariant::fromValue(pair));
                    action->setProperty(actionTypeId, saveId);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &word : words )
		miniDict.insert( word, new PosEntry( 0 ) );
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine*, QJSEngine*) -> QObject* { return new QObject; }
```

#### AUTO 


```{c}
auto vLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines) {
            WordsWithCharacters &list = sortedLine.first;
            for (int k = 0; k < list.length(); k++) {
                const QRect area1 = list.at(k).area().roundedGeometry(pageWidth, pageHeight);
                if (k + 1 >= list.length()) {
                    break;
                }

                const QRect area2 = list.at(k + 1).area().roundedGeometry(pageWidth, pageHeight);
                const int space = area2.left() - area1.right();

                if (space != 0) {
                    // Make a TinyTextEntity of string space and push it between it and it+1
                    const int left = area1.right();
                    const int right = area2.left();
                    const int top = area2.top() < area1.top() ? area2.top() : area1.top();
                    const int bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                    const QString spaceStr(QStringLiteral(" "));
                    const QRect rect(QPoint(left, top), QPoint(right, bottom));
                    const NormalizedRect entRect(rect, pageWidth, pageHeight);
                    TinyTextEntity *ent1 = new TinyTextEntity(spaceStr, entRect);
                    TinyTextEntity *ent2 = new TinyTextEntity(spaceStr, entRect);
                    WordWithCharacters word(ent1, QList<TinyTextEntity *>() << ent2);

                    list.insert(k + 1, word);

                    // Skip the space
                    k++;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &lib : qAsConst(generatorLibs)) {
        KPluginLoader loader(lib);
        QVERIFY2(!loader.fileName().isEmpty(), qPrintable(lib));
        qDebug() << loader.fileName();
        auto factory = loader.factory();
        if (!factory) {
            qWarning() << "Could not get KPluginFactory for" << lib;
            failures++;
            continue;
        }
        Okular::Generator *generator = factory->create<Okular::Generator>();
        if (!generator) {
            qWarning() << "Failed to cast" << lib << "to Okular::Generator";
            // without the necessary Q_INTERFACES() qobject_cast fails!
            auto obj = factory->create<QObject>();
            qDebug() << "Object is of type " << obj->metaObject()->className();
            qDebug() << "dynamic_cast:" << dynamic_cast<Okular::Generator *>(obj);
            qDebug() << "qobject_cast:" << qobject_cast<Okular::Generator *>(obj);
            failures++;
            continue;
        }
        successful++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu *>(view->findChild<QMenu *>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "Follow this link" action
        QAction *processLink = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("ProcessLinkAction")));
        QVERIFY(processLink);

        // chek if the menu contains  "Copy Link Address" action
        QAction *actCopyLinkLocation = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("CopyLinkLocationAction")));
        QVERIFY(actCopyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[view]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "follow this link" action
        QAction *processLinkAction = qobject_cast<QAction*>(menu->findChild<QAction*>("ProcessLinkAction"));
        QVERIFY(processLinkAction);

        // check if the menu contains "copy link address" action
        QAction *copyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyLinkLocationAction"));
        QVERIFY(copyLinkLocation);

        // close menu to continue test
        menu->close();
    }
```

#### AUTO 


```{c}
auto certDataLabel = new QLabel( i18n("Certificate Data:") );
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *trimModeAction : trimModeActions) {
        if (trimModeAction->data().toInt() != except_id) {
            trimModeAction->setChecked(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bm : bmlist) {
        //        qCDebug(OkularUiDebug).nospace() << "checking '" << tmp << "'";
        //        qCDebug(OkularUiDebug).nospace() << "      vs '" << baseurl << "'";
        // TODO check that bm and baseurl are the same (#ref excluded)
        QTreeWidgetItem *item = new BookmarkItem(bm);
        ret.append(item);
    }
```

#### AUTO 


```{c}
auto certTree = new QTreeView( this );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const AnnotPagePair &pair : qAsConst(mAnnotations) )
            {
                if ( pair.pageNumber != -1 )
                    mDocument->removePageAnnotation( pair.pageNumber, pair.annotation );
            }
```

#### AUTO 


```{c}
auto showBtn = m_fields[QStringLiteral( "ShowScriptButton" )];
```

#### LAMBDA EXPRESSION 


```{c}
[] (const KToolBar * toolBar) {
        return toolBar->objectName() == QStringLiteral("annotationToolBar");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, colorType] () {
        slotSetColor( colorType );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { textpageGenerationFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ann : tools) {
        // action group workaround: connecting to toggled instead of triggered
        connect(ann, &QAction::toggled, this, [this, toolId](bool checked) {
            if (checked) {
                d->selectTool(toolId);
            }
        });
        toolId++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ObjectRect *objectRect : rects) {
        objectRect->transform(matrix);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &f : qAsConst(content_parser.manifest) )
        m_ebookManifest.push_back( pathToUrl( f ) );
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *fwi : qAsConst(m_formWidgets)) {
        Okular::NormalizedRect r = fwi->rect();
        fwi->setWidthHeight(qRound(fabs(r.right - r.left) * m_uncroppedGeometry.width()), qRound(fabs(r.bottom - r.top) * m_uncroppedGeometry.height()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(mEntries)) {
        if (mArchive) {
            const KArchiveFile *entry = static_cast<const KArchiveFile *>(mArchiveDir->entry(file));
            if (entry) {
                dev.reset(entry->createDevice());
            }
        } else if (mDirectory) {
            dev.reset(mDirectory->createDevice(file));
        } else {
            dev.reset(mUnrar->createDevice(file));
        }

        if (!dev.isNull()) {
            reader.setDevice(dev.data());
            if (reader.canRead()) {
                QSize pageSize = reader.size();
                if (reader.transformation() & QImageIOHandler::TransformationRotate90) {
                    pageSize.transpose();
                }
                if (!pageSize.isValid()) {
                    const QImage i = reader.read();
                    if (!i.isNull()) {
                        pageSize = i.size();
                    }
                }
                if (pageSize.isValid()) {
                    pagesVector->replace(count, new Okular::Page(count, pageSize.width(), pageSize.height(), Okular::Rotation0));
                    mPageMap.append(file);
                    count++;
                } else {
                    qCDebug(OkularComicbookDebug) << "Ignoring" << file << "doesn't seem to be an image even if QImageReader::canRead returned true";
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto fieldChoicesWithExportValues = m_field->choicesWithExportValues();
```

#### AUTO 


```{c}
auto childItem1 = new SignatureItem(parentItem, nullptr, SignatureItem::ValidityStatus, pageNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *executingRequest : qAsConst(d->m_executingPixmapRequests)) {
            if (executingRequest->observer() == pObserver) {
                d->cancelRenderingBecauseOf(executingRequest, nullptr);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Document &doc : qAsConst(minDocs))
			results << docList.at((int)doc.docNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &iListing : qAsConst(listing)) {
        // Strip the directory name
        const QString ename = iListing.mid(striplength);

        if (isDirectory(ename))
            app_dir(entry, ename);
        else
            app_file(entry, ename, 0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& backRect : remainingArea )
        p->fillRect( backRect, backColor );
```

#### LAMBDA EXPRESSION 


```{c}
[item]() {
                    QString path;
                    if (item->url.isLocalFile()) {
                        path = item->url.toLocalFile();
                    } else {
                        path = item->url.toString();
                    }
                    QGuiApplication::clipboard()->setText(path);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *viewModeAction : viewModeActions)
    {
        if (viewModeAction->data().toInt() == Okular::Settings::viewMode())
        {
            viewModeAction->setChecked( true );
        }
    }
```

#### AUTO 


```{c}
auto resizer = new KColumnResizer( this );
```

#### LAMBDA EXPRESSION 


```{c}
[](const QToolButton * x)  { return x->toolTip().contains("Typewriter"); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::FormField *f : popplerFormFields) {
        Okular::FormField *of = nullptr;
        switch (f->type()) {
        case Poppler::FormField::FormButton:
            of = new PopplerFormFieldButton(std::unique_ptr<Poppler::FormFieldButton>(static_cast<Poppler::FormFieldButton *>(f)));
            break;
        case Poppler::FormField::FormText:
            of = new PopplerFormFieldText(std::unique_ptr<Poppler::FormFieldText>(static_cast<Poppler::FormFieldText *>(f)));
            break;
        case Poppler::FormField::FormChoice:
            of = new PopplerFormFieldChoice(std::unique_ptr<Poppler::FormFieldChoice>(static_cast<Poppler::FormFieldChoice *>(f)));
            break;
        case Poppler::FormField::FormSignature: {
            of = new PopplerFormFieldSignature(std::unique_ptr<Poppler::FormFieldSignature>(static_cast<Poppler::FormFieldSignature *>(f)));
            break;
        }
        default:;
        }
        if (of)
            // form field created, good - it will take care of the Poppler::FormField
            okularFormFields.append(of);
        else
            // no form field available - delete the Poppler::FormField
            delete f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->currentPage)) {
        QModelIndex index = d->indexForItem(item);
        if (!index.isValid())
            continue;

        item->highlight = false;
        emit dataChanged(index, index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->slotTimedMemoryCheck(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<Okular::NormalizedPoint> &path : inkPathsList) {
        QLinkedList<QPointF> points;
        for (const Okular::NormalizedPoint &p : path) {
            points.append(normPointToPointF(p));
        }
        paths.append(points);
    }
```

#### AUTO 


```{c}
auto childItem4 = new SignatureItem( parentItem, sf, SignatureItem::FieldInfo, currentPage );
```

#### AUTO 


```{c}
auto request = new Okular::PixmapRequest(observer, m_viewPort.pageNumber, width() * dpr, height() * dpr, priority, Okular::PixmapRequest::NoFeature);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
    {
        if (triedOffers.contains(md))
            continue;

        const QStringList mimetypes = md.mimeTypes();
        for (const QString &supported : mimetypes)
        {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type && !exactMatches.contains(md)) {
                exactMatches << md;
            }

            if (type.inherits(supported) && !offers.contains(md))
            {
                offers << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const FontInfo &fi : list )
        {
            emit gotFont( fi );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const SmoothPath &drawing : qAsConst(m_frames[ m_frameIndex ]->drawings) ) {
            drawing.paint( &pmPainter, pmSize.width(), pmSize.height() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &file : files) {
        shell->openUrl(file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &str : choices )
            {
                bool ok = true;
                int val = str.toInt( &ok );
                if ( ok )
                    newchoices.append( val );
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Okular::Action *action, Okular::FormFieldText *fft ) {
                              document->processFormatAction( action, fft );
                          }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Page *p : pagesVector)
            {
                const QLinkedList<Okular::FormField*> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end())
                {
                    delete s;
                    createSignature = false;
                    continue;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        const QModelIndexList annotations = retrieveAnnotations(index);
        for (const QModelIndex &idx : annotations) {
            const QModelIndex authorIndex = m_authorProxy->mapToSource(idx);
            const QModelIndex filterIndex = m_groupProxy->mapToSource(authorIndex);
            const QModelIndex annotIndex = m_filterProxy->mapToSource(filterIndex);
            Okular::Annotation *annotation = m_model->annotationForIndex(annotIndex);
            if (annotation) {
                const int pageNumber = m_model->data(annotIndex, AnnotationModel::PageRole).toInt();
                popup.addAnnotation(annotation, pageNumber);
            }
        }
    }
```

#### AUTO 


```{c}
auto targetDefaultRW = dynamic_cast< Okular::FormFieldText* > ( fields[QStringLiteral( "TargetDefaultRw" )] );
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_document->m_pagesVector)) {
        p->setTextPage(nullptr);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool clean)
            {
                setModified( !clean );
                setWindowTitleFromDocument();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : videoWidgets) {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());

            if (vw->isPlaying() && viewportRectAtZeroZero.intersected(vw->geometry()).isEmpty()) {
                vw->stop();
                vw->pageLeft();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * item : qAsConst( d->items ) )
                {
                    if ( !item->isVisible() )
                        continue;

                    const QRect & itemRect = item->croppedGeometry();
                    if ( selectionRect.intersects( itemRect ) )
                    {
                        // request the textpage if there isn't one
                        okularPage= item->page();
                        qCDebug(OkularUiDebug) << "checking if page" << item->pageNumber() << "has text:" << okularPage->hasTextPage();
                        if ( !okularPage->hasTextPage() )
                            d->document->requestTextPage( okularPage->number() );
                        // grab text in the rect that intersects itemRect
                        QRect rectInItem = selectionRect.intersected( itemRect );
                        rectInItem.translate( -item->uncroppedGeometry().topLeft() );
                        QRect rectInSelection = selectionRect.intersected( itemRect );
                        rectInSelection.translate( -selectionRect.topLeft() );
                        d->tableSelectionParts.append(
                            TableSelectionPart(
                                item,
                                Okular::NormalizedRect( rectInItem, item->uncroppedWidth(), item->uncroppedHeight() ),
                                Okular::NormalizedRect( rectInSelection, selectionRect.width(), selectionRect.height() )
                            )
                        );
                    }
                }
```

#### AUTO 


```{c}
auto detailsFrame = new QFrame(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers))
    {
        if ( o != excludeObserver )
            o->notifyViewportChanged( smoothMove );

        if ( currentPageChanged )
            o->notifyCurrentPageChanged( oldPageNumber, currentViewportPage );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& s1, const KPluginMetaData& s2)
        {
            const QString property = QStringLiteral("X-KDE-Priority");
            return s1.rawData()[property].toInt() > s2.rawData()[property].toInt();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, request] { generatePixmap(request); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &flashVar : flashVars) {
        const int pos = flashVar.indexOf(QLatin1Char('='));
        if (pos == -1)
            continue;

        const QString key = flashVar.left(pos);
        const QString value = flashVar.mid(pos + 1);

        if (key == QLatin1String("source"))
            sourceId = value;
        else if (key == QLatin1String("loop"))
            playbackLoops = (value == QLatin1String("true") ? true : false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
        if (annotation->subType() == Okular::Annotation::AScreen) {
            Okular::ScreenAnnotation *screenAnnotation = static_cast<Okular::ScreenAnnotation *>(annotation);
            resolveMediaLinkReference(screenAnnotation->additionalAction(Okular::Annotation::PageOpening));
            resolveMediaLinkReference(screenAnnotation->additionalAction(Okular::Annotation::PageClosing));
        }

        if (annotation->subType() == Okular::Annotation::AWidget) {
            Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation *>(annotation);
            resolveMediaLinkReference(widgetAnnotation->additionalAction(Okular::Annotation::PageOpening));
            resolveMediaLinkReference(widgetAnnotation->additionalAction(Okular::Annotation::PageClosing));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MatchesVector &mv : qAsConst(*pageMatches)) {
            for (const MatchColor &mc : mv) {
                delete mc.first;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * visibleItem : qAsConst( d->visibleItems ) )
            if ( visibleItem->pageNumber() == pageNumber )
                return false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
                if (pair.pageNumber != -1)
                    mDocument->removePageAnnotation(pair.pageNumber, pair.annotation);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * item : qAsConst( d->items ) )
    {
        // check if a piece of the page intersects the contents rect
        if ( !item->isVisible() || !item->croppedGeometry().intersects( checkRect ) )
            continue;

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry();

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate( itemGeometry.left(), itemGeometry.top() );

        // draw the page outline (black border and bottom-right shadow)
        if ( !itemGeometry.contains( contentsRect ) )
        {
            int itemWidth = itemGeometry.width();
            int itemHeight = itemGeometry.height();
            // draw simple outline
            QPen pen( Qt::black );
            pen.setWidth(0);
            p->setPen( pen );

            QRectF outline( -1.0/dpr, -1.0/dpr, itemWidth + 1.0/dpr, itemHeight + 1.0/dpr );
            p->drawRect( outline );

            // draw bottom/right gradient
            for ( int i = 1; i <= shadowWidth; i++ )
            {
                pen.setColor( interpolateColor( double(i)/( shadowWidth+1 ) ) );
                p->setPen( pen );
                QPointF left( (i-1)/dpr, itemHeight + i/dpr );
                QPointF up( itemWidth + i/dpr, (i-1)/dpr );
                QPointF corner( itemWidth + i/dpr, itemHeight + i/dpr);
                p->drawLine( left, corner );
                p->drawLine( up, corner );
            }
        }

        p->restore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TinyTextEntity *te : qAsConst(d->m_words)) {
            ret.append(new TextEntity(te->text(), new Okular::NormalizedRect(te->area)));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::TextEntity *te : words) {
            if (te->text().isEmpty()) {
                delete te;
                continue;
            }

            Okular::NormalizedRect wordArea = *te->area();

            // convert it from item coordinates to part coordinates
            wordArea.left -= tsp.rectInItem.left;
            wordArea.left /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.right -= tsp.rectInItem.left;
            wordArea.right /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.top -= tsp.rectInItem.top;
            wordArea.top /= (tsp.rectInItem.bottom - tsp.rectInItem.top);
            wordArea.bottom -= tsp.rectInItem.top;
            wordArea.bottom /= (tsp.rectInItem.bottom - tsp.rectInItem.top);

            // convert from part coordinates to table coordinates
            wordArea.left *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.left += tsp.rectInSelection.left;
            wordArea.right *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.right += tsp.rectInSelection.left;
            wordArea.top *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.top += tsp.rectInSelection.top;
            wordArea.bottom *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.bottom += tsp.rectInSelection.top;

            // add to the ticks arrays...
            colTicks.append(qMakePair(wordArea.left, +1));
            colTicks.append(qMakePair(wordArea.right, -1));
            rowTicks.append(qMakePair(wordArea.top, +1));
            rowTicks.append(qMakePair(wordArea.bottom, -1));

            delete te;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *pr : qAsConst( pixmapsToRequest ) )
    {
        QLinkedList< Okular::PixmapRequest * > requestedPixmaps;
        requestedPixmaps.push_back( pr );
        m_parent->requestPixmaps( requestedPixmaps, Okular::Document::NoOption );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Annotation *a, int cb, int ce) { addAnnotation(a, cb, ce); }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->currentPage)) {
        QModelIndex index = d->indexForItem(item);
        if (!index.isValid()) {
            continue;
        }

        item->highlight = true;
        emit dataChanged(index, index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double col : qAsConst(d->tableSelectionCols)) {
                    if (col >= tsp.rectInSelection.left && col <= tsp.rectInSelection.right) {
                        col = (col - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                        const int x =  selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                        screenPainter->drawLine(
                            x, selectionPartRectInternal.top(),
                            x, selectionPartRectInternal.top() + selectionPartRectInternal.height()
                        );
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QScreen *screen : screens) {
        if (screen->geometry().adjusted(-5, -5, 5, 5).contains(cursorPos)) {
            s_lastScreen = screen;
            return screen;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Page *p : qAsConst(pagesVector)) {
                const QLinkedList<Okular::FormField *> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end()) {
                    delete s;
                    createSignature = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const AnnotPagePair &pair : qAsConst(mAnnotations) )
        {
            if ( !mDocument->canRemovePageAnnotation( pair.annotation ) )
                action->setEnabled( false );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(fix_word &fw : widthTable_in_units_of_design_size)
    fw.value = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: pageFormFields )
    {
        fields.insert( ff->name(), static_cast< Okular::FormField* >( ff ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->items)) {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for (FormWidgetIface *fwi : formWidgetsList) {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for (VideoWidget *vw : videoWidgets) {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());

            if (vw->isPlaying() && viewportRectAtZeroZero.intersected(vw->geometry()).isEmpty()) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if (!i->isVisible())
            continue;
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking page" << i->pageNumber();
        kWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects(i->croppedGeometry());
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected(i->croppedGeometry());
        if (intersectionRect.isEmpty()) {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back(i);
        Okular::VisiblePageRect *vItem = new Okular::VisiblePageRect(i->pageNumber(), Okular::NormalizedRect(intersectionRect.translated(-i->uncroppedGeometry().topLeft()), i->uncroppedWidth(), i->uncroppedHeight()));
        visibleRects.push_back(vItem);
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight());
        kWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if (i->page()->hasTilesManager(this) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low) {
            double rectMargin = pixelsToExpand / (double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax(0.0, vItem->rect.left - rectMargin);
            expandedVisibleRect.top = qMax(0.0, vItem->rect.top - rectMargin);
            expandedVisibleRect.right = qMin(1.0, vItem->rect.right + rectMargin);
            expandedVisibleRect.bottom = qMin(1.0, vItem->rect.bottom + rectMargin);
        }

        // if the item has not the right pixmap, add a request for it
        if (!i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect)) {
#ifdef PAGEVIEW_DEBUG
            kWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest *p = new Okular::PixmapRequest(this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), devicePixelRatioF(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous);
            requestedPixmaps.push_back(p);

            if (i->page()->hasTilesManager(this)) {
                p->setNormalizedRect(expandedVisibleRect);
                p->setTile(true);
            } else
                p->setNormalizedRect(vItem->rect);
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if (isEvent) {
            const QRect &geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            const double distance = hypot((geometry.left() + geometry.right()) / 2.0 - (viewportCenterX - 4), (geometry.top() + geometry.bottom()) / 2.0 - viewportCenterY);
            if (distance >= minDistance && nearPageNumber != -1)
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if (geometry.height() > 0 && geometry.width() > 0) {
                // Compute normalized coordinates w.r.t. cropped page
                focusedX = (viewportCenterX - (double)geometry.left()) / (double)geometry.width();
                focusedY = (viewportCenterY - (double)geometry.top()) / (double)geometry.height();
                // Convert to normalized coordinates w.r.t. full page (no-op if not cropped)
                focusedX = i->crop().left + focusedX * i->crop().width();
                focusedY = i->crop().top + focusedY * i->crop().height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : qAsConst(m_fileformats)) {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(mimeName);
            const QStringList globs(mimeType.globPatterns());
            if (globs.isEmpty()) {
                continue;
            }

#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
            globPatterns.unite(QSet<QString>(globs.begin(), globs.end()));
#else
            globPatterns.unite(globs.toSet());
#endif

            namedGlobs[mimeType.comment()].append(globs);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &target : targets) {
            scripts << QStringLiteral("getField(\"%1\").hidden = %2;").arg(target).arg(l->isShowAction() ? QLatin1String("false") : QLatin1String("true"));
        }
```

#### AUTO 


```{c}
auto signatureStatusFormLayout = new QFormLayout(signatureStatusBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                for (double col : qAsConst(d->tableSelectionCols)) {
                    if (col >= tsp.rectInSelection.left && col <= tsp.rectInSelection.right) {
                        col = (col - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                        const int x =  selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                        screenPainter->drawLine(
                            x, selectionPartRectInternal.top(),
                            x, selectionPartRectInternal.top() + selectionPartRectInternal.height()
                        );
                    }
                }
                for (double row : qAsConst(d->tableSelectionRows)) {
                    if (row >= tsp.rectInSelection.top && row <= tsp.rectInSelection.bottom) {
                        row = (row - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                        const int y =  selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                        screenPainter->drawLine(
                            selectionPartRectInternal.left(), y,
                            selectionPartRectInternal.left() + selectionPartRectInternal.width(), y
                        );
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int p, Okular::Page *op) { d->rotationFinished(p, op); }
```

#### AUTO 


```{c}
auto widget = part.m_pageView->viewport()->childAt( tfPos );
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                    QRect selectionPartRectInternal = selectionPartRect;
                    selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                    if ( !selectionPartRect.isNull() && selectionPartRect.intersects( contentsRect ) &&
                        !selectionPartRectInternal.contains( contentsRect ) )
                    {
                        QRect blendRect = selectionPartRectInternal.intersected( contentsRect );
                        // skip rectangles covered by the selection's border
                        if ( blendRect.isValid() )
                        {
                            // grab current pixmap into a new one to colorize contents
                            QPixmap blendedPixmap( blendRect.width()  * devicePixelRatioF(), blendRect.height()  * devicePixelRatioF() );
                            blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                            QPainter p( &blendedPixmap );
                            p.drawPixmap( 0, 0, doubleBuffer,
                                        (blendRect.left() - contentsRect.left()) * devicePixelRatioF(), (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                        blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );

                            QColor blCol = d->mouseSelectionColor.darker( 140 );
                            blCol.setAlphaF( 0.2 );
                            p.fillRect( blendedPixmap.rect(), blCol );
                            p.end();
                            // copy the blended pixmap back to its place
                            pixmapPainter.drawPixmap( blendRect.left(), blendRect.top(), blendedPixmap );
                        }
                        // draw border (red if the selection is too small)
                        pixmapPainter.setPen( d->mouseSelectionColor );
                        pixmapPainter.drawRect( selectionPartRect.adjusted( 0, 0, -1, -1 ) );
                    }
                }
```

#### AUTO 


```{c}
auto childItem2 = new SignatureItem(parentItem, nullptr, SignatureItem::SigningTime, pageNumber);
```

#### LAMBDA EXPRESSION 


```{c}
[this, stampIconName]() { slotStampToolSelected(stampIconName); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Page * pIt : qAsConst(doc->m_pagesVector) )
    {
        numFields += pIt->formFields().size();
    }
```

#### AUTO 


```{c}
auto opacity
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *videoWidget : videoWidgetsList)
                videoWidget->pageEntered();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : mainDirEntries) {
        if (mainDir->entry(entry)->isDirectory()) {
            qWarning() << "Warning: Found a directory inside" << archivePath << " - Okular does not create files like that so it is most probably forged.";
            return nullptr;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Shell *shell : qAsConst(shells)) {
            shell->savePropertiesInternal(&config, ++numWindows);
            // Windows aren't necessarily closed on shutdown, but we'll use
            // this as a way to trigger the destructor code, which is normally
            // connected to the aboutToQuit signal
            shell->close();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * i : qAsConst( d->items ) )
    {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for ( FormWidgetIface *fwi :  formWidgetsList)
        {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for ( VideoWidget *vw : videoWidgets )
        {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );

            if ( vw->isPlaying() && viewportRectAtZeroZero.intersected( vw->geometry() ).isEmpty() ) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if ( !i->isVisible() )
            continue;
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking page" << i->pageNumber();
        kWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects( i->croppedGeometry() );
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected( i->croppedGeometry() );
        if ( intersectionRect.isEmpty() )
        {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back( i );
        Okular::VisiblePageRect * vItem = new Okular::VisiblePageRect( i->pageNumber(), Okular::NormalizedRect( intersectionRect.translated( -i->uncroppedGeometry().topLeft() ), i->uncroppedWidth(), i->uncroppedHeight() ) );
        visibleRects.push_back( vItem );
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap( this, i->uncroppedWidth(), i->uncroppedHeight() );
        kWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if ( i->page()->hasTilesManager( this ) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low )
        {
            double rectMargin = pixelsToExpand/(double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax( 0.0, vItem->rect.left - rectMargin );
            expandedVisibleRect.top = qMax( 0.0, vItem->rect.top - rectMargin );
            expandedVisibleRect.right = qMin( 1.0, vItem->rect.right + rectMargin );
            expandedVisibleRect.bottom = qMin( 1.0, vItem->rect.bottom + rectMargin );
        }

        // if the item has not the right pixmap, add a request for it
        if ( !i->page()->hasPixmap( this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect ) )
        {
#ifdef PAGEVIEW_DEBUG
            kWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest * p = new Okular::PixmapRequest( this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous );
            requestedPixmaps.push_back( p );

            if ( i->page()->hasTilesManager( this ) )
            {
                p->setNormalizedRect( expandedVisibleRect );
                p->setTile( true );
            }
            else
                p->setNormalizedRect( vItem->rect );
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if ( isEvent )
        {
            const QRect & geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            double distance = hypot( (geometry.left() + geometry.right()) / 2 - (viewportCenterX - 4),
                                     (geometry.top() + geometry.bottom()) / 2 - viewportCenterY );
            if ( distance >= minDistance && nearPageNumber != -1 )
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if ( geometry.height() > 0 && geometry.width() > 0 )
            {
                focusedX = ( viewportCenterX - (double)geometry.left() ) / (double)geometry.width();
                focusedY = ( viewportCenterY - (double)geometry.top() ) / (double)geometry.height();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, opacity] () {
            d->annotator->setAnnotationOpacity( opacity / 100 );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SmoothPath &drawing : qAsConst(m_frames[m_frameIndex]->drawings)) {
            drawing.paint(&pmPainter, pmSize.width(), pmSize.height());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormField *ff : qAsConst(formfields) )
            {
                hashedforms[ff->id()] = ff;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation * a : annotations )
        {
            if ( a->subType() == Okular::Annotation::AMovie )
            {
                Okular::MovieAnnotation * movieAnn = static_cast< Okular::MovieAnnotation * >( a );
                VideoWidget * vw = new VideoWidget( movieAnn, movieAnn->movie(), m_document, this );
                frame->videoWidgets.insert( movieAnn->movie(), vw );
                vw->pageInitialized();
            }
            else if ( a->subType() == Okular::Annotation::ARichMedia )
            {
                Okular::RichMediaAnnotation * richMediaAnn = static_cast< Okular::RichMediaAnnotation * >( a );
                if ( richMediaAnn->movie() ) {
                    VideoWidget * vw = new VideoWidget( richMediaAnn, richMediaAnn->movie(), m_document, this );
                    frame->videoWidgets.insert( richMediaAnn->movie(), vw );
                    vw->pageInitialized();
                }
            }
            else if ( a->subType() == Okular::Annotation::AScreen )
            {
                const Okular::ScreenAnnotation * screenAnn = static_cast< Okular::ScreenAnnotation * >( a );
                Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation( screenAnn );
                if ( movie )
                {
                    VideoWidget * vw = new VideoWidget( screenAnn, movie, m_document, this );
                    frame->videoWidgets.insert( movie, vw );
                    vw->pageInitialized();
                }
            }
        }
```

#### AUTO 


```{c}
auto resizer = new KColumnResizer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int pageNumber : qAsConst(*pagesToNotify)) {
        for (DocumentObserver *observer : qAsConst(m_observers)) {
            observer->notifyPageChanged(pageNumber, DocumentObserver::Highlights);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](DocumentInfo::Key k, const QString &v) { addMetaData(k, v); }
```

#### AUTO 


```{c}
auto verticalScaling   = painterWindow.height() / pageSize.height();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &iChar : query) {
        const QChar ch = iChar.toLower();

        // a quote either begins or ends the phrase
        if (ch == '"') {
            keeper.addTerm(term);

            if (keeper.isInPhrase())
                keeper.endPhrase();
            else
                keeper.beginPhrase();

            continue;
        }

        // If new char does not stop the word, add ot and continue
        if (ch.isLetterOrNumber() || partOfWordChars.indexOf(ch) != -1) {
            term.append(ch);
            continue;
        }

        // If it is a split char, add this term and split char as separate term
        if (splitChars.indexOf(ch) != -1) {
            // Add existing term if present
            keeper.addTerm(term);

            // Change the term variable, so it will be added when we exit this block
            term = ch;
        }

        // Just add the word; it is most likely a space or terminated by tokenizer.
        keeper.addTerm(term);
        term = QString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            if (!annotation)
                continue;

            annotation->setCreationDate(QDateTime::currentDateTime());
            annotation->setModificationDate(QDateTime::currentDateTime());
            annotation->setAuthor(Okular::Settings::identityAuthor());
            m_document->addPageAnnotation(m_lockedItem->pageNumber(), annotation);

            if (signatureMode())
                m_document->sign(annotation);

            if (annotation->openDialogAfterCreation())
                m_pageView->openAnnotationWindow(annotation, m_lockedItem->pageNumber());
        }
```

#### AUTO 


```{c}
auto widget = win2->window()->childAt(win2->mapTo(win2->window(), QPoint(10,  10)));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &p : points ) {
                    QPointF point = getPointFromString( p );
                    path.lineTo( point );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : geom) {
                        if (newrect.isNull())
                            newrect = r;
                        else
                            newrect |= r;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &searchProvider : searchProviders )
            {
                action = new QAction( searchProvider, webShortcutsMenu );
                action->setIcon( QIcon::fromTheme( filterData.iconNameForPreferredSearchProvider( searchProvider ) ) );
                action->setData( filterData.queryForPreferredSearchProvider( searchProvider ) );
                connect( action, &QAction::triggered, this, &PageView::slotHandleWebShortcutAction );
                webShortcutsMenu->addAction( action );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
        // set the 'page field' (see PixmapRequest) and check if it is valid
        qCDebug(OkularCoreDebug).nospace() << "request observer=" << request->observer() << " " << request->width() << "x" << request->height() << "@" << request->pageNumber();
        if (d->m_pagesVector.value(request->pageNumber()) == 0) {
            // skip requests referencing an invalid page (must not happen)
            delete request;
            continue;
        }

        request->d->mPage = d->m_pagesVector.value(request->pageNumber());

        if (request->isTile()) {
            // Change the current request rect so that only invalid tiles are
            // requested. Also make sure the rect is tile-aligned.
            NormalizedRect tilesRect;
            const QList<Tile> tiles = request->d->tilesManager()->tilesAt(request->normalizedRect(), TilesManager::TerminalTile);
            QList<Tile>::const_iterator tIt = tiles.constBegin(), tEnd = tiles.constEnd();
            while (tIt != tEnd) {
                const Tile &tile = *tIt;
                if (!tile.isValid()) {
                    if (tilesRect.isNull())
                        tilesRect = tile.rect();
                    else
                        tilesRect |= tile.rect();
                }

                tIt++;
            }

            request->setNormalizedRect(tilesRect);
        }

        if (!request->asynchronous())
            request->d->mPriority = 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *f : formFields) {
            if (item->form->id() == f->id()) {
                item->form = static_cast<Okular::FormFieldSignature *>(f);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : rgn) {
        p.fillRect(r, Okular::Settings::slidesBackgroundColor());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldSignature *signature : signatureFormFields) {
                    if (signature->signatureType() == Okular::FormFieldSignature::UnsignedSignature) {
                        anySignatureUnsigned = true;
                    } else {
                        const Okular::SignatureInfo &info = signature->signatureInfo();
                        if (info.signatureStatus() != SignatureInfo::SignatureValid) {
                            allSignaturesValid = false;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::FontInfo &font : qAsConst(fonts)) {
        Okular::FontInfo of;
        of.setName(font.name());
        of.setSubstituteName(font.substituteName());
        of.setType(convertPopplerFontInfoTypeToOkularFontInfoType(font.type()));
        of.setEmbedType(embedTypeForPopplerFontInfo(font));
        of.setFile(font.file());
        of.setCanBeExtracted(of.embedType() != Okular::FontInfo::NotEmbedded);

        QVariant nativeId;
        nativeId.setValue(font);
        of.setNativeId(nativeId);

        list.append(of);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : qAsConst(m_fileformats)) {
        QMimeType mimeType = mimeDatabase.mimeTypeForName(mimeName);
        mimetypes << mimeType.name();
    }
```

#### AUTO 


```{c}
auto update_scroller = [=](){
        d->scroller->scrollTo(QPoint(horizontalScrollBar()->value(), verticalScrollBar()->value()), 0); //sync scroller with scrollbar
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::EmbeddedFile *pef : popplerFiles)
        {
            docEmbeddedFiles.append(new PDFEmbeddedFile(pef));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
            AllocatedPixmap *p = searchLowestPriorityPixmap(false, true, observer);
            if (!p) { // No pixmap to remove
                continue;
            }

            clean_hits++;

            TilesManager *tilesManager = m_pagesVector.at(p->page)->d->tilesManager(observer);
            if (tilesManager && tilesManager->totalMemory() > 0) {
                qulonglong memoryDiff = p->memory;
                NormalizedRect visibleRect;
                if (visibleRects.contains(p->page)) {
                    visibleRect = visibleRects[p->page]->rect;
                }

                // Free non visible tiles
                tilesManager->cleanupPixmapMemory(memoryToFree, visibleRect, currentViewportPage);

                p->memory = tilesManager->totalMemory();
                memoryDiff -= p->memory;
                memoryToFree = (memoryDiff < memoryToFree) ? (memoryToFree - memoryDiff) : 0;
                m_allocatedPixmapsTotalMemory -= memoryDiff;

                if (p->memory > 0) {
                    pixmapsToKeep.push_back(p);
                } else {
                    delete p;
                }
            } else {
                pixmapsToKeep.push_back(p);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *a : annotations) {
        if (a->subType() == Okular::Annotation::AMovie) {
            Okular::MovieAnnotation *movieAnn = static_cast<Okular::MovieAnnotation *>(a);
            VideoWidget *vw = new VideoWidget(movieAnn, movieAnn->movie(), d->document, viewport());
            item->videoWidgets().insert(movieAnn->movie(), vw);
            vw->pageInitialized();
        } else if (a->subType() == Okular::Annotation::ARichMedia) {
            Okular::RichMediaAnnotation *richMediaAnn = static_cast<Okular::RichMediaAnnotation *>(a);
            VideoWidget *vw = new VideoWidget(richMediaAnn, richMediaAnn->movie(), d->document, viewport());
            item->videoWidgets().insert(richMediaAnn->movie(), vw);
            vw->pageInitialized();
        } else if (a->subType() == Okular::Annotation::AScreen) {
            const Okular::ScreenAnnotation *screenAnn = static_cast<Okular::ScreenAnnotation *>(a);
            Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation(screenAnn);
            if (movie) {
                VideoWidget *vw = new VideoWidget(screenAnn, movie, d->document, viewport());
                item->videoWidgets().insert(movie, vw);
                vw->pageInitialized();
            }
        }
    }
```

#### AUTO 


```{c}
auto factory = loader.factory();
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString &t : result )
    {
        for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QStringLiteral( "%1=\"(.*)\"" ).arg( attribute ) );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                t = attribute + '=' + match.captured( 1 );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MatchesVector &mv : qAsConst(*pageMatches)) {
            qDeleteAll(mv);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : qAsConst(result)) {
            uniqueMimetypes.insert(mimeDatabase.mimeTypeForName(mimeName));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &retI : ret)
    {
        const TextEntity * orig = retI;
        retI = new TextEntity( orig->text(), new Okular::NormalizedRect(orig->transformedArea ( d->rotationMatrix() )) );
        delete orig;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MatchColor &mc : it.value()) {
                it.key()->d->setHighlight(searchID, mc.first, mc.second);
                delete mc.first;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *pr : qAsConst(pixmapsToRequest)) {
        QList<Okular::PixmapRequest *> requestedPixmaps;
        requestedPixmaps.push_back(pr);
        m_parent->requestPixmaps(requestedPixmaps, Okular::Document::NoOption);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &flashVar : flashVars ) {
        const int pos = flashVar.indexOf( QLatin1Char( '=' ) );
        if ( pos == -1 )
            continue;

        const QString key = flashVar.left( pos );
        const QString value = flashVar.mid( pos + 1 );

        if ( key == QLatin1String( "source" ) )
            sourceId = value;
        else if ( key == QLatin1String( "loop" ) )
            playbackLoops = ( value == QLatin1String( "true" ) ? true : false );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QWidget *page : qAsConst(m_color_pages) ) {
        page->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NormalizedPoint &p : qAsConst(transformedLinePoints)) {
            polygon.append(QPointF(p.x, p.y));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto& stamp : StampAnnotationWidget::defaultStamps ) {

        KToggleAction * ann = new KToggleAction( d->stampIcon( stamp.second ), stamp.first, this);
        if ( !d->aStamp->defaultAction() )
            d->aStamp->setDefaultAction( ann );
        d->aStamp->addAction( ann );
        d->agTools->addAction( ann );
        // action group workaround: connecting to toggled instead of triggered
        // (because deselectAllAnnotationActions has to call triggered)
        connect( ann, &QAction::toggled, this, [this, stamp] ( bool checked ) {
            if ( checked )
                d->slotStampToolSelected( stamp.second );
        } );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->playOrPause(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : rgn)
            m_pageView->viewport()->update(r.translated(-areaPos));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : pe->region()) {
        if (!r.isValid()) {
            continue;
        }
#ifdef ENABLE_PROGRESS_OVERLAY
        const QRect dR(QRectF(r.x() * dpr, r.y() * dpr, r.width() * dpr, r.height() * dpr).toAlignedRect());
        if (Okular::Settings::slidesShowProgress() && r.intersects(m_overlayGeometry)) {
            // backbuffer the overlay operation
            QPixmap backPixmap(dR.size());
            backPixmap.setDevicePixelRatio(dpr);
            QPainter pixPainter(&backPixmap);

            // first draw the background on the backbuffer
            pixPainter.drawPixmap(QPoint(0, 0), m_lastRenderedPixmap, dR);

            // then blend the overlay (a piece of) over the background
            QRect ovr = m_overlayGeometry.intersected(r);
            pixPainter.drawPixmap((ovr.left() - r.left()), (ovr.top() - r.top()), m_lastRenderedOverlay, (ovr.left() - m_overlayGeometry.left()) * dpr, (ovr.top() - m_overlayGeometry.top()) * dpr, ovr.width() * dpr, ovr.height() * dpr);

            // finally blit the pixmap to the screen
            pixPainter.end();
            const QRect backPixmapRect = backPixmap.rect();
            const QRect dBackPixmapRect(QRectF(backPixmapRect.x() * dpr, backPixmapRect.y() * dpr, backPixmapRect.width() * dpr, backPixmapRect.height() * dpr).toAlignedRect());
            painter.drawPixmap(r.topLeft(), backPixmap, dBackPixmapRect);
        } else {
#endif
            // copy the rendered pixmap to the screen
            painter.drawPixmap(r.topLeft(), m_lastRenderedPixmap, dR);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, opacity]() { d->annotator->setAnnotationOpacity(opacity / 100); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldSignature *sf : signatureFormFields) {
        const Okular::SignatureInfo &info = sf->signatureInfo();

        const int pageNumber = sf->page()->number();

        // based on whether or not signature form is a nullptr it is decided if clicking on an item should change the viewport.
        auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, pageNumber);
        parentItem->displayString = i18n("Rev. %1: Signed By %2", revNumber, info.signerName());

        auto childItem1 = new SignatureItem(parentItem, nullptr, SignatureItem::ValidityStatus, pageNumber);
        childItem1->displayString = SignatureGuiUtils::getReadableSignatureStatus(info.signatureStatus());

        auto childItem2 = new SignatureItem(parentItem, nullptr, SignatureItem::SigningTime, pageNumber);
        childItem2->displayString = i18n("Signing Time: %1", info.signingTime().toString(Qt::DefaultLocaleLongDate));

        const QString reason = info.reason();
        if (!reason.isEmpty()) {
            auto childItem3 = new SignatureItem(parentItem, nullptr, SignatureItem::Reason, pageNumber);
            childItem3->displayString = i18n("Reason: %1", reason);
        }

        auto childItem4 = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, pageNumber);
        childItem4->displayString = i18n("Field: %1 on page %2", sf->name(), pageNumber + 1);

        ++revNumber;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QToolButton *button : qAsConst(m_buttons) )
        if ( button )
        {
            button->setDefaultAction( action );
            button->setToolTip( i18n("Click to use the current selection tool\nClick on the arrow to choose another selection tool") );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::NormalizedRect &r : qAsConst(*selection) )
                {
                    Okular::HighlightAnnotation::Quad q;
                    q.setCapStart( false );
                    q.setCapEnd( false );
                    q.setFeather( 1.0 );
                    q.setPoint( Okular::NormalizedPoint( r.left, r.bottom ), 0 );
                    q.setPoint( Okular::NormalizedPoint( r.right, r.bottom ), 1 );
                    q.setPoint( Okular::NormalizedPoint( r.right, r.top ), 2 );
                    q.setPoint( Okular::NormalizedPoint( r.left, r.top ), 3 );
                    ha->highlightQuads().append( q );
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Annotation *a : m_annotations)
    {
        if ( a->uniqueName() == uniqueName )
            return a;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SmoothPath &drawing : m_frames[m_frameIndex]->drawings) {
            drawing.paint(&pmPainter, pmSize.width(), pmSize.height());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(mEntries)) {
        if (mArchive) {
            const KArchiveFile *entry = static_cast<const KArchiveFile *>(mArchiveDir->entry(file));
            if (entry) {
                dev.reset(entry->createDevice());
            }
        } else if (mDirectory) {
            dev.reset(mDirectory->createDevice(file));
        } else {
            dev.reset(mUnrar->createDevice(file));
        }

        if (!dev.isNull()) {
            reader.setDevice(dev.data());
            if (reader.canRead()) {
                QSize pageSize = reader.size();
                if (reader.transformation() & QImageIOHandler::TransformationRotate90) {
                    pageSize.transpose();
                }
                if (!pageSize.isValid()) {
                    const QImage i = reader.read();
                    if (!i.isNull())
                        pageSize = i.size();
                }
                if (pageSize.isValid()) {
                    pagesVector->replace(count, new Okular::Page(count, pageSize.width(), pageSize.height(), Okular::Rotation0));
                    mPageMap.append(file);
                    count++;
                } else {
                    qCDebug(OkularComicbookDebug) << "Ignoring" << file << "doesn't seem to be an image even if QImageReader::canRead returned true";
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust(1, 1, -1, -1);
                if (!selectionPartRect.isNull() && selectionPartRect.intersects(contentsRect) && !selectionPartRectInternal.contains(contentsRect)) {
                    screenPainter.setPen(palette().color(QPalette::Active, QPalette::Highlight).darker(110));
                    screenPainter.drawRect(selectionPartRect);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Poppler::FormField *f : popplerFormFields )
    {
        Okular::FormField * of = nullptr;
        switch ( f->type() )
        {
            case Poppler::FormField::FormButton:
                of = new PopplerFormFieldButton( std::unique_ptr<Poppler::FormFieldButton>( static_cast<Poppler::FormFieldButton*>( f ) ) );
                break;
            case Poppler::FormField::FormText:
                of = new PopplerFormFieldText( std::unique_ptr<Poppler::FormFieldText>( static_cast<Poppler::FormFieldText*>( f ) ) );
                break;
            case Poppler::FormField::FormChoice:
                of = new PopplerFormFieldChoice( std::unique_ptr<Poppler::FormFieldChoice>( static_cast<Poppler::FormFieldChoice*>( f ) ) );
                break;
            case Poppler::FormField::FormSignature: {
                of = new PopplerFormFieldSignature( std::unique_ptr<Poppler::FormFieldSignature>( static_cast<Poppler::FormFieldSignature*>( f ) ) );
                break;
            }
            default: ;
        }
        if ( of )
            // form field created, good - it will take care of the Poppler::FormField
            okularFormFields.append( of );
        else
            // no form field available - delete the Poppler::FormField
            delete f;
    }
```

#### AUTO 


```{c}
auto nextIterator = std::list<DocumentViewport>::const_iterator(d->m_viewportIterator);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QListWidgetItem *item : selection) {
        rows.append(row(item));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ObjectRect *objRect : qAsConst(m_page->m_rects)) {
        objRect->transform(matrix);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * item : qAsConst( d->items ) )
    {
        const bool hadfocus = item->setFormWidgetsVisible( on );
        somehadfocus = somehadfocus || hadfocus;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message) { m_openError = message; }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QWidget * widget) {
        return qobject_cast<const KParts::MainWindow *>( widget ) != nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Hyperlink &dviLink : qAsConst(pageInfo->hyperLinkList)) {
        QRect boxArea = dviLink.box;
        double nl = (double)boxArea.left() / pageWidth, nt = (double)boxArea.top() / pageHeight, nr = (double)boxArea.right() / pageWidth, nb = (double)boxArea.bottom() / pageHeight;

        QString linkText = dviLink.linkText;
        if (linkText.startsWith(QLatin1String("#"))) {
            linkText = linkText.mid(1);
        }
        Anchor anch = m_dviRenderer->findAnchor(linkText);

        Okular::Action *okuLink = nullptr;

        /* distinguish between local (-> anchor) and remote links */
        if (anch.isValid()) {
            /* internal link */
            Okular::DocumentViewport vp;
            fillViewportFromAnchor(vp, anch, pageWidth, pageHeight);

            okuLink = new Okular::GotoAction(QLatin1String(""), vp);
        } else {
            okuLink = new Okular::BrowseAction(QUrl::fromUserInput(dviLink.linkText));
        }
        if (okuLink) {
            Okular::ObjectRect *orlink = new Okular::ObjectRect(nl, nt, nr, nb, false, Okular::ObjectRect::Action, okuLink);
            dviLinks.push_front(orlink);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *executingRequest : qAsConst( d->m_executingPixmapRequests ) )
        {
            if ( executingRequest->observer() == pObserver ) {
                d->cancelRenderingBecauseOf( executingRequest, nullptr );
            }
        }
```

#### AUTO 


```{c}
auto childItem1 = new SignatureItem( parentItem, nullptr, SignatureItem::ValidityStatus, currentPage );
```

#### RANGE FOR STATEMENT 


```{c}
for (const int page : qAsConst(d->pagesWithTextSelection)) {
            d->document->setPageTextSelection(page, nullptr, QColor());
        }
```

#### AUTO 


```{c}
const auto currentViewportIterator = QLinkedList<DocumentViewport>::const_iterator(m_viewportIterator);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::HighlightAnnotation::Quad &oQuad : oQuads) {
        Poppler::HighlightAnnotation::Quad pQuad;
        pQuad.points[0] = normPointToPointF(oQuad.point(3));
        pQuad.points[1] = normPointToPointF(oQuad.point(2));
        pQuad.points[2] = normPointToPointF(oQuad.point(1));
        pQuad.points[3] = normPointToPointF(oQuad.point(0));
        pQuad.capStart = oQuad.capStart();
        pQuad.capEnd = oQuad.capEnd();
        pQuad.feather = oQuad.feather();
        pQuads << pQuad;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&url]( const TabState state ){
                     return state.part->url() == url;
                 }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::Annotation *popplerRevision : popplerRevisions) {
            bool deletePopplerRevision;
            Okular::Annotation::Revision okularRevision;
            okularRevision.setAnnotation(createAnnotationFromPopplerAnnotation(popplerRevision, popplerPage, &deletePopplerRevision));
            okularRevision.setScope(popplerToOkular(popplerRevision->revisionScope()));
            okularRevision.setType(popplerToOkular(popplerRevision->revisionType()));
            okularRevisions << okularRevision;

            if (deletePopplerRevision) {
                delete popplerRevision;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &qurl : qAsConst(pageList))
    {
        QString url = qurl.toString();
        const QString urlLower = url.toLower();
        if (!urlLower.endsWith(QLatin1String(".html")) && !urlLower.endsWith(QLatin1String(".htm")))
            continue;

        int pos = url.indexOf (QLatin1Char(('#')));
        // insert the url into the maps, but insert always the variant without the #ref part
        QString tmpUrl = pos == -1 ? url : url.left(pos);

        // url already there, abort insertion
        if (m_urlPage.contains(tmpUrl)) continue;

        int foundPage = tmpPageList.value(tmpUrl, -1);
        if (foundPage != -1 ) {
            m_urlPage.insert(tmpUrl, foundPage);
            m_pageUrl[foundPage] = tmpUrl;
        } else {
            //add pages not present in toc
            m_urlPage.insert(tmpUrl, pageNum);
            m_pageUrl.append(tmpUrl);
            pageNum++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &anchorName : anchorNames) {
                    documentAnchors.insert(anchorName, parent);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                    QRect selectionPartRectInternal = selectionPartRect;
                    selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                    if ( !selectionPartRect.isNull() && selectionPartRect.intersects( contentsRect ) &&
                        !selectionPartRectInternal.contains( contentsRect ) )
                    {
                        screenPainter.setPen( palette().color( QPalette::Active, QPalette::Highlight ).darker(110) );
                        screenPainter.drawRect( selectionPartRect );
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[view]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains go-to link action
        QAction *goToAction = qobject_cast<QAction*>(menu->findChild<QAction*>("GoToAction"));
        QVERIFY(goToAction);

        // check if the "follow this link" action is not visible
        QAction *processLinkAction = qobject_cast<QAction*>(menu->findChild<QAction*>("ProcessLinkAction"));
        QVERIFY(!processLinkAction);

        // check if the "copy link address" action is not visible
        QAction *copyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyLinkLocationAction"));
        QVERIFY(!copyLinkLocation);

        // close menu to continue test
        menu->close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *ann : qAsConst(d->textQuickTools)) {
        ann->setEnabled(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &t : result) {
        t.replace(QLatin1String("\\,"), QLatin1String(","));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        d->aShowToolBar->setChecked( false );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->aToolBarVisibility->setChecked(true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *fwi : formWidgetsList) {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : list) {
                const QRect wordRect = word.area().geometry(pageWidth, pageHeight);

                if (topRect.intersects(wordRect))
                    list1.append(word);
                else
                    list2.append(word);
            }
```

#### AUTO 


```{c}
auto signatureStatusFormLayout = new QFormLayout( signatureStatusBox );
```

#### LAMBDA EXPRESSION 


```{c}
[this, searchText] { Q_EMIT triggerSearch(searchText); }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
        // add request to the 'stack' at the right place
        if (!request->priority()) {
            // add priority zero requests to the top of the stack
            d->m_pixmapRequestsStack.append(request);
        } else {
            // insert in stack sorted by priority
            sIt = d->m_pixmapRequestsStack.begin();
            sEnd = d->m_pixmapRequestsStack.end();
            while (sIt != sEnd && (*sIt)->priority() > request->priority()) {
                ++sIt;
            }
            d->m_pixmapRequestsStack.insert(sIt, request);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &c : childrenNumberAndMoreStuff) {
                    if (c.isDigit()) {
                        ++indexOfFirstNonDigit;
                    } else {
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( const WordWithCharacters &word : list )
            {
                const QRect wordRect = word.area().geometry(pageWidth,pageHeight);

                if(topRect.intersects(wordRect))
                    list1.append(word);
                else
                    list2.append(word);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
                observer->notifyPageChanged(pageNumber, DocumentObserver::Highlights);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsRenderNode &child : children) {
        if (child.name == name) {
            return &child;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            if (annotation->subType() == Okular::Annotation::AWidget) {
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation *>(annotation);
                d->document->processAction(widgetAnnotation->additionalAction(Okular::Annotation::PageOpening));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *f : pages[item->page]->formFields() )
        {
            if ( item->form->id() == f->id() )
            {
                item->form = static_cast<Okular::FormFieldSignature*>( f );
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormField *f : formFields) {
            if (f->type() == Okular::FormField::FormSignature)
                isDigitallySigned = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( TOCItem *item : qAsConst(d->itemsToOpen) )
        {
            const QModelIndex index = d->indexForItem( item );
            if ( !index.isValid() )
                continue;

            // TODO misusing parent() here, fix
            QMetaObject::invokeMethod( QObject::parent(), "expand", Qt::QueuedConnection, Q_ARG( QModelIndex, index ) );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (m_document->metaData(QStringLiteral("ShowStampsWarning")).toString() == QLatin1String("yes")) {
                KMessageBox::information(
                    nullptr, i18nc("@info", "Stamps inserted in PDF documents are not visible in PDF readers other than Okular"), i18nc("@title:window", "Experimental feature"), QStringLiteral("stampAnnotationWarning"));
            }
        }
```

#### AUTO 


```{c}
const auto defaultStamps = StampAnnotationWidget::defaultStamps();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(entries)) {
            const KArchiveEntry *relSubEntry = relDir->entry(entry);
            if (!relSubEntry->isFile())
                continue;

            const KZipFileEntry *relSubFile = static_cast<const KZipFileEntry *>(relSubEntry);
            data.append(relSubFile->data());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Document &doc : qAsConst(minDocs)) {
            results << docList.at((int)doc.docNumber);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (View *view : qAsConst(m_views)) {
                                if (view->name() == viewName) {
                                    loadViewsInfo(view, viewElement);
                                    loadedAnything = true;
                                    break;
                                }
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TileNode &tile : d->tiles )
        d->deleteTiles( tile );
```

#### RANGE FOR STATEMENT 


```{c}
for (const HighlightAnnotation::Quad &quad : m_highlightQuads) {
        QLinkedList<NormalizedPoint> pathPoints;

        // first, we check if the point is within the area described by the 4 quads
        // this is the case, if the point is always on one side of each segments delimiting the polygon:
        pathPoints << quad.transformedPoint(0);
        int directionVote = 0;
        for (int i = 1; i < 5; ++i) {
            NormalizedPoint thisPoint = quad.transformedPoint(i % 4);
            directionVote += (isLeftOfVector(pathPoints.back(), thisPoint, point)) ? 1 : -1;
            pathPoints << thisPoint;
        }
        if (abs(directionVote) == 4) {
            return 0;
        }

        // if that's not the case, we treat the outline as path and simply determine
        // the distance from the path to the point
        const double thisOutsideDistance = ::distanceSqr(x, y, xScale, yScale, pathPoints);
        if (thisOutsideDistance < outsideDistance) {
            outsideDistance = thisOutsideDistance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : annotations) {
            const QModelIndex authorIndex = m_authorProxy->mapToSource(idx);
            const QModelIndex filterIndex = m_groupProxy->mapToSource(authorIndex);
            const QModelIndex annotIndex = m_filterProxy->mapToSource(filterIndex);
            Okular::Annotation *annotation = m_model->annotationForIndex(annotIndex);
            if (annotation) {
                const int pageNumber = m_model->data(annotIndex, AnnotationModel::PageRole).toInt();
                popup.addAnnotation(annotation, pageNumber);
            }
        }
```

#### AUTO 


```{c}
auto addViewMode = [=](QAction *a, const QString &name, Okular::Settings::EnumViewMode::type id) {
        a->setCheckable(true);
        a->setData(int(id));
        d->aViewModeMenu->addAction(a);
        ac->addAction(name, a);
        d->viewModeActionGroup->addAction(a);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            if (!annotation)
                continue;

            annotation->setCreationDate(QDateTime::currentDateTime());
            annotation->setModificationDate(QDateTime::currentDateTime());
            annotation->setAuthor(Okular::Settings::identityAuthor());
            m_document->addPageAnnotation(m_lockedItem->pageNumber(), annotation);

            if (signatureMode())
                m_document->sign();

            if (annotation->openDialogAfterCreation())
                m_pageView->openAnnotationWindow(annotation, m_lockedItem->pageNumber());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Okular::Action *action, Okular::FormFieldText *fft, bool &ok ) {
                          document->processKeystrokeAction( action, fft, ok );
                          }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormFieldButton *formButton : qAsConst(m_formButtons)) {
        formButton->setState(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, link]() {
            d->document->processAction( link );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : rgn) {
        if (useSubdivision) {
            // set 'contentsRect' to a part of the sub-divided region
            contentsRect = r.translated(areaPos).intersected(viewportRect);
            if (!contentsRect.isValid())
                continue;
        }
#ifdef PAGEVIEW_DEBUG
        qCDebug(OkularUiDebug) << contentsRect;
#endif

        // note: this check will take care of all things requiring alpha blending (not only selection)
        bool wantCompositing = !selectionRect.isNull() && contentsRect.intersects(selectionRect);
        // also alpha-blend when there is a table selection...
        wantCompositing |= !d->tableSelectionParts.isEmpty();

        if (wantCompositing && Okular::Settings::enableCompositing()) {
            // create pixmap and open a painter over it (contents{left,top} becomes pixmap {0,0})
            QPixmap doubleBuffer(contentsRect.size() * devicePixelRatioF());
            doubleBuffer.setDevicePixelRatio(devicePixelRatioF());
            QPainter pixmapPainter(&doubleBuffer);

            pixmapPainter.translate(-contentsRect.left(), -contentsRect.top());

            // 1) Layer 0: paint items and clear bg on unpainted rects
            drawDocumentOnPainter(contentsRect, &pixmapPainter);
            // 2a) Layer 1a: paint (blend) transparent selection (rectangle)
            if (!selectionRect.isNull() && selectionRect.intersects(contentsRect) && !selectionRectInternal.contains(contentsRect)) {
                QRect blendRect = selectionRectInternal.intersected(contentsRect);
                // skip rectangles covered by the selection's border
                if (blendRect.isValid()) {
                    // grab current pixmap into a new one to colorize contents
                    QPixmap blendedPixmap(blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF());
                    blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                    QPainter p(&blendedPixmap);

                    p.drawPixmap(0,
                                 0,
                                 doubleBuffer,
                                 (blendRect.left() - contentsRect.left()) * devicePixelRatioF(),
                                 (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                 blendRect.width() * devicePixelRatioF(),
                                 blendRect.height() * devicePixelRatioF());

                    QColor blCol = selBlendColor.darker(140);
                    blCol.setAlphaF(0.2);
                    p.fillRect(blendedPixmap.rect(), blCol);
                    p.end();
                    // copy the blended pixmap back to its place
                    pixmapPainter.drawPixmap(blendRect.left(), blendRect.top(), blendedPixmap);
                }
                // draw border (red if the selection is too small)
                pixmapPainter.setPen(selBlendColor);
                pixmapPainter.drawRect(selectionRect.adjusted(0, 0, -1, -1));
            }
            // 2b) Layer 1b: paint (blend) transparent selection (table)
            for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust(1, 1, -1, -1);
                if (!selectionPartRect.isNull() && selectionPartRect.intersects(contentsRect) && !selectionPartRectInternal.contains(contentsRect)) {
                    QRect blendRect = selectionPartRectInternal.intersected(contentsRect);
                    // skip rectangles covered by the selection's border
                    if (blendRect.isValid()) {
                        // grab current pixmap into a new one to colorize contents
                        QPixmap blendedPixmap(blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF());
                        blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                        QPainter p(&blendedPixmap);
                        p.drawPixmap(0,
                                     0,
                                     doubleBuffer,
                                     (blendRect.left() - contentsRect.left()) * devicePixelRatioF(),
                                     (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                     blendRect.width() * devicePixelRatioF(),
                                     blendRect.height() * devicePixelRatioF());

                        QColor blCol = d->mouseSelectionColor.darker(140);
                        blCol.setAlphaF(0.2);
                        p.fillRect(blendedPixmap.rect(), blCol);
                        p.end();
                        // copy the blended pixmap back to its place
                        pixmapPainter.drawPixmap(blendRect.left(), blendRect.top(), blendedPixmap);
                    }
                    // draw border (red if the selection is too small)
                    pixmapPainter.setPen(d->mouseSelectionColor);
                    pixmapPainter.drawRect(selectionPartRect.adjusted(0, 0, -1, -1));
                }
            }
            drawTableDividers(&pixmapPainter);
            // 3a) Layer 1: give annotator painting control
            if (d->annotator && d->annotator->routePaints(contentsRect))
                d->annotator->routePaint(&pixmapPainter, contentsRect);
            // 3b) Layer 1: give mouseAnnotation painting control
            d->mouseAnnotation->routePaint(&pixmapPainter, contentsRect);

            // 4) Layer 2: overlays
            if (Okular::Settings::debugDrawBoundaries()) {
                pixmapPainter.setPen(Qt::blue);
                pixmapPainter.drawRect(contentsRect);
            }

            // finish painting and draw contents
            pixmapPainter.end();
            screenPainter.drawPixmap(contentsRect.left(), contentsRect.top(), doubleBuffer);
        } else {
            // 1) Layer 0: paint items and clear bg on unpainted rects
            drawDocumentOnPainter(contentsRect, &screenPainter);
            // 2a) Layer 1a: paint opaque selection (rectangle)
            if (!selectionRect.isNull() && selectionRect.intersects(contentsRect) && !selectionRectInternal.contains(contentsRect)) {
                screenPainter.setPen(palette().color(QPalette::Active, QPalette::Highlight).darker(110));
                screenPainter.drawRect(selectionRect);
            }
            // 2b) Layer 1b: paint opaque selection (table)
            for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust(1, 1, -1, -1);
                if (!selectionPartRect.isNull() && selectionPartRect.intersects(contentsRect) && !selectionPartRectInternal.contains(contentsRect)) {
                    screenPainter.setPen(palette().color(QPalette::Active, QPalette::Highlight).darker(110));
                    screenPainter.drawRect(selectionPartRect);
                }
            }
            drawTableDividers(&screenPainter);
            // 3a) Layer 1: give annotator painting control
            if (d->annotator && d->annotator->routePaints(contentsRect))
                d->annotator->routePaint(&screenPainter, contentsRect);
            // 3b) Layer 1: give mouseAnnotation painting control
            d->mouseAnnotation->routePaint(&screenPainter, contentsRect);

            // 4) Layer 2: overlays
            if (Okular::Settings::debugDrawBoundaries()) {
                screenPainter.setPen(Qt::red);
                screenPainter.drawRect(contentsRect);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : data) {
        QRegularExpressionMatch match = re.match(line);
        if (match.hasMatch()) {
            newdata.append(match.captured(1));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const XpsRenderNode &child : qAsConst(node.children) ) {
        bool isStroked = true;
        att = node.attributes.value( QStringLiteral("IsStroked") );
        if ( !att.isEmpty() ) {
            isStroked = att == QLatin1String( "true" );
        }
        if ( !isStroked ) {
            continue;
        }

        // PolyLineSegment
        if ( child.name == QLatin1String( "PolyLineSegment" ) ) {
            att = child.attributes.value( QStringLiteral("Points") );
            if ( !att.isEmpty() ) {
                const QStringList points = att.split( QLatin1Char( ' ' ), QString::SkipEmptyParts );
                for ( const QString &p : points ) {
                    QPointF point = getPointFromString( p );
                    path.lineTo( point );
                }
            }
        }
        // PolyBezierSegment
        else if ( child.name == QLatin1String( "PolyBezierSegment" ) ) {
            att = child.attributes.value( QStringLiteral("Points") );
            if ( !att.isEmpty() ) {
                const QStringList points = att.split( QLatin1Char( ' ' ), QString::SkipEmptyParts );
                if ( points.count() % 3 == 0 ) {
                    for ( int i = 0; i < points.count(); ) {
                        QPointF firstControl = getPointFromString( points.at( i++ ) );
                        QPointF secondControl = getPointFromString( points.at( i++ ) );
                        QPointF endPoint = getPointFromString( points.at( i++ ) );
                        path.cubicTo(firstControl, secondControl, endPoint);
                    }
                }
            }
        }
        // PolyQuadraticBezierSegment
        else if ( child.name == QLatin1String( "PolyQuadraticBezierSegment" ) ) {
            att = child.attributes.value( QStringLiteral("Points") );
            if ( !att.isEmpty() ) {
                const QStringList points = att.split( QLatin1Char( ' ' ), QString::SkipEmptyParts );
                if ( points.count() % 2 == 0 ) {
                    for ( int i = 0; i < points.count(); ) {
                        QPointF point1 = getPointFromString( points.at( i++ ) );
                        QPointF point2 = getPointFromString( points.at( i++ ) );
                        path.quadTo( point1, point2 );
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &t : text )
    {
        for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QStringLiteral( "(.*),\\s*(%1=.*)" ).arg( attribute ), QRegularExpression::DotMatchesEverythingOption );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                QStringList results = text;
                const int index = results.indexOf( t );
                results.removeAt( index );
                results.insert( index, match.captured( 2 ) );
                results.insert( index, match.captured( 1 ) );
                return splitDNAttributes( results );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PresentationFrame *frame : qAsConst(m_frames)) {
        frame->recalcGeometry(m_width, m_height, screenRatio);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pages) {
        const int currentPage = page->number();
        // get form fields page by page so that page number and index of the form can be determined.
        const QVector<const Okular::FormFieldSignature *> signatureFormFields = SignatureGuiUtils::getSignatureFormFields(document, false, currentPage);
        if (signatureFormFields.isEmpty())
            continue;

        for (int i = 0; i < signatureFormFields.count(); i++) {
            const Okular::FormFieldSignature *sf = signatureFormFields[i];
            const Okular::SignatureInfo &info = sf->signatureInfo();

            // based on whether or not signature form is a nullptr it is decided if clicking on an item should change the viewport.
            auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, currentPage);
            parentItem->displayString = i18n("Rev. %1: Signed By %2", i + 1, info.signerName());

            auto childItem1 = new SignatureItem(parentItem, nullptr, SignatureItem::ValidityStatus, currentPage);
            childItem1->displayString = SignatureGuiUtils::getReadableSignatureStatus(info.signatureStatus());

            auto childItem2 = new SignatureItem(parentItem, nullptr, SignatureItem::SigningTime, currentPage);
            childItem2->displayString = i18n("Signing Time: %1", info.signingTime().toString(Qt::DefaultLocaleLongDate));

            const QString reason = info.reason();
            if (!reason.isEmpty()) {
                auto childItem3 = new SignatureItem(parentItem, nullptr, SignatureItem::Reason, currentPage);
                childItem3->displayString = i18n("Reason: %1", reason);
            }

            auto childItem4 = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, currentPage);
            childItem4->displayString = i18n("Field: %1 on page %2", sf->name(), currentPage + 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *request : requests )
    {
        // add request to the 'stack' at the right place
        if ( !request->priority() )
            // add priority zero requests to the top of the stack
            d->m_pixmapRequestsStack.append( request );
        else
        {
            // insert in stack sorted by priority
            sIt = d->m_pixmapRequestsStack.begin();
            sEnd = d->m_pixmapRequestsStack.end();
            while ( sIt != sEnd && (*sIt)->priority() > request->priority() )
                ++sIt;
            d->m_pixmapRequestsStack.insert( sIt, request );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(orderedProperties)) {
        const QString titleString = info.getKeyTitle(key);
        const QString valueString = info.get(key);
        if (titleString.isNull() || valueString.isNull())
            continue;

        // create labels and layout them
        QWidget *value = nullptr;
        if (key == Okular::DocumentInfo::getKeyString(Okular::DocumentInfo::MimeType)) {
            /// for mime type fields, show icon as well
            value = new QWidget(page);
            /// place icon left of mime type's name
            QHBoxLayout *hboxLayout = new QHBoxLayout(value);
            hboxLayout->setContentsMargins(0, 0, 0, 0);
            /// retrieve icon and place it in a QLabel
            QMimeDatabase db;
            QMimeType mimeType = db.mimeTypeForName(valueString);
            KSqueezedTextLabel *squeezed;
            if (mimeType.isValid()) {
                /// retrieve icon and place it in a QLabel
                QLabel *pixmapLabel = new QLabel(value);
                hboxLayout->addWidget(pixmapLabel, 0);
                const QIcon icon = QIcon::fromTheme(mimeType.iconName(), QIcon::fromTheme(QStringLiteral("application-octet-stream")));
                pixmapLabel->setPixmap(icon.pixmap(KIconLoader::SizeSmall));
                /// mime type's name and label
                squeezed = new KSqueezedTextLabel(i18nc("mimetype information, example: \"PDF Document (application/pdf)\"", "%1 (%2)", mimeType.comment(), valueString), value);
            } else {
                /// only mime type name
                squeezed = new KSqueezedTextLabel(valueString, value);
            }
            squeezed->setTextInteractionFlags(Qt::TextSelectableByMouse);
            hboxLayout->addWidget(squeezed, 1);
        } else {
            /// default for any other document information
            KSqueezedTextLabel *label = new KSqueezedTextLabel(valueString, page);
            label->setTextInteractionFlags(Qt::TextSelectableByMouse);
            value = label;
        }
        layout->addRow(new QLabel(i18n("%1:", titleString)), value);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields))
    {
        if (f->rect() == oldField->rect() && f->type() == oldField->type() && f->id() == oldField->id())
            return f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *ann : qAsConst(d->textTools)) {
        ann->setEnabled(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
    {
        if (triedOffers.contains(md))
            continue;

        foreach (const QString& supported, md.mimeTypes())
        {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type && !exactMatches.contains(md)) {
                exactMatches << md;
            }

            if (type.inherits(supported) && !offers.contains(md))
            {
                offers << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * visibleItem : qAsConst( d->visibleItems ) )
        if ( visibleItem->pageNumber() == pageNumber && visibleItem->isVisible() )
        {
            // update item's rectangle plus the little outline
            QRect expandedRect = visibleItem->croppedGeometry();
            // a PageViewItem is placed in the global page layout,
            // while we need to map its position in the viewport coordinates
            // (to get the correct area to repaint)
            expandedRect.translate( -contentAreaPosition() );
            expandedRect.adjust( -1, -1, 3, 3 );
            viewport()->update( expandedRect );

            // if we were "zoom-dragging" do not overwrite the "zoom-drag" cursor
            if ( cursor().shape() != Qt::SizeVerCursor )
            {
                // since the page has been regenerated below cursor, update it
                updateCursor();
            }
            break;
        }
```

#### AUTO 


```{c}
auto availableFormats = QImageReader::supportedImageFormats();
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : qAsConst(m_frames[ previousPage ]->videoWidgets) )
        {
            vw->stop();
            vw->pageLeft();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) { openUrl(url); }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
        // add request to the 'stack' at the right place
        if (!request->priority())
            // add priority zero requests to the top of the stack
            d->m_pixmapRequestsStack.append(request);
        else {
            // insert in stack sorted by priority
            sIt = d->m_pixmapRequestsStack.begin();
            sEnd = d->m_pixmapRequestsStack.end();
            while (sIt != sEnd && (*sIt)->priority() > request->priority())
                ++sIt;
            d->m_pixmapRequestsStack.insert(sIt, request);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *ann : qAsConst(*d->textQuickTools)) {
        ann->setEnabled(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *btn : qAsConst(m_actions)) {
                if (action != btn) {
                    btn->setChecked(false);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::Annotation *a : popplerAnnotations) {
        bool doDelete = true;
        Okular::Annotation *newann = createAnnotationFromPopplerAnnotation(a, &doDelete);
        if (newann) {
            page->addAnnotation(newann);

            if (a->subType() == Poppler::Annotation::AScreen) {
                Poppler::ScreenAnnotation *annotScreen = static_cast<Poppler::ScreenAnnotation *>(a);
                Okular::ScreenAnnotation *screenAnnotation = static_cast<Okular::ScreenAnnotation *>(newann);

                // The activation action
                const Poppler::Link *actionLink = annotScreen->action();
                if (actionLink)
                    screenAnnotation->setAction(createLinkFromPopplerLink(actionLink));

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotScreen->additionalAction(Poppler::Annotation::PageOpeningAction);
                if (pageOpeningLink)
                    screenAnnotation->setAdditionalAction(Okular::Annotation::PageOpening, createLinkFromPopplerLink(pageOpeningLink));

                const Poppler::Link *pageClosingLink = annotScreen->additionalAction(Poppler::Annotation::PageClosingAction);
                if (pageClosingLink)
                    screenAnnotation->setAdditionalAction(Okular::Annotation::PageClosing, createLinkFromPopplerLink(pageClosingLink));
            }

            if (a->subType() == Poppler::Annotation::AWidget) {
                Poppler::WidgetAnnotation *annotWidget = static_cast<Poppler::WidgetAnnotation *>(a);
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation *>(newann);

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotWidget->additionalAction(Poppler::Annotation::PageOpeningAction);
                if (pageOpeningLink)
                    widgetAnnotation->setAdditionalAction(Okular::Annotation::PageOpening, createLinkFromPopplerLink(pageOpeningLink));

                const Poppler::Link *pageClosingLink = annotWidget->additionalAction(Poppler::Annotation::PageClosingAction);
                if (pageClosingLink)
                    widgetAnnotation->setAdditionalAction(Okular::Annotation::PageClosing, createLinkFromPopplerLink(pageClosingLink));
            }

            if (!doDelete)
                annotationsOnOpenHash.insert(newann, a);
        }
        if (doDelete)
            delete a;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * a : actions )
    {
        if ( a->isChecked() )
        {
            return a;
        }
        else if ( a->menu() )
        {
            QAction * b = checkedAction( a->menu() );
            if ( b )
            {
                return b;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *visibleItem : qAsConst(d->visibleItems)) {
            if (visibleItem->pageNumber() == pageNumber) {
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KToggleAction *a, const QString &name, Okular::SettingsCore::EnumRenderMode::type id) {
        a->setData(int(id));
        addAction(a);
        ac->addAction(name, a);
        m_colorModeActionGroup->addAction(a);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[item]() {
                    if (item->url.isLocalFile()) {
                        QFileInfo fileInfo(item->url.toLocalFile());
                        QDir parentDir = fileInfo.dir();
                        QUrl parentDirUrl = QUrl::fromLocalFile(parentDir.absolutePath());
                        QDesktopServices::openUrl(parentDirUrl);
                    }
                }
```

#### AUTO 


```{c}
const auto &ann
```

#### RANGE FOR STATEMENT 


```{c}
for ( HighlightAreaRect *hlar : qAsConst(m_page->m_highlights) )
    {
        hlar->transform( highlightRotationMatrix );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &wwc : list) {
            TinyTextEntity *ent = wwc.word;
            const QRect entRect = ent->area.geometry(pageWidth, pageHeight);

            // calculate vertical projection profile proj_on_xaxis1
            for (int k = entRect.left(); k <= entRect.left() + entRect.width(); ++k) {
                if ((k - regionRect.left()) < size_proj_x && (k - regionRect.left()) >= 0) {
                    proj_on_xaxis[k - regionRect.left()] += entRect.height();
                }
            }

            // calculate horizontal projection profile in the same way
            for (int k = entRect.top(); k <= entRect.top() + entRect.height(); ++k) {
                if ((k - regionRect.top()) < size_proj_y && (k - regionRect.top()) >= 0) {
                    proj_on_yaxis[k - regionRect.top()] += entRect.width();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &toolXml : items )
    {
        QDomDocument entryParser;
        if ( !entryParser.setContent( toolXml ) )
        {
            qWarning() << "Skipping malformed tool XML string";
            break;
        }

        QDomElement toolElement = entryParser.documentElement();
        if ( toolElement.tagName() == QLatin1String("tool") )
        {
            // Create list item and attach the source XML string as data
            QString itemText = toolElement.attribute( QStringLiteral("name") );
            if ( itemText.isEmpty() )
                itemText = PageViewAnnotator::defaultToolName( toolElement );
            QListWidgetItem * listEntry = new QListWidgetItem( itemText, m_list );
            listEntry->setData( ToolXmlRole, QVariant::fromValue(toolXml) );
            listEntry->setIcon( PageViewAnnotator::makeToolPixmap( toolElement ) );
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) { d->aShowToolBar->setEnabled(!checked); }
```

#### AUTO 


```{c}
auto obj = factory->create<QObject>();
```

#### RANGE FOR STATEMENT 


```{c}
for (int p : noMoreSelectedPages) {
            d->document->setPageTextSelection(p, nullptr, QColor());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction* action : actions ) {
        QVariant mode_id = action->data();
        if (mode_id.toInt() == nr) {
            action->trigger();
        }
    }
```

#### AUTO 


```{c}
auto itMainWindow = std::find_if( widgets.begin(), widgets.end(), [] (const QWidget * widget) {
        return qobject_cast<const KParts::MainWindow *>( widget ) != nullptr;
    } );
```

#### AUTO 


```{c}
auto hideBtn = m_fields[QStringLiteral("HideActionButton")];
```

#### AUTO 


```{c}
auto it = d->certificateForForm.constFind(form);
```

#### AUTO 


```{c}
auto annot = new Okular::HighlightAnnotation();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const pdfsyncpoint &pt : qAsConst(points) )
    {
        // drop pdfsync points not completely valid
        if ( pt.page < 0 || pt.page >= m_pagesVector.size() )
            continue;

        // magic numbers for TeX's RSU's (Ridiculously Small Units) conversion to pixels
        Okular::NormalizedPoint p(
            ( pt.x * dpi.width() ) / ( 72.27 * 65536.0 * m_pagesVector[pt.page]->width() ),
            ( pt.y * dpi.height() ) / ( 72.27 * 65536.0 * m_pagesVector[pt.page]->height() )
            );
        QString file = pt.file;
        Okular::SourceReference * sourceRef = new Okular::SourceReference( file, pt.row, pt.column );
        refRects[ pt.page ].append( new Okular::SourceRefObjectRect( p, sourceRef ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ParsedEntry &e : parsedList) {
        if (e.urls.empty()) {
            continue;
        }

        root_offset = qMin(root_offset, e.indent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MatchColor &mc : mv) {
                delete mc.first;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &allDocumentsI : qAsConst(alldocuments)) {
        const QString docpath = allDocumentsI.path();

        if (docpath.endsWith(QLatin1String(".html"), Qt::CaseInsensitive) || docpath.endsWith(QLatin1String(".htm"), Qt::CaseInsensitive) || docpath.endsWith(QLatin1String(".xhtml"), Qt::CaseInsensitive)) {
            documents.push_back(allDocumentsI);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (fix_word &fw : heightTable_in_units_of_design_size)
        fw.value = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (Annotation *annotation : annotations) {
        QUndoCommand *uc = new RemoveAnnotationCommand(this->d, annotation, page);
        d->m_undoStack->push(uc);
    }
```

#### AUTO 


```{c}
auto childItem2 = new SignatureItem( parentItem, nullptr, SignatureItem::SigningTime, currentPage );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem *item : qAsConst(d->items) )
    {
        if ( item->isVisible() && selectionRect.intersects( item->croppedGeometry() ) )
            affectedItemsSet.insert( item->pageNumber() );
    }
```

#### AUTO 


```{c}
auto &characterBitmap
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->items)) {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for (FormWidgetIface *fwi : formWidgetsList) {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for (VideoWidget *vw : videoWidgets) {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());

            if (vw->isPlaying() && viewportRectAtZeroZero.intersected(vw->geometry()).isEmpty()) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if (!i->isVisible())
            continue;
#ifdef PAGEVIEW_DEBUG
        qWarning() << "checking page" << i->pageNumber();
        qWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects(i->croppedGeometry());
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected(i->croppedGeometry());
        if (intersectionRect.isEmpty()) {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back(i);
        Okular::VisiblePageRect *vItem = new Okular::VisiblePageRect(i->pageNumber(), Okular::NormalizedRect(intersectionRect.translated(-i->uncroppedGeometry().topLeft()), i->uncroppedWidth(), i->uncroppedHeight()));
        visibleRects.push_back(vItem);
#ifdef PAGEVIEW_DEBUG
        qWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight());
        qWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if (i->page()->hasTilesManager(this) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low) {
            double rectMargin = pixelsToExpand / (double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax(0.0, vItem->rect.left - rectMargin);
            expandedVisibleRect.top = qMax(0.0, vItem->rect.top - rectMargin);
            expandedVisibleRect.right = qMin(1.0, vItem->rect.right + rectMargin);
            expandedVisibleRect.bottom = qMin(1.0, vItem->rect.bottom + rectMargin);
        }

        // if the item has not the right pixmap, add a request for it
        if (!i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect)) {
#ifdef PAGEVIEW_DEBUG
            qWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest *p = new Okular::PixmapRequest(this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), devicePixelRatioF(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous);
            requestedPixmaps.push_back(p);

            if (i->page()->hasTilesManager(this)) {
                p->setNormalizedRect(expandedVisibleRect);
                p->setTile(true);
            } else
                p->setNormalizedRect(vItem->rect);
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if (isEvent) {
            const QRect &geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            const double distance = hypot((geometry.left() + geometry.right()) / 2.0 - (viewportCenterX - 4), (geometry.top() + geometry.bottom()) / 2.0 - viewportCenterY);
            if (distance >= minDistance && nearPageNumber != -1)
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if (geometry.height() > 0 && geometry.width() > 0) {
                // Compute normalized coordinates w.r.t. cropped page
                focusedX = (viewportCenterX - (double)geometry.left()) / (double)geometry.width();
                focusedY = (viewportCenterY - (double)geometry.top()) / (double)geometry.height();
                // Convert to normalized coordinates w.r.t. full page (no-op if not cropped)
                focusedX = i->crop().left + focusedX * i->crop().width();
                focusedY = i->crop().top + focusedY * i->crop().height();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu *>(view->findChild<QMenu *>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains go-to link action
        QAction *goToAction = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("GoToAction")));
        QVERIFY(goToAction);

        // check if the "follow this link" action is not visible
        QAction *processLinkAction = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("ProcessLinkAction")));
        QVERIFY(!processLinkAction);

        // check if the "copy link address" action is not visible
        QAction *copyLinkLocation = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("CopyLinkLocationAction")));
        QVERIFY(!copyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Okular::NormalizedPoint &item : path )
        {
            Okular::NormalizedPoint p;
            transform.map( item.x, item.y, &p.x, &p.y );
            transformedPath.append(p);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, toolId](bool checked) {
            if (checked)
                d->selectTool(toolId);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &toolXml : userTools )
    {
        QDomDocument entryParser;
        if ( entryParser.setContent( toolXml ) )
            m_toolsDefinition.appendChild( doc.importNode( entryParser.documentElement(), true ) );
        else
            qCWarning(OkularUiDebug) << "Skipping malformed tool XML in AnnotationTools setting";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *fw : fwi) {
            if (fw->formField() == form) {
                SignatureEdit *widget = static_cast<SignatureEdit *>(fw);
                widget->setDummyMode(true);
                QTimer::singleShot(250, this, [=] { widget->setDummyMode(false); });
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const XpsRenderNode &child : qAsConst(node.children) ) {
        if ( child.data.canConvert<XpsPathFigure *>() ) {
            XpsPathFigure *figure = child.data.value<XpsPathFigure *>();
            geom->paths.append( figure );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: page->formFields() )
    {
        if ( ff->name().startsWith( QStringLiteral( "Target" ) ) )
        {
            QVERIFY( !ff->isVisible() );
            anyChecked = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * item : qAsConst( d->items ) )
    {
        // check if a piece of the page intersects the contents rect
        if ( !item->isVisible() || !item->croppedGeometry().intersects( contentsRect ) )
            continue;

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry();

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate( itemGeometry.left(), itemGeometry.top() );

        // draw the page using the PagePainter with all flags active
        if ( contentsRect.intersects( itemGeometry ) )
        {
            Okular::NormalizedPoint *viewPortPoint = nullptr;
            Okular::NormalizedPoint point( d->lastSourceLocationViewportNormalizedX, d->lastSourceLocationViewportNormalizedY );
            if( Okular::Settings::showSourceLocationsGraphically()
                && item->pageNumber() ==  d->lastSourceLocationViewportPageNumber )
            {
                viewPortPoint = &point;
            }
            QRect pixmapRect = contentsRect.intersected( itemGeometry );
            pixmapRect.translate( -item->croppedGeometry().topLeft() );
            PagePainter::paintCroppedPageOnPainter( p, item->page(), this, pageflags,
                item->uncroppedWidth(), item->uncroppedHeight(), pixmapRect,
                item->crop(), viewPortPoint );
        }

        // remove painted area from 'remainingArea' and restore painter
        remainingArea -= itemGeometry;
        p->restore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::EmbeddedFile *pef : popplerFiles) {
            docEmbeddedFiles.append(new PDFEmbeddedFile(pef));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Hyperlink &dviLink : qAsConst(pageInfo->hyperLinkList) )
    {
        QRect boxArea = dviLink.box;
        double nl = (double)boxArea.left() / pageWidth,
               nt = (double)boxArea.top() / pageHeight,
               nr = (double)boxArea.right() / pageWidth,
               nb = (double)boxArea.bottom() / pageHeight;
        
        QString linkText = dviLink.linkText;
        if ( linkText.startsWith(QLatin1String("#")) )
            linkText = linkText.mid( 1 );
        Anchor anch = m_dviRenderer->findAnchor( linkText );

        Okular::Action *okuLink = nullptr;

        /* distinguish between local (-> anchor) and remote links */
        if (anch.isValid())
        {
            /* internal link */
            Okular::DocumentViewport vp;
            fillViewportFromAnchor( vp, anch, pageWidth, pageHeight );

            okuLink = new Okular::GotoAction( QLatin1String(""), vp );
        }
        else
        {
            okuLink = new Okular::BrowseAction( QUrl::fromUserInput( dviLink.linkText ) );
        }
        if ( okuLink ) 
        {
            Okular::ObjectRect *orlink = new Okular::ObjectRect( nl, nt, nr, nb, 
                                        false, Okular::ObjectRect::Action, okuLink );
            dviLinks.push_front( orlink );
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](QAction *a, const QString &name, Okular::Settings::EnumViewMode::type id) {
        a->setCheckable(true);
        a->setData(int(id));
        d->aViewModeMenu->addAction(a);
        ac->addAction(name, a);
        d->viewModeActionGroup->addAction(a);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu *>(view->findChild<QMenu *>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "follow this link" action
        QAction *processLinkAction = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("ProcessLinkAction")));
        QVERIFY(processLinkAction);

        // check if the menu contains "copy link address" action
        QAction *copyLinkLocation = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("CopyLinkLocationAction")));
        QVERIFY(copyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &service : services )
    {
        if ( service.startsWith(pattern) && !service.endsWith( myPid ) )
        {
            bestService.reset( new QDBusInterface(service, QStringLiteral("/okularshell"), QStringLiteral("org.kde.okular")) );

            // Find a window that can handle our documents
            const QDBusReply<bool> reply = bestService->call( QStringLiteral("canOpenDocs"), paths.count(), desktop );
            if( reply.isValid() && reply.value() )
                break;

            bestService.reset();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int pageNumber : qAsConst(s->highlightedPages)) {
        d->m_pagesVector.at(pageNumber)->d->deleteHighlights(searchID);
        foreachObserver(notifyPageChanged(pageNumber, DocumentObserver::Highlights));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        QVariant mode_id = action->data();
        if (mode_id.toInt() == nr) {
            action->trigger();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Document &doc : qAsConst(minDocs)) {
        fileName = docList[(int)doc.docNumber];
        if (searchForPhrases(termSeq, seqWords, fileName, chmFile)) {
            results << fileName;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields))
    {
        if (f->type() == oldField->type() && f->id() == oldField->id() && qFuzzyCompare(f->rect().left, oldField->rect().left) && qFuzzyCompare(f->rect().top, oldField->rect().top) && qFuzzyCompare(f->rect().right, oldField->rect().right) && qFuzzyCompare(f->rect().bottom, oldField->rect().bottom))
        {
            return f;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_document->m_pagesVector))
    {
        p->setTextPage( nullptr );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : available) {
        if (triedOffers.contains(md)) {
            continue;
        }

        const QStringList mimetypes = md.mimeTypes();
        for (const QString &supported : mimetypes) {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type && !exactMatches.contains(md)) {
                exactMatches << md;
            }

            if (type.inherits(supported) && !offers.contains(md)) {
                offers << md;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cert : certs) {
            if (cert->validityStart() <= now && now <= cert->validityEnd()) {
                items.append(cert->nickName());
                nickToCert[cert->nickName()] = cert;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suffix: md.mimeTypeForName(mimeName).suffixes())
                supportedPatterns += QStringLiteral("*.") + suffix;
```

#### AUTO 


```{c}
auto validityFormLayout = new QFormLayout( validityBox );
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
        // set the 'page field' (see PixmapRequest) and check if it is valid
        qCDebug(OkularCoreDebug).nospace() << "request observer=" << request->observer() << " " << request->width() << "x" << request->height() << "@" << request->pageNumber();
        if (d->m_pagesVector.value(request->pageNumber()) == nullptr) {
            // skip requests referencing an invalid page (must not happen)
            delete request;
            continue;
        }

        request->d->mPage = d->m_pagesVector.value(request->pageNumber());

        if (request->isTile()) {
            // Change the current request rect so that only invalid tiles are
            // requested. Also make sure the rect is tile-aligned.
            NormalizedRect tilesRect;
            const QList<Tile> tiles = request->d->tilesManager()->tilesAt(request->normalizedRect(), TilesManager::TerminalTile);
            QList<Tile>::const_iterator tIt = tiles.constBegin(), tEnd = tiles.constEnd();
            while (tIt != tEnd) {
                const Tile &tile = *tIt;
                if (!tile.isValid()) {
                    if (tilesRect.isNull()) {
                        tilesRect = tile.rect();
                    } else {
                        tilesRect |= tile.rect();
                    }
                }

                tIt++;
            }

            request->setNormalizedRect(tilesRect);
        }

        if (!request->asynchronous()) {
            request->d->mPriority = 0;
        }
    }
```

#### AUTO 


```{c}
const auto points = oLineAnnotation->linePoints();
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        QApplication::clipboard()->clear();

        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu *>(view->findChild<QMenu *>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the copy selected text to clipboard is present
        QAction *copyAct = qobject_cast<QAction *>(menu->findChild<QAction *>(QStringLiteral("CopyTextToClipboard")));
        QVERIFY(copyAct);

        menu->close();
        menuClosed = true;
    }
```

#### AUTO 


```{c}
auto issuerFormLayout = new QFormLayout(issuerBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (TileNode &tile : d->tiles) {
        d->setPixmap(pixmap, rotatedRect, tile, isPartialPixmap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QUrl &allDocumentsI : qAsConst( alldocuments ) )
	{
		const QString docpath = allDocumentsI.path();

		if ( docpath.endsWith( QLatin1String(".html"), Qt::CaseInsensitive )
		|| docpath.endsWith( QLatin1String(".htm"), Qt::CaseInsensitive )
		|| docpath.endsWith( QLatin1String(".xhtml"), Qt::CaseInsensitive ) )
			documents.push_back( allDocumentsI );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const int p : pageList) {
        if (!pl.isEmpty())
            pl += QLatin1String(",");
        pl += QString::number(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFormFields) {
        m_fields.insert(ff->name(), ff);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * item : qAsConst( d->items ) )
        {
            // update internal page size (leaving a little margin in case of Fit* modes)
            updateItemSize( item, colWidth[ cIdx ] - kcolWidthMargin, viewportHeight - krowHeightMargin );
            // find row's maximum height and column's max width
            if ( item->croppedWidth() + kcolWidthMargin > colWidth[ cIdx ] )
                colWidth[ cIdx ] = item->croppedWidth() + kcolWidthMargin;
            if ( item->croppedHeight() + krowHeightMargin > rowHeight[ rIdx ] )
                rowHeight[ rIdx ] = item->croppedHeight() + krowHeightMargin;
            // handle the 'centering on first row' stuff
            // update col/row indices
            if ( ++cIdx == nCols )
            {
                cIdx = 0;
                rIdx++;
            }
        }
```

#### AUTO 


```{c}
auto certPropBtn = new QPushButton(i18n("View Certificate..."));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attribute : attributes) {
            const QRegularExpression re(QStringLiteral("%1=\"(.*)\"").arg(attribute));
            const QRegularExpressionMatch match = re.match(t);
            if (match.hasMatch()) {
                t = attribute + QLatin1Char('=') + match.captured(1);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *form : forms) {
                    if (form->id() == formId) {
                        Action *action = form->additionalAction(FormField::CalculateField);
                        if (action) {
                            FormFieldText *fft = dynamic_cast<FormFieldText *>(form);
                            std::shared_ptr<Event> event;
                            QString oldVal;
                            if (fft) {
                                // Prepare text calculate event
                                event = Event::createFormCalculateEvent(fft, m_pagesVector[pageIdx]);
                                if (!m_scripter) {
                                    m_scripter = new Scripter(this);
                                }
                                m_scripter->setEvent(event.get());
                                // The value maybe changed in javascript so save it first.
                                oldVal = fft->text();
                            }

                            m_parent->processAction(action);
                            if (event && fft) {
                                // Update text field from calculate
                                m_scripter->setEvent(nullptr);
                                const QString newVal = event->value().toString();
                                if (newVal != oldVal) {
                                    fft->setText(newVal);
                                    fft->setAppearanceText(newVal);
                                    if (const Okular::Action *action = fft->additionalAction(Okular::FormField::FormatField)) {
                                        // The format action handles the refresh.
                                        m_parent->processFormatAction(action, fft);
                                    } else {
                                        Q_EMIT m_parent->refreshFormWidget(fft);
                                        pageNeedsRefresh = true;
                                    }
                                }
                            }
                        } else {
                            qWarning() << "Form that is part of calculate order doesn't have a calculate action";
                        }
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Phonon::State s) { stateChanged(s); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { saveFile(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormField *f : formFields) {
                if (f->type() == Okular::FormField::FormSignature)
                    isDigitallySigned = true;
            }
```

#### AUTO 


```{c}
auto issuerBox = new QGroupBox( i18n("Issued By"), generalPage );
```

#### RANGE FOR STATEMENT 


```{c}
for( QString url : qAsConst(content_parser.spine) )
        {
            EBookTocEntry e;

            if ( content_parser.manifest.contains( url ) )
                url = content_parser.manifest[ url ];

            e.name = url;
            e.url= pathToUrl( url );
            e.iconid = EBookTocEntry::IMAGE_NONE;
            e.indent = 0;

            // Add into url-title map
            m_urlTitleMap[ pathToUrl( url ) ] = url;
            m_tocEntries.push_back( e );
        }
```

#### AUTO 


```{c}
const auto &mimeName
```

#### RANGE FOR STATEMENT 


```{c}
for (ObjectRect *objRect : qAsConst(m_page->m_rects))
        objRect->transform(matrix);
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_pagesVector))
        p->d->m_doc = d;
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->visibleItems)) {
            item->reloadFormWidgetsState();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &arg : paths )
    {
        // Copy stdin to temporary file which can be opened by the existing
        // window. The temp file is automatically deleted after it has been
        // opened. Not sure if this behavior is safe on all platforms.
        QScopedPointer<QTemporaryFile> tempFile;
        QString path;
        if( arg == QLatin1String("-") )
        {
            tempFile.reset( new QTemporaryFile );
            QFile stdinFile;
            if( !tempFile->open() || !stdinFile.open(stdin,QIODevice::ReadOnly) )
                return false;

            const size_t bufSize = 1024*1024;
            QScopedPointer<char,QScopedPointerArrayDeleter<char> > buf( new char[bufSize] );
            size_t bytes;
            do
            {
                bytes = stdinFile.read( buf.data(), bufSize );
                tempFile->write( buf.data(), bytes );
            } while( bytes != 0 );

            path = tempFile->fileName();
        }
        else
        {
            // Page only makes sense if we are opening one file
            const QString page = ShellUtils::page(serializedOptions);
            path = ShellUtils::urlFromArg(arg, ShellUtils::qfileExistFunc(), page).url();
        }

        // Returns false if it can't fit another document
        const QDBusReply<bool> reply = bestService->call( QStringLiteral("openDocument"), path, serializedOptions );
        if( !reply.isValid() || !reply.value() )
        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const KBookmark &bm : list )
    {
        if ( bm.parentGroup() == thebg )
        {
            thebg.deleteBookmark( bm );
            deletedAny = true;

            DocumentViewport vp( bm.url().fragment(QUrl::FullyDecoded) );
            if ( referurl == d->document->m_url )
            {
                d->urlBookmarks[ vp.pageNumber ]--;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](int index) { m_forceRaster->setChecked(index != 0); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::FormFieldSignature *s : allSignatures)
        {
            bool createSignature = true;
            const QString fullyQualifiedName = s->fullyQualifiedName();
            auto compareSignatureByFullyQualifiedName = [&fullyQualifiedName](const Okular::FormField *off) { return off->fullyQualifiedName() == fullyQualifiedName; };

            // See if the signature is in one of the already loaded page (i.e. 1 to end)
            for (Okular::Page *p : pagesVector)
            {
                const QLinkedList<Okular::FormField*> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end())
                {
                    delete s;
                    createSignature = false;
                    continue;
                }
            }
            // See if the signature is in page 0
            if (std::find_if(page0FormFields.constBegin(), page0FormFields.constEnd(), compareSignatureByFullyQualifiedName) != page0FormFields.constEnd())
            {
                delete s;
                createSignature = false;
            }
            // Otherwise it's a page-less signature, add it to page 0
            if (createSignature)
            {
                Okular::FormField * of = new PopplerFormFieldSignature( std::unique_ptr<Poppler::FormFieldSignature>( s ) );
                page0FormFields.append( of );

            }
        }
```

#### AUTO 


```{c}
const auto &stamp
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
            QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
            selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
            QRect selectionPartRectInternal = selectionPartRect;
            selectionPartRectInternal.adjust(1, 1, -1, -1);
            for (double col : qAsConst(d->tableSelectionCols)) {
                if (col >= tsp.rectInSelection.left && col <= tsp.rectInSelection.right) {
                    col = (col - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                    const int x = selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                    screenPainter->drawLine(x, selectionPartRectInternal.top(), x, selectionPartRectInternal.top() + selectionPartRectInternal.height());
                }
            }
            for (double row : qAsConst(d->tableSelectionRows)) {
                if (row >= tsp.rectInSelection.top && row <= tsp.rectInSelection.bottom) {
                    row = (row - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                    const int y = selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                    screenPainter->drawLine(selectionPartRectInternal.left(), y, selectionPartRectInternal.left() + selectionPartRectInternal.width(), y);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: page->formFields() )
    {
        m_fields.insert( ff->name(),  ff );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const pdfsyncpoint &pt : qAsConst(points)) {
        // drop pdfsync points not completely valid
        if (pt.page < 0 || pt.page >= m_pagesVector.size())
            continue;

        // magic numbers for TeX's RSU's (Ridiculously Small Units) conversion to pixels
        Okular::NormalizedPoint p((pt.x * dpi.width()) / (72.27 * 65536.0 * m_pagesVector[pt.page]->width()), (pt.y * dpi.height()) / (72.27 * 65536.0 * m_pagesVector[pt.page]->height()));
        QString file = pt.file;
        Okular::SourceReference *sourceRef = new Okular::SourceReference(file, pt.row, pt.column);
        refRects[pt.page].append(new Okular::SourceRefObjectRect(p, sourceRef));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ParsedEntry &e : parsedList) {
        if (e.urls.empty()) {
            continue;
        }

        EBookIndexEntry entry;
        entry.name = e.name;
        entry.urls = e.urls;
        entry.seealso = e.seealso;

        // If the index array is empty, make sure the first entry is on root offset
        if (index.isEmpty()) {
            entry.indent = root_offset;
        } else {
            entry.indent = e.indent - root_offset;
        }

        index.append(entry);
        printf("%d: %s\n", entry.indent, qPrintable(entry.name));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * i : qAsConst( d->visibleItems ) )
    {
        const QRect & r = i->croppedGeometry();
        if ( x < r.right() && x > r.left() && y < r.bottom() )
        {
            if ( y > r.top() )
                item = i;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &searchText) {
        m_findBar->startSearch(searchText);
        slotShowFindBar();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int l, const QString &t, const QTextBlock &b) { addTitle(l, t, b); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Poppler::RichMediaAnnotation::Asset *asset : assets ) {
        if ( asset->name() == sourceId ) {
            matchingAsset = asset;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString &t : result )
    {
        t.replace( "\\,", "," );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->slotGeneratorConfigChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &t : result) {
        for (const QString &attribute : attributes) {
            const QRegularExpression re(QStringLiteral("%1=\"(.*)\"").arg(attribute));
            const QRegularExpressionMatch match = re.match(t);
            if (match.hasMatch()) {
                t = attribute + '=' + match.captured(1);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EBookTocEntry &e : qAsConst(topics)) {
        QDomElement item = m_docSyn.createElement(e.name);
        if (!e.url.isEmpty()) {
            QString url = e.url.toString();
            item.setAttribute(QStringLiteral("ViewportName"), url);
            if (!tmpPageList.contains(url)) { // add a page only once
                tmpPageList.insert(url, pageNum);
                pageNum++;
            }
        }
        item.setAttribute(QStringLiteral("Icon"), e.iconid);
        if (e.indent == 0)
            m_docSyn.appendChild(item);
        else
            lastIndentElement[e.indent - 1].appendChild(item);
        lastIndentElement[e.indent] = item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pair] { doRemovePageAnnotation(pair); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        // check if a piece of the page intersects the contents rect
        if (!item->isVisible() || !item->croppedGeometry().intersects(checkRect)) {
            continue;
        }

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry();

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate(itemGeometry.left(), itemGeometry.top());

        // draw the page outline (black border and bottom-right shadow)
        if (!itemGeometry.contains(contentsRect)) {
            int itemWidth = itemGeometry.width();
            int itemHeight = itemGeometry.height();
            // draw simple outline
            QPen pen(Qt::black);
            pen.setWidth(0);
            p->setPen(pen);

            QRectF outline(-1.0 / dpr, -1.0 / dpr, itemWidth + 1.0 / dpr, itemHeight + 1.0 / dpr);
            p->drawRect(outline);

            // draw bottom/right gradient
            for (int i = 1; i <= shadowWidth; i++) {
                pen.setColor(interpolateColor(double(i) / (shadowWidth + 1)));
                p->setPen(pen);
                QPointF left((i - 1) / dpr, itemHeight + i / dpr);
                QPointF up(itemWidth + i / dpr, (i - 1) / dpr);
                QPointF corner(itemWidth + i / dpr, itemHeight + i / dpr);
                p->drawLine(left, corner);
                p->drawLine(up, corner);
            }
        }

        p->restore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : choices) {
            bool ok = true;
            int val = str.toInt(&ok);
            if (ok)
                newchoices.append(val);
        }
```

#### AUTO 


```{c}
const auto &highlight
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers)) {
        if (o != excludeObserver) {
            o->notifyViewportChanged(smoothMove);
        }

        if (currentPageChanged) {
            o->notifyCurrentPageChanged(oldPageNumber, currentViewportPage);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QUrl &allDocumentsI : qAsConst( alldocuments ) )
	{
		const QString docpath = allDocumentsI.path();

		if ( docpath.endsWith( ".html", Qt::CaseInsensitive )
		|| docpath.endsWith( ".htm", Qt::CaseInsensitive )
		|| docpath.endsWith( ".xhtml", Qt::CaseInsensitive ) )
			documents.push_back( allDocumentsI );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect & r : rgn )
        {
            if ( useSubdivision )
            {
                // set 'contentsRect' to a part of the sub-divided region
                contentsRect = r.translated( areaPos ).intersected( viewportRect );
                if ( !contentsRect.isValid() )
                    continue;
            }
#ifdef PAGEVIEW_DEBUG
            qCDebug(OkularUiDebug) << contentsRect;
#endif

            // note: this check will take care of all things requiring alpha blending (not only selection)
            bool wantCompositing = !selectionRect.isNull() && contentsRect.intersects( selectionRect );
            // also alpha-blend when there is a table selection...
            wantCompositing |= !d->tableSelectionParts.isEmpty();

            if ( wantCompositing && Okular::Settings::enableCompositing() )
            {
                // create pixmap and open a painter over it (contents{left,top} becomes pixmap {0,0})
                QPixmap doubleBuffer( contentsRect.size() * devicePixelRatioF() );
                doubleBuffer.setDevicePixelRatio(devicePixelRatioF());
                QPainter pixmapPainter( &doubleBuffer );

                pixmapPainter.translate( -contentsRect.left(), -contentsRect.top() );

                // 1) Layer 0: paint items and clear bg on unpainted rects
                drawDocumentOnPainter( contentsRect, &pixmapPainter );
                // 2a) Layer 1a: paint (blend) transparent selection (rectangle)
                if ( !selectionRect.isNull() && selectionRect.intersects( contentsRect ) &&
                    !selectionRectInternal.contains( contentsRect ) )
                {
                    QRect blendRect = selectionRectInternal.intersected( contentsRect );
                    // skip rectangles covered by the selection's border
                    if ( blendRect.isValid() )
                    {
                        // grab current pixmap into a new one to colorize contents
                        QPixmap blendedPixmap( blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );
                        blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                        QPainter p( &blendedPixmap );

                        p.drawPixmap( 0, 0, doubleBuffer,
                                    (blendRect.left() - contentsRect.left()) * devicePixelRatioF(), (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                    blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );

                        QColor blCol = selBlendColor.darker( 140 );
                        blCol.setAlphaF( 0.2 );
                        p.fillRect( blendedPixmap.rect(), blCol );
                        p.end();
                        // copy the blended pixmap back to its place
                        pixmapPainter.drawPixmap( blendRect.left(), blendRect.top(), blendedPixmap );
                    }
                    // draw border (red if the selection is too small)
                    pixmapPainter.setPen( selBlendColor );
                    pixmapPainter.drawRect( selectionRect.adjusted( 0, 0, -1, -1 ) );
                }
                // 2b) Layer 1b: paint (blend) transparent selection (table)
                foreach (const TableSelectionPart &tsp, d->tableSelectionParts) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                    QRect selectionPartRectInternal = selectionPartRect;
                    selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                    if ( !selectionPartRect.isNull() && selectionPartRect.intersects( contentsRect ) &&
                        !selectionPartRectInternal.contains( contentsRect ) )
                    {
                        QRect blendRect = selectionPartRectInternal.intersected( contentsRect );
                        // skip rectangles covered by the selection's border
                        if ( blendRect.isValid() )
                        {
                            // grab current pixmap into a new one to colorize contents
                            QPixmap blendedPixmap( blendRect.width()  * devicePixelRatioF(), blendRect.height()  * devicePixelRatioF() );
                            blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                            QPainter p( &blendedPixmap );
                            p.drawPixmap( 0, 0, doubleBuffer,
                                        (blendRect.left() - contentsRect.left()) * devicePixelRatioF(), (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                        blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF() );

                            QColor blCol = d->mouseSelectionColor.darker( 140 );
                            blCol.setAlphaF( 0.2 );
                            p.fillRect( blendedPixmap.rect(), blCol );
                            p.end();
                            // copy the blended pixmap back to its place
                            pixmapPainter.drawPixmap( blendRect.left(), blendRect.top(), blendedPixmap );
                        }
                        // draw border (red if the selection is too small)
                        pixmapPainter.setPen( d->mouseSelectionColor );
                        pixmapPainter.drawRect( selectionPartRect.adjusted( 0, 0, -1, -1 ) );
                    }
                }
                drawTableDividers( &pixmapPainter );
                // 3a) Layer 1: give annotator painting control
                if ( d->annotator && d->annotator->routePaints( contentsRect ) )
                    d->annotator->routePaint( &pixmapPainter, contentsRect );
                // 3b) Layer 1: give mouseAnnotation painting control
                d->mouseAnnotation->routePaint( &pixmapPainter, contentsRect );

                // 4) Layer 2: overlays
                if ( Okular::Settings::debugDrawBoundaries() )
                {
                    pixmapPainter.setPen( Qt::blue );
                    pixmapPainter.drawRect( contentsRect );
                }

                // finish painting and draw contents
                pixmapPainter.end();
                screenPainter.drawPixmap( contentsRect.left(), contentsRect.top(), doubleBuffer );
            }
            else
            {
                // 1) Layer 0: paint items and clear bg on unpainted rects
                drawDocumentOnPainter( contentsRect, &screenPainter );
                // 2a) Layer 1a: paint opaque selection (rectangle)
                if ( !selectionRect.isNull() && selectionRect.intersects( contentsRect ) &&
                    !selectionRectInternal.contains( contentsRect ) )
                {
                    screenPainter.setPen( palette().color( QPalette::Active, QPalette::Highlight ).darker(110) );
                    screenPainter.drawRect( selectionRect );
                }
                // 2b) Layer 1b: paint opaque selection (table)
                foreach (const TableSelectionPart &tsp, d->tableSelectionParts) {
                    QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                    selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
                    QRect selectionPartRectInternal = selectionPartRect;
                    selectionPartRectInternal.adjust( 1, 1, -1, -1 );
                    if ( !selectionPartRect.isNull() && selectionPartRect.intersects( contentsRect ) &&
                        !selectionPartRectInternal.contains( contentsRect ) )
                    {
                        screenPainter.setPen( palette().color( QPalette::Active, QPalette::Highlight ).darker(110) );
                        screenPainter.drawRect( selectionPartRect );
                    }
                }
                drawTableDividers( &screenPainter );
                // 3a) Layer 1: give annotator painting control
                if ( d->annotator && d->annotator->routePaints( contentsRect ) )
                    d->annotator->routePaint( &screenPainter, contentsRect );
                // 3b) Layer 1: give mouseAnnotation painting control
                d->mouseAnnotation->routePaint( &screenPainter, contentsRect );

                // 4) Layer 2: overlays
                if ( Okular::Settings::debugDrawBoundaries() )
                {
                    screenPainter.setPen( Qt::red );
                    screenPainter.drawRect( contentsRect );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const AnnotPagePair &pair : qAsConst(mAnnotations) )
        {
            menu.addAction( new OKMenuTitle( &menu, GuiUtils::captionForAnnotation( pair.annotation ) ) );

            action = menu.addAction( QIcon::fromTheme( QStringLiteral("comment") ), i18n( "&Open Pop-up Note" ) );
            action->setData( QVariant::fromValue( pair ) );
            action->setProperty( actionTypeId, openId );

            action = menu.addAction( QIcon::fromTheme( QStringLiteral("list-remove") ), i18n( "&Delete" ) );
            action->setEnabled( mDocument->isAllowed( Okular::AllowNotes ) &&
                                mDocument->canRemovePageAnnotation( pair.annotation ) );
            action->setData( QVariant::fromValue( pair ) );
            action->setProperty( actionTypeId, deleteId );

            action = menu.addAction( QIcon::fromTheme( QStringLiteral("configure") ), i18n( "&Properties" ) );
            action->setData( QVariant::fromValue( pair ) );
            action->setProperty( actionTypeId, propertiesId );

            if ( annotationHasFileAttachment( pair.annotation ) )
            {
                const Okular::EmbeddedFile *embeddedFile = embeddedFileFromAnnotation( pair.annotation );
                if ( embeddedFile )
                {
                    const QString saveText = i18nc( "%1 is the name of the file to save", "&Save '%1'...", embeddedFile->name() );

                    menu.addSeparator();
                    action = menu.addAction( QIcon::fromTheme( QStringLiteral("document-save") ), saveText );
                    action->setData( QVariant::fromValue( pair ) );
                    action->setProperty( actionTypeId, saveId );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &relEntry : qAsConst(relEntries)) {
            if (relEntry.compare(entryName, Qt::CaseInsensitive) == 0) {
                return relDir->entry(relEntry);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *) -> QObject * { return new OkularSingleton; }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers)) {
        if (o != excludeObserver) {
            o->notifyZoom(factor);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &wwc : list) {
            TinyTextEntity *ent = wwc.word;
            const QRect entRect = ent->area.geometry(pageWidth, pageHeight);

            // calculate vertical projection profile proj_on_xaxis1
            for (int k = entRect.left(); k <= entRect.left() + entRect.width(); ++k) {
                if ((k - regionRect.left()) < size_proj_x && (k - regionRect.left()) >= 0)
                    proj_on_xaxis[k - regionRect.left()] += entRect.height();
            }

            // calculate horizontal projection profile in the same way
            for (int k = entRect.top(); k <= entRect.top() + entRect.height(); ++k) {
                if ((k - regionRect.top()) < size_proj_y && (k - regionRect.top()) >= 0)
                    proj_on_yaxis[k - regionRect.top()] += entRect.width();
            }
        }
```

#### AUTO 


```{c}
auto *mainWindow = findMainWindow()
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& highlight : *bufferedHighlights)
            {
                const Okular::NormalizedRect & r = highlight.second;
                // find out the rect to highlight on pixmap
                QRect highlightRect = r.geometry( scaledWidth, scaledHeight ).translated( -scaledCrop.topLeft() ).intersected( limits );
                highlightRect.translate( -limits.left(), -limits.top() );

                const QColor highlightColor = highlight.first;
                QPainter painter(&backImage);
                painter.setCompositionMode(QPainter::CompositionMode_Multiply);
                painter.fillRect(highlightRect, highlightColor);

                auto frameColor = highlightColor.darker(150);
                const QRect frameRect = r.geometry( scaledWidth, scaledHeight ).translated( -scaledCrop.topLeft() ).translated( -limits.left(), -limits.top() );
                painter.setPen(frameColor);
                painter.drawRect(frameRect);
            }
```

#### AUTO 


```{c}
auto addColorMode = [=](KToggleAction *a, const QString &name, Okular::SettingsCore::EnumRenderMode::type id) {
        a->setData(int(id));
        addAction(a);
        ac->addAction(name, a);
        m_colorModeActionGroup->addAction(a);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const ParsedEntry &e : parsedList) {
        if (e.urls.empty())
            continue;

        EBookIndexEntry entry;
        entry.name = e.name;
        entry.urls = e.urls;
        entry.seealso = e.seealso;

        // If the index array is empty, make sure the first entry is on root offset
        if (index.isEmpty())
            entry.indent = root_offset;
        else
            entry.indent = e.indent - root_offset;

        index.append(entry);
        printf("%d: %s\n", entry.indent, qPrintable(entry.name));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]( QAction * action ) {
        if (action == d->agLastAction) {
            d->agLastAction = nullptr;
            d->agTools->checkedAction()->setChecked( false );
            d->selectTool( -1 );
        } else {
            d->agLastAction = action;
            // Show the annotation toolbar whenever actions are triggered (e.g using shortcuts)
            d->aShowToolBar->setChecked( true );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : qAsConst(content_parser.manifest)) {
        m_ebookManifest.push_back(pathToUrl(f));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &toolbar : toolbars) {
            m_hamburgerMenuAction->hideActionsOf(toolbar);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointer<QToolButton> &button : qAsConst(m_buttons)) {
        if (button) {
            button->setDefaultAction(defaultAction());

            // Override some properties of the default action,
            // where the property of this menu makes more sense.
            button->setEnabled(isEnabled());

            if (delayed()) {
                button->setPopupMode(QToolButton::DelayedPopup);
            } else if (stickyMenu()) {
                button->setPopupMode(QToolButton::InstantPopup);
            } else {
                button->setPopupMode(QToolButton::MenuButtonPopup);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                selectionPartRect.translate(tsp.item->uncroppedGeometry().topLeft());
                QRect selectionPartRectInternal = selectionPartRect;
                selectionPartRectInternal.adjust(1, 1, -1, -1);
                if (!selectionPartRect.isNull() && selectionPartRect.intersects(contentsRect) && !selectionPartRectInternal.contains(contentsRect)) {
                    QRect blendRect = selectionPartRectInternal.intersected(contentsRect);
                    // skip rectangles covered by the selection's border
                    if (blendRect.isValid()) {
                        // grab current pixmap into a new one to colorize contents
                        QPixmap blendedPixmap(blendRect.width() * devicePixelRatioF(), blendRect.height() * devicePixelRatioF());
                        blendedPixmap.setDevicePixelRatio(devicePixelRatioF());
                        QPainter p(&blendedPixmap);
                        p.drawPixmap(0,
                                     0,
                                     doubleBuffer,
                                     (blendRect.left() - contentsRect.left()) * devicePixelRatioF(),
                                     (blendRect.top() - contentsRect.top()) * devicePixelRatioF(),
                                     blendRect.width() * devicePixelRatioF(),
                                     blendRect.height() * devicePixelRatioF());

                        QColor blCol = d->mouseSelectionColor.darker(140);
                        blCol.setAlphaF(0.2);
                        p.fillRect(blendedPixmap.rect(), blCol);
                        p.end();
                        // copy the blended pixmap back to its place
                        pixmapPainter.drawPixmap(blendRect.left(), blendRect.top(), blendedPixmap);
                    }
                    // draw border (red if the selection is too small)
                    pixmapPainter.setPen(d->mouseSelectionColor);
                    pixmapPainter.drawRect(selectionPartRect.adjusted(0, 0, -1, -1));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->itemsToOpen)) {
            const QModelIndex index = d->indexForItem(item);
            if (!index.isValid()) {
                continue;
            }

            // TODO misusing parent() here, fix
            QMetaObject::invokeMethod(QObject::parent(), "expand", Qt::QueuedConnection, Q_ARG(QModelIndex, index));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->visibleItems)) {
        const QRect &r = i->croppedGeometry();
        if (x < r.right() && x > r.left() && y < r.bottom()) {
            if (y > r.top()) {
                item = i;
            }
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : qAsConst(entries)) {
            const KArchiveEntry *relSubEntry = relDir->entry(entry);
            if (!relSubEntry->isFile()) {
                continue;
            }

            const KZipFileEntry *relSubFile = static_cast<const KZipFileEntry *>(relSubEntry);
            data.append(relSubFile->data());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int index : selectedItems) {
            if (index >= 0 && index < count()) {
                item(index)->setSelected(true);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::FormFieldSignature *s : allSignatures) {
            bool createSignature = true;
            const QString fullyQualifiedName = s->fullyQualifiedName();
            auto compareSignatureByFullyQualifiedName = [&fullyQualifiedName](const Okular::FormField *off) { return off->fullyQualifiedName() == fullyQualifiedName; };

            // See if the signature is in one of the already loaded page (i.e. 1 to end)
            for (Okular::Page *p : qAsConst(pagesVector)) {
                const QList<Okular::FormField *> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end()) {
                    delete s;
                    createSignature = false;
                    break;
                }
            }
            // See if the signature is in page 0
            if (createSignature && std::find_if(page0FormFields.constBegin(), page0FormFields.constEnd(), compareSignatureByFullyQualifiedName) != page0FormFields.constEnd()) {
                delete s;
                createSignature = false;
            }
            // Otherwise it's a page-less signature, add it to page 0
            if (createSignature) {
                Okular::FormField *of = new PopplerFormFieldSignature(std::unique_ptr<Poppler::FormFieldSignature>(s));
                page0FormFields.append(of);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &entry : mainDir->entries() )
    {
        if ( mainDir->entry( entry )->isDirectory() )
        {
            qWarning() << "Warning: Found a directory inside" << archivePath << " - Okular does not create files like that so it is most probably forged.";
            return nullptr;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const FormFieldButton *formButton : qAsConst(m_formButtons) )
    {
        m_prevButtonStates.append( formButton->state() );
    }
```

#### AUTO 


```{c}
const auto fft = static_cast< Okular::FormFieldText * > ( m_ff );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &pair : defaultStamps()) {
        m_pixmapSelector->addItem(pair.first, pair.second);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            QList<QTreeWidgetItem *> subitems = createItems(url, m_document->bookmarkManager()->bookmarks(url));
            if (!subitems.isEmpty()) {
                FileItem *item = new FileItem(url, m_tree, m_document);
                item->addChildren(subitems);
                if (!currenturlitem && url == m_document->currentDocument()) {
                    currenturlitem = item;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *trimModeAction : trimModeActions)
    {
        if (trimModeAction->data().toInt() != except_id)
            trimModeAction->setChecked( false );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * ann : qAsConst( *d->textTools ) ) {
        ann->setEnabled( on );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &t : text )
    {
        for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QString( "(.*),\\s*(%1=.*)" ).arg( attribute ), QRegularExpression::DotMatchesEverythingOption );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                QStringList results = text;
                const int index = results.indexOf( t );
                results.removeAt( index );
                results.insert( index, match.captured( 2 ) );
                results.insert( index, match.captured( 1 ) );
                return splitDNAttributes( results );
            }
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_tabs.begin(), m_tabs.end(), [&url](const TabState state) { return state.part->url() == url; });
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormWidgetIface *fwi :  formWidgetsList)
        {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TinyTextEntity *te : qAsConst(d->m_words))
        {
            ret.append( new TextEntity( te->text(), new Okular::NormalizedRect( te->area) ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : rgn) {
            m_pageView->viewport()->update(r.translated(-areaPos));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &suffix : suffixes) {
                supportedPatterns += QStringLiteral("*.") + suffix;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::ObjectRect *annotRect : annotRects) {
                        Okular::Annotation *ann = ((Okular::AnnotationObjectRect *)annotRect)->annotation();
                        if (ann && (ann->subType() != Okular::Annotation::AWidget)) {
                            annotPopup.addAnnotation(ann, pageItem->pageNumber());
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TinyTextEntity *te : qAsConst(d->m_words)) {
            if (b == AnyPixelTextAreaInclusionBehaviour) {
                if (area->intersects(te->area)) {
                    ret.append(new TextEntity(te->text(), new Okular::NormalizedRect(te->area)));
                }
            } else {
                const NormalizedPoint center = te->area.center();
                if (area->contains(center.x, center.y)) {
                    ret.append(new TextEntity(te->text(), new Okular::NormalizedRect(te->area)));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                        // first, crop the cell to this part
                        if (!tsp.rectInSelection.intersects(cell))
                            continue;
                        Okular::NormalizedRect cellPart = tsp.rectInSelection & cell; // intersection

                        // second, convert it from table coordinates to part coordinates
                        cellPart.left -= tsp.rectInSelection.left;
                        cellPart.left /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                        cellPart.right -= tsp.rectInSelection.left;
                        cellPart.right /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                        cellPart.top -= tsp.rectInSelection.top;
                        cellPart.top /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                        cellPart.bottom -= tsp.rectInSelection.top;
                        cellPart.bottom /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);

                        // third, convert from part coordinates to item coordinates
                        cellPart.left *= (tsp.rectInItem.right - tsp.rectInItem.left);
                        cellPart.left += tsp.rectInItem.left;
                        cellPart.right *= (tsp.rectInItem.right - tsp.rectInItem.left);
                        cellPart.right += tsp.rectInItem.left;
                        cellPart.top *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                        cellPart.top += tsp.rectInItem.top;
                        cellPart.bottom *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                        cellPart.bottom += tsp.rectInItem.top;

                        // now get the text
                        Okular::RegularAreaRect rects;
                        rects.append( cellPart );
                        txt += tsp.item->page()->text( &rects, Okular::TextPage::CentralPixelTextAreaInclusionBehaviour );
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: pageFormFields )
        {
            fields.insert( ff->name(), static_cast< Okular::FormField* >( ff ) );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&programFeaturesLabelPlaced]() -> QString {
        if (programFeaturesLabelPlaced) {
            return QString();
        } else {
            programFeaturesLabelPlaced = true;
            return i18nc("@title:group Config dialog, general page", "Program features:");
        }
    }
```

#### AUTO 


```{c}
const auto button = KMessageBox::questionYesNo(
                widget(), i18n("You have chosen to save an Okular Archive without the file name ending with the '%1' extension. That is not allowed, do you want to choose a new name?", wantedExtension), i18n("Unsupported extension"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(quickTools)) {
        aQuickTools->removeAction(action);
        aQuickToolsBar->removeAction(action);
        delete action;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormField *f : formFields) {
            if (f->type() == Okular::FormField::FormSignature) {
                isDigitallySigned = true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QImage &image) { setPosterImage(image); }
```

#### LAMBDA EXPRESSION 


```{c}
[link]() {
                const Okular::BrowseAction *browseLink = static_cast<const Okular::BrowseAction *>(link);
                QClipboard *cb = QApplication::clipboard();
                cb->setText(browseLink->url().toDisplayString(), QClipboard::Clipboard);
                if (cb->supportsSelection())
                    cb->setText(browseLink->url().toDisplayString(), QClipboard::Selection);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation* annotation : annotations ) {
            m_document->removePageAnnotation( 0, annotation );
        }
```

#### AUTO 


```{c}
auto issuerBox = new QGroupBox(i18n("Issued By"), generalPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DVI_SourceFileAnchor &sfa : sourceAnchors) {
        if (sfa.page < 1 || (int)sfa.page > numofpages) {
            continue;
        }

        Okular::NormalizedPoint p(-1.0, (double)sfa.distance_from_top.getLength_in_pixel(dpi().height()) / (double)pageRequiredSize.height());
        Okular::SourceReference *sourceRef = new Okular::SourceReference(sfa.fileName, sfa.line);
        refRects[sfa.page - 1].append(new Okular::SourceRefObjectRect(p, sourceRef));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormField *ff : qAsConst(d->formfields) )
    {
        ff->d_ptr->setDefault();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto opacity : d->opacityStandardValues ) {
        KToggleAction * ann = new KToggleAction( d->opacityIcon( opacity ), QStringLiteral( "%1\%" ).arg( opacity ), this);
        d->aOpacity->addAction( ann );
        connect( ann, &QAction::triggered, this, [this, opacity] () {
            d->annotator->setAnnotationOpacity( opacity / 100 );
        } );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar &formatChar : format) {
            if (formatChar == 'M') {
                formatChar = 'm';
            } else if (formatChar == 'm') {
                formatChar = 'M';
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        if (action == d->agLastAction) {
            d->agLastAction = nullptr;
            d->agTools->checkedAction()->setChecked(false);
            d->selectTool(-1);
        } else {
            d->agLastAction = action;
            // Show the annotation toolbar whenever builtin tool actions are triggered (e.g using shortcuts)
            if (!d->isQuickToolAction(action)) {
                d->aToolBarVisibility->setChecked(true);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(m_fileList))
    {
        QFile::remove(file);
    }
```

#### AUTO 


```{c}
auto horizontalScaling = painterWindow.width() / pageSize.width();
```

#### AUTO 


```{c}
auto scrollBar = part.m_pageView->verticalScrollBar();
```

#### AUTO 


```{c}
auto signEngine = static_cast<PickPointEngineSignature *>(m_engine);
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : list) {
                const QRect wordRect = word.area().geometry(pageWidth, pageHeight);

                if (topRect.intersects(wordRect)) {
                    list1.append(word);
                } else {
                    list2.append(word);
                }
            }
```

#### AUTO 


```{c}
auto width
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->saveDocumentInfo(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Okular::Action *action, Okular::FormFieldText *fft) { document->processFormatAction(action, fft); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Term &t : qAsConst(termList)) {
		const QVector<Document> docs = t.documents;
		for(QVector<Document>::Iterator minDoc_it = minDocs.begin(); minDoc_it != minDocs.end(); ) {
			bool found = false;
			for (QVector<Document>::ConstIterator doc_it = docs.constBegin(); doc_it != docs.constEnd(); ++doc_it ) {
				if ( (*minDoc_it).docNumber == (*doc_it).docNumber ) {
					(*minDoc_it).frequency += (*doc_it).frequency;
					found = true;
					break;
				}
			}
			if ( !found )
				minDoc_it = minDocs.erase( minDoc_it );
			else
				++minDoc_it;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar &formatChar : format) {
            if (formatChar == QLatin1Char('M')) {
                formatChar = QLatin1Char('m');
            } else if (formatChar == QLatin1Char('m')) {
                formatChar = QLatin1Char('M');
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : anchors)
                    targets[QLatin1Char('#') + name] = it;
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_pagesVector)) {
        p->d->m_doc = d;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : choices) {
            bool ok = true;
            int val = str.toInt(&ok);
            if (ok) {
                newchoices.append(val);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
    {
        foreach (const QString& supported, md.mimeTypes())
        {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type) {
                exactMatches << md;
            }

            if (type.inherits(supported))
            {
                offers << md;
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KToolBar *toolBar) { return toolBar->objectName() == QStringLiteral("annotationToolBar"); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractButton *button : buttons) {
        checked.append(button->isChecked());
        Okular::FormFieldButton *formButton = static_cast<Okular::FormFieldButton *>(dynamic_cast<FormWidgetIface *>(button)->formField());
        formButtons.append(formButton);
        prevChecked.append(formButton->state());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int page : qAsConst(list)) {
        variantList << page;
    }
```

#### AUTO 


```{c}
auto saveBtn = new QPushButton( i18n( "Save As"), this );
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *field : fields) {
        resolveMediaLinkReference(field->activationAction());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MiniBar *miniBar : qAsConst(m_miniBars)) {
            miniBar->setEnabled(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *child : current->children) {
            if (child->viewport.isValid()) {
                if (child->viewport.pageNumber <= viewport.pageNumber) {
                    pos = child;
                    if (child->viewport.pageNumber == viewport.pageNumber) {
                        break;
                    }
                } else {
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *field : fields )
    {
        resolveMediaLinkReference( field->activationAction() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : colorModeActions) {
        a->setEnabled(enabled);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[view]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "Follow this link" action
        QAction *processLink = qobject_cast<QAction*>(menu->findChild<QAction*>("ProcessLinkAction"));
        QVERIFY(processLink);

        // chek if the menu contains  "Copy Link Address" action
        QAction *actCopyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyLinkLocationAction"));
        QVERIFY(actCopyLinkLocation);

        // close menu to continue test
        menu->close();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( SourceRefObjectRect *rect : refRects ) {
        m_rects << rect;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar &formatChar : format) {
            if (formatChar == 'M')
                formatChar = 'm';
            else if (formatChar == 'm')
                formatChar = 'M';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TextDocumentGeneratorPrivate::LinkPosition &linkPos : qAsConst(d->mLinkPositions) )
        {
            delete linkPos.link;
        }
```

#### AUTO 


```{c}
auto detailsFrame = new QFrame( this );
```

#### RANGE FOR STATEMENT 


```{c}
for (const HighlightAnnotation::Quad &quad : m_highlightQuads) {
        QList<NormalizedPoint> pathPoints;

        // first, we check if the point is within the area described by the 4 quads
        // this is the case, if the point is always on one side of each segments delimiting the polygon:
        pathPoints << quad.transformedPoint(0);
        int directionVote = 0;
        for (int i = 1; i < 5; ++i) {
            NormalizedPoint thisPoint = quad.transformedPoint(i % 4);
            directionVote += (isLeftOfVector(pathPoints.back(), thisPoint, point)) ? 1 : -1;
            pathPoints << thisPoint;
        }
        if (abs(directionVote) == 4) {
            return 0;
        }

        // if that's not the case, we treat the outline as path and simply determine
        // the distance from the path to the point
        const double thisOutsideDistance = ::distanceSqr(x, y, xScale, yScale, pathPoints);
        if (thisOutsideDistance < outsideDistance) {
            outsideDistance = thisOutsideDistance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QStringLiteral( "%1=\"(.*)\"" ).arg( attribute ) );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                t = attribute + "=" + match.captured( 1 );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *ann : tools) {
        ann->setEnabled(on);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            m_document->removePageAnnotation(0, annotation);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bm : list) {
        if (bm.parentGroup() == thebg) {
            thebg.deleteBookmark(bm);
            deletedAny = true;

            DocumentViewport vp(bm.url().fragment(QUrl::FullyDecoded));
            if (referurl == d->document->m_url) {
                d->urlBookmarks[vp.pageNumber]--;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->slotRegularExpression(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
        // add ticks for the edges of this area...
        colSelectionTicks.append(qMakePair(tsp.rectInSelection.left, +1));
        colSelectionTicks.append(qMakePair(tsp.rectInSelection.right, -1));
        rowSelectionTicks.append(qMakePair(tsp.rectInSelection.top, +1));
        rowSelectionTicks.append(qMakePair(tsp.rectInSelection.bottom, -1));

        // get the words in this part
        Okular::RegularAreaRect rects;
        rects.append(tsp.rectInItem);
        const Okular::TextEntity::List words = tsp.item->page()->words(&rects, Okular::TextPage::CentralPixelTextAreaInclusionBehaviour);

        for (const Okular::TextEntity *te : words) {
            if (te->text().isEmpty()) {
                delete te;
                continue;
            }

            Okular::NormalizedRect wordArea = *te->area();

            // convert it from item coordinates to part coordinates
            wordArea.left -= tsp.rectInItem.left;
            wordArea.left /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.right -= tsp.rectInItem.left;
            wordArea.right /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.top -= tsp.rectInItem.top;
            wordArea.top /= (tsp.rectInItem.bottom - tsp.rectInItem.top);
            wordArea.bottom -= tsp.rectInItem.top;
            wordArea.bottom /= (tsp.rectInItem.bottom - tsp.rectInItem.top);

            // convert from part coordinates to table coordinates
            wordArea.left *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.left += tsp.rectInSelection.left;
            wordArea.right *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.right += tsp.rectInSelection.left;
            wordArea.top *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.top += tsp.rectInSelection.top;
            wordArea.bottom *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.bottom += tsp.rectInSelection.top;

            // add to the ticks arrays...
            colTicks.append(qMakePair(wordArea.left, +1));
            colTicks.append(qMakePair(wordArea.right, -1));
            rowTicks.append(qMakePair(wordArea.top, +1));
            rowTicks.append(qMakePair(wordArea.bottom, -1));

            delete te;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int pageNumber : qAsConst(s->highlightedPages))
    {
        d->m_pagesVector.at(pageNumber)->d->deleteHighlights( searchID );
        foreachObserver( notifyPageChanged( pageNumber, DocumentObserver::Highlights ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : points) {
                    QPointF point = getPointFromString(p);
                    path.lineTo(point);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Term &t : qAsConst(termList)) {
        const QVector<Document> docs = t.documents;
        for (QVector<Document>::Iterator minDoc_it = minDocs.begin(); minDoc_it != minDocs.end();) {
            bool found = false;
            for (QVector<Document>::ConstIterator doc_it = docs.constBegin(); doc_it != docs.constEnd(); ++doc_it) {
                if ((*minDoc_it).docNumber == (*doc_it).docNumber) {
                    (*minDoc_it).frequency += (*doc_it).frequency;
                    found = true;
                    break;
                }
            }
            if (!found) {
                minDoc_it = minDocs.erase(minDoc_it);
            } else {
                ++minDoc_it;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFormFields) {
        if (ff->name().startsWith(QStringLiteral("Target"))) {
            QVERIFY(!ff->isVisible());
            anyChecked = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *ff : qAsConst(d->formfields)) {
        ff->d_ptr->setDefault();
        ff->d_ptr->m_page = this;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *w : formWidgetsList) {
                    w->setCanBeFilled(allowfillforms);
                }
```

#### AUTO 


```{c}
auto colorList = defaultColors;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::Link *popplerLink : popplerLinks)
    {
        QRectF linkArea = popplerLink->linkArea();
        double nl = linkArea.left(),
               nt = linkArea.top(),
               nr = linkArea.right(),
               nb = linkArea.bottom();
        // create the rect using normalized coords and attach the Okular::Link to it
        Okular::ObjectRect * rect = new Okular::ObjectRect( nl, nt, nr, nb, false, Okular::ObjectRect::Action, createLinkFromPopplerLink(popplerLink) );
        // add the ObjectRect to the container
        links.push_front( rect );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::Page *page : pages )
    {
        const int currentPage = page->number();
        // get form fields page by page so that page number and index of the form can be determined.
        const QVector<const Okular::FormFieldSignature*> signatureFormFields = SignatureGuiUtils::getSignatureFormFields( document, false, currentPage );
        if ( signatureFormFields.isEmpty() )
            continue;

        for ( int i = 0; i < signatureFormFields.count(); i++ )
        {
            const Okular::FormFieldSignature *sf = signatureFormFields[i];
            const Okular::SignatureInfo &info = sf->signatureInfo();

            // based on whether or not signature form is a nullptr it is decided if clicking on an item should change the viewport.
            auto *parentItem = new SignatureItem( root, sf, SignatureItem::RevisionInfo, currentPage );
            parentItem->displayString = i18n( "Rev. %1: Signed By %2", i+1, info.signerName() );

            auto childItem1 = new SignatureItem( parentItem, nullptr, SignatureItem::ValidityStatus, currentPage );
            childItem1->displayString = SignatureGuiUtils::getReadableSignatureStatus( info.signatureStatus() );

            auto childItem2 = new SignatureItem( parentItem, nullptr, SignatureItem::SigningTime, currentPage );
            childItem2->displayString = i18n("Signing Time: %1", info.signingTime().toString( Qt::DefaultLocaleLongDate ) );

            auto childItem3 = new SignatureItem( parentItem, nullptr, SignatureItem::Reason, currentPage );
            childItem3->displayString = i18n("Reason: %1", !info.reason().isEmpty() ? info.reason() : i18n("Not Available") );

            auto childItem4 = new SignatureItem( parentItem, sf, SignatureItem::FieldInfo, currentPage );
            childItem4->displayString = i18n("Field: %1 on page %2", sf->name(), currentPage+1 );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int fontId : qAsConst(m_fontCache)) {
        m_fontDatabase.removeApplicationFont(fontId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(m_observers)) {
        o->notifyPageChanged(page, DocumentObserver::Pixmap | DocumentObserver::Annotations);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString &t : result )
    {
        for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QString( "%1=\"(.*)\"" ).arg( attribute ) );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                t = attribute + "=" + match.captured( 1 );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
            menu->addAction(new OKMenuTitle(menu, GuiUtils::captionForAnnotation(pair.annotation)));

            action = menu->addAction(QIcon::fromTheme(QStringLiteral("comment")), i18n("&Open Pop-up Note"));
            connect(action, &QAction::triggered, menu, [this, pair] { doOpenAnnotationWindow(pair); });

            action = menu->addAction(QIcon::fromTheme(QStringLiteral("list-remove")), i18n("&Delete"));
            action->setEnabled(mDocument->isAllowed(Okular::AllowNotes) && mDocument->canRemovePageAnnotation(pair.annotation));
            connect(action, &QAction::triggered, menu, [this, pair] { doRemovePageAnnotation(pair); });

            action = menu->addAction(QIcon::fromTheme(QStringLiteral("configure")), i18n("&Properties"));
            connect(action, &QAction::triggered, menu, [this, pair] { doOpenPropertiesDialog(pair); });

            if (annotationHasFileAttachment(pair.annotation)) {
                const Okular::EmbeddedFile *embeddedFile = embeddedFileFromAnnotation(pair.annotation);
                if (embeddedFile) {
                    const QString saveText = i18nc("%1 is the name of the file to save", "&Save '%1'...", embeddedFile->name());

                    menu->addSeparator();
                    action = menu->addAction(QIcon::fromTheme(QStringLiteral("document-save")), saveText);
                    connect(action, &QAction::triggered, menu, [this, pair] { doSaveEmbeddedFile(pair); });
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& highlight : qAsConst(*bufferedHighlights))
            {
                const Okular::NormalizedRect & r = highlight.second;
                // find out the rect to highlight on pixmap
                QRect highlightRect = r.geometry( scaledWidth, scaledHeight ).translated( -scaledCrop.topLeft() ).intersected( limits );
                highlightRect.translate( -limits.left(), -limits.top() );

                const QColor highlightColor = highlight.first;
                QPainter painter(&backImage);
                painter.setCompositionMode(QPainter::CompositionMode_Multiply);
                painter.fillRect(highlightRect, highlightColor);

                auto frameColor = highlightColor.darker(150);
                const QRect frameRect = r.geometry( scaledWidth, scaledHeight ).translated( -scaledCrop.topLeft() ).translated( -limits.left(), -limits.top() );
                painter.setPen(frameColor);
                painter.drawRect(frameRect);
            }
```

#### AUTO 


```{c}
auto client
```

#### RANGE FOR STATEMENT 


```{c}
for ( TOCItem* item : qAsConst(d->currentPage) )
    {
        QModelIndex index = d->indexForItem( item );
        if ( !index.isValid() )
            continue;

        item->highlight = true;
        emit dataChanged( index, index );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : qAsConst(m_videoWidgets) )
    {
        const Okular::NormalizedRect r = vw->normGeometry();
        vw->resize(
            qRound( fabs( r.right - r.left ) * m_uncroppedGeometry.width() ),
            qRound( fabs( r.bottom - r.top ) * m_uncroppedGeometry.height() ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->visibleItems)) {
        const QRect &r = i->croppedGeometry();
        if (x < r.right() && x > r.left() && y < r.bottom()) {
            if (y > r.top())
                item = i;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ResizeHandle &handle : m_resizeHandleList )
        {
            const QRect rect = getHandleRect( handle, ad );
            if ( rect.contains( eventPos ) )
            {
                selected |= handle;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &toolXml : tools )
            {
                QDomDocument entryParser;
                if ( entryParser.setContent( toolXml ) ) {
                    root.appendChild( m_toolsDefinition.importNode( entryParser.documentElement(), true ) );
                    m_toolsCount++;
                } else {
                    qCWarning(OkularUiDebug) << "Skipping malformed tool XML in AnnotationTools setting";
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
        {
            // TODO should be uniquify this list?
            result << md.mimeTypes();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, searchStruct] { doContinueDirectionMatchSearch(searchStruct); }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { widget->setDummyMode(false); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *request : requests )
    {
        // set the 'page field' (see PixmapRequest) and check if it is valid
        qCDebug(OkularCoreDebug).nospace() << "request observer=" << request->observer() << " " <<request->width() << "x" << request->height() << "@" << request->pageNumber();
        if ( d->m_pagesVector.value( request->pageNumber() ) == 0 )
        {
            // skip requests referencing an invalid page (must not happen)
            delete request;
            continue;
        }

        request->d->mPage = d->m_pagesVector.value( request->pageNumber() );

        if ( request->isTile() )
        {
            // Change the current request rect so that only invalid tiles are
            // requested. Also make sure the rect is tile-aligned.
            NormalizedRect tilesRect;
            const QList<Tile> tiles = request->d->tilesManager()->tilesAt( request->normalizedRect(), TilesManager::TerminalTile );
            QList<Tile>::const_iterator tIt = tiles.constBegin(), tEnd = tiles.constEnd();
            while ( tIt != tEnd )
            {
                const Tile &tile = *tIt;
                if ( !tile.isValid() )
                {
                    if ( tilesRect.isNull() )
                        tilesRect = tile.rect();
                    else
                        tilesRect |= tile.rect();
                }

                tIt++;
            }

            request->setNormalizedRect( tilesRect );
        }

        if ( !request->asynchronous() )
            request->d->mPriority = 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( TileNode &tile : d->tiles )
    {
        d->setPixmap( pixmap, rotatedRect, tile, isPartialPixmap );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RegionText &tmpRegion : tree) {
        // Step 01
        QList<QPair<WordsWithCharacters, QRect>> sortedLines = makeAndSortLines(tmpRegion.text(), pageWidth, pageHeight);

        // Step 02
        for (QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines) {
            WordsWithCharacters &list = sortedLine.first;
            for (int k = 0; k < list.length(); k++) {
                const QRect area1 = list.at(k).area().roundedGeometry(pageWidth, pageHeight);
                if (k + 1 >= list.length())
                    break;

                const QRect area2 = list.at(k + 1).area().roundedGeometry(pageWidth, pageHeight);
                const int space = area2.left() - area1.right();

                if (space != 0) {
                    // Make a TinyTextEntity of string space and push it between it and it+1
                    const int left = area1.right();
                    const int right = area2.left();
                    const int top = area2.top() < area1.top() ? area2.top() : area1.top();
                    const int bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                    const QString spaceStr(QStringLiteral(" "));
                    const QRect rect(QPoint(left, top), QPoint(right, bottom));
                    const NormalizedRect entRect(rect, pageWidth, pageHeight);
                    TinyTextEntity *ent1 = new TinyTextEntity(spaceStr, entRect);
                    TinyTextEntity *ent2 = new TinyTextEntity(spaceStr, entRect);
                    WordWithCharacters word(ent1, QList<TinyTextEntity *>() << ent2);

                    list.insert(k + 1, word);

                    // Skip the space
                    k++;
                }
            }
        }

        WordsWithCharacters tmpList;
        for (const QPair<WordsWithCharacters, QRect> &sortedLine : qAsConst(sortedLines)) {
            tmpList += sortedLine.first;
        }
        tmpRegion.setText(tmpList);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& md : available)
        {
            result << md.mimeTypes();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::ObjectRect * orect : orects )
                        {
                            Okular::Annotation * ann = ( (Okular::AnnotationObjectRect *)orect )->annotation();
                            if ( ann && (ann->subType() != Okular::Annotation::AWidget) )
                                popup.addAnnotation( ann, pageItem->pageNumber() );

                        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex &proxyIndex : proxyIndexes ) {
        if ( !isAuthorItem( proxyIndex ) ) {
            sourceSelection << QItemSelectionRange( mapToSource( proxyIndex ) );
        }
    }
```

#### AUTO 


```{c}
auto extraInfoFormLayout = new QFormLayout( extraInfoBox );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : entryList) {
        const KArchiveEntry *e = dir->entry(file);
        if (e->isDirectory()) {
            imagesInArchive(prefix + file + QLatin1Char('/'), static_cast<const KArchiveDirectory *>(e), entries);
        } else if (e->isFile()) {
            entries->append(prefix + file);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::HighlightAreaRect *highlight : page->m_highlights) {
                for (hIt = highlight->constBegin(); hIt != highlight->constEnd(); ++hIt) {
                    if ((*hIt).intersects(limitRect)) {
                        bufferedHighlights->append(qMakePair(highlight->color, *hIt));
                    }
                }
            }
```

#### AUTO 


```{c}
const auto currentViewportIterator = QLinkedList< DocumentViewport >::const_iterator(m_viewportIterator);
```

#### RANGE FOR STATEMENT 


```{c}
for( const EBookTocEntry &e : qAsConst(toc_parser.entries) )
        {
            // Add into url-title map
            m_urlTitleMap[ e.url ] = e.name;
            m_tocEntries.push_back( e );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AnnotWindow *aw : qAsConst(d->m_annowindows)) {
                    Okular::Annotation *newA = d->document->page(aw->pageNumber())->annotation(aw->annotation()->uniqueName());
                    aw->updateAnnotation(newA);
                }
```

#### AUTO 


```{c}
auto it = std::find_if(defaultStamps.begin(), defaultStamps.end(), [&stampIconName](const QPair<QString, QString> &element) { return element.second == stampIconName; });
```

#### RANGE FOR STATEMENT 


```{c}
for ( const XpsRenderNode &child : qAsConst(node.children) ) {
            double offset = child.attributes.value( QStringLiteral("Offset") ).toDouble();
            QColor color = hexToRgba( child.attributes.value( QStringLiteral("Color") ).toLatin1() );
            gradients.append( XpsGradient( offset, color ) );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *visibleItem : qAsConst(d->visibleItems)) {
            if (abs(visibleItem->pageNumber() - pageNumber) <= 1) {
                return false;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NormalizedPoint &np : m_transformedInplaceCallout) {
        np.transform(matrix);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &colorNameValue : colorList) {
        QColor color(colorNameValue.second);
        QAction *aColor = new QAction(colorIcon(color), i18nc("@item:inlistbox Color name", "%1", colorNameValue.first), q);
        aColorPicker->addAction(aColor);
        QObject::connect(aColor, &QAction::triggered, q, [this, colorType, color]() { slotSetColor(colorType, color); });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsGradient &grad : gradients) {
        if (grad.offset == offset) {
            return i;
        }
        ++i;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers))
    {
        QLinkedList< Okular::PixmapRequest * > requestedPixmaps;

        TilesManager *tilesManager = page->d->tilesManager( observer );
        if ( tilesManager )
        {
            tilesManager->markDirty();

            PixmapRequest * p = new PixmapRequest( observer, pageNumber, tilesManager->width() / qApp->devicePixelRatio(), tilesManager->height() / qApp->devicePixelRatio(), 1, PixmapRequest::Asynchronous );

            // Get the visible page rect
            NormalizedRect visibleRect;
            QVector< Okular::VisiblePageRect * >::const_iterator vIt = m_pageRects.constBegin(), vEnd = m_pageRects.constEnd();
            for ( ; vIt != vEnd; ++vIt )
            {
                if ( (*vIt)->pageNumber == pageNumber )
                {
                    visibleRect = (*vIt)->rect;
                    break;
                }
            }

            if ( !visibleRect.isNull() )
            {
                p->setNormalizedRect( visibleRect );
                p->setTile( true );
                p->d->mForce = true;
                requestedPixmaps.push_back( p );
            }
            else
            {
                delete p;
            }
        }

        m_parent->requestPixmaps( requestedPixmaps, Okular::Document::NoOption );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Annotation *annotation : annotationsList) {
            Okular::Action *action = nullptr;

            if (annotation->subType() == Okular::Annotation::AScreen)
                action = static_cast<const Okular::ScreenAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageClosing);
            else if (annotation->subType() == Okular::Annotation::AWidget)
                action = static_cast<const Okular::WidgetAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageClosing);

            if (action)
                m_document->processAction(action);
        }
```

#### AUTO 


```{c}
auto signatureStatusBox = new QGroupBox( i18n("Validity Status") );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pages) {
        const int currentPage = page->number();
        // get form fields page by page so that page number and index of the form can be determined.
        const QVector<const Okular::FormFieldSignature *> signatureFormFields = SignatureGuiUtils::getSignatureFormFields(document, false, currentPage);
        if (signatureFormFields.isEmpty())
            continue;

        for (int i = 0; i < signatureFormFields.count(); i++) {
            const Okular::FormFieldSignature *sf = signatureFormFields[i];
            const Okular::SignatureInfo &info = sf->signatureInfo();

            // based on whether or not signature form is a nullptr it is decided if clicking on an item should change the viewport.
            auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, currentPage);
            parentItem->displayString = i18n("Rev. %1: Signed By %2", i + 1, info.signerName());

            auto childItem1 = new SignatureItem(parentItem, nullptr, SignatureItem::ValidityStatus, currentPage);
            childItem1->displayString = SignatureGuiUtils::getReadableSignatureStatus(info.signatureStatus());

            auto childItem2 = new SignatureItem(parentItem, nullptr, SignatureItem::SigningTime, currentPage);
            childItem2->displayString = i18n("Signing Time: %1", info.signingTime().toString(Qt::DefaultLocaleLongDate));

            auto childItem3 = new SignatureItem(parentItem, nullptr, SignatureItem::Reason, currentPage);
            childItem3->displayString = i18n("Reason: %1", !info.reason().isEmpty() ? info.reason() : i18n("Not Available"));

            auto childItem4 = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, currentPage);
            childItem4->displayString = i18n("Field: %1 on page %2", sf->name(), currentPage + 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &t : text) {
        for (const QString &attribute : attributes) {
            const QRegularExpression re(QStringLiteral("(.*),\\s*(%1=.*)").arg(attribute), QRegularExpression::DotMatchesEverythingOption);
            const QRegularExpressionMatch match = re.match(t);
            if (match.hasMatch()) {
                QStringList results = text;
                const int index = results.indexOf(t);
                results.removeAt(index);
                results.insert(index, match.captured(2));
                results.insert(index, match.captured(1));
                return splitDNAttributes(results);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QString &t : result )
    {
        for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QStringLiteral( "%1=\"(.*)\"" ).arg( attribute ) );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                t = attribute + "=" + match.captured( 1 );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int size : {16, 22, 24, 32, 48}) {
        QPixmap pixmap(QSize(size, size) * qApp->devicePixelRatio());
        pixmap.setDevicePixelRatio(qApp->devicePixelRatio());
        pixmap.fill(Qt::transparent);
        QPainter painter(&pixmap);
        // Configure hairlines for visualization of outline or transparency (visualizeTransparent):
        painter.setPen(QPen(qApp->palette().color(QPalette::Active, QPalette::WindowText), 0));
        painter.setBrush(Qt::NoBrush);

        if (background.isNull()) {
            // Full-size color rectangles.
            // Draw rectangles left to right:
            for (int i = 0; i < colors.count(); ++i) {
                if (!colors.at(i).isValid()) {
                    continue;
                }
                QRect rect(QPoint(size * i / colors.count(), 0), QPoint(size * (i + 1) / colors.count(), size));
                if ((flags & VisualizeTransparent) && (colors.at(i) == Qt::transparent)) {
                    painter.drawLine(rect.topLeft(), rect.bottomRight());
                    painter.drawLine(rect.bottomLeft(), rect.topRight());
                } else {
                    painter.fillRect(rect, colors.at(i));
                }
            }

            // Draw hairline outline:
            // To get the hairline on the outermost pixels, we shrink the rectangle by a half pixel on each edge.
            const qreal halfPixelWidth = 0.5 / pixmap.devicePixelRatio();
            painter.drawRect(QRectF(QPointF(halfPixelWidth, halfPixelWidth), QPointF(qreal(size) - halfPixelWidth, qreal(size) - halfPixelWidth)));
        } else {
            // Lower 25% color rectangles.
            // Draw background icon:
            background.paint(&painter, QRect(QPoint(0, 0), QSize(size, size)));

            // Draw rectangles left to right:
            for (int i = 0; i < colors.count(); ++i) {
                if (!colors.at(i).isValid()) {
                    continue;
                }
                QRect rect(QPoint(size * i / colors.count(), size * 3 / 4), QPoint(size * (i + 1) / colors.count(), size));
                if ((flags & VisualizeTransparent) && (colors.at(i) == Qt::transparent)) {
                    painter.drawLine(rect.topLeft(), rect.bottomRight());
                    painter.drawLine(rect.bottomLeft(), rect.topRight());
                } else {
                    painter.fillRect(rect, colors.at(i));
                }
            }
        }

        painter.end();
        colorIcon.addPixmap(pixmap);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ link ]() {
                const Okular::BrowseAction * browseLink = static_cast< const Okular::BrowseAction * >( link );
                QClipboard *cb = QApplication::clipboard();
                cb->setText( browseLink->url().toDisplayString(), QClipboard::Clipboard );
                if ( cb->supportsSelection() )
                    cb->setText( browseLink->url().toDisplayString(), QClipboard::Selection );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVoice &voice : voices) {
        if (voice.name() == voiceName) {
            d->speech->setVoice(voice);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RegionText &tmpRegion : tree) {
        // Step 01
        QList<QPair<WordsWithCharacters, QRect>> sortedLines = makeAndSortLines(tmpRegion.text(), pageWidth, pageHeight);

        // Step 02
        for (QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines) {
            WordsWithCharacters &list = sortedLine.first;
            for (int k = 0; k < list.length(); k++) {
                const QRect area1 = list.at(k).area().roundedGeometry(pageWidth, pageHeight);
                if (k + 1 >= list.length()) {
                    break;
                }

                const QRect area2 = list.at(k + 1).area().roundedGeometry(pageWidth, pageHeight);
                const int space = area2.left() - area1.right();

                if (space != 0) {
                    // Make a TinyTextEntity of string space and push it between it and it+1
                    const int left = area1.right();
                    const int right = area2.left();
                    const int top = area2.top() < area1.top() ? area2.top() : area1.top();
                    const int bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                    const QString spaceStr(QStringLiteral(" "));
                    const QRect rect(QPoint(left, top), QPoint(right, bottom));
                    const NormalizedRect entRect(rect, pageWidth, pageHeight);
                    TinyTextEntity *ent1 = new TinyTextEntity(spaceStr, entRect);
                    TinyTextEntity *ent2 = new TinyTextEntity(spaceStr, entRect);
                    WordWithCharacters word(ent1, QList<TinyTextEntity *>() << ent2);

                    list.insert(k + 1, word);

                    // Skip the space
                    k++;
                }
            }
        }

        WordsWithCharacters tmpList;
        for (const QPair<WordsWithCharacters, QRect> &sortedLine : qAsConst(sortedLines)) {
            tmpList += sortedLine.first;
        }
        tmpRegion.setText(tmpList);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) { d->slotToolBarVisibilityChanged(checked); }
```

#### AUTO 


```{c}
const auto widgets = createdWidgets();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &characterBitmap : characterBitmaps)
        characterBitmap = nullptr;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Okular::Action *action, Okular::FormFieldText *fft) { document->processFocusAction(action, fft); }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->items)) {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for (FormWidgetIface *fwi : formWidgetsList) {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for (VideoWidget *vw : videoWidgets) {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());

            if (vw->isPlaying() && viewportRectAtZeroZero.intersected(vw->geometry()).isEmpty()) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if (!i->isVisible())
            continue;
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking page" << i->pageNumber();
        kWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects(i->croppedGeometry());
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected(i->croppedGeometry());
        if (intersectionRect.isEmpty()) {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back(i);
        Okular::VisiblePageRect *vItem = new Okular::VisiblePageRect(i->pageNumber(), Okular::NormalizedRect(intersectionRect.translated(-i->uncroppedGeometry().topLeft()), i->uncroppedWidth(), i->uncroppedHeight()));
        visibleRects.push_back(vItem);
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight());
        kWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if (i->page()->hasTilesManager(this) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low) {
            double rectMargin = pixelsToExpand / (double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax(0.0, vItem->rect.left - rectMargin);
            expandedVisibleRect.top = qMax(0.0, vItem->rect.top - rectMargin);
            expandedVisibleRect.right = qMin(1.0, vItem->rect.right + rectMargin);
            expandedVisibleRect.bottom = qMin(1.0, vItem->rect.bottom + rectMargin);
        }

        // if the item has not the right pixmap, add a request for it
        if (!i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect)) {
#ifdef PAGEVIEW_DEBUG
            kWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest *p = new Okular::PixmapRequest(this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous);
            requestedPixmaps.push_back(p);

            if (i->page()->hasTilesManager(this)) {
                p->setNormalizedRect(expandedVisibleRect);
                p->setTile(true);
            } else
                p->setNormalizedRect(vItem->rect);
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if (isEvent) {
            const QRect &geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            const double distance = hypot((geometry.left() + geometry.right()) / 2.0 - (viewportCenterX - 4), (geometry.top() + geometry.bottom()) / 2.0 - viewportCenterY);
            if (distance >= minDistance && nearPageNumber != -1)
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if (geometry.height() > 0 && geometry.width() > 0) {
                focusedX = (viewportCenterX - (double)geometry.left()) / (double)geometry.width();
                focusedY = (viewportCenterY - (double)geometry.top()) / (double)geometry.height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::Annotation *a : popplerAnnotations) {
        bool doDelete = true;
        Okular::Annotation *newann = createAnnotationFromPopplerAnnotation(a, *popplerPage, &doDelete);
        if (newann) {
            page->addAnnotation(newann);

            if (a->subType() == Poppler::Annotation::AScreen) {
                Poppler::ScreenAnnotation *annotScreen = static_cast<Poppler::ScreenAnnotation *>(a);
                Okular::ScreenAnnotation *screenAnnotation = static_cast<Okular::ScreenAnnotation *>(newann);

                // The activation action
                const Poppler::Link *actionLink = annotScreen->action();
                if (actionLink)
                    screenAnnotation->setAction(createLinkFromPopplerLink(actionLink));

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotScreen->additionalAction(Poppler::Annotation::PageOpeningAction);
                if (pageOpeningLink)
                    screenAnnotation->setAdditionalAction(Okular::Annotation::PageOpening, createLinkFromPopplerLink(pageOpeningLink));

                const Poppler::Link *pageClosingLink = annotScreen->additionalAction(Poppler::Annotation::PageClosingAction);
                if (pageClosingLink)
                    screenAnnotation->setAdditionalAction(Okular::Annotation::PageClosing, createLinkFromPopplerLink(pageClosingLink));
            }

            if (a->subType() == Poppler::Annotation::AWidget) {
                Poppler::WidgetAnnotation *annotWidget = static_cast<Poppler::WidgetAnnotation *>(a);
                Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation *>(newann);

                // The additional actions
                const Poppler::Link *pageOpeningLink = annotWidget->additionalAction(Poppler::Annotation::PageOpeningAction);
                if (pageOpeningLink)
                    widgetAnnotation->setAdditionalAction(Okular::Annotation::PageOpening, createLinkFromPopplerLink(pageOpeningLink));

                const Poppler::Link *pageClosingLink = annotWidget->additionalAction(Poppler::Annotation::PageClosingAction);
                if (pageClosingLink)
                    widgetAnnotation->setAdditionalAction(Okular::Annotation::PageClosing, createLinkFromPopplerLink(pageClosingLink));
            }

            if (!doDelete)
                annotationsOnOpenHash.insert(newann, a);
        }
        if (doDelete)
            delete a;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &supported : mimetypes)
        {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(supported);
            if (mimeType == type && !exactMatches.contains(md)) {
                exactMatches << md;
            }

            if (type.inherits(supported) && !offers.contains(md))
            {
                offers << md;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *w : fws) {
                        Okular::FormField *f = Okular::PagePrivate::findEquivalentForm(d->document->page(i), w->formField());
                        if (f) {
                            w->setFormField(f);
                        } else {
                            qWarning() << "Lost form field on document save, something is wrong";
                            item->formWidgets().remove(w);
                            delete w;
                        }
                    }
```

#### AUTO 


```{c}
auto &retI
```

#### RANGE FOR STATEMENT 


```{c}
for (const TeXFontDefinition *font : fonts) {
            Okular::FontInfo of;
            QString name;
            int zoom = (int)(font->enlargement * 100 + 0.5);
#ifdef HAVE_FREETYPE
            if (font->getFullFontName().isEmpty()) {
                name = QStringLiteral("%1, %2%").arg(font->fontname).arg(zoom);
            } else {
                name = QStringLiteral("%1 (%2), %3%").arg(font->fontname, font->getFullFontName(), QString::number(zoom));
            }
#else
            name = QString("%1, %2%").arg(font->fontname).arg(zoom);
#endif
            of.setName(name);

            QString fontFileName;
            if (!(font->flags & TeXFontDefinition::FONT_VIRTUAL)) {
                if (font->font != nullptr) {
                    fontFileName = font->font->errorMessage;
                } else {
                    fontFileName = i18n("Font file not found");
                }

                if (fontFileName.isEmpty()) {
                    fontFileName = font->filename;
                }
            }

            of.setFile(fontFileName);

            Okular::FontInfo::FontType ft;
            switch (font->getFontType()) {
            case TeXFontDefinition::TEX_PK:
                ft = Okular::FontInfo::TeXPK;
                break;
            case TeXFontDefinition::TEX_VIRTUAL:
                ft = Okular::FontInfo::TeXVirtual;
                break;
            case TeXFontDefinition::TEX_FONTMETRIC:
                ft = Okular::FontInfo::TeXFontMetric;
                break;
            case TeXFontDefinition::FREETYPE:
                ft = Okular::FontInfo::TeXFreeTypeHandled;
                break;
            }
            of.setType(ft);

            // DVI has not the concept of "font embedding"
            of.setEmbedType(Okular::FontInfo::NotEmbedded);
            of.setCanBeExtracted(false);

            list.append(of);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
        QLinkedList<Okular::PixmapRequest *> requestedPixmaps;

        TilesManager *tilesManager = page->d->tilesManager(observer);
        if (tilesManager) {
            tilesManager->markDirty();

            PixmapRequest *p = new PixmapRequest(observer, pageNumber, tilesManager->width(), tilesManager->height(), 1 /* dpr */, 1, PixmapRequest::Asynchronous);

            // Get the visible page rect
            NormalizedRect visibleRect;
            QVector<Okular::VisiblePageRect *>::const_iterator vIt = m_pageRects.constBegin(), vEnd = m_pageRects.constEnd();
            for (; vIt != vEnd; ++vIt) {
                if ((*vIt)->pageNumber == pageNumber) {
                    visibleRect = (*vIt)->rect;
                    break;
                }
            }

            if (!visibleRect.isNull()) {
                p->setNormalizedRect(visibleRect);
                p->setTile(true);
                p->d->mForce = true;
                requestedPixmaps.push_back(p);
            } else {
                delete p;
            }
        }

        m_parent->requestPixmaps(requestedPixmaps, Okular::Document::NoOption);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Action *a : nextActions )
        {
            processAction( a );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->_o_configChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TileNode &tile : qAsConst(d->tiles)) {
        if (!d->hasPixmap(rotatedRect, tile)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &ks : infoKeys) {
        if ( !orderedProperties.contains( ks ) ) {
            orderedProperties << ks;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QUrl &url : urls )
        {
            QList<QTreeWidgetItem*> subitems = createItems( url, m_document->bookmarkManager()->bookmarks( url ) );
            if ( !subitems.isEmpty() )
            {
                FileItem * item = new FileItem( url, m_tree, m_document );
                item->addChildren( subitems );
                if ( !currenturlitem && url == m_document->currentDocument() )
                {
                    currenturlitem = item;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFormFields) {
        fields.insert(ff->name(), static_cast<Okular::FormField *>(ff));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString url : qAsConst(content_parser.spine)) {
            EBookTocEntry e;

            if (content_parser.manifest.contains(url))
                url = content_parser.manifest[url];

            e.name = url;
            e.url = pathToUrl(url);
            e.iconid = EBookTocEntry::IMAGE_NONE;
            e.indent = 0;

            // Add into url-title map
            m_urlTitleMap[pathToUrl(url)] = url;
            m_tocEntries.push_back(e);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageSet) {
        PageViewItem *item = new PageViewItem(page);
        d->items.push_back(item);
#ifdef PAGEVIEW_DEBUG
        qCDebug(OkularUiDebug).nospace() << "cropped geom for " << d->items.last()->pageNumber() << " is " << d->items.last()->croppedGeometry();
#endif
        const QList<Okular::FormField *> pageFields = page->formFields();
        for (Okular::FormField *ff : pageFields) {
            FormWidgetIface *w = FormWidgetFactory::createWidget(ff, this);
            if (w) {
                w->setPageItem(item);
                w->setFormWidgetsController(d->formWidgetsController());
                w->setVisibility(false);
                w->setCanBeFilled(allowfillforms);
                item->formWidgets().insert(w);
                hasformwidgets = true;
            }
        }

        createAnnotationsVideoWidgets(item, page->annotations());
    }
```

#### AUTO 


```{c}
auto openResult = loadDocumentWithPassword(newFileName, newPagesVector, QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const TextDocumentGeneratorPrivate::LinkInfo &info : linkInfos) {
        // in case that the converter report bogus link info data, do not assert here
        if (info.page < 0 || info.page >= objects.count()) {
            continue;
        }

        const QRectF rect = info.boundingRect;
        if (info.ownsLink) {
            objects[info.page].append(new Okular::ObjectRect(rect.left(), rect.top(), rect.right(), rect.bottom(), false, Okular::ObjectRect::Action, info.link));
        } else {
            objects[info.page].append(new Okular::NonOwningObjectRect(rect.left(), rect.top(), rect.right(), rect.bottom(), false, Okular::ObjectRect::Action, info.link));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * viewModeAction : viewModeActions )
    {
        if ( viewModeAction->data().toInt() == Okular::Settings::viewMode() )
        {
            viewModeAction->setChecked( true );
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bm : bmarks) {
        DocumentViewport vp(bm.url().fragment(QUrl::FullyDecoded));
        if (vp.isValid() && vp.pageNumber == page) {
            return bm;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EBookTocEntry &e : qAsConst(topics))
    {
        QDomElement item = m_docSyn.createElement(e.name);
        if (!e.url.isEmpty())
        {
            QString url = e.url.toString();
            item.setAttribute(QStringLiteral("ViewportName"), url);
            if(!tmpPageList.contains(url))
            {//add a page only once
                tmpPageList.insert(url, pageNum);
                pageNum++;
            }
        }
        item.setAttribute(QStringLiteral("Icon"), e.iconid);
        if (e.indent == 0) m_docSyn.appendChild(item);
        else lastIndentElement[e.indent - 1].appendChild(item);
        lastIndentElement[e.indent] = item;
    }
```

#### AUTO 


```{c}
auto addViewMode = [=] ( QAction * a, const QString &name, Okular::Settings::EnumViewMode::type id ) {
        a->setCheckable( true );
        a->setData( int( id ) );
        d->aViewModeMenu->addAction( a );
        ac->addAction( name, a );
        d->viewModeActionGroup->addAction( a );
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(const RegionText &tmpRegion : qAsConst(tree))
    {
        tmp += tmpRegion.text();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( SignatureItem *child : qAsConst(item->children) ) {
        updateFormFieldSignaturePointer( child, pages );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *executingRequest : qAsConst(m_executingPixmapRequests)) {
                executingRequest->d->mShouldAbortRender = 1;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pagesToNotifySet, pageMatches, currentPage, searchID, words] { doContinueGooglesDocumentSearch(pagesToNotifySet, pageMatches, currentPage + 1, searchID, words); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int req : qAsConst(d->refreshPages))
    {
        QMetaObject::invokeMethod( d->document, "refreshPixmaps", Qt::QueuedConnection,
                                   Q_ARG( int, req ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
            if (!mDocument->canRemovePageAnnotation(pair.annotation)) {
                action->setEnabled(false);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : listWithWordsAndSpaces) {
        delete word.word;
        listOfCharacters.append(word.characters);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const DVI_SourceFileAnchor &sfa : sourceAnchors )
    {
        if ( sfa.page < 1 || (int)sfa.page > numofpages )
            continue;

        Okular::NormalizedPoint p( -1.0, (double)sfa.distance_from_top.getLength_in_pixel( dpi().height() ) / (double)pageRequiredSize.height() );
        Okular::SourceReference * sourceRef = new Okular::SourceReference( sfa.fileName, sfa.line );
        refRects[ sfa.page - 1 ].append( new Okular::SourceRefObjectRect( p, sourceRef ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Document &doc : qAsConst(minDocs))
            results << docList.at((int)doc.docNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *executingRequest : qAsConst(d->m_executingPixmapRequests)) {
            bool newRequestsContainExecutingRequestPage = false;
            bool requestCancelled = false;
            for (PixmapRequest *newRequest : requests) {
                if (newRequest->pageNumber() == executingRequest->pageNumber() && requesterObserver == executingRequest->observer()) {
                    newRequestsContainExecutingRequestPage = true;
                }

                if (shouldCancelRenderingBecauseOf(*executingRequest, *newRequest)) {
                    requestCancelled = d->cancelRenderingBecauseOf(executingRequest, newRequest);
                }
            }

            // If we were told to remove all the previous requests and the executing request page is not part of the new requests, cancel it
            if (!requestCancelled && removeAllPrevious && requesterObserver == executingRequest->observer() && !newRequestsContainExecutingRequestPage) {
                requestCancelled = d->cancelRenderingBecauseOf(executingRequest, nullptr);
            }

            if (requestCancelled) {
                observersPixmapCleared << executingRequest->observer();
            }
        }
```

#### AUTO 


```{c}
auto menu = m_hamburgerMenuAction->menu();
```

#### LAMBDA EXPRESSION 


```{c}
[this, stamp](bool checked) {
            if (checked) {
                d->slotStampToolSelected(stamp.second);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Page *pIt : qAsConst(doc->m_pagesVector)) {
        const QList<Okular::FormField *> pageFields = pIt->formFields();

        if (numField < pageFields.size()) {
            const Okular::FormField *form = pageFields[numField];

            return KJSString(form->fullyQualifiedName());
        }

        numField -= pageFields.size();
    }
```

#### AUTO 


```{c}
auto item = cssArray[i];
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : videoWidgets) {
                        const Okular::NormalizedRect r = vw->normGeometry();
                        vw->setGeometry(qRound(item->uncroppedGeometry().left() + item->uncroppedWidth() * r.left) + 1 - viewportRect.left(),
                                        qRound(item->uncroppedGeometry().top() + item->uncroppedHeight() * r.top) + 1 - viewportRect.top(),
                                        qRound(fabs(r.right - r.left) * item->uncroppedGeometry().width()),
                                        qRound(fabs(r.bottom - r.top) * item->uncroppedGeometry().height()));

                        // Workaround, otherwise the size somehow gets lost
                        vw->show();
                        vw->hide();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::HighlightAnnotation::Quad &quad : hlann->highlightQuads())
            {
                const Okular::NormalizedPoint p3 = quad.point( 3 );
                quad.setPoint( quad.point(0), 3 );
                quad.setPoint( p3, 0 );
                const Okular::NormalizedPoint p2 = quad.point( 2 );
                quad.setPoint( quad.point(1), 2 );
                quad.setPoint( p2, 1 );
            }
```

#### AUTO 


```{c}
auto subjectFormLayout = new QFormLayout( subjectBox );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageSet) {
        PresentationFrame *frame = new PresentationFrame();
        frame->page = page;
        const QLinkedList<Okular::Annotation *> annotations = page->annotations();
        for (Okular::Annotation *a : annotations) {
            if (a->subType() == Okular::Annotation::AMovie) {
                Okular::MovieAnnotation *movieAnn = static_cast<Okular::MovieAnnotation *>(a);
                VideoWidget *vw = new VideoWidget(movieAnn, movieAnn->movie(), m_document, this);
                frame->videoWidgets.insert(movieAnn->movie(), vw);
                vw->pageInitialized();
            } else if (a->subType() == Okular::Annotation::ARichMedia) {
                Okular::RichMediaAnnotation *richMediaAnn = static_cast<Okular::RichMediaAnnotation *>(a);
                if (richMediaAnn->movie()) {
                    VideoWidget *vw = new VideoWidget(richMediaAnn, richMediaAnn->movie(), m_document, this);
                    frame->videoWidgets.insert(richMediaAnn->movie(), vw);
                    vw->pageInitialized();
                }
            } else if (a->subType() == Okular::Annotation::AScreen) {
                const Okular::ScreenAnnotation *screenAnn = static_cast<Okular::ScreenAnnotation *>(a);
                Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation(screenAnn);
                if (movie) {
                    VideoWidget *vw = new VideoWidget(screenAnn, movie, m_document, this);
                    frame->videoWidgets.insert(movie, vw);
                    vw->pageInitialized();
                }
            }
        }
        frame->recalcGeometry(m_width, m_height, screenRatio);
        // add the frame to the vector
        m_frames.push_back(frame);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
                if (!item->isVisible())
                    continue;

                const QRect &itemRect = item->croppedGeometry();
                if (selectionRect.intersects(itemRect)) {
                    // request the textpage if there isn't one
                    okularPage = item->page();
                    qCDebug(OkularUiDebug) << "checking if page" << item->pageNumber() << "has text:" << okularPage->hasTextPage();
                    if (!okularPage->hasTextPage())
                        d->document->requestTextPage(okularPage->number());
                    // grab text in the rect that intersects itemRect
                    QRect rectInItem = selectionRect.intersected(itemRect);
                    rectInItem.translate(-item->uncroppedGeometry().topLeft());
                    QRect rectInSelection = selectionRect.intersected(itemRect);
                    rectInSelection.translate(-selectionRect.topLeft());
                    d->tableSelectionParts.append(
                        TableSelectionPart(item, Okular::NormalizedRect(rectInItem, item->uncroppedWidth(), item->uncroppedHeight()), Okular::NormalizedRect(rectInSelection, selectionRect.width(), selectionRect.height())));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *widget : widgets) {
        auto *actionBarWidget = qobject_cast<ActionBarWidget *>(widget);
        if (actionBarWidget) {
            actionBarWidget->recreateButtons(m_actions);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields)) {
        if (f->rect() == oldField->rect() && f->type() == oldField->type() && f->id() == oldField->id()) {
            return f;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TextDocumentGeneratorPrivate::LinkPosition &linkPos : qAsConst(d->mLinkPositions)) {
            delete linkPos.link;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<WordsWithCharacters, QRect> &line : lines) {
        WordsWithCharacters &list = line.first;
        std::sort(list.begin(), list.end(), compareTinyTextEntityX);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::FormField *f : popplerFormFields) {
        Okular::FormField *of = nullptr;
        switch (f->type()) {
        case Poppler::FormField::FormButton:
            of = new PopplerFormFieldButton(std::unique_ptr<Poppler::FormFieldButton>(static_cast<Poppler::FormFieldButton *>(f)));
            break;
        case Poppler::FormField::FormText:
            of = new PopplerFormFieldText(std::unique_ptr<Poppler::FormFieldText>(static_cast<Poppler::FormFieldText *>(f)));
            break;
        case Poppler::FormField::FormChoice:
            of = new PopplerFormFieldChoice(std::unique_ptr<Poppler::FormFieldChoice>(static_cast<Poppler::FormFieldChoice *>(f)));
            break;
        case Poppler::FormField::FormSignature: {
            of = new PopplerFormFieldSignature(std::unique_ptr<Poppler::FormFieldSignature>(static_cast<Poppler::FormFieldSignature *>(f)));
            break;
        }
        default:;
        }
        if (of) {
            // form field created, good - it will take care of the Poppler::FormField
            okularFormFields.append(of);
        } else {
            // no form field available - delete the Poppler::FormField
            delete f;
        }
    }
```

#### AUTO 


```{c}
auto cmp = [](const KPluginMetaData& s1, const KPluginMetaData& s2)
        {
            const QString property = QStringLiteral("X-KDE-Priority");
            return s1.rawData()[property].toInt() > s2.rawData()[property].toInt();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action) {
        if (action->isCheckable()) {
            d->aQuickTools->setDefaultAction(action);
        }
    }
```

#### AUTO 


```{c}
auto dialogHelper = std::make_unique<TestingUtils::CloseDialogHelper>(&part, QDialogButtonBox::No);
```

#### RANGE FOR STATEMENT 


```{c}
for (fix_word &fw : heightTable_in_units_of_design_size) {
        fw.value = 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: page->formFields() )
    {
        fields.insert( ff->name(), static_cast<Okular::FormFieldText*>( ff ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double opacity : d->opacityStandardValues) {
        KToggleAction *ann = new KToggleAction(GuiUtils::createOpacityIcon(opacity), QStringLiteral("%1%").arg(opacity * 100), this);
        d->aOpacity->addAction(ann);
        connect(ann, &QAction::triggered, this, [this, opacity]() { d->annotator->setAnnotationOpacity(opacity); });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            m_certificatesAsked = false;
            update();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : videoWidgets )
                    {
                        const Okular::NormalizedRect r = vw->normGeometry();
                        vw->setGeometry(
                            qRound( item->uncroppedGeometry().left() + item->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                            qRound( item->uncroppedGeometry().top() + item->uncroppedHeight() * r.top ) + 1 - viewportRect.top(),
                            qRound( fabs( r.right - r.left ) * item->uncroppedGeometry().width() ),
                            qRound( fabs( r.bottom - r.top ) * item->uncroppedGeometry().height() ) );

                        // Workaround, otherwise the size somehow gets lost
                        vw->show();
                        vw->hide();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TeXFontDefinition *font : fonts)
        {
            Okular::FontInfo of;
            QString name;
            int zoom = (int)(font->enlargement*100 + 0.5);
#ifdef HAVE_FREETYPE
            if ( font->getFullFontName().isEmpty() ) 
            {
                name = QStringLiteral( "%1, %2%" )
                        .arg( font->fontname )
                        .arg( zoom );
            }
            else
            {
                name = QStringLiteral( "%1 (%2), %3%" ) 
                        .arg( font->fontname, font->getFullFontName(), QString::number(zoom) ); 
            }
#else
            name = QString( "%1, %2%" )
                    .arg( font->fontname )
                    .arg( zoom );
#endif
            of.setName( name );

            QString fontFileName;
            if (!(font->flags & TeXFontDefinition::FONT_VIRTUAL)) {
                if ( font->font != nullptr )
                    fontFileName = font->font->errorMessage;
                else
                    fontFileName = i18n("Font file not found");

                if ( fontFileName.isEmpty() )
                    fontFileName = font->filename;
            }

            of.setFile( fontFileName );

            Okular::FontInfo::FontType ft;
            switch ( font->getFontType() )
            {
                case TeXFontDefinition::TEX_PK:
                    ft = Okular::FontInfo::TeXPK;
                    break;
                case TeXFontDefinition::TEX_VIRTUAL:
                    ft = Okular::FontInfo::TeXVirtual;
                    break;
                case TeXFontDefinition::TEX_FONTMETRIC:
                    ft = Okular::FontInfo::TeXFontMetric;
                    break;
                case TeXFontDefinition::FREETYPE:
                    ft = Okular::FontInfo::TeXFreeTypeHandled;
                    break;
            }
            of.setType( ft );

            // DVI has not the concept of "font embedding"
            of.setEmbedType( Okular::FontInfo::NotEmbedded );
            of.setCanBeExtracted( false );

            list.append( of );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int page : qAsConst(affectedItemsIds)) {
                ret.append(textSelectionForItem(d->items[page]));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *executingRequest : qAsConst(m_executingPixmapRequests))
                executingRequest->d->mShouldAbortRender = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : words)
        miniDict.insert(word, new PosEntry(0));
```

#### LAMBDA EXPRESSION 


```{c}
[this, toolId] ( bool checked ) {
            if ( checked )
                d->selectTool( toolId );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
        d->scroller->scrollTo(QPoint(horizontalScrollBar()->value(), verticalScrollBar()->value()), 0); //sync scroller with scrollbar
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( QPair<WordsWithCharacters, QRect> &linesI : lines)
        {
            /* the line area which will be expanded
               line_rects is only necessary to preserve the topmin and bottommax of all
               the texts in the line, left and right is not necessary at all
            */
            QRect &lineArea = linesI.second;
            const int text_y1 = elementArea.top() ,
                      text_y2 = elementArea.top() + elementArea.height() ,
                      text_x1 = elementArea.left(),
                      text_x2 = elementArea.left() + elementArea.width();
            const int line_y1 = lineArea.top() ,
                      line_y2 = lineArea.top() + lineArea.height(),
                      line_x1 = lineArea.left(),
                      line_x2 = lineArea.left() + lineArea.width();

            /*
               if the new text and the line has y overlapping parts of more than 70%,
               the text will be added to this line
             */
            if(doesConsumeY(elementArea,lineArea,70))
            {
                WordsWithCharacters &line = linesI.first;
                line.append(*it);

                const int newLeft = line_x1 < text_x1 ? line_x1 : text_x1;
                const int newRight = line_x2 > text_x2 ? line_x2 : text_x2;
                const int newTop = line_y1 < text_y1 ? line_y1 : text_y1;
                const int newBottom = text_y2 > line_y2 ? text_y2 : line_y2;

                lineArea = QRect( newLeft,newTop, newRight - newLeft, newBottom - newTop );
                found = true;
            }

            if(found) break;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool selected) {
        if (selected) {
            QAction *aMouseMode = d->mouseModeActionGroup->checkedAction();
            if (aMouseMode) {
                aMouseMode->setChecked(false);
            }
        } else {
            switch (d->mouseMode) {
            case Okular::Settings::EnumMouseMode::Browse:
                d->aMouseNormal->setChecked(true);
                break;
            case Okular::Settings::EnumMouseMode::Zoom:
                d->aMouseZoom->setChecked(true);
                break;
            case Okular::Settings::EnumMouseMode::RectSelect:
                d->aMouseSelect->setChecked(true);
                break;
            case Okular::Settings::EnumMouseMode::TableSelect:
                d->aMouseTableSelect->setChecked(true);
                break;
            case Okular::Settings::EnumMouseMode::Magnifier:
                d->aMouseMagnifier->setChecked(true);
                break;
            case Okular::Settings::EnumMouseMode::TextSelect:
                d->aMouseTextSelect->setChecked(true);
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto *potentialMainWindow = parent();
```

#### AUTO 


```{c}
auto revisionLayout = new QHBoxLayout(revisionBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toolXml : tools) {
            QDomDocument entryParser;
            if (entryParser.setContent(toolXml)) {
                root.appendChild(m_toolsDefinition.importNode(entryParser.documentElement(), true));
                m_toolsCount++;
            } else {
                qCWarning(OkularUiDebug) << "Skipping malformed tool XML in AnnotationTools setting";
            }
        }
```

#### AUTO 


```{c}
auto validityFormLayout = new QFormLayout(validityBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this](Okular::FormField *form) {
        Okular::FormFieldText *fft = reinterpret_cast<Okular::FormFieldText *>(form);
        if (fft) {
            m_formattedText = fft->text();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &qurl : qAsConst(pageList)) {
        QString url = qurl.toString();
        const QString urlLower = url.toLower();
        if (!urlLower.endsWith(QLatin1String(".html")) && !urlLower.endsWith(QLatin1String(".htm")))
            continue;

        int pos = url.indexOf(QLatin1Char(('#')));
        // insert the url into the maps, but insert always the variant without the #ref part
        QString tmpUrl = pos == -1 ? url : url.left(pos);

        // url already there, abort insertion
        if (m_urlPage.contains(tmpUrl))
            continue;

        int foundPage = tmpPageList.value(tmpUrl, -1);
        if (foundPage != -1) {
            m_urlPage.insert(tmpUrl, foundPage);
            m_pageUrl[foundPage] = tmpUrl;
        } else {
            // add pages not present in toc
            m_urlPage.insert(tmpUrl, pageNum);
            m_pageUrl.append(tmpUrl);
            pageNum++;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &filePath, int pageNumber) {
        // We cheat a bit here reusing the urlsDropped signal, but at the end the output is the same, we want to open some files
        // urlsDropped should have just had a different name
        QUrl u = QUrl::fromLocalFile(filePath);
        u.setFragment(QStringLiteral("page=%1").arg(pageNumber));
        Q_EMIT urlsDropped({u});
    }
```

#### AUTO 


```{c}
auto hideBtn = m_fields[QStringLiteral( "HideScriptButton" )];
```

#### RANGE FOR STATEMENT 


```{c}
for (const TileNode &tile : d->tiles) {
        d->deleteTiles(tile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
        // set the 'page field' (see PixmapRequest) and check if it is valid
        qCDebug(OkularCoreDebug).nospace() << "request observer=" << request->observer() << " " << request->width() << "x" << request->height() << "@" << request->pageNumber();
        if (d->m_pagesVector.value(request->pageNumber()) == nullptr) {
            // skip requests referencing an invalid page (must not happen)
            delete request;
            continue;
        }

        request->d->mPage = d->m_pagesVector.value(request->pageNumber());

        if (request->isTile()) {
            // Change the current request rect so that only invalid tiles are
            // requested. Also make sure the rect is tile-aligned.
            NormalizedRect tilesRect;
            const QList<Tile> tiles = request->d->tilesManager()->tilesAt(request->normalizedRect(), TilesManager::TerminalTile);
            QList<Tile>::const_iterator tIt = tiles.constBegin(), tEnd = tiles.constEnd();
            while (tIt != tEnd) {
                const Tile &tile = *tIt;
                if (!tile.isValid()) {
                    if (tilesRect.isNull())
                        tilesRect = tile.rect();
                    else
                        tilesRect |= tile.rect();
                }

                tIt++;
            }

            request->setNormalizedRect(tilesRect);
        }

        if (!request->asynchronous())
            request->d->mPriority = 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &entry : qAsConst(entries) ) {
            const KArchiveEntry* relSubEntry = relDir->entry( entry );
            if ( !relSubEntry->isFile() )
                continue;

            const KZipFileEntry* relSubFile = static_cast<const KZipFileEntry *>( relSubEntry );
            data.append( relSubFile->data() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::HighlightAnnotation::Quad &quad : hlann->highlightQuads()) {
                const Okular::NormalizedPoint p3 = quad.point(3);
                quad.setPoint(quad.point(0), 3);
                quad.setPoint(p3, 0);
                const Okular::NormalizedPoint p2 = quad.point(2);
                quad.setPoint(quad.point(1), 2);
                quad.setPoint(p2, 1);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FontInfo &fi : list) {
            Q_EMIT gotFont(fi);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
            openUrl(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * ann : qAsConst( *d->textQuickTools ) ) {
        ann->setEnabled( on );
    }
```

#### AUTO 


```{c}
auto update_scroller = [=]() {
        d->scroller->scrollTo(QPoint(horizontalScrollBar()->value(), verticalScrollBar()->value()), 0); // sync scroller with scrollbar
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotAttemptReload(); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::FormFieldButton* formButton : formButtons )
    {
        int id = formButton->id();
        QAbstractButton* button = m_buttons[id];
        CheckBoxEdit *check = qobject_cast< CheckBoxEdit * >( button );
        if ( check )
        {
            emit refreshFormWidget( check->formField() );
        }
        // temporarily disable exclusiveness of the button group
        // since it breaks doing/redoing steps into which all the checkboxes
        // are unchecked
        const bool wasExclusive = button->group()->exclusive();
        button->group()->setExclusive(false);
        bool checked = formButton->state();
        button->setChecked( checked );
        button->group()->setExclusive(wasExclusive);
        button->setFocus();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TextDocumentGeneratorPrivate::LinkInfo &info : linkInfos ) {
        // in case that the converter report bogus link info data, do not assert here
        if ( info.page >= objects.count() )
          continue;

        const QRectF rect = info.boundingRect;
        objects[ info.page ].append( new Okular::ObjectRect( rect.left(), rect.top(), rect.right(), rect.bottom(), false,
                                                             Okular::ObjectRect::Action, info.link ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *twi : selected) {
        Okular::EmbeddedFile *ef = qvariant_cast<Okular::EmbeddedFile *>(twi->data(0, EmbeddedFileRole));
        viewFile(ef);
    }
```

#### AUTO 


```{c}
auto validityBox = new QGroupBox( i18n("Validity"), generalPage );
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList) {
        action->setEnabled( true );
        m_topBar->addAction( action );
        addAction( action );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int c : qAsConst(choices) )
            {
                list.append( QString::number( c ) );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsRenderNode &child : qAsConst(node.children)) {
            double offset = child.attributes.value(QStringLiteral("Offset")).toDouble();
            QColor color = hexToRgba(child.attributes.value(QStringLiteral("Color")).toLatin1());
            gradients.append(XpsGradient(offset, color));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QStringLiteral( "(.*),\\s*(%1=.*)" ).arg( attribute ), QRegularExpression::DotMatchesEverythingOption );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                QStringList results = text;
                const int index = results.indexOf( t );
                results.removeAt( index );
                results.insert( index, match.captured( 2 ) );
                results.insert( index, match.captured( 1 ) );
                return splitDNAttributes( results );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DVI_SourceFileAnchor &sfa : sourceAnchors) {
        if (sfa.page < 1 || (int)sfa.page > numofpages)
            continue;

        Okular::NormalizedPoint p(-1.0, (double)sfa.distance_from_top.getLength_in_pixel(dpi().height()) / (double)pageRequiredSize.height());
        Okular::SourceReference *sourceRef = new Okular::SourceReference(sfa.fileName, sfa.line);
        refRects[sfa.page - 1].append(new Okular::SourceRefObjectRect(p, sourceRef));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &iListing : qAsConst(listing) )
	{
		// Strip the directory name
		const QString ename = iListing.mid (striplength);

		if ( isDirectory ( ename ) )
			app_dir(entry, ename);
		else
			app_file(entry, ename, 0);
 
	}
```

#### RANGE FOR STATEMENT 


```{c}
for(QPair<WordsWithCharacters, QRect> &line : lines)
    {
        WordsWithCharacters &list = line.first;
        std::sort(list.begin(), list.end(), compareTinyTextEntityX);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &action : actions) {
        QToolButton *toolButton = new QToolButton(this);
        toolButton->setAutoRaise(true);
        toolButton->setFocusPolicy(Qt::NoFocus);
        toolButton->setIconSize(parentToolbar->iconSize());
        toolButton->setToolButtonStyle(parentToolbar->toolButtonStyle());
        toolButton->setDefaultAction(action);
        layout()->addWidget(toolButton);
        layout()->setAlignment(toolButton, Qt::AlignCenter);
        connect(parentToolbar, &QToolBar::iconSizeChanged, toolButton, &QToolButton::setIconSize);
        connect(parentToolbar, &QToolBar::toolButtonStyleChanged, toolButton, &QToolButton::setToolButtonStyle);
    }
```

#### AUTO 


```{c}
auto *actionBarWidget = qobject_cast<ActionBarWidget *>(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QAction *action : actions) {
                if (action->isChecked()) {
                    return action->data();
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        d->scroller->scrollTo(QPoint(horizontalScrollBar()->value(), verticalScrollBar()->value()), 0); // sync scroller with scrollbar
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( MiniBar *miniBar : qAsConst(m_miniBars) )
        {
            // update prev/next button state
            miniBar->m_prevButton->setEnabled( currentPage > 0 );
            miniBar->m_nextButton->setEnabled( currentPage < ( pages - 1 ) );
            // update text on widgets
            miniBar->m_pageNumberEdit->setText( pageNumber );
            miniBar->m_pageNumberLabel->setText( pageNumber );
            miniBar->m_pageLabelEdit->setText( pageLabel );
        }
```

#### AUTO 


```{c}
auto sha256Label = new QLabel( QString( QCryptographicHash::hash( certData, QCryptographicHash::Sha256 ).toHex(' ') ) );
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *ff : pageFormFields) {
        if (ff->id() == 65537) {
            QCOMPARE(ff->type(), FormField::FormText);
            FormFieldText *fft = static_cast<FormFieldText *>(ff);
            part.m_document->editFormText(0, fft, QStringLiteral("BlaBla"), 6, 0, 0);
        } else if (ff->id() == 65538) {
            QCOMPARE(ff->type(), FormField::FormButton);
            FormFieldButton *ffb = static_cast<FormFieldButton *>(ff);
            QCOMPARE(ffb->buttonType(), FormFieldButton::Radio);
            part.m_document->editFormButtons(0, QList<FormFieldButton *>() << ffb, QList<bool>() << true);
        } else if (ff->id() == 65542) {
            QCOMPARE(ff->type(), FormField::FormChoice);
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>(ff);
            QCOMPARE(ffc->choiceType(), FormFieldChoice::ListBox);
            part.m_document->editFormList(0, ffc, QList<int>() << 1);
        } else if (ff->id() == 65543) {
            QCOMPARE(ff->type(), FormField::FormChoice);
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>(ff);
            QCOMPARE(ffc->choiceType(), FormFieldChoice::ComboBox);
            part.m_document->editFormCombo(0, ffc, QStringLiteral("combo2"), 3, 0, 0);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotSaveFileAs(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toolXml : items) {
        QDomDocument entryParser;
        if (!entryParser.setContent(toolXml)) {
            qWarning() << "Skipping malformed tool XML string";
            break;
        }

        const QDomElement toolElement = entryParser.documentElement();
        if (toolElement.tagName() == QLatin1String("tool")) {
            const QString name = toolElement.attribute(QStringLiteral("name"));
            QString itemText;
            if (toolElement.attribute(QStringLiteral("default"), QStringLiteral("false")) == QLatin1String("true")) {
                itemText = i18n(name.toLatin1().constData());
            } else {
                itemText = name;
            }

            QListWidgetItem *listEntry = new QListWidgetItem(itemText, m_list);
            listEntry->setData(ToolXmlRole, QVariant::fromValue(toolXml));
            listEntry->setData(Qt::DecorationRole, colorDecorationFromToolDescription(toolXml));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &drawingXml : drawingTools) {
        QDomDocument entryParser;
        if (entryParser.setContent(drawingXml)) {
            drawingDefinition.appendChild(doc.importNode(entryParser.documentElement(), true));
        } else {
            qCWarning(OkularUiDebug) << "Skipping malformed quick selection XML in QuickSelectionTools setting";
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
        // update internal page size (leaving a little margin in case of Fit* modes)
        updateItemSize(item, colWidth[cIdx] - kcolWidthMargin, viewportHeight - krowHeightMargin);
        // find row's maximum height and column's max width
        if (item->croppedWidth() + kcolWidthMargin > colWidth[cIdx]) {
            colWidth[cIdx] = item->croppedWidth() + kcolWidthMargin;
        }
        if (item->croppedHeight() + krowHeightMargin > rowHeight[rIdx]) {
            rowHeight[rIdx] = item->croppedHeight() + krowHeightMargin;
        }
        // handle the 'centering on first row' stuff
        // update col/row indices
        if (++cIdx == nCols) {
            cIdx = 0;
            rIdx++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *pageItem : qAsConst(d->items)) {
        if (pageItem->isVisible()) {
            currentPageItem = pageItem;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : qAsConst(videoWidgets)) {
            const Okular::NormalizedRect r = vw->normGeometry();
            QRect vwgeom = r.geometry(geometry.width(), geometry.height());
            vw->resize(vwgeom.size());
            vw->move(geometry.topLeft() + vwgeom.topLeft());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parameter : parameters) {
                if (parameter.startsWith(QStringLiteral("page="), Qt::CaseInsensitive)) {
                    page = dest.midRef(5).toInt(&ok);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int pageNumber : qAsConst(s->highlightedPages)) {
        d->m_pagesVector.at(pageNumber)->d->deleteHighlights(searchID);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &docscript : docScripts )
        {
            d->m_scripter->execute( JavaScript, docscript );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int p : pageList) {
        pages += QStringLiteral(",%1").arg(p);
    }
```

#### AUTO 


```{c}
auto wheelDown = new QWheelEvent({}, {}, {}, {0, -150}, Qt::NoButton, Qt::NoModifier, Qt::NoScrollPhase, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cert : certs)
              vReturnCerts.append(new PopplerCertificateInfo(*cert));
```

#### RANGE FOR STATEMENT 


```{c}
for (double row : qAsConst(d->tableSelectionRows)) {
                if (row >= tsp.rectInSelection.top && row <= tsp.rectInSelection.bottom) {
                    row = (row - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                    const int y = selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                    screenPainter->drawLine(selectionPartRectInternal.left(), y, selectionPartRectInternal.left() + selectionPartRectInternal.width(), y);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields)) {
        if (f->rect() == oldField->rect() && f->type() == oldField->type()) {
            return f;
        }
    }
```

#### AUTO 


```{c}
auto *mainWindow = qobject_cast<KMainWindow *>(potentialMainWindow)
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Annotation *ann : annotations) {
                if (!(ann->flags() & Okular::Annotation::External)) {
                    wontSaveAnnotations = true;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, colorType, color] () {
            slotSetColor( colorType, color );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->currentPage)) {
        QModelIndex index = d->indexForItem(item);
        if (!index.isValid()) {
            continue;
        }

        item->highlight = false;
        Q_EMIT dataChanged(index, index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *ann : qAsConst(*d->textTools)) {
        ann->setEnabled(on);
    }
```

#### AUTO 


```{c}
auto childItem2 = new SignatureItem(parentItem, nullptr, SignatureItem::SigningTime, currentPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *page : qAsConst(m_color_pages)) {
        page->hide();
    }
```

#### AUTO 


```{c}
auto dialogHelper = std::make_unique<TestingUtils::CloseDialogHelper>( &part, QDialogButtonBox::No );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : qAsConst(m_fileformats)) {
        QMimeType mimeType = mimeDatabase.mimeTypeForName(mimeName);
        const QStringList globs(mimeType.globPatterns());
        if (globs.isEmpty()) {
            continue;
        }

        globPatterns.unite(globs.toSet());

        namedGlobs[mimeType.comment()].append(globs);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            for (const AnnotPagePair &pair : qAsConst(mAnnotations)) {
                doRemovePageAnnotation(pair);
            }
        }
```

#### AUTO 


```{c}
auto generalPage = new QFrame(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::TextEntity *te : words)
        {
            if (te->text().isEmpty()) {
                delete te;
                continue;
            }

            Okular::NormalizedRect wordArea = *te->area();

            // convert it from item coordinates to part coordinates
            wordArea.left -= tsp.rectInItem.left;
            wordArea.left /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.right -= tsp.rectInItem.left;
            wordArea.right /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.top -= tsp.rectInItem.top;
            wordArea.top /= (tsp.rectInItem.bottom - tsp.rectInItem.top);
            wordArea.bottom -= tsp.rectInItem.top;
            wordArea.bottom /= (tsp.rectInItem.bottom - tsp.rectInItem.top);

            // convert from part coordinates to table coordinates
            wordArea.left *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.left += tsp.rectInSelection.left;
            wordArea.right *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.right += tsp.rectInSelection.left;
            wordArea.top *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.top += tsp.rectInSelection.top;
            wordArea.bottom *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.bottom += tsp.rectInSelection.top;

            // add to the ticks arrays...
            colTicks.append( qMakePair( wordArea.left,   +1) );
            colTicks.append( qMakePair( wordArea.right,  -1) );
            rowTicks.append( qMakePair( wordArea.top,    +1) );
            rowTicks.append( qMakePair( wordArea.bottom, -1) );

            delete te;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, width] () {
            d->annotator->setAnnotationWidth( width );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ParsedEntry &e : qAsConst(parsed) )
	{
		if ( root_offset == -1 )
			root_offset = e.indent;

		EBookTocEntry entry;
		entry.iconid = (EBookTocEntry::Icon) e.iconid;
		entry.indent = e.indent - root_offset;
		entry.name = e.name;

        if ( !e.urls.empty() )
            entry.url = e.urls[0];

		toc.append( entry );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( TileNode &tile : d->tiles )
    {
        TilesManager::Private::markDirty( tile );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const XpsPathFigure *figure : qAsConst(pathdata->paths)) {
        m_painter->setBrush(figure->isFilled ? brush : QBrush());
        m_painter->drawPath(figure->path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect & r : rgn )
    {
        p.fillRect( r, Okular::Settings::slidesBackgroundColor() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : rgn)
        viewport()->update(rect);
```

#### AUTO 


```{c}
const auto currentViewportIterator = std::list<DocumentViewport>::const_iterator(m_viewportIterator);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { sendGeneratorPixmapRequest(); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : videoWidgets )
        {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );

            if ( vw->isPlaying() && viewportRectAtZeroZero.intersected( vw->geometry() ).isEmpty() ) {
                vw->stop();
                vw->pageLeft();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields))
    {
        if (f->type() == oldField->type() && qFuzzyCompare(f->rect().left, oldField->rect().left) && qFuzzyCompare(f->rect().top, oldField->rect().top) && qFuzzyCompare(f->rect().right, oldField->rect().right) && qFuzzyCompare(f->rect().bottom, oldField->rect().bottom))
        {
            return f;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const Okular::Action *action, Okular::FormFieldText *fft, bool &ok ) {
                          document->processValidateAction( action, fft, ok );
                          }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &backRect : remainingArea) {
        p->fillRect(backRect, backColor);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLinkedList<QPointF> &popplerInkPath : popplerInkPaths) {
        QLinkedList<Okular::NormalizedPoint> okularInkPath;
        for (const QPointF &popplerPoint : popplerInkPath) {
            okularInkPath << Okular::NormalizedPoint(popplerPoint.x(), popplerPoint.y());
        }
        okularInkPaths << okularInkPath;
    }
```

#### AUTO 


```{c}
const auto &item
```

#### RANGE FOR STATEMENT 


```{c}
for( QChar &formatChar : format )
        {  
            if( formatChar == 'M' )
                formatChar = 'm';
            else if( formatChar == 'm' )
                formatChar = 'M';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TabState &tab : qAsConst(m_tabs)) {
        tab.part->reloadXML();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &value : fieldChoicesWithExportValues) {
        values.insert(value.first, value.second);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TextDocumentGeneratorPrivate::AnnotationInfo &info : annotationInfos) {
        annots[info.page].append(info.annotation);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &characterBitmap : characterBitmaps) {
        characterBitmap = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFields) {
        ff->type();

        switch (ff->type()) {
        case Okular::FormField::FormButton: {
            Okular::FormFieldButton *ffb = static_cast<Okular::FormFieldButton *>(ff);
            switch (ffb->buttonType()) {
            case Okular::FormFieldButton::Push:
                break;
            case Okular::FormFieldButton::CheckBox:
                m_checkBoxForms.append(ffb);
                break;
            case Okular::FormFieldButton::Radio:
                m_radioButtonForms.append(ffb);
                break;
            default:;
            }
            break;
        }
        case Okular::FormField::FormText: {
            Okular::FormFieldText *fft = static_cast<Okular::FormFieldText *>(ff);
            switch (fft->textType()) {
            case Okular::FormFieldText::Multiline:
                m_textAreaForm = fft;
                break;
            case Okular::FormFieldText::Normal:
                m_textLineForm = fft;
                break;
            case Okular::FormFieldText::FileSelect:
                m_fileEditForm = fft;
                break;
            }
            break;
        }
        case Okular::FormField::FormChoice: {
            Okular::FormFieldChoice *ffc = static_cast<Okular::FormFieldChoice *>(ff);
            switch (ffc->choiceType()) {
            case Okular::FormFieldChoice::ListBox:
                if (ffc->multiSelect()) {
                    m_listMultiEdit = ffc;
                } else {
                    m_listSingleEdit = ffc;
                }
                break;
            case Okular::FormFieldChoice::ComboBox:
                m_comboEdit = ffc;
                break;
            }
            break;
        }
        default:;
        }
    }
```

#### AUTO 


```{c}
auto a = newPagesVector[m_pageNumber]->annotation(m_annotation->uniqueName());
```

#### RANGE FOR STATEMENT 


```{c}
for ( TOCItem* item : qAsConst(d->currentPage) )
    {
        QModelIndex index = d->indexForItem( item );
        if ( !index.isValid() )
            continue;

        item->highlight = false;
        emit dataChanged( index, index );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *w : formWidgetsList)
                    w->setCanBeFilled(allowfillforms);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::TextBox *word : text) {
        const int qstringCharCount = word->text().length();
        next = word->nextWord();
        int textBoxChar = 0;
        for (int j = 0; j < qstringCharCount; j++) {
            const QChar c = word->text().at(j);
            if (c.isHighSurrogate()) {
                s = c;
                addChar = false;
            } else if (c.isLowSurrogate()) {
                s += c;
                addChar = true;
            } else {
                s = c;
                addChar = true;
            }

            if (addChar) {
                QRectF charBBox = word->charBoundingBox(textBoxChar);
                append(ktp, (j == qstringCharCount - 1 && !next) ? (s + QLatin1Char('\n')) : s, charBBox.left() / width, charBBox.bottom() / height, charBBox.right() / width, charBBox.top() / height);
                textBoxChar++;
            }
        }

        if (word->hasSpaceAfter() && next) {
            // TODO Check with a document with vertical text
            // probably won't work and we will need to do comparisons
            // between wordBBox and nextWordBBox to see if they are
            // vertically or horizontally aligned
            QRectF wordBBox = word->boundingBox();
            QRectF nextWordBBox = next->boundingBox();
            append(ktp, QStringLiteral(" "), wordBBox.right() / width, wordBBox.bottom() / height, nextWordBBox.left() / width, wordBBox.top() / height);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : wList) {
        Shell *s = qobject_cast<Shell *>(widget);
        if (s && s != ignore) {
            return s;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annot : annots) {
                if (annot == ref) {
                    found = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RegionText &tmpRegion : qAsConst(tree)) {
        tmp += tmpRegion.text();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : qAsConst(m_videoWidgets)) {
        const Okular::NormalizedRect r = vw->normGeometry();
        vw->resize(qRound(fabs(r.right - r.left) * m_uncroppedGeometry.width()), qRound(fabs(r.bottom - r.top) * m_uncroppedGeometry.height()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &md : available) {
            result << md.mimeTypes();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::FormFieldSignature *s : allSignatures) {
            bool createSignature = true;
            const QString fullyQualifiedName = s->fullyQualifiedName();
            auto compareSignatureByFullyQualifiedName = [&fullyQualifiedName](const Okular::FormField *off) { return off->fullyQualifiedName() == fullyQualifiedName; };

            // See if the signature is in one of the already loaded page (i.e. 1 to end)
            for (Okular::Page *p : qAsConst(pagesVector)) {
                const QLinkedList<Okular::FormField *> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end()) {
                    delete s;
                    createSignature = false;
                    continue;
                }
            }
            // See if the signature is in page 0
            if (std::find_if(page0FormFields.constBegin(), page0FormFields.constEnd(), compareSignatureByFullyQualifiedName) != page0FormFields.constEnd()) {
                delete s;
                createSignature = false;
            }
            // Otherwise it's a page-less signature, add it to page 0
            if (createSignature) {
                Okular::FormField *of = new PopplerFormFieldSignature(std::unique_ptr<Poppler::FormFieldSignature>(s));
                page0FormFields.append(of);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const WordWithCharacters &wwc : list )
        {
            TinyTextEntity *ent = wwc.word;
            const QRect entRect = ent->area.geometry(pageWidth, pageHeight);

            // calculate vertical projection profile proj_on_xaxis1
            for(int k = entRect.left() ; k <= entRect.left() + entRect.width() ; ++k)
            {
                if( ( k-regionRect.left() ) < size_proj_x && ( k-regionRect.left() ) >= 0 )
                    proj_on_xaxis[k - regionRect.left()] += entRect.height();
            }

            // calculate horizontal projection profile in the same way
            for(int k = entRect.top() ; k <= entRect.top() + entRect.height() ; ++k)
            {
                if( ( k-regionRect.top() ) < size_proj_y && ( k-regionRect.top() ) >= 0 )
                    proj_on_yaxis[k - regionRect.top()] += entRect.width();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QChar &iChar : query )
	{
		const QChar ch = iChar.toLower();
		
		// a quote either begins or ends the phrase
		if ( ch == '"' )
		{
			keeper.addTerm( term );
			
			if ( keeper.isInPhrase() )
				keeper.endPhrase();
			else
				keeper.beginPhrase();

			continue;
		}
		
		// If new char does not stop the word, add ot and continue
		if ( ch.isLetterOrNumber() || partOfWordChars.indexOf( ch ) != -1 )
		{
			term.append( ch );
			continue;
		}
		
		// If it is a split char, add this term and split char as separate term
		if ( splitChars.indexOf( ch ) != -1 )
		{
			// Add existing term if present
			keeper.addTerm( term );
			
			// Change the term variable, so it will be added when we exit this block
			term = ch;
		}

		// Just add the word; it is most likely a space or terminated by tokenizer.
		keeper.addTerm( term );
		term = QString();			
	}
```

#### LAMBDA EXPRESSION 


```{c}
[&stampIconName](const QPair<QString, QString> &element) { return element.second == stampIconName; }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Shell* shell : qAsConst(shells) )
    {
        QVERIFY( QTest::qWaitForWindowExposed( shell ) );
        numDocs += shell->m_tabs.size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QString( "(.*),\\s*(%1=.*)" ).arg( attribute ), QRegularExpression::DotMatchesEverythingOption );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                QStringList results = text;
                const int index = results.indexOf( t );
                results.removeAt( index );
                results.insert( index, match.captured( 2 ) );
                results.insert( index, match.captured( 1 ) );
                return splitDNAttributes( results );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : qAsConst(listFiles)) {
        // Extract all the files to mTempDir regardless of their path inside the archive
        // This will break if ever an arvhice with two files with the same name in different subfolders
        QFileInfo fi(f);
        if (QFile::exists(mTempDir->path() + QLatin1Char('/') + subDir + fi.fileName())) {
            newList.append(subDir + fi.fileName());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<WordsWithCharacters, QRect> &sortedLine : qAsConst(sortedLines))
        {
            tmpList += sortedLine.first;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( const FormFieldButton *formButton : formButtons )
    {
        left = qMin<double>( left, formButton->rect().left );
        top = qMin<double>( top, formButton->rect().top );
        right = qMax<double>( right, formButton->rect().right );
        bottom = qMax<double>( bottom, formButton->rect().bottom );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( KMainWindow* kmw : mainWindows )
    {
        Shell* shell = qobject_cast<Shell*>( kmw );
        if( shell )
        {
            shells.append( shell );
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, searchStruct] { d->doContinueDirectionMatchSearch(searchStruct); }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(observersPixmapCleared)) {
        o->notifyContentsCleared(Okular::DocumentObserver::Pixmap);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Action *a : nextActions) {
            processAction(a);
        }
```

#### AUTO 


```{c}
auto limit_value = nSteps ? 200 : verticalScrollBar()->rect().height();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * item : qAsConst( d->items ) )
    {
        // check if a piece of the page intersects the contents rect
        if ( !item->isVisible() || !item->croppedGeometry().intersects( checkRect ) )
            continue;

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry(),
              outlineGeometry = itemGeometry;
        outlineGeometry.adjust( -1, -1, 3, 3 );

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate( itemGeometry.left(), itemGeometry.top() );

        // draw the page outline (black border and 2px bottom-right shadow)
        if ( !itemGeometry.contains( contentsRect ) )
        {
            int itemWidth = itemGeometry.width(),
                itemHeight = itemGeometry.height();
            // draw simple outline
            p->setPen( Qt::black );
            p->drawRect( -1, -1, itemWidth + 1, itemHeight + 1 );
            // draw bottom/right gradient
            static const int levels = 2;
            int r = backColor.red() / (levels + 2) + 6,
                g = backColor.green() / (levels + 2) + 6,
                b = backColor.blue() / (levels + 2) + 6;
            for ( int i = 0; i < levels; i++ )
            {
                p->setPen( QColor( r * (i+2), g * (i+2), b * (i+2) ) );
                p->drawLine( i, i + itemHeight + 1, i + itemWidth + 1, i + itemHeight + 1 );
                p->drawLine( i + itemWidth + 1, i, i + itemWidth + 1, i + itemHeight );
                p->setPen( backColor );
                p->drawLine( -1, i + itemHeight + 1, i - 1, i + itemHeight + 1 );
                p->drawLine( i + itemWidth + 1, -1, i + itemWidth + 1, i - 1 );
            }
        }

        // draw the page using the PagePainter with all flags active
        if ( contentsRect.intersects( itemGeometry ) )
        {
            Okular::NormalizedPoint *viewPortPoint = nullptr;
            Okular::NormalizedPoint point( d->lastSourceLocationViewportNormalizedX, d->lastSourceLocationViewportNormalizedY );
            if( Okular::Settings::showSourceLocationsGraphically()
                && item->pageNumber() ==  d->lastSourceLocationViewportPageNumber )
            {
                viewPortPoint = &point;
            }
            QRect pixmapRect = contentsRect.intersected( itemGeometry );
            pixmapRect.translate( -item->croppedGeometry().topLeft() );
            PagePainter::paintCroppedPageOnPainter( p, item->page(), this, pageflags,
                item->uncroppedWidth(), item->uncroppedHeight(), pixmapRect,
                item->crop(), viewPortPoint );
        }

        // remove painted area from 'remainingArea' and restore painter
        remainingArea -= outlineGeometry.intersected( contentsRect );
        p->restore();
    }
```

#### AUTO 


```{c}
auto childItem3 = new SignatureItem(parentItem, nullptr, SignatureItem::Reason, currentPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
        int cWidth = colWidth[cIdx], rHeight = rowHeight[rIdx];
        if (continuousView || rIdx == pageRowIdx) {
            const bool reallyDoCenterFirst = item->pageNumber() == 0 && centerFirstPage;
            const bool reallyDoCenterLast = item->pageNumber() == pageCount - 1 && centerLastPage;
            int actualX = 0;
            if (reallyDoCenterFirst || reallyDoCenterLast) {
                // page is centered across entire viewport
                actualX = (fullWidth - item->croppedWidth()) / 2;
            } else if (facingPages) {
                if (Okular::Settings::rtlReadingDirection()) {
                    // RTL reading mode
                    actualX = ((centerFirstPage && item->pageNumber() % 2 == 0) || (!centerFirstPage && item->pageNumber() % 2 == 1)) ? (fullWidth / 2) - item->croppedWidth() - 1 : (fullWidth / 2) + 1;
                } else {
                    // page edges 'touch' the center of the viewport
                    actualX = ((centerFirstPage && item->pageNumber() % 2 == 1) || (!centerFirstPage && item->pageNumber() % 2 == 0)) ? (fullWidth / 2) - item->croppedWidth() - 1 : (fullWidth / 2) + 1;
                }
            } else {
                // page is centered within its virtual column
                // actualX = insertX + (cWidth - item->croppedWidth()) / 2;
                if (Okular::Settings::rtlReadingDirection()) {
                    actualX = fullWidth - insertX - cWidth + ((cWidth - item->croppedWidth()) / 2);
                } else {
                    actualX = insertX + (cWidth - item->croppedWidth()) / 2;
                }
            }
            item->moveTo(actualX, (continuousView ? insertY : origInsertY) + (rHeight - item->croppedHeight()) / 2);
            item->setVisible(true);
        } else {
            item->moveTo(0, 0);
            item->setVisible(false);
        }
        item->setFormWidgetsVisible(d->m_formsVisible);
        // advance col/row index
        insertX += cWidth;
        if (++cIdx == nCols) {
            cIdx = 0;
            rIdx++;
            insertX = 0;
            insertY += rHeight;
        }
#ifdef PAGEVIEW_DEBUG
        kWarning() << "updating size for pageno" << item->pageNumber() << "cropped" << item->croppedGeometry() << "uncropped" << item->uncroppedGeometry();
#endif
    }
```

#### AUTO 


```{c}
auto it = std::find_if( StampAnnotationWidget::defaultStamps.begin(),
                            StampAnnotationWidget::defaultStamps.end(),
                            [&stampIconName] (const QPair<QString, QString>& element) {
                                return element.second == stampIconName;
                            }
                          );
```

#### AUTO 


```{c}
const auto& ann
```

#### LAMBDA EXPRESSION 


```{c}
[this, link]() { d->document->processAction(link); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TabState &tab : qAsConst(m_tabs)) {
            tab.part->closeUrl(false);
        }
```

#### AUTO 


```{c}
auto hideBtn = m_fields[QStringLiteral( "HideActionButton" )];
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
        if (annotation->subType() == Okular::Annotation::AWidget)
            continue;

        result.append(annotation);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, colorType, color]() { slotSetColor(colorType, color); }
```

#### AUTO 


```{c}
auto it = std::find_if( toolbuttonList.begin(),
                          toolbuttonList.end(),
                          [](const QToolButton * x)  { return x->toolTip().contains("Typewriter"); } );
```

#### AUTO 


```{c}
auto detailsPageLayout = new QVBoxLayout( detailsFrame );
```

#### AUTO 


```{c}
auto validityBox = new QGroupBox(i18n("Validity"), generalPage);
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction *action : qAsConst(m_actions) )
        {
            button->menu()->addAction( action );
            if ( action->isChecked() )
                button->setDefaultAction( action );
        }
```

#### AUTO 


```{c}
auto payload = vPayload.value<RenderImagePayload *>();
```

#### AUTO 


```{c}
auto sha256Label = new QLabel(QString(QCryptographicHash::hash(certData, QCryptographicHash::Sha256).toHex(' ')));
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->itemsToOpen)) {
            const QModelIndex index = d->indexForItem(item);
            if (!index.isValid())
                continue;

            // TODO misusing parent() here, fix
            QMetaObject::invokeMethod(QObject::parent(), "expand", Qt::QueuedConnection, Q_ARG(QModelIndex, index));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem *pageItem : qAsConst(d->items) )
    {
        if ( pageItem->isVisible() )
        {
            currentPageItem = pageItem;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResizeHandle &handle : m_resizeHandleList) {
            const QRect rect = getHandleRect(handle, ad);
            if (rect.contains(eventPos)) {
                selected |= handle;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const ResizeHandle &handle : qAsConst(m_resizeHandleList) )
        {
            QRect rect = getHandleRect( handle, m_focusedAnnotation );
            painter->drawRect( rect );
        }
```

#### AUTO 


```{c}
const auto &colorNameValue
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageSet) {
        PresentationFrame *frame = new PresentationFrame();
        frame->page = page;
        const QList<Okular::Annotation *> annotations = page->annotations();
        for (Okular::Annotation *a : annotations) {
            if (a->subType() == Okular::Annotation::AMovie) {
                Okular::MovieAnnotation *movieAnn = static_cast<Okular::MovieAnnotation *>(a);
                VideoWidget *vw = new VideoWidget(movieAnn, movieAnn->movie(), m_document, this);
                frame->videoWidgets.insert(movieAnn->movie(), vw);
                vw->pageInitialized();
            } else if (a->subType() == Okular::Annotation::ARichMedia) {
                Okular::RichMediaAnnotation *richMediaAnn = static_cast<Okular::RichMediaAnnotation *>(a);
                if (richMediaAnn->movie()) {
                    VideoWidget *vw = new VideoWidget(richMediaAnn, richMediaAnn->movie(), m_document, this);
                    frame->videoWidgets.insert(richMediaAnn->movie(), vw);
                    vw->pageInitialized();
                }
            } else if (a->subType() == Okular::Annotation::AScreen) {
                const Okular::ScreenAnnotation *screenAnn = static_cast<Okular::ScreenAnnotation *>(a);
                Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation(screenAnn);
                if (movie) {
                    VideoWidget *vw = new VideoWidget(screenAnn, movie, m_document, this);
                    frame->videoWidgets.insert(movie, vw);
                    vw->pageInitialized();
                }
            }
        }
        frame->recalcGeometry(m_width, m_height, screenRatio);
        // add the frame to the vector
        m_frames.push_back(frame);
    }
```

#### AUTO 


```{c}
auto request = new Okular::PixmapRequest(observer, m_viewPort.pageNumber, width() * dpr, height() * dpr, priority, Okular::PixmapRequest::Asynchronous);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FormFieldButton *formButton : qAsConst(m_formButtons)) {
        m_prevButtonStates.append(formButton->state());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *tmpItem : qAsConst(d->items))
        if (tmpItem->pageNumber() == vp.pageNumber) {
            item = tmpItem;
            break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Hyperlink &dviLink : qAsConst(pageInfo->hyperLinkList)) {
        QRect boxArea = dviLink.box;
        double nl = (double)boxArea.left() / pageWidth, nt = (double)boxArea.top() / pageHeight, nr = (double)boxArea.right() / pageWidth, nb = (double)boxArea.bottom() / pageHeight;

        QString linkText = dviLink.linkText;
        if (linkText.startsWith(QLatin1String("#")))
            linkText = linkText.mid(1);
        Anchor anch = m_dviRenderer->findAnchor(linkText);

        Okular::Action *okuLink = nullptr;

        /* distinguish between local (-> anchor) and remote links */
        if (anch.isValid()) {
            /* internal link */
            Okular::DocumentViewport vp;
            fillViewportFromAnchor(vp, anch, pageWidth, pageHeight);

            okuLink = new Okular::GotoAction(QLatin1String(""), vp);
        } else {
            okuLink = new Okular::BrowseAction(QUrl::fromUserInput(dviLink.linkText));
        }
        if (okuLink) {
            Okular::ObjectRect *orlink = new Okular::ObjectRect(nl, nt, nr, nb, false, Okular::ObjectRect::Action, okuLink);
            dviLinks.push_front(orlink);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QVariant &arg : args )
    {
        if ( arg.type() == QVariant::String )
        {
            QString argString = arg.toString();
            int separatorIndex = argString.indexOf( QStringLiteral("=") );
            if ( separatorIndex >= 0 && argString.left( separatorIndex ) == QLatin1String( "ConfigFileName" ) )
            {
                return argString.mid( separatorIndex + 1 );
            }
        }
    }
```

#### AUTO 


```{c}
auto hideBtn = m_fields[QStringLiteral("HideScriptButton")];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMimeType &mimeType : uniqueMimetypes) {
            result.append(mimeType.name());
        }
```

#### AUTO 


```{c}
auto childItem3 = new SignatureItem( parentItem, nullptr, SignatureItem::Reason, currentPage );
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
        QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
        selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );
        // should check whether this is on-screen here?
        updatedRect = updatedRect.united(selectionPartRect);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers)) {
        if (o != excludeObserver) {
            o->notifyVisibleRectsChanged();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *twi : selected) {
        Okular::EmbeddedFile *ef = qvariant_cast<Okular::EmbeddedFile *>(twi->data(0, EmbeddedFileRole));
        saveFile(ef);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KConfigGroup &group, const QByteArrayList &names) {
        if (group.name() == QLatin1String("KDE") && names.contains(QByteArrayLiteral("AnimationDurationFactor"))) {
            PageView::updateSmoothScrollAnimationSpeed();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (HighlightAreaRect *highlight : m_highlights) {
        if (highlight->s_id == s_id) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &arg : args) {
        if (arg.type() == QVariant::String) {
            if (arg.toString() == QLatin1String("Print/Preview")) {
                return Okular::PrintPreviewMode;
            } else if (arg.toString() == QLatin1String("ViewerWidget")) {
                return Okular::ViewerWidgetMode;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]( Okular::FormField * form )
            {
                Okular::FormFieldText *fft = reinterpret_cast< Okular::FormFieldText * >( form );
                if( fft )
                    m_formattedText = fft->text();
            }
```

#### AUTO 


```{c}
auto fingerprintBox = new QGroupBox( i18n("Fingerprints"), generalPage );
```

#### LAMBDA EXPRESSION 


```{c}
[this](Phonon::State s) { stateChanged( s ); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : wList) {
        Shell *s = qobject_cast<Shell *>(widget);
        if (s && s != ignore)
            return s;
    }
```

#### AUTO 


```{c}
auto anchorIt = documentAnchors.constFind(linkIt.key());
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "follow this link" action
        QAction *processLinkAction = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("ProcessLinkAction")));
        QVERIFY(processLinkAction);

        // check if the menu contains "copy link address" action
        QAction *copyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("CopyLinkLocationAction")));
        QVERIFY(copyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &docscript : docScripts) {
            d->m_scripter->execute(JavaScript, docscript);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Shell *shell : qAsConst(shells) )
    {
        QVERIFY( QTest::qWaitForWindowExposed( shell ) );
        numDocs += shell->m_tabs.size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLinkedList<QPointF> &popplerInkPath : popplerInkPaths) {
        QList<Okular::NormalizedPoint> okularInkPath;
        for (const QPointF &popplerPoint : popplerInkPath) {
            okularInkPath << Okular::NormalizedPoint(popplerPoint.x(), popplerPoint.y());
        }
        okularInkPaths << okularInkPath;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation *annotation : annotations )
        {
            if ( !annotation ) continue;

            annotation->setCreationDate( QDateTime::currentDateTime() );
            annotation->setModificationDate( QDateTime::currentDateTime() );
            annotation->setAuthor( Okular::Settings::identityAuthor() );
            m_document->addPageAnnotation( m_lockedItem->pageNumber(), annotation );
            
            if ( annotation->openDialogAfterCreation() )
                m_pageView->openAnnotationWindow( annotation, m_lockedItem->pageNumber() );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString & groupAddress, const QString & caller) {
        d->_o_changed(groupAddress, caller);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *executingRequest : qAsConst( d->m_executingPixmapRequests ) )
        {
            bool newRequestsContainExecutingRequestPage = false;
            bool requestCancelled = false;
            for ( PixmapRequest *newRequest : requests )
            {
                if ( newRequest->pageNumber() == executingRequest->pageNumber() && requesterObserver == executingRequest->observer())
                {
                    newRequestsContainExecutingRequestPage = true;
                }

                if ( shouldCancelRenderingBecauseOf( *executingRequest, *newRequest ) )
                {
                    requestCancelled = d->cancelRenderingBecauseOf( executingRequest, newRequest );
                }
            }

            // If we were told to remove all the previous requests and the executing request page is not part of the new requests, cancel it
            if ( !requestCancelled && removeAllPrevious && requesterObserver == executingRequest->observer() && !newRequestsContainExecutingRequestPage )
            {
                requestCancelled = d->cancelRenderingBecauseOf( executingRequest, nullptr );
            }

            if ( requestCancelled )
            {
                observersPixmapCleared << executingRequest->observer();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( int p : noMoreSelectedPages )
        {
            d->document->setPageTextSelection( p, nullptr, QColor() );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &popplerPoint : popplerInkPath) {
            okularInkPath << Okular::NormalizedPoint(popplerPoint.x(), popplerPoint.y());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *ann : page->m_annotations) {
                int flags = ann->flags();

                if (flags & Okular::Annotation::Hidden) {
                    continue;
                }

                if (flags & Okular::Annotation::ExternallyDrawn) {
                    // ExternallyDrawn annots are never rendered by PagePainter.
                    // Just paint the boundingRect if the annot is moved or resized.
                    if (flags & (Okular::Annotation::BeingMoved | Okular::Annotation::BeingResized)) {
                        boundingRectOnlyAnn = ann;
                    }
                    continue;
                }

                bool intersects = ann->transformedBoundingRectangle().intersects(nXMin, nYMin, nXMax, nYMax);
                if (ann->subType() == Okular::Annotation::AText) {
                    Okular::TextAnnotation *ta = static_cast<Okular::TextAnnotation *>(ann);
                    if (ta->textType() == Okular::TextAnnotation::Linked) {
                        Okular::NormalizedRect iconrect(ann->transformedBoundingRectangle().left,
                                                        ann->transformedBoundingRectangle().top,
                                                        ann->transformedBoundingRectangle().left + TEXTANNOTATION_ICONSIZE / page->width(),
                                                        ann->transformedBoundingRectangle().top + TEXTANNOTATION_ICONSIZE / page->height());
                        intersects = iconrect.intersects(nXMin, nYMin, nXMax, nYMax);
                    }
                }
                if (intersects) {
                    Okular::Annotation::SubType type = ann->subType();
                    if (type == Okular::Annotation::ALine || type == Okular::Annotation::AHighlight || type == Okular::Annotation::AInk /*|| (type == Annotation::AGeom && ann->style().opacity() < 0.99)*/) {
                        if (!bufferedAnnotations) {
                            bufferedAnnotations = new QList<Okular::Annotation *>();
                        }
                        bufferedAnnotations->append(ann);
                    } else {
                        if (!unbufferedAnnotations) {
                            unbufferedAnnotations = new QList<Okular::Annotation *>();
                        }
                        unbufferedAnnotations->append(ann);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TileNode &tile : qAsConst( d->tiles ) )
    {
        if ( !d->hasPixmap( rotatedRect, tile ) )
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int p : qAsConst(affectedItemsSet)) {
            if (p < tmpmin)
                tmpmin = p;
            if (p > tmpmax)
                tmpmax = p;
        }
```

#### AUTO 


```{c}
auto mime = db.mimeTypeForFileNameAndData( fileName, fileData );
```

#### AUTO 


```{c}
auto cbMakeRO = dynamic_cast< Okular::FormFieldButton* > ( fields[QStringLiteral( "CBMakeRO" )] );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &i: { i18n( " Square" ), i18n( " Circle" ), i18n( " Diamond" ), i18n( " Open Arrow" ), i18n( " Closed Arrow" ),
                    i18n( " None" ), i18n( " Butt" ), i18n( " Right Open Arrow" ), i18n( " Right Closed Arrow" ), i18n( "Slash" ) } )
    {
        m_startStyleCombo->addItem(i);
        m_endStyleCombo->addItem(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pagesToNotifySet, pageMatches, currentPage, searchID] { doContinueAllDocumentSearch(pagesToNotifySet, pageMatches, currentPage + 1, searchID); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : qAsConst(m_fileformats)) {
            QMimeType mimeType = mimeDatabase.mimeTypeForName(mimeName);
            mimetypes << mimeType.name();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (AnnItem *child : qAsConst(item->children)) {
        updateAnnotationPointer(child, pages);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Annotation *annotation : annotationsList) {
            Okular::Action *action = nullptr;

            if (annotation->subType() == Okular::Annotation::AScreen) {
                action = static_cast<const Okular::ScreenAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageClosing);
            } else if (annotation->subType() == Okular::Annotation::AWidget) {
                action = static_cast<const Okular::WidgetAnnotation *>(annotation)->additionalAction(Okular::Annotation::PageClosing);
            }

            if (action) {
                m_document->processAction(action);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cert : certs) {
        vReturnCerts.append(new PopplerCertificateInfo(cert));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormField *ff : part.m_document->page( 0 )->formFields() )
    {
        if ( ff->id() == 65537 )
        {
            QCOMPARE( ff->type(), FormField::FormText );
            FormFieldText *fft = static_cast<FormFieldText *>( ff );
            part.m_document->editFormText( 0, fft, "BlaBla", 6, 0, 0 );
        }
        else if ( ff->id() == 65538 )
        {
            QCOMPARE( ff->type(), FormField::FormButton );
            FormFieldButton *ffb = static_cast<FormFieldButton *>( ff );
            QCOMPARE( ffb->buttonType(), FormFieldButton::Radio );
            part.m_document->editFormButtons( 0, QList< FormFieldButton* >() << ffb, QList< bool >() << true );
        }
        else if ( ff->id() == 65542 )
        {
            QCOMPARE( ff->type(), FormField::FormChoice );
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>( ff );
            QCOMPARE( ffc->choiceType(), FormFieldChoice::ListBox );
            part.m_document->editFormList( 0, ffc, QList< int >() << 1 );
        }
        else if ( ff->id() == 65543 )
        {
            QCOMPARE( ff->type(), FormField::FormChoice );
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>( ff );
            QCOMPARE( ffc->choiceType(), FormFieldChoice::ComboBox );
            part.m_document->editFormCombo( 0, ffc, "combo2", 3, 0, 0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAbstractButton* button : buttons )
    {
        checked.append( button->isChecked() );
        Okular::FormFieldButton *formButton = static_cast<Okular::FormFieldButton *>( dynamic_cast<FormWidgetIface*>(button)->formField() );
        formButtons.append( formButton );
        prevChecked.append( formButton->state() );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::Annotation *annotation : annotationsList )
        {
            Okular::Action *action = nullptr;

            if ( annotation->subType() == Okular::Annotation::AScreen )
                action = static_cast<const Okular::ScreenAnnotation*>( annotation )->additionalAction( Okular::Annotation::PageClosing );
            else if ( annotation->subType() == Okular::Annotation::AWidget )
                action = static_cast<const Okular::WidgetAnnotation*>( annotation )->additionalAction( Okular::Annotation::PageClosing );

            if ( action )
                m_document->processAction( action );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : words) {
        miniDict.insert(word, new PosEntry(0));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const KToolBar *toolBar) { return toolBar->objectName() == toolBarName; }
```

#### RANGE FOR STATEMENT 


```{c}
for (TileNode &tile : d->tiles) {
        d->tilesAt(rotatedRect, tile, result, tileLeaf);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *videoWidget : videoWidgetsList )
                videoWidget->pageEntered();
```

#### AUTO 


```{c}
auto itToolBar = std::find_if( toolbars.begin(), toolbars.end(), [] (const KToolBar * toolBar) {
        return toolBar->objectName() == QStringLiteral("annotationToolBar");
    } );
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *viewModeAction : viewModeActions) {
        if (viewModeAction->data().toInt() == Okular::Settings::viewMode()) {
            viewModeAction->setChecked(true);
            break;
        }
    }
```

#### AUTO 


```{c}
const auto& stamp
```

#### AUTO 


```{c}
const auto &cert
```

#### AUTO 


```{c}
auto cbMakeRW = dynamic_cast< Okular::FormFieldButton* > ( fields[QStringLiteral( "CBMakeRW" )] );
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        if ( m_sidebar->currentItem() != m_signaturePanel) {
            m_sidebar->setCurrentItem( m_signaturePanel );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ParsedEntry &e : parsedList) {
        if (e.urls.empty())
            continue;

        root_offset = qMin(root_offset, e.indent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const HighlightAnnotation::Quad &quad : m_highlightQuads )
    {
        QLinkedList<NormalizedPoint> pathPoints;

        //first, we check if the point is within the area described by the 4 quads
        //this is the case, if the point is always on one side of each segments delimiting the polygon:
        pathPoints << quad.transformedPoint( 0 );
        int directionVote = 0;
        for ( int i = 1; i < 5; ++i )
        {
            NormalizedPoint thisPoint = quad.transformedPoint( i % 4 );
            directionVote += (isLeftOfVector( pathPoints.back(), thisPoint, point )) ? 1 : -1;
            pathPoints << thisPoint;
        }
        if ( abs( directionVote ) == 4 )
            return 0;

        //if that's not the case, we treat the outline as path and simply determine
        //the distance from the path to the point
        const double thisOutsideDistance = ::distanceSqr( x, y, xScale, yScale, pathPoints );
        if ( thisOutsideDistance < outsideDistance )
            outsideDistance = thisOutsideDistance;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : rgn) {
        summedArea += r.width() * r.height();
    }
```

#### AUTO 


```{c}
auto *sessionInterface = QDBusConnection::sessionBus().interface();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeName : result) {
            uniqueMimetypes.insert(mimeDatabase.mimeTypeForName(mimeName));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] ( bool checked ) {
        d->slotToolBarVisibilityChanged( checked );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PixmapRequest *request : requests) {
        // add request to the 'stack' at the right place
        if (!request->priority()) {
            // add priority zero requests to the top of the stack
            d->m_pixmapRequestsStack.push_back(request);
        } else {
            // insert in stack sorted by priority
            sIt = d->m_pixmapRequestsStack.begin();
            sEnd = d->m_pixmapRequestsStack.end();
            while (sIt != sEnd && (*sIt)->priority() > request->priority()) {
                ++sIt;
            }
            d->m_pixmapRequestsStack.insert(sIt, request);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const KBookmark &bm : bmlist )
    {
//        qCDebug(OkularUiDebug).nospace() << "checking '" << tmp << "'";
//        qCDebug(OkularUiDebug).nospace() << "      vs '" << baseurl << "'";
        // TODO check that bm and baseurl are the same (#ref excluded)
        QTreeWidgetItem * item = new BookmarkItem( bm );
        ret.append( item );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : listWithWordsAndSpaces)
    {
        delete word.word;
        listOfCharacters.append(word.characters);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageSet) {
        PageViewItem *item = new PageViewItem(page);
        d->items.push_back(item);
#ifdef PAGEVIEW_DEBUG
        qCDebug(OkularUiDebug).nospace() << "cropped geom for " << d->items.last()->pageNumber() << " is " << d->items.last()->croppedGeometry();
#endif
        const QLinkedList<Okular::FormField *> pageFields = page->formFields();
        for (Okular::FormField *ff : pageFields) {
            FormWidgetIface *w = FormWidgetFactory::createWidget(ff, viewport());
            if (w) {
                w->setPageItem(item);
                w->setFormWidgetsController(d->formWidgetsController());
                w->setVisibility(false);
                w->setCanBeFilled(allowfillforms);
                item->formWidgets().insert(w);
                hasformwidgets = true;
            }
        }

        createAnnotationsVideoWidgets(item, page->annotations());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *fwi : qAsConst(m_formWidgets))
    {
        Okular::NormalizedRect r = fwi->rect();
        fwi->setWidthHeight(
            qRound( fabs( r.right - r.left ) * m_uncroppedGeometry.width() ),
            qRound( fabs( r.bottom - r.top ) * m_uncroppedGeometry.height() ) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<WordsWithCharacters, QRect> &linesI : lines) {
            /* the line area which will be expanded
               line_rects is only necessary to preserve the topmin and bottommax of all
               the texts in the line, left and right is not necessary at all
            */
            QRect &lineArea = linesI.second;
            const int text_y1 = elementArea.top(), text_y2 = elementArea.top() + elementArea.height(), text_x1 = elementArea.left(), text_x2 = elementArea.left() + elementArea.width();
            const int line_y1 = lineArea.top(), line_y2 = lineArea.top() + lineArea.height(), line_x1 = lineArea.left(), line_x2 = lineArea.left() + lineArea.width();

            /*
               if the new text and the line has y overlapping parts of more than 70%,
               the text will be added to this line
             */
            if (doesConsumeY(elementArea, lineArea, 70)) {
                WordsWithCharacters &line = linesI.first;
                line.append(*it);

                const int newLeft = line_x1 < text_x1 ? line_x1 : text_x1;
                const int newRight = line_x2 > text_x2 ? line_x2 : text_x2;
                const int newTop = line_y1 < text_y1 ? line_y1 : text_y1;
                const int newBottom = text_y2 > line_y2 ? text_y2 : line_y2;

                lineArea = QRect(newLeft, newTop, newRight - newLeft, newBottom - newTop);
                found = true;
            }

            if (found) {
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &iChar : query) {
        const QChar ch = iChar.toLower();

        // a quote either begins or ends the phrase
        if (ch == QLatin1Char('"')) {
            keeper.addTerm(term);

            if (keeper.isInPhrase()) {
                keeper.endPhrase();
            } else {
                keeper.beginPhrase();
            }

            continue;
        }

        // If new char does not stop the word, add ot and continue
        if (ch.isLetterOrNumber() || partOfWordChars.indexOf(ch) != -1) {
            term.append(ch);
            continue;
        }

        // If it is a split char, add this term and split char as separate term
        if (splitChars.indexOf(ch) != -1) {
            // Add existing term if present
            keeper.addTerm(term);

            // Change the term variable, so it will be added when we exit this block
            term = ch;
        }

        // Just add the word; it is most likely a space or terminated by tokenizer.
        keeper.addTerm(term);
        term = QString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &k, const QString &v, const QString &t) { addMetaData(k, v, t); }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "Follow this link" action
        QAction *processLink = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("ProcessLinkAction")));
        QVERIFY(processLink);

        // chek if the menu contains  "Copy Link Address" action
        QAction *actCopyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("CopyLinkLocationAction")));
        QVERIFY(actCopyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldSignature *sf : signatureFormFields) {
        const int pageNumber = sf->page()->number();

        if (sf->signatureType() == Okular::FormFieldSignature::UnsignedSignature) {
            auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, pageNumber);
            parentItem->displayString = i18n("Unsigned Signature %1", unsignedSignatureNumber);

            auto childItem = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, pageNumber);
            childItem->displayString = i18n("Field: %1 on page %2", sf->name(), pageNumber + 1);

            ++unsignedSignatureNumber;
        } else {
            const Okular::SignatureInfo &info = sf->signatureInfo();

            // based on whether or not signature form is a nullptr it is decided if clicking on an item should change the viewport.
            auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, pageNumber);
            parentItem->displayString = i18n("Rev. %1: Signed By %2", revNumber, info.signerName());

            auto childItem1 = new SignatureItem(parentItem, nullptr, SignatureItem::ValidityStatus, pageNumber);
            childItem1->displayString = SignatureGuiUtils::getReadableSignatureStatus(info.signatureStatus());

            auto childItem2 = new SignatureItem(parentItem, nullptr, SignatureItem::SigningTime, pageNumber);
            childItem2->displayString = i18n("Signing Time: %1", info.signingTime().toString(Qt::DefaultLocaleLongDate));

            const QString reason = info.reason();
            if (!reason.isEmpty()) {
                auto childItem3 = new SignatureItem(parentItem, nullptr, SignatureItem::Reason, pageNumber);
                childItem3->displayString = i18n("Reason: %1", reason);
            }

            auto childItem4 = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, pageNumber);
            childItem4->displayString = i18n("Field: %1 on page %2", sf->name(), pageNumber + 1);

            ++revNumber;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &file : entryList ) {
        const KArchiveEntry *e = dir->entry( file );
        if ( e->isDirectory() ) {
            imagesInArchive( prefix + file + QLatin1Char('/'), static_cast<const KArchiveDirectory*>( e ), entries );
        } else if ( e->isFile() ) {
            entries->append( prefix + file );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                // first, crop the cell to this part
                if (!tsp.rectInSelection.intersects(cell))
                    continue;
                Okular::NormalizedRect cellPart = tsp.rectInSelection & cell; // intersection

                // second, convert it from table coordinates to part coordinates
                cellPart.left -= tsp.rectInSelection.left;
                cellPart.left /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                cellPart.right -= tsp.rectInSelection.left;
                cellPart.right /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                cellPart.top -= tsp.rectInSelection.top;
                cellPart.top /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                cellPart.bottom -= tsp.rectInSelection.top;
                cellPart.bottom /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);

                // third, convert from part coordinates to item coordinates
                cellPart.left *= (tsp.rectInItem.right - tsp.rectInItem.left);
                cellPart.left += tsp.rectInItem.left;
                cellPart.right *= (tsp.rectInItem.right - tsp.rectInItem.left);
                cellPart.right += tsp.rectInItem.left;
                cellPart.top *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                cellPart.top += tsp.rectInItem.top;
                cellPart.bottom *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                cellPart.bottom += tsp.rectInItem.top;

                // now get the text
                Okular::RegularAreaRect rects;
                rects.append(cellPart);
                txt += tsp.item->page()->text(&rects, Okular::TextPage::CentralPixelTextAreaInclusionBehaviour);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TeXFontDefinition *font : fonts) {
            Okular::FontInfo of;
            QString name;
            int zoom = (int)(font->enlargement * 100 + 0.5);
#ifdef HAVE_FREETYPE
            if (font->getFullFontName().isEmpty()) {
                name = QStringLiteral("%1, %2%").arg(font->fontname).arg(zoom);
            } else {
                name = QStringLiteral("%1 (%2), %3%").arg(font->fontname, font->getFullFontName(), QString::number(zoom));
            }
#else
            name = QString("%1, %2%").arg(font->fontname).arg(zoom);
#endif
            of.setName(name);

            QString fontFileName;
            if (!(font->flags & TeXFontDefinition::FONT_VIRTUAL)) {
                if (font->font != nullptr)
                    fontFileName = font->font->errorMessage;
                else
                    fontFileName = i18n("Font file not found");

                if (fontFileName.isEmpty())
                    fontFileName = font->filename;
            }

            of.setFile(fontFileName);

            Okular::FontInfo::FontType ft;
            switch (font->getFontType()) {
            case TeXFontDefinition::TEX_PK:
                ft = Okular::FontInfo::TeXPK;
                break;
            case TeXFontDefinition::TEX_VIRTUAL:
                ft = Okular::FontInfo::TeXVirtual;
                break;
            case TeXFontDefinition::TEX_FONTMETRIC:
                ft = Okular::FontInfo::TeXFontMetric;
                break;
            case TeXFontDefinition::FREETYPE:
                ft = Okular::FontInfo::TeXFreeTypeHandled;
                break;
            }
            of.setType(ft);

            // DVI has not the concept of "font embedding"
            of.setEmbedType(Okular::FontInfo::NotEmbedded);
            of.setCanBeExtracted(false);

            list.append(of);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *ff : qAsConst(formfields)) {
                hashedforms[ff->id()] = ff;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( View *view : qAsConst(m_views) )
    {
        QDomElement viewEntry = doc.createElement( QStringLiteral("view") );
        viewEntry.setAttribute( QStringLiteral("name"), view->name() );
        viewsNode.appendChild( viewEntry );
        saveViewsInfo( view, viewEntry );
    }
```

#### AUTO 


```{c}
auto certTree = new QTreeView(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->items)) {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for (FormWidgetIface *fwi : formWidgetsList) {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for (VideoWidget *vw : videoWidgets) {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());

            if (vw->isPlaying() && viewportRectAtZeroZero.intersected(vw->geometry()).isEmpty()) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if (!i->isVisible()) {
            continue;
        }
#ifdef PAGEVIEW_DEBUG
        qWarning() << "checking page" << i->pageNumber();
        qWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects(i->croppedGeometry());
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected(i->croppedGeometry());
        if (intersectionRect.isEmpty()) {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back(i);
        Okular::VisiblePageRect *vItem = new Okular::VisiblePageRect(i->pageNumber(), Okular::NormalizedRect(intersectionRect.translated(-i->uncroppedGeometry().topLeft()), i->uncroppedWidth(), i->uncroppedHeight()));
        visibleRects.push_back(vItem);
#ifdef PAGEVIEW_DEBUG
        qWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight());
        qWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if (i->page()->hasTilesManager(this) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low) {
            double rectMargin = pixelsToExpand / (double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax(0.0, vItem->rect.left - rectMargin);
            expandedVisibleRect.top = qMax(0.0, vItem->rect.top - rectMargin);
            expandedVisibleRect.right = qMin(1.0, vItem->rect.right + rectMargin);
            expandedVisibleRect.bottom = qMin(1.0, vItem->rect.bottom + rectMargin);
        }

        // if the item has not the right pixmap, add a request for it
        if (!i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect)) {
#ifdef PAGEVIEW_DEBUG
            qWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest *p = new Okular::PixmapRequest(this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), devicePixelRatioF(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous);
            requestedPixmaps.push_back(p);

            if (i->page()->hasTilesManager(this)) {
                p->setNormalizedRect(expandedVisibleRect);
                p->setTile(true);
            } else {
                p->setNormalizedRect(vItem->rect);
            }
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if (isEvent) {
            const QRect &geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            const double distance = hypot((geometry.left() + geometry.right()) / 2.0 - (viewportCenterX - 4), (geometry.top() + geometry.bottom()) / 2.0 - viewportCenterY);
            if (distance >= minDistance && nearPageNumber != -1) {
                continue;
            }
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if (geometry.height() > 0 && geometry.width() > 0) {
                // Compute normalized coordinates w.r.t. cropped page
                focusedX = (viewportCenterX - (double)geometry.left()) / (double)geometry.width();
                focusedY = (viewportCenterY - (double)geometry.top()) / (double)geometry.height();
                // Convert to normalized coordinates w.r.t. full page (no-op if not cropped)
                focusedX = i->crop().left + focusedX * i->crop().width();
                focusedY = i->crop().top + focusedY * i->crop().height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        // check if a piece of the page intersects the contents rect
        if (!item->isVisible() || !item->croppedGeometry().intersects(contentsRect))
            continue;

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry();

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate(itemGeometry.left(), itemGeometry.top());

        // draw the page using the PagePainter with all flags active
        if (contentsRect.intersects(itemGeometry)) {
            Okular::NormalizedPoint *viewPortPoint = nullptr;
            Okular::NormalizedPoint point(d->lastSourceLocationViewportNormalizedX, d->lastSourceLocationViewportNormalizedY);
            if (Okular::Settings::showSourceLocationsGraphically() && item->pageNumber() == d->lastSourceLocationViewportPageNumber) {
                viewPortPoint = &point;
            }
            QRect pixmapRect = contentsRect.intersected(itemGeometry);
            pixmapRect.translate(-item->croppedGeometry().topLeft());
            PagePainter::paintCroppedPageOnPainter(p, item->page(), this, pageflags, item->uncroppedWidth(), item->uncroppedHeight(), pixmapRect, item->crop(), viewPortPoint);
        }

        // remove painted area from 'remainingArea' and restore painter
        remainingArea -= itemGeometry;
        p->restore();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormFieldButton *formButton : qAsConst(m_formButtons) )
    {
        formButton->setState( false );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &filePath) {
        // We cheat a bit here reusing the urlsDropped signal, but at the end the output is the same, we want to open some files
        // urlsDropped should have just had a different name
        Q_EMIT urlsDropped({QUrl::fromLocalFile(filePath)});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::Page *page : pageVector) {
            if (!page->label().isEmpty()) {
                MiniBar *miniBar = *m_miniBars.constBegin(); // We assume all the minibars have the same font, font size etc, so we just take one minibar for the purpose of calculating the displayed length of the page labels.
                if (miniBar->fontMetrics().horizontalAdvance(page->label()) > miniBar->fontMetrics().horizontalAdvance(pagesOrLabelString)) {
                    pagesOrLabelString = page->label();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines)
    {
        const WordsWithCharacters list = sortedLine.first;
        QList<QRect> line_space_rects;
        int maxSpace = 0, minSpace = pageWidth;

        // for every TinyTextEntity element in the line
        WordsWithCharacters::ConstIterator it = list.begin(), itEnd = list.end();
        QRect max_area1,max_area2;
        QString before_max, after_max;

        // for every line
        for( ; it != itEnd ; it++ )
        {
            const QRect area1 = (*it).area().roundedGeometry(pageWidth,pageHeight);
            if( it+1 == itEnd ) break;

            const QRect area2 = (*(it+1)).area().roundedGeometry(pageWidth,pageHeight);
            int space = area2.left() - area1.right();

            if(space > maxSpace)
            {
                max_area1 = area1;
                max_area2 = area2;
                maxSpace = space;
                before_max = (*it).text();
                after_max = (*(it+1)).text();
            }

            if(space < minSpace && space != 0) minSpace = space;

            //if we found a real space, whose length is not zero and also less than the pageWidth
            if(space != 0 && space != pageWidth)
            {
                // increase the count of the space amount
                if(hor_space_stat.contains(space)) hor_space_stat[space]++;
                else hor_space_stat[space] = 1;

                int left,right,top,bottom;

                left = area1.right();
                right = area2.left();

                top = area2.top() < area1.top() ? area2.top() : area1.top();
                bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                QRect rect(left,top,right-left,bottom-top);
                line_space_rects.append(rect);
            }
        }

        space_rects.append(line_space_rects);

        if(hor_space_stat.contains(maxSpace))
        {
            if(hor_space_stat[maxSpace] != 1)
                hor_space_stat[maxSpace]--;
            else hor_space_stat.remove(maxSpace);
        }

        if(maxSpace != 0)
        {
            if (col_space_stat.contains(maxSpace))
                col_space_stat[maxSpace]++;
            else col_space_stat[maxSpace] = 1;

            //store the max rect of each line
            const int left = max_area1.right();
                const int right = max_area2.left();
            const int top = (max_area1.top() > max_area2.top()) ? max_area2.top() :
                                                                  max_area1.top();
            const int bottom = (max_area1.bottom() < max_area2.bottom()) ? max_area2.bottom() :
                                                                           max_area1.bottom();

            const QRect rect(left,top,right-left,bottom-top);
            max_hor_space_rects.append(rect);
        }
        else max_hor_space_rects.append(QRect(0,0,0,0));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList) {
        action->setEnabled(true);
        m_topBar->addAction(action);
        addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFormFields) {
        fields.insert(ff->name(), static_cast<Okular::FormFieldText *>(ff));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int pageNumber : qAsConst(s->highlightedPages)) {
        d->m_pagesVector.at(pageNumber)->d->deleteHighlights( searchID );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::Link *nl : nextLinks) {
            nextActions << createLinkFromPopplerLink(nl, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &relEntry : qAsConst(relEntries) ) {
            if ( relEntry.compare( entryName, Qt::CaseInsensitive ) == 0 ) {
                return relDir->entry( relEntry );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (NormalizedPoint &np : m_inplaceCallout) {
        np.transform(matrix);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( MiniBar *miniBar : qAsConst(m_miniBars) )
        {
            miniBar->setEnabled( false );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : wList )
    {
        Shell *s = qobject_cast<Shell*>(widget);
        if (s && s != ignore)
            return s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TinyTextEntity *te : qAsConst(d->m_words))
        {
            if (b == AnyPixelTextAreaInclusionBehaviour)
            {
                if ( area->intersects( te->area ) )
                {
                    ret.append( new TextEntity( te->text(), new Okular::NormalizedRect( te->area) ) );
                }
            }
            else
            {
                const NormalizedPoint center = te->area.center();
                if ( area->contains( center.x, center.y ) )
                {
                    ret.append( new TextEntity( te->text(), new Okular::NormalizedRect( te->area) ) );
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const KBookmark &bm : bmarks )
    {
        DocumentViewport vp( bm.url().fragment(QUrl::FullyDecoded) );
        if ( vp.isValid() && vp.pageNumber == page )
        {
            ret.append(bm);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EBookTocEntry &e : qAsConst(topics)) {
        QDomElement item = m_docSyn.createElement(e.name);
        if (!e.url.isEmpty()) {
            QString url = e.url.toString();
            item.setAttribute(QStringLiteral("ViewportName"), url);
            if (!tmpPageList.contains(url)) { // add a page only once
                tmpPageList.insert(url, pageNum);
                pageNum++;
            }
        }
        item.setAttribute(QStringLiteral("Icon"), e.iconid);
        if (e.indent == 0) {
            m_docSyn.appendChild(item);
        } else {
            lastIndentElement[e.indent - 1].appendChild(item);
        }
        lastIndentElement[e.indent] = item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::TextBox *word : text)
    {
        const int qstringCharCount = word->text().length();
        next=word->nextWord();
        int textBoxChar = 0;
        for (int j = 0; j < qstringCharCount; j++)
        {
            const QChar c = word->text().at(j);
            if (c.isHighSurrogate())
            {
                s = c;
                addChar = false;
            }
            else if (c.isLowSurrogate())
            {
                s += c;
                addChar = true;
            }
            else
            {
                s = c;
                addChar = true;
            }

            if (addChar)
            {
                QRectF charBBox = word->charBoundingBox(textBoxChar);
                append(ktp, (j==qstringCharCount-1 && !next) ? (s + QLatin1Char('\n')) : s,
                    charBBox.left()/width,
                    charBBox.bottom()/height,
                    charBBox.right()/width,
                    charBBox.top()/height);
                textBoxChar++;
            }
        }

        if ( word->hasSpaceAfter() && next )
        {
            // TODO Check with a document with vertical text
            // probably won't work and we will need to do comparisons
            // between wordBBox and nextWordBBox to see if they are
            // vertically or horizontally aligned
            QRectF wordBBox = word->boundingBox();
            QRectF nextWordBBox = next->boundingBox();
            append(ktp, QStringLiteral(" "),
                     wordBBox.right()/width,
                     wordBBox.bottom()/height,
                     nextWordBBox.left()/width,
                     wordBBox.top()/height);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
        if (annotation->subType() == Okular::Annotation::AWidget) {
            continue;
        }

        result.append(annotation);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormWidgetIface *fwi : qAsConst(m_formWidgets))
    {
        fwi->setVisibility( fwi->formField()->isVisible() && FormWidgetsController::shouldFormWidgetBeShown(fwi->formField()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const TabState &tab : qAsConst( m_tabs ) )
        {
           tab.part->closeUrl( false );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Annotation *a : m_annotations) {
        if (a->uniqueName() == uniqueName)
            return a;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(bitmap *characterBitmap : characterBitmaps) {
    delete characterBitmap;
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldSignature *signature : signatureFormFields) {
            if (signature->signatureType() == Okular::FormFieldSignature::UnsignedSignature) {
                anySignatureUnsigned = true;
            } else {
                const Okular::SignatureInfo &info = signature->signatureInfo();
                if (info.signatureStatus() != Okular::SignatureInfo::SignatureValid) {
                    allSignaturesValid = false;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction *btn : qAsConst(m_actions) )
            {
                if ( action != btn ) {
                    btn->setChecked( false );
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::NormalizedPoint &p : annotPoints  )
            {
                points.append(normPointToPointF( p ));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        if (item->isVisible() && selectionRect.intersects(item->croppedGeometry()))
            affectedItemsSet.insert(item->pageNumber());
    }
```

#### AUTO 


```{c}
auto it =  std::find_if( m_tabs.begin(), m_tabs.end(),
                 [&url]( const TabState state ){
                     return state.part->url() == url;
                 });
```

#### AUTO 


```{c}
auto it = certs.begin();
```

#### AUTO 


```{c}
auto generalPageLayout = new QVBoxLayout( generalPage );
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::EmbeddedFile *ef : *document->embeddedFiles())
	{
		QTreeWidgetItem *twi = new QTreeWidgetItem();
		twi->setText(0, ef->name());
		QMimeDatabase db;
		QMimeType mime = db.mimeTypeForFile( ef->name(), QMimeDatabase::MatchExtension);
		if (mime.isValid())
		{
			twi->setIcon(0, QIcon::fromTheme(mime.iconName()));
		}
		twi->setText(1, ef->description());
		twi->setText(2, ef->size() <= 0 ? i18nc("Not available size", "N/A") : KFormat().formatByteSize(ef->size()));
		twi->setText(3, dateToString( ef->creationDate() ) );
		twi->setText(4, dateToString( ef->modificationDate() ) );
		twi->setData( 0, EmbeddedFileRole, QVariant::fromValue( ef ) );
		m_tw->addTopLevelItem(twi);
	}
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "Follow this link" action
        QAction *processLink = qobject_cast<QAction*>(menu->findChild<QAction*>("ProcessLinkAction"));
        QVERIFY(processLink);

        // chek if the menu contains  "Copy Link Address" action
        QAction *actCopyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyLinkLocationAction"));
        QVERIFY(actCopyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("kcmshell5"), QStringList() << QStringLiteral("webshortcuts"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QWidget *widget) { return qobject_cast<const KParts::MainWindow *>(widget) != nullptr; }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const XpsGradient &grad : gradients ) {
        qgrad->setColorAt( grad.offset, grad.color );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto opacity : d->opacityStandardValues) {
        KToggleAction *ann = new KToggleAction(d->opacityIcon(opacity), QStringLiteral("%1\%").arg(opacity), this);
        d->aOpacity->addAction(ann);
        connect(ann, &QAction::triggered, this, [this, opacity]() { d->annotator->setAnnotationOpacity(opacity / 100); });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, pair] { doSaveEmbeddedFile(pair); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *a : actions) {
        if (a->isChecked()) {
            return a;
        } else if (a->menu()) {
            QAction *b = checkedAction(a->menu());
            if (b) {
                return b;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: pageFormFields )
    {
        fields.insert( ff->name(), static_cast<Okular::FormFieldText*>( ff ) );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Okular::FormFieldSignature *a, const Okular::FormFieldSignature *b) {
        const Okular::SignatureInfo &infoA = a->signatureInfo();
        const Okular::SignatureInfo &infoB = b->signatureInfo();
        return infoA.signingTime() < infoB.signingTime();
    }
```

#### AUTO 


```{c}
auto interpolateColor = [&backColor](double t) { return QColor(t * backColor.red(), t * backColor.green(), t * backColor.blue()); };
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        if (item->isVisible() && selectionRect.intersects(item->croppedGeometry())) {
            affectedItemsSet.insert(item->pageNumber());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PresentationFrame * frame : qAsConst( m_frames ) )
    {
        frame->recalcGeometry( m_width, m_height, screenRatio );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *videoWidget : videoWidgetsList) {
                videoWidget->pageEntered();
            }
```

#### AUTO 


```{c}
auto fingerprintFormLayout = new QFormLayout( fingerprintBox );
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &groupAddress, const QString &caller) { d->_o_changed(groupAddress, caller); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                    // first, crop the cell to this part
                    if (!tsp.rectInSelection.intersects(cell))
                        continue;
                    Okular::NormalizedRect cellPart = tsp.rectInSelection & cell; // intersection

                    // second, convert it from table coordinates to part coordinates
                    cellPart.left -= tsp.rectInSelection.left;
                    cellPart.left /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                    cellPart.right -= tsp.rectInSelection.left;
                    cellPart.right /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                    cellPart.top -= tsp.rectInSelection.top;
                    cellPart.top /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                    cellPart.bottom -= tsp.rectInSelection.top;
                    cellPart.bottom /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);

                    // third, convert from part coordinates to item coordinates
                    cellPart.left *= (tsp.rectInItem.right - tsp.rectInItem.left);
                    cellPart.left += tsp.rectInItem.left;
                    cellPart.right *= (tsp.rectInItem.right - tsp.rectInItem.left);
                    cellPart.right += tsp.rectInItem.left;
                    cellPart.top *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                    cellPart.top += tsp.rectInItem.top;
                    cellPart.bottom *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                    cellPart.bottom += tsp.rectInItem.top;

                    // now get the text
                    Okular::RegularAreaRect rects;
                    rects.append(cellPart);
                    txt += tsp.item->page()->text(&rects, Okular::TextPage::CentralPixelTextAreaInclusionBehaviour);
                }
```

#### AUTO 


```{c}
auto compareSignatureByFullyQualifiedName = [&fullyQualifiedName](const Okular::FormField *off) { return off->fullyQualifiedName() == fullyQualifiedName; };
```

#### AUTO 


```{c}
auto signatureStatusBox = new QGroupBox(i18n("Validity Status"));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto& ann : tools ) {
        // action group workaround: connecting to toggled instead of triggered
        connect( ann, &QAction::toggled, this, [this, toolId] ( bool checked ) {
            if ( checked )
                d->selectTool( toolId );
        } );
        toolId++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (HighlightAreaRect *hlar : qAsConst(m_page->m_highlights)) {
        hlar->transform(highlightRotationMatrix);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Page *pIt : qAsConst(doc->m_pagesVector)) {
        numFields += pIt->formFields().size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ObjectRect *oRect : oRects) {
                if (oRect->objectType() == ObjectRect::Action) {
                    const Action *a = static_cast<const Action *>(oRect->object());
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the menu contains "follow this link" action
        QAction *processLinkAction = qobject_cast<QAction*>(menu->findChild<QAction*>("ProcessLinkAction"));
        QVERIFY(processLinkAction);

        // check if the menu contains "copy link address" action
        QAction *copyLinkLocation = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyLinkLocationAction"));
        QVERIFY(copyLinkLocation);

        // close menu to continue test
        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers)) {
        if (o != excludeObserver)
            o->notifyViewportChanged(smoothMove);

        if (currentPageChanged)
            o->notifyCurrentPageChanged(oldPageNumber, currentViewportPage);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *i : qAsConst(d->items)) {
        const QSet<FormWidgetIface *> formWidgetsList = i->formWidgets();
        for (FormWidgetIface *fwi : formWidgetsList) {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());
        }
        const QHash<Okular::Movie *, VideoWidget *> videoWidgets = i->videoWidgets();
        for (VideoWidget *vw : videoWidgets) {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(qRound(i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left) + 1 - viewportRect.left(), qRound(i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top) + 1 - viewportRect.top());

            if (vw->isPlaying() && viewportRectAtZeroZero.intersected(vw->geometry()).isEmpty()) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if (!i->isVisible())
            continue;
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking page" << i->pageNumber();
        kWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects(i->croppedGeometry());
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected(i->croppedGeometry());
        if (intersectionRect.isEmpty()) {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back(i);
        Okular::VisiblePageRect *vItem = new Okular::VisiblePageRect(i->pageNumber(), Okular::NormalizedRect(intersectionRect.translated(-i->uncroppedGeometry().topLeft()), i->uncroppedWidth(), i->uncroppedHeight()));
        visibleRects.push_back(vItem);
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight());
        kWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if (i->page()->hasTilesManager(this) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low) {
            double rectMargin = pixelsToExpand / (double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax(0.0, vItem->rect.left - rectMargin);
            expandedVisibleRect.top = qMax(0.0, vItem->rect.top - rectMargin);
            expandedVisibleRect.right = qMin(1.0, vItem->rect.right + rectMargin);
            expandedVisibleRect.bottom = qMin(1.0, vItem->rect.bottom + rectMargin);
        }

        // if the item has not the right pixmap, add a request for it
        if (!i->page()->hasPixmap(this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect)) {
#ifdef PAGEVIEW_DEBUG
            kWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest *p = new Okular::PixmapRequest(this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), devicePixelRatioF(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous);
            requestedPixmaps.push_back(p);

            if (i->page()->hasTilesManager(this)) {
                p->setNormalizedRect(expandedVisibleRect);
                p->setTile(true);
            } else
                p->setNormalizedRect(vItem->rect);
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if (isEvent) {
            const QRect &geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            const double distance = hypot((geometry.left() + geometry.right()) / 2.0 - (viewportCenterX - 4), (geometry.top() + geometry.bottom()) / 2.0 - viewportCenterY);
            if (distance >= minDistance && nearPageNumber != -1)
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if (geometry.height() > 0 && geometry.width() > 0) {
                focusedX = (viewportCenterX - (double)geometry.left()) / (double)geometry.width();
                focusedY = (viewportCenterY - (double)geometry.top()) / (double)geometry.height();
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mimeName : mimeTypes) {
            for (const auto &suffix : md.mimeTypeForName(mimeName).suffixes())
                supportedPatterns += QStringLiteral("*.") + suffix;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, width]() { d->annotator->setAnnotationWidth(width); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( NormalizedPoint &np : m_inplaceCallout ) {
       np.transform( matrix );
    }
```

#### AUTO 


```{c}
auto cmp = [](const KPluginMetaData &s1, const KPluginMetaData &s2) {
            const QString property = QStringLiteral("X-KDE-Priority");
            return s1.rawData()[property].toInt() > s2.rawData()[property].toInt();
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const int index : selectedItems)
            if (index >= 0 && index < count())
                item(index)->setSelected(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bookmark : bMarks) {
        Okular::DocumentViewport viewport(bookmark.url().fragment());
        pages << viewport.pageNumber;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->finished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<Okular::NormalizedPoint> &inkPath : transformedInkPaths) {
                        // normalize page point to image
                        NormalizedPath path;
                        for (const Okular::NormalizedPoint &inkPoint : inkPath) {
                            Okular::NormalizedPoint point;
                            point.x = (inkPoint.x - xOffset) * xScale;
                            point.y = (inkPoint.y - yOffset) * yScale;
                            path.append(point);
                        }
                        // draw the normalized path into image
                        drawShapeOnImage(backImage, path, false, inkPen, QBrush(), pageScale);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TextDocumentGeneratorPrivate::AnnotationPosition &annPos : qAsConst(d->mAnnotationPositions) )
        {
            delete annPos.annotation;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::HighlightAnnotation::Quad &popplerQ : popplerHq) {
        Okular::HighlightAnnotation::Quad q;

        // Poppler stores highlight points in swapped order
        q.setPoint(Okular::NormalizedPoint(popplerQ.points[0].x(), popplerQ.points[0].y()), 3);
        q.setPoint(Okular::NormalizedPoint(popplerQ.points[1].x(), popplerQ.points[1].y()), 2);
        q.setPoint(Okular::NormalizedPoint(popplerQ.points[2].x(), popplerQ.points[2].y()), 1);
        q.setPoint(Okular::NormalizedPoint(popplerQ.points[3].x(), popplerQ.points[3].y()), 0);

        q.setCapStart(popplerQ.capStart);
        q.setCapEnd(popplerQ.capEnd);
        q.setFeather(popplerQ.feather);
        okularHq << q;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &retI : ret) {
        const TextEntity *orig = retI;
        retI = new TextEntity(orig->text(), new Okular::NormalizedRect(orig->transformedArea(d->rotationMatrix())));
        delete orig;
    }
```

#### AUTO 


```{c}
auto issuerFormLayout = new QFormLayout( issuerBox );
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
                    Okular::AudioPlayer::instance()->stopPlaybacks();
                }
```

#### AUTO 


```{c}
auto interpolateColor = [&backColor]( double t )
    {
        return QColor( t*backColor.red(), t*backColor.green(), t*backColor.blue() );
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
                if (!item->isVisible()) {
                    continue;
                }

                const QRect &itemRect = item->croppedGeometry();
                if (selectionRect.intersects(itemRect)) {
                    // request the textpage if there isn't one
                    okularPage = item->page();
                    qCDebug(OkularUiDebug) << "checking if page" << item->pageNumber() << "has text:" << okularPage->hasTextPage();
                    if (!okularPage->hasTextPage()) {
                        d->document->requestTextPage(okularPage->number());
                    }
                    // grab text in the rect that intersects itemRect
                    QRect relativeRect = selectionRect.intersected(itemRect);
                    relativeRect.translate(-item->uncroppedGeometry().topLeft());
                    Okular::RegularAreaRect rects;
                    rects.append(Okular::NormalizedRect(relativeRect, item->uncroppedWidth(), item->uncroppedHeight()));
                    selectedText += okularPage->text(&rects);
                }
            }
```

#### AUTO 


```{c}
auto subjectBox = new QGroupBox( i18n("Issued To"), generalPage );
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : qAsConst(m_videoWidgets)) {
        const Okular::NormalizedRect r = vw->normGeometry();
        vw->move(qRound(x + m_uncroppedGeometry.width() * r.left) + 1, qRound(y + m_uncroppedGeometry.height() * r.top) + 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *annotation : annotations) {
            if (!annotation) {
                continue;
            }

            annotation->setCreationDate(QDateTime::currentDateTime());
            annotation->setModificationDate(QDateTime::currentDateTime());
            annotation->setAuthor(Okular::Settings::identityAuthor());
            m_document->addPageAnnotation(m_lockedItem->pageNumber(), annotation);

            if (annotation->openDialogAfterCreation()) {
                m_pageView->openAnnotationWindow(annotation, m_lockedItem->pageNumber());
            }
        }
```

#### AUTO 


```{c}
auto exportBtn = new QPushButton(i18n("Export..."));
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::EmbeddedFile *ef : *document->embeddedFiles()) {
        QTreeWidgetItem *twi = new QTreeWidgetItem();
        twi->setText(0, ef->name());
        QMimeDatabase db;
        QMimeType mime = db.mimeTypeForFile(ef->name(), QMimeDatabase::MatchExtension);
        if (mime.isValid()) {
            twi->setIcon(0, QIcon::fromTheme(mime.iconName()));
        }
        twi->setText(1, ef->description());
        twi->setText(2, ef->size() <= 0 ? i18nc("Not available size", "N/A") : KFormat().formatByteSize(ef->size()));
        twi->setText(3, dateToString(ef->creationDate()));
        twi->setText(4, dateToString(ef->modificationDate()));
        twi->setData(0, EmbeddedFileRole, QVariant::fromValue(ef));
        m_tw->addTopLevelItem(twi);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFields) {
            FormWidgetIface *w = FormWidgetFactory::createWidget(ff, this);
            if (w) {
                w->setPageItem(item);
                w->setFormWidgetsController(d->formWidgetsController());
                w->setVisibility(false);
                w->setCanBeFilled(allowfillforms);
                item->formWidgets().insert(w);
                hasformwidgets = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *twi : selected)
	{
		Okular::EmbeddedFile* ef = qvariant_cast< Okular::EmbeddedFile* >( twi->data( 0, EmbeddedFileRole ) );
		viewFile( ef );
	}
```

#### RANGE FOR STATEMENT 


```{c}
for ( const int page : qAsConst( d->pagesWithTextSelection ) )
            d->document->setPageTextSelection( page, nullptr, QColor() );
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        openUrl(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( VideoWidget *vw : qAsConst(m_videoWidgets) )
    {
        const Okular::NormalizedRect r = vw->normGeometry();
        vw->move(
            qRound( x + m_uncroppedGeometry.width() * r.left ) + 1,
            qRound( y + m_uncroppedGeometry.height() * r.top ) + 1 );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &colorNameValue : colorList) {
        QColor color(colorNameValue.second);
        QAction *aColor = new QAction(GuiUtils::createColorIcon({color}, QIcon(), GuiUtils::VisualizeTransparent), colorNameValue.first.toString(), q);
        aColorPicker->addAction(aColor);
        QObject::connect(aColor, &QAction::triggered, q, [this, colorType, color]() { slotSetColor(colorType, color); });
    }
```

#### AUTO 


```{c}
auto &toolButton
```

#### AUTO 


```{c}
auto extraInfoBox = new QGroupBox( i18n("Additional Information") );
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suffix : md.mimeTypeForName(mimeName).suffixes())
                supportedPatterns += QStringLiteral("*.") + suffix;
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff : pageFormFields )
    {
        m_fields.insert( ff->name(),  ff );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        removeRCFileIfVersionSmallerThan(file, 47);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TOCItem *item : qAsConst(d->currentPage)) {
        QModelIndex index = d->indexForItem(item);
        if (!index.isValid()) {
            continue;
        }

        item->highlight = false;
        emit dataChanged(index, index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * item : qAsConst( d->items ) )
                {
                    if ( !item->isVisible() )
                        continue;

                    const QRect & itemRect = item->croppedGeometry();
                    if ( selectionRect.intersects( itemRect ) )
                    {
                        // request the textpage if there isn't one
                        okularPage= item->page();
                        qCDebug(OkularUiDebug) << "checking if page" << item->pageNumber() << "has text:" << okularPage->hasTextPage();
                        if ( !okularPage->hasTextPage() )
                            d->document->requestTextPage( okularPage->number() );
                        // grab text in the rect that intersects itemRect
                        QRect relativeRect = selectionRect.intersected( itemRect );
                        relativeRect.translate( -item->uncroppedGeometry().topLeft() );
                        Okular::RegularAreaRect rects;
                        rects.append( Okular::NormalizedRect( relativeRect, item->uncroppedWidth(), item->uncroppedHeight() ) );
                        selectedText += okularPage->text( &rects );
                    }
                }
```

#### AUTO 


```{c}
auto mime = db.mimeTypeForFileNameAndData(fileName, fileData);
```

#### RANGE FOR STATEMENT 


```{c}
for( auto cert : certs )
                items.append(cert->nickName());
```

#### RANGE FOR STATEMENT 


```{c}
for (Poppler::FormFieldSignature *s : allSignatures) {
            bool createSignature = true;
            const QString fullyQualifiedName = s->fullyQualifiedName();
            auto compareSignatureByFullyQualifiedName = [&fullyQualifiedName](const Okular::FormField *off) { return off->fullyQualifiedName() == fullyQualifiedName; };

            // See if the signature is in one of the already loaded page (i.e. 1 to end)
            for (Okular::Page *p : qAsConst(pagesVector)) {
                const QLinkedList<Okular::FormField *> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end()) {
                    delete s;
                    createSignature = false;
                    break;
                }
            }
            // See if the signature is in page 0
            if (createSignature && std::find_if(page0FormFields.constBegin(), page0FormFields.constEnd(), compareSignatureByFullyQualifiedName) != page0FormFields.constEnd()) {
                delete s;
                createSignature = false;
            }
            // Otherwise it's a page-less signature, add it to page 0
            if (createSignature) {
                Okular::FormField *of = new PopplerFormFieldSignature(std::unique_ptr<Poppler::FormFieldSignature>(s));
                page0FormFields.append(of);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Page *pIt : qAsConst(doc->m_pagesVector)) {
        const QLinkedList<Okular::FormField *> pageFields = pIt->formFields();

        if (numField < pageFields.size()) {
            const auto ffIt = pageFields.begin() + numField;

            return KJSString((*ffIt)->fullyQualifiedName());
        }

        numField -= pageFields.size();
    }
```

#### AUTO 


```{c}
auto itToolBar = std::find_if(toolbars.begin(), toolbars.end(), [&](const KToolBar *toolBar) { return toolBar->objectName() == toolBarName; });
```

#### AUTO 


```{c}
const auto symbolSize = !m_symbol.isNull() ? style()->pixelMetric(QStyle::PM_SmallIconSize) : 0;
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout( this );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QStringLiteral( "%1=\"(.*)\"" ).arg( attribute ) );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                t = attribute + '=' + match.captured( 1 );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *o : qAsConst(d->m_observers))
        if (o != excludeObserver)
            o->notifyZoom( factor );
```

#### RANGE FOR STATEMENT 


```{c}
for (TileNode &tile : d->tiles) {
        TilesManager::Private::markDirty(tile);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (glyph &g : glyphtable)
            g.shrunkenCharacter = QImage();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : geom) {
                        if (newrect.isNull()) {
                            newrect = r;
                        } else {
                            newrect |= r;
                        }
                    }
```

#### AUTO 


```{c}
auto revisionBtn = new QPushButton( i18n("View Signed Version...") );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const PageViewItem * tmpItem : qAsConst( d->items ) )
        if ( tmpItem->pageNumber() == vp.pageNumber )
        {
            item = tmpItem;
            break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * item : qAsConst( d->items ) )
        {
            int cWidth = colWidth[ cIdx ],
                rHeight = rowHeight[ rIdx ];
            if ( continuousView || rIdx == pageRowIdx )
            {
                const bool reallyDoCenterFirst = item->pageNumber() == 0 && centerFirstPage;
                const bool reallyDoCenterLast = item->pageNumber() == pageCount - 1 && centerLastPage;
                int actualX = 0;
                if ( reallyDoCenterFirst || reallyDoCenterLast )
                {
                    // page is centered across entire viewport
                    actualX = (fullWidth - item->croppedWidth()) / 2;
                }
                else if ( facingPages )
                {
                    if (Okular::Settings::rtlReadingDirection()){
                        // RTL reading mode
                        actualX = ( (centerFirstPage && item->pageNumber() % 2 == 0) ||
                                    (!centerFirstPage && item->pageNumber() % 2 == 1) ) ?
                                    (fullWidth / 2) - item->croppedWidth() - 1 : (fullWidth / 2) + 1;
                    } else {
                        // page edges 'touch' the center of the viewport
                        actualX = ( (centerFirstPage && item->pageNumber() % 2 == 1) ||
                                    (!centerFirstPage && item->pageNumber() % 2 == 0) ) ?
                                    (fullWidth / 2) - item->croppedWidth() - 1 : (fullWidth / 2) + 1;
                    }
                }
                else
                {
                    // page is centered within its virtual column
                    //actualX = insertX + (cWidth - item->croppedWidth()) / 2;
                    if (Okular::Settings::rtlReadingDirection()){
                        actualX = fullWidth - insertX - cWidth +( (cWidth - item->croppedWidth()) / 2);
                    } else {
                        actualX = insertX + (cWidth - item->croppedWidth()) / 2;
                    }
                }
                item->moveTo( actualX,
                              (continuousView ? insertY : origInsertY) + (rHeight - item->croppedHeight()) / 2 );
                item->setVisible( true );
            }
            else
            {
                item->moveTo( 0, 0 );
                item->setVisible( false );
            }
            item->setFormWidgetsVisible( d->m_formsVisible );
            // advance col/row index
            insertX += cWidth;
            if ( ++cIdx == nCols )
            {
                cIdx = 0;
                rIdx++;
                insertX = 0;
                insertY += rHeight;
            }
#ifdef PAGEVIEW_DEBUG
            kWarning() << "updating size for pageno" << item->pageNumber() << "cropped" << item->croppedGeometry() << "uncropped" << item->uncroppedGeometry();
#endif
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedPoint &item : path) {
            Okular::NormalizedPoint p;
            transform.map(item.x, item.y, &p.x, &p.y);
            transformedPath.append(p);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Action *a, int cb, int ce) { addAction(a, cb, ce); }
```

#### RANGE FOR STATEMENT 


```{c}
for (glyph &g : glyphtable) {
            g.shrunkenCharacter = QImage();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::NormalizedPoint &p : path )
                {
                    points.append(normPointToPointF( p ));
                }
```

#### AUTO 


```{c}
auto *viewOrientationMenu = qobject_cast<QMenu *>(factory()->container(QStringLiteral("view_orientation"), this))
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *trimModeAction : trimModeActions) {
        if (trimModeAction->data().toInt() != except_id)
            trimModeAction->setChecked(false);
    }
```

#### AUTO 


```{c}
auto it = namedGlobs.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
            observer->notifyPageChanged(pageNumber, DocumentObserver::Highlights);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stamp] ( bool checked ) {
            if ( checked )
                d->slotStampToolSelected( stamp.second );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointF &p : popplerPoints) {
        points << Okular::NormalizedPoint(p.x(), p.y());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect &r : rgn )
            m_pageView->viewport()->update( r.translated( -areaPos ) );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const XpsGradient &grad : gradients ) {
        if ( grad.offset == offset ) {
            return i;
        }
        ++i;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { Okular::AudioPlayer::instance()->stopPlaybacks(); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormField *ff : pageFormFields )
    {
        if ( ff->id() == 65537 )
        {
            QCOMPARE( ff->type(), FormField::FormText );
            FormFieldText *fft = static_cast<FormFieldText *>( ff );
            part.m_document->editFormText( 0, fft, QStringLiteral("BlaBla"), 6, 0, 0 );
        }
        else if ( ff->id() == 65538 )
        {
            QCOMPARE( ff->type(), FormField::FormButton );
            FormFieldButton *ffb = static_cast<FormFieldButton *>( ff );
            QCOMPARE( ffb->buttonType(), FormFieldButton::Radio );
            part.m_document->editFormButtons( 0, QList< FormFieldButton* >() << ffb, QList< bool >() << true );
        }
        else if ( ff->id() == 65542 )
        {
            QCOMPARE( ff->type(), FormField::FormChoice );
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>( ff );
            QCOMPARE( ffc->choiceType(), FormFieldChoice::ListBox );
            part.m_document->editFormList( 0, ffc, QList< int >() << 1 );
        }
        else if ( ff->id() == 65543 )
        {
            QCOMPARE( ff->type(), FormField::FormChoice );
            FormFieldChoice *ffc = static_cast<FormFieldChoice *>( ff );
            QCOMPARE( ffc->choiceType(), FormFieldChoice::ComboBox );
            part.m_document->editFormCombo( 0, ffc, QStringLiteral("combo2"), 3, 0, 0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &oldIndex : qAsConst(d->m_oldTocExpandedIndexes)) {
            const QModelIndex index = indexForIndex(oldIndex, this);
            if (!index.isValid())
                continue;

            // TODO misusing parent() here, fix
            QMetaObject::invokeMethod(QObject::parent(), "expand", Qt::QueuedConnection, Q_ARG(QModelIndex, index));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        QApplication::clipboard()->clear();

        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>(QStringLiteral("PopupMenu")));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the copy selected text to clipboard is present
        QAction *copyAct = qobject_cast<QAction*>(menu->findChild<QAction*>(QStringLiteral("CopyTextToClipboard")));
        QVERIFY(copyAct);

        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        // check if a piece of the page intersects the contents rect
        if (!item->isVisible() || !item->croppedGeometry().intersects(contentsRect)) {
            continue;
        }

        // get item and item's outline geometries
        QRect itemGeometry = item->croppedGeometry();

        // move the painter to the top-left corner of the real page
        p->save();
        p->translate(itemGeometry.left(), itemGeometry.top());

        // draw the page using the PagePainter with all flags active
        if (contentsRect.intersects(itemGeometry)) {
            Okular::NormalizedPoint *viewPortPoint = nullptr;
            Okular::NormalizedPoint point(d->lastSourceLocationViewportNormalizedX, d->lastSourceLocationViewportNormalizedY);
            if (Okular::Settings::showSourceLocationsGraphically() && item->pageNumber() == d->lastSourceLocationViewportPageNumber) {
                viewPortPoint = &point;
            }
            QRect pixmapRect = contentsRect.intersected(itemGeometry);
            pixmapRect.translate(-item->croppedGeometry().topLeft());
            PagePainter::paintCroppedPageOnPainter(p, item->page(), this, pageflags, item->uncroppedWidth(), item->uncroppedHeight(), pixmapRect, item->crop(), viewPortPoint);
        }

        // remove painted area from 'remainingArea' and restore painter
        remainingArea -= itemGeometry;
        p->restore();
    }
```

#### AUTO 


```{c}
auto vLayout = new QVBoxLayout( this );
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bookmark : pageMarks) {
        list << bookmark.url().toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TableSelectionPart& tsp : qAsConst(d->tableSelectionParts) )
    {
        // add ticks for the edges of this area...
        colSelectionTicks.append( qMakePair( tsp.rectInSelection.left,   +1 ) );
        colSelectionTicks.append( qMakePair( tsp.rectInSelection.right,  -1 ) );
        rowSelectionTicks.append( qMakePair( tsp.rectInSelection.top,    +1 ) );
        rowSelectionTicks.append( qMakePair( tsp.rectInSelection.bottom, -1 ) );

        // get the words in this part
        Okular::RegularAreaRect rects;
        rects.append( tsp.rectInItem );
        const Okular::TextEntity::List words = tsp.item->page()->words( &rects, Okular::TextPage::CentralPixelTextAreaInclusionBehaviour );

        for (const Okular::TextEntity *te : words)
        {
            if (te->text().isEmpty()) {
                delete te;
                continue;
            }

            Okular::NormalizedRect wordArea = *te->area();

            // convert it from item coordinates to part coordinates
            wordArea.left -= tsp.rectInItem.left;
            wordArea.left /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.right -= tsp.rectInItem.left;
            wordArea.right /= (tsp.rectInItem.right - tsp.rectInItem.left);
            wordArea.top -= tsp.rectInItem.top;
            wordArea.top /= (tsp.rectInItem.bottom - tsp.rectInItem.top);
            wordArea.bottom -= tsp.rectInItem.top;
            wordArea.bottom /= (tsp.rectInItem.bottom - tsp.rectInItem.top);

            // convert from part coordinates to table coordinates
            wordArea.left *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.left += tsp.rectInSelection.left;
            wordArea.right *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
            wordArea.right += tsp.rectInSelection.left;
            wordArea.top *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.top += tsp.rectInSelection.top;
            wordArea.bottom *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
            wordArea.bottom += tsp.rectInSelection.top;

            // add to the ticks arrays...
            colTicks.append( qMakePair( wordArea.left,   +1) );
            colTicks.append( qMakePair( wordArea.right,  -1) );
            rowTicks.append( qMakePair( wordArea.top,    +1) );
            rowTicks.append( qMakePair( wordArea.bottom, -1) );

            delete te;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &iChar : query) {
        const QChar ch = iChar.toLower();

        // a quote either begins or ends the phrase
        if (ch == '"') {
            keeper.addTerm(term);

            if (keeper.isInPhrase()) {
                keeper.endPhrase();
            } else {
                keeper.beginPhrase();
            }

            continue;
        }

        // If new char does not stop the word, add ot and continue
        if (ch.isLetterOrNumber() || partOfWordChars.indexOf(ch) != -1) {
            term.append(ch);
            continue;
        }

        // If it is a split char, add this term and split char as separate term
        if (splitChars.indexOf(ch) != -1) {
            // Add existing term if present
            keeper.addTerm(term);

            // Change the term variable, so it will be added when we exit this block
            term = ch;
        }

        // Just add the word; it is most likely a space or terminated by tokenizer.
        keeper.addTerm(term);
        term = QString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( ObjectRect *objRect : qAsConst(m_page->m_rects) )
        objRect->transform( matrix );
```

#### RANGE FOR STATEMENT 


```{c}
for (const int page : qAsConst(d->pagesWithTextSelection))
            d->document->setPageTextSelection(page, nullptr, QColor());
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::Annotation *annotation : annotations )
    {
        if ( annotation->subType() == Okular::Annotation::AScreen )
        {
            Okular::ScreenAnnotation *screenAnnotation = static_cast<Okular::ScreenAnnotation*>( annotation );
            resolveMediaLinkReference( screenAnnotation->additionalAction( Okular::Annotation::PageOpening ) );
            resolveMediaLinkReference( screenAnnotation->additionalAction( Okular::Annotation::PageClosing ) );
        }

        if ( annotation->subType() == Okular::Annotation::AWidget )
        {
            Okular::WidgetAnnotation *widgetAnnotation = static_cast<Okular::WidgetAnnotation*>( annotation );
            resolveMediaLinkReference( widgetAnnotation->additionalAction( Okular::Annotation::PageOpening ) );
            resolveMediaLinkReference( widgetAnnotation->additionalAction( Okular::Annotation::PageClosing ) );
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&url](const TabState state) { return state.part->url() == url; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &toolXml : items) {
        QDomDocument entryParser;
        if (!entryParser.setContent(toolXml)) {
            qWarning() << "Skipping malformed tool XML string";
            break;
        }

        QDomElement toolElement = entryParser.documentElement();
        if (toolElement.tagName() == QLatin1String("tool")) {
            // Create list item and attach the source XML string as data
            QString itemText = toolElement.attribute(QStringLiteral("name"));
            if (itemText.isEmpty())
                itemText = PageViewAnnotator::defaultToolName(toolElement);
            QListWidgetItem *listEntry = new QListWidgetItem(itemText, m_list);
            listEntry->setData(ToolXmlRole, QVariant::fromValue(toolXml));
            listEntry->setIcon(PageViewAnnotator::makeToolPixmap(toolElement));
        }
    }
```

#### AUTO 


```{c}
auto genIt = d->m_loadedGenerators.constFind(d->m_generatorName);
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Page *p : qAsConst(pagesVector)) {
                const QList<Okular::FormField *> pageFormFields = p->formFields();
                if (std::find_if(pageFormFields.begin(), pageFormFields.end(), compareSignatureByFullyQualifiedName) != pageFormFields.end()) {
                    delete s;
                    createSignature = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Revision &revision : qAsConst(d->m_revisions)) {
        // create revision element
        QDomElement r = document.createElement(QStringLiteral("revision"));
        annNode.appendChild(r);
        // set element attributes
        r.setAttribute(QStringLiteral("revScope"), (int)revision.scope());
        r.setAttribute(QStringLiteral("revType"), (int)revision.type());
        // use revision as the annotation element, so fill it up
        AnnotationUtils::storeAnnotation(revision.annotation(), r, document);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QLinkedList<Okular::NormalizedPoint> &path : inkPathsList )
            {
                QLinkedList<QPointF> points;
                for ( const Okular::NormalizedPoint &p : path )
                {
                    points.append(normPointToPointF( p ));
                }
                paths.append( points );
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormFieldButton *formButton : formButtons) {
        int id = formButton->id();
        QAbstractButton *button = m_buttons[id];
        CheckBoxEdit *check = qobject_cast<CheckBoxEdit *>(button);
        if (check) {
            emit refreshFormWidget(check->formField());
        }
        // temporarily disable exclusiveness of the button group
        // since it breaks doing/redoing steps into which all the checkboxes
        // are unchecked
        const bool wasExclusive = button->group()->exclusive();
        button->group()->setExclusive(false);
        bool checked = formButton->state();
        button->setChecked(checked);
        button->group()->setExclusive(wasExclusive);
        button->setFocus();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TileNode &tile : d->tiles)
        d->deleteTiles(tile);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mimeName : mimeTypes) {
            const QStringList suffixes = md.mimeTypeForName(mimeName).suffixes();
            for (const QString &suffix : suffixes) {
                supportedPatterns += QStringLiteral("*.") + suffix;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<WordsWithCharacters, QRect> &linesI : lines) {
            /* the line area which will be expanded
               line_rects is only necessary to preserve the topmin and bottommax of all
               the texts in the line, left and right is not necessary at all
            */
            QRect &lineArea = linesI.second;
            const int text_y1 = elementArea.top(), text_y2 = elementArea.top() + elementArea.height(), text_x1 = elementArea.left(), text_x2 = elementArea.left() + elementArea.width();
            const int line_y1 = lineArea.top(), line_y2 = lineArea.top() + lineArea.height(), line_x1 = lineArea.left(), line_x2 = lineArea.left() + lineArea.width();

            /*
               if the new text and the line has y overlapping parts of more than 70%,
               the text will be added to this line
             */
            if (doesConsumeY(elementArea, lineArea, 70)) {
                WordsWithCharacters &line = linesI.first;
                line.append(*it);

                const int newLeft = line_x1 < text_x1 ? line_x1 : text_x1;
                const int newRight = line_x2 > text_x2 ? line_x2 : text_x2;
                const int newTop = line_y1 < text_y1 ? line_y1 : text_y1;
                const int newBottom = text_y2 > line_y2 ? text_y2 : line_y2;

                lineArea = QRect(newLeft, newTop, newRight - newLeft, newBottom - newTop);
                found = true;
            }

            if (found)
                break;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(fix_word &fw : heightTable_in_units_of_design_size)
    fw.value = 0;
```

#### AUTO 


```{c}
auto *effect = new QGraphicsOpacityEffect(m_noRecentsLabel);
```

#### RANGE FOR STATEMENT 


```{c}
for ( PageViewItem * i : qAsConst( d->items ) )
    {
        foreach( FormWidgetIface *fwi, i->formWidgets() )
        {
            Okular::NormalizedRect r = fwi->rect();
            fwi->moveTo(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );
        }
        Q_FOREACH ( VideoWidget *vw, i->videoWidgets() )
        {
            const Okular::NormalizedRect r = vw->normGeometry();
            vw->move(
                qRound( i->uncroppedGeometry().left() + i->uncroppedWidth() * r.left ) + 1 - viewportRect.left(),
                qRound( i->uncroppedGeometry().top() + i->uncroppedHeight() * r.top ) + 1 - viewportRect.top() );

            if ( vw->isPlaying() && viewportRectAtZeroZero.intersected( vw->geometry() ).isEmpty() ) {
                vw->stop();
                vw->pageLeft();
            }
        }

        if ( !i->isVisible() )
            continue;
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking page" << i->pageNumber();
        kWarning().nospace() << "viewportRect is " << viewportRect << ", page item is " << i->croppedGeometry() << " intersect : " << viewportRect.intersects( i->croppedGeometry() );
#endif
        // if the item doesn't intersect the viewport, skip it
        QRect intersectionRect = viewportRect.intersected( i->croppedGeometry() );
        if ( intersectionRect.isEmpty() )
        {
            continue;
        }

        // add the item to the 'visible list'
        d->visibleItems.push_back( i );
        Okular::VisiblePageRect * vItem = new Okular::VisiblePageRect( i->pageNumber(), Okular::NormalizedRect( intersectionRect.translated( -i->uncroppedGeometry().topLeft() ), i->uncroppedWidth(), i->uncroppedHeight() ) );
        visibleRects.push_back( vItem );
#ifdef PAGEVIEW_DEBUG
        kWarning() << "checking for pixmap for page" << i->pageNumber() << "=" << i->page()->hasPixmap( this, i->uncroppedWidth(), i->uncroppedHeight() );
        kWarning() << "checking for text for page" << i->pageNumber() << "=" << i->page()->hasTextPage();
#endif

        Okular::NormalizedRect expandedVisibleRect = vItem->rect;
        if ( i->page()->hasTilesManager( this ) && Okular::Settings::memoryLevel() != Okular::Settings::EnumMemoryLevel::Low )
        {
            double rectMargin = pixelsToExpand/(double)i->uncroppedHeight();
            expandedVisibleRect.left = qMax( 0.0, vItem->rect.left - rectMargin );
            expandedVisibleRect.top = qMax( 0.0, vItem->rect.top - rectMargin );
            expandedVisibleRect.right = qMin( 1.0, vItem->rect.right + rectMargin );
            expandedVisibleRect.bottom = qMin( 1.0, vItem->rect.bottom + rectMargin );
        }

        // if the item has not the right pixmap, add a request for it
        if ( !i->page()->hasPixmap( this, i->uncroppedWidth(), i->uncroppedHeight(), expandedVisibleRect ) )
        {
#ifdef PAGEVIEW_DEBUG
            kWarning() << "rerequesting visible pixmaps for page" << i->pageNumber() << "!";
#endif
            Okular::PixmapRequest * p = new Okular::PixmapRequest( this, i->pageNumber(), i->uncroppedWidth(), i->uncroppedHeight(), PAGEVIEW_PRIO, Okular::PixmapRequest::Asynchronous );
            requestedPixmaps.push_back( p );

            if ( i->page()->hasTilesManager( this ) )
            {
                p->setNormalizedRect( expandedVisibleRect );
                p->setTile( true );
            }
            else
                p->setNormalizedRect( vItem->rect );
        }

        // look for the item closest to viewport center and the relative
        // position between the item and the viewport center
        if ( isEvent )
        {
            const QRect & geometry = i->croppedGeometry();
            // compute distance between item center and viewport center (slightly moved left)
            double distance = hypot( (geometry.left() + geometry.right()) / 2 - (viewportCenterX - 4),
                                     (geometry.top() + geometry.bottom()) / 2 - viewportCenterY );
            if ( distance >= minDistance && nearPageNumber != -1 )
                continue;
            nearPageNumber = i->pageNumber();
            minDistance = distance;
            if ( geometry.height() > 0 && geometry.width() > 0 )
            {
                focusedX = ( viewportCenterX - (double)geometry.left() ) / (double)geometry.width();
                focusedY = ( viewportCenterY - (double)geometry.top() ) / (double)geometry.height();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &s1, const KPluginMetaData &s2) {
            const QString property = QStringLiteral("X-KDE-Priority");
            return s1.rawData()[property].toInt() > s2.rawData()[property].toInt();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &f : qAsConst(listFiles) ) {
        // Extract all the files to mTempDir regardless of their path inside the archive
        // This will break if ever an arvhice with two files with the same name in different subfolders
        QFileInfo fi( f );
        if ( QFile::exists( mTempDir->path() + QLatin1Char('/') + subDir + fi.fileName() ) ) {
            newList.append( subDir + fi.fileName() );
        }
    }
```

#### AUTO 


```{c}
auto ac = actionCollection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVoice &voice : voices) {
            if (voice.name() == voiceName) {
                speech->setVoice(voice);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
        QLinkedList<Okular::PixmapRequest *> requestedPixmaps;

        TilesManager *tilesManager = page->d->tilesManager(observer);
        if (tilesManager) {
            tilesManager->markDirty();

            PixmapRequest *p = new PixmapRequest(observer, pageNumber, tilesManager->width() / qApp->devicePixelRatio(), tilesManager->height() / qApp->devicePixelRatio(), 1, PixmapRequest::Asynchronous);

            // Get the visible page rect
            NormalizedRect visibleRect;
            QVector<Okular::VisiblePageRect *>::const_iterator vIt = m_pageRects.constBegin(), vEnd = m_pageRects.constEnd();
            for (; vIt != vEnd; ++vIt) {
                if ((*vIt)->pageNumber == pageNumber) {
                    visibleRect = (*vIt)->rect;
                    break;
                }
            }

            if (!visibleRect.isNull()) {
                p->setNormalizedRect(visibleRect);
                p->setTile(true);
                p->d->mForce = true;
                requestedPixmaps.push_back(p);
            } else {
                delete p;
            }
        }

        m_parent->requestPixmaps(requestedPixmaps, Okular::Document::NoOption);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields))
    {
        if (f->rect() == oldField->rect() && f->type() == oldField->type())
            return f;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( AnnItem *child : qAsConst(item->children) ) {
        updateAnnotationPointer( child, pages );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QVariant &arg : args )
    {
        if ( arg.type() == QVariant::String )
        {
            if ( arg.toString() == QLatin1String( "Print/Preview" ) )
            {
                return Okular::PrintPreviewMode;
            }
            else if ( arg.toString() == QLatin1String( "ViewerWidget" ) )
            {
                return Okular::ViewerWidgetMode;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const HighlightAnnotation::Quad &quad : m_highlightQuads) {
        QLinkedList<NormalizedPoint> pathPoints;

        // first, we check if the point is within the area described by the 4 quads
        // this is the case, if the point is always on one side of each segments delimiting the polygon:
        pathPoints << quad.transformedPoint(0);
        int directionVote = 0;
        for (int i = 1; i < 5; ++i) {
            NormalizedPoint thisPoint = quad.transformedPoint(i % 4);
            directionVote += (isLeftOfVector(pathPoints.back(), thisPoint, point)) ? 1 : -1;
            pathPoints << thisPoint;
        }
        if (abs(directionVote) == 4)
            return 0;

        // if that's not the case, we treat the outline as path and simply determine
        // the distance from the path to the point
        const double thisOutsideDistance = ::distanceSqr(x, y, xScale, yScale, pathPoints);
        if (thisOutsideDistance < outsideDistance)
            outsideDistance = thisOutsideDistance;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *ff : pageFormFields) {
            fields.insert(ff->name(), static_cast<Okular::FormField *>(ff));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const NormalizedPoint &p : qAsConst(transformedLinePoints) )
            polygon.append( QPointF( p.x, p.y ) );
```

#### AUTO 


```{c}
auto certPropBtn = new QPushButton( i18n("Vew Certificate...") );
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *f : formFields )
        {
            if ( item->form->id() == f->id() )
            {
                item->form = static_cast<Okular::FormFieldSignature*>( f );
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
        QList<Okular::PixmapRequest *> requestedPixmaps;

        TilesManager *tilesManager = page->d->tilesManager(observer);
        if (tilesManager) {
            tilesManager->markDirty();

            PixmapRequest *p = new PixmapRequest(observer, pageNumber, tilesManager->width(), tilesManager->height(), 1 /* dpr */, 1, PixmapRequest::Asynchronous);

            // Get the visible page rect
            NormalizedRect visibleRect;
            QVector<Okular::VisiblePageRect *>::const_iterator vIt = m_pageRects.constBegin(), vEnd = m_pageRects.constEnd();
            for (; vIt != vEnd; ++vIt) {
                if ((*vIt)->pageNumber == pageNumber) {
                    visibleRect = (*vIt)->rect;
                    break;
                }
            }

            if (!visibleRect.isNull()) {
                p->setNormalizedRect(visibleRect);
                p->setTile(true);
                p->d->mForce = true;
                requestedPixmaps.push_back(p);
            } else {
                delete p;
            }
        }

        m_parent->requestPixmaps(requestedPixmaps, Okular::Document::NoOption);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TextDocumentGeneratorPrivate::LinkInfo &info : linkInfos ) {
        // in case that the converter report bogus link info data, do not assert here
        if ( info.page >= objects.count() )
          continue;

        const QRectF rect = info.boundingRect;
        if ( info.ownsLink ) {
            objects[ info.page ].append( new Okular::ObjectRect( rect.left(), rect.top(), rect.right(), rect.bottom(), false,
                                                                 Okular::ObjectRect::Action, info.link ) );
        } else {
            objects[ info.page ].append( new Okular::NonOwningObjectRect( rect.left(), rect.top(), rect.right(), rect.bottom(), false,
                                                                          Okular::ObjectRect::Action, info.link ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
                if (!item->isVisible()) {
                    continue;
                }

                const QRect &itemRect = item->croppedGeometry();
                if (selectionRect.intersects(itemRect)) {
                    // request the textpage if there isn't one
                    okularPage = item->page();
                    qCDebug(OkularUiDebug) << "checking if page" << item->pageNumber() << "has text:" << okularPage->hasTextPage();
                    if (!okularPage->hasTextPage()) {
                        d->document->requestTextPage(okularPage->number());
                    }
                    // grab text in the rect that intersects itemRect
                    QRect rectInItem = selectionRect.intersected(itemRect);
                    rectInItem.translate(-item->uncroppedGeometry().topLeft());
                    QRect rectInSelection = selectionRect.intersected(itemRect);
                    rectInSelection.translate(-selectionRect.topLeft());
                    d->tableSelectionParts.append(
                        TableSelectionPart(item, Okular::NormalizedRect(rectInItem, item->uncroppedWidth(), item->uncroppedHeight()), Okular::NormalizedRect(rectInSelection, selectionRect.width(), selectionRect.height())));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::FontInfo &font : qAsConst(fonts)) {
        Okular::FontInfo of;
        of.setName(font.name());
#ifdef HAVE_POPPLER_0_80
        of.setSubstituteName(font.substituteName());
#endif
        of.setType(convertPopplerFontInfoTypeToOkularFontInfoType(font.type()));
        of.setEmbedType(embedTypeForPopplerFontInfo(font));
        of.setFile(font.file());
        of.setCanBeExtracted(of.embedType() != Okular::FontInfo::NotEmbedded);

        QVariant nativeId;
        nativeId.setValue(font);
        of.setNativeId(nativeId);

        list.append(of);
    }
```

#### AUTO 


```{c}
auto manager = new KColorSchemeManager(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &highlight : qAsConst(*bufferedHighlights)) {
                const Okular::NormalizedRect &r = highlight.second;
                // find out the rect to highlight on pixmap
                QRect highlightRect = r.geometry(scaledWidth, scaledHeight).translated(-scaledCrop.topLeft()).intersected(limits);
                highlightRect.translate(-limits.left(), -limits.top());

                const QColor highlightColor = highlight.first;
                QPainter painter(&backImage);
                painter.setCompositionMode(QPainter::CompositionMode_Multiply);
                painter.fillRect(highlightRect, highlightColor);

                auto frameColor = highlightColor.darker(150);
                const QRect frameRect = r.geometry(scaledWidth, scaledHeight).translated(-scaledCrop.topLeft()).translated(-limits.left(), -limits.top());
                painter.setPen(frameColor);
                painter.drawRect(frameRect);
            }
```

#### AUTO 


```{c}
auto generalPageLayout = new QVBoxLayout(generalPage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *visibleItem : qAsConst(d->visibleItems))
            if (abs(visibleItem->pageNumber() - pageNumber) <= 1)
                return false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Document &doc : qAsConst(minDocs)) {
        fileName = docList[(int)doc.docNumber];
        if (searchForPhrases(termSeq, seqWords, fileName, chmFile))
            results << fileName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attribute : attributes) {
            const QRegularExpression re(QStringLiteral("(.*),\\s*(%1=.*)").arg(attribute), QRegularExpression::DotMatchesEverythingOption);
            const QRegularExpressionMatch match = re.match(t);
            if (match.hasMatch()) {
                QStringList results = text;
                const int index = results.indexOf(t);
                results.removeAt(index);
                results.insert(index, match.captured(2));
                results.insert(index, match.captured(1));
                return splitDNAttributes(results);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &t : result) {
        for (const QString &attribute : attributes) {
            const QRegularExpression re(QStringLiteral("%1=\"(.*)\"").arg(attribute));
            const QRegularExpressionMatch match = re.match(t);
            if (match.hasMatch()) {
                t = attribute + QLatin1Char('=') + match.captured(1);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList)
        {
            openUrl( url );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &stamp : StampAnnotationWidget::defaultStamps()) {
        KToggleAction *ann = new KToggleAction(d->stampIcon(stamp.second), stamp.first, this);
        if (!d->aStamp->defaultAction())
            d->aStamp->setDefaultAction(ann);
        d->aStamp->addAction(ann);
        d->agTools->addAction(ann);
        // action group workaround: connecting to toggled instead of triggered
        // (because deselectAllAnnotationActions has to call triggered)
        connect(ann, &QAction::toggled, this, [this, stamp](bool checked) {
            if (checked)
                d->slotStampToolSelected(stamp.second);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &iListing : qAsConst(listing)) {
        // Strip the directory name
        const QString ename = iListing.mid(striplength);

        if (isDirectory(ename)) {
            app_dir(entry, ename);
        } else {
            app_file(entry, ename, 0);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KBookmark &bm : qAsConst(bmarks)) {
        DocumentViewport vp(bm.url().fragment(QUrl::FullyDecoded));
        if (viewport < vp) {
            bookmark = bm;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormFieldButton *oldFormButton : oldFormButtons )
    {
        FormFieldButton *button = dynamic_cast<FormFieldButton *>(Okular::PagePrivate::findEquivalentForm( newPagesVector[m_pageNumber], oldFormButton ));
        if ( !button )
            return false;
        m_formButtons << button;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (PageViewItem *item : qAsConst(d->items)) {
        int cWidth = colWidth[cIdx], rHeight = rowHeight[rIdx];
        if (continuousView || rIdx == pageRowIdx) {
            const bool reallyDoCenterFirst = item->pageNumber() == 0 && centerFirstPage;
            const bool reallyDoCenterLast = item->pageNumber() == pageCount - 1 && centerLastPage;
            int actualX = 0;
            if (reallyDoCenterFirst || reallyDoCenterLast) {
                // page is centered across entire viewport
                actualX = (fullWidth - item->croppedWidth()) / 2;
            } else if (facingPages) {
                if (Okular::Settings::rtlReadingDirection()) {
                    // RTL reading mode
                    actualX = ((centerFirstPage && item->pageNumber() % 2 == 0) || (!centerFirstPage && item->pageNumber() % 2 == 1)) ? (fullWidth / 2) - item->croppedWidth() - 1 : (fullWidth / 2) + 1;
                } else {
                    // page edges 'touch' the center of the viewport
                    actualX = ((centerFirstPage && item->pageNumber() % 2 == 1) || (!centerFirstPage && item->pageNumber() % 2 == 0)) ? (fullWidth / 2) - item->croppedWidth() - 1 : (fullWidth / 2) + 1;
                }
            } else {
                // page is centered within its virtual column
                // actualX = insertX + (cWidth - item->croppedWidth()) / 2;
                if (Okular::Settings::rtlReadingDirection()) {
                    actualX = fullWidth - insertX - cWidth + ((cWidth - item->croppedWidth()) / 2);
                } else {
                    actualX = insertX + (cWidth - item->croppedWidth()) / 2;
                }
            }
            item->moveTo(actualX, (continuousView ? insertY : origInsertY) + (rHeight - item->croppedHeight()) / 2);
            item->setVisible(true);
        } else {
            item->moveTo(0, 0);
            item->setVisible(false);
        }
        item->setFormWidgetsVisible(d->m_formsVisible);
        // advance col/row index
        insertX += cWidth;
        if (++cIdx == nCols) {
            cIdx = 0;
            rIdx++;
            insertX = 0;
            insertY += rHeight;
        }
#ifdef PAGEVIEW_DEBUG
        qWarning() << "updating size for pageno" << item->pageNumber() << "cropped" << item->croppedGeometry() << "uncropped" << item->uncroppedGeometry();
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QRect & r : rgn )
        {
            summedArea += r.width() * r.height();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool clean) {
        setModified(!clean);
        setWindowTitleFromDocument();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const WordWithCharacters &word : list) {
                const QRect wordRect = word.area().geometry(pageWidth, pageHeight);

                if (leftRect.intersects(wordRect)) {
                    list1.append(word);
                } else {
                    list2.append(word);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[view]() {
        QApplication::clipboard()->clear();

        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the copy selected text to clipboard is present
        QAction *copyAct = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyTextToClipboard"));
        QVERIFY(copyAct);

        menu->close();
    }
```

#### AUTO 


```{c}
auto targetDefaultRO = dynamic_cast< Okular::FormFieldText* > ( fields[QStringLiteral( "TargetDefaultRo" )] );
```

#### RANGE FOR STATEMENT 


```{c}
for ( PixmapRequest *newRequest : requests )
            {
                if ( newRequest->pageNumber() == executingRequest->pageNumber() && requesterObserver == executingRequest->observer())
                {
                    newRequestsContainExecutingRequestPage = true;
                }

                if ( shouldCancelRenderingBecauseOf( *executingRequest, *newRequest ) )
                {
                    requestCancelled = d->cancelRenderingBecauseOf( executingRequest, newRequest );
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( MiniBar *miniBar : qAsConst(m_miniBars) )
    {
        // resize width of widgets
        miniBar->resizeForPage( pages );
            
        // update child widgets
        miniBar->m_pageLabelEdit->setPageLabels( pageVector );
        miniBar->m_pageNumberEdit->setPagesNumber( pages );
        miniBar->m_pagesButton->setText( pagesString );
        miniBar->m_prevButton->setEnabled( false );
        miniBar->m_nextButton->setEnabled( false );
        miniBar->m_pageLabelEdit->setVisible( labelsDiffer );
        miniBar->m_pageNumberLabel->setVisible( labelsDiffer );
        miniBar->m_pageNumberEdit->setVisible( !labelsDiffer );

        miniBar->adjustSize();

        miniBar->setEnabled( true );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        QString newarg = arg;
        newarg.replace(QLatin1Char('\''), QLatin1String("\\'"));
        arrayargs.append(QLatin1Char('"') + newarg + QLatin1Char('"'));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { doc->executeScript(function); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( FormWidgetIface *w : fws )
                    {
                        Okular::FormField *f = Okular::PagePrivate::findEquivalentForm( d->document->page( i ), w->formField() );
                        if (f)
                        {
                            w->setFormField( f );
                        }
                        else
                        {
                            qWarning() << "Lost form field on document save, something is wrong";
                            item->formWidgets().remove(w);
                            delete w;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *visibleItem : qAsConst(d->visibleItems))
            if (visibleItem->pageNumber() == pageNumber)
                return false;
```

#### RANGE FOR STATEMENT 


```{c}
for ( auto width : d->widthStandardValues ) {
        KToggleAction * ann = new KToggleAction( d->widthIcon( width ), i18nc("@item:inlistbox", "Width %1", width), this);
        d->aWidth->addAction( ann );
        connect( ann, &QAction::triggered, this, [this, width] () {
            d->annotator->setAnnotationWidth( width );
        } );
    }
```

#### AUTO 


```{c}
const auto fft = static_cast<Okular::FormFieldText *>(m_ff);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PageViewItem *item : qAsConst(d->items)) {
        Okular::RegularAreaRect *area = textSelectionForItem(item);
        d->pagesWithTextSelection.insert(item->pageNumber());
        d->document->setPageTextSelection(item->pageNumber(), area, palette().color(QPalette::Active, QPalette::Highlight));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : rgn) {
        viewport()->update(rect);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (double opacity : d->opacityStandardValues) {
        KToggleAction *ann = new KToggleAction(GuiUtils::createOpacityIcon(opacity), QStringLiteral("%1\%").arg(opacity * 100), this);
        d->aOpacity->addAction(ann);
        connect(ann, &QAction::triggered, this, [this, opacity]() { d->annotator->setAnnotationOpacity(opacity); });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int req : qAsConst(d->refreshPages)) {
        QTimer::singleShot(0, this, [this, req] { d->document->refreshPixmaps(req); });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (d->aViewContinuous && !d->document->isOpened())
            d->aViewContinuous->setChecked(Okular::Settings::viewContinuous());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString url : qAsConst(content_parser.spine)) {
            EBookTocEntry e;

            if (content_parser.manifest.contains(url)) {
                url = content_parser.manifest[url];
            }

            e.name = url;
            e.url = pathToUrl(url);
            e.iconid = EBookTocEntry::IMAGE_NONE;
            e.indent = 0;

            // Add into url-title map
            m_urlTitleMap[pathToUrl(url)] = url;
            m_tocEntries.push_back(e);
        }
```

#### AUTO 


```{c}
auto sha1Label = new QLabel(QString::fromLatin1(QCryptographicHash::hash(certData, QCryptographicHash::Sha1).toHex(' ')));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::Page * page : pageSet )
    {
        PresentationFrame * frame = new PresentationFrame();
        frame->page = page;
        const QLinkedList< Okular::Annotation * > annotations = page->annotations();
        for ( Okular::Annotation * a : annotations )
        {
            if ( a->subType() == Okular::Annotation::AMovie )
            {
                Okular::MovieAnnotation * movieAnn = static_cast< Okular::MovieAnnotation * >( a );
                VideoWidget * vw = new VideoWidget( movieAnn, movieAnn->movie(), m_document, this );
                frame->videoWidgets.insert( movieAnn->movie(), vw );
                vw->pageInitialized();
            }
            else if ( a->subType() == Okular::Annotation::ARichMedia )
            {
                Okular::RichMediaAnnotation * richMediaAnn = static_cast< Okular::RichMediaAnnotation * >( a );
                if ( richMediaAnn->movie() ) {
                    VideoWidget * vw = new VideoWidget( richMediaAnn, richMediaAnn->movie(), m_document, this );
                    frame->videoWidgets.insert( richMediaAnn->movie(), vw );
                    vw->pageInitialized();
                }
            }
            else if ( a->subType() == Okular::Annotation::AScreen )
            {
                const Okular::ScreenAnnotation * screenAnn = static_cast< Okular::ScreenAnnotation * >( a );
                Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation( screenAnn );
                if ( movie )
                {
                    VideoWidget * vw = new VideoWidget( screenAnn, movie, m_document, this );
                    frame->videoWidgets.insert( movie, vw );
                    vw->pageInitialized();
                }
            }
        }
        frame->recalcGeometry( m_width, m_height, screenRatio );
        // add the frame to the vector
        m_frames.push_back( frame );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ObjectRect *rect : m_rects) {
        if (rect->objectType() == type) {
            double d = rect->distanceSqr(x, y, xScale, yScale);
            if (d < minDistance) {
                res = rect;
                minDistance = d;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Okular::Annotation *ann : annotations )
            {
                if ( !(ann->flags() & Okular::Annotation::External) )
                {
                    wontSaveAnnotations = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( Okular::FormField *ff: pageFormFields )
    {
        if ( ff->name().startsWith( QStringLiteral( "Target" ) ) )
        {
            QVERIFY( !ff->isVisible() );
            anyChecked = true;
        }
    }
```

#### AUTO 


```{c}
auto *parentItem = new SignatureItem(root, sf, SignatureItem::RevisionInfo, pageNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for ( const auto &item: termStyles )
        {
            const QIcon icon = endStyleIcon( item.first, QGuiApplication::palette().color( QPalette::WindowText ) );
            m_startStyleCombo->addItem( icon, item.second );
            m_endStyleCombo->addItem( icon, item.second );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ObjectRect *rect : m_rects) {
        if (rect->distanceSqr(x, y, xScale, yScale) < distanceConsideredEqual) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &arg : args )
    {
        QString newarg = arg;
        newarg.replace( QLatin1Char('\''), QLatin1String("\\'") );
        arrayargs.append( QLatin1Char('"') + newarg + QLatin1Char('"') );
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]( Okular::FormField * form )
            {
                Okular::FormFieldText *fft = reinterpret_cast< Okular::FormFieldText * >( form );
                if( fft )
                    m_formattedText = fft->text();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const TabState &tab : qAsConst( m_tabs ) )
    {
        urls.append( tab.part->url().url() );
    }
```

#### AUTO 


```{c}
auto childItem4 = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, pageNumber);
```

#### AUTO 


```{c}
auto childItem = new SignatureItem(parentItem, sf, SignatureItem::FieldInfo, pageNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for (VideoWidget *vw : qAsConst(m_frames[m_frameIndex]->videoWidgets)) {
            vw->pageEntered();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, favToolId](bool checked) {
            if (checked) {
                slotQuickToolSelected(favToolId);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::NormalizedRect &r : qAsConst(*selection)) {
                Okular::HighlightAnnotation::Quad q;
                q.setCapStart(false);
                q.setCapEnd(false);
                q.setFeather(1.0);
                q.setPoint(Okular::NormalizedPoint(r.left, r.bottom), 0);
                q.setPoint(Okular::NormalizedPoint(r.right, r.bottom), 1);
                q.setPoint(Okular::NormalizedPoint(r.right, r.top), 2);
                q.setPoint(Okular::NormalizedPoint(r.left, r.top), 3);
                ha->highlightQuads().append(q);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (FormField *f : qAsConst(p->d->formfields)) {
        if (f->rect() == oldField->rect() && f->type() == oldField->type())
            return f;
    }
```

#### AUTO 


```{c}
auto sha256Label = new QLabel(QString::fromLatin1(QCryptographicHash::hash(certData, QCryptographicHash::Sha256).toHex(' ')));
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) { Q_EMIT preferredScreenChanged(index - k_specialScreenCount); }
```

#### AUTO 


```{c}
auto widget = part.m_pageView->viewport()->childAt(tfPos);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &toolButton : findChildren<QToolButton *>()) {
        oldLayout->removeWidget(toolButton);
        newLayout->addWidget(toolButton);
        newLayout->setAlignment(toolButton, Qt::AlignCenter);
    }
```

#### AUTO 


```{c}
auto extraInfoBox = new QGroupBox(i18n("Additional Information"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Okular::FontInfo &f) { d->fontReadingGotFont(f); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                // first, crop the cell to this part
                if (!tsp.rectInSelection.intersects(cell)) {
                    continue;
                }
                Okular::NormalizedRect cellPart = tsp.rectInSelection & cell; // intersection

                // second, convert it from table coordinates to part coordinates
                cellPart.left -= tsp.rectInSelection.left;
                cellPart.left /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                cellPart.right -= tsp.rectInSelection.left;
                cellPart.right /= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                cellPart.top -= tsp.rectInSelection.top;
                cellPart.top /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                cellPart.bottom -= tsp.rectInSelection.top;
                cellPart.bottom /= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);

                // third, convert from part coordinates to item coordinates
                cellPart.left *= (tsp.rectInItem.right - tsp.rectInItem.left);
                cellPart.left += tsp.rectInItem.left;
                cellPart.right *= (tsp.rectInItem.right - tsp.rectInItem.left);
                cellPart.right += tsp.rectInItem.left;
                cellPart.top *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                cellPart.top += tsp.rectInItem.top;
                cellPart.bottom *= (tsp.rectInItem.bottom - tsp.rectInItem.top);
                cellPart.bottom += tsp.rectInItem.top;

                // now get the text
                Okular::RegularAreaRect rects;
                rects.append(cellPart);
                txt += tsp.item->page()->text(&rects, Okular::TextPage::CentralPixelTextAreaInclusionBehaviour);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, toolId](bool checked) {
            if (checked) {
                d->selectTool(toolId);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] ( Okular::FormField *form ) {
                          slotRefresh ( form );
                      }
```

#### LAMBDA EXPRESSION 


```{c}
[&executeNextActions] { executeNextActions = false; }
```

#### LAMBDA EXPRESSION 


```{c}
[&backColor]( double t )
    {
        return QColor( t*backColor.red(), t*backColor.green(), t*backColor.blue() );
    }
```

#### AUTO 


```{c}
auto targetDefaultRO = dynamic_cast<Okular::FormFieldText *>(fields[QStringLiteral("TargetDefaultRo")]);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actionsList)
    {
        action->setEnabled( true );
        m_topBar->addAction( action );
        addAction( action );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::FormField *f : formFields) {
            if (f->type() == Okular::FormField::FormSignature) {
                signatureFormFields.append(static_cast<Okular::FormFieldSignature *>(f));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SourceRefObjectRect *rect : refRects) {
        m_rects << rect;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ann : tools) {
        // action group workaround: connecting to toggled instead of triggered
        connect(ann, &QAction::toggled, this, [this, toolId](bool checked) {
            if (checked)
                d->selectTool(toolId);
        });
        toolId++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLinkedList<Okular::NormalizedPoint> &path : inkPathsList) {
        QLinkedList<QPointF> points;
        for (const Okular::NormalizedPoint &p : path) {
            points.append(normPointToPointF(p));
        }
        paths.append(points);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers)) {
            AllocatedPixmap *p = searchLowestPriorityPixmap(false, true, observer);
            if (!p) // No pixmap to remove
                continue;

            clean_hits++;

            TilesManager *tilesManager = m_pagesVector.at(p->page)->d->tilesManager(observer);
            if (tilesManager && tilesManager->totalMemory() > 0) {
                qulonglong memoryDiff = p->memory;
                NormalizedRect visibleRect;
                if (visibleRects.contains(p->page))
                    visibleRect = visibleRects[p->page]->rect;

                // Free non visible tiles
                tilesManager->cleanupPixmapMemory(memoryToFree, visibleRect, currentViewportPage);

                p->memory = tilesManager->totalMemory();
                memoryDiff -= p->memory;
                memoryToFree = (memoryDiff < memoryToFree) ? (memoryToFree - memoryDiff) : 0;
                m_allocatedPixmapsTotalMemory -= memoryDiff;

                if (p->memory > 0)
                    pixmapsToKeep.append(p);
                else
                    delete p;
            } else
                pixmapsToKeep.append(p);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines) {
        const WordsWithCharacters list = sortedLine.first;
        QList<QRect> line_space_rects;
        int maxSpace = 0, minSpace = pageWidth;

        // for every TinyTextEntity element in the line
        WordsWithCharacters::ConstIterator it = list.begin(), itEnd = list.end();
        QRect max_area1, max_area2;
        QString before_max, after_max;

        // for every line
        for (; it != itEnd; it++) {
            const QRect area1 = (*it).area().roundedGeometry(pageWidth, pageHeight);
            if (it + 1 == itEnd) {
                break;
            }

            const QRect area2 = (*(it + 1)).area().roundedGeometry(pageWidth, pageHeight);
            int space = area2.left() - area1.right();

            if (space > maxSpace) {
                max_area1 = area1;
                max_area2 = area2;
                maxSpace = space;
                before_max = (*it).text();
                after_max = (*(it + 1)).text();
            }

            if (space < minSpace && space != 0) {
                minSpace = space;
            }

            // if we found a real space, whose length is not zero and also less than the pageWidth
            if (space != 0 && space != pageWidth) {
                // increase the count of the space amount
                if (hor_space_stat.contains(space)) {
                    hor_space_stat[space]++;
                } else {
                    hor_space_stat[space] = 1;
                }

                int left, right, top, bottom;

                left = area1.right();
                right = area2.left();

                top = area2.top() < area1.top() ? area2.top() : area1.top();
                bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                QRect rect(left, top, right - left, bottom - top);
                line_space_rects.append(rect);
            }
        }

        space_rects.append(line_space_rects);

        if (hor_space_stat.contains(maxSpace)) {
            if (hor_space_stat[maxSpace] != 1) {
                hor_space_stat[maxSpace]--;
            } else {
                hor_space_stat.remove(maxSpace);
            }
        }

        if (maxSpace != 0) {
            if (col_space_stat.contains(maxSpace)) {
                col_space_stat[maxSpace]++;
            } else {
                col_space_stat[maxSpace] = 1;
            }

            // store the max rect of each line
            const int left = max_area1.right();
            const int right = max_area2.left();
            const int top = (max_area1.top() > max_area2.top()) ? max_area2.top() : max_area1.top();
            const int bottom = (max_area1.bottom() < max_area2.bottom()) ? max_area2.bottom() : max_area1.bottom();

            const QRect rect(left, top, right - left, bottom - top);
            max_hor_space_rects.append(rect);
        } else {
            max_hor_space_rects.append(QRect(0, 0, 0, 0));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ParsedEntry &e : qAsConst(parsed)) {
        if (root_offset == -1)
            root_offset = e.indent;

        EBookTocEntry entry;
        entry.iconid = (EBookTocEntry::Icon)e.iconid;
        entry.indent = e.indent - root_offset;
        entry.name = e.name;

        if (!e.urls.empty())
            entry.url = e.urls[0];

        toc.append(entry);
    }
```

#### AUTO 


```{c}
auto certPropBtn = new QPushButton( i18n("View Certificate...") );
```

#### RANGE FOR STATEMENT 


```{c}
for (DocumentObserver *observer : qAsConst(m_observers))
        {
            AllocatedPixmap * p = searchLowestPriorityPixmap( false, true, observer );
            if ( !p ) // No pixmap to remove
                continue;

            clean_hits++;

            TilesManager *tilesManager = m_pagesVector.at( p->page )->d->tilesManager( observer );
            if ( tilesManager && tilesManager->totalMemory() > 0 )
            {
                qulonglong memoryDiff = p->memory;
                NormalizedRect visibleRect;
                if ( visibleRects.contains( p->page ) )
                    visibleRect = visibleRects[ p->page ]->rect;

                // Free non visible tiles
                tilesManager->cleanupPixmapMemory( memoryToFree, visibleRect, currentViewportPage );

                p->memory = tilesManager->totalMemory();
                memoryDiff -= p->memory;
                memoryToFree = (memoryDiff < memoryToFree) ? (memoryToFree - memoryDiff) : 0;
                m_allocatedPixmapsTotalMemory -= memoryDiff;

                if ( p->memory > 0 )
                    pixmapsToKeep.append( p );
                else
                    delete p;
            }
            else
                pixmapsToKeep.append( p );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPair<WordsWithCharacters, QRect> &sortedLine : sortedLines) {
            WordsWithCharacters &list = sortedLine.first;
            for (int k = 0; k < list.length(); k++) {
                const QRect area1 = list.at(k).area().roundedGeometry(pageWidth, pageHeight);
                if (k + 1 >= list.length())
                    break;

                const QRect area2 = list.at(k + 1).area().roundedGeometry(pageWidth, pageHeight);
                const int space = area2.left() - area1.right();

                if (space != 0) {
                    // Make a TinyTextEntity of string space and push it between it and it+1
                    const int left = area1.right();
                    const int right = area2.left();
                    const int top = area2.top() < area1.top() ? area2.top() : area1.top();
                    const int bottom = area2.bottom() > area1.bottom() ? area2.bottom() : area1.bottom();

                    const QString spaceStr(QStringLiteral(" "));
                    const QRect rect(QPoint(left, top), QPoint(right, bottom));
                    const NormalizedRect entRect(rect, pageWidth, pageHeight);
                    TinyTextEntity *ent1 = new TinyTextEntity(spaceStr, entRect);
                    TinyTextEntity *ent2 = new TinyTextEntity(spaceStr, entRect);
                    WordWithCharacters word(ent1, QList<TinyTextEntity *>() << ent2);

                    list.insert(k + 1, word);

                    // Skip the space
                    k++;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &line : data )
    {
        QRegularExpressionMatch match = re.match( line );
        if ( match.hasMatch() ) {
            newdata.append( match.captured( 1 ) );
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Term &t : qAsConst(termList)) {
        const QVector<Document> docs = t.documents;
        for (QVector<Document>::Iterator minDoc_it = minDocs.begin(); minDoc_it != minDocs.end();) {
            bool found = false;
            for (QVector<Document>::ConstIterator doc_it = docs.constBegin(); doc_it != docs.constEnd(); ++doc_it) {
                if ((*minDoc_it).docNumber == (*doc_it).docNumber) {
                    (*minDoc_it).frequency += (*doc_it).frequency;
                    found = true;
                    break;
                }
            }
            if (!found)
                minDoc_it = minDocs.erase(minDoc_it);
            else
                ++minDoc_it;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Page *p : qAsConst(d->m_pagesVector)) {
            const QList<ObjectRect *> &oRects = p->objectRects();
            for (ObjectRect *oRect : oRects) {
                if (oRect->objectType() == ObjectRect::Action) {
                    const Action *a = static_cast<const Action *>(oRect->object());
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }

            const QList<FormField *> forms = p->formFields();
            for (const FormField *form : forms) {
                const QList<Action *> additionalActions = form->additionalActions();
                for (const Action *a : additionalActions) {
                    const BackendOpaqueAction *backendAction = dynamic_cast<const BackendOpaqueAction *>(a);
                    if (backendAction) {
                        d->m_generator->freeOpaqueActionContents(*backendAction);
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( TOCItem *child : current->children )
        {
            if ( child->viewport.isValid() )
            {
                if ( child->viewport.pageNumber <= viewport.pageNumber )
                {
                    pos = child;
                    if ( child->viewport.pageNumber == viewport.pageNumber )
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, stampIconName] () {
            slotStampToolSelected( stampIconName );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { d->slotCaseSensitive(); }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const TextDocumentGeneratorPrivate::AnnotationInfo &info : annotationInfos ) {
        annots[ info.page ].append( info.annotation );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &backRect : remainingArea)
        p->fillRect(backRect, backColor);
```

#### LAMBDA EXPRESSION 


```{c}
[this, pair] { doOpenPropertiesDialog(pair); }
```

#### LAMBDA EXPRESSION 


```{c}
[view, &menuClosed]() {
        QApplication::clipboard()->clear();

        // check if popup menu is active and visible
        QMenu *menu = qobject_cast<QMenu*>(view->findChild<QMenu*>("PopupMenu"));
        QVERIFY(menu);
        QVERIFY(menu->isVisible());

        // check if the copy selected text to clipboard is present
        QAction *copyAct = qobject_cast<QAction*>(menu->findChild<QAction*>("CopyTextToClipboard"));
        QVERIFY(copyAct);

        menu->close();
        menuClosed = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( DocumentObserver *o : qAsConst( observersPixmapCleared ) )
        o->notifyContentsCleared( Okular::DocumentObserver::Pixmap );
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &arg : paths )
    {
        // Copy stdin to temporary file which can be opened by the existing
        // window. The temp file is automatically deleted after it has been
        // opened. Not sure if this behavior is safe on all platforms.
        QScopedPointer<QTemporaryFile> tempFile;
        QString path;
        if( arg == QLatin1String("-") )
        {
            tempFile.reset( new QTemporaryFile );
            QFile stdinFile;
            if( !tempFile->open() || !stdinFile.open(stdin,QIODevice::ReadOnly) )
                return false;

            const size_t bufSize = 1024*1024;
            QScopedPointer<char,QScopedPointerArrayDeleter<char> > buf( new char[bufSize] );
            size_t bytes;
            do
            {
                bytes = stdinFile.read( buf.data(), bufSize );
                tempFile->write( buf.data(), bytes );
            } while( bytes != 0 );

            path = tempFile->fileName();
        }
        else
        {
            // Page only makes sense if we are opening one file
            const QString page = ShellUtils::page(serializedOptions);
            path = ShellUtils::urlFromArg(arg, ShellUtils::qfileExistFunc(), page).url();
        }

        // Returns false if it can't fit another document
        const QDBusReply<bool> reply = bestService->call( QStringLiteral("openDocument"), path, serializedOptions );
        if( !reply.isValid() || !reply.value() )
            return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( TileNode &tile : d->tiles )
    {
        d->rankTiles( tile, rankedTiles, visibleRect, visiblePageNumber );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : services) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            bestService.reset(new QDBusInterface(service, QStringLiteral("/okularshell"), QStringLiteral("org.kde.okular")));

            // Find a window that can handle our documents
            const QDBusReply<bool> reply = bestService->call(QStringLiteral("canOpenDocs"), paths.count(), desktop);
            if (reply.isValid() && reply.value()) {
                break;
            }

            bestService.reset();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &attribute : attributes )
        {
            const QRegularExpression re( QString( "%1=\"(.*)\"" ).arg( attribute ) );
            const QRegularExpressionMatch match = re.match( t );
            if ( match.hasMatch() )
            {
                t = attribute + "=" + match.captured( 1 );
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::FormField *f : formFields) {
                if (f->type() == Okular::FormField::FormSignature)
                    return true;
            }
```

#### AUTO 


```{c}
auto showBtn = m_fields[QStringLiteral("ShowScriptButton")];
```

#### RANGE FOR STATEMENT 


```{c}
for (const TableSelectionPart &tsp : qAsConst(d->tableSelectionParts)) {
                        QRect selectionPartRect = tsp.rectInItem.geometry(tsp.item->uncroppedWidth(), tsp.item->uncroppedHeight());
                        selectionPartRect.translate( tsp.item->uncroppedGeometry().topLeft () );

                        // This will update the whole table rather than just the added/removed divider
                        // (which can span more than one part).
                        updatedRect = updatedRect.united(selectionPartRect);

                        if (!selectionPartRect.contains(eventPos))
                            continue;

                        // At this point it's clear we're either adding or removing a divider manually, so obviously the user is happy with the guess (if any).
                        d->tableDividersGuessed = false;

                        // There's probably a neat trick to finding which edge it's closest to,
                        // but this way has the advantage of simplicity.
                        const int fromLeft = abs(selectionPartRect.left() - eventPos.x());
                        const int fromRight = abs(selectionPartRect.left() + selectionPartRect.width() - eventPos.x());
                        const int fromTop = abs(selectionPartRect.top() - eventPos.y());
                        const int fromBottom = abs(selectionPartRect.top() + selectionPartRect.height() - eventPos.y());
                        const int colScore = fromTop<fromBottom ? fromTop : fromBottom;
                        const int rowScore = fromLeft<fromRight ? fromLeft : fromRight;

                        if (colScore < rowScore) {
                            bool deleted=false;
                            for(int i=0; i<d->tableSelectionCols.length(); i++) {
                                const double col = (d->tableSelectionCols[i] - tsp.rectInSelection.left) / (tsp.rectInSelection.right - tsp.rectInSelection.left);
                                const int colX =  selectionPartRect.left() + col * selectionPartRect.width() + 0.5;
                                if (abs(colX - eventPos.x())<=3) {
                                    d->tableSelectionCols.removeAt(i);
                                    deleted=true;

                                    break;
                                }
                            }
                            if (!deleted) {
                                double col = eventPos.x() - selectionPartRect.left();
                                col /= selectionPartRect.width(); // at this point, it's normalised within the part
                                col *= (tsp.rectInSelection.right - tsp.rectInSelection.left);
                                col += tsp.rectInSelection.left; // at this point, it's normalised within the whole table

                                d->tableSelectionCols.append(col);
                                std::sort(d->tableSelectionCols.begin(), d->tableSelectionCols.end());
                            }
                        } else {
                            bool deleted=false;
                            for(int i=0; i<d->tableSelectionRows.length(); i++) {
                                const double row = (d->tableSelectionRows[i] - tsp.rectInSelection.top) / (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                                const int rowY =  selectionPartRect.top() + row * selectionPartRect.height() + 0.5;
                                if (abs(rowY - eventPos.y())<=3) {
                                    d->tableSelectionRows.removeAt(i);
                                    deleted=true;

                                    break;
                                }
                            }
                            if (!deleted) {
                                double row = eventPos.y() - selectionPartRect.top();
                                row /= selectionPartRect.height(); // at this point, it's normalised within the part
                                row *= (tsp.rectInSelection.bottom - tsp.rectInSelection.top);
                                row += tsp.rectInSelection.top; // at this point, it's normalised within the whole table

                                d->tableSelectionRows.append(row);
                                std::sort(d->tableSelectionRows.begin(), d->tableSelectionRows.end());
                            }
                        }
                    }
```

#### AUTO 


```{c}
auto a = newPagesVector[m_pageNumber]->annotation( m_annotation->uniqueName() );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Poppler::FontInfo &font : qAsConst(fonts))
    {
        Okular::FontInfo of;
        of.setName( font.name() );
#ifdef HAVE_POPPLER_0_80
        of.setSubstituteName( font.substituteName() );
#endif
        of.setType( convertPopplerFontInfoTypeToOkularFontInfoType( font.type() ) );
        of.setEmbedType( embedTypeForPopplerFontInfo( font) );
        of.setFile( font.file() );
        of.setCanBeExtracted( of.embedType() != Okular::FontInfo::NotEmbedded );

        QVariant nativeId;
        nativeId.setValue( font );
        of.setNativeId( nativeId );

        list.append( of );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Okular::ObjectRect *orect : orects) {
                        Okular::Annotation *ann = ((Okular::AnnotationObjectRect *)orect)->annotation();
                        if (ann && (ann->subType() != Okular::Annotation::AWidget))
                            popup.addAnnotation(ann, pageItem->pageNumber());
                    }
```

#### AUTO 


```{c}
auto PDFGeneratorNSSPasswordCallback = [&userCancelled](const char *element) -> char * {
        bool ok;
        const QString pwd = QInputDialog::getText(nullptr, i18n("Enter Password"), i18n("Enter password to open %1:", QString::fromUtf8(element)), QLineEdit::Password, QString(), &ok);
        *userCancelled = !ok;
        return ok ? strdup(pwd.toUtf8().constData()) : nullptr;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QModelIndex &index : indexes )
    {
        const QModelIndexList annotations = retrieveAnnotations(index);
        for ( const QModelIndex &idx : annotations )
        {
            const QModelIndex authorIndex = m_authorProxy->mapToSource( idx );
            const QModelIndex filterIndex = m_groupProxy->mapToSource( authorIndex );
            const QModelIndex annotIndex = m_filterProxy->mapToSource( filterIndex );
            Okular::Annotation *annotation = m_model->annotationForIndex( annotIndex );
            if ( annotation )
            {
                const int pageNumber = m_model->data( annotIndex, AnnotationModel::PageRole ).toInt();
                popup.addAnnotation( annotation, pageNumber );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(mEntries)) {
        if ( mArchive ) {
            const KArchiveFile *entry = static_cast<const KArchiveFile*>( mArchiveDir->entry( file ) );
            if ( entry ) {
                dev.reset( entry->createDevice() );
            }
        } else if ( mDirectory ) {
            dev.reset( mDirectory->createDevice( file ) );
        } else {
            dev.reset( mUnrar->createDevice( file ) );
        }

        if ( ! dev.isNull() ) {
            reader.setDevice( dev.data() );
            if ( reader.canRead() )
            {
                QSize pageSize = reader.size();
                if ( !pageSize.isValid() ) {
                    const QImage i = reader.read();
                    if ( !i.isNull() )
                        pageSize = i.size();
                }
                if ( pageSize.isValid() ) {
                    pagesVector->replace( count, new Okular::Page( count, pageSize.width(), pageSize.height(), Okular::Rotation0 ) );
                    mPageMap.append(file);
                    count++;
                } else {
                    qCDebug(OkularComicbookDebug) << "Ignoring" << file << "doesn't seem to be an image even if QImageReader::canRead returned true";
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Shell *shell : qAsConst(shells)) {
        QVERIFY(QTest::qWaitForWindowExposed(shell));
        numDocs += shell->m_tabs.size();
    }
```

#### AUTO 


```{c}
auto certDataLabel = new QLabel(i18n("Certificate Data:"));
```

#### RANGE FOR STATEMENT 


```{c}
for ( NormalizedPoint &np : m_transformedInplaceCallout ) {
       np.transform( matrix );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int pageNumber : qAsConst(*pagesToNotify)) {
            for (DocumentObserver *observer : qAsConst(m_observers)) {
                observer->notifyPageChanged(pageNumber, DocumentObserver::Highlights);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const pdfsyncpoint &pt : qAsConst(points)) {
        // drop pdfsync points not completely valid
        if (pt.page < 0 || pt.page >= m_pagesVector.size()) {
            continue;
        }

        // magic numbers for TeX's RSU's (Ridiculously Small Units) conversion to pixels
        Okular::NormalizedPoint p((pt.x * dpi.width()) / (72.27 * 65536.0 * m_pagesVector[pt.page]->width()), (pt.y * dpi.height()) / (72.27 * 65536.0 * m_pagesVector[pt.page]->height()));
        QString file = pt.file;
        Okular::SourceReference *sourceRef = new Okular::SourceReference(file, pt.row, pt.column);
        refRects[pt.page].append(new Okular::SourceRefObjectRect(p, sourceRef));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Okular::Annotation *a : annotations) {
            if (a->subType() == Okular::Annotation::AMovie) {
                Okular::MovieAnnotation *movieAnn = static_cast<Okular::MovieAnnotation *>(a);
                VideoWidget *vw = new VideoWidget(movieAnn, movieAnn->movie(), m_document, this);
                frame->videoWidgets.insert(movieAnn->movie(), vw);
                vw->pageInitialized();
            } else if (a->subType() == Okular::Annotation::ARichMedia) {
                Okular::RichMediaAnnotation *richMediaAnn = static_cast<Okular::RichMediaAnnotation *>(a);
                if (richMediaAnn->movie()) {
                    VideoWidget *vw = new VideoWidget(richMediaAnn, richMediaAnn->movie(), m_document, this);
                    frame->videoWidgets.insert(richMediaAnn->movie(), vw);
                    vw->pageInitialized();
                }
            } else if (a->subType() == Okular::Annotation::AScreen) {
                const Okular::ScreenAnnotation *screenAnn = static_cast<Okular::ScreenAnnotation *>(a);
                Okular::Movie *movie = GuiUtils::renditionMovieFromScreenAnnotation(screenAnn);
                if (movie) {
                    VideoWidget *vw = new VideoWidget(screenAnn, movie, m_document, this);
                    frame->videoWidgets.insert(movie, vw);
                    vw->pageInitialized();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for ( QAction * a : menu->actions() )
    {
        if ( a->isChecked() )
        {
            return a;
        }
        else if ( a->menu() )
        {
            QAction * b = checkedAction( a->menu() );
            if ( b )
            {
                return b;
            }
        }
    }
```

