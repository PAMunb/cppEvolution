#### AUTO 


```{c}
auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
```

#### LAMBDA EXPRESSION 


```{c}
[this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
```

#### AUTO 


```{c}
auto tmp = new NetworkModel::MyNIC;
```

#### LAMBDA EXPRESSION 


```{c}
[this, proc](int /* exitCode */, QProcess::ExitStatus exitStatus) {
        proc->deleteLater();

        switch (exitStatus) {
        case QProcess::CrashExit:
            return setError(xi18nc("@info", "The <command>%1</command> tool crashed while generating page content", m_executableName),
                            xi18nc("@Info", "Try again later. If keeps happening, please report the crash to your distribution."));
        case QProcess::NormalExit:
            break;
        }

        m_text = QString::fromLocal8Bit(proc->readAllStandardOutput());
        m_text = m_text.trimmed();
        m_originalLines = m_text.split('\n');
        if (!m_filter.isEmpty()) {
            // re-apply filter on new text
            setFilter(m_filter);
        }

        Q_EMIT textChanged();
        setReady();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) {
        int row = ui->infoGrid->rowCount();
        // Random sizes stolen from original UI file values :S
        ui->infoGrid->addItem(new QSpacerItem(17, 21, QSizePolicy::Minimum, QSizePolicy::Fixed), row, 1, 1, 1);
        ++row;
        ui->infoGrid->addWidget(new SectionLabel(text), row, 1, Qt::AlignLeft);
        ++row;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, compositorItem, interfacesItem] {
            Registry *registry = new Registry(this);
            EventQueue *queue = new EventQueue(this);
            queue->setup(m_connection);
            registry->setEventQueue(queue);
            connect(registry, &Registry::interfaceAnnounced, this,
                [this, interfacesItem] (QByteArray interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
            );
            connect(registry, &Registry::seatAnnounced, this,
                [this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Keyboard"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
            );
            QTreeWidgetItem *outputItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Outputs"));
            outputItem->setExpanded(true);
            connect(registry, &Registry::outputAnnounced, this,
                [this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
            );
            registry->create(m_connection);
            registry->setup();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto state : { QPalette::Active, QPalette::Inactive, QPalette::Disabled }) {
        pal.setBrush(state, QPalette::WindowText, pal.toolTipText());
        pal.setBrush(state, QPalette::Window, pal.toolTipBase());
    }
```

#### AUTO 


```{c}
auto addEntriesToGrid = [this](QList<QObject *> *list, const std::vector<Entry *> &entries) {
            for (auto entry : entries) {
                if (!entry->isValid()) {
                    delete entry; // since we do not keep it around
                    continue;
                }
                list->append(entry);
                m_entries.push_back(entry);
            }
        };
```

#### AUTO 


```{c}
auto *ifa = ifap;
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<HistoryReply>> reply = *watcher;
        watcher->deleteLater();
        m_values.clear();

        if (reply.isError()) {
            qWarning() << "Failed to get device history from UPower" << reply.error().message();
            return;
        }

        foreach (const HistoryReply &r, reply.value()) {
            if (r.value > 0) { //we get back some values which contain no value, possibly to indicate if charging changes, ignore them
                m_values.prepend(r);
            }
        }

        Q_EMIT dataChanged();
    }
```

#### AUTO 


```{c}
const auto dummyDistroDescriptionLabel = new QLabel(i18nc("@title:row", "Operating System:"), this);
```

#### AUTO 


```{c}
auto *battery = const_cast<Solid::Battery *>(device.as<Solid::Battery>());
```

#### AUTO 


```{c}
const auto devices = Solid::Device::listFromType(Solid::DeviceInterface::NetworkShare);
```

#### LAMBDA EXPRESSION 


```{c}
[&udi](const Solid::Device &dev) {return dev.udi() == udi;}
```

#### LAMBDA EXPRESSION 


```{c}
[this, compositorItem, interfacesItem] {
            Registry *registry = new Registry(this);
            EventQueue *queue = new EventQueue(this);
            queue->setup(m_connection);
            registry->setEventQueue(queue);
            connect(registry, &Registry::interfaceAnnounced, this,
                [this, interfacesItem] (const QByteArray &interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
            );
            connect(registry, &Registry::seatAnnounced, this,
                [this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
            );
            QTreeWidgetItem *outputItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Outputs"));
            outputItem->setExpanded(true);
            connect(registry, &Registry::outputAnnounced, this,
                [this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);
                            new QTreeWidgetItem(o, QStringList() << i18nc("The scale factor of the output", "Scale") << QString::number(output->scale()));

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
            );
            registry->create(m_connection);
            registry->setup();
        }
```

#### AUTO 


```{c}
auto it = m_foundExecutablePaths.cbegin();
```

#### AUTO 


```{c}
const auto &key
```

#### AUTO 


```{c}
auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
```

#### AUTO 


```{c}
static const auto dummyData = make_array<QString>(QStringLiteral("system version"),
                                                          QStringLiteral("system product name"),
                                                          QStringLiteral("system serial number"),
                                                          QStringLiteral("system manufacturer"),
                                                          QStringLiteral("to be filled by o.e.m."),
                                                          QStringLiteral("standard"), /* sometimes the version is useless */
                                                          QStringLiteral("sku"),
                                                          QStringLiteral("default string"),
                                                          QStringLiteral("not specified")
                                                          /* may also be empty, but that is filtered above already */);
```

#### AUTO 


```{c}
auto it = std::find_if(m_batteries.constBegin(), m_batteries.constEnd(), [&udi](const Solid::Device &dev) {
            return dev.udi() == udi;
        });
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral(PCI_BACKEND), {QStringLiteral(PCI_BACKEND_ARGUMENTS)}, parent);
```

#### AUTO 


```{c}
auto existingService = m_applicationInfo.find(name);
```

#### AUTO 


```{c}
const auto valueLabel = labelPair.second;
```

#### AUTO 


```{c}
auto it = std::find_if(m_batteries.constBegin(), m_batteries.constEnd(), [&udi](const Solid::Device &dev) {return dev.udi() == udi;});
```

#### AUTO 


```{c}
auto it = values.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](QString &str) {
					str = str.trimmed();
				}
```

#### AUTO 


```{c}
auto proc = new QProcess(this);
```

#### AUTO 


```{c}
auto k = seat->createKeyboard(seat);
```

#### AUTO 


```{c}
auto battery = m_batteries.at(index);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KService::Ptr &categoryModule : categoryList) {
        m_root->addChild(new KcmCategoryItem(categoryModule,m_root));
    }
```

#### AUTO 


```{c}
auto it = m_combinedData.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : m_entries) {
            text += entry->diagnosticLine(Entry::Language::System);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, avahi, watcher] {
        watcher->deleteLater();
        avahi->deleteLater();
        QDBusPendingReply<QString> reply = *watcher;
        if (reply.isError()) {
            // When Avahi isn't available there's not really a good way to resolve the FQDN. The user could drive
            // resolution through LLMNR or NetBios or some other ad-hoc system, neither provide us with an easy
            // way to get their configured FQDN. We are therefor opting to not render URLs in that scenario since
            // we can't get a name that will reliably work.
            m_fqdn.clear();
            return;
        }
        m_fqdn = reply.argumentAt(0).toString();
        Q_EMIT dataChanged(createIndex(0, 0), createIndex(m_list.count(), 0), {static_cast<int>(Role::ShareUrl)});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&udi](const Solid::Device &dev) {
            return dev.udi() == udi;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<HistoryReply>> reply = *watcher;
        watcher->deleteLater();
        m_values.clear();

        if (reply.isError()) {
            qWarning() << "Failed to get device history from UPower" << reply.error().message();
            return;
        }

        foreach (const HistoryReply &r, reply.value()) {
            if (r.value > 0) { // we get back some values which contain no value, possibly to indicate if charging changes, ignore them
                m_values.prepend(r);
            }
        }

        Q_EMIT dataChanged();
    }
```

#### AUTO 


```{c}
const auto displayName = i18n("Info Center");
```

#### AUTO 


```{c}
auto it = deviceForUdi(udi);
```

#### AUTO 


```{c}
auto addEntriesToGrid = [this](std::vector<const Entry *> entries)
    {
        int row = ui->infoGrid->rowCount();
        for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->localizedLabel()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->localizedValue()), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, interfacesItem] (QByteArray interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : sharedDirectories) {
        m_list += samba->getSharesByPath(path);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](std::vector<const Entry *> entries) {
        int row = ui->infoGrid->rowCount();
        for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->localizedLabel()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->localizedValue()), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : m_entries) {
            text += entry->diagnosticLine(Entry::Language::English);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &udi) {
        auto it = std::find_if(m_batteries.constBegin(), m_batteries.constEnd(), [&udi](const Solid::Device &dev) {
            return dev.udi() == udi;
        });
        if (it != m_batteries.constEnd()) {
            return;
        }

        const Solid::Device device(udi);
        if (device.isValid() && device.is<Solid::Battery>()) {
            beginInsertRows(QModelIndex(), m_batteries.count(), m_batteries.count());
            m_batteries.append(device);
            endInsertRows();

            emit countChanged();
        }
    }
```

#### AUTO 


```{c}
auto compositorItem = new QTreeWidgetItem(m_tree, QStringList() << i18n("Compositor Information"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : entries) {
                if (!entry->isValid()) {
                    delete entry; // since we do not keep it around
                    continue;
                }
                list->append(entry);
                m_entries.push_back(entry);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Keyboard"));
                            }
                        }
```

#### AUTO 


```{c}
auto state
```

#### AUTO 


```{c}
auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
```

#### AUTO 


```{c}
const auto role = static_cast<Role>(intRole);
```

#### AUTO 


```{c}
const auto freeSpace = storageInfo.bytesFree();
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_firmware_security"),
                                     i18nc("@label kcm name", "Firmware Security"),
                                     QStringLiteral("1.0"),
                                     QString(),
                                     KAboutLicense::GPL);
```

#### AUTO 


```{c}
auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text)
    {
        int row = ui->infoGrid->rowCount();
        // Random sizes stolen from original UI file values :S
        ui->infoGrid->addItem(new QSpacerItem(17, 21, QSizePolicy::Minimum, QSizePolicy::Fixed), row, 1, 1, 1);
        ++row;
        ui->infoGrid->addWidget(new SectionLabel(text), row, 1, Qt::AlignLeft);
        ++row;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &udi) {
        auto it = std::find_if(m_batteries.constBegin(), m_batteries.constEnd(), [&udi](const Solid::Device &dev) {
            return dev.udi() == udi;
        });
        if (it == m_batteries.constEnd()) {
            return;
        }

        int index = std::distance(m_batteries.constBegin(), it);

        beginRemoveRows(QModelIndex(), index, index);
        m_batteries.removeAt(index);
        endRemoveRows();

        emit countChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->label.toString()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->value), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
```

#### AUTO 


```{c}
auto it = devices.begin();
```

#### AUTO 


```{c}
const auto &path
```

#### AUTO 


```{c}
auto msg = QDBusMessage::createMethodCall(QStringLiteral("org.freedesktop.UPower"),
                                              m_device,
                                              QStringLiteral("org.freedesktop.UPower.Device"),
                                              QStringLiteral("GetHistory"));
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("lspci"), {QStringLiteral("-v")}, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
```

#### AUTO 


```{c}
auto *watcher = new QDBusPendingCallWatcher(reply, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &udi) {
        const int index = m_batteriesUdi.indexOf(udi);
        if (index < 0) {
            // we don't have that one
            return;
        }

        beginRemoveRows(QModelIndex(), index, index);
        m_batteries.removeAt(index);
        m_batteriesUdi.removeAt(index);
        endRemoveRows();

        emit countChanged();
    }
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_vulkan"), i18nc("@label kcm name", "Vulkan"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### LAMBDA EXPRESSION 


```{c}
[this](std::vector<const Entry *> entries)
    {
        int row = ui->infoGrid->rowCount();
        for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->localizedLabel()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->localizedValue()), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](libusb_device *dev) {
		int level = 0;
		for (libusb_device *p = libusb_get_parent(dev); p; p = libusb_get_parent(p)) {
			++level;
		}
		return level;
	}
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        for (int i = 0; i < m_tree->columnCount(); ++i) {
            m_tree->resizeColumnToContents(i);
        }
    }
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_interrupts"), i18nc("@label kcm name", "Interrupts"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### AUTO 


```{c}
auto title = new KTitleWidget(this);
```

#### AUTO 


```{c}
auto make_array(Input&&... args) -> std::array<Output, sizeof...(args)> // NB: we need suffix notation here so args is defined
{
    return {std::forward<Input>(args)...};
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
```

#### AUTO 


```{c}
auto it = processorMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : list) {
        const QString name = device.product();
        auto it = processorMap.find(name);
        if (it == processorMap.end()) {
            processorMap.insert(name, 1);
        } else {
            ++it.value();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : m_entries) {
        text += entry->diagnosticLine(Entry::Language::English);
    }
```

#### AUTO 


```{c}
auto aboutData = new KAboutData;
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<WakeUpReply>> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qWarning() << "Failed to get wakeup statistics from UPower";
            return;
        }

        const bool resetModel = m_data.isEmpty();

        if (resetModel) {
            beginResetModel();
        }

        m_total = 0.0;
        m_combinedData.clear();
        m_data.clear();

        auto values = reply.value();

        for (auto it = values.constBegin(); it != values.constEnd(); ++it) {
            if (!(*it).fromUserSpace) {
                continue;
            }
            const QString appName = (*it).cmdline.split(QLatin1Char(' '), QString::SkipEmptyParts).first(); // ugly
            if (!m_combinedData.contains(appName)) {
                m_combinedData[appName].name = appName;
                m_combinedData[appName].userSpace = (*it).fromUserSpace;
            }
            m_combinedData[appName].wakeUps += (*it).wakeUpsPerSecond;
            if ((*it).id) {
                m_combinedData[appName].pid = (*it).id;
            }
            if (!(*it).details.isEmpty()) {
                m_combinedData[appName].details = (*it).details;
            }
            m_total += (*it).wakeUpsPerSecond;
        }

        for (auto it = m_combinedData.begin(); it != m_combinedData.end(); ++it) {
            const QString &name = (*it).name;

            auto existingService = m_applicationInfo.find(name);
            if (existingService != m_applicationInfo.end()) {
                (*it).prettyName = (*existingService).first;
                (*it).iconName = (*existingService).second;
            } else {
                KService::Ptr service = KService::serviceByStorageId(name + ".desktop");
                if (service) {
                    it->prettyName = service->property("Name", QVariant::Invalid).toString();
                    it->iconName = service->icon();

                    m_applicationInfo.insert(name, qMakePair((*it).prettyName, (*it).iconName));
                } else {
                    // use the app name as fallback icon
                    (*it).iconName = name.split(QLatin1Char('/'), QString::SkipEmptyParts).last().toLower();
                }
            }

            m_data.append((*it));
        }

        m_combinedData.clear();

        std::sort(m_data.begin(), m_data.end(), [](const WakeUpData &a, const WakeUpData &b) {
            return a.wakeUps > b.wakeUps;
        });

        emit totalChanged();
        emit countChanged();

        if (resetModel) {
            endResetModel();
        } else {
            emit dataChanged(index(0, 0), index(s_maximumEntries - 1, 0));
        }
    }
```

#### AUTO 


```{c}
auto entry
```

#### AUTO 


```{c}
const auto string = ki18nc("@label %1 is the formatted amount of system memory (e.g. 7,7 GiB)", "%1 of RAM")
                                .subs(KFormat(localeForLanguage(language)).formatByteSize(totalRam));
```

#### LAMBDA EXPRESSION 


```{c}
[this, compositorItem, interfacesItem] {
            Registry *registry = new Registry(this);
            EventQueue *queue = new EventQueue(registry);
            queue->setup(m_connection);
            registry->setEventQueue(queue);
            connect(registry, &Registry::interfaceAnnounced, this,
                [this, interfacesItem] (const QByteArray &interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
            );
            connect(registry, &Registry::seatAnnounced, this,
                [this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
            );
            QTreeWidgetItem *outputItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Outputs"));
            outputItem->setExpanded(true);
            connect(registry, &Registry::outputAnnounced, this,
                [this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);
                            new QTreeWidgetItem(o, QStringList() << i18nc("The scale factor of the output", "Scale") << QString::number(output->scale()));

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
            );
            m_registry = registry;
            registry->create(m_connection);
            registry->setup();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : {QStringLiteral("system-manufacturer"),
                            QStringLiteral("system-product-name"),
                            QStringLiteral("system-version"),
                            QStringLiteral("system-serial-number")}) {
        QProcess proc;
        proc.start(dmidecode, {QStringLiteral("--string"), key});
        proc.waitForFinished();
        const QByteArray output = proc.readAllStandardOutput().trimmed();

        if (output.isEmpty() || proc.error() != QProcess::UnknownError || proc.exitStatus() != QProcess::NormalExit) {
            continue;
        }

        // Fairly exhaustive filter list based on a dozen or so samples gathered from reddit and other places.
        // These are values that may appear in the DMI system information but aren't really useful.
        static const auto dummyData = make_array<QString>(QStringLiteral("system version"),
                                                          QStringLiteral("system product name"),
                                                          QStringLiteral("system serial number"),
                                                          QStringLiteral("system manufacturer"),
                                                          QStringLiteral("to be filled by o.e.m."),
                                                          QStringLiteral("standard"), /* sometimes the version is useless */
                                                          QStringLiteral("sku"),
                                                          QStringLiteral("default string"),
                                                          QStringLiteral("not specified")
                                                          /* may also be empty, but that is filtered above already */);
        if (std::find(dummyData.cbegin(), dummyData.cend(), output.toLower()) != dummyData.cend()) {
            continue;
        }

        reply.addData(key, output);
    }
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_glx"), i18nc("@label kcm name", "OpenGL (GLX)"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### AUTO 


```{c}
const auto valueLabelText = valueLabel->text();
```

#### AUTO 


```{c}
const auto nic = m_nics.at(index.row());
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_egl"), i18nc("@label kcm name", "OpenGL (EGL)"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### AUTO 


```{c}
const auto devices = Solid::Device::listFromType(Solid::DeviceInterface::Battery);
```

#### LAMBDA EXPRESSION 


```{c}
[this, interfacesItem] (const QByteArray &interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
```

#### AUTO 


```{c}
const auto samba = KSambaShare::instance();
```

#### AUTO 


```{c}
auto addSectionHeader = [this](const QString &text) {
        int row = ui->infoGrid->rowCount();
        // Random sizes stolen from original UI file values :S
        ui->infoGrid->addItem(new QSpacerItem(17, 21, QSizePolicy::Minimum, QSizePolicy::Fixed), row, 1, 1, 1);
        ++row;
        ui->infoGrid->addWidget(new SectionLabel(text), row, 1, Qt::AlignLeft);
        ++row;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &kcmModule : moduleList) {
        if (kcmModule->isType(KST_KService) == true) {

            QString category = kcmModule->property(QStringLiteral("X-KDE-KInfoCenter-Category")).toString().trimmed();

            if(!category.isEmpty() || !category.isNull()) {
                KcmTreeItem *item = m_root->containsCategory(category);
                if(item != nullptr) {
                    item->addChild(new KcmTreeItem(kcmModule,item));
                } else {
                    KcmTreeItem *lost = m_root->containsCategory(QStringLiteral("lost_and_found"));
                    if(lost != nullptr) {
                        lost->addChild(new KcmTreeItem(kcmModule,lost));
                    } else {
                        qWarning() << "Lost and found category not found, unable to display lost Kcontrol modules";
                    }
                }
            } else {
                m_root->addChild(new KcmTreeItem(kcmModule,m_root));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : samba->sharedDirectories()) {
        m_list += samba->getSharesByPath(path);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto labelPair : qAsConst(labelsForClipboard)) {
        const auto valueLabel = labelPair.second;
        if (!valueLabel->isHidden()) {
            const auto descriptionLabelText = labelPair.first->text();
            const auto valueLabelText = valueLabel->text();
            text += i18nc("%1 is a label already including a colon, %2 is the corresponding value", "%1 %2", descriptionLabelText, valueLabelText) + QStringLiteral("\n");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->localizedLabel()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->localizedValue()), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, proc](int /* exitCode */, QProcess::ExitStatus exitStatus) {
        proc->deleteLater();

        switch (exitStatus) {
        case QProcess::CrashExit:
            return setError(xi18nc("@info", "The subprocess <command>%1</command> crashed unexpectedly. No data could be obtained.", m_executableName));
        case QProcess::NormalExit:
            break;
        }

        m_text = QString::fromLocal8Bit(proc->readAllStandardOutput());
        m_originalLines = m_text.split('\n');
        if (!m_filter.isEmpty()) {
            // re-apply filter on new text
            setFilter(m_filter);
        }

        Q_EMIT textChanged();
        setReady();
    }
```

#### AUTO 


```{c}
auto levels = [](libusb_device *dev) {
        int level = 0;
        for (libusb_device *p = libusb_get_parent(dev); p; p = libusb_get_parent(p)) {
            ++level;
        }
        return level;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&udi](const Solid::Device &device) {
            return device.udi() == udi;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](libusb_device *dev) {
        int level = 0;
        for (libusb_device *p = libusb_get_parent(dev); p; p = libusb_get_parent(p)) {
            ++level;
        }
        return level;
    }
```

#### AUTO 


```{c}
auto r = OSRelease(QFINDTESTDATA("data/os-release"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : infos) {
                    l3 = newItem(l2, l3, info.deviceId);
                    l3->setExpanded(true);
                    makeDriItem(info, l3, nullptr);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, compositorItem, interfacesItem] {
            Registry *registry = new Registry(this);
            EventQueue *queue = new EventQueue(registry);
            queue->setup(m_connection);
            registry->setEventQueue(queue);
            connect(registry, &Registry::interfaceAnnounced, this,
                [this, interfacesItem] (const QByteArray &interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << QString::fromLatin1(interface) << QString::number(version));
                }
            );
            connect(registry, &Registry::seatAnnounced, this,
                [this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
            );
            QTreeWidgetItem *outputItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Outputs"));
            outputItem->setExpanded(true);
            connect(registry, &Registry::outputAnnounced, this,
                [this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);
                            new QTreeWidgetItem(o, QStringList() << i18nc("The scale factor of the output", "Scale") << QString::number(output->scale()));

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
            );
            m_registry = registry;
            registry->create(m_connection);
            registry->setup();
        }
```

#### AUTO 


```{c}
auto proc = new QProcess;
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("vulkaninfo"), {}, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<WakeUpReply>> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qWarning() << "Failed to get wakeup statistics from UPower";
            return;
        }

        const bool resetModel = m_data.isEmpty();

        if (resetModel) {
            beginResetModel();
        }

        m_total = 0.0;
        m_combinedData.clear();
        m_data.clear();

        auto values = reply.value();

        for (auto it = values.constBegin(); it != values.constEnd(); ++it) {
            if (!(*it).fromUserSpace) {
                continue;
            }
            const QString appName = (*it).cmdline.split(QLatin1Char(' '), Qt::SkipEmptyParts).first(); // ugly
            if (!m_combinedData.contains(appName)) {
                m_combinedData[appName].name = appName;
                m_combinedData[appName].userSpace = (*it).fromUserSpace;
            }
            m_combinedData[appName].wakeUps += (*it).wakeUpsPerSecond;
            if ((*it).id) {
                m_combinedData[appName].pid = (*it).id;
            }
            if (!(*it).details.isEmpty()) {
                m_combinedData[appName].details = (*it).details;
            }
            m_total += (*it).wakeUpsPerSecond;
        }

        for (auto it = m_combinedData.begin(); it != m_combinedData.end(); ++it) {
            const QString &name = (*it).name;

            auto existingService = m_applicationInfo.find(name);
            if (existingService != m_applicationInfo.end()) {
                (*it).prettyName = (*existingService).first;
                (*it).iconName = (*existingService).second;
            } else {
                KService::Ptr service = KService::serviceByStorageId(name + ".desktop");
                if (service) {
                    it->prettyName = service->property(QStringLiteral("Name"), QVariant::Invalid).toString();
                    it->iconName = service->icon();

                    m_applicationInfo.insert(name, qMakePair((*it).prettyName, (*it).iconName));
                } else {
                    // use the app name as fallback icon
                    (*it).iconName = name.split(QLatin1Char('/'), Qt::SkipEmptyParts).last().toLower();
                }
            }

            m_data.append((*it));
        }

        m_combinedData.clear();

        std::sort(m_data.begin(), m_data.end(), [](const WakeUpData &a, const WakeUpData &b) {
            return a.wakeUps > b.wakeUps;
        });

        emit totalChanged();
        emit countChanged();

        if (resetModel) {
            endResetModel();
        } else {
            emit dataChanged(index(0, 0), index(s_maximumEntries - 1, 0));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        QDBusPendingReply<QList<WakeUpReply>> reply = *watcher;
        watcher->deleteLater();

        if (reply.isError()) {
            qWarning() << "Failed to get wakeup statistics from UPower";
            return;
        }

        const bool resetModel = m_data.isEmpty();

        if (resetModel) {
            beginResetModel();
        }

        m_total = 0.0;
        m_combinedData.clear();
        m_data.clear();

        auto values = reply.value();

        for (auto it = values.constBegin(); it != values.constEnd(); ++it) {
            if (!(*it).fromUserSpace) {
                continue;
            }
            const QString appName = (*it).cmdline.split(QLatin1Char(' '), QString::SkipEmptyParts).first(); // ugly
            if (!m_combinedData.contains(appName)) {
                m_combinedData[appName].name = appName;
                m_combinedData[appName].userSpace = (*it).fromUserSpace;
            }
            m_combinedData[appName].wakeUps += (*it).wakeUpsPerSecond;
            if ((*it).id) {
                m_combinedData[appName].pid = (*it).id;
            }
            if (!(*it).details.isEmpty()) {
                m_combinedData[appName].details = (*it).details;
            }
            m_total += (*it).wakeUpsPerSecond;
        }

        for (auto it = m_combinedData.begin(); it != m_combinedData.end(); ++it) {
            const QString &name = (*it).name;

            auto existingService = m_applicationInfo.find(name);
            if (existingService != m_applicationInfo.end()) {
                (*it).prettyName = (*existingService).first;
                (*it).iconName = (*existingService).second;
            } else {
                KService::Ptr service = KService::serviceByStorageId(name + ".desktop");
                if (service) {
                    it->prettyName = service->property(QStringLiteral("Name"), QVariant::Invalid).toString();
                    it->iconName = service->icon();

                    m_applicationInfo.insert(name, qMakePair((*it).prettyName, (*it).iconName));
                } else {
                    // use the app name as fallback icon
                    (*it).iconName = name.split(QLatin1Char('/'), QString::SkipEmptyParts).last().toLower();
                }
            }

            m_data.append((*it));
        }

        m_combinedData.clear();

        std::sort(m_data.begin(), m_data.end(), [](const WakeUpData &a, const WakeUpData &b) {
            return a.wakeUps > b.wakeUps;
        });

        emit totalChanged();
        emit countChanged();

        if (resetModel) {
            endResetModel();
        } else {
            emit dataChanged(index(0, 0), index(s_maximumEntries - 1, 0));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        KWindowSystem::forceActiveWindow(display->winId());
    }
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("eglinfo"), {}, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &udi) {

        auto it = std::find_if(m_batteries.constBegin(), m_batteries.constEnd(), [&udi](const Solid::Device &dev) {return dev.udi() == udi;});
        if (it != m_batteries.constEnd()) {
            return;
        }

        const Solid::Device device(udi);
        if (device.isValid() && device.is<Solid::Battery>()) {
            beginInsertRows(QModelIndex(), m_batteries.count(), m_batteries.count());
            m_batteries.append(device);
            endInsertRows();

            emit countChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QList<QObject *> *list, const std::vector<Entry *> &entries) {
            for (auto entry : entries) {
                if (!entry->isValid()) {
                    delete entry; // since we do not keep it around
                    continue;
                }
                list->append(entry);
                m_entries.push_back(entry);
            }
        }
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_pci"), i18nc("@label kcm name", "PCI"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### LAMBDA EXPRESSION 


```{c}
[this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Keyboard"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
```

#### AUTO 


```{c}
auto watcher = new QDBusPendingCallWatcher(avahi->GetHostNameFqdn(), this);
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("lscpu"), {}, parent);
```

#### AUTO 


```{c}
auto dialog = new KPropertiesDialog(QUrl::fromUserInput(m_list.at(index).path()), QApplication::activeWindow());
```

#### LAMBDA EXPRESSION 


```{c}
[this, compositorItem, interfacesItem] {
            Registry *registry = new Registry(this);
            EventQueue *queue = new EventQueue(this);
            queue->setup(m_connection);
            registry->setEventQueue(queue);
            connect(registry, &Registry::interfaceAnnounced, this,
                [this, interfacesItem] (QByteArray interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
            );
            connect(registry, &Registry::seatAnnounced, this,
                [this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
            );
            QTreeWidgetItem *outputItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Outputs"));
            outputItem->setExpanded(true);
            connect(registry, &Registry::outputAnnounced, this,
                [this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
            );
            registry->create(m_connection);
            registry->setup();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &findExecutable : findExecutables) {
        m_foundExecutablePaths[findExecutable] = QStandardPaths::findExecutable(findExecutable);
    }
```

#### AUTO 


```{c}
const auto usedSpace = size - freeSpace;
```

#### AUTO 


```{c}
auto levels = [](libusb_device *dev) {
		int level = 0;
		for (libusb_device *p = libusb_get_parent(dev); p; p = libusb_get_parent(p)) {
			++level;
		}
		return level;
	};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &item : list) {
        if (!item.isEmpty()) {
            bLabel = new QLabel(item);
            bLabel->setWordWrap(true);
            if (bLabel->text() != QLatin1String("--")) {
                if (toggle) {
                    toggle = false;
                    bLabel->setFont(labelFont);
                } else {
                    bLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
                    bLabel->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);
                    bLabel->setAlignment(Qt::AlignTop);
                    toggle = true;
                }
            } else {
                bLabel->setText(QLatin1String(""));
            }
            addWidget(bLabel);
        }
    }
```

#### AUTO 


```{c}
auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
```

#### AUTO 


```{c}
auto resizeColumns = [this] {
        for (int i = 0; i < m_tree->columnCount(); ++i) {
            m_tree->resizeColumnToContents(i);
        }
    };
```

#### AUTO 


```{c}
auto labelPair
```

#### AUTO 


```{c}
auto view = new QTableView(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
```

#### AUTO 


```{c}
auto addSectionHeader = [this](const QString &text)
    {
        int row = ui->infoGrid->rowCount();
        // Random sizes stolen from original UI file values :S
        ui->infoGrid->addItem(new QSpacerItem(17, 21, QSizePolicy::Minimum, QSizePolicy::Fixed), row, 1, 1, 1);
        ++row;
        ui->infoGrid->addWidget(new SectionLabel(text), row, 1, Qt::AlignLeft);
        ++row;
    };
```

#### AUTO 


```{c}
auto outputContext =
#if defined(Q_OS_FREEBSD)
            new CommandOutputContext(QStringLiteral("vmstat"), {QStringLiteral("-i")}, parent);
#else
            new CommandOutputContext(QStringLiteral("cat"), {QStringLiteral("/proc/interrupts")}, parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);
                            new QTreeWidgetItem(o, QStringList() << i18nc("The scale factor of the output", "Scale") << QString::number(output->scale()));

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("xdpyinfo"), {}, parent);
```

#### AUTO 


```{c}
auto *service = new KDBusService(KDBusService::Unique, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](std::vector<const Entry *> entries)
    {
        int row = ui->infoGrid->rowCount();
        for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->label.toString()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->value), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Solid::Device &device : m_cpus) {
        const QString name = device.product();
        auto it = processorMap.find(name);
        if (it == processorMap.end()) {
            processorMap.insert(name, 1);
        } else {
            ++it.value();
        }
    }
```

#### AUTO 


```{c}
const auto &mode
```

#### AUTO 


```{c}
auto it = m_values.constBegin(), end = m_values.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this, proc](int /* exitCode */, QProcess::ExitStatus exitStatus) {
        proc->deleteLater();

        switch (exitStatus) {
        case QProcess::CrashExit:
            return setError(xi18nc("@info", "The subprocess <command>%1</command> crashed unexpectedly. No data could be obtained.", m_executableName));
        case QProcess::NormalExit:
            break;
        }

        m_text = QString::fromLocal8Bit(proc->readAllStandardOutput());
        m_text = m_text.trimmed();
        m_originalLines = m_text.split('\n');
        if (!m_filter.isEmpty()) {
            // re-apply filter on new text
            setFilter(m_filter);
        }

        Q_EMIT textChanged();
        setReady();
    }
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_xserver"), i18nc("@label kcm name", "X-Server"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### AUTO 


```{c}
auto addEntriesToGrid = [this](std::vector<const Entry *> entries) {
        int row = ui->infoGrid->rowCount();
        for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->localizedLabel()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->localizedValue()), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
    };
```

#### AUTO 


```{c}
auto it = processorMap.find(name);
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_wayland"), i18nc("@label kcm name", "Wayland"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### AUTO 


```{c}
auto interfacesItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Interfaces") << i18n("Interface Version"));
```

#### AUTO 


```{c}
const auto descriptionLabelText = labelPair.first->text();
```

#### AUTO 


```{c}
const auto usedPercent = static_cast<int>((usedSpace * 100) / size);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &udi) {
        auto it = std::find_if(m_batteries.constBegin(), m_batteries.constEnd(), [&udi](const Solid::Device &dev) {return dev.udi() == udi;});
        if (it == m_batteries.constEnd()) {
            return;
        }

        int index = std::distance(m_batteries.constBegin(), it);


        beginRemoveRows(QModelIndex(), index, index);
        m_batteries.removeAt(index);
        endRemoveRows();

        emit countChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, interfacesItem] (const QByteArray &interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << QString::fromLatin1(interface) << QString::number(version));
                }
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("wayland-info"), {}, parent);
```

#### AUTO 


```{c}
const auto &info
```

#### LAMBDA EXPRESSION 


```{c}
[](const WakeUpData &a, const WakeUpData &b) {
            return a.wakeUps > b.wakeUps;
        }
```

#### AUTO 


```{c}
auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
```

#### LAMBDA EXPRESSION 


```{c}
[this, compositorItem, interfacesItem] {
            Registry *registry = new Registry(this);
            EventQueue *queue = new EventQueue(this);
            queue->setup(m_connection);
            registry->setEventQueue(queue);
            connect(registry, &Registry::interfaceAnnounced, this,
                [this, interfacesItem] (QByteArray interface, quint32 name, quint32 version) {
                    Q_UNUSED(name)
                    new QTreeWidgetItem(interfacesItem, QStringList() << interface << QString::number(version));
                }
            );
            connect(registry, &Registry::seatAnnounced, this,
                [this, registry, compositorItem] (quint32 name, quint32 version) {
                    QTreeWidgetItem *seatItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Seat") << QString());
                    seatItem->setExpanded(true);
                    Seat *seat = registry->createSeat(name, version, registry);
                    connect(seat, &Seat::nameChanged, this,
                        [this, seat, seatItem] {
                            new QTreeWidgetItem(seatItem, QStringList() << i18n("Name") << seat->name());
                        }
                    );
                    connect(seat, &Seat::hasPointerChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasPointer()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Pointer"));
                            }
                        }
                    );
                    connect(seat, &Seat::hasKeyboardChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasKeyboard()) {
                                auto i = new QTreeWidgetItem(seatItem, QStringList{i18n("Keyboard")});
                                i->setExpanded(true);
                                auto e = new QTreeWidgetItem(i, QStringList{i18n("Repeat enabled")});
                                auto r = new QTreeWidgetItem(i, QStringList{i18n("Repeat rate (characters per second)")});
                                auto d = new QTreeWidgetItem(i, QStringList{i18n("Repeat delay (msec)")});
                                auto k = seat->createKeyboard(seat);
                                connect(k, &Keyboard::keyRepeatChanged, this,
                                        [this, k, e, r, d] {
                                            e->setText(1, k->isKeyRepeatEnabled() ? i18n("Yes") : i18n("No"));
                                            r->setText(1, QString::number(k->keyRepeatRate()));
                                            d->setText(1, QString::number(k->keyRepeatDelay()));
                                        }
                                );
                            }
                        }
                    );
                    connect(seat, &Seat::hasTouchChanged, this,
                        [this, seat, seatItem] {
                            if (seat->hasTouch()) {
                                new QTreeWidgetItem(seatItem, QStringList() << i18n("Touch"));
                            }
                        }
                    );
                }
            );
            QTreeWidgetItem *outputItem = new QTreeWidgetItem(compositorItem, QStringList() << i18n("Outputs"));
            outputItem->setExpanded(true);
            connect(registry, &Registry::outputAnnounced, this,
                [this, registry, outputItem] (quint32 name, quint32 version) {
                    Output *output = registry->createOutput(name, version, registry);
                    connect(output, &Output::changed, this,
                        [this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);
                            new QTreeWidgetItem(o, QStringList() << i18nc("The scale factor of the output", "Scale") << QString::number(output->scale()));

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
                    );
                }
            );
            registry->create(m_connection);
            registry->setup();
        }
```

#### AUTO 


```{c}
auto avahi = new OrgFreedesktopAvahiServerInterface(QStringLiteral("org.freedesktop.Avahi"), QStringLiteral("/"), QDBusConnection::systemBus(), this);
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext({QStringLiteral("fwupdmgr"), QStringLiteral("aha")},
                                                      QStringLiteral("/bin/sh"),
                                                      {package.path() + QStringLiteral("contents/code/fwupdmgr.sh")},
                                                      parent);
```

#### AUTO 


```{c}
auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
```

#### AUTO 


```{c}
auto it = m_values.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, avahi, watcher] {
        watcher->deleteLater();
        avahi->deleteLater();
        QDBusPendingReply<QString> reply = *watcher;
        if (reply.isError()) {
            // When Avahi isn't available there's not really a good way to resolve the FQDN. The user could drive
            // resolution through LLMNR or NetBios or some other ad-hoc system, neither provide us with an easy
            // way to get their configured FQDN. We are therefor opting to not render URLs in that scenario since
            // we can't get a name that will reliably work.
            m_fqdn.clear();
            return;
        }
        m_fqdn = reply.argumentAt(0).toString();
        Q_EMIT dataChanged(createIndex(0, 0), createIndex(m_list.count(), 0), { static_cast<int>(Role::ShareUrl) });
    }
```

#### AUTO 


```{c}
const auto battery = m_batteries.value(index.row()).as<Solid::Battery>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : std::as_const(m_originalLines)) {
            if (line.contains(filter, Qt::CaseInsensitive)) {
                m_text += line + '\n';
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](QString &str) {
                    str = str.trimmed();
                }
```

#### AUTO 


```{c}
auto values = reply.value();
```

#### AUTO 


```{c}
auto outputContext = new CommandOutputContext(QStringLiteral("glxinfo"), {}, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : m_entries) {
        text += entry->diagnosticLine(Entry::Language::System);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : m_originalLines) {
            if (line.contains(filter, Qt::CaseInsensitive)) {
                m_text += line + '\n';
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, output, outputItem] {
                            output->deleteLater();
                            const QSize s = output->physicalSize();
                            const QPoint p = output->globalPosition();

                            auto o = new QTreeWidgetItem(outputItem, QStringList() << QString::number(outputItem->childCount()));
                            o->setExpanded(true);

                            new QTreeWidgetItem(o, QStringList() << i18n("Manufacturer") << output->manufacturer());
                            new QTreeWidgetItem(o, QStringList() << i18n("Model") << output->model());
                            new QTreeWidgetItem(o, QStringList() << i18n("Physical Size") << QStringLiteral("%1x%2").arg(s.width()).arg(s.height()));
                            new QTreeWidgetItem(o, QStringList() << i18n("Global Position") << QStringLiteral("%1/%2").arg(p.x()).arg(p.y()));

                            QString subPixel;
                            switch (output->subPixel()) {
                            case Output::SubPixel::None:
                                subPixel = i18n("None");
                                break;
                            case Output::SubPixel::HorizontalRGB:
                                subPixel = i18n("Horizontal RGB");
                                break;
                            case Output::SubPixel::HorizontalBGR:
                                subPixel = i18n("Horizontal BGR");
                                break;
                            case Output::SubPixel::VerticalRGB:
                                subPixel = i18n("Vertical RGB");
                                break;
                            case Output::SubPixel::VerticalBGR:
                                subPixel = i18n("Vertical BGR");
                                break;
                            case Output::SubPixel::Unknown:
                            default:
                                subPixel = i18n("Unknown");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Subpixel") << subPixel);

                            QString transform;
                            switch (output->transform()) {
                            case Output::Transform::Rotated90:
                                transform = QStringLiteral("90");
                                break;
                            case Output::Transform::Rotated180:
                                transform = QStringLiteral("180");
                                break;
                            case Output::Transform::Rotated270:
                                transform = QStringLiteral("270");
                                break;
                            case Output::Transform::Flipped:
                                transform = i18n("Flipped");
                                break;
                            case Output::Transform::Flipped90:
                                transform = i18n("Flipped 90");
                                break;
                            case Output::Transform::Flipped180:
                                transform = i18n("Flipped 180");
                                break;
                            case Output::Transform::Flipped270:
                                transform = i18n("Flipped 270");
                                break;
                            case Output::Transform::Normal:
                            default:
                                transform = i18n("Normal");
                                break;
                            }
                            new QTreeWidgetItem(o, QStringList() << i18n("Transform") << transform);
                            new QTreeWidgetItem(o, QStringList() << i18nc("The scale factor of the output", "Scale") << QString::number(output->scale()));

                            // add Modes
                            auto modesItem = new QTreeWidgetItem(o, QStringList() << i18n("Modes"));
                            int i = 0;
                            for (const auto &mode : output->modes()) {
                                auto modeItem = new QTreeWidgetItem(modesItem, QStringList() << QString::number(i++));
                                modeItem->setExpanded(true);
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Size")
                                                                            << QStringLiteral("%1x%2").arg(mode.size.width()).arg(mode.size.height()));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Refresh Rate")
                                                                            << QString::number(mode.refreshRate));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Preferred")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Preferred) ? i18n("yes") : i18n("no")));
                                new QTreeWidgetItem(modeItem, QStringList() << i18n("Current")
                                                                            << (mode.flags.testFlag(Output::Mode::Flag::Current) ? i18n("yes") : i18n("no")));
                            }
                        }
```

#### AUTO 


```{c}
auto *about = new KAboutData(QStringLiteral("kcm_cpu"), i18nc("@label kcm name", "CPU"), QStringLiteral("1.0"), QString(), KAboutLicense::GPL);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &udi) {
        if (m_batteriesUdi.contains(udi)) {
            // we already know that one
            return;
        }

        const Solid::Device device(udi);
        if (device.isValid()) {
            auto *battery = const_cast<Solid::Battery *>(device.as<Solid::Battery>());
            if (battery) {
                beginInsertRows(QModelIndex(), m_batteries.count(), m_batteries.count());
                m_batteries.append(battery);
                // FIXME Fix Solid so it exposes the base device interface properties too
                m_batteriesUdi.append(device.udi());
                endInsertRows();

                emit countChanged();
            }
        }
    }
```

#### AUTO 


```{c}
auto avahi = new OrgFreedesktopAvahiServerInterface(QStringLiteral("org.freedesktop.Avahi"),
                                                        QStringLiteral("/"),
                                                        QDBusConnection::systemBus(),
                                                        this);
```

#### AUTO 


```{c}
auto addEntriesToGrid = [this](std::vector<const Entry *> entries)
    {
        int row = ui->infoGrid->rowCount();
        for (auto entry : entries) {
            if (!entry->isValid()) {
                delete entry; // since we do not keep it around
                continue;
            }
            ui->infoGrid->addWidget(new QLabel(entry->label.toString()), row, 0, Qt::AlignRight);
            ui->infoGrid->addWidget(new QLabel(entry->value), row, 1, Qt::AlignLeft);
            m_entries.push_back(entry);
            ++row;
        }
    };
```

#### AUTO 


```{c}
const auto string = ki18nc("@label %1 is the formatted amount of system memory (e.g. 7,7 GiB)",
                                   "%1 of RAM").subs(KFormat(localeForLanguage(language)).formatByteSize(totalRam));
```

