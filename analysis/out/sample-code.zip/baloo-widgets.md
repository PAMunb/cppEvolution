#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_items)) {
        QUrl url = item.targetUrl();
        if (!url.isLocalFile()) {
            continue;
        }
        KFileMetaData::UserMetaData md(url.toLocalFile());
        md.setRating(rating);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : m_tags) {
        modifyTagWidget(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_items) {
            KFileMetaData::UserMetaData md(filePath);

            // When multiple tags are selected one doesn't want to loose the old tags
            // of any of the resources. Unless specifically removed.
            QStringList newTags = md.tags() + tags;
            newTags.removeDuplicates();

            for (const QString& tag : m_prevTags) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
            md.setTags(newTags);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_items)) {
            QUrl url = item.targetUrl();
            if (!url.isLocalFile()) {
                continue;
            }
            KFileMetaData::UserMetaData md(url.toLocalFile());

            // When multiple tags are selected one doesn't want to loose the old tags
            // of any of the resources. Unless specifically removed.
            QStringList newTags = md.tags() + tags;
            newTags.removeDuplicates();

            for (const QString& tag : m_prevTags) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
            md.setTags(newTags);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileMetaDataWidgetPrivate::Row &row : std::as_const(d->m_rows)) {
        const QWidget *valueWidget = row.value;
        const int rightWidth = valueWidget->sizeHint().width();
        rightWidthAverage += rightWidth;
        if (rightWidth > rightWidthMax) {
            rightWidthMax = rightWidth;
        }

        const int leftWidth = row.label->sizeHint().width();
        if (leftWidth > leftWidthMax) {
            leftWidthMax = leftWidth;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: keys) {
        settings.writeEntry(key, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_items)) {
        QUrl url = item.targetUrl();
        if (!url.isLocalFile()) {
            continue;
        }
        KFileMetaData::UserMetaData md(url.toLocalFile());
        md.setUserComment(comment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : qAsConst(m_allTags)) {
        modifyTagWidget(tag);
    }
```

#### AUTO 


```{c}
const auto height = m_data.value(QStringLiteral("height"));
```

#### AUTO 


```{c}
const auto widget = new Baloo::FileMetaDataWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : parser.positionalArguments()) {
        QFileInfo fi(path);
        list << KFileItem(QUrl::fromLocalFile(fi.absoluteFilePath()), QString(), mode_t());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_fileItems)) {
        const QUrl url = item.targetUrl();
        if (url.isLocalFile() && !item.isSlow()) {
            urls << url.toLocalFile();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& propUri : qAsConst(allProperties)) {
        for (const QVariantMap& map : qAsConst(propertyList)) {
            QVariantMap::const_iterator it = map.find(propUri);
            if (it == map.constEnd()) {
                m_data.remove(propUri);
                break;
            }

            QVariantMap::iterator dit = m_data.find(it.key());
            if (dit == m_data.end()) {
                m_data.insert(propUri, it.value());
            } else {
                QVariant finalValue = intersect(it.value(), dit.value());
                if (finalValue.isValid()) {
                    m_data[propUri] = finalValue;
                } else {
                    m_data.remove(propUri);
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : qAsConst(d->itemList)) {
        size = size.expandedTo(item->minimumSize());
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : m_urls) {
        bool extractorRunning = false;
        KFileMetaData::PropertyMap fileProperties;

        // UseRealtimeIndexing::Fallback: try DB first, then filesystem
        // UseRealtimeIndexing::Disabled: DB contents only
        // UseRealtimeIndexing::Only:     DB disabled, use filesystem
        if (m_useRealtime != UseRealtimeIndexing::Only) {
            Baloo::File file(filePath);
            file.load();
            fileProperties = file.properties();
            qCDebug(WIDGETS) << filePath << "DB properties:" << fileProperties;
        }
        if (fileProperties.empty() && m_useRealtime != UseRealtimeIndexing::Disabled) {
            extractorRunning = true;
            m_extractor.process(filePath);
        }

        QVariantMap prop;
        KFileMetaData::UserMetaData umd(filePath);

        if (umd.isSupported()) {
            prop = Baloo::Private::convertUserMetaData(umd);
        } else {
            m_canEditAll = false;
        }
        if (m_canEditAll) {
            m_canEditAll = QFileInfo(filePath).isWritable();
        }

        if (extractorRunning) {
            m_extractor.waitFinished();
            fileProperties = m_extractor.properties();
            qCDebug(WIDGETS) << filePath << "  properties:" << fileProperties;
        }
        prop.unite(Baloo::Private::toNamedVariantMap(fileProperties));

        m_data << prop;
    }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
const auto key
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : qAsConst(m_urls)) {
        bool extractorRunning = false;
        KFileMetaData::PropertyMap fileProperties;

        // UseRealtimeIndexing::Fallback: try DB first, then filesystem
        // UseRealtimeIndexing::Disabled: DB contents only
        // UseRealtimeIndexing::Only:     DB disabled, use filesystem
        if (m_useRealtime != UseRealtimeIndexing::Only) {
            Baloo::File file(filePath);
            file.load();
            fileProperties = file.properties();
            qCDebug(WIDGETS) << filePath << "DB properties:" << fileProperties;
        }
        if (fileProperties.empty() && m_useRealtime != UseRealtimeIndexing::Disabled) {
            extractorRunning = true;
            m_extractor.process(filePath);
        }

        QVariantMap prop;
        KFileMetaData::UserMetaData umd(filePath);

        if (umd.isSupported()) {
            prop = Baloo::Private::convertUserMetaData(umd);
        } else {
            m_canEditAll = false;
        }
        if (m_canEditAll) {
            m_canEditAll = QFileInfo(filePath).isWritable();
        }

        if (extractorRunning) {
            m_extractor.waitFinished();
            fileProperties = m_extractor.properties();
            qCDebug(WIDGETS) << filePath << "  properties:" << fileProperties;
        }
        prop.unite(Baloo::Private::toNamedVariantMap(fileProperties));

        m_data << prop;
    }
```

#### AUTO 


```{c}
auto mainLayout = new QGridLayout(q);
```

#### AUTO 


```{c}
auto rangeEnd = std::find_if(begin, propMap.constKeyValueEnd(),
            [key](const entry& e) { return e.first != key; });
```

#### AUTO 


```{c}
auto labelString = KStringHandler::csqueeze(valueString, maxUrlLength);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : std::as_const(m_allTags)) {
        modifyTagWidget(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& key : keys) {
        Row row;
        if (m_configureVisibleProperties) {
            row.checkBox = new QCheckBox(q);
            if (active.contains(key)) {
                row.checkBox->setChecked(true);
            }
            m_gridLayout->addWidget(row.checkBox, rowIndex, 0, Qt::AlignTop | Qt::AlignRight);
            connect(row.checkBox, &QCheckBox::stateChanged,
                    q, [this, key](int state) { this->m_visibilityChanged[key] = (state == Qt::Checked); });
        } else {
            row.checkBox = nullptr;
        }

        row.label = createLabel(key, m_provider->label(key), q);
        m_gridLayout->addWidget(row.label, rowIndex, labelColumn + 0, Qt::AlignRight);

        m_gridLayout->addItem(new QSpacerItem(spacerWidth, 1), rowIndex, labelColumn + 1);

        row.value = m_widgetFactory->createWidget(key, data[key], q);
        m_gridLayout->addWidget(row.value, rowIndex, labelColumn + 2, Qt::AlignLeft);

        m_gridLayout->setRowStretch(rowIndex, 0);

        // Remember the label and value-widget as row
        m_rows.append(row);
        ++rowIndex;
    }
```

#### AUTO 


```{c}
const auto parts = metaDataLabel.split(QLatin1Char('_'));
```

#### AUTO 


```{c}
auto yesterday_re = yesterdayShortRegex();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap& map : resources) {
            QVariantMap::const_iterator it = map.constFind(prop);
            if (it == map.constEnd()) {
                total = 0;
                break;
            } else {
                total += it.value().toInt();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_items)) {
        QUrl url = item.targetUrl();
        if (!url.isLocalFile()) {
            continue;
        }
        KFileMetaData::UserMetaData md(url.toLocalFile());
        md.setUserComment(comment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &fileData : files) {
        propertyList << fileData;
        auto uniqueValues = fileData.keys();
        uniqueValues.erase(std::unique(uniqueValues.begin(), uniqueValues.end()), uniqueValues.end());
        allProperties += QSet<QString>(uniqueValues.begin(), uniqueValues.end());
    }
```

#### AUTO 


```{c}
auto valueWidget = m_widget->findChild<QLabel *>(QStringLiteral("kfileitem#type"));
```

#### AUTO 


```{c}
auto newTagLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_fileItems)) {
        const QUrl url = item.targetUrl();
        if (url.isLocalFile()) {
            urls << url.toLocalFile();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
        Row row;
        if (m_configureVisibleProperties) {
            row.checkBox = new QCheckBox(q);
            if (active.contains(key)) {
                row.checkBox->setChecked(true);
            }
            m_gridLayout->addWidget(row.checkBox, rowIndex, 0, Qt::AlignTop | Qt::AlignRight);
            connect(row.checkBox, &QCheckBox::stateChanged, q, [this, key](int state) {
                this->m_visibilityChanged[key] = (state == Qt::Checked);
            });
        } else {
            row.checkBox = nullptr;
        }

        row.label = createLabel(key, m_provider->label(key), q);
        m_gridLayout->addWidget(row.label, rowIndex, labelColumn + 0, Qt::AlignRight);

        m_gridLayout->addItem(new QSpacerItem(spacerWidth, 1), rowIndex, labelColumn + 1);

        row.value = m_widgetFactory->createWidget(key, data[key], q);
        m_gridLayout->addWidget(row.value, rowIndex, labelColumn + 2, Qt::AlignLeft);

        m_gridLayout->setRowStretch(rowIndex, 0);

        // Remember the label and value-widget as row
        m_rows.append(row);
        ++rowIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(row.items)) {
            int yy = y;
            if (alignment() & Qt::AlignBottom)
                yy += (row.height - item->sizeHint().height());
            else if (alignment() & Qt::AlignVCenter)
                yy += (row.height - item->sizeHint().height()) / 2;
            item->setGeometry(QRect(QPoint(x, yy), item->sizeHint()));

            x += item->sizeHint().width() + horizontalSpacing();

            if (alignment() & Qt::AlignJustify)
                x += (rect.width() - row.width) / qMax(row.items.count() - 1, 1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_fileItems)) {
        const QUrl url = item.targetUrl();
        if (url.isLocalFile() && !item.isSlow()) {
            urls << url.toLocalFile();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : std::as_const(m_urls)) {
        bool extractorRunning = false;
        KFileMetaData::PropertyMultiMap fileProperties;

        // UseRealtimeIndexing::Fallback: try DB first, then filesystem
        // UseRealtimeIndexing::Disabled: DB contents only
        // UseRealtimeIndexing::Only:     DB disabled, use filesystem
        if (m_useRealtime != UseRealtimeIndexing::Only) {
            Baloo::File file(filePath);
            file.load();
            fileProperties = file.properties();
            qCDebug(WIDGETS) << filePath << "DB properties:" << fileProperties;
        }
        if (fileProperties.empty() && m_useRealtime != UseRealtimeIndexing::Disabled) {
            extractorRunning = true;
            m_extractor.process(filePath);
        }

        QVariantMap prop;
        KFileMetaData::UserMetaData umd(filePath);

        if (umd.isSupported()) {
            prop = Baloo::Private::convertUserMetaData(umd);
        } else {
            m_canEditAll = false;
        }
        if (m_canEditAll) {
            m_canEditAll = QFileInfo(filePath).isWritable();
        }

        if (extractorRunning) {
            m_extractor.waitFinished();
            fileProperties = m_extractor.properties();
            qCDebug(WIDGETS) << filePath << "  properties:" << fileProperties;
        }
        prop.insert(Baloo::Private::toNamedVariantMap(fileProperties));

        m_data << prop;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_fileItems)) {
        allDirectories &= item.isDir();
        if (!allDirectories) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel(itemLabel + QLatin1Char(':'), parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto property : disabledProperties) {
            settings.writeEntry(property, false);
        }
```

#### AUTO 


```{c}
auto ancient = QDateTime::currentDateTime().addYears(-10);
```

#### AUTO 


```{c}
auto job = new Baloo::TagListJob();
```

#### AUTO 


```{c}
auto tjob = static_cast<Baloo::TagListJob *>(job);
```

#### AUTO 


```{c}
auto artistWidget = m_widget->findChild<QLabel*>(QStringLiteral("artist"));
```

#### AUTO 


```{c}
auto genreWidget = m_widget->findChild<QLabel*>(QStringLiteral("genre"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::Row& row : qAsConst(d->m_rows)) {
        const QWidget* valueWidget = row.value;
        const int rightWidth = valueWidget->sizeHint().width();
        rightWidthAverage += rightWidth;
        if (rightWidth > rightWidthMax) {
            rightWidthMax = rightWidth;
        }

        const int leftWidth = row.label->sizeHint().width();
        if (leftWidth > leftWidthMax) {
            leftWidthMax = leftWidth;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ slotLoadingFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *item : std::as_const(m_allTagTreeItems)) {
        if (item->checkState(0) == Qt::Checked) {
            m_tags << qvariant_cast<QString>(item->data(0, Qt::UserRole));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_fileItems) {
            count += subDirectoriesCount(item.url().path());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&list](const entry &s) {
                list.append(s.second);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : qAsConst(d->itemList)) {
        const QSize itemSize = item->minimumSize();
        size.rwidth() += itemSize.width();
        if (itemSize.height() > size.height()) {
            size.setHeight(itemSize.height());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &fileData : files) {
        propertyList << fileData;
        allProperties.unite(fileData.uniqueKeys().toSet());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_fileItems) {
                if (!item.isDir() && !item.isLink()) {
                    totalSize += item.size();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &map : resources) {
            QVariantMap::const_iterator it = map.constFind(prop);
            if (it == map.constEnd()) {
                total = 0;
                break;
            } else {
                total += it.value().toInt();
            }
        }
```

#### AUTO 


```{c}
const auto protocol = parts.at(1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &propUri : std::as_const(allProperties)) {
        for (const QVariantMap &map : std::as_const(propertyList)) {
            QVariantMap::const_iterator it = map.find(propUri);
            if (it == map.constEnd()) {
                m_data.remove(propUri);
                break;
            }

            QVariantMap::iterator dit = m_data.find(it.key());
            if (dit == m_data.end()) {
                m_data.insert(propUri, it.value());
            } else {
                QVariant finalValue = intersect(it.value(), dit.value());
                if (finalValue.isValid()) {
                    m_data[propUri] = finalValue;
                } else {
                    m_data.remove(propUri);
                    break;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_fileItems)) {
            if (!item.isDir() && !item.isLink()) {
                totalSize += item.size();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Row& row : qAsConst(m_rows)) {
        delete row.label;
        row.value->deleteLater();
        if (row.checkBox) {
            row.checkBox->deleteLater();
        }
    }
```

#### AUTO 


```{c}
auto long_ago_re = longAgoShortRegex();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Row &row : std::as_const(m_rows)) {
        delete row.label;
        row.value->deleteLater();
        if (row.checkBox) {
            row.checkBox->deleteLater();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_fileItems) {
            allDirectories &= item.isDir();
        }
```

#### AUTO 


```{c}
auto artistWidget = m_widget->findChild<QLabel *>(QStringLiteral("artist"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_urls) {
        Baloo::File file(filePath);
        file.load();

        QVariantMap prop = convertPropertyMap(file.properties());

        KFileMetaData::UserMetaData md(filePath);
        QStringList tags = md.tags();
        if (!tags.isEmpty()) {
            prop.insert("tags", tags);
        }

        int rating = md.rating();
        if (rating) {
            prop.insert("rating", rating);
        }

        QString comment = md.userComment();
        if (!comment.isEmpty()) {
            prop.insert("userComment", comment);
        }

        const QString originUrl = md.originUrl().toDisplayString();
        if (!originUrl.isEmpty()) {
            prop.insert("originUrl", originUrl);
        }

        m_data << prop;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : m_prevTags) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_fileItems)) {
            isSizeKnown = item.isLocalFile() && !item.isSlow();
            if (!isSizeKnown) {
                return;
            }
            const QPair<int, int> counts = subDirectoriesCount(item.url().path());
            const int subcount = counts.first;
            isSizeKnown = subcount != -1;
            if (!isSizeKnown) {
                return;
            }
            count += subcount;
            hiddenCount += counts.second;
        }
```

#### AUTO 


```{c}
auto newTagLabel = new QLabel(i18nc("@label", "Create new tag:"));
```

#### AUTO 


```{c}
auto fetchJob = static_cast<FileFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_items)) {
            QUrl url = item.targetUrl();
            if (!url.isLocalFile()) {
                continue;
            }
            KFileMetaData::UserMetaData md(url.toLocalFile());

            // When multiple tags are selected one doesn't want to loose the old tags
            // of any of the resources. Unless specifically removed.
            QStringList newTags = md.tags() + tags;
            newTags.removeDuplicates();

            for (const QString &tag : m_prevTags) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
            md.setTags(newTags);
        }
```

#### AUTO 


```{c}
auto changedIt = m_visibilityChanged.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_fileItems)) {
            isSizeKnown = item.isLocalFile() && !item.isSlow();
            if (!isSizeKnown) {
                return;
            }
            const QPair<int, int> counts = subDirectoriesCount(item.url().path());
            const int subcount = counts.first;
            isSizeKnown = subcount != -1;
            if (!isSizeKnown) {
                return;
            }
            count += subcount;
            hiddenCount += counts.second;
        }
```

#### AUTO 


```{c}
auto rangeEnd = std::find_if(begin, propMap.constKeyValueEnd(), [key](const entry &e) {
            return e.first != key;
        });
```

#### AUTO 


```{c}
auto yesterday_s = form.formatRelativeDateTime(yesterday, QLocale::ShortFormat);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tag : tags) {
        getTagCheckBox(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &map : std::as_const(propertyList)) {
            QVariantMap::const_iterator it = map.find(propUri);
            if (it == map.constEnd()) {
                m_data.remove(propUri);
                break;
            }

            QVariantMap::iterator dit = m_data.find(it.key());
            if (dit == m_data.end()) {
                m_data.insert(propUri, it.value());
            } else {
                QVariant finalValue = intersect(it.value(), dit.value());
                if (finalValue.isValid()) {
                    m_data[propUri] = finalValue;
                } else {
                    m_data.remove(propUri);
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tags) {
        getTagCheckBox(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &propUri : qAsConst(allProperties)) {
        for (const QVariantMap &map : qAsConst(propertyList)) {
            QVariantMap::const_iterator it = map.find(propUri);
            if (it == map.constEnd()) {
                m_data.remove(propUri);
                break;
            }

            QVariantMap::iterator dit = m_data.find(it.key());
            if (dit == m_data.end()) {
                m_data.insert(propUri, it.value());
            } else {
                QVariant finalValue = intersect(it.value(), dit.value());
                if (finalValue.isValid()) {
                    m_data[propUri] = finalValue;
                } else {
                    m_data.remove(propUri);
                    break;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto me = static_cast<QMouseEvent *>(event);
```

#### AUTO 


```{c}
const auto &field = extraFields.at(i);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto field = extraFields.value(extraNumber);
```

#### AUTO 


```{c}
auto yesterday_re = QRegularExpression(QStringLiteral("Yesterday, (?:[1-2][0-9]|[1-9]):[0-5][0-9] [AP]M"));
```

#### AUTO 


```{c}
const auto keys = settings.keyList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_items)) {
            QUrl url = item.targetUrl();
            if (!url.isLocalFile()) {
                continue;
            }
            KFileMetaData::UserMetaData md(url.toLocalFile());

            // When multiple tags are selected one doesn't want to loose the old tags
            // of any of the resources. Unless specifically removed.
            QStringList newTags = md.tags() + tags;
            newTags.removeDuplicates();

            for (const QString &tag : qAsConst(m_prevTags)) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
            md.setTags(newTags);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_fileItems) {
        allDirectories &= item.isDir();
        if (!allDirectories) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto ratingWidget = m_widget->findChild<KRatingWidget *>(QStringLiteral("rating"));
```

#### AUTO 


```{c}
auto tagWidget = new TagWidget(parent);
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem* item : m_allTagTreeItems.values()) {
        if (item->checkState(0) == Qt::Checked) {
            m_tags << qvariant_cast<QString>(item->data(0, Qt::UserRole));
        }
    }
```

#### AUTO 


```{c}
const auto& key
```

#### AUTO 


```{c}
auto yesterday = QDateTime::currentDateTime().addDays(-1);
```

#### LAMBDA EXPRESSION 


```{c}
[this, key](int state) { this->m_visibilityChanged[key] = (state == Qt::Checked); }
```

#### AUTO 


```{c}
auto url = value.toUrl();
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(d->itemList)) {
        size = size.expandedTo(item->minimumSize());
    }
```

#### AUTO 


```{c}
auto checkBox = new TagCheckBox(tag, q);
```

#### RANGE FOR STATEMENT 


```{c}
for (KFileMetaData::Extractor *ex : exList) {
        ex->extract(&result);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_urls) {
        Baloo::File file(filePath);
        file.load();

        QVariantMap prop = Baloo::Private::toNamedVariantMap(file.properties());
        KFileMetaData::UserMetaData umd(filePath);

        if (umd.isSupported()) {
            // FIXME - check writable

            QVariantMap attributes = Baloo::Private::convertUserMetaData(umd);
            prop.unite(attributes);
        } else {
            m_canEditAll = false;
        }
        if (m_canEditAll) {
            m_canEditAll = QFileInfo(filePath).isWritable();
        }

        m_data << prop;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, key](int state) {
                this->m_visibilityChanged[key] = (state == Qt::Checked);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KJob* job) {
        Baloo::TagListJob* tjob = static_cast<Baloo::TagListJob*>(job);
        m_allTags = tjob->tags();
        loadTagWidget();
    }
```

#### AUTO 


```{c}
auto key = (*begin).first;
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : std::as_const(d->itemList)) {
        size = size.expandedTo(item->minimumSize());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_fileItems) {
                count += subDirectoriesCount(item.url().path());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap& fileData : files) {
        propertyList << fileData;
        allProperties.unite(fileData.uniqueKeys().toSet());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
        Row row;
        if (m_configureVisibleProperties) {
            row.checkBox = new QCheckBox(q);
            if (active.contains(key)) {
                row.checkBox->setChecked(true);
            }
            m_gridLayout->addWidget(row.checkBox, rowIndex, 0, Qt::AlignTop | Qt::AlignRight);
            QObject::connect(row.checkBox, &QCheckBox::stateChanged, q, [this, key](int state) {
                this->m_visibilityChanged[key] = (state == Qt::Checked);
            });
        } else {
            row.checkBox = nullptr;
        }

        row.label = createLabel(key, m_provider->label(key), q);
        m_gridLayout->addWidget(row.label, rowIndex, labelColumn + 0, Qt::AlignRight);

        m_gridLayout->addItem(new QSpacerItem(spacerWidth, 1), rowIndex, labelColumn + 1);

        row.value = m_widgetFactory->createWidget(key, data[key], q);
        m_gridLayout->addWidget(row.value, rowIndex, labelColumn + 2, Qt::AlignLeft);

        m_gridLayout->setRowStretch(rowIndex, 0);

        // Remember the label and value-widget as row
        m_rows.append(row);
        ++rowIndex;
    }
```

#### AUTO 


```{c}
const auto args = parser.positionalArguments();
```

#### AUTO 


```{c}
auto commentWidget = new KCommentWidget(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_fileItems)) {
        const QUrl url = item.targetUrl();
        if (url.isLocalFile()) {
            urls << url.toLocalFile();
        }
    }
```

#### AUTO 


```{c}
auto genreWidget = m_widget->findChild<QLabel *>(QStringLiteral("genre"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_items)) {
        QUrl url = item.targetUrl();
        if (!url.isLocalFile()) {
            continue;
        }
        KFileMetaData::UserMetaData md(url.toLocalFile());
        md.setRating(rating);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_items) {
        KFileMetaData::UserMetaData md(filePath);
        md.setUserComment(comment);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto valueWidget = new ValueWidget(parent);
```

#### AUTO 


```{c}
auto pw = static_cast<QWidget *>(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        Baloo::TagListJob *tjob = static_cast<Baloo::TagListJob *>(job);
        m_allTags = tjob->tags();
        loadTagWidget();
    }
```

#### AUTO 


```{c}
const auto tag = qvariant_cast<QString>(item->data(0, Qt::UserRole));
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : qAsConst(row.items)) {
            int yy = y;
            if( alignment() & Qt::AlignBottom )
                yy += (row.height - item->sizeHint().height());
            else if( alignment() & Qt::AlignVCenter )
                yy += (row.height - item->sizeHint().height())/2;
            item->setGeometry(QRect(QPoint(x, yy), item->sizeHint()));

            x += item->sizeHint().width() + horizontalSpacing();

            if( alignment() & Qt::AlignJustify )
                x += (rect.width() - row.width)/qMax(row.items.count()-1,1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : value.toList()) {
                list << toString(var, dateFormat);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_fileItems)) {
            if (!item.isDir() && !item.isLink()) {
                totalSize += item.size();
            }
        }
```

#### AUTO 


```{c}
auto dateWidget = widget->findChild<QLabel *>(QStringLiteral("kfileitem#modified"), Qt::FindDirectChildrenOnly);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Row &row : qAsConst(rows)) {
        x = rect.x();
        if (alignment() & Qt::AlignRight)
            x += (rect.width() - row.width);
        else if (alignment() & Qt::AlignHCenter)
            x += (rect.width() - row.width) / 2;

        for (QLayoutItem *item : qAsConst(row.items)) {
            int yy = y;
            if (alignment() & Qt::AlignBottom)
                yy += (row.height - item->sizeHint().height());
            else if (alignment() & Qt::AlignVCenter)
                yy += (row.height - item->sizeHint().height()) / 2;
            item->setGeometry(QRect(QPoint(x, yy), item->sizeHint()));

            x += item->sizeHint().width() + horizontalSpacing();

            if (alignment() & Qt::AlignJustify)
                x += (rect.width() - row.width) / qMax(row.items.count() - 1, 1);
        }

        y = y + row.height + verticalSpacing();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        auto tjob = static_cast<Baloo::TagListJob *>(job);
        m_allTags = tjob->tags();
        loadTagWidget();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_urls) {

        bool extractorRunning = false;
        KFileMetaData::PropertyMap fileProperties;

        // UseRealtimeIndexing::Fallback: try DB first, then filesystem
        // UseRealtimeIndexing::Disabled: DB contents only
        // UseRealtimeIndexing::Only:     DB disabled, use filesystem
        if (m_useRealtime != UseRealtimeIndexing::Only) {
            Baloo::File file(filePath);
            file.load();
            fileProperties = file.properties();
            qCDebug(WIDGETS) << filePath << "DB properties:" << fileProperties;
        }
        if (fileProperties.empty() && m_useRealtime != UseRealtimeIndexing::Disabled) {
            extractorRunning = true;
            m_extractor.process(filePath);
        }

        QVariantMap prop;
        KFileMetaData::UserMetaData umd(filePath);

        if (umd.isSupported()) {
            prop = Baloo::Private::convertUserMetaData(umd);
        } else {
            m_canEditAll = false;
        }
        if (m_canEditAll) {
            m_canEditAll = QFileInfo(filePath).isWritable();
        }

        if (extractorRunning) {
            m_extractor.waitFinished();
            fileProperties = m_extractor.properties();
            qCDebug(WIDGETS) << filePath << "  properties:" << fileProperties;
        }
        prop.unite(Baloo::Private::toNamedVariantMap(fileProperties));

        m_data << prop;
    }
```

#### AUTO 


```{c}
const auto width = m_data.value(QStringLiteral("width"));
```

#### LAMBDA EXPRESSION 


```{c}
[&list](const entry& s) { list.append(s.second); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_urls) {
        Baloo::File file(filePath);
        file.load();

        QVariantMap prop = Baloo::Private::toNamedVariantMap(file.properties());
        KFileMetaData::UserMetaData umd(filePath);
        QVariantMap attributes = Baloo::Private::convertUserMetaData(umd);

        prop.unite(attributes);

        m_data << prop;
    }
```

#### AUTO 


```{c}
auto long_ago = QDateTime::currentDateTime().addYears(-10);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap &map : qAsConst(propertyList)) {
            QVariantMap::const_iterator it = map.find(propUri);
            if (it == map.constEnd()) {
                m_data.remove(propUri);
                break;
            }

            QVariantMap::iterator dit = m_data.find(it.key());
            if (dit == m_data.end()) {
                m_data.insert(propUri, it.value());
            } else {
                QVariant finalValue = intersect(it.value(), dit.value());
                if (finalValue.isValid()) {
                    m_data[propUri] = finalValue;
                } else {
                    m_data.remove(propUri);
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : qAsConst(d->itemList)) {
        const QSize itemSize = item->minimumSize();
        size.rwidth() += itemSize.width();
        if (itemSize.height() > size.height()) {
            size.setHeight(itemSize.height());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urlList)
        list << KFileItem( url, QString(), mode_t() );
```

#### AUTO 


```{c}
const auto &key
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileMetaDataWidgetPrivate::Row &row : std::as_const(d->m_rows)) {
        const QWidget *valueWidget = row.value;
        const int rowHeight = qMax(row.label->heightForWidth(leftWidthMax), valueWidget->heightForWidth(rightWidthMax));
        height += rowHeight;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_items)) {
        QUrl url = item.targetUrl();
        if (!url.isLocalFile()) {
            continue;
        }
        KFileMetaData::UserMetaData md(url.toLocalFile());
        md.setRating(rating);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *item : qAsConst(m_allTagTreeItems)) {
        if (item->checkState(0) == Qt::Checked) {
            m_tags << qvariant_cast<QString>(item->data(0, Qt::UserRole));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : value.toList()) {
                list << toString(var);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &var : value.toList()) {
            list << toString(var, dateFormat);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : std::as_const(m_tags)) {
        modifyTagWidget(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : std::as_const(m_prevTags)) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("@label:textbox",
                                  "Configure which tags should "
                                  "be applied."),
                            this);
```

#### LAMBDA EXPRESSION 


```{c}
[key](const entry &e) {
            return e.first != key;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& s1, const QString& s2){ return coll.compare(s1, s2) < 0; }
```

#### AUTO 


```{c}
const auto extraFields = KProtocolInfo::extraFields(item.url());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_fileItems)) {
        allDirectories &= item.isDir();
        if (!allDirectories) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem *item : m_allTagTreeItems.values()) {
        if (item->checkState(0) == Qt::Checked) {
            m_tags << qvariant_cast<QString>(item->data(0, Qt::UserRole));
        }
    }
```

#### AUTO 


```{c}
auto ratingWidget = new KRatingWidget(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Row& row : qAsConst(rows)) {
        x = rect.x();
        if( alignment() & Qt::AlignRight )
            x += (rect.width() - row.width);
        else if( alignment() & Qt::AlignHCenter )
            x += (rect.width() - row.width)/2;

        for (QLayoutItem* item : qAsConst(row.items)) {
            int yy = y;
            if( alignment() & Qt::AlignBottom )
                yy += (row.height - item->sizeHint().height());
            else if( alignment() & Qt::AlignVCenter )
                yy += (row.height - item->sizeHint().height())/2;
            item->setGeometry(QRect(QPoint(x, yy), item->sizeHint()));

            x += item->sizeHint().width() + horizontalSpacing();

            if( alignment() & Qt::AlignJustify )
                x += (rect.width() - row.width)/qMax(row.items.count()-1,1);
        }

        y = y + row.height + verticalSpacing();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &s1, const QString &s2) {
            return coll.compare(s1, s2) < 0;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &var : valueList) {
            list << toString(var, dateFormat);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto key: keys) {
        Row row;
        if (m_configureVisibleProperties) {
            row.checkBox = new QCheckBox(q);
            if (active.contains(key)) {
                row.checkBox->setChecked(true);
            }
            m_gridLayout->addWidget(row.checkBox, rowIndex, 0, Qt::AlignTop | Qt::AlignRight);
            connect(row.checkBox, &QCheckBox::stateChanged,
                    q, [this, key](int state) { this->m_visibilityChanged[key] = (state == Qt::Checked); });
        } else {
            row.checkBox = nullptr;
        }

        row.label = createLabel(key, m_provider->label(key), q);
        m_gridLayout->addWidget(row.label, rowIndex, labelColumn + 0, Qt::AlignRight);

        m_gridLayout->addItem(new QSpacerItem(spacerWidth, 1), rowIndex, labelColumn + 1);

        row.value = m_widgetFactory->createWidget(key, data[key], q);
        m_gridLayout->addWidget(row.value, rowIndex, labelColumn + 2, Qt::AlignLeft);

        m_gridLayout->setRowStretch(rowIndex, 0);

        // Remember the label and value-widget as row
        m_rows.append(row);
        ++rowIndex;
    }
```

#### AUTO 


```{c}
const auto extraFields = KProtocolInfo::extraFields(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Row &row : std::as_const(rows)) {
        x = rect.x();
        if (alignment() & Qt::AlignRight)
            x += (rect.width() - row.width);
        else if (alignment() & Qt::AlignHCenter)
            x += (rect.width() - row.width) / 2;

        for (QLayoutItem *item : std::as_const(row.items)) {
            int yy = y;
            if (alignment() & Qt::AlignBottom)
                yy += (row.height - item->sizeHint().height());
            else if (alignment() & Qt::AlignVCenter)
                yy += (row.height - item->sizeHint().height()) / 2;
            item->setGeometry(QRect(QPoint(x, yy), item->sizeHint()));

            x += item->sizeHint().width() + horizontalSpacing();

            if (alignment() & Qt::AlignJustify)
                x += (rect.width() - row.width) / qMax(row.items.count() - 1, 1);
        }

        y = y + row.height + verticalSpacing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::Row& row : qAsConst(d->m_rows)) {
        const QWidget* valueWidget = row.value;
        const int rowHeight = qMax(row.label->heightForWidth(leftWidthMax),
                                   valueWidget->heightForWidth(rightWidthMax));
        height += rowHeight;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_fileItems)) {
            count += subDirectoriesCount(item.url().path());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_urls) {
        Baloo::File file(filePath);
        file.load();

        QVariantMap prop = convertPropertyMap(file.properties());

        KFileMetaData::UserMetaData md(filePath);
        QStringList tags = md.tags();
        if (!tags.isEmpty()) {
            prop.insert("tags", tags);
        }

        int rating = md.rating();
        if (rating) {
            prop.insert("rating", rating);
        }

        QString comment = md.userComment();
        if (!comment.isEmpty()) {
            prop.insert("userComment", comment);
        }

        m_data << prop;
    }
```

#### AUTO 


```{c}
auto uniqueValues = fileData.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileMetaDataWidgetPrivate::Row &row : qAsConst(d->m_rows)) {
        const QWidget *valueWidget = row.value;
        const int rowHeight = qMax(row.label->heightForWidth(leftWidthMax), valueWidget->heightForWidth(rightWidthMax));
        height += rowHeight;
    }
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(label, m_metaDataList);
```

#### AUTO 


```{c}
auto widget = new Baloo::FileMetaDataWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Row &row : qAsConst(m_rows)) {
        delete row.label;
        row.value->deleteLater();
        if (row.checkBox) {
            row.checkBox->deleteLater();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : std::as_const(row.items)) {
            int yy = y;
            if (alignment() & Qt::AlignBottom)
                yy += (row.height - item->sizeHint().height());
            else if (alignment() & Qt::AlignVCenter)
                yy += (row.height - item->sizeHint().height()) / 2;
            item->setGeometry(QRect(QPoint(x, yy), item->sizeHint()));

            x += item->sizeHint().width() + horizontalSpacing();

            if (alignment() & Qt::AlignJustify)
                x += (rect.width() - row.width) / qMax(row.items.count() - 1, 1);
        }
```

#### AUTO 


```{c}
const auto parts = metaDataLabel.splitRef(QLatin1Char('_'));
```

#### AUTO 


```{c}
auto box = new QCheckBox(QStringLiteral("Align Right"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_fileItems)) {
        allDirectories &= item.isDir();
        if (!allDirectories) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tag : m_prevTags) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
```

#### AUTO 


```{c}
auto long_ago_s = form.formatRelativeDateTime(long_ago, QLocale::ShortFormat);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotLoadingFinished();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
        settings.writeEntry(key, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariantMap& map : qAsConst(propertyList)) {
            QVariantMap::const_iterator it = map.find(propUri);
            if (it == map.constEnd()) {
                m_data.remove(propUri);
                break;
            }

            QVariantMap::iterator dit = m_data.find(it.key());
            if (dit == m_data.end()) {
                m_data.insert(propUri, it.value());
            } else {
                QVariant finalValue = intersect(it.value(), dit.value());
                if (finalValue.isValid()) {
                    m_data[propUri] = finalValue;
                } else {
                    m_data.remove(propUri);
                    break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList)
        list << KFileItem(url, QString(), mode_t());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_fileItems) {
            if (!item.isDir() && !item.isLink()) {
                totalSize += item.size();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_items)) {
        QUrl url = item.targetUrl();
        if (!url.isLocalFile()) {
            continue;
        }
        KFileMetaData::UserMetaData md(url.toLocalFile());
        md.setUserComment(comment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : qAsConst(m_tags)) {
        modifyTagWidget(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_items)) {
            QUrl url = item.targetUrl();
            if (!url.isLocalFile()) {
                continue;
            }
            KFileMetaData::UserMetaData md(url.toLocalFile());

            // When multiple tags are selected one doesn't want to loose the old tags
            // of any of the resources. Unless specifically removed.
            QStringList newTags = md.tags() + tags;
            newTags.removeDuplicates();

            for (const QString &tag : std::as_const(m_prevTags)) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
            md.setTags(newTags);
        }
```

#### AUTO 


```{c}
static const auto extraPrefix = QStringLiteral("kfileitem#extra_");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : args) {
        QFileInfo fi(path);
        list << KFileItem(QUrl::fromLocalFile(fi.absoluteFilePath()), QString(), mode_t());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : qAsConst(m_fileItems)) {
            isSizeKnown = item.isLocalFile();
            if (!isSizeKnown) {
                return;
            }
            const QPair<int, int> counts = subDirectoriesCount(item.url().path());
            const int subcount = counts.first;
            isSizeKnown = subcount != -1;
            if (!isSizeKnown) {
                return;
            }
            count += subcount;
            hiddenCount += counts.second;
        }
```

#### AUTO 


```{c}
auto labelString = valueString;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : parser.positionalArguments()) {
        QFileInfo fi(path);
        list << KFileItem(QUrl::fromLocalFile(fi.absoluteFilePath()), QString(), mode_t());
    }
```

#### AUTO 


```{c}
auto distance = std::distance(begin, rangeEnd);
```

#### AUTO 


```{c}
auto begin = propMap.constKeyValueBegin();
```

#### AUTO 


```{c}
const auto property
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::Row &row : qAsConst(d->m_rows)) {
        const QWidget *valueWidget = row.value;
        const int rowHeight = qMax(row.label->heightForWidth(leftWidthMax), valueWidget->heightForWidth(rightWidthMax));
        height += rowHeight;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[key](const entry& e) { return e.first != key; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FileMetaDataWidgetPrivate::Row &row : qAsConst(d->m_rows)) {
        const QWidget *valueWidget = row.value;
        const int rightWidth = valueWidget->sizeHint().width();
        rightWidthAverage += rightWidth;
        if (rightWidth > rightWidthMax) {
            rightWidthMax = rightWidth;
        }

        const int leftWidth = row.label->sizeHint().width();
        if (leftWidth > leftWidthMax) {
            leftWidthMax = leftWidth;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto key: keys) {
        Row row;
        const int spacerWidth = QFontMetrics(q->font()).size(Qt::TextSingleLine, " ").width();
        m_gridLayout->addItem(new QSpacerItem(spacerWidth, 1), rowIndex, 1);

        row.label = createLabel(key, m_provider->label(key), q);
        m_gridLayout->addWidget(row.label, rowIndex, 0, Qt::AlignRight);

        row.value = m_widgetFactory->createWidget(key, data[key], q);
        m_gridLayout->addWidget(row.value, rowIndex, 2, Qt::AlignLeft);

        // Remember the label and value-widget as row
        m_rows.append(row);
        ++rowIndex;
    }
```

#### AUTO 


```{c}
auto pi = KFileMetaData::PropertyInfo::fromName(prop);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto job = new FileFetchJob(urls, canEdit, FileFetchJob::UseRealtimeIndexing::Disabled, this);
```

#### AUTO 


```{c}
const auto valueList = value.toList();
```

#### AUTO 


```{c}
auto long_ago_re = QRegularExpression(QStringLiteral("(?:[1-3][0-9]|[1-9]) (?:[1-2][0-9]|[1-9]):[0-5][0-9] [AP]M"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_items) {
            KFileMetaData::UserMetaData md(filePath);
            md.setTags(tags);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::Row &row : qAsConst(d->m_rows)) {
        const QWidget *valueWidget = row.value;
        const int rightWidth = valueWidget->sizeHint().width();
        rightWidthAverage += rightWidth;
        if (rightWidth > rightWidthMax) {
            rightWidthMax = rightWidth;
        }

        const int leftWidth = row.label->sizeHint().width();
        if (leftWidth > leftWidthMax) {
            leftWidthMax = leftWidth;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : m_items) {
        KFileMetaData::UserMetaData md(filePath);
        md.setRating(rating);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : qAsConst(m_prevTags)) {
                if (!tags.contains(tag)) {
                    newTags.removeAll(tag);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_fileItems)) {
            isSizeKnown = item.isLocalFile();
            if (!isSizeKnown) {
                return;
            }
            const QPair<int, int> counts = subDirectoriesCount(item.url().path());
            const int subcount = counts.first;
            isSizeKnown = subcount != -1;
            if (!isSizeKnown) {
                return;
            }
            count += subcount;
            hiddenCount += counts.second;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : m_allTags) {
        modifyTagWidget(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem *item : std::as_const(d->itemList)) {
        const QSize itemSize = item->minimumSize();
        size.rwidth() += itemSize.width();
        if (itemSize.height() > size.height()) {
            size.setHeight(itemSize.height());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : std::as_const(m_fileItems)) {
            if (!item.isDir() && !item.isLink()) {
                totalSize += item.size();
            }
        }
```

