#### RANGE FOR STATEMENT 


```{c}
for (Entity* source : qAsConst(m_entities)) {
        for (Entity* target : qAsConst(m_entities)) {
            if (source->player() != target->player() &&
                !source->nick().isEmpty()) {
                target->notifyNick(source->player(), source->nick());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
            entity->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        entity->notifyReady(Sea::Player(player));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        entity->notify(player, c, info);
        if (player == entity->player()) {
            entity->stats()->addInfo(info);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        if (entity->player() != Sea::Player(player)) {
            entity->notifyNick(Sea::Player(player), nick);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GameOverMessage::ShipInfo &ship : msg.ships()) {
            QStringList data;
            data << QString::number(ship.pos.x)
                 << QString::number(ship.pos.y)
                 << (ship.direction == Ship::TOP_DOWN ? QStringLiteral("0") : QStringLiteral("1"));
            addField(QStringLiteral("ship") + QString::number(ship.size), data.join( QLatin1String( " " )));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Animation* a : std::as_const(m_animations)) {
        a->start(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
            entity->notifyShips(winner);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        entity->startPlacing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        entity->startPlacing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : m_entities) {
        if (entity->player() == player) {
            return entity;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        if (entity->player() == player) {
            entity->notifyRestartPlacing(player);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        entity->notifyGameOptions();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* e : qAsConst(m_entities)) {
        connect(e, &Entity::compatibility,
                entity, &Entity::setCompatibilityLevel);
        connect(entity, &Entity::compatibility,
                e, &Entity::setCompatibilityLevel);

        connect(e, &Entity::abortGame,
                entity, &Entity::notifyAbort);
        connect(entity, &Entity::abortGame,
                e, &Entity::notifyAbort);
        connect(e, &Entity::restartPlacingShips,
                this, &Controller::restartPlacingShips);
        connect(e, &Entity::restartPlacingShips,
                this, &Controller::notifyRestartPlacingShips);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const GameOverMessage::ShipInfo& ship : msg.ships()) {
                m_seaview->add(m_sea->turn(), new Ship(ship.size, ship.direction, ship.pos));
        }
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : m_entities) {
        int player = entity->player();
        qCDebug(KNAVALBATTLE_LOG) << "found player" << player;
        bitmap |= (1 << player);    
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        if (entity->player() == player) {
            entity->notifyRestartPlacing(player);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
            if (entity != chat_sender) {
                qCDebug(KNAVALBATTLE_LOG) << "forwarding to" << entity->nick();
                entity->notifyChat(chat_sender, text);
            }
        }
```

#### AUTO 


```{c}
const auto myShips = m_sea->myShips();
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
            entity->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Animation* a : qAsConst(m_animations)) {
        a->start(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        entity->notifyGameOptions();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
            if (entity != chat_sender) {
                qCDebug(KNAVALBATTLE_LOG) << "forwarding to" << entity->nick();
                entity->notifyChat(chat_sender, text);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sprite* s : spritesOfPos) {
            if (s->spriteKey().startsWith(QLatin1String("ship"))) {
                s->setZValue(BACKGROUND);
                s->setOpacity(0.5);
            }
            else if (s->spriteKey().startsWith(QLatin1String("hit"))) {
                s->setSpriteKey(QStringLiteral("hit-end"));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        m_sea->clear(entity->player());
            Q_EMIT startPlacingShips(Sea::PLAYER_A);
            entity->startPlacing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        entity->notify(player, c, info);
        if (player == entity->player()) {
            entity->stats()->addInfo(info);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        entity->notifyGameOver(winner);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ship * ship : enemyShips) {
        if (ship->alive()) {
            m_seaview->add(winner, ship);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
        entity->notifyReady(Sea::Player(player));
    }
```

#### AUTO 


```{c}
const auto spritesOfPos = m_sprites.values(p);
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* target : std::as_const(m_entities)) {
            if (source->player() != target->player() &&
                !source->nick().isEmpty()) {
                target->notifyNick(source->player(), source->nick());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : qAsConst(m_entities)) {
            entity->startPlaying();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* target : qAsConst(m_entities)) {
            if (source->player() != target->player() &&
                !source->nick().isEmpty()) {
                target->notifyNick(source->player(), source->nick());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* e : std::as_const(m_entities)) {
        connect(e, &Entity::compatibility,
                entity, &Entity::setCompatibilityLevel);
        connect(entity, &Entity::compatibility,
                e, &Entity::setCompatibilityLevel);

        connect(e, &Entity::abortGame,
                entity, &Entity::notifyAbort);
        connect(entity, &Entity::abortGame,
                e, &Entity::notifyAbort);
        connect(e, &Entity::restartPlacingShips,
                this, &Controller::restartPlacingShips);
        connect(e, &Entity::restartPlacingShips,
                this, &Controller::notifyRestartPlacingShips);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        entity->notifyGameOver(winner);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Ship* ship : myShips) {
            if (ship->alive()) {
                msg->addShip(ship->position(), ship->size(), ship->direction());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* source : std::as_const(m_entities)) {
        for (Entity* target : std::as_const(m_entities)) {
            if (source->player() != target->player() &&
                !source->nick().isEmpty()) {
                target->notifyNick(source->player(), source->nick());
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
            entity->startPlaying();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        m_sea->clear(entity->player());
            Q_EMIT startPlacingShips(Sea::PLAYER_A);
            entity->startPlacing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
            entity->notifyShips(winner);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entity* entity : std::as_const(m_entities)) {
        if (entity->player() != Sea::Player(player)) {
            entity->notifyNick(Sea::Player(player), nick);
        }
    }
```

