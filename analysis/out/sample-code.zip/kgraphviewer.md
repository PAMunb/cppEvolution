#### LAMBDA EXPRESSION 


```{c}
[&]() { print(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&] () { print(); }
```

