#### AUTO 


```{c}
const auto f = parseField(*it);
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const Key &key) {
        return key.id() == id;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : it->paramValues) {
        const auto it = std::find_if(std::begin(email_type_names), std::end(email_type_names), [&s](const email_type_name &t) {
            return QLatin1String(t.name) == s;
        });
        if (it != std::end(email_type_names)) {
            type |= (*it).type;
        }
    }
```

#### AUTO 


```{c}
auto fetchAnotherLine = [&text, &lineStart, &lineEnd, &cur]() -> QByteArray {
                                            const QByteArray ret = cur;
                                            lineStart = lineEnd + 1;
                                            lineEnd = text.indexOf('\n', lineStart);
                                            if (lineEnd != -1) {
                                                cur = text.mid(lineStart, lineEnd - lineStart);
                                                // remove the trailing \r, left from \r\n
                                                if (cur.endsWith('\r')) {
                                                    cur.chop(1);
                                                }
                                            }
                                            return ret;
                                        };
```

#### AUTO 


```{c}
const auto &path
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const PhoneNumber &phone) {
        return phone.id() == id;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr auto GeoUriFields = AddressFormatField::StreetAddress | AddressFormatField::PostalCode | AddressFormatField::Locality
    | AddressFormatField::DependentLocality | AddressFormatField::Region | AddressFormatField::Country;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &country : parsedList) {
        const auto name = KContacts::normalizeCountryName(country.name);
        if (name.isEmpty()) {
            qWarning() << "Skipping empty normalized country name:" << country.name << country.isoCode << country.language;
            continue;
        }
        processedList.push_back(Elem{name, country.isoCode, country.language, 0});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto lhs, const auto &rhs) {
        return lhs | rhs.field();
    }
```

#### AUTO 


```{c}
auto it = parsedList.begin() ;
```

#### AUTO 


```{c}
auto typeIt = d->mParamMap.findParam(paramName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rel : relatedList) {
            VCardLine line(QStringLiteral("RELATED"), rel.related());
            addParameters(line, rel.parameters());
            card.addLine(line);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rel : relatedList) {
            VCardLine line(QStringLiteral("RELATED"), rel.related());
            line.addParameters(rel.params());
            card.addLine(line);
        }
```

#### AUTO 


```{c}
const auto iso = ISOname.simplified().toLower();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : s) {
        switch (c.script()) {
        case QChar::Script_Arabic:
            return AddressFormatScript::ArabicLikeScript;
        case QChar::Script_Han:
            return AddressFormatScript::HanLikeScript;
        case QChar::Script_Hangul:
        case QChar::Script_Thai:
            return AddressFormatScript::HangulLikeScript;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
const auto &id
```

#### AUTO 


```{c}
auto matchFunc = [type, &customTypeString](const Key &key) {
        if (key.type() == type) {
            if (type == Key::Custom) {
                if (customTypeString.isEmpty()) {
                    return true;
                } else {
                    if (key.customTypeString() == customTypeString) {
                        return true;
                    }
                }
            } else {
                return true;
            }
        }
        return false;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Picture &logo : lstLogo) {
            card.addLine(createPicture(QStringLiteral("LOGO"), logo, version));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Address &addr : d->mAddresses) {
        if (matchBinaryPattern(addr.type(), type)) {
            if (addr.type() & Address::Pref) {
                return addr;
            } else if (address.isEmpty()) {
                address = addr;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *jsEngine) -> QJSValue {
        Address address;
        address.setCountry(QStringLiteral("DE"));
        address.setRegion(QStringLiteral("BE"));
        address.setLocality(QStringLiteral("Berlin"));
        address.setPostalCode(QStringLiteral("10969"));
        address.setStreet(QStringLiteral("Prinzenstraße 85 F"));

        auto obj = jsEngine->newObject();
        obj.setProperty(QStringLiteral("address"), jsEngine->toScriptValue(address));
        return obj;
    }
```

#### AUTO 


```{c}
auto it = d->mParamMap.findParam(paramName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &t : url_type_names) {
        if (((type ^ oldType) & t.type) == 0) {
            continue; // no change
        }

        const QLatin1String str(t.name);
        if (type & t.type) {
            it->paramValues.push_back(str);
        } else {
            it->paramValues.removeAll(str);
        }
    }
```

#### AUTO 


```{c}
const auto it = sIsoCache->isoToCountry.constFind(iso);
```

#### AUTO 


```{c}
static const auto VENDOR_ID = QStringLiteral("KADDRESSBOOK");
```

#### LAMBDA EXPRESSION 


```{c}
[&mailAddr](const Email &e) {
        return e.mail() == mailAddr;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto lhs, auto rhs) {
        return lhs.c < rhs;
    }
```

#### AUTO 


```{c}
auto paths = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("kf5/kcontacts/improtocols"), QStandardPaths::LocateDirectory);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &phone : phoneNumbers) {
        VCardLine line(QStringLiteral("TEL"), phone.number());
        const auto paramsMap = phone.parameters();
        for (auto it = paramsMap.cbegin(), endIt = paramsMap.cend(); it != endIt; ++it) {
            if (it.key().toUpper() != QLatin1String("TYPE")) {
                line.addParameter(it.key(), it.value().join(QLatin1Char(',')));
            }
        }

        const PhoneNumber::Type type = phone.type();
        QStringList lst;
        for (const auto &pType : s_phoneTypes) {
            if (pType.flag & type) {
                const QString str = QString::fromLatin1(pType.phoneType);
                if (version == VCard::v4_0) {
                    lst << str.toLower();
                } else {
                    lst << str;
                }
            }
        }
        if (!lst.isEmpty()) {
            addParameter(line, version, QStringLiteral("TYPE"), lst);
        }
        card->addLine(line);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address().url());
            QMapIterator<QString, QStringList> i(impp.parameters());
            while (i.hasNext()) {
                i.next();
                if (i.key().toLower() != QStringLiteral("x-service-type")) {
                    line.addParameter(i.key(), i.value().join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info : s_addressTypes) {
            if (info.flag & addr.type()) {
                const QString str = QString::fromLatin1(info.addressType);
                addreLineType << str;
                if (hasLabel) {
                    labelLineType << str;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Org &org : lstOrg) {
        QStringList organization{org.organization().replace(QLatin1Char(';'), QLatin1String("\\;"))};
        if (!addressee.department().isEmpty()) {
            organization.append(addressee.department().replace(QLatin1Char(';'), QLatin1String("\\;")));
        }
        const QString orgStr = organization.join(QLatin1Char(';'));
        VCardLine orgLine(QStringLiteral("ORG"), orgStr);
        if (version == VCard::v2_1 && needsEncoding(orgStr)) {
            orgLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            orgLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        addParameters(orgLine, org.parameters());
        card->addLine(orgLine);
    }
```

#### AUTO 


```{c}
const auto name = elementAttributes.value(QLatin1String("name"));
```

#### AUTO 


```{c}
auto versionEntryIt = mLineMap.constFind(QStringLiteral("VERSION"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressee : list) {
        VCard card;
        // VERSION
        if (version == VCard::v2_1) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("2.1")));
        } else if (version == VCard::v3_0) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("3.0")));
        } else if (version == VCard::v4_0) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("4.0")));
        }

        // ADR + LABEL
        const Address::List addresses = addressee.addresses();
        processAddresses(addresses, version, &card);

        // BDAY
        const bool withTime = addressee.birthdayHasTime();
        const QString birthdayString = createDateTime(addressee.birthday(), version, withTime);
        card.addLine(VCardLine(QStringLiteral("BDAY"), birthdayString));

        // CATEGORIES only > 2.1
        if (version != VCard::v2_1) {
            QStringList categories = addressee.categories();
            for (auto &cat : categories) {
                cat.replace(QLatin1Char(','), QLatin1String("\\,"));
            }

            VCardLine catLine(QStringLiteral("CATEGORIES"), categories.join(QLatin1Char(',')));
            card.addLine(catLine);
        }
        // MEMBER (only in 4.0)
        if (version == VCard::v4_0) {
            // The KIND property must be set to "group" in order to use this property.
            if (addressee.kind().toLower() == QLatin1String("group")) {
                const QStringList lst = addressee.members();
                for (const QString &member : lst) {
                    card.addLine(VCardLine(QStringLiteral("MEMBER"), member));
                }
            }
        }
        // SOURCE
        const QVector<QUrl> lstUrl = addressee.sourcesUrlList();
        for (const QUrl &url : lstUrl) {
            VCardLine line = VCardLine(QStringLiteral("SOURCE"), url.url());
            card.addLine(line);
        }

        const Related::List relatedList = addressee.relationships();
        for (const auto &rel : relatedList) {
            VCardLine line(QStringLiteral("RELATED"), rel.related());
            line.addParameters(rel.params());
            card.addLine(line);
        }
        // CLASS only for version == 3.0
        if (version == VCard::v3_0) {
            card.addLine(createSecrecy(addressee.secrecy()));
        }
        // LANG only for version == 4.0
        if (version == VCard::v4_0) {
            const Lang::List langList = addressee.langs();
            for (const auto &lang : langList) {
                VCardLine line(QStringLiteral("LANG"), lang.language());
                line.addParameters(lang.params());
                card.addLine(line);
            }
        }
        // CLIENTPIDMAP
        if (version == VCard::v4_0) {
            const ClientPidMap::List clientpidmapList = addressee.clientPidMapList();
            for (const auto &pMap : clientpidmapList) {
                VCardLine line(QStringLiteral("CLIENTPIDMAP"), pMap.clientPidMap());
                line.addParameters(pMap.params());
                card.addLine(line);
            }
        }
        // EMAIL
        const Email::List emailList = addressee.emailList();
        processEmailList(emailList, version, &card);

        // FN required for only version > 2.1
        VCardLine fnLine(QStringLiteral("FN"), addressee.formattedName());
        if (version == VCard::v2_1 && needsEncoding(addressee.formattedName())) {
            fnLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            fnLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        card.addLine(fnLine);

        // GEO
        const Geo geo = addressee.geo();
        if (geo.isValid()) {
            QString str;
            if (version == VCard::v4_0) {
                str = QString::asprintf("geo:%.6f,%.6f", geo.latitude(), geo.longitude());
            } else {
                str = QString::asprintf("%.6f;%.6f", geo.latitude(), geo.longitude());
            }
            card.addLine(VCardLine(QStringLiteral("GEO"), str));
        }

        // KEY
        const Key::List keys = addressee.keys();
        for (const auto &k : keys) {
            card.addLine(createKey(k, version));
        }

        // LOGO
        card.addLine(createPicture(QStringLiteral("LOGO"), addressee.logo(), version));
        const QVector<Picture> lstLogo = addressee.extraLogoList();
        for (const Picture &logo : lstLogo) {
            card.addLine(createPicture(QStringLiteral("LOGO"), logo, version));
        }

        // MAILER only for version < 4.0
        if (version != VCard::v4_0) {
            VCardLine mailerLine(QStringLiteral("MAILER"), addressee.mailer());
            if (version == VCard::v2_1 && needsEncoding(addressee.mailer())) {
                mailerLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                mailerLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card.addLine(mailerLine);
        }

        // N required for only version < 4.0
        QStringList name;
        name.append(addressee.familyName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.givenName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.additionalName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.prefix().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.suffix().replace(QLatin1Char(';'), QStringLiteral("\\;")));

        VCardLine nLine(QStringLiteral("N"), name.join(QLatin1Char(';')));
        if (version == VCard::v2_1 && needsEncoding(name.join(QLatin1Char(';')))) {
            nLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            nLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        if (version == VCard::v4_0 && !addressee.sortString().isEmpty()) {
            nLine.addParameter(QStringLiteral("SORT-AS"), addressee.sortString());
        }

        card.addLine(nLine);

        // NAME only for version < 4.0
        if (version != VCard::v4_0) {
            VCardLine nameLine(QStringLiteral("NAME"), addressee.name());
            if (version == VCard::v2_1 && needsEncoding(addressee.name())) {
                nameLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                nameLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card.addLine(nameLine);
        }

        // NICKNAME only for version > 2.1
        if (version != VCard::v2_1) {
            const QVector<NickName> lstNickName = addressee.extraNickNameList();
            for (const NickName &nickName : lstNickName) {
                VCardLine nickNameLine(QStringLiteral("NICKNAME"), nickName.nickname());
                nickNameLine.addParameters(nickName.params());

                card.addLine(nickNameLine);
            }
        }

        // NOTE
        VCardLine noteLine(QStringLiteral("NOTE"), addressee.note());
        if (version == VCard::v2_1 && needsEncoding(addressee.note())) {
            noteLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            noteLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        card.addLine(noteLine);

        // ORG
        processOrganizations(addressee, version, &card);

        // PHOTO
        card.addLine(createPicture(QStringLiteral("PHOTO"), addressee.photo(), version));
        const QVector<Picture> lstExtraPhoto = addressee.extraPhotoList();
        for (const Picture &photo : lstExtraPhoto) {
            card.addLine(createPicture(QStringLiteral("PHOTO"), photo, version));
        }

        // PROID only for version > 2.1
        if (version != VCard::v2_1) {
            card.addLine(VCardLine(QStringLiteral("PRODID"), addressee.productId()));
        }

        // REV
        card.addLine(VCardLine(QStringLiteral("REV"), createDateTime(addressee.revision(), version)));

        // ROLE
        const QVector<Role> lstExtraRole = addressee.extraRoleList();
        for (const Role &role : lstExtraRole) {
            VCardLine roleLine(QStringLiteral("ROLE"), role.role());
            if (version == VCard::v2_1 && needsEncoding(role.role())) {
                roleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                roleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            roleLine.addParameters(role.params());
            card.addLine(roleLine);
        }

        // SORT-STRING
        if (version == VCard::v3_0) {
            card.addLine(VCardLine(QStringLiteral("SORT-STRING"), addressee.sortString()));
        }

        // SOUND
        card.addLine(createSound(addressee.sound(), version));
        const QVector<Sound> lstSound = addressee.extraSoundList();
        for (const Sound &sound : lstSound) {
            card.addLine(createSound(sound, version));
        }

        // TEL
        const PhoneNumber::List phoneNumbers = addressee.phoneNumbers();
        processPhoneNumbers(phoneNumbers, version, &card);

        // TITLE
        const QVector<Title> lstTitle = addressee.extraTitleList();
        for (const Title &title : lstTitle) {
            VCardLine titleLine(QStringLiteral("TITLE"), title.title());
            if (version == VCard::v2_1 && needsEncoding(title.title())) {
                titleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                titleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            titleLine.addParameters(title.params());

            card.addLine(titleLine);
        }

        // TZ
        // TODO Add vcard4.0 support
        const TimeZone timeZone = addressee.timeZone();
        if (timeZone.isValid()) {
            int neg = 1;
            if (timeZone.offset() < 0) {
                neg = -1;
            }

            QString str =
                QString::asprintf("%c%02d:%02d", (timeZone.offset() >= 0 ? '+' : '-'), (timeZone.offset() / 60) * neg, (timeZone.offset() % 60) * neg);

            card.addLine(VCardLine(QStringLiteral("TZ"), str));
        }

        // UID
        card.addLine(VCardLine(QStringLiteral("UID"), addressee.uid()));

        // URL
        const QVector<ResourceLocatorUrl> lstExtraUrl = addressee.extraUrlList();
        for (const ResourceLocatorUrl &url : lstExtraUrl) {
            VCardLine line(QStringLiteral("URL"), url.url());
            line.addParameters(url.params());
            card.addLine(line);
        }
        if (version == VCard::v4_0) {
            // GENDER
            const Gender gender = addressee.gender();
            if (gender.isValid()) {
                QString genderStr;
                if (!gender.gender().isEmpty()) {
                    genderStr = gender.gender();
                }
                if (!gender.comment().isEmpty()) {
                    genderStr += QLatin1Char(';') + gender.comment();
                }
                VCardLine line(QStringLiteral("GENDER"), genderStr);
                card.addLine(line);
            }
            // KIND
            if (!addressee.kind().isEmpty()) {
                VCardLine line(QStringLiteral("KIND"), addressee.kind());
                card.addLine(line);
            }
        }
        // From vcard4.
        if (version == VCard::v4_0) {
            const QVector<CalendarUrl> lstCalendarUrl = addressee.calendarUrlList();
            for (const CalendarUrl &url : lstCalendarUrl) {
                if (url.isValid()) {
                    QString type;
                    switch (url.type()) {
                    case CalendarUrl::Unknown:
                    case CalendarUrl::EndCalendarType:
                        break;
                    case CalendarUrl::FBUrl:
                        type = QStringLiteral("FBURL");
                        break;
                    case CalendarUrl::CALUri:
                        type = QStringLiteral("CALURI");
                        break;
                    case CalendarUrl::CALADRUri:
                        type = QStringLiteral("CALADRURI");
                        break;
                    }
                    if (!type.isEmpty()) {
                        VCardLine line(type, url.url().toDisplayString());
                        line.addParameters(url.params());
                        card.addLine(line);
                    }
                }
            }
        }

        // FieldGroup
        const QVector<FieldGroup> lstGroup = addressee.fieldGroupList();
        for (const FieldGroup &group : lstGroup) {
            VCardLine line(group.fieldGroupName(), group.value());
            line.addParameters(group.params());
            card.addLine(line);
        }

        // IMPP (supported in vcard 3 too)
        const QVector<Impp> lstImpp = addressee.imppList();
        for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address().url());
            const ParameterMap pMap = impp.params();
            for (const auto &[param, list] : pMap) {
                if (param.toLower() != QLatin1String("x-service-type")) {
                    line.addParameter(param, list.join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }

        // X-
        const QStringList customs = addressee.customs();
        processCustoms(customs, version, &card, exportVcard);

        vCardList.append(card);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Org &org : lstOrg) {
            QStringList organization;
            organization.append(org.organization().replace(QLatin1Char(';'),
                                                           QStringLiteral("\\;")));
            if (!(*addrIt).department().isEmpty()) {
                organization.append((*addrIt).department().replace(QLatin1Char(';'),
                                                                   QStringLiteral("\\;")));
            }
            const QString orgStr = organization.join(QLatin1Char(';'));
            VCardLine orgLine(QStringLiteral("ORG"), orgStr);
            if (version == VCard::v2_1 && needsEncoding(orgStr)) {
                orgLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                orgLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(orgLine, org.parameters());
            card.addLine(orgLine);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressee : list) {
        VCard card;
        // VERSION
        if (version == VCard::v2_1) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("2.1")));
        } else if (version == VCard::v3_0) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("3.0")));
        } else if (version == VCard::v4_0) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("4.0")));
        }

        // ADR + LABEL
        const Address::List addresses = addressee.addresses();
        processAddresses(addresses, version, &card);

        // BDAY
        const bool withTime = addressee.birthdayHasTime();
        const QString birthdayString = createDateTime(addressee.birthday(), version, withTime);
        card.addLine(VCardLine(QStringLiteral("BDAY"), birthdayString));

        // Laurent: 31 Jan 2015. Not necessary to export it. When Categories were changes as AkonadiTag nobody thought that it would break categories support...
        //=> not necessary to export just tag...
        // CATEGORIES only > 2.1
        if (!exportVcard) {
            if (version != VCard::v2_1) {
                QStringList categories = addressee.categories();
                for (auto &cat : categories) {
                    cat.replace(QLatin1Char(','), QLatin1String("\\,"));
                }

                VCardLine catLine(QStringLiteral("CATEGORIES"), categories.join(QLatin1Char(',')));
                card.addLine(catLine);
            }
        }
        // MEMBER (only in 4.0)
        if (version == VCard::v4_0) {
            // The KIND property must be set to "group" in order to use this property.
            if (addressee.kind().toLower() == QLatin1String("group")) {
                const QStringList lst = addressee.members();
                for (const QString &member : lst) {
                    card.addLine(VCardLine(QStringLiteral("MEMBER"), member));
                }
            }
        }
        // SOURCE
        const QVector<QUrl> lstUrl = addressee.sourcesUrlList();
        for (const QUrl &url : lstUrl) {
            VCardLine line = VCardLine(QStringLiteral("SOURCE"), url.url());
            card.addLine(line);
        }

        const Related::List relatedList = addressee.relationships();
        for (const auto &rel : relatedList) {
            VCardLine line(QStringLiteral("RELATED"), rel.related());
            line.addParameters(rel.params());
            card.addLine(line);
        }
        // CLASS only for version == 3.0
        if (version == VCard::v3_0) {
            card.addLine(createSecrecy(addressee.secrecy()));
        }
        // LANG only for version == 4.0
        if (version == VCard::v4_0) {
            const Lang::List langList = addressee.langs();
            for (const auto &lang : langList) {
                VCardLine line(QStringLiteral("LANG"), lang.language());
                line.addParameters(lang.params());
                card.addLine(line);
            }
        }
        // CLIENTPIDMAP
        if (version == VCard::v4_0) {
            const ClientPidMap::List clientpidmapList = addressee.clientPidMapList();
            for (const auto &pMap : clientpidmapList) {
                VCardLine line(QStringLiteral("CLIENTPIDMAP"), pMap.clientPidMap());
                line.addParameters(pMap.params());
                card.addLine(line);
            }
        }
        // EMAIL
        const Email::List emailList = addressee.emailList();
        processEmailList(emailList, version, &card);

        // FN required for only version > 2.1
        VCardLine fnLine(QStringLiteral("FN"), addressee.formattedName());
        if (version == VCard::v2_1 && needsEncoding(addressee.formattedName())) {
            fnLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            fnLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        card.addLine(fnLine);

        // GEO
        const Geo geo = addressee.geo();
        if (geo.isValid()) {
            QString str;
            if (version == VCard::v4_0) {
                str = QString::asprintf("geo:%.6f,%.6f", geo.latitude(), geo.longitude());
            } else {
                str = QString::asprintf("%.6f;%.6f", geo.latitude(), geo.longitude());
            }
            card.addLine(VCardLine(QStringLiteral("GEO"), str));
        }

        // KEY
        const Key::List keys = addressee.keys();
        for (const auto &k : keys) {
            card.addLine(createKey(k, version));
        }

        // LOGO
        card.addLine(createPicture(QStringLiteral("LOGO"), addressee.logo(), version));
        const QVector<Picture> lstLogo = addressee.extraLogoList();
        for (const Picture &logo : lstLogo) {
            card.addLine(createPicture(QStringLiteral("LOGO"), logo, version));
        }

        // MAILER only for version < 4.0
        if (version != VCard::v4_0) {
            VCardLine mailerLine(QStringLiteral("MAILER"), addressee.mailer());
            if (version == VCard::v2_1 && needsEncoding(addressee.mailer())) {
                mailerLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                mailerLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card.addLine(mailerLine);
        }

        // N required for only version < 4.0
        QStringList name;
        name.append(addressee.familyName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.givenName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.additionalName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.prefix().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.suffix().replace(QLatin1Char(';'), QStringLiteral("\\;")));

        VCardLine nLine(QStringLiteral("N"), name.join(QLatin1Char(';')));
        if (version == VCard::v2_1 && needsEncoding(name.join(QLatin1Char(';')))) {
            nLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            nLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        if (version == VCard::v4_0 && !addressee.sortString().isEmpty()) {
            nLine.addParameter(QStringLiteral("SORT-AS"), addressee.sortString());
        }

        card.addLine(nLine);

        // NAME only for version < 4.0
        if (version != VCard::v4_0) {
            VCardLine nameLine(QStringLiteral("NAME"), addressee.name());
            if (version == VCard::v2_1 && needsEncoding(addressee.name())) {
                nameLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                nameLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card.addLine(nameLine);
        }

        // NICKNAME only for version > 2.1
        if (version != VCard::v2_1) {
            const QVector<NickName> lstNickName = addressee.extraNickNameList();
            for (const NickName &nickName : lstNickName) {
                VCardLine nickNameLine(QStringLiteral("NICKNAME"), nickName.nickname());
                nickNameLine.addParameters(nickName.params());

                card.addLine(nickNameLine);
            }
        }

        // NOTE
        VCardLine noteLine(QStringLiteral("NOTE"), addressee.note());
        if (version == VCard::v2_1 && needsEncoding(addressee.note())) {
            noteLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            noteLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        card.addLine(noteLine);

        // ORG
        processOrganizations(addressee, version, &card);

        // PHOTO
        card.addLine(createPicture(QStringLiteral("PHOTO"), addressee.photo(), version));
        const QVector<Picture> lstExtraPhoto = addressee.extraPhotoList();
        for (const Picture &photo : lstExtraPhoto) {
            card.addLine(createPicture(QStringLiteral("PHOTO"), photo, version));
        }

        // PROID only for version > 2.1
        if (version != VCard::v2_1) {
            card.addLine(VCardLine(QStringLiteral("PRODID"), addressee.productId()));
        }

        // REV
        card.addLine(VCardLine(QStringLiteral("REV"), createDateTime(addressee.revision(), version)));

        // ROLE
        const QVector<Role> lstExtraRole = addressee.extraRoleList();
        for (const Role &role : lstExtraRole) {
            VCardLine roleLine(QStringLiteral("ROLE"), role.role());
            if (version == VCard::v2_1 && needsEncoding(role.role())) {
                roleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                roleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            roleLine.addParameters(role.params());
            card.addLine(roleLine);
        }

        // SORT-STRING
        if (version == VCard::v3_0) {
            card.addLine(VCardLine(QStringLiteral("SORT-STRING"), addressee.sortString()));
        }

        // SOUND
        card.addLine(createSound(addressee.sound(), version));
        const QVector<Sound> lstSound = addressee.extraSoundList();
        for (const Sound &sound : lstSound) {
            card.addLine(createSound(sound, version));
        }

        // TEL
        const PhoneNumber::List phoneNumbers = addressee.phoneNumbers();
        processPhoneNumbers(phoneNumbers, version, &card);

        // TITLE
        const QVector<Title> lstTitle = addressee.extraTitleList();
        for (const Title &title : lstTitle) {
            VCardLine titleLine(QStringLiteral("TITLE"), title.title());
            if (version == VCard::v2_1 && needsEncoding(title.title())) {
                titleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                titleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            titleLine.addParameters(title.params());

            card.addLine(titleLine);
        }

        // TZ
        // TODO Add vcard4.0 support
        const TimeZone timeZone = addressee.timeZone();
        if (timeZone.isValid()) {
            int neg = 1;
            if (timeZone.offset() < 0) {
                neg = -1;
            }

            QString str =
                QString::asprintf("%c%02d:%02d", (timeZone.offset() >= 0 ? '+' : '-'), (timeZone.offset() / 60) * neg, (timeZone.offset() % 60) * neg);

            card.addLine(VCardLine(QStringLiteral("TZ"), str));
        }

        // UID
        card.addLine(VCardLine(QStringLiteral("UID"), addressee.uid()));

        // URL
        const QVector<ResourceLocatorUrl> lstExtraUrl = addressee.extraUrlList();
        for (const ResourceLocatorUrl &url : lstExtraUrl) {
            VCardLine line(QStringLiteral("URL"), url.url());
            line.addParameters(url.params());
            card.addLine(line);
        }
        if (version == VCard::v4_0) {
            // GENDER
            const Gender gender = addressee.gender();
            if (gender.isValid()) {
                QString genderStr;
                if (!gender.gender().isEmpty()) {
                    genderStr = gender.gender();
                }
                if (!gender.comment().isEmpty()) {
                    genderStr += QLatin1Char(';') + gender.comment();
                }
                VCardLine line(QStringLiteral("GENDER"), genderStr);
                card.addLine(line);
            }
            // KIND
            if (!addressee.kind().isEmpty()) {
                VCardLine line(QStringLiteral("KIND"), addressee.kind());
                card.addLine(line);
            }
        }
        // From vcard4.
        if (version == VCard::v4_0) {
            const QVector<CalendarUrl> lstCalendarUrl = addressee.calendarUrlList();
            for (const CalendarUrl &url : lstCalendarUrl) {
                if (url.isValid()) {
                    QString type;
                    switch (url.type()) {
                    case CalendarUrl::Unknown:
                    case CalendarUrl::EndCalendarType:
                        break;
                    case CalendarUrl::FBUrl:
                        type = QStringLiteral("FBURL");
                        break;
                    case CalendarUrl::CALUri:
                        type = QStringLiteral("CALURI");
                        break;
                    case CalendarUrl::CALADRUri:
                        type = QStringLiteral("CALADRURI");
                        break;
                    }
                    if (!type.isEmpty()) {
                        VCardLine line(type, url.url().toDisplayString());
                        line.addParameters(url.params());
                        card.addLine(line);
                    }
                }
            }
        }

        // FieldGroup
        const QVector<FieldGroup> lstGroup = addressee.fieldGroupList();
        for (const FieldGroup &group : lstGroup) {
            VCardLine line(group.fieldGroupName(), group.value());
            line.addParameters(group.params());
            card.addLine(line);
        }

        // IMPP (supported in vcard 3 too)
        const QVector<Impp> lstImpp = addressee.imppList();
        for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address().url());
            const ParameterMap pMap = impp.params();
            for (const auto &[param, list] : pMap) {
                if (param.toLower() != QLatin1String("x-service-type")) {
                    line.addParameter(param, list.join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }

        // X-
        const QStringList customs = addressee.customs();
        processCustoms(customs, version, &card, exportVcard);

        vCardList.append(card);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : std::as_const(idents)) {
            lines = card.lines(id);

            // iterate over the lines
            for (const VCardLine &vline : std::as_const(lines)) {
                QVariant val = vline.value();
                if (val.isValid()) {
                    if (vline.hasGroup()) {
                        textLine = vline.group().toLatin1() + '.' + vline.identifier().toLatin1();
                    } else {
                        textLine = vline.identifier().toLatin1();
                    }

                    params = vline.parameterList();
                    hasEncoding = false;
                    if (!params.isEmpty()) { // we have parameters
                        for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
                    }

                    QByteArray input;
                    QByteArray output;
                    bool checkMultibyte = false; // avoid splitting a multibyte character

                    // handle charset
                    const QString charset = vline.parameter(QStringLiteral("charset"));
                    if (!charset.isEmpty()) {
                        // have to convert the data
                        const QString value = vline.value().toString();
                        QTextCodec *codec = QTextCodec::codecForName(charset.toLatin1());
                        if (codec) {
                            input = codec->fromUnicode(value);
                        } else {
                            checkMultibyte = true;
                            input = value.toUtf8();
                        }
                    } else if (vline.value().type() == QVariant::ByteArray) {
                        input = vline.value().toByteArray();
                    } else {
                        checkMultibyte = true;
                        input = vline.value().toString().toUtf8();
                    }

                    // handle encoding
                    if (hasEncoding) { // have to encode the data
                        if (encodingType == QLatin1Char('b')) {
                            checkMultibyte = false;
                            output = input.toBase64();
                        } else if (encodingType == QLatin1String("quoted-printable")) {
                            checkMultibyte = false;
                            KCodecs::quotedPrintableEncode(input, output, false);
                        }
                    } else {
                        output = input;
                    }
                    addEscapes(output, (vline.identifier() == QLatin1String("CATEGORIES") || vline.identifier() == QLatin1String("GEO")));

                    if (!output.isEmpty()) {
                        textLine.append(':' + output);

                        if (textLine.length() > FOLD_WIDTH) { // we have to fold the line
                            if (checkMultibyte) {
                                // RFC 6350: Multi-octet characters MUST remain contiguous.
                                // we know that textLine contains UTF-8 encoded characters
                                int lineLength = 0;
                                for (int i = 0; i < textLine.length(); ++i) {
                                    if ((textLine[i] & 0xC0) == 0xC0) { // a multibyte sequence follows
                                        int sequenceLength = 2;
                                        if ((textLine[i] & 0xE0) == 0xE0) {
                                            sequenceLength = 3;
                                        } else if ((textLine[i] & 0xF0) == 0xF0) {
                                            sequenceLength = 4;
                                        }
                                        if ((lineLength + sequenceLength) > FOLD_WIDTH) {
                                            // the current line would be too long. fold it
                                            text += "\r\n " + textLine.mid(i, sequenceLength);
                                            lineLength = 1 + sequenceLength; // incl. leading space
                                        } else {
                                            text += textLine.mid(i, sequenceLength);
                                            lineLength += sequenceLength;
                                        }
                                        i += sequenceLength - 1;
                                    } else {
                                        text += textLine[i];
                                        ++lineLength;
                                    }
                                    if ((lineLength == FOLD_WIDTH) && (i < (textLine.length() - 1))) {
                                        text += "\r\n ";
                                        lineLength = 1; // leading space
                                    }
                                }
                                text += "\r\n";
                            } else {
                                for (int i = 0; i <= (textLine.length() / FOLD_WIDTH); ++i) {
                                    text.append((i == 0 ? "" : " ") + textLine.mid(i * FOLD_WIDTH, FOLD_WIDTH) + "\r\n");
                                }
                            }
                        } else {
                            text.append(textLine + "\r\n");
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto path = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("kf5/kcontacts/improtocols/") + serviceType + QStringLiteral(".desktop"));
```

#### AUTO 


```{c}
auto it = std::remove_if(d->mKeys.begin(), d->mKeys.end(), [&key](const Key &k) {
        return k.id() == key.id();
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[param, list] : paramsMap) {
            if (param.toUpper() != QLatin1String("TYPE")) {
                line.addParameter(param, list.join(QLatin1Char(',')));
            }
        }
```

#### AUTO 


```{c}
const auto &email
```

#### AUTO 


```{c}
const auto scriptPref = AddressFormatScript::detect(address) == AddressFormatScript::LatinLikeScript ? AddressFormatScriptPreference::Latin
                                                                                                         : AddressFormatScriptPreference::Local;
```

#### AUTO 


```{c}
const auto sourceCountry = KCountry::fromQLocale(QLocale().country());
```

#### LAMBDA EXPRESSION 


```{c}
[&text, &lineStart, &lineEnd, &cur]() -> QByteArray {
                    const QByteArray ret = cur;
                    lineStart = lineEnd + 1;
                    lineEnd = text.indexOf('\n', lineStart);
                    if (lineEnd != -1) {
                        cur = text.mid(lineStart, lineEnd - lineStart);
                        // remove the trailing \r, left from \r\n
                        if (cur.endsWith('\r')) {
                            cur.chop(1);
                        }
                    }
                    return ret;
                }
```

#### AUTO 


```{c}
static const auto X_PROFESSION = QStringLiteral("X-Profession");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto f : list) {
        if ((type() & f) && (f != Pref)) {
            label.append(QLatin1Char('/') + typeLabel(f));
        }
    }
```

#### AUTO 


```{c}
const auto &[p, list]
```

#### AUTO 


```{c}
const auto format = AddressFormatRepository::formatForAddress(*this, formatPref);
```

#### AUTO 


```{c}
const auto parsedList = TranslatedCountries::parseFilesRecursive(sourceDirPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const VCardLine &vline : std::as_const(lines)) {
                QVariant val = vline.value();
                if (val.isValid()) {
                    if (vline.hasGroup()) {
                        textLine = vline.group().toLatin1() + '.' + vline.identifier().toLatin1();
                    } else {
                        textLine = vline.identifier().toLatin1();
                    }

                    params = vline.parameterList();
                    hasEncoding = false;
                    if (!params.isEmpty()) { // we have parameters
                        for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
                    }

                    QByteArray input;
                    QByteArray output;
                    bool checkMultibyte = false; // avoid splitting a multibyte character

                    // handle charset
                    const QString charset = vline.parameter(QStringLiteral("charset"));
                    if (!charset.isEmpty()) {
                        // have to convert the data
                        const QString value = vline.value().toString();
                        QTextCodec *codec = QTextCodec::codecForName(charset.toLatin1());
                        if (codec) {
                            input = codec->fromUnicode(value);
                        } else {
                            checkMultibyte = true;
                            input = value.toUtf8();
                        }
                    } else if (vline.value().type() == QVariant::ByteArray) {
                        input = vline.value().toByteArray();
                    } else {
                        checkMultibyte = true;
                        input = vline.value().toString().toUtf8();
                    }

                    // handle encoding
                    if (hasEncoding) { // have to encode the data
                        if (encodingType == QLatin1Char('b')) {
                            checkMultibyte = false;
                            output = input.toBase64();
                        } else if (encodingType == QLatin1String("quoted-printable")) {
                            checkMultibyte = false;
                            KCodecs::quotedPrintableEncode(input, output, false);
                        }
                    } else {
                        output = input;
                    }
                    addEscapes(output, (vline.identifier() == QLatin1String("CATEGORIES") || vline.identifier() == QLatin1String("GEO")));

                    if (!output.isEmpty()) {
                        textLine.append(':' + output);

                        if (textLine.length() > FOLD_WIDTH) { // we have to fold the line
                            if (checkMultibyte) {
                                // RFC 6350: Multi-octet characters MUST remain contiguous.
                                // we know that textLine contains UTF-8 encoded characters
                                int lineLength = 0;
                                for (int i = 0; i < textLine.length(); ++i) {
                                    if ((textLine[i] & 0xC0) == 0xC0) { // a multibyte sequence follows
                                        int sequenceLength = 2;
                                        if ((textLine[i] & 0xE0) == 0xE0) {
                                            sequenceLength = 3;
                                        } else if ((textLine[i] & 0xF0) == 0xF0) {
                                            sequenceLength = 4;
                                        }
                                        if ((lineLength + sequenceLength) > FOLD_WIDTH) {
                                            // the current line would be too long. fold it
                                            text += "\r\n " + textLine.mid(i, sequenceLength);
                                            lineLength = 1 + sequenceLength; // incl. leading space
                                        } else {
                                            text += textLine.mid(i, sequenceLength);
                                            lineLength += sequenceLength;
                                        }
                                        i += sequenceLength - 1;
                                    } else {
                                        text += textLine[i];
                                        ++lineLength;
                                    }
                                    if ((lineLength == FOLD_WIDTH) && (i < (textLine.length() - 1))) {
                                        text += "\r\n ";
                                        lineLength = 1; // leading space
                                    }
                                }
                                text += "\r\n";
                            } else {
                                for (int i = 0; i <= (textLine.length() / FOLD_WIDTH); ++i) {
                                    text.append((i == 0 ? "" : " ") + textLine.mid(i * FOLD_WIDTH, FOLD_WIDTH) + "\r\n");
                                }
                            }
                        } else {
                            text.append(textLine);
                            text.append("\r\n");
                        }
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const VCardLine &vline : std::as_const(lines)) {
                QVariant val = vline.value();
                if (val.isValid()) {
                    if (vline.hasGroup()) {
                        textLine = vline.group().toLatin1() + '.' + vline.identifier().toLatin1();
                    } else {
                        textLine = vline.identifier().toLatin1();
                    }

                    params = vline.parameterList();
                    hasEncoding = false;
                    if (!params.isEmpty()) { // we have parameters
                        for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
                    }

                    QByteArray input;
                    QByteArray output;
                    bool checkMultibyte = false; // avoid splitting a multibyte character

                    // handle charset
                    const QString charset = vline.parameter(QStringLiteral("charset"));
                    if (!charset.isEmpty()) {
                        // have to convert the data
                        const QString value = vline.value().toString();
                        QTextCodec *codec = QTextCodec::codecForName(charset.toLatin1());
                        if (codec) {
                            input = codec->fromUnicode(value);
                        } else {
                            checkMultibyte = true;
                            input = value.toUtf8();
                        }
                    } else if (vline.value().type() == QVariant::ByteArray) {
                        input = vline.value().toByteArray();
                    } else {
                        checkMultibyte = true;
                        input = vline.value().toString().toUtf8();
                    }

                    // handle encoding
                    if (hasEncoding) { // have to encode the data
                        if (encodingType == QLatin1Char('b')) {
                            checkMultibyte = false;
                            output = input.toBase64();
                        } else if (encodingType == QLatin1String("quoted-printable")) {
                            checkMultibyte = false;
                            KCodecs::quotedPrintableEncode(input, output, false);
                        }
                    } else {
                        output = input;
                    }
                    addEscapes(output, (vline.identifier() == QLatin1String("CATEGORIES") || vline.identifier() == QLatin1String("GEO")));

                    if (!output.isEmpty()) {
                        textLine.append(':' + output);

                        if (textLine.length() > FOLD_WIDTH) { // we have to fold the line
                            if (checkMultibyte) {
                                // RFC 6350: Multi-octet characters MUST remain contiguous.
                                // we know that textLine contains UTF-8 encoded characters
                                int lineLength = 0;
                                for (int i = 0; i < textLine.length(); ++i) {
                                    if ((textLine[i] & 0xC0) == 0xC0) { // a multibyte sequence follows
                                        int sequenceLength = 2;
                                        if ((textLine[i] & 0xE0) == 0xE0) {
                                            sequenceLength = 3;
                                        } else if ((textLine[i] & 0xF0) == 0xF0) {
                                            sequenceLength = 4;
                                        }
                                        if ((lineLength + sequenceLength) > FOLD_WIDTH) {
                                            // the current line would be too long. fold it
                                            text += "\r\n " + textLine.mid(i, sequenceLength);
                                            lineLength = 1 + sequenceLength; // incl. leading space
                                        } else {
                                            text += textLine.mid(i, sequenceLength);
                                            lineLength += sequenceLength;
                                        }
                                        i += sequenceLength - 1;
                                    } else {
                                        text += textLine[i];
                                        ++lineLength;
                                    }
                                    if ((lineLength == FOLD_WIDTH) && (i < (textLine.length() - 1))) {
                                        text += "\r\n ";
                                        lineLength = 1; // leading space
                                    }
                                }
                                text += "\r\n";
                            } else {
                                for (int i = 0; i <= (textLine.length() / FOLD_WIDTH); ++i) {
                                    text.append((i == 0 ? "" : " ") + textLine.mid(i * FOLD_WIDTH, FOLD_WIDTH) + "\r\n");
                                }
                            }
                        } else {
                            text.append(textLine + "\r\n");
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto fmt = AddressFormatPrivate::get(format);
```

#### AUTO 


```{c}
const auto &lang
```

#### LAMBDA EXPRESSION 


```{c}
[](const PhoneNumber::List &list, PhoneNumber::TypeFlag compareFlag) {
        auto it = std::find_if(list.cbegin(), list.cend(), [=](const PhoneNumber &phone) {
            return (phone.type() & ~(PhoneNumber::Pref)) == compareFlag;
        });
        return it;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : types) {
        const KContacts::PhoneNumber phone(QStringLiteral("1"), type);
        QCOMPARE(phone.type(), type);

        // Pref is special cased
        if (type != KContacts::PhoneNumber::Pref) {
            QCOMPARE(phone.typeLabel(), KContacts::PhoneNumber::typeFlagLabel((KContacts::PhoneNumber::TypeFlag)(int)type));
            labels.insert(type, phone.typeLabel());
        } else {
            labels.insert(type, KContacts::PhoneNumber::typeFlagLabel((KContacts::PhoneNumber::TypeFlag)(int)type));
        }
        QCOMPARE(KContacts::PhoneNumber::typeLabel(type), phone.typeLabel());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type](const Address &addr) {
        return matchBinaryPattern(addr.type(), type);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourceLocatorUrl &url : lstExtraUrl) {
            VCardLine line(QStringLiteral("URL"), url.url());
            addParameters(line, url.parameters());
            card.addLine(line);
        }
```

#### AUTO 


```{c}
const auto it = std::lower_bound(std::begin(field_map), std::end(field_map), c.cell(), [](auto lhs, auto rhs) {
        return lhs.c < rhs;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : d->mNumber) {
        if (c.isDigit() || (c == QLatin1Char('+') && result.isEmpty())) {
            result.push_back(c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldGroup &group : lstGroup) {
            VCardLine line(group.fieldGroupName(), group.value());
            addParameters(line, group.parameters());
            card.addLine(line);
        }
```

#### AUTO 


```{c}
auto it = std::find_if(d->mEmails.begin(), d->mEmails.end(), [&mailAddr](const Email &e) {
        return e.mail() == mailAddr;
    });
```

#### AUTO 


```{c}
auto it = params.begin(), endIt = params.cend();
```

#### AUTO 


```{c}
static const auto X_OFFICE = QStringLiteral("X-Office");
```

#### AUTO 


```{c}
const auto &addr
```

#### AUTO 


```{c}
auto it = paramMap.cbegin(), endIt = paramMap.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addr : addresses) {
        QStringList address;

        // clang-format off
        const bool isEmpty = addr.postOfficeBox().isEmpty()
                             && addr.extended().isEmpty()
                             && addr.street().isEmpty()
                             && addr.locality().isEmpty()
                             && addr.region().isEmpty()
                             && addr.postalCode().isEmpty()
                             && addr.country().isEmpty();
        // clang-format on

        address.append(addr.postOfficeBox().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.extended().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.street().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.locality().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.region().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.postalCode().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.country().replace(QLatin1Char(';'), QStringLiteral("\\;")));

        const QString addressJoined(address.join(QLatin1Char(';')));
        VCardLine adrLine(QStringLiteral("ADR"), addressJoined);
        if (version == VCard::v2_1 && needsEncoding(addressJoined)) {
            adrLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            adrLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }

        const bool hasLabel = !addr.label().isEmpty();
        QStringList addreLineType;
        QStringList labelLineType;

        for (const auto &info : s_addressTypes) {
            if (info.flag & addr.type()) {
                const QString str = QString::fromLatin1(info.addressType);
                addreLineType << str;
                if (hasLabel) {
                    labelLineType << str;
                }
            }
        }

        if (hasLabel) {
            if (version == VCard::v4_0) {
                if (!addr.label().isEmpty()) {
                    adrLine.addParameter(QStringLiteral("LABEL"), QStringLiteral("\"%1\"").arg(addr.label()));
                }
            } else {
                VCardLine labelLine(QStringLiteral("LABEL"), addr.label());
                if (version == VCard::v2_1 && needsEncoding(addr.label())) {
                    labelLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                    labelLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
                }
                addParameter(&labelLine, version, QStringLiteral("TYPE"), labelLineType);
                card->addLine(labelLine);
            }
        }
        if (version == VCard::v4_0) {
            Geo geo = addr.geo();
            if (geo.isValid()) {
                QString str = QString::asprintf("\"geo:%.6f,%.6f\"", geo.latitude(), geo.longitude());
                adrLine.addParameter(QStringLiteral("GEO"), str);
            }
        }
        if (!isEmpty) {
            addParameter(&adrLine, version, QStringLiteral("TYPE"), addreLineType);
            card->addLine(adrLine);
        }
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(std::begin(email_type_names), std::end(email_type_names), [s](const email_type_name &t) {
            return QLatin1String(t.name) == s;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &lang : langList) {
                VCardLine line(QStringLiteral("LANG"), lang.language());
                addParameters(line, lang.parameters());
                card.addLine(line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &c : countries) {
        out.write("    \"");
        out.write(c.name.toUtf8());
        out.write("\\0\"\n");
        c.offset = off;
        off += c.name.toUtf8().size() + 1;
    }
```

#### AUTO 


```{c}
const auto fi = it.fileInfo();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Elem &lhs, const Elem &rhs) {
        const auto c = strcmp(lhs.name.constData(), rhs.name.constData());
        if (c == 0) {
            return lhs.isoCode < rhs.isoCode;
        }
        return  c < 0;
    }
```

#### AUTO 


```{c}
const auto it = d->mParamMap.findParam(QLatin1String("pref"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : KContacts::Impp::serviceTypes()) {
        QTest::newRow(type.toLatin1().constData()) << type << true;
    }
```

#### AUTO 


```{c}
auto fetchAnotherLine = [&text, &lineStart, &lineEnd, &cur]() -> QByteArray {
                    const QByteArray ret = cur;
                    lineStart = lineEnd + 1;
                    lineEnd = text.indexOf('\n', lineStart);
                    if (lineEnd != -1) {
                        cur = text.mid(lineStart, lineEnd - lineStart);
                        // remove the trailing \r, left from \r\n
                        if (cur.endsWith('\r')) {
                            cur.chop(1);
                        }
                    }
                    return ret;
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Title &title : lstTitle) {
            VCardLine titleLine(QStringLiteral("TITLE"), title.title());
            if (version == VCard::v2_1 && needsEncoding(title.title())) {
                titleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                titleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            titleLine.addParameters(title.params());

            card.addLine(titleLine);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inputFile : std::as_const(mInputFiles)) {
        const QString outFile = outFilePattern.arg(inputFile);
        const QString outFileV2_1 = outFile21Pattern.arg(inputFile);
        const QString outFileV4 = outFile4Pattern.arg(inputFile);
        QTest::newRow(QFile::encodeName(inputFile).constData())
            << inputFile << (mOutput2_1Dir.exists(outFileV2_1) ? outFileV2_1 : QString()) << (mOutput3_0Dir.exists(outFile) ? outFile : QString())
            << (mOutput4_0Dir.exists(outFileV4) ? outFileV4 : QString());
    }
```

#### AUTO 


```{c}
auto findPhone = [](const PhoneNumber::List &list, PhoneNumber::TypeFlag compareFlag) {
        auto it = std::find_if(list.cbegin(), list.cend(), [=](const PhoneNumber &phone) {
            return (phone.type() & ~(PhoneNumber::Pref)) == compareFlag;
        });
        return it;
    };
```

#### CONST EXPRESSION 


```{c}
static constexpr auto AllDomesticFields = AllFields & ~(int)AddressFormatField::Country;
```

#### AUTO 


```{c}
static constexpr auto AllFields = AddressFormatField::Country | AddressFormatField::Region | AddressFormatField::Locality
    | AddressFormatField::DependentLocality | AddressFormatField::SortingCode | AddressFormatField::PostalCode | AddressFormatField::StreetAddress
    | AddressFormatField::Organization | AddressFormatField::Name | AddressFormatField::PostOfficeBox;
```

#### AUTO 


```{c}
auto obj = jsEngine->newObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inputFile : qAsConst(mInputFiles)) {
        const QString outFile = outFilePattern.arg(inputFile);
        const QString outFileV2_1 = outFile21Pattern.arg(inputFile);
        const QString outFileV4 = outFile4Pattern.arg(inputFile);
        QTest::newRow(QFile::encodeName(inputFile).constData())
            << inputFile
            << (mOutput2_1Dir.exists(outFileV2_1) ? outFileV2_1 : QString())
            << (mOutput3_0Dir.exists(outFile) ? outFile : QString())
            << (mOutput4_0Dir.exists(outFileV4) ? outFileV4 : QString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&address](const Address &addr) {
        return addr.id() == address.id();
    }
```

#### AUTO 


```{c}
const auto c = KCountry::fromAlpha2(isoCodeOrName);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Elem &lhs, const Elem &rhs) {
        return strcmp(lhs.name.constData(), rhs.name.constData()) == 0 && lhs.isoCode == rhs.isoCode;
    }
```

#### AUTO 


```{c}
auto encodedName = elem.name;
```

#### AUTO 


```{c}
auto calurl = lst.at(0).extraUrlList().at(0);
```

#### AUTO 


```{c}
const auto &[param, values]
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[p, list] : map) {
        s << p << list;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : qAsConst(types)) {
        KContacts::PhoneNumber::Type combinedType = type | KContacts::PhoneNumber::Pref;
        const KContacts::PhoneNumber phone(QLatin1String("1"), combinedType);
        QCOMPARE(phone.type(), combinedType);
        QCOMPARE(KContacts::PhoneNumber::typeLabel(combinedType), phone.typeLabel());

        if (type < KContacts::PhoneNumber::Pref) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[type]).arg(labels[KContacts::PhoneNumber::Pref]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        } else if (type > KContacts::PhoneNumber::Pref) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[KContacts::PhoneNumber::Pref]).arg(labels[type]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        }
    }
```

#### AUTO 


```{c}
const auto it =
        std::lower_bound(std::begin(iso_to_country_index), std::end(iso_to_country_index), iso.constData(), [](const IsoToCountryIndex &lhs, const char *rhs) {
            return strncmp(&lhs.m_c1, rhs, 2) < 0;
        });
```

#### AUTO 


```{c}
auto versionEntryIt = findByLineId(QLatin1String(s_verStr));
```

#### AUTO 


```{c}
auto it = std::lower_bound(std::begin(country_to_iso_index), std::end(country_to_iso_index), lookupKey, [](const CountryToIsoIndex &lhs, const QByteArray &rhs) {
        return strcmp(country_name_stringtable + lhs.m_offset, rhs.constData()) < 0;
    });
```

#### AUTO 


```{c}
auto it = std::find_if(d->mPhoneNumbers.cbegin(), d->mPhoneNumbers.cend(), [&id](const PhoneNumber &phone) {
        return phone.id() == id;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &str : list) {
        if (!str.isEmpty()) {
            container.insert(str);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[param, list] : params) {
        addParameter(param, list.join(QLatin1Char(',')));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[param, list] : pMap) {
                if (param.toLower() != QLatin1String("x-service-type")) {
                    line.addParameter(param, list.join(QLatin1Char(',')));
                }
            }
```

#### AUTO 


```{c}
const auto iso = ISOname.simplified().toLower().toUtf8();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &countryCode : groups) {
            // qDebug() << countryCode;
            QVERIFY(KCountry::fromAlpha2(countryCode).isValid());
            const auto group = config.group(countryCode);

            QVERIFY(group.hasKey("AddressFormat"));
            const auto upper = parseFields(group.readEntry("Upper"));
            const auto required = parseFields(group.readEntry("Required"));

            // TODO can we check all language variants as well?
            for (const auto &key : {"AddressFormat", "BusinessAddressFormat", "LatinAddressFormat", "LatinBusinessAddressFormat"}) {
                if (!group.hasKey(key)) {
                    continue;
                }
                const auto elems = parseElements(group.readEntry(key, QString()));

                AddressFormatFields seen = AddressFormatField::NoField;
                for (const auto &elem : elems) {
                    if (!elem.isField()) {
                        continue;
                    }
                    QCOMPARE(seen & elem.field() & ~(int)AddressFormatField::SortingCode, 0);
                    seen |= elem.field();
                }

                QCOMPARE(seen & required, required);
                QCOMPARE(seen & upper & ~(int)AddressFormatField::Country, upper & ~(int)AddressFormatField::Country);
            }

            const auto zipRegEx = group.readEntry("PostalCodeFormat", QString());
            if (!zipRegEx.isEmpty()) {
                QVERIFY(QRegularExpression(zipRegEx).isValid());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &parameter : tmpParams) {
                            if (parameter.contains('=')) {
                                if (tmpParameter.isEmpty()) {
                                    tmpParameter = parameter;
                                } else {
                                    params << tmpParameter;
                                    tmpParameter = parameter;
                                }
                            } else {
                                if (tmpParameter.isEmpty() && !valueAdded) {
                                    tmpParameter = parameter;
                                    valueAdded = true;
                                } else {
                                    tmpParameter += ';' + parameter;
                                }
                            }
                        }
```

#### AUTO 


```{c}
const auto &pType
```

#### AUTO 


```{c}
auto it = findByLineId(identifier);
```

#### AUTO 


```{c}
auto it = d->findByName(qualifiedName);
```

#### LAMBDA EXPRESSION 


```{c}
[](const CountryToIsoIndex &lhs, const QByteArray &rhs) {
        return strncmp(country_name_stringtable + lhs.m_offset, rhs.constData(), strlen(country_name_stringtable + lhs.m_offset)) < 0;
    }
```

#### AUTO 


```{c}
auto it = d->mParamMap.findParam(QLatin1String("pref"));
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& elem : processedList) {
        f.write("    \"");
        auto encodedName = elem.name;
        encodedName.replace('"', "\\x22"); // yes, there is one name containing a single double quote...
        f.write(encodedName);
        f.write("\\0\" // ");
        f.write(elem.isoCode.toUtf8());
        f.write("\n");

        elem.offset = offset;
        offset += elem.name.size() + 1; // +1 for the terminating \0
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const IsoToCountryIndex &lhs, const char *rhs) {
        return strncmp(&lhs.m_c1, rhs, 2) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pMap : clientpidmapList) {
                VCardLine line(QStringLiteral("CLIENTPIDMAP"), pMap.clientPidMap());
                addParameters(line, pMap.parameters());
                card.addLine(line);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CalendarUrl &url : lstCalendarUrl) {
                if (url.isValid()) {
                    QString type;
                    switch (url.type()) {
                    case CalendarUrl::Unknown:
                    case CalendarUrl::EndCalendarType:
                        break;
                    case CalendarUrl::FBUrl:
                        type = QStringLiteral("FBURL");
                        break;
                    case CalendarUrl::CALUri:
                        type = QStringLiteral("CALURI");
                        break;
                    case CalendarUrl::CALADRUri:
                        type = QStringLiteral("CALADRURI");
                        break;

                    }
                    if (!type.isEmpty()) {
                        VCardLine line(type, url.url().toDisplayString());
                        addParameters(line, url.parameters());
                        card.addLine(line);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addr : addresses) {
        QStringList address;

        // clang-format off
        const bool isEmpty = addr.postOfficeBox().isEmpty()
                             && addr.extended().isEmpty()
                             && addr.street().isEmpty()
                             && addr.locality().isEmpty()
                             && addr.region().isEmpty()
                             && addr.postalCode().isEmpty()
                             && addr.country().isEmpty();
        // clang-format on

        address.append(addr.postOfficeBox().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.extended().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.street().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.locality().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.region().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.postalCode().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        address.append(addr.country().replace(QLatin1Char(';'), QStringLiteral("\\;")));

        const QString addressJoined(address.join(QLatin1Char(';')));
        VCardLine adrLine(QStringLiteral("ADR"), addressJoined);
        if (version == VCard::v2_1 && needsEncoding(addressJoined)) {
            adrLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            adrLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }

        const bool hasLabel = !addr.label().isEmpty();
        QStringList addreLineType;
        QStringList labelLineType;

        for (const auto &info : s_addressTypes) {
            if (info.flag & addr.type()) {
                const QString str = QString::fromLatin1(info.addressType);
                addreLineType << str;
                if (hasLabel) {
                    labelLineType << str;
                }
            }
        }

        if (hasLabel) {
            if (version == VCard::v4_0) {
                if (!addr.label().isEmpty()) {
                    adrLine.addParameter(QStringLiteral("LABEL"), QStringLiteral("\"%1\"").arg(addr.label()));
                }
            } else {
                VCardLine labelLine(QStringLiteral("LABEL"), addr.label());
                if (version == VCard::v2_1 && needsEncoding(addr.label())) {
                    labelLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                    labelLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
                }
                addParameter(labelLine, version, QStringLiteral("TYPE"), labelLineType);
                card->addLine(labelLine);
            }
        }
        if (version == VCard::v4_0) {
            Geo geo = addr.geo();
            if (geo.isValid()) {
                QString str = QString::asprintf("\"geo:%.6f,%.6f\"", geo.latitude(), geo.longitude());
                adrLine.addParameter(QStringLiteral("GEO"), str);
            }
        }
        if (!isEmpty) {
            addParameter(adrLine, version, QStringLiteral("TYPE"), addreLineType);
            card->addLine(adrLine);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : it.value()) {
        const auto it = std::find_if(std::begin(email_type_names), std::end(email_type_names), [s](const email_type_name &t) {
            return QLatin1String(t.name) == s;
        });
        if (it != std::end(email_type_names)) {
            type |= (*it).type;
        }
    }
```

#### AUTO 


```{c}
const auto precedingSeparator = (it != format.elements().begin() && (*std::prev(it)).isSeparator());
```

#### AUTO 


```{c}
const auto &info
```

#### RANGE FOR STATEMENT 


```{c}
for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address().url());
            const ParameterMap pMap = impp.params();
            for (const auto &[param, list] : pMap) {
                if (param.toLower() != QLatin1String("x-service-type")) {
                    line.addParameter(param, list.join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }
```

#### AUTO 


```{c}
auto &cat
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const T &elem) {
        return QVariant::fromValue(elem);
    }
```

#### AUTO 


```{c}
const auto required = parseFields(group.readEntry("Required"));
```

#### AUTO 


```{c}
static const auto X_MANAGERSNAME = QStringLiteral("X-ManagersName");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : it.value()) {
        const auto it = std::find_if(std::begin(url_type_names), std::end(url_type_names), [s](const url_type_name &t) {
            return QLatin1String(t.name) == s;
        });
        if (it != std::end(url_type_names)) {
            type |= (*it).type;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[s](const email_type_name &t) {
            return QLatin1String(t.name) == s;
        }
```

#### AUTO 


```{c}
const auto path = improtcolFile(serviceType);
```

#### AUTO 


```{c}
const auto countryName = [&]() -> QString {
        if (address.country().isEmpty()) {
            return {};
        }
        // we use the already ISO 3166-1 resolved country from format here to
        // avoid a potentially expensive second name-based lookup
        return style == AddressFormatStyle::GeoUriQuery ? format.country() : KCountry::fromAlpha2(format.country()).name();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[](const Entry &lhs, const Entry &rhs) {
        return lhs.isoCode < rhs.isoCode;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type](const auto &phone) {
        return matchBinaryPattern(phone.type(), type);
    }
```

#### AUTO 


```{c}
const auto values = (*lineIt).value().toString().split(QChar(0xE000), QString::SkipEmptyParts);
```

#### AUTO 


```{c}
const auto offsetString = QStringView(timeString).mid(tzPos + 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[lineId, l] : mLineMap) {
        list.append(lineId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &cat : categories) {
                    cat.replace(QLatin1Char(','), QLatin1String("\\,"));
                }
```

#### AUTO 


```{c}
auto fmt = parseFormat(u"%O%n%N%nPostfach %P%n%A%n%Z %C", u"R", u"DE");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &k : keys) {
            card.addLine(createKey(k, version));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &countryCode : groups) {
            // qDebug() << countryCode;
            QVERIFY(KCountry::fromAlpha2(countryCode).isValid());
            const auto group = config.group(countryCode);

            QVERIFY(group.hasKey("AddressFormat"));
            const auto upper = AddressFormatParser::parseFields(group.readEntry("Upper"));
            const auto required = AddressFormatParser::parseFields(group.readEntry("Required"));

            // TODO can we check all language variants as well?
            for (const auto &key : {"AddressFormat", "BusinessAddressFormat", "LatinAddressFormat", "LatinBusinessAddressFormat"}) {
                if (!group.hasKey(key)) {
                    continue;
                }
                const auto elems = AddressFormatParser::parseElements(group.readEntry(key, QString()));

                AddressFormatFields seen = AddressFormatField::NoField;
                for (const auto &elem : elems) {
                    if (!elem.isField()) {
                        continue;
                    }
                    QCOMPARE(seen & elem.field() & ~(int)AddressFormatField::SortingCode, 0);
                    seen |= elem.field();
                }

                QCOMPARE(seen & required, required);
                QCOMPARE(seen & upper & ~(int)AddressFormatField::Country, upper & ~(int)AddressFormatField::Country);
            }

            const auto zipRegEx = group.readEntry("PostalCodeFormat", QString());
            if (!zipRegEx.isEmpty()) {
                QVERIFY(QRegularExpression(zipRegEx).isValid());
            }
        }
```

#### AUTO 


```{c}
auto it = std::find_if(d->mKeys.begin(), d->mKeys.end(), [&key](Key &existing) {
        return existing.id() == key.id();
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &t : email_type_names) {
        if (((type ^ oldType) & t.type) == 0) {
            continue; // no change
        }

        if (type & t.type) {
            theIt->paramValues.push_back(QLatin1String(t.name));
        } else {
            theIt->paramValues.removeAll(QLatin1String(t.name));
        }
    }
```

#### AUTO 


```{c}
const auto result = QString::fromUtf8("KDE e.V.\nz.Hd. Dr. Konqi\nPrinzenstraße 85 F\n10969 Berlin\n\nAUSTRIA");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Org &org : lstOrg) {
            QStringList organization;
            organization.append(org.organization().replace(QLatin1Char(';'),
                                QStringLiteral("\\;")));
            if (!(*addrIt).department().isEmpty()) {
                organization.append((*addrIt).department().replace(QLatin1Char(';'),
                                    QStringLiteral("\\;")));
            }
            const QString orgStr = organization.join(QLatin1Char(';'));
            VCardLine orgLine(QStringLiteral("ORG"), orgStr);
            if (version == VCard::v2_1 && needsEncoding(orgStr)) {
                orgLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                orgLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(orgLine, org.parameters());
            card.addLine(orgLine);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Role &role : lstExtraRole) {
            VCardLine roleLine(QStringLiteral("ROLE"), role.role());
            if (version == VCard::v2_1 && needsEncoding(role.role())) {
                roleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                roleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(roleLine, role.parameters());
            card.addLine(roleLine);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : std::as_const(types)) {
        KContacts::PhoneNumber::Type combinedType = type | KContacts::PhoneNumber::Fax;
        const KContacts::PhoneNumber phone(QLatin1String("1"), combinedType);
        QCOMPARE(phone.type(), combinedType);
        QCOMPARE(KContacts::PhoneNumber::typeLabel(combinedType), phone.typeLabel());

        if (type == KContacts::PhoneNumber::Home || type == KContacts::PhoneNumber::Work) {
            // special cased
        } else if (type < KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[type]).arg(labels[KContacts::PhoneNumber::Fax]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        } else if (type > KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[KContacts::PhoneNumber::Fax]).arg(labels[type]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        }
    }
```

#### AUTO 


```{c}
const auto &pMap
```

#### AUTO 


```{c}
const auto v
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &email : emailList) {
        VCardLine line(QStringLiteral("EMAIL"), email.mail());
        const QMap paramMap = email.parameters();
        for (auto it = paramMap.cbegin(), endIt = paramMap.cend(); it != endIt; ++it) {
            const QString &key = it.key();
            QStringList params = it.value();

            if (version == VCard::v2_1) {
                if (key.toLower() == QLatin1String("type")) {
                    bool hasPreferred = false;
                    const int removeItems = params.removeAll(QStringLiteral("PREF"));
                    if (removeItems > 0) {
                        hasPreferred = true;
                    }
                    if (!params.isEmpty()) {
                        addParameter(line, version, key, params);
                    }
                    if (hasPreferred) {
                        line.addParameter(QStringLiteral("PREF"), QString());
                    }
                } else {
                    line.addParameter(key, params.join(QLatin1Char(',')));
                }
            } else {
                line.addParameter(key, params.join(QLatin1Char(',')));
            }
        }
        card->addLine(line);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypeOffers) {
        const QMimeType mimeTypePtr = db.mimeTypeForName(mimeType);
        if (mimeTypePtr.isValid() && mimeTypePtr.inherits(KContacts::Addressee::mimeType())) {
            return mimeType;
        }
    }
```

#### AUTO 


```{c}
const auto it = std::lower_bound(std::begin(iso_to_country_index), std::end(iso_to_country_index), iso.constData(), [](const IsoToCountryIndex &lhs, const char *rhs) {
        return strncmp(&lhs.m_c1, rhs, 2) < 0;
    });
```

#### AUTO 


```{c}
const auto groups = config.groupList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address());
            line.addParameter(QStringLiteral("X-SERVICE-TYPE"), Impp::typeToString(impp.type()));
            QMapIterator<QString, QStringList> i(impp.parameters());
            while (i.hasNext()) {
                i.next();
                if (i.key().toLower() != QStringLiteral("x-service-type")) {
                    line.addParameter(i.key(), i.value().join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }
```

#### AUTO 


```{c}
auto it =
        std::lower_bound(std::begin(country_to_iso_index), std::end(country_to_iso_index), lookupKey, [](const CountryToIsoIndex &lhs, const QByteArray &rhs) {
            return strcmp(country_name_stringtable + lhs.m_offset, rhs.constData()) < 0;
        });
```

#### AUTO 


```{c}
auto it = std::find_if(d->mAddresses.begin(), d->mAddresses.end(), [&address](const Address &addr) {
        return addr.id() == address.id();
    });
```

#### AUTO 


```{c}
auto paramIt = d->mParamMap.findParam(QStringLiteral("pref"));
```

#### AUTO 


```{c}
const auto c
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : KContacts::Impp::serviceTypes()) {
        QTest::newRow(type.toLatin1().constData()) << type;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&s](const email_type_name &t) {
            return QLatin1String(t.name) == s;
        }
```

#### AUTO 


```{c}
auto it = findByLineId(line.identifier());
```

#### AUTO 


```{c}
const auto obj = v.toObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pMap : clientpidmapList) {
                VCardLine line(QStringLiteral("CLIENTPIDMAP"), pMap.clientPidMap());
                line.addParameters(pMap.params());
                card.addLine(line);
            }
```

#### AUTO 


```{c}
const auto f
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &email : emailList) {
        VCardLine line(QStringLiteral("EMAIL"), email.mail());
        const ParameterMap pMap = email.params();
        for (const auto &[param, l] : pMap) {
            QStringList list = l;
            if (version == VCard::v2_1) {
                if (param.toLower() == QLatin1String("type")) {
                    bool hasPreferred = false;
                    const int removeItems = list.removeAll(QStringLiteral("PREF"));
                    if (removeItems > 0) {
                        hasPreferred = true;
                    }
                    if (!list.isEmpty()) {
                        addParameter(&line, version, param, list);
                    }
                    if (hasPreferred) {
                        line.addParameter(QStringLiteral("PREF"), QString());
                    }
                } else {
                    line.addParameter(param, list.join(QLatin1Char(',')));
                }
            } else {
                line.addParameter(param, list.join(QLatin1Char(',')));
            }
        }
        card->addLine(line);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        const int index = custom.indexOf(QLatin1Char(':'));
        if (index == -1) {
            continue;
        }

        const QString qualifiedName = custom.left(index);
        const QString value = custom.mid(index + 1);

        if (!seen.contains(qualifiedName)) {
            d->mCustomFields.push_back({qualifiedName, value});
            seen.push_back(qualifiedName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &str : list) {
            if (str.startsWith(cnTag)) {
                name = QStringView(str).mid(cnTag.size()).trimmed().toString();
            } else if (str.startsWith(mailTag)) {
                email = QStringView(str).mid(mailTag.size()).trimmed().toString();
            }
        }
```

#### AUTO 


```{c}
const auto &phone
```

#### LAMBDA EXPRESSION 


```{c}
[](const PhoneNumber &num) {
        return QVariant::fromValue(num);
    }
```

#### AUTO 


```{c}
static constexpr auto GeoUriFields = AddressFormatField::StreetAddress | AddressFormatField::PostalCode | AddressFormatField::Locality
    | AddressFormatField::DependentLocality | AddressFormatField::Region | AddressFormatField::Country;
```

#### AUTO 


```{c}
const auto name = KContacts::normalizeCountryName(country.name);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto& elem : processedList) {
        f.write("    ");
        bool encodedChar = false;
        // MSVC has a limit on strings of 65535 bytes, however arrays can be longer
        // so we have to encode this ~500k string as an char array manually...
        for (const char c : elem.name) {
            f.write("'");
            if (c >= 32 && c < 127) {
                f.write(&c, 1);
            } else {
                f.write("\\x");
                f.write(QByteArray::number(c, 16).right(2));
                encodedChar = true;
            }
            f.write("',");
        }
        f.write("0, // ");
        if (encodedChar) {
            f.write(elem.name);
            f.write(" ");
        }
        f.write(elem.isoCode.toUtf8());
        f.write("\n");

        elem.offset = offset;
        offset += elem.name.size() + 1; // +1 for the terminating \0
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : countries) {
        out.write("    IsoToCountryIndex{\"");
        out.write(c.isoCode.toUtf8());
        out.write("\", ");
        out.write(QByteArray::number(c.offset));
        out.write("},\n");
    }
```

#### AUTO 


```{c}
const auto endIt =
        std::upper_bound(std::begin(country_to_iso_index), std::end(country_to_iso_index), lookupKey, [](const QByteArray &lhs, const CountryToIsoIndex &rhs) {
            return strncmp(lhs.constData(), country_name_stringtable + rhs.m_offset, strlen(country_name_stringtable + rhs.m_offset)) < 0;
        });
```

#### AUTO 


```{c}
static const auto X_ASSISTANTSNAME = QStringLiteral("X-AssistantsName");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &value : values) {
                            url.setPath(value);
                            Impp impp;
                            impp.setParams((*lineIt).parameterMap());
                            impp.setAddress(url);
                            addr.insertImpp(impp);
                        }
```

#### AUTO 


```{c}
const auto territory = reader.attributes().value(QLatin1String("type")).toString().toLower();
```

#### AUTO 


```{c}
auto it = std::find_if(d->mPhoneNumbers.begin(), d->mPhoneNumbers.end(), [&phoneNumber](const PhoneNumber &p) {
        return p.id() == phoneNumber.id();
    });
```

#### AUTO 


```{c}
auto beforeIt = std::lower_bound(d->mCustomFields.begin(), d->mCustomFields.end(), newdata);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Addressee &addr : addrList) {
        result = (addresseeToLDIF(addr, str) || result); // order matters
    }
```

#### AUTO 


```{c}
const auto gid = elementAttributes.value(QLatin1String("gid"));
```

#### AUTO 


```{c}
const auto styleData = style_map[(int)style];
```

#### AUTO 


```{c}
const auto &[name, list]
```

#### AUTO 


```{c}
auto prevIt = it - 1;
```

#### AUTO 


```{c}
auto it = d->mCustomFields.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactGroup &group : groupList) {
        writeGroup(group);
    }
```

#### AUTO 


```{c}
const auto &countryCode
```

#### AUTO 


```{c}
const auto it = std::unique(processedList.begin(), processedList.end(), [](const Elem &lhs, const Elem &rhs) {
        return strcmp(lhs.name.constData(), rhs.name.constData()) == 0 && lhs.isoCode == rhs.isoCode;
    });
```

#### AUTO 


```{c}
const auto required = AddressFormatParser::parseFields(group.readEntry("Required"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const PhoneNumber &phone : d->mPhoneNumbers) {
        if (matchBinaryPattern(phone.type(), type)) {
            if (phone.type() & PhoneNumber::Pref) {
                return phone;
            } else if (phoneNumber.number().isEmpty()) {
                phoneNumber = phone;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &elem: processedList) {
        f.write("    CountryToIsoIndex{");
        f.write(QByteArray::number(elem.offset));
        f.write(", \"");
        f.write(elem.isoCode.toUtf8());
        f.write("\"},\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldGroup &group : lstGroup) {
            VCardLine line(group.fieldGroupName(), group.value());
            line.addParameters(group.params());
            card.addLine(line);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *native_separator_map[] = {", ", "، ", "", " "};
```

#### AUTO 


```{c}
const auto paramsMap = phone.parameters();
```

#### AUTO 


```{c}
const auto typeIt = std::find_if(std::begin(url_type_names), std::end(url_type_names), [&s](const url_type_name &t) {
            return QLatin1String(t.name) == s;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto v : doc.object().value(QLatin1String("3166-1")).toArray()) {
        const auto obj = v.toObject();
        countries.push_back(Entry{obj.value(QLatin1String("alpha_2")).toString().toLower(), obj.value(QLatin1String("name")).toString(), 0});
    }
```

#### AUTO 


```{c}
const auto typeFlag
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &t : url_type_names) {
        if (((type ^ oldType) & t.type) == 0) {
            continue; // no change
        }

        if (type & t.type) {
            types.push_back(QLatin1String(t.name));
        } else {
            types.removeAll(QLatin1String(t.name));
        }
    }
```

#### AUTO 


```{c}
const auto email = elementAttributes.value(QLatin1String("email"));
```

#### AUTO 


```{c}
const auto idx = n.indexOf(QLatin1Char('_'));
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : qAsConst(types)) {
        KContacts::PhoneNumber::Type combinedType = type | KContacts::PhoneNumber::Fax;
        const KContacts::PhoneNumber phone(QLatin1String("1"), combinedType);
        QCOMPARE(phone.type(), combinedType);
        QCOMPARE(KContacts::PhoneNumber::typeLabel(combinedType), phone.typeLabel());

        if (type == KContacts::PhoneNumber::Home
            || type == KContacts::PhoneNumber::Work) {
            // special cased
        } else if (type < KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[type]).arg(labels[KContacts::PhoneNumber::Fax]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        } else if (type > KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[KContacts::PhoneNumber::Fax]).arg(labels[type]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        }
    }
```

#### AUTO 


```{c}
auto& elem
```

#### RANGE FOR STATEMENT 


```{c}
for (const Sound &sound : lstSound) {
            card.addLine(createSound(sound, version));
        }
```

#### AUTO 


```{c}
auto it = d->parameters.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &valueStr : valueStringList) {
            line.addParameter(valueStr, QString());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &country : parsedList) {
        const auto name = KContacts::normalizeCountryName(country.name);
        if (name.isEmpty()) {
            qWarning() << "Skipping empty normalized country name:" << country.name << country.isoCode << country.language;
            continue;
        }
        processedList.push_back(Elem{name, country.isoCode, country.language, 0});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : qAsConst(types)) {
        KContacts::PhoneNumber::Type combinedType = type | KContacts::PhoneNumber::Fax;
        const KContacts::PhoneNumber phone(QLatin1String("1"), combinedType);
        QCOMPARE(phone.type(), combinedType);
        QCOMPARE(KContacts::PhoneNumber::typeLabel(combinedType), phone.typeLabel());

        if (type == KContacts::PhoneNumber::Home || type == KContacts::PhoneNumber::Work) {
            // special cased
        } else if (type < KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[type]).arg(labels[KContacts::PhoneNumber::Fax]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        } else if (type > KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[KContacts::PhoneNumber::Fax]).arg(labels[type]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        }
    }
```

#### AUTO 


```{c}
const auto &[param, l]
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[param, values] : mParamMap) {
        list.append(param);
    }
```

#### AUTO 


```{c}
const auto &country
```

#### AUTO 


```{c}
const auto lookupKey = cname.toCaseFolded().toUtf8();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : types) {
        QVERIFY(!KContacts::Impp::serviceLabel(type).isEmpty());
    }
```

#### AUTO 


```{c}
auto s = AddressFormatter::format(address, QString(), QString(), fmt, AddressFormatStyle::SingleLineDomestic);
```

#### CONST EXPRESSION 


```{c}
static constexpr const char *separator_map[] = {"\n", ","};
```

#### AUTO 


```{c}
const auto upper = AddressFormatParser::parseFields(group.readEntry("Upper"));
```

#### LAMBDA EXPRESSION 


```{c}
[&s](const url_type_name &t) {
            return QLatin1String(t.name) == s;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[name, value] : d->mCustomFields) {
        result << name + sep + value;
    }
```

#### AUTO 


```{c}
auto it = findByLineId(QLatin1String(s_verStr));
```

#### AUTO 


```{c}
auto it = findPhone(list, PhoneNumber::Work);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Address &addr) {
        return QVariant::fromValue(addr);
    }
```

#### AUTO 


```{c}
const auto &vcardLine = it.value();
```

#### AUTO 


```{c}
const auto sourceFmt = AddressFormatRepository::formatForCountry(sourceCountry.alpha2(), AddressFormatScriptPreference::Local);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &id : std::as_const(idents)) {
            lines = card.lines(id);

            // iterate over the lines
            for (const VCardLine &vline : std::as_const(lines)) {
                QVariant val = vline.value();
                if (val.isValid()) {
                    if (vline.hasGroup()) {
                        textLine = vline.group().toLatin1() + '.' + vline.identifier().toLatin1();
                    } else {
                        textLine = vline.identifier().toLatin1();
                    }

                    params = vline.parameterList();
                    hasEncoding = false;
                    if (!params.isEmpty()) { // we have parameters
                        for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
                    }

                    QByteArray input;
                    QByteArray output;
                    bool checkMultibyte = false; // avoid splitting a multibyte character

                    // handle charset
                    const QString charset = vline.parameter(QStringLiteral("charset"));
                    if (!charset.isEmpty()) {
                        // have to convert the data
                        const QString value = vline.value().toString();
                        QTextCodec *codec = QTextCodec::codecForName(charset.toLatin1());
                        if (codec) {
                            input = codec->fromUnicode(value);
                        } else {
                            checkMultibyte = true;
                            input = value.toUtf8();
                        }
                    } else if (vline.value().type() == QVariant::ByteArray) {
                        input = vline.value().toByteArray();
                    } else {
                        checkMultibyte = true;
                        input = vline.value().toString().toUtf8();
                    }

                    // handle encoding
                    if (hasEncoding) { // have to encode the data
                        if (encodingType == QLatin1Char('b')) {
                            checkMultibyte = false;
                            output = input.toBase64();
                        } else if (encodingType == QLatin1String("quoted-printable")) {
                            checkMultibyte = false;
                            KCodecs::quotedPrintableEncode(input, output, false);
                        }
                    } else {
                        output = input;
                    }
                    addEscapes(output, (vline.identifier() == QLatin1String("CATEGORIES") || vline.identifier() == QLatin1String("GEO")));

                    if (!output.isEmpty()) {
                        textLine.append(':' + output);

                        if (textLine.length() > FOLD_WIDTH) { // we have to fold the line
                            if (checkMultibyte) {
                                // RFC 6350: Multi-octet characters MUST remain contiguous.
                                // we know that textLine contains UTF-8 encoded characters
                                int lineLength = 0;
                                for (int i = 0; i < textLine.length(); ++i) {
                                    if ((textLine[i] & 0xC0) == 0xC0) { // a multibyte sequence follows
                                        int sequenceLength = 2;
                                        if ((textLine[i] & 0xE0) == 0xE0) {
                                            sequenceLength = 3;
                                        } else if ((textLine[i] & 0xF0) == 0xF0) {
                                            sequenceLength = 4;
                                        }
                                        if ((lineLength + sequenceLength) > FOLD_WIDTH) {
                                            // the current line would be too long. fold it
                                            text += "\r\n " + textLine.mid(i, sequenceLength);
                                            lineLength = 1 + sequenceLength; // incl. leading space
                                        } else {
                                            text += textLine.mid(i, sequenceLength);
                                            lineLength += sequenceLength;
                                        }
                                        i += sequenceLength - 1;
                                    } else {
                                        text += textLine[i];
                                        ++lineLength;
                                    }
                                    if ((lineLength == FOLD_WIDTH) && (i < (textLine.length() - 1))) {
                                        text += "\r\n ";
                                        lineLength = 1; // leading space
                                    }
                                }
                                text += "\r\n";
                            } else {
                                for (int i = 0; i <= (textLine.length() / FOLD_WIDTH); ++i) {
                                    text.append((i == 0 ? "" : " ") + textLine.mid(i * FOLD_WIDTH, FOLD_WIDTH) + "\r\n");
                                }
                            }
                        } else {
                            text.append(textLine);
                            text.append("\r\n");
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto e = AddressFormatElementPrivate::get(elem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Org &org : lstOrg) {
        QStringList organization{org.organization().replace(QLatin1Char(';'), QLatin1String("\\;"))};
        if (!addressee.department().isEmpty()) {
            organization.append(addressee.department().replace(QLatin1Char(';'), QLatin1String("\\;")));
        }
        const QString orgStr = organization.join(QLatin1Char(';'));
        VCardLine orgLine(QStringLiteral("ORG"), orgStr);
        if (version == VCard::v2_1 && needsEncoding(orgStr)) {
            orgLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            orgLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        orgLine.addParameters(org.params());
        card->addLine(orgLine);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(d->mKeys.cbegin(), d->mKeys.cend(), [&id](const Key &key) {
        return key.id() == id;
    });
```

#### AUTO 


```{c}
const auto group = config.group(countryCode);
```

#### AUTO 


```{c}
const auto name = reader.readElementText();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &elem : processedList) {
        f.write("    ");
        bool encodedChar = false;
        // MSVC has a limit on strings of 65535 bytes, however arrays can be longer
        // so we have to encode this ~500k string as an char array manually...
        for (const char c : elem.name) {
            f.write("'");
            if (c >= 32 && c < 127) {
                f.write(&c, 1);
            } else {
                f.write("\\x");
                f.write(QByteArray::number(c, 16).right(2));
                encodedChar = true;
            }
            f.write("',");
        }
        f.write("0, // ");
        if (encodedChar) {
            f.write(elem.name);
            f.write(" ");
        }
        f.write(elem.isoCode.toUtf8());
        f.write("\n");

        elem.offset = offset;
        offset += elem.name.size() + 1; // +1 for the terminating \0
    }
```

#### AUTO 


```{c}
static constexpr auto AllDomesticFields = AllFields & ~(int)AddressFormatField::Country;
```

#### AUTO 


```{c}
const auto oldType = this->type();
```

#### RANGE FOR STATEMENT 


```{c}
for (const NickName &nickName : lstNickName) {
                VCardLine nickNameLine(QStringLiteral("NICKNAME"), nickName.nickname());
                nickNameLine.addParameters(nickName.params());

                card.addLine(nickNameLine);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : paths) {
        QDirIterator it(path, QDir::Files);
        while (it.hasNext()) {
            it.next();
            const auto fi = it.fileInfo();
            if (fi.suffix() == QLatin1String("desktop")) {
                types.push_back(fi.baseName());
            }
        }
    }
```

#### AUTO 


```{c}
const auto &addressee
```

#### AUTO 


```{c}
auto it = std::find_if(list.cbegin(), list.cend(), [=](const PhoneNumber &phone) {
            return (phone.type() & ~(PhoneNumber::Pref)) == compareFlag;
        });
```

#### AUTO 


```{c}
auto it = mParamMap.findParam(param);
```

#### AUTO 


```{c}
const auto &type
```

#### AUTO 


```{c}
const auto paths = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("kf5/kcontacts/improtocols"), QStandardPaths::LocateDirectory);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Elem &lhs, const Elem &rhs) {
        const auto c = strcmp(lhs.name.constData(), rhs.name.constData());
        if (c == 0) {
            return lhs.isoCode < rhs.isoCode;
        }
        return c < 0;
    }
```

#### AUTO 


```{c}
const auto elems = AddressFormatParser::parseElements(group.readEntry(key, QString()));
```

#### AUTO 


```{c}
auto it = d->parameters.constFind(QLatin1String("pref"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &k : keyList) {
        str += k.toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto c : s) {
        fields |= parseField(c);
    }
```

#### AUTO 


```{c}
const auto followingFieldEmpty = (std::next(it) != format.elements().end() && (*std::next(it)).isField() && isFieldEmpty((*std::next(it)).field()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Picture &photo : lstExtraPhoto) {
            card.addLine(createPicture(QStringLiteral("PHOTO"), photo, version));
        }
```

#### AUTO 


```{c}
auto dIt = std::lower_bound(begin(), end(), newdata);
```

#### AUTO 


```{c}
auto it2 = it;
```

#### AUTO 


```{c}
auto it = std::find_if(std::begin(s_addressTypes), std::end(s_addressTypes), [&str](const AddressTypeInfo &info) {
        return str == QLatin1String(info.addressType);
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : {"AddressFormat", "BusinessAddressFormat", "LatinAddressFormat", "LatinBusinessAddressFormat"}) {
                if (!group.hasKey(key)) {
                    continue;
                }
                const auto elems = parseElements(group.readEntry(key, QString()));

                AddressFormatFields seen = AddressFormatField::NoField;
                for (const auto &elem : elems) {
                    if (!elem.isField()) {
                        continue;
                    }
                    QCOMPARE(seen & elem.field() & ~(int)AddressFormatField::SortingCode, 0);
                    seen |= elem.field();
                }

                QCOMPARE(seen & required, required);
                QCOMPARE(seen & upper & ~(int)AddressFormatField::Country, upper & ~(int)AddressFormatField::Country);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inputFile : qAsConst(mInputFiles)) {
        const QString outFile = outFilePattern.arg(inputFile);
        const QString outFileV2_1 = outFile21Pattern.arg(inputFile);
        const QString outFileV4 = outFile4Pattern.arg(inputFile);
        QTest::newRow(QFile::encodeName(inputFile).constData())
                << inputFile
                << (mOutput2_1Dir.exists(outFileV2_1) ? outFileV2_1 : QString())
                << (mOutput3_0Dir.exists(outFile) ? outFile : QString())
                << (mOutput4_0Dir.exists(outFileV4) ? outFileV4 : QString());
    }
```

#### AUTO 


```{c}
const auto it = d->mParamMap.findParam(QLatin1String("type"));
```

#### AUTO 


```{c}
auto s = AddressFormatter::format(addr, QStringLiteral("Dr. Konqi"), QStringLiteral("KDE e.V."), fmt, AddressFormatStyle::Postal);
```

#### AUTO 


```{c}
static const auto X_SPOUSESNAME = QStringLiteral("X-SpousesName");
```

#### AUTO 


```{c}
auto it = std::find_if(d->mLangs.begin(), d->mLangs.end(), [&languageStr](const Lang &lang) {
        return lang.language() == languageStr;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[p, list] : *this) {
            str += QStringLiteral("%1 %2").arg(p, list.join(QLatin1Char(',')));
        }
```

#### AUTO 


```{c}
const auto c = KCountry::fromAlpha2(ISOname);
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : qAsConst(types)) {
        KContacts::PhoneNumber::Type combinedType = type | KContacts::PhoneNumber::Fax;
        const KContacts::PhoneNumber phone(QLatin1String("1"), combinedType);
        QCOMPARE(phone.type(), combinedType);
        QCOMPARE(KContacts::PhoneNumber::typeLabel(combinedType), phone.typeLabel());

        if (type == KContacts::PhoneNumber::Home ||
                type == KContacts::PhoneNumber::Work) {
            // special cased
        } else if (type < KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[type]).arg(labels[KContacts::PhoneNumber::Fax]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        } else if (type > KContacts::PhoneNumber::Fax) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[KContacts::PhoneNumber::Fax]).arg(labels[type]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&key](const Key &k) {
        return k.id() == key.id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto f : list) {
        // these are actually flags
        const TypeFlag flag = static_cast<TypeFlag>(static_cast<int>(f));
        if (type & flag) {
            if (!first) {
                label.append(QLatin1Char('/'));
            }

            label.append(typeFlagLabel(flag));

            if (first) {
                first = false;
            }
        }
    }
```

#### AUTO 


```{c}
auto &elem
```

#### AUTO 


```{c}
const auto &[name, value]
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &elem : elems) {
                    if (!elem.isField()) {
                        continue;
                    }
                    QCOMPARE(seen & elem.field() & ~(int)AddressFormatField::SortingCode, 0);
                    seen |= elem.field();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const CountryToIsoIndex &lhs, const QByteArray &rhs) {
        return strcmp(country_name_stringtable + lhs.m_offset, rhs.constData()) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const NickName &nickName : lstNickName) {
                VCardLine nickNameLine(QStringLiteral("NICKNAME"), nickName.nickname());
                addParameters(nickNameLine, nickName.parameters());

                card.addLine(nickNameLine);
            }
```

#### AUTO 


```{c}
const auto &[lineId, l]
```

#### AUTO 


```{c}
const auto zipRegEx = group.readEntry("PostalCodeFormat", QString());
```

#### AUTO 


```{c}
auto it = std::find_if(std::begin(s_phoneTypes), std::end(s_phoneTypes), [&str](const PhoneTypeInfo &info) {
        return str == QLatin1String(info.phoneType);
    });
```

#### AUTO 


```{c}
auto it = std::find_if(d->mPhoneNumbers.begin(), d->mPhoneNumbers.end(), [&phoneNumber](const PhoneNumber &pNumber) {
        return pNumber.id() == phoneNumber.id();
    });
```

#### AUTO 


```{c}
const auto preferredEmail = elementAttributes.value(QLatin1String("preferredEmail"));
```

#### LAMBDA EXPRESSION 


```{c}
[=](const PhoneNumber &phone) {
            return (phone.type() & ~(PhoneNumber::Pref)) == compareFlag;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &value : values) {
                            url.setPath(value);
                            Impp impp;
                            impp.setParameters((*lineIt).parameterMap());
                            impp.setAddress(url);
                            addr.insertImpp(impp);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &valueStr : valueStringList) {
            line->addParameter(valueStr, QString());
        }
```

#### AUTO 


```{c}
const auto path =
        QStandardPaths::locate(QStandardPaths::GenericDataLocation, QStringLiteral("kf5/kcontacts/improtocols/") + serviceType + QStringLiteral(".desktop"));
```

#### AUTO 


```{c}
const auto it = std::find_if(std::begin(email_type_names), std::end(email_type_names), [&s](const email_type_name &t) {
            return QLatin1String(t.name) == s;
        });
```

#### AUTO 


```{c}
const auto &c
```

#### AUTO 


```{c}
auto it = std::find_if(d->mAddresses.cbegin(), d->mAddresses.cend(), [&id](const Address &addr) {
        return addr.id() == id;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&param](const ParameterData &info) {
            return info.param == param;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const IsoToCountryIndex &lhs, const char *rhs) {
            return strncmp(&lhs.m_c1, rhs, 2) < 0;
        }
```

#### AUTO 


```{c}
const auto &k
```

#### AUTO 


```{c}
auto prefIt = d->mParamMap.findParam(QLatin1String("pref"));
```

#### AUTO 


```{c}
auto it = paramsMap.cbegin(), endIt = paramsMap.cend();
```

#### AUTO 


```{c}
auto it = mParamMap.constFind(param);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c: countries) {
        out.write("    IsoToCountryIndex{\"");
        out.write(c.isoCode.toUtf8());
        out.write("\", ");
        out.write(QByteArray::number(c.offset));
        out.write("},\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : lst) {
                    card.addLine(VCardLine(QStringLiteral("MEMBER"), member));
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Email &email) {
        return QVariant::fromValue(email);
    }
```

#### AUTO 


```{c}
const auto groupName = elementAttributes.value(QLatin1String("name"));
```

#### AUTO 


```{c}
auto beforeIt = std::lower_bound(mLineMap.begin(), mLineMap.end(), newdata);
```

#### AUTO 


```{c}
const auto &s
```

#### AUTO 


```{c}
const auto values = (*lineIt).value().toString().split(QChar(0xE000), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
const auto &value
```

#### AUTO 


```{c}
const auto &p
```

#### RANGE FOR STATEMENT 


```{c}
for (const CalendarUrl &url : lstCalendarUrl) {
                if (url.isValid()) {
                    QString type;
                    switch (url.type()) {
                    case CalendarUrl::Unknown:
                    case CalendarUrl::EndCalendarType:
                        break;
                    case CalendarUrl::FBUrl:
                        type = QStringLiteral("FBURL");
                        break;
                    case CalendarUrl::CALUri:
                        type = QStringLiteral("CALURI");
                        break;
                    case CalendarUrl::CALADRUri:
                        type = QStringLiteral("CALADRURI");
                        break;
                    }
                    if (!type.isEmpty()) {
                        VCardLine line(type, url.url().toDisplayString());
                        line.addParameters(url.params());
                        card.addLine(line);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : {"AddressFormat", "BusinessAddressFormat", "LatinAddressFormat", "LatinBusinessAddressFormat"}) {
                if (!group.hasKey(key)) {
                    continue;
                }
                const auto elems = AddressFormatParser::parseElements(group.readEntry(key, QString()));

                AddressFormatFields seen = AddressFormatField::NoField;
                for (const auto &elem : elems) {
                    if (!elem.isField()) {
                        continue;
                    }
                    QCOMPARE(seen & elem.field() & ~(int)AddressFormatField::SortingCode, 0);
                    seen |= elem.field();
                }

                QCOMPARE(seen & required, required);
                QCOMPARE(seen & upper & ~(int)AddressFormatField::Country, upper & ~(int)AddressFormatField::Country);
            }
```

#### AUTO 


```{c}
const auto lookupKey = normalizeCountryName(cname);
```

#### AUTO 


```{c}
const auto &str
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : phones) {
        str += p.toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addr : addrList) {
        str += addr.toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() -> QString {
        if (address.country().isEmpty()) {
            return {};
        }
        // we use the already ISO 3166-1 resolved country from format here to
        // avoid a potentially expensive second name-based lookup
        return style == AddressFormatStyle::GeoUriQuery ? format.country() : KCountry::fromAlpha2(format.country()).name();
    }
```

#### AUTO 


```{c}
const auto precedingFieldEmpty = (it != format.elements().begin() && (*std::prev(it)).isField() && isFieldEmpty((*std::prev(it)).field()));
```

#### AUTO 


```{c}
const auto &t
```

#### RANGE FOR STATEMENT 


```{c}
for (const Email &email : listEmail) {
        str += email.toString();
    }
```

#### AUTO 


```{c}
auto c = countryName();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
```

#### AUTO 


```{c}
const auto &[param, list]
```

#### LAMBDA EXPRESSION 


```{c}
[&str](const PhoneTypeInfo &info) {
        return str == QLatin1String(info.phoneType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&identifier](const LineData &data) {
            return data.identifier == identifier;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&phoneNumber](const PhoneNumber &pNumber) {
        return pNumber.id() == phoneNumber.id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Org &org : lstOrg) {
            QStringList organization;
            organization.append(org.organization().replace(QLatin1Char(';'), QStringLiteral("\\;")));
            if (!(*addrIt).department().isEmpty()) {
                organization.append((*addrIt).department().replace(QLatin1Char(';'), QStringLiteral("\\;")));
            }
            const QString orgStr = organization.join(QLatin1Char(';'));
            VCardLine orgLine(QStringLiteral("ORG"), orgStr);
            if (version == VCard::v2_1 && needsEncoding(orgStr)) {
                orgLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                orgLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(orgLine, org.parameters());
            card.addLine(orgLine);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address().url());
            QMapIterator<QString, QStringList> i(impp.parameters());
            while (i.hasNext()) {
                i.next();
                if (i.key().toLower() != QLatin1String("x-service-type")) {
                    line.addParameter(i.key(), i.value().join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Lang &lang : listLang) {
        str += lang.toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&key](Key &existing) {
        return existing.id() == key.id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &phone : phoneNumbers) {
        VCardLine line(QStringLiteral("TEL"), phone.number());
        const ParameterMap paramsMap = phone.params();
        for (const auto &[param, list] : paramsMap) {
            if (param.toUpper() != QLatin1String("TYPE")) {
                line.addParameter(param, list.join(QLatin1Char(',')));
            }
        }

        const PhoneNumber::Type type = phone.type();
        QStringList lst;
        for (const auto &pType : s_phoneTypes) {
            if (pType.flag & type) {
                const QString str = QString::fromLatin1(pType.phoneType);
                if (version == VCard::v4_0) {
                    lst << str.toLower();
                } else {
                    lst << str;
                }
            }
        }
        if (!lst.isEmpty()) {
            addParameter(&line, version, QStringLiteral("TYPE"), lst);
        }
        card->addLine(line);
    }
```

#### AUTO 


```{c}
auto types = d->parameters.value(QLatin1String("type"));
```

#### LAMBDA EXPRESSION 


```{c}
[&str](const AddressTypeInfo &info) {
        return str == QLatin1String(info.addressType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &lang : langList) {
                VCardLine line(QStringLiteral("LANG"), lang.language());
                line.addParameters(lang.params());
                card.addLine(line);
            }
```

#### AUTO 


```{c}
const auto script = AddressFormatScript::detect(address);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &t : email_type_names) {
        if (((type ^ oldType) & t.type) == 0) {
            continue; // no change
        }

        if (type & t.type) {
            types.push_back(QLatin1String(t.name));
        } else {
            types.removeAll(QLatin1String(t.name));
        }
    }
```

#### AUTO 


```{c}
auto it = s.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&](AddressFormatField f) -> bool {
        if ((styleData.includeFields & f) == 0) {
            return true;
        }
        switch (f) {
        case AddressFormatField::NoField:
        case AddressFormatField::DependentLocality:
        case AddressFormatField::SortingCode:
            return true;
        case AddressFormatField::Name:
            return name.isEmpty();
        case AddressFormatField::Organization:
            return organization.isEmpty();
        case AddressFormatField::PostOfficeBox:
            return address.postOfficeBox().isEmpty();
        case AddressFormatField::StreetAddress:
            return address.street().isEmpty() && (address.extended().isEmpty() || style == AddressFormatStyle::GeoUriQuery);
        case AddressFormatField::PostalCode:
            return address.postalCode().isEmpty();
        case AddressFormatField::Locality:
            return address.locality().isEmpty();
        case AddressFormatField::Region:
            return address.region().isEmpty();
        case AddressFormatField::Country:
            return address.country().isEmpty();
        }
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : it->paramValues) {
        const auto typeIt = std::find_if(std::begin(url_type_names), std::end(url_type_names), [&s](const url_type_name &t) {
            return QLatin1String(t.name) == s;
        });
        if (typeIt != std::end(url_type_names)) {
            type |= (*typeIt).type;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Title &title : lstTitle) {
            VCardLine titleLine(QStringLiteral("TITLE"), title.title());
            if (version == VCard::v2_1 && needsEncoding(title.title())) {
                titleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                titleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(titleLine, title.parameters());

            card.addLine(titleLine);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QByteArray tmpArg : args) {
                                if (tmpArg.startsWith('"')) {
                                    tmpArg = tmpArg.mid(1);
                                }
                                if (tmpArg.endsWith('"')) {
                                    tmpArg.chop(1);
                                }
                                vCardLine.addParameter(cache.fromLatin1(first),
                                                       cache.fromLatin1(tmpArg));
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::PhoneNumber::Type type : std::as_const(types)) {
        KContacts::PhoneNumber::Type combinedType = type | KContacts::PhoneNumber::Pref;
        const KContacts::PhoneNumber phone(QLatin1String("1"), combinedType);
        QCOMPARE(phone.type(), combinedType);
        QCOMPARE(KContacts::PhoneNumber::typeLabel(combinedType), phone.typeLabel());

        if (type < KContacts::PhoneNumber::Pref) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[type]).arg(labels[KContacts::PhoneNumber::Pref]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        } else if (type > KContacts::PhoneNumber::Pref) {
            const QString expectedCombinedString = QStringLiteral("%1/%2").arg(labels[KContacts::PhoneNumber::Pref]).arg(labels[type]);
            QCOMPARE(phone.typeLabel(), expectedCombinedString);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : name) {
        // the following needs to be done fairly fine-grained, as this can easily mess up scripts
        // that rely on some non-letter characters to work
        // when changing this, check changes to the ambiguity warnings of the generator
        switch (c.category()) {
            // strip decorative elements that don't contribute to identification (parenthesis, dashes, quotes, etc)
            case QChar::Punctuation_Connector:
            case QChar::Punctuation_Dash:
            case QChar::Punctuation_Open:
            case QChar::Punctuation_Close:
            case QChar::Punctuation_InitialQuote:
            case QChar::Punctuation_FinalQuote:
            case QChar::Punctuation_Other:
                continue;
            // strip spaces
            case QChar::Separator_Space:
            case QChar::Separator_Line:
            case QChar::Separator_Paragraph:
                continue;
            default:
                break;
        }

        if (c.isSpace()) {
            continue;
        }

        // if the character has a canonical decomposition skip the combining diacritic markers following it
        // this works particularly well for Latin, but seems to mess things up in Hangul
        if (c.script() != QChar::Script_Hangul && c.decompositionTag() == QChar::Canonical) {
            res.push_back(c.decomposition().at(0).toCaseFolded());
        } else {
            res.push_back(c.toCaseFolded());
        }
    }
```

#### AUTO 


```{c}
static const auto BLOGFEED = QStringLiteral("BlogFeed");
```

#### AUTO 


```{c}
const auto it = d->parameters.constFind(QLatin1String("pref"));
```

#### LAMBDA EXPRESSION 


```{c}
[&languageStr](const Lang &lang) {
        return lang.language() == languageStr;
    }
```

#### AUTO 


```{c}
const auto &key
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : lst) {
                    VCardLine line(QStringLiteral("MEMBER"), member);
                    card.addLine(line);
                }
```

#### AUTO 


```{c}
auto result = QString::fromUtf8("4-6-28 Minami-Azabu, Minato-ku\nTOKYO 106-0047\n\nGIAPPONE");
```

#### AUTO 


```{c}
const auto it = std::find_if(std::begin(url_type_names), std::end(url_type_names), [s](const url_type_name &t) {
            return QLatin1String(t.name) == s;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const ResourceLocatorUrl &url : lstExtraUrl) {
            VCardLine line(QStringLiteral("URL"), url.url());
            line.addParameters(url.params());
            card.addLine(line);
        }
```

#### AUTO 


```{c}
auto it = format.elements().begin();
```

#### CONST EXPRESSION 


```{c}
static constexpr auto AllFields = AddressFormatField::Country | AddressFormatField::Region | AddressFormatField::Locality
    | AddressFormatField::DependentLocality | AddressFormatField::SortingCode | AddressFormatField::PostalCode | AddressFormatField::StreetAddress
    | AddressFormatField::Organization | AddressFormatField::Name | AddressFormatField::PostOfficeBox;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &str : customs) {
        QString identifier = QLatin1String("X-") + QStringView(str).left(str.indexOf(QLatin1Char(':')));
        const QString value = str.mid(str.indexOf(QLatin1Char(':')) + 1);
        if (value.isEmpty()) {
            continue;
        }
        // Convert to standard identifier
        if (exportVcard) {
            if (identifier == QLatin1String("X-messaging/aim-All")) {
                identifier = QStringLiteral("X-AIM");
            } else if (identifier == QLatin1String("X-messaging/icq-All")) {
                identifier = QStringLiteral("X-ICQ");
            } else if (identifier == QLatin1String("X-messaging/xmpp-All")) {
                identifier = QStringLiteral("X-JABBER");
            } else if (identifier == QLatin1String("X-messaging/msn-All")) {
                identifier = QStringLiteral("X-MSN");
            } else if (identifier == QLatin1String("X-messaging/yahoo-All")) {
                identifier = QStringLiteral("X-YAHOO");
            } else if (identifier == QLatin1String("X-messaging/gadu-All")) {
                identifier = QStringLiteral("X-GADUGADU");
            } else if (identifier == QLatin1String("X-messaging/skype-All")) {
                identifier = QStringLiteral("X-SKYPE");
            } else if (identifier == QLatin1String("X-messaging/groupwise-All")) {
                identifier = QStringLiteral("X-GROUPWISE");
            } else if (identifier == QLatin1String("X-messaging/sms-All")) {
                identifier = QStringLiteral("X-SMS");
            } else if (identifier == QLatin1String("X-messaging/meanwhile-All")) {
                identifier = QStringLiteral("X-MEANWHILE");
            } else if (identifier == QLatin1String("X-messaging/irc-All")) {
                identifier = QStringLiteral("X-IRC"); // Not defined by rfc but need for fixing #300869
            } else if (identifier == QLatin1String("X-messaging/googletalk-All")) {
                // Not defined by rfc but need for fixing #300869
                identifier = QStringLiteral("X-GTALK");
            } else if (identifier == QLatin1String("X-messaging/twitter-All")) {
                identifier = QStringLiteral("X-TWITTER");
            }
        }

        if (identifier.toLower() == QLatin1String("x-kaddressbook-x-anniversary") && version == VCard::v4_0) {
            // ANNIVERSARY
            if (!value.isEmpty()) {
                const QDate date = QDate::fromString(value, Qt::ISODate);
                QDateTime dt = QDateTime(date.startOfDay());
                dt.setTime(QTime());
                VCardLine line(QStringLiteral("ANNIVERSARY"), createDateTime(dt, version, false));
                card->addLine(line);
            }
        } else if (identifier.toLower() == QLatin1String("x-kaddressbook-x-spousesname") && version == VCard::v4_0) {
            if (!value.isEmpty()) {
                VCardLine line(QStringLiteral("RELATED"), QStringLiteral(";"));
                line.addParameter(QStringLiteral("TYPE"), QStringLiteral("spouse"));
                line.addParameter(QStringLiteral("VALUE"), value);
                card->addLine(line);
            }
        } else {
            VCardLine line(identifier, value);
            if (version == VCard::v2_1 && needsEncoding(value)) {
                line.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                line.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card->addLine(line);
        }
    }
```

#### AUTO 


```{c}
auto it = m_values.constFind(value);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[name, list] : *this) {
            map.insert(name, list);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&text, &lineStart, &lineEnd, &cur]() -> QByteArray {
                                            const QByteArray ret = cur;
                                            lineStart = lineEnd + 1;
                                            lineEnd = text.indexOf('\n', lineStart);
                                            if (lineEnd != -1) {
                                                cur = text.mid(lineStart, lineEnd - lineStart);
                                                // remove the trailing \r, left from \r\n
                                                if (cur.endsWith('\r')) {
                                                    cur.chop(1);
                                                }
                                            }
                                            return ret;
                                        }
```

#### AUTO 


```{c}
const auto elems = parseElements(group.readEntry(key, QString()));
```

#### AUTO 


```{c}
auto it = mLineMap.constFind(identifier);
```

#### AUTO 


```{c}
const auto doc = QJsonDocument::fromJson(input.readAll());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &addressee : list) {
        VCard card;
        // VERSION
        if (version == VCard::v2_1) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("2.1")));
        } else if (version == VCard::v3_0) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("3.0")));
        } else if (version == VCard::v4_0) {
            card.addLine(VCardLine(QStringLiteral("VERSION"), QStringLiteral("4.0")));
        }

        // ADR + LABEL
        const Address::List addresses = addressee.addresses();
        processAddresses(addresses, version, &card);

        // BDAY
        const bool withTime = addressee.birthdayHasTime();
        const QString birthdayString = createDateTime(addressee.birthday(), version, withTime);
        card.addLine(VCardLine(QStringLiteral("BDAY"), birthdayString));

        // Laurent: 31 Jan 2015. Not necessary to export it. When Categories were changes as AkonadiTag nobody thought that it would break categories support...
        //=> not necessary to export just tag...
        // CATEGORIES only > 2.1
        if (!exportVcard) {
            if (version != VCard::v2_1) {
                QStringList categories = addressee.categories();
                for (auto &cat : categories) {
                    cat.replace(QLatin1Char(','), QLatin1String("\\,"));
                }

                VCardLine catLine(QStringLiteral("CATEGORIES"), categories.join(QLatin1Char(',')));
                card.addLine(catLine);
            }
        }
        // MEMBER (only in 4.0)
        if (version == VCard::v4_0) {
            // The KIND property must be set to "group" in order to use this property.
            if (addressee.kind().toLower() == QLatin1String("group")) {
                const QStringList lst = addressee.members();
                for (const QString &member : lst) {
                    card.addLine(VCardLine(QStringLiteral("MEMBER"), member));
                }
            }
        }
        // SOURCE
        const QVector<QUrl> lstUrl = addressee.sourcesUrlList();
        for (const QUrl &url : lstUrl) {
            VCardLine line = VCardLine(QStringLiteral("SOURCE"), url.url());
            card.addLine(line);
        }

        const Related::List relatedList = addressee.relationships();
        for (const auto &rel : relatedList) {
            VCardLine line(QStringLiteral("RELATED"), rel.related());
            addParameters(line, rel.parameters());
            card.addLine(line);
        }
        // CLASS only for version == 3.0
        if (version == VCard::v3_0) {
            card.addLine(createSecrecy(addressee.secrecy()));
        }
        // LANG only for version == 4.0
        if (version == VCard::v4_0) {
            const Lang::List langList = addressee.langs();
            for (const auto &lang : langList) {
                VCardLine line(QStringLiteral("LANG"), lang.language());
                addParameters(line, lang.parameters());
                card.addLine(line);
            }
        }
        // CLIENTPIDMAP
        if (version == VCard::v4_0) {
            const ClientPidMap::List clientpidmapList = addressee.clientPidMapList();
            for (const auto &pMap : clientpidmapList) {
                VCardLine line(QStringLiteral("CLIENTPIDMAP"), pMap.clientPidMap());
                addParameters(line, pMap.parameters());
                card.addLine(line);
            }
        }
        // EMAIL
        const Email::List emailList = addressee.emailList();
        processEmailList(emailList, version, &card);

        // FN required for only version > 2.1
        VCardLine fnLine(QStringLiteral("FN"), addressee.formattedName());
        if (version == VCard::v2_1 && needsEncoding(addressee.formattedName())) {
            fnLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            fnLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        card.addLine(fnLine);

        // GEO
        const Geo geo = addressee.geo();
        if (geo.isValid()) {
            QString str;
            if (version == VCard::v4_0) {
                str = QString::asprintf("geo:%.6f,%.6f", geo.latitude(), geo.longitude());
            } else {
                str = QString::asprintf("%.6f;%.6f", geo.latitude(), geo.longitude());
            }
            card.addLine(VCardLine(QStringLiteral("GEO"), str));
        }

        // KEY
        const Key::List keys = addressee.keys();
        for (const auto &k : keys) {
            card.addLine(createKey(k, version));
        }

        // LOGO
        card.addLine(createPicture(QStringLiteral("LOGO"), addressee.logo(), version));
        const QVector<Picture> lstLogo = addressee.extraLogoList();
        for (const Picture &logo : lstLogo) {
            card.addLine(createPicture(QStringLiteral("LOGO"), logo, version));
        }

        // MAILER only for version < 4.0
        if (version != VCard::v4_0) {
            VCardLine mailerLine(QStringLiteral("MAILER"), addressee.mailer());
            if (version == VCard::v2_1 && needsEncoding(addressee.mailer())) {
                mailerLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                mailerLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card.addLine(mailerLine);
        }

        // N required for only version < 4.0
        QStringList name;
        name.append(addressee.familyName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.givenName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.additionalName().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.prefix().replace(QLatin1Char(';'), QStringLiteral("\\;")));
        name.append(addressee.suffix().replace(QLatin1Char(';'), QStringLiteral("\\;")));

        VCardLine nLine(QStringLiteral("N"), name.join(QLatin1Char(';')));
        if (version == VCard::v2_1 && needsEncoding(name.join(QLatin1Char(';')))) {
            nLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            nLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        if (version == VCard::v4_0 && !addressee.sortString().isEmpty()) {
            nLine.addParameter(QStringLiteral("SORT-AS"), addressee.sortString());
        }

        card.addLine(nLine);

        // NAME only for version < 4.0
        if (version != VCard::v4_0) {
            VCardLine nameLine(QStringLiteral("NAME"), addressee.name());
            if (version == VCard::v2_1 && needsEncoding(addressee.name())) {
                nameLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                nameLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            card.addLine(nameLine);
        }

        // NICKNAME only for version > 2.1
        if (version != VCard::v2_1) {
            const QVector<NickName> lstNickName = addressee.extraNickNameList();
            for (const NickName &nickName : lstNickName) {
                VCardLine nickNameLine(QStringLiteral("NICKNAME"), nickName.nickname());
                addParameters(nickNameLine, nickName.parameters());

                card.addLine(nickNameLine);
            }
        }

        // NOTE
        VCardLine noteLine(QStringLiteral("NOTE"), addressee.note());
        if (version == VCard::v2_1 && needsEncoding(addressee.note())) {
            noteLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
            noteLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
        }
        card.addLine(noteLine);

        // ORG
        processOrganizations(addressee, version, &card);

        // PHOTO
        card.addLine(createPicture(QStringLiteral("PHOTO"), addressee.photo(), version));
        const QVector<Picture> lstExtraPhoto = addressee.extraPhotoList();
        for (const Picture &photo : lstExtraPhoto) {
            card.addLine(createPicture(QStringLiteral("PHOTO"), photo, version));
        }

        // PROID only for version > 2.1
        if (version != VCard::v2_1) {
            card.addLine(VCardLine(QStringLiteral("PRODID"), addressee.productId()));
        }

        // REV
        card.addLine(VCardLine(QStringLiteral("REV"), createDateTime(addressee.revision(), version)));

        // ROLE
        const QVector<Role> lstExtraRole = addressee.extraRoleList();
        for (const Role &role : lstExtraRole) {
            VCardLine roleLine(QStringLiteral("ROLE"), role.role());
            if (version == VCard::v2_1 && needsEncoding(role.role())) {
                roleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                roleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(roleLine, role.parameters());
            card.addLine(roleLine);
        }

        // SORT-STRING
        if (version == VCard::v3_0) {
            card.addLine(VCardLine(QStringLiteral("SORT-STRING"), addressee.sortString()));
        }

        // SOUND
        card.addLine(createSound(addressee.sound(), version));
        const QVector<Sound> lstSound = addressee.extraSoundList();
        for (const Sound &sound : lstSound) {
            card.addLine(createSound(sound, version));
        }

        // TEL
        const PhoneNumber::List phoneNumbers = addressee.phoneNumbers();
        processPhoneNumbers(phoneNumbers, version, &card);

        // TITLE
        const QVector<Title> lstTitle = addressee.extraTitleList();
        for (const Title &title : lstTitle) {
            VCardLine titleLine(QStringLiteral("TITLE"), title.title());
            if (version == VCard::v2_1 && needsEncoding(title.title())) {
                titleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                titleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            addParameters(titleLine, title.parameters());

            card.addLine(titleLine);
        }

        // TZ
        // TODO Add vcard4.0 support
        const TimeZone timeZone = addressee.timeZone();
        if (timeZone.isValid()) {
            int neg = 1;
            if (timeZone.offset() < 0) {
                neg = -1;
            }

            QString str =
                QString::asprintf("%c%02d:%02d", (timeZone.offset() >= 0 ? '+' : '-'), (timeZone.offset() / 60) * neg, (timeZone.offset() % 60) * neg);

            card.addLine(VCardLine(QStringLiteral("TZ"), str));
        }

        // UID
        card.addLine(VCardLine(QStringLiteral("UID"), addressee.uid()));

        // URL
        const QVector<ResourceLocatorUrl> lstExtraUrl = addressee.extraUrlList();
        for (const ResourceLocatorUrl &url : lstExtraUrl) {
            VCardLine line(QStringLiteral("URL"), url.url());
            addParameters(line, url.parameters());
            card.addLine(line);
        }
        if (version == VCard::v4_0) {
            // GENDER
            const Gender gender = addressee.gender();
            if (gender.isValid()) {
                QString genderStr;
                if (!gender.gender().isEmpty()) {
                    genderStr = gender.gender();
                }
                if (!gender.comment().isEmpty()) {
                    genderStr += QLatin1Char(';') + gender.comment();
                }
                VCardLine line(QStringLiteral("GENDER"), genderStr);
                card.addLine(line);
            }
            // KIND
            if (!addressee.kind().isEmpty()) {
                VCardLine line(QStringLiteral("KIND"), addressee.kind());
                card.addLine(line);
            }
        }
        // From vcard4.
        if (version == VCard::v4_0) {
            const QVector<CalendarUrl> lstCalendarUrl = addressee.calendarUrlList();
            for (const CalendarUrl &url : lstCalendarUrl) {
                if (url.isValid()) {
                    QString type;
                    switch (url.type()) {
                    case CalendarUrl::Unknown:
                    case CalendarUrl::EndCalendarType:
                        break;
                    case CalendarUrl::FBUrl:
                        type = QStringLiteral("FBURL");
                        break;
                    case CalendarUrl::CALUri:
                        type = QStringLiteral("CALURI");
                        break;
                    case CalendarUrl::CALADRUri:
                        type = QStringLiteral("CALADRURI");
                        break;
                    }
                    if (!type.isEmpty()) {
                        VCardLine line(type, url.url().toDisplayString());
                        addParameters(line, url.parameters());
                        card.addLine(line);
                    }
                }
            }
        }

        // FieldGroup
        const QVector<FieldGroup> lstGroup = addressee.fieldGroupList();
        for (const FieldGroup &group : lstGroup) {
            VCardLine line(group.fieldGroupName(), group.value());
            addParameters(line, group.parameters());
            card.addLine(line);
        }

        // IMPP (supported in vcard 3 too)
        const QVector<Impp> lstImpp = addressee.imppList();
        for (const Impp &impp : lstImpp) {
            VCardLine line(QStringLiteral("IMPP"), impp.address().url());
            QMapIterator<QString, QStringList> i(impp.parameters());
            while (i.hasNext()) {
                i.next();
                if (i.key().toLower() != QLatin1String("x-service-type")) {
                    line.addParameter(i.key(), i.value().join(QLatin1Char(',')));
                }
            }
            card.addLine(line);
        }

        // X-
        const QStringList customs = addressee.customs();
        processCustoms(customs, version, &card, exportVcard);

        vCardList.append(card);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char c : elem.name) {
            f.write("'");
            if (c >= 32 && c < 127) {
                f.write(&c, 1);
            } else {
                f.write("\\x");
                f.write(QByteArray::number(c, 16).right(2));
                encodedChar = true;
            }
            f.write("',");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto typeFlag : list) {
        // these are actually flags
        const TypeFlag flag = static_cast<TypeFlag>(static_cast<int>(typeFlag));
        if (type & flag) {
            label.append(QLatin1Char('/') + typeFlagLabel(flag));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &custom : customs) {
        const int index = custom.indexOf(QLatin1Char(':'));
        if (index == -1) {
            continue;
        }

        const QString qualifiedName = custom.left(index);
        const QString value = custom.mid(index + 1);

        d->mCustomFields.insert(qualifiedName, value);
    }
```

#### AUTO 


```{c}
auto it = processedList.begin() + 1;
```

#### AUTO 


```{c}
const auto endIt = std::upper_bound(std::begin(country_to_iso_index), std::end(country_to_iso_index), lookupKey, [](const QByteArray &lhs, const CountryToIsoIndex &rhs) {
        return strncmp(lhs.constData(), country_name_stringtable + rhs.m_offset, strlen(country_name_stringtable + rhs.m_offset)) < 0;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &lhs, const CountryToIsoIndex &rhs) {
        return strncmp(lhs.constData(), country_name_stringtable + rhs.m_offset, strlen(country_name_stringtable + rhs.m_offset)) < 0;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[s](const url_type_name &t) {
            return QLatin1String(t.name) == s;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &inputFile : qAsConst(mInputFiles)) {
        const QString outFile = outFilePattern.arg(inputFile);
        const QString outFileV2_1 = outFile21Pattern.arg(inputFile);
        const QString outFileV4 = outFile4Pattern.arg(inputFile);
        QTest::newRow(QFile::encodeName(inputFile).constData())
            << inputFile << (mOutput2_1Dir.exists(outFileV2_1) ? outFileV2_1 : QString()) << (mOutput3_0Dir.exists(outFile) ? outFile : QString())
            << (mOutput4_0Dir.exists(outFileV4) ? outFileV4 : QString());
    }
```

#### AUTO 


```{c}
const auto it = d->parameters.constFind(QLatin1String("type"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pType : s_phoneTypes) {
            if (pType.flag & type) {
                const QString str = QString::fromLatin1(pType.phoneType);
                if (version == VCard::v4_0) {
                    lst << str.toLower();
                } else {
                    lst << str;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QVariant &elem) {
        return elem.value<T>();
    }
```

#### AUTO 


```{c}
auto beforeIt = std::lower_bound(mLineMap.begin(), mLineMap.end(), newData);
```

#### AUTO 


```{c}
const auto types = KContacts::Impp::serviceTypes();
```

#### AUTO 


```{c}
auto it = lines.begin();
```

#### AUTO 


```{c}
auto &c
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : name) {
        // the following needs to be done fairly fine-grained, as this can easily mess up scripts
        // that rely on some non-letter characters to work
        // when changing this, check changes to the ambiguity warnings of the generator
        switch (c.category()) {
        // strip decorative elements that don't contribute to identification (parenthesis, dashes, quotes, etc)
        case QChar::Punctuation_Connector:
        case QChar::Punctuation_Dash:
        case QChar::Punctuation_Open:
        case QChar::Punctuation_Close:
        case QChar::Punctuation_InitialQuote:
        case QChar::Punctuation_FinalQuote:
        case QChar::Punctuation_Other:
            continue;
        // strip spaces
        case QChar::Separator_Space:
        case QChar::Separator_Line:
        case QChar::Separator_Paragraph:
            continue;
        default:
            break;
        }

        if (c.isSpace()) {
            continue;
        }

        // if the character has a canonical decomposition skip the combining diacritic markers following it
        // this works particularly well for Latin, but seems to mess things up in Hangul
        if (c.script() != QChar::Script_Hangul && c.decompositionTag() == QChar::Canonical) {
            res.push_back(c.decomposition().at(0).toCaseFolded());
        } else {
            res.push_back(c.toCaseFolded());
        }
    }
```

#### AUTO 


```{c}
const auto formatPref = (orgaName.isEmpty() || style != AddressFormatStyle::Postal) ? AddressFormatPreference::Generic : AddressFormatPreference::Business;
```

#### AUTO 


```{c}
auto fmt = parseFormat(u"%C, %S %Z", u"", u"US");
```

#### AUTO 


```{c}
const auto upper = parseFields(group.readEntry("Upper"));
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const Address &addr) {
        return addr.id() == id;
    }
```

#### AUTO 


```{c}
auto c
```

#### LAMBDA EXPRESSION 


```{c}
[&phoneNumber](const PhoneNumber &p) {
        return p.id() == phoneNumber.id();
    }
```

#### AUTO 


```{c}
auto it = d->mParameters.cbegin();
```

#### AUTO 


```{c}
const auto n = QLocale().name();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CalendarUrl &url : lstCalendarUrl) {
                if (url.isValid()) {
                    QString type;
                    switch (url.type()) {
                    case CalendarUrl::Unknown:
                    case CalendarUrl::EndCalendarType:
                        break;
                    case CalendarUrl::FBUrl:
                        type = QStringLiteral("FBURL");
                        break;
                    case CalendarUrl::CALUri:
                        type = QStringLiteral("CALURI");
                        break;
                    case CalendarUrl::CALADRUri:
                        type = QStringLiteral("CALADRURI");
                        break;
                    }
                    if (!type.isEmpty()) {
                        VCardLine line(type, url.url().toDisplayString());
                        addParameters(line, url.parameters());
                        card.addLine(line);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ContactGroup &group : contactGroupList) {
        result = (contactGroupToLDIF(group, str) || result); // order matters
    }
```

#### AUTO 


```{c}
const auto shouldPrepend = isReverseOrder(sourceFmt);
```

#### AUTO 


```{c}
const auto &rel
```

#### AUTO 


```{c}
const auto country = i18n(strbuf.leftRef(pos).toUtf8().constData());
```

#### AUTO 


```{c}
auto fmt = parseFormat(u"〒%Z%n%S%C%A%n%O%n%N", u"SR", u"JP");
```

#### LAMBDA EXPRESSION 


```{c}
[](const CountryToIsoIndex &lhs, const QByteArray &rhs) {
            return strcmp(country_name_stringtable + lhs.m_offset, rhs.constData()) < 0;
        }
```

#### AUTO 


```{c}
auto it = d->parameters.cbegin(), itEnd = d->parameters.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Role &role : lstExtraRole) {
            VCardLine roleLine(QStringLiteral("ROLE"), role.role());
            if (version == VCard::v2_1 && needsEncoding(role.role())) {
                roleLine.addParameter(QStringLiteral("charset"), QStringLiteral("UTF-8"));
                roleLine.addParameter(QStringLiteral("encoding"), QStringLiteral("QUOTED-PRINTABLE"));
            }
            roleLine.addParameters(role.params());
            card.addLine(roleLine);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[type, &customTypeString](const Key &key) {
        if (key.type() == type) {
            if (type == Key::Custom) {
                if (customTypeString.isEmpty()) {
                    return true;
                } else {
                    if (key.customTypeString() == customTypeString) {
                        return true;
                    }
                }
            } else {
                return true;
            }
        }
        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : d->mKeys) {
        if (key.type() == type) {
            if (type == Key::Custom) {
                if (customTypeString.isEmpty()) {
                    return key;
                } else {
                    if (key.customTypeString() == customTypeString) {
                        return key;
                    }
                }
            } else {
                return key;
            }
        }
    }
```

#### AUTO 


```{c}
auto it = findPhone(list, PhoneNumber::Home);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &elem : processedList) {
        f.write("    CountryToIsoIndex{");
        f.write(QByteArray::number(elem.offset));
        f.write(", \"");
        f.write(elem.isoCode.toUtf8());
        f.write("\"},\n");
    }
```

#### AUTO 


```{c}
static const auto X_ANNIVERSARY = QStringLiteral("X-Anniversary");
```

#### AUTO 


```{c}
const auto uid = elementAttributes.value(QLatin1String("uid"));
```

#### LAMBDA EXPRESSION 


```{c}
[](QQmlEngine *, QJSEngine *jsEngine) -> QJSValue {
        return jsEngine->toScriptValue(AddressFormatRepository());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &lhs, const CountryToIsoIndex &rhs) {
            return strncmp(lhs.constData(), country_name_stringtable + rhs.m_offset, strlen(country_name_stringtable + rhs.m_offset)) < 0;
        }
```

#### AUTO 


```{c}
const auto isFieldEmpty = [&](AddressFormatField f) -> bool {
        if ((styleData.includeFields & f) == 0) {
            return true;
        }
        switch (f) {
        case AddressFormatField::NoField:
        case AddressFormatField::DependentLocality:
        case AddressFormatField::SortingCode:
            return true;
        case AddressFormatField::Name:
            return name.isEmpty();
        case AddressFormatField::Organization:
            return organization.isEmpty();
        case AddressFormatField::PostOfficeBox:
            return address.postOfficeBox().isEmpty();
        case AddressFormatField::StreetAddress:
            return address.street().isEmpty() && (address.extended().isEmpty() || style == AddressFormatStyle::GeoUriQuery);
        case AddressFormatField::PostalCode:
            return address.postalCode().isEmpty();
        case AddressFormatField::Locality:
            return address.locality().isEmpty();
        case AddressFormatField::Region:
            return address.region().isEmpty();
        case AddressFormatField::Country:
            return address.country().isEmpty();
        }
        return true;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &cat : categories) {
                cat.replace(QLatin1Char(','), QLatin1String("\\,"));
            }
```

#### AUTO 


```{c}
const auto &elem
```

#### RANGE FOR STATEMENT 


```{c}
for (const VCard &card : list) {
        text.append("BEGIN:VCARD\r\n");

        QStringList idents = card.identifiers();
        // VERSION must be first
        if (idents.contains(QLatin1String("VERSION"))) {
            const QString str = idents.takeAt(idents.indexOf(QLatin1String("VERSION")));
            idents.prepend(str);
        }

        for (const auto &id : std::as_const(idents)) {
            lines = card.lines(id);

            // iterate over the lines
            for (const VCardLine &vline : std::as_const(lines)) {
                QVariant val = vline.value();
                if (val.isValid()) {
                    if (vline.hasGroup()) {
                        textLine = vline.group().toLatin1() + '.' + vline.identifier().toLatin1();
                    } else {
                        textLine = vline.identifier().toLatin1();
                    }

                    params = vline.parameterList();
                    hasEncoding = false;
                    if (!params.isEmpty()) { // we have parameters
                        for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
                    }

                    QByteArray input;
                    QByteArray output;
                    bool checkMultibyte = false; // avoid splitting a multibyte character

                    // handle charset
                    const QString charset = vline.parameter(QStringLiteral("charset"));
                    if (!charset.isEmpty()) {
                        // have to convert the data
                        const QString value = vline.value().toString();
                        QTextCodec *codec = QTextCodec::codecForName(charset.toLatin1());
                        if (codec) {
                            input = codec->fromUnicode(value);
                        } else {
                            checkMultibyte = true;
                            input = value.toUtf8();
                        }
                    } else if (vline.value().type() == QVariant::ByteArray) {
                        input = vline.value().toByteArray();
                    } else {
                        checkMultibyte = true;
                        input = vline.value().toString().toUtf8();
                    }

                    // handle encoding
                    if (hasEncoding) { // have to encode the data
                        if (encodingType == QLatin1Char('b')) {
                            checkMultibyte = false;
                            output = input.toBase64();
                        } else if (encodingType == QLatin1String("quoted-printable")) {
                            checkMultibyte = false;
                            KCodecs::quotedPrintableEncode(input, output, false);
                        }
                    } else {
                        output = input;
                    }
                    addEscapes(output, (vline.identifier() == QLatin1String("CATEGORIES") || vline.identifier() == QLatin1String("GEO")));

                    if (!output.isEmpty()) {
                        textLine.append(':' + output);

                        if (textLine.length() > FOLD_WIDTH) { // we have to fold the line
                            if (checkMultibyte) {
                                // RFC 6350: Multi-octet characters MUST remain contiguous.
                                // we know that textLine contains UTF-8 encoded characters
                                int lineLength = 0;
                                for (int i = 0; i < textLine.length(); ++i) {
                                    if ((textLine[i] & 0xC0) == 0xC0) { // a multibyte sequence follows
                                        int sequenceLength = 2;
                                        if ((textLine[i] & 0xE0) == 0xE0) {
                                            sequenceLength = 3;
                                        } else if ((textLine[i] & 0xF0) == 0xF0) {
                                            sequenceLength = 4;
                                        }
                                        if ((lineLength + sequenceLength) > FOLD_WIDTH) {
                                            // the current line would be too long. fold it
                                            text += "\r\n " + textLine.mid(i, sequenceLength);
                                            lineLength = 1 + sequenceLength; // incl. leading space
                                        } else {
                                            text += textLine.mid(i, sequenceLength);
                                            lineLength += sequenceLength;
                                        }
                                        i += sequenceLength - 1;
                                    } else {
                                        text += textLine[i];
                                        ++lineLength;
                                    }
                                    if ((lineLength == FOLD_WIDTH) && (i < (textLine.length() - 1))) {
                                        text += "\r\n ";
                                        lineLength = 1; // leading space
                                    }
                                }
                                text += "\r\n";
                            } else {
                                for (int i = 0; i <= (textLine.length() / FOLD_WIDTH); ++i) {
                                    text.append((i == 0 ? "" : " ") + textLine.mid(i * FOLD_WIDTH, FOLD_WIDTH) + "\r\n");
                                }
                            }
                        } else {
                            text.append(textLine + "\r\n");
                        }
                    }
                }
            }
        }

        text.append("END:VCARD\r\n");
        text.append("\r\n");
    }
```

#### AUTO 


```{c}
auto s = AddressFormatter::format(address, QString(), QString(), fmt, AddressFormatStyle::MultiLineDomestic);
```

#### RANGE FOR STATEMENT 


```{c}
for (const VCard &card : list) {
        text.append("BEGIN:VCARD\r\n");

        QStringList idents = card.identifiers();
        // VERSION must be first
        if (idents.contains(QLatin1String("VERSION"))) {
            const QString str = idents.takeAt(idents.indexOf(QLatin1String("VERSION")));
            idents.prepend(str);
        }

        for (const auto &id : std::as_const(idents)) {
            lines = card.lines(id);

            // iterate over the lines
            for (const VCardLine &vline : std::as_const(lines)) {
                QVariant val = vline.value();
                if (val.isValid()) {
                    if (vline.hasGroup()) {
                        textLine = vline.group().toLatin1() + '.' + vline.identifier().toLatin1();
                    } else {
                        textLine = vline.identifier().toLatin1();
                    }

                    params = vline.parameterList();
                    hasEncoding = false;
                    if (!params.isEmpty()) { // we have parameters
                        for (const QString &param : std::as_const(params)) {
                            if (param == QLatin1String("encoding")) {
                                hasEncoding = true;
                                encodingType = vline.parameter(QStringLiteral("encoding")).toLower();
                            }

                            values = vline.parameters(param);
                            for (const QString &str : std::as_const(values)) {
                                textLine.append(';' + param.toLatin1().toUpper());
                                if (!str.isEmpty()) {
                                    textLine.append('=' + str.toLatin1());
                                }
                            }
                        }
                    }

                    QByteArray input;
                    QByteArray output;
                    bool checkMultibyte = false; // avoid splitting a multibyte character

                    // handle charset
                    const QString charset = vline.parameter(QStringLiteral("charset"));
                    if (!charset.isEmpty()) {
                        // have to convert the data
                        const QString value = vline.value().toString();
                        QTextCodec *codec = QTextCodec::codecForName(charset.toLatin1());
                        if (codec) {
                            input = codec->fromUnicode(value);
                        } else {
                            checkMultibyte = true;
                            input = value.toUtf8();
                        }
                    } else if (vline.value().type() == QVariant::ByteArray) {
                        input = vline.value().toByteArray();
                    } else {
                        checkMultibyte = true;
                        input = vline.value().toString().toUtf8();
                    }

                    // handle encoding
                    if (hasEncoding) { // have to encode the data
                        if (encodingType == QLatin1Char('b')) {
                            checkMultibyte = false;
                            output = input.toBase64();
                        } else if (encodingType == QLatin1String("quoted-printable")) {
                            checkMultibyte = false;
                            KCodecs::quotedPrintableEncode(input, output, false);
                        }
                    } else {
                        output = input;
                    }
                    addEscapes(output, (vline.identifier() == QLatin1String("CATEGORIES") || vline.identifier() == QLatin1String("GEO")));

                    if (!output.isEmpty()) {
                        textLine.append(':' + output);

                        if (textLine.length() > FOLD_WIDTH) { // we have to fold the line
                            if (checkMultibyte) {
                                // RFC 6350: Multi-octet characters MUST remain contiguous.
                                // we know that textLine contains UTF-8 encoded characters
                                int lineLength = 0;
                                for (int i = 0; i < textLine.length(); ++i) {
                                    if ((textLine[i] & 0xC0) == 0xC0) { // a multibyte sequence follows
                                        int sequenceLength = 2;
                                        if ((textLine[i] & 0xE0) == 0xE0) {
                                            sequenceLength = 3;
                                        } else if ((textLine[i] & 0xF0) == 0xF0) {
                                            sequenceLength = 4;
                                        }
                                        if ((lineLength + sequenceLength) > FOLD_WIDTH) {
                                            // the current line would be too long. fold it
                                            text += "\r\n " + textLine.mid(i, sequenceLength);
                                            lineLength = 1 + sequenceLength; // incl. leading space
                                        } else {
                                            text += textLine.mid(i, sequenceLength);
                                            lineLength += sequenceLength;
                                        }
                                        i += sequenceLength - 1;
                                    } else {
                                        text += textLine[i];
                                        ++lineLength;
                                    }
                                    if ((lineLength == FOLD_WIDTH) && (i < (textLine.length() - 1))) {
                                        text += "\r\n ";
                                        lineLength = 1; // leading space
                                    }
                                }
                                text += "\r\n";
                            } else {
                                for (int i = 0; i <= (textLine.length() / FOLD_WIDTH); ++i) {
                                    text.append((i == 0 ? "" : " ") + textLine.mid(i * FOLD_WIDTH, FOLD_WIDTH) + "\r\n");
                                }
                            }
                        } else {
                            text.append(textLine);
                            text.append("\r\n");
                        }
                    }
                }
            }
        }

        text.append("END:VCARD\r\n");
        text.append("\r\n");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Elem &lhs, const Elem &rhs) {
        const auto c = strcmp(lhs.name.constData(), rhs.name.constData());
        if (c == 0)
            return lhs.isoCode < rhs.isoCode;
        return  c < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : lstUrl) {
            VCardLine line = VCardLine(QStringLiteral("SOURCE"), url.url());
            card.addLine(line);
        }
```

#### AUTO 


```{c}
const auto c = strcmp(lhs.name.constData(), rhs.name.constData());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[param, l] : pMap) {
            QStringList list = l;
            if (version == VCard::v2_1) {
                if (param.toLower() == QLatin1String("type")) {
                    bool hasPreferred = false;
                    const int removeItems = list.removeAll(QStringLiteral("PREF"));
                    if (removeItems > 0) {
                        hasPreferred = true;
                    }
                    if (!list.isEmpty()) {
                        addParameter(&line, version, param, list);
                    }
                    if (hasPreferred) {
                        line.addParameter(QStringLiteral("PREF"), QString());
                    }
                } else {
                    line.addParameter(param, list.join(QLatin1Char(',')));
                }
            } else {
                line.addParameter(param, list.join(QLatin1Char(',')));
            }
        }
```

#### AUTO 


```{c}
const auto country = i18nd("iso_3166-1", strbuf.leftRef(pos).toUtf8().constData());
```

