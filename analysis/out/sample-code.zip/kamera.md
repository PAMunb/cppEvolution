#### AUTO 


```{c}
auto lay = new QVBoxLayout;
```

#### AUTO 


```{c}
auto slider = static_cast<QSlider *>(m_wmap[widget]);
```

#### AUTO 


```{c}
auto main = new QFrame(this);
```

#### AUTO 


```{c}
auto vertLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto send = dynamic_cast<QRadioButton*>( sender() );
```

#### AUTO 


```{c}
auto topLayout = new QHBoxLayout(page);
```

#### AUTO 


```{c}
auto rightLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto grid2 = new QWidget(m_settingsStack);
```

#### AUTO 


```{c}
auto gridLayout2 = new QGridLayout(grid2);
```

#### AUTO 


```{c}
auto page = new QWidget( this );
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *item : items) {
        const QModelIndex index = m_model->indexFromItem(item);
        m_modelSel->selectionModel()->select(index, QItemSelectionModel::Select);
    }
```

#### AUTO 


```{c}
auto object = (KameraProtocol*)data;
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Port:"), grid);
```

#### AUTO 


```{c}
auto cameraItem = new QStandardItem;
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Unable to initialize the gPhoto2 libraries."), this);
```

#### AUTO 


```{c}
auto checkBox = static_cast<QCheckBox *>(m_wmap[widget]);
```

#### AUTO 


```{c}
auto scrollArea = new QScrollArea(tab);
```

#### AUTO 


```{c}
auto m_device = new KCamera(QString(), QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : buttonGroup->children()) {
                auto radButton = static_cast<QRadioButton *>(button);
                if (radButton->isChecked()) {
                    gp_widget_set_value(widget,
                            (void *)radButton->text().toLocal8Bit().data());
                    break;
                }
            }
```

#### AUTO 


```{c}
auto radButton = static_cast<QRadioButton *>(button);
```

#### AUTO 


```{c}
auto comboBox = new QComboBox(parent);
```

#### AUTO 


```{c}
auto  label = new QLabel(i18n("Date (not supported by KControl)"), parent);
```

#### AUTO 


```{c}
auto buttonGroup = static_cast<QGroupBox *>(m_wmap[widget]);
```

#### AUTO 


```{c}
auto checkBox = new QCheckBox(grid);
```

#### AUTO 


```{c}
auto tabContainer = new QWidget(tab);
```

#### AUTO 


```{c}
auto lineEdit = static_cast<QLineEdit *>(m_wmap[widget]);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto scrollArea =
                dynamic_cast<QScrollArea *>(tab->children().at(1));
```

#### AUTO 


```{c}
auto vbox_layout =
                dynamic_cast<QVBoxLayout *>(scrollArea->widget()->layout());
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto comboBox = static_cast<QComboBox *>(m_wmap[widget]);
```

#### AUTO 


```{c}
auto self( reinterpret_cast<KKameraConfig*>(data) );
```

#### AUTO 


```{c}
auto button
```

#### AUTO 


```{c}
auto grid = new QWidget(m_settingsStack);
```

#### AUTO 


```{c}
auto buttonGroup = new QGroupBox(
                        QString::fromLocal8Bit(widget_label), parent);
```

#### AUTO 


```{c}
auto grid = new QWidget(parent);
```

#### AUTO 


```{c}
auto tab = new QWidget;
```

#### AUTO 


```{c}
auto tabLayout = new QVBoxLayout(tab);
```

#### AUTO 


```{c}
auto slider = new QSlider(Qt::Horizontal, grid);
```

#### AUTO 


```{c}
auto deviceItem = new QStandardItem;
```

#### AUTO 


```{c}
auto lineEdit = new QLineEdit(widget_value_string, grid);
```

#### AUTO 


```{c}
auto gridLayout = new QGridLayout(grid);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(main);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto newestButton = new QRadioButton(widget_choice);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto button : buttonGroup->children()) {
                QRadioButton *radButton = static_cast<QRadioButton *>(button);
                if (radButton->isChecked()) {
                    gp_widget_set_value(widget,
                            (void *)radButton->text().toLocal8Bit().data());
                    break;
                }
            }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Button (not supported by KControl)"), parent);
```

#### AUTO 


```{c}
auto label2 = new QLabel(i18n("Port"), grid2);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(
            QDialogButtonBox::Ok|QDialogButtonBox::Cancel, this);
```

