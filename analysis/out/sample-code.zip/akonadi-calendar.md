#### AUTO 


```{c}
auto *scheduler = new MailScheduler(/*factory=*/ nullptr, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);

        // If it's readonly, we can't possible remove it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();

        // Code for new invitations:
        // We cannot check the value of "status" to be RequestNew because
        // "status" comes from a similar check inside libical, where the event
        // is compared to other events in the calendar. But if we have another
        // version of the event around (e.g. shared folder for a group), the
        // status could be RequestNew, Obsolete or Updated.
        qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";

        // This is supposed to be a new request, not an update - however we want
        // to update the existing one to handle the "clicking more than once
        // on the invitation" case. So check the attendee status of the attendee.
        bool isMine = true;
        const Attendee::List attendees = existingIncidence->attendees();
        for (const KCalCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail &&
                    attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }

        if (!isMine) {
            continue;
        }

        qCDebug(AKONADICALENDAR_LOG) << "removing existing incidence " << existingUid;
        if (incidence->hasRecurrenceId()) {
            Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());

            if (existingInstance) {
                existingInstance->setStatus(Incidence::StatusCanceled);
                result = calendar->modifyIncidence(existingInstance) ? ResultSuccess : ResultModifyingError;
            } else {
                incidence->setSchedulingID(incidence->uid(), existingIncidence->uid());
                incidence->setStatus(Incidence::StatusCanceled);
                result = calendar->addIncidence(incidence) ? ResultSuccess : ResultCreatingError;
            }

            if (result != ResultSuccess) {
                emit transactionFinished(result, i18n("Error recording exception"));
            }

        } else {
            result = calendar->deleteIncidence(existingIncidence) ? ResultSuccess : ResultErrorDelete;
            if (result != ResultSuccess) {
                emit transactionFinished(result, errorString);
            }
        }

        // The success case will be handled in handleDeleteFinished()
        return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        Q_UNUSED(item)
        Q_ASSERT_X(item.isValid(), "History::recordDeletion()", "Item must be valid.");
        Q_ASSERT_X(item.hasPayload<Incidence::Ptr>(), "History::recordDeletion()", "Item must have an Incidence::Ptr payload.");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);
        // If it's readonly, we can't possible update it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();
        const int existingRevision = existingIncidence->revision();

        if (existingRevision <= incidence->revision()) {
            // The new incidence might be an update for the found one
            bool isUpdate = true;
            // Code for new invitations:
            // If you think we could check the value of "status" to be RequestNew:  we can't.
            // It comes from a similar check inside libical, where the event is compared to
            // other events in the calendar. But if we have another version of the event around
            // (e.g. shared folder for a group), the status could be RequestNew, Obsolete or Updated.
            qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";
            // This is supposed to be a new request, not an update - however we want to update
            // the existing one to handle the "clicking more than once on the invitation" case.
            // So check the attendee status of the attendee.
            const Attendee::List attendees = existingIncidence->attendees();
            Attendee::List::ConstIterator ait;
            for (ait = attendees.begin(); ait != attendees.end(); ++ait) {
                if ((*ait).email() == email && (*ait).status() == Attendee::NeedsAction) {
                    // This incidence wasn't created by me - it's probably in a shared folder
                    // and meant for someone else, ignore it.
                    qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                    isUpdate = false;
                    break;
                }
            }
            if (isUpdate) {
                if (existingRevision == incidence->revision() &&
                        existingIncidence->lastModified() > incidence->lastModified()) {
                    // This isn't an update - the found incidence was modified more recently
                    errorString = i18n("This isn't an update. "
                                       "The found incidence was modified more recently.");
//QT5 port
#if 0
                    qCWarning(AKONADICALENDAR_LOG) << errorString
                                                   << "; revision=" << existingIncidence->revision()
                                                   << "; existing->lastModified=" << existingIncidence->lastModified()
                                                   << "; update->lastModified=" << incidence->lastModified();
#endif
                    emit transactionFinished(ResultOutatedUpdate, errorString);
                    return;
                }
                qCDebug(AKONADICALENDAR_LOG) << "replacing existing incidence " << existingUid;
                if (existingIncidence->type() != incidence->type()) {
                    qCritical() << "assigning different incidence types";
                    result = ResultAssigningDifferentTypes;
                    errorString = i18n("Error: Assigning different incidence types.");
                    emit transactionFinished(result, errorString);
                } else {
                    incidence->setSchedulingID(schedulingUid, existingUid) ;

                    if (incidence->hasRecurrenceId()) {
                        Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());
                        if (!existingInstance) {
                            // The organizer created an exception, lets create it in our calendar, we don't have it yet
                            const bool success = calendar->addIncidence(incidence);

                            if (!success) {
                                emit transactionFinished(ResultCreatingError, QStringLiteral("Error creating incidence"));
                            } else {
                                // Signal emitted in the result slot of addFinished()
                            }

                            return;
                        }
                    }

                    const bool success = calendar->modifyIncidence(incidence);

                    if (!success) {
                        emit transactionFinished(ResultModifyingError, i18n("Error modifying incidence"));
                    } else {
                        //handleModifyFinished() will emit the final signal.
                    }
                }
                return;
            }
        } else {
            errorString = i18n("This isn't an update. "
                               "The found incidence was modified more recently.");
            qCWarning(AKONADICALENDAR_LOG) << errorString;
            // This isn't an update - the found incidence has a bigger revision number
            qCDebug(AKONADICALENDAR_LOG) << "This isn't an update - the found incidence has a bigger revision number";
            emit transactionFinished(ResultOutatedUpdate, errorString);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail && attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto now = QDateTime::currentDateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &knownIncidence : knownIncidences) {
                if (knownIncidence->summary() == d->m_incidence->summary()) {
                    qCDebug(AKONADICALENDAR_LOG) << "\nFound: uid=" << knownIncidence->uid() << "; identifier=" << knownIncidence->instanceIdentifier()
                                                 << "; schedulingId" << knownIncidence->schedulingID();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : incidences) {
        if (uids.contains(incidence->uid())) {
            uids.removeAll(incidence->uid());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : incidences) {
        if (incidence) {
            items << item(incidence->instanceIdentifier());
        } else {
            items << Akonadi::Item();
        }
    }
```

#### AUTO 


```{c}
auto *job = new IncidenceFetchJob();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : myEmails) {
            KCalCore::Attendee::Ptr me = incidence->attendeeByMail(email);
            if (me &&
                    (me->status() == KCalCore::Attendee::Accepted ||
                     me->status() == KCalCore::Attendee::Delegated)) {
                incidenceAcceptedBefore = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selections) {
                mUI.mNameLineEdit->setEnabled(true);
                mUI.mEmailLineEdit->setEnabled(true);
                auto item = new QListWidgetItem(mUI.mListWidget);
                item->setSelected(true);
                mUI.mNameLineEdit->setText(selection.name());
                mUI.mEmailLineEdit->setText(selection.email());
                mUI.mListWidget->addItem(item);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        ItemDeleteJob *job = new ItemDeleteJob(item);
        AKVERIFYEXEC(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
                if (attendee->role() != Attendee::NonParticipant &&
                        attendee->status() != Attendee::Delegated && !Akonadi::CalendarUtils::thatIsMe(attendee)) {
                    attendee->setStatus(Attendee::NeedsAction);
                    attendee->setRSVP(true);
                }
            }
```

#### AUTO 


```{c}
const auto appId = grp.readEntry(QStringLiteral("ApplicationId"), QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload<KCalCore::Incidence::Ptr>());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }
                // We only send CANCEL if we're the organizer.
                // If we're not, then we send REPLY with PartStat=Declined in handleInvitationsAfterChange()
                if (Akonadi::CalendarUtils::thatIsMe(incidence->organizer()->email())) {
                    //TODO: not to popup all delete message dialogs at once :(
                    sendOk = false;
                    handler->sendIncidenceDeletedMessage(KCalCore::iTIPCancel, incidence);
                    if (change->atomicOperationId) {
                        mInvitationStatusByAtomicOperation.insert(change->atomicOperationId, status);
                    }
                    //TODO: with some status we want to break immediately
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    const KCalendarCore::Attendee me(incidence->attendeeByMails(myEmails));
                    if (!me.isNull()) {
                        if (me.status() == KCalendarCore::Attendee::Accepted ||
                                me.status() == KCalendarCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalendarCore::Attendee newMe(me);
                        newMe.setStatus(KCalendarCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        //break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalendarCore::iTIPReply);
                    }
                }
            }
```

#### AUTO 


```{c}
auto *selectionModel = new QItemSelectionModel(mCollectionProxyModel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &incidence : incidences) {
        if (incidence) {
            items << item(incidence->instanceIdentifier());
        } else {
            items << Akonadi::Item();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        auto *job = new ItemDeleteJob(item);
        AKVERIFYEXEC(job);
    }
```

#### AUTO 


```{c}
auto transaction = qobject_cast<TransactionSequence *>(job);
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(),
                                                     CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
const auto incidence = items.constFirst().payload<KCalendarCore::Incidence::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(change->originalItems)) {
                Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }
                // We only send CANCEL if we're the organizer.
                // If we're not, then we send REPLY with PartStat=Declined in handleInvitationsAfterChange()
                if (Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    // TODO: not to popup all delete message dialogs at once :(
                    sendOk = false;
                    handler->sendIncidenceDeletedMessage(KCalendarCore::iTIPCancel, incidence);
                    if (change->atomicOperationId) {
                        mInvitationStatusByAtomicOperation.insert(change->atomicOperationId, status);
                    }
                    // TODO: with some status we want to break immediately
                }
            }
```

#### AUTO 


```{c}
auto fetch = qobject_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto event2 = item2.payload<Event::Ptr>();
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(mUI.mListWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &child : std::as_const(node->directChilds)) {
        s << child;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mItems)) {
        if (useAtomicOperation) {
            mChanger->startAtomicOperation();
        }

        Q_ASSERT(item.hasPayload<KCalCore::Incidence::Ptr>());
        const int changeId = mChanger->createIncidence(item.payload<KCalCore::Incidence::Ptr>(),
                             Collection(item.storageCollectionId()),
                             currentParent());
        success = (changeId != -1) && success;
        mChangeIds << changeId;
        if (useAtomicOperation) {
            mChanger->endAtomicOperation();
        }

        mOldIdByChangeId.insert(changeId, item.id());
    }
```

#### AUTO 


```{c}
auto createjob = qobject_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### AUTO 


```{c}
auto *checkerJob = static_cast<FbCheckerJob *>(job);
```

#### AUTO 


```{c}
auto atomicOperation = new AtomicOperation(d, d->mLatestAtomicOperationId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &agent : agents) {
        if (agent.type().capabilities().contains(QLatin1String("FreeBusyProvider"))) {
            providers << agent.identifier();
        }
    }
```

#### AUTO 


```{c}
auto *modifyJob = new ItemModifyJob(newItem, parentJob(change));
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : incidences) {
        if (uids.contains(incidence->uid()))
            uids.removeAll(incidence->uid());
    }
```

#### AUTO 


```{c}
auto columnFilterProxy = new KColumnFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            if (attendee.email() == receiver) {
                if (action.startsWith(QLatin1String("accepted"))) {
                    attendee.setStatus(KCalCore::Attendee::Accepted);
                } else if (action.startsWith(QLatin1String("tentative"))) {
                    attendee.setStatus(KCalCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals() &&
                           action.startsWith(QLatin1String("counter"))) {
                    attendee.setStatus(KCalCore::Attendee::Tentative);
                } else if (action.startsWith(QLatin1String("delegated"))) {
                    attendee.setStatus(KCalCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : std::as_const(d->mCollectionMap)) {
        if (!entityTreeModel()->isCollectionPopulated(collection.id())) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);

        // If it's readonly, we can't possible remove it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();

        // Code for new invitations:
        // We cannot check the value of "status" to be RequestNew because
        // "status" comes from a similar check inside libical, where the event
        // is compared to other events in the calendar. But if we have another
        // version of the event around (e.g. shared folder for a group), the
        // status could be RequestNew, Obsolete or Updated.
        qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";

        // This is supposed to be a new request, not an update - however we want
        // to update the existing one to handle the "clicking more than once
        // on the invitation" case. So check the attendee status of the attendee.
        bool isMine = true;
        const Attendee::List attendees = existingIncidence->attendees();
        for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail &&
                    attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }

        if (!isMine) {
            continue;
        }

        qCDebug(AKONADICALENDAR_LOG) << "removing existing incidence " << existingUid;
        if (incidence->hasRecurrenceId()) {
            Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());

            if (existingInstance) {
                existingInstance->setStatus(Incidence::StatusCanceled);
                result = calendar->modifyIncidence(existingInstance) ? ResultSuccess : ResultModifyingError;
            } else {
                incidence->setSchedulingID(incidence->uid(), existingIncidence->uid());
                incidence->setStatus(Incidence::StatusCanceled);
                result = calendar->addIncidence(incidence) ? ResultSuccess : ResultCreatingError;
            }

            if (result != ResultSuccess) {
                emit transactionFinished(result, i18n("Error recording exception"));
            }

        } else {
            result = calendar->deleteIncidence(existingIncidence) ? ResultSuccess : ResultErrorDelete;
            if (result != ResultSuccess) {
                emit transactionFinished(result, errorString);
            }
        }

        // The success case will be handled in handleDeleteFinished()
        return;
    }
```

#### AUTO 


```{c}
const auto parentCollection = index.data(EntityTreeModel::ParentCollectionRole).value<Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selections) {
                mUI.mNameLineEdit->setEnabled(true);
                mUI.mEmailLineEdit->setEnabled(true);
                auto *item = new QListWidgetItem(mUI.mListWidget);
                item->setSelected(true);
                mUI.mNameLineEdit->setText(selection.name());
                mUI.mEmailLineEdit->setText(selection.email());
                mUI.mListWidget->addItem(item);
            }
```

#### AUTO 


```{c}
auto monitor = new Akonadi::Monitor(q);
```

#### AUTO 


```{c}
auto *deleteJob = new ItemDeleteJob(itemsToDelete);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : std::as_const(incidences)) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid() << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### AUTO 


```{c}
const auto &attIn
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimetype : allMimeTypes) {
            monitor->setMimeTypeMonitored(mimetype, mMimeTypes.isEmpty() || mMimeTypes.contains(mimetype));
        }
```

#### AUTO 


```{c}
auto job = new ItemDeleteJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QVERIFY(createJob->exec());
        QVERIFY(createJob->item().isValid());
    }
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(mUI.mListWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : incidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Change::Ptr &change : lstPendingCreations) {
        mPendingCreations.removeAll(change);

        if (canceled) {
            change->resultCode = ResultCodeUserCanceled;
            continue;
        }

        if (noAcl) {
            change->resultCode = ResultCodePermissions;
            continue;
        }

        if (invalidCollection) {
            change->resultCode = ResultCodeInvalidUserCollection;
            continue;
        }

        if (collectionToUse.isValid()) {
            // We don't show the dialog multiple times
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        KCalendarCore::Incidence::Ptr incidence = CalendarUtils::incidence(change->newItem);
        Collection::List candidateCollections = collectionsForMimeType(incidence->mimeType(), allCollections);
        if (candidateCollections.count() == 1 && candidateCollections.first().isValid()) {
            // We only have 1 writable collection, don't bother the user with a dialog
            collectionToUse = candidateCollections.first();
            qCDebug(AKONADICALENDAR_LOG) << "Only one collection exists, will not show collection dialog: " << collectionToUse.displayName();
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        // Lets ask the user which collection to use:
        int dialogCode;
        QWidget *parent = change->parentWidget;

        const QStringList mimeTypes(incidence->mimeType());
        collectionToUse = CalendarUtils::selectCollection(parent, /*by-ref*/ dialogCode,
                                                          mimeTypes, mDefaultCollection);
        if (dialogCode != QDialog::Accepted) {
            qCDebug(AKONADICALENDAR_LOG) << "User canceled collection choosing";
            change->resultCode = ResultCodeUserCanceled;
            canceled = true;
            cancelTransaction();
            continue;
        }

        if (collectionToUse.isValid() && !hasRights(collectionToUse, ChangeTypeCreate)) {
            qCWarning(AKONADICALENDAR_LOG) << "No ACLs for incidence creation";
            const QString errorMessage = showErrorDialog(ResultCodePermissions, parent);
            change->resultCode = ResultCodePermissions;
            change->errorString = errorMessage;
            noAcl = true;
            cancelTransaction();
            continue;
        }

        // TODO: add unit test for these two situations after reviewing API
        if (!collectionToUse.isValid()) {
            qCritical() << "Invalid collection selected. Can't create incidence.";
            change->resultCode = ResultCodeInvalidUserCollection;
            const QString errorString = showErrorDialog(ResultCodeInvalidUserCollection, parent);
            change->errorString = errorString;
            invalidCollection = true;
            cancelTransaction();
            continue;
        }

        step2CreateIncidence(change, collectionToUse);
    }
```

#### AUTO 


```{c}
auto deleteJob = new ItemDeleteJob(change->originalItems, parentJob(change));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : childs) {
        KCalendarCore::Todo::Ptr childTodo = child.dynamicCast<KCalendarCore::Todo>();

        if (!childTodo) {
            return false; // This never happens
        }

        if (!treeIsDeletable(childTodo)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : childs) {
        KCalendarCore::Todo::Ptr childTodo = child.dynamicCast<KCalendarCore::Todo>();

        if (!childTodo) {
            return false;    // This never happens
        }

        if (!treeIsDeletable(childTodo)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &agent : agents) {
        if (agent.type().capabilities().contains(QStringLiteral("FreeBusyProvider"))) {
            providers << agent.identifier();
        }
    }
```

#### AUTO 


```{c}
auto *itemFetch = new ItemFetchJob(col, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            if (item.storageCollectionId() == collection.id()) {
                KCalendarCore::Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (incidence) {
                    incidence->setReadOnly(!(collection.rights() & Akonadi::Collection::CanChangeItem));
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            if (attendee.email() == receiver) {
                if (action.startsWith(QLatin1String("accepted"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Accepted);
                } else if (action.startsWith(QLatin1String("tentative"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals() &&
                           action.startsWith(QLatin1String("counter"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Tentative);
                } else if (action.startsWith(QLatin1String("delegated"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &ba) {
            d->remoteDownloadFinished(job, ba);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : qAsConst(mUndoStack)) {
        entry->updateIds(oldId, newId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &knownIncidence : knownIncidences) {
                if (knownIncidence->summary() == d->m_incidence->summary()) {
                    qCDebug(AKONADICALENDAR_LOG) << "\nFound: uid=" << knownIncidence->uid()
                                                 << "; identifier=" << knownIncidence->instanceIdentifier()
                                                 << "; schedulingId" << knownIncidence->schedulingID();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : myEmails) {
            const KCalendarCore::Attendee me = incidence->attendeeByMail(email);
            if (!me.isNull()
                && (me.status() == KCalendarCore::Attendee::Accepted
                    || me.status() == KCalendarCore::Attendee::Delegated)) {
                incidenceAcceptedBefore = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
        if (!m_mimeTypeChecker.isWantedCollection(col) || col.isVirtual()) {
            continue;
        }
        auto itemFetch = new ItemFetchJob(col, this);
        itemFetch->fetchScope().fetchFullPayload(true);
        connect(itemFetch, &ItemFetchJob::result, this, &IncidenceFetchJob::itemFetchResult);
        ++m_jobCount;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotCreateSubTodo();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : qAsConst(incidences)) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### AUTO 


```{c}
const auto col = idx.data(Akonadi::EntityTreeModel::ParentCollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(type, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : std::as_const(deletion->mItemIds)) {
                if (operation->m_itemIdsInOperation.contains(id)) {
                    allow = false;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attNew : qAsConst(attendeesNew)) {
            QString msg = i18nc("@info", "%1 wants to attend %2 but was not invited.", attNew.fullName(), incidence->summary());
            if (!attNew.delegator().isEmpty()) {
                msg = i18nc("@info", "%1 wants to attend %2 on behalf of %3.", attNew.fullName(), incidence->summary(), attNew.delegator());
            }
            if (KMessageBox::questionYesNo(nullptr,
                                           msg,
                                           i18nc("@title", "Uninvited attendee"),
                                           KGuiItem(i18nc("@option", "Accept Attendance")),
                                           KGuiItem(i18nc("@option", "Reject Attendance")))
                != KMessageBox::Yes) {
                Incidence::Ptr cancel = incidence;
                cancel->addComment(i18nc("@info", "The organizer rejected your attendance at this meeting."));
                performTransaction(incidenceBase, iTIPCancel, attNew.fullName());
                continue;
            }

            Attendee a(attNew.name(), attNew.email(), attNew.RSVP(), attNew.status(), attNew.role(), attNew.uid());

            a.setDelegate(attNew.delegate());
            a.setDelegator(attNew.delegator());
            incidence->addAttendee(a);

            result = ResultSuccess;
            errorString.clear();
            attendeeAdded = true;
        }
```

#### AUTO 


```{c}
const auto todo = incidence.staticCast<KCalendarCore::Todo>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : childs) {
            Akonadi::Item childItem = m_calendar->item(incidence);
            if (!childItem.isValid()) {
                Q_EMIT q->cutFinished(/**success=*/false, i18n("Can't find item: %1", childItem.id()));
                return;
            }

            KCalendarCore::Incidence::Ptr newIncidence(child->clone());
            newIncidence->setRelatedTo(QString());
            childItem.setPayload<KCalendarCore::Incidence::Ptr>(newIncidence);
            const int changeId = m_changer->modifyIncidence(childItem, /*originalPayload*/ child);
            if (changeId == -1) {
                m_abortCurrentOperation = true;
                break;
            } else {
                m_pendingChangeIds << changeId;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &cols, const QSet<QByteArray> &set)
        {
            onCollectionChanged(cols, set);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attEv : attendeesEv) {
                if (attIn.email().toLower() == attEv.email().toLower()) {
                    // update attendee-info
                    qCDebug(AKONADICALENDAR_LOG) << "update attendee";
                    attEv.setStatus(attIn.status());
                    attEv.setDelegate(attIn.delegate());
                    attEv.setDelegator(attIn.delegator());
                    result = ResultSuccess;
                    errorString.clear();
                    found = true;
                }
            }
```

#### AUTO 


```{c}
auto *d = static_cast<FetchJobCalendarPrivate *>(d_ptr.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        if (d->deleteAlreadyCalled(item.id())) {
            // IncidenceChanger::deleteIncidence() called twice, ignore this one.
            qCDebug(AKONADICALENDAR_LOG) << "Item " << item.id() << " already deleted or being deleted, skipping";
        } else {
            itemsToDelete.append(item);
        }
    }
```

#### AUTO 


```{c}
auto fetchJob = new ItemFetchJob(mCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : list) {
        mUI.mNameLineEdit->setEnabled(true);
        mUI.mEmailLineEdit->setEnabled(true);
        QListWidgetItem *item = new QListWidgetItem(mUI.mListWidget);
        item->setSelected(true);
        mUI.mNameLineEdit->setText(contact.name());
        mUI.mEmailLineEdit->setText(contact.preferredEmail());
        mUI.mListWidget->addItem(item);
    }
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(d->mUI.mListWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this, client]() {
            client->dismiss(this);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
                    ItemFetchJob *fetchJob = new ItemFetchJob(item, this);
                    fetchJob->fetchScope().fetchFullPayload();
                    QVERIFY(!fetchJob->exec());
                    QVERIFY(fetchJob->items().isEmpty());
                    delete fetchJob;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : childs) {
            Akonadi::Item childItem = m_calendar->item(incidence);
            if (!childItem.isValid()) {
                emit q->cutFinished(/**success=*/ false, i18n("Can't find item: %1", childItem.id()));
                return;
            }

            KCalendarCore::Incidence::Ptr newIncidence(child->clone());
            newIncidence->setRelatedTo(QString());
            childItem.setPayload<KCalendarCore::Incidence::Ptr>(newIncidence);
            const int changeId = m_changer->modifyIncidence(childItem, /*originalPayload*/ child);
            if (changeId == -1) {
                m_abortCurrentOperation = true;
                break;
            } else {
                m_pendingChangeIds << changeId;
            }
        }
```

#### AUTO 


```{c}
auto *createJob = new ItemCreateJob(i, collection);
```

#### AUTO 


```{c}
auto job = qobject_cast<FreeBusyDownloadJob *>(_job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selections) {
                mUI.mNameLineEdit->setEnabled(true);
                mUI.mEmailLineEdit->setEnabled(true);
                QListWidgetItem *item = new QListWidgetItem(mUI.mListWidget);
                mUI.mListWidget->setItemSelected(item, true);
                mUI.mNameLineEdit->setText(selection.name());
                mUI.mEmailLineEdit->setText(selection.email());
                mUI.mListWidget->addItem(item);
            }
```

#### AUTO 


```{c}
const auto alarmsLst = incidence->alarms();
```

#### AUTO 


```{c}
auto iface = dynamic_cast<QDBusInterface *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        deletionChange->mItemIds.append(item.id());
    }
```

#### AUTO 


```{c}
auto job = new ItemDeleteJob(mCalendar->item(uid));
```

#### AUTO 


```{c}
auto *job3 = new ItemFetchJob(journal, this);
```

#### AUTO 


```{c}
const auto item = node->sourceIndex.data(EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto exIncPtr = exInc.payload<KCalendarCore::Incidence::Ptr>();
```

#### AUTO 


```{c}
const auto contextAction = determineContextAction(incidence);
```

#### LAMBDA EXPRESSION 


```{c}
[ d] { d->processRetrieveQueue(); }
```

#### AUTO 


```{c}
auto handler = new ITIPHandlerHelper(mFactory, change->parentWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : std::as_const(mQueuedEntries)) {
            mUndoStack.push(entry);
        }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(),
                                                     CollectionFetchJob::Recursive,
                                                     this);
```

#### AUTO 


```{c}
auto *attachMessage = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
        if (!m_mimeTypeChecker.isWantedCollection(col) || col.isVirtual()) {
            continue;
        }
        auto *itemFetch = new ItemFetchJob(col, this);
        itemFetch->fetchScope().fetchFullPayload(true);
        connect(itemFetch, &ItemFetchJob::result, this, &IncidenceFetchJob::itemFetchResult);
        ++m_jobCount;
    }
```

#### AUTO 


```{c}
auto &attEv
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : uids) {
        Akonadi::Item child = item(uid);
        if (child.isValid() && child.hasPayload<KCalendarCore::Incidence::Ptr>()) {
            children.append(child);
        } else {
            qCWarning(AKONADICALENDAR_LOG) << "Invalid child with uid " << uid;
        }
    }
```

#### AUTO 


```{c}
auto *searchJob = static_cast<Akonadi::IncidenceFetchJob *>(job);
```

#### AUTO 


```{c}
auto flatner = new KDescendantsProxyModel(this);
```

#### AUTO 


```{c}
auto *job = new ItemModifyJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : std::as_const(uids)) {
            KCalendarCore::Incidence::Ptr child = d->m_calendar->incidence(uid);
            if (child) {
                incidencesToCut << child;
            }
        }
```

#### AUTO 


```{c}
auto *mailer = new MailClient(d->m_factory);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Change::Ptr &change : lstPendingCreations) {
        mPendingCreations.removeAll(change);

        if (canceled) {
            change->resultCode = ResultCodeUserCanceled;
            continue;
        }

        if (noAcl) {
            change->resultCode = ResultCodePermissions;
            continue;
        }

        if (invalidCollection) {
            change->resultCode = ResultCodeInvalidUserCollection;
            continue;
        }

        if (collectionToUse.isValid()) {
            // We don't show the dialog multiple times
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        KCalCore::Incidence::Ptr incidence = CalendarUtils::incidence(change->newItem);
        Collection::List candidateCollections = collectionsForMimeType(incidence->mimeType(), allCollections);
        if (candidateCollections.count() == 1 && candidateCollections.first().isValid()) {
            // We only have 1 writable collection, don't bother the user with a dialog
            collectionToUse = candidateCollections.first();
            qCDebug(AKONADICALENDAR_LOG) << "Only one collection exists, will not show collection dialog: " << collectionToUse.displayName();
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        // Lets ask the user which collection to use:
        int dialogCode;
        QWidget *parent = change->parentWidget;

        const QStringList mimeTypes(incidence->mimeType());
        collectionToUse = CalendarUtils::selectCollection(parent, /*by-ref*/dialogCode,
                          mimeTypes, mDefaultCollection);
        if (dialogCode != QDialog::Accepted) {
            qCDebug(AKONADICALENDAR_LOG) << "User canceled collection choosing";
            change->resultCode = ResultCodeUserCanceled;
            canceled = true;
            cancelTransaction();
            continue;
        }

        if (collectionToUse.isValid() && !hasRights(collectionToUse, ChangeTypeCreate)) {
            qCWarning(AKONADICALENDAR_LOG) << "No ACLs for incidence creation";
            const QString errorMessage = showErrorDialog(ResultCodePermissions, parent);
            change->resultCode = ResultCodePermissions;
            change->errorString = errorMessage;
            noAcl = true;
            cancelTransaction();
            continue;
        }

        // TODO: add unit test for these two situations after reviewing API
        if (!collectionToUse.isValid()) {
            qCritical() << "Invalid collection selected. Can't create incidence.";
            change->resultCode = ResultCodeInvalidUserCollection;
            const QString errorString = showErrorDialog(ResultCodeInvalidUserCollection, parent);
            change->errorString = errorString;
            invalidCollection = true;
            cancelTransaction();
            continue;
        }

        step2CreateIncidence(change, collectionToUse);
    }
```

#### AUTO 


```{c}
auto d = static_cast<FetchJobCalendarPrivate *>(d_ptr.data());
```

#### AUTO 


```{c}
const auto lstPendingCreations = mPendingCreations;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attNew : qAsConst(attendeesNew)) {
            QString msg
                = i18nc("@info", "%1 wants to attend %2 but was not invited.",
                        attNew.fullName(), incidence->summary());
            if (!attNew.delegator().isEmpty()) {
                msg = i18nc("@info", "%1 wants to attend %2 on behalf of %3.",
                            attNew.fullName(), incidence->summary(), attNew.delegator());
            }
            if (KMessageBox::questionYesNo(
                    nullptr, msg, i18nc("@title", "Uninvited attendee"),
                    KGuiItem(i18nc("@option", "Accept Attendance")),
                    KGuiItem(i18nc("@option", "Reject Attendance"))) != KMessageBox::Yes) {
                Incidence::Ptr cancel = incidence;
                cancel->addComment(i18nc("@info",
                                         "The organizer rejected your attendance at this meeting."));
                performTransaction(incidenceBase, iTIPCancel, attNew.fullName());
                continue;
            }

            Attendee a(attNew.name(), attNew.email(), attNew.RSVP(),
                       attNew.status(), attNew.role(), attNew.uid());

            a.setDelegate(attNew.delegate());
            a.setDelegator(attNew.delegator());
            incidence->addAttendee(a);

            result = ResultSuccess;
            errorString.clear();
            attendeeAdded = true;
        }
```

#### AUTO 


```{c}
auto job3 = new ItemFetchJob(journal, this);
```

#### AUTO 


```{c}
auto d = static_cast<FetchJobCalendarPrivate *>(d_ptr.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : incidences) {
        if (uids.contains(incidence->uid()))
            uids.removeAll(incidence->uid());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### AUTO 


```{c}
auto it = id == -1 ? d->mItemsByCollection.cbegin() : d->mItemsByCollection.constFind(id);
```

#### AUTO 


```{c}
auto *attachDisposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto *job = qobject_cast<Akonadi::ContactSearchJob *>(_job);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attEv : attendeesEv) {
                if (attIn->email().toLower() == attEv->email().toLower()) {
                    //update attendee-info
                    qCDebug(AKONADICALENDAR_LOG) << "update attendee";
                    attEv->setStatus(attIn->status());
                    attEv->setDelegate(attIn->delegate());
                    attEv->setDelegator(attIn->delegator());
                    result = ResultSuccess;
                    errorString.clear();
                    found = true;
                }
            }
```

#### AUTO 


```{c}
auto bodyMessage = new KMime::Content;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        processFreeBusyDownloadResult(job);
    }
```

#### AUTO 


```{c}
const auto j = qobject_cast<const ItemDeleteJob *>(job);
```

#### AUTO 


```{c}
auto *copy = new BlockAlarmsAttribute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event (" << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);
        // If it's readonly, we can't possible update it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();
        const int existingRevision = existingIncidence->revision();

        if (existingRevision <= incidence->revision()) {
            // The new incidence might be an update for the found one
            bool isUpdate = true;
            // Code for new invitations:
            // If you think we could check the value of "status" to be RequestNew:  we can't.
            // It comes from a similar check inside libical, where the event is compared to
            // other events in the calendar. But if we have another version of the event around
            // (e.g. shared folder for a group), the status could be RequestNew, Obsolete or Updated.
            qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";
            // This is supposed to be a new request, not an update - however we want to update
            // the existing one to handle the "clicking more than once on the invitation" case.
            // So check the attendee status of the attendee.
            const Attendee::List attendees = existingIncidence->attendees();
            Attendee::List::ConstIterator ait;
            for (ait = attendees.begin(); ait != attendees.end(); ++ait) {
                if ((*ait).email() == email && (*ait).status() == Attendee::NeedsAction) {
                    // This incidence wasn't created by me - it's probably in a shared folder
                    // and meant for someone else, ignore it.
                    qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                    isUpdate = false;
                    break;
                }
            }
            if (isUpdate) {
                if (existingRevision == incidence->revision() && existingIncidence->lastModified() > incidence->lastModified()) {
                    // This isn't an update - the found incidence was modified more recently
                    errorString = i18n(
                        "This isn't an update. "
                        "The found incidence was modified more recently.");
// QT5 port
#if 0
                    qCWarning(AKONADICALENDAR_LOG) << errorString
                                                   << "; revision=" << existingIncidence->revision()
                                                   << "; existing->lastModified=" << existingIncidence->lastModified()
                                                   << "; update->lastModified=" << incidence->lastModified();
#endif
                    Q_EMIT transactionFinished(ResultOutatedUpdate, errorString);
                    return;
                }
                qCDebug(AKONADICALENDAR_LOG) << "replacing existing incidence " << existingUid;
                if (existingIncidence->type() != incidence->type()) {
                    qCritical() << "assigning different incidence types";
                    result = ResultAssigningDifferentTypes;
                    errorString = i18n("Error: Assigning different incidence types.");
                    Q_EMIT transactionFinished(result, errorString);
                } else {
                    incidence->setSchedulingID(schedulingUid, existingUid);

                    if (incidence->hasRecurrenceId()) {
                        Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());
                        if (!existingInstance) {
                            // The organizer created an exception, lets create it in our calendar, we don't have it yet
                            const bool success = calendar->addIncidence(incidence);

                            if (!success) {
                                Q_EMIT transactionFinished(ResultCreatingError, QStringLiteral("Error creating incidence"));
                            } else {
                                // Signal emitted in the result slot of addFinished()
                            }

                            return;
                        }
                    }

                    const bool success = calendar->modifyIncidence(incidence);

                    if (!success) {
                        Q_EMIT transactionFinished(ResultModifyingError, i18n("Error modifying incidence"));
                    } else {
                        // handleModifyFinished() will Q_EMIT the final signal.
                    }
                }
                return;
            }
        } else {
            errorString = i18n(
                "This isn't an update. "
                "The found incidence was modified more recently.");
            qCWarning(AKONADICALENDAR_LOG) << errorString;
            // This isn't an update - the found incidence has a bigger revision number
            qCDebug(AKONADICALENDAR_LOG) << "This isn't an update - the found incidence has a bigger revision number";
            Q_EMIT transactionFinished(ResultOutatedUpdate, errorString);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : myEmails) {
            const KCalendarCore::Attendee me = incidence->attendeeByMail(email);
            if (!me.isNull() &&
                    (me.status() == KCalendarCore::Attendee::Accepted ||
                     me.status() == KCalendarCore::Attendee::Delegated)) {
                incidenceAcceptedBefore = true;
                break;
            }
        }
```

#### AUTO 


```{c}
auto it = d->mItemById.cbegin(), end = d->mItemById.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(mUids)) {
        const Item item1 = mCalendar->item(uid);
        const Item item2 = mCalendar->item(item1.id());
        QVERIFY(item1.isValid());
        QVERIFY(item2.isValid());
        QCOMPARE(item1.id(), item2.id());
        QCOMPARE(item1.payload<KCalendarCore::Incidence::Ptr>()->uid(), uid);
        QCOMPARE(item2.payload<KCalendarCore::Incidence::Ptr>()->uid(), uid);
    }
```

#### AUTO 


```{c}
auto *handler = new ITIPHandlerHelper(mFactory, change->parentWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[appId, kontactPlugin, uid, occurrence, xdgActivationToken]() {
        // if running inside Kontact, select the right plugin
        if (appId == QLatin1String("org.kde.kontact")) {
            const QString objectName = QLatin1Char('/') + kontactPlugin + QLatin1String("_PimApplication");
            QDBusInterface iface(appId, objectName, QStringLiteral("org.kde.PIMUniqueApplication"), QDBusConnection::sessionBus());
            if (iface.isValid()) {
                QStringList arguments({kontactPlugin});
                iface.call(QStringLiteral("newInstance"), QByteArray(), arguments, QString());
            }
        }

        // select the right incidence/occurrence
        org::kde::calendar::Calendar iface(appId, QStringLiteral("/Calendar"), QDBusConnection::sessionBus());
        iface.showIncidenceByUid(uid, occurrence, xdgActivationToken);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            if (attendee->email() == receiver) {
                if (action.startsWith(QStringLiteral("accepted"))) {
                    attendee->setStatus(KCalCore::Attendee::Accepted);
                } else if (action.startsWith(QStringLiteral("tentative"))) {
                    attendee->setStatus(KCalCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals() &&
                           action.startsWith(QStringLiteral("counter"))) {
                    attendee->setStatus(KCalCore::Attendee::Tentative);
                } else if (action.startsWith(QStringLiteral("delegated"))) {
                    attendee->setStatus(KCalCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PreNode::Ptr &node : nodes) {
            Q_ASSERT(node);
            const QString uid = node->incidence->instanceIdentifier();
            const QString parentUid = node->incidence->relatedTo();
            if (parentUid.isEmpty()) { // toplevel todo
                prenodeByUid.insert(uid, node);
                remainingNodes.removeAll(node);
                node->depth = 0;
            } else {
                if (prenodeByUid.contains(parentUid)) {
                    node->depth = 1 + prenodeByUid.value(parentUid)->depth;
                    remainingNodes.removeAll(node);
                    prenodeByUid.insert(uid, node);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);

        // If it's readonly, we can't possible remove it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();

        // Code for new invitations:
        // We cannot check the value of "status" to be RequestNew because
        // "status" comes from a similar check inside libical, where the event
        // is compared to other events in the calendar. But if we have another
        // version of the event around (e.g. shared folder for a group), the
        // status could be RequestNew, Obsolete or Updated.
        qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";

        // This is supposed to be a new request, not an update - however we want
        // to update the existing one to handle the "clicking more than once
        // on the invitation" case. So check the attendee status of the attendee.
        bool isMine = true;
        const Attendee::List attendees = existingIncidence->attendees();
        for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail
                && attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }

        if (!isMine) {
            continue;
        }

        qCDebug(AKONADICALENDAR_LOG) << "removing existing incidence " << existingUid;
        if (incidence->hasRecurrenceId()) {
            Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());

            if (existingInstance) {
                existingInstance->setStatus(Incidence::StatusCanceled);
                result = calendar->modifyIncidence(existingInstance) ? ResultSuccess : ResultModifyingError;
            } else {
                incidence->setSchedulingID(incidence->uid(), existingIncidence->uid());
                incidence->setStatus(Incidence::StatusCanceled);
                result = calendar->addIncidence(incidence) ? ResultSuccess : ResultCreatingError;
            }

            if (result != ResultSuccess) {
                Q_EMIT transactionFinished(result, i18n("Error recording exception"));
            }
        } else {
            result = calendar->deleteIncidence(existingIncidence) ? ResultSuccess : ResultErrorDelete;
            if (result != ResultSuccess) {
                Q_EMIT transactionFinished(result, errorString);
            }
        }

        // The success case will be handled in handleDeleteFinished()
        return;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotCreateSubTodo(); }
```

#### AUTO 


```{c}
auto modificationChange = new ModificationChange(this, changeId,
                                                                    atomicOperationId, parent);
```

#### AUTO 


```{c}
auto *job2 = new ItemFetchJob(todo, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateActions();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &node : std::as_const(m_toplevelNodeList)) {
        qCDebug(AKONADICALENDAR_LOG) << node;
    }
```

#### AUTO 


```{c}
const auto service = KService::serviceByDesktopName(appId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selections) {
                mUI.mNameLineEdit->setEnabled(true);
                mUI.mEmailLineEdit->setEnabled(true);
                QListWidgetItem *item = new QListWidgetItem(mUI.mListWidget);
                item->setSelected(true);
                mUI.mNameLineEdit->setText(selection.name());
                mUI.mEmailLineEdit->setText(selection.email());
                mUI.mListWidget->addItem(item);
            }
```

#### AUTO 


```{c}
auto *job = new CollectionModifyJob(mCollection, this);
```

#### AUTO 


```{c}
auto it = mItemById.cbegin(), end = mItemById.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        Q_UNUSED(item);
        Q_ASSERT_X(item.isValid(),
                   "History::recordDeletion()", "Item must be valid.");
        Q_ASSERT_X(item.hasPayload<Incidence::Ptr>(),
                   "History::recordDeletion()", "Item must have an Incidence::Ptr payload.");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
        if (!m_mimeTypeChecker.isWantedCollection(col) || col.isVirtual()) {
            continue;
        }
        ItemFetchJob *itemFetch = new ItemFetchJob(col, this);
        itemFetch->fetchScope().fetchFullPayload(true);
        connect(itemFetch, &ItemFetchJob::result, this, &IncidenceFetchJob::itemFetchResult);
        ++m_jobCount;
    }
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(ta_item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &child : childs) {
        KCalCore::Todo::Ptr childTodo = child.dynamicCast<KCalCore::Todo>();

        if (!childTodo) {
            return false;    // This never happens
        }

        if (!treeIsDeletable(childTodo)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *job = new ItemModifyJob(ta_item);
```

#### AUTO 


```{c}
const auto it = m_notifications.constFind(uid);
```

#### AUTO 


```{c}
auto *modificationChange = new ModificationChange(this, changeId,
                                                                    atomicOperationId, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        Q_UNUSED(item)
        Q_ASSERT_X(item.isValid(),
                   "History::recordDeletion()", "Item must be valid.");
        Q_ASSERT_X(item.hasPayload<Incidence::Ptr>(),
                   "History::recordDeletion()", "Item must have an Incidence::Ptr payload.");
    }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto incidence = item.payload<KCalendarCore::Incidence::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
#if AKONADICALENDAR_VERSION < QT_VERSION_CHECK(5, 19, 41)
        const QString uid = alarm->customProperty("ETMCalendar", "parentUid");
#else
        const QString uid = alarm->parentUid();
#endif
        const auto incidence = mCalendar->incidence(uid);
        if (incidence) {
            const auto occurrence = occurrenceForAlarm(incidence, alarm, from);
            addNotification(uid, alarm->text(), occurrence, mLastChecked);
        } else {
            qCDebug(Log) << "Alarm points" << alarm << "to an nonexisting incidence" << uid;
        }
    }
```

#### AUTO 


```{c}
const auto j = qobject_cast<const ItemModifyJob *>(job);
```

#### AUTO 


```{c}
const auto rightIncidencePtr = rightItem.payload<Incidence::Ptr>();
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<Akonadi::AbstractEmailAddressSelectionDialog>(editWidgetPlugin, q);
```

#### AUTO 


```{c}
auto deleteJob = new ItemDeleteJob(itemsToDelete);
```

#### AUTO 


```{c}
auto createJob = new ItemCreateJob(i, collection);
```

#### AUTO 


```{c}
auto *model = qobject_cast<Akonadi::CalendarModel *>(other->entityTreeModel());
```

#### AUTO 


```{c}
auto transferJob = static_cast<KIO::TransferJob *>(job);
```

#### AUTO 


```{c}
const auto kontactPlugin = grp.readEntry(QStringLiteral("KontactPlugin"), QStringLiteral("korganizer"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lst) {
        KCalendarCore::Incidence::Ptr incidence = CalendarUtils::incidence(item);
        incidence->setReadOnly(isReadOnly);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            if (attendee.email() == receiver) {
                if (action.startsWith(QLatin1String("accepted"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Accepted);
                } else if (action.startsWith(QLatin1String("tentative"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals() && action.startsWith(QLatin1String("counter"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Tentative);
                } else if (action.startsWith(QLatin1String("delegated"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### AUTO 


```{c}
auto *createjob
        = qobject_cast<Akonadi::AgentInstanceCreateJob *>(job);
```

#### AUTO 


```{c}
auto job = new ItemCreateJob(item, mCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : myEmails) {
            const KCalendarCore::Attendee me = incidence->attendeeByMail(email);
            if (!me.isNull() && (me.status() == KCalendarCore::Attendee::Accepted || me.status() == KCalendarCore::Attendee::Delegated)) {
                incidenceAcceptedBefore = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &child : immediateChildren) {
            getIncidenceHierarchy(child, uids);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : list) {
        mUI.mNameLineEdit->setEnabled(true);
        mUI.mEmailLineEdit->setEnabled(true);
        auto item = new QListWidgetItem(mUI.mListWidget);
        item->setSelected(true);
        mUI.mNameLineEdit->setText(contact.name());
        mUI.mEmailLineEdit->setText(contact.preferredEmail());
        mUI.mListWidget->addItem(item);
    }
```

#### AUTO 


```{c}
auto *job = new FreeBusyDownloadJob(freeBusyUrlForEmail, mParentWidgetForRetrieval);
```

#### AUTO 


```{c}
auto mailer = new MailClient(d->m_factory);
```

#### AUTO 


```{c}
auto selectionModel = new QItemSelectionModel(mCollectionProxyModel);
```

#### AUTO 


```{c}
auto widget = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotCreateJournal();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : children) {
            Akonadi::Item childItem = m_calendar->item(incidence);
            if (!childItem.isValid()) {
                Q_EMIT q->cutFinished(/**success=*/false, i18n("Can't find item: %1", childItem.id()));
                return;
            }

            KCalendarCore::Incidence::Ptr newIncidence(child->clone());
            newIncidence->setRelatedTo(QString());
            childItem.setPayload<KCalendarCore::Incidence::Ptr>(newIncidence);
            const int changeId = m_changer->modifyIncidence(childItem, /*originalPayload*/ child);
            if (changeId == -1) {
                m_abortCurrentOperation = true;
                break;
            } else {
                m_pendingChangeIds << changeId;
            }
        }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(),
                                                         CollectionFetchJob::Recursive,
                                                         this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : qAsConst(mEntries)) {
        entry->doIt(TypeRedo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item::Id &id : itemIds) {
            if (mItemById.contains(id)) {
                internalRemove(mItemById.value(id));
            }
        }
```

#### AUTO 


```{c}
auto *transferJob = static_cast<KIO::TransferJob *>(job);
```

#### AUTO 


```{c}
auto *createJob = new ItemCreateJob(change->newItem, collection, parentJob(change));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            // Weren't deleted due to error
            mDeletedItemIds.remove(mDeletedItemIds.indexOf(item.id()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail &&
                    attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::EmailAddressSelection &selection : selections) {
                    mUI.mNameLineEdit->setEnabled(true);
                    mUI.mEmailLineEdit->setEnabled(true);
                    QListWidgetItem *item = new QListWidgetItem(mUI.mListWidget);
                    mUI.mListWidget->setItemSelected(item, true);
                    mUI.mNameLineEdit->setText(selection.name());
                    mUI.mEmailLineEdit->setText(selection.email());
                    mUI.mListWidget->addItem(item);
                }
```

#### AUTO 


```{c}
const auto suspendedAlarms = suspendedGroup.groupList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    const KCalendarCore::Attendee me(incidence->attendeeByMails(myEmails));
                    if (!me.isNull()) {
                        if (me.status() == KCalendarCore::Attendee::Accepted
                            || me.status() == KCalendarCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalendarCore::Attendee newMe(me);
                        newMe.setStatus(KCalendarCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        //break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalendarCore::iTIPReply);
                    }
                }
            }
```

#### AUTO 


```{c}
auto *fetchJob = new ItemFetchJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        KCalendarCore::Todo::Ptr todo = CalendarUtils::todo(item);

        if (!todo || !todo->isCompleted()) {
            continue;
        }

        if (treeIsDeletable(todo)) {
            toDelete.append(item);
        } else {
            m_ignoredItems++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : uids) {
        Akonadi::Item child = item(uid);
        if (child.isValid() && child.hasPayload<KCalCore::Incidence::Ptr>()) {
            children.append(child);
        } else {
            qCWarning(AKONADICALENDAR_LOG) << "Invalid child with uid " << uid;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotEditIncidence();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attIn : attendeesIn) {
            bool found = false;
            for (auto &attEv : attendeesEv) {
                if (attIn->email().toLower() == attEv->email().toLower()) {
                    //update attendee-info
                    qCDebug(AKONADICALENDAR_LOG) << "update attendee";
                    attEv->setStatus(attIn->status());
                    attEv->setDelegate(attIn->delegate());
                    attEv->setDelegator(attIn->delegator());
                    result = ResultSuccess;
                    errorString.clear();
                    found = true;
                }
            }
            if (!found && attIn->status() != Attendee::Declined) {
                attendeesNew.append(attIn);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : incidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee->setUid(attendee->email());
        }
        incidence->setAttendees(attendees);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : qAsConst(deletedIds)) {
                QVERIFY(id != -1);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalendarCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mItems)) {
        if (useAtomicOperation) {
            mChanger->startAtomicOperation();
        }

        Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
        const int changeId = mChanger->createIncidence(item.payload<KCalendarCore::Incidence::Ptr>(),
                             Collection(item.storageCollectionId()),
                             currentParent());
        success = (changeId != -1) && success;
        mChangeIds << changeId;
        if (useAtomicOperation) {
            mChanger->endAtomicOperation();
        }

        mOldIdByChangeId.insert(changeId, item.id());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &cols, const QSet<QByteArray> &set) {
                    onCollectionChanged(cols, set);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(mUids)) {
        const Item item1 = mCalendar->item(uid);
        const Item item2 = mCalendar->item(item1.id());
        QVERIFY(item1.isValid());
        QVERIFY(item2.isValid());
        QCOMPARE(item1.id(), item2.id());
        QCOMPARE(item1.payload<KCalCore::Incidence::Ptr>()->uid(), uid);
        QCOMPARE(item2.payload<KCalCore::Incidence::Ptr>()->uid(), uid);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &knownIncidence : knownIncidences) {
                if (knownIncidence->summary() == d->m_incidence->summary()) {
                    qCDebug(AKONADICALENDAR_LOG) << "\nFound: uid=" << knownIncidence->uid()
                                                 << "; identifier=" << knownIncidence->instanceIdentifier()
                                                 << "; schedulingId" << knownIncidence->schedulingID();
                }
            }
```

#### AUTO 


```{c}
auto *monitor = new Akonadi::Monitor(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attIn : attendeesIn) {
            bool found = false;
            for (auto &attEv : attendeesEv) {
                if (attIn.email().toLower() == attEv.email().toLower()) {
                    //update attendee-info
                    qCDebug(AKONADICALENDAR_LOG) << "update attendee";
                    attEv.setStatus(attIn.status());
                    attEv.setDelegate(attIn.delegate());
                    attEv.setDelegator(attIn.delegator());
                    result = ResultSuccess;
                    errorString.clear();
                    found = true;
                }
            }
            if (!found && attIn.status() != Attendee::Declined) {
                attendeesNew.append(attIn);
            }
        }
```

#### AUTO 


```{c}
auto iface = qobject_cast<QDBusInterface *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(uids)) {
            KCalCore::Incidence::Ptr child = d->m_calendar->incidence(uid);
            if (child) {
                incidencesToCopy << child;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        QVERIFY(job->exec());
        QVERIFY(!job->items().isEmpty());
        ok = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &incidence : qAsConst(incidences)) {
            Q_ASSERT(incidence);
            if (!incidence) {
                continue;
            }
            const int requestId = d->m_changer->createIncidence(incidence, collection);
            Q_ASSERT(requestId != -1); // -1 only happens with invalid incidences
            if (requestId != -1) {
                d->m_pendingRequests << requestId;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]( const Akonadi::Collection &cols, const QSet<QByteArray> &set)
        { onCollectionChanged(cols, set);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : immediateChildren) {
            getIncidenceHierarchy(child, uids);
        }
```

#### AUTO 


```{c}
auto *job = static_cast<KIO::FileCopyJob *>(_job);
```

#### AUTO 


```{c}
auto *modifyJob = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
auto *job4 = new ItemFetchJob(incidence, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : incidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        const auto attendees = incidence->attendees();
        for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            attendee->setUid(attendee->email());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItem) {
            if (!item.isValid() || !item.hasPayload<KCalCore::Incidence::Ptr>()) {
                m_success = false;
                m_errorMessage = QStringLiteral("Invalid item or payload: %1").arg(item.id());
                qCWarning(AKONADICALENDAR_LOG) << "Unable to fetch incidences:" << m_errorMessage;
                continue;
            }
            internalInsert(item);
        }
```

#### AUTO 


```{c}
auto *job = new ItemCreateJob(item, mCollection, this);
```

#### AUTO 


```{c}
auto item = idx.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        if (!m_mimeTypeChecker.isWantedItem(item)) {
            continue;
        }
        m_items.push_back(item);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ContactSearchJob();
```

#### AUTO 


```{c}
auto bodyDisposition = new KMime::Headers::ContentDisposition;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event (" << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);

        // If it's readonly, we can't possible remove it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();

        // Code for new invitations:
        // We cannot check the value of "status" to be RequestNew because
        // "status" comes from a similar check inside libical, where the event
        // is compared to other events in the calendar. But if we have another
        // version of the event around (e.g. shared folder for a group), the
        // status could be RequestNew, Obsolete or Updated.
        qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";

        // This is supposed to be a new request, not an update - however we want
        // to update the existing one to handle the "clicking more than once
        // on the invitation" case. So check the attendee status of the attendee.
        bool isMine = true;
        const Attendee::List attendees = existingIncidence->attendees();
        for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail && attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }

        if (!isMine) {
            continue;
        }

        qCDebug(AKONADICALENDAR_LOG) << "removing existing incidence " << existingUid;
        if (incidence->hasRecurrenceId()) {
            Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());

            if (existingInstance) {
                existingInstance->setStatus(Incidence::StatusCanceled);
                result = calendar->modifyIncidence(existingInstance) ? ResultSuccess : ResultModifyingError;
            } else {
                incidence->setSchedulingID(incidence->uid(), existingIncidence->uid());
                incidence->setStatus(Incidence::StatusCanceled);
                result = calendar->addIncidence(incidence) ? ResultSuccess : ResultCreatingError;
            }

            if (result != ResultSuccess) {
                Q_EMIT transactionFinished(result, i18n("Error recording exception"));
            }
        } else {
            result = calendar->deleteIncidence(existingIncidence) ? ResultSuccess : ResultErrorDelete;
            if (result != ResultSuccess) {
                Q_EMIT transactionFinished(result, errorString);
            }
        }

        // The success case will be handled in handleDeleteFinished()
        return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : childs) {
            Akonadi::Item childItem = m_calendar->item(incidence);
            if (!childItem.isValid()) {
                emit q->cutFinished(/**success=*/ false, i18n("Can't find item: %1", childItem.id()));
                return;
            }

            KCalendarCore::Incidence::Ptr newIncidence(child->clone());
            newIncidence->setRelatedTo(QString());
            childItem.setPayload<KCalendarCore::Incidence::Ptr>(newIncidence);
            const int changeId = m_changer->modifyIncidence(childItem, /*originalPayload*/child);
            if (changeId == -1) {
                m_abortCurrentOperation = true;
                break;
            } else {
                m_pendingChangeIds << changeId;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : std::as_const(mUids)) {
        const Item item1 = mCalendar->item(uid);
        const Item item2 = mCalendar->item(item1.id());
        QVERIFY(item1.isValid());
        QVERIFY(item2.isValid());
        QCOMPARE(item1.id(), item2.id());
        QCOMPARE(item1.payload<KCalendarCore::Incidence::Ptr>()->uid(), uid);
        QCOMPARE(item2.payload<KCalendarCore::Incidence::Ptr>()->uid(), uid);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        const QString uid = alarm->parentUid();
        const auto incidence = mCalendar->incidence(uid);
        const auto occurrence = occurrenceForAlarm(incidence, alarm, from);
        addNotification(uid, alarm->text(), occurrence, mLastChecked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : qAsConst(deletion->mItemIds)) {
                Q_ASSERT(!m_itemIdsInOperation.contains(id));
                m_itemIdsInOperation.insert(id);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }
                // We only send CANCEL if we're the organizer.
                // If we're not, then we send REPLY with PartStat=Declined in handleInvitationsAfterChange()
                if (Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    // TODO: not to popup all delete message dialogs at once :(
                    sendOk = false;
                    handler->sendIncidenceDeletedMessage(KCalendarCore::iTIPCancel, incidence);
                    if (change->atomicOperationId) {
                        mInvitationStatusByAtomicOperation.insert(change->atomicOperationId, status);
                    }
                    // TODO: with some status we want to break immediately
                }
            }
```

#### AUTO 


```{c}
auto i = item.payload<Incidence::Ptr>();
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionFetchJob(collection, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
const auto preSize = prenodeByUid.count();
```

#### AUTO 


```{c}
auto model = qobject_cast<Akonadi::CalendarModel *>(other->entityTreeModel());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : splittedEmail) {
        const QString str = KEmailAddress::extractEmailAddress(KEmailAddress::normalizeAddressesAndEncodeIdn(email));
        normalizedEmail << str;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            if (attendee.email() == receiver) {
                if (action.startsWith(QLatin1String("accepted"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Accepted);
                } else if (action.startsWith(QLatin1String("tentative"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals()
                           && action.startsWith(QLatin1String("counter"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Tentative);
                } else if (action.startsWith(QLatin1String("delegated"))) {
                    attendee.setStatus(KCalendarCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Help, this);
```

#### AUTO 


```{c}
const auto j = qobject_cast<const ItemCreateJob *>(job);
```

#### AUTO 


```{c}
const auto item = idx.data(Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### AUTO 


```{c}
const auto leftIncidencePtr = leftItem.payload<Incidence::Ptr>();
```

#### AUTO 


```{c}
auto *iface = dynamic_cast<QDBusInterface *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
                    auto *fetchJob = new ItemFetchJob(item, this);
                    fetchJob->fetchScope().fetchFullPayload();
                    QVERIFY(!fetchJob->exec());
                    QVERIFY(fetchJob->items().isEmpty());
                    delete fetchJob;
                }
```

#### AUTO 


```{c}
auto *atomicOperation = new AtomicOperation(d, d->mLatestAtomicOperationId);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ContactSearchJob();
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : std::as_const(uids)) {
            KCalendarCore::Incidence::Ptr child = d->m_calendar->incidence(uid);
            if (child) {
                incidencesToCopy << child;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        const auto attendees = incidence->attendees();
        for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            attendee->setUid(attendee->email());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &expectedIncidence : expectedIncidences) {
        KCalendarCore::Incidence::Ptr incidence;
        for (int i = 0; i < incidences.count(); i++) {
            if (incidences.at(i)->instanceIdentifier() == expectedIncidence->instanceIdentifier()) {
                incidence = incidences.at(i);
                incidences.remove(i);
                break;
            }
        }
        QVERIFY(incidence);
        // Don't fail on creation times, which are obviously different
        expectedIncidence->setCreated(incidence->created());
        incidence->removeCustomProperty(QByteArray("LIBKCAL"), QByteArray("ID"));

        if (*expectedIncidence != *incidence) {
            ICalFormat format;
            QString expectedData = format.toString(expectedIncidence);
            QString gotData = format.toString(incidence);
            qDebug() << "Test failed, expected:\n" << expectedData << "\nbut got " << gotData;
            QVERIFY(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    const KCalendarCore::Attendee me(incidence->attendeeByMails(myEmails));
                    if (!me.isNull()) {
                        if (me.status() == KCalendarCore::Attendee::Accepted || me.status() == KCalendarCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalendarCore::Attendee newMe(me);
                        newMe.setStatus(KCalendarCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        // break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalendarCore::iTIPReply);
                    }
                }
            }
```

#### AUTO 


```{c}
auto incidence = items.first().payload<KCalendarCore::Incidence::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            internalInsert(item);
        }
```

#### AUTO 


```{c}
const auto incType{inc->type()};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotCreateJournal(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);

        // If it's readonly, we can't possible remove it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();

        // Code for new invitations:
        // We cannot check the value of "status" to be RequestNew because
        // "status" comes from a similar check inside libical, where the event
        // is compared to other events in the calendar. But if we have another
        // version of the event around (e.g. shared folder for a group), the
        // status could be RequestNew, Obsolete or Updated.
        qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";

        // This is supposed to be a new request, not an update - however we want
        // to update the existing one to handle the "clicking more than once
        // on the invitation" case. So check the attendee status of the attendee.
        bool isMine = true;
        const Attendee::List attendees = existingIncidence->attendees();
        for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail
                && attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }

        if (!isMine) {
            continue;
        }

        qCDebug(AKONADICALENDAR_LOG) << "removing existing incidence " << existingUid;
        if (incidence->hasRecurrenceId()) {
            Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());

            if (existingInstance) {
                existingInstance->setStatus(Incidence::StatusCanceled);
                result = calendar->modifyIncidence(existingInstance) ? ResultSuccess : ResultModifyingError;
            } else {
                incidence->setSchedulingID(incidence->uid(), existingIncidence->uid());
                incidence->setStatus(Incidence::StatusCanceled);
                result = calendar->addIncidence(incidence) ? ResultSuccess : ResultCreatingError;
            }

            if (result != ResultSuccess) {
                emit transactionFinished(result, i18n("Error recording exception"));
            }
        } else {
            result = calendar->deleteIncidence(existingIncidence) ? ResultSuccess : ResultErrorDelete;
            if (result != ResultSuccess) {
                emit transactionFinished(result, errorString);
            }
        }

        // The success case will be handled in handleDeleteFinished()
        return;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee &attendee : attendees) {
        if (CalendarUtils::thatIsMe(attendee)) {
            return !d->mBlockedStatusList.contains(attendee.status());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(uids)) {
            KCalendarCore::Incidence::Ptr child = d->m_calendar->incidence(uid);
            if (child) {
                incidencesToCopy << child;
            }
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(collection, Akonadi::CollectionFetchJob::Base, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        const QString uid = alarm->parentUid();
        const auto incidence = mCalendar->incidence(uid);
        if (incidence) {
            const auto occurrence = occurrenceForAlarm(incidence, alarm, from);
            addNotification(uid, alarm->text(), occurrence, mLastChecked);
        } else {
            qCDebug(Log) << "Alarm points" << alarm << "to an nonexisting incidence" << uid;
        }
    }
```

#### AUTO 


```{c}
const auto collections = fetch->collections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(items)) {
        QVERIFY(Helper::confirmDoesntExist(item));
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::AgentInstanceCreateJob(type, this);
```

#### AUTO 


```{c}
auto session = new Akonadi::Session("ETMCalendar", q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
#if AKONADICALENDAR_VERSION < QT_VERSION_CHECK(5, 19, 41)
        const QString uid = alarm->customProperty("ETMCalendar", "parentUid");
#else
        const QString uid = alarm->parentUid();
#endif
        const auto incidence = mCalendar->incidence(uid);
        const auto occurrence = occurrenceForAlarm(incidence, alarm, from);
        addNotification(uid, alarm->text(), occurrence, mLastChecked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);
        // If it's readonly, we can't possible update it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();
        const int existingRevision = existingIncidence->revision();

        if (existingRevision <= incidence->revision()) {
            // The new incidence might be an update for the found one
            bool isUpdate = true;
            // Code for new invitations:
            // If you think we could check the value of "status" to be RequestNew:  we can't.
            // It comes from a similar check inside libical, where the event is compared to
            // other events in the calendar. But if we have another version of the event around
            // (e.g. shared folder for a group), the status could be RequestNew, Obsolete or Updated.
            qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";
            // This is supposed to be a new request, not an update - however we want to update
            // the existing one to handle the "clicking more than once on the invitation" case.
            // So check the attendee status of the attendee.
            const Attendee::List attendees = existingIncidence->attendees();
            Attendee::List::ConstIterator ait;
            for (ait = attendees.begin(); ait != attendees.end(); ++ait) {
                if ((*ait).email() == email && (*ait).status() == Attendee::NeedsAction) {
                    // This incidence wasn't created by me - it's probably in a shared folder
                    // and meant for someone else, ignore it.
                    qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                    isUpdate = false;
                    break;
                }
            }
            if (isUpdate) {
                if (existingRevision == incidence->revision() &&
                        existingIncidence->lastModified() > incidence->lastModified()) {
                    // This isn't an update - the found incidence was modified more recently
                    errorString = i18n("This isn't an update. "
                                       "The found incidence was modified more recently.");
//QT5 port
#if 0
                    qCWarning(AKONADICALENDAR_LOG) << errorString
                                                   << "; revision=" << existingIncidence->revision()
                                                   << "; existing->lastModified=" << existingIncidence->lastModified()
                                                   << "; update->lastModified=" << incidence->lastModified();
#endif
                    emit transactionFinished(ResultOutatedUpdate, errorString);
                    return;
                }
                qCDebug(AKONADICALENDAR_LOG) << "replacing existing incidence " << existingUid;
                if (existingIncidence->type() != incidence->type()) {
                    qCritical() << "assigning different incidence types";
                    result = ResultAssigningDifferentTypes;
                    errorString = i18n("Error: Assigning different incidence types.");
                    emit transactionFinished(result, errorString);
                } else {
                    incidence->setSchedulingID(schedulingUid, existingUid) ;

                    if (incidence->hasRecurrenceId()) {
                        Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());
                        if (!existingInstance) {
                            // The organizer created an exception, lets create it in our calendar, we don't have it yet
                            const bool success = calendar->addIncidence(incidence);

                            if (!success) {
                                emit transactionFinished(ResultCreatingError, QStringLiteral("Error creating incidence"));
                            } else {
                                // Signal emitted in the result slot of addFinished()
                            }

                            return;
                        }
                    }

                    const bool success = calendar->modifyIncidence(incidence);

                    if (!success) {
                        emit transactionFinished(ResultModifyingError, i18n("Error modifying incidence"));
                    } else {
                        //handleModifyFinished() will emit the final signal.
                    }
                }
                return;
            }
        } else {
            errorString = i18n("This isn't an update. "
                               "The found incidence was modified more recently.");
            qCWarning(AKONADICALENDAR_LOG) << errorString;
            // This isn't an update - the found incidence has a bigger revision number
            qCDebug(AKONADICALENDAR_LOG) << "This isn't an update - the found incidence has a bigger revision number";
            emit transactionFinished(ResultOutatedUpdate, errorString);
            return;
        }
    }
```

#### AUTO 


```{c}
auto *model = new CalendarModel(monitor);
```

#### AUTO 


```{c}
auto *calendar2 = new ETMCalendar(mCalendar, this);
```

#### AUTO 


```{c}
auto incidence2 = fetchedItem.payload<KCalendarCore::Incidence::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const QString pref = contact.preferredEmail();
        if (!pref.isEmpty() && pref != email) {
            group = cfg.group(pref);
            url = group.readEntry("url");
            qCDebug(AKONADICALENDAR_LOG) << "Preferred email of" << email << "is" << pref;
            if (!url.isEmpty()) {
                qCDebug(AKONADICALENDAR_LOG) << "Taken url from preferred email:" << url;
                emit freeBusyUrlRetrieved(email, replaceVariablesUrl(QUrl(url), email));
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(items)) {
                    auto fetchJob = new ItemFetchJob(item, this);
                    fetchJob->fetchScope().fetchFullPayload();
                    QVERIFY(!fetchJob->exec());
                    QVERIFY(fetchJob->items().isEmpty());
                    delete fetchJob;
                }
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(service, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &incidence : incidences) {
        if (uids.contains(incidence->uid()))
            uids.removeAll(incidence->uid());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail
                && attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(uids)) {
            KCalCore::Incidence::Ptr child = d->m_calendar->incidence(uid);
            if (child) {
                incidencesToCut << child;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(change->originalItems)) {
        mDeletedItemIds << item.id();
    }
```

#### AUTO 


```{c}
const auto &s
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &provider : providers) {
        FreeBusyProviderRequest request(provider);

        connect(request.mInterface.data(), SIGNAL(handlesFreeBusy(QString, bool)), this, SLOT(onHandlesFreeBusy(QString, bool)));

        request.mInterface->call(QStringLiteral("canHandleFreeBusy"), email);
        request.mRequestStatus = FreeBusyProviderRequest::HandlingRequested;
        mProvidersRequestsByEmail[email].mRequests << request;
    }
```

#### AUTO 


```{c}
auto fetch = qobject_cast<CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto model = new CalendarModel(monitor);
```

#### AUTO 


```{c}
auto searchJob = static_cast<Akonadi::IncidenceFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        KCalCore::Todo::Ptr todo = CalendarUtils::incidence(item).dynamicCast<KCalCore::Todo>();

        if (!todo || !todo->isCompleted()) {
            continue;
        }

        if (treeIsDeletable(todo)) {
            toDelete.append(item);
        } else {
            m_ignoredItems++;
        }
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        foreach(const KCalCore::Attendee::Ptr &attendee, incidence->attendees()) {
            attendee->setUid(attendee->email());
        }
    }
```

#### AUTO 


```{c}
auto *fetch = qobject_cast<CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto incidence = fetchedItem.payload<KCalendarCore::Incidence::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &incidence : std::as_const(incidences)) {
            Q_ASSERT(incidence);
            if (!incidence) {
                continue;
            }
            const int requestId = d->m_changer->createIncidence(incidence, collection);
            Q_ASSERT(requestId != -1); // -1 only happens with invalid incidences
            if (requestId != -1) {
                d->m_pendingRequests << requestId;
            }
        }
```

#### AUTO 


```{c}
const auto items = fetch->items();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &child : children) {
            // qCDebug(AKONADICALENDAR_LOG) << "Dealing with child: " << child.data() << child->uid;
            m_toplevelNodeList.append(child);
            child->parentNode = Node::Ptr();
            m_waitingForParent.insert(node->uid, child);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : contacts) {
        const QString pref = contact.preferredEmail();
        if (!pref.isEmpty() && pref != email) {
            group = cfg.group(pref);
            url = group.readEntry("url");
            qCDebug(AKONADICALENDAR_LOG) << "Preferred email of" << email << "is" << pref;
            if (!url.isEmpty()) {
                qCDebug(AKONADICALENDAR_LOG) << "Taken url from preferred email:" << url;
                Q_EMIT freeBusyUrlRetrieved(email, replaceVariablesUrl(QUrl(url), email));
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : list) {
        mUI.mNameLineEdit->setEnabled(true);
        mUI.mEmailLineEdit->setEnabled(true);
        auto *item = new QListWidgetItem(mUI.mListWidget);
        item->setSelected(true);
        mUI.mNameLineEdit->setText(contact.name());
        mUI.mEmailLineEdit->setText(contact.preferredEmail());
        mUI.mListWidget->addItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : std::as_const(mEntries)) {
        entry->doIt(TypeRedo);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        internalRemove(item);
    }
```

#### AUTO 


```{c}
auto it = d->mItemById.constFind(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : allEmails) {
        emails.append(email);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attNew : std::as_const(attendeesNew)) {
            QString msg = i18nc("@info", "%1 wants to attend %2 but was not invited.", attNew.fullName(), incidence->summary());
            if (!attNew.delegator().isEmpty()) {
                msg = i18nc("@info", "%1 wants to attend %2 on behalf of %3.", attNew.fullName(), incidence->summary(), attNew.delegator());
            }
            if (KMessageBox::questionYesNo(nullptr,
                                           msg,
                                           i18nc("@title", "Uninvited attendee"),
                                           KGuiItem(i18nc("@option", "Accept Attendance")),
                                           KGuiItem(i18nc("@option", "Reject Attendance")))
                != KMessageBox::Yes) {
                Incidence::Ptr cancel = incidence;
                cancel->addComment(i18nc("@info", "The organizer rejected your attendance at this meeting."));
                performTransaction(incidenceBase, iTIPCancel, attNew.fullName());
                continue;
            }

            Attendee a(attNew.name(), attNew.email(), attNew.RSVP(), attNew.status(), attNew.role(), attNew.uid());

            a.setDelegate(attNew.delegate());
            a.setDelegator(attNew.delegator());
            incidence->addAttendee(a);

            result = ResultSuccess;
            errorString.clear();
            attendeeAdded = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : qAsConst(deletion->mItemIds)) {
                if (operation->m_itemIdsInOperation.contains(id)) {
                    allow = false;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto item = q->data(index, Akonadi::EntityTreeModel::ItemRole).value<Akonadi::Item>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
        if (CalendarUtils::thatIsMe(attendee)) {
            return !d->mBlockedStatusList.contains(attendee->status());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalendarCore::Incidence::Ptr &incidence : incidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### AUTO 


```{c}
auto *job = new ItemDeleteJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attEv : attendeesEv) {
                if (attIn.email().toLower() == attEv.email().toLower()) {
                    //update attendee-info
                    qCDebug(AKONADICALENDAR_LOG) << "update attendee";
                    attEv.setStatus(attIn.status());
                    attEv.setDelegate(attIn.delegate());
                    attEv.setDelegator(attIn.delegator());
                    result = ResultSuccess;
                    errorString.clear();
                    found = true;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Akonadi::MailClient::Result result, const QString &str) {
            d->finishSendAsICalendar(result, str);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotCreateTodo();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item::Id id : deletedIds) {
                mLatestRevisionByItemId.remove(id);    // TODO
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QByteArray &ba) { d->remoteDownloadFinished(job, ba); }
```

#### AUTO 


```{c}
auto modificationChange = new ModificationChange(this, changeId, atomicOperationId, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
                if (attendee.role() != Attendee::NonParticipant &&
                        attendee.status() != Attendee::Delegated && !Akonadi::CalendarUtils::thatIsMe(attendee)) {
                    attendee.setStatus(Attendee::NeedsAction);
                    attendee.setRSVP(true);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : childs) {
            Akonadi::Item childItem = m_calendar->item(incidence);
            if (!childItem.isValid()) {
                Q_EMIT q->cutFinished(/**success=*/ false, i18n("Can't find item: %1", childItem.id()));
                return;
            }

            KCalendarCore::Incidence::Ptr newIncidence(child->clone());
            newIncidence->setRelatedTo(QString());
            childItem.setPayload<KCalendarCore::Incidence::Ptr>(newIncidence);
            const int changeId = m_changer->modifyIncidence(childItem, /*originalPayload*/ child);
            if (changeId == -1) {
                m_abortCurrentOperation = true;
                break;
            } else {
                m_pendingChangeIds << changeId;
            }
        }
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
                    auto fetchJob = new ItemFetchJob(item, this);
                    fetchJob->fetchScope().fetchFullPayload();
                    QVERIFY(!fetchJob->exec());
                    QVERIFY(fetchJob->items().isEmpty());
                    delete fetchJob;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
                if (attendee.role() != Attendee::NonParticipant && attendee.status() != Attendee::Delegated && !Akonadi::CalendarUtils::thatIsMe(attendee)) {
                    attendee.setStatus(Attendee::NeedsAction);
                    attendee.setRSVP(true);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        if (!item.isValid()) {
            qCritical() << "Items must be valid!";
            d->cancelTransaction();
            return -1;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee &attendee : attendees) {
        if (attendee.email() == QLatin1String(s_ourEmail)) {
            me = attendee;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);
        // If it's readonly, we can't possible update it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();
        const int existingRevision = existingIncidence->revision();

        if (existingRevision <= incidence->revision()) {
            // The new incidence might be an update for the found one
            bool isUpdate = true;
            // Code for new invitations:
            // If you think we could check the value of "status" to be RequestNew:  we can't.
            // It comes from a similar check inside libical, where the event is compared to
            // other events in the calendar. But if we have another version of the event around
            // (e.g. shared folder for a group), the status could be RequestNew, Obsolete or Updated.
            qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";
            // This is supposed to be a new request, not an update - however we want to update
            // the existing one to handle the "clicking more than once on the invitation" case.
            // So check the attendee status of the attendee.
            const Attendee::List attendees = existingIncidence->attendees();
            Attendee::List::ConstIterator ait;
            for (ait = attendees.begin(); ait != attendees.end(); ++ait) {
                if ((*ait).email() == email && (*ait).status() == Attendee::NeedsAction) {
                    // This incidence wasn't created by me - it's probably in a shared folder
                    // and meant for someone else, ignore it.
                    qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                    isUpdate = false;
                    break;
                }
            }
            if (isUpdate) {
                if (existingRevision == incidence->revision()
                    && existingIncidence->lastModified() > incidence->lastModified()) {
                    // This isn't an update - the found incidence was modified more recently
                    errorString = i18n("This isn't an update. "
                                       "The found incidence was modified more recently.");
//QT5 port
#if 0
                    qCWarning(AKONADICALENDAR_LOG) << errorString
                                                   << "; revision=" << existingIncidence->revision()
                                                   << "; existing->lastModified=" << existingIncidence->lastModified()
                                                   << "; update->lastModified=" << incidence->lastModified();
#endif
                    Q_EMIT transactionFinished(ResultOutatedUpdate, errorString);
                    return;
                }
                qCDebug(AKONADICALENDAR_LOG) << "replacing existing incidence " << existingUid;
                if (existingIncidence->type() != incidence->type()) {
                    qCritical() << "assigning different incidence types";
                    result = ResultAssigningDifferentTypes;
                    errorString = i18n("Error: Assigning different incidence types.");
                    Q_EMIT transactionFinished(result, errorString);
                } else {
                    incidence->setSchedulingID(schedulingUid, existingUid);

                    if (incidence->hasRecurrenceId()) {
                        Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());
                        if (!existingInstance) {
                            // The organizer created an exception, lets create it in our calendar, we don't have it yet
                            const bool success = calendar->addIncidence(incidence);

                            if (!success) {
                                Q_EMIT transactionFinished(ResultCreatingError, QStringLiteral("Error creating incidence"));
                            } else {
                                // Signal emitted in the result slot of addFinished()
                            }

                            return;
                        }
                    }

                    const bool success = calendar->modifyIncidence(incidence);

                    if (!success) {
                        Q_EMIT transactionFinished(ResultModifyingError, i18n("Error modifying incidence"));
                    } else {
                        //handleModifyFinished() will Q_EMIT the final signal.
                    }
                }
                return;
            }
        } else {
            errorString = i18n("This isn't an update. "
                               "The found incidence was modified more recently.");
            qCWarning(AKONADICALENDAR_LOG) << errorString;
            // This isn't an update - the found incidence has a bigger revision number
            qCDebug(AKONADICALENDAR_LOG) << "This isn't an update - the found incidence has a bigger revision number";
            Q_EMIT transactionFinished(ResultOutatedUpdate, errorString);
            return;
        }
    }
```

#### AUTO 


```{c}
auto *fetch = qobject_cast<ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);

        // If it's readonly, we can't possible remove it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();

        // Code for new invitations:
        // We cannot check the value of "status" to be RequestNew because
        // "status" comes from a similar check inside libical, where the event
        // is compared to other events in the calendar. But if we have another
        // version of the event around (e.g. shared folder for a group), the
        // status could be RequestNew, Obsolete or Updated.
        qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";

        // This is supposed to be a new request, not an update - however we want
        // to update the existing one to handle the "clicking more than once
        // on the invitation" case. So check the attendee status of the attendee.
        bool isMine = true;
        const Attendee::List attendees = existingIncidence->attendees();
        for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            if (attendee->email() == attendeeEmail &&
                    attendee->status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }

        if (!isMine) {
            continue;
        }

        qCDebug(AKONADICALENDAR_LOG) << "removing existing incidence " << existingUid;
        if (incidence->hasRecurrenceId()) {
            Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());

            if (existingInstance) {
                existingInstance->setStatus(Incidence::StatusCanceled);
                result = calendar->modifyIncidence(existingInstance) ? ResultSuccess : ResultModifyingError;
            } else {
                incidence->setSchedulingID(incidence->uid(), existingIncidence->uid());
                incidence->setStatus(Incidence::StatusCanceled);
                result = calendar->addIncidence(incidence) ? ResultSuccess : ResultCreatingError;
            }

            if (result != ResultSuccess) {
                emit transactionFinished(result, i18n("Error recording exception"));
            }

        } else {
            result = calendar->deleteIncidence(existingIncidence) ? ResultSuccess : ResultErrorDelete;
            if (result != ResultSuccess) {
                emit transactionFinished(result, errorString);
            }
        }

        // The success case will be handled in handleDeleteFinished()
        return;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, d] { d->processRetrieveQueue(); }
```

#### AUTO 


```{c}
auto it = m_notifications.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &node : nodesToRemoveSorted) {
        // Go ahead and remove it now. We don't do it in ::onRowsRemoved(), because
        // while unparenting children with moveRows() the view might call data() on the
        // item that is already removed from ETM.
        removeNode(node);
        // qCDebug(AKONADICALENDAR_LOG) << "Just removed a node, here's the tree";
        // dumpTree();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob*job) { processFreeBusyDownloadResult(job);}
```

#### LAMBDA EXPRESSION 


```{c}
[this](Akonadi::ServerManager::State state) {
            if (state == Akonadi::ServerManager::Running) {
                setupAkonadi();
            }
        }
```

#### AUTO 


```{c}
auto it2 = d->mItemById.constFind(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : attendees) {
        if (CalendarUtils::thatIsMe(attendee)) {
            return !d->mBlockedStatusList.contains(attendee.status());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            if (item.storageCollectionId() == collection.id()) {
                KCalCore::Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (incidence) {
                    incidence->setReadOnly(!(collection.rights() & Akonadi::Collection::CanChangeItem));
                }
            }
        }
```

#### AUTO 


```{c}
const auto eventEndTime = startTime.addSecs(event->dtStart().secsTo(event->dtEnd()));
```

#### AUTO 


```{c}
auto job1 = new ItemFetchJob(event, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attIn : attendeesIn) {
            bool found = false;
            for (auto &attEv : attendeesEv) {
                if (attIn.email().toLower() == attEv.email().toLower()) {
                    // update attendee-info
                    qCDebug(AKONADICALENDAR_LOG) << "update attendee";
                    attEv.setStatus(attIn.status());
                    attEv.setDelegate(attIn.delegate());
                    attEv.setDelegator(attIn.delegator());
                    result = ResultSuccess;
                    errorString.clear();
                    found = true;
                }
            }
            if (!found && attIn.status() != Attendee::Declined) {
                attendeesNew.append(attIn);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            QDesktopServices::openUrl(m_contextAction);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : qAsConst(d->mCollectionMap)) {
        if (!entityTreeModel()->isCollectionPopulated(collection.id())) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto atomicOperation = new AtomicOperation(d.get(), d->mLatestAtomicOperationId);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : std::as_const(deletedIds)) {
                QVERIFY(id != -1);
            }
```

#### AUTO 


```{c}
const auto incidence = mCalendar->incidence(it.value()->uid());
```

#### RANGE FOR STATEMENT 


```{c}
for (const PreNode::Ptr &node : sortedNodes) {
        insertNode(node);
    }
```

#### AUTO 


```{c}
auto fJob = new ItemFetchJob(Item(item.id()));
```

#### AUTO 


```{c}
auto attendees = incidence->attendees();
```

#### AUTO 


```{c}
const auto incidenceType = incidence->type() == KCalendarCore::Incidence::TypeTodo ? i18n("Task") : i18n("Event");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }
                // We only send CANCEL if we're the organizer.
                // If we're not, then we send REPLY with PartStat=Declined in handleInvitationsAfterChange()
                if (Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    //TODO: not to popup all delete message dialogs at once :(
                    sendOk = false;
                    handler->sendIncidenceDeletedMessage(KCalendarCore::iTIPCancel, incidence);
                    if (change->atomicOperationId) {
                        mInvitationStatusByAtomicOperation.insert(change->atomicOperationId, status);
                    }
                    //TODO: with some status we want to break immediately
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
        if (attendee->email() == QLatin1String(s_ourEmail)) {
            me = attendee;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer()->email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    KCalCore::Attendee::Ptr me(incidence->attendeeByMails(myEmails));
                    if (me) {
                        if (me->status() == KCalCore::Attendee::Accepted ||
                                me->status() == KCalCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalCore::Attendee::Ptr newMe(new KCalCore::Attendee(*me));
                        newMe->setStatus(KCalCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        //break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalCore::iTIPReply);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
                if (attendee.role() != Attendee::NonParticipant
                    && attendee.status() != Attendee::Delegated && !Akonadi::CalendarUtils::thatIsMe(attendee)) {
                    attendee.setStatus(Attendee::NeedsAction);
                    attendee.setRSVP(true);
                }
            }
```

#### AUTO 


```{c}
auto *deleteJob = new ItemDeleteJob(change->originalItems, parentJob(change));
```

#### AUTO 


```{c}
const auto occurrence = occurrenceForAlarm(incidence, alarm, from);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItem) {
            if (!item.isValid() || !item.hasPayload<KCalendarCore::Incidence::Ptr>()) {
                m_success = false;
                m_errorMessage = QStringLiteral("Invalid item or payload: %1").arg(item.id());
                qCWarning(AKONADICALENDAR_LOG) << "Unable to fetch incidences:" << m_errorMessage;
                continue;
            }
            internalInsert(item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : std::as_const(deletion->mItemIds)) {
                Q_ASSERT(!m_itemIdsInOperation.contains(id));
                m_itemIdsInOperation.insert(id);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s : suspendedAlarms) {
        const KConfigGroup suspendedAlarm(&suspendedGroup, s);
        const QString uid = suspendedAlarm.readEntry("UID");
        const QString txt = suspendedAlarm.readEntry("Text");
        const QDateTime occurrence = suspendedAlarm.readEntry("Occurrence", QDateTime());
        const QDateTime remindAt = suspendedAlarm.readEntry("RemindAt", QDateTime());
        qCDebug(Log) << "restoreSuspendedFromConfig: Restoring alarm" << uid << "," << txt << "," << remindAt;

        if (!uid.isEmpty() && remindAt.isValid()) {
            addNotification(uid, txt, occurrence, remindAt);
        }
    }
```

#### AUTO 


```{c}
auto createJob = new ItemCreateJob(change->newItem, collection, parentJob(change));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : attendees) {
        if (attendee.email() == QLatin1String(s_ourEmail)) {
            me = attendee;
            break;
        }
    }
```

#### AUTO 


```{c}
auto calendar2 = new ETMCalendar(mCalendar, this);
```

#### AUTO 


```{c}
auto job = qobject_cast<Akonadi::ContactSearchJob *>(_job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Change::Ptr &change : lstPendingCreations) {
        mPendingCreations.removeAll(change);

        if (canceled) {
            change->resultCode = ResultCodeUserCanceled;
            continue;
        }

        if (noAcl) {
            change->resultCode = ResultCodePermissions;
            continue;
        }

        if (invalidCollection) {
            change->resultCode = ResultCodeInvalidUserCollection;
            continue;
        }

        if (collectionToUse.isValid()) {
            // We don't show the dialog multiple times
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        KCalendarCore::Incidence::Ptr incidence = CalendarUtils::incidence(change->newItem);
        Collection::List candidateCollections = collectionsForMimeType(incidence->mimeType(), allCollections);
        if (candidateCollections.count() == 1 && candidateCollections.first().isValid()) {
            // We only have 1 writable collection, don't bother the user with a dialog
            collectionToUse = candidateCollections.first();
            qCDebug(AKONADICALENDAR_LOG) << "Only one collection exists, will not show collection dialog: " << collectionToUse.displayName();
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        // Lets ask the user which collection to use:
        int dialogCode;
        QWidget *parent = change->parentWidget;

        const QStringList mimeTypes(incidence->mimeType());
        collectionToUse = CalendarUtils::selectCollection(parent, /*by-ref*/ dialogCode, mimeTypes, mDefaultCollection);
        if (dialogCode != QDialog::Accepted) {
            qCDebug(AKONADICALENDAR_LOG) << "User canceled collection choosing";
            change->resultCode = ResultCodeUserCanceled;
            canceled = true;
            cancelTransaction();
            continue;
        }

        if (collectionToUse.isValid() && !hasRights(collectionToUse, ChangeTypeCreate)) {
            qCWarning(AKONADICALENDAR_LOG) << "No ACLs for incidence creation";
            const QString errorMessage = showErrorDialog(ResultCodePermissions, parent);
            change->resultCode = ResultCodePermissions;
            change->errorString = errorMessage;
            noAcl = true;
            cancelTransaction();
            continue;
        }

        // TODO: add unit test for these two situations after reviewing API
        if (!collectionToUse.isValid()) {
            qCritical() << "Invalid collection selected. Can't create incidence.";
            change->resultCode = ResultCodeInvalidUserCollection;
            const QString errorString = showErrorDialog(ResultCodeInvalidUserCollection, parent);
            change->errorString = errorString;
            invalidCollection = true;
            cancelTransaction();
            continue;
        }

        step2CreateIncidence(change, collectionToUse);
    }
```

#### AUTO 


```{c}
const auto *j = qobject_cast<const ItemDeleteJob *>(job);
```

#### AUTO 


```{c}
auto job2 = new ItemFetchJob(todo, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid() << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : std::as_const(deletedIds)) {
            QVERIFY(id != -1);
        }
```

#### AUTO 


```{c}
const auto organizer = incidence->organizer();
```

#### AUTO 


```{c}
auto job4 = new ItemFetchJob(incidence, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : incidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        foreach(const KCalCore::Attendee::Ptr &attendee, incidence->attendees()) {
            attendee->setUid(attendee->email());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &expectedIncidence : expectedIncidences) {
        KCalCore::Incidence::Ptr incidence;
        for (int i=0; i<incidences.count(); i++) {
            if (incidences.at(i)->instanceIdentifier() == expectedIncidence->instanceIdentifier()) {
                incidence = incidences.at(i);
                incidences.remove(i);
                break;
            }
        }
        QVERIFY(incidence);
        // Don't fail on creation times, which are obviously different
        expectedIncidence->setCreated(incidence->created());
        incidence->removeCustomProperty(QByteArray("LIBKCAL"), QByteArray("ID"));

        if (*expectedIncidence != *incidence) {
            ICalFormat format;
            QString expectedData = format.toString(expectedIncidence);
            QString gotData = format.toString(incidence);
            qDebug() << "Test failed, expected:\n" << expectedData << "\nbut got " << gotData;
            QVERIFY(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &child : childs) {
            Akonadi::Item childItem = m_calendar->item(incidence);
            if (!childItem.isValid()) {
                emit q->cutFinished(/**success=*/ false, i18n("Can't find item: %1", childItem.id()));
                return;
            }

            KCalCore::Incidence::Ptr newIncidence(child->clone());
            newIncidence->setRelatedTo(QString());
            childItem.setPayload<KCalCore::Incidence::Ptr>(newIncidence);
            const int changeId = m_changer->modifyIncidence(childItem, /*originalPayload*/child);
            if (changeId == -1) {
                m_abortCurrentOperation = true;
                break;
            } else {
                m_pendingChangeIds << changeId;
            }
        }
```

#### AUTO 


```{c}
auto &attendee
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            attendee->setUid(attendee->email());
        }
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(d->mUI.mListWidget);
```

#### AUTO 


```{c}
const auto collection = index.data(Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &child : std::as_const(node->directChilds)) {
        calculateDepth(child);
    }
```

#### AUTO 


```{c}
auto job = static_cast<KIO::FileCopyJob *>(_job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
        if (collection.contentMimeTypes().contains(mimeType)) {
            result << collection;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            if (attendee->email() == attendeeEmail &&
                    attendee->status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }
```

#### AUTO 


```{c}
auto job = new IncidenceFetchJob();
```

#### AUTO 


```{c}
const auto incidence = mCalendar->incidence(uid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mItems)) {
        if (useAtomicOperation) {
            mChanger->startAtomicOperation();
        }

        Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
        const int changeId = mChanger->createIncidence(item.payload<KCalendarCore::Incidence::Ptr>(), Collection(item.storageCollectionId()), currentParent());
        success = (changeId != -1) && success;
        mChangeIds << changeId;
        if (useAtomicOperation) {
            mChanger->endAtomicOperation();
        }

        mOldIdByChangeId.insert(changeId, item.id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &expectedIncidence : expectedIncidences) {
        KCalendarCore::Incidence::Ptr incidence;
        for (int i=0; i<incidences.count(); i++) {
            if (incidences.at(i)->instanceIdentifier() == expectedIncidence->instanceIdentifier()) {
                incidence = incidences.at(i);
                incidences.remove(i);
                break;
            }
        }
        QVERIFY(incidence);
        // Don't fail on creation times, which are obviously different
        expectedIncidence->setCreated(incidence->created());
        incidence->removeCustomProperty(QByteArray("LIBKCAL"), QByteArray("ID"));

        if (*expectedIncidence != *incidence) {
            ICalFormat format;
            QString expectedData = format.toString(expectedIncidence);
            QString gotData = format.toString(incidence);
            qDebug() << "Test failed, expected:\n" << expectedData << "\nbut got " << gotData;
            QVERIFY(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(change->originalItems)) {
        mDeletedItemIds << item.id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : qAsConst(mQueuedEntries)) {
            mUndoStack.push(entry);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
        mCollectionMap.remove(collection.id());
    }
```

#### AUTO 


```{c}
const auto *j = qobject_cast<const ItemModifyJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotEditIncidence(); }
```

#### AUTO 


```{c}
auto copy = new BlockAlarmsAttribute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    const KCalendarCore::Attendee me(incidence->attendeeByMails(myEmails));
                    if (!me.isNull()) {
                        if (me.status() == KCalendarCore::Attendee::Accepted || me.status() == KCalendarCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalendarCore::Attendee newMe(me);
                        newMe.setStatus(KCalendarCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        // break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalendarCore::iTIPReply);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &provider : providers) {
        FreeBusyProviderRequest request(provider);

        // clang-format off
        connect(request.mInterface.data(), SIGNAL(handlesFreeBusy(QString,bool)), this, SLOT(onHandlesFreeBusy(QString,bool)));
        // clang-format on
        request.mInterface->call(QStringLiteral("canHandleFreeBusy"), email);
        request.mRequestStatus = FreeBusyProviderRequest::HandlingRequested;
        mProvidersRequestsByEmail[email].mRequests << request;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Change::Ptr &change : lstPendingCreations) {
        mPendingCreations.removeAll(change);

        if (canceled) {
            change->resultCode = IncidenceChanger::ResultCodeUserCanceled;
            continue;
        }

        if (noAcl) {
            change->resultCode = IncidenceChanger::ResultCodePermissions;
            continue;
        }

        if (invalidCollection) {
            change->resultCode = IncidenceChanger::ResultCodeInvalidUserCollection;
            continue;
        }

        if (collectionToUse.isValid()) {
            // We don't show the dialog multiple times
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        KCalendarCore::Incidence::Ptr incidence = CalendarUtils::incidence(change->newItem);
        Collection::List candidateCollections = collectionsForMimeType(incidence->mimeType(), allCollections);
        if (candidateCollections.count() == 1 && candidateCollections.first().isValid()) {
            // We only have 1 writable collection, don't bother the user with a dialog
            collectionToUse = candidateCollections.first();
            qCDebug(AKONADICALENDAR_LOG) << "Only one collection exists, will not show collection dialog: " << collectionToUse.displayName();
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        // Lets ask the user which collection to use:
        int dialogCode;
        QWidget *parent = change->parentWidget;

        const QStringList mimeTypes(incidence->mimeType());
        collectionToUse = CalendarUtils::selectCollection(parent, /*by-ref*/ dialogCode, mimeTypes, mDefaultCollection);
        if (dialogCode != QDialog::Accepted) {
            qCDebug(AKONADICALENDAR_LOG) << "User canceled collection choosing";
            change->resultCode = IncidenceChanger::ResultCodeUserCanceled;
            canceled = true;
            cancelTransaction();
            continue;
        }

        if (collectionToUse.isValid() && !hasRights(collectionToUse, IncidenceChanger::ChangeTypeCreate)) {
            qCWarning(AKONADICALENDAR_LOG) << "No ACLs for incidence creation";
            const QString errorMessage = showErrorDialog(IncidenceChanger::ResultCodePermissions, parent);
            change->resultCode = IncidenceChanger::ResultCodePermissions;
            change->errorString = errorMessage;
            noAcl = true;
            cancelTransaction();
            continue;
        }

        // TODO: add unit test for these two situations after reviewing API
        if (!collectionToUse.isValid()) {
            qCritical() << "Invalid collection selected. Can't create incidence.";
            change->resultCode = IncidenceChanger::ResultCodeInvalidUserCollection;
            const QString errorString = showErrorDialog(IncidenceChanger::ResultCodeInvalidUserCollection, parent);
            change->errorString = errorString;
            invalidCollection = true;
            cancelTransaction();
            continue;
        }

        step2CreateIncidence(change, collectionToUse);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &provider : providers) {
        FreeBusyProviderRequest request(provider);

        connect(request.mInterface.data(), SIGNAL(handlesFreeBusy(QString,bool)),
                this, SLOT(onHandlesFreeBusy(QString,bool)));

        request.mInterface->call(QStringLiteral("canHandleFreeBusy"), email);
        request.mRequestStatus = FreeBusyProviderRequest::HandlingRequested;
        mProvidersRequestsByEmail[email].mRequests << request;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload<KCalCore::Incidence::Ptr>());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }
                // We only send CANCEL if we're the organizer.
                // If we're not, then we send REPLY with PartStat=Declined in handleInvitationsAfterChange()
                if (Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    //TODO: not to popup all delete message dialogs at once :(
                    sendOk = false;
                    handler->sendIncidenceDeletedMessage(KCalCore::iTIPCancel, incidence);
                    if (change->atomicOperationId) {
                        mInvitationStatusByAtomicOperation.insert(change->atomicOperationId, status);
                    }
                    //TODO: with some status we want to break immediately
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);
        // If it's readonly, we can't possible update it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();
        const int existingRevision = existingIncidence->revision();

        if (existingRevision <= incidence->revision()) {
            // The new incidence might be an update for the found one
            bool isUpdate = true;
            // Code for new invitations:
            // If you think we could check the value of "status" to be RequestNew:  we can't.
            // It comes from a similar check inside libical, where the event is compared to
            // other events in the calendar. But if we have another version of the event around
            // (e.g. shared folder for a group), the status could be RequestNew, Obsolete or Updated.
            qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";
            // This is supposed to be a new request, not an update - however we want to update
            // the existing one to handle the "clicking more than once on the invitation" case.
            // So check the attendee status of the attendee.
            const Attendee::List attendees = existingIncidence->attendees();
            Attendee::List::ConstIterator ait;
            for (ait = attendees.begin(); ait != attendees.end(); ++ait) {
                if ((*ait).email() == email && (*ait).status() == Attendee::NeedsAction) {
                    // This incidence wasn't created by me - it's probably in a shared folder
                    // and meant for someone else, ignore it.
                    qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                    isUpdate = false;
                    break;
                }
            }
            if (isUpdate) {
                if (existingRevision == incidence->revision()
                    && existingIncidence->lastModified() > incidence->lastModified()) {
                    // This isn't an update - the found incidence was modified more recently
                    errorString = i18n("This isn't an update. "
                                       "The found incidence was modified more recently.");
//QT5 port
#if 0
                    qCWarning(AKONADICALENDAR_LOG) << errorString
                                                   << "; revision=" << existingIncidence->revision()
                                                   << "; existing->lastModified=" << existingIncidence->lastModified()
                                                   << "; update->lastModified=" << incidence->lastModified();
#endif
                    emit transactionFinished(ResultOutatedUpdate, errorString);
                    return;
                }
                qCDebug(AKONADICALENDAR_LOG) << "replacing existing incidence " << existingUid;
                if (existingIncidence->type() != incidence->type()) {
                    qCritical() << "assigning different incidence types";
                    result = ResultAssigningDifferentTypes;
                    errorString = i18n("Error: Assigning different incidence types.");
                    emit transactionFinished(result, errorString);
                } else {
                    incidence->setSchedulingID(schedulingUid, existingUid);

                    if (incidence->hasRecurrenceId()) {
                        Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());
                        if (!existingInstance) {
                            // The organizer created an exception, lets create it in our calendar, we don't have it yet
                            const bool success = calendar->addIncidence(incidence);

                            if (!success) {
                                emit transactionFinished(ResultCreatingError, QStringLiteral("Error creating incidence"));
                            } else {
                                // Signal emitted in the result slot of addFinished()
                            }

                            return;
                        }
                    }

                    const bool success = calendar->modifyIncidence(incidence);

                    if (!success) {
                        emit transactionFinished(ResultModifyingError, i18n("Error modifying incidence"));
                    } else {
                        //handleModifyFinished() will emit the final signal.
                    }
                }
                return;
            }
        } else {
            errorString = i18n("This isn't an update. "
                               "The found incidence was modified more recently.");
            qCWarning(AKONADICALENDAR_LOG) << errorString;
            // This isn't an update - the found incidence has a bigger revision number
            qCDebug(AKONADICALENDAR_LOG) << "This isn't an update - the found incidence has a bigger revision number";
            emit transactionFinished(ResultOutatedUpdate, errorString);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : incidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id id : qAsConst(deletedIds)) {
            QVERIFY(id != -1);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        if (!d->hasRights(item.parentCollection(), ChangeTypeDelete)) {
            qCWarning(AKONADICALENDAR_LOG) << "Item " << item.id() << " can't be deleted due to ACL restrictions";
            const QString errorString = d->showErrorDialog(ResultCodePermissions, parent);
            change->resultCode = ResultCodePermissions;
            change->errorString = errorString;
            d->cancelTransaction();
            return changeId;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : std::as_const(mUndoStack)) {
        entry->updateIds(oldId, newId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
        if (collection.rights() & Akonadi::Collection::CanCreateItem) {
            allCollections << collection;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item::Id id : deletedIds) {
                mLatestRevisionByItemId.remove(id); // TODO
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(mItems)) {
        if (useAtomicOperation) {
            mChanger->startAtomicOperation();
        }

        Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
        const int changeId = mChanger->createIncidence(item.payload<KCalendarCore::Incidence::Ptr>(), Collection(item.storageCollectionId()), currentParent());
        success = (changeId != -1) && success;
        mChangeIds << changeId;
        if (useAtomicOperation) {
            mChanger->endAtomicOperation();
        }

        mOldIdByChangeId.insert(changeId, item.id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(mItems)) {
        if (useAtomicOperation) {
            mChanger->startAtomicOperation();
        }

        Q_ASSERT(item.hasPayload<KCalendarCore::Incidence::Ptr>());
        const int changeId = mChanger->createIncidence(item.payload<KCalendarCore::Incidence::Ptr>(),
                                                       Collection(item.storageCollectionId()),
                                                       currentParent());
        success = (changeId != -1) && success;
        mChangeIds << changeId;
        if (useAtomicOperation) {
            mChanger->endAtomicOperation();
        }

        mOldIdByChangeId.insert(changeId, item.id());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[blockedAttr](const auto &alarm) {
                                             return blockedAttr->isAlarmTypeBlocked(alarm->type());
                                         }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : qAsConst(incidences)) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We have incidece with uid=" << incidence->uid() << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### AUTO 


```{c}
const auto lst = mItemsByCollection.values(collection.id());
```

#### AUTO 


```{c}
const auto *j = qobject_cast<const ItemCreateJob *>(job);
```

#### AUTO 


```{c}
auto *columnFilterProxy = new KColumnFilterProxyModel(this);
```

#### AUTO 


```{c}
auto disposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto job = new CollectionModifyJob(mCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee::Ptr &attendee : attendees) {
                if (attendee->role() != Attendee::NonParticipant &&
                        attendee->status() != Attendee::Delegated && !Akonadi::CalendarUtils::thatIsMe(attendee)) {
                    attendee->setStatus(Attendee::NeedsAction);
                    attendee->setRSVP(true);
                }
            }
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attNew : qAsConst(attendeesNew)) {
            QString msg =
                i18nc("@info", "%1 wants to attend %2 but was not invited.",
                      attNew->fullName(), incidence->summary());
            if (!attNew->delegator().isEmpty()) {
                msg = i18nc("@info", "%1 wants to attend %2 on behalf of %3.",
                            attNew->fullName(), incidence->summary(), attNew->delegator());
            }
            if (KMessageBox::questionYesNo(
                        nullptr, msg, i18nc("@title", "Uninvited attendee"),
                        KGuiItem(i18nc("@option", "Accept Attendance")),
                        KGuiItem(i18nc("@option", "Reject Attendance"))) != KMessageBox::Yes) {
                Incidence::Ptr cancel = incidence;
                cancel->addComment(i18nc("@info",
                                         "The organizer rejected your attendance at this meeting."));
                performTransaction(incidenceBase, iTIPCancel, attNew->fullName());
                continue;
            }

            Attendee::Ptr a(new Attendee(attNew->name(), attNew->email(), attNew->RSVP(),
                                         attNew->status(), attNew->role(), attNew->uid()));

            a->setDelegate(attNew->delegate());
            a->setDelegator(attNew->delegator());
            incidence->addAttendee(a);

            result = ResultSuccess;
            errorString.clear();
            attendeeAdded = true;
        }
```

#### AUTO 


```{c}
auto attachMessage = new KMime::Content;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &existingIncidence : existingIncidences) {
        qCDebug(AKONADICALENDAR_LOG) << "Considering this found event ("
                                     << (existingIncidence->isReadOnly() ? "readonly" : "readwrite")
                                     << ") :" << mFormat->toString(existingIncidence);
        // If it's readonly, we can't possible update it.
        if (existingIncidence->isReadOnly()) {
            continue;
        }

        const QString existingUid = existingIncidence->uid();
        const int existingRevision = existingIncidence->revision();

        if (existingRevision <= incidence->revision()) {
            // The new incidence might be an update for the found one
            bool isUpdate = true;
            // Code for new invitations:
            // If you think we could check the value of "status" to be RequestNew:  we can't.
            // It comes from a similar check inside libical, where the event is compared to
            // other events in the calendar. But if we have another version of the event around
            // (e.g. shared folder for a group), the status could be RequestNew, Obsolete or Updated.
            qCDebug(AKONADICALENDAR_LOG) << "looking in " << existingUid << "'s attendees";
            // This is supposed to be a new request, not an update - however we want to update
            // the existing one to handle the "clicking more than once on the invitation" case.
            // So check the attendee status of the attendee.
            const Attendee::List attendees = existingIncidence->attendees();
            Attendee::List::ConstIterator ait;
            for (ait = attendees.begin(); ait != attendees.end(); ++ait) {
                if ((*ait)->email() == email && (*ait)->status() == Attendee::NeedsAction) {
                    // This incidence wasn't created by me - it's probably in a shared folder
                    // and meant for someone else, ignore it.
                    qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                    isUpdate = false;
                    break;
                }
            }
            if (isUpdate) {
                if (existingRevision == incidence->revision() &&
                        existingIncidence->lastModified() > incidence->lastModified()) {
                    // This isn't an update - the found incidence was modified more recently
                    errorString = i18n("This isn't an update. "
                                       "The found incidence was modified more recently.");
//QT5 port
#if 0
                    qCWarning(AKONADICALENDAR_LOG) << errorString
                                                   << "; revision=" << existingIncidence->revision()
                                                   << "; existing->lastModified=" << existingIncidence->lastModified()
                                                   << "; update->lastModified=" << incidence->lastModified();
#endif
                    emit transactionFinished(ResultOutatedUpdate, errorString);
                    return;
                }
                qCDebug(AKONADICALENDAR_LOG) << "replacing existing incidence " << existingUid;
                if (existingIncidence->type() != incidence->type()) {
                    qCritical() << "assigning different incidence types";
                    result = ResultAssigningDifferentTypes;
                    errorString = i18n("Error: Assigning different incidence types.");
                    emit transactionFinished(result, errorString);
                } else {
                    incidence->setSchedulingID(schedulingUid, existingUid) ;

                    if (incidence->hasRecurrenceId()) {
                        Incidence::Ptr existingInstance = calendar->incidence(incidence->instanceIdentifier());
                        if (!existingInstance) {
                            // The organizer created an exception, lets create it in our calendar, we don't have it yet
                            const bool success = calendar->addIncidence(incidence);

                            if (!success) {
                                emit transactionFinished(ResultCreatingError, QStringLiteral("Error creating incidence"));
                            } else {
                                // Signal emitted in the result slot of addFinished()
                            }

                            return;
                        }
                    }

                    const bool success = calendar->modifyIncidence(incidence);

                    if (!success) {
                        emit transactionFinished(ResultModifyingError, i18n("Error modifying incidence"));
                    } else {
                        //handleModifyFinished() will emit the final signal.
                    }
                }
                return;
            }
        } else {
            errorString = i18n("This isn't an update. "
                               "The found incidence was modified more recently.");
            qCWarning(AKONADICALENDAR_LOG) << errorString;
            // This isn't an update - the found incidence has a bigger revision number
            qCDebug(AKONADICALENDAR_LOG) << "This isn't an update - the found incidence has a bigger revision number";
            emit transactionFinished(ResultOutatedUpdate, errorString);
            return;
        }
    }
```

#### AUTO 


```{c}
const auto incidence = mItems.constFirst().payload<KCalendarCore::Incidence::Ptr>();
```

#### AUTO 


```{c}
const auto collections = m_collectionFetchJob->collections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : myEmails) {
            const KCalCore::Attendee me = incidence->attendeeByMail(email);
            if (!me.isNull() &&
                    (me.status() == KCalCore::Attendee::Accepted ||
                     me.status() == KCalCore::Attendee::Delegated)) {
                incidenceAcceptedBefore = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto match = urlFinder.match(incidence->description());
```

#### AUTO 


```{c}
auto fJob = new ItemFetchJob(Item(mItemIdByUid.value(incidence->uid())));
```

#### AUTO 


```{c}
auto attachDisposition = new KMime::Headers::ContentDisposition;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotCreateTodo(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        KCalendarCore::Todo::Ptr todo = CalendarUtils::incidence(item).dynamicCast<KCalendarCore::Todo>();

        if (!todo || !todo->isCompleted()) {
            continue;
        }

        if (treeIsDeletable(todo)) {
            toDelete.append(item);
        } else {
            m_ignoredItems++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
        mCollectionMap[collection.id()] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            if (attendee->email() == receiver) {
                if (action.startsWith(QLatin1String("accepted"))) {
                    attendee->setStatus(KCalCore::Attendee::Accepted);
                } else if (action.startsWith(QLatin1String("tentative"))) {
                    attendee->setStatus(KCalCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals() &&
                           action.startsWith(QLatin1String("counter"))) {
                    attendee->setStatus(KCalCore::Attendee::Tentative);
                } else if (action.startsWith(QLatin1String("delegated"))) {
                    attendee->setStatus(KCalCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Alarm::Ptr &alarm : alarmsLst) {
                if (blockedAttr->isAlarmTypeBlocked(alarm->type())) {
                    incidence->removeAlarm(alarm);
                }
            }
```

#### AUTO 


```{c}
auto fetchJob = new ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto *calendar = qobject_cast<Akonadi::CalendarBase *>(sender());
```

#### AUTO 


```{c}
auto modifyJob = new ItemModifyJob(newItem, parentJob(change));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Change::Ptr &change : lstPendingCreations) {
        mPendingCreations.removeAll(change);

        if (canceled) {
            change->resultCode = ResultCodeUserCanceled;
            continue;
        }

        if (noAcl) {
            change->resultCode = ResultCodePermissions;
            continue;
        }

        if (invalidCollection) {
            change->resultCode = ResultCodeInvalidUserCollection;
            continue;
        }

        if (collectionToUse.isValid()) {
            // We don't show the dialog multiple times
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        KCalendarCore::Incidence::Ptr incidence = CalendarUtils::incidence(change->newItem);
        Collection::List candidateCollections = collectionsForMimeType(incidence->mimeType(), allCollections);
        if (candidateCollections.count() == 1 && candidateCollections.first().isValid()) {
            // We only have 1 writable collection, don't bother the user with a dialog
            collectionToUse = candidateCollections.first();
            qCDebug(AKONADICALENDAR_LOG) << "Only one collection exists, will not show collection dialog: " << collectionToUse.displayName();
            step2CreateIncidence(change, collectionToUse);
            continue;
        }

        // Lets ask the user which collection to use:
        int dialogCode;
        QWidget *parent = change->parentWidget;

        const QStringList mimeTypes(incidence->mimeType());
        collectionToUse = CalendarUtils::selectCollection(parent, /*by-ref*/dialogCode,
                          mimeTypes, mDefaultCollection);
        if (dialogCode != QDialog::Accepted) {
            qCDebug(AKONADICALENDAR_LOG) << "User canceled collection choosing";
            change->resultCode = ResultCodeUserCanceled;
            canceled = true;
            cancelTransaction();
            continue;
        }

        if (collectionToUse.isValid() && !hasRights(collectionToUse, ChangeTypeCreate)) {
            qCWarning(AKONADICALENDAR_LOG) << "No ACLs for incidence creation";
            const QString errorMessage = showErrorDialog(ResultCodePermissions, parent);
            change->resultCode = ResultCodePermissions;
            change->errorString = errorMessage;
            noAcl = true;
            cancelTransaction();
            continue;
        }

        // TODO: add unit test for these two situations after reviewing API
        if (!collectionToUse.isValid()) {
            qCritical() << "Invalid collection selected. Can't create incidence.";
            change->resultCode = ResultCodeInvalidUserCollection;
            const QString errorString = showErrorDialog(ResultCodeInvalidUserCollection, parent);
            change->errorString = errorString;
            invalidCollection = true;
            cancelTransaction();
            continue;
        }

        step2CreateIncidence(change, collectionToUse);
    }
```

#### AUTO 


```{c}
auto *transaction = qobject_cast<TransactionSequence *>(job);
```

#### AUTO 


```{c}
auto it = d->mItemIdByUid.constFind(uid);
```

#### AUTO 


```{c}
const auto buffer = data.peek(sizeof(Header));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->slotCreateEvent();
        }
```

#### AUTO 


```{c}
auto calendar = new FetchJobCalendar();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            // Werent deleted due to error
            mDeletedItemIds.remove(mDeletedItemIds.indexOf(item.id()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attNew : qAsConst(attendeesNew)) {
            QString msg =
                i18nc("@info", "%1 wants to attend %2 but was not invited.",
                      attNew.fullName(), incidence->summary());
            if (!attNew.delegator().isEmpty()) {
                msg = i18nc("@info", "%1 wants to attend %2 on behalf of %3.",
                            attNew.fullName(), incidence->summary(), attNew.delegator());
            }
            if (KMessageBox::questionYesNo(
                        nullptr, msg, i18nc("@title", "Uninvited attendee"),
                        KGuiItem(i18nc("@option", "Accept Attendance")),
                        KGuiItem(i18nc("@option", "Reject Attendance"))) != KMessageBox::Yes) {
                Incidence::Ptr cancel = incidence;
                cancel->addComment(i18nc("@info",
                                         "The organizer rejected your attendance at this meeting."));
                performTransaction(incidenceBase, iTIPCancel, attNew.fullName());
                continue;
            }

            Attendee a(attNew.name(), attNew.email(), attNew.RSVP(),
                                         attNew.status(), attNew.role(), attNew.uid());

            a.setDelegate(attNew.delegate());
            a.setDelegator(attNew.delegator());
            incidence->addAttendee(a);

            result = ResultSuccess;
            errorString.clear();
            attendeeAdded = true;
        }
```

#### AUTO 


```{c}
auto incidence = fetchedItem.payload<KCalendarCore::Event::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : std::as_const(mRedoStack)) {
        entry->updateIds(oldId, newId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(uids)) {
            KCalendarCore::Incidence::Ptr child = d->m_calendar->incidence(uid);
            if (child) {
                incidencesToCut << child;
            }
        }
```

#### AUTO 


```{c}
auto *bodyMessage = new KMime::Content;
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(item);
```

#### AUTO 


```{c}
auto *job1 = new ItemFetchJob(event, this);
```

#### AUTO 


```{c}
auto *fetchJob = new ItemFetchJob(mCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &child : children) {
        KCalendarCore::Todo::Ptr childTodo = child.dynamicCast<KCalendarCore::Todo>();

        if (!childTodo) {
            return false; // This never happens
        }

        if (!treeIsDeletable(childTodo)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    KCalCore::Attendee::Ptr me(incidence->attendeeByMails(myEmails));
                    if (me) {
                        if (me->status() == KCalCore::Attendee::Accepted ||
                                me->status() == KCalCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalCore::Attendee::Ptr newMe(new KCalCore::Attendee(*me));
                        newMe->setStatus(KCalCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        //break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalCore::iTIPReply);
                    }
                }
            }
```

#### AUTO 


```{c}
const auto event = item.payload<Event::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[ d] {
        d->processRetrieveQueue();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : uids) {
        Incidence::Ptr child = incidence(uid);
        if (child) {
            children.append(child);
        } else {
            qCWarning(AKONADICALENDAR_LOG) << "Invalid child with uid " << uid;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, client]() {
            client->suspend(this);
            QObject::disconnect(m_notification, &KNotification::closed, client, nullptr);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[d] {
            d->processRetrieveQueue();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry::Ptr &entry : qAsConst(mRedoStack)) {
        entry->updateIds(oldId, newId);
    }
```

#### AUTO 


```{c}
auto *disposition = new KMime::Headers::ContentDisposition;
```

#### AUTO 


```{c}
auto *calendar = new FetchJobCalendar();
```

#### AUTO 


```{c}
auto *flatner = new KDescendantsProxyModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotCreateEvent(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &alarm : alarmsLst) {
                if (blockedAttr->isAlarmTypeBlocked(alarm->type())) {
                    incidence->removeAlarm(alarm);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        auto job = new ItemDeleteJob(item);
        AKVERIFYEXEC(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            if (attendee->email() == receiver) {
                if (action.startsWith(QLatin1String("accepted"))) {
                    attendee->setStatus(KCalCore::Attendee::Accepted);
                } else if (action.startsWith(QLatin1String("tentative"))) {
                    attendee->setStatus(KCalCore::Attendee::Tentative);
                } else if (CalendarSettings::self()->outlookCompatCounterProposals() &&
                           action.startsWith(QLatin1String("counter"))) {
                    attendee->setStatus(KCalCore::Attendee::Tentative);
                } else if (action.startsWith(QLatin1String("delegated"))) {
                    attendee->setStatus(KCalCore::Attendee::Delegated);
                }
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(change->originalItems)) {
                Q_ASSERT(item.hasPayload());
                Incidence::Ptr incidence = CalendarUtils::incidence(item);
                Q_ASSERT(incidence);
                if (!incidence->supportsGroupwareCommunication()) {
                    continue;
                }

                if (!Akonadi::CalendarUtils::thatIsMe(incidence->organizer().email())) {
                    const QStringList myEmails = Akonadi::CalendarUtils::allEmails();
                    bool notifyOrganizer = false;
                    const KCalCore::Attendee me(incidence->attendeeByMails(myEmails));
                    if (!me.isNull()) {
                        if (me.status() == KCalCore::Attendee::Accepted ||
                                me.status() == KCalCore::Attendee::Delegated) {
                            notifyOrganizer = true;
                        }
                        KCalCore::Attendee newMe(me);
                        newMe.setStatus(KCalCore::Attendee::Declined);
                        incidence->clearAttendees();
                        incidence->addAttendee(newMe);
                        //break;
                    }

                    if (notifyOrganizer) {
                        MailScheduler scheduler(mFactory, change->parentWidget); // TODO make async
                        scheduler.performTransaction(incidence, KCalCore::iTIPReply);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee &attendee : attendees) {
            if (attendee.email() == attendeeEmail &&
                    attendee.status() == Attendee::NeedsAction) {
                // This incidence wasn't created by me - it's probably in a shared
                // folder and meant for someone else, ignore it.
                qCDebug(AKONADICALENDAR_LOG) << "ignoring " << existingUid << " since I'm still NeedsAction there";
                isMine = false;
                break;
            }
        }
```

#### AUTO 


```{c}
auto *bodyDisposition = new KMime::Headers::ContentDisposition;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lst) {
        KCalCore::Incidence::Ptr incidence = CalendarUtils::incidence(item);
        incidence->setReadOnly(isReadOnly);
    }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
auto job = new FreeBusyDownloadJob(freeBusyUrlForEmail, mParentWidgetForRetrieval);
```

#### AUTO 


```{c}
auto itemFetch = new ItemFetchJob(col, this);
```

#### AUTO 


```{c}
const auto event = incidence.staticCast<KCalendarCore::Event>();
```

#### AUTO 


```{c}
auto *job = qobject_cast<FreeBusyDownloadJob *>(_job);
```

#### AUTO 


```{c}
auto calendar = qobject_cast<Akonadi::CalendarBase *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &child : children) {
            const int fromRow = m_toplevelNodeList.indexOf(child);
            Q_ASSERT(fromRow != -1);
            const QModelIndex toParent = indexForNode(node);
            Q_ASSERT(toParent.isValid());
            Q_ASSERT(toParent.model() == q);
            // const int toRow = node->directChilds.count();

            if (!silent) {
                // const bool res = q->beginMoveRows( /**fromParent*/QModelIndex(), fromRow,
                //                                 fromRow, toParent, toRow );
                // Q_EMIT q->layoutAboutToBeChanged();
                q->beginResetModel();
                // Q_ASSERT( res );
            }
            child->parentNode = node;
            node->directChilds.append(child);
            m_toplevelNodeList.remove(fromRow);

            if (!silent) {
                // q->endMoveRows();
                q->endResetModel();
                // Q_EMIT q->layoutChanged();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
            attendee->setUid(attendee->email());
        }
```

#### AUTO 


```{c}
const auto &attNew
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee.setUid(attendee.email());
        }
        incidence->setAttendees(attendees);
    }
```

#### AUTO 


```{c}
auto checkerJob = static_cast<FbCheckerJob *>(job);
```

#### AUTO 


```{c}
auto modifyJob = new ItemModifyJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const KCalCore::Incidence::Ptr &incidence : expectedIncidences) {
        incidence->setUid(incidence->schedulingID());
        qDebug() << "We expect incidece with uid=" << incidence->uid()
                 << "; instanceidentifier=" << incidence->instanceIdentifier();
        auto attendees = incidence->attendees();
        for (auto &attendee : attendees) {
            attendee->setUid(attendee->email());
        }
        incidence->setAttendees(attendees);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->updateActions();
    }
```

#### AUTO 


```{c}
auto incidence = retrievedItem.payload<KCalendarCore::Incidence::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](Akonadi::MailClient::Result result, const QString &str) { d->finishSendAsICalendar(result,str); }
```

#### AUTO 


```{c}
auto scheduler = new MailScheduler(/*factory=*/nullptr, this);
```

#### AUTO 


```{c}
const auto attendees = incidence->attendees();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypes) {
        if (collectionMimeTypes.contains(mimeType)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(items)) {
        QVERIFY(Helper::confirmDoesntExist(item));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node::Ptr &topLevelNode : std::as_const(m_toplevelNodeList)) {
        calculateDepth(topLevelNode);
    }
```

#### AUTO 


```{c}
auto scheduler = new MailScheduler(/*factory=*/ nullptr, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, client, startTime]() {
            client->showIncidence(uid(), startTime, m_notification->xdgActivationToken());
        }
```

