#### AUTO 


```{c}
auto spinbox = styleOptCast<QStyleOptionSpinBox>(option)
```

#### AUTO 


```{c}
auto sgrp = qtcStyleCast<QStyleOptionSizeGrip>(option)
```

#### AUTO 


```{c}
auto twf = styleOptCast<QStyleOptionTabWidgetFrame>(option)
```

#### AUTO 


```{c}
auto round = (active || (firstTab && lastTab) ||
                      opts.tabMouseOver == TAB_MO_GLOW ||
                      opts.roundAllTabs ? ROUNDED_BOTTOM :
                      firstTab ? ROUNDED_BOTTOMLEFT : lastTab ?
                      ROUNDED_BOTTOMRIGHT : ROUNDED_NONE);
```

#### AUTO 


```{c}
auto opt = styleOptCast<QStyleOptionRubberBand>(option);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget: const_(rem)) {
            itsSViewContainers.remove(widget);
        }
```

#### AUTO 


```{c}
static inline auto
qtcMin(const T1 &a, const T2 &b) -> decltype((a < b) ? a : b)
{
    return (a < b) ? a : b;
}
```

#### AUTO 


```{c}
auto header = qtcStyleCast<QStyleOptionHeader>(option)
```

#### AUTO 


```{c}
auto scrollbar = styleOptCast<QStyleOptionSlider>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &kde_home: getKDE4Home()) {
            add_dir(Str::cat(kde_home.get(), "share/apps/QtCurve/"));
        }
```

#### AUTO 


```{c}
auto *res = new QtCurve::Image(width, height, 4);
```

#### AUTO 


```{c}
auto mask =
                    qtcStyleCast<QStyleHintReturnMask>(returnData)
```

#### AUTO 


```{c}
auto func = cleanup_callbacks->func;
```

#### AUTO 


```{c}
auto &bgndFile = opts.bgndImage.pixmap.file;
```

#### AUTO 


```{c}
auto toolbar = qtcStyleCast<QStyleOptionToolBar>(option)
```

#### AUTO 


```{c}
auto ho = qtcStyleCast<QStyleOptionHeader>(option);
```

#### AUTO 


```{c}
auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
auto &srcGrad = src->customGradient[i];
```

#### AUTO 


```{c}
auto mi = styleOptCast<QStyleOptionMenuItem>(option)
```

#### AUTO 


```{c}
static inline auto
qtcMax(const T1 &a, const T2 &b) -> decltype((a > b) ? a : b)
{
    return (a > b) ? a : b;
}
```

#### AUTO 


```{c}
auto mask =
                        styleOptCast<QStyleHintReturnMask>(returnData)
```

#### AUTO 


```{c}
auto abspath = d.absoluteFilePath(file);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect: region.rects()) {
            data << rect.x() << rect.y() << rect.width() << rect.height();
        }
```

#### AUTO 


```{c}
auto bar2 =
                    qtcStyleCast<QStyleOptionProgressBarV2>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] {
            QInternal::registerCallback(QInternal::EventNotifyCallback,
                                        qtcEventCallback);
#ifdef QTC_QT5_ENABLE_QTQUICK2
            QQuickWindow::setDefaultAlphaBuffer(true);
#endif
#ifdef Qt5X11Extras_FOUND
            if (qApp->platformName() == "xcb") {
                qtcX11InitXcb(QX11Info::connection(), QX11Info::appScreen());
            }
#endif
        }
```

#### AUTO 


```{c}
auto &grad = opts->customGradient[i];
```

#### AUTO 


```{c}
auto panel = styleOptCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto tbb = qtcStyleCast<QStyleOptionTabBarBase>(option)
```

#### AUTO 


```{c}
auto bar = styleOptCast<QStyleOptionProgressBarV2>(option)
```

#### AUTO 


```{c}
auto lv = qtcStyleCast<QStyleOptionQ3ListView>(option)
```

#### AUTO 


```{c}
static inline auto
qtcSum(First &&first, Rest &&...rest)
    -> decltype(first + qtcSum(std::forward<Rest>(rest)...))
{
    return first + qtcSum(std::forward<Rest>(rest)...);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (int hint: const_(m_mdiButtons[1])) {
                if (hint == SC_TitleBarCloseButton ||
                    hint == WINDOWTITLE_SPACER ||
                    tb->titleBarFlags & toHint(hint)) {
                    if (hint != WINDOWTITLE_SPACER || totalRight) {
                        totalRight += (hint == WINDOWTITLE_SPACER ?
                                       controlSize / 2 : controlSize);
                    }
                    if (rhs) {
                        if (hint == sc) {
                            pos += controlSize;
                            found = true;
                        } else if (found) {
                            pos += (hint == WINDOWTITLE_SPACER ?
                                    controlSize / 2 : controlSize);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
const auto &rect = QHighDpi::toNativePixels(_rect, widget->window()->windowHandle());
```

#### LAMBDA EXPRESSION 


```{c}
[] (const pair_type &a,
                                                 const char *key) {
                return strcmp_func(a.first, key) < 0;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        QInternal::registerCallback(QInternal::EventNotifyCallback,
                                    qtcEventCallback);
#ifdef Q_WS_X11
        qtcX11InitXlib(QX11Info::display());
#endif
        }
```

#### AUTO 


```{c}
auto file = QFileDialog::getSaveFileName(this, i18n("Save As"), QString(),
                                             i18n("QtCurve Settings Files (*" EXTENSION ")"));
```

#### AUTO 


```{c}
static inline auto
alignTo(T1 len, T2 align) -> decltype(len + align)
{
    return len + getPadding(len, align);
}
```

#### AUTO 


```{c}
auto bar = qtcStyleCast<QStyleOptionProgressBar>(option)
```

#### AUTO 


```{c}
auto &file = opts.menuBgndImage.pixmap.file;
```

#### AUTO 


```{c}
auto &destGrad = dest->customGradient[i];
```

#### AUTO 


```{c}
auto &grad = opts->customGradient[i]
```

#### AUTO 


```{c}
auto tb = styleOptCast<QStyleOptionToolBox>(option);
```

#### AUTO 


```{c}
auto tb = styleOptCast<QStyleOptionTitleBar>(option)
```

#### AUTO 


```{c}
auto round = (active || (firstTab && lastTab) ||
                      opts.tabMouseOver == TAB_MO_GLOW ||
                      opts.roundAllTabs ? ROUNDED_TOP :
                      firstTab ? ROUNDED_TOPLEFT : lastTab ?
                      ROUNDED_TOPRIGHT : ROUNDED_NONE);
```

#### AUTO 


```{c}
auto toolbutton = qtcStyleCast<QStyleOptionToolButton>(option)
```

#### AUTO 


```{c}
auto bgnd = styleOptCast<BgndOption>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                    connect(QCoreApplication::instance(), &QCoreApplication::aboutToQuit, this, [this] () {
                            // disconnect from the session DBus. We're no longer interested in the
                            // information it might send when the app we're serving is shutting down.
                            disconnectDBus();
                            // Stop listening to select signals. We shouldn't stop emitting signals
                            // (like QObject::destroyed) but we can reduce the likelihood that pending
                            // signals will be sent to us post-mortem.
#ifdef QTC_QT5_ENABLE_KDE
                            disconnect(KWindowSystem::self(), &KWindowSystem::compositingChanged,
                                       this, &Style::compositingToggled);
#endif
                        } );
                }
```

#### AUTO 


```{c}
auto focusFrame = qtcStyleCast<QStyleOptionFocusRect>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        size_t len = 0;
        const char *const args[] = {"kde4-config", "--localprefix", nullptr};
        char *res = qtcPopenStdout("kde4-config", args, 300, &len);
        if (res && res[strspn(res, " \t\b\n\f\v")]) {
            if (res[len - 1] == '\n') {
                res[len - 1] = '\0';
            }
            return res;
        }
        if ((res = getenv(getuid() ? "KDEHOME" : "KDEROOTHOME"))) {
            return strdup(res);
        }
        return Str::cat(getHome(), ".kde4");
    }
```

#### AUTO 


```{c}
auto origin = xdg_data_dirs;
```

#### AUTO 


```{c}
auto cb = new CleanupCallback{func, data, cleanup_callbacks,
                                  &cleanup_callbacks};
```

#### AUTO 


```{c}
auto &bgndFile = opts.bgndPixmap.file;
```

#### AUTO 


```{c}
auto groupBox = qtcStyleCast<QStyleOptionGroupBox>(option)
```

#### AUTO 


```{c}
auto focusFrame = styleOptCast<QStyleOptionFocusRect>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: std::initializer_list<QAbstractButton*>{
            animatedProgress, highlightTab, fillSlider, stripedSbar,
                roundMbTopOnly, statusbarHiding_keyboard, statusbarHiding_kwin,
                darkerBorders, comboSplitter, unifyCombo, vArrows, xCheck,
                crButton, roundAllTabs, borderTab, borderInactiveTab,
                invertBotTab, doubleGtkComboArrow, stdSidebarButtons,
                toolbarTabs, centerTabText, borderMenuitems, popupBorder,
                windowBorder_fill, windowBorder_separator, lvLines, lvButton,
                drawStatusBarFrames, menubarMouseOver,
                shadeMenubarOnlyWhenActive, thin_menuitems, thin_buttons,
                thin_frames, hideShortcutUnderline, gtkScrollViews,
                highlightScrollViews, etchEntry, flatSbarButtons,
                colorSliderMouseOver, windowBorder_addLightBorder,
                dwtBtnAsPerTitleBar, dwtColAsPerTitleBar,
                dwtIconColAsPerTitleBar, dwtFontAsPerTitleBar,
                dwtTextAsPerTitleBar, dwtEffectAsPerTitleBar, dwtRoundTopOnly,
                smallRadio, gtkComboMenus, mapKdeIcons, colorMenubarMouseOver,
                useHighlightForMenu, gbLabel_bold, gbLabel_centred, fadeLines,
                menuIcons, stdBtnSizes, forceAlternateLvCols, boldProgress,
                coloredTbarMo, borderSelection, squareEntry, squareLvSelection,
                squareScrollViews, squareFrame, squareTabFrame, squareSlider,
                squareScrollbarSlider, squareWindows, squareTooltips,
                squarePopupMenus, titlebarButtons_button,
                titlebarButtons_customIcon, titlebarButtons_noFrame,
                titlebarButtons_round, titlebarButtons_hoverFrame,
                titlebarButtons_hoverSymbol, titlebarButtons_hoverSymbolFull,
                titlebarButtons_sunkenBackground, titlebarButtons_arrowMinMax,
                titlebarButtons_colorOnMouseOver,
                titlebarButtons_colorSymbolsOnly, titlebarButtons_colorInactive,
                titlebarButtons_hideOnInactiveWindow}) {
        connect(qtcSlot(w, toggled), qtcSlot(this, updateChanged));
    }
```

#### AUTO 


```{c}
auto reply = qtcX11Call(get_property, 0, wId, qtc_x11_qtc_bgnd,
                            XCB_ATOM_CARDINAL, 0, 1);
```

#### AUTO 


```{c}
auto round = (active || (firstTab && lastTab) ||
                      opts.tabMouseOver == TAB_MO_GLOW ||
                      opts.roundAllTabs ? ROUNDED_RIGHT :
                      firstTab ? ROUNDED_TOPRIGHT : lastTab ?
                      ROUNDED_BOTTOMRIGHT : ROUNDED_NONE);
```

#### AUTO 


```{c}
auto *w
```

#### AUTO 


```{c}
auto mask = qtcStyleCast<QStyleHintReturnMask>(returnData)
```

#### AUTO 


```{c}
static const auto wmclassAtom = XcbUtils::getAtom("WM_CLASS");
```

#### AUTO 


```{c}
auto toolbar = styleOptCast<QStyleOptionToolBar>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] (void *ptr) {
                delete reinterpret_cast<T*>(ptr);
            }
```

#### AUTO 


```{c}
auto groupBox = styleOptCast<QStyleOptionGroupBox>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir: dirs) {
            const QDir d(dir);
            const QStringList fileNames = d.entryList(QStringList() << QStringLiteral("*" EXTENSION));
            for (const QString &file: fileNames) {
                if (!files_map.contains(file)) {
                    auto abspath = d.absoluteFilePath(file);
                    files_map.insert(file, abspath);
                    files.append(file);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& exception: list) {
        ExceptionId id(exception);
        if (!id.className().isEmpty()) {
            _whiteList.insert(exception);
        }
    }
```

#### AUTO 


```{c}
auto xdg_data_dirs = getenv("XDG_DATA_DIRS")
```

#### AUTO 


```{c}
auto bus = QDBusConnection::sessionBus();
```

#### LAMBDA EXPRESSION 


```{c}
[] (void *data) {
            reinterpret_cast<Style*>(data)->disconnectDBus();
        }
```

#### AUTO 


```{c}
auto reply = qtcX11GetProperty(0, wId, qtc_x11_qtc_bgnd,
                                   XCB_ATOM_CARDINAL, 0, 1);
```

#### AUTO 


```{c}
auto mbi = qtcStyleCast<QStyleOptionMenuItem>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (QProgressBar *bar: const_(m_progressBars)) {
            if ((opts.animatedProgress && 0 == m_animateStep % 2 &&
                 bar->value() != bar->minimum() &&
                 bar->value() != bar->maximum()) ||
                (0 == bar->minimum() && 0 == bar->maximum())) {
                bar->update();
                hasAnimation = true;
            }
        }
```

#### AUTO 


```{c}
auto v4Opt = qtcStyleCast<QStyleOptionViewItemV4>(option);
```

#### AUTO 


```{c}
auto comboBox = qtcStyleCast<QStyleOptionComboBox>(option)
```

#### AUTO 


```{c}
auto &back = qtc_tics.back();
```

#### AUTO 


```{c}
auto lv = styleOptCast<QStyleOptionQ3ListView>(option)
```

#### AUTO 


```{c}
auto toolbutton =
                styleOptCast<QStyleOptionToolButton>(option)
```

#### AUTO 


```{c}
auto frame = styleOptCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto ho = styleOptCast<QStyleOptionHeader>(option);
```

#### LAMBDA EXPRESSION 


```{c}
[] (const pair_type &a, const pair_type &b) {
                      return strcmp_func(a.first, b.first) < 0;
                  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {lighterPopupMenuBgnd, tabBgnd, menuDelay, menuCloseDelay, crHighlight,
                expanderHighlight, colorSelTab, highlightFactor, bgndOpacity,
                dlgOpacity, menuBgndOpacity, splitterHighlight, gbFactor}) {
        connect(qtcSlot(w, valueChanged, (int)), qtcSlot(this, updateChanged));
    }
```

#### AUTO 


```{c}
auto new_state = GTK_STATE_PRELIGHT == state ? GTK_STATE_NORMAL : state;
```

#### AUTO 


```{c}
auto data = cleanup_callbacks->data;
```

#### RANGE FOR STATEMENT 


```{c}
for (QProgressBar *bar: const_(m_progressBars)) {
            if ((opts.animatedProgress && 0 == m_animateStep % 2 &&
                 bar->value() != bar->minimum() &&
                 bar->value() != bar->maximum()) ||
                (0 == bar->minimum() && 0 == bar->maximum())) {
                bar->update();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QStatusBar *statusBar: const_(sb)) {
                if (m_saveStatusBarStatus) {
                    statusBar->installEventFilter(this);
                }
                if (m_saveStatusBarStatus && qtcStatusBarHidden(appName)) {
                    statusBar->setHidden(true);
                }
            }
```

#### AUTO 


```{c}
auto _tab = styleOptCast<QStyleOptionTab>(option)
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto round = (active || (firstTab && lastTab) ||
                      opts.tabMouseOver == TAB_MO_GLOW ||
                      opts.roundAllTabs ? ROUNDED_LEFT :
                      firstTab ? ROUNDED_TOPLEFT : lastTab ?
                      ROUNDED_BOTTOMLEFT : ROUNDED_NONE);
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        size_t len = 0;
        const char *const args[] = {"kde4-config", "--localprefix", nullptr};
        char *res = qtcPopenStdout("kde4-config", args, 300, &len);
        if (res && res[strspn(res, " \t\b\n\f\v")]) {
            if (res[len - 1] == '\n') {
                res[len - 1] = '\0';
            }
            return res;
        }
        if ((res = getenv(getuid() ? "KDEHOME" : "KDEROOTHOME"))) {
            return strdup(res);
        }
        // according to kdecore/kernel/kstandarddirs.h, ~/.kde is the default for KDEHOME
        // distributions using the default should not have to patch this code.
        return Str::cat(getHome(), ".kde");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int hint: const_(itsMdiButtons[1])) {
                if (hint == SC_TitleBarCloseButton ||
                    hint == WINDOWTITLE_SPACER ||
                    tb->titleBarFlags & toHint(hint)) {
                    if (hint != WINDOWTITLE_SPACER || totalRight) {
                        totalRight += (hint == WINDOWTITLE_SPACER ?
                                       controlSize / 2 : controlSize);
                    }
                    if (rhs) {
                        if (hint == sc) {
                            pos += controlSize;
                            found = true;
                        } else if (found) {
                            pos += (hint == WINDOWTITLE_SPACER ?
                                    controlSize / 2 : controlSize);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto reply = qtcX11QueryTree(current);
```

#### LAMBDA EXPRESSION 


```{c}
[] () -> bool {
        const char *env_color = getenv("QTCURVE_LOG_COLOR");
        if (Str::convert(env_color, false)) {
            return true;
        } else if (!Str::convert(env_color, true)) {
            return false;
        } else if (isatty(2)) {
            return true;
        } else {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QStatusBar *statusBar: getStatusBars(widget)) {
                statusBar->removeEventFilter(this);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {noBgndGradientApps, noBgndOpacityApps,
                noMenuBgndOpacityApps, noBgndImageApps, useQtFileDialogApps,
                menubarApps, statusbarApps, noMenuStripeApps, nonnativeMenubarApps}) {
        connect(qtcSlot(w, editingFinished), qtcSlot(this, updateChanged));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        const char *env_home = getenv("XDG_DATA_HOME");
        if (env_home && *env_home == '/') {
            return Str::cat(env_home, "/");
        } else {
            return Str::cat(getHome(), ".local/share/");
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        // TODO figure out if it is still necessary
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
                KGlobal::ref();
#pragma GCC diagnostic pop
            }
```

#### AUTO 


```{c}
auto toolbutton = styleOptCast<QStyleOptionToolButton>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        std::forward_list<uniqueStr> res;
        auto add_dir = [&] (char *dir) {
            if (isDir(dir)) {
                res.emplace_front(dir);
            } else {
                free(dir);
            }
        };
        add_dir(Str::cat(getHome(), ".kde/"));
        add_dir(Str::cat(getHome(), ".kde4/"));
        char *env = getenv(getuid() ? "KDEHOME" : "KDEROOTHOME");
        if (env && env[0] == '/') {
            add_dir(Str::cat(env, "/"));
        } else {
#ifndef QTC_KDE4_DEFAULT_HOME_DEFAULT
            add_dir(Str::cat(getHome(), QTC_KDE4_DEFAULT_HOME "/"));
#endif
        }
        return res;
    }
```

#### AUTO 


```{c}
auto _frame = styleOptCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto tbOpt = qtcStyleCast<QStyleOptionToolButton>(option)
```

#### AUTO 


```{c}
auto tb = qtcStyleCast<QStyleOptionToolButton>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {lighterPopupMenuBgnd, tabBgnd, menuDelay, crHighlight,
                expanderHighlight, colorSelTab, highlightFactor, bgndOpacity,
                dlgOpacity, menuBgndOpacity, splitterHighlight, gbFactor}) {
        connect(qtcSlot(w, valueChanged, (int)), qtcSlot(this, updateChanged));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *childObject: widget->children()) {
        QWidget *child(qobject_cast<QWidget*>(childObject));
        if (!(child && child->isVisible()))
            continue;
        if (isOpaque(child)) {
            const QPoint offset(child->mapTo(parent, QPoint(0, 0)));
            if (child->mask().isEmpty()) {
                region -= child->rect().translated(offset);
            } else {
                region -= child->mask().translated(offset);
            }
        } else {
            trimBlurRegion(parent, child, region);
        }
    }
```

#### AUTO 


```{c}
auto panel = qtcStyleCast<QStyleOptionFrame>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {customComboBtnColor, customSortedLvColor,
                customProgressColor, customMenuStripeColor,
                customCheckRadioColor, customSlidersColor, customMenubarsColor,
                customMenuSelTextColor, customMenuNormTextColor,
                customCrBgndColor, titlebarButtons_colorClose,
                titlebarButtons_colorMin, titlebarButtons_colorMax,
                titlebarButtons_colorKeepAbove, titlebarButtons_colorKeepBelow,
                titlebarButtons_colorHelp, titlebarButtons_colorMenu,
                titlebarButtons_colorShade, titlebarButtons_colorAllDesktops,
                titlebarButtons_colorCloseIcon, titlebarButtons_colorMinIcon,
                titlebarButtons_colorMaxIcon,
                titlebarButtons_colorKeepAboveIcon,
                titlebarButtons_colorKeepBelowIcon,
                titlebarButtons_colorHelpIcon, titlebarButtons_colorMenuIcon,
                titlebarButtons_colorShadeIcon,
                titlebarButtons_colorAllDesktopsIcon,
                titlebarButtons_colorCloseInactiveIcon,
                titlebarButtons_colorMinInactiveIcon,
                titlebarButtons_colorMaxInactiveIcon,
                titlebarButtons_colorKeepAboveInactiveIcon,
                titlebarButtons_colorKeepBelowInactiveIcon,
                titlebarButtons_colorHelpInactiveIcon,
                titlebarButtons_colorMenuInactiveIcon,
                titlebarButtons_colorShadeInactiveIcon,
                titlebarButtons_colorAllDesktopsInactiveIcon}) {
        connect(qtcSlot(w, changed), qtcSlot(this, updateChanged));
    }
```

#### AUTO 


```{c}
auto tb = styleOptCast<QStyleOptionToolBox>(option)
```

#### AUTO 


```{c}
auto sgrp = styleOptCast<QStyleOptionSizeGrip>(option)
```

#### AUTO 


```{c}
auto l = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto &rect
```

#### AUTO 


```{c}
auto combo = styleOptCast<QStyleOptionComboBox>(option);
```

#### AUTO 


```{c}
auto combo = qtcStyleCast<QStyleOptionComboBox>(option);
```

#### AUTO 


```{c}
auto reply = qtcX11Call(query_tree, current);
```

#### LAMBDA EXPRESSION 


```{c}
[] (void *props) {
                    delete (Props*)props;
                }
```

#### AUTO 


```{c}
auto fo = styleOptCast<QStyleOptionFrame>(option);
```

#### AUTO 


```{c}
auto ind_state = ((list || (!mnu && state == GTK_STATE_INSENSITIVE)) ?
                      state : GTK_STATE_NORMAL);
```

#### RANGE FOR STATEMENT 


```{c}
for (QStatusBar *statusBar: const_(sb)) {
                statusBar->setHidden(statusBar->isVisible());
            }
```

#### AUTO 


```{c}
static inline auto
getPadding(T1 len, T2 align) -> decltype(len + align)
{
    if (auto left = len % align) {
        return align - left;
    }
    return 0;
}
```

#### AUTO 


```{c}
auto frame = qtcStyleCast<QStyleOptionGroupBox>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &exception: list) {
        ExceptionId id(exception);
        if (!id.className().isEmpty()) {
            _blackList.insert(exception);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
            std::unique_ptr<KZip> zip(compressed ? new KZip(file) : nullptr);
            if (zip && zip->open(QIODevice::WriteOnly))
                return false;
            std::unique_ptr<QTemporaryFile> temp(
                compressed ? new QTemporaryFile() : nullptr);
            if (temp && !temp->open())
                return false;
            KConfig cfg(compressed ? temp->fileName() : file,
                        KConfig::NoGlobals);
            Options opts;
            QString bgndImageName;
            QString menuBgndImageName;
            QString bgndPixmapName;
            QString menuBgndPixmapName;
            QString themeName(getFileName(file).remove(EXTENSION)
                              .replace(' ', '_'));
            setOptions(opts);
            if (compressed) {
                if (opts.bgndImage.type == IMG_FILE) {
                    bgndImageName = getThemeFile(opts.bgndImage.pixmap.file);
                    opts.bgndImage.pixmap.file = (themeName +
                                                  BGND_FILE IMAGE_FILE +
                                                  getExt(bgndImageName));
                }
                if (opts.menuBgndImage.type == IMG_FILE) {
                    menuBgndImageName =
                        getThemeFile(opts.menuBgndImage.pixmap.file);
                    opts.menuBgndImage.pixmap.file =
                        (themeName + BGND_FILE MENU_FILE IMAGE_FILE +
                         getExt(menuBgndImageName));
                }
                if (opts.bgndAppearance == APPEARANCE_FILE) {
                    bgndPixmapName = getThemeFile(opts.bgndPixmap.file);
                    opts.bgndPixmap.file =
                        themeName + BGND_FILE + getExt(bgndPixmapName);
                }
                if (opts.menuBgndAppearance == APPEARANCE_FILE) {
                    menuBgndPixmapName = getThemeFile(opts.menuBgndPixmap.file);
                    opts.menuBgndPixmap.file =
                        themeName + BGND_FILE MENU_FILE +
                        getExt(menuBgndPixmapName);
                }
            }
            if (!qtcWriteConfig(&cfg, opts, presets[defaultText].opts, true))
                return false;
            kwin->save(&cfg);
            if (compressed) {
                zip->addLocalFile(temp->fileName(), themeName + EXTENSION);
                if (!bgndImageName.isEmpty())
                    zip->addLocalFile(bgndImageName,
                                      opts.bgndImage.pixmap.file);
                if (!menuBgndImageName.isEmpty())
                    zip->addLocalFile(menuBgndImageName,
                                      opts.menuBgndImage.pixmap.file);
                if (!bgndPixmapName.isEmpty())
                    zip->addLocalFile(bgndPixmapName, opts.bgndPixmap.file);
                if (!menuBgndPixmapName.isEmpty())
                    zip->addLocalFile(menuBgndPixmapName,
                                      opts.menuBgndPixmap.file);
                zip->close();
            }
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &rect: tab->rects) {
            Rect::union_(&rect, &updateRect, &updateRect);
        }
```

#### AUTO 


```{c}
auto &stop =
                                                stops[grad->numStops + addStart];
```

#### AUTO 


```{c}
auto cb = (CleanupCallback*)_cb;
```

#### AUTO 


```{c}
auto round = ROUNDED_NONE;
```

#### AUTO 


```{c}
auto buttonBox = QtCurve::createDialogButtonBox(this);
```

#### AUTO 


```{c}
auto it = find(hash);
```

#### AUTO 


```{c}
auto cmb = qtcStyleCast<QStyleOptionComboBox>(option)
```

#### AUTO 


```{c}
const auto &local = (other.colorGroup() == QPalette::Active ?
                         m_activeShadowConfig : m_inactiveShadowConfig);
```

#### AUTO 


```{c}
auto file = QtCurve::getConfFile(std::string(img->pixmap.file));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: std::initializer_list<QAbstractButton*>{
            animatedProgress, highlightTab, fillSlider, stripedSbar,
                roundMbTopOnly, statusbarHiding_keyboard, statusbarHiding_kwin,
                darkerBorders, comboSplitter, unifyCombo, vArrows, xCheck,
                crButton, roundAllTabs, borderTab, borderInactiveTab,
                invertBotTab, doubleGtkComboArrow, stdSidebarButtons,
                toolbarTabs, centerTabText, borderMenuitems, popupBorder,
                windowBorder_fill, windowBorder_separator, lvLines, lvButton,
                drawStatusBarFrames, menubarMouseOver,
                shadeMenubarOnlyWhenActive, thin_menuitems, thin_buttons,
                thin_frames, hideShortcutUnderline, gtkScrollViews,
                highlightScrollViews, etchEntry, flatSbarButtons,
                colorSliderMouseOver, windowBorder_addLightBorder,
                dwtBtnAsPerTitleBar, dwtColAsPerTitleBar,
                dwtIconColAsPerTitleBar, dwtFontAsPerTitleBar,
                dwtTextAsPerTitleBar, dwtEffectAsPerTitleBar, dwtRoundTopOnly,
                smallRadio, gtkComboMenus, mapKdeIcons, colorMenubarMouseOver,
                useHighlightForMenu, gbLabel_bold, gbLabel_centred, fadeLines,
                menuIcons, onlyTicksInMenu, stdBtnSizes, forceAlternateLvCols, boldProgress,
                coloredTbarMo, borderSelection, squareEntry, squareLvSelection,
                squareScrollViews, squareFrame, squareTabFrame, squareSlider,
                squareScrollbarSlider, squareWindows, squareTooltips,
                squarePopupMenus, titlebarButtons_button,
                titlebarButtons_customIcon, titlebarButtons_noFrame,
                titlebarButtons_round, titlebarButtons_hoverFrame,
                titlebarButtons_hoverSymbol, titlebarButtons_hoverSymbolFull,
                titlebarButtons_sunkenBackground, titlebarButtons_arrowMinMax,
                titlebarButtons_colorOnMouseOver,
                titlebarButtons_colorSymbolsOnly, titlebarButtons_colorInactive,
                titlebarButtons_hideOnInactiveWindow}) {
        connect(qtcSlot(w, toggled), qtcSlot(this, updateChanged));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &_rect: rects) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 6, 0)
            const auto &rect = QHighDpi::toNativePixels(_rect, widget->window()->windowHandle());
#else
            const auto &rect = _rect;
#endif
            data << rect.x() << rect.y() << rect.width() << rect.height();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            QInternal::registerCallback(QInternal::EventNotifyCallback,
                                        qtcEventCallback);
            m_eventNotifyCallbackInstalled = true;
#ifdef QTC_QT5_ENABLE_QTQUICK2
            QQuickWindow::setDefaultAlphaBuffer(true);
#endif
#ifdef Qt5X11Extras_FOUND
            if (qApp->platformName() == "xcb") {
                qtcX11InitXcb(QX11Info::connection(), QX11Info::appScreen());
            }
#endif
        }
```

#### AUTO 


```{c}
auto mi = qtcStyleCast<QStyleOptionMenuItem>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[&] (char *dir) {
            if (isDir(dir)) {
                res.emplace_front(dir);
            } else {
                free(dir);
            }
        }
```

#### AUTO 


```{c}
auto titleBar = styleOptCast<QStyleOptionTitleBar>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        std::forward_list<std::string> res;
        auto add_dir = [&] (const char *dir, bool needfree=true) {
            if (isDir(dir)) {
                res.emplace_front(dir);
            }
            if (needfree) {
                free(const_cast<char*>(dir));
            }
        };
        for (auto &kde_home: getKDE4Home()) {
            add_dir(Str::cat(kde_home.get(), "share/apps/QtCurve/"));
        }
        if (auto xdg_data_dirs = getenv("XDG_DATA_DIRS")) {
            while (true) {
                auto delim = strchr(xdg_data_dirs, ':');
                if (delim) {
                    auto origin = xdg_data_dirs;
                    xdg_data_dirs = delim + 1;
                    if (origin[0] != '/')
                        continue;
                    std::string dir(origin, delim - origin);
                    dir += "/QtCurve/";
                    if (isDir(dir.c_str())) {
                        res.push_front(std::move(dir));
                    }
                } else if (xdg_data_dirs[0] == '/') {
                    std::string dir(xdg_data_dirs);
                    dir += "/QtCurve/";
                    if (isDir(dir.c_str()))
                        res.push_front(std::move(dir));
                    break;
                } else {
                    break;
                }
            }
        } else {
            add_dir("/usr/local/share/QtCurve/", false);
            add_dir("/usr/share/QtCurve/", false);
        }
        auto xdg_home = Str::cat(getXDGDataHome(), "QtCurve/");
        makePath(xdg_home, 0700);
        add_dir(xdg_home);
        return res;
    }
```

#### AUTO 


```{c}
auto _tab = qtcStyleCast<QStyleOptionTab>(option)
```

#### AUTO 


```{c}
auto v2= styleOptCast<QStyleOptionDockWidgetV2>(option);
```

#### AUTO 


```{c}
auto v2 = qtcStyleCast<QStyleOptionDockWidgetV2>(dwOpt);
```

#### AUTO 


```{c}
auto f = styleOptCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto fo = qtcStyleCast<QStyleOptionFrame>(option);
```

#### AUTO 


```{c}
auto scrollBar = styleOptCast<QStyleOptionSlider>(option)
```

#### AUTO 


```{c}
auto bar2 =
                    styleOptCast<QStyleOptionProgressBarV2>(option)
```

#### AUTO 


```{c}
auto tb = qtcStyleCast<QStyleOptionTitleBar>(option)
```

#### AUTO 


```{c}
auto &local = (other.colorGroup() == QPalette::Active ?
                   m_activeShadowConfig : m_inactiveShadowConfig);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file: dir.entryList()) {
                            if (file.endsWith(EXTENSION)) {
                                qtcFile = dir.path() + "/" + file;
                            }
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QStatusBar *statusBar: const_(sb)) {
                if (itsSaveStatusBarStatus) {
                    statusBar->installEventFilter(this);
                }
                if (itsSaveStatusBarStatus && qtcStatusBarHidden(appName)) {
                    statusBar->setHidden(true);
                }
            }
```

#### AUTO 


```{c}
auto &file = opts.bgndImage.pixmap.file;
```

#### AUTO 


```{c}
auto &back = tics_list->back();
```

#### AUTO 


```{c}
auto v4Opt = styleOptCast<QStyleOptionViewItemV4>(option);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {lighterPopupMenuBgnd, tabBgnd, menuDelay, menuCloseDelay, crHighlight,
                expanderHighlight, colorSelTab, highlightFactor, bgndOpacity,
                dlgOpacity, menuBgndOpacity, splitterHighlight, gbFactor, dropShadowSize}) {
        connect(qtcSlot(w, valueChanged, (int)), qtcSlot(this, updateChanged));
    }
```

#### AUTO 


```{c}
auto opt = qtcStyleCast<QStyleOptionRubberBand>(option);
```

#### AUTO 


```{c}
auto preview = qtcStyleCast<PreviewOption>(option)
```

#### AUTO 


```{c}
auto mask = styleOptCast<QStyleHintReturnMask>(returnData)
```

#### AUTO 


```{c}
auto &file = opts.bgndPixmap.file;
```

#### AUTO 


```{c}
auto &rect = tab->rects[i];
```

#### AUTO 


```{c}
auto comboBox = styleOptCast<QStyleOptionComboBox>(option)
```

#### AUTO 


```{c}
auto margins = widget->contentsMargins();
```

#### AUTO 


```{c}
auto &pixbuf = pixbufMap[key];
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget: const_(m_updated)) {
                widget->update();
            }
```

#### AUTO 


```{c}
auto page = new QFrame(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &_rect: region.rects()) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 6, 0)
            const auto &rect = QHighDpi::toNativePixels(_rect, widget->window()->windowHandle());
#else
            const auto &rect = _rect;
#endif
            data << rect.x() << rect.y() << rect.width() << rect.height();
        }
```

#### AUTO 


```{c}
auto tab = qtcStyleCast<QStyleOptionTab>(option)
```

#### AUTO 


```{c}
auto opt = styleOptCast<QStyleOptionViewItem>(option);
```

#### AUTO 


```{c}
static inline auto
qtcSum(First &&first, Rest &&...rest...)
    -> decltype(first + qtcSum(std::forward<Rest>(rest)...))
{
    return first + qtcSum(std::forward<Rest>(rest)...);
}
```

#### LAMBDA EXPRESSION 


```{c}
[&] {
            std::unique_ptr<KZip> zip(compressed ? new KZip(file) : nullptr);
            if (zip && !zip->open(QIODevice::WriteOnly))
                return false;
            std::unique_ptr<KTemporaryFile> temp(
                compressed ? new KTemporaryFile() : nullptr);
            if (temp && !temp->open())
                return false;
            KConfig cfg(compressed ? temp->fileName() : file,
                        KConfig::NoGlobals);
            Options opts;
            QString bgndImageName;
            QString menuBgndImageName;
            QString bgndPixmapName;
            QString menuBgndPixmapName;
            QString themeName(getFileName(file).remove(EXTENSION)
                              .replace(' ', '_'));
            setOptions(opts);
            if (compressed) {
                if (opts.bgndImage.type == IMG_FILE) {
                    bgndImageName = getThemeFile(opts.bgndImage.pixmap.file);
                    opts.bgndImage.pixmap.file =
                        themeName + BGND_FILE IMAGE_FILE +
                        getExt(bgndImageName);
                }
                if (opts.menuBgndImage.type == IMG_FILE) {
                    menuBgndImageName =
                        getThemeFile(opts.menuBgndImage.pixmap.file);
                    opts.menuBgndImage.pixmap.file =
                        themeName + BGND_FILE MENU_FILE IMAGE_FILE +
                        getExt(menuBgndImageName);
                }
                if (opts.bgndAppearance == APPEARANCE_FILE) {
                    bgndPixmapName = getThemeFile(opts.bgndPixmap.file);
                    opts.bgndPixmap.file =
                        themeName + BGND_FILE + getExt(bgndPixmapName);
                }
                if (opts.menuBgndAppearance == APPEARANCE_FILE) {
                    menuBgndPixmapName = getThemeFile(opts.menuBgndPixmap.file);
                    opts.menuBgndPixmap.file =
                        themeName + BGND_FILE MENU_FILE +
                        getExt(menuBgndPixmapName);
                }
            }
            if (!qtcWriteConfig(&cfg, opts, presets[defaultText].opts, true))
                return false;
            kwin->save(&cfg);
            if (compressed) {
                zip->addLocalFile(temp->fileName(), themeName + EXTENSION);
                if (!bgndImageName.isEmpty())
                    zip->addLocalFile(bgndImageName,
                                      opts.bgndImage.pixmap.file);
                if (!menuBgndImageName.isEmpty())
                    zip->addLocalFile(menuBgndImageName,
                                      opts.menuBgndImage.pixmap.file);
                if (!bgndPixmapName.isEmpty())
                    zip->addLocalFile(bgndPixmapName, opts.bgndPixmap.file);
                if (!menuBgndPixmapName.isEmpty())
                    zip->addLocalFile(menuBgndPixmapName,
                                      opts.menuBgndPixmap.file);
                zip->close();
            }
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        size_t len = 0;
        const char *const args[] = {"kde4-config", "--install", "icon",
                                    nullptr};
        char *res = qtcPopenStdout("kde4-config", args, 300, &len);
        if (res && res[strspn(res, " \t\b\n\f\v")]) {
            if (res[len - 1]=='\n') {
                res[len - 1]='\0';
            }
            return res;
        }
        return strdup(QTC_KDE4_ICONS_PREFIX &&
                      strlen(QTC_KDE4_ICONS_PREFIX) > 2 ?
                      QTC_KDE4_ICONS_PREFIX : DEFAULT_ICON_PREFIX);
    }
```

#### AUTO 


```{c}
auto bgnd = qtcStyleCast<BgndOption>(option)
```

#### AUTO 


```{c}
auto btn = qtcStyleCast<QStyleOptionButton>(option)
```

#### AUTO 


```{c}
auto v2= qtcStyleCast<QStyleOptionDockWidgetV2>(option);
```

#### RANGE FOR STATEMENT 


```{c}
for (const WidgetPointer &widget: const_(_pendingWidgets)) {
            if (widget) {
                update(widget.data());
            }
        }
```

#### AUTO 


```{c}
auto dwOpt = qtcStyleCast<QStyleOptionDockWidget>(option)
```

#### AUTO 


```{c}
auto layout = new QGridLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ExceptionId &id: _whiteList) {
        if (!id.appName().isEmpty() && id.appName() != appName)
            continue;
        if (widget->inherits(id.className().toLatin1())) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto it = widget_map[map].find(hash);
```

#### AUTO 


```{c}
auto &menuBgndFile = opts.menuBgndPixmap.file;
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        const char *env_home = getenv("XDG_CONFIG_HOME");
        if (env_home && *env_home == '/') {
            return Str::cat(env_home, "/");
        } else {
            return Str::cat(getHome(), ".config/");
        }
    }
```

#### AUTO 


```{c}
auto round = getRound(detail, widget, rev);
```

#### AUTO 


```{c}
auto &back = tics_list.back();
```

#### AUTO 


```{c}
auto bar = styleOptCast<QStyleOptionProgressBar>(option)
```

#### AUTO 


```{c}
auto f = qtcStyleCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto scrollbar = qtcStyleCast<QStyleOptionSlider>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (int hint: const_(itsMdiButtons[0])) {
                if (hint == SC_TitleBarCloseButton ||
                    hint == WINDOWTITLE_SPACER ||
                    tb->titleBarFlags & toHint(hint)) {
                    totalLeft += (hint == WINDOWTITLE_SPACER ?
                                  controlSize / 2 : controlSize);
                    if (hint == sc) {
                        found = true;
                    } else if (!found) {
                        pos += (hint == WINDOWTITLE_SPACER ?
                                controlSize / 2 : controlSize);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: std::initializer_list<QAbstractButton*>{
            animatedProgress, highlightTab, fillSlider, stripedSbar,
                roundMbTopOnly, statusbarHiding_keyboard, statusbarHiding_kwin,
                darkerBorders, comboSplitter, unifyCombo, vArrows, xCheck,
                crButton, roundAllTabs, borderTab, borderInactiveTab,
                invertBotTab, doubleGtkComboArrow, stdSidebarButtons,
                toolbarTabs, centerTabText, borderMenuitems, popupBorder,
                windowBorder_fill, windowBorder_separator, lvLines, lvButton,
                drawStatusBarFrames, menubarMouseOver,
                shadeMenubarOnlyWhenActive, thin_menuitems, thin_buttons,
                thin_frames, hideShortcutUnderline, gtkScrollViews,
                highlightScrollViews, etchEntry, flatSbarButtons,
                colorSliderMouseOver, windowBorder_addLightBorder,
                dwtBtnAsPerTitleBar, dwtColAsPerTitleBar,
                dwtIconColAsPerTitleBar, dwtFontAsPerTitleBar,
                dwtTextAsPerTitleBar, dwtEffectAsPerTitleBar, dwtRoundTopOnly,
                smallRadio, gtkComboMenus, mapKdeIcons, colorMenubarMouseOver,
                useHighlightForMenu, gbLabel_bold, gbLabel_centred, fadeLines,
                menuIcons, onlyTicksInMenu, buttonStyleMenuSections, stdBtnSizes, forceAlternateLvCols, boldProgress,
                coloredTbarMo, borderSelection, squareEntry, squareLvSelection,
                squareScrollViews, squareFrame, squareTabFrame, squareSlider,
                squareScrollbarSlider, squareWindows, squareTooltips,
                squarePopupMenus, titlebarButtons_button,
                titlebarButtons_customIcon, titlebarButtons_noFrame,
                titlebarButtons_round, titlebarButtons_hoverFrame,
                titlebarButtons_hoverSymbol, titlebarButtons_hoverSymbolFull,
                titlebarButtons_sunkenBackground, titlebarButtons_arrowMinMax,
                titlebarButtons_colorOnMouseOver,
                titlebarButtons_colorSymbolsOnly, titlebarButtons_colorInactive,
                titlebarButtons_hideOnInactiveWindow}) {
        connect(qtcSlot(w, toggled), qtcSlot(this, updateChanged));
    }
```

#### AUTO 


```{c}
auto toolbutton =
                qtcStyleCast<QStyleOptionToolButton>(option)
```

#### AUTO 


```{c}
auto round = (opts.square & SQUARE_FRAME ?
                              ROUNDED_NONE : ROUNDED_ALL);
```

#### AUTO 


```{c}
auto reply = qtcX11Call(get_property, 0, wId,
                            qtc_x11_atoms[QTC_X11_ATOM_QTC_BGND],
                            XCB_ATOM_CARDINAL, 0, 1);
```

#### AUTO 


```{c}
auto menuItem = styleOptCast<QStyleOptionMenuItem>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        const char *env_home = getenv("HOME");
        if (qtcLikely(env_home && *env_home == '/')) {
            return Str::cat(env_home, "/");
        } else {
            struct passwd *pw = getpwuid(getuid());
            if (qtcLikely(pw && pw->pw_dir && *pw->pw_dir == '/')) {
                return Str::cat(pw->pw_dir, "/");
            }
        }
        return strdup("/tmp/");
    }
```

#### AUTO 


```{c}
auto spinBox = qtcStyleCast<QStyleOptionSpinBox>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        const char *env_home = getenv("QTCURVE_CONFIG_DIR");
        char *res = ((env_home && *env_home == '/') ? Str::cat(env_home, "/") :
                     Str::cat(getXDGConfigHome(), "qtcurve/"));
        makePath(res, 0700);
        return res;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child: w->children()) {
        if (child->isWidgetType()) {
            if (qobject_cast<QToolBar*>(child))
                return static_cast<QToolBar*>(child);
            QToolBar *tb = getToolBarChild((QWidget*)child);
            if (tb) {
                return tb;
            }
        }
    }
```

#### AUTO 


```{c}
auto v2 = styleOptCast<QStyleOptionDockWidgetV2>(dwOpt);
```

#### AUTO 


```{c}
auto left = len % align
```

#### AUTO 


```{c}
auto twf = qtcStyleCast<QStyleOptionTabWidgetFrame>(option)
```

#### AUTO 


```{c}
auto *value = new Info(widget, stop_time);
```

#### RANGE FOR STATEMENT 


```{c}
for (QProgressBar *bar: const_(itsProgressBars)) {
            if ((opts.animatedProgress && 0 == itsAnimateStep % 2 &&
                 bar->value() != bar->minimum() &&
                 bar->value() != bar->maximum()) ||
                (0 == bar->minimum() && 0 == bar->maximum())) {
                bar->update();
            }
        }
```

#### AUTO 


```{c}
static inline auto
_forEachCaller(const char *str, size_t len, Func &func, Args&... args)
    -> typename std::enable_if<std::is_same<decltype(func(str, len, args...)),
                                            bool>::value, bool>::type
{
    return func(str, len, args...);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {noBgndGradientApps, noBgndOpacityApps,
                noMenuBgndOpacityApps, noBgndImageApps, useQtFileDialogApps,
                menubarApps, statusbarApps, noMenuStripeApps}) {
        connect(qtcSlot(w, editingFinished), qtcSlot(this, updateChanged));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget: const_(rem)) {
            m_sViewContainers.remove(widget);
        }
```

#### AUTO 


```{c}
auto round = (mb ? active_mb && opts.roundMbTopOnly ? ROUNDED_TOP :
                      ROUNDED_ALL : ROUNDED_ALL);
```

#### AUTO 


```{c}
auto dwOpt = styleOptCast<QStyleOptionDockWidget>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            QInternal::registerCallback(QInternal::EventNotifyCallback,
                                        qtcEventCallback);
            m_eventNotifyCallbackInstalled = true;
            if (QCoreApplication::instance()) {
                connect(QCoreApplication::instance(), &QCoreApplication::aboutToQuit, this, &StylePlugin::unregisterCallback);
            }
#ifdef QTC_QT5_ENABLE_QTQUICK2
            QQuickWindow::setDefaultAlphaBuffer(true);
#endif
#ifdef Qt5X11Extras_FOUND
            if (qApp->platformName() == "xcb") {
                qtcX11InitXcb(QX11Info::connection(), QX11Info::appScreen());
            }
#endif
        }
```

#### AUTO 


```{c}
auto xdg_home = Str::cat(getXDGDataHome(), "QtCurve/");
```

#### RANGE FOR STATEMENT 


```{c}
for (int hint: const_(m_mdiButtons[0])) {
                if (hint == SC_TitleBarCloseButton ||
                    hint == WINDOWTITLE_SPACER ||
                    tb->titleBarFlags & toHint(hint)) {
                    totalLeft += (hint == WINDOWTITLE_SPACER ?
                                  controlSize / 2 : controlSize);
                    if (hint == sc) {
                        found = true;
                    } else if (!found) {
                        pos += (hint == WINDOWTITLE_SPACER ?
                                controlSize / 2 : controlSize);
                    }
                }
            }
```

#### AUTO 


```{c}
auto tb = qtcStyleCast<QStyleOptionToolBox>(option)
```

#### AUTO 


```{c}
auto lineEdit = qtcStyleCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto tbOpt = styleOptCast<QStyleOptionToolButton>(option)
```

#### AUTO 


```{c}
auto menuItem = qtcStyleCast<QStyleOptionMenuItem>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *child: viewport->findChildren<QWidget*>()) {
        if (child->parent() == viewport &&
            child->backgroundRole() == QPalette::Window) {
            child->setAutoFillBackground(false);
        }
    }
```

#### AUTO 


```{c}
auto delim = strchr(xdg_data_dirs, ':');
```

#### AUTO 


```{c}
auto view = qobject_cast<const QAbstractItemView*>(widget);
```

#### AUTO 


```{c}
auto preview = styleOptCast<PreviewOption>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget: QApplication::topLevelWidgets()) {
        widget->update();
    }
```

#### AUTO 


```{c}
auto mask =
                        qtcStyleCast<QStyleHintReturnMask>(returnData)
```

#### AUTO 


```{c}
auto mbi = styleOptCast<QStyleOptionMenuItem>(option)
```

#### AUTO 


```{c}
auto &kde_home
```

#### AUTO 


```{c}
auto add_dir = [&] (char *dir) {
            if (isDir(dir)) {
                res.emplace_front(dir);
            } else {
                free(dir);
            }
        };
```

#### AUTO 


```{c}
auto btn = styleOptCast<QStyleOptionButton>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *child: w->children()) {
        if (child->isWidgetType()) {
            setStyleRecursive((QWidget*)child, s, minSize);
        }
    }
```

#### AUTO 


```{c}
auto page = new QWidget(this);
```

#### AUTO 


```{c}
auto tb = qtcStyleCast<QStyleOptionToolBox>(option);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w: {menuStripeAppearance, bgndGrad, menuBgndGrad,
                toolbarBorders, handles, appearance, menubarAppearance,
                toolbarAppearance, lvAppearance, sliderAppearance,
                tabAppearance, toolbarSeparators, splitters, sliderStyle,
                glowProgress, crSize, progressAppearance,
                progressGrooveAppearance, grooveAppearance, sunkenAppearance,
                progressGrooveColor, menuitemAppearance, titlebarAppearance,
                inactiveTitlebarAppearance, titlebarButtonAppearance,
                selectionAppearance, scrollbarType, windowDrag,
                sbarBgndAppearance, sliderFill, dwtAppearance,
                tooltipAppearance, gbLabel_textPos, titlebarAlignment,
                titlebarEffect, titlebarIcon, tbarBtns, tbarBtnAppearance,
                tbarBtnEffect}) {
        connect(qtcSlot(w, currentIndexChanged, (int)),
                qtcSlot(this, updateChanged));
    }
```

#### AUTO 


```{c}
auto dwopt = qtcStyleCast<QStyleOptionDockWidget>(option);
```

#### AUTO 


```{c}
auto round = (((!isTab && opts.square & SQUARE_FRAME) ||
                       (isTab && opts.square & SQUARE_TAB_FRAME)) ?
                      ROUNDED_NONE : ROUNDED_ALL);
```

#### AUTO 


```{c}
auto slider = qtcStyleCast<QStyleOptionSlider>(option)
```

#### AUTO 


```{c}
auto mask =
                    styleOptCast<QStyleHintReturnMask>(returnData)
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file: fileNames) {
                if (!files_map.contains(file)) {
                    auto abspath = d.absoluteFilePath(file);
                    files_map.insert(file, abspath);
                    files.append(file);
                }
            }
```

#### AUTO 


```{c}
auto ind_state = (state == GTK_STATE_INSENSITIVE ?
                          state : GTK_STATE_NORMAL);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *childObject: widget->children()) {
        QWidget *child = qtcToWidget(childObject);
        if (!(child && child->isVisible()))
            continue;
        if (isOpaque(child)) {
            const QPoint offset(child->mapTo(parent, QPoint(0, 0)));
            if (child->mask().isEmpty()) {
                region -= child->rect().translated(offset);
            } else {
                region -= child->mask().translated(offset);
            }
        } else {
            trimBlurRegion(parent, child, region);
        }
    }
```

#### AUTO 


```{c}
auto new_state = state == GTK_STATE_PRELIGHT ? GTK_STATE_NORMAL : state;
```

#### AUTO 


```{c}
auto dwopt = styleOptCast<QStyleOptionDockWidget>(option);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const char *str, size_t len) {
            if (nele <= offset) {
                nele += 8;
                buff = (char*)realloc(buff, nele * size);
            }
            if (loader((char*)buff + offset * size, str, len, data)) {
                offset++;
                if (max_len && offset >= max_len) {
                    return false;
                }
            }
            return true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] { KGlobal::ref(); }
```

#### AUTO 


```{c}
auto _frame = qtcStyleCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto &menuBgndFile =
                                    opts.menuBgndImage.pixmap.file;
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok |
                                          QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto cmb = styleOptCast<QStyleOptionComboBox>(option)
```

#### AUTO 


```{c}
auto add_dir = [&] (const char *dir, bool needfree=true) {
            if (isDir(dir)) {
                res.emplace_front(dir);
            }
            if (needfree) {
                free(const_cast<char*>(dir));
            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                            // disconnect from the session DBus. We're no longer interested in the
                            // information it might send when the app we're serving is shutting down.
                            disconnectDBus();
                            // Stop listening to select signals. We shouldn't stop emitting signals
                            // (like QObject::destroyed) but we can reduce the likelihood that pending
                            // signals will be sent to us post-mortem.
#ifdef QTC_QT5_ENABLE_KDE
                            disconnect(KWindowSystem::self(), &KWindowSystem::compositingChanged,
                                       this, &Style::compositingToggled);
#endif
                        }
```

#### AUTO 


```{c}
static inline auto
_forEachCaller(const char *str, size_t, Func &func, Args&... args)
    -> typename std::enable_if<std::is_same<decltype(func(str, args...)),
                                            bool>::value, bool>::type
{
    return func(str, args...);
}
```

#### AUTO 


```{c}
auto lower_it = std::lower_bound(
            this->begin(), this->end(), key, [] (const pair_type &a,
                                                 const char *key) {
                return strcmp_func(a.first, key) < 0;
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const ExceptionId &id: const_(_blackList)) {
        if (!id.appName().isEmpty() && id.appName() != appName)
            continue;
        if (id.className() == "*" && !id.appName().isEmpty()) {
            // if application name matches and all classes are selected
            // disable the grabbing entirely
            setEnabled(false);
            return true;
        }
        if (widget->inherits(id.className().toLatin1())) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto header = styleOptCast<QStyleOptionHeader>(option)
```

#### AUTO 


```{c}
auto tab = styleOptCast<QStyleOptionTab>(option)
```

#### AUTO 


```{c}
auto filename = QtCurve::getConfFile(std::string(CONFIG_FILE));
```

#### AUTO 


```{c}
auto ho = styleOptCast<QStyleOptionHeader>(option)
```

#### AUTO 


```{c}
auto scrollBar = qtcStyleCast<QStyleOptionSlider>(option)
```

#### AUTO 


```{c}
auto s = f.pixelSize() > 0
```

#### AUTO 


```{c}
auto spinBox = styleOptCast<QStyleOptionSpinBox>(option)
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const char *dir, bool needfree=true) {
            if (isDir(dir)) {
                res.emplace_front(dir);
            }
            if (needfree) {
                free(const_cast<char*>(dir));
            }
        }
```

#### AUTO 


```{c}
auto mimeType = mime_db.mimeTypeForFile(file, QMimeDatabase::MatchContent);
```

#### LAMBDA EXPRESSION 


```{c}
[] {
        void *hdl = dlopen(nullptr, RTLD_NOW);
        // I do not use the procfs here since any system that has procfs
        // (Linux) should support one of these variables/functions.
        if (!hdl) {
            return strdup("");
        }
        void *progname_p = nullptr;
        const char *name = nullptr;
        if ((progname_p = dlsym(hdl, "program_invocation_short_name")) ||
            (progname_p = dlsym(hdl, "program_invocation_name")) ||
            (progname_p = dlsym(hdl, "__progname"))) {
            name = *(char *const*)progname_p;
        } else if ((progname_p = dlsym(hdl, "getprogname"))) {
            name = ((const char *(*)())progname_p)();
        }
        if (!name) {
            return strdup("");
        }
        const char *sub_name;
        if ((sub_name = strrchr(name, '/')) && sub_name[1]) {
            return strdup(sub_name + 1);
        }
        return strdup(name);
    }
```

#### AUTO 


```{c}
auto titleBar = qtcStyleCast<QStyleOptionTitleBar>(option)
```

#### AUTO 


```{c}
auto frame = styleOptCast<QStyleOptionGroupBox>(option)
```

#### AUTO 


```{c}
auto tb = styleOptCast<QStyleOptionToolButton>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *child: viewport->findChildren<QWidget*>()) {
        if (child->parent() == viewport &&
            QPalette::Window == child->backgroundRole()) {
            child->setAutoFillBackground(false);
        }
    }
```

#### AUTO 


```{c}
auto button = styleOptCast<QStyleOptionButton>(option)
```

#### AUTO 


```{c}
auto frame = qtcStyleCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto ho = qtcStyleCast<QStyleOptionHeader>(option)
```

#### AUTO 


```{c}
auto tbb = styleOptCast<QStyleOptionTabBarBase>(option)
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget: QApplication::topLevelWidgets()) {
        if (qobject_cast<QMainWindow*>(widget) && qtcGetWid(widget) == xid) {
            return static_cast<QMainWindow*>(widget);
        }
    }
```

#### AUTO 


```{c}
auto &file = opts.menuBgndPixmap.file;
```

#### AUTO 


```{c}
auto lineEdit = styleOptCast<QStyleOptionFrame>(option)
```

#### AUTO 


```{c}
auto edgePad = m_config.edgePad();
```

#### AUTO 


```{c}
auto bar = qtcStyleCast<QStyleOptionProgressBarV2>(option)
```

#### AUTO 


```{c}
auto slider = styleOptCast<QStyleOptionSlider>(option)
```

#### AUTO 


```{c}
auto len = strlen(buff.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget: const_(itsUpdated)) {
                widget->update();
            }
```

#### AUTO 


```{c}
const auto &rects = region;
```

#### AUTO 


```{c}
auto button = qtcStyleCast<QStyleOptionButton>(option)
```

#### AUTO 


```{c}
auto spinbox = qtcStyleCast<QStyleOptionSpinBox>(option)
```

