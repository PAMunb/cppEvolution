#### RANGE FOR STATEMENT 


```{c}
for (const QRect &rect : region) {
    p.fillRect(rect, palette().dark());
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& mimeType : supported) {
    mimeTypes.append(QString::fromLatin1(mimeType));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *sibling : siblings) {
    if (sibling != window() && (sibling->windowType() & Qt::Window) && sibling->isVisible()) {
      QRect rect = sibling->frameGeometry();
      rect.translate(-selRect.topLeft());
      region -= rect;
    }
  }
```

