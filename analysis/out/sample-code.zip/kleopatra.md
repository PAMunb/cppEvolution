#### AUTO 


```{c}
auto cmd = new NewCertificateCommand(nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            advancedSettingsDlg->open();
        }
```

#### AUTO 


```{c}
static auto get_receive_keys_job(GpgME::Protocol protocol)
{
    Q_ASSERT(protocol != UnknownProtocol);

#ifdef QGPGME_SUPPORTS_RECEIVING_KEYS_BY_KEY_ID
    std::unique_ptr<ReceiveKeysJob> job{};
    if (const auto backend = (protocol == GpgME::OpenPGP ? QGpgME::openpgp() : QGpgME::smime())) {
        job.reset(backend->receiveKeysJob());
    }
    return job;
#else
    return std::unique_ptr<Job>{};
#endif
}
```

#### AUTO 


```{c}
const auto &pair
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) {
                                    return QString::compare(lhs, rhs, fs_cs) < 0;
                                  }
```

#### AUTO 


```{c}
const auto dvResult = dynamic_cast<const DecryptVerifyResult *>(m_result.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mailbox &mb : mbs) {
        senders.push_back(Sender(mb));
    }
```

#### AUTO 


```{c}
auto it = std::begin(names);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout{qq};
```

#### AUTO 


```{c}
auto previousResultWidget = qobject_cast<ResultItemWidget *>(scrollAreaLayout->itemAt(insertIndex - 1)->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto size: sizes) {
            mKeySizeCombo->addItem(QString::number(size));
        }
```

#### AUTO 


```{c}
const auto subkeys = KeyCache::instance()->findSubkeysByKeyID(vec);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sig: result.signatures()) {
        // Update key information
        sig.key(true, true);
    }
```

#### AUTO 


```{c}
auto okButton = ui.buttonBox->button(QDialogButtonBox::Ok);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->schedule(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : lines)
            if (line.startsWith("sysconfdir:"))     //krazy:exclude=strings
                try {
                    return QDir(QFile::decodeName(hexdecode(line.mid(strlen("sysconfdir:"))))).exists(QStringLiteral("gpgconf.conf"));
                } catch (...) {
                    return false;
                }
```

#### AUTO 


```{c}
auto outputGrp = new QGroupBox(i18n("Output"));
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const CertificateSelectionLine &l) {
                       return l.key(proto);
                   }
```

#### AUTO 


```{c}
auto protocol = d->key.protocol() == GpgME::CMS ?
                                         QGpgME::smime() : QGpgME::openpgp();
```

#### AUTO 


```{c}
auto prevWidget = after ? after : mRecpLayout->itemAt(mRecpLayout->count() - 1)->widget();
```

#### AUTO 


```{c}
const auto secondFocusPolicy = second->focusPolicy();
```

#### AUTO 


```{c}
const auto name = QString::fromUtf8(key.userID(0).name());
```

#### AUTO 


```{c}
const auto card = SmartCard::ReaderStatus::instance()->getCard<Card>(serialNumber);
```

#### AUTO 


```{c}
const auto time = QDateTime::fromTime_t(mKey.creationTime());
```

#### AUTO 


```{c}
const auto groupKeys = std::accumulate(std::begin(groups), std::end(groups),
                                           KeyGroup::Keys{},
                                           [](auto allKeys, const auto &group) {
                                                const auto keys = group.keys();
                                                allKeys.insert(std::begin(keys), std::end(keys));
                                                return allKeys;
                                           });
```

#### AUTO 


```{c}
const auto status = KeyCache::instance()->group(group.id()).isNull() ?
                        ImportedGroup::Status::New :
                        ImportedGroup::Status::Updated;
```

#### AUTO 


```{c}
const auto pivCard = SmartCard::ReaderStatus::instance()->getCard<PIVCard>(serialNumber);
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyRef] () { showCertificateDetails(keyRef); }
```

#### AUTO 


```{c}
const auto auditLogLinkText =
        m_result->hasError() ? i18n("Diagnostics")
                             : i18nc("The Audit Log is a detailed error log from the gnupg backend",
                                     "Show Audit Log");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : std::as_const(files)) {
                const std::vector< std::shared_ptr<SignEncryptTask> > created =
                    createSignEncryptTasksForFileInfo(QFileInfo(file), ascii,
                            pgpRecipients,
                            pgpSigners,
                            cmsRecipients,
                            cmsSigners,
                            buildOutputNamesForDir(file, wizard->outputNames()),
                            wizard->encryptSymmetric());
                tasks.insert(tasks.end(), created.begin(), created.end());
            }
```

#### AUTO 


```{c}
auto conf = QGpgME::cryptoConfig();
```

#### AUTO 


```{c}
auto fname = FileDialog::getSaveFileNameEx(parentWidgetOrView(),
                          i18nc("1 is protocol", "Export %1 Certificates", Formatting::displayName(protocol)),
                          QStringLiteral("imp"),
                          proposedFileName,
                          protocol == GpgME::OpenPGP
                          ? i18n("OpenPGP Certificates") + QLatin1String(" (*.asc *.gpg *.pgp)")
                          : i18n("S/MIME Certificates")  + QLatin1String(" (*.pem *.der)"));
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Sender &sender) { return count_signing_certificates(proto, sender) == 1; }
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::ChangeExpiryCommand(key);
```

#### AUTO 


```{c}
const auto comp = conf->component(engine_name(eng));
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Change PIN"));
```

#### AUTO 


```{c}
auto parts = text.split(" ");
```

#### AUTO 


```{c}
auto type = data.type();
```

#### AUTO 


```{c}
const auto info = gpgagent_statuslines(gpg_agent, "SCD LEARN --keypairinfo", err);
```

#### AUTO 


```{c}
const auto &existingKey
```

#### LAMBDA EXPRESSION 


```{c}
[this, gpgconf, profile] () {
        mApplyBtn->setEnabled(true);
        if (gpgconf->exitStatus() != QProcess::NormalExit) {
            KMessageBox::error(this, QStringLiteral("<pre>%1</pre>").arg(QString::fromLocal8Bit(gpgconf->readAll())));
            delete gpgconf;
            return;
        }
        delete gpgconf;
        KMessageBox::information(this,
                         i18nc("%1 is the name of the profile",
                               "The configuration profile \"%1\" was applied.", profile),
                         i18n("GnuPG Profile - Kleopatra"));
        auto config = QGpgME::cryptoConfig();
        if (config) {
            config->clear();
        }
        KeyFilterManager::instance()->reload();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, uid]() { revokeUID(uid); }
```

#### AUTO 


```{c}
auto nkCard = new NetKeyCard();
```

#### AUTO 


```{c}
auto w = getFirstEnabledFocusWidget(cardWidget)
```

#### AUTO 


```{c}
const auto coll = q->actionCollection();
```

#### AUTO 


```{c}
const auto formatted = lastName + QStringLiteral("<<") + parts.join("<");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { authenticationCanceled(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateKey(); }
```

#### AUTO 


```{c}
const auto slot = getOpenPGPCardSlotForKey(mSubkey, parentWidgetOrView());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fname: m_passedFiles) {
        kleo_assert(!fname.isEmpty());

        const unsigned int classification = classify(fname);
        const Protocol proto = findProtocol(classification);

        if (mayBeOpaqueSignature(classification) || mayBeCipherText(classification) || mayBeDetachedSignature(classification)) {

            DecryptVerifyOperationWidget *const op = m_wizard->operationWidget(counter++);
            kleo_assert(op != nullptr);

            op->setArchiveDefinitions(archiveDefinitions);

            const QString signedDataFileName = findSignedData(fname);

            // this breaks opaque signatures whose source files still
            // happen to exist in the same directory. Until we have
            // content-based classification, this is the most unlikely
            // case, so that's the case we break. ### FIXME remove when content-classify is done
            if (mayBeDetachedSignature(classification) && !signedDataFileName.isEmpty()) {
                op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignature);
            }
            // ### end FIXME
            else if (mayBeOpaqueSignature(classification) || mayBeCipherText(classification)) {
                op->setMode(DecryptVerifyOperationWidget::DecryptVerifyOpaque, q->pick_archive_definition(proto, archiveDefinitions, fname));
            } else {
                op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignature);
            }

            op->setInputFileName(fname);
            op->setSignedDataFileName(signedDataFileName);

            m_filesAfterPreparation << fname;

        } else {

            // probably the signed data file was selected:
            const QStringList signatures = findSignatures(fname);

            if (signatures.empty()) {
                // We are assuming this is a detached signature file, but
                // there were no signature files for it. Let's guess it's encrypted after all.
                // ### FIXME once we have a proper heuristic for this, this should move into
                // classify() and/or classifyContent()
                DecryptVerifyOperationWidget *const op = m_wizard->operationWidget(counter++);
                kleo_assert(op != nullptr);
                op->setArchiveDefinitions(archiveDefinitions);
                op->setMode(DecryptVerifyOperationWidget::DecryptVerifyOpaque, q->pick_archive_definition(proto, archiveDefinitions, fname));
                op->setInputFileName(fname);
                m_filesAfterPreparation << fname;
            } else {
                for (const auto &s: signatures) {
                    DecryptVerifyOperationWidget *op = m_wizard->operationWidget(counter++);
                    kleo_assert(op != nullptr);

                    op->setArchiveDefinitions(archiveDefinitions);
                    op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignedData);
                    op->setInputFileName(s);
                    op->setSignedDataFileName(fname);

                    m_filesAfterPreparation << fname;
                }

            }
        }
    }
```

#### AUTO 


```{c}
auto action = menu->addAction(QIcon::fromTheme(QStringLiteral("view-certificate-revoke")),
                                          i18n("Revoke Certification..."),
                                          q, [this, signature]() {
                auto cmd = new Kleo::Commands::RevokeCertificationCommand(signature);
                cmd->setParentWidget(q);
                certificationsTV->setEnabled(false);
                connect(cmd, &Kleo::Commands::RevokeCertificationCommand::finished,
                        q, [this]() {
                    certificationsTV->setEnabled(true);
                    // Trigger an update when done
                    q->setKey(key);
                });
                cmd->start();
            });
```

#### AUTO 


```{c}
auto overview = new HtmlLabel;
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox{i18n("X.509 Directory Services"), this};
```

#### AUTO 


```{c}
auto certSel = new CertificateLineEdit(mModel, this,
                                                           new EncryptCertificateFilter(mCurrentProto));
```

#### AUTO 


```{c}
auto buttonLayout = new QHBoxLayout(buttonWidget);
```

#### AUTO 


```{c}
const auto key = index.model()->data(index, KeyList::KeyRole).value<GpgME::Key>();
```

#### AUTO 


```{c}
const auto fpr = import.fingerprint()
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { doChangePin(OpenPGPCard::resetCodeKeyRef()); }
```

#### AUTO 


```{c}
const auto range = mCardInfo.equal_range(name);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { ui.userIDTable->setEnabled(true); }
```

#### AUTO 


```{c}
const auto addesses{additionalEMailAddresses()};
```

#### AUTO 


```{c}
const auto name = errorShown ? mAccessibleName + QLatin1String{", "} + invalidEntryText()
                                 : mAccessibleName;
```

#### AUTO 


```{c}
const auto cards = ReaderStatus::instance()->getCards();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            doChangePin(false);
        }
```

#### AUTO 


```{c}
const auto path = datadir.filePath(i18nc("The Gpg4win compendium is only available"
                                                 "at this point (24.7.2017) in german and english."
                                                 "Please check with Gpg4win before translating this filename.",
                                                 "gpg4win-compendium-en.pdf"));
```

#### AUTO 


```{c}
auto ci = std::shared_ptr<Card>(new Card());
```

#### AUTO 


```{c}
auto const cmd = new LookupCertificatesCommand(needle, nullptr);
```

#### AUTO 


```{c}
auto pgpBegin = keys.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotKeysMayHaveChanged(); }
```

#### AUTO 


```{c}
auto it = std::find_if(ads.cbegin(), ads.cend(), [&archiveCmd](const std::shared_ptr<ArchiveDefinition> &toCheck) {
        return toCheck->id() == archiveCmd;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotProcessReadyReadStandardError(); }
```

#### AUTO 


```{c}
auto listView = new QListView;
```

#### AUTO 


```{c}
const auto suitableKeys = getKeysSuitableForCSRCreation(netKeyCard.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit : qAsConst(mRecpWidgets)) {
        edit->setKeyFilter(encFilter);
    }
```

#### AUTO 


```{c}
const auto description = errorShown ? mErrorLabel->text() : QString{};
```

#### AUTO 


```{c}
const auto quickguide = new DocAction(QIcon::fromTheme(QStringLiteral("help-contextual")), i18n("Quickguide"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                "handout_sign_encrypt_gnupg_en.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### AUTO 


```{c}
static auto accumulateNewKeys(std::vector<std::string> &fingerprints, const std::vector<GpgME::Import> &imports)
{
    return std::accumulate(std::begin(imports), std::end(imports),
                           fingerprints,
                           [](auto fingerprints, const auto &import) {
                               if (import.status() == Import::NewKey) {
                                   fingerprints.push_back(import.fingerprint());
                               }
                               return fingerprints;
                           });
}
```

#### AUTO 


```{c}
const auto defaultExpirationInDays = settings.validityPeriodInDays();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto kind : icons.keys()) {
            auto requesterWithIcon = new FileNameRequesterWithIcon{
                kind == SignEncryptFilesWizard::Directory ? QDir::Dirs : QDir::Files, this};
            requesterWithIcon->setIcon(QIcon::fromTheme(icons[kind]));
            requesterWithIcon->setToolTip(toolTips[kind]);
            requesterWithIcon->setNameFilter(nameFilters[kind]);
            lay->addWidget(requesterWithIcon);

            connect(requesterWithIcon, &FileNameRequesterWithIcon::fileNameChanged, this,
                    [this, kind](const QString &newName) {
                        mOutNames[kind] = newName;
                    });

            mRequesters.insert(kind, requesterWithIcon);
        }
```

#### AUTO 


```{c}
auto reqLB = new QLabel(l->parentWidget());
```

#### AUTO 


```{c}
const auto values = QString::fromStdString(value).split(QLatin1Char(' '));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                q->accept();
            }
```

#### AUTO 


```{c}
const auto firstWithNullPin = std::find_if(cis.cbegin(), cis.cend(),
                                                   [](const std::shared_ptr<Card> &ci) { return ci->hasNullPin(); });
```

#### LAMBDA EXPRESSION 


```{c}
[](SignClipboardCommand*){}
```

#### AUTO 


```{c}
const auto mailText = mEdit->text();
```

#### LAMBDA EXPRESSION 


```{c}
[q, keyRef] () { Q_EMIT q->createCSRRequested(keyRef); }
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox{i18n("X.509 Directory Services"), q};
```

#### RANGE FOR STATEMENT 


```{c}
for (auto algorithm: algorithms) {
            mAlgorithmCombo->addItem(algorithm.second, QByteArray::fromStdString(algorithm.first));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Key &key) { m_flatModel->removeKey(key); }
```

#### AUTO 


```{c}
auto ei = new GpgME::GpgGenCardKeyInteractor(mSerial);
```

#### AUTO 


```{c}
const auto grip = values[0].toStdString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
                // Yep you can have one subkey associated with multiple
                // primary keys.
                toolTips << Formatting::toolTip(sub.parent(), Formatting::Validity |
                        Formatting::ExpiryDates |
                        Formatting::UserIDs |
                        Formatting::Fingerprint);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &server) { return server.toUrl(); }
```

#### AUTO 


```{c}
const auto color = KColorScheme(QPalette::Active, KColorScheme::View).foreground(
                Kleo::gnupgIsDeVsCompliant() ? KColorScheme::PositiveText : KColorScheme::NegativeText
            ).color();
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : std::as_const(d->uids))
        if (qstricmp(uid.parent().primaryFingerprint(), d->certificationTarget.primaryFingerprint()) != 0) {
            qCWarning(KLEOPATRA_LOG) << "User-ID <-> Key mismatch!";
            d->finished();
            return;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: mTarget.userIDs()) {
                GpgME::Error err;
                const char *c_remark = uid.remark(remarkKey, err);
                if (c_remark) {
                    const QString candidate = QString::fromUtf8(c_remark);
                    if (candidate != remark) {
                        qCDebug(KLEOPATRA_LOG) << "Different remarks on user IDs. Taking last.";
                        remark = candidate;
                        uidsWithRemark.clear();
                    }
                    uidsWithRemark.push_back(uid);
                }
            }
```

#### AUTO 


```{c}
const auto it = std::remove_if(encryptionCertificates.begin(), encryptionCertificates.end(),
                                   [](const Key &key) {
                                       return ! (key.protocol() == GpgME::CMS &&
                                                 !key.subkey(0).isNull() &&
                                                 key.subkey(0).canEncrypt() &&
                                                 key.subkey(0).isSecret());
                                   });
```

#### AUTO 


```{c}
auto result = spy.takeFirst().at(0).value<GpgME::VerificationResult>();
```

#### AUTO 


```{c}
const auto &actionData
```

#### LAMBDA EXPRESSION 


```{c}
[progress, proc] () {
            proc->kill();
            qCDebug(KLEOPATRA_LOG) << "Update force cancled. Output:"
                                   << QString::fromLocal8Bit(proc->readAllStandardOutput())
                                   << "stderr:"
                                   << QString::fromLocal8Bit(proc->readAllStandardError());
    }
```

#### AUTO 


```{c}
const auto usage = values[0];
```

#### AUTO 


```{c}
const auto color = KColorScheme(QPalette::Active, KColorScheme::View).foreground(
                Kleo::gnupgIsDeVsCompliant() ? KColorScheme::NormalText: KColorScheme::NegativeText
            ).color();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(KeyList::KeyRole).value<GpgME::Key>();
        if (key.isNull()) {
            return;
        }
        m_expandedKeys.removeAll(QString::fromLatin1(key.primaryFingerprint()));
        m_group.writeEntry("Expanded", m_expandedKeys);
    }
```

#### AUTO 


```{c}
const auto sizes = columnSizes();
```

#### LAMBDA EXPRESSION 


```{c}
[this, btn] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::ImportCertificateFromFileCommand();
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            }
```

#### AUTO 


```{c}
auto requesterWithIcon = new FileNameRequesterWithIcon{id == SignEncryptFilesWizard::Directory ? QDir::Dirs : QDir::Files, this};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : l) {
        message(s);
    }
```

#### AUTO 


```{c}
auto &key
```

#### LAMBDA EXPRESSION 


```{c}
[](long ts) {
        return ts == 0 ? i18n("never") : QDateTime::fromTime_t(ts).toString(Qt::SystemLocaleShortDate);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cd : checksumDefinitions) {
        if (!cd) {
            continue;
        }
        const QStringList &patterns = cd->patterns();
        result.reserve(result.size() + patterns.size());
        std::transform(patterns.cbegin(), patterns.cend(), std::back_inserter(result), [](const QString &pattern) {
            return QRegularExpression(QRegularExpression::anchoredPattern(pattern), s_regex_cs);
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) {
                      return parseFileName(lhs, Q_NULLPTR) < parseFileName(rhs, Q_NULLPTR);
                  }
```

#### AUTO 


```{c}
auto clipboard = QGuiApplication::clipboard()
```

#### AUTO 


```{c}
auto l = new QVBoxLayout{mOpenPGPKeysSection};
```

#### AUTO 


```{c}
auto const le = qobject_cast<QLineEdit *>(w)
```

#### AUTO 


```{c}
const auto pgpCard = std::dynamic_pointer_cast<OpenPGPCard>(card);
```

#### AUTO 


```{c}
auto trimmed = str.trimmed();
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto out = reinterpret_cast <Output *>(io.get());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { changeExpiration(); }
```

#### AUTO 


```{c}
const auto &newCard
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QAbstractItemView *view) { slotCurrentViewChanged(view); }
```

#### AUTO 


```{c}
const auto *const iface = QAccessible::queryAccessibleInterface(object)
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint & p) {
        slotContextMenu(p);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : files) {
        const unsigned int classification = classify(fileName);

        if (classification & Class::AnyCertStoreType) {
            importFiles << fileName;
        } else if (classification & Class::AnyMessageType) {
            // For any message we decrypt / verify. This includes
            // the class CipherText
            decryptFiles << fileName;
        } else if (isChecksumFile(fileName)) {
            checksumFiles << fileName;
        } else {
            QFileInfo fi(fileName);
            if (fi.isReadable()) {
                encryptFiles << fileName;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            doChangePin(true);
        }
```

#### AUTO 


```{c}
auto pinButton = new QPushButton(i18n("Change PIN"));
```

#### AUTO 


```{c}
auto hl = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto cbp = (proto == GpgME::OpenPGP ? QGpgME::openpgp() : QGpgME::smime())
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (pair.first == "KEY-FPR" ||
            pair.first == "KEY-TIME") {
            // Key fpr and key time need to be distinguished, the number
            // of the key decides the usage.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[0];
            const auto fpr = values[1].toStdString();
            if (usage == QLatin1String("1")) {
                mMetaInfo.insert(std::string("SIG") + pair.first, fpr);
            } else if (usage == QLatin1String("2")) {
                mMetaInfo.insert(std::string("ENC") + pair.first, fpr);
            } else if (usage == QLatin1String("3")) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, fpr);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else if (pair.first == "KEYPAIRINFO") {
            // Fun, same as above but the other way around.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[1];
            const auto grip = values[0].toStdString();
            if (usage == QLatin1String("OPENPGP.1")) {
                mMetaInfo.insert(std::string("SIG") + pair.first, grip);
            } else if (usage == QLatin1String("OPENPGP.2")) {
                mMetaInfo.insert(std::string("ENC") + pair.first, grip);
            } else if (usage == QLatin1String("OPENPGP.3")) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, grip);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### AUTO 


```{c}
const auto actions = contextMenuPage == current ? currentPageActions : otherPageActions;
```

#### AUTO 


```{c}
auto cmd = new Commands::DetailsCommand(key, view(), controller());
```

#### AUTO 


```{c}
auto btnLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto const legacyEntry = configEntry(s_pgpservice_legacy_componentName, s_pgpservice_legacy_entryName,
                                              CryptoConfigEntry::ArgType_String, SingleValue, DoNotShowError);
```

#### AUTO 


```{c}
auto algoString = (split.size() == 2) ? split[1] : split[0];
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.canReallySign(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, task] (const std::shared_ptr<const Kleo::Crypto::Task::Result> &result) {
                qCDebug(KLEOPATRA_LOG) << "Decrypt / Verify done. Err:" << result->errorCode();
                task->deleteLater();
                cryptDone(result);
            }
```

#### AUTO 


```{c}
const auto query = certificationsModel.data(idx.sibling(idx.row(), 0)).toString();
```

#### AUTO 


```{c}
const auto positionalArguments = parser.positionalArguments();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { copyFingerprintToClipboard(); }
```

#### AUTO 


```{c}
auto cmd = new DetailsCommand(klm->key(idx), nullptr);
```

#### AUTO 


```{c}
const auto allIds = std::accumulate(std::cbegin(results), std::cend(results),
                                        std::set<QString>{},
                                        [](auto allIds, const auto &r) {
                                            allIds.insert(r.id);
                                            return allIds;
                                        });
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotCommandFinished(); }
```

#### AUTO 


```{c}
auto it = d->parameters.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&dir](const QString &path) {
                               return dir.absoluteFilePath(path);
                           }
```

#### AUTO 


```{c}
const auto index = mChecksumDefinitionCB.widget()->findData(defaultChecksumDefinitionId);
```

#### LAMBDA EXPRESSION 


```{c}
[&service](int i) {
                         service.setExitValue(i);
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            protocol = GpgME::CMS;
            q->accept();
        }
```

#### AUTO 


```{c}
const auto result = KEmailAddress::splitAddress (var, name, addrspec, comment);
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &i : coll->tasks()) {    // create labels for all tags in collection
        Q_ASSERT(i);
        QLabel *l = d->labelForTag(i->tag());
        Q_ASSERT(l); (void)l;
    }
```

#### AUTO 


```{c}
auto cardInfoGrid = new QGridLayout;
```

#### AUTO 


```{c}
const auto encFilter = std::shared_ptr<KeyFilter>(new EncryptCertificateFilter(mCurrentProto));
```

#### AUTO 


```{c}
auto scrollAreaLayout = qobject_cast<QBoxLayout *>(scrollArea->widget()->layout());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT q->userIDChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotRecipientsResolved(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&s](const char *type) {
                                    return ::strcasecmp(s.c_str(), type) == 0;
                                }
```

#### AUTO 


```{c}
const auto man_gpg = new DocAction(QIcon::fromTheme(QStringLiteral("help-contextual")), i18n("GnuPG Manual"),
            QStringLiteral("gnupg.pdf"), QStringLiteral("../share/doc/gnupg"));
```

#### AUTO 


```{c}
auto cmd = Command::commandForQuery(fpr);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Mailbox &mbox) {
                       return mbox.prettyAddress();
                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &task : qAsConst(runnable)) {
            q->connectTask(task);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const KeyGroup &group) {
                if (!mGroup.isNull() && mGroup.source() == group.source() && mGroup.id() == group.id()) {
                    QSignalBlocker blocky(this);
                    mGroup = group;
                    setText(Formatting::summaryLine(mGroup));
                    setToolTip(Formatting::toolTip(mGroup, Formatting::ToolTipOption::AllOptions));
                    mLineAction->setIcon(Formatting::validityIcon(mGroup));
                    mLineAction->setToolTip(Formatting::validity(mGroup) +
                                            QLatin1String("<br/>") + i18n("Click for details."));
                }
            }
```

#### AUTO 


```{c}
const auto choice = KMessageBox::warningContinueCancel(d->parentWidget(), warningText,
            i18nc("@title:window", "Overwrite existing key"),
            KStandardGuiItem::cont(), KStandardGuiItem::cancel(), QString(), KMessageBox::Notify | KMessageBox::Dangerous);
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &k) { return k.protocol() == Protocol::OpenPGP; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawLine : qAsConst(trustListFileContents)) {

        const QString line = QString::fromLatin1(rawLine.data(), rawLine.size());
        if (!rx.exactMatch(line)) {
            qCDebug(KLEOPATRA_LOG) << "line \"" << rawLine.data() << "\" does not match";
            out.write(rawLine + '\n');
            continue;
        }
        const QString cap2 = rx.cap(2);
        if (cap2 != key && cap2 != keyColon) {
            qCDebug(KLEOPATRA_LOG) << qPrintable(key) << " != "
                                   << qPrintable(cap2) << " != "
                                   << qPrintable(keyColon);
            out.write(rawLine + '\n');
            continue;
        }
        found = true;
        const bool disabled = rx.cap(1) == QLatin1Char('!');
        const QByteArray flags = rx.cap(3).toLatin1();
        const QByteArray rests = rx.cap(4).toLatin1();
        if (trust == Key::Ultimate)
            if (!disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write(keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        else if (trust == Key::Never) {
            if (disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write('!' + keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        }
        // else: trust == Key::Unknown
        // -> don't write - ie.erase
    }
```

#### AUTO 


```{c}
const auto view = d->parentWidgetOrView();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sig: verifyResult.signatures()) {
        if (!(sig.summary() & GpgME::Signature::KeyMissing)) {
            continue;
        }

        auto btn = new QPushButton;
        QString suffix;
        const auto keyid = QLatin1String(sig.fingerprint());
        if (verifyResult.numSignatures() > 1) {
            suffix = QLatin1Char(' ') + keyid;
        }
        btn = new QPushButton(search ? i18nc("1 is optional keyid. No space is intended as it can be empty.",
                                       "Search%1", suffix)
                                     : i18nc("1 is optional keyid. No space is intended as it can be empty.",
                                       "Import%1", suffix));

        if (search) {
            btn->setIcon(QIcon::fromTheme(QStringLiteral("edit-find")));
            connect (btn, &QPushButton::clicked, q, [this, btn, keyid] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::Commands::LookupCertificatesCommand(keyid, nullptr);
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            });
        } else {
            btn->setIcon(QIcon::fromTheme(QStringLiteral("view-certificate-import")));
            connect (btn, &QPushButton::clicked, q, [this, btn] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::ImportCertificateFromFileCommand();
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            });
        }
        btn->setFixedSize(btn->sizeHint());
        lay->addWidget(btn);
    }
```

#### AUTO 


```{c}
const auto &key = index.data(Kleo::KeyListModelInterface::KeyRole).value<GpgME::Key>();
```

#### RANGE FOR STATEMENT 


```{c}
for (std::shared_ptr<AssuanCommandFactory> fac : std::as_const(factories))
#ifndef HAVE_ASSUAN2
        if (const gpg_error_t err = assuan_register_command(ctx.get(), fac->name(), fac->_handler()))
#else
        if (const gpg_error_t err = assuan_register_command(ctx.get(), fac->name(), fac->_handler(), ""))
#endif
            throw Exception(err, std::string("register \"") + fac->name() + "\" handler");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fpr: qAsConst(m_expandedKeys)) {
        const KeyListModelInterface *const km = keyListModel(*m_view);
        if (!km) {
            qCWarning(KLEOPATRA_LOG) << "invalid model";
            return;
        }
        const auto key = KeyCache::instance()->findByFingerprint(fpr.toLatin1().constData());
        if (key.isNull()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in cache";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        const auto idx = km->index(key);
        if (!idx.isValid()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in model";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        m_view->expand(idx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        n += QFileInfo(dir.absoluteFilePath(file)).size();
    }
```

#### AUTO 


```{c}
auto vLay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto manufacturerIdAndName = scd_getattr_status(gpgAgent, "MANUFACTURER", err);
```

#### AUTO 


```{c}
auto const buttonLayout = new QHBoxLayout(buttonWidget);
```

#### AUTO 


```{c}
const auto key = KeyCache::instance()->findSubkeyByKeyGrip(sigInfo.grip, GpgME::OpenPGP).parent();
```

#### AUTO 


```{c}
auto it = std::find_if(checksumDefinitions.cbegin(), checksumDefinitions.cend(), matchFileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &task : std::as_const(runnable)) {
            q->connectTask(task);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->addUserID(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cardApp: cardApps) {
        const auto card = get_card_status(cardApp.serialNumber, cardApp.appName, gpgAgent);
        cards.push_back(card);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &i : signers) {
        const std::vector<Mailbox> bxs = extractMailboxes(i);
        res.insert(res.end(), bxs.begin(), bxs.end());
    }
```

#### AUTO 


```{c}
const auto card = ReaderStatus::instance()->getCard<C>(serialNumber);
```

#### AUTO 


```{c}
const auto readersData = gpgagent_data(assuanContext, command.c_str(), err);
```

#### AUTO 


```{c}
const auto op = static_cast<SignerResolvePage::Operation>(mode_);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImportResult &result : results) {
        //when a new certificate got a secret key
        if (result.numSecretKeysImported() >= 1) {
            const char *fingerPr = result.imports()[0].fingerprint();
            GpgME::Error err;
            QScopedPointer<Context>
                ctx(Context::createForProtocol(GpgME::Protocol::OpenPGP));

            if (!ctx){
                qCWarning(KLEOPATRA_LOG) << "Failed to get context";
                continue;
            }

            const Key toTrustOwner = ctx->key(fingerPr, err , false);

            if (toTrustOwner.isNull()) {
                return;
            }

            QStringList uids;
            const auto toTrustOwnerUserIDs{toTrustOwner.userIDs()};
            uids.reserve(toTrustOwnerUserIDs.size());
            for (const UserID &uid : toTrustOwnerUserIDs) {
                uids << Formatting::prettyNameAndEMail(uid);
            }

            const QString str = xi18nc("@info",
                "<title>You have imported a Secret Key.</title>"
                "<para>The key has the fingerprint:<nl/>"
                "<numid>%1</numid>"
                "</para>"
                "<para>And claims the User IDs:"
                "<list><item>%2</item></list>"
                "</para>"
                "Is this your own key? (Set trust level to ultimate)",
                QString::fromUtf8(fingerPr),
                uids.join(QLatin1String("</item><item>")));

            int k = KMessageBox::questionYesNo(nullptr, str, i18nc("@title:window",
                                                               "Secret key imported"));

            if (k == KMessageBox::Yes) {
                //To use the ChangeOwnerTrustJob over
                //the CryptoBackendFactory
                const QGpgME::Protocol *const backend = QGpgME::openpgp();

                if (!backend){
                    qCWarning(KLEOPATRA_LOG) << "Failed to get CryptoBackend";
                    return;
                }

                ChangeOwnerTrustJob *const j = backend->changeOwnerTrustJob();
                j->start(toTrustOwner, Key::Ultimate);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyInfo : OpenPGPCard::supportedKeys()) {
        const KeyWidgets keyWidgets = createKeyWidgets(keyInfo, q);

        const std::string keyRef = keyInfo.keyRef;
        connect(keyWidgets.showCertificateDetailsButton, &QPushButton::clicked,
                q, [this, keyRef] () { showCertificateDetails(keyRef); });
        if (keyWidgets.createCSRButton) {
            connect(keyWidgets.createCSRButton, &QPushButton::clicked,
                    q, [q, keyRef] () { Q_EMIT q->createCSRRequested(keyRef); });
        }

        const int row = grid->rowCount();
        grid->addWidget(keyWidgets.keyTitleLabel, row, 0, Qt::AlignTop);
        grid->addWidget(keyWidgets.keyInfoLabel, row, 1, Qt::AlignTop);

        auto buttons = new QHBoxLayout;
        buttons->addWidget(keyWidgets.showCertificateDetailsButton);
        if (keyWidgets.createCSRButton) {
            buttons->addWidget(keyWidgets.createCSRButton);
        }
        buttons->addStretch(1);
        grid->addLayout(buttons, row, 2, Qt::AlignTop);

        mKeyWidgets.insert({keyInfo.keyRef, keyWidgets});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: uids) {
            const unsigned int idx =
                std::distance(all.cbegin(), std::find_if(all.cbegin(), all.cend(),
                            [uid](const GpgME::UserID &other) { return uidEqual(uid, other); }));
            if (idx < all.size()) {
                indexes.push_back(idx);
            }
        }
```

#### AUTO 


```{c}
const auto appName = ReaderStatus::switchApp(assuanContext, mRealSerial, OpenPGPCard::AppName, err);
```

#### AUTO 


```{c}
const auto &dir
```

#### AUTO 


```{c}
const auto &groupName
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) {
                      return parseFileName(lhs, nullptr) < parseFileName(rhs, nullptr);
                  }
```

#### AUTO 


```{c}
auto cmd = new ImportCertificateFromPIVCardCommand(keyref, mCardSerialNumber);
```

#### AUTO 


```{c}
const auto editKey = edit->key();
```

#### AUTO 


```{c}
auto cmd = new Commands::CertifyCertificateCommand(key);
```

#### AUTO 


```{c}
auto cmd = new CreateCSRForCardKeyCommand(keyref, mRealSerial, OpenPGPCard::AppName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &i : std::as_const(certs)) {
        addCertificateToComboBox(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar ch : fpr) {
        result += ch;
        if (needColon) {
            result += QLatin1Char(':');
        }
        needColon = !needColon;
    }
```

#### AUTO 


```{c}
auto areaVLay = new QVBoxLayout(areaWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[conn](const std::shared_ptr<AssuanServerConnection> &other) {
                                         return conn == other.get();
                                     }
```

#### AUTO 


```{c}
auto buttonYes = KStandardGuiItem::yes();
```

#### AUTO 


```{c}
const auto buttonCode = KMessageBox::createKMessageBox(dialog, buttonBox, QMessageBox::Critical, text, {}, {}, nullptr, {});
```

#### AUTO 


```{c}
const auto proto = (pgp() == OpenPGP) ? QGpgME::openpgp() : QGpgME::smime();
```

#### AUTO 


```{c}
const auto optr = (*oit).get();
```

#### AUTO 


```{c}
auto scrollLay = new QVBoxLayout;
```

#### AUTO 


```{c}
auto filename = FileDialog::getSaveFileNameEx(
        parent,
        i18nc("@title:window", "Secret Key Backup"),
        QStringLiteral("imp"),
        proposedFilename,
        secretKeyFileFilters(key.protocol()));
```

#### AUTO 


```{c}
auto profLabel = new QLabel(i18n("GnuPG Profile:"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](int err, const QString &details) { slotControllerError(err,details); }
```

#### LAMBDA EXPRESSION 


```{c}
[removeButton] (const QItemSelection &selected, const QItemSelection &) {
                    removeButton->setEnabled(!selected.isEmpty());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &g) {
                                                 return g.status == ImportedGroup::Status::New;
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[&str, &pos](QValidator *val) {
                       return val->validate(str, pos);
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto w) { return w->isEmpty(); }
```

#### AUTO 


```{c}
const auto &path
```

#### AUTO 


```{c}
const auto input = Input::createFromFile(cFile.fileName);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { importFinished(); }
```

#### AUTO 


```{c}
const auto chvStatus = QString::fromStdString(
            scd_getattr_status(gpg_agent, "CHV-STATUS", err)).split(QStringLiteral(" "));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { manageGroups(); }
```

#### AUTO 


```{c}
auto currentIndex = getGroupIndex(selection.current);
```

#### AUTO 


```{c}
const auto sig = !selfSigs.empty() ? selfSigs.back() : GpgME::UserID::Signature{};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &card: d->cardInfos()) {
        if (card->serialNumber() == serialNumber && card->appName() == appName) {
            qCDebug(KLEOPATRA_LOG) << "ReaderStatus::getCard() - Found card with serial number" << serialNumber << "and app" << appName;
            return card;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.genRevokeBtn->setEnabled(true);
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &t : std::as_const(tmp)) {
        connectTask(t);
    }
```

#### AUTO 


```{c}
const auto &uid
```

#### LAMBDA EXPRESSION 


```{c}
[rx](const QString &str) { 
                                return rx.exactMatch(str);
                             }
```

#### AUTO 


```{c}
const auto key = d->key();
```

#### AUTO 


```{c}
const auto keys = card->keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit: qAsConst(mRecpWidgets)) {
        const auto editGroup = edit->group();
        if (group.isNull() && editGroup.isNull()) {
            recpRemovalRequested(edit);
            return;
        }
        if (editGroup.name() == group.name()) {
            recpRemovalRequested(edit);
            return;
        }
    }
```

#### AUTO 


```{c}
auto rearangingModel = new KeyRearrangeColumnsProxyModel(this);
```

#### AUTO 


```{c}
const auto *const event = static_cast<QResizeEvent*>(ev);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint& p) {
                slotContextMenu(p);
            }
```

#### AUTO 


```{c}
const auto tags = tagList.join(QStringLiteral("; "));
```

#### AUTO 


```{c}
const auto newWindowSize = (w->size() + extent).boundedTo(maxWindowSize);
```

#### LAMBDA EXPRESSION 


```{c}
[&html, dn](const QString &lbl, const QString &attr) {
                                const QString val = dn[attr];
                                if (!val.isEmpty()) {
                                    html += QStringLiteral(
                                            "<tr><th style=\"text-align: left; white-space: nowrap\">%1:</th>"
                                                "<td style=\"white-space: nowrap\">%2</td>"
                                            "</tr>").arg(lbl, val);
                                }
                            }
```

#### AUTO 


```{c}
const auto statusLines = Assuan::sendStatusLinesCommand(gpgAgent, command.c_str(), err);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ChecksumsUtils::File &file : files) {
            const bool isSameFileName = (QString::compare(file.name, fileName, ChecksumsUtils::fs_cs) == 0);
            qCDebug(KLEOPATRA_LOG) << "find_sums_by_input_files:        "
                                   << qPrintable(file.name) << " == "
                                   << qPrintable(fileName)  << " ? "
                                   << isSameFileName;
            if (isSameFileName) {
                return true;
            }
        }
```

#### AUTO 


```{c}
const auto ad_default_id = filePrefs.archiveCommand();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &result) { slotResult(result); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, gpgconf] () {
        if (gpgconf->exitStatus() != QProcess::NormalExit) {
            KMessageBox::error(this, QStringLiteral("<pre>%1</pre>").arg(QString::fromLocal8Bit(gpgconf->readAll())));
            delete gpgconf;
            return;
        }
        delete gpgconf;
        KMessageBox::information(this,
                         i18nc("@info", "The configuration profile is now applied."),
                         i18n("Configuration profile applied"));
        auto config = QGpgME::cryptoConfig();
        if (config) {
            config->clear();
        }
    }
```

#### AUTO 


```{c}
auto cmd = new ExportCertificateCommand{key};
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool on) { slotPageHierarchyChanged(on); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        mLearnKeysBtn->setEnabled(false);
        auto cmd = new LearnCardKeysCommand(GpgME::CMS);
        cmd->setParentWidget(this);
        cmd->start();

        connect(cmd, &Command::finished, this, [] () {
            ReaderStatus::mutableInstance()->updateStatus();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyGroup &group : groups) {
            if (!certWidget) {
                certWidget = certificateLineEdit;
            } else {
                certWidget = insertRecipientWidget(certWidget);
            }
            certWidget->setGroup(group);
        }
```

#### AUTO 


```{c}
const auto time = QDateTime::fromSecsSinceEpoch(subkey.creationTime(), Qt::UTC);
```

#### AUTO 


```{c}
const auto other = dynamic_cast<const OpenPGPCard *>(&rhs);
```

#### AUTO 


```{c}
const auto currentErrorMessage = ui.errorLabel.text();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (parseCardInfo(pair.first, pair.second)) {
            continue;
        }
        if (pair.first == "KEY-FPR") {
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto keyNumber = values[0];
            const std::string keyRef = "OPENPGP." + keyNumber.toStdString();
            const auto fpr = values[1].toStdString();
            if (keyNumber == QLatin1Char('1') || keyNumber == QLatin1Char('2') || keyNumber == QLatin1Char('3')) {
                mMetaInfo.insert("KLEO-FPR-" + keyRef, fpr);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &grpName: groupList) {
            auto grp = comp->group(grpName);
            if (!grp) {
                qCWarning(KLEOPATRA_LOG) << "Failed to find group:" << grp << "in component:" << compName;
                return;
            }
            const QStringList entries = grp->entryList();
            for (const auto &entryName: entries) {
                auto entry = grp->entry(entryName);
                if (!entry) {
                    qCWarning(KLEOPATRA_LOG) << "Failed to find entry:" << entry << "in group:"<< grp << "in component:" << compName;
                    return;
                }
                entry->resetToDefault();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const CertificateSelectionLine &l) {
                                                           return l.wasInitiallyAmbiguous(proto);
                                                       }
```

#### AUTO 


```{c}
auto tabGrid = new QGridLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { progressDialog->accept(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir: srcDir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot)) {
        const QString srcName = src + QLatin1Char('/') + dir;
        const QString destName = dest + QLatin1Char('/') + dir;
        if (!recursivelyCopy(srcName, destName)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
const auto result = saveRequestToFile(filePath, request, QIODevice::NewOnly);
```

#### AUTO 


```{c}
const auto key = KeyListSortFilterProxyModel::data(index, KeyList::KeyRole).value<GpgME::Key>();
```

#### AUTO 


```{c}
auto end = keys.end();
```

#### AUTO 


```{c}
const auto key = ui.treeView->view()->model()->data(index, KeyList::KeyRole).value<GpgME::Key>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) { return key.isRevoked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::KeyGenerationResult &result, const QByteArray &pubKeyData) {
        slotResult(result, pubKeyData);
    }
```

#### AUTO 


```{c}
const auto newGroups = std::count_if(std::begin(groups), std::end(groups),
                                             [](const auto &g) {
                                                 return g.status == ImportedGroup::Status::New;
                                             });
```

#### AUTO 


```{c}
auto infoBtn = createInfoButton(i18n("You can use this to set an expiration date for a certification.") +
                                            QStringLiteral("<br/><br/>") +
                                            i18n("By setting an expiration date, you can limit the validity of "
                                                 "your certification to a certain amount of time. Once the expiration "
                                                 "date has passed, your certification is no longer valid."),
                                            q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &app: apps) {
                    qCDebug(KLEOPATRA_LOG) << "getCardsAndApps(): Found card" << serialNumber << "with app" << app;
                    result.push_back({ serialNumber.toStdString(), app.toStdString() });
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { lookup(); }
```

#### AUTO 


```{c}
auto matchFileName = [&fileName](const std::shared_ptr<Kleo::ChecksumDefinition> &cd) {
        if (!cd) {
            return false;
        }

        const QStringList &patterns = cd->patterns();
        return std::any_of(patterns.cbegin(), patterns.cend(), [&fileName](const QString &pattern) {
            const QRegularExpression re(QRegularExpression::anchoredPattern(pattern), s_regex_cs);
            return re.match(fileName).hasMatch();
        });
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
        // Yep you can have one subkey associated with mutliple
        // primary keys.
        toolTips << Formatting::toolTip(sub.parent(), Formatting::Validity |
                                        Formatting::StorageLocation |
                                        Formatting::ExpiryDates |
                                        Formatting::UserIDs |
                                        Formatting::Fingerprint);
    }
```

#### AUTO 


```{c}
auto w = window()
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        if (m_result->parentTask()) {
            const auto dvTask = dynamic_cast<DecryptVerifyTask*>(m_result->parentTask().data());
            dvTask->setIgnoreMDCError(true);
            dvTask->start();
            q->setVisible(false);
        } else {
            qCWarning(KLEOPATRA_LOG) << "Failed to get parent task";
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool on) { d->slotToggleHierarchicalView(on); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { editChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::ImportResult &result) { importResult(result); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : checksumDefinitions)
        if (cd) {
            const auto patterns = cd->patterns();
            for (const QString &pattern : patterns) {
                result.push_back(QRegExp(pattern, fs_cs));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fname: qAsConst(m_passedFiles)) {
        kleo_assert(!fname.isEmpty());

        const unsigned int classification = classify(fname);
        const Protocol proto = findProtocol(classification);

        if (mayBeOpaqueSignature(classification) || mayBeCipherText(classification) || mayBeDetachedSignature(classification)) {

            DecryptVerifyOperationWidget *const op = m_wizard->operationWidget(counter++);
            kleo_assert(op != nullptr);

            op->setArchiveDefinitions(archiveDefinitions);

            const QString signedDataFileName = findSignedData(fname);

            // this breaks opaque signatures whose source files still
            // happen to exist in the same directory. Until we have
            // content-based classification, this is the most unlikely
            // case, so that's the case we break. ### FIXME remove when content-classify is done
            if (mayBeDetachedSignature(classification) && !signedDataFileName.isEmpty()) {
                op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignature);
            }
            // ### end FIXME
            else if (mayBeOpaqueSignature(classification) || mayBeCipherText(classification)) {
                op->setMode(DecryptVerifyOperationWidget::DecryptVerifyOpaque, q->pick_archive_definition(proto, archiveDefinitions, fname));
            } else {
                op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignature);
            }

            op->setInputFileName(fname);
            op->setSignedDataFileName(signedDataFileName);

            m_filesAfterPreparation << fname;

        } else {

            // probably the signed data file was selected:
            const QStringList signatures = findSignatures(fname);

            if (signatures.empty()) {
                // We are assuming this is a detached signature file, but
                // there were no signature files for it. Let's guess it's encrypted after all.
                // ### FIXME once we have a proper heuristic for this, this should move into
                // classify() and/or classifyContent()
                DecryptVerifyOperationWidget *const op = m_wizard->operationWidget(counter++);
                kleo_assert(op != nullptr);
                op->setArchiveDefinitions(archiveDefinitions);
                op->setMode(DecryptVerifyOperationWidget::DecryptVerifyOpaque, q->pick_archive_definition(proto, archiveDefinitions, fname));
                op->setInputFileName(fname);
                m_filesAfterPreparation << fname;
            } else {
                for (const auto &s: signatures) {
                    DecryptVerifyOperationWidget *op = m_wizard->operationWidget(counter++);
                    kleo_assert(op != nullptr);

                    op->setArchiveDefinitions(archiveDefinitions);
                    op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignedData);
                    op->setInputFileName(s);
                    op->setSignedDataFileName(fname);

                    m_filesAfterPreparation << fname;
                }

            }
        }
    }
```

#### AUTO 


```{c}
const auto dateFormat = (locale().dateFormat(QLocale::ShortFormat) //
                                     .replace(QLatin1String{"yy"}, QLatin1String{"yyyy"})
                                     .replace(QLatin1String{"yyyyyyyy"}, QLatin1String{"yyyy"}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &grpName: comp->groupList()) {
            auto grp = comp->group(grpName);
            if (!grp) {
                qCWarning(KLEOPATRA_LOG) << "Failed to find group:" << grp << "in component:" << compName;
                return;
            }
            for (const auto &entryName: grp->entryList()) {
                auto entry = grp->entry(entryName);
                if (!entry) {
                    qCWarning(KLEOPATRA_LOG) << "Failed to find entry:" << entry << "in group:"<< grp << "in component:" << compName;
                    return;
                }
                entry->resetToDefault();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit : std::as_const(mRecpWidgets)) {
        edit->setKeyFilter(encFilter);
    }
```

#### AUTO 


```{c}
auto gpgconf = new QProcess;
```

#### LAMBDA EXPRESSION 


```{c}
[this, cmd]() {
                         ui.addUserIDBtn->setEnabled(true);
                     }
```

#### AUTO 


```{c}
auto comments = QString("Comment: ");
```

#### LAMBDA EXPRESSION 


```{c}
[toolbar](auto w) {
            forceSetTabOrder(toolbar, w);
        }
```

#### AUTO 


```{c}
auto findAnyGoodKey = []() {
        const std::vector<Key> secKeys = KeyCache::instance()->secretKeys();
        return std::any_of(secKeys.cbegin(), secKeys.cend(), [](const Key &secKey) {
            return secKey.canCertify() && secKey.protocol() == OpenPGP && !secKey.isRevoked()
                   && !secKey.isExpired() && !secKey.isInvalid();
        });
    };
```

#### AUTO 


```{c}
const auto *const model = d->ui.tabWidget.currentModel();
```

#### AUTO 


```{c}
auto cmd = new Commands::DetailsCommand(mKey, Q_NULLPTR);
```

#### AUTO 


```{c}
const auto split = data.split('\n');
```

#### LAMBDA EXPRESSION 


```{c}
[] {
                KHelpClient::invokeHelp(QStringLiteral("kleopatra"));
            }
```

#### AUTO 


```{c}
const auto conf = QGpgME::cryptoConfig();
```

#### AUTO 


```{c}
auto le = qobject_cast<QLineEdit *>(l->itemAtPosition(row, 1)->widget());
```

#### AUTO 


```{c}
auto workerThread = new GenKeyThread(params, mRealSerial);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QValidator *val) { removeValidator(val); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Input> &i : allInputs) {
                i->setLabel(sessionTitle);
            }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : results) {
            if (importFailed(r)) {
                showError(r.result.error(), r.id);
            }
        }
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        ui.userIDTable->setEnabled(true);
        updateKey();
    }
```

#### AUTO 


```{c}
const auto index = mArchiveDefinitionCB.widget()->findData(ad_default_id);
```

#### AUTO 


```{c}
auto cmd = new EditGroupCommand(group, q->parentWidget());
```

#### AUTO 


```{c}
auto fsm = qobject_cast<QFileSystemModel *>(proxy.sourceModel())
```

#### AUTO 


```{c}
const auto firstFocusPolicy = first->focusPolicy();
```

#### AUTO 


```{c}
auto lay = new QGridLayout(this);
```

#### AUTO 


```{c}
auto hLayBtn = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotDialogDestroyed(); }
```

#### AUTO 


```{c}
auto newKey = Key();
```

#### AUTO 


```{c}
const auto key = KeyListSortFilterProxyModel::data(index,
                    Kleo::KeyListModelInterface::KeyRole).value<GpgME::Key>();
```

#### AUTO 


```{c}
const auto ownerId = key.userID(0);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            enableDisableActions();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey] () {
            auto cmd = new Kleo::Commands::ImportPaperKeyCommand(subkey.parent());
            ui.subkeysTree->setEnabled(false);
            connect(cmd, &Kleo::Commands::ImportPaperKeyCommand::finished,
                    q, [this]() { ui.subkeysTree->setEnabled(true); });
            cmd->setParentWidget(q);
            cmd->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sumFileName : std::as_const(it->second)) {

            const std::vector<File> summedfiles = parse_sum_file(dir.absoluteFilePath(sumFileName));
            QStringList files;
            files.reserve(summedfiles.size());
            std::transform(summedfiles.cbegin(), summedfiles.cend(),
                           std::back_inserter(files), std::mem_fn(&File::name));
            const SumFile sumFile = {
                it->first,
                sumFileName,
                aggregate_size(it->first, files),
                filename2definition(sumFileName, checksumDefinitions),
            };
            sumfiles.push_back(sumFile);

        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (QItemSelection selection, const QModelIndex &index) {
            if (index.isValid()) {
                selection.merge(QItemSelection(index, index), QItemSelectionModel::Select);
            }
            return selection;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[] (const QModelIndex &index) { return !index.isValid(); }
```

#### AUTO 


```{c}
auto infoBtn = new QPushButton{parent};
```

#### AUTO 


```{c}
auto page =
            new DirectoryServicesConfigurationPage(parent, args);
```

#### LAMBDA EXPRESSION 


```{c}
[ proc] () {
            proc->kill();
            qCDebug(KLEOPATRA_LOG) << "Update force canceled. Output:"
                                   << QString::fromLocal8Bit(proc->readAllStandardOutput())
                                   << "stderr:"
                                   << QString::fromLocal8Bit(proc->readAllStandardError());
    }
```

#### AUTO 


```{c}
auto rsaLabel = new QLabel(i18n("RSA Keysize:"));
```

#### AUTO 


```{c}
auto missingSignerKeyIds = Kleo::getMissingSignerKeyIds(newOpenPGPKeys);
```

#### AUTO 


```{c}
static const auto path = findGpgExe(GpgME::GpgConfEngine, QStringLiteral("gpgconf"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { changePassphrase(); }
```

#### AUTO 


```{c}
auto createSeparatorAction(QObject *parent)
{
    auto action = new QAction{parent};
    action->setSeparator(true);
    return action;
}
```

#### AUTO 


```{c}
auto ret = KMessageBox::warningContinueCancel(this,
            i18n("Setting a PIN is required but <b>can't be reverted</b>.") +
            QStringLiteral("<p>%1</p><p>%2</p>").arg(
                i18n("If you proceeed you will be asked to enter a new PIN "
                     "and later to repeat that PIN.")).arg(
                i18n("It will <b>not be possible</b> to recover the "
                     "card if the PIN has been entered wrongly more than 2 times.")),
            i18n("Set initial PIN"),
            KStandardGuiItem::cont(),
            KStandardGuiItem::cancel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (pair.first == "APPVERSION") {
            setAppVersion(parseAppVersion(pair.second));
        } else if (pair.first == "KEYPAIRINFO") {
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() != 3) {
                qCWarning(KLEOPATRA_LOG) << "Invalid KEYPAIRINFO entry" << QString::fromStdString(pair.second);
                setStatus(Card::CardError);
                continue;
            }
            const auto grip = values[0].toStdString();
            const auto slotId = values[1];
            const auto usage = values[2];
            if (slotId == QLatin1String("PIV.9A")) {
                mMetaInfo.insert(std::string("PIV-AUTH-") + pair.first, grip);
            } else if (slotId == QLatin1String("PIV.9E")) {
                mMetaInfo.insert(std::string("CARD-AUTH-") + pair.first, grip);
            } else if (slotId == QLatin1String("PIV.9C")) {
                mMetaInfo.insert(std::string("SIG-") + pair.first, grip);
            } else if (slotId == QLatin1String("PIV.9D")) {
                mMetaInfo.insert(std::string("ENC-") + pair.first, grip);
            } else {
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### AUTO 


```{c}
const auto &compName
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const GpgME::Error &err) {
            if (err) {
                KMessageBox::sorry(q,
                                   i18n("<p>Changing the certification trust of the key <b>%1</b> failed:</p><p>%2</p>",
                                        Formatting::formatForComboBox(secKey()),
                                        QString::fromLocal8Bit(err.asString())),
                                   i18n("Certification Trust Change Failed"));
            }
            if (err || err.isCanceled()) {
                mSetOwnerTrustAction->setEnabled(true);
            } else {
                mMissingOwnerTrustInfo->setMessageType(KMessageWidget::Positive);
                mMissingOwnerTrustInfo->setIcon(QIcon::fromTheme(QStringLiteral("checkmark")));
                mMissingOwnerTrustInfo->setText(i18n("Owner trust set successfully."));
            }
        }
```

#### AUTO 


```{c}
const auto keyType = advancedSettingsDlg->keyType();
```

#### AUTO 


```{c}
const auto choice = KMessageBox::warningContinueCancel(parentWidgetOrView(), message,
                i18nc("@title:window", "Overwrite existing key"),
                KStandardGuiItem::cont(), KStandardGuiItem::cancel(), QString(), KMessageBox::Notify | KMessageBox::Dangerous);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: KeyCache::instance()->findRecipients(dvResult->decryptionResult())) {
            return key.protocol();
        }
```

#### AUTO 


```{c}
const auto job = *it;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        /* We use a single shot timer here to ensure that the keysMayHaveChanged
         * handlers are all handled before we restore the expand state so that
         * the model is already populated. */
        QTimer::singleShot(0, [this] () {
            restoreExpandState();
            if (!m_onceResized) {
                m_onceResized = true;
                resizeColumns();
            }
        });
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &pattern) {
            return QRegularExpression(QRegularExpression::anchoredPattern(pattern), s_regex_cs);
        }
```

#### AUTO 


```{c}
auto lastWidget = mRecpLayout->itemAt(mRecpLayout->count() - 1)->widget();
```

#### AUTO 


```{c}
const auto protocol = static_cast<Protocol>(p);
```

#### AUTO 


```{c}
auto vboxLayout = new QVBoxLayout{mainWidget};
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotDuplicateCurrentTab(); }
```

#### AUTO 


```{c}
const auto encFilter = std::shared_ptr<KeyFilter>(new EncryptCertificateFilter(proto));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                mOkButton->setEnabled(!mEmailEdit->text().isEmpty() && mEmailEdit->hasAcceptableInput());
            }
```

#### AUTO 


```{c}
const auto &profile
```

#### AUTO 


```{c}
auto mPGPRB = new QRadioButton(i18n("OpenPGP"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Key &key) { slotAboutToRemoveKey(key); }
```

#### AUTO 


```{c}
auto cardWidget = d->mTabWidget->currentWidget()
```

#### AUTO 


```{c}
auto mainWidget = new QWidget;
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::RevokeCertificationCommand(signature);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { checkRequirements(); }
```

#### AUTO 


```{c}
const auto backend = smime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fn : std::as_const(d->files)) {
        QFile in(fn);
        if (!in.open(QIODevice::ReadOnly)) {
            d->error(i18n("Could not open file %1 for reading: %2", in.fileName(), in.errorString()), i18n("Certificate Import Failed"));
            d->importResult({fn, GpgME::UnknownProtocol, ImportType::Local, ImportResult{}});
            continue;
        }
        const auto data = in.readAll();
        d->startImport(GpgME::OpenPGP, data, fn);
        d->startImport(GpgME::CMS, data, fn);
        d->importGroupsFromFile(fn);
    }
```

#### AUTO 


```{c}
auto line2 = new QFrame();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            mChangeSigGPINBtn->setEnabled(false);
            doChangePin(true);
        }
```

#### AUTO 


```{c}
const auto serialNumber = newCard->serialNumber();
```

#### AUTO 


```{c}
const auto tofu = uid.tofuInfo();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) {
            q->certificateToPIVCardDone(err);
        }
```

#### AUTO 


```{c}
auto expander = new AnimatedExpander(i18n("Advanced"));
```

#### AUTO 


```{c}
auto keyFilter = std::make_shared<SecKeyFilter>();
```

#### AUTO 


```{c}
const auto patterns = cd->patterns();
```

#### AUTO 


```{c}
auto const sm = qobject_cast<QAbstractProxyModel *>(pm->sourceModel())
```

#### AUTO 


```{c}
auto info = Assuan::sendStatusLinesCommand(gpg_agent, "SCD LEARN --force", err);
```

#### AUTO 


```{c}
const auto keyRef = getKeyRef(usableKeys, this);
```

#### LAMBDA EXPRESSION 


```{c}
[import, q]() {
                    import->setEnabled(true);
                }
```

#### AUTO 


```{c}
auto cmsBegin = pgpEnd;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->onKeysMayHaveChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str, VerifyChecksumsDialog::Status st) { Q_EMIT status(str, st); }
```

#### AUTO 


```{c}
auto dlg = new SetInitialPinDialog;
```

#### AUTO 


```{c}
auto menu = new QMenu(q);
```

#### AUTO 


```{c}
auto certSel = new CertificateLineEdit(mModel, this,
                                           new EncryptCertificateFilter(mCurrentProto));
```

#### AUTO 


```{c}
auto profLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto c = Context::createForEngine(AssuanEngine, &err);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &key) {
                             return key.primaryFingerprint() &&
                                    keyListing.wkdKeyFingerprints.find(key.primaryFingerprint()) != std::end(keyListing.wkdKeyFingerprints);
                         }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->showMoreDetails(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &id : userIDs)
        if (mailbox_equal(mailbox(id), mbox, Qt::CaseInsensitive)) {
            return id;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyInfo : OpenPGPCard::supportedKeys()) {
        KeyWidgets keyWidgets = createKeyWidgets(keyInfo);
        layoutKeyWidgets(keysGrid, OpenPGPCard::keyDisplayName(keyInfo.keyRef), keyWidgets);
    }
```

#### AUTO 


```{c}
const auto displaySerialNumber = scd_getattr_status(gpgAgent, "$DISPSERIALNO", err);
```

#### AUTO 


```{c}
auto groupBoxLayout = new QVBoxLayout{groupBox};
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : selectedCertificates) {
            data += key.primaryFingerprint();
            data += '\n';
        }
```

#### AUTO 


```{c}
const auto imports = result.imports();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractItemView *view) { addView(view); }
```

#### AUTO 


```{c}
auto *vBox = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const GpgME::Key &) {
#ifdef GPGME_HAS_REMARKS
            updateRemark();
#endif
        }
```

#### AUTO 


```{c}
auto *vlay = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto urlButtton = new QPushButton;
```

#### AUTO 


```{c}
auto hLay = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[importButton, q] () {
            importButton->setEnabled(false);
            auto cmd = new Kleo::ImportCertificateFromFileCommand();
            connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                    q, [importButton]() {
                importButton->setEnabled(true);
            });
            cmd->setParentWidget(q);
            cmd->start();
        }
```

#### AUTO 


```{c}
const auto compendium = new DocAction(QIcon::fromTheme(QStringLiteral("gpg4win-compact")), i18n("Gpg4win Compendium"),
            i18nc("The Gpg4win compendium is only available"
                  "at this point (24.7.2017) in german and english."
                  "Please check with Gpg4win before translating this filename.",
                  "gpg4win-compendium-en.pdf"),
            QStringLiteral("../share/gpg4win"));
```

#### AUTO 


```{c}
const auto protocol = d->ui.chooseProtocolPage.protocol();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &text) {
                slotDetermined(text.at(text.size() - 1).digitValue());
            }
```

#### AUTO 


```{c}
const auto states = pinStates();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : qAsConst(mRecpWidgets)) {
        if (!w->isEnabled()) {
            // If one is disabled, all are disabled.
            break;
        }
        const Key k = w->key();
        const KeyGroup g = w->group();
        if (!k.isNull()) {
            ret << k;
        } else if (!g.isNull()) {
            const auto keys = g.keys();
            std::copy(keys.begin(), keys.end(), std::back_inserter(ret));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : certs)
        if (s.isEmpty()) {
            qCWarning(LIBKLEOPATRACLIENTCORE_LOG) << "SelectCertificateCommand::setSelectedCertificates: empty certificate!";
        } else {
            data += s.toUtf8() += '\n';
        }
```

#### AUTO 


```{c}
auto *completeFilterModel = new ProxyModel(completer);
```

#### AUTO 


```{c}
const auto entryList = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
```

#### AUTO 


```{c}
const auto errMsg = card->errorMsg();
```

#### AUTO 


```{c}
auto confirmButton = KStandardGuiItem::yes();
```

#### AUTO 


```{c}
const auto domain = address.substr(atPos + 1);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { writeCertificateToCard(PIVCard::cardAuthenticationKeyRef()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
            addItem(Formatting::formatForComboBox(key), qVariantFromValue(key));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg] () {
            doGenKey(dlg);
            dlg->deleteLater();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : std::as_const(attrOrder)) {
        const QString key = rawKey.trimmed().toUpper();
        const QString attr = attributeFromKey(key);
        if (attr.isEmpty()) {
            continue;
        }
        const QString preset = savedValues.value(attr, config.readEntry(attr, QString()));
        const bool required = key.endsWith(QLatin1Char('!'));
        const bool readonly = config.isEntryImmutable(attr);
        const QString label = config.readEntry(attr + QLatin1String("_label"),
                                               attributeLabel(attr, pgp()));
        const QString regex = config.readEntry(attr + QLatin1String("_regex"));
        const QString placeholder = config.readEntry(attr + QLatin1String{"_placeholder"});

        int row;
        bool known = true;
        QValidator *validator = nullptr;
        if (attr == QLatin1String("EMAIL")) {
            row = row_index_of(ui.emailLE, ui.gridLayout);
            validator = regex.isEmpty() ? Validation::email() : Validation::email(QRegExp(regex));
        } else if (attr == QLatin1String("NAME") || attr == QLatin1String("CN")) {
            if ((pgp() && attr == QLatin1String("CN")) || (!pgp() && attr == QLatin1String("NAME"))) {
                continue;
            }
            if (pgp()) {
                validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(QRegExp(regex));
            }
            row = row_index_of(ui.nameLE, ui.gridLayout);
        } else {
            known = false;
            row = add_row(ui.gridLayout, &dynamicWidgets);
        }
        if (!validator && !regex.isEmpty()) {
            validator = new QRegExpValidator(QRegExp(regex), nullptr);
        }

        QLineEdit *le = adjust_row(ui.gridLayout, row, label, preset, validator, readonly, required);
        le->setPlaceholderText(placeholder);

        const Line line = { key, label, regex, le };
        lines[row] = line;

        if (!known) {
            widgets.push_back(le);
        }

        // don't connect twice:
        disconnect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
        connect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QMetaObject::invokeMethod(
            q,
            [this]() {
                getCertificateDetails();
            },
            Qt::QueuedConnection);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Sender &s : qAsConst(senders)) {
            addSigner(s);
        }
```

#### AUTO 


```{c}
const auto var = qEnvironmentVariable("EMAIL");
```

#### AUTO 


```{c}
auto w = new QWidget;
```

#### AUTO 


```{c}
auto createOpenPGPOnlyKeyFilter()
{
    auto filter = std::make_shared<DefaultKeyFilter>();
    filter->setIsOpenPGP(DefaultKeyFilter::Set);
    return filter;
}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { onEditingFinished(); }
```

#### AUTO 


```{c}
const auto selection = selectedRows();
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey]() {
                    auto cmd = new ChangeExpiryCommand(subkey.parent());
                    cmd->setSubkey(subkey);
                    ui.subkeysTree->setEnabled(false);
                    connect(cmd, &ChangeExpiryCommand::finished,
                            q, [this]() {
                                ui.subkeysTree->setEnabled(true);
                                key.update();
                                q->setKey(key);
                            });
                    cmd->setParentWidget(q);
                    cmd->start();
                }
```

#### AUTO 


```{c}
auto verifyTask = new VerifyOpaqueTask();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.addUserIDBtn->setEnabled(true);
                         updateKey();
                     }
```

#### AUTO 


```{c}
const auto card = SmartCard::ReaderStatus::instance()->getCard<Card>(serialNumber());
```

#### AUTO 


```{c}
auto cmd = new CreateCSRForCardKeyCommand(keyRef, mSerialNumber, NetKeyCard::AppName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyGroup &group : groups) {
            if (isFirstItem) {
                certificateLineEdit->setGroup(group);
                isFirstItem = false;
            } else {
                addRecipient(group);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](Job *job) { job->slotCancel(); }
```

#### AUTO 


```{c}
const auto atPos = address.find('@');
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        close();
    }
```

#### AUTO 


```{c}
const auto selectedEntries{m_listWidget->selectedEntries()};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {q->reject();}
```

#### AUTO 


```{c}
const auto keyserver = mOpenPGPKeyserverEdit->text();
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::CertifyCertificateCommand(key);
```

#### AUTO 


```{c}
auto sigKey = mSigSelect->currentKey();
```

#### LAMBDA EXPRESSION 


```{c}
[cmd](const std::shared_ptr<AssuanCommand> &other) {
                                        return other.get() == cmd;
                                     }
```

#### AUTO 


```{c}
auto btn = new QPushButton("Apply");
```

#### AUTO 


```{c}
auto cmd = new Commands::DetailsCommand{q->key(), nullptr};
```

#### AUTO 


```{c}
auto tagsLay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::LookupCertificatesCommand(keyid, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (pair.first == "APPVERSION") {
            setAppVersion(parseAppVersion(pair.second));
        } else if (pair.first == "KEYPAIRINFO") {
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() != 3) {
                qCWarning(KLEOPATRA_LOG) << "Invalid KEYPAIRINFO entry" << QString::fromStdString(pair.second);
                setStatus(Card::CardError);
                continue;
            }
            const auto grip = values[0].toStdString();
            const auto keyRef = values[1].toStdString();
            //const auto usage = values[2];
            mMetaInfo.insert("KEYPAIRINFO-" + keyRef, grip);
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### AUTO 


```{c}
auto const cmd = new DecryptVerifyFilesCommand(files, nullptr);
```

#### AUTO 


```{c}
const auto matchContexts = qvariant_cast<KeyFilter::MatchContexts>(sourceModel()->data(index, KeyFilterManager::FilterMatchContextsRole));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto generateButton = new QPushButton(i18n("Generate New Keys"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
        auto cmd = new Kleo::Commands::CertifyCertificateCommand(userID);
        ui.userIDTable->setEnabled(false);
        connect(cmd, &Kleo::Commands::CertifyCertificateCommand::finished,
                q, [this]() { ui.userIDTable->setEnabled(true); });
        cmd->start();
    }
```

#### AUTO 


```{c}
auto overview = new QLabel;
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::ChangePassphraseCommand(key);
```

#### AUTO 


```{c}
auto label = new QLabel(templ.arg(welcome).arg(introduction).arg(keyExplanation).arg(privateKeyExplanation).arg(publicKeyExplanation).arg(learnMore));
```

#### AUTO 


```{c}
const auto trustDomains = accumulateTrustDomains(key.userIDs());
```

#### AUTO 


```{c}
const auto newDomains = accumulateTrustDomains(userID.signatures());
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &t : std::as_const(tmp)) {
        q->connectTask(t);
    }
```

#### AUTO 


```{c}
auto const titleLayout = new QVBoxLayout(titleFrame);
```

#### AUTO 


```{c}
auto &childData = childCache()[index];
```

#### AUTO 


```{c}
auto wid = new ItemWidget(id, name, mbox, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : std::as_const(mRecpWidgets)) {
        if (!w->isEnabled()) {
            // If one is disabled, all are disabled.
            break;
        }
        const Key k = w->key();
        const KeyGroup g = w->group();
        if (!k.isNull()) {
            ret.push_back(k);
        } else if (!g.isNull()) {
            const auto keys = g.keys();
            std::copy(keys.begin(), keys.end(), std::back_inserter(ret));
        }
    }
```

#### AUTO 


```{c}
auto lay = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : extraView) {
        config->deleteGroup(group);
    }
```

#### AUTO 


```{c}
const auto wantedViewportHeight = event->size().height();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotSigGPinRequested(); }
```

#### AUTO 


```{c}
const auto selection = d->saveSelection();
```

#### AUTO 


```{c}
auto ctx = QGpgME::Job::context(keyGenJob);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                this->parentWidget()->setEnabled(true);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) { return !key.hasSecret(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    Q_EMIT q->selectedUserIDsChanged(q->selectedUserIDs());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : attrOrder) {
            const QString key = rawKey.trimmed().toUpper();
            const QString attr = attributeFromKey(key);
            if (attr.isEmpty()) {
                continue;
            }
            const QString defaultPreset = (attr == QLatin1String("CN")) ? userFullName() :
                                          (attr == QLatin1String("EMAIL")) ? userEmailAddress() :
                                          QString();
            const QString preset = config.readEntry(attr, defaultPreset);
            const bool required = key.endsWith(QLatin1Char('!'));
            const bool readonly = config.isEntryImmutable(attr);
            const QString label = config.readEntry(attr + QLatin1String("_label"),
                                                   attributeLabel(attr));
            const QString regex = config.readEntry(attr + QLatin1String("_regex"));

            QValidator *validator = nullptr;
            if (attr == QLatin1String("EMAIL")) {
                validator = regex.isEmpty() ? Validation::email() : Validation::email(regex);
            } else if (!regex.isEmpty()) {
                validator = new QRegularExpressionValidator{QRegularExpression{regex}, nullptr};
            }

            QLineEdit *le = addRow(ui.gridLayout, label, preset, validator, readonly, required);

            const Line line = { attr, label, regex, le, required };
            ui.lines.push_back(line);

            if (attr != QLatin1String("EMAIL")) {
                connect(le, &QLineEdit::textChanged, [this] () { updateDN(); });
            }
            connect(le, &QLineEdit::textChanged, [this] () { checkRequirements(); });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: recipients()) {
	if (!IS_DE_VS(key) || keyValidity(key) < GpgME::UserID::Validity::Full) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto const buttonWidget = new QWidget;
```

#### AUTO 


```{c}
const auto key = KeyCache::instance()->findSubkeyByKeyGrip(info.grip);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i: m_results) {
            Q_EMIT q->verificationResult(i->verificationResult());
        }
```

#### AUTO 


```{c}
auto grp = comp->group(grpName);
```

#### AUTO 


```{c}
static auto accumulateNewOpenPGPKeys(const std::vector<ImportResultData> &results)
{
    return std::accumulate(std::begin(results), std::end(results),
                           std::vector<std::string>{},
                           [](auto &fingerprints, const auto &r) {
                               if (r.protocol == GpgME::OpenPGP) {
                                   fingerprints = accumulateNewKeys(fingerprints, r.result.imports());
                               }
                               return fingerprints;
                           });
}
```

#### AUTO 


```{c}
const auto it
            = s_wizards.find(id);
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::ImportPaperKeyCommand(subkey.parent());
```

#### AUTO 


```{c}
auto actionLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Recipient &r : std::as_const(recipients)) {
            addRecipient(r);
        }
```

#### AUTO 


```{c}
auto w = getFirstEnabledFocusWidget(d->mPlaceHolderWidget)
```

#### AUTO 


```{c}
auto exportJob = QGpgME::openpgp()->publicKeyExportJob();
```

#### LAMBDA EXPRESSION 


```{c}
[&fileName](const std::shared_ptr<Kleo::ChecksumDefinition> &cd) {
        if (!cd) {
            return false;
        }

        const QStringList &patterns = cd->patterns();
        return std::any_of(patterns.cbegin(), patterns.cend(), [&fileName](const QString &pattern) {
            const QRegularExpression re(QRegularExpression::anchoredPattern(pattern), s_regex_cs);
            return re.match(fileName).hasMatch();
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[learnBtn, learnLbl] () {
                learnLbl->setText(i18n("Certificates added to the certificate list."));
            }
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::DetailsCommand(parentKey[0], nullptr);
```

#### AUTO 


```{c}
auto input = Input::createFromByteArray(&mInputData,  i18n("Notepad"));
```

#### AUTO 


```{c}
auto subLay2 = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto backend = openpgp();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &k : recipients) {
            if (k.protocol() == GpgME::OpenPGP) {
                pgpRecipients.push_back(k);
            } else {
                cmsRecipients.push_back(k);
            }
        }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox{QDialogButtonBox::Retry | QDialogButtonBox::Ok, dialog};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fn : std::as_const(d->files)) {
        QFile in(fn);
        if (!in.open(QIODevice::ReadOnly)) {
            d->error(i18n("Could not open file %1 for reading: %2", in.fileName(), in.errorString()), i18n("Certificate Import Failed"));
            d->importResult(ImportResult(), fn);
            continue;
        }
        const GpgME::Protocol protocol = findProtocol(fn);
        if (protocol == GpgME::UnknownProtocol) {   //TODO: might use exceptions here
            d->error(i18n("Could not determine certificate type of %1.", in.fileName()), i18n("Certificate Import Failed"));
            d->importResult(ImportResult(), fn);
            continue;
        }
        d->startImport(protocol, in.readAll(), fn);
    }
```

#### AUTO 


```{c}
const auto filter = KeyFilterManager::instance()->keyFilterByID(notCertifiedKeysFilterId());
```

#### AUTO 


```{c}
auto action = q->actionCollection()->action(QStringLiteral("manage_smartcard"));
```

#### AUTO 


```{c}
auto defaultInvalidEntryErrorMessage()
{
    return i18n("Error: Enter a value in the correct format.");
}
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyRef] () { importCertificateFromCard(keyRef); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
                                          revokeUserID(userID);
                                      }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotMoveCurrentTabLeft(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: std::as_const(mRecpWidgets)) {
        if (edit->isEnabled() && !edit->isEmpty() && edit->key().isNull() && edit->group().isNull()) {
            unresolvedRecipients.push_back(edit->text().toHtmlEscaped());
        }
    }
```

#### AUTO 


```{c}
auto sigLay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto group = new QGroupBox{i18n("OpenPGP"), parent};
```

#### AUTO 


```{c}
const auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
auto btn = ui.buttonBox.button(QDialogButtonBox::Ok);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool state) {
        d->changed = state;
        updateButtons();
        if (QPushButton *button = buttonBox()->button(QDialogButtonBox::Reset)) {
            button->setEnabled(d->changed);
        }
    }
```

#### AUTO 


```{c}
const auto focusPolicy = active ? Qt::StrongFocus : Qt::ClickFocus;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        const QFileInfo fi(file);
        const QDir dir = fi.isDir() ? QDir(file) : fi.dir();
        dirs.insert(dir);
    }
```

#### AUTO 


```{c}
const auto &keyUid = keyUids[i];
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { openDetailsDialog(); }
```

#### AUTO 


```{c}
auto newGroup = KeyGroup();
```

#### AUTO 


```{c}
auto fixedFont = QFont(QStringLiteral("Monospace"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fpr: m_expandedKeys) {
        const KeyListModelInterface *km = dynamic_cast<const KeyListModelInterface*> (m_view->model());
        if (!km) {
            qCWarning(KLEOPATRA_LOG) << "invalid model";
            return;
        }
        const auto key = KeyCache::instance()->findByFingerprint(fpr.toLatin1().constData());
        if (key.isNull()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in cache";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        const auto idx = km->index(key);
        if (!idx.isValid()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in model";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        m_view->expand(idx);
    }
```

#### AUTO 


```{c}
auto wid = new ResultItemWidget(result);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            ui.userIDTable->setEnabled(true);
            // Trigger an update when done
            q->setKey(key);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[sender](const action_item &item) { return item.action == sender; }
```

#### LAMBDA EXPRESSION 


```{c}
[this, cmd]() {
                         ui.certifyBtn->setEnabled(true);
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto file: srcDir.entryList(QDir::Files)) {
        const QString srcName = src + QDir::separator() + file;
        const QString destName = dest + QDir::separator() + file;
        if(!QFile::copy(srcName, destName)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: key.userIDs()) {
            if (uid.isRevoked() || uid.isInvalid()) {
                // Skip user ID's that cannot really be certified.
                i++;
                continue;
            }
            QStandardItem *const item = new QStandardItem;
            item->setText(Formatting::prettyUserID(uid));
            item->setData(i, UserIDIndex);
            item->setCheckable(true);
            item->setEditable(false);
            item->setCheckState(Qt::Checked);
            appendRow(item);
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Line &line : lines) {
            const QLineEdit *le = line.edit;
            if (!le) {
                continue;
            }
            qCDebug(KLEOPATRA_LOG) << "requirementsAreMet(): checking \"" << line.attr << "\" against \"" << le->text() << "\":";
            if (le->text().trimmed().isEmpty()) {
                if (line.required) {
                    if (line.regex.isEmpty()) {
                        return xi18nc("@info", "<interface>%1</interface> is required, but empty.", line.label);
                    } else {
                        return xi18nc("@info", "<interface>%1</interface> is required, but empty.<nl/>"
                                      "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                    }
                }
            } else if (hasIntermediateInput(le)) {
                if (line.regex.isEmpty()) {
                    return xi18nc("@info", "<interface>%1</interface> is incomplete.", line.label);
                } else {
                    return xi18nc("@info", "<interface>%1</interface> is incomplete.<nl/>"
                                  "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                }
            } else if (!le->hasAcceptableInput()) {
                if (line.regex.isEmpty()) {
                    return xi18nc("@info", "<interface>%1</interface> is invalid.", line.label);
                } else {
                    return xi18nc("@info", "<interface>%1</interface> is invalid.<nl/>"
                                  "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                }
            }
        }
```

#### AUTO 


```{c}
const auto lastName = parts.takeLast();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &card: cards) {
            if (card->serialNumber() == mSerial) {
                const auto pgpCard = dynamic_cast<SmartCard::OpenPGPCard*>(card.get());
                Q_ASSERT(pgpCard);
                cardFound = true;
                if (slot == 1) {
                    existingKey = pgpCard->sigFpr();
                    break;
                }
                if (slot == 2) {
                    existingKey = pgpCard->encFpr();
                    encKeyWarning = i18n("It will no longer be possible to decrypt past communication "
                                         "encrypted for the existing key.");
                    break;
                }
                if (slot == 3) {
                    existingKey = pgpCard->authFpr();
                    break;
                }
                break;
            }
        }
```

#### AUTO 


```{c}
auto cmd = new Kleo::ImportCertificateFromDataCommand(mInputData, mImportProto);
```

#### AUTO 


```{c}
const auto it = mementos().find(tag);
```

#### AUTO 


```{c}
const auto pivCard = std::dynamic_pointer_cast<PIVCard>(card);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    restartAtEnterDetailsPage();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : patterns)
                if (QRegExp(pattern, fs_cs).exactMatch(fileName)) {
                    return cd;
                }
```

#### AUTO 


```{c}
auto info = gpgagent_statuslines(gpg_agent, "SCD LEARN --force", err);
```

#### AUTO 


```{c}
auto it = std::find_if(std::cbegin(jobs), std::cend(jobs),
                           [finishedJob](const auto &job) { return job.job == finishedJob; });
```

#### AUTO 


```{c}
auto technicalTab = new ScrollArea{tabWidget};
```

#### AUTO 


```{c}
auto action = d->currentPageActions.get(Actions::Close)
```

#### LAMBDA EXPRESSION 


```{c}
[] () {
                qCDebug(KLEOPATRA_LOG) << "Learn command finished.";
            }
```

#### AUTO 


```{c}
auto mailLabel = new QLabel(i18n("EMail:"));
```

#### AUTO 


```{c}
auto groupLayout = new QVBoxLayout{group};
```

#### AUTO 


```{c}
const auto key = certificateLineEdit->key();
```

#### AUTO 


```{c}
auto protocol = key.protocol() == GpgME::CMS ?
                                      QGpgME::smime() : QGpgME::openpgp();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                doDecryptVerify();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const action_item &item) { return item.action == q->sender(); }
```

#### AUTO 


```{c}
const auto data = process()->readAllStandardOutput();
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::AddUserIDCommand(key);
```

#### AUTO 


```{c}
auto pivCard = ReaderStatus::instance()->getCard<PIVCard>(d->serialNumber());
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *MoveLeft = "window_move_tab_left";
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &error) {
            dialog->setNksPinSettingResult(error);
        }
```

#### AUTO 


```{c}
const auto allIds = std::accumulate(std::cbegin(results), std::cend(results),
                                        std::set<QString>{},
                                        [](auto &allIds, const auto &r) {
                                            allIds.insert(r.id);
                                            return allIds;
                                        });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotDialogRejected(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { showSmartcardView(); }
```

#### AUTO 


```{c}
auto algoString = split[1];
```

#### AUTO 


```{c}
auto dlg = new GroupDetailsDialog;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { keyCacheUpdated(); }
```

#### AUTO 


```{c}
const auto it = std::find_if(actions.cbegin(), actions.cend(),
                                 [sender](const action_item &item) { return item.action == sender; });
```

#### LAMBDA EXPRESSION 


```{c}
[](ChecksumCreateFilesCommand*){}
```

#### AUTO 


```{c}
auto const dlg = new CertificateSelectionDialog(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            restoreExpandState();
            if (!m_onceResized) {
                m_onceResized = true;
                resizeColumns();
            }
        }
```

#### AUTO 


```{c}
auto w = findChild<TrustChainWidget*>();
```

#### LAMBDA EXPRESSION 


```{c}
[] (auto domains, const auto &signature) {
            if (isGood(signature) && signature.isTrustSignature()) {
                domains.insert(Formatting::trustSignatureDomain(signature));
            }
            return domains;
        }
```

#### AUTO 


```{c}
auto myLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { ui.subkeysTree->setEnabled(true); }
```

#### AUTO 


```{c}
auto glay = new QGridLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &v) {
        return v && !v->parent();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                ui.userIDTable->setEnabled(true);
                // Trigger an update when done
                q->setKey(key);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Line &line : list) {
        const QLineEdit *le = line.edit;
        if (!le) {
            continue;
        }
        const QString key = line.attr;
        qCDebug(KLEOPATRA_LOG) << "requirementsAreMet(): checking \"" << key << "\" against \"" << le->text() << "\":";
        if (le->text().trimmed().isEmpty()) {
            if (key.endsWith(QLatin1Char('!'))) {
                if (line.regex.isEmpty()) {
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.", line.label);
                } else
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.<nl/>"
                                   "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                return false;
            }
        } else if (has_intermediate_input(le)) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else if (!le->hasAcceptableInput()) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is invalid.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is invalid.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        }
        qCDebug(KLEOPATRA_LOG) << "ok";
    }
```

#### AUTO 


```{c}
const auto choice = KMessageBox::warningContinueCancel(parentWidgetOrView(), message,
            i18nc("@title:window", "Create OpenPGP Key"),
            KStandardGuiItem::cont(), KStandardGuiItem::cancel(), QString(), KMessageBox::Notify);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (unsigned int /*slot*/) {
                const auto cards = ReaderStatus::instance()->getCards();
                if (!cards.size()) {
                    setCard(std::shared_ptr<Card>(new Card()));
                } else {
                    // No support for multiple reader / cards currently
                    setCard(cards[0]);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[infoBtn] () {
            const QString msg = i18n("You can use this to add additional info to a "
                                     "certification.") + QStringLiteral("<br/><br/>") +
                                     i18n("Tags created by anyone with full certification trust "
                                          "are shown in the keylist and can be searched.");
            QToolTip::showText(infoBtn->mapToGlobal(QPoint()) + QPoint(infoBtn->width(), 0),
                               msg, infoBtn, QRect(), 30000);
        }
```

#### AUTO 


```{c}
auto end = std::remove_if(result.begin(), result.end(),
                              [](const Key &key) { return key.canEncrypt(); });
```

#### AUTO 


```{c}
const auto m = q->mementoContent< std::shared_ptr<NewSignEncryptEMailController> >(NewSignEncryptEMailController::mementoName());
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(q);
```

#### AUTO 


```{c}
const auto outpath = outDir.absoluteFilePath(fi.fileName());
```

#### AUTO 


```{c}
const auto labelText = templ.arg(welcome).arg(introduction).arg(keyExplanation).arg(privateKeyExplanation).arg(publicKeyExplanation).arg(learnMore);
```

#### AUTO 


```{c}
const auto key = parse_keypairinfo_and_lookup_key(klc.get(), info);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                mAdvancedSelected = true;
                q->accept();
            }
```

#### AUTO 


```{c}
auto algorithm
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { generateKey(PIVCard::digitalSignatureKeyRef()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &card: ReaderStatus::instance()->getCards()) {
        if (card->appName() == OpenPGPCard::AppName) {
            suitableCards.push_back(card);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { exportClicked(); }
```

#### AUTO 


```{c}
const auto ids = m_idsByFingerprint[it->fingerprint()];
```

#### AUTO 


```{c}
const auto newErrorMessage = decoratedError(errorMessage());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: std::as_const(mRecpWidgets)) {
        if (edit->isEnabled() && !edit->hasAcceptableInput()) {
            if (!firstUnresolvedRecipient) {
                firstUnresolvedRecipient = edit;
            }
            unresolvedRecipients.push_back(edit->text().toHtmlEscaped());
        }
    }
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout(top);
```

#### AUTO 


```{c}
const auto pgpSigFpr = card->appKeyFingerprint(OpenPGPCard::pgpSigKeyRef());
```

#### AUTO 


```{c}
auto mainWidget = new QWidget{q};
```

#### AUTO 


```{c}
auto reqLB = qobject_cast<QLabel *>(l->itemAtPosition(row, 2)->widget());
```

#### AUTO 


```{c}
auto action = actions.get(Actions::Rename)
```

#### AUTO 


```{c}
auto toolbarButtons = toolbar->findChildren<QToolButton*>();
```

#### AUTO 


```{c}
const auto &uid = uids[i];
```

#### AUTO 


```{c}
const auto statusCb = [this](const QString &str, VerifyChecksumsDialog::Status st) { Q_EMIT status(str, st); };
```

#### AUTO 


```{c}
auto caption = new QLabel(i18nc("Caption for an unknwon key/certificate where only ID is known.",
                              "Unknown Recipient:"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->exportClicked(); }
```

#### AUTO 


```{c}
auto statusLbl = new QLabel(i18nc("Compliance means that GnuPG is running in a more restricted mode e.g. to handle restricted documents.",
                                        // The germans want some extra sausage
                                        "Compliance: %1", complianceMode == QStringLiteral("de-vs") ? QStringLiteral ("VS-NfD") : complianceMode));
```

#### AUTO 


```{c}
auto coll = new KActionCollection(q);
```

#### AUTO 


```{c}
const auto groups = readKeyGroups(path);
```

#### AUTO 


```{c}
auto b = new QToolButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag: uid.remarks(Tags::tagKeys(), err)) {
            if (err) {
                qCWarning(KLEOPATRA_LOG) << "Getting remarks for user id" << uid.id() << "failed:" << err;
            }
            tagList << QString::fromStdString(tag);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : results) {
                if (importFailed(r)) {
                    showError(r.result.error(), r.id);
                }
            }
```

#### AUTO 


```{c}
auto comments = QStringLiteral("Comment: ");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        Q_EMIT q->retry();
        q->done(-1); // neither Accepted nor Rejected
    }
```

#### AUTO 


```{c}
const auto decVerifyTask = qobject_cast<AbstractDecryptVerifyTask*> (task.data());
```

#### LAMBDA EXPRESSION 


```{c}
[&baseDir](const QString &file) {
                       return baseDir.relativeFilePath(file);
                   }
```

#### AUTO 


```{c}
const auto &cardApp
```

#### AUTO 


```{c}
auto icon = KleopatraApplication::instance()->sysTrayIcon();
```

#### AUTO 


```{c}
auto vlay = new QVBoxLayout();
```

#### AUTO 


```{c}
const auto &scheme
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        keyParameters = detailsDialog->keyParameters();
        protectKeyWithPassword = detailsDialog->protectKeyWithPassword();
        QMetaObject::invokeMethod(
            q,
            [this] {
                createCertificate();
            },
            Qt::QueuedConnection);
    }
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox{i18nc("@title:group", "Key Material"), technicalTab};
```

#### AUTO 


```{c}
auto it = dirs.begin();
```

#### AUTO 


```{c}
const auto backend = (protocol == GpgME::OpenPGP) ? QGpgME::openpgp() : QGpgME::smime();
```

#### LAMBDA EXPRESSION 


```{c}
[&s](const QRegularExpression &rx) { return rx.match(s).hasMatch(); }
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto userIds = userId.parent().userIDs();
```

#### AUTO 


```{c}
auto groupKeysLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto gridLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto cmd = new ChangePinCommand(mCardSerialNumber, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawLine : std::as_const(trustListFileContents)) {

        const QString line = QString::fromLatin1(rawLine.data(), rawLine.size());
        const QRegularExpressionMatch match = rx.match(line);
        if (!match.hasMatch()) {
            qCDebug(KLEOPATRA_LOG) << "line \"" << rawLine.data() << "\" does not match";
            out.write(rawLine + '\n');
            continue;
        }
        const QString cap2 = match.captured(2);
        if (cap2 != key && cap2 != keyColon) {
            qCDebug(KLEOPATRA_LOG) << qPrintable(key) << " != "
                                   << qPrintable(cap2) << " != "
                                   << qPrintable(keyColon);
            out.write(rawLine + '\n');
            continue;
        }
        found = true;
        const bool disabled = match.capturedView(1) == QLatin1Char('!');
        const QByteArray flags = match.captured(3).toLatin1();
        const QByteArray rests = match.captured(4).toLatin1();
        if (trust == Key::Ultimate)
            if (!disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write(keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        else if (trust == Key::Never) {
            if (disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write('!' + keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        }
        // else: trust == Key::Unknown
        // -> don't write - ie.erase
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : selectedEntries) {
        m_listWidget->removeEntry(i);
    }
```

#### AUTO 


```{c}
auto encBox = new QGroupBox(i18nc("@action", "Encrypt"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            mNKSBtn->setEnabled(false);
            doChangePin(false);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { doChangePin(NetKeyCard::nksPinKeyRef()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &k : recipients) {
            if (pgp && cms) {
                break;
            }
            if (k.protocol() == Protocol::OpenPGP) {
                pgp = true;
            } else {
                cms = true;
            }
        }
```

#### AUTO 


```{c}
auto btn = new QPushButton;
```

#### AUTO 


```{c}
const auto decResult = dvResult->decryptionResult();
```

#### AUTO 


```{c}
const auto chain = Kleo::KeyCache::instance()->findIssuers(key,
                            Kleo::KeyCache::RecursiveSearch | Kleo::KeyCache::IncludeSubject);
```

#### AUTO 


```{c}
const auto pivCard = SmartCard::ReaderStatus::instance()->getCard<PIVCard>(serialNumber());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entryName: grp->entryList()) {
                auto entry = grp->entry(entryName);
                if (!entry) {
                    qCWarning(KLEOPATRA_LOG) << "Failed to find entry:" << entry << "in group:"<< grp << "in component:" << compName;
                    return;
                }
                entry->resetToDefault();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: qAsConst(mRecpWidgets)) {
        if (!edit->isEmpty() && edit->key().isNull() && edit->group().isNull()) {
            KMessageBox::error(this, i18nc("%1 is user input that could not be found",
                        "Could not find a key for '%1'", edit->text().toHtmlEscaped()),
                    i18n("Failed to find recipient"), KMessageBox::Notify);
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : std::as_const(attrOrder)) {
        const QString key = rawKey.trimmed().toUpper();
        const QString attr = attributeFromKey(key);
        if (attr.isEmpty()) {
            continue;
        }
        const QString preset = savedValues.value(attr, config.readEntry(attr, QString()));
        const bool required = key.endsWith(QLatin1Char('!'));
        const bool readonly = config.isEntryImmutable(attr);
        const QString label = config.readEntry(attr + QLatin1String("_label"),
                                               attributeLabel(attr, pgp()));
        const QString regex = config.readEntry(attr + QLatin1String("_regex"));

        int row;
        bool known = true;
        QValidator *validator = nullptr;
        if (attr == QLatin1String("EMAIL")) {
            row = row_index_of(ui.emailLE, ui.gridLayout);
            validator = regex.isEmpty() ? Validation::email() : Validation::email(QRegExp(regex));
        } else if (attr == QLatin1String("NAME") || attr == QLatin1String("CN")) {
            if ((pgp() && attr == QLatin1String("CN")) || (!pgp() && attr == QLatin1String("NAME"))) {
                continue;
            }
            if (pgp()) {
                validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(QRegExp(regex));
            }
            row = row_index_of(ui.nameLE, ui.gridLayout);
        } else {
            known = false;
            row = add_row(ui.gridLayout, &dynamicWidgets);
        }
        if (!validator && !regex.isEmpty()) {
            validator = new QRegExpValidator(QRegExp(regex), nullptr);
        }

        QLineEdit *le = adjust_row(ui.gridLayout, row, label, preset, validator, readonly, required);

        const Line line = { key, label, regex, le };
        lines[row] = line;

        if (!known) {
            widgets.push_back(le);
        }

        // don't connect twice:
        disconnect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
        connect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &fingerprints, const auto &r) {
                               if (r.protocol == GpgME::OpenPGP) {
                                   fingerprints = accumulateNewKeys(fingerprints, r.result.imports());
                               }
                               return fingerprints;
                           }
```

#### AUTO 


```{c}
const auto parentKey = KeyCache::instance()->findIssuers(key, KeyCache::NoOption);
```

#### LAMBDA EXPRESSION 


```{c}
[this, cmd]() {
                         ui.changePassphraseBtn->setEnabled(true);
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sig: result.signatures()) {
        // Update key information
        sig.key(true, true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[detailsDlg] () {
            if (detailsDlg) {
                detailsDlg->show();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { editGroup(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(Kleo::KeyListModelInterface::KeyRole).value<GpgME::Key>();
        const auto fpr = QString::fromLatin1(key.primaryFingerprint());

        if (m_expandedKeys.contains(fpr)) {
            return;
        }
        m_expandedKeys << fpr;
        auto grp = KSharedConfig::openConfig()->group("KeyTreeView");
        grp.writeEntry("Expanded", m_expandedKeys);
    }
```

#### AUTO 


```{c}
auto createInfoButton(const QString &text, QWidget *parent)
{
    auto infoBtn = new QPushButton{parent};
    infoBtn->setIcon(QIcon::fromTheme(QStringLiteral("help-contextual")));
    infoBtn->setFlat(true);

    QObject::connect(infoBtn, &QPushButton::clicked, infoBtn, [infoBtn, text] () {
        QToolTip::showText(infoBtn->mapToGlobal(QPoint()) + QPoint(infoBtn->width(), 0),
                           text, infoBtn, QRect(), 30000);
    });

    return infoBtn;
}
```

#### AUTO 


```{c}
const auto lastDir = config.readEntry("LastDirectory", QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        result += QFile::encodeName(file);
        result += sep;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : filesToImportGroupsFrom) {
        const bool certificateImportSucceeded =
            std::any_of(std::cbegin(results), std::cend(results),
                        [path](const auto &r) {
                            return r.id == path && !importFailed(r) && !importWasCanceled(r);
                        });
        if (certificateImportSucceeded) {
            qCDebug(KLEOPATRA_LOG) << __func__ << "Importing groups from file" << path;
            const auto groups = readKeyGroups(path);
            std::transform(std::begin(groups), std::end(groups),
                           std::back_inserter(importedGroups),
                           [path](const auto &group) {
                               return storeGroup(group, path);
                           });
        }
        increaseProgressValue();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { slotPageTitleChanged(text); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int err, const QString &details) { done(err, details); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImportResult &result : std::as_const(results)) {
        const auto imports = result.imports();
        for (const Import &import : imports) {
            if (!import.fingerprint()) {
                continue;
            }
            fingerprints << QString::fromLatin1(import.fingerprint());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const CertsVec &certs) { slotSaveAsRequested(certs); }
```

#### AUTO 


```{c}
const auto protocol = key.protocol();
```

#### LAMBDA EXPRESSION 


```{c}
[proc] () {
        while (proc->canReadLine()) {
            const QString line = QString::fromLocal8Bit(proc->readLine()).trimmed();
            // Command-fd is a stable interface, while this is all kind of hacky we
            // are on a deadline :-/
            if (line == QStringLiteral("[GNUPG:] GET_BOOL gen_revoke.okay")) {
                proc->write("y\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_LINE ask_revocation_reason.code")) {
                proc->write("0\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_LINE ask_revocation_reason.text")) {
                proc->write("\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_BOOL openfile.overwrite.okay")) {
                // We asked before
                proc->write("y\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_BOOL ask_revocation_reason.okay")) {
                proc->write("y\n");
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                certificationsTV->setEnabled(true);
                // Trigger an update when done
                q->setKey(key);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                }
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::LookupCertificatesCommand(mKeyID, nullptr);
```

#### AUTO 


```{c}
const auto index = after ? mRecpLayout->indexOf(after) + 1 : mRecpLayout->count();
```

#### AUTO 


```{c}
const auto &connection
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : cds) {
        mChecksumDefinitionCB->addItem(cd->label(), qVariantFromValue(cd));
        if (cd == default_cd) {
            mChecksumDefinitionCB->setCurrentIndex(mChecksumDefinitionCB->count() - 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Sender &sender) { return count_encrypt_certificates(proto, sender) >= 1; }
```

#### AUTO 


```{c}
auto cmd = new AuthenticatePIVCardApplicationCommand(serialNumber(), parentWidgetOrView());
```

#### AUTO 


```{c}
const auto key = lookup_key(klc.get(), info.grip);
```

#### AUTO 


```{c}
const auto verifyResult = dvResult->verificationResult();
```

#### AUTO 


```{c}
const auto bb = new QDialogButtonBox();
```

#### LAMBDA EXPRESSION 


```{c}
[this](ImportResult result, QString, Error) {
        if (result.error()) {
            d->error(result.error().asString(), errorCaption());
            finished();
            return;
        }
        if (!result.numSecretKeysImported() ||
            (result.numSecretKeysUnchanged() == result.numSecretKeysImported())) {
            d->error(i18n("Failed to restore any secret keys."), errorCaption());
            finished();
            return;
        }

        // Refresh the key after success
        auto key = d->key();
        key.update();
        KeyCache::mutableInstance()->insert(key);
        finished();
        return;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.addUserIDBtn->setEnabled(true);
                     }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info: card->keyInfos()) {
        const auto key = KeyCache::instance()->findSubkeyByKeyGrip(info.grip);
        if (key.isNull()) {
            mCMSKeysSection->setVisible(true);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[serialNumber, appName] (const std::shared_ptr<Card> &card) {
                            return card->serialNumber() == serialNumber && card->appName() == appName;
                        }
```

#### AUTO 


```{c}
static auto accumulateNewKeys(std::vector<std::string> &fingerprints, const std::vector<GpgME::Import> &imports)
{
    return std::accumulate(std::begin(imports), std::end(imports),
                           fingerprints,
                           [](auto &fingerprints, const auto &import) {
                               if (import.status() == Import::NewKey) {
                                   fingerprints.push_back(import.fingerprint());
                               }
                               return fingerprints;
                           });
}
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey, card]() {
                    auto cmd = new Kleo::Commands::KeyToCardCommand(subkey, card->serialNumber(), card->appName());
                    ui.subkeysTree->setEnabled(false);
                    connect(cmd, &Kleo::Commands::KeyToCardCommand::finished,
                            q, [this]() { ui.subkeysTree->setEnabled(true); });
                    cmd->setParentWidget(q);
                    cmd->start();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            protocol = GpgME::OpenPGP;
            q->accept();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (std::shared_ptr<Task> i : std::as_const(d->m_runnableTasks)) {
        connectTask(i);
        tsks.push_back(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[importButton]() {
                importButton->setEnabled(true);
            }
```

#### AUTO 


```{c}
const auto description = errorShown ? accessibleDescription() + QLatin1String{" "} + mErrorLabel->accessibleName()
                                        : accessibleDescription();
```

#### AUTO 


```{c}
auto action = q->actionCollection()->action(QStringLiteral("view_certificate_overview"))
```

#### AUTO 


```{c}
auto cmd = new CreateOpenPGPKeyFromCardKeysCommand(mCardSerialNumber, PIVCard::AppName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : indexes) {
        if (idx.isValid()) {
            view->selectionModel()->select(idx, QItemSelectionModel::Select | QItemSelectionModel::Rows);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &g) { return !g.isNull() && !g.isImmutable(); }
```

#### AUTO 


```{c}
const auto file
```

#### LAMBDA EXPRESSION 


```{c}
[](auto btn) {
                                  return btn && btn->isEnabled() && btn->isChecked();
                              }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                createCertificate();
            }
```

#### AUTO 


```{c}
auto recipientScroll = new QScrollArea;
```

#### LAMBDA EXPRESSION 


```{c}
[](const CardInfo &ci) { return ci.status == CardCanLearnKeys; }
```

#### AUTO 


```{c}
auto nkCard = new NetKeyCard(*ci);
```

#### AUTO 


```{c}
const auto pgpCard = ReaderStatus::instance()->getCard<OpenPGPCard>(mSerial);
```

#### LAMBDA EXPRESSION 


```{c}
[](DecryptVerifyClipboardCommand*){}
```

#### AUTO 


```{c}
const auto insertIndex = widget->hasErrorResult() ? m_lastErrorItemIndex++ : scrollAreaLayout->count() - 1;
```

#### AUTO 


```{c}
auto config = QGpgME::cryptoConfig();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : attrOrder) {
            const QString key = rawKey.trimmed().toUpper();
            const QString attr = attributeFromKey(key);
            if (attr.isEmpty()) {
                continue;
            }
            const QString defaultPreset = (attr == QLatin1String("CN")) ? userFullName() :
                                          (attr == QLatin1String("EMAIL")) ? userEmailAddress() :
                                          QString();
            const QString preset = config.readEntry(attr, defaultPreset);
            const bool required = key.endsWith(QLatin1Char('!'));
            const bool readonly = config.isEntryImmutable(attr);
            const QString label = config.readEntry(attr + QLatin1String("_label"),
                                                   attributeLabel(attr));
            const QString regex = config.readEntry(attr + QLatin1String("_regex"));

            QValidator *validator = nullptr;
            if (attr == QLatin1String("EMAIL")) {
                validator = regex.isEmpty() ? Validation::email() : Validation::email(QRegExp(regex));
            } else if (!regex.isEmpty()) {
                validator = new QRegExpValidator(QRegExp(regex), nullptr);
            }

            QLineEdit *le = addRow(ui.gridLayout, label, preset, validator, readonly, required);

            const Line line = { attr, label, regex, le, required };
            ui.lines.push_back(line);

            if (attr != QLatin1String("EMAIL")) {
                connect(le, &QLineEdit::textChanged, [this] () { updateDN(); });
            }
            connect(le, &QLineEdit::textChanged, [this] () { checkRequirements(); });
        }
```

#### AUTO 


```{c}
const auto it
            = std::find_if(ads.begin(), ads.end(), FindExtension(extension, proto));
```

#### AUTO 


```{c}
const auto matchingOldCard = std::find_if(oldCards.cbegin(), oldCards.cend(),
                        [serialNumber, appName] (const std::shared_ptr<Card> &card) {
                            return card->serialNumber() == serialNumber && card->appName() == appName;
                        });
```

#### LAMBDA EXPRESSION 


```{c}
[&s](const QRegExp &rx) { return rx.exactMatch(s); }
```

#### AUTO 


```{c}
auto expander = new AnimatedExpander{i18n("Advanced"), q};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info: infos) {
        const auto key = parse_keypairinfo_and_lookup_key(klc.get(), info);
        if (key.isNull()) {
            setCanLearnKeys(true);
        }
        mKeys.push_back(key);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        mLearnKeysBtn->setEnabled(false);
        auto cmd = new LearnCardKeysCommand(GpgME::CMS);
        cmd->setParentWidget(this);
        cmd->start();

        auto icon = KleopatraApplication::instance()->sysTrayIcon();
        if (icon) {
            icon->setLearningInProgress(true);
        }

        connect(cmd, &Command::finished, this, [icon] () {
            ReaderStatus::mutableInstance()->updateStatus();
            icon->setLearningInProgress(false);
        });
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(sumfiles.cbegin(), sumfiles.cend(),
                                         sumfile_contains_file(dir, fileName));
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Line &line : ui.lines ) {
            const QString text = line.edit->text().trimmed();
            if (text.isEmpty()) {
                continue;
            }
            QString attr = attributeFromKey(line.attr);
            if (attr == QLatin1String("EMAIL")) {
                continue;
            }
            if (const char *const oid = oidForAttributeName(attr)) {
                attr = QString::fromUtf8(oid);
            }
            dn.append(DN::Attribute(attr, text));
        }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto req = new FileNameRequester(forKind == SignEncryptFilesWizard::Directory ?
                                                       QDir::Dirs : QDir::Files, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { importCanceled(); }
```

#### AUTO 


```{c}
const auto holder = card->cardHolder();
```

#### AUTO 


```{c}
auto descriptionToLines(const QString &description)
{
    std::vector<std::string> lines;
    if (!description.isEmpty()) {
        lines = toStdStrings(description.split(QLatin1Char('\n')));
    }
    return lines;
}
```

#### AUTO 


```{c}
auto job = get_receive_keys_job(protocol);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout{dnsGB};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (parseCardInfo(pair.first, pair.second)) {
            continue;
        }
        if (pair.first == "KEY-FPR" ||
            pair.first == "KEY-TIME") {
            // Key fpr and key time need to be distinguished, the number
            // of the key decides the usage.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[0];
            const auto fpr = values[1].toStdString();
            if (usage == QLatin1Char('1')) {
                mMetaInfo.insert(std::string("SIG") + pair.first, fpr);
            } else if (usage == QLatin1Char('2')) {
                mMetaInfo.insert(std::string("ENC") + pair.first, fpr);
            } else if (usage == QLatin1Char('3')) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, fpr);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else if (pair.first == "KEYPAIRINFO") {
            // Fun, same as above but the other way around.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[1];
            const auto grip = values[0].toStdString();
            if (usage == QLatin1String("OPENPGP.1")) {
                mMetaInfo.insert(std::string("SIG") + pair.first, grip);
            } else if (usage == QLatin1String("OPENPGP.2")) {
                mMetaInfo.insert(std::string("ENC") + pair.first, grip);
            } else if (usage == QLatin1String("OPENPGP.3")) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, grip);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[dlg] () {
            dlg->accept();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &k) { return k.subkey(0).isSecret() && !k.subkey(0).isCardKey(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : results) {
        if (r.protocol == GpgME::CMS && r.type == ImportType::External && !importFailed(r)) {
            const auto imports = r.result.imports();
            std::for_each(std::begin(imports), std::end(imports), &validateImportedCertificate);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { slotProcessReadyReadStandardOutput(); }
```

#### AUTO 


```{c}
auto output = Output::createFromByteArray(&mOutputData, i18n("Notepad"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, task] (const std::shared_ptr<const Kleo::Crypto::Task::Result> &result) {
                qCDebug(KLEOPATRA_LOG) << "Encrypt / Sign done. Err:" << result->errorCode();
                task->deleteLater();
                cryptDone(result);
            }
```

#### AUTO 


```{c}
const auto pgpCard = SmartCard::ReaderStatus::instance()->getCard<OpenPGPCard>(mSerial);
```

#### AUTO 


```{c}
auto cmd = new Kleo::ReloadKeysCommand(nullptr);
```

#### AUTO 


```{c}
auto infoBtn = createInfoButton(i18n("You can use this to add additional info to a certification.") +
                                            QStringLiteral("<br/><br/>") +
                                            i18n("Tags created by anyone with full certification trust "
                                                "are shown in the keylist and can be searched."),
                                            q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: mTarget.userIDs()) {
                GpgME::Error err;
                const char *c_remark = uid.remark(remarkKey, err);
                if (c_remark) {
                    const QString candidate = QString::fromUtf8(c_remark);
                    if (candidate != remark) {
                        qCDebug(KLEOPATRA_LOG) << "Different remarks on user ids. Taking last.";
                        remark = candidate;
                        uidsWithRemark.clear();
                    }
                    uidsWithRemark.push_back(uid);
                }
            }
```

#### AUTO 


```{c}
auto assuanContext = std::shared_ptr<Context>(c.release());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Protocol i : supportedProtocols()) {
        auto const b = new QCheckBox;
        b->setText(formatLabel(i, Key()));
        m_buttons[i] = b;
        layout->addWidget(b);
        m_buttonGroup->addButton(b);
    }
```

#### AUTO 


```{c}
auto ret = new NetKeyCard();
```

#### AUTO 


```{c}
auto bar = recipientScroll->verticalScrollBar();
```

#### AUTO 


```{c}
const auto secretKey = secKey();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : std::as_const(indexes)) {
        if (idx.isValid()) {
            sm->select(idx, QItemSelectionModel::Select | QItemSelectionModel::Rows);
        }
    }
```

#### AUTO 


```{c}
const auto subkey = item->data(0, Qt::UserRole).value<GpgME::Subkey>();
```

#### AUTO 


```{c}
const auto totalConsidered = std::accumulate(std::cbegin(results), std::cend(results),
                                                 0,
                                                 [](auto totalConsidered, const auto &r) {
                                                     return totalConsidered + r.result.numConsidered();
                                                 });
```

#### AUTO 


```{c}
auto caption = new QLabel(i18nc("Caption for an unknown key/certificate where only ID is known.",
                              "Unknown Recipient:"));
```

#### AUTO 


```{c}
auto sigGrp = new QGroupBox(i18nc("@title:group", "Prove authenticity (sign)"));
```

#### AUTO 


```{c}
const auto additionalServers = readKeyserverConfigs(legacyEntry);
```

#### AUTO 


```{c}
const auto isKeyboardFocusEvent = reason == Qt::TabFocusReason
                                    || reason == Qt::BacktabFocusReason
                                    || reason == Qt::ShortcutFocusReason;
```

#### AUTO 


```{c}
auto toolbarChildren = toolbar->findChildren<QWidget*>();
```

#### AUTO 


```{c}
auto appName = scd_getattr_status(gpgAgent, "APPTYPE", err);
```

#### AUTO 


```{c}
auto emailLbl = new QLabel(i18n("EMail") + QLatin1Char(':'));
```

#### AUTO 


```{c}
auto waitWidget = new WaitWidget(this);
```

#### AUTO 


```{c}
const auto man_gpg = new DocAction(QIcon::fromTheme(QStringLiteral("help-hint")), i18n("GnuPG Manual"),
            QStringLiteral("gnupg.pdf"), QStringLiteral("../share/doc/gnupg"));
```

#### AUTO 


```{c}
auto fixedFont = QFont("Monospace", 10);
```

#### AUTO 


```{c}
auto lookUpBtn = new QPushButton(i18n("Search"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(KeyList::KeyRole).value<GpgME::Key>();
        if (key.isNull()) {
            return;
        }
        const auto fpr = QString::fromLatin1(key.primaryFingerprint());

        if (m_expandedKeys.contains(fpr)) {
            return;
        }
        m_expandedKeys << fpr;
        if (m_group.isValid()) {
            m_group.writeEntry("Expanded", m_expandedKeys);
        }
    }
```

#### AUTO 


```{c}
const auto newErrorMessage = decoratedError(errorMessage(mError));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotRenameCurrentTab(); }
```

#### AUTO 


```{c}
const auto idx = km->index(key);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dns : dnsN) {
            keyParameters.addDomainName(dns);
        }
```

#### AUTO 


```{c}
const auto subkeys = KeyCache::instance()->findSubkeysByKeyID({keyid});
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
            auto cmd = new Kleo::Commands::CertifyCertificateCommand(userID);
            cmd->setParentWidget(q);
            certificationsTV->setEnabled(false);
            connect(cmd, &Kleo::Commands::CertifyCertificateCommand::finished,
                    q, [this]() {
                certificationsTV->setEnabled(true);
                // Trigger an update when done
                q->setKey(key);
            });
            cmd->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, id](const QString &newName) {
                mOutNames[id] = newName;
            }
```

#### AUTO 


```{c}
auto cmd = new KeyToCardCommand(subkey);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &error) {
            dialog->setSigGPinSettingResult(error);
        }
```

#### AUTO 


```{c}
auto le = new QLineEdit(this);
```

#### AUTO 


```{c}
static const auto maxConnectionAttempts = 10;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        parseCardInfo(pair.first, pair.second);
    }
```

#### AUTO 


```{c}
const auto &keyId
```

#### AUTO 


```{c}
auto servers = readKeyserverConfigs(newEntry);
```

#### AUTO 


```{c}
auto detailsLabel = new HtmlLabel;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->updateOkButton(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *opt : std::as_const(options)) {
        std::string line = "OPTION ";
        line += opt;
        if (const gpg_error_t err = assuan_transact(ctx, line.c_str(), nullptr, nullptr, nullptr, nullptr, nullptr, nullptr)) {
            qDebug("%s", Exception(err, line).what());
            return 1;
        }
    }
```

#### AUTO 


```{c}
auto action = actions.get(Actions::Duplicate)
```

#### AUTO 


```{c}
auto actionLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit: mRecpWidgets) {
        const auto editKey = edit->key();
        if (key.isNull() && editKey.isNull()) {
            recpRemovalRequested(edit);
            return;
        }
        if (editKey.primaryFingerprint() &&
            key.primaryFingerprint() &&
            !strcmp(editKey.primaryFingerprint(), key.primaryFingerprint())) {
            recpRemovalRequested(edit);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : results) {
        if (r.protocol == GpgME::CMS && r.type == ImportType::External
                && !importFailed(r) && !importWasCanceled(r)) {
            const auto imports = r.result.imports();
            std::for_each(std::begin(imports), std::end(imports), &validateImportedCertificate);
        }
    }
```

#### AUTO 


```{c}
const auto &tag
```

#### AUTO 


```{c}
auto verticalSpacer = new QSpacerItem{20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding};
```

#### AUTO 


```{c}
const auto attachmentPath = attachment.filePath();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QPoint &p) {
                    contextMenuRequested(p);
                }
```

#### AUTO 


```{c}
const auto embedFileName = QString::fromUtf8(res.fileName()).toHtmlEscaped();
```

#### AUTO 


```{c}
const auto usage = values[1];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &groupName : groupNames) {
        const CryptoConfigGroup *const group = comp ? comp->group(groupName) : nullptr;
        if (CryptoConfigEntry *const entry = group->entry(QString::fromLatin1(entryName))) {
            return entry;
        }
    }
```

#### AUTO 


```{c}
const auto it = m_labels.find(p);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { addUserID(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &key: qAsConst(mAddedKeys)) {
        removeRecipient(key);
    }
```

#### AUTO 


```{c}
auto label = new QLabel{i18n("Smart card reader to use:"), this};
```

#### AUTO 


```{c}
auto action = actions.get(Actions::MoveLeft)
```

#### AUTO 


```{c}
auto fileGrp = new QGroupBox(i18n("File Operations"));
```

#### AUTO 


```{c}
auto signerLayout = new QGridLayout(signingCertificateBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                // queue the call of editFinished() to ensure that QCompleter::activated is handled first
                QMetaObject::invokeMethod(q, [this]() { editFinished(); }, Qt::QueuedConnection);
            }
```

#### AUTO 


```{c}
const auto decryptVerifyResult = dynamic_cast<const Kleo::Crypto::DecryptVerifyResult*>(result.get());
```

#### AUTO 


```{c}
const auto entry = getCryptoConfigEntry(conf, "gpg-agent", "enforce-passphrase-constraints");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : std::as_const(attrOrder)) {
        const QString key = rawKey.trimmed().toUpper();
        const QString attr = attributeFromKey(key);
        if (attr.isEmpty()) {
            continue;
        }
        const QString preset = savedValues.value(attr, config.readEntry(attr, QString()));
        const bool required = key.endsWith(QLatin1Char('!'));
        const bool readonly = config.isEntryImmutable(attr);
        const QString label = config.readEntry(attr + QLatin1String("_label"),
                                               attributeLabel(attr, pgp()));
        const QString regex = config.readEntry(attr + QLatin1String("_regex"));
        const QString placeholder = config.readEntry(attr + QLatin1String{"_placeholder"});

        int row;
        bool known = true;
        std::shared_ptr<QValidator> validator;
        if (attr == QLatin1String("EMAIL")) {
            row = row_index_of(ui->emailLE, ui->gridLayout);
            validator = regex.isEmpty() ? Validation::email() : Validation::email(regex);
        } else if (attr == QLatin1String("NAME") || attr == QLatin1String("CN")) {
            if ((pgp() && attr == QLatin1String("CN")) || (!pgp() && attr == QLatin1String("NAME"))) {
                continue;
            }
            if (pgp()) {
                validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(regex);
            }
            row = row_index_of(ui->nameLE, ui->gridLayout);
        } else {
            known = false;
            row = add_row(ui->gridLayout, &dynamicWidgets);
        }
        if (!validator && !regex.isEmpty()) {
            validator = std::make_shared<QRegularExpressionValidator>(QRegularExpression{regex});
        }

        QLineEdit *le = adjust_row(ui->gridLayout, row, label, preset, validator, readonly, required);
        le->setPlaceholderText(placeholder);

        const Line line = { key, label, regex, le, validator };
        lines[row] = line;

        if (!known) {
            widgets.push_back(le);
        }

        // don't connect twice:
        disconnect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
        connect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotUpdateRequested(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int oldCount, int newCount) { _klhv_slotSectionCountChanged(oldCount, newCount); }
```

#### AUTO 


```{c}
const auto address = mTarget.userID(0).addrSpec();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.canEncrypt(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &uri) {
        return serialize("Name-URI", uri);
    }
```

#### AUTO 


```{c}
auto pgpEnd = std::stable_partition(pgpBegin, keys.end(),
                                        [](const GpgME::Key &key) {
                                            return key.protocol() != GpgME::CMS;
                                        });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { certifyClicked(); }
```

#### AUTO 


```{c}
auto *grid = new QGridLayout;
```

#### AUTO 


```{c}
auto fixedFont = QFont("Monospace");
```

#### AUTO 


```{c}
auto btn = new QPushButton(i18n("Force decryption"));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(mainWidget);
```

#### AUTO 


```{c}
auto const proxy = qobject_cast<QAbstractProxyModel *>(view->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: lines) {
        if (pair.first == needle) {
            return pair.second;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { done(); }
```

#### AUTO 


```{c}
auto it = options.begin(), end = options.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            mChangeNKSPINBtn->setEnabled(false);
            doChangePin(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &state: chvStatus) {
        const auto parsed = parse_pin_state (state);
        states.push_back(parsed);
        if (parsed == Card::NullPin) {
            if (num == 0) {
                ci->setHasNullPin(true);
            }
        }
        ++num;
    }
```

#### AUTO 


```{c}
auto page =
            new CryptoOperationsConfigurationPage(parent, args);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { authenticationFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fn : std::as_const(d->files)) {
        QFile in(fn);
        if (!in.open(QIODevice::ReadOnly)) {
            d->error(i18n("Could not open file %1 for reading: %2", in.fileName(), in.errorString()), i18n("Certificate Import Failed"));
            d->importResult({fn, ImportResult{}});
            continue;
        }
        const auto data = in.readAll();
        d->startImport(GpgME::OpenPGP, data, fn);
        d->startImport(GpgME::CMS, data, fn);
    }
```

#### AUTO 


```{c}
const auto wantedAdditionalHeight = wantedViewportHeight - currentViewportHeight;
```

#### AUTO 


```{c}
auto entry = grp->entry(entryName);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) { showKeyDetails(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { onDialogRejected(); }
```

#### AUTO 


```{c}
auto data = new QMimeData;
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.hasSecret(); }
```

#### AUTO 


```{c}
const auto formatted = lastName + QStringLiteral("<<") + parts.join(QLatin1Char('<'));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool checked) {
        toggleButton.setArrowType(checked ? Qt::ArrowType::DownArrow : Qt::ArrowType::RightArrow);
        toggleAnimation.setDirection(checked ? QAbstractAnimation::Forward : QAbstractAnimation::Backward);
        toggleAnimation.start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                const bool haveSecretKeys = !KeyCache::instance()->secretKeys().empty();
                const bool havePublicKeys = !KeyCache::instance()->keys().empty();
                mSigChk->setEnabled(haveSecretKeys);
                mEncSelfChk->setEnabled(haveSecretKeys);
                mEncOtherChk->setEnabled(havePublicKeys);
            }
```

#### AUTO 


```{c}
const auto cache = Kleo::KeyCache::instance();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : progressLabelByTagKeys) {
        if (!i.isEmpty()) {
            m_progressLabelByTag.value(i)->setText(i18n("%1: All operations completed.", i));
        } else {
            m_progressLabelByTag.value(i)->setText(i18n("All operations completed."));
        }
    }
```

#### AUTO 


```{c}
const auto nameIsRequired = attrOrder.contains(QLatin1String{"NAME!"}, Qt::CaseInsensitive);
```

#### AUTO 


```{c}
const auto updatedGroups = groups.size() - newGroups;
```

#### AUTO 


```{c}
auto cmd = new Commands::RevokeUserIDCommand(userId);
```

#### AUTO 


```{c}
const auto result = scd_getattr_status(gpgAgent, attribute, err);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) {
                                       return ! (key.protocol() == GpgME::CMS &&
                                                 !key.subkey(0).isNull() &&
                                                 key.subkey(0).canEncrypt() &&
                                                 key.subkey(0).isSecret());
                                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &line : list) {
        const QLineEdit *le = line.edit;
        if (!le) {
            continue;
        }
        const QString key = line.attr;
        qCDebug(KLEOPATRA_LOG) << "requirementsAreMet(): checking" << key << "against" << le->text() << ":";
        if (le->text().trimmed().isEmpty()) {
            if (key.endsWith(QLatin1Char('!'))) {
                if (line.regex.isEmpty()) {
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.", line.label);
                } else
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.<nl/>"
                                   "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                return false;
            }
        } else if (has_intermediate_input(le)) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else if (!le->hasAcceptableInput()) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is invalid.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is invalid.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else {
            allEmpty = false;
        }
    }
```

#### AUTO 


```{c}
auto it = Kleo::binary_find(pageOrder.begin(), pageOrder.end(), currentId);
```

#### LAMBDA EXPRESSION 


```{c}
[] {
                                 KHelpClient::invokeHelp(QStringLiteral("kleopatra"));
                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::KeyListResult&, const std::vector<GpgME::Key> &keys, const QString&, const GpgME::Error&)
                {
                    for (const auto &key: keys) {
                        if (Kleo::keyValidity(key) < GpgME::UserID::Validity::Full) {
                            certifyButton->show();
                            return;
                        }
                    }
                    certifyButton->hide();
                }
```

#### AUTO 


```{c}
auto *action = coll->action(QStringLiteral("configure_groups"))
```

#### AUTO 


```{c}
auto hLay1 = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const std::string &serialNumber, const std::string &appName) { cardRemoved(serialNumber, appName); }
```

#### AUTO 


```{c}
auto detailsDlg = dialog();
```

#### AUTO 


```{c}
auto recipientGrid = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
                    // Yep you can have one subkey associated with multiple primary keys.
                    const GpgME::Key key = sub.parent();
                    toolTips << Formatting::toolTip(key,
                                                    Formatting::Validity |
                                                    Formatting::ExpiryDates |
                                                    Formatting::UserIDs |
                                                    Formatting::Fingerprint);
                    const auto uids = key.userIDs();
                    for (const auto &uid: uids) {
                        lines.push_back(Formatting::prettyUserID(uid));
                    }
                }
```

#### AUTO 


```{c}
auto get(const std::string &name) const
    {
        const auto it = actions.find(name);
        return (it != actions.end()) ? it->second : nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
        options << QStringLiteral("%1 - %2").arg(QString::fromStdString(key.keyRef), QString::fromStdString(key.grip));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey: KeyCache::instance()->findSubkeysByKeyID(subids)) {
                    key = subkey.parent();
                }
```

#### AUTO 


```{c}
auto encKey = mSelfSelect->currentKey();
```

#### AUTO 


```{c}
auto statusLbl = new QLabel(i18nc("Compliance means that GnuPG is running in a more restricted mode e.g. to handle restricted documents.",
                                        "Compliance: %1", complianceMode));
```

#### LAMBDA EXPRESSION 


```{c}
[](auto allKeys, const auto &group) {
                                                const auto keys = group.keys();
                                                allKeys.insert(std::begin(keys), std::end(keys));
                                                return allKeys;
                                           }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (unsigned int slot) {
                    if (slot == 0) {
                        const auto cards = ReaderStatus::instance()->getCards();
                        if (!cards.size()) {
                            setCard(std::shared_ptr<Card>(new Card()));
                        } else {
                            // No support for multiple reader / cards currently
                            setCard(cards[0]);
                        }
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { updateDN(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey] () {
            auto cmd = new ImportPaperKeyCommand(subkey.parent());
            ui.subkeysTree->setEnabled(false);
            connect(cmd, &ImportPaperKeyCommand::finished,
                    q, [this]() { ui.subkeysTree->setEnabled(true); });
            cmd->setParentWidget(q);
            cmd->start();
        }
```

#### AUTO 


```{c}
const auto additionalRule = regexp.isEmpty() ? QString{} : i18n("Additionally, the name must adhere to rules set by your organization.");
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool on) {
            mPublishCB->setEnabled(on);
        }
```

#### AUTO 


```{c}
const auto symguide = new DocAction(QIcon::fromTheme(QStringLiteral("help-hint")), i18n("Password-based encryption"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                "handout_symmetric_encryption_gnupg_en.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("LDAP &timeout (minutes:seconds):"), this);
```

#### AUTO 


```{c}
const auto nksCard = ReaderStatus::instance()->getCard<NetKeyCard>(d->serialNumber());
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(searchTab);
```

#### AUTO 


```{c}
const auto identifiers{m_listWidget->identifiers()};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->changeExpiration(); }
```

#### AUTO 


```{c}
auto entry = newEntry ? newEntry : legacyEntry;
```

#### RANGE FOR STATEMENT 


```{c}
for (const pair &p : v) {
        s << "status(" << QString::fromStdString(p.first) << ") =" << QString::fromStdString(p.second) << endl;
    }
```

#### AUTO 


```{c}
auto cmd = new Kleo::RefreshCertificateCommand{key};
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ArchiveDefinition> &ad : archiveDefinitions) {
        d->ui.archivesCB.addItem(ad->label(), QVariant::fromValue(ad));
    }
```

#### AUTO 


```{c}
const auto emailError = ui.emailInput->currentError();
```

#### AUTO 


```{c}
const auto &line
```

#### AUTO 


```{c}
const auto keyUids = mKey.userIDs();
```

#### AUTO 


```{c}
const auto primaryKeyCanBeUsedForSecretKeyOperations = [](const auto &k) { return k.subkey(0).isSecret() || k.subkey(0).isCardKey(); };
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *edit : std::as_const(mRecpWidgets)) {
        if (edit->isEmpty()) {
            emptyEdits++;
        }
        if (emptyEdits > 1) {
            int row, col, rspan, cspan;
            mRecpLayout->getItemPosition(mRecpLayout->indexOf(w), &row, &col, &rspan, &cspan);
            mRecpLayout->removeWidget(w);
            mRecpWidgets.removeAll(w);
            // The row count of the grid layout does not reflect the actual
            // items so we keep our internal count.
            mRecpRowCount--;
            for (int i = row + 1; i <= mRecpRowCount; i++) {
                // move widgets one up
                auto item = mRecpLayout->itemAtPosition(i, 1);
                if (!item) {
                    break;
                }
                mRecpLayout->removeItem(item);
                mRecpLayout->addItem(item, i - 1, 1);
            }
            w->deleteLater();
            return;
        }
    }
```

#### AUTO 


```{c}
const auto auditLogUrl = m_result->auditLog().asUrl(auditlog_url_template());
```

#### AUTO 


```{c}
const auto isSignature = [](int classification) -> bool {
        return mayBeDetachedSignature(classification)
                || mayBeOpaqueSignature(classification)
                || (classification & Class::TypeMask) == Class::ClearsignedMessage;
    };
```

#### AUTO 


```{c}
const auto slotId = values[1];
```

#### AUTO 


```{c}
auto btn = button(QWizard::CustomButton1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey : key.subkeys()) {
        auto item = new QTreeWidgetItem();
        item->setData(0, Qt::DisplayRole, QString::fromLatin1(subkey.keyID()));
        item->setData(0, Qt::UserRole, QVariant::fromValue(subkey));
        item->setData(1, Qt::DisplayRole, Kleo::Formatting::type(subkey));
        item->setData(2, Qt::DisplayRole, Kleo::Formatting::creationDateString(subkey));
        item->setData(3, Qt::DisplayRole, Kleo::Formatting::expirationDateString(subkey));
        item->setData(4, Qt::DisplayRole, Kleo::Formatting::validityShort(subkey));
        switch (subkey.publicKeyAlgorithm()) {
            case GpgME::Subkey::AlgoECDSA:
            case GpgME::Subkey::AlgoEDDSA:
            case GpgME::Subkey::AlgoECDH:
                item->setData(5, Qt::DisplayRole, QString::fromStdString(subkey.algoName()));
                break;
            default:
                item->setData(5, Qt::DisplayRole, QString::number(subkey.length()));
        }
        item->setData(6, Qt::DisplayRole, Kleo::Formatting::usageString(subkey));
        d->ui.subkeysTree->addTopLevelItem(item);
    }
```

#### AUTO 


```{c}
auto fo = std::dynamic_pointer_cast<FileOutput>(output)
```

#### LAMBDA EXPRESSION 


```{c}
[](auto allIds, const auto &r) {
                                            allIds.insert(r.id);
                                            return allIds;
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[&service](int i) {
        service.setExitValue(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            mImportBtn->setEnabled(true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : std::as_const(d->uids))
        if (qstricmp(uid.parent().primaryFingerprint(), key.primaryFingerprint()) != 0) {
            qCWarning(KLEOPATRA_LOG) << "User ID <-> Key mismatch!";
            d->finished();
            return;
        }
```

#### AUTO 


```{c}
static auto notCertifiedKeysFilterId()
    {
        static const QString filterId = QStringLiteral("not-certified-certificates");
        return filterId;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &recipient: recipients) {
            const auto &key = recipient.resolvedEncryptionKey(presetProtocol);
            if (!IS_DE_VS(key) || keyValidity(key) < GpgME::UserID::Validity::Full) {
                return false;
            }
        }
```

#### AUTO 


```{c}
auto cmd = new ExportGroupsCommand(selectedGroups);
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::KeyToCardCommand(subkey, card->serialNumber());
```

#### AUTO 


```{c}
const auto &entryName
```

#### AUTO 


```{c}
const auto dateTime = [](long ts) {
        return ts == 0 ? i18n("never") : QDateTime::fromSecsSinceEpoch(ts).toString(Qt::SystemLocaleShortDate);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            mSigGBtn->setEnabled(false);
            doChangePin(true);
        }
```

#### AUTO 


```{c}
auto tv = qobject_cast<KeyTreeView *> (parent());
```

#### LAMBDA EXPRESSION 


```{c}
[import]() {
                    import->setEnabled(true);
                }
```

#### AUTO 


```{c}
auto *const legacyEntry = configEntry(s_pgpservice_legacy_componentName, s_pgpservice_legacy_entryName,
                                              CryptoConfigEntry::ArgType_String, SingleValue, DoNotShowError);
```

#### AUTO 


```{c}
const auto firstCms = std::partition(keys.begin(), keys.end(),
                                         [](const GpgME::Key &key) {
                                            return key.protocol() != GpgME::CMS;
                                         });
```

#### AUTO 


```{c}
const auto selectedCertificates(dialog->selectedCertificates());
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Input> &i : allInputs) {
            i->setLabel(st);
        }
```

#### AUTO 


```{c}
const auto output =
                ad       ? ad->createOutputFromUnpackCommand(cFile.protocol, cFile.fileName, wd) :
                /*else*/   Output::createFromFile(wd.absoluteFilePath(outputFileName(fi.fileName())), false);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file: srcDir.entryList(QDir::Files)) {
        const QString srcName = src + QLatin1Char('/') + file;
        const QString destName = dest + QLatin1Char('/') + file;
        if(!QFile::copy(srcName, destName)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QChar ch : encoded)
        if (shift) {
            switch (ch.toLatin1()) {
            case '\\': decoded += QLatin1Char('\\'); break;
            case 'n':  decoded += QLatin1Char('\n'); break;
            default:
                qCDebug(KLEOPATRA_LOG) << "invalid escape sequence" << '\\' << ch << "(interpreted as '" << ch << "')";
                decoded += ch;
                break;
            }
            shift = false;
        } else {
            if (ch == QLatin1Char('\\')) {
                shift = true;
            } else {
                decoded += ch;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        KConfigGroup conf(KSharedConfig::openConfig(), "CertifySettings");
        const auto lastKey = mCertWidget->secKey();
        // Do not accept if the keys are the same.
        if (!lastKey.isNull() && !mCertWidget->target().isNull() &&
            !strcmp(lastKey.primaryFingerprint(),
                    mCertWidget->target().primaryFingerprint())) {
            KMessageBox::error(this, i18n("You cannot certify using the same key."),
                               i18n("Invalid Selection"), KMessageBox::Notify);
            return;
        }

        if (!lastKey.isNull()) {
            conf.writeEntry("LastKey", lastKey.primaryFingerprint());
        }
        conf.writeEntry("ExportCheckState", mCertWidget->exportableSelected());
        conf.writeEntry("PublishCheckState", mCertWidget->publishSelected());
        accept();
    }
```

#### AUTO 


```{c}
const auto pgpCard = ReaderStatus::instance()->getCard<OpenPGPCard>(mRealSerial);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fname : dirs) {
            recursivelyRemovePath(dir.filePath(fname));
        }
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *Hierarchical = "window_view_hierarchical";
```

#### AUTO 


```{c}
const auto regexp = config.readEntry("NAME_regex");
```

#### AUTO 


```{c}
const auto nameError = ui.nameAndEmail->nameError();
```

#### AUTO 


```{c}
const auto jobsToCancel = d->jobs;
```

#### AUTO 


```{c}
const auto isKeyboardFocusEvent = reason == Qt::TabFocusReason
                                   || reason == Qt::BacktabFocusReason
                                   || reason == Qt::ShortcutFocusReason;
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) {
                                            return key.protocol() != GpgME::CMS;
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[import, q] () {
                import->setEnabled(false);
                auto cmd = new Kleo::ImportCertificateFromFileCommand();
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                        q, [import]() {
                    import->setEnabled(true);
                });
                cmd->setParentWidget(q);
                cmd->start();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &html](const QString &hdr) {
        html += QStringLiteral("<tr><th colspan=\"2\" style=\"background-color: %1; color: %2\">%3</th></tr>")
                    .arg(q->palette().highlight().color().name(),
                         q->palette().highlightedText().color().name(),
                         hdr);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.addUserIDBtn->setEnabled(true);
                         key.update();
                         q->setKey(key);
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KeyGroup &group) {
                if (!mGroup.isNull() && mGroup.source() == group.source() && mGroup.id() == group.id()) {
                    setTextWithBlockedSignals(Formatting::summaryLine(group));
                    // queue the update to ensure that the model has been updated
                    QMetaObject::invokeMethod(q, [this]() { updateKey(); }, Qt::QueuedConnection);
                }
            }
```

#### AUTO 


```{c}
auto list = QString::fromStdString(mMetaInfo.value("DISP-NAME")).split("<<");
```

#### AUTO 


```{c}
const auto dateTime = [](long ts) {
        QLocale l;
        return ts == 0 ? i18n("never") : l.toString(QDateTime::fromSecsSinceEpoch(ts), QLocale::ShortFormat);
    };
```

#### AUTO 


```{c}
auto item = new QListWidgetItem;
```

#### AUTO 


```{c}
auto certSel = new CertificateLineEdit(mModel,
                                           new EncryptCertificateFilter(mCurrentProto),
                                           this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int) {
                slotDialogClosed();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sender : std::as_const(in.senders)) {
        if ((err = send_sender(ctx, sender, in.areSendersInformative))) {
            out.errorString = i18n("Failed to send sender %1: %2", sender, to_error_string(err));
            goto leave;
        }
    }
```

#### AUTO 


```{c}
auto btn = new QPushButton(i18n("Apply"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &idx) {
                    certificationDblClicked(idx);
                }
```

#### AUTO 


```{c}
auto protocolLayout = new QHBoxLayout(protocolWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w: qAsConst(mUnknownWidgets)) {
        mRecpLayout->removeWidget(w);
        delete w;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[start](const auto &anchor) {
        return anchor.start == start;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool on) {
            mTrustSignatureDomainLE->setEnabled(on);
            Q_EMIT q->changed();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : sl) {
        result = commonPrefix(s, result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](GpgME::ImportResult, QString, GpgME::Error) {
                qCDebug(KLEOPATRA_LOG) << "import job done";
                mStatusLabel->setText(i18n("Automatic import finished."));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &index) { return getGroup(index); }
```

#### AUTO 


```{c}
auto cmd = new Kleo::ImportCertificateFromKeyserverCommand{QStringList{std::begin(missingSignerKeyIds), std::end(missingSignerKeyIds)}};
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { doChangePin(OpenPGPCard::pinKeyRef()); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { deleteGroup(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->slotSignersResolved(); }
```

#### AUTO 


```{c}
auto group = new QGroupBox{i18n("X.509"), parent};
```

#### AUTO 


```{c}
auto buttonWidget = new QWidget;
```

#### AUTO 


```{c}
auto genKeyAction = new QAction(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        /* We use a single shot timer here to ensure that the keysMayHaveChanged
         * handlers are all handled before we restore the expand state so that
         * the model is already populated. */
        QTimer::singleShot(0, [this] () {
            restoreExpandState();
            setupRemarkKeys();
            if (!m_onceResized) {
                m_onceResized = true;
                resizeColumns();
            }
        });
    }
```

#### AUTO 


```{c}
auto cmd = new CreateOpenPGPKeyFromCardKeysCommand(mRealSerial, OpenPGPCard::AppName, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Key &key) { slotAddKey(key); }
```

#### AUTO 


```{c}
auto label = new QLabel{i18n("The process of creating a key requires large amounts of random numbers. This may require several minutes..."), parent};
```

#### AUTO 


```{c}
const auto name = errorShown ? descriptionAccessibleName + QLatin1String{", "} + invalidEntryText()
                                     : descriptionAccessibleName;
```

#### AUTO 


```{c}
static const auto path = findGpgExe(GpgME::GpgSMEngine, QStringLiteral("gpgsm"));
```

#### AUTO 


```{c}
auto cmd = Command::commandForQuery(QString::fromUtf8(signature.signerKeyID()));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const GpgME::Key &) {
            updateTags();
            checkOwnerTrust();
            Q_EMIT q->changed();
        }
```

#### AUTO 


```{c}
const auto it = std::remove_if(signingCertificates.begin(), signingCertificates.end(),
                                   [](const Key &key) {
                                       return ! (key.protocol() == GpgME::CMS &&
                                                 !key.subkey(0).isNull() &&
                                                 key.subkey(0).canSign() &&
                                                 !key.subkey(0).canEncrypt() &&
                                                 key.subkey(0).isSecret() &&
                                                 !key.subkey(0).isCardKey());
                                   });
```

#### LAMBDA EXPRESSION 


```{c}
[primary](const UserID &uid) {
        return qstricmp(uid.parent().primaryFingerprint(), primary) != 0;
    }
```

#### AUTO 


```{c}
const auto appName = newCard->appName();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox{this};
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotMoveCurrentTabRight(); }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &u) {
                                                       return !isRevokedOrExpired(u);
                                                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : qAsConst(attrOrder)) {
        const QString key = rawKey.trimmed().toUpper();
        const QString attr = attributeFromKey(key);
        if (attr.isEmpty()) {
            continue;
        }
        const QString preset = savedValues.value(attr, config.readEntry(attr, QString()));
        const bool required = key.endsWith(QLatin1Char('!'));
        const bool readonly = config.isEntryImmutable(attr);
        const QString label = config.readEntry(attr + QLatin1String("_label"),
                                               attributeLabel(attr, pgp()));
        const QString regex = config.readEntry(attr + QLatin1String("_regex"));

        int row;
        bool known = true;
        QValidator *validator = nullptr;
        if (attr == QLatin1String("EMAIL")) {
            row = row_index_of(ui.emailLE, ui.gridLayout);
            validator = regex.isEmpty() ? Validation::email() : Validation::email(QRegExp(regex));
        } else if (attr == QLatin1String("NAME") || attr == QLatin1String("CN")) {
            if ((pgp() && attr == QLatin1String("CN")) || (!pgp() && attr == QLatin1String("NAME"))) {
                continue;
            }
            if (pgp()) {
                validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(QRegExp(regex));
            }
            row = row_index_of(ui.nameLE, ui.gridLayout);
        } else {
            known = false;
            row = add_row(ui.gridLayout, &dynamicWidgets);
        }
        if (!validator && !regex.isEmpty()) {
            validator = new QRegExpValidator(QRegExp(regex), nullptr);
        }

        QLineEdit *le = adjust_row(ui.gridLayout, row, label, preset, validator, readonly, required);

        const Line line = { key, label, regex, le };
        lines[row] = line;

        if (!known) {
            widgets.push_back(le);
        }

        // don't connect twice:
        disconnect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
        connect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
    }
```

#### AUTO 


```{c}
const auto selectedUserIDs = dialog->selectedUserIDs();
```

#### AUTO 


```{c}
const auto b = bb->addButton(i18n("&Get update"), QDialogButtonBox::AcceptRole);
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
        auto cmd = new Kleo::Commands::CertifyCertificateCommand(userID);
        ui.userIDTable->setEnabled(false);
        connect(cmd, &Kleo::Commands::CertifyCertificateCommand::finished,
                q, [this]() {
            ui.userIDTable->setEnabled(true);
            updateKey();
        });
        cmd->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : fileNames) {
        dirs.push_back(QFileInfo(fileName).path() + QLatin1Char('/'));
    }
```

#### AUTO 


```{c}
auto pivCard = new PIVCard(*ci);
```

#### RANGE FOR STATEMENT 


```{c}
for (KCModule *module : mChangedModules) {
        module->save();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool value) {
            if (mCurrentProto != GpgME::CMS) {
                return;
            }
            if (value) {
                mEncSelfChk->setChecked(false);
                mEncOtherChk->setChecked(false);
            }
        }
```

#### AUTO 


```{c}
const auto fm = ui.treeView->fontMetrics();
```

#### AUTO 


```{c}
auto buttonsLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { keysMayHaveChanged(); }
```

#### AUTO 


```{c}
auto action = new QAction(ad.text, coll);
```

#### AUTO 


```{c}
const auto &recipient
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &compName: config->componentList()) {
        auto comp = config->component(compName);
        if (!comp) {
            qCWarning(KLEOPATRA_LOG) << "Failed to find component:" << comp;
            return;
        }
        for (const auto &grpName: comp->groupList()) {
            auto grp = comp->group(grpName);
            if (!grp) {
                qCWarning(KLEOPATRA_LOG) << "Failed to find group:" << grp << "in component:" << compName;
                return;
            }
            for (const auto &entryName: grp->entryList()) {
                auto entry = grp->entry(entryName);
                if (!entry) {
                    qCWarning(KLEOPATRA_LOG) << "Failed to find entry:" << entry << "in group:"<< grp << "in component:" << compName;
                    return;
                }
                entry->resetToDefault();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool state) {
                    mUseOutputDir = state;
                    mArchive = !mUseOutputDir;
                    updateFileWidgets();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &idx) {
                certificationDblClicked(idx);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &compName: componentList) {
        auto comp = config->component(compName);
        if (!comp) {
            qCWarning(KLEOPATRA_LOG) << "Failed to find component:" << comp;
            return;
        }
        const QStringList groupList = comp->groupList();
        for (const auto &grpName: groupList) {
            auto grp = comp->group(grpName);
            if (!grp) {
                qCWarning(KLEOPATRA_LOG) << "Failed to find group:" << grp << "in component:" << compName;
                return;
            }
            const QStringList entries = grp->entryList();
            for (const auto &entryName: entries) {
                auto entry = grp->entry(entryName);
                if (!entry) {
                    qCWarning(KLEOPATRA_LOG) << "Failed to find entry:" << entry << "in group:"<< grp << "in component:" << compName;
                    return;
                }
                entry->resetToDefault();
            }
        }
    }
```

#### AUTO 


```{c}
auto unknownWidget = new UnknownRecipientWidget(keyID);
```

#### AUTO 


```{c}
const auto decResult = result.decryptionResult();
```

#### AUTO 


```{c}
auto result = importjob->exec(data);
```

#### AUTO 


```{c}
auto radioButtonSize(const QRadioButton *radioButton)
{
    QStyleOptionButton opt;
    return radioButton->style()->sizeFromContents(QStyle::CT_RadioButton, &opt, QSize(), radioButton);
}
```

#### AUTO 


```{c}
const auto description = errorShown ? ui.descriptionError->text() : QString{};
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &child) {
        if (child.id != 0) {
            QAccessible::deleteAccessibleInterface(child.id);
        }
    }
```

#### AUTO 


```{c}
const auto split = algoString.split(QLatin1Char('/'));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout{dialog};
```

#### RANGE FOR STATEMENT 


```{c}
for (const Protocol i: supportedProtocolsLst) {
        auto const l = new QLabel;
        l->setText(formatLabel(i, Key()));
        layout->addWidget(l);
        m_labels[i] =  l;
    }
```

#### AUTO 


```{c}
const auto split = entry->stringValue().split(QLatin1Char('+'));
```

#### AUTO 


```{c}
auto grp = new QButtonGroup(q);
```

#### AUTO 


```{c}
auto const box = new QDialogButtonBox;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Protocol i : supportedProtocols()) {
        const bool checked = std::find(protocols.begin(), protocols.end(), i) != protocols.end();
        d->signingProtocolSelectionWidget->setProtocolChecked(i, checked);
        d->readOnlyProtocolSelectionWidget->setProtocolChecked(i, checked);
    }
```

#### AUTO 


```{c}
const auto dir
```

#### AUTO 


```{c}
const auto progressCb = [this, &scanning](int c) { Q_EMIT progress(c, 0, scanning); };
```

#### AUTO 


```{c}
auto command = new ListReadersCommand(q);
```

#### AUTO 


```{c}
const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: mRecpWidgets) {
        if (!edit->isEmpty() && edit->key().isNull()) {
            KMessageBox::error(this, i18nc("%1 is user input that could not be found",
                        "Could not find a key for '%1'", edit->text().toHtmlEscaped()),
                    i18n("Failed to find recipient"), KMessageBox::Notify);
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { webOfTrustClicked(); }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.changePassphraseBtn->setEnabled(true);
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.isNull(); }
```

#### AUTO 


```{c}
const auto key = KeyListSortFilterProxyModel::data(idx, KeyList::KeyRole).value<GpgME::Key>();
```

#### AUTO 


```{c}
auto cmd = new SetInitialPinCommand(firstCardWithNullPin);
```

#### AUTO 


```{c}
const auto defaultChecksumDefinitionId = settings.checksumDefinitionId();
```

#### AUTO 


```{c}
const auto nullDescription = i18n("You need to set a PIN before you can use the certificates.");
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Set &Unlimited"), group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Line &line : std::as_const(lineList)) {
        savedValues[ attributeFromKey(line.attr) ] = line.edit->text().trimmed();
    }
```

#### AUTO 


```{c}
auto hLay2 = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->certifyClicked(); }
```

#### AUTO 


```{c}
const auto finishedJob = q->sender();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &statusLine: statusLines) {
        if (statusLine.first == "SERIALNO") {
            const auto serialNumberAndApps = QByteArray::fromStdString(statusLine.second).split(' ');
            if (serialNumberAndApps.size() >= 2) {
                const auto serialNumber = serialNumberAndApps[0];
                auto apps = serialNumberAndApps.mid(1);
                // sort the apps to get a stable order independently of the currently selected application
                std::sort(apps.begin(), apps.end());
                for (const auto &app: apps) {
                    qCDebug(KLEOPATRA_LOG) << "getCardsAndApps(): Found card" << serialNumber << "with app" << app;
                    result.push_back({ serialNumber.toStdString(), app.toStdString() });
                }
            } else {
                logUnexpectedStatusLine(statusLine, "getCardsAndApps()", command);
            }
        } else {
            logUnexpectedStatusLine(statusLine, "getCardsAndApps()", command);
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *Duplicate = "window_duplicate_tab";
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : files) {
        fileInfos.push_back(QFileInfo(i));
    }
```

#### AUTO 


```{c}
const auto appendHeader = [this, &html](const QString &hdr) {
        html += QStringLiteral("<tr><th colspan=\"2\" style=\"background-color: %1; color: %2\">%3</th></tr>")
                    .arg(q->palette().highlight().color().name(),
                         q->palette().highlightedText().color().name(),
                         hdr);
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { writeCertificateToCard(PIVCard::keyManagementKeyRef()); }
```

#### AUTO 


```{c}
auto act = coll->action(QStringLiteral("pad_view"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotSendCertificateByEMailContinuation();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](EncryptClipboardCommand*){}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Key &key) { slotNextKey(key); }
```

#### AUTO 


```{c}
auto advLay = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto ad = q->pick_archive_definition(proto, archiveDefinitions, fName);
```

#### AUTO 


```{c}
const auto ctx = std::shared_ptr<GpgME::Context> (GpgME::Context::createForProtocol(GpgME::OpenPGP));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (parseCardInfo(pair.first, pair.second)) {
            continue;
        }
        if (pair.first == "KEYPAIRINFO") {
            const KeyPairInfo info = KeyPairInfo::fromStatusLine(pair.second);
            if (info.grip.empty()) {
                qCWarning(KLEOPATRA_LOG) << "Invalid KEYPAIRINFO status line"
                        << QString::fromStdString(pair.second);
                setStatus(Card::CardError);
                continue;
            }
            mMetaInfo.insert("KEYPAIRINFO-" + info.keyRef, info.grip);
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### AUTO 


```{c}
auto label = new QLabel{qq};
```

#### AUTO 


```{c}
const auto &i
```

#### AUTO 


```{c}
const auto *const model = ui.tabWidget.currentModel();
```

#### AUTO 


```{c}
static auto split(const std::string &s, char c)
{
    std::vector<std::string> result;

    auto start = 0;
    auto end = s.find(c, start);
    while (end != s.npos) {
        result.push_back(s.substr(start, end - start));
        start = end + 1;
        end = s.find(c, start);
    }
    result.push_back(s.substr(start));

    return result;
}
```

#### AUTO 


```{c}
const auto &s
```

#### AUTO 


```{c}
const auto &r
```

#### AUTO 


```{c}
const auto card = cards[0];
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &id : userIDs) {
        const Mailbox mbox = mailbox(id);
        if (!mbox.addrSpec().isEmpty()) {
            res.push_back(mbox);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { changePin(PIVCard::pukKeyRef()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar ch : encoded)
        if (shift) {
            switch (ch.toLatin1()) {
            case '\\': decoded += QLatin1Char('\\'); break;
            case 'n':  decoded += QLatin1Char('\n'); break;
            default:
                qCDebug(KLEOPATRA_LOG) << "invalid escape sequence" << '\\' << ch << "(interpreted as '" << ch << "')";
                decoded += ch;
                break;
            }
            shift = false;
        } else {
            if (ch == QLatin1Char('\\')) {
                shift = true;
            } else {
                decoded += ch;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: KeyCache::instance()->keys()) {
        if (key.isNull() || key.isRevoked() || key.isExpired() ||
            key.isDisabled() || key.isInvalid() || key.protocol() != GpgME::OpenPGP) {
            continue;
        }
        if (key.ownerTrust() >= GpgME::Key::Full) {
            ret.push_back(key);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &job) {
                      if (job) {
                          job->slotCancel();
                      }
                  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SumFile &sumfile : sumfiles) {
        qCDebug(KLEOPATRA_LOG) << sumfile;
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(actions.cbegin(), actions.cend(),
                                     [this](const action_item &item) { return item.action == q->sender(); });
```

#### AUTO 


```{c}
const auto version = QByteArray::fromStdString(s).toUInt(&ok, 16);
```

#### AUTO 


```{c}
auto pukButton = new QPushButton(i18n("Change PUK"));
```

#### AUTO 


```{c}
auto const l = new QLabel;
```

#### AUTO 


```{c}
const auto extraView{extractViewGroups(config)};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: q->resolvedEncryptionKeys()) {
                if (!IS_DE_VS(key) || keyValidity(key) < GpgME::UserID::Validity::Full) {
                    de_vs = false;
                    break;
                }
            }
```

#### AUTO 


```{c}
auto overViewLines = overView.split(QLatin1Char('\n'));
```

#### AUTO 


```{c}
const auto editGroup = edit->group();
```

#### AUTO 


```{c}
auto cmd = Command::commandForQuery(query);
```

#### AUTO 


```{c}
const auto profiles = datadir.entryInfoList(QStringList() << QStringLiteral("*.prf"), QDir::Readable | QDir::Files, QDir::Name);
```

#### LAMBDA EXPRESSION 


```{c}
[this, chk]() {
            QDesktopServices::openUrl(QUrl("https://www.gpg4win.org/download.html"));
            KConfigGroup updatecfg(KSharedConfig::openConfig(), "UpdateNotification");
            updatecfg.writeEntry("NeverShow", !chk->isChecked());
            gpgconf_set_update_check (chk->isChecked());
            QDialog::accept();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
                // Yep you can have one subkey associated with multiple
                // primary keys.
                toolTips << Formatting::toolTip(sub.parent(), Formatting::Validity |
                        Formatting::StorageLocation |
                        Formatting::ExpiryDates |
                        Formatting::UserIDs |
                        Formatting::Fingerprint);

            }
```

#### AUTO 


```{c}
const auto backend = QGpgME::openpgp();
```

#### AUTO 


```{c}
auto action = get(name)
```

#### AUTO 


```{c}
const auto *const newEntry = configEntry(s_x509services_componentName, s_x509services_entryName,
                                                 CryptoConfigEntry::ArgType_LDAPURL, ListValue, DoNotShowError);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) {
        q->keyToOpenPGPCardDone(err);
    }
```

#### AUTO 


```{c}
const auto nksCard = ReaderStatus::instance()->getCard<NetKeyCard>(serialNumber());
```

#### AUTO 


```{c}
const auto choice = KMessageBox::questionYesNo(
        q->window(), message, i18nc("@title:window", "Confirm Revocation"),
        confirmButton, KStandardGuiItem::cancel(), {}, KMessageBox::Notify | KMessageBox::WindowModal);
```

#### AUTO 


```{c}
const auto &t
```

#### AUTO 


```{c}
const auto &v
```

#### AUTO 


```{c}
auto fpr = split.value(1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: key.userIDs()) {
            if (uid.isRevoked() || uid.isInvalid()) {
                // Skip user ID's that cannot really be certified.
                i++;
                continue;
            }
            auto const item = new QStandardItem;
            item->setText(Formatting::prettyUserID(uid));
            item->setData(i, UserIDIndex);
            item->setCheckable(true);
            item->setEditable(false);
            item->setCheckState(Qt::Checked);
            appendRow(item);
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &i : tasks) {
        Q_ASSERT(i);
        d->m_tasks[i->id()] = i;
        connect(i.get(), SIGNAL(progress(QString,int,int)),
                this, SLOT(taskProgress(QString,int,int)));
        connect(i.get(), SIGNAL(result(std::shared_ptr<const Kleo::Crypto::Task::Result>)),
                this, SLOT(taskResult(std::shared_ptr<const Kleo::Crypto::Task::Result>)));
        connect(i.get(), SIGNAL(started()),
                this, SLOT(taskStarted()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int year, int month) {
                    // We select the same day in the month when
                    // a page is switched.
                    auto date = ui.onCW->selectedDate();
                    if (!date.setDate(year, month, date.day())) {
                        date.setDate(year, month, 1);
                    }
                    ui.onCW->setSelectedDate(date);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { setOwnerTrust(); }
```

#### AUTO 


```{c}
auto accumulateTrustDomains(const std::vector<GpgME::UserID::Signature> &signatures)
{
    return std::accumulate(
        std::begin(signatures), std::end(signatures),
        std::set<QString>(),
        [] (auto domains, const auto &signature) {
            if (isGood(signature) && signature.isTrustSignature()) {
                domains.insert(Formatting::trustSignatureDomain(signature));
            }
            return domains;
        }
    );
}
```

#### AUTO 


```{c}
const auto target = QFileDialog::getSaveFileName(this, i18n("Save backup of encryption key"),
                                                         fi.fileName(),
                                                         QStringLiteral("%1 (*.gpg)").arg(i18n("Backup Key")));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotUploadCertificateToDirectoryServer();
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout{uriGB};
```

#### AUTO 


```{c}
const auto currentViewportHeight = viewport()->height();
```

#### AUTO 


```{c}
auto button = new QPushButton;
```

#### AUTO 


```{c}
const auto entry = conf->entry(protocol == CMS ? QStringLiteral("gpgsm") : QStringLiteral("gpg"),
                                   QStringLiteral("Configuration"),
                                   QStringLiteral("default_pubkey_algo"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { addKeysToGroup(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {checkAcceptable();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (parseCardInfo(pair.first, pair.second)) {
            continue;
        }
        mMetaInfo.insert(pair.first, pair.second);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &email) {
        return serialize("Name-Email", (d->protocol == CMS) ? encodeEmail(email) : email);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, infoBtn] () {
            const QString msg = i18n("You can use this to add additional info to a "
                                     "certification.") + QStringLiteral("<br/><br/>") +
                                     i18n("Tags created by anyone with full certification trust "
                                          "are shown in the keylist and can be searched.");
            QToolTip::showText(infoBtn->mapToGlobal(QPoint()) + QPoint(infoBtn->width(), 0),
                               msg, infoBtn, QRect(), 30000);
        }
```

#### AUTO 


```{c}
const auto *const model = dynamic_cast<KeyListModelInterface*>(view->model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Line &line : list) {
        const QLineEdit *le = line.edit;
        if (!le) {
            continue;
        }
        const QString key = line.attr;
        qCDebug(KLEOPATRA_LOG) << "requirementsAreMet(): checking \"" << key << "\" against \"" << le->text() << "\":";
        if (le->text().trimmed().isEmpty()) {
            if (key.endsWith(QLatin1Char('!'))) {
                if (line.regex.isEmpty()) {
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.", line.label);
                } else
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.<nl/>"
                                   "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                return false;
            }
        } else if (has_intermediate_input(le)) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else if (!le->hasAcceptableInput()) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is invalid.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is invalid.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else {
            allEmpty = false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Sender &sender) { return count_encrypt_certificates(proto, sender) == 1; }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) {
                              return QString::compare(lhs, rhs, fs_cs) < 0;
                          }
```

#### AUTO 


```{c}
auto cmd = new Commands::DecryptVerifyFilesCommand(undetected, nullptr, true);
```

#### AUTO 


```{c}
const auto currentErrorMessage = mErrorLabel->text();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        /* We use a single shot timer here to ensure that the keysMayHaveChanged
         * handlers are all handled before we restore the expand state so that
         * the model is already populated. */
        QTimer::singleShot(0, [this] () {
            restoreExpandState();
            setUpTagKeys();
            if (!m_onceResized) {
                m_onceResized = true;
                resizeColumns();
            }
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.protocol() != OpenPGP; }
```

#### AUTO 


```{c}
const auto newValue = static_cast<unsigned>(value);
```

#### AUTO 


```{c}
const auto dateTime = [](long ts) {
        return ts == 0 ? i18n("never") : QDateTime::fromTime_t(ts).toString(Qt::SystemLocaleShortDate);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &i : std::as_const(m_runnableTasks)) {
        q->connectTask(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[finishedJob](const auto &job) { return job.job == finishedJob; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
            const KConfigGroup cGroup(config, group);
            const QString id = cGroup.readEntryUntranslated(QStringLiteral("id"));
            const QString name = cGroup.readEntry("Name");
            mArchiveDefinitionCB->addItem(name, QVariant(id));
            if (id == ad_default_id) {
                mArchiveDefinitionCB->setCurrentIndex(mArchiveDefinitionCB->count() - 1);
            }
        }
```

#### AUTO 


```{c}
const auto &key = recipient.resolvedEncryptionKey(presetProtocol);
```

#### AUTO 


```{c}
const auto classification = classify(sig);
```

#### AUTO 


```{c}
auto centerLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { checkAcceptable(); }
```

#### AUTO 


```{c}
const auto currentErrorMessage = ui.descriptionError->text();
```

#### LAMBDA EXPRESSION 


```{c}
[this, fpr] () {
            qCDebug(KLEOPATRA_LOG) << "Updating key info after changes";
            ReaderStatus::mutableInstance()->updateStatus();
            updateSigKeyWidgets(fpr);
    }
```

#### AUTO 


```{c}
const auto grp = KSharedConfig::openConfig()->group("KeyTreeView");
```

#### AUTO 


```{c}
const auto group = KeyListSortFilterProxyModel::data(index, KeyList::GroupRole).value<KeyGroup>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const std::shared_ptr<TaskCollection> &t) { return !t->isEmpty(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Key &gpgKey) { slotDetailsRequested(gpgKey); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : attrOrder) {
            const QString key = rawKey.trimmed().toUpper();
            const QString attr = attributeFromKey(key);
            if (attr.isEmpty()) {
                continue;
            }
            const QString defaultPreset = (attr == QLatin1String("CN")) ? userFullName() :
                                          (attr == QLatin1String("EMAIL")) ? userEmailAddress() :
                                          QString();
            const QString preset = config.readEntry(attr, defaultPreset);
            const bool required = key.endsWith(QLatin1Char('!'));
            const bool readonly = config.isEntryImmutable(attr);
            const QString label = config.readEntry(attr + QLatin1String("_label"),
                                                   attributeLabel(attr));
            const QString regex = config.readEntry(attr + QLatin1String("_regex"));

            std::shared_ptr<QValidator> validator;
            if (attr == QLatin1String("EMAIL")) {
                validator = regex.isEmpty() ? Validation::email() : Validation::email(regex);
            } else if (!regex.isEmpty()) {
                validator = std::make_shared<QRegularExpressionValidator>(QRegularExpression{regex});
            }

            QLineEdit *le = addRow(ui.gridLayout, label, preset, validator, readonly, required);

            const Line line = { attr, label, regex, le, validator, required };
            ui.lines.push_back(line);

            if (attr != QLatin1String("EMAIL")) {
                connect(le, &QLineEdit::textChanged, [this] () { updateDN(); });
            }
            connect(le, &QLineEdit::textChanged, [this] () { checkRequirements(); });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : checksumDefinitions) {
        if (cd) {
            Q_FOREACH (const QString &pattern, cd->patterns()) {
                if (QRegExp(pattern, fs_cs).exactMatch(fileName)) {
                    return cd;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotDialogAccepted(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                                ui.subkeysTree->setEnabled(true);
                                key.update();
                                q->setKey(key);
                            }
```

#### AUTO 


```{c}
auto nameButtton = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature &sig : sigs) {
            const QString s = signatureToString(sig, sig.key(true, true));
            const char *color = summaryToString(sig.summary());
            q->sendStatusEncoded("SIGSTATUS",
                                 color + (' ' + hexencode(s.toUtf8().constData())));
        }
```

#### AUTO 


```{c}
const auto path = datadir.filePath(profile + QStringLiteral(".prf"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
                Key key = mCompleter->completionModel()->data(index, KeyList::KeyRole).value<Key>();
                auto group = mCompleter->completionModel()->data(index, KeyList::GroupRole).value<KeyGroup>();
                if (!key.isNull()) {
                    setKey(key);
                } else if (!group.isNull()) {
                    setGroup(group);
                } else {
                    qCDebug(KLEOPATRA_LOG) << "Activated item is neither key nor group";
                }
            }
```

#### AUTO 


```{c}
const auto err = ctx->startKeyListing(pattern.c_str())
```

#### AUTO 


```{c}
auto mainLay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto userID = certificationsModel.userID(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey: KeyCache::instance()->findSubkeysByKeyID(subids)) {
                    key = subkey.parent();
                    break;
                }
```

#### AUTO 


```{c}
auto keyGenJob = QGpgME::openpgp()->keyGenerationJob();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotDialogAccepted();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &url) { return KeyserverConfig::fromUrl(url); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->publishCertificate(); }
```

#### AUTO 


```{c}
auto profLabel = new QLabel(i18n("Activate GnuPG Profile:"));
```

#### AUTO 


```{c}
const auto manufacturerName = manufacturerIdAndName.substr(startOfManufacturerName + 1);
```

#### AUTO 


```{c}
auto cmd = new KeyToCardCommand(keyref, mCardSerialNumber, PIVCard::AppName);
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Mailbox &recipient) {
                       return resolveRecipient(recipient, proto);
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::ImportResult &result) {
                            return result.error().isCanceled();
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid : uids) {
            QStandardItem *const item = new QStandardItem;
            item->setText(Formatting::prettyUserID(uid));
            item->setCheckable(true);
            item->setEditable(false);
            item->setCheckState(Qt::Checked);
            appendRow(item);
        }
```

#### AUTO 


```{c}
auto ret = std::shared_ptr<ByteArrayOutput>(new ByteArrayOutput(data));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.protocol() == CMS; }
```

#### AUTO 


```{c}
auto classification = input->classification();
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Change Admin Key"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : attrOrder) {
            const QString key = rawKey.trimmed().toUpper();
            const QString attr = attributeFromKey(key);
            if (attr.isEmpty()) {
                continue;
            }
            const QString defaultPreset = (attr == QLatin1String("CN")) ? emailSettings.getSetting(KEMailSettings::RealName) :
                                          (attr == QLatin1String("EMAIL")) ? emailSettings.getSetting(KEMailSettings::EmailAddress) :
                                          QString();
            const QString preset = config.readEntry(attr, defaultPreset);
            const bool required = key.endsWith(QLatin1Char('!'));
            const bool readonly = config.isEntryImmutable(attr);
            const QString label = config.readEntry(attr + QLatin1String("_label"),
                                                   attributeLabel(attr));
            const QString regex = config.readEntry(attr + QLatin1String("_regex"));

            QValidator *validator = nullptr;
            if (attr == QLatin1String("EMAIL")) {
                validator = regex.isEmpty() ? Validation::email() : Validation::email(QRegExp(regex));
            } else if (!regex.isEmpty()) {
                validator = new QRegExpValidator(QRegExp(regex), nullptr);
            }

            QLineEdit *le = addRow(ui.gridLayout, label, preset, validator, readonly, required);

            const Line line = { attr, label, regex, le, required };
            ui.lines.push_back(line);

            if (attr != QLatin1String("EMAIL")) {
                connect(le, &QLineEdit::textChanged, [this] () { updateDN(); });
            }
            connect(le, &QLineEdit::textChanged, [this] () { checkRequirements(); });
        }
```

#### AUTO 


```{c}
auto item = mRecpLayout->itemAtPosition(i, 1);
```

#### AUTO 


```{c}
auto action = actions.get(Actions::Close)
```

#### AUTO 


```{c}
const auto time = QDateTime::fromSecsSinceEpoch(subkey.creationTime());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        if (isChecksumFile(file)) {
            verifyFiles << file;
        } else {
            createFiles << file;
        }
    }
```

#### AUTO 


```{c}
const auto attrOrder = config.readEntry("OpenPGPAttributeOrder", QStringList{});
```

#### AUTO 


```{c}
auto key = d->key();
```

#### AUTO 


```{c}
auto progress = new QProgressDialog(this, Qt::CustomizeWindowHint | Qt::WindowTitleHint | Qt::Dialog);
```

#### AUTO 


```{c}
auto groupBox = new QGroupBox{i18nc("@title:group", "Certificate Usage"), technicalTab};
```

#### AUTO 


```{c}
const auto lineSeparator = widgets.keyInfoLabel->textFormat() == Qt::PlainText ? QLatin1String("\n") : QLatin1String("<br>");
```

#### AUTO 


```{c}
const auto infoText = nameIsRequired || emailIsRequired
                ? i18n("Enter a name and an email address to use for the user ID.")
                : i18n("Enter a name and/or an email address to use for the user ID.");
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const KeyGroup &group) {
                if (group.id() == mGroup.id()) {
                    QSignalBlocker blocky(this);
                    mGroup = group;
                    setText(Formatting::summaryLine(mGroup));
                    setToolTip(Formatting::toolTip(mGroup, Formatting::ToolTipOption::AllOptions));
                    mLineAction->setIcon(Formatting::validityIcon(mGroup));
                    mLineAction->setToolTip(Formatting::validity(mGroup) +
                                            QLatin1String("<br/>") + i18n("Click for details."));
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(Kleo::KeyListModelInterface::KeyRole).value<GpgME::Key>();
        m_expandedKeys.removeAll(QString::fromLatin1(key.primaryFingerprint()));
        m_group.writeEntry("Expanded", m_expandedKeys);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) {
        q->keyToPIVCardDone(err);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&archiveCmd](const std::shared_ptr<ArchiveDefinition> &toCheck) {
        return toCheck->id() == archiveCmd;
    }
```

#### AUTO 


```{c}
auto cmd = new ChangePinCommand(mRealSerial, OpenPGPCard::AppName, this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &s) { return QString::fromStdString(s).toHtmlEscaped(); }
```

#### AUTO 


```{c}
auto cmd = new Kleo::ImportCertificateFromFileCommand();
```

#### AUTO 


```{c}
auto cmd = Command::commandForQuery(needle);
```

#### AUTO 


```{c}
auto bbox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, qq);
```

#### AUTO 


```{c}
auto removeButton = new QPushButton();
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Recipient &rec) { return count_encrypt_certificates(proto, rec) == 1; }
```

#### AUTO 


```{c}
const auto currentItem = d->ui.subkeysTree->currentItem();
```

#### AUTO 


```{c}
auto *const firstStandardAction = menu->actions().value(0);
```

#### AUTO 


```{c}
auto w = window->nextInFocusChain();
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyRef] () { generateKey(keyRef); }
```

#### AUTO 


```{c}
const auto appendRow = [&html](const QString &lbl, const QString &val) {
        html += QStringLiteral("<tr>"
                               "<th style=\"text-align: right; padding-right: 5px; white-space: nowrap;\">%1:</th>"
                               "<td style=\"white-space: nowrap;\">%2</td>"
                               "</tr>")
                    .arg(lbl, val);
    };
```

#### AUTO 


```{c}
auto it = data.begin(), end = data.end();
```

#### AUTO 


```{c}
const auto isCMSOpaqueSignature = cFile.protocol == GpgME::CMS && mayBeOpaqueSignature(cFile.classification);
```

#### AUTO 


```{c}
const auto today = QDate::currentDate();
```

#### AUTO 


```{c}
const auto minDate = ui->expiryDE->minimumDate();
```

#### LAMBDA EXPRESSION 


```{c}
[this, action]() { d->slotActionTriggered(action); }
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit: qAsConst(mRecpWidgets)) {
        const auto editKey = edit->key();
        if (key.isNull() && editKey.isNull()) {
            recpRemovalRequested(edit);
            return;
        }
        if (editKey.primaryFingerprint() &&
            key.primaryFingerprint() &&
            !strcmp(editKey.primaryFingerprint(), key.primaryFingerprint())) {
            recpRemovalRequested(edit);
            return;
        }
    }
```

#### AUTO 


```{c}
const auto sigs = userId.signatures();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractItemView *view) { slotCurrentViewChanged(view); }
```

#### AUTO 


```{c}
static auto readKeyserverConfigs(const CryptoConfigEntry *configEntry)
{
    std::vector<KeyserverConfig> servers;
    if (configEntry) {
        const auto urls = configEntry->urlValueList();
        servers.reserve(urls.size());
        std::transform(std::begin(urls), std::end(urls),
                       std::back_inserter(servers),
                       &KeyserverConfig::fromUrl);
    }
    return servers;
}
```

#### LAMBDA EXPRESSION 


```{c}
[infoBtn, text] () {
        QToolTip::showText(infoBtn->mapToGlobal(QPoint()) + QPoint(infoBtn->width(), 0),
                           text, infoBtn, QRect(), 30000);
    }
```

#### AUTO 


```{c}
auto nextStepsGBLayout = new QVBoxLayout{nextStepsGB};
```

#### AUTO 


```{c}
auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) { slotKeyFilterChanged(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[&klc](const std::string &str) {
                        return !parse_keypairinfo_and_lookup_key(klc.get(), str);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profile: profiles) {
        combo->addItem(profile.baseName());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, fpr] () {
            qCDebug(KLEOPATRA_LOG) << "Updating key info after changes";
            ReaderStatus::mutableInstance()->updateStatus();
            mOpenPGPKeysWidget->update(nullptr);
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(nohupedCommands.begin(), nohupedCommands.end(),
                                     [cmd](const std::shared_ptr<AssuanCommand> &other) {
                                        return other.get() == cmd;
                                     });
```

#### AUTO 


```{c}
const auto url = QString::fromStdString(card->pubkeyUrl());
```

#### AUTO 


```{c}
auto outputLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto cmd = new LearnCardKeysCommand(GpgME::CMS);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    certificationsTV->setEnabled(true);
                    // Trigger an update when done
                    q->setKey(key);
                }
```

#### AUTO 


```{c}
auto availableKeysLayout = new QVBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &error) { slotResult(error); }
```

#### AUTO 


```{c}
auto it = d->m_tasks.begin(), end = d->m_tasks.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &connection : m_connections) {
        disconnect(connection);
    }
```

#### AUTO 


```{c}
const auto it = sd->mementos.find(tag);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
            if (!certWidget) {
                certWidget = certificateLineEdit;
            } else {
                certWidget = insertRecipientWidget(certWidget);
            }
            certWidget->setKey(key);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotNksPinRequested(); }
```

#### AUTO 


```{c}
const auto choice = KMessageBox::warningContinueCancel(parentWidgetOrView(), message,
            i18nc("@title:window", "Overwrite existing key"),
            KStandardGuiItem::cont(), KStandardGuiItem::cancel(), QString(), KMessageBox::Notify | KMessageBox::Dangerous);
```

#### AUTO 


```{c}
auto grid = new QGridLayout{q};
```

#### AUTO 


```{c}
const auto pgpPrefsKeys = pgpPrefs.keys();
```

#### AUTO 


```{c}
const auto resultSerialNumber = ReaderStatus::switchCard(assuanContext, serialNumber(), err);
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::RevokeCertificationCommand(userID);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &job) {
                      qCDebug(KLEOPATRA_LOG) << "Canceling job" << job.job;
                      std::for_each(std::cbegin(job.connections), std::cend(job.connections),
                                    &disconnectConnection);
                      job.job->slotCancel();
                      d->importResult(ImportResult{Error::fromCode(GPG_ERR_CANCELED)}, job.job);
                  }
```

#### AUTO 


```{c}
auto action = coll->action(QStringLiteral("configure_groups"))
```

#### AUTO 


```{c}
auto cmsEnd = keys.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : files) {
        CryptoFile cFile;
        cFile.fileName = file;
        cFile.baseName = file.left(file.length() - 4);
        cFile.classification = classify(file);
        cFile.protocol = findProtocol(cFile.classification);

        auto it = std::find_if(out.begin(), out.end(),
                               [&cFile](const CryptoFile &other) {
                                    return other.protocol == cFile.protocol
                                            && other.baseName == cFile.baseName;
                               });
        if (it != out.end()) {
            // If we found a file with the same basename, make sure that encrypted
            // file is before the signature file, so that we first decrypt and then
            // verify
            if (isSignature(cFile.classification) && isCipherText(it->classification)) {
                out.insert(it + 1, cFile);
            } else if (isCipherText(cFile.classification) && isSignature(it->classification)) {
                out.insert(it, cFile);
            } else {
                // both are signatures or both are encrypted files, in which
                // case order does not matter
                out.insert(it, cFile);
            }
        } else {
            out.push_back(cFile);
        }
    }
```

#### AUTO 


```{c}
auto pukButton = new QPushButton(i18n("Change Admin PIN"));
```

#### AUTO 


```{c}
auto pinButtton = new QPushButton(i18n("Change PIN"));
```

#### AUTO 


```{c}
auto newKey = Kleo::KeyCache::instance()->findByFingerprint(key.primaryFingerprint());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotNewTab(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg] () {doGenKey(dlg);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {

        const QFileInfo fi(file);
        const QDir dir = fi.dir();
        const QStringList entries = remove_checksum_files(dir.entryList(QDir::Files), patterns);

        QStringList inputFiles;
        if (allowAddition) {
            inputFiles = entries;
        } else {
            const std::vector<ChecksumsUtils::File> parsed = ChecksumsUtils::parse_sum_file(fi.absoluteFilePath());
            QStringList oldInputFiles;
            oldInputFiles.reserve(parsed.size());
            std::transform(parsed.cbegin(), parsed.cend(), std::back_inserter(oldInputFiles),
                           std::mem_fn(&ChecksumsUtils::File::name));
            inputFiles = fs_intersect(oldInputFiles, entries);
        }

        const Dir item = {
            dir,
            fi.fileName(),
            inputFiles,
            aggregate_size(dir, inputFiles),
            ChecksumsUtils::filename2definition(fi.fileName(), checksumDefinitions)
        };

        dirs.push_back(item);

        if (progress) {
            progress(++i);
        }

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { selectionChanged(); }
```

#### AUTO 


```{c}
const auto sigFpr = keys.readEntry("SigningKey", QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { writeCertificateToCard(PIVCard::pivAuthenticationKeyRef()); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) { editGroup(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.certifyBtn->setEnabled(true);
                     }
```

#### AUTO 


```{c}
const auto entry = conf->entry(QStringLiteral("gpg-agent"),
                                   QStringLiteral("Passphrase policy"),
                                   QStringLiteral("enforce-passphrase-constraints"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotDialogRejected(); }
```

#### AUTO 


```{c}
const auto userIDs{key.userIDs()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: recipients()) {
        if (!IS_DE_VS(key) || keyValidity(key) < GpgME::UserID::Validity::Full) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { addGroup(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ad : actionData) {
        // create actions for the context menu of the currently not active tabs,
        // but do not add those actions to the action collection
        auto action = new QAction(ad.text, coll);
        if (ad.icon) {
            action->setIcon(QIcon::fromTheme(QLatin1String(ad.icon)));
        }
        action->setEnabled(ad.actionState == Enabled);
        d->otherPageActions.insert(ad.name, action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QAction *action) {
                    const int col = action->data().toInt();
                    if ((col == TAGS_COLUMN) && action->isChecked()) {
                        Tags::enableTags();
                    }
                    if (action->isChecked()) {
                        showColumn(col);
                    } else {
                        hideColumn(col);
                    }

                    KeyTreeView *tv = qobject_cast<KeyTreeView *> (parent());
                    if (tv) {
                        tv->resizeColumns();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[keyUid](const GpgME::UserID &checkedUid) { return uidsAreEqual(keyUid, checkedUid); }
```

#### LAMBDA EXPRESSION 


```{c}
[prot](const GpgME::Key &key) { return key.protocol() != prot; }
```

#### RANGE FOR STATEMENT 


```{c}
for (QListWidgetItem *const i : selected) {
        delete i;
    }
```

#### AUTO 


```{c}
auto cmd = new Commands::DecryptVerifyFilesCommand(undetected, Q_NULLPTR, true);
```

#### AUTO 


```{c}
auto importjob = QGpgME::openpgp()->importJob();
```

#### AUTO 


```{c}
const auto appVersion = QByteArray::fromStdString(s).toUInt(&ok, 16);
```

#### AUTO 


```{c}
auto button = new QPushButton(i18nc("@action:button", "Change PIN"));
```

#### AUTO 


```{c}
const auto entry = conf->entry(cmp, QStringLiteral("Keyserver"), QStringLiteral("keyserver"));
```

#### AUTO 


```{c}
auto mailGrp = new QGroupBox(i18n("EMail Operations"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const CardInfo &ci) { return ci.status == CardHasNullPin; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawLine : qAsConst(trustListFileContents)) {

        const QString line = QString::fromLatin1(rawLine.data(), rawLine.size());
        if (!rx.exactMatch(line)) {
            qCDebug(KLEOPATRA_LOG) << "line \"" << rawLine.data() << "\" does not match";
            out.write(rawLine + '\n');
            continue;
        }
        const QString cap2 = rx.cap(2);
        if (cap2 != key && cap2 != keyColon) {
            qCDebug(KLEOPATRA_LOG) << qPrintable(key) << " != "
                                   << qPrintable(cap2) << " != "
                                   << qPrintable(keyColon);
            out.write(rawLine + '\n');
            continue;
        }
        found = true;
        const bool disabled = rx.cap(1) == QLatin1String("!");
        const QByteArray flags = rx.cap(3).toLatin1();
        const QByteArray rests = rx.cap(4).toLatin1();
        if (trust == Key::Ultimate)
            if (!disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write(keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        else if (trust == Key::Never) {
            if (disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write('!' + keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        }
        // else: trust == Key::Unknown
        // -> don't write - ie.erase
    }
```

#### AUTO 


```{c}
auto myLayout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const auto &err) { slotResult(err); }
```

#### LAMBDA EXPRESSION 


```{c}
[](SignEncryptFilesCommand*){}
```

#### RANGE FOR STATEMENT 


```{c}
for (const pair &p : v) {
        s << "status(" << QString::fromStdString(p.first) << ") =" << QString::fromStdString(p.second) << '\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QListWidgetItem *i : items) {
        entries.append(i->data(IdRole).toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Private::action_item &ai : std::as_const(d->actions))
        if (ai.action) {
            ai.action->setEnabled(ai.restrictions == (ai.restrictions & restrictionsMask));
        }
```

#### AUTO 


```{c}
const auto dateFormat = (locale().dateFormat(QLocale::ShortFormat) //
                                    .replace(QLatin1String{"yy"}, QLatin1String{"yyyy"})
                                    .replace(QLatin1String{"yyyyyyyy"}, QLatin1String{"yyyy"}));
```

#### AUTO 


```{c}
const auto resultAppName = switchApp(assuanContext, serialNumber, appName, err);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { import(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Command *cmd : allCmds) {
                if (parentId) {
                    cmd->setParentWId(parentId);
                } else {
                    MainWindow *mw = mainWindow();
                    if (!mw) {
                        mw = new MainWindow;
                        mw->setAttribute(Qt::WA_DeleteOnClose);
                        setMainWindow(mw);
                        d->connectConfigureDialog();
                    }
                    cmd->setParentWidget(mw);
                }
                cmd->start();
            }
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem;
```

#### AUTO 


```{c}
const auto info = Assuan::sendStatusLinesCommand(gpg_agent, "SCD LEARN --force", err);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Line &line : qAsConst(lineList)) {
        savedValues[ attributeFromKey(line.attr) ] = line.edit->text().trimmed();
    }
```

#### AUTO 


```{c}
const auto readers = hexdecode(readersData);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r: results) {
        //when a new certificate got a secret key
        if (r.result.numSecretKeysImported() >= 1) {
            const char *fingerPr = r.result.imports()[0].fingerprint();
            GpgME::Error err;
            QScopedPointer<Context>
                ctx(Context::createForProtocol(GpgME::Protocol::OpenPGP));

            if (!ctx){
                qCWarning(KLEOPATRA_LOG) << "Failed to get context";
                continue;
            }

            const Key toTrustOwner = ctx->key(fingerPr, err , false);

            if (toTrustOwner.isNull()) {
                return;
            }

            QStringList uids;
            const auto toTrustOwnerUserIDs{toTrustOwner.userIDs()};
            uids.reserve(toTrustOwnerUserIDs.size());
            for (const UserID &uid : toTrustOwnerUserIDs) {
                uids << Formatting::prettyNameAndEMail(uid);
            }

            const QString str = xi18nc("@info",
                "<title>You have imported a Secret Key.</title>"
                "<para>The key has the fingerprint:<nl/>"
                "<numid>%1</numid>"
                "</para>"
                "<para>And claims the User IDs:"
                "<list><item>%2</item></list>"
                "</para>"
                "Is this your own key? (Set trust level to ultimate)",
                QString::fromUtf8(fingerPr),
                uids.join(QLatin1String("</item><item>")));

            int k = KMessageBox::questionYesNo(nullptr, str, i18nc("@title:window",
                                                               "Secret key imported"));

            if (k == KMessageBox::Yes) {
                //To use the ChangeOwnerTrustJob over
                //the CryptoBackendFactory
                const QGpgME::Protocol *const backend = QGpgME::openpgp();

                if (!backend){
                    qCWarning(KLEOPATRA_LOG) << "Failed to get CryptoBackend";
                    return;
                }

                ChangeOwnerTrustJob *const j = backend->changeOwnerTrustJob();
                j->start(toTrustOwner, Key::Ultimate);
            }
        }
    }
```

#### AUTO 


```{c}
const auto key = d->userId.parent();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyInfo : PIVCard::supportedKeys()) {
        KeyWidgets keyWidgets = createKeyWidgets(keyInfo);
        layoutKeyWidgets(keysGrid, PIVCard::keyDisplayName(keyInfo.keyRef), keyWidgets);
    }
```

#### AUTO 


```{c}
auto statusBar = std::make_unique<QStatusBar>();
```

#### AUTO 


```{c}
const auto maxDate = ui->expiryDE->maximumDate();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { gnupgLogViewer(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](DecryptVerifyFilesCommand*){}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &oldCard: oldCards) {
                    qCDebug(KLEOPATRA_LOG) << "ReaderStatusThread: Card" << oldCard->serialNumber() << "with app" << oldCard->appName() << "was removed";
                    Q_EMIT cardRemoved(oldCard->serialNumber(), oldCard->appName());
                }
```

#### AUTO 


```{c}
auto cache = KeyCache::instance();
```

#### AUTO 


```{c}
auto archLabel = new QLabel(i18n("Archive command to use when archiving files:"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                this->setEnabled(true);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, chk]() {
            QDesktopServices::openUrl(QUrl(QStringLiteral("https://www.gpg4win.org/download.html")));
            KConfigGroup updatecfg(KSharedConfig::openConfig(), "UpdateNotification");
            updatecfg.writeEntry("NeverShow", !chk->isChecked());
            gpgconf_set_update_check (chk->isChecked());
            QDialog::accept();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : std::as_const(d->uids))
        if (qstricmp(uid.parent().primaryFingerprint(), key.primaryFingerprint()) != 0) {
            qCWarning(KLEOPATRA_LOG) << "User-ID <-> Key mismatch!";
            d->finished();
            return;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &scanning](int c) { Q_EMIT progress(c, 0, scanning); }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Recipient &rec) { return count_encrypt_certificates(proto, rec) >= 1; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyId : mKeyIds) {
        startImport(GpgME::OpenPGP, {keyId}, mId);
    }
```

#### AUTO 


```{c}
const auto infoText = i18n("X.509 key pairs are certified by a certification authority (CA). The generated request needs to be sent to a CA to finalize creation.");
```

#### LAMBDA EXPRESSION 


```{c}
[this, protocol](const GpgME::Error &result) {
        if (protocol == CMS) {
            cmsDeleteResult(result);
        } else {
            pgpDeleteResult(result);
        }
    }
```

#### AUTO 


```{c}
const auto *const ap = anchorProvider()
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : std::as_const(mColumnActions)) {
                const int column = action->data().toInt();
                action->setChecked(!isColumnHidden(column));
            }
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::KeyToCardCommand(subkey, card->serialNumber(), card->appName());
```

#### AUTO 


```{c}
const auto time = QDateTime::fromSecsSinceEpoch(mSubkey.creationTime());
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const std::shared_ptr<Task> &task) { return task->protocol() == proto; }
```

#### AUTO 


```{c}
const auto cd = qvariant_cast< std::shared_ptr<ChecksumDefinition> >(mChecksumDefinitionCB->itemData(idx));
```

#### AUTO 


```{c}
auto ffci = dynamic_cast<Kleo::FocusFirstChild *>(widget)
```

#### AUTO 


```{c}
auto helpButton = buttonBox()->button(QDialogButtonBox::Help);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: key.userIDs()) {
        if (uid.validity() >= GpgME::UserID::Marginal) {
            // Already marginal so don't bug the user
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) { slotResult(err); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) { slotActivated(index); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp &rx : rxs) {
        end = std::remove_if(l.begin(), end,
                             [rx](const QString &str) { 
                                return rx.exactMatch(str);
                             });
    }
```

#### AUTO 


```{c}
auto isGood(const GpgME::UserID::Signature &signature)
{
    return signature.status() == GpgME::UserID::Signature::NoError &&
           !signature.isInvalid() &&
           0x10 <= signature.certClass() && signature.certClass() <= 0x13;
}
```

#### AUTO 


```{c}
const auto toTrustOwnerUserIDs{toTrustOwner.userIDs()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
            addItem(Formatting::formatForComboBox(key), QVariant::fromValue(key));
        }
```

#### AUTO 


```{c}
auto cmd = new NewOpenPGPCertificateCommand{view(), controller()};
```

#### AUTO 


```{c}
auto it = mementos.begin(), end = mementos.end();
```

#### AUTO 


```{c}
static const auto initialRetryDelay = 125ms;
```

#### AUTO 


```{c}
const auto maxDate = ui.expiryDE->maximumDate();
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &k) { return k.subkey(0).isSecret() || k.subkey(0).isCardKey(); }
```

#### LAMBDA EXPRESSION 


```{c}
[parent, progress, proc](int exitCode, QProcess::ExitStatus exitStatus) {
            qCDebug(KLEOPATRA_LOG) << "Update force exited with status:" << exitStatus
                                   << "code:" << exitCode;
            delete progress;
            proc->deleteLater();
            UpdateNotification::checkUpdate(parent, exitStatus == QProcess::NormalExit);
    }
```

#### AUTO 


```{c}
auto ba = process.readAllStandardError();
```

#### AUTO 


```{c}
const auto imports = r.result.imports();
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout{q};
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Mailbox &signer) {
                       return resolveSigner(signer, proto);
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const CertificateSelectionLine &l) {
                                                          return l.wasInitiallyAmbiguous(proto);
                                                      }
```

#### AUTO 


```{c}
auto *const newEntry = configEntry(s_pgpservice_componentName, s_pgpservice_entryName,
                                           CryptoConfigEntry::ArgType_String, SingleValue, DoNotShowError);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {doChangePin(3);}
```

#### AUTO 


```{c}
auto secKeyLay = new QHBoxLayout{q};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    ui.moreDetailsBtn->setEnabled(true);
                }
```

#### AUTO 


```{c}
const auto card = SmartCard::ReaderStatus::instance()->getCard(serialNumber(), appName);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.refreshBtn->setEnabled(true);
                     }
```

#### AUTO 


```{c}
const auto emailIsRequired = attrOrder.contains(QLatin1String{"EMAIL!"}, Qt::CaseInsensitive);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Q_EMIT changed(true); }
```

#### AUTO 


```{c}
auto const item = new QStandardItem;
```

#### LAMBDA EXPRESSION 


```{c}
[this, chk]() {
            QDesktopServices::openUrl(QUrl("https://www.gpg4win.org/download.html"));
            KConfigGroup updatecfg(KSharedConfig::openConfig(), "UpdateNotification");

            updatecfg.writeEntry("NeverShow", !chk->isChecked());
            QDialog::accept();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(mColumnActions)) {
                const int column = action->data().toInt();
                action->setChecked(!isColumnHidden(column));
            }
```

#### AUTO 


```{c}
auto parts = text.split(' ');
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : std::as_const(groupList)) {
            const KConfigGroup kcg(config, group);
            if (!KCONFIG_DELETEGROUP_BROKEN || kcg.readEntry("magic", 0U) == 0xFA1AFE1U) {
                addView(kcg);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { doChangePin(OpenPGPCard::adminPinKeyRef()); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        updateButtons();
        if (QPushButton *button = buttonBox()->button(QDialogButtonBox::Reset)) {
            button->setEnabled(d->configPage->hasChanged());
        }
    }
```

#### AUTO 


```{c}
const auto result = switchApp(gpg_agent, serialNumber, appName, err);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {Q_EMIT (q->backRequested());}
```

#### LAMBDA EXPRESSION 


```{c}
[this](const CertsVec &certs) { slotImportRequested(certs); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotAttentionAnimationTimerTimout(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *const o : list) {
        if (QWidget *const w = qobject_cast<QWidget *>(o)) {
            w->setDisabled(passive && w != ui.closePB() && w != ui.buttonBox);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey : key.subkeys()) {
        auto item = new QTreeWidgetItem();
        item->setData(0, Qt::DisplayRole, Formatting::prettyID(subkey.keyID()));
        item->setData(0, Qt::UserRole, QVariant::fromValue(subkey));
        item->setData(1, Qt::DisplayRole, Kleo::Formatting::type(subkey));
        item->setData(2, Qt::DisplayRole, Kleo::Formatting::creationDateString(subkey));
        item->setData(3, Qt::DisplayRole, Kleo::Formatting::expirationDateString(subkey));
        item->setData(4, Qt::DisplayRole, Kleo::Formatting::validityShort(subkey));
        switch (subkey.publicKeyAlgorithm()) {
            case GpgME::Subkey::AlgoECDSA:
            case GpgME::Subkey::AlgoEDDSA:
            case GpgME::Subkey::AlgoECDH:
                item->setData(5, Qt::DisplayRole, QString::fromStdString(subkey.algoName()));
                break;
            default:
                item->setData(5, Qt::DisplayRole, QString::number(subkey.length()));
        }
        item->setData(6, Qt::DisplayRole, Kleo::Formatting::usageString(subkey));
        item->setData(7, Qt::DisplayRole, subkey.keyID() == key.keyID() ? QStringLiteral("?") : QString());
        d->ui.subkeysTree->addTopLevelItem(item);
        if (subkey.fingerprint() == selectedKeyFingerprint) {
            d->ui.subkeysTree->setCurrentItem(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Dir &dir : dirs) {
                Q_EMIT progress(done / factor, total / factor,
                                i18n("Checksumming (%2) in %1", dir.checksumDefinition->label(), dir.dir.path()));
                bool fatal = false;
                const QString error = process(dir, &fatal);
                if (!error.isEmpty()) {
                    errors.push_back(error);
                } else {
                    created.push_back(dir.dir.absoluteFilePath(dir.sumFile));
                }
                done += dir.totalSize;
                if (fatal || canceled) {
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: uids) {
                        lines.push_back(Formatting::prettyUserID(uid));
                    }
```

#### AUTO 


```{c}
const auto &key = sender.resolvedSigningKey(presetProtocol);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        // Check if any unknown recipient can now be found.
        for (auto w: mUnknownWidgets) {
            auto key = KeyCache::instance()->findByKeyIDOrFingerprint(w->keyID().toLatin1().constData());
            if (key.isNull()) {
                std::vector<std::string> subids;
                subids.push_back(std::string(w->keyID().toLatin1().constData()));
                for (const auto &subkey: KeyCache::instance()->findSubkeysByKeyID(subids)) {
                    key = subkey.parent();
                }
            }
            if (key.isNull()) {
                continue;
            }
            // Key is now available replace by line edit.
            qCDebug(KLEOPATRA_LOG) << "Removing widget for keyid: " << w->keyID();
            mRecpLayout->removeWidget(w);
            mUnknownWidgets.removeAll(w);
            delete w;
            addRecipient(key);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) {
            for (CertificateLineEdit *edit : std::as_const(mRecpWidgets)) {
                edit->setEnabled(toggled);
            }
            updateOp();
        }
```

#### AUTO 


```{c}
static auto informationOnChanges(const ImportResult &result)
{
    QString text;

    // if additional keys have been retrieved via WKD, then most of the below
    // details are just a guess and may concern the additional keys instead of
    // the refresh keys; this could only be clarified by a thorough comparison of
    // unrefreshed and refreshed key

    if (result.numUnchanged() == result.numConsidered()) {
        // if numUnchanged < numConsidered, then it is not clear whether the refreshed key
        // hasn't changed or whether another key retrieved via WKD hasn't changed
        text = i18n("The key hasn't changed.");
    } else if (result.newRevocations() > 0) {
        // it is possible that a revoked key has been newly imported via WKD,
        // but it is much more likely that the refreshed key was revoked
        text = i18n("The key has been revoked.");
    } else {
        // it doesn't make much sense to list below details if the key has been revoked
        text = i18n("The key has been updated.");

        QStringList details;
        if (result.newUserIDs() > 0) {
            details.push_back(i18n("New user IDs: %1", result.newUserIDs()));
        }
        if (result.newSubkeys() > 0) {
            details.push_back(i18n("New subkeys: %1", result.newSubkeys()));
        }
        if (result.newSignatures() > 0) {
            details.push_back(i18n("New signatures: %1", result.newSignatures()));
        }
        if (!details.empty()) {
            text += QLatin1String{"<br><br>"} + details.join(QLatin1String{"<br>"});
        }
    }

    text = QLatin1String{"<p>"} + text + QLatin1String{"</p>"};
    if (result.numImported() > 0) {
        text += QLatin1String{"<p>"} + i18np("Additionally, one new key has been retrieved.",
                                             "Additionally, %1 new keys have been retrieved.",
                                             result.numImported()) + QLatin1String{"</p>"};
    }

    return text;
}
```

#### AUTO 


```{c}
auto tabWidget = new QTabWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey : key.subkeys()) {
        auto item = new QTreeWidgetItem();
        item->setData(0, Qt::DisplayRole, QString::fromLatin1(subkey.keyID()));
        item->setData(0, Qt::UserRole, QVariant::fromValue(subkey));
        item->setData(1, Qt::DisplayRole, Kleo::Formatting::type(subkey));
        item->setData(2, Qt::DisplayRole, Kleo::Formatting::creationDateString(subkey));
        item->setData(3, Qt::DisplayRole, Kleo::Formatting::expirationDateString(subkey));
        item->setData(4, Qt::DisplayRole, Kleo::Formatting::validityShort(subkey));
        item->setData(5, Qt::DisplayRole, QString::number(subkey.length()));
        item->setData(6, Qt::DisplayRole, Kleo::Formatting::usageString(subkey));
        d->ui.subkeysTree->addTopLevelItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, gpgconf, profile] () {
        mApplyBtn->setEnabled(true);
        if (gpgconf->exitStatus() != QProcess::NormalExit) {
            KMessageBox::error(this, QStringLiteral("<pre>%1</pre>").arg(QString::fromUtf8(gpgconf->readAll())));
            delete gpgconf;
            return;
        }
        delete gpgconf;
        KMessageBox::information(this,
                         i18nc("%1 is the name of the profile",
                               "The configuration profile \"%1\" was applied.", profile),
                         i18n("GnuPG Profile - Kleopatra"));
        auto config = QGpgME::cryptoConfig();
        if (config) {
            config->clear();
        }
        KeyFilterManager::instance()->reload();
    }
```

#### AUTO 


```{c}
auto const cmd = new ChecksumVerifyFilesCommand(verifyFiles, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { onDescriptionEditingFinished(); }
```

#### AUTO 


```{c}
auto gridLayout = new QGridLayout{};
```

#### AUTO 


```{c}
const auto subkey = key.subkey(0);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (unsigned int slot) {
                if (slot == 0) {
                    const auto cards = ReaderStatus::instance()->getCards();
                    if (!cards.size()) {
                        setCard(std::shared_ptr<Card>(new Card()));
                    } else {
                        // No support for multiple reader / cards currently
                        setCard(cards[0]);
                    }
                }
            }
```

#### AUTO 


```{c}
auto args = d->process.arguments();
```

#### AUTO 


```{c}
auto le = new QLineEdit(l->parentWidget());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(Kleo::KeyListModelInterface::KeyRole).value<GpgME::Key>();
        const auto fpr = QString::fromLatin1(key.primaryFingerprint());

        if (m_expandedKeys.contains(fpr)) {
            return;
        }
        m_expandedKeys << fpr;
        m_group.writeEntry("Expanded", m_expandedKeys);
    }
```

#### AUTO 


```{c}
auto statusLbl = new QLabel(i18nc("Compliance means that GnuPG is running in a more restricted mode e.g. to handle restricted documents.",
                                        // The germans want some extra sausage
                                        "Compliance: %1", complianceMode == QLatin1String("de-vs") ? QStringLiteral ("VS-NfD") : complianceMode));
```

#### AUTO 


```{c}
auto publishLay = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[](auto canceledIds, const auto &r) {
                                                 if (importWasCanceled(r)) {
                                                     canceledIds.insert(r.id);
                                                 }
                                                 return canceledIds;
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { doChangePin(OpenPGPCard::resetCodeKeyRef(), ChangePinCommand::ResetMode); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : netKeyCard->keyInfos()) {
        if (key.canSign() && (((key.keyRef.substr(0, 9) == "NKS-NKS3.") && !netKeyCard->hasNKSNullPin()) ||
                              ((key.keyRef.substr(0, 9) == "NKS-SIGG.") && !netKeyCard->hasSigGNullPin()))) {
            keys.push_back(key);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            checkAccept();
        }
```

#### AUTO 


```{c}
auto bbox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sig: verifyResult.signatures()) {
        if (!(sig.summary() & GpgME::Signature::KeyMissing)) {
            continue;
        }

        auto btn = new QPushButton;
        QString suffix;
        const auto keyid = QLatin1String(sig.fingerprint());
        if (verifyResult.numSignatures() > 1) {
            suffix = QLatin1Char(' ') + keyid;
        }
        btn = new QPushButton(search ? i18nc("1 is optional keyid. No space is intended as it can be empty.",
                                       "Search%1", suffix)
                                     : i18nc("1 is optional keyid. No space is intended as it can be empty.",
                                       "Import%1", suffix));

        if (search) {
            btn->setIcon(QIcon::fromTheme("edit-find"));
            connect (btn, &QPushButton::clicked, q, [this, btn, keyid] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::Commands::LookupCertificatesCommand(keyid, nullptr);
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            });
        } else {
            btn->setIcon(QIcon::fromTheme("view-certificate-import"));
            connect (btn, &QPushButton::clicked, q, [this, btn] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::ImportCertificateFromFileCommand();
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            });
        }
        btn->setFixedSize(btn->sizeHint());
        lay->addWidget(btn);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[path](const auto &r) {
                            return r.id == path && !importFailed(r);
                        }
```

#### AUTO 


```{c}
const auto *const legacyEntry = configEntry(s_x509services_legacy_componentName, s_x509services_legacy_entryName,
                                                    CryptoConfigEntry::ArgType_LDAPURL, ListValue, DoNotShowError);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &s: signatures) {
                    DecryptVerifyOperationWidget *op = m_wizard->operationWidget(counter++);
                    kleo_assert(op != nullptr);

                    op->setArchiveDefinitions(archiveDefinitions);
                    op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignedData);
                    op->setInputFileName(s);
                    op->setSignedDataFileName(fname);

                    m_filesAfterPreparation << fname;
                }
```

#### AUTO 


```{c}
const auto supportedProtocolsLst = supportedProtocols();
```

#### AUTO 


```{c}
const auto fprs = Assuan::sendStatusLinesCommand(gpg_agent, "SCD GETATTR KEY-FPR", err);
```

#### AUTO 


```{c}
const auto lastKey = mCertWidget->secKey();
```

#### AUTO 


```{c}
auto input = std::shared_ptr<OutputInput>(new OutputInput(fo));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
        // Yep you can have one subkey associated with multiple
        // primary keys.
        toolTips << Formatting::toolTip(sub.parent(), Formatting::Validity |
                                        Formatting::StorageLocation |
                                        Formatting::ExpiryDates |
                                        Formatting::UserIDs |
                                        Formatting::Fingerprint);
    }
```

#### AUTO 


```{c}
const auto group = KeyListSortFilterProxyModel::data(idx, KeyList::GroupRole).value<KeyGroup>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : std::as_const(mRecpWidgets)) {
        if (w->key().isNull() && w->group().isNull()) {
            oneEmpty = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto id = requester.id;
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey]() {
            auto cmd = new KeyToCardCommand(subkey);
            ui.subkeysTree->setEnabled(false);
            connect(cmd, &KeyToCardCommand::finished,
                    q, [this]() { ui.subkeysTree->setEnabled(true); });
            cmd->setParentWidget(q);
            cmd->start();
        }
```

#### AUTO 


```{c}
const auto mailText = text();
```

#### AUTO 


```{c}
const auto &card
```

#### AUTO 


```{c}
const auto signatures = findSignatures(fName);
```

#### LAMBDA EXPRESSION 


```{c}
[this](GpgME::KeyListResult result, std::vector<GpgME::Key>, QString, GpgME::Error) {
                signatureListingDone(result);
            }
```

#### AUTO 


```{c}
const auto other = dynamic_cast<const PIVCard *>(&rhs);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &allIds, const auto &r) {
                                            allIds.insert(r.id);
                                            return allIds;
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            doChangePin(NetKeyCard::nksPinKeyRef());
        }
```

#### AUTO 


```{c}
auto selectedRows()
    {
        return ui.groupsList->selectionModel()->selectedRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sig : signatures) {
                    qCDebug(KLEOPATRA_LOG) << "Guessing: " << sig << " is a signature for: " << fName;
                    std::shared_ptr<VerifyDetachedTask> t(new VerifyDetachedTask);
                    t->setInput(Input::createFromFile(sig));
                    t->setSignedData(Input::createFromFile(fName));
                    t->setProtocol(proto);
                    tasks.push_back(t);
                }
```

#### AUTO 


```{c}
const auto *const job = qobject_cast<const QGpgME::Job *>(q->sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                ui.userIDTable->setEnabled(true);
                updateKey();
            }
```

#### AUTO 


```{c}
const auto classification = classify(fName);
```

#### AUTO 


```{c}
auto cmd = new NewCertificateCommand(Q_NULLPTR);
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::GenRevokeCommand(key);
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *ExpandAll = "window_expand_all";
```

#### AUTO 


```{c}
const auto keyserverUrl = keyserver.contains(QLatin1String{"://"}) ? keyserver : (QLatin1String{"hkps://"} + keyserver);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Protocol i : supportedProtocols()) {
        if (isProtocolChecked(i)) {
            res.insert(i);
        }
    }
```

#### AUTO 


```{c}
const auto statusLines = gpgagent_statuslines(gpgAgent, command.c_str(), err);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Dir &dir : dirs) {
        qCDebug(KLEOPATRA_LOG) << dir;
    }
```

#### AUTO 


```{c}
const auto keys = d->keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &key: mAddedKeys) {
        removeRecipient(key);
    }
```

#### AUTO 


```{c}
auto const b = new QCheckBox;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) {
        changeUrlResult(err);
    }
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(q);
```

#### AUTO 


```{c}
const auto output =
                ad       ? ad->createOutputFromUnpackCommand(proto, fName, wd) :
                /*else*/   Output::createFromFile(wd.absoluteFilePath(outputFileName(fi.fileName())), false);
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::DumpCertificateCommand(key);
```

#### LAMBDA EXPRESSION 


```{c}
[protocol](const auto &k) {
                            return k.hasSecret() && k.canReallySign() && (k.protocol() == protocol);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys)
        if (key.hasSecret() && key.ownerTrust() == Key::Ultimate) {
            return false;
        }
```

#### AUTO 


```{c}
auto ret = KMessageBox::warningContinueCancel(this,
                i18n("The existing keys on this card will be <b>deleted</b> "
                     "and replaced by new keys.") + QStringLiteral("<br/><br/>") +
                i18n("It will no longer be possible to decrypt past communication "
                     "encrypted for the existing key."),
                i18n("Secret Key Deletion"),
                KStandardGuiItem::guiItem(KStandardGuiItem::Delete),
                KStandardGuiItem::cancel(), QString(), KMessageBox::Notify | KMessageBox::Dangerous);
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) { return key.hasSecret(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &actionData : data) {
        coll->addAction(QLatin1String(actionData.name), make_action_from_data(actionData, coll));
    }
```

#### AUTO 


```{c}
const auto helpAction = new Kleo::DocAction(QIcon::fromTheme(QStringLiteral("help")),
            i18n("Help"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                  "handout_group-feature_gnupg_en.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sig: verifyResult.signatures()) {
        if (!(sig.summary() & GpgME::Signature::KeyMissing)) {
            continue;
        }

        auto btn = new QPushButton;
        QString suffix;
        const auto keyid = QLatin1String(sig.fingerprint());
        if (verifyResult.numSignatures() > 1) {
            suffix = QLatin1Char(' ') + keyid;
        }
        btn = new QPushButton(search ? i18nc("1 is optional keyid. No space is intended as it can be empty.",
                                       "Search%1", suffix)
                                     : i18nc("1 is optional keyid. No space is intended as it can be empty.",
                                       "Import%1", suffix));

        if (search) {
            btn->setIcon(QIcon::fromTheme(QStringLiteral("edit-find")));
            connect (btn, &QPushButton::clicked, q, [this, btn, keyid] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::Commands::LookupCertificatesCommand(keyid, nullptr);
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            });
        } else {
            btn->setIcon(QIcon::fromTheme(QStringLiteral("view-certificate-import")));
            connect (btn, &QPushButton::clicked, q, [this, btn] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::ImportCertificateFromFileCommand();
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            });
        }
        btn->setFixedSize(btn->sizeHint());
        lay->addWidget(btn);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[model] (const KeyGroup &group) {
                       return model->index(group);
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) {
                                    return QString::compare(lhs, rhs, ChecksumsUtils::fs_cs) < 0;
                                  }
```

#### AUTO 


```{c}
const auto keyRef = values[1].toStdString();
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { checkAccept(); }
```

#### AUTO 


```{c}
auto importAction = new QAction(q);
```

#### AUTO 


```{c}
auto sel = KMessageBox::questionYesNo(parentWidgetOrView(),
                i18n("In order to mark the certificate as valid (green) it needs to be certified.") + QStringLiteral("<br>") +
                i18n("Certifying means that you check the Fingerprint.") + QStringLiteral("<br>") +
                i18n("Some suggestions to do this are:") +
                QStringLiteral("<li><ul>%1").arg(suggestions.join(QStringLiteral("</ul><ul>"))) +
                QStringLiteral("</ul></li>") +
                i18n("Do you wish to start this process now?"),
                i18nc("@title", "You have imported a new certificate (public key)"),
                KStandardGuiItem::yes(), KStandardGuiItem::no(), QStringLiteral("CertifyQuestion"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &i : qAsConst(certs)) {
        addCertificateToComboBox(i);
    }
```

#### AUTO 


```{c}
const auto comp = conf->component (m_component);
```

#### AUTO 


```{c}
const auto slot = getOpenPGPCardSlotForKey(subkey, parentWidgetOrView());
```

#### AUTO 


```{c}
const auto cds = ChecksumDefinition::getChecksumDefinitions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : list) {
        d->addFile(QFileInfo(i));
    }
```

#### AUTO 


```{c}
auto it = std::find_if(out.begin(), out.end(),
                               [&cFile](const CryptoFile &other) {
                                    return other.protocol == cFile.protocol
                                            && other.baseName == cFile.baseName;
                               });
```

#### AUTO 


```{c}
auto mainLay = new QVBoxLayout(q);
```

#### AUTO 


```{c}
const auto *const entry = d->readerPortConfigEntry();
```

#### AUTO 


```{c}
const auto keys = g.keys();
```

#### AUTO 


```{c}
const auto values = QString::fromStdString(s).split(QLatin1Char(' '));
```

#### AUTO 


```{c}
const auto minimumExpiry = std::max(0, settings.validityPeriodInDaysMin());
```

#### AUTO 


```{c}
const auto formatted = lastName + QStringLiteral("<<") + parts.join('<');
```

#### LAMBDA EXPRESSION 


```{c}
[path](const auto &group) {
                               return storeGroup(group, path);
                           }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool value) {
                    if (value) {
                        mSigEncWidget->setProtocol(GpgME::CMS);
                    }
                }
```

#### AUTO 


```{c}
const auto legacyEntry = configEntry(s_x509services_legacy_componentName, s_x509services_legacy_entryName,
                                         CryptoConfigEntry::ArgType_LDAPURL, ListValue, DoNotShowError);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { editFinished(); }
```

#### AUTO 


```{c}
const auto selectedGroups = getGroups(selectedRows());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &link) { d->slotLinkActivated(link); }
```

#### AUTO 


```{c}
const auto ad = getDefaultAd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sig : signatures) {
                    const auto classification = classify(sig);
                    qCDebug(KLEOPATRA_LOG) << "Guessing: " << sig << " is a signature for: " << cFile.fileName
                                           << "Classification: " << classification;
                    const auto proto = findProtocol(classification);
                    if (proto == GpgME::UnknownProtocol) {
                        qCDebug(KLEOPATRA_LOG) << "Could not determine protocol. Skipping guess.";
                        continue;
                    }
                    foundSig = true;
                    std::shared_ptr<VerifyDetachedTask> t(new VerifyDetachedTask);
                    t->setInput(Input::createFromFile(sig));
                    t->setSignedData(Input::createFromFile(cFile.fileName));
                    t->setProtocol(findProtocol(classification));
                    tasks.push_back(t);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool state) {
                    mUseOutputDir = state;
                    mArchive = !mUseOutputDir && !mSingleFile;
                    updateFileWidgets();
                }
```

#### AUTO 


```{c}
const auto &anchor = d->anchors()[index];
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : qAsConst(mRecpWidgets)) {
        if (!w->isEnabled()) {
            // If one is disabled, all are disabled.
            break;
        }
        const Key k = w->key();
        const KeyGroup g = w->group();
        if (!k.isNull()) {
            ret.push_back(k);
        } else if (!g.isNull()) {
            const auto keys = g.keys();
            std::copy(keys.begin(), keys.end(), std::back_inserter(ret));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : std::as_const(attrOrder)) {
        const QString key = rawKey.trimmed().toUpper();
        const QString attr = attributeFromKey(key);
        if (attr.isEmpty()) {
            continue;
        }
        const QString preset = savedValues.value(attr, config.readEntry(attr, QString()));
        const bool required = key.endsWith(QLatin1Char('!'));
        const bool readonly = config.isEntryImmutable(attr);
        const QString label = config.readEntry(attr + QLatin1String("_label"),
                                               attributeLabel(attr, pgp()));
        const QString regex = config.readEntry(attr + QLatin1String("_regex"));
        const QString placeholder = config.readEntry(attr + QLatin1String{"_placeholder"});

        int row;
        bool known = true;
        QValidator *validator = nullptr;
        if (attr == QLatin1String("EMAIL")) {
            row = row_index_of(ui.emailLE, ui.gridLayout);
            validator = regex.isEmpty() ? Validation::email() : Validation::email(regex);
        } else if (attr == QLatin1String("NAME") || attr == QLatin1String("CN")) {
            if ((pgp() && attr == QLatin1String("CN")) || (!pgp() && attr == QLatin1String("NAME"))) {
                continue;
            }
            if (pgp()) {
                validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(regex);
            }
            row = row_index_of(ui.nameLE, ui.gridLayout);
        } else {
            known = false;
            row = add_row(ui.gridLayout, &dynamicWidgets);
        }
        if (!validator && !regex.isEmpty()) {
            validator = new QRegularExpressionValidator{QRegularExpression{regex}, nullptr};
        }

        QLineEdit *le = adjust_row(ui.gridLayout, row, label, preset, validator, readonly, required);
        le->setPlaceholderText(placeholder);

        const Line line = { key, label, regex, le };
        lines[row] = line;

        if (!known) {
            widgets.push_back(le);
        }

        // don't connect twice:
        disconnect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
        connect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
    }
```

#### AUTO 


```{c}
const auto it
            = std::lower_bound(conn.factories.begin(), conn.factories.end(), commandName, _detail::ByName<std::less>());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            auto action = q->actionCollection()->action(QStringLiteral("manage_smartcard"));
            Q_ASSERT(action);
            action->setChecked(false);
        }
```

#### AUTO 


```{c}
const auto &fname
```

#### AUTO 


```{c}
auto button = new QPushButton(i18nc("@action:button", "Change Admin Key"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                const bool haveSecretKeys = !KeyCache::instance()->secretKeys().empty();
                const bool havePublicKeys = !KeyCache::instance()->keys().empty();
                const bool symmetricOnly = FileOperationsPreferences().symmetricEncryptionOnly();
                mSigChk->setEnabled(haveSecretKeys);
                mEncSelfChk->setEnabled(haveSecretKeys && !symmetricOnly);
                mEncOtherChk->setEnabled(havePublicKeys && !symmetricOnly);
            }
```

#### AUTO 


```{c}
auto hLay3 = new QHBoxLayout();
```

#### AUTO 


```{c}
auto label = new QLabel{infoText, q};
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QAction *action) {
                    if (action->isChecked()) {
                        showColumn(action->data().toInt());
                    } else {
                        hideColumn(action->data().toInt());
                    }

                    KeyTreeView *tv = qobject_cast<KeyTreeView *> (parent());
                    if (tv) {
                        tv->resizeColumns();
                    }
                }
```

#### AUTO 


```{c}
const auto vsa10573 = new DocAction(QIcon::fromTheme(QStringLiteral("dvipdf")), i18n("SecOps VSA-10573"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                "BSI-VSA-10573-ENG_secops-20220207.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### AUTO 


```{c}
auto chkLabel = new QLabel(i18n("Checksum program to use when creating checksum files:"));
```

#### AUTO 


```{c}
const auto bytesWritten = file.write(request);
```

#### AUTO 


```{c}
auto cmd = new Commands::DetailsCommand(certificateLineEdit->key(), nullptr);
```

#### AUTO 


```{c}
static const auto path = findGpgExe(GpgME::GpgSMEngine, QStringLiteral("gpg"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        canceled();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : toTrustOwnerUserIDs) {
                uids << Formatting::prettyNameAndEMail(uid);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QSystemTrayIcon::ActivationReason reason) { slotActivated(reason); }
```

#### AUTO 


```{c}
auto cmd = new Commands::NewCertificateCommand();
```

#### LAMBDA EXPRESSION 


```{c}
[this, scanning](int arg) { Q_EMIT progress(arg, 0, scanning); }
```

#### AUTO 


```{c}
auto pgpCard = new OpenPGPCard(*ci);
```

#### LAMBDA EXPRESSION 


```{c}
[this, learnBtn, learnLbl] () {
            learnBtn->setEnabled(false);
            auto cmd = new LearnCardKeysCommand(GpgME::CMS);
            cmd->setParentWidget(this);
            cmd->start();
            learnLbl->setVisible(true);
            learnLbl->setText(i18n("Loading certificates..."));

            connect(cmd, &Command::finished, this, [learnBtn, learnLbl] () {
                learnLbl->setText(i18n("Certificates added to the certificate list."));
            });
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &i : qAsConst(m_runnableTasks)) {
        q->connectTask(i);
    }
```

#### AUTO 


```{c}
auto cmd = new AuthenticatePIVCardApplicationCommand(mSerial, parentWidgetOrView());
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout{parent};
```

#### LAMBDA EXPRESSION 


```{c}
[this](const std::shared_ptr<Kleo::KeyFilter> &filter) { slotPageKeyFilterChanged(filter); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fName : fileNames) {
        const auto classification = classify(fName);
        const auto proto = findProtocol(classification);

        QFileInfo fi(fName);
        qCDebug(KLEOPATRA_LOG) << "classified" << fName << "as" << printableClassification(classification);

        if (!fi.isReadable()) {
            reportError(makeGnuPGError(GPG_ERR_ASS_NO_INPUT),
                        xi18n("Cannot open <filename>%1</filename> for reading.", fName));
        } else if (mayBeAnyCertStoreType(classification)) {
            // Trying to verify a certificate. Possible because extensions are often similar
            // for PGP Keys.
            reportError(makeGnuPGError(GPG_ERR_ASS_NO_INPUT),
                        xi18n("The file <filename>%1</filename> contains certificates and can't be decrypted or verified.", fName));
            qCDebug(KLEOPATRA_LOG) << "reported error";
        } else if (isDetachedSignature(classification)) {
            // Detached signature, try to find data or ask the user.
            QString signedDataFileName = findSignedData(fName);
            if (signedDataFileName.isEmpty()) {
                signedDataFileName = QFileDialog::getOpenFileName(nullptr, xi18n("Select the file to verify with \"%1\"", fi.fileName()),
                                                                  fi.dir().dirName());
            }
            if (signedDataFileName.isEmpty()) {
                qCDebug(KLEOPATRA_LOG) << "No signed data selected. Verify abortet.";
                continue;
            }
            qCDebug(KLEOPATRA_LOG) << "Detached verify: " << fName << " Data: " << signedDataFileName;
            std::shared_ptr<VerifyDetachedTask> t(new VerifyDetachedTask);
            t->setInput(Input::createFromFile(fName));
            t->setSignedData(Input::createFromFile(signedDataFileName));
            t->setProtocol(proto);
            tasks.push_back(t);
        } else if (!mayBeAnyMessageType(classification)) {
            // Not a Message? Maybe there is a signature for this file?
            const auto signatures = findSignatures(fName);
            if (!signatures.empty()) {
                for (const QString &sig : signatures) {
                    qCDebug(KLEOPATRA_LOG) << "Guessing: " << sig << " is a signature for: " << fName;
                    std::shared_ptr<VerifyDetachedTask> t(new VerifyDetachedTask);
                    t->setInput(Input::createFromFile(sig));
                    t->setSignedData(Input::createFromFile(fName));
                    t->setProtocol(proto);
                    tasks.push_back(t);
                }
            } else {
                undetected << fName;
                qCDebug(KLEOPATRA_LOG) << "Failed detection for: " << fName << " adding to undetected.";
            }
        } else {
            // Any Message type so we have input and output.
            const auto input = Input::createFromFile(fName);
            const auto archiveDefinitions = ArchiveDefinition::getArchiveDefinitions();

            const auto ad = q->pick_archive_definition(proto, archiveDefinitions, fName);

            const auto wd = QDir(m_workDir.path());

            const auto output =
                ad       ? ad->createOutputFromUnpackCommand(proto, fName, wd) :
                /*else*/   Output::createFromFile(wd.absoluteFilePath(outputFileName(fi.fileName())), false);

            if (isOpaqueSignature(classification)) {
                qCDebug(KLEOPATRA_LOG) << "creating a VerifyOpaqueTask";
                std::shared_ptr<VerifyOpaqueTask> t(new VerifyOpaqueTask);
                t->setInput(input);
                t->setOutput(output);
                t->setProtocol(proto);
                tasks.push_back(t);
            } else {
                // Any message. That is not an opaque signature needs to be
                // decrypted. Verify we always do because we can't know if
                // an encrypted message is also signed.
                qCDebug(KLEOPATRA_LOG) << "creating a DecryptVerifyTask";
                std::shared_ptr<DecryptVerifyTask> t(new DecryptVerifyTask);
                t->setInput(input);
                t->setOutput(output);
                t->setProtocol(proto);
                tasks.push_back(t);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { generateKey(PIVCard::pivAuthenticationKeyRef()); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
            auto cmd = new Kleo::Commands::RevokeCertificationCommand(userID);
            ui.userIDTable->setEnabled(false);
            connect(cmd, &Kleo::Commands::RevokeCertificationCommand::finished,
                    q, [this]() {
                ui.userIDTable->setEnabled(true);
                updateKey();
            });
            cmd->start();
        }
```

#### AUTO 


```{c}
const auto nksCard = ReaderStatus::instance()->getCard<NetKeyCard>(mSerialNumber);
```

#### AUTO 


```{c}
const auto canceledIds = std::accumulate(std::cbegin(results), std::cend(results),
                                             std::set<QString>{},
                                             [](auto &canceledIds, const auto &r) {
                                                 if (importWasCanceled(r)) {
                                                     canceledIds.insert(r.id);
                                                 }
                                                 return canceledIds;
                                             });
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const KeyGroup &group) {
                if (!mGroup.isNull() && mGroup.source() == group.source() && mGroup.id() == group.id()) {
                    mGroup = KeyGroup();
                    QSignalBlocker blocky(this);
                    clear();
                    // queue the update to ensure that the model has been updated
                    QMetaObject::invokeMethod(this, &CertificateLineEdit::updateKey, Qt::QueuedConnection);
                }
            }
```

#### AUTO 


```{c}
const auto usage = values[2];
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) {
            for (CertificateLineEdit *edit : qAsConst(mRecpWidgets)) {
                edit->setEnabled(toggled);
            }
            updateOp();
        }
```

#### AUTO 


```{c}
auto label = labelForTag(tag);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &) {
                updateCommitButton();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Line &line : ui.lines ) {
            if (attributeFromKey(line.attr) == attribute) {
                return line.edit;
            }
        }
```

#### AUTO 


```{c}
const auto email = QString::fromUtf8(key.userID(0).email());
```

#### AUTO 


```{c}
auto label = new QLabel{i18n("This is how the new user ID will be stored in the certificate:"), q};
```

#### AUTO 


```{c}
const auto uids = key.userIDs();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : lines)
        if (line.startsWith(which) && line[qstrlen(which)] == ':') {
            const int begin = qstrlen(which) + 1;
            int end = line.size();
            while (end && (line[end - 1] == '\n' || line[end - 1] == '\r')) {
                --end;
            }
            const QString result = QDir::fromNativeSeparators(QFile::decodeName(hexdecode(line.mid(begin, end - begin))));
            qCDebug(KLEOPATRA_LOG) << "gpgConfListDir: found " << qPrintable(result)
                                   << " for '" << which << "'entry";
            return result;
        }
```

#### AUTO 


```{c}
const auto pgpCard = SmartCard::ReaderStatus::instance()->getCard<OpenPGPCard>(serialNumber());
```

#### AUTO 


```{c}
const auto settings = Kleo::Settings{};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
            // Yep you can have one subkey associated with mutliple
            // primary keys.
            toolTips << Formatting::toolTip(sub.parent(), Formatting::Validity |
                                            Formatting::StorageLocation |
                                            Formatting::ExpiryDates |
                                            Formatting::UserIDs |
                                            Formatting::Fingerprint);
        }
```

#### AUTO 


```{c}
auto protocolSelectionLay = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[](const std::shared_ptr<SelfTest> &test) {
                                        return test->failed();
                                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups)
        try {
            const std::shared_ptr<ArchiveDefinition> ad(new KConfigBasedArchiveDefinition(KConfigGroup(config, group)));
            result.push_back(ad);
        } catch (const std::exception &e) {
            qCDebug(KLEOPATRA_LOG) << e.what();
            errors.push_back(QString::fromLocal8Bit(e.what()));
        } catch (...) {
            errors.push_back(i18n("Caught unknown exception in group %1", group));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { createCSR(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (parseCardInfo(pair.first, pair.second)) {
            continue;
        }
        if (pair.first == "KEY-FPR" ||
            pair.first == "KEY-TIME") {
            // Key fpr and key time need to be distinguished, the number
            // of the key decides the usage.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[0];
            const auto fpr = values[1].toStdString();
            if (usage == QLatin1Char('1')) {
                mMetaInfo.insert(std::string("SIG") + pair.first, fpr);
            } else if (usage == QLatin1Char('2')) {
                mMetaInfo.insert(std::string("ENC") + pair.first, fpr);
            } else if (usage == QLatin1Char('3')) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, fpr);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### AUTO 


```{c}
auto e = static_cast<QContextMenuEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto fingerprints, const auto &import) {
                               if (import.status() == Import::NewKey) {
                                   fingerprints.push_back(import.fingerprint());
                               }
                               return fingerprints;
                           }
```

#### AUTO 


```{c}
auto const dlg = new ResultDialog(created, errors);
```

#### AUTO 


```{c}
auto it = options.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i: m_progressLabelByTag.keys()) {
        if (!i.isEmpty()) {
            m_progressLabelByTag.value(i)->setText(i18n("%1: All operations completed.", i));
        } else {
            m_progressLabelByTag.value(i)->setText(i18n("All operations completed."));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: keyPairInfoLines) {
        if (pair.first == "KEYPAIRINFO") {
            const KeyPairInfo info = KeyPairInfo::fromStatusLine(pair.second);
            if (info.grip.empty()) {
                qCWarning(KLEOPATRA_LOG) << "Invalid KEYPAIRINFO status line"
                        << QString::fromStdString(pair.second);
                continue;
            }
            pivCard->setKeyAlgorithm(keyRef, info.algorithm);
        } else {
            logUnexpectedStatusLine(pair, "readKeyPairInfoFromPIVCard()", command);
        }
    }
```

#### AUTO 


```{c}
auto centerLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto decTask = new DecryptVerifyTask();
```

#### AUTO 


```{c}
const auto seec = mementoContent< std::shared_ptr<NewSignEncryptEMailController> >(NewSignEncryptEMailController::mementoName());
```

#### AUTO 


```{c}
auto w = findChild<CertificateDetailsWidget*>();
```

#### AUTO 


```{c}
const auto certificationKey = mCertificationKeySelect->currentKey();
```

#### AUTO 


```{c}
const auto keyPairInfoLines = Assuan::sendStatusLinesCommand(gpg_agent, command.c_str(), err);
```

#### AUTO 


```{c}
auto it = std::find_if(std::cbegin(mAnchors), std::cend(mAnchors), [start](const auto &anchor) {
        return anchor.start == start;
    });
```

#### AUTO 


```{c}
const auto keyPairInfoLines = gpgagent_statuslines(gpg_agent, command.c_str(), err);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &statusLine: statusLines) {
            if (statusLine.first == "SERIALNO") {
                const auto serialNumberAndApps = QByteArray::fromStdString(statusLine.second).split(' ');
                if (serialNumberAndApps.size() >= 2) {
                    const auto serialNumber = serialNumberAndApps[0];
                    auto apps = serialNumberAndApps.mid(1);
                    // sort the apps to get a stable order independently of the currently selected application
                    std::sort(apps.begin(), apps.end());
                    for (const auto &app: apps) {
                        qCDebug(KLEOPATRA_LOG) << "getCardsAndApps(): Found card" << serialNumber << "with app" << app;
                        result.push_back({ serialNumber.toStdString(), app.toStdString() });
                    }
                } else {
                    logUnexpectedStatusLine(statusLine, "getCardsAndApps()", command);
                }
            } else {
                logUnexpectedStatusLine(statusLine, "getCardsAndApps()", command);
            }
        }
```

#### AUTO 


```{c}
auto combo = new QComboBox;
```

#### AUTO 


```{c}
const auto backendVersions = Kleo::backendVersionInfo();
```

#### LAMBDA EXPRESSION 


```{c}
[] () {
            ReaderStatus::mutableInstance()->updateStatus();
        }
```

#### AUTO 


```{c}
auto fileGrpLay = new QVBoxLayout;
```

#### AUTO 


```{c}
auto resultGBLayout = new QHBoxLayout{resultGB};
```

#### LAMBDA EXPRESSION 


```{c}
[&dir](const QString &entry) {
                               return dir.absoluteFilePath(entry);
                           }
```

#### AUTO 


```{c}
auto kind
```

#### RANGE FOR STATEMENT 


```{c}
for (const SumFile &sumFile : sumfiles) {
                Q_EMIT progress(done / factor, total / factor,
                                i18n("Verifying checksums (%2) in %1", sumFile.checksumDefinition->label(), sumFile.dir.path()));
                bool fatal = false;
                const QString error = process(sumFile, &fatal, env, statusCb);
                if (!error.isEmpty()) {
                    errors.push_back(error);
                }
                done += sumFile.totalSize;
                if (fatal || canceled) {
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: key.userIDs()) {
        if (validity == UserID::Validity::Unknown
            || validity > uid.validity()) {
            validity = uid.validity();
        }
    }
```

#### AUTO 


```{c}
auto cmd = new PIVGenerateCardKeyCommand(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](GpgME::KeyListResult, std::vector<GpgME::Key> keys, QString, GpgME::Error) {
        if (keys.size() == 1) {
            auto importJob = QGpgME::openpgp()->importFromKeyserverJob();
            qCDebug(KLEOPATRA_LOG) << "Importing: " << keys[0].primaryFingerprint();
            connect(importJob, &QGpgME::ImportFromKeyserverJob::result, importJob, [this](GpgME::ImportResult, QString, GpgME::Error) {
                qCDebug(KLEOPATRA_LOG) << "import job done";
                mStatusLabel->setText(i18n("Automatic import finished."));
            });
            importJob->start(keys);
        } else if (keys.size() > 1) {
            qCDebug(KLEOPATRA_LOG) << "Multiple keys found on server";
            mStatusLabel->setText(i18n("Error multiple keys found on server."));
        } else {
            qCDebug(KLEOPATRA_LOG) << "No key found";
            mStatusLabel->setText(i18n("Key not found in directory service."));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const CertificateSelectionLine &l) {
                                      return l.isStillAmbiguous(proto);
                                  }
```

#### LAMBDA EXPRESSION 


```{c}
[this, btn, keyid] () {
                btn->setEnabled(false);
                m_importCanceled = false;
                auto cmd = new Kleo::Commands::LookupCertificatesCommand(keyid, nullptr);
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::canceled,
                        q, [this]() { m_importCanceled = true; });
                connect(cmd, &Kleo::Commands::LookupCertificatesCommand::finished,
                        q, [this, btn]() {
                    btn->setEnabled(true);
                    oneImportFinished();
                });
                cmd->setParentWidget(q);
                cmd->start();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
#ifdef Q_OS_WIN
        // As encoding is more complicated on windows with different
        // 8 bit codepages we always use UTF-8 here and add this as an
        // option in the libkleopatrarc.desktop archive definition.
        result += file.toUtf8();
#else
        result += QFile::encodeName(file);
#endif
        result += sep;
    }
```

#### AUTO 


```{c}
const auto newEntry = configEntry(s_x509services_componentName, s_x509services_entryName,
                                      CryptoConfigEntry::ArgType_LDAPURL, ListValue, DoNotShowError);
```

#### AUTO 


```{c}
auto pName = Kleo::Formatting::prettyName(uid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid: key.userIDs()) {
            if (uid.isRevoked() || uid.isInvalid()) {
                // Skip user IDs that cannot really be certified.
                i++;
                continue;
            }
            auto const item = new QStandardItem;
            item->setText(Formatting::prettyUserID(uid));
            item->setData(i, UserIDIndex);
            item->setCheckable(true);
            item->setEditable(false);
            item->setCheckState(Qt::Checked);
            appendRow(item);
            i++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool value) {
                    if (value) {
                        mSigEncWidget->setProtocol(GpgME::OpenPGP);
                    }
                }
```

#### AUTO 


```{c}
auto unblockButton = new QPushButton(i18n("Unblock Card"));
```

#### AUTO 


```{c}
auto job = QGpgME::openpgp()->locateKeysJob();
```

#### AUTO 


```{c}
auto job = QGpgME::smime()->keyListJob(false, true, true);
```

#### AUTO 


```{c}
const auto signingKeyGrip = card->keyInfo(card->signingKeyRef()).grip;
```

#### AUTO 


```{c}
auto w = new DecryptVerifyEMailWizard;
```

#### AUTO 


```{c}
auto ptr = controller.get();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("&Executable:"), group);
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &job) { job.job->slotCancel(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &recipient : std::as_const(in.recipients)) {
        if ((err = send_recipient(ctx, recipient, in.areRecipientsInformative))) {
            out.errorString = i18n("Failed to send recipient %1: %2", recipient, to_error_string(err));
            goto leave;
        }
    }
```

#### AUTO 


```{c}
auto progress = new QProgressDialog(i18n("Searching for updates..."),
                                        i18n("Cancel"), 0, 0, parent);
```

#### AUTO 


```{c}
const auto &fpr
```

#### AUTO 


```{c}
auto cmd = new Commands::DetailsCommand(subkeys[0].parent(), nullptr);
```

#### AUTO 


```{c}
auto b
```

#### AUTO 


```{c}
auto job = jobOwner.get();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Import &import : imports) {
            if (!import.fingerprint()) {
                continue;
            }
            fingerprints << QString::fromLatin1(import.fingerprint());
        }
```

#### AUTO 


```{c}
const auto cardSupportsKey = !widgets.cardKeyRef.empty();
```

#### AUTO 


```{c}
const auto it = d->m_tasks.find(id);
```

#### AUTO 


```{c}
const auto chvStatus = QString::fromStdString(
            scd_getattr_status(gpg_agent, "CHV-STATUS", err)).split(QLatin1Char(' '));
```

#### AUTO 


```{c}
auto contentAnimation = static_cast<QPropertyAnimation *>(toggleAnimation.animationAt(toggleAnimation.animationCount() - 1));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sender: senders) {
            const auto &key = sender.resolvedSigningKey(presetProtocol);
            if (!IS_DE_VS(key) || keyValidity(key) < GpgME::UserID::Validity::Full) {
                return false;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) {
        slotResult(err);
    }
```

#### AUTO 


```{c}
const auto card = get_card_status(cardApp.serialNumber, cardApp.appName, gpgAgent);
```

#### AUTO 


```{c}
auto resultGB = new QGroupBox{i18nc("@title:group", "Result"), parent};
```

#### AUTO 


```{c}
auto it = chain.rbegin(), end = chain.rend();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateResultLabel(); }
```

#### AUTO 


```{c}
auto *const cmd = new ChecksumVerifyFilesCommand(verifyFiles, nullptr);
```

#### AUTO 


```{c}
const auto maximumExpiry = settings.validityPeriodInDaysMax();
```

#### AUTO 


```{c}
auto worker = new DeviceInfoWatcher::Worker;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Line &line : list) {
        const QLineEdit *le = line.edit;
        if (!le) {
            continue;
        }
        const QString key = line.attr;
        qCDebug(KLEOPATRA_LOG) << "requirementsAreMet(): checking" << key << "against" << le->text() << ":";
        if (le->text().trimmed().isEmpty()) {
            if (key.endsWith(QLatin1Char('!'))) {
                if (line.regex.isEmpty()) {
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.", line.label);
                } else
                    error = xi18nc("@info", "<interface>%1</interface> is required, but empty.<nl/>"
                                   "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
                return false;
            }
        } else if (has_intermediate_input(le)) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is incomplete.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else if (!le->hasAcceptableInput()) {
            if (line.regex.isEmpty()) {
                error = xi18nc("@info", "<interface>%1</interface> is invalid.", line.label);
            } else
                error = xi18nc("@info", "<interface>%1</interface> is invalid.<nl/>"
                               "Local Admin rule: <icode>%2</icode>", line.label, line.regex);
            return false;
        } else {
            allEmpty = false;
        }
    }
```

#### AUTO 


```{c}
auto *hLay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto ctx = Context::createForProtocol(OpenPGP);
```

#### AUTO 


```{c}
const auto actual_version = getVersionFromString(actual, ok);
```

#### AUTO 


```{c}
const auto signatures = findSignatures(cFile.fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : patterns) {
                if (QRegExp(pattern, fs_cs).exactMatch(fileName)) {
                    return cd;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&str](QValidator *val) { val->fixup(str); }
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Certification key:"));
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, qq);
```

#### LAMBDA EXPRESSION 


```{c}
[this, okButton] () {
        okButton->setEnabled(mCertWidget->isValid());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tag: uid.remarks(Tags::tagKeys(), err)) {
            if (err) {
                qCWarning(KLEOPATRA_LOG) << "Getting remarks for user ID" << uid.id() << "failed:" << err;
            }
            tagList << QString::fromStdString(tag);
        }
```

#### AUTO 


```{c}
const auto key = userId.parent();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : widgetskeys) {
        Q_ASSERT(items.contains(i));
        widgets[i]->setSelected(items[i]->isSelected());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : selectedKeys) {
        groupKeysModel->removeKey(key);
    }
```

#### AUTO 


```{c}
auto *const cmd = new ChecksumCreateFilesCommand(createFiles, nullptr);
```

#### AUTO 


```{c}
auto protocolWidget = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &lhs, const QString &rhs) {
                              return QString::compare(lhs, rhs, ChecksumsUtils::fs_cs) < 0;
                          }
```

#### AUTO 


```{c}
auto w = new DecryptVerifyOperationWidget(m_ui.scrollArea.widget());
```

#### AUTO 


```{c}
auto statusLbl = std::make_unique<QLabel>(Formatting::deVsString(Kleo::gnupgIsDeVsCompliant()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyPairInfo &keyInfo : pivCard->keyInfos()) {
        if (!keyInfo.grip.empty()) {
            readKeyPairInfoFromPIVCard(keyInfo.keyRef, pivCard, gpg_agent);
            readCertificateFromPIVCard(keyInfo.keyRef, pivCard, gpg_agent);
        }
    }
```

#### AUTO 


```{c}
const auto card = ReaderStatus::instance()->getCard(serialNumber(), appName);
```

#### AUTO 


```{c}
const auto *const ap = anchorProvider();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QAction *action) {
                    const int col = action->data().toInt();
                    if (col == REMARK_COLUMN) {
                        Remarks::enableRemarks(action->isChecked());
                    }
                    if (action->isChecked()) {
                        showColumn(col);
                    } else {
                        hideColumn(col);
                    }

                    KeyTreeView *tv = qobject_cast<KeyTreeView *> (parent());
                    if (tv) {
                        tv->resizeColumns();
                    }
                }
```

#### AUTO 


```{c}
const auto pgpCard = SmartCard::ReaderStatus::instance()->getCard<OpenPGPCard>(serialNumber);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &err) {
        changeNameResult(err);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemWidget *i : std::as_const(widgets)) {
        i->setProtocol(prot);
    }
```

#### AUTO 


```{c}
auto w = simulateFocusNextPrevChild(widget, true);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) { slotContextMenu(pos); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { finished(); }
```

#### AUTO 


```{c}
auto actionLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto dialog = new KeySelectionDialog(parentWidgetOrView());
```

#### AUTO 


```{c}
auto vLay = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto cbp = (proto == GpgME::OpenPGP) ? QGpgME::openpgp() : QGpgME::smime();
```

#### LAMBDA EXPRESSION 


```{c}
[proc] () {
        while (proc->canReadLine()) {
            const QString line = QString::fromUtf8(proc->readLine()).trimmed();
            // Command-fd is a stable interface, while this is all kind of hacky we
            // are on a deadline :-/
            if (line == QStringLiteral("[GNUPG:] GET_BOOL gen_revoke.okay")) {
                proc->write("y\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_LINE ask_revocation_reason.code")) {
                proc->write("0\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_LINE ask_revocation_reason.text")) {
                proc->write("\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_BOOL openfile.overwrite.okay")) {
                // We asked before
                proc->write("y\n");
            } else if (line == QStringLiteral("[GNUPG:] GET_BOOL ask_revocation_reason.okay")) {
                proc->write("y\n");
            }
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout{uidGB};
```

#### AUTO 


```{c}
auto const dlg = new CertificateSelectionDialog(this);
```

#### AUTO 


```{c}
auto w
```

#### AUTO 


```{c}
auto focusProxy = deepestFocusProxy(w)
```

#### AUTO 


```{c}
const auto &sig
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotInAmountChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit: std::as_const(mRecpWidgets)) {
        const auto editGroup = edit->group();
        if (group.isNull() && editGroup.isNull()) {
            recpRemovalRequested(edit);
            return;
        }
        if (editGroup.name() == group.name()) {
            recpRemovalRequested(edit);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : results) {
            const std::vector<Import> imports = r.result.imports();
            m_importsByFingerprint.insert(m_importsByFingerprint.end(), imports.begin(), imports.end());
            for (std::vector<Import>::const_iterator it = imports.begin(), end = imports.end(); it != end; ++it) {
                m_idsByFingerprint[it->fingerprint()].insert(r.id);
            }
        }
```

#### AUTO 


```{c}
auto posCopy = pos;
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit : std::as_const(mRecpWidgets)) {
                edit->setEnabled(toggled);
            }
```

#### AUTO 


```{c}
auto outputGrp = new QGroupBox(i18nc("@title:group", "Output"));
```

#### AUTO 


```{c}
const auto infoText = i18n("OpenPGP key pairs are certified by confirming the fingerprint of the public key.");
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &fingerprints, const auto &import) {
                               if (import.status() == Import::NewKey) {
                                   fingerprints.push_back(import.fingerprint());
                               }
                               return fingerprints;
                           }
```

#### AUTO 


```{c}
auto scrollLay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto messageWidget = new KMessageWidget;
```

#### AUTO 


```{c}
const auto backend = (proto == GpgME::OpenPGP) ? QGpgME::openpgp() : QGpgME::smime();
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &name : mainViewActionNames ) {
        if (auto action = coll->action(name)) {
            action->setCheckable(true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &requester : requestersInfo) {
            const auto id = requester.id;
            auto requesterWithIcon = new FileNameRequesterWithIcon{id == SignEncryptFilesWizard::Directory ? QDir::Dirs : QDir::Files, this};
            requesterWithIcon->setIcon(QIcon::fromTheme(requester.icon));
            requesterWithIcon->setToolTip(requester.toolTip);
            requesterWithIcon->requester()->setAccessibleNameOfLineEdit(requester.accessibleName);
            requesterWithIcon->setNameFilter(isAscii ? requester.nameFilterAscii : requester.nameFilterBinary);
            lay->addWidget(requesterWithIcon);

            connect(requesterWithIcon, &FileNameRequesterWithIcon::fileNameChanged, this, [this, id](const QString &newName) {
                mOutNames[id] = newName;
            });

            mRequesters.insert(id, requesterWithIcon);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : keys) {
            mRequester[i] = createRequester(i, mOutLayout);
        }
```

#### AUTO 


```{c}
auto importJob = QGpgME::openpgp()->importFromKeyserverJob();
```

#### AUTO 


```{c}
auto completer = new QCompleter(this);
```

#### AUTO 


```{c}
auto list = QString::fromUtf8(QByteArray::fromStdString(value)).
                    split(QStringLiteral("<<"), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
const auto &oldCard
```

#### AUTO 


```{c}
auto w = simulateFocusNextPrevChild(widget, false);
```

#### AUTO 


```{c}
const auto widgetskeys = widgets.keys();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.protocol() != CMS; }
```

#### AUTO 


```{c}
const auto it = std::find_if(runnable.begin(), runnable.end(),
                                 [proto](const std::shared_ptr<Task> &task) { return task->protocol() == proto; });
```

#### AUTO 


```{c}
auto checkBoxSize(const QCheckBox *checkBox)
{
    QStyleOptionButton opt;
    return checkBox->style()->sizeFromContents(QStyle::CT_CheckBox, &opt, QSize(), checkBox);
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature &sig : sigs) {
            const QString s = signatureToString(sig, DecryptVerifyResult::keyForSignature(sig, signers));
            const char *color = summaryToString(sig.summary());
            q->sendStatusEncoded("SIGSTATUS",
                                 color + (' ' + hexencode(s.toUtf8().constData())));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<const DecryptVerifyResult> &i : std::as_const(m_results)) {
            Q_EMIT q->verificationResult(i->verificationResult());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid : uids) {
            auto const item = new QStandardItem;
            item->setText(Formatting::prettyUserID(uid));
            item->setCheckable(true);
            item->setEditable(false);
            item->setCheckState(Qt::Checked);
            appendRow(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        const std::vector<Key> secKeys = KeyCache::instance()->secretKeys();
        return std::any_of(secKeys.cbegin(), secKeys.cend(), [](const Key &secKey) {
            return secKey.canCertify() && secKey.protocol() == OpenPGP && !secKey.isRevoked()
                   && !secKey.isExpired() && !secKey.isInvalid();
        });
    }
```

#### AUTO 


```{c}
auto it = m_buttons.begin(), end = m_buttons.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QAction *action) {
                    const int col = action->data().toInt();
                    if ((col == TAGS_COLUMN) && action->isChecked()) {
                        Tags::enableTags();
                    }
                    if (action->isChecked()) {
                        showColumn(col);
                    } else {
                        hideColumn(col);
                    }

                    auto tv = qobject_cast<KeyTreeView *> (parent());
                    if (tv) {
                        tv->resizeColumns();
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { reload(); }
```

#### AUTO 


```{c}
const auto dirs{dir.entryList(QDir::AllEntries | QDir::NoDotAndDotDot)};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {q->accept();}
```

#### AUTO 


```{c}
auto horizontalLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto sigGrp = new QGroupBox(i18n("Prove authenticity (sign)"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : std::as_const(files)) {
                QFileInfo fi(fileName);
                if (!fi.isReadable()) {
                    errors << i18n("Cannot read \"%1\"", fileName);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &secKey) {
            return secKey.canCertify() && secKey.protocol() == OpenPGP && !secKey.isRevoked()
                   && !secKey.isExpired() && !secKey.isInvalid();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto b : toolbarButtons) {
            b->setFocusPolicy(Qt::TabFocus);
        }
```

#### AUTO 


```{c}
const auto ad = q->pick_archive_definition(cFile.protocol, archiveDefinitions, cFile.fileName);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const KeyGroup &group) {
                if (!mGroup.isNull() && mGroup.source() == group.source() && mGroup.id() == group.id()) {
                    QSignalBlocker blocky(this);
                    setText(Formatting::summaryLine(group));
                    // queue the update to ensure that the model has been updated
                    QMetaObject::invokeMethod(this, &CertificateLineEdit::updateKey, Qt::QueuedConnection);
                }
            }
```

#### AUTO 


```{c}
auto ctx = Context::createForProtocol(GpgME::CMS);
```

#### AUTO 


```{c}
auto listView = new QListView{q};
```

#### AUTO 


```{c}
const auto ci = get_card_status(0, gpgAgent);
```

#### AUTO 


```{c}
auto cmd = new ExportCertificateCommand(key());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyInfo : PIVCard::supportedKeys()) {
        KeyWidgets keyWidgets = createKeyWidgets(keyInfo);
        layoutKeyWidgets(grid, PIVCard::keyDisplayName(keyInfo.keyRef), keyWidgets);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox{QDialogButtonBox::Ok | QDialogButtonBox::Cancel, qq};
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &r) {
                            return r.result.error().isCanceled();
                        }
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *Rename = "window_rename_tab";
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { removeKeysFromGroup(); }
```

#### AUTO 


```{c}
auto l = new QVBoxLayout{mCMSKeysSection};
```

#### AUTO 


```{c}
auto l = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            restoreExpandState();
            setupRemarkKeys();
            if (!m_onceResized) {
                m_onceResized = true;
                resizeColumns();
            }
        }
```

#### AUTO 


```{c}
const auto subkeyType = advancedSettingsDlg->subkeyType();
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::string &keyRef : PIVCard::supportedKeys()) {
        if (!pivCard->keyGrip(keyRef).empty()) {
            readKeyPairInfoFromPIVCard(keyRef, pivCard, gpg_agent);
            readCertificateFromPIVCard(keyRef, pivCard, gpg_agent);
        }
    }
```

#### AUTO 


```{c}
auto lb = qobject_cast<QLabel *>(l->itemAtPosition(row, 0)->widget());
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {doChangePin(2);}
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const GpgME::KeyListResult&, const std::vector<GpgME::Key> &keys, const QString&, const GpgME::Error&)
                {
                    for (const auto &key: keys) {
                        if (Kleo::keyValidity(key) < GpgME::UserID::Validity::Full) {
                            certifyButton->show();
                            return;
                        }
                    }
                    certifyButton->hide();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Key &key) { return key.protocol() != proto; }
```

#### AUTO 


```{c}
const auto *focusProxy = deepestFocusProxy(w)
```

#### AUTO 


```{c}
auto dlg = new GenCardKeyDialog(GenCardKeyDialog::AllKeyAttributes, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature &sig : sigs) {
        details += formatSignature(sig, info) + QLatin1Char('\n');
    }
```

#### LAMBDA EXPRESSION 


```{c}
[btn] (const QString &text) {
        btn->setEnabled(!text.isEmpty());
    }
```

#### AUTO 


```{c}
auto emailLay = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto nameError = ui.nameInput->currentError();
```

#### AUTO 


```{c}
auto hboxLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto cmd = new CreateOpenPGPKeyFromCardKeysCommand(mSerialNumber, NetKeyCard::AppName, this);
```

#### AUTO 


```{c}
auto dlg = new CertificateDetailsDialog;
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *MoveRight = "window_move_tab_right";
```

#### AUTO 


```{c}
auto tagsLay = new QHBoxLayout{q};
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &k) { return k.hasSecret(); }
```

#### AUTO 


```{c}
auto learnBtn = new QPushButton(i18n("Load additional certificates"));
```

#### AUTO 


```{c}
auto &cFile = (*it);
```

#### AUTO 


```{c}
auto logo = new QLabel;
```

#### AUTO 


```{c}
const auto certificationKey = KeyCache::instance()->findByKeyIDOrFingerprint(signature.signerKeyID());
```

#### AUTO 


```{c}
auto list = QString::fromStdString(mMetaInfo.value("DISP-NAME")).split(QStringLiteral("<<"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, signature]() {
            auto cmd = Command::commandForQuery(QString::fromUtf8(signature.signerKeyID()));
            cmd->setParentWId(q->winId());
            cmd->start();
        }
```

#### AUTO 


```{c}
auto scrollAreaLayout = qobject_cast<QBoxLayout *>(m_scrollArea->widget()->layout());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KeyGroup &group) {
                if (!mGroup.isNull() && mGroup.source() == group.source() && mGroup.id() == group.id()) {
                    mGroup = KeyGroup();
                    QSignalBlocker blocky{&ui.lineEdit};
                    ui.lineEdit.clear();
                    // queue the update to ensure that the model has been updated
                    QMetaObject::invokeMethod(q, [this]() { updateKey(); }, Qt::QueuedConnection);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(Kleo::KeyListModelInterface::KeyRole).value<GpgME::Key>();
        m_expandedKeys.removeAll(QString::fromLatin1(key.primaryFingerprint()));
        auto grp = KSharedConfig::openConfig()->group("KeyTreeView");
        grp.writeEntry("Expanded", m_expandedKeys);
    }
```

#### AUTO 


```{c}
auto it = m_tasks.begin(), end = m_tasks.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filePath : std::as_const(in.filePaths)) {
        if ((err = send_file(ctx, filePath))) {
            out.errorString = i18n("Failed to send file path %1: %2", filePath, to_error_string(err));
            goto leave;
        }
    }
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message, int current, int total) { slotProgress(message, current, total); }
```

#### AUTO 


```{c}
auto groupsLayout = new QGridLayout();
```

#### AUTO 


```{c}
const auto cmsAllowed = settings.cmsEnabled() && settings.cmsCertificateCreationAllowed();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : filesToImportGroupsFrom) {
        const bool certificateImportSucceeded =
            std::any_of(std::cbegin(results), std::cend(results),
                        [path](const auto &r) {
                            return r.id == path && !importFailed(r);
                        });
        if (certificateImportSucceeded) {
            qCDebug(KLEOPATRA_LOG) << __func__ << "Importing groups from file" << path;
            const auto groups = readKeyGroups(path);
            std::transform(std::begin(groups), std::end(groups),
                           std::back_inserter(importedGroups),
                           [path](const auto &group) {
                               return storeGroup(group, path);
                           });
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &v : it.value()) {
            keyParameters.push_back(it.key() + QLatin1Char(':') + v);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // To avoid an infinite show if we miss the keyListingDone signal
        // (Race potential) we use a watchdog timer, too to actively poll
        // the keycache every second. See bug #381910
        if (KeyCache::instance()->initialized()) {
            qCDebug(KLEOPATRA_LOG) << "Hiding overlay from watchdog";
            hideOverlay();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Line &line : ui.lines ) {
            widgets.push_back(line.edit);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : patterns) {
                result.push_back(QRegExp(pattern, fs_cs));
            }
```

#### AUTO 


```{c}
auto it = c.begin();
```

#### AUTO 


```{c}
static auto create(QWidget *parent)
    {
        std::unique_ptr<FormTextInput> self{new FormTextInput};
        self->setWidget(new Widget{parent});
        return self;
    }
```

#### AUTO 


```{c}
auto assuanContext = std::shared_ptr<GpgME::Context>(c.release());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto kind : icons.keys()) {
            auto requesterWithIcon = new FileNameRequesterWithIcon{
                kind == SignEncryptFilesWizard::Directory ? QDir::Dirs : QDir::Files, this};
            requesterWithIcon->setIcon(QIcon::fromTheme(icons[kind]));
            requesterWithIcon->setToolTip(toolTips[kind]);
            lay->addWidget(requesterWithIcon);

            connect(requesterWithIcon, &FileNameRequesterWithIcon::fileNameChanged, this,
                    [this, kind](const QString &newName) {
                        mOutNames[kind] = newName;
                    });

            mRequesters.insert(kind, requesterWithIcon);
        }
```

#### AUTO 


```{c}
const auto newErrorMessage = descriptionErrorMessage();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Key &key) {
                signatureListingNextKey (key);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        finished();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->genRevokeCert(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, lookUpBtn] () {
        lookUpBtn->setEnabled(false);
        auto cmd = new Kleo::Commands::LookupCertificatesCommand(mKeyID, nullptr);
        connect(cmd, &Kleo::Commands::LookupCertificatesCommand::finished,
                this, [lookUpBtn]() {
                    lookUpBtn->setEnabled(true);
                });
        cmd->setParentWidget(this->parentWidget());
        cmd->start();
    }
```

#### AUTO 


```{c}
const auto result = switchCard(gpg_agent, serialNumber, err);
```

#### LAMBDA EXPRESSION 


```{c}
[bar] (int, int max) {
            bar->setValue(max);
        }
```

#### AUTO 


```{c}
auto it = cryptoFiles.begin(), end = cryptoFiles.end();
```

#### AUTO 


```{c}
auto hLay = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[icon] () {
            ReaderStatus::mutableInstance()->updateStatus();
            icon->setLearningInProgress(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sig : signatures) {
                    qCDebug(KLEOPATRA_LOG) << "Guessing: " << sig << " is a signature for: " << cFile.fileName;
                    std::shared_ptr<VerifyDetachedTask> t(new VerifyDetachedTask);
                    t->setInput(Input::createFromFile(sig));
                    t->setSignedData(Input::createFromFile(cFile.fileName));
                    t->setProtocol(cFile.protocol);
                    tasks.push_back(t);
                }
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { addRecipientWidget(); }
```

#### AUTO 


```{c}
auto it = dirs2files.begin(), end = dirs2files.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &key: std::as_const(mAddedKeys)) {
        removeRecipient(key);
    }
```

#### AUTO 


```{c}
auto vBox = new QVBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fname: std::as_const(m_passedFiles)) {
        kleo_assert(!fname.isEmpty());

        const unsigned int classification = classify(fname);
        const Protocol proto = findProtocol(classification);

        if (mayBeOpaqueSignature(classification) || mayBeCipherText(classification) || mayBeDetachedSignature(classification)) {

            DecryptVerifyOperationWidget *const op = m_wizard->operationWidget(counter++);
            kleo_assert(op != nullptr);

            op->setArchiveDefinitions(archiveDefinitions);

            const QString signedDataFileName = findSignedData(fname);

            // this breaks opaque signatures whose source files still
            // happen to exist in the same directory. Until we have
            // content-based classification, this is the most unlikely
            // case, so that's the case we break. ### FIXME remove when content-classify is done
            if (mayBeDetachedSignature(classification) && !signedDataFileName.isEmpty()) {
                op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignature);
            }
            // ### end FIXME
            else if (mayBeOpaqueSignature(classification) || mayBeCipherText(classification)) {
                op->setMode(DecryptVerifyOperationWidget::DecryptVerifyOpaque, q->pick_archive_definition(proto, archiveDefinitions, fname));
            } else {
                op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignature);
            }

            op->setInputFileName(fname);
            op->setSignedDataFileName(signedDataFileName);

            m_filesAfterPreparation << fname;

        } else {

            // probably the signed data file was selected:
            const QStringList signatures = findSignatures(fname);

            if (signatures.empty()) {
                // We are assuming this is a detached signature file, but
                // there were no signature files for it. Let's guess it's encrypted after all.
                // ### FIXME once we have a proper heuristic for this, this should move into
                // classify() and/or classifyContent()
                DecryptVerifyOperationWidget *const op = m_wizard->operationWidget(counter++);
                kleo_assert(op != nullptr);
                op->setArchiveDefinitions(archiveDefinitions);
                op->setMode(DecryptVerifyOperationWidget::DecryptVerifyOpaque, q->pick_archive_definition(proto, archiveDefinitions, fname));
                op->setInputFileName(fname);
                m_filesAfterPreparation << fname;
            } else {
                for (const auto &s: signatures) {
                    DecryptVerifyOperationWidget *op = m_wizard->operationWidget(counter++);
                    kleo_assert(op != nullptr);

                    op->setArchiveDefinitions(archiveDefinitions);
                    op->setMode(DecryptVerifyOperationWidget::VerifyDetachedWithSignedData);
                    op->setInputFileName(s);
                    op->setSignedDataFileName(fname);

                    m_filesAfterPreparation << fname;
                }

            }
        }
    }
```

#### AUTO 


```{c}
auto btnBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : checksumDefinitions)
        if (cd) {
            const auto patterns = cd->patterns();
            for (const QString &pattern : patterns)
                if (QRegExp(pattern, fs_cs).exactMatch(fileName)) {
                    return cd;
                }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { genRevokeCert(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &pos) { showContextMenu(pos); }
```

#### AUTO 


```{c}
const auto usableKeys = getUsableSigningKeys(netKeyCard.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sub: subkeys) {
                    // Yep you can have one subkey associated with multiple
                    // primary keys.
                    toolTips << Formatting::toolTip(sub.parent(), Formatting::Validity |
                                                    Formatting::StorageLocation |
                                                    Formatting::ExpiryDates |
                                                    Formatting::UserIDs |
                                                    Formatting::Fingerprint);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto w) { return !w->isHidden(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&fileName](const QString &pattern) {
            const QRegularExpression re(QRegularExpression::anchoredPattern(pattern), s_regex_cs);
            return re.match(fileName).hasMatch();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[mbox](const Mailbox &m) {
                            return mailbox_equal(mbox, m, Qt::CaseInsensitive);
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *edit : qAsConst(mRecpWidgets)) {
        if (edit->isEmpty()) {
            emptyEdits++;
        }
        if (emptyEdits > 1) {
            int row, col, rspan, cspan;
            mRecpLayout->getItemPosition(mRecpLayout->indexOf(w), &row, &col, &rspan, &cspan);
            mRecpLayout->removeWidget(w);
            mRecpWidgets.removeAll(w);
            // The row count of the grid layout does not reflect the actual
            // items so we keep our internal count.
            mRecpRowCount--;
            for (int i = row + 1; i <= mRecpRowCount; i++) {
                // move widgets one up
                auto item = mRecpLayout->itemAtPosition(i, 1);
                if (!item) {
                    break;
                }
                mRecpLayout->removeItem(item);
                mRecpLayout->addItem(item, i - 1, 1);
            }
            w->deleteLater();
            return;
        }
    }
```

#### AUTO 


```{c}
auto mw = new MainWindow;
```

#### LAMBDA EXPRESSION 


```{c}
[](unsigned char c){ return std::tolower(c); }
```

#### AUTO 


```{c}
auto protocolFromOptions(CertificateSelectionDialog::Options options)
{
    switch (options & CertificateSelectionDialog::AnyFormat) {
    case CertificateSelectionDialog::OpenPGPFormat:
        return GpgME::OpenPGP;
    case CertificateSelectionDialog::CMSFormat:
        return GpgME::CMS;
    default:
        return GpgME::UnknownProtocol;
    }
}
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyRef] () { writeKeyToCard(keyRef); }
```

#### AUTO 


```{c}
auto splitLine = new QFrame;
```

#### AUTO 


```{c}
const auto regexp = config.readEntry(QLatin1String("NAME_regex"));
```

#### AUTO 


```{c}
const auto keyserver = mOpenPGPKeyserverEdit->text().trimmed();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](GpgME::KeyListResult, std::vector<GpgME::Key> keys, QString, GpgME::Error)
                {
                    for (const auto &key: keys) {
                        if (Kleo::keyValidity(key) < GpgME::UserID::Validity::Full) {
                            certifyButton->show();
                            return;
                        }
                    }
                    certifyButton->hide();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : cds) {
        mChecksumDefinitionCB.widget()->addItem(cd->label(), QVariant{cd->id()});
    }
```

#### AUTO 


```{c}
const auto archiveDefinitions = ArchiveDefinition::getArchiveDefinitions();
```

#### LAMBDA EXPRESSION 


```{c}
[](long ts) {
        return ts == 0 ? i18n("never") : QDateTime::fromSecsSinceEpoch(ts).toString(Qt::SystemLocaleShortDate);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                d->mainWidget->saveConfig();
                accept();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto w) { return !w->isEnabled() || w->hasAcceptableInput(); }
```

#### AUTO 


```{c}
auto key = KeyCache::instance()->findByFingerprint(fpr);
```

#### LAMBDA EXPRESSION 


```{c}
[](const std::shared_ptr<Card> &ci) { return ci->canLearnKeys(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyPairInfo &k : mKeyInfos) {
        if (k.keyRef == keyRef) {
            return k;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KeyGenerationResult &result) {
        QMetaObject::invokeMethod(
            q,
            [this, result] {
                showResult(result);
            },
            Qt::QueuedConnection);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto totalConsidered, const auto &r) {
                                                     return totalConsidered + r.result.numConsidered();
                                                 }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {keyListingDone();}
```

#### LAMBDA EXPRESSION 


```{c}
[q, this] () {
                q->mWithRevocations = true;
                revocationsButton.setEnabled(false);
                q->updateRequested();
            }
```

#### AUTO 


```{c}
const auto cmsPrefsKeys = cmsPrefs.keys();
```

#### AUTO 


```{c}
auto it = Kleo::binary_find(d->pageOrder.begin(), d->pageOrder.end(), d->currentId);
```

#### AUTO 


```{c}
auto ret = new OpenPGPCard();
```

#### AUTO 


```{c}
auto action = menu->addAction(QIcon::fromTheme(QStringLiteral("view-certificate-revoke")),
                                      i18nc("@action:inmenu", "Revoke User ID"),
                                      q, [this, userID]() {
                                          revokeUserID(userID);
                                      });
```

#### LAMBDA EXPRESSION 


```{c}
[path](const auto &r) {
                            return r.id == path && !importFailed(r) && !importWasCanceled(r);
                        }
```

#### AUTO 


```{c}
auto label = new QLabel;
```

#### AUTO 


```{c}
const auto styleTag = styleTemplate.arg(linkColor.isValid() ? linkColor.name() : q->palette().link().color().name());
```

#### AUTO 


```{c}
const auto &nameFilters = FileOperationsPreferences().addASCIIArmor() ? nameFiltersAscii : nameFiltersBinary;
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : qAsConst(d->uids))
        if (qstricmp(uid.parent().primaryFingerprint(), key.primaryFingerprint()) != 0) {
            qCWarning(KLEOPATRA_LOG) << "User-ID <-> Key mismatch!";
            d->finished();
            return;
        }
```

#### AUTO 


```{c}
auto progLay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *const cmd = new ChecksumCreateFilesCommand(createFiles, 0);
```

#### AUTO 


```{c}
const auto symguide = new DocAction(QIcon::fromTheme(QStringLiteral("help-contextual")), i18n("Password-based encryption"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                "handout_symmetric_encryption_gnupg_en.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### AUTO 


```{c}
const auto &requester
```

#### AUTO 


```{c}
const auto key = ctx->nextKey(e);
```

#### AUTO 


```{c}
const auto &keyInfo
```

#### AUTO 


```{c}
auto data = process()->readAllStandardOutput();
```

#### AUTO 


```{c}
auto ctx = QGpgME::Job::context(job);
```

#### AUTO 


```{c}
const auto mailText = ui.lineEdit.text().trimmed();
```

#### AUTO 


```{c}
auto advLay = new QVBoxLayout{q};
```

#### AUTO 


```{c}
auto task = new SignEncryptTask();
```

#### AUTO 


```{c}
auto cmd = new ImportCertificateFromDataCommand(QByteArray::fromStdString(certificateData), GpgME::CMS, i18n("Card Certificate"));
```

#### AUTO 


```{c}
auto it = cmdline_options.begin(), end = cmdline_options.end();
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &r) { return r.result.numConsidered() > 0; }
```

#### AUTO 


```{c}
auto infoBtn = createInfoButton(i18n("You can use this to certify a trusted introducer for a domain.") +
                                            QStringLiteral("<br/><br/>") +
                                            i18n("All certificates with email addresses belonging to the domain "
                                                 "that have been certified by the trusted introducer are treated "
                                                 "as certified, i.e. a trusted introducer acts as a kind of "
                                                 "intermediate CA for a domain."),
                                            q);
```

#### AUTO 


```{c}
auto glay = new QGridLayout(group);
```

#### AUTO 


```{c}
auto split = link.split(QLatin1Char(':'));
```

#### AUTO 


```{c}
const auto certs = dlg->selectedCertificates();
```

#### LAMBDA EXPRESSION 


```{c}
[] (auto domains, const auto &userID) {
            const auto newDomains = accumulateTrustDomains(userID.signatures());
            std::copy(std::begin(newDomains), std::end(newDomains), std::inserter(domains, std::end(domains)));
            return domains;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &text) {
        mApplyBtn->setEnabled(!text.isEmpty());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &[opt, fn] : funcMap) {
        if (parser.isSet(opt) && found.isEmpty()) {
            found = opt;
            foundFunc = fn;
        } else if (parser.isSet(opt)) {
            return i18n(R"(Ambiguous commands "%1" and "%2")", found, opt);
        }
    }
```

#### AUTO 


```{c}
auto comments = QString::fromLatin1("Comment: ");
```

#### AUTO 


```{c}
const auto fpr = QString::fromLatin1(key.primaryFingerprint());
```

#### AUTO 


```{c}
const auto dnsN{dnsNames()};
```

#### AUTO 


```{c}
const auto fpr = values[1].toStdString();
```

#### AUTO 


```{c}
auto mAreaWidget = new QWidget;
```

#### AUTO 


```{c}
const auto minimum_version = getVersionFromString(minimum, ok);
```

#### AUTO 


```{c}
auto iconLabel = new QLabel;
```

#### AUTO 


```{c}
auto it = dirs2sums.begin(), end = dirs2sums.end();
```

#### AUTO 


```{c}
auto splitter = new QSplitter;
```

#### AUTO 


```{c}
auto recipientsVLay = new QVBoxLayout(recipientsWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: qAsConst(mRecpWidgets)) {
        if (!edit->isEmpty() && edit->key().isNull()) {
            KMessageBox::error(this, i18nc("%1 is user input that could not be found",
                        "Could not find a key for '%1'", edit->text().toHtmlEscaped()),
                    i18n("Failed to find recipient"), KMessageBox::Notify);
            return false;
        }
    }
```

#### AUTO 


```{c}
const auto urls = mX509ServicesEntry->urlValueList();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotControllerDone(); }
```

#### AUTO 


```{c}
const auto &key
```

#### AUTO 


```{c}
const auto descriptionLbl = new QLabel(QStringLiteral("<b>%1</b><br/>%2").arg(nullTitle, nullDescription));
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey]() {
            QScopedPointer<ExportDialog> dlg(new ExportDialog(q));
            dlg->setKey(subkey, static_cast<unsigned int> (GpgME::Context::ExportSSH));
            dlg->exec();
        }
```

#### AUTO 


```{c}
auto mbox = e.getSetting(KEMailSettings::EmailAddress);
```

#### AUTO 


```{c}
auto scrollAreaLayout = qobject_cast<QBoxLayout *>(ui.scrollArea->widget()->layout());
```

#### AUTO 


```{c}
const auto it = m_buttons.find(p);
```

#### AUTO 


```{c}
const auto entry = conf->entry(QStringLiteral("gpg"),
                                   QStringLiteral("Configuration"),
                                   QStringLiteral("compliance"));
```

#### AUTO 


```{c}
const auto keys = group.keys();
```

#### AUTO 


```{c}
const auto info = gpgagent_statuslines(gpg_agent, "SCD LEARN --force", err);
```

#### AUTO 


```{c}
auto const newEntry = configEntry(s_pgpservice_componentName, s_pgpservice_entryName,
                                           CryptoConfigEntry::ArgType_String, SingleValue, DoNotShowError);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return key.protocol() == OpenPGP; }
```

#### AUTO 


```{c}
auto cmd = new KeyToCardCommand(keyref, mCardSerialNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uri : urisList) {
            keyParameters.addURI(uri);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            restoreExpandState();
            setUpTagKeys();
            if (!m_onceResized) {
                m_onceResized = true;
                resizeColumns();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int exitCode, QProcess::ExitStatus status) { slotProcessFinished(exitCode, status); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &domain) {
        return serialize("Name-DNS", encodeDomainName(domain));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[progress, proc] () {
            proc->kill();
            qCDebug(KLEOPATRA_LOG) << "Update force canceled. Output:"
                                   << QString::fromLocal8Bit(proc->readAllStandardOutput())
                                   << "stderr:"
                                   << QString::fromLocal8Bit(proc->readAllStandardError());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Signature &sig) { return !IsGoodOrValid(sig); }
```

#### AUTO 


```{c}
auto toolbar = q->findChild<KToolBar*>()
```

#### AUTO 


```{c}
auto frame = new QFrame;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar &ch : encoded)
        if (shift) {
            switch (ch.toLatin1()) {
            case '\\': decoded += QLatin1Char('\\'); break;
            case 'n':  decoded += QLatin1Char('\n'); break;
            default:
                qCDebug(KLEOPATRA_LOG) << "invalid escape sequence" << '\\' << ch << "(interpreted as '" << ch << "')";
                decoded += ch;
                break;
            }
            shift = false;
        } else {
            if (ch == QLatin1Char('\\')) {
                shift = true;
            } else {
                decoded += ch;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImportResult &result : qAsConst(results)) {
        const auto imports = result.imports();
        for (const Import &import : imports) {
            if (!import.fingerprint()) {
                continue;
            }
            fingerprints << QString::fromLatin1(import.fingerprint());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool value) {
            if (mCurrentProto != GpgME::CMS) {
                return;
            }
            if (value) {
                mSigChk->setChecked(false);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sumFileName : std::as_const(it->second)) {

            const std::vector<ChecksumsUtils::File> summedfiles = ChecksumsUtils::parse_sum_file(dir.absoluteFilePath(sumFileName));
            QStringList files;
            files.reserve(summedfiles.size());
            std::transform(summedfiles.cbegin(), summedfiles.cend(),
                           std::back_inserter(files), std::mem_fn(&ChecksumsUtils::File::name));
            const SumFile sumFile = {
                it->first,
                sumFileName,
                aggregate_size(it->first, files),
                ChecksumsUtils::filename2definition(sumFileName, checksumDefinitions),
            };
            sumfiles.push_back(sumFile);

        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->showTrustChainDialog(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : qAsConst(mRecpWidgets)) {
        if (!w->isEnabled()) {
            // If one is disabled, all are disabled.
            break;
        }
        const Key k = w->key();
        if (!k.isNull()) {
            ret << k;
        }
    }
```

#### AUTO 


```{c}
auto const legacyEntry = configEntry(s_pgpservice_legacy_componentName, s_pgpservice_legacy_entryName,
                                             CryptoConfigEntry::ArgType_String, SingleValue, DoNotShowError);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &group : selection.selected) {
            selectionModel->select(getGroupIndex(group), QItemSelectionModel::Select | QItemSelectionModel::Rows);
        }
```

#### AUTO 


```{c}
const auto pgpCard = dynamic_cast<SmartCard::OpenPGPCard*>(card.get());
```

#### AUTO 


```{c}
auto mCMSRB = new QRadioButton(i18n("S/MIME"));
```

#### LAMBDA EXPRESSION 


```{c}
[okButton] (const QString &text) {
                    okButton->setEnabled(!text.trimmed().isEmpty());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, kind](const QString &newName) {
                        mOutNames[kind] = newName;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : std::as_const(attrOrder)) {
        const QString key = rawKey.trimmed().toUpper();
        const QString attr = attributeFromKey(key);
        if (attr.isEmpty()) {
            continue;
        }
        const QString preset = savedValues.value(attr, config.readEntry(attr, QString()));
        const bool required = key.endsWith(QLatin1Char('!'));
        const bool readonly = config.isEntryImmutable(attr);
        const QString label = config.readEntry(attr + QLatin1String("_label"),
                                               attributeLabel(attr, pgp()));
        const QString regex = config.readEntry(attr + QLatin1String("_regex"));
        const QString placeholder = config.readEntry(attr + QLatin1String{"_placeholder"});

        int row;
        bool known = true;
        QValidator *validator = nullptr;
        if (attr == QLatin1String("EMAIL")) {
            row = row_index_of(ui->emailLE, ui->gridLayout);
            validator = regex.isEmpty() ? Validation::email() : Validation::email(regex);
        } else if (attr == QLatin1String("NAME") || attr == QLatin1String("CN")) {
            if ((pgp() && attr == QLatin1String("CN")) || (!pgp() && attr == QLatin1String("NAME"))) {
                continue;
            }
            if (pgp()) {
                validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(regex);
            }
            row = row_index_of(ui->nameLE, ui->gridLayout);
        } else {
            known = false;
            row = add_row(ui->gridLayout, &dynamicWidgets);
        }
        if (!validator && !regex.isEmpty()) {
            validator = new QRegularExpressionValidator{QRegularExpression{regex}, nullptr};
        }

        QLineEdit *le = adjust_row(ui->gridLayout, row, label, preset, validator, readonly, required);
        le->setPlaceholderText(placeholder);

        const Line line = { key, label, regex, le };
        lines[row] = line;

        if (!known) {
            widgets.push_back(le);
        }

        // don't connect twice:
        disconnect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
        connect(le, &QLineEdit::textChanged, this, &EnterDetailsPage::slotUpdateResultLabel);
    }
```

#### AUTO 


```{c}
const auto certificate = KeyCache::instance()->findSubkeyByKeyGrip(cardKeygrip).parent();
```

#### AUTO 


```{c}
auto buttons = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto progressLabelByTagKeys{m_progressLabelByTag.keys()};
```

#### AUTO 


```{c}
auto dlg = new Dialogs::GroupDetailsDialog{q};
```

#### AUTO 


```{c}
auto cmd = new ChangePinCommand(mCardSerialNumber, PIVCard::AppName, this);
```

#### AUTO 


```{c}
const auto it = std::find_if(runnable.begin(), runnable.end(),
                       [proto](const std::shared_ptr<Kleo::Crypto::EncryptEMailTask> &task) {
                           return task->protocol() == proto;
                       });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi: workdir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot)) {
            const auto inpath = fi.absoluteFilePath();

            if (fi.isDir()) {
                // A directory. Assume that the input was an archive
                // and avoid directory merges by trying to find a non
                // existing directory.
                auto candidate = fi.baseName();
                if (candidate.startsWith(QLatin1Char('-'))) {
                    // Bug in GpgTar Extracts stdout passed archives to a dir named -
                    candidate = QFileInfo(m_passedFiles.first()).baseName();
                }

                QString suffix;
                QFileInfo ofi;
                int i = 0;
                do {
                    ofi = QFileInfo(outDir.absoluteFilePath(candidate + suffix));
                    if (!ofi.exists()) {
                        break;
                    }
                    suffix = QStringLiteral("_%1").arg(++i);
                } while (i < 1000);


                if (!QFile::rename(inpath, ofi.absoluteFilePath())) {
                    reportError(makeGnuPGError(GPG_ERR_GENERAL),
                            xi18n("Failed to move <filename>%1</filename> to <filename>%2</filename>.",
                                  inpath, ofi.absoluteFilePath()));
                }
                continue;
            }
            const auto outpath = outDir.absoluteFilePath(fi.fileName());
            qCDebug(KLEOPATRA_LOG) << "Moving " << inpath << " to " << outpath;
            const QFileInfo ofi(outpath);
            if (ofi.exists()) {
                int sel = KMessageBox::No;
                if (!overWriteAll) {
                    sel = KMessageBox::questionYesNoCancel(m_dialog, i18n("The file <b>%1</b> already exists.\n"
                                                           "Overwrite?", outpath),
                                                           i18n("Overwrite Existing File?"),
                                                           KStandardGuiItem::overwrite(),
                                                           KGuiItem(i18n("Overwrite All")),
                                                           KStandardGuiItem::cancel());
                }
                if (sel == KMessageBox::Cancel) {
                    qCDebug(KLEOPATRA_LOG) << "Overwriting canceled for: " << outpath;
                    continue;
                }
                if (sel == KMessageBox::No) { //Overwrite All
                    overWriteAll = true;
                }
                if (!QFile::remove(outpath)) {
                    reportError(makeGnuPGError(GPG_ERR_GENERAL),
                                xi18n("Failed to delete <filename>%1</filename>.",
                                      outpath));
                    continue;
                }
            }
            if (!QFile::rename(inpath, outpath)) {
                reportError(makeGnuPGError(GPG_ERR_GENERAL),
                            xi18n("Failed to move <filename>%1</filename> to <filename>%2</filename>.",
                                  inpath, outpath));
            }
        }
```

#### AUTO 


```{c}
const auto it = id.map->find(what);
```

#### AUTO 


```{c}
const auto pgpSigFpr = card->keyFingerprint(OpenPGPCard::pgpSigKeyRef());
```

#### AUTO 


```{c}
auto protocolGroup = new QButtonGroup(q);
```

#### AUTO 


```{c}
const auto pivCard = SmartCard::ReaderStatus::instance()->getCard<PIVCard>(mSerial);
```

#### AUTO 


```{c}
auto proto = getProtocol(result);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { changePin(PIVCard::pinKeyRef()); }
```

#### AUTO 


```{c}
const auto card = getCardToTransferSubkeyTo(subkey, parentWidgetOrView());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) { slotDoubleClicked(index); }
```

#### AUTO 


```{c}
const auto serialNumber = Assuan::sendStatusCommand(gpgAgent, "SCD SERIALNO", err);
```

#### AUTO 


```{c}
const auto description = errorShown ? ui.errorLabel.text() : QString{};
```

#### AUTO 


```{c}
const auto vsa10584 = new DocAction(QIcon::fromTheme(QStringLiteral("dvipdf")), i18n("SecOps VSA-10584"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                "BSI-VSA-10584-ENG_secops-20220207.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### AUTO 


```{c}
const auto blockedUrlSchemes = Settings{}.blockedUrlSchemes();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { showOrHideCertifyButton(); }
```

#### AUTO 


```{c}
const auto parentTask = m_result->parentTask();
```

#### AUTO 


```{c}
const auto &grpName
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QItemSelection &oldSel, const QItemSelection &newSel) {
        slotSelectionChanged(oldSel, newSel);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, gpgconf, profile] () {
        mApplyBtn->setEnabled(true);
        if (gpgconf->exitStatus() != QProcess::NormalExit) {
            KMessageBox::error(this, QStringLiteral("<pre>%1</pre>").arg(QString::fromLocal8Bit(gpgconf->readAll())));
            delete gpgconf;
            return;
        }
        delete gpgconf;
        KMessageBox::information(this,
                         i18nc("%1 is the name of the profile",
                               "The configuration profile \"%1\" was applied.", profile),
                         i18n("GnuPG Profile - Kleopatra"));
        auto config = QGpgME::cryptoConfig();
        if (config) {
            config->clear();
        }
    }
```

#### AUTO 


```{c}
const auto fm = q->fontMetrics();
```

#### AUTO 


```{c}
const auto quickguide = new DocAction(QIcon::fromTheme(QStringLiteral("help-hint")), i18n("Quickguide"),
            i18nc("Only available in German and English. Leave to English for other languages.",
                "handout_sign_encrypt_gnupg_en.pdf"),
            QStringLiteral("../share/doc/gnupg-vsd"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &group: std::as_const(mAddedGroups)) {
        removeRecipient(group);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](SessionDataHandler*) { mutex.unlock(); }
```

#### AUTO 


```{c}
const auto holder = QString::fromStdString(card->cardHolder());
```

#### AUTO 


```{c}
const auto &sub
```

#### AUTO 


```{c}
auto group = new QGroupBox(i18n("WatchGnuPG"), top);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &str) {
                                 return re.match(str).hasMatch();
                             }
```

#### AUTO 


```{c}
auto comp = config->component(compName);
```

#### AUTO 


```{c}
const auto size = dialog.readEntry("Size", QSize(600, 800));
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : qAsConst(mRecpWidgets)) {
        if (w->key().isNull() && w->group().isNull()) {
            oneEmpty = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto exportJob = startExportJob(key);
```

#### AUTO 


```{c}
const auto collapsedHeight = sizeHint().height() - contentArea.maximumHeight();
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *Close = "window_close_tab";
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &k) { return k.protocol() == Protocol::CMS; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file: files) {
        if (QFileInfo(file).isDir()) {
            setOperationMode((operationMode() & ~ArchiveMask) | ArchiveForced);
            archive = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto dvResult = dynamic_cast<const Kleo::Crypto::DecryptVerifyResult*>(result.get());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool valid) { onValidityChanged(valid); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { close(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return !key.isNull(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: std::as_const(mRecpWidgets)) {
        if (edit->isEnabled() && !edit->isEmpty() && edit->key().isNull() && edit->group().isNull()) {
            if (!firstUnresolvedRecipient) {
                firstUnresolvedRecipient = edit;
            }
            unresolvedRecipients.push_back(edit->text().toHtmlEscaped());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { refreshCertificate(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, chk]() {
            KConfigGroup updatecfg(KSharedConfig::openConfig(), "UpdateNotification");
            updatecfg.writeEntry("NeverShow", !chk->isChecked());
            QDialog::reject();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : qAsConst(files)) {
                QFileInfo fi(fileName);
                if (!fi.isReadable()) {
                    errors << i18n("Cannot read \"%1\"", fileName);
                }
            }
```

#### AUTO 


```{c}
const auto proto = pgp() ? QGpgME::openpgp() : QGpgME::smime();
```

#### AUTO 


```{c}
auto const cmd = new ExportOpenPGPCertsToServerCommand(certificationTarget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : files) {
        CryptoFile cFile;
        cFile.fileName = file;
        cFile.baseName = stripSuffix(file);
        cFile.classification = classify(file);
        cFile.protocol = findProtocol(cFile.classification);

        auto it = std::find_if(out.begin(), out.end(),
                               [&cFile](const CryptoFile &other) {
                                    return other.protocol == cFile.protocol
                                            && other.baseName == cFile.baseName;
                               });
        if (it != out.end()) {
            // If we found a file with the same basename, make sure that encrypted
            // file is before the signature file, so that we first decrypt and then
            // verify
            if (isSignature(cFile.classification) && isCipherText(it->classification)) {
                out.insert(it + 1, cFile);
            } else if (isCipherText(cFile.classification) && isSignature(it->classification)) {
                out.insert(it, cFile);
            } else {
                // both are signatures or both are encrypted files, in which
                // case order does not matter
                out.insert(it, cFile);
            }
        } else {
            out.push_back(cFile);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &idx) {
        const auto klm = dynamic_cast<KeyListModelInterface *> (mTreeView->view()->model());
        if (!klm) {
            qCDebug(KLEOPATRA_LOG) << "Unhandled Model: " << mTreeView->view()->model()->metaObject()->className();
            return;
        }
        auto cmd = new DetailsCommand(klm->key(idx), nullptr);
        cmd->setParentWidget(this);
        cmd->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &scheme : blockedUrlSchemes) {
        QDesktopServices::setUrlHandler(scheme, this, "blockUrl");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : std::as_const(d->uids))
        if (qstricmp(uid.parent().primaryFingerprint(), d->certificationTarget.primaryFingerprint()) != 0) {
            qCWarning(KLEOPATRA_LOG) << "User ID <-> Key mismatch!";
            d->finished();
            return;
        }
```

#### AUTO 


```{c}
auto areaWidget = new QWidget;
```

#### AUTO 


```{c}
const auto timestamp = time.toString(QStringLiteral("yyyyMMdd'T'HHmmss"));
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                // queue the call of editFinished() to ensure that QCompleter::activated is handled first
                QMetaObject::invokeMethod(this, &CertificateLineEdit::editFinished, Qt::QueuedConnection);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { create(); }
```

#### AUTO 


```{c}
const auto choice = KMessageBox::warningContinueCancel(d->parentWidgetOrView(), warningText,
            i18nc("@title:window", "Overwrite existing key"),
            KStandardGuiItem::cont(), KStandardGuiItem::cancel(), QString(), KMessageBox::Notify | KMessageBox::Dangerous);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (pair.first == "KEY-FPR" ||
            pair.first == "KEY-TIME") {
            // Key fpr and key time need to be distinguished, the number
            // of the key decides the usage.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[0];
            const auto fpr = values[1].toStdString();
            if (usage == QLatin1Char('1')) {
                mMetaInfo.insert(std::string("SIG") + pair.first, fpr);
            } else if (usage == QLatin1Char('2')) {
                mMetaInfo.insert(std::string("ENC") + pair.first, fpr);
            } else if (usage == QLatin1Char('3')) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, fpr);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else if (pair.first == "KEYPAIRINFO") {
            // Fun, same as above but the other way around.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[1];
            const auto grip = values[0].toStdString();
            if (usage == QLatin1String("OPENPGP.1")) {
                mMetaInfo.insert(std::string("SIG") + pair.first, grip);
            } else if (usage == QLatin1String("OPENPGP.2")) {
                mMetaInfo.insert(std::string("ENC") + pair.first, grip);
            } else if (usage == QLatin1String("OPENPGP.3")) {
                mMetaInfo.insert(std::string("AUTH") + pair.first, grip);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_importCanceled = true; }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { slotSearchTextChanged(text); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
                auto cmd = new Kleo::Commands::RevokeCertificationCommand(userID);
                cmd->setParentWidget(q);
                certificationsTV->setEnabled(false);
                connect(cmd, &Kleo::Commands::RevokeCertificationCommand::finished,
                        q, [this]() {
                    certificationsTV->setEnabled(true);
                    // Trigger an update when done
                    q->setKey(key);
                });
                cmd->start();
            }
```

#### AUTO 


```{c}
const auto cache = KeyCache::instance();
```

#### AUTO 


```{c}
auto const cmd = new SignEncryptFilesCommand(files, nullptr);
```

#### AUTO 


```{c}
const auto entry = getCryptoConfigEntry(conf, engineIsVersion(2, 3, 0)? "dirmngr" : "gpg", "keyserver");
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) {
                                             return key.hasSecret();
                                        }
```

#### AUTO 


```{c}
auto ci = std::shared_ptr<Card> (new Card());
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &i : tasks) {
        assert(i);
        d->m_tasks[i->id()] = i;
        connect(i.get(), SIGNAL(progress(QString,int,int)),
                this, SLOT(taskProgress(QString,int,int)));
        connect(i.get(), SIGNAL(result(std::shared_ptr<const Kleo::Crypto::Task::Result>)),
                this, SLOT(taskResult(std::shared_ptr<const Kleo::Crypto::Task::Result>)));
        connect(i.get(), SIGNAL(started()),
                this, SLOT(taskStarted()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Signature &sig : sigs) {
        details += formatSignature(sig, DecryptVerifyResult::keyForSignature(sig, signers), info) + QLatin1Char('\n');
    }
```

#### AUTO 


```{c}
auto vLay = new QVBoxLayout(q);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: KeyCache::instance()->findSigners(dvResult->verificationResult())) {
            return key.protocol();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyRef] () { createCSR(keyRef); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &r) { return r.result; }
```

#### AUTO 


```{c}
const auto sigKey = mSigEncWidget->signKey();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : netKeyCard->keyInfos()) {
        if (key.keyRef.substr(0, 9) == "NKS-SIGG.") {
            // SigG certificates for qualified signatures are issued with the physical cards;
            // it's not possible to request a certificate for them
            continue;
        }
        if (key.canSign() && (key.keyRef.substr(0, 9) == "NKS-NKS3.") && !netKeyCard->hasNKSNullPin()) {
            keys.push_back(key);
        }
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox();
```

#### AUTO 


```{c}
auto const cmd = new ChecksumCreateFilesCommand(createFiles, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const Sender &sender) { return count_signing_certificates(proto, sender) >= 1; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &state: chvStatus) {
        const auto parsed = parse_pin_state (state);
        states.push_back(parsed);
        if (parsed == Card::NullPin) {
            ret->setHasNullPin(true);
        }
    }
```

#### AUTO 


```{c}
auto contentHeight = contentLayout->sizeHint().height();
```

#### AUTO 


```{c}
const auto entry = getCryptoConfigEntry(conf, protocol == CMS ? "gpgsm" : "gpg", "default_pubkey_algo");
```

#### AUTO 


```{c}
auto ctx = QGpgME::Job::context(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (KeyPairInfo &k : mKeyInfos) {
        if (k.keyRef == keyPairInfo.keyRef) {
            k.update(keyPairInfo);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { Q_EMIT changed(true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Sender &s : qAsConst(senders)) {
            addRecipient(s);
        }
```

#### AUTO 


```{c}
const auto shortKeyID = Formatting::prettyKeyID(key.shortKeyID());
```

#### AUTO 


```{c}
const auto nptr = (*nit).get();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w: std::as_const(mUnknownWidgets)) {
        mRecpLayout->removeWidget(w);
        delete w;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotWizardCanceled(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        canceled();
        protocolDialog->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Recipient &r : qAsConst(recipients)) {
            addRecipient(r);
        }
```

#### AUTO 


```{c}
auto filter = std::make_shared<DefaultKeyFilter>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::ImportResult &result) {
                        return result.error().code();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &task : qAsConst(runnable)) {
            q->connectTask(task);
        }
```

#### AUTO 


```{c}
auto learnLbl = new QLabel();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWidget *, QWidget *now) {
                d->updateFocusFrame(now);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAbstractItemView *view) { removeView(view); }
```

#### AUTO 


```{c}
const auto chvStatus = QString::fromStdString(
            scd_getattr_status(gpg_agent, "CHV-STATUS", err)).split(QStringLiteral(" \t"));
```

#### AUTO 


```{c}
auto ret = KMessageBox::warningContinueCancel(this,
            i18n("Setting a PIN is required but <b>can't be reverted</b>.") +
            QStringLiteral("<p>%1</p><p>%2</p>").arg(
                i18n("If you proceed you will be asked to enter a new PIN "
                     "and later to repeat that PIN.")).arg(
                i18n("It will <b>not be possible</b> to recover the "
                     "card if the PIN has been entered wrongly more than 2 times.")),
            i18n("Set initial PIN"),
            KStandardGuiItem::cont(),
            KStandardGuiItem::cancel());
```

#### AUTO 


```{c}
const auto verbatimType = scd_getattr_status(gpg_agent, "APPTYPE", err);
```

#### AUTO 


```{c}
const auto ei = GpgME::engineInfo(GpgME::GpgConfEngine);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : identifiers) {
        const Mailbox mbox = m_listWidget->mailbox(i);
        if (!mbox.hasAddress()) {
            continue;
        }
        const Key pgp = m_listWidget->selectedCertificate(i, OpenPGP);
        if (!pgp.isNull()) {
            m_recipientPreferences->setPreferredCertificate(mbox, OpenPGP, pgp);
        }
        const Key cms = m_listWidget->selectedCertificate(i, CMS);
        if (!cms.isNull()) {
            m_recipientPreferences->setPreferredCertificate(mbox, CMS, cms);
        }
    }
```

#### AUTO 


```{c}
const auto id = mChecksumDefinitionCB.widget()->itemData(idx).toString();
```

#### AUTO 


```{c}
auto parameters = d->technicalParameters;
```

#### AUTO 


```{c}
auto job = protocol->publicKeyExportJob(true);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &canceledIds, const auto &r) {
                                                 if (importWasCanceled(r)) {
                                                     canceledIds.insert(r.id);
                                                 }
                                                 return canceledIds;
                                             }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->changePassphrase(); }
```

#### AUTO 


```{c}
auto dialog = std::make_unique<EditGroupDialog>(q);
```

#### AUTO 


```{c}
auto group = mCompleter->completionModel()->data(index, KeyList::GroupRole).value<KeyGroup>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &app: apps) {
                        qCDebug(KLEOPATRA_LOG) << "getCardsAndApps(): Found card" << serialNumber << "with app" << app;
                        result.push_back({ serialNumber.toStdString(), app.toStdString() });
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) {
                             return key.protocol() == GpgME::OpenPGP;
                         }
```

#### AUTO 


```{c}
auto ctx = GpgME::Context::createForProtocol(GpgME::OpenPGP);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Protocol i : selectedProtocols()) {
        if (signingCertificates(i).empty()) {
            res.insert(i);
        }
    }
```

#### AUTO 


```{c}
const auto focusWidget = (index < mRecpLayout->count() - 1) ?
                mRecpLayout->itemAt(index + 1)->widget() :
                mRecpLayout->itemAt(mRecpLayout->count() - 2)->widget();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &group: qAsConst(mAddedGroups)) {
        removeRecipient(group);
    }
```

#### AUTO 


```{c}
auto *completer = new QCompleter(this);
```

#### AUTO 


```{c}
const auto index = certificationsTV->indexAt(p);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mailbox &i : recipients) {
        //TODO:
        const QString address = i.prettyAddress();
        d->addRecipient(i);
        const std::vector<Key> pgp = makeSuggestions(d->m_recipientPreferences, i, OpenPGP);
        const std::vector<Key> cms = makeSuggestions(d->m_recipientPreferences, i, CMS);
        pgpCount += pgp.empty() ? 0 : 1;
        cmsCount += cms.empty() ? 0 : 1;
        d->m_listWidget->setCertificates(address, pgp, cms);
    }
```

#### AUTO 


```{c}
auto certRequesterSignal = &KleopatraClientCopy::Gui::CertificateRequester::selectedCertificatesChanged;
```

#### AUTO 


```{c}
auto lb = new QLabel(l->parentWidget());
```

#### AUTO 


```{c}
auto const layout = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[proc] () {
        while (proc->canReadLine()) {
            const QString line = QString::fromUtf8(proc->readLine()).trimmed();
            // Command-fd is a stable interface, while this is all kind of hacky we
            // are on a deadline :-/
            if (line == QLatin1String("[GNUPG:] GET_BOOL gen_revoke.okay")) {
                proc->write("y\n");
            } else if (line == QLatin1String("[GNUPG:] GET_LINE ask_revocation_reason.code")) {
                proc->write("0\n");
            } else if (line == QLatin1String("[GNUPG:] GET_LINE ask_revocation_reason.text")) {
                proc->write("\n");
            } else if (line == QLatin1String("[GNUPG:] GET_BOOL openfile.overwrite.okay")) {
                // We asked before
                proc->write("y\n");
            } else if (line == QLatin1String("[GNUPG:] GET_BOOL ask_revocation_reason.okay")) {
                proc->write("y\n");
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        onProtocolChosen();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { restoreExpandState(); }
```

#### AUTO 


```{c}
auto it = certs.cbegin(), endIt = certs.cend();
```

#### AUTO 


```{c}
const auto servers = mDirectoryServices->keyservers();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        //QListWidgetItem * item = new QListWidgetItem( d->categoriesLV );
        apply_config(KConfigGroup(config, group), new QListWidgetItem(d->categoriesLV));
    }
```

#### AUTO 


```{c}
auto cmd = new PIVGenerateCardKeyCommand(mCardSerialNumber, this);
```

#### AUTO 


```{c}
auto sel = KMessageBox::questionYesNo(d->parentWidgetOrView(),
                    xi18nc("@info", "To certify other certificates, you first need to create an OpenPGP certificate for yourself.") +
                    QStringLiteral("<br><br>") +
                    i18n("Do you wish to create one now?"),
                    i18n("Certification Not Possible"));
```

#### AUTO 


```{c}
const auto &key = index.data(KeyList::KeyRole).value<GpgME::Key>();
```

#### AUTO 


```{c}
const auto it = actions.find(name);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : filesToImportGroupsFrom) {
        const bool certificateImportSucceeded =
            std::any_of(std::cbegin(results), std::cend(results),
                        [path](const auto &r) {
                            return r.id == path && !importFailed(r) && !importWasCanceled(r);
                        });
        if (certificateImportSucceeded) {
            qCDebug(KLEOPATRA_LOG) << __func__ << "Importing groups from file" << path;
            const auto groups = readKeyGroups(path);
            std::transform(std::begin(groups), std::end(groups),
                           std::back_inserter(importedGroups),
                           [path](const auto &group) {
                               return storeGroup(group, path);
                           });
        }
    }
```

#### AUTO 


```{c}
static auto accumulateNewOpenPGPKeys(const std::vector<ImportResultData> &results)
{
    return std::accumulate(std::begin(results), std::end(results),
                           std::vector<std::string>{},
                           [](auto fingerprints, const auto &r) {
                               if (r.protocol == GpgME::OpenPGP) {
                                   fingerprints = accumulateNewKeys(fingerprints, r.result.imports());
                               }
                               return fingerprints;
                           });
}
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {Q_EMIT q->backRequested();}
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w: mUnknownWidgets) {
            auto key = KeyCache::instance()->findByKeyIDOrFingerprint(w->keyID().toLatin1().constData());
            if (key.isNull()) {
                std::vector<std::string> subids;
                subids.push_back(std::string(w->keyID().toLatin1().constData()));
                for (const auto &subkey: KeyCache::instance()->findSubkeysByKeyID(subids)) {
                    key = subkey.parent();
                }
            }
            if (key.isNull()) {
                continue;
            }
            // Key is now available replace by line edit.
            qCDebug(KLEOPATRA_LOG) << "Removing widget for keyid: " << w->keyID();
            mRecpLayout->removeWidget(w);
            mUnknownWidgets.removeAll(w);
            delete w;
            addRecipient(key);
        }
```

#### AUTO 


```{c}
const auto lines = gpgagent_statuslines (gpgAgent, what, err);
```

#### AUTO 


```{c}
const auto remarkKeyFpr = conf.readEntry("RemarkKeyFpr", QString());
```

#### AUTO 


```{c}
auto verticalLayout = new QVBoxLayout{dialog};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sig : signatures) {
                    const auto classification = classify(sig);
                    qCDebug(KLEOPATRA_LOG) << "Guessing: " << sig << " is a signature for: " << cFile.fileName
                                           << "Classification: " << classification;
                    const auto proto = findProtocol(classification);
                    if (proto == GpgME::UnknownProtocol) {
                        qCDebug(KLEOPATRA_LOG) << "Could not determine protocol. Skipping guess.";
                        continue;
                    }
                    foundSig = true;
                    std::shared_ptr<VerifyDetachedTask> t(new VerifyDetachedTask);
                    t->setInput(Input::createFromFile(sig));
                    t->setSignedData(Input::createFromFile(cFile.fileName));
                    t->setProtocol(proto);
                    tasks.push_back(t);
                }
```

#### AUTO 


```{c}
auto groupNameLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const std::shared_ptr<Kleo::Crypto::EncryptEMailTask> &task) {
                           return task->protocol() == proto;
                       }
```

#### AUTO 


```{c}
static auto searchTextToEmailAddress(const QString &s)
{
    return QString::fromStdString(UserID::addrSpecFromString(s.toStdString().c_str()));
}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { publishCertificate(); }
```

#### AUTO 


```{c}
const auto maxWindowSize = screen()->geometry().size() * 2 / 3;
```

#### AUTO 


```{c}
const auto bkpFile = QString::fromStdString(backup);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(qq);
```

#### AUTO 


```{c}
auto entry = conf->entry(QStringLiteral("dirmngr"),
                             QStringLiteral("Enforcement"),
                             QStringLiteral("allow-version-check"));
```

#### AUTO 


```{c}
const auto minDate = ui.expiryDE->minimumDate();
```

#### AUTO 


```{c}
auto glay = new QGridLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QMetaObject::Connection &conn) {
        return conn;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mbox](const Key &key) {
                            return keyContainsMailbox(key, mbox);
                        }
```

#### AUTO 


```{c}
const auto it = d->inputs.options.find(name);
```

#### AUTO 


```{c}
static const auto maxRetryDelay = 1000ms;
```

#### AUTO 


```{c}
auto parts = text.split(QLatin1Char(' '));
```

#### AUTO 


```{c}
auto outLabel = new QLabel(i18n("&Output folder:"));
```

#### AUTO 


```{c}
auto item = ui.subkeysTree->itemAt(p);
```

#### AUTO 


```{c}
const auto params = dlg->getKeyParams();
```

#### LAMBDA EXPRESSION 


```{c}
[addButton] (const QItemSelection &selected, const QItemSelection &) {
                    addButton->setEnabled(!selected.isEmpty());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QItemSelection &, const QItemSelection &) { slotSelectionChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : identifiers) {
        const GpgME::Key cert = d->m_listWidget->selectedCertificate(i);
        if (!cert.isNull()) {
            certs.push_back(cert);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyref] () {
                this->updateKeyWidgets(keyref, nullptr);
                this->setEnabled(true);
            }
```

#### AUTO 


```{c}
auto page =
            new AppearanceConfigurationPage(parent, args);
```

#### AUTO 


```{c}
const auto &ad
```

#### AUTO 


```{c}
auto &group
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { onDialogAccepted(); }
```

#### AUTO 


```{c}
auto recipientWidget = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const UserID &uid : qAsConst(d->uids))
        if (qstricmp(uid.parent().primaryFingerprint(), d->certificationTarget.primaryFingerprint()) != 0) {
            qCWarning(KLEOPATRA_LOG) << "User-ID <-> Key mismatch!";
            d->finished();
            return;
        }
```

#### AUTO 


```{c}
auto cmd = new ImportPaperKeyCommand(subkey.parent());
```

#### AUTO 


```{c}
auto pMail = Kleo::Formatting::prettyEMail(uid);
```

#### AUTO 


```{c}
auto newOpenPGPKeys = KeyCache::instance()->findByFingerprint(accumulateNewOpenPGPKeys(results));
```

#### AUTO 


```{c}
auto name = e.getSetting(KEMailSettings::RealName);
```

#### AUTO 


```{c}
auto proc = process();
```

#### LAMBDA EXPRESSION 


```{c}
[this, chk]() {
            KConfigGroup updatecfg(KSharedConfig::openConfig(), "UpdateNotification");
            updatecfg.writeEntry("NeverShow", !chk->isChecked());
            gpgconf_set_update_check (chk->isChecked());
            QDialog::reject();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &link) { smimeLinkActivated(link); }
```

#### AUTO 


```{c}
auto mMainWin = new KWatchGnuPGMainWindow();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const GpgME::Key &) {
#ifdef GPGME_HAS_REMARKS
            updateTags();
#endif
            Q_EMIT q->changed();
        }
```

#### AUTO 


```{c}
auto ret = mOutNames;
```

#### AUTO 


```{c}
const auto backend = (key().protocol() == GpgME::OpenPGP) ? QGpgME::openpgp() : QGpgME::smime();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotUpdateRequested(); }
```

#### AUTO 


```{c}
const auto emailError = ui.nameAndEmail->emailError();
```

#### LAMBDA EXPRESSION 


```{c}
[uid](const GpgME::UserID &other) { return uidEqual(uid, other); }
```

#### AUTO 


```{c}
auto resetCodeButton = new QPushButton(i18n("Change Reset Code"));
```

#### AUTO 


```{c}
const auto lowered = split[0].toLower().remove(QLatin1Char('-'));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : ids) {
        if (d->m_listWidget->selectedCertificate(i).isNull()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
const auto time = QDateTime::fromSecsSinceEpoch(mKey.creationTime());
```

#### AUTO 


```{c}
auto line1 = new QFrame();
```

#### LAMBDA EXPRESSION 


```{c}
[this, cmd]() {
                         ui.genRevokeBtn->setEnabled(true);
                     }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { doChangePin(NetKeyCard::sigGPinKeyRef()); }
```

#### AUTO 


```{c}
auto w = parent->nextInFocusChain();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info: infos) {
        const auto key = lookup_key(klc.get(), info.grip);
        if (key.isNull()) {
            setCanLearnKeys(true);
        }
        mKeys.push_back(key);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { canceled(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                mCryptBtn->setEnabled(true);
                mDecryptBtn->setEnabled(true);
                mProgressBar->setVisible(false);
                mProgressLabel->setVisible(false);

                updateCommitButton();
                mRevertBtn->setVisible(true);
                mEdit->setPlainText(QString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &i : keys) {
        fingerprints << QLatin1String(i.primaryFingerprint());
    }
```

#### AUTO 


```{c}
const auto edit
```

#### AUTO 


```{c}
const auto &cd
```

#### AUTO 


```{c}
auto nameLabel = new QLabel(i18n("Name:"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey, card]() {
        auto cmd = new Kleo::Commands::KeyToCardCommand(subkey, card->serialNumber());
        ui.subkeysTree->setEnabled(false);
        connect(cmd, &Kleo::Commands::KeyToCardCommand::finished,
                q, [this]() { ui.subkeysTree->setEnabled(true); });
        cmd->setParentWidget(q);
        cmd->start();
    }
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) {
                                       return ! (key.protocol() == GpgME::CMS &&
                                                 !key.subkey(0).isNull() &&
                                                 key.subkey(0).canSign() &&
                                                 !key.subkey(0).canEncrypt() &&
                                                 key.subkey(0).isSecret() &&
                                                 !key.subkey(0).isCardKey());
                                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *opt : qAsConst(options)) {
        std::string line = "OPTION ";
        line += opt;
        if (const gpg_error_t err = assuan_transact(ctx, line.c_str(), nullptr, nullptr, nullptr, nullptr, nullptr, nullptr)) {
            qDebug("%s", Exception(err, line).what());
            return 1;
        }
    }
```

#### AUTO 


```{c}
auto pivCard = ReaderStatus::instance()->getCard<PIVCard>(serialNumber());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotExpandAll(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &existingKey: mSigEncWidget->recipients()) {
                if (existingKey.primaryFingerprint() && key.primaryFingerprint() &&
                    !strcmp (existingKey.primaryFingerprint(), key.primaryFingerprint())) {
                    keyFound = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit : qAsConst(mRecpWidgets)) {
                edit->setEnabled(toggled);
            }
```

#### AUTO 


```{c}
const auto command = std::string("READKEY --card --no-data -- ") + keyInfo.keyRef;
```

#### LAMBDA EXPRESSION 


```{c}
[this, signature]() {
                auto cmd = new Kleo::Commands::RevokeCertificationCommand(signature);
                cmd->setParentWidget(q);
                certificationsTV->setEnabled(false);
                connect(cmd, &Kleo::Commands::RevokeCertificationCommand::finished,
                        q, [this]() {
                    certificationsTV->setEnabled(true);
                    // Trigger an update when done
                    q->setKey(key);
                });
                cmd->start();
            }
```

#### AUTO 


```{c}
const auto readers = SmartCard::ReaderStatus::getReaders(err);
```

#### AUTO 


```{c}
const auto views = tabWidget->views();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotCollapseAll(); }
```

#### AUTO 


```{c}
const auto prev = it - 1;
```

#### LAMBDA EXPRESSION 


```{c}
[focusPolicy](const auto &label) {
                      if (label) {
                          label->setFocusPolicy(focusPolicy);
                      }
                  }
```

#### LAMBDA EXPRESSION 


```{c}
[](ChecksumVerifyFilesCommand *){}
```

#### AUTO 


```{c}
const auto wd = QDir(m_workDir.path());
```

#### AUTO 


```{c}
auto button = new QPushButton(i18nc("@action:button", "Change PUK"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &keyId : keyIds) {
        startImport(GpgME::OpenPGP, {keyId}, QStringLiteral("Retrieve Signer Keys"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                updateCommitButton();
            }
```

#### AUTO 


```{c}
auto size
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
const auto bytesWritten = f.write(keyData);
```

#### AUTO 


```{c}
auto subLay3 = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : positionalArguments) {
            // We do not check that file exists here. Better handle
            // these errors in the UI.
            if (QFileInfo(file).isAbsolute()) {
                files << file;
            } else {
                files << cwd.absoluteFilePath(file);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { onDescriptionTextChanged(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, forKind](const QString &newName) {
                    mOutNames[forKind] = newName;
                 }
```

#### LAMBDA EXPRESSION 


```{c}
[on](std::shared_ptr<AssuanServerConnection> conn) {
                      conn->enableCryptoCommands(on);
                  }
```

#### AUTO 


```{c}
const auto choice = KMessageBox::questionYesNo(
        parentWidgetOrView(), message, i18nc("@title:window", "Write certificate to card"),
        confirmButton, KStandardGuiItem::cancel(), QString(), KMessageBox::Notify | KMessageBox::WindowModal);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotDialogAccepted(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : ids) {
        if (!id.isEmpty()) {
            escapedIds << id.toHtmlEscaped();
        }
    }
```

#### AUTO 


```{c}
const auto key = KeyCache::instance()->findByFingerprint(fpr.toLatin1().constData());
```

#### AUTO 


```{c}
auto label = new QLabel{i18n("Choose which type of key pair you want to create."), parent};
```

#### RANGE FOR STATEMENT 


```{c}
for (const Sender &s : std::as_const(senders)) {
            addRecipient(s);
        }
```

#### AUTO 


```{c}
const auto encFpr = keys.readEntry("EncryptKey", QString());
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                if (mImportProto != GpgME::UnknownProtocol) {
                    doImport();
                } else {
                    doEncryptSign();
                }
            }
```

#### AUTO 


```{c}
const auto resultAppName = ReaderStatus::switchApp(assuanContext, serialNumber(), appName, err);
```

#### AUTO 


```{c}
auto keysGrid = new QGridLayout;
```

#### AUTO 


```{c}
const auto readers = SCDaemon::getReaders(err);
```

#### AUTO 


```{c}
const auto cards = SmartCard::ReaderStatus::instance()->getCards();
```

#### AUTO 


```{c}
const auto tag = task->tag();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &newCard: newCards) {
                    const auto serialNumber = newCard->serialNumber();
                    const auto appName = newCard->appName();
                    const auto matchingOldCard = std::find_if(oldCards.cbegin(), oldCards.cend(),
                        [serialNumber, appName] (const std::shared_ptr<Card> &card) {
                            return card->serialNumber() == serialNumber && card->appName() == appName;
                        });
                    if (matchingOldCard == oldCards.cend()) {
                        qCDebug(KLEOPATRA_LOG) << "ReaderStatusThread: Card" << serialNumber << "with app" << appName << "was added";
                        Q_EMIT cardAdded(serialNumber, appName);
                    } else {
                        if (*newCard != **matchingOldCard) {
                            qCDebug(KLEOPATRA_LOG) << "ReaderStatusThread: Card" << serialNumber << "with app" << appName << "changed";
                            Q_EMIT cardChanged(serialNumber, appName);
                        }
                        oldCards.erase(matchingOldCard);
                    }
                    if (newCard->canLearnKeys()) {
                        anyLC = true;
                    }
                    if (newCard->hasNullPin() && firstCardWithNullPin.empty()) {
                        firstCardWithNullPin = newCard->serialNumber();
                    }
                    if (newCard->status() == Card::CardError) {
                        anyError = true;
                    }
                }
```

#### AUTO 


```{c}
auto filename = FileDialog::getSaveFileNameEx(
        parent,
        i18ncp("@title:window", "Export Certificate Group", "Export Certificate Groups", groups.size()),
        QStringLiteral("imp"),
        proposedFilename,
        i18nc("filename filter like Certificate Groups (*.foo)", "Certificate Groups (*%1)", certificateGroupFileExtension));
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
            auto cmd = new Kleo::Commands::RevokeCertificationCommand(userID);
            ui.userIDTable->setEnabled(false);
            connect(cmd, &Kleo::Commands::RevokeCertificationCommand::finished,
                    q, [this]() {
                ui.userIDTable->setEnabled(true);
                // Trigger an update when done
                q->setKey(key);
            });
            cmd->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { showMoreDetails(); }
```

#### AUTO 


```{c}
const auto newWindowSize = currentSize.expandedTo((currentSize + extent).boundedTo(maxWindowSize));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {accept();}
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return !key.canReallySign(); }
```

#### AUTO 


```{c}
const auto missingSignerKeyIds = Kleo::getMissingSignerKeyIds(key().userIDs());
```

#### AUTO 


```{c}
const auto progressCb = [this, scanning](int arg) { Q_EMIT progress(arg, 0, scanning); };
```

#### AUTO 


```{c}
auto item = ui.userIDTable->itemAt(p);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &info: card->keyInfos()) {
        const auto key = KeyCache::instance()->findSubkeyByKeyGrip(info.grip);
        if (key.isNull()) {
            auto cmd = new LearnCardKeysCommand(GpgME::CMS);
            cmd->setParentWidget(this);
            cmd->setShowsOutputWindow(false);
            qCDebug(KLEOPATRA_LOG) << "Did not find:" << info.grip.c_str() << "Starting gpgsm --learn.";
            cmd->start();
            connect(cmd, &Command::finished, this, [] () {
                qCDebug(KLEOPATRA_LOG) << "Learn command finished.";
            });
            return;
        }
    }
```

#### AUTO 


```{c}
const auto cis = cardInfos();
```

#### AUTO 


```{c}
auto l = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto chk = new QCheckBox (i18n("Show this notification for future updates."));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { showCertificateView(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::CreatedSignature &sig) {
                       return QString::fromLatin1(sig.hashAlgorithmAsString()).toLower();
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[this, gpgconf, profile] () {
        if (gpgconf->exitStatus() != QProcess::NormalExit) {
            KMessageBox::error(this, QStringLiteral("<pre>%1</pre>").arg(QString::fromLocal8Bit(gpgconf->readAll())));
            delete gpgconf;
            return;
        }
        delete gpgconf;
        KMessageBox::information(this,
                         i18nc("%1 is the name of the profile",
                               "The configuration profile \"%1\" was applied.", profile),
                         i18n("GnuPG Profile - Kleopatra"));
        auto config = QGpgME::cryptoConfig();
        if (config) {
            config->clear();
        }
    }
```

#### AUTO 


```{c}
const auto cmd = new LookupCertificatesCommand(nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateTechnicalParameters();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->setChanged(true); }
```

#### AUTO 


```{c}
const auto card = SmartCard::ReaderStatus::instance()->getCard<Card>(mSerial);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fpr: std::as_const(m_expandedKeys)) {
        const KeyListModelInterface *const km = keyListModel(*m_view);
        if (!km) {
            qCWarning(KLEOPATRA_LOG) << "invalid model";
            return;
        }
        const auto key = KeyCache::instance()->findByFingerprint(fpr.toLatin1().constData());
        if (key.isNull()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in cache";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        const auto idx = km->index(key);
        if (!idx.isValid()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in model";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        m_view->expand(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::Error &result, const QByteArray &keyData) {
        exportResult(result, keyData);
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout{q};
```

#### LAMBDA EXPRESSION 


```{c}
[this, workerThread, progress] {
            progress->accept();
            progress->deleteLater();
            genKeyDone(workerThread->error(), workerThread->bkpFile());
            delete workerThread;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                getCertificateDetails();
            }
```

#### AUTO 


```{c}
const auto input = Input::createFromFile(fName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &k : signers) {
            if (k.protocol() == GpgME::OpenPGP) {
                pgpSigners.push_back(k);
            } else {
                cmsSigners.push_back(k);
            }
        }
```

#### AUTO 


```{c}
auto defaultValueRequiredErrorMessage()
{
    return i18n("Error: Enter a value.");
}
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) { slotDoubleClicked(index); }
```

#### AUTO 


```{c}
auto *completeFilterModel = new KeyListSortFilterProxyModel(completer);
```

#### AUTO 


```{c}
auto cmd = new SetPIVCardApplicationAdministrationKeyCommand(mCardSerialNumber, this);
```

#### AUTO 


```{c}
auto const layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Protocol i: supportedProtocolsLst) {
        QLabel *const l = new QLabel;
        l->setText(formatLabel(i, Key()));
        layout->addWidget(l);
        m_labels[i] =  l;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](int classification) -> bool {
        return mayBeDetachedSignature(classification)
                || mayBeOpaqueSignature(classification)
                || (classification & Class::TypeMask) == Class::ClearsignedMessage;
    }
```

#### AUTO 


```{c}
const auto nullTitle = i18nc("NullPIN is a word that is used all over in the netkey "
                                 "documentation and should be understandable by Netkey cardholders",
                                 "The NullPIN is still active on this card.");
```

#### LAMBDA EXPRESSION 


```{c}
[&html](const QString &lbl, const QString &val) {
        html += QStringLiteral("<tr>"
                               "<th style=\"text-align: right; padding-right: 5px; white-space: nowrap;\">%1:</th>"
                               "<td style=\"white-space: nowrap;\">%2</td>"
                               "</tr>")
                    .arg(lbl, val);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r: results) {
        //when a new certificate got a secret key
        if (r.result.numSecretKeysImported() >= 1) {
            const char *fingerPr = r.result.imports()[0].fingerprint();
            GpgME::Error err;
            QScopedPointer<Context>
                ctx(Context::createForProtocol(GpgME::Protocol::OpenPGP));

            if (!ctx){
                qCWarning(KLEOPATRA_LOG) << "Failed to get context";
                continue;
            }

            const Key toTrustOwner = ctx->key(fingerPr, err , false);

            if (toTrustOwner.isNull()) {
                return;
            }

            QStringList uids;
            const auto toTrustOwnerUserIDs{toTrustOwner.userIDs()};
            uids.reserve(toTrustOwnerUserIDs.size());
            for (const UserID &uid : toTrustOwnerUserIDs) {
                uids << Formatting::prettyNameAndEMail(uid);
            }

            const QString str = xi18nc("@info",
                "<title>You have imported a Secret Key.</title>"
                "<para>The key has the fingerprint:<nl/>"
                "<numid>%1</numid>"
                "</para>"
                "<para>And claims the user IDs:"
                "<list><item>%2</item></list>"
                "</para>"
                "Is this your own key? (Set trust level to ultimate)",
                QString::fromUtf8(fingerPr),
                uids.join(QLatin1String("</item><item>")));

            int k = KMessageBox::questionYesNo(nullptr, str, i18nc("@title:window",
                                                               "Secret key imported"));

            if (k == KMessageBox::Yes) {
                //To use the ChangeOwnerTrustJob over
                //the CryptoBackendFactory
                const QGpgME::Protocol *const backend = QGpgME::openpgp();

                if (!backend){
                    qCWarning(KLEOPATRA_LOG) << "Failed to get CryptoBackend";
                    return;
                }

                ChangeOwnerTrustJob *const j = backend->changeOwnerTrustJob();
                j->start(toTrustOwner, Key::Ultimate);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) {
                                       return ! (key.protocol() == GpgME::CMS &&
                                                 !key.subkey(0).isNull() &&
                                                 key.subkey(0).canEncrypt() &&
                                                 key.subkey(0).isSecret() &&
                                                 !key.subkey(0).isCardKey());
                                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : addesses) {
            keyParameters.addEmail(email);
        }
```

#### AUTO 


```{c}
auto key = KeyCache::instance()->findByKeyIDOrFingerprint(w->keyID().toLatin1().constData());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { showTrustChainDialog(); }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto w) { w->setVisible(false); }
```

#### AUTO 


```{c}
auto transaction = std::unique_ptr<AssuanTransaction>(new WriteCertAssuanTransaction(certificateData));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &p) { userIDTableContextMenuRequested(p); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateSelectionLine &line : qAsConst(ui.recipients)) {
            line.showHide(proto, first, showAll, encrypt);
        }
```

#### AUTO 


```{c}
auto addButton = new QPushButton();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return !key.canEncrypt(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys)
        if (key.isRoot())
            if (key.userID(0).validity() == UserID::Ultimate) {
                trusted = true;
            } else {
                untrusted = true;
            }
        else {
            return Command::NoRestriction;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {checkWelcomePage();}
```

#### AUTO 


```{c}
auto genGrp = new QGroupBox(i18nc("@title", "General Operations"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : knownRecipients) {
            details += QLatin1String("<li>") + renderKey(key) + QLatin1String("</li>");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[q]() { Q_EMIT q->changed(true); }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto btn) {
                                  return btn && btn->isEnabled();
                              }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entryName: entries) {
                auto entry = grp->entry(entryName);
                if (!entry) {
                    qCWarning(KLEOPATRA_LOG) << "Failed to find entry:" << entry << "in group:"<< grp << "in component:" << compName;
                    return;
                }
                entry->resetToDefault();
            }
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Change PUK"));
```

#### AUTO 


```{c}
auto data = secKey.readAll();
```

#### AUTO 


```{c}
auto candidate = fi.baseName();
```

#### AUTO 


```{c}
const auto serialNumberAndApps = QByteArray::fromStdString(statusLine.second).split(' ');
```

#### LAMBDA EXPRESSION 


```{c}
[s](const QRegExp &rx) { return rx.exactMatch(s); }
```

#### AUTO 


```{c}
auto secKeyLay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto l = new QHBoxLayout{};
```

#### AUTO 


```{c}
const auto card = ReaderStatus::instance()->getCard<OpenPGPCard>(serialNumber());
```

#### AUTO 


```{c}
auto err = job->start({mailText}, /*secretOnly=*/false)
```

#### AUTO 


```{c}
const auto canceledIds = std::accumulate(std::cbegin(results), std::cend(results),
                                             std::set<QString>{},
                                             [](auto canceledIds, const auto &r) {
                                                 if (importWasCanceled(r)) {
                                                     canceledIds.insert(r.id);
                                                 }
                                                 return canceledIds;
                                             });
```

#### LAMBDA EXPRESSION 


```{c}
[](auto fingerprints, const auto &r) {
                               if (r.protocol == GpgME::OpenPGP) {
                                   fingerprints = accumulateNewKeys(fingerprints, r.result.imports());
                               }
                               return fingerprints;
                           }
```

#### AUTO 


```{c}
const auto dlg = new QProgressDialog(i18n("Loading certificates... (this can take a while)"),
            i18n("Show Details"), 0, 0, d->parentWidgetOrView());
```

#### AUTO 


```{c}
const auto emails = parameters.emails();
```

#### AUTO 


```{c}
const auto err = ctx->setFlag("ignore-mdc-error", "1");
```

#### AUTO 


```{c}
auto getGroupIndex(const KeyGroup &group)
    {
        QModelIndex index;
        if (const KeyListModelInterface *const klmi = dynamic_cast<KeyListModelInterface *>(ui.groupsList->model())) {
            index = klmi->index(group);
        }
        return index;
    }
```

#### AUTO 


```{c}
auto groupBoxGrid = new QGridLayout{groupBox};
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &t : qAsConst(tmp)) {
        q->connectTask(t);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (pair.first == "APPVERSION") {
            setAppVersion(parseAppVersion(pair.second));
        } else if (pair.first == "KEYPAIRINFO") {
            const KeyPairInfo info = KeyPairInfo::fromStatusLine(pair.second);
            if (info.grip.empty()) {
                qCWarning(KLEOPATRA_LOG) << "Invalid KEYPAIRINFO status line"
                        << QString::fromStdString(pair.second);
                setStatus(Card::CardError);
                continue;
            }
            mMetaInfo.insert("KEYPAIRINFO-" + info.keyRef, info.grip);
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### AUTO 


```{c}
auto headerView = new HeaderView(Qt::Horizontal);
```

#### AUTO 


```{c}
auto scrollArea = new ScrollArea{parent};
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &link) { d->smimeLinkActivated(link); }
```

#### AUTO 


```{c}
auto proc = new QProcess;
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { generateKey(PIVCard::keyManagementKeyRef()); }
```

#### AUTO 


```{c}
auto w = findChild<SubKeysWidget*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i: m_runnableTasks) {
        q->connectTask(i);
    }
```

#### AUTO 


```{c}
auto btn = bbox->addButton(QDialogButtonBox::Close);
```

#### AUTO 


```{c}
auto top = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            mGenerateBtn->setEnabled(true);
        }
```

#### AUTO 


```{c}
auto const menu = qobject_cast<QMenu *>(q->factory()->container(QStringLiteral("listview_popup"), q))
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            removeLastResultItem();
        }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout{emailGB};
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) { currentIndexChanged(index); }
```

#### AUTO 


```{c}
const auto key = ctx->key(result.fingerprint(), e, true);
```

#### AUTO 


```{c}
auto const hv = static_cast<HeaderView *>(m_view->header())
```

#### LAMBDA EXPRESSION 


```{c}
[this, userID]() {
        auto cmd = new Kleo::Commands::CertifyCertificateCommand(userID);
        ui.userIDTable->setEnabled(false);
        connect(cmd, &Kleo::Commands::CertifyCertificateCommand::finished,
                q, [this]() {
            ui.userIDTable->setEnabled(true);
            // Trigger an update when done
            q->setKey(key);
        });
        cmd->start();
    }
```

#### AUTO 


```{c}
auto cmd = new ChangePinCommand(mSerialNumber, NetKeyCard::AppName, this);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout{this};
```

#### AUTO 


```{c}
auto *vBox = new QVBoxLayout(q);
```

#### AUTO 


```{c}
const auto background = KColorScheme(QPalette::Active, KColorScheme::View).background(
                Kleo::gnupgIsDeVsCompliant() ? KColorScheme::PositiveBackground : KColorScheme::NegativeBackground
            ).color();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : qAsConst(groupList)) {
            const KConfigGroup kcg(config, group);
            if (!KCONFIG_DELETEGROUP_BROKEN || kcg.readEntry("magic", 0U) == 0xFA1AFE1U) {
                addView(kcg);
            }
        }
```

#### AUTO 


```{c}
const auto answer = KMessageBox::questionYesNo(
            q->topLevelWidget(),
            xi18nc("@info", "<para>The certificates or the certificate groups have been updated in the background.</para>"
                            "<para>Do you want to save your changes?</para>"),
            i18nc("@title::window", "Save changes?"),
            buttonYes, buttonNo);
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<SignEMailTask> &t : completed) {
            Q_EMIT q->reportMicAlg(t->micAlg());
            if (!Q) {
                return;
            }
        }
```

#### AUTO 


```{c}
const auto it = d->idToPage.find(id);
```

#### AUTO 


```{c}
auto cmd = new Commands::DetailsCommand(mKey, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int year, int month) {
                    // We select the ame day in the month when
                    // a page is switched.
                    auto date = ui.onCW->selectedDate();
                    if (!date.setDate(year, month, date.day())) {
                        date.setDate(year, month, 1);
                    }
                    ui.onCW->setSelectedDate(date);
                }
```

#### AUTO 


```{c}
auto requesterWithIcon = new FileNameRequesterWithIcon{
                kind == SignEncryptFilesWizard::Directory ? QDir::Dirs : QDir::Files, this};
```

#### AUTO 


```{c}
auto tv = dynamic_cast<QTreeView *> (view());
```

#### AUTO 


```{c}
auto drag = new QDrag(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &allKeys, const auto &group) {
                                                const auto keys = group.keys();
                                                allKeys.insert(std::begin(keys), std::end(keys));
                                                return allKeys;
                                           }
```

#### AUTO 


```{c}
auto label = new QLabel{infoText, parent};
```

#### LAMBDA EXPRESSION 


```{c}
[](const std::shared_ptr<Card> &ci) { return ci->hasNullPin(); }
```

#### AUTO 


```{c}
auto end = s.find(c, start);
```

#### LAMBDA EXPRESSION 


```{c}
[this, certSel]() { certificateSelectionRequested(certSel); }
```

#### AUTO 


```{c}
auto buttonNo = KStandardGuiItem::no();
```

#### LAMBDA EXPRESSION 


```{c}
[] (QItemSelection &selection, const QModelIndex &index) {
            if (index.isValid()) {
                selection.merge(QItemSelection(index, index), QItemSelectionModel::Select);
            }
            return selection;
        }
```

#### AUTO 


```{c}
auto algorithmLabel = new QLabel(i18n("Algorithm:"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (progressDialog) {
            progressDialog->accept();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, combo] () {
        applyProfile(combo->currentText());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
                Key key = mCompleter->completionModel()->data(index, KeyList::KeyRole).value<Key>();
                KeyGroup group = mCompleter->completionModel()->data(index, KeyList::GroupRole).value<KeyGroup>();
                if (!key.isNull()) {
                    setKey(key);
                } else if (!group.isNull()) {
                    setGroup(group);
                } else {
                    qCDebug(KLEOPATRA_LOG) << "Activated item is neither key nor group";
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[filter](const auto &key) {
                                 return filter->matches(key, KeyFilter::Filtering);
                             }
```

#### AUTO 


```{c}
auto statusBar = new QStatusBar;
```

#### AUTO 


```{c}
const auto it = std::remove_if(encryptionCertificates.begin(), encryptionCertificates.end(),
                                   [](const Key &key) {
                                       return ! (key.protocol() == GpgME::CMS &&
                                                 !key.subkey(0).isNull() &&
                                                 key.subkey(0).canEncrypt() &&
                                                 key.subkey(0).isSecret() &&
                                                 !key.subkey(0).isCardKey());
                                   });
```

#### AUTO 


```{c}
const auto result = writeKeyGroups(filename, groups);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &state: chvStatus) {
        const auto parsed = parse_pin_state (state);
        states.push_back(parsed);
        if (parsed == Card::NullPin) {
            ci->setHasNullPin(true);
        }
    }
```

#### AUTO 


```{c}
auto grp = KSharedConfig::openConfig()->group("KeyTreeView");
```

#### AUTO 


```{c}
auto ap = anchorProvider()
```

#### AUTO 


```{c}
auto accumulateTrustDomains(const std::vector<GpgME::UserID> &userIds)
{
    return std::accumulate(
        std::begin(userIds), std::end(userIds),
        std::set<QString>(),
        [] (auto domains, const auto &userID) {
            const auto newDomains = accumulateTrustDomains(userID.signatures());
            std::copy(std::begin(newDomains), std::end(newDomains), std::inserter(domains, std::end(domains)));
            return domains;
        }
    );
}
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWidget *old, QWidget *now) {
        Q_UNUSED(old);
        ensureWidgetVisible(now);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { generate(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
        const QStringList existing = m_listWidget->identifiers();
        QString rec = i18n("Recipient");
        while (existing.contains(rec)) {
            rec = i18nc("%1 == number", "Recipient (%1)", ++i);
        }
        addRecipient(rec, rec);
        const std::vector<Key> pgp = key.protocol() == OpenPGP ? std::vector<Key>(1, key) : std::vector<Key>();
        const std::vector<Key> cms = key.protocol() == CMS ? std::vector<Key>(1, key) : std::vector<Key>();
        m_listWidget->setCertificates(rec, pgp, cms);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int idx, int oldSize, int newSize) { _klhv_slotSectionResized(idx, oldSize, newSize); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {

        const QFileInfo fi(file);
        const QDir dir = fi.dir();
        const QStringList entries = remove_checksum_files(dir.entryList(QDir::Files), patterns);

        QStringList inputFiles;
        if (allowAddition) {
            inputFiles = entries;
        } else {
            const std::vector<File> parsed = parse_sum_file(fi.absoluteFilePath());
            QStringList oldInputFiles;
            oldInputFiles.reserve(parsed.size());
            std::transform(parsed.cbegin(), parsed.cend(), std::back_inserter(oldInputFiles),
                           std::mem_fn(&File::name));
            inputFiles = fs_intersect(oldInputFiles, entries);
        }

        const Dir item = {
            dir,
            fi.fileName(),
            inputFiles,
            aggregate_size(dir, inputFiles),
            filename2definition(fi.fileName(), checksumDefinitions)
        };

        dirs.push_back(item);

        if (progress) {
            progress(++i);
        }

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &recipient: decResult.recipients()) {
            if (!recipient.keyID()) {
                continue;
            }

            GpgME::Key key;
            if (strlen(recipient.keyID()) < 16) {
                key = KeyCache::instance()->findByShortKeyID(recipient.keyID());
            } else {
                key = KeyCache::instance()->findByKeyIDOrFingerprint(recipient.keyID());
            }

            if (key.isNull()) {
                std::vector<std::string> subids;
                subids.push_back(std::string(recipient.keyID()));
                for (const auto &subkey: KeyCache::instance()->findSubkeysByKeyID(subids)) {
                    key = subkey.parent();
                    break;
                }
            }

            if (key.isNull()) {
                qCDebug(KLEOPATRA_LOG) << "Unknown key" << recipient.keyID();
                mSigEncWidget->addUnknownRecipient(recipient.keyID());
                continue;
            }

            bool keyFound = false;
            for (const auto &existingKey: mSigEncWidget->recipients()) {
                if (existingKey.primaryFingerprint() && key.primaryFingerprint() &&
                    !strcmp (existingKey.primaryFingerprint(), key.primaryFingerprint())) {
                    keyFound = true;
                    break;
                }
            }
            if (!keyFound) {
                mSigEncWidget->addRecipient(key);
            }
        }
```

#### AUTO 


```{c}
const auto tagKeyFpr = TagsPreferences().tagKey();
```

#### AUTO 


```{c}
auto cmd = new DetailsCommand(key, nullptr);
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) {
                            return key.protocol() == GpgME::OpenPGP;
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[](State state) { return state == Acceptable; }
```

#### AUTO 


```{c}
const auto keys = mOutNames.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &t: coll->tasks()) {
        if (!qobject_cast<VerifyDetachedTask *>(t.get())) {
            hasOutputs = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &rawLine : std::as_const(trustListFileContents)) {

        const QString line = QString::fromLatin1(rawLine.data(), rawLine.size());
        if (!rx.exactMatch(line)) {
            qCDebug(KLEOPATRA_LOG) << "line \"" << rawLine.data() << "\" does not match";
            out.write(rawLine + '\n');
            continue;
        }
        const QString cap2 = rx.cap(2);
        if (cap2 != key && cap2 != keyColon) {
            qCDebug(KLEOPATRA_LOG) << qPrintable(key) << " != "
                                   << qPrintable(cap2) << " != "
                                   << qPrintable(keyColon);
            out.write(rawLine + '\n');
            continue;
        }
        found = true;
        const bool disabled = rx.cap(1) == QLatin1Char('!');
        const QByteArray flags = rx.cap(3).toLatin1();
        const QByteArray rests = rx.cap(4).toLatin1();
        if (trust == Key::Ultimate)
            if (!disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write(keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        else if (trust == Key::Never) {
            if (disabled) { // unchanged
                out.write(rawLine + '\n');
            } else {
                out.write('!' + keyColon.toLatin1() + ' ' + flags + rests + '\n');
            }
        }
        // else: trust == Key::Unknown
        // -> don't write - ie.erase
    }
```

#### AUTO 


```{c}
auto area = new QScrollArea;
```

#### AUTO 


```{c}
auto statusLbl = new QLabel(Formatting::deVsString());
```

#### AUTO 


```{c}
const auto servers = mWidget->keyservers();
```

#### AUTO 


```{c}
const auto colors = KColorScheme(QPalette::Active, KColorScheme::View);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { selfTest(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &group : selectedGroups) {
            const bool success = groupsModel->removeGroup(group);
            if (!success) {
                qCDebug(KLEOPATRA_LOG) << "Removing group from model failed:" << group;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->webOfTrustClicked(); }
```

#### AUTO 


```{c}
const auto remark = remarkList.join(QStringLiteral("; "));
```

#### AUTO 


```{c}
auto bbox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
const auto parsed = parse_pin_state (state);
```

#### LAMBDA EXPRESSION 


```{c}
[proto](const CertificateSelectionLine &l) {
                                            return l.isStillAmbiguous(proto);
                                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
                Key key = mCompleter->completionModel()->data(index, KeyList::KeyRole).value<Key>();
                auto group = mCompleter->completionModel()->data(index, KeyList::GroupRole).value<KeyGroup>();
                if (!key.isNull()) {
                    q->setKey(key);
                } else if (!group.isNull()) {
                    q->setGroup(group);
                } else {
                    qCDebug(KLEOPATRA_LOG) << "Activated item is neither key nor group";
                }
            }
```

#### AUTO 


```{c}
const auto klm = dynamic_cast<KeyListModelInterface *> (mTreeView->view()->model());
```

#### LAMBDA EXPRESSION 


```{c}
[this](QValidator *val) { addValidator(val); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { configureGroups(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateSelectionLine &line : std::as_const(ui.recipients)) {
            line.showHide(proto, first, showAll, encrypt);
        }
```

#### AUTO 


```{c}
auto labels = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto dir: srcDir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot)) {
        const QString srcName = src + QDir::separator() + dir;
        const QString destName = dest + QDir::separator() + dir;
        if (!recursivelyCopy(srcName, destName)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
const auto serialNumber = ReaderStatus::switchCard(assuanContext, mRealSerial, err);
```

#### AUTO 


```{c}
auto sel = KMessageBox::questionYesNo(d->parentWidgetOrView(), i18n("The file <b>%1</b> already exists.\n"
                                                  "Overwrite?", mOutputFileName),
                                                  i18n("Overwrite Existing File?"));
```

#### AUTO 


```{c}
auto const cmd = new ExportOpenPGPCertsToServerCommand(key());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // Trigger an update when done
        setKey(key());
        mFetchKeysBtn->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto grid = new QGridLayout;
```

#### AUTO 


```{c}
auto const top = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool checked) {
            mExpirationDateEdit->setEnabled(checked);
            Q_EMIT q->changed();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey : key.subkeys()) {
        auto item = new QTreeWidgetItem();
        item->setData(0, Qt::DisplayRole, Formatting::prettyID(subkey.keyID()));
        item->setData(0, Qt::UserRole, QVariant::fromValue(subkey));
        item->setData(1, Qt::DisplayRole, Kleo::Formatting::type(subkey));
        item->setData(2, Qt::DisplayRole, Kleo::Formatting::creationDateString(subkey));
        item->setData(3, Qt::DisplayRole, Kleo::Formatting::expirationDateString(subkey));
        item->setData(4, Qt::DisplayRole, Kleo::Formatting::validityShort(subkey));
        switch (subkey.publicKeyAlgorithm()) {
            case GpgME::Subkey::AlgoECDSA:
            case GpgME::Subkey::AlgoEDDSA:
            case GpgME::Subkey::AlgoECDH:
                item->setData(5, Qt::DisplayRole, QString::fromStdString(subkey.algoName()));
                break;
            default:
                item->setData(5, Qt::DisplayRole, QString::number(subkey.length()));
        }
        item->setData(6, Qt::DisplayRole, Kleo::Formatting::usageString(subkey));
        item->setData(7, Qt::DisplayRole, subkey.keyID() == key.keyID() ? QStringLiteral("?") : QString());
        d->ui.subkeysTree->addTopLevelItem(item);
    }
```

#### AUTO 


```{c}
const auto &group
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { writeCertificateToCard(PIVCard::digitalSignatureKeyRef()); }
```

#### LAMBDA EXPRESSION 


```{c}
[model](const QModelIndex &idx) {
                       return model->group(idx);
                   }
```

#### LAMBDA EXPRESSION 


```{c}
[lookUpBtn]() {
                    lookUpBtn->setEnabled(true);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            if (d->m_useKeyCache) {
                setKeys(d->m_secretOnly ? KeyCache::instance()->secretKeys() : KeyCache::instance()->keys());
            }
        }
```

#### AUTO 


```{c}
auto keys = cache->findSubkeysByKeyID(id);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {doChangePin(1);}
```

#### AUTO 


```{c}
const auto all = mTarget.userIDs();
```

#### AUTO 


```{c}
const auto displaySerialnumber = scd_getattr_status(gpg_agent, "$DISPSERIALNO", err);
```

#### AUTO 


```{c}
auto fsm = qobject_cast<QDirModel *>(proxy.sourceModel())
```

#### AUTO 


```{c}
const auto startOfManufacturerName = value.find(' ');
```

#### AUTO 


```{c}
auto encBox = new QGroupBox(i18nc("@title:group", "Encrypt"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::KeyListResult &result) { slotKeyListResult(result); }
```

#### AUTO 


```{c}
const auto newErrorMessage = errorMessage();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool checked) {
                ui->expiryDE->setEnabled(checked);
                if (checked && !ui->expiryDE->isValid()) {
                    setExpiryDate(defaultExpirationDate(OnUnlimitedValidity::ReturnInternalDefault));
                }
            }
```

#### AUTO 


```{c}
auto recipientsWidget = new QWidget;
```

#### AUTO 


```{c}
const auto cards = rs->getCards();
```

#### AUTO 


```{c}
const auto inpath = fi.absoluteFilePath();
```

#### AUTO 


```{c}
auto btnLay = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto margins = mainLayout->contentsMargins();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rx : rxs) {
        end = std::remove_if(l.begin(), end,
                             [rx](const QString &str) {
                                return rx.match(str).hasMatch();
                             });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                revert();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateSelectionLine &l : std::as_const(ui.signers))
            if (s == l.toolButton()) {
                dlg = create_signing_certificate_selection_dialog(q, proto, l.mailboxText());
                if (dlg->exec()) {
                    l.addAndSelectCertificate(dlg->selectedCertificate());
                }
                // ### switch to key.protocol(), in case proto == UnknownProtocol
                break;
            }
```

#### AUTO 


```{c}
const auto netKeyCard = ReaderStatus::instance()->getCard<NetKeyCard>(mSerialNumber);
```

#### LAMBDA EXPRESSION 


```{c}
[rx](const QString &str) {
                                return rx.match(str).hasMatch();
                             }
```

#### AUTO 


```{c}
auto action = coll->action(name)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: q->resolvedSigningKeys()) {
            if (!IS_DE_VS(key) || keyValidity(key) < GpgME::UserID::Validity::Full) {
                de_vs = false;
                break;
            }
        }
```

#### AUTO 


```{c}
auto certKeyLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto &[opt, fn]
```

#### AUTO 


```{c}
const auto keyRef = getKeyRef(suitableKeys, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, mailText](const KeyListResult &result, const std::vector<GpgME::Key> &keys) {
        onLocateJobResult(job, mailText, result, keys);
    }
```

#### AUTO 


```{c}
const auto sig
```

#### RANGE FOR STATEMENT 


```{c}
for (const KeyPairInfo &keyInfo : card->keyInfos()) {
        if (!keyInfo.grip.empty()) {
            Error err;
            const auto command = std::string("READKEY --card --no-data -- ") + keyInfo.keyRef;
            (void)Assuan::sendStatusLinesCommand(gpg_agent, command.c_str(), err);
            if (err) {
                qCWarning(KLEOPATRA_LOG) << "Running" << command << "failed:" << err;
            }
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction{parent};
```

#### AUTO 


```{c}
const auto serialNumber = gpgagent_status(gpgAgent, "SCD SERIALNO", err);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                        restartAtEnterDetailsPage();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[import, q] () {
                import->setEnabled(false);
                auto cmd = new Kleo::ImportCertificateFromFileCommand();
                connect(cmd, &Kleo::ImportCertificateFromFileCommand::finished,
                        q, [import, q]() {
                    import->setEnabled(true);
                });
                cmd->setParentWidget(q);
                cmd->start();
            }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(frame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto edit: std::as_const(mRecpWidgets)) {
        if (!edit->isEmpty() && edit->key().isNull() && edit->group().isNull()) {
            KMessageBox::error(this, i18nc("%1 is user input that could not be found",
                        "Could not find a key for '%1'", edit->text().toHtmlEscaped()),
                    i18n("Failed to find recipient"), KMessageBox::Notify);
            return false;
        }
    }
```

#### AUTO 


```{c}
const auto userID = item->data(0, Qt::UserRole).value<GpgME::UserID>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<SignEncryptTask> &i : tasks) {
            i->setOverwritePolicy(overwritePolicy);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
        result << QLatin1String(key.primaryFingerprint());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](State state) { return state == Invalid; }
```

#### AUTO 


```{c}
const auto groupKeys = std::accumulate(std::begin(groups), std::end(groups),
                                           KeyGroup::Keys{},
                                           [](auto &allKeys, const auto &group) {
                                                const auto keys = group.keys();
                                                allKeys.insert(std::begin(keys), std::end(keys));
                                                return allKeys;
                                           });
```

#### AUTO 


```{c}
auto apps = serialNumberAndApps.mid(1);
```

#### AUTO 


```{c}
auto action = actions.get(Actions::MoveRight)
```

#### AUTO 


```{c}
const auto wd = QDir(m_workDir->path());
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const GpgME::Key &) {
#ifdef GPGME_HAS_REMARKS
            updateTags();
#endif
        }
```

#### AUTO 


```{c}
auto cmd = new Kleo::Commands::CertifyCertificateCommand(userID);
```

#### AUTO 


```{c}
const auto proto = findProtocol(classification);
```

#### AUTO 


```{c}
auto buttonLayout = new QVBoxLayout{};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotBackupCertificate();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &i : groups) {
        const KConfigGroup group(m_config, i);
        const QByteArray id = group.readEntry("email", QByteArray());
        if (id.isEmpty()) {
            continue;
        }
        pgpPrefs.insert(id, group.readEntry("pgpCertificate", QByteArray()));
        cmsPrefs.insert(id, group.readEntry("cmsCertificate", QByteArray()));
    }
```

#### AUTO 


```{c}
const auto startOfManufacturerName = manufacturerIdAndName.find(' ');
```

#### AUTO 


```{c}
const auto &rx
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fn : qAsConst(d->files)) {
        QFile in(fn);
        if (!in.open(QIODevice::ReadOnly)) {
            d->error(i18n("Could not open file %1 for reading: %2", in.fileName(), in.errorString()), i18n("Certificate Import Failed"));
            d->importResult(ImportResult(), fn);
            continue;
        }
        const GpgME::Protocol protocol = findProtocol(fn);
        if (protocol == GpgME::UnknownProtocol) {   //TODO: might use exceptions here
            d->error(i18n("Could not determine certificate type of %1.", in.fileName()), i18n("Certificate Import Failed"));
            d->importResult(ImportResult(), fn);
            continue;
        }
        d->startImport(protocol, in.readAll(), fn);
    }
```

#### AUTO 


```{c}
auto baseLay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto it = std::find_if(std::begin(buttons), std::end(buttons), p);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
        /* We use a single shot timer here to ensure that the keysMayHaveChanged
         * handlers are all handled before we restore the expand state so that
         * the model is already populated. */
        QTimer::singleShot(0, [this] () { restoreExpandState(); });
    }
```

#### AUTO 


```{c}
auto item = new QListWidgetItem{d->categoriesLV};
```

#### AUTO 


```{c}
const auto ci = d->cardInfos();
```

#### RANGE FOR STATEMENT 


```{c}
for (const GpgME::Key &i : keys) {
        add_cert(*combo, i);
    }
```

#### AUTO 


```{c}
auto enableDisableSlot = [this]() {
            enableDisableActions();
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(KeyList::KeyRole).value<GpgME::Key>();
        if (key.isNull()) {
            return;
        }
        m_expandedKeys.removeAll(QString::fromLatin1(key.primaryFingerprint()));
        if (m_group.isValid()) {
            m_group.writeEntry("Expanded", m_expandedKeys);
        }
    }
```

#### AUTO 


```{c}
auto infoBtn = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for ( const Line &line : ui.lines ) {
            const QString attr = attributeFromKey(line.attr);
            const QString value = line.edit->text().trimmed();
            config.writeEntry(attr, value);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ArchiveDefinition> &ad : archiveDefinitions) {
        d->ui.archivesCB.addItem(ad->label(), qVariantFromValue(ad));
    }
```

#### AUTO 


```{c}
auto date = ui.onCW->selectedDate();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file: srcDir.entryList(QDir::Files)) {
        const QString srcName = src + QDir::separator() + file;
        const QString destName = dest + QDir::separator() + file;
        if(!QFile::copy(srcName, destName)) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto subKeyIndentation = new QSpacerItem(13, 13, QSizePolicy::Fixed, QSizePolicy::Minimum);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rawKey : attrOrder) {
                const QString key = rawKey.trimmed().toUpper();
                const QString attr = attributeFromKey(key);
                if (attr.isEmpty()) {
                    continue;
                }
                const QString preset = config.readEntry(attr);
                const bool required = key.endsWith(QLatin1Char('!'));
                const bool readonly = config.isEntryImmutable(attr);
                const QString label = config.readEntry(attr + QLatin1String("_label"),
                                                       attributeLabel(attr, true));
                const QString regex = config.readEntry(attr + QLatin1String("_regex"));

                int row;
                QValidator *validator = nullptr;
                if (attr == QLatin1String("EMAIL")) {
                    validator = regex.isEmpty() ? Validation::email() : Validation::email(QRegExp(regex));
                    row = row_index_of(emailLE, gridLayout);
                } else if (attr == QLatin1String("NAME")) {
                    validator = regex.isEmpty() ? Validation::pgpName() : Validation::pgpName(QRegExp(regex));
                    row = row_index_of(nameLE, gridLayout);
                } else if (attr == QLatin1String("COMMENT")) {
                    validator = regex.isEmpty() ? Validation::pgpComment() : Validation::pgpComment(QRegExp(regex));
                    row = row_index_of(commentLE, gridLayout);
                } else {
                    continue;
                }

                QLineEdit *le = adjust_row(gridLayout, row, label, preset, validator, readonly, required);

                const Line line = { key, label, regex, le };
                lines[row] = line;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for ( const QString &name : mainViewActionNames ) {
                if (auto action = coll->action(name)) {
                    action->setChecked(name == actionName);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { cancelCommands(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : checksumDefinitions) {
        if (cd) {
            const auto patterns = cd->patterns();
            for (const QString &pattern : patterns) {
                if (QRegExp(pattern, fs_cs).exactMatch(fileName)) {
                    return cd;
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto backend = (protocol == GpgME::OpenPGP ? QGpgME::openpgp() : QGpgME::smime())
```

#### AUTO 


```{c}
auto const explanationLayout = new QVBoxLayout(explanationFrame);
```

#### AUTO 


```{c}
auto keyIdLabel = new QLabel(mKeyID);
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateSelectionLine &line : qAsConst(ui.signers)) {
            line.showHide(proto, first, showAll, sign);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &idx) {
        const auto klm = dynamic_cast<KeyListModelInterface *> (mTreeView->view()->model());
        if (!klm) {
            qCDebug(KLEOPATRA_LOG) << "Unhandled Model: " << mTreeView->view()->model()->metaObject()->className();
        }
        auto cmd = new DetailsCommand(klm->key(idx), nullptr);
        cmd->setParentWidget(this);
        cmd->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&cFile](const CryptoFile &other) {
                                    return other.protocol == cFile.protocol
                                            && other.baseName == cFile.baseName;
                               }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: keyPairInfoLines) {
        if (pair.first == "KEYPAIRINFO") {
            const KeyPairInfo info = KeyPairInfo::fromStatusLine(pair.second);
            if (info.grip.empty()) {
                qCWarning(KLEOPATRA_LOG) << "Invalid KEYPAIRINFO status line"
                        << QString::fromStdString(pair.second);
                continue;
            }
            pivCard->setKeyAlgorithm(keyRef, info.algorithm);
        } else {
            qCWarning(KLEOPATRA_LOG) << "readKeyPairInfoFromPIVCard(): Unexpected status line on "
                    << QString::fromStdString(command) << ":" << QString::fromStdString(pair.first)
                    << QString::fromStdString(pair.second);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mailbox &mb : mbs) {
        recipients.push_back(Recipient(mb));
    }
```

#### AUTO 


```{c}
const auto &sender
```

#### AUTO 


```{c}
auto const labels = new QWidget;
```

#### AUTO 


```{c}
auto const item = new QListWidgetItem;
```

#### AUTO 


```{c}
auto bar = new QProgressBar;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key: keys) {
                        if (Kleo::keyValidity(key) < GpgME::UserID::Validity::Full) {
                            certifyButton->show();
                            return;
                        }
                    }
```

#### AUTO 


```{c}
auto p = parent()
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotOnDateChanged(); }
```

#### AUTO 


```{c}
auto groupsButtonLayout = new QVBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QModelIndex &index) {
        if (!index.isValid()) {
            return;
        }
        const auto &key = index.data(KeyList::KeyRole).value<GpgME::Key>();
        if (key.isNull()) {
            return;
        }
        const auto fpr = QString::fromLatin1(key.primaryFingerprint());

        if (m_expandedKeys.contains(fpr)) {
            return;
        }
        m_expandedKeys << fpr;
        m_group.writeEntry("Expanded", m_expandedKeys);
    }
```

#### AUTO 


```{c}
auto cmd = new ChangeExpiryCommand(subkey.parent());
```

#### AUTO 


```{c}
auto firstNotHidden = std::find_if(std::cbegin(mRequesters), std::cend(mRequesters),
                                               [](auto w) { return !w->isHidden(); });
```

#### AUTO 


```{c}
auto act = coll->action(QStringLiteral("manage_smartcard"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QPoint &p) { tableContextMenuRequested(p); }
```

#### AUTO 


```{c}
const auto &info
```

#### AUTO 


```{c}
auto generateButton = new QPushButton(i18n("Generate new Keys"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const File &file : files) {
            const bool isSameFileName = (QString::compare(file.name, fileName, fs_cs) == 0);
            qCDebug(KLEOPATRA_LOG) << "find_sums_by_input_files:        "
                                   << qPrintable(file.name) << " == "
                                   << qPrintable(fileName)  << " ? "
                                   << isSameFileName;
            if (isSameFileName) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto mailGrpLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto end = std::remove_if(result.begin(), result.end(),
                              [](const Key &key) { return key.hasSecret(); });
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) { return key.isExpired(); }
```

#### AUTO 


```{c}
const auto it = d->inputs.inquireData.find(what);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout{q};
```

#### AUTO 


```{c}
const auto regexp = config.readEntry(QLatin1String("EMAIL_regex"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const GpgME::KeyListResult &result) {
        d->keyListingDone(result);
    }
```

#### AUTO 


```{c}
const auto signature = certificationsModel.signature(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (CertificateLineEdit *edit: std::as_const(mRecpWidgets)) {
        const auto editKey = edit->key();
        if (key.isNull() && editKey.isNull()) {
            recpRemovalRequested(edit);
            return;
        }
        if (editKey.primaryFingerprint() &&
            key.primaryFingerprint() &&
            !strcmp(editKey.primaryFingerprint(), key.primaryFingerprint())) {
            recpRemovalRequested(edit);
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                         ui.changeExpirationBtn->setEnabled(true);
                     }
```

#### AUTO 


```{c}
auto action = menu->addAction(QIcon::fromTheme(QStringLiteral("send-to-symbolic")),
                                      i18n("Transfer to smartcard"),
                                      q, [this, subkey]() {
            auto cmd = new KeyToCardCommand(subkey);
            ui.subkeysTree->setEnabled(false);
            connect(cmd, &KeyToCardCommand::finished,
                    q, [this]() { ui.subkeysTree->setEnabled(true); });
            cmd->setParentWidget(q);
            cmd->start();
        });
```

#### AUTO 


```{c}
auto comboLay = new QGridLayout;
```

#### AUTO 


```{c}
const auto urisList{uris()};
```

#### LAMBDA EXPRESSION 


```{c}
[&str, &pos](const auto &val) {
                       return val->validate(str, pos);
                   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
            const KConfigGroup cGroup(config, group);
            const QString id = cGroup.readEntryUntranslated(QStringLiteral("id"));
            const QString name = cGroup.readEntry("Name");
            mArchiveDefinitionCB.widget()->addItem(name, QVariant(id));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair: infos) {
        qCDebug(KLEOPATRA_LOG) << pair.first.c_str() << ":" << pair.second.c_str();
        if (pair.first == "KEY-FPR" ||
            pair.first == "KEY-TIME") {
            // Key fpr and key time need to be distinguished, the number
            // of the key decides the usage.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[0];
            const auto fpr = values[1].toStdString();
            if (usage == "1") {
                mMetaInfo.insert(std::string("SIG") + pair.first, fpr);
            } else if (usage == "2") {
                mMetaInfo.insert(std::string("ENC") + pair.first, fpr);
            } else if (usage == "3") {
                mMetaInfo.insert(std::string("AUTH") + pair.first, fpr);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else if (pair.first == "KEYPAIRINFO") {
            // Fun, same as above but the other way around.
            const auto values = QString::fromStdString(pair.second).split(QLatin1Char(' '));
            if (values.size() < 2) {
                qCWarning(KLEOPATRA_LOG) << "Invalid entry.";
                setStatus(Card::CardError);
                continue;
            }
            const auto usage = values[1];
            const auto grip = values[0].toStdString();
            if (usage == "OPENPGP.1") {
                mMetaInfo.insert(std::string("SIG") + pair.first, grip);
            } else if (usage == "OPENPGP.2") {
                mMetaInfo.insert(std::string("ENC") + pair.first, grip);
            } else if (usage == "OPENPGP.3") {
                mMetaInfo.insert(std::string("AUTH") + pair.first, grip);
            } else {
                // Maybe more keyslots in the future?
                qCDebug(KLEOPATRA_LOG) << "Unhandled keyslot";
            }
        } else {
            mMetaInfo.insert(pair.first, pair.second);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) {
                                            return key.protocol() != GpgME::CMS;
                                         }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto w: mUnknownWidgets) {
        mRecpLayout->removeWidget(w);
        delete w;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &t : qAsConst(tmp)) {
        connectTask(t);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            updateResultLabel();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &card: suitableCards) {
        options.push_back(i18nc("smartcard application - serial number of smartcard", "%1 - %2",
            displayAppName(card->appName()), card->displaySerialNumber()));
    }
```

#### AUTO 


```{c}
const auto updatedGroupIndex = getGroupIndex(updatedGroup);
```

#### AUTO 


```{c}
const auto numProcessedCertificates = sum(res, &ImportResult::numConsidered);
```

#### AUTO 


```{c}
auto keyCache = KeyCache::mutableInstance();
```

#### AUTO 


```{c}
auto cmd = new AuthenticatePIVCardApplicationCommand(serialNumber, parentWidgetOrView());
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<Task> &i : d->m_tasks->tasks()) {    // create labels for all tags in collection
        Q_ASSERT(i && d->labelForTag(i->tag()));
        Q_UNUSED(i)
    }
```

#### AUTO 


```{c}
auto scrollAreaLayout = qobject_cast<QVBoxLayout *>(personalTab->widget()->layout());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Sender &s : std::as_const(senders)) {
            addSigner(s);
        }
```

#### AUTO 


```{c}
const auto appendRow = [&html, dn](const QString &lbl, const QString &attr) {
                                const QString val = dn[attr];
                                if (!val.isEmpty()) {
                                    html += QStringLiteral(
                                            "<tr><th style=\"text-align: left; white-space: nowrap\">%1:</th>"
                                                "<td style=\"white-space: nowrap\">%2</td>"
                                            "</tr>").arg(lbl, val);
                                }
                            };
```

#### AUTO 


```{c}
const auto descriptionLbl = new QLabel(QStringLiteral("<b>%1</b><br/>%2").arg(nullTitle).arg(nullDescription));
```

#### AUTO 


```{c}
auto cmd = new AuthenticatePIVCardApplicationCommand(serialNumber(), parentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fi: workdir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot)) {
            const auto inpath = fi.absoluteFilePath();

            if (fi.isDir()) {
                // A directory. Assume that the input was an archive
                // and avoid directory merges by trying to find a non
                // existing directory.
                auto candidate = fi.baseName();
                if (candidate.startsWith(QLatin1Char('-'))) {
                    // Bug in GpgTar Extracts stdout passed archives to a dir named -
                    candidate = QFileInfo(m_passedFiles.first()).baseName();
                }

                QString suffix;
                QFileInfo ofi;
                int i = 0;
                do {
                    ofi = QFileInfo(outDir.absoluteFilePath(candidate + suffix));
                    if (!ofi.exists()) {
                        break;
                    }
                    suffix = QStringLiteral("_%1").arg(++i);
                } while (i < 1000);

                if (!moveDir(inpath, ofi.absoluteFilePath())) {
                    reportError(makeGnuPGError(GPG_ERR_GENERAL),
                            xi18n("Failed to move <filename>%1</filename> to <filename>%2</filename>.",
                                  inpath, ofi.absoluteFilePath()));
                }
                continue;
            }
            const auto outpath = outDir.absoluteFilePath(fi.fileName());
            qCDebug(KLEOPATRA_LOG) << "Moving " << inpath << " to " << outpath;
            const QFileInfo ofi(outpath);
            if (ofi.exists()) {
                int sel = KMessageBox::No;
                if (!overWriteAll) {
                    sel = KMessageBox::questionYesNoCancel(m_dialog, i18n("The file <b>%1</b> already exists.\n"
                                                           "Overwrite?", outpath),
                                                           i18n("Overwrite Existing File?"),
                                                           KStandardGuiItem::overwrite(),
                                                           KGuiItem(i18n("Overwrite All")),
                                                           KStandardGuiItem::cancel());
                }
                if (sel == KMessageBox::Cancel) {
                    qCDebug(KLEOPATRA_LOG) << "Overwriting canceled for: " << outpath;
                    continue;
                }
                if (sel == KMessageBox::No) { //Overwrite All
                    overWriteAll = true;
                }
                if (!QFile::remove(outpath)) {
                    reportError(makeGnuPGError(GPG_ERR_GENERAL),
                                xi18n("Failed to delete <filename>%1</filename>.",
                                      outpath));
                    continue;
                }
            }
            if (!QFile::rename(inpath, outpath)) {
                reportError(makeGnuPGError(GPG_ERR_GENERAL),
                            xi18n("Failed to move <filename>%1</filename> to <filename>%2</filename>.",
                                  inpath, outpath));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { setAdminKey(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&str](const auto &val) {
        val->fixup(str);
    }
```

#### AUTO 


```{c}
auto cmd = new CreateCSRForCardKeyCommand(keyref, mCardSerialNumber, PIVCard::AppName, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &subkey : key.subkeys()) {
        auto item = new QTreeWidgetItem();
        item->setData(0, Qt::DisplayRole, QString::fromLatin1(subkey.keyID()));
        item->setData(1, Qt::DisplayRole, Kleo::Formatting::type(subkey));
        item->setData(2, Qt::DisplayRole, Kleo::Formatting::creationDateString(subkey));
        item->setData(3, Qt::DisplayRole, Kleo::Formatting::expirationDateString(subkey));
        item->setData(4, Qt::DisplayRole, Kleo::Formatting::validityShort(subkey));
        item->setData(5, Qt::DisplayRole, QString::number(subkey.length()));
        item->setData(6, Qt::DisplayRole, Kleo::Formatting::usageString(subkey));
        d->ui.subkeysTree->addTopLevelItem(item);
    }
```

#### AUTO 


```{c}
const auto data = in.readAll();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ad : actionData) {
        d->currentPageActions.insert(ad.name, make_action_from_data(ad, coll));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Key &key) { m_hierarchicalModel->removeKey(key); }
```

#### AUTO 


```{c}
const auto it = d->options.find(opt);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int err, const QString &details) { slotControllerError(err, details); }
```

#### AUTO 


```{c}
auto *const cmd = new ChecksumVerifyFilesCommand(verifyFiles, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotCertificationPrepared(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<ChecksumDefinition> &cd : cds) {
        mChecksumDefinitionCB->addItem(cd->label(), QVariant::fromValue(cd));
        if (cd == default_cd) {
            mChecksumDefinitionCB->setCurrentIndex(mChecksumDefinitionCB->count() - 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { onTextChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateLineEdit *w : qAsConst(mRecpWidgets)) {
        if (w->key().isNull()) {
            oneEmpty = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
        const KConfigGroup configGroup{config, group};
        const bool isCmsSpecificKeyFilter = !configGroup.readEntry("is-openpgp-key", true);
        auto item = new QListWidgetItem{d->categoriesLV};
        // hide CMS-specific filters if CMS is disabled; we hide those filters
        // instead of skipping them, so that they are not removed on save
        item->setHidden(isCmsSpecificKeyFilter && !Kleo::Settings{}.cmsEnabled());
        apply_config(configGroup, item);
    }
```

#### AUTO 


```{c}
const auto j = backend->quickJob();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &str) {
                                 return QRegExp(QLatin1String("^LANG=.*"), fs_cs).exactMatch(str);
                             }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::shared_ptr<const DecryptVerifyResult> &i : qAsConst(m_results)) {
            Q_EMIT q->verificationResult(i->verificationResult());
        }
```

#### AUTO 


```{c}
auto line = new QFrame();
```

#### LAMBDA EXPRESSION 


```{c}
[this, keyRef] () { writeCertificateToCard(keyRef); }
```

#### AUTO 


```{c}
auto cmd = new CertificateToPIVCardCommand(keyref, mCardSerialNumber);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : qAsConst(indexes)) {
        if (idx.isValid()) {
            sm->select(idx, QItemSelectionModel::Select | QItemSelectionModel::Rows);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : results) {
        const auto imports = r.result.imports();
        for (const Import &import : imports) {
            if (!import.fingerprint()) {
                continue;
            }
            fingerprints << QString::fromLatin1(import.fingerprint());
        }
    }
```

#### AUTO 


```{c}
const auto pivCard = ReaderStatus::instance()->getCard<PIVCard>(serialNumber());
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateSelectionLine &l : std::as_const(ui.recipients))
            if (s == l.toolButton()) {
                dlg = create_encryption_certificate_selection_dialog(q, proto, l.mailboxText());
                if (dlg->exec()) {
                    l.addAndSelectCertificate(dlg->selectedCertificate());
                }
                // ### switch to key.protocol(), in case proto == UnknownProtocol
                break;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QObject *obj) { slotDestroyed(obj); }
```

#### AUTO 


```{c}
const auto &subkey
```

#### AUTO 


```{c}
const auto dvTask = dynamic_cast<DecryptVerifyTask*>(m_result->parentTask().data());
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &r) { return r.id; }
```

#### AUTO 


```{c}
const auto currentSize = w->size();
```

#### AUTO 


```{c}
const auto urls = configEntry->urlValueList();
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout{q};
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
            doChangePin(NetKeyCard::sigGPinKeyRef());
        }
```

#### AUTO 


```{c}
auto changedSignal = &SMimeValidationConfigurationWidget::changed;
```

#### AUTO 


```{c}
auto ret = new QWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this, result] {
                showResult(result);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { listNotCertifiedKeys(); }
```

#### AUTO 


```{c}
const auto serialNumber = serialNumberAndApps[0];
```

#### AUTO 


```{c}
auto existingKey = pivCard->keyInfo(d->keyRef).grip;
```

#### AUTO 


```{c}
auto const entry = d->readerPortConfigEntry(config);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &fpr: qAsConst(m_expandedKeys)) {
        const KeyListModelInterface *km = dynamic_cast<const KeyListModelInterface*> (m_view->model());
        if (!km) {
            qCWarning(KLEOPATRA_LOG) << "invalid model";
            return;
        }
        const auto key = KeyCache::instance()->findByFingerprint(fpr.toLatin1().constData());
        if (key.isNull()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in cache";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        const auto idx = km->index(key);
        if (!idx.isValid()) {
            qCDebug(KLEOPATRA_LOG) << "Cannot find:" << fpr << "anymore in model";
            m_expandedKeys.removeAll(fpr);
            return;
        }
        m_view->expand(idx);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const KeyGroup &group) {
                if (!mGroup.isNull() && mGroup.source() == group.source() && mGroup.id() == group.id()) {
                    // queue the update to ensure that the model has been updated
                    QMetaObject::invokeMethod(this, &CertificateLineEdit::updateKey, Qt::QueuedConnection);
                }
            }
```

#### AUTO 


```{c}
const auto &app
```

#### AUTO 


```{c}
const auto keyserver = mOpenPGPKeyserverEdit.widget()->text().trimmed();
```

#### AUTO 


```{c}
const auto certificationKey = dialog->selectedCertificationKey();
```

#### AUTO 


```{c}
const auto &statusLine
```

#### AUTO 


```{c}
const auto resultSerialNumber = switchCard(assuanContext, serialNumber, err);
```

#### LAMBDA EXPRESSION 


```{c}
[this, subkey, card]() {
                    auto cmd = new Kleo::Commands::KeyToCardCommand(subkey, card->serialNumber());
                    ui.subkeysTree->setEnabled(false);
                    connect(cmd, &Kleo::Commands::KeyToCardCommand::finished,
                            q, [this]() { ui.subkeysTree->setEnabled(true); });
                    cmd->setParentWidget(q);
                    cmd->start();
                }
```

#### AUTO 


```{c}
auto dialog = new QDialog;
```

#### LAMBDA EXPRESSION 


```{c}
[](typename T_container::const_reference val) {
                           return val.prettyAddress();
                       }
```

#### AUTO 


```{c}
auto remarkLay = new QHBoxLayout;
```

#### AUTO 


```{c}
static const auto path = findGpgExe(GpgME::GpgEngine, QStringLiteral("gpg"));
```

#### AUTO 


```{c}
const auto key = keys().front();
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout{this};
```

#### LAMBDA EXPRESSION 


```{c}
[](const Key &key) { return !key.hasSecret(); }
```

#### AUTO 


```{c}
auto name = Formatting::prettyName(key);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { d->slotCloseCurrentTab(); }
```

#### AUTO 


```{c}
auto start = 0;
```

#### LAMBDA EXPRESSION 


```{c}
[this, certSel] () { dialogRequested(certSel); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotInUnitChanged(); }
```

#### AUTO 


```{c}
auto getGroups(const QModelIndexList &indexes)
    {
        std::vector<KeyGroup> groups;
        std::transform(std::begin(indexes), std::end(indexes),
                       std::back_inserter(groups),
                       [this](const auto &index) { return getGroup(index); });
        return groups;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto kind : icons.keys()) {
            auto requesterWithIcon = new FileNameRequesterWithIcon{
                kind == SignEncryptFilesWizard::Directory ? QDir::Dirs : QDir::Files, this};
            requesterWithIcon->setIcon(QIcon::fromTheme(icons[kind]));
            requesterWithIcon->setToolTip(toolTips[kind]);
            requesterWithIcon->requester()->setAccessibleNameOfLineEdit(accessibleNames[kind]);
            requesterWithIcon->setNameFilter(nameFilters[kind]);
            lay->addWidget(requesterWithIcon);

            connect(requesterWithIcon, &FileNameRequesterWithIcon::fileNameChanged, this,
                    [this, kind](const QString &newName) {
                        mOutNames[kind] = newName;
                    });

            mRequesters.insert(kind, requesterWithIcon);
        }
```

#### AUTO 


```{c}
auto existingKey = pivCard->keyGrip(d->keyRef);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &card: getCards()) {
            if (card->serialNumber() == serialNumber) {
                qCDebug(KLEOPATRA_LOG) << "ReaderStatus::getCard() - Found card with serial number" << QString::fromStdString(serialNumber);
                return std::dynamic_pointer_cast<T>(card);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool toggled) {
            Q_FOREACH (CertificateLineEdit *edit, mRecpWidgets) {
                edit->setEnabled(toggled);
            }
            updateOp();
        }
```

#### AUTO 


```{c}
auto pivCard = new PIVCard();
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto parent = widget ? widget->parentWidget() : nullptr;
```

#### AUTO 


```{c}
const auto &state
```

#### AUTO 


```{c}
const auto curWidget = ui.stackWidget->currentWidget();
```

#### AUTO 


```{c}
auto entry = getCryptoConfigEntry(conf, "dirmngr", "allow-version-check");
```

#### AUTO 


```{c}
const auto outLoc = outputLocation();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { generateKey(PIVCard::cardAuthenticationKeyRef()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : recipients) {
            details += QLatin1String("<li>") + renderKey(key) + QLatin1String("</li>");
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {finished();}
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const GpgME::Key &) {
#ifdef GPGME_HAS_REMARKS
            updateTags();
#endif
            checkOwnerTrust();
            Q_EMIT q->changed();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const std::string &serialNumber, const std::string &appName) { cardAddedOrChanged(serialNumber, appName); }
```

#### AUTO 


```{c}
auto encBoxLay = new QVBoxLayout;
```

#### AUTO 


```{c}
auto expanderAnimation = static_cast<QPropertyAnimation *>(toggleAnimation.animationAt(i));
```

#### AUTO 


```{c}
auto selectionModel = ui.groupsList->selectionModel();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Mailbox &mb : encryptToSelfRecipients) {
        const QString id = QLatin1String("sender-") + QString::number(++senders);
        d->m_listWidget->addEntry(id, i18n("Sender"), mb);
        const std::vector<Key> pgp = makeSuggestions(d->m_recipientPreferences, mb, OpenPGP);
        const std::vector<Key> cms = makeSuggestions(d->m_recipientPreferences, mb, CMS);
        pgpCount += !pgp.empty();
        cmsCount += !cms.empty();
        d->m_listWidget->setCertificates(id, pgp, cms);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir: srcDir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot)) {
        const QString srcName = src + QDir::separator() + dir;
        const QString destName = dest + QDir::separator() + dir;
        if (!recursivelyCopy(srcName, destName)) {
            return false;
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr static const char *CollapseAll = "window_collapse_all";
```

#### LAMBDA EXPRESSION 


```{c}
[this, job](const GpgME::Error &err, const QByteArray &keyData) {
                onExportJobResult(job, err, keyData);
            }
```

#### AUTO 


```{c}
const auto infoText = nameIsRequired || emailIsRequired
            ? i18n("Enter a name and an email address to use for the user ID.")
            : i18n("Enter a name and/or an email address to use for the user ID.");
```

#### AUTO 


```{c}
auto
    it = data.lower_bound(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemWidget *i : qAsConst(widgets)) {
        i->setProtocol(prot);
    }
```

#### AUTO 


```{c}
auto p15Card = new P15Card(*ci);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotSendCertificateByEMail();
    }
```

#### AUTO 


```{c}
auto it = in.options.begin(), end = in.options.end();
```

#### LAMBDA EXPRESSION 


```{c}
[](long ts) {
        QLocale l;
        return ts == 0 ? i18n("never") : l.toString(QDateTime::fromSecsSinceEpoch(ts), QLocale::ShortFormat);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImportResult &result : results) {
        //when a new certificate got a secret key
        if (result.numSecretKeysImported() >= 1) {
            const char *fingerPr = result.imports()[0].fingerprint();
            GpgME::Error err;
            QScopedPointer<Context>
                ctx(Context::createForProtocol(GpgME::Protocol::OpenPGP));

            if (!ctx){
                qCWarning(KLEOPATRA_LOG) << "Failed to get context";
                continue;
            }

            const Key toTrustOwner = ctx->key(fingerPr, err , false);

            if (toTrustOwner.isNull()) {
                return;
            }

            QStringList uids;
            uids.reserve(toTrustOwner.userIDs().size());
            Q_FOREACH (const UserID &uid, toTrustOwner.userIDs()) {
                uids << Formatting::prettyNameAndEMail(uid);
            }

            const QString str = xi18nc("@info",
                "<title>You have imported a Secret Key.</title>"
                "<para>The key has the fingerprint:<nl/>"
                "<numid>%1</numid>"
                "</para>"
                "<para>And claims the User IDs:"
                "<list><item>%2</item></list>"
                "</para>"
                "Is this your own key? (Set trust level to ultimate)",
                QString::fromUtf8(fingerPr),
                uids.join(QLatin1String("</item><item>")));

            int k = KMessageBox::questionYesNo(nullptr, str, i18nc("@title:window",
                                                               "Secret key imported"));

            if (k == KMessageBox::Yes) {
                //To use the ChangeOwnerTrustJob over
                //the CryptoBackendFactory
                const QGpgME::Protocol *const backend = QGpgME::openpgp();

                if (!backend){
                    qCWarning(KLEOPATRA_LOG) << "Failed to get CryptoBackend";
                    return;
                }

                ChangeOwnerTrustJob *const j = backend->changeOwnerTrustJob();
                j->start(toTrustOwner, Key::Ultimate);
            }
        }
    }
```

#### AUTO 


```{c}
const auto keyNumber = values[0];
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImportResult &result : results) {
        //when a new certificate got a secret key
        if (result.numSecretKeysImported() >= 1) {
            const char *fingerPr = result.imports()[0].fingerprint();
            GpgME::Error err;
            QScopedPointer<Context>
                ctx(Context::createForProtocol(GpgME::Protocol::OpenPGP));

            if (!ctx){
                qCWarning(KLEOPATRA_LOG) << "Failed to get context";
                continue;
            }

            const Key toTrustOwner = ctx->key(fingerPr, err , false);

            if (toTrustOwner.isNull()) {
                return;
            }

            QStringList uids;
            uids.reserve(toTrustOwner.userIDs().size());
            Q_FOREACH (const UserID &uid, toTrustOwner.userIDs()) {
                uids << Formatting::prettyNameAndEMail(uid);
            }

            const QString str = xi18nc("@info",
                "<title>You have imported a Secret Key.</title>"
                "<para>The key has the fingerprint:<nl/>"
                "<numid>%1</numid>"
                "</para>"
                "<para>And claims the User IDs:"
                "<list><item>%2</item></list>"
                "</para>"
                "Is this your own key? (Set trust level to ultimate)",
                QString::fromUtf8(fingerPr),
                uids.join(QStringLiteral("</item><item>")));

            int k = KMessageBox::questionYesNo(nullptr, str, i18nc("@title:window",
                                                               "Secret key imported"));

            if (k == KMessageBox::Yes) {
                //To use the ChangeOwnerTrustJob over
                //the CryptoBackendFactory
                const QGpgME::Protocol *const backend = QGpgME::openpgp();

                if (!backend){
                    qCWarning(KLEOPATRA_LOG) << "Failed to get CryptoBackend";
                    return;
                }

                ChangeOwnerTrustJob *const j = backend->changeOwnerTrustJob();
                j->start(toTrustOwner, Key::Ultimate);
            }
        }
    }
```

#### AUTO 


```{c}
const auto tagKeys = Tags::tagKeys();
```

#### LAMBDA EXPRESSION 


```{c}
[this] () {
                doEncryptSign();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CertificateSelectionLine &line : std::as_const(ui.signers)) {
            line.showHide(proto, first, showAll, sign);
        }
```

#### AUTO 


```{c}
auto cancelButton = buttonBox->button(QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto subLay1 = new QVBoxLayout;
```

#### AUTO 


```{c}
auto key = ctx->key(fpr, err, false);
```

#### AUTO 


```{c}
const auto sigInfo = card->keyInfo(card->signingKeyRef());
```

#### AUTO 


```{c}
const auto index = mFilterModel->index(0, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { restartDaemons(); }
```

#### AUTO 


```{c}
auto cmd = new ChangePinCommand(mRealSerial, this);
```

#### AUTO 


```{c}
const auto fprs = gpgagent_statuslines(gpg_agent, "SCD GETATTR KEY-FPR", err);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
        const QModelIndex mi = proxy.index(key);
        if (mi.isValid()) {
            result.merge(QItemSelection(mi, mi), QItemSelectionModel::Select);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &uid : uids) {
        auto item = new QTreeWidgetItem;
        const QString toolTip = tofuTooltipString(uid);
        item->setData(0, Qt::UserRole, QVariant::fromValue(uid));
        item->setData(0, Qt::DisplayRole, Kleo::Formatting::prettyEMail(uid));
        item->setData(0, Qt::ToolTipRole, toolTip);
        item->setData(1, Qt::DisplayRole, Kleo::Formatting::prettyName(uid));
        item->setData(1, Qt::ToolTipRole, toolTip);
        if (isOpenPGP) {
            QIcon trustIcon;
            switch (uid.validity()) {
            case GpgME::UserID::Unknown:
            case GpgME::UserID::Undefined:
                trustIcon = QIcon::fromTheme(QStringLiteral("emblem-question"));
                break;
            case GpgME::UserID::Never:
                trustIcon = QIcon::fromTheme(QStringLiteral("emblem-error"));
                break;
            case GpgME::UserID::Marginal:
                trustIcon = QIcon::fromTheme(QStringLiteral("emblem-warning"));
                break;
            case GpgME::UserID::Full:
            case GpgME::UserID::Ultimate:
                trustIcon = QIcon::fromTheme(QStringLiteral("emblem-success"));
                break;
            }
            item->setData(2, Qt::DecorationRole, trustIcon);
            item->setData(2, Qt::DisplayRole, Kleo::Formatting::validityShort(uid));
            item->setData(2, Qt::ToolTipRole, toolTip);

            ui.userIDTable->addTopLevelItem(item);

            if (canRevokeUID) {
                auto button = new QPushButton;
                button->setIcon(QIcon::fromTheme(QStringLiteral("entry-delete")));
                button->setToolTip(i18n("Revoke this User ID"));
                button->setMaximumWidth(32);
                QObject::connect(button, &QPushButton::clicked,
                                q, [this, uid]() { revokeUID(uid); });
                ui.userIDTable->setItemWidget(item, 4, button);
            }
        } else {
            ui.userIDTable->addTopLevelItem(item);
        }
    }
```

#### AUTO 


```{c}
const auto &file
```

#### AUTO 


```{c}
auto overView = Formatting::toolTip(key, Formatting::Fingerprint |
                                             Formatting::UserIDs |
                                             Formatting::Issuer |
                                             Formatting::Subject |
                                             Formatting::ExpiryDates |
                                             Formatting::CertificateType |
                                             Formatting::CertificateUsage);
```

#### AUTO 


```{c}
auto nextStepsGB = new QGroupBox{i18nc("@title:group", "Next Steps"), parent};
```

#### AUTO 


```{c}
const auto backend = (key.protocol() == GpgME::OpenPGP) ? QGpgME::openpgp() : QGpgME::smime();
```

#### AUTO 


```{c}
const auto w = widget();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            ui.userIDTable->setEnabled(true);
            updateKey();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &i : keys) {
        KConfigGroup group(m_config, QStringLiteral("EncryptionPreference_%1").arg(n++));
        group.writeEntry("email", i);
        const QByteArray pgp = pgpPrefs.value(i);
        if (!pgp.isEmpty()) {
            group.writeEntry("pgpCertificate", pgp);
        }
        const QByteArray cms = cmsPrefs.value(i);
        if (!cms.isEmpty()) {
            group.writeEntry("cmsCertificate", cms);
        }
    }
```

#### AUTO 


```{c}
const auto keyid = QLatin1String(sig.fingerprint());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
            if (isFirstItem) {
                certificateLineEdit->setKey(key);
                isFirstItem = false;
            } else {
                addRecipient(key);
            }
        }
```

#### AUTO 


```{c}
auto mainLay = new QVBoxLayout{q};
```

#### AUTO 


```{c}
auto getGroup(const QModelIndex &index)
    {
        return index.isValid() ? ui.groupsList->model()->data(index, KeyList::GroupRole).value<KeyGroup>() : KeyGroup{};
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool) { showPadView(); }
```

#### AUTO 


```{c}
const auto recipientKeys = recipients();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->keysMayHaveChanged(); }
```

#### AUTO 


```{c}
const auto &task
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { exportGroup(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Key &key : keys) {
        qCDebug(KLEOPATRA_LOG) << "found key " << key.userID(0).id();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { writeKeyToCard(PIVCard::keyManagementKeyRef()); }
```

#### AUTO 


```{c}
auto tabLayout = qobject_cast<QVBoxLayout *>(technicalTab->widget()->layout());
```

#### AUTO 


```{c}
const auto complianceMode = Formatting::complianceMode();
```

#### AUTO 


```{c}
auto const newEntry = configEntry(s_pgpservice_componentName, s_pgpservice_entryName,
                                          CryptoConfigEntry::ArgType_String, SingleValue, DoNotShowError);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { slotPageStringFilterChanged(text); }
```

#### LAMBDA EXPRESSION 


```{c}
[](const GpgME::Key &key) { return !key.canReallySign(); }
```

#### AUTO 


```{c}
auto buttonsLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto mainWidget = new QWidget{qq};
```

