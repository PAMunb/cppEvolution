#### RANGE FOR STATEMENT 


```{c}
for (KCubeWidget * cube : qAsConst(cubes)) {
      cube->updateColors();
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCubeWidget * cube : std::as_const(cubes)) {
      cube->reset();
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCubeWidget * cube : std::as_const(cubes)) {
      cube->updateColors();
   }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_game->showSettingsDialog(true); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KCubeWidget * cube : qAsConst(cubes)) {
      cube->reset();
   }
```

