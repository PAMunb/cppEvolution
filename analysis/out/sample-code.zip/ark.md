#### RANGE FOR STATEMENT 


```{c}
for (const QString &fullPath : std::as_const(expectedAddedFullPaths)) {
        QVERIFY(currentFullPaths.contains(fullPath));
    }
```

#### AUTO 


```{c}
auto extractionJob = archive->copyFiles(entriesToExtract, destDir.path(), extractionOptions);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& url : qAsConst(m_inputs)) {
        addExtraction(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : list) {

        // Find the topmost unselected parent. This is done by iterating up
        // through the directory hierarchy and see if each parent is included
        // in the selection OR if the parent is already part of list.
        // The latter is needed for unselected folders which are subfolders of
        // a selected parent folder.
        QModelIndex selectionRoot = index.parent();
        while (m_view->selectionModel()->isSelected(selectionRoot) ||
               list.contains(selectionRoot)) {
            selectionRoot = selectionRoot.parent();
        }

        // Fetch the root node for the unselected parent.
        const QString rootFileName = selectionRoot.isValid()
            ? m_model->entryForIndex(selectionRoot)->fullPath()
            : QString();


        // Append index with root node to fileList.
        QModelIndexList alist = QModelIndexList() << index;
        const auto filesIndexes = filesForIndexes(alist);
        for (Archive::Entry *entry : filesIndexes) {
            const QString fullPath = entry->fullPath();
            if (!fullPathsList.contains(fullPath)) {
                entry->rootNode = rootFileName;
                fileList.append(entry);
                fullPathsList.append(fullPath);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &value : array) {
        readWriteExecutables << value.toString();
    }
```

#### AUTO 


```{c}
auto createJob = Archive::create(m_filename, m_mimeType, m_entries, options, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(m_addSwitch)) {
        args << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : std::as_const(m_passedFiles)) {
        const QString oldPath = m_tempWorkingDir->path() + QLatin1Char('/') + file->fullPath(NoTrailingSlash);
        const QString newPath = m_tempAddDir->path() + QLatin1Char('/') + file->name();
        if (!QFile::rename(oldPath, newPath)) {
            return false;
        }
        m_tempAddedFiles << new Archive::Entry(nullptr, file->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : qAsConst(m_jobs)) {
        job->kill();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            if (statJob->error()) {
                KMessageBox::error(widget(), statJob->errorString());
                return;
            }

            const QString udsLocalPath = statJob->statResult().stringValue(KIO::UDSEntry::UDS_LOCAL_PATH);
            if (udsLocalPath.isEmpty()) { // The URL could not be resolved to a local path
                qCWarning(ARK) << "Ark cannot extract to non-local destination:" << localPath;
                KMessageBox::sorry(widget(), xi18nc("@info", "Ark can extract archives to local destinations only."));
                return;
            }

            doExtract(udsLocalPath);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto piece : pieces) {
        Archive::Entry *entry = parent->find(piece);
        if (!entry) {
            // Directory entry will be traversed later (that happens for some archive formats, 7z for instance).
            // We have to create one before, in order to construct tree from its children,
            // and then delete the existing one (see ArchiveModel::newEntry).
            entry = new Archive::Entry(parent);

            entry->setProperty("fullPath", (parent == m_rootEntry.data())
                                           ? QString(piece + QLatin1Char('/'))
                                           : QString(parent->fullPath(WithTrailingSlash) + piece + QLatin1Char('/')));
            entry->setProperty("isDirectory", true);
            insertEntry(entry, behaviour);
        }
        if (!entry->isDir()) {
            Archive::Entry *e = new Archive::Entry(parent);
            e->copyMetaData(entry);
            // Maybe we have both a file and a directory of the same name.
            // We avoid removing previous entries unless necessary.
            insertEntry(e, behaviour);
        }
        parent = entry;
    }
```

#### AUTO 


```{c}
auto encryptCheckBox = dialog->findChild<QCheckBox*>(QStringLiteral("encryptCheckBox"));
```

#### AUTO 


```{c}
const auto index = zip_name_locate(archive, entry.toUtf8().constData(), ZIP_FL_ENC_GUESS);
```

#### AUTO 


```{c}
auto statJob = KIO::stat(saveUrl, KIO::StatJob::DestinationSide, 0);
```

#### AUTO 


```{c}
auto job = Kerfuffle::Archive::batchExtract(url.toLocalFile(), destination, autoSubfolder(), preservePaths());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {

        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        // If entry is a directory, traverse and add all its files and subfolders.
        if (QFileInfo(e->fullPath()).isDir()) {

            if (!writeEntry(archive, e->fullPath(), destination, options, true)) {
                return false;
            }

            QDirIterator it(e->fullPath(),
                            QDir::AllEntries | QDir::Readable |
                            QDir::Hidden | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories);

            while (!QThread::currentThread()->isInterruptionRequested() && it.hasNext()) {
                const QString path = it.next();

                if (QFileInfo(path).isDir()) {
                    if (!writeEntry(archive, path, destination, options, true)) {
                        return false;
                    }
                } else {
                    if (!writeEntry(archive, path, destination, options)) {
                        return false;
                    }
                }
                i++;
            }
        } else {
            if (!writeEntry(archive, e->fullPath(), destination, options)) {
                return false;
            }
        }
        i++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : qAsConst(originalEntries)) {
        originalFullPaths.append(entry->fullPath());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : std::as_const(offers)) {
        archive = create(fileName, plugin, parent);
        // Use the first valid plugin, according to the priority sorting.
        if (archive->isValid()) {
            return archive;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QStringLiteral("kerfuffle_clizip")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### AUTO 


```{c}
const auto args = substituteAddVariables(m_param.value(AddArgs).toStringList(),
                                             files,
                                             workDir,
                                             password(),
                                             isHeaderEncryptionEnabled());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto e : *this)
            c.push_back(e);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
        const QMimeType mimeType = determineMimeType(url.path());
        if (m_pluginManager->preferredPluginsFor(mimeType).isEmpty()) {
            continue;
        }
        supportedUrls << url;
        // Check whether we can write in the parent directory of the file.
        const QString directory = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toLocalFile();
        if (!QFileInfo(directory).isWritable()) {
            readOnlyParentDir = true;
        }
    }
```

#### AUTO 


```{c}
const auto plugins = preferredPluginsFor(mimeType, false);
```

#### AUTO 


```{c}
auto addJob = archive()->addFiles(m_entries, new Archive::Entry(this), m_options);
```

#### AUTO 


```{c}
auto loadJob = Archive::load(archivePath, plugin);
```

#### AUTO 


```{c}
auto e = QSharedPointer<Archive::Entry>(new Archive::Entry());
```

#### AUTO 


```{c}
auto e = new Archive::Entry();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {

        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        const qlonglong index = zip_name_locate(archive.get(), fromUnixSeparator(e->fullPath()).toUtf8().constData(), ZIP_FL_ENC_GUESS);
        if (index == -1) {
            qCCritical(ARK) << "Could not find entry to delete:" << e->fullPath();
            Q_EMIT error(xi18n("Failed to delete entry: %1", e->fullPath()));
            return false;
        }
        if (zip_delete(archive.get(), index) == -1) {
            qCCritical(ARK) << "Could not delete entry" << e->fullPath() << ":" << zip_strerror(archive.get());
            Q_EMIT error(xi18n("Failed to delete entry: %1", QString::fromUtf8(zip_strerror(archive.get()))));
            return false;
        }
        Q_EMIT entryRemoved(e->fullPath());
        Q_EMIT progress(float(++i) / files.size());
    }
```

#### AUTO 


```{c}
const auto args = substituteAddVariables(m_param.value(AddArgs).toStringList(),
                                             files,
                                             password(),
                                             isHeaderEncryptionEnabled(),
                                             compLevel,
                                             volumeSize);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : std::as_const(currentEntries)) {
        currentFullPaths << entry->fullPath();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fileExtension, urls, name, parent, this]() {
        auto *addToArchiveJob = new AddToArchive(parent);
        addToArchiveJob->setChangeToFirstPath(true);
        for (const QUrl &url : urls) {
            addToArchiveJob->addInput(url);
        }
        if (!fileExtension.isEmpty()) {
            addToArchiveJob->setAutoFilenameSuffix(fileExtension);
        } else {
            if (!addToArchiveJob->showAddDialog()) {
                delete addToArchiveJob;
                return;
            }
        }
        addToArchiveJob->start();
        connect(addToArchiveJob, &KJob::finished, this, [this, addToArchiveJob](){
            if (addToArchiveJob->error() == 0) {
                KIO::highlightInFileManager({QUrl::fromLocalFile(addToArchiveJob->fileName())});
            } else if (!addToArchiveJob->errorString().isEmpty()) {
                #if KIO_VERSION >= QT_VERSION_CHECK(5, 82, 0)
                Q_EMIT error(addToArchiveJob->errorString());
                #endif
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : {0, 1}) {
        kcfg_disabledPlugins->resizeColumnToContents(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[mimeType](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("Kerfuffle/Plugin")) &&
               metaData.mimeTypes().contains(mimeType);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        if (!url.isLocalFile()) {
            Q_EMIT messageWidget(KMessageWidget::Error, i18n("You can only add local files to an archive."));
            return false;
        }
        paths << url.toLocalFile();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        label->setText(futureWatcher->result());
        futureWatcher->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *e : qAsConst(m_newMovedFiles)) {
            Q_EMIT entry(e);
        }
```

#### AUTO 


```{c}
auto extractJob = archive()->extractFiles({}, m_destination, options);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto plugin : installedPlugins) {
        const auto metaData = plugin->metaData();
        auto item = new QTreeWidgetItem(kcfg_disabledPlugins);
        item->setData(0, Qt::UserRole, QVariant::fromValue(plugin));
        item->setText(0, metaData.name());
        item->setText(1, metaData.description());
        item->setCheckState(0, plugin->isEnabled() ? Qt::Checked : Qt::Unchecked);
        if (!plugin->isEnabled()) {
            m_toBeDisabled << metaData.pluginId();
        }
        if (!plugin->hasRequiredExecutables()) {
            item->setDisabled(true);
            for (int i : {0, 1}) {
                item->setToolTip(i, i18n("The plugin cannot be used because one or more required executables are missing. Check your installation."));
            }
        }
    }
```

#### AUTO 


```{c}
const auto mimeName = mimeType.name();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(m_addSwitch)) {
        args << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& metaData : qAsConst(m_plugins)) {
        QVERIFY(metaData.serviceTypes().contains(QStringLiteral("Kerfuffle/Plugin")));
        QVERIFY(!metaData.mimeTypes().isEmpty());

        const QJsonObject json = metaData.rawData();
        QVERIFY(json.keys().contains(QStringLiteral("X-KDE-Priority")));
        QVERIFY(json.keys().contains(QStringLiteral("KPlugin")));

        if (json.keys().contains(QStringLiteral("X-KDE-Kerfuffle-ReadOnlyExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadOnlyExecutables")].isArray());
        }

        if (json.keys().contains(QStringLiteral("X-KDE-Kerfuffle-ReadWriteExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWriteExecutables")].isArray());

            // If there is a list of read-write executables, the plugin has to be read-write.
            QVERIFY(json.keys().contains(QStringLiteral("X-KDE-Kerfuffle-ReadWrite")));
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWrite")].toBool());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entry : std::as_const(targetEntries)) {
        QVERIFY(oldPaths.contains(entry->fullPath()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : entries) {
        if (entry->isDir()) {
            m_numberOfFolders++;
            uncompressedSize += traverseAndComputeDirSizes(entry);
        } else {
            m_numberOfFiles++;
            uncompressedSize += entry->property("size").toULongLong();
        }
    }
```

#### AUTO 


```{c}
const auto rightEntry = right.first;
```

#### AUTO 


```{c}
auto remainingJobs = static_cast<ulong>(m_initialJobCount - subjobs().size());
```

#### AUTO 


```{c}
const auto &entry
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPluginsById(QStringLiteral("kerfuffle"), QStringLiteral("kerfuffle_cliunarchiver"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : qAsConst(entriesWithoutChildren)) {
            if (entry->isDir() && m_destination->fullPath().startsWith(entry->fullPath())) {
                KMessageBox::error(widget(),
                                   i18n("Folders can't be moved into themselves."),
                                   i18n("Moving a folder into itself"));
                delete m_destination;
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(m_testSwitch)) {
        args << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : qAsConst(m_entries)) {
        totalCount++;
        if (QFileInfo(entry->fullPath()).isDir()) {
            QDirIterator it(entry->fullPath(), QDir::AllEntries | QDir::Readable | QDir::Hidden | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
            while (it.hasNext()) {
                it.next();
                totalCount++;
            }
        }
    }
```

#### AUTO 


```{c}
auto loadJob = Archive::load(QFINDTESTDATA("data/RDA-attributes.zip"), m_plugin, this);
```

#### AUTO 


```{c}
const auto args = substituteAddVariables(m_param.value(AddArgs).toStringList(),
                                             files,
                                             password(),
                                             isHeaderEncryptionEnabled(),
                                             compLevel);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto entry : archiveEntries) {
        if (entry->isDir()) {
            dirs++;
        } else {
            files++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &entry : jsonList) {
        const QVariantMap entryMap = entry.toMap();

        if (!entryMap.contains(QLatin1String("fullPath"))) {
            continue;
        }

        Kerfuffle::Archive::Entry *e = new Kerfuffle::Archive::Entry();

        QVariantMap::const_iterator entryIterator = entryMap.constBegin();
        for (; entryIterator != entryMap.constEnd(); ++entryIterator) {
            const QByteArray key = entryIterator.key().toUtf8();
            if (e->property(key.constData()).isValid()) {
                e->setProperty(key.constData(), entryIterator.value());
            } else {
                qDebug() << entryIterator.key() << "is not a valid entry key";
            }
        }

        const QString fullPath = entryMap[QStringLiteral("fullPath")].toString();
        archive[fullPath] = e;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *e : qAsConst(files)) {
        filesList << e->fullPath(NoTrailingSlash);
    }
```

#### AUTO 


```{c}
auto loadJob = load(fileName, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : fileExistsFileNameRegExp) {
            const QRegularExpression rxFileNamePattern(pattern);
            const QRegularExpressionMatch rxMatch = rxFileNamePattern.match(line);

            if (rxMatch.hasMatch()) {
                m_storedFileName = rxMatch.captured(1);
                qCWarning(ARK) << "Detected existing file:" << m_storedFileName;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto plugin : plugins) {
            QTest::newRow(QStringLiteral("%1 (%2, %3)").arg(testName, format, plugin->metaData().pluginId()).toUtf8().constData())
                << filename
                << plugin
                << targetEntries
                << destination
                << expectedNewPaths
                << numberOfEntries;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& node : qAsConst(nodesToDelete)) {
        Archive::Entry *rawEntry = static_cast<Archive::Entry*>(node.internalPointer());
        qCDebug(ARK) << "Delete with parent entries " << rawEntry->getParent()->entries() << " and row " << rawEntry->row();
        beginRemoveRows(parent(node), rawEntry->row(), rawEntry->row());
        m_entryIcons.remove(rawEntry->getParent()->entries().at(rawEntry->row())->fullPath(NoTrailingSlash));
        rawEntry->getParent()->removeEntryAt(rawEntry->row());
        endRemoveRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            addToArchiveJob->addInput(url);
        }
```

#### AUTO 


```{c}
const auto args = substituteDeleteVariables(deleteArgs,
                                                files,
                                                password());
```

#### AUTO 


```{c}
const auto readBytes = zip_fread(zipFile.get(), buf, 1000);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entry : std::as_const(targetEntries)) {
        QVERIFY(!newPaths.contains(entry->fullPath()));
    }
```

#### AUTO 


```{c}
const auto encryptionType = ArchiveFormat::fromMetadata(m_mimeType, m_metaData).encryptionType();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : std::as_const(originalEntries)) {
        originalFullPaths.append(entry->fullPath());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KService::Ptr service) {
        return service->desktopEntryName() == QLatin1String("oktetapart");
    }
```

#### AUTO 


```{c}
auto item = new QTreeWidgetItem(kcfg_disabledPlugins);
```

#### LAMBDA EXPRESSION 


```{c}
[urls,name, option, parent,this]() {
        auto *batchExtractJob = new BatchExtract(parent);
        batchExtractJob->setDestinationFolder(QFileInfo(urls.first().toLocalFile()).path());
        batchExtractJob->setOpenDestinationAfterExtraction(true);
        if (option == AutoSubfolder) {
            batchExtractJob->setAutoSubfolder(true);
        } else if (option == ShowDialog) {
            if (!batchExtractJob->showExtractDialog()) {
                delete batchExtractJob;
                return;
            }
        }
        for (const QUrl &url : urls) {
            batchExtractJob->addInput(url);
        }
        batchExtractJob->start();
        connect(batchExtractJob, &KJob::finished, this, [this, batchExtractJob](){
            if (!batchExtractJob->errorString().isEmpty()) {
                Q_EMIT error(batchExtractJob->errorString());
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        if (skippedDirPath.count() > 0 && entry.startsWith(skippedDirPath)) {
            continue;
        } else {
            skippedDirPath.clear();
        }

        while (!entry.startsWith(lastDirEntry->fullPath())) {
            lastDirEntry = lastDirEntry->getParent();
        }

        bool isDir = entry.right(1) == QLatin1String("/");
        const Archive::Entry *archiveEntry = lastDirEntry->find(entry.split(QLatin1Char('/'), QString::SkipEmptyParts).last());

        if (archiveEntry != nullptr) {
            if (archiveEntry->isDir() != isDir || !allowMerging) {
                if (isDir) {
                    skippedDirPath = lastDirEntry->fullPath();
                }

                if (!error) {
                    conflictingEntries.clear();
                    error = true;
                }
                conflictingEntries << archiveEntry;
            } else {
                if (isDir) {
                    lastDirEntry = archiveEntry;
                }
                else if (!error) {
                    conflictingEntries << archiveEntry;
                }
            }
        } else if (isDir) {
            skippedDirPath = entry;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QLatin1String("kerfuffle_clizip")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, batchExtractJob](){
            if (!batchExtractJob->errorString().isEmpty()) {
                Q_EMIT error(batchExtractJob->errorString());
            }
        }
```

#### AUTO 


```{c}
const auto moveArgs = m_param.value(MoveArgs).toStringList();
```

#### AUTO 


```{c}
const auto mimeTypes = plugin->metaData().mimeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entry : std::as_const(targetEntries)) {
        QVERIFY(newPaths.contains(entry->fullPath()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QStringLiteral("kerfuffle_cli7z")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### AUTO 


```{c}
const auto pieces = QStringTokenizer{folderPath, QLatin1Char('/'), Qt::SkipEmptyParts};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & extension : qAsConst(m_possibleExtensions)) {
        qCDebug(ARK) << extension;

        if (uncompressedName.endsWith(extension, Qt::CaseInsensitive)) {
            uncompressedName.chop(extension.size());
            return uncompressedName;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rx : std::as_const(m_testPassedPatterns)) {
        if (QRegularExpression(rx).match(line).hasMatch()) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        readStdout();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTemporaryDir *tmpDir : std::as_const(m_tmpExtractDirList)) {
        relPath.remove(tmpDir->path()); //Remove tmpDir.
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mimeType : mimeTypes) {
                cout << mimeType << '\n';
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : qAsConst(entriesToAdd)) {
        const QString fullPath = destinationPath + entry->fullPath();
        if (!originalFullPaths.contains(fullPath)) {
            expectedEntriesCount++;
            expectedAddedFullPaths << destinationPath + entry->fullPath();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entry : qAsConst(targetEntries)) {
        QVERIFY(oldPaths.contains(entry->fullPath()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : entries) {
        QListWidgetItem *item = new QListWidgetItem(icons.value(entry->fullPath(NoTrailingSlash)), entry->fullPath(NoTrailingSlash));
        m_entriesList.addItem(item);
    }
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->cliProperties()->extractArgs(archiveName, filesList, false, password);
```

#### AUTO 


```{c}
auto compressedArchiveSize = QFileInfo(filename()).size();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : formats) {
        const QString filename = QStringLiteral("%1.%2").arg(archiveName, format);
        const auto mime = QMimeDatabase().mimeTypeForFile(filename, QMimeDatabase::MatchExtension);

        const auto plugins = m_pluginManager.preferredWritePluginsFor(mime);
        for (const auto plugin : plugins) {
            QTest::newRow(QStringLiteral("%1 (%2, %3)").arg(testName, format, plugin->metaData().pluginId()).toUtf8().constData())
                << filename
                << plugin
                << targetEntries
                << destination
                << expectedNewPaths
                << numberOfEntries;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            if (job->error()) {
                return;
            }

            auto archive = qobject_cast<Kerfuffle::LoadJob*>(job)->archive();
            dialog->setSingleFolderArchive(archive->isSingleFolder());
            dialog->setSubfolder(archive->subfolderName());
        }
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->substituteListVariables(listArgs, QString());
```

#### AUTO 


```{c}
auto createJob = new CreateJob(archive, entries, options);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QUrl &url) {
        return url.isLocalFile();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {

        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        const qlonglong index = zip_name_locate(archive, fromUnixSeparator(e->fullPath()).toUtf8().constData(), ZIP_FL_ENC_GUESS);
        if (index == -1) {
            qCCritical(ARK) << "Could not find entry to delete:" << e->fullPath();
            Q_EMIT error(xi18n("Failed to delete entry: %1", e->fullPath()));
            return false;
        }
        if (zip_delete(archive, index) == -1) {
            qCCritical(ARK) << "Could not delete entry" << e->fullPath() << ":" << zip_strerror(archive);
            Q_EMIT error(xi18n("Failed to delete entry: %1", QString::fromUtf8(zip_strerror(archive))));
            return false;
        }
        Q_EMIT entryRemoved(e->fullPath());
        Q_EMIT progress(float(++i) / files.size());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kerfuffle::Archive::Entry *file : files) {
        const QString &fileName = file->fullPath();
        if (m_archive.contains(fileName)) {
            m_archive.remove(fileName);
            emit entryRemoved(fileName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            onFinished(ret);
        }
```

#### AUTO 


```{c}
const auto args = substituteListVariables(m_param.value(ListArgs).toStringList(), password());
```

#### AUTO 


```{c}
auto quitAction = KStandardAction::quit(this, &MainWindow::quit, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &entry : jsonList) {
        const QVariantMap entryMap = entry.toMap();

        if (!entryMap.contains(QStringLiteral("fullPath"))) {
            continue;
        }

        Kerfuffle::Archive::Entry *e = new Kerfuffle::Archive::Entry();

        QVariantMap::const_iterator entryIterator = entryMap.constBegin();
        for (; entryIterator != entryMap.constEnd(); ++entryIterator) {
            const QByteArray key = entryIterator.key().toUtf8();
            if (e->property(key.constData()).isValid()) {
                e->setProperty(key.constData(), entryIterator.value());
            } else {
                qDebug() << entryIterator.key() << "is not a valid entry key";
            }
        }

        const QString fullPath = entryMap[QStringLiteral("fullPath")].toString();
        archive[fullPath] = e;
    }
```

#### AUTO 


```{c}
const auto entry
```

#### AUTO 


```{c}
const auto index = zip_name_locate(archive, entry.toUtf8(), ZIP_FL_ENC_GUESS);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : paths) {
            const QString pluginPath = QStringLiteral("%1/kerfuffle/kerfuffle_libarchive.so").arg(path);
            if (QFileInfo::exists(pluginPath)) {
                return pluginPath;
            }
        }
```

#### AUTO 


```{c}
auto collapsibleCompression = dialog->optionsDialog->findChild<KCollapsibleGroupBox*>(QStringLiteral("collapsibleCompression"));
```

#### AUTO 


```{c}
auto readWriteInterface = qobject_cast<ReadWriteArchiveInterface*>(archiveInterface());
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        m_searchWidget->hide();
        m_searchLineEdit->clear();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : formats) {
        const QString filename = QStringLiteral("test.%1").arg(format);
        const auto mime = QMimeDatabase().mimeTypeForFile(filename, QMimeDatabase::MatchExtension);

        const auto plugins = m_pluginManager.preferredWritePluginsFor(mime);
        for (const auto plugin : plugins) {
            QTest::newRow(qPrintable(QStringLiteral("delete a single file (%1, %2)").arg(format, plugin->metaData().pluginId())))
                << filename
                << plugin
                << QVector<Archive::Entry*> { new Archive::Entry(this, QStringLiteral("dir1/a.txt")) }
                << 13u
                << 12u;

            QTest::newRow(qPrintable(QStringLiteral("delete multiple files (%1, %2)").arg(format, plugin->metaData().pluginId())))
                << filename
                << plugin
                << QVector<Archive::Entry*> {
                       new Archive::Entry(this, QStringLiteral("a.txt")),
                       new Archive::Entry(this, QStringLiteral("dir1/b.txt"))
                   }
                << 13u
                << 11u;
        }
    }
```

#### AUTO 


```{c}
const auto& mimeType
```

#### AUTO 


```{c}
const auto nofEntries = zip_get_num_entries(archive, 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : filesIndexes) {
            const QString fullPath = entry->fullPath();
            if (!fullPathsList.contains(fullPath)) {
                entry->rootNode = rootFileName;
                fileList.append(entry);
                fullPathsList.append(fullPath);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &expectedPath : qAsConst(expectedNewPaths)) {
        QVERIFY(!oldPaths.contains(expectedPath));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotOpenEntry(OpenFile); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& line : qAsConst(lines)) {
        if (!line.isEmpty() || (m_listEmptyLines && m_operationMode == List)) {
            if (!handleLine(QString::fromLocal8Bit(line))) {
                killProcess();
                return;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &i : selectedRows) {
        list.append(m_filterModel->mapToSource(i));
    }
```

#### AUTO 


```{c}
auto name = toUnixSeparator(QString::fromUtf8(statBuffer.name));
```

#### LAMBDA EXPRESSION 


```{c}
[this, optionsWidget](int result) {
        if (result == QDialog::Accepted) {
            m_compOptions = optionsWidget->commpressionOptions();
        }
        optionsDialog->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : entries) {
            args << file->fullPath(NoTrailingSlash) << destination->fullPath() + file->name();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : std::as_const(m_entries)) {
        totalCount++;
        if (QFileInfo(entry->fullPath()).isDir()) {
            QDirIterator it(entry->fullPath(), QDir::AllEntries | QDir::Readable | QDir::Hidden | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
            while (it.hasNext()) {
                it.next();
                totalCount++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fullPath : removedFullPaths) {
            emit entryRemoved(fullPath);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entryPath : qAsConst(entries)) {
        if (lastFolder.count() > 0 && entryPath.startsWith(lastFolder)) {
            // Replace last moved or copied folder path with destination path.
            int charsCount = entryPath.count() - lastFolder.count();
            if (entriesWithoutChildren != 1) {
                charsCount += nameLength;
            }
            newPath = destinationPath + entryPath.right(charsCount);
        } else {
            const QString name = entryPath.split(QLatin1Char('/'), Qt::SkipEmptyParts).last();
            if (entriesWithoutChildren != 1) {
                newPath = destinationPath + name;
                if (entryPath.right(1) == QLatin1String("/")) {
                    newPath += QLatin1Char('/');
                }
            } else {
                // If the mode is set to Move and there is only one passed file in the list,
                // we have to use destination as newPath.
                newPath = destinationPath;
            }
            if (entryPath.right(1) == QLatin1String("/")) {
                nameLength = name.count() + 1; // plus slash
                lastFolder = entryPath;
            } else {
                nameLength = 0;
                lastFolder = QString();
            }
        }
        paths << newPath;
    }
```

#### AUTO 


```{c}
const auto itemFlags = Qt::ItemIsEnabled | Qt::ItemIsSelectable | QAbstractItemModel::flags(index);
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->substituteListVariables(listArgs, password);
```

#### AUTO 


```{c}
const auto readBytes = zip_fread(zipFile, buf, 1000);
```

#### AUTO 


```{c}
const auto fileName = it->fileName();
```

#### AUTO 


```{c}
auto archive = qobject_cast<Kerfuffle::LoadJob*>(job)->archive();
```

#### AUTO 


```{c}
const auto returnCode = archive_write_header(m_archiveWriter.data(), entry);
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->cliProperties()->addArgs(archiveName, {}, password, false, compressionLevel, compressionMethod, QString(), 0);
```

#### AUTO 


```{c}
const auto formats = QStringList {
        QStringLiteral("7z"),
        QStringLiteral("rar"),
        QStringLiteral("tar.gz"),
        QStringLiteral("zip")
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {
            if (QThread::currentThread()->isInterruptionRequested()) {
                break;
            }
            if (!extractEntry(archive,
                              e->fullPath(),
                              e->rootNode,
                              destinationDirectory,
                              options.preservePaths(),
                              removeRootNode)) {
                qCDebug(ARK) << "Extraction failed";
                return false;
            }
            Q_EMIT progress(float(++i) / nofEntries);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& metaData : qAsConst(m_plugins)) {
        QVERIFY(metaData.serviceTypes().contains(QLatin1String("Kerfuffle/Plugin")));
        QVERIFY(!metaData.mimeTypes().isEmpty());

        const QJsonObject json = metaData.rawData();
        QVERIFY(json.keys().contains(QLatin1String("X-KDE-Priority")));
        QVERIFY(json.keys().contains(QLatin1String("KPlugin")));

        if (json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadOnlyExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadOnlyExecutables")].isArray());
        }

        if (json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadWriteExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWriteExecutables")].isArray());

            // If there is a list of read-write executables, the plugin has to be read-write.
            QVERIFY(json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadWrite")));
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWrite")].toBool());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {

        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        // If entry is a directory, traverse and add all its files and subfolders.
        if (QFileInfo(e->fullPath()).isDir()) {

            if (!writeEntry(archive.get(), e->fullPath(), destination, options, true)) {
                return false;
            }

            QDirIterator it(e->fullPath(),
                            QDir::AllEntries | QDir::Readable |
                            QDir::Hidden | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories);

            while (!QThread::currentThread()->isInterruptionRequested() && it.hasNext()) {
                const QString path = it.next();

                if (QFileInfo(path).isDir()) {
                    if (!writeEntry(archive.get(), path, destination, options, true)) {
                        return false;
                    }
                } else {
                    if (!writeEntry(archive.get(), path, destination, options)) {
                        return false;
                    }
                }
                i++;
            }
        } else {
            if (!writeEntry(archive.get(), e->fullPath(), destination, options)) {
                return false;
            }
        }
        i++;
    }
```

#### AUTO 


```{c}
auto extractionJob = archive->extractFiles({}, destDir.path());
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : qAsConst(sortedEntries)) {
        if (lastFolder.count() > 0 && entry->fullPath().startsWith(lastFolder)) {
            continue;
        }

        lastFolder = (entry->fullPath().right(1) == QLatin1String("/")) ? entry->fullPath() : QString();
        filteredEntries << entry;
    }
```

#### AUTO 


```{c}
const auto plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : std::as_const(m_plugins)) {
        if (plugin->isEnabled()) {
            enabledPlugins << plugin;
        }
    }
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->cliProperties()->extractArgs(archiveName, filesList, preservePaths, password);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : topLevelWidgets) {
        if (widget->isVisible()) {
            widget->close();
        }
    }
```

#### AUTO 


```{c}
const auto &path
```

#### AUTO 


```{c}
auto job = m_model->loadArchive(localFilePath(), fixedMimeType, m_model);
```

#### AUTO 


```{c}
const auto leftEntry = left.first;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mimeType : mimeTypes) {
        QMimeType mime(QMimeDatabase().mimeTypeForName(mimeType));
        map[mime.comment().toLower()] = mime.name();
    }
```

#### AUTO 


```{c}
auto arkPartIt = std::find_if(offers.begin(), offers.end(), [](KService::Ptr service) {
        return service->storageId() == QLatin1String("ark_part.desktop");
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : std::as_const(expectedNewPaths)) {
        QVERIFY(newPaths.contains(path));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &format : formats) {
        const QString filename = QFINDTESTDATA(QStringLiteral("data/test_permissions.%1").arg(format));
        const auto mime = QMimeDatabase().mimeTypeForFile(filename, QMimeDatabase::MatchExtension);
        const auto plugins = m_pluginManager.preferredWritePluginsFor(mime);
        for (const auto plugin : plugins) {
            QTest::newRow(QStringLiteral("test preserve 0755 permissions (%1, %2)").arg(format, plugin->metaData().pluginId()).toUtf8().constData())
                << filename
                << plugin
                << QStringLiteral("0755.sh")
                << 0755;
        }
    }
```

#### AUTO 


```{c}
auto dialog = new Kerfuffle::SettingsDialog(this, QStringLiteral("settings"), iface->config());
```

#### LAMBDA EXPRESSION 


```{c}
[this, addToArchiveJob]() {
            if (addToArchiveJob->error() != 0) {
                Q_EMIT error(addToArchiveJob->errorString());
            }
        }
```

#### AUTO 


```{c}
const auto formats = QStringList {
        QStringLiteral("7z"),
        QStringLiteral("rar"),
        QStringLiteral("tar.bz2"),
        QStringLiteral("zip")
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : std::as_const(entriesToAdd)) {
        const QString fullPath = destinationPath + entry->fullPath();
        if (!originalFullPaths.contains(fullPath)) {
            expectedEntriesCount++;
            expectedAddedFullPaths << destinationPath + entry->fullPath();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : qAsConst(m_supportedMimeTypes)) {
        m_ui->mimeComboBox->addItem(QMimeDatabase().mimeTypeForName(type).comment());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : entries) {
        filesList << file->fullPath(format);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QPair<Archive::Entry*, int> &left, const QPair<Archive::Entry*, int> &right) {
            const auto leftEntry = left.first;
            const auto rightEntry = right.first;
            bool isLessThan = false;  // Whether the left entry is less than the right entry.

            // #234373: sort folders before files.
            if ((leftEntry->isDir()) && (!rightEntry->isDir())) {
                isLessThan = true;
            } else if ((!leftEntry->isDir()) && (rightEntry->isDir())) {
                isLessThan = false;
            } else {
                const QVariant leftEntryMetaData = leftEntry->property(m_propertiesMap[column]);
                const QVariant rightEntryMetaData = rightEntry->property(m_propertiesMap[column]);

                switch (column) {
                case FullPath:
                    isLessThan = leftEntry->name() < rightEntry->name();
                    break;
                case Size:
                case CompressedSize:
                    isLessThan = leftEntryMetaData.toInt() < rightEntryMetaData.toInt();
                    break;
                default:
                    isLessThan = leftEntryMetaData.toString() < rightEntryMetaData.toString();
                    break;
                }
            }

            if (order == Qt::AscendingOrder) {
                return isLessThan;
            }
            // Descending order.
            return !isLessThan;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &value : array) {
            encryptionMethods.append(value.toString());
        }
```

#### AUTO 


```{c}
const auto& url
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            onFinished(false);
        }
```

#### AUTO 


```{c}
auto time = static_cast<uint>(archive_entry_mtime(aentry));
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPluginsById(QStringLiteral("kerfuffle"), QStringLiteral("kerfuffle_clirar"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : qAsConst(expectedNewPaths)) {
        QVERIFY(newPaths.contains(path));
    }
```

#### AUTO 


```{c}
auto encryptHeaderCheckBox = dialog->findChild<QCheckBox*>(QStringLiteral("encryptHeaderCheckBox"));
```

#### RANGE FOR STATEMENT 


```{c}
for (Kerfuffle::SettingsPage *page : pages) {
        dialog->addPage(page, page->name(), page->iconName());
        connect(dialog, &KConfigDialog::settingsChanged, page, &Kerfuffle::SettingsPage::slotSettingsChanged);
        connect(dialog, &Kerfuffle::SettingsDialog::defaultsButtonClicked, page, &Kerfuffle::SettingsPage::slotDefaultsButtonClicked);
    }
```

#### AUTO 


```{c}
const auto args = substituteMoveVariables(moveArgs, withoutChildren, destination, password());
```

#### AUTO 


```{c}
const auto archiveEntries = entries();
```

#### AUTO 


```{c}
auto e
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &expectedPath : std::as_const(expectedNewPaths)) {
        QVERIFY(!oldPaths.contains(expectedPath));
    }
```

#### AUTO 


```{c}
const auto args = substituteAddVariables(m_param.value(AddArgs).toStringList(),
                                             filesToPass,
                                             password(),
                                             isHeaderEncryptionEnabled(),
                                             options.compressionLevel(),
                                             options.volumeSize(),
                                             options.compressionMethod());
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("Kerfuffle/Plugin")) &&
               metaData.rawData()[QStringLiteral("X-KDE-Kerfuffle-ReadWrite")].toBool();
    }
```

#### AUTO 


```{c}
const auto urlList = fileItemInfos.urlList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entry : qAsConst(targetEntries)) {
        QVERIFY(newPaths.contains(entry->fullPath()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[urls,name, option, parent,this]() {
        auto *batchExtractJob = new BatchExtract(parent);
        batchExtractJob->setDestinationFolder(QFileInfo(urls.first().toLocalFile()).path());
        batchExtractJob->setOpenDestinationAfterExtraction(true);
        if (option == AutoSubfolder) {
            batchExtractJob->setAutoSubfolder(true);
        } else if (option == ShowDialog) {
            if (!batchExtractJob->showExtractDialog()) {
                delete batchExtractJob;
                return;
            }
        }
        for (const QUrl &url : urls) {
            batchExtractJob->addInput(url);
        }
        batchExtractJob->start();
        connect(batchExtractJob, &KJob::finished, this, [this, batchExtractJob](){
            if (!batchExtractJob->errorString().isEmpty()) {
                #if KIO_VERSION >= QT_VERSION_CHECK(5, 82, 0)
                Q_EMIT error(batchExtractJob->errorString());
                #endif
            }
        });
    }
```

#### AUTO 


```{c}
const auto pages = iface->settingsPages(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &row : qAsConst(m_cutIndexes)) {
        m_view->dataChanged(row, row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : qAsConst(map)) {
        sortedMimeTypes << value;
    }
```

#### AUTO 


```{c}
auto entryList = QVector<Archive::Entry*>::fromList(m_model->filesToCopy.values());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {
            if (QThread::currentThread()->isInterruptionRequested()) {
                break;
            }
            if (!extractEntry(archive.get(),
                              e->fullPath(),
                              e->rootNode,
                              destinationDirectory,
                              options.preservePaths(),
                              removeRootNode)) {
                qCDebug(ARK) << "Extraction failed";
                return false;
            }
            Q_EMIT progress(float(++i) / nofEntries);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[fileExtension, urls, name, parent, this]() {
        auto *addToArchiveJob = new AddToArchive(parent);
        addToArchiveJob->setImmediateProgressReporting(true);
        addToArchiveJob->setChangeToFirstPath(true);
        for (const QUrl &url : urls) {
            addToArchiveJob->addInput(url);
        }
        if (!fileExtension.isEmpty()) {
            addToArchiveJob->setAutoFilenameSuffix(fileExtension);
        } else {
            if (!addToArchiveJob->showAddDialog()) {
                delete addToArchiveJob;
                return;
            }
        }
        addToArchiveJob->start();
        connect(addToArchiveJob, &KJob::finished, this, [this, addToArchiveJob](){
            if (addToArchiveJob->error() == 0) {
                KIO::highlightInFileManager({QUrl::fromLocalFile(addToArchiveJob->fileName())});
            } else if (!addToArchiveJob->errorString().isEmpty()) {
                Q_EMIT error(addToArchiveJob->errorString());
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {
            if (QThread::currentThread()->isInterruptionRequested()) {
                break;
            }
            if (!extractEntry(archive,
                              e->fullPath(),
                              e->rootNode,
                              destinationDirectory,
                              options.preservePaths(),
                              removeRootNode)) {
                qCDebug(ARK) << "Extraction failed";
                return false;
            }
            emit progress(float(++i) / nofEntries);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &executable : executables) {
        if (executable.isEmpty()) {
            continue;
        }

        if (QStandardPaths::findExecutable(executable).isEmpty()) {
            return false;
        }
    }
```

#### AUTO 


```{c}
auto dlg = new QFileDialog(this, i18nc("to open an archive", "Open Archive"));
```

#### AUTO 


```{c}
const auto index = zip_name_locate(archive, fromUnixSeparator(entry).toUtf8().constData(), ZIP_FL_ENC_GUESS);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entryPath : qAsConst(entries)) {
        if (lastFolder.count() > 0 && entryPath.startsWith(lastFolder)) {
            // Replace last moved or copied folder path with destination path.
            int charsCount = entryPath.count() - lastFolder.count();
            if (entriesWithoutChildren != 1) {
                charsCount += nameLength;
            }
            newPath = destinationPath + entryPath.right(charsCount);
        } else {
            const QString name = entryPath.split(QLatin1Char('/'), QString::SkipEmptyParts).last();
            if (entriesWithoutChildren != 1) {
                newPath = destinationPath + name;
                if (entryPath.right(1) == QLatin1String("/")) {
                    newPath += QLatin1Char('/');
                }
            } else {
                // If the mode is set to Move and there is only one passed file in the list,
                // we have to use destination as newPath.
                newPath = destinationPath;
            }
            if (entryPath.right(1) == QLatin1String("/")) {
                nameLength = name.count() + 1; // plus slash
                lastFolder = entryPath;
            } else {
                nameLength = 0;
                lastFolder = QString();
            }
        }
        paths << newPath;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {

        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        const qlonglong index = zip_name_locate(archive, e->fullPath().toUtf8().constData(), ZIP_FL_ENC_GUESS);
        if (index == -1) {
            qCCritical(ARK) << "Could not find entry to delete:" << e->fullPath();
            emit error(xi18n("Failed to delete entry: %1", e->fullPath()));
            return false;
        }
        if (zip_delete(archive, index) == -1) {
            qCCritical(ARK) << "Could not delete entry" << e->fullPath() << ":" << zip_strerror(archive);
            emit error(xi18n("Failed to delete entry: %1", QString::fromUtf8(zip_strerror(archive))));
            return false;
        }
        emit entryRemoved(e->fullPath());
        emit progress(float(++i) / files.size());
    }
```

#### AUTO 


```{c}
const auto args = substituteAddVariables(m_param.value(AddArgs).toStringList(),
                                             filesToPass,
                                             password(),
                                             isHeaderEncryptionEnabled(),
                                             compLevel,
                                             volumeSize,
                                             compMethod);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto e : qAsConst(m_emittedEntries)) {
        // Entries might be passed to pending slots, so we just schedule their deletion.
        e->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.pluginId() == QLatin1String("arkpart") &&
               metaData.serviceTypes().contains(QLatin1String("KParts/ReadOnlyPart")) &&
               metaData.serviceTypes().contains(QLatin1String("Browser/View"));
    }
```

#### AUTO 


```{c}
const auto nofEntries = zip_get_num_entries(archive.get(), 0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : qAsConst(currentEntries)) {
        currentFullPaths << entry->fullPath();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&list](Archive::Entry* entry) { list << entry; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        if (!url.isLocalFile()) {
            emit messageWidget(KMessageWidget::Error, i18n("You can only add local files to an archive."));
            return false;
        }
        paths << url.toLocalFile();
    }
```

#### AUTO 


```{c}
const auto plugins = m_pluginManager.preferredWritePluginsFor(mime);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        if (tempList.contains(entry)) {
            return true;
        }
        tempList << entry;
    }
```

#### AUTO 


```{c}
auto replacedArgs = plugin->cliProperties()->addArgs(archiveName, {}, password, encryptHeader, compressionLevel, compressionMethod, QString(), volumeSize);
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        const auto mimeTypes = plugin->metaData().mimeTypes();
        for (const auto& mimeType : mimeTypes) {
            if (db.mimeTypeForName(mimeType).isValid()) {
                supported.insert(mimeType);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *file : files) {
            // The entries may have parent. We have to save and apply it to our new entry in order to prevent memory
            // leaks.
            if (preservedParent == nullptr) {
                preservedParent = file->parent();
            }

            const QString filePath = QDir::currentPath() + QLatin1Char('/') + file->fullPath(NoTrailingSlash);
            const QString newFilePath = absoluteDestinationPath + file->fullPath(NoTrailingSlash);
            if (QFile::link(filePath, newFilePath)) {
                qCDebug(ARK) << "Symlink's created:" << filePath << newFilePath;
            } else {
                qCDebug(ARK) << "Can't create symlink" << filePath << newFilePath;
                emit finished(false);
                return false;
            }
        }
```

#### AUTO 


```{c}
auto readBytes = archive_read_data(source, buff, sizeof(buff));
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : {0, 1}) {
                item->setToolTip(i, i18n("The plugin cannot be used because one or more required executables are missing. Check your installation."));
            }
```

#### AUTO 


```{c}
const auto deleteArgs = m_param.value(DeleteArgs).toStringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : std::as_const(m_entries)) {
            entry->setFullPath(stripDir.absoluteFilePath(entry->fullPath()));
        }
```

#### AUTO 


```{c}
auto loadJob = Archive::load(path, mimeType, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto plugin : plugins) {
            QTest::newRow(qPrintable(QStringLiteral("delete a single file (%1, %2)").arg(format, plugin->metaData().pluginId())))
                << filename
                << plugin
                << QVector<Archive::Entry*> { new Archive::Entry(this, QStringLiteral("dir1/a.txt")) }
                << 13u
                << 12u;

            QTest::newRow(qPrintable(QStringLiteral("delete multiple files (%1, %2)").arg(format, plugin->metaData().pluginId())))
                << filename
                << plugin
                << QVector<Archive::Entry*> {
                       new Archive::Entry(this, QStringLiteral("a.txt")),
                       new Archive::Entry(this, QStringLiteral("dir1/b.txt"))
                   }
                << 13u
                << 11u;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : qAsConst(m_entries)) {
            entry->setFullPath(stripDir.absoluteFilePath(entry->fullPath()));
        }
```

#### AUTO 


```{c}
const auto compressionMethods = m_model->archive()->property("compressionMethods").toStringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->isReadWrite()) {
            availableWritePlugins << plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QLatin1String("kerfuffle_cli7z")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](Plugin* p1, Plugin* p2) {
        return p1->priority() > p2->priority();
    }
```

#### AUTO 


```{c}
auto loadJob = Archive::load(archivePath, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto entry : qAsConst(targetEntries)) {
        QVERIFY(!newPaths.contains(entry->fullPath()));
    }
```

#### AUTO 


```{c}
const auto writeMimeTypes = m_pluginManager.supportedWriteMimeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QStringLiteral("kerfuffle_clirar")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&paths](Archive::Entry* entry) { paths << entry->fullPath(); }
```

#### AUTO 


```{c}
const auto plugins = availablePlugins();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &piece : qAsConst(pieces)) {
        Archive::Entry *entry = parent->find(piece);
        if (!entry) {
            // Directory entry will be traversed later (that happens for some archive formats, 7z for instance).
            // We have to create one before, in order to construct tree from its children,
            // and then delete the existing one (see ArchiveModel::newEntry).
            entry = new Archive::Entry(parent);

            entry->setProperty("fullPath", (parent == m_rootEntry.data())
                                           ? QString(piece + QLatin1Char('/'))
                                           : QString(parent->fullPath(WithTrailingSlash) + piece + QLatin1Char('/')));
            entry->setProperty("isDirectory", true);
            insertEntry(entry, behaviour);
        }
        if (!entry->isDir()) {
            Archive::Entry *e = new Archive::Entry(parent);
            e->copyMetaData(entry);
            // Maybe we have both a file and a directory of the same name.
            // We avoid removing previous entries unless necessary.
            insertEntry(e, behaviour);
        }
        parent = entry;
    }
```

#### AUTO 


```{c}
auto currentEntries = listEntries(iface);
```

#### AUTO 


```{c}
const auto reallyDelete =
        KMessageBox::questionYesNo(widget(),
                                   i18ncp("@info",
                                          "Deleting this file is not undoable. Are you sure you want to do this?",
                                          "Deleting these files is not undoable. Are you sure you want to do this?",
                                          selectionsCount),
                                   i18ncp("@title:window", "Delete File", "Delete Files", selectionsCount),
                                   KStandardGuiItem::del(),
                                   KStandardGuiItem::no(),
                                   QString(),
                                   KMessageBox::Dangerous | KMessageBox::Notify);
```

#### AUTO 


```{c}
const auto buttonCode = KMessageBox::warningYesNo(widget(),
                                                      xi18nc("@info",
                                                             "The archive <filename>%1</filename> already exists. Do you wish to overwrite it?",
                                                             targetInfo.fileName()),
                                                      i18nc("@title:window", "File Exists"),
                                                      KStandardGuiItem::overwrite(),
                                                      KStandardGuiItem::cancel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : qAsConst(entryMap)) {
        if (lastFolder.count() > 0 && entry->fullPath().startsWith(lastFolder)) {
            // Replace last moved or copied folder path with destination path.
            int charsCount = entry->fullPath().count() - lastFolder.count();
            if (entriesWithoutChildren > 1) {
                charsCount += nameLength;
            }
            newPath = destination->fullPath() + entry->fullPath().right(charsCount);
        } else {
            if (entriesWithoutChildren > 1) {
                newPath = destination->fullPath() + entry->name();
            } else {
                // If there is only one passed file in the list,
                // we have to use destination as newPath.
                newPath = destination->fullPath(NoTrailingSlash);
            }
            if (entry->isDir()) {
                newPath += QLatin1Char('/');
                nameLength = entry->name().count() + 1; // plus slash
                lastFolder = entry->fullPath();
            } else {
                nameLength = 0;
                lastFolder = QString();
            }
        }
        Archive::Entry *newEntry = new Archive::Entry(nullptr);
        newEntry->copyMetaData(entry);
        newEntry->setFullPath(newPath);
        m_newMovedFiles << newEntry;
    }
```

#### AUTO 


```{c}
const auto args = substituteTestVariables(m_param.value(TestArgs).toStringList());
```

#### AUTO 


```{c}
auto future = QtConcurrent::run(&PropertiesDialog::calcHash, this, algorithm, fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : qAsConst(m_plugins)) {
        if (plugin->isEnabled()) {
            enabledPlugins << plugin;
        }
    }
```

#### AUTO 


```{c}
auto compLevelSlider = dialog->optionsDialog->findChild<QSlider*>(QStringLiteral("compLevelSlider"));
```

#### AUTO 


```{c}
const auto size = receivedEntry->property("size").toULongLong();
```

#### LAMBDA EXPRESSION 


```{c}
[fileExtension, urls, name, parent, this]() {
        auto *addToArchiveJob = new AddToArchive(parent);
        addToArchiveJob->setChangeToFirstPath(true);
        for (const QUrl &url : urls) {
            addToArchiveJob->addInput(url);
        }
        if (!fileExtension.isEmpty()) {
            addToArchiveJob->setAutoFilenameSuffix(fileExtension);
        } else {
            if (!addToArchiveJob->showAddDialog()) {
                delete addToArchiveJob;
                return;
            }
        }
        addToArchiveJob->start();
        connect(addToArchiveJob, &KJob::finished, this, [this, addToArchiveJob]() {
            if (addToArchiveJob->error() != 0) {
                Q_EMIT error(addToArchiveJob->errorString());
            }
        });
    }
```

#### AUTO 


```{c}
const auto entries = dir->entries();
```

#### LAMBDA EXPRESSION 


```{c}
[](KService::Ptr service) {
        return service->storageId() == QLatin1String("ark_part.desktop");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[exec, urls, parent]() {
        KRun::run(exec, urls, parent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mime : mimeTypes) {
        if (mimeType.name() != mime) {
            continue;
        }

        const QJsonObject formatProps = json[mime].toObject();

        int minCompLevel = formatProps[QStringLiteral("CompressionLevelMin")].toInt();
        int maxCompLevel = formatProps[QStringLiteral("CompressionLevelMax")].toInt();
        int defaultCompLevel = formatProps[QStringLiteral("CompressionLevelDefault")].toInt();

        bool supportsWriteComment = formatProps[QStringLiteral("SupportsWriteComment")].toBool();
        bool supportsTesting = formatProps[QStringLiteral("SupportsTesting")].toBool();
        bool supportsMultiVolume = formatProps[QStringLiteral("SupportsMultiVolume")].toBool();

        QVariantMap compressionMethods = formatProps[QStringLiteral("CompressionMethods")].toObject().toVariantMap();
        QString defaultCompMethod = formatProps[QStringLiteral("CompressionMethodDefault")].toString();

        // We use a QStringList instead of QVariantMap for encryption methods, to
        // allow arbitrary ordering of the items.
        QStringList encryptionMethods;
        const QJsonArray array = formatProps[QStringLiteral("EncryptionMethods")].toArray();
        for (const QJsonValue &value : array) {
            encryptionMethods.append(value.toString());
        }
        QString defaultEncMethod = formatProps[QStringLiteral("EncryptionMethodDefault")].toString();

        Archive::EncryptionType encType = Archive::Unencrypted;
        if (formatProps[QStringLiteral("HeaderEncryption")].toBool()) {
            encType = Archive::HeaderEncrypted;
        } else if (formatProps[QStringLiteral("Encryption")].toBool()) {
            encType = Archive::Encrypted;
        }

        return ArchiveFormat(mimeType,
                             encType,
                             minCompLevel,
                             maxCompLevel,
                             defaultCompLevel,
                             supportsWriteComment,
                             supportsTesting,
                             supportsMultiVolume,
                             compressionMethods,
                             defaultCompMethod,
                             encryptionMethods,
                             defaultEncMethod);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        paths << url.toLocalFile();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : qAsConst(m_passedFiles)) {
        const QString oldPath = m_tempWorkingDir->path() + QLatin1Char('/') + file->fullPath(NoTrailingSlash);
        const QString newPath = m_tempAddDir->path() + QLatin1Char('/') + file->name();
        if (!QFile::rename(oldPath, newPath)) {
            return false;
        }
        m_tempAddedFiles << new Archive::Entry(nullptr, file->name());
    }
```

#### AUTO 


```{c}
const auto ns = QtPrivate::Tok::size(m_needle);
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->cliProperties()->listArgs(archiveName, QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
        if (!url.isLocalFile()) {
            continue;
        }
        const QMimeType mimeType = determineMimeType(url.toLocalFile());
        if (m_pluginManager->preferredPluginsFor(mimeType).isEmpty()) {
            continue;
        }
        supportedUrls << url;
        // Check whether we can write in the parent directory of the file.
        if (!readOnlyParentDir) {
            const QString directory = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toLocalFile();
            if (!QFileInfo(directory).isWritable()) {
                readOnlyParentDir = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : qAsConst(m_entries)) {
        // #191821: workDir must be used instead of QDir::current()
        //          so that symlinks aren't resolved automatically
        const QString &fullPath = entry->fullPath();
        QString relativePath = workDir.relativeFilePath(fullPath);

        if (fullPath.endsWith(QLatin1Char('/'))) {
            relativePath += QLatin1Char('/');
        }

        entry->setFullPath(relativePath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, addToArchiveJob](){
            if (addToArchiveJob->error() == 0) {
                KIO::highlightInFileManager({QUrl::fromLocalFile(addToArchiveJob->fileName())});
            } else if (!addToArchiveJob->errorString().isEmpty()) {
                Q_EMIT error(addToArchiveJob->errorString());
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotOpenEntry(OpenFileWith); }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            if (job->error()) {
                return;
            }

            auto archive = qobject_cast<Kerfuffle::LoadJob*>(job)->archive();
            dialog->setExtractToSubfolder(archive->hasMultipleTopLevelEntries());
            dialog->setSubfolder(archive->subfolderName());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& metaData : std::as_const(m_plugins)) {
        QVERIFY(!metaData.mimeTypes().isEmpty());

        const QJsonObject json = metaData.rawData();
        QVERIFY(json.keys().contains(QLatin1String("X-KDE-Priority")));
        QVERIFY(json.keys().contains(QLatin1String("KPlugin")));

        if (json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadOnlyExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadOnlyExecutables")].isArray());
        }

        if (json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadWriteExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWriteExecutables")].isArray());

            // If there is a list of read-write executables, the plugin has to be read-write.
            QVERIFY(json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadWrite")));
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWrite")].toBool());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entryPath : std::as_const(entries)) {
        if (lastFolder.count() > 0 && entryPath.startsWith(lastFolder)) {
            // Replace last moved or copied folder path with destination path.
            int charsCount = entryPath.count() - lastFolder.count();
            if (entriesWithoutChildren != 1) {
                charsCount += nameLength;
            }
            newPath = destinationPath + entryPath.right(charsCount);
        } else {
            const QString name = entryPath.split(QLatin1Char('/'), Qt::SkipEmptyParts).last();
            if (entriesWithoutChildren != 1) {
                newPath = destinationPath + name;
                if (entryPath.right(1) == QLatin1String("/")) {
                    newPath += QLatin1Char('/');
                }
            } else {
                // If the mode is set to Move and there is only one passed file in the list,
                // we have to use destination as newPath.
                newPath = destinationPath;
            }
            if (entryPath.right(1) == QLatin1String("/")) {
                nameLength = name.count() + 1; // plus slash
                lastFolder = entryPath;
            } else {
                nameLength = 0;
                lastFolder = QString();
            }
        }
        paths << newPath;
    }
```

#### AUTO 


```{c}
auto jobPart = static_cast<ulong>(100 / m_initialJobCount);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entryPath : qAsConst(entries)) {
        if (lastFolder.count() > 0 && entryPath.startsWith(lastFolder)) {
            // Replace last moved or copied folder path with destination path.
            int charsCount = entryPath.count() - lastFolder.count();
            if (entriesWithoutChildren != 1) {
                charsCount += nameLength;
            }
            newPath = destinationPath + entryPath.right(charsCount);
        } else {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            const QString name = entryPath.split(QLatin1Char('/'), QString::SkipEmptyParts).last();
#else
            const QString name = entryPath.split(QLatin1Char('/'), Qt::SkipEmptyParts).last();
#endif
            if (entriesWithoutChildren != 1) {
                newPath = destinationPath + name;
                if (entryPath.right(1) == QLatin1String("/")) {
                    newPath += QLatin1Char('/');
                }
            } else {
                // If the mode is set to Move and there is only one passed file in the list,
                // we have to use destination as newPath.
                newPath = destinationPath;
            }
            if (entryPath.right(1) == QLatin1String("/")) {
                nameLength = name.count() + 1; // plus slash
                lastFolder = entryPath;
            } else {
                nameLength = 0;
                lastFolder = QString();
            }
        }
        paths << newPath;
    }
```

#### AUTO 


```{c}
auto extractionJob = archive->extractFiles(entriesToExtract, destDir.path(), extractionOptions);
```

#### AUTO 


```{c}
auto archiveEntries = listEntries(iface);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& node : std::as_const(nodesToDelete)) {
        Archive::Entry *rawEntry = static_cast<Archive::Entry*>(node.internalPointer());
        qCDebug(ARK) << "Delete with parent entries " << rawEntry->getParent()->entries() << " and row " << rawEntry->row();
        beginRemoveRows(parent(node), rawEntry->row(), rawEntry->row());
        rawEntry->getParent()->removeEntryAt(rawEntry->row());
        endRemoveRows();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : qAsConst(entries)) {
        if (!fullPathsToDelete.contains(entry->fullPath())) {
            expectedRemainingEntries.append(entry);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
            batchExtractJob->addInput(url);
        }
```

#### AUTO 


```{c}
auto loadJob = Archive::load(archivePath, m_plugin, this);
```

#### AUTO 


```{c}
auto archive = create(fileName, mimeType, parent);
```

#### AUTO 


```{c}
auto item = *iterator;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : files) {

        QFileInfo relEntry(file->fullPath().remove(file->rootNode));
        QFileInfo absSourceEntry(QDir::current().absolutePath() + QLatin1Char('/') + file->fullPath());
        QFileInfo absDestEntry(finalDestDir.path() + QLatin1Char('/') + relEntry.filePath());

        if (absSourceEntry.isDir()) {

            // For directories, just create the path.
            if (!finalDestDir.mkpath(relEntry.filePath())) {
                qCWarning(ARK) << "Failed to create directory" << relEntry.filePath() << "in final destination.";
            }

        } else {

            // If destination file exists, prompt the user.
            if (absDestEntry.exists()) {
                qCWarning(ARK) << "File" << absDestEntry.absoluteFilePath() << "exists.";

                if (!skipAll && !overwriteAll) {

                    Kerfuffle::OverwriteQuery query(absDestEntry.absoluteFilePath());
                    query.setNoRenameMode(true);
                    query.execute();

                    if (query.responseOverwrite() || query.responseOverwriteAll()) {
                        if (query.responseOverwriteAll()) {
                            overwriteAll = true;
                        }
                        if (!QFile::remove(absDestEntry.absoluteFilePath())) {
                            qCWarning(ARK) << "Failed to remove" << absDestEntry.absoluteFilePath();
                        }

                    } else if (query.responseSkip() || query.responseAutoSkip()) {
                        if (query.responseAutoSkip()) {
                            skipAll = true;
                        }
                        continue;

                    } else if (query.responseCancelled()) {
                        Q_EMIT cancelled();
                        Q_EMIT finished(false);
                        return false;
                    }

                } else if (skipAll) {
                    continue;
                } else if (overwriteAll) {
                    if (!QFile::remove(absDestEntry.absoluteFilePath())) {
                        qCWarning(ARK) << "Failed to remove" << absDestEntry.absoluteFilePath();
                    }
                }
            }

            // Create any parent directories.
            if (!finalDestDir.mkpath(relEntry.path())) {
                qCWarning(ARK) << "Failed to create parent directory for file:" << absDestEntry.filePath();
            }

            // Move files to the final destination.
            if (!QFile(absSourceEntry.absoluteFilePath()).rename(absDestEntry.absoluteFilePath())) {
                qCWarning(ARK) << "Failed to move file" << absSourceEntry.filePath() << "to final destination.";
                Q_EMIT error(i18ncp("@info",
                                  "Could not move the extracted file to the destination directory.",
                                  "Could not move the extracted files to the destination directory.",
                                  m_extractedFiles.size()));
                Q_EMIT finished(false);
                return false;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, copyJob, srcUrl, saveUrl]() {
        const int err = copyJob->error();
        if (err) {
            QString msg = copyJob->errorString();
            // Use custom error messages for these two cases, otherwise just use KIO's
            if (err == KIO::ERR_WRITE_ACCESS_DENIED) {
                msg = xi18nc("@info",
                            "The archive could not be saved as <filename>%1</filename>. Try saving"
                            " it to another location.", saveUrl.toDisplayString(QUrl::PreferLocalFile));
            } else if (err == KIO::ERR_DOES_NOT_EXIST) {
                msg = xi18nc("@info",
                            "The archive <filename>%1</filename> does not exist anymore, therefore it"
                            " cannot be copied to the specified location.", srcUrl.toDisplayString(QUrl::PreferLocalFile));
            }

            KMessageBox::error(widget(), msg);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTemporaryDir *tmpDir : qAsConst(m_tmpExtractDirList)) {
        relPath.remove(tmpDir->path()); //Remove tmpDir.
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QLatin1String("kerfuffle_clirar")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](int result) {
        if (result == QDialog::Accepted) {
            openUrl(dlg->selectedUrls().at(0));
        }
        dlg->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("Kerfuffle/Plugin"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : entries) {
        if (entry->isDir()) {
            traverseAndCountDirNode(entry);
            m_numberOfFolders++;
        } else {
            m_numberOfFiles++;
            m_uncompressedSize += entry->property("size").toULongLong();
        }
    }
```

#### AUTO 


```{c}
auto archive = create(fileName, plugin, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : qAsConst(inputFiles)) {
        addToArchiveJob->addInput(QUrl::fromUserInput(file));
    }
```

#### AUTO 


```{c}
const auto pluginId = metaData.pluginId();
```

#### AUTO 


```{c}
auto loadJob = Archive::load(QFINDTESTDATA(QStringLiteral("data/%1").arg(expectedArchiveName)));
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : std::as_const(m_entries)) {
        // #191821: workDir must be used instead of QDir::current()
        //          so that symlinks aren't resolved automatically
        const QString &fullPath = entry->fullPath();
        QString relativePath = workDir.relativeFilePath(fullPath);

        if (fullPath.endsWith(QLatin1Char('/'))) {
            relativePath += QLatin1Char('/');
        }

        entry->setFullPath(relativePath);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(m_listSwitch)) {
        args << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        if (skippedDirPath.count() > 0 && entry.startsWith(skippedDirPath)) {
            continue;
        } else {
            skippedDirPath.clear();
        }

        while (!entry.startsWith(lastDirEntry->fullPath())) {
            lastDirEntry = lastDirEntry->getParent();
        }

        bool isDir = entry.right(1) == QLatin1String("/");
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
        const Archive::Entry *archiveEntry = lastDirEntry->find(entry.split(QLatin1Char('/'), QString::SkipEmptyParts).last());
#else
        const Archive::Entry *archiveEntry = lastDirEntry->find(entry.split(QLatin1Char('/'), Qt::SkipEmptyParts).last());
#endif

        if (archiveEntry != nullptr) {
            if (archiveEntry->isDir() != isDir || !allowMerging) {
                if (isDir) {
                    skippedDirPath = lastDirEntry->fullPath();
                }

                if (!error) {
                    conflictingEntries.clear();
                    error = true;
                }
                conflictingEntries << archiveEntry;
            } else {
                if (isDir) {
                    lastDirEntry = archiveEntry;
                }
                else if (!error) {
                    conflictingEntries << archiveEntry;
                }
            }
        } else if (isDir) {
            skippedDirPath = entry;
        }
    }
```

#### AUTO 


```{c}
auto part = new Ark::Part(parentWidget, parent, args);
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *selectedFile : files) {
        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        if (!writeFile(selectedFile->fullPath(), destinationPath)) {
            finish(false);
            return false;
        }
        addedEntries++;
        Q_EMIT progress(float(addedEntries)/float(totalCount));

        // For directories, write all subfiles/folders.
        const QString &fullPath = selectedFile->fullPath();
        if (QFileInfo(fullPath).isDir()) {
            QDirIterator it(fullPath,
                            QDir::AllEntries | QDir::Readable |
                            QDir::Hidden | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories);

            while (!QThread::currentThread()->isInterruptionRequested() && it.hasNext()) {
                QString path = it.next();

                if ((it.fileName() == QLatin1String("..")) ||
                    (it.fileName() == QLatin1Char('.'))) {
                    continue;
                }

                const bool isRealDir = it.fileInfo().isDir() && !it.fileInfo().isSymLink();

                if (isRealDir) {
                    path.append(QLatin1Char('/'));
                }

                if (!writeFile(path, destinationPath)) {
                    finish(false);
                    return false;
                }
                addedEntries++;
                Q_EMIT progress(float(addedEntries)/float(totalCount));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue& value : entries) {
        const QJsonObject currentEntryJson = value.toObject();

        Archive::Entry *currentEntry = new Archive::Entry(this);

        QString filename = currentEntryJson.value(QStringLiteral("XADFileName")).toString();

        currentEntry->setProperty("isDirectory", !currentEntryJson.value(QStringLiteral("XADIsDirectory")).isUndefined());
        if (currentEntry->isDir()) {
            filename += QLatin1Char('/');
        }

        currentEntry->setProperty("fullPath", filename);

        // FIXME: archives created from OSX (i.e. with the __MACOSX folder) list each entry twice, the 2nd time with size 0
        currentEntry->setProperty("size", currentEntryJson.value(QStringLiteral("XADFileSize")));
        currentEntry->setProperty("compressedSize", currentEntryJson.value(QStringLiteral("XADCompressedSize")));
        currentEntry->setProperty("timestamp", currentEntryJson.value(QStringLiteral("XADLastModificationDate")).toVariant());
        currentEntry->setProperty("size", currentEntryJson.value(QStringLiteral("XADFileSize")));
        const bool isPasswordProtected = (currentEntryJson.value(QStringLiteral("XADIsEncrypted")).toInt() == 1);
        currentEntry->setProperty("isPasswordProtected", isPasswordProtected);
        if (isPasswordProtected) {
            formatName == QLatin1String("RAR 5") ? Q_EMIT encryptionMethodFound(QStringLiteral("AES256")) :
                                                   Q_EMIT encryptionMethodFound(QStringLiteral("AES128"));
        }
        // TODO: missing fields

        Q_EMIT entry(currentEntry);
    }
```

#### AUTO 


```{c}
auto createJob = Archive::create(m_filename, m_mimeType, m_entries, m_options, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mime : mimeTypes) {
                if (mimeType.inherits(mime)) {
                    filteredPlugins << plugin;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Entry *entry : qAsConst(m_entries)) {
        if (entry && (entry->nameView() == name)) {
            return entry;
        }
    }
```

#### AUTO 


```{c}
auto readBytes = file.read(buff, sizeof(buff));
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : entries) {
        map.insert(entry->fullPath(), entry);
    }
```

#### AUTO 


```{c}
auto loadJob = new LoadJob(archive);
```

#### AUTO 


```{c}
auto remainingEntries = listEntries(iface);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : std::as_const(map)) {
        sortedMimeTypes << value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &row : std::as_const(m_cutIndexes)) {
        m_view->dataChanged(row, row);
    }
```

#### AUTO 


```{c}
auto tmp = *this;
```

#### AUTO 


```{c}
auto job = it.next();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &multiSuffix : multiVolumeSuffix) {
        QString newSuffix = multiSuffix;
        newSuffix.replace(QStringLiteral("$Suffix"), oldSuffix);
        name = filename().remove(oldSuffix).append(newSuffix);
        if (QFileInfo::exists(name)) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : files) {

        QFileInfo relEntry(file->fullPath().remove(file->rootNode));
        QFileInfo absSourceEntry(QDir::current().absolutePath() + QLatin1Char('/') + file->fullPath());
        QFileInfo absDestEntry(finalDestDir.path() + QLatin1Char('/') + relEntry.filePath());

        if (absSourceEntry.isDir()) {

            // For directories, just create the path.
            if (!finalDestDir.mkpath(relEntry.filePath())) {
                qCWarning(ARK) << "Failed to create directory" << relEntry.filePath() << "in final destination.";
            }

        } else {

            // If destination file exists, prompt the user.
            if (absDestEntry.exists()) {
                qCWarning(ARK) << "File" << absDestEntry.absoluteFilePath() << "exists.";

                if (!skipAll && !overwriteAll) {

                    Kerfuffle::OverwriteQuery query(absDestEntry.absoluteFilePath());
                    query.setNoRenameMode(true);
                    query.execute();

                    if (query.responseOverwrite() || query.responseOverwriteAll()) {
                        if (query.responseOverwriteAll()) {
                            overwriteAll = true;
                        }
                        if (!QFile::remove(absDestEntry.absoluteFilePath())) {
                            qCWarning(ARK) << "Failed to remove" << absDestEntry.absoluteFilePath();
                        }

                    } else if (query.responseSkip() || query.responseAutoSkip()) {
                        if (query.responseAutoSkip()) {
                            skipAll = true;
                        }
                        continue;

                    } else if (query.responseCancelled()) {
                        emit cancelled();
                        emit finished(false);
                        return false;
                    }

                } else if (skipAll) {
                    continue;
                } else if (overwriteAll) {
                    if (!QFile::remove(absDestEntry.absoluteFilePath())) {
                        qCWarning(ARK) << "Failed to remove" << absDestEntry.absoluteFilePath();
                    }
                }
            }

            // Create any parent directories.
            if (!finalDestDir.mkpath(relEntry.path())) {
                qCWarning(ARK) << "Failed to create parent directory for file:" << absDestEntry.filePath();
            }

            // Move files to the final destination.
            if (!QFile(absSourceEntry.absoluteFilePath()).rename(absDestEntry.absoluteFilePath())) {
                qCWarning(ARK) << "Failed to move file" << absSourceEntry.filePath() << "to final destination.";
                emit error(i18ncp("@info",
                                  "Could not move the extracted file to the destination directory.",
                                  "Could not move the extracted files to the destination directory.",
                                  m_extractedFiles.size()));
                emit finished(false);
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kerfuffle::Archive::Entry *file : files) {
        const QString &fileName = file->fullPath();
        if (m_archive.contains(fileName)) {
            m_archive.remove(fileName);
            Q_EMIT entryRemoved(fileName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : std::as_const(m_testSwitch)) {
        args << s;
    }
```

#### AUTO 


```{c}
const auto installedPlugins = m_pluginManager.installedPlugins();
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : std::as_const(sortedEntries)) {
        if (lastFolder.count() > 0 && entry->fullPath().startsWith(lastFolder)) {
            continue;
        }

        lastFolder = (entry->fullPath().right(1) == QLatin1String("/")) ? entry->fullPath() : QString();
        filteredEntries << entry;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {delete m_addJob;}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *file : entriesWithoutChildren) {
            pairList << file->fullPath(NoTrailingSlash) << destination->fullPath() + file->name();
        }
```

#### AUTO 


```{c}
auto deleteJob = archive->deleteFiles(targetEntries);
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPlugins(QString(), [](const KPluginMetaData& metaData) {
        return metaData.pluginId() == QLatin1String("arkpart") &&
               metaData.serviceTypes().contains(QLatin1String("KParts/ReadOnlyPart")) &&
               metaData.serviceTypes().contains(QLatin1String("Browser/View"));
    });
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->cliProperties()->listArgs(archiveName, password);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &method : methods) {

        QRegularExpression rxEncMethod(QStringLiteral("^(7zAES|AES-128|AES-192|AES-256|ZipCrypto)$"));
        if (rxEncMethod.match(method).hasMatch()) {
            QRegularExpression rxAESMethods(QStringLiteral("^(AES-128|AES-192|AES-256)$"));
            if (rxAESMethods.match(method).hasMatch()) {
                // Remove dash for AES methods.
                emit encryptionMethodFound(QString(method).remove(QLatin1Char('-')));
            } else {
                emit encryptionMethodFound(method);
            }
            continue;
        }

        // LZMA methods are output with some trailing numbers by 7z representing dictionary/block sizes.
        // We are not interested in these, so remove them.
        if (method.startsWith(QLatin1String("LZMA2"))) {
            emit compressionMethodFound(method.left(5));
        } else if (method.startsWith(QLatin1String("LZMA"))) {
            emit compressionMethodFound(method.left(4));
        } else if (method == QLatin1String("xz")) {
            emit compressionMethodFound(method.toUpper());
        } else {
            emit compressionMethodFound(method);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto plugin : plugins) {
            QTest::newRow(QStringLiteral("test preserve 0755 permissions (%1, %2)").arg(format, plugin->metaData().pluginId()).toUtf8().constData())
                << filename
                << plugin
                << QStringLiteral("0755.sh")
                << 0755;
        }
```

#### AUTO 


```{c}
auto *batchExtractJob = new BatchExtract(parent);
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPluginsById(QStringLiteral("kerfuffle"), QStringLiteral("kerfuffle_cli7z"));
```

#### AUTO 


```{c}
const auto mime = QMimeDatabase().mimeTypeForFile(filename, QMimeDatabase::MatchExtension);
```

#### AUTO 


```{c}
auto QStringTokenizerBase<Haystack, Needle>::next(tokenizer_state state) const noexcept -> next_result
{
    while (true) {
        if (state.end < 0) {
            // already at end:
            return {{}, false, state};
        }
        state.end = m_haystack.indexOf(m_needle, state.start + state.extra, m_cs);
        Haystack result;
        if (state.end >= 0) {
            // token separator found => return intermediate element:
            result = m_haystack.mid(state.start, state.end - state.start);
            const auto ns = QtPrivate::Tok::size(m_needle);
            state.start = state.end + ns;
            state.extra = (ns == 0 ? 1 : 0);
        } else {
            // token separator not found => return final element:
            result = m_haystack.mid(state.start);
        }
        if ((m_sb & Qt::SkipEmptyParts) && result.isEmpty())
            continue;
        return {result, true, state};
    }
}
```

#### AUTO 


```{c}
const auto pluginId = plugin->metaData().pluginId();
```

#### AUTO 


```{c}
auto batchJob = new BatchExtract(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Entry *entry : std::as_const(m_entries)) {
        if (entry && (entry->nameView() == name)) {
            return entry;
        }
    }
```

#### AUTO 


```{c}
auto archiveFile = QFile(archive()->fileName());
```

#### AUTO 


```{c}
auto i = m_propertiesMap.begin();
```

#### AUTO 


```{c}
const auto plugins = m_pluginManger.availablePlugins();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *e : entries) {
        filesList << escapeFileName(e->fullPath(NoTrailingSlash));
    }
```

#### AUTO 


```{c}
auto collapsibleEncryption = dialog->findChild<KCollapsibleGroupBox*>(QStringLiteral("collapsibleEncryption"));
```

#### AUTO 


```{c}
auto loadJob = Archive::load(archiveName, plugin);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.pluginId() == QStringLiteral("arkpart") &&
               metaData.serviceTypes().contains(QStringLiteral("KParts/ReadOnlyPart")) &&
               metaData.serviceTypes().contains(QStringLiteral("Browser/View"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kerfuffle::Archive::Entry *entry : files) {
        const QString &path = destination->fullPath() + entry->fullPath();
        if (m_archive.contains(path)) {
            return false;
        }

        Kerfuffle::Archive::Entry *e = new Kerfuffle::Archive::Entry(nullptr);
        e->setProperty("fullPath", path);

        m_archive[path] = e;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *, const QString &title, const QPair<QString,QString> &field1, const QPair<QString,QString> &) {
            emit description(this, title, field1);
        }
```

#### AUTO 


```{c}
const auto mimeTypes = pluginManager.supportedMimeTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[&numberOfFolders](Archive::Entry *entry) {
        if (entry->isDir()) {
            numberOfFolders++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & extension : std::as_const(m_possibleExtensions)) {
        qCDebug(ARK) << extension;

        if (uncompressedName.endsWith(extension, Qt::CaseInsensitive)) {
            uncompressedName.chop(extension.size());
            return uncompressedName;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metaData : plugins) {
        const auto pluginId = metaData.pluginId();
        // Filter out duplicate plugins.
        if (addedPlugins.contains(pluginId)) {
            continue;
        }

        Plugin *plugin = new Plugin(this, metaData);
        plugin->setEnabled(!ArkSettings::disabledPlugins().contains(pluginId));
        addedPlugins << pluginId;
        m_plugins << plugin;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *e : files) {
        args << e->fullPath(NoTrailingSlash);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rx : qAsConst(m_testPassedPatterns)) {
        if (QRegularExpression(rx).match(line).hasMatch()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto piece
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : std::as_const(entriesWithoutChildren)) {
            if (entry->isDir() && m_destination->fullPath().startsWith(entry->fullPath())) {
                KMessageBox::error(widget(),
                                   i18n("Folders can't be moved into themselves."),
                                   i18n("Moving a folder into itself"));
                delete m_destination;
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& file : filesToAdd) {
        m_jobTempEntries.push_back(new Archive::Entry(nullptr, file));
        if (QFileInfo(file).isDir()) {
            withChildPaths << file + QLatin1Char('/');
            QDirIterator it(file, QDir::AllEntries | QDir::Readable | QDir::Hidden | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
            while (it.hasNext()) {
                QString path = it.next();
                if (it.fileInfo().isDir()) {
                    path += QLatin1Char('/');
                }
                withChildPaths << path;
            }
        } else {
            withChildPaths << file;
        }
    }
```

#### AUTO 


```{c}
const auto e
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *e : std::as_const(m_newMovedFiles)) {
            Q_EMIT entry(e);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *file : files) {
            // The entries may have parent. We have to save and apply it to our new entry in order to prevent memory
            // leaks.
            if (preservedParent == nullptr) {
                preservedParent = file->parent();
            }

            const QString filePath = QDir::currentPath() + QLatin1Char('/') + file->fullPath(NoTrailingSlash);
            const QString newFilePath = absoluteDestinationPath + file->fullPath(NoTrailingSlash);
            if (QFile::link(filePath, newFilePath)) {
                qCDebug(ARK) << "Symlink's created:" << filePath << newFilePath;
            } else {
                qCDebug(ARK) << "Can't create symlink" << filePath << newFilePath;
                Q_EMIT finished(false);
                return false;
            }
        }
```

#### AUTO 


```{c}
auto part = new Ark::Part(parentWidget, parent, metaData(), args);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : commentSwitches) {
        args << s;
    }
```

#### AUTO 


```{c}
auto doExtract = [this](const QString &destination) {
        qCDebug(ARK) << "Extract to" << destination;

        Kerfuffle::ExtractionOptions options;
        options.setDragAndDropEnabled(true);

        // Create and start the ExtractJob.
        ExtractJob *job = m_model->extractFiles(filesAndRootNodesForIndexes(addChildren(getSelectedIndexes())), destination, options);
        registerJob(job);
        connect(job, &KJob::result, this, &Part::slotExtractionDone);
        job->start();
    };
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *, const QString &title, const QPair<QString,QString> &field1, const QPair<QString,QString> &) {
            Q_EMIT description(this, title, field1);
        }
```

#### AUTO 


```{c}
auto loadJob = Archive::load(archivePath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& mimeType : mimeTypes) {
            if (db.mimeTypeForName(mimeType).isValid()) {
                supported.insert(mimeType);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : std::as_const(entryMap)) {
        if (lastFolder.count() > 0 && entry->fullPath().startsWith(lastFolder)) {
            // Replace last moved or copied folder path with destination path.
            int charsCount = entry->fullPath().count() - lastFolder.count();
            if (entriesWithoutChildren > 1) {
                charsCount += nameLength;
            }
            newPath = destination->fullPath() + entry->fullPath().right(charsCount);
        } else {
            if (entriesWithoutChildren > 1) {
                newPath = destination->fullPath() + entry->name();
            } else {
                // If there is only one passed file in the list,
                // we have to use destination as newPath.
                newPath = destination->fullPath(NoTrailingSlash);
            }
            if (entry->isDir()) {
                newPath += QLatin1Char('/');
                nameLength = entry->name().count() + 1; // plus slash
                lastFolder = entry->fullPath();
            } else {
                nameLength = 0;
                lastFolder = QString();
            }
        }
        Archive::Entry *newEntry = new Archive::Entry(nullptr);
        newEntry->copyMetaData(entry);
        newEntry->setFullPath(newPath);
        m_newMovedFiles << newEntry;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : std::as_const(entries)) {
        if (!fullPathsToDelete.contains(entry->fullPath())) {
            expectedRemainingEntries.append(entry);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob*, unsigned long percent) {
            emitPercent(percent, 100);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : entries) {
        urls.append(QUrl::fromLocalFile(entry->fullPath()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : std::as_const(inputFiles)) {
        addToArchiveJob->addInput(QUrl::fromUserInput(file));
    }
```

#### AUTO 


```{c}
auto job = new LoadJob(iface);
```

#### AUTO 


```{c}
auto archiveTypeComboBox = dialog->findChild<QComboBox*>(QStringLiteral("mimeComboBox"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlList) {
        if (!url.isLocalFile()) {
            continue;
        }
        const QMimeType mimeType = determineMimeType(url.toLocalFile());
        if (m_pluginManager->preferredPluginsFor(mimeType).isEmpty()) {
            continue;
        }
        supportedUrls << url;
        // Check whether we can write in the parent directory of the file.
        const QString directory = url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash).toLocalFile();
        if (!QFileInfo(directory).isWritable()) {
            readOnlyParentDir = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fullPath : removedFullPaths) {
            Q_EMIT entryRemoved(fullPath);
        }
```

#### AUTO 


```{c}
const auto replacedArgs = plugin->cliProperties()->addArgs(archiveName, {}, password, encryptHeader, compressionLevel, compressionMethod, QString(), volumeSize);
```

#### AUTO 


```{c}
auto *addToArchiveJob = new AddToArchive(parent);
```

#### AUTO 


```{c}
auto path = rootPath + name;
```

#### LAMBDA EXPRESSION 


```{c}
[fileExtension, urls, name, parent, this]() {
        auto *addToArchiveJob = new AddToArchive(parent);
        addToArchiveJob->setChangeToFirstPath(true);
        for (const QUrl &url : urls) {
            addToArchiveJob->addInput(url);
        }
        if (!fileExtension.isEmpty()) {
            addToArchiveJob->setAutoFilenameSuffix(fileExtension);
        } else {
            if (!addToArchiveJob->showAddDialog()) {
                delete addToArchiveJob;
                return;
            }
        }
        addToArchiveJob->start();
        connect(addToArchiveJob, &KJob::finished, this, [this, addToArchiveJob](){
            if (addToArchiveJob->error() == 0) {
                KIO::highlightInFileManager({QUrl::fromLocalFile(addToArchiveJob->fileName())});
            } else if (!addToArchiveJob->errorString().isEmpty()) {
                Q_EMIT error(addToArchiveJob->errorString());
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *selectedFile : files) {
        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        if (!writeFile(selectedFile->fullPath(), destinationPath)) {
            finish(false);
            return false;
        }
        addedEntries++;
        emit progress(float(addedEntries)/float(totalCount));

        // For directories, write all subfiles/folders.
        const QString &fullPath = selectedFile->fullPath();
        if (QFileInfo(fullPath).isDir()) {
            QDirIterator it(fullPath,
                            QDir::AllEntries | QDir::Readable |
                            QDir::Hidden | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories);

            while (!QThread::currentThread()->isInterruptionRequested() && it.hasNext()) {
                QString path = it.next();

                if ((it.fileName() == QLatin1String("..")) ||
                    (it.fileName() == QLatin1Char('.'))) {
                    continue;
                }

                const bool isRealDir = it.fileInfo().isDir() && !it.fileInfo().isSymLink();

                if (isRealDir) {
                    path.append(QLatin1Char('/'));
                }

                if (!writeFile(path, destinationPath)) {
                    finish(false);
                    return false;
                }
                addedEntries++;
                emit progress(float(addedEntries)/float(totalCount));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (!supportedMime) {
            // Check whether the mimetype inherits from a supported mimetype.
            const QStringList mimeTypes = plugin->metaData().mimeTypes();
            for (const QString &mime : mimeTypes) {
                if (mimeType.inherits(mime)) {
                    filteredPlugins << plugin;
                }
            }
        } else if (plugin->metaData().mimeTypes().contains(mimeType.name())) {
            filteredPlugins << plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPersistentModelIndex& node : qAsConst(nodesToDelete)) {
        Archive::Entry *rawEntry = static_cast<Archive::Entry*>(node.internalPointer());
        qCDebug(ARK) << "Delete with parent entries " << rawEntry->getParent()->entries() << " and row " << rawEntry->row();
        beginRemoveRows(parent(node), rawEntry->row(), rawEntry->row());
        rawEntry->getParent()->removeEntryAt(rawEntry->row());
        endRemoveRows();
    }
```

#### AUTO 


```{c}
const auto urls = data->urls();
```

#### AUTO 


```{c}
auto oktetaPart = std::find_if(offers.begin(), offers.end(), [](KService::Ptr service) {
        return service->desktopEntryName() == QLatin1String("oktetapart");
    });
```

#### LAMBDA EXPRESSION 


```{c}
[mimeType](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("Kerfuffle/Plugin"))) {
            return false;
        }

        if (metaData.mimeTypes().contains(mimeType)) {
            return true;
        }

        // The mimetype is not directly supported, but it could inherit from a supported one.
        if (!supportedMimeTypes().contains(mimeType)) {
            foreach (const QString &mime, metaData.mimeTypes()) {
                if (QMimeDatabase().mimeTypeForName(mimeType).inherits(mime)) {
                    return true;
                }
            }
        }

        return false;
    }
```

#### AUTO 


```{c}
const auto compressedSize = receivedEntry->property("compressedSize").toULongLong();
```

#### AUTO 


```{c}
auto future = QtConcurrent::run(this, &PropertiesDialog::calcHash, algorithm, fileName);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* e : files) {

        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        const qlonglong index = zip_name_locate(archive, e->fullPath().toUtf8().constData(), ZIP_FL_ENC_GUESS);
        if (index == -1) {
            qCCritical(ARK) << "Could not find entry to delete:" << e->fullPath();
            Q_EMIT error(xi18n("Failed to delete entry: %1", e->fullPath()));
            return false;
        }
        if (zip_delete(archive, index) == -1) {
            qCCritical(ARK) << "Could not delete entry" << e->fullPath() << ":" << zip_strerror(archive);
            Q_EMIT error(xi18n("Failed to delete entry: %1", QString::fromUtf8(zip_strerror(archive))));
            return false;
        }
        Q_EMIT entryRemoved(e->fullPath());
        Q_EMIT progress(float(++i) / files.size());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotWatchedFileModified(m_lastChangedFilename);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotOpenEntry(Preview); }
```

#### AUTO 


```{c}
constexpr auto haystackView(Arg &&a) const noexcept
            -> decltype(this->view(std::forward<Arg>(a)))
        { return this->view(std::forward<Arg>(a)); }
```

#### AUTO 


```{c}
auto futureWatcher = new QFutureWatcher<QString>(this);
```

#### AUTO 


```{c}
auto entryName = entry->name();
```

#### AUTO 


```{c}
auto entry
```

#### AUTO 


```{c}
const auto filesIndexes = filesForIndexes(alist);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue& value : entries) {
        const QJsonObject currentEntryJson = value.toObject();

        Archive::Entry *currentEntry = new Archive::Entry(this);

        QString filename = currentEntryJson.value(QStringLiteral("XADFileName")).toString();

        currentEntry->setProperty("isDirectory", !currentEntryJson.value(QStringLiteral("XADIsDirectory")).isUndefined());
        if (currentEntry->isDir()) {
            filename += QLatin1Char('/');
        }

        currentEntry->setProperty("fullPath", filename);

        // FIXME: archives created from OSX (i.e. with the __MACOSX folder) list each entry twice, the 2nd time with size 0
        currentEntry->setProperty("size", currentEntryJson.value(QStringLiteral("XADFileSize")));
        currentEntry->setProperty("compressedSize", currentEntryJson.value(QStringLiteral("XADCompressedSize")));
        currentEntry->setProperty("timestamp", currentEntryJson.value(QStringLiteral("XADLastModificationDate")).toVariant());
        currentEntry->setProperty("size", currentEntryJson.value(QStringLiteral("XADFileSize")));
        const bool isPasswordProtected = (currentEntryJson.value(QStringLiteral("XADIsEncrypted")).toInt() == 1);
        currentEntry->setProperty("isPasswordProtected", isPasswordProtected);
        if (isPasswordProtected) {
            formatName == QLatin1String("RAR 5") ? emit encryptionMethodFound(QStringLiteral("AES256")) :
                                                   emit encryptionMethodFound(QStringLiteral("AES128"));
        }
        // TODO: missing fields

        emit entry(currentEntry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry* entry : entries) {
        entryMap.insert(entry->fullPath(), entry);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, batchExtractJob](){
            if (!batchExtractJob->errorString().isEmpty()) {
                #if KIO_VERSION >= QT_VERSION_CHECK(5, 82, 0)
                Q_EMIT error(batchExtractJob->errorString());
                #endif
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QStringLiteral("kerfuffle_cliunarchiver")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &value : array) {
        readOnlyExecutables << value.toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, addToArchiveJob](){
            if (addToArchiveJob->error() == 0) {
                KIO::highlightInFileManager({QUrl::fromLocalFile(addToArchiveJob->fileName())});
            } else if (!addToArchiveJob->errorString().isEmpty()) {
                #if KIO_VERSION >= QT_VERSION_CHECK(5, 82, 0)
                Q_EMIT error(addToArchiveJob->errorString());
                #endif
            }
        }
```

#### AUTO 


```{c}
const auto args = substituteCommentVariables(m_param.value(CommentArgs).toStringList(),
                                                 m_commentTempFile->fileName());
```

#### LAMBDA EXPRESSION 


```{c}
[urls,name, option, parent,this]() {
        auto *batchExtractJob = new BatchExtract(parent);
        batchExtractJob->setDestinationFolder(QFileInfo(urls.first().toLocalFile()).path());
        batchExtractJob->setOpenDestinationAfterExtraction(ArkSettings::openDestinationFolderAfterExtraction());
        if (option == AutoSubfolder) {
            batchExtractJob->setAutoSubfolder(true);
        } else if (option == ShowDialog) {
            if (!batchExtractJob->showExtractDialog()) {
                delete batchExtractJob;
                return;
            }
        }
        for (const QUrl &url : urls) {
            batchExtractJob->addInput(url);
        }
        batchExtractJob->start();
        connect(batchExtractJob, &KJob::finished, this, [this, batchExtractJob](){
            if (!batchExtractJob->errorString().isEmpty()) {
                Q_EMIT error(batchExtractJob->errorString());
            }
        });
    }
```

#### AUTO 


```{c}
const auto expectedQtPermissions = KIO::convertPermissions(expectedPermissions);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : list) {
        ret << m_model->entryForIndex(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &destination) {
        qCDebug(ARK) << "Extract to" << destination;

        Kerfuffle::ExtractionOptions options;
        options.setDragAndDropEnabled(true);

        // Create and start the ExtractJob.
        ExtractJob *job = m_model->extractFiles(filesAndRootNodesForIndexes(addChildren(getSelectedIndexes())), destination, options);
        registerJob(job);
        connect(job, &KJob::result, this, &Part::slotExtractionDone);
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fullPath : qAsConst(expectedAddedFullPaths)) {
        QVERIFY(currentFullPaths.contains(fullPath));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *e : std::as_const(files)) {
        filesList << e->fullPath(NoTrailingSlash);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KService::Ptr service) {
        return service->desktopEntryName() == QLatin1String("khtml");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : qAsConst(m_plugins)) {
        if (plugin->isValid()) {
            availablePlugins << plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& url : std::as_const(m_inputs)) {
        addExtraction(url);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fileExtension, urls, name, parent, this]() {
        auto *addToArchiveJob = new AddToArchive(parent);
        addToArchiveJob->setImmediateProgressReporting(true);
        addToArchiveJob->setChangeToFirstPath(true);
        for (const QUrl &url : urls) {
            addToArchiveJob->addInput(url);
        }
        if (!fileExtension.isEmpty()) {
            addToArchiveJob->setAutoFilenameSuffix(fileExtension);
        } else {
            if (!addToArchiveJob->showAddDialog()) {
                delete addToArchiveJob;
                return;
            }
        }
        addToArchiveJob->start();
        connect(addToArchiveJob, &KJob::finished, this, [this, addToArchiveJob]() {
            if (addToArchiveJob->error() != 0) {
                Q_EMIT error(addToArchiveJob->errorString());
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : entries) {
        sortedEntries.insert(entry->fullPath(), entry);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &method : methods) {

        QRegularExpression rxEncMethod(QStringLiteral("^(7zAES|AES-128|AES-192|AES-256|ZipCrypto)$"));
        if (rxEncMethod.match(method).hasMatch()) {
            QRegularExpression rxAESMethods(QStringLiteral("^(AES-128|AES-192|AES-256)$"));
            if (rxAESMethods.match(method).hasMatch()) {
                // Remove dash for AES methods.
                Q_EMIT encryptionMethodFound(QString(method).remove(QLatin1Char('-')));
            } else {
                Q_EMIT encryptionMethodFound(method);
            }
            continue;
        }

        // LZMA methods are output with some trailing numbers by 7z representing dictionary/block sizes.
        // We are not interested in these, so remove them.
        if (method.startsWith(QLatin1String("LZMA2"))) {
            Q_EMIT compressionMethodFound(method.left(5));
        } else if (method.startsWith(QLatin1String("LZMA"))) {
            Q_EMIT compressionMethodFound(method.left(4));
        } else if (method == QLatin1String("xz")) {
            Q_EMIT compressionMethodFound(method.toUpper());
        } else {
            Q_EMIT compressionMethodFound(method);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : std::as_const(m_supportedMimeTypes)) {
        m_ui->mimeComboBox->addItem(QMimeDatabase().mimeTypeForName(type).comment());
    }
```

#### AUTO 


```{c}
auto khtmlPart = std::find_if(offers.begin(), offers.end(), [](KService::Ptr service) {
        return service->desktopEntryName() == QLatin1String("khtml");
    });
```

#### AUTO 


```{c}
auto quitAction = KStandardAction::quit(this, &MainWindow::quit, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto e : std::as_const(m_emittedEntries)) {
        // Entries might be passed to pending slots, so we just schedule their deletion.
        e->deleteLater();
    }
```

#### AUTO 


```{c}
const auto name = subfolderName().isEmpty() ? archive()->completeBaseName() : subfolderName();
```

#### AUTO 


```{c}
const auto args = substituteAddVariables(m_param.value(AddArgs).toStringList(),
                                             filesToPass,
                                             password(),
                                             isHeaderEncryptionEnabled(),
                                             compLevel,
                                             volumeSize);
```

#### AUTO 


```{c}
auto loadJob = new LoadJob(iface);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : qAsConst(m_listSwitch)) {
        args << s;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& line : std::as_const(lines)) {
        if (!line.isEmpty() || (m_listEmptyLines && m_operationMode == List)) {
            if (!handleLine(QString::fromLocal8Bit(line))) {
                killProcess();
                return;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        const QStringList paths = QCoreApplication::libraryPaths();
        for (const QString &path : paths) {
            const QString pluginPath = QStringLiteral("%1/kerfuffle/kerfuffle_libarchive.so").arg(path);
            if (QFileInfo::exists(pluginPath)) {
                return pluginPath;
            }
        }

        return QString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : list) {
            const Archive::Entry *entry = m_model->entryForIndex(index);
            totalSize += entry->property("size").toULongLong();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Archive::Entry *entry : entries) {
        QListWidgetItem *item = new QListWidgetItem(entry->icon(), entry->fullPath(NoTrailingSlash));
        m_entriesList.addItem(item);
    }
```

#### AUTO 


```{c}
const auto &mimeType
```

#### AUTO 


```{c}
const auto metaData = plugin->metaData();
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : offers) {
        archive = create(fileName, plugin, parent);
        // Use the first valid plugin, according to the priority sorting.
        if (archive->isValid()) {
            return archive;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : std::as_const(m_plugins)) {
        if (plugin->isValid()) {
            availablePlugins << plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plugin *plugin : plugins) {
        if (plugin->metaData().pluginId() == QLatin1String("kerfuffle_cliunarchiver")) {
            m_plugin = plugin;
            return;
        }
    }
```

#### AUTO 


```{c}
const auto &expectedPath
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        if (skippedDirPath.count() > 0 && entry.startsWith(skippedDirPath)) {
            continue;
        } else {
            skippedDirPath.clear();
        }

        while (!entry.startsWith(lastDirEntry->fullPath())) {
            lastDirEntry = lastDirEntry->getParent();
        }

        bool isDir = entry.right(1) == QLatin1String("/");
        const Archive::Entry *archiveEntry = lastDirEntry->find(entry.split(QLatin1Char('/'), Qt::SkipEmptyParts).last());

        if (archiveEntry != nullptr) {
            if (archiveEntry->isDir() != isDir || !allowMerging) {
                if (isDir) {
                    skippedDirPath = lastDirEntry->fullPath();
                }

                if (!error) {
                    conflictingEntries.clear();
                    error = true;
                }
                conflictingEntries << archiveEntry;
            } else {
                if (isDir) {
                    lastDirEntry = archiveEntry;
                }
                else if (!error) {
                    conflictingEntries << archiveEntry;
                }
            }
        } else if (isDir) {
            skippedDirPath = entry;
        }
    }
```

#### AUTO 


```{c}
auto plugin = item->data(0, Qt::UserRole).value<Plugin*>();
```

#### AUTO 


```{c}
auto *dialog = new KAboutPluginDialog(m_part->metaData(), this);
```

#### AUTO 


```{c}
auto batchJob = new BatchExtractJob(loadJob, destination, autoSubfolder, preservePaths);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        foreach (const QString &path, QCoreApplication::libraryPaths()) {
            const QString pluginPath = QStringLiteral("%1/kerfuffle/kerfuffle_libarchive.so").arg(path);
            if (QFileInfo::exists(pluginPath)) {
                return pluginPath;
            }
        }

        return QString();
    }
```

#### AUTO 


```{c}
auto entryList = QVector<Archive::Entry*>::fromList(m_model->filesToMove.values());
```

#### AUTO 


```{c}
const auto selectedRows = m_view->selectionModel()->selectedRows();
```

#### AUTO 


```{c}
auto archive = loadJob->archive();
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *selectedFile : files) {
        if (QThread::currentThread()->isInterruptionRequested()) {
            break;
        }

        if (!writeFile(selectedFile->fullPath(), destinationPath)) {
            finish(false);
            return false;
        }
        addedEntries++;
        emit progress(float(addedEntries)/float(totalCount));

        // For directories, write all subfiles/folders.
        const QString &fullPath = selectedFile->fullPath();
        if (QFileInfo(fullPath).isDir()) {
            QDirIterator it(fullPath,
                            QDir::AllEntries | QDir::Readable |
                            QDir::Hidden | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories);

            while (!QThread::currentThread()->isInterruptionRequested() && it.hasNext()) {
                QString path = it.next();

                if ((it.fileName() == QLatin1String("..")) ||
                    (it.fileName() == QLatin1String("."))) {
                    continue;
                }

                const bool isRealDir = it.fileInfo().isDir() && !it.fileInfo().isSymLink();

                if (isRealDir) {
                    path.append(QLatin1Char('/'));
                }

                if (!writeFile(path, destinationPath)) {
                    finish(false);
                    return false;
                }
                addedEntries++;
                emit progress(float(addedEntries)/float(totalCount));
            }
        }
    }
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::findPlugins(QString(), [](const KPluginMetaData& metaData) {
        return metaData.pluginId() == QStringLiteral("arkpart") &&
               metaData.serviceTypes().contains(QStringLiteral("KParts/ReadOnlyPart")) &&
               metaData.serviceTypes().contains(QStringLiteral("Browser/View"));
    });
```

#### AUTO 


```{c}
const auto readBytes = zip_fread(zf, buf, 1000);
```

#### RANGE FOR STATEMENT 


```{c}
for (Entry *entry : qAsConst(m_entries)) {
        if (entry && (entry->name() == name)) {
            return entry;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *, const QString &title, const QPair<QString, QString> &field1, const QPair<QString, QString> &) {
            Q_EMIT description(this, title, field1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("Kerfuffle/Plugin")) &&
               metaData.rawData()[QStringLiteral("X-KDE-Kerfuffle-ReadWrite")].toVariant().toBool();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, prevFile]() {
            slotWatchedFileModified(prevFile);
        }
```

#### AUTO 


```{c}
auto fileNameLineEdit = dialog->findChild<QLineEdit*>(QStringLiteral("filenameLineEdit"));
```

#### AUTO 


```{c}
const auto jsonList = json.toList();
```

#### AUTO 


```{c}
const auto topLevelWidgets = qApp->topLevelWidgets();
```

#### AUTO 


```{c}
constexpr auto needleView(Arg &&a) const noexcept
            -> decltype(this->view(std::forward<Arg>(a)))
        { return this->view(std::forward<Arg>(a)); }
```

#### AUTO 


```{c}
const auto plugins = availableWritePlugins();
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *entry : m_entries) {
        totalUncompressedSize += entry->size();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg](int result) {
        if (result == QDialog::Accepted) {
            openUrl(dlg->selectedUrls().first());
        }
        dlg->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData& metaData : qAsConst(m_plugins)) {
        QVERIFY(!metaData.mimeTypes().isEmpty());

        const QJsonObject json = metaData.rawData();
        QVERIFY(json.keys().contains(QLatin1String("X-KDE-Priority")));
        QVERIFY(json.keys().contains(QLatin1String("KPlugin")));

        if (json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadOnlyExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadOnlyExecutables")].isArray());
        }

        if (json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadWriteExecutables"))) {
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWriteExecutables")].isArray());

            // If there is a list of read-write executables, the plugin has to be read-write.
            QVERIFY(json.keys().contains(QLatin1String("X-KDE-Kerfuffle-ReadWrite")));
            QVERIFY(json[QStringLiteral("X-KDE-Kerfuffle-ReadWrite")].toBool());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[exec, urls, parent]() {
        KService::Ptr service(new KService(QStringLiteral("ark"), exec, QString()));
        KIO::ApplicationLauncherJob *job = new KIO::ApplicationLauncherJob(service);
        job->setUrls(urls);
        job->setUiDelegate(new KDialogJobUiDelegate(KJobUiDelegate::AutoHandlingEnabled, parent));
        job->start();
    }
```

#### AUTO 


```{c}
auto loadJob = Archive::load(archive->fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (Archive::Entry *e : qAsConst(m_newMovedFiles)) {
            emit entry(e);
        }
```

#### AUTO 


```{c}
const auto args = substituteTestVariables(m_param.value(TestArgs).toStringList(), password());
```

