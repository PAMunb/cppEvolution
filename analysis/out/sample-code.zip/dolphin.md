#### AUTO 


```{c}
const auto widget
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_currentView->setSortOrder(Qt::AscendingOrder);
    }
```

#### AUTO 


```{c}
auto applyButton = buttonBox->button(QDialogButtonBox::Apply);
```

#### AUTO 


```{c}
const auto &pair
```

#### RANGE FOR STATEMENT 


```{c}
for (DolphinViewContainer *viewContainer : theViewContainers) {

        // Only consider local dirs, not remote locations and abstract protocols
        if (viewContainer->url().isLocalFile()) {
            if (!QFileInfo::exists(viewContainer->url().toLocalFile())) {
                viewContainer->setUrl(QUrl::fromLocalFile(QDir::homePath()));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        urls.append(item.url());
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (KItemListWidget *newHoveredWidget = widgetForPos(pos); newHoveredWidget) {
        // something got hovered, work out which part and set hover for the appropriate widget
        const auto mappedPos = newHoveredWidget->mapFromItem(m_view, pos);
        const bool isOnExpansionToggle = newHoveredWidget->expansionToggleRect().contains(mappedPos);

        if (isOnExpansionToggle) {
            // make sure we unhover the old one first if old!=new
            if (oldHoveredExpansionWidget && *oldHoveredExpansionWidget != newHoveredWidget) {
                (*oldHoveredExpansionWidget)->setExpansionAreaHovered(false);
            }
            // we also unhover any old icon+text hovers, in case the mouse movement from icon+text to expansion toggle is too fast (i.e. newHoveredWidget is never null between the transition)
            unhoverOldHoveredWidget();


            newHoveredWidget->setExpansionAreaHovered(true);
        } else {
            // make sure we unhover the old one first if old!=new
            if (auto oldHoveredWidget = hoveredWidget(); oldHoveredWidget && oldHoveredWidget != newHoveredWidget) {
                oldHoveredWidget->setHovered(false);
                Q_EMIT itemUnhovered(oldHoveredWidget->index());
            }
            // we also unhover any old expansion toggle hovers, in case the mouse movement from expansion toggle to icon+text is too fast (i.e. newHoveredWidget is never null between the transition)
            unhoverOldExpansionWidget();

            const bool isOverIconAndText = newHoveredWidget->iconRect().contains(mappedPos) || newHoveredWidget->textRect().contains(mappedPos);
            const bool hasMultipleSelection = m_selectionManager->selectedItems().count() > 1;

            if (hasMultipleSelection && !isOverIconAndText) {
                // In case we have multiple selections, clicking on any row will deselect the selection.
                // So, as a visual cue for signalling that clicking anywhere won't select, but clear current highlights,
                // we disable hover of the *row*(i.e. blank space to the right of the icon+text)

                // (no-op in this branch for masked hover)
            } else {
                newHoveredWidget->setHovered(true);
                newHoveredWidget->setHoverPosition(mappedPos);
                Q_EMIT itemHovered(newHoveredWidget->index());
            }
        }
    } else {
        // unhover any currently hovered expansion and text+icon widgets
        unhoverOldHoveredWidget();
        unhoverOldExpansionWidget();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : files) {
        const QUrl dir(url.adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash));
        if (!dirs.contains(dir)) {
            dirs.append(dir);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        const QUrl itemUrl = m_model->placesItem(index)->url();
        if (itemUrl.isValid()) {
            urls << itemUrl;
        }
        stream << index;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        bool urlFound = false;
        for (auto& interface: dolphinInterfaces) {
            auto isUrlOpenReply = interface.first->isUrlOpen(url);
            isUrlOpenReply.waitForFinished();
            if (!isUrlOpenReply.isError() && isUrlOpenReply.value()) {
                interface.second.append(url);
                urlFound = true;
                break;
            }
        }
        if (!urlFound) {
            newUrls.append(url);
        }
    }
```

#### AUTO 


```{c}
const auto &plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_visibleRoles)) {
        const qreal preferredWidth = m_headerWidget->preferredColumnWidth(role);
        m_headerWidget->setColumnWidth(role, preferredWidth);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        v->load();
    }
```

#### AUTO 


```{c}
auto mimeType = QMimeDatabase().mimeTypeForName(commonMimeType);
```

#### AUTO 


```{c}
const auto &device
```

#### AUTO 


```{c}
auto propsGrid = new QWidget(this);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout{navigatorWidget};
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tag : m_searchTags) {
            terms << QStringLiteral("tag:%1").arg(tag);
        }
```

#### AUTO 


```{c}
auto extensionIndex = text.lastIndexOf('.');
```

#### AUTO 


```{c}
const auto link = m_activeViewContainer->view()->selectedItems().at(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tagName : qAsConst(allTags)) {
        QAction* action = m_tagsSelector->menu()->addAction(QIcon::fromTheme(QStringLiteral("tag")), tagName);
        action->setCheckable(true);
        action->setChecked(m_searchTags.contains(tagName));

        connect(action, &QAction::triggered, this, [this, tagName, onlyOneTag](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            Q_EMIT facetChanged();

            if (!onlyOneTag) {
                m_tagsSelector->menu()->show();
            }
        });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, moreSearchToolsButton]()
    {
        m_menuFactory.reset(new KMoreToolsMenuFactory("dolphin/search-tools"));
        moreSearchToolsButton->menu()->clear();
        m_menuFactory->fillMenuFromGroupingNames(moreSearchToolsButton->menu(), { "files-find" }, this->m_searchPath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[konsoleInstallUrl]() {
                    QDesktopServices::openUrl(konsoleInstallUrl);
                }
```

#### AUTO 


```{c}
const auto actions = actionMenu->menu()->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& interface: qAsConst(dolphinInterfaces)) {
        if (!interface.second.isEmpty()) {
            auto reply = openFiles ? interface.first->openFiles(interface.second, splitView) : interface.first->openDirectories(interface.second, splitView);
            reply.waitForFinished();
            if (!reply.isError()) {
                interface.first->activateWindow();
                attached = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto teardownAction = m_model->teardownAction(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : pluginServices) {
        const QString desktopEntryName = service->desktopEntryName();
        if (!isInServicesList(desktopEntryName)) {
            const bool checked = showGroup.readEntry(desktopEntryName, true);
            addRow(service->icon(), service->name(), desktopEntryName, checked);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fontWeight](auto &&v) {
        v->setFontWeight(fontWeight);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool isTrashEmpty){
                setIcon(isTrashEmpty ? QStringLiteral("user-trash") : QStringLiteral("user-trash-full"));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            m_recursiveDirectorySizeLimit->setEnabled(m_sizeOfContents->isChecked());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
        const int index = itemRange.index;
        const int count = itemRange.count;

        if (updateSizeHints) {
            m_sizeHintResolver->itemsChanged(index, count, roles);
            m_layouter->markAsDirty();

            if (!m_layoutTimer->isActive()) {
                m_layoutTimer->start();
            }
        }

        // Apply the changed roles to the visible item-widgets
        const int lastIndex = index + count - 1;
        for (int i = index; i <= lastIndex; ++i) {
            KItemListWidget* widget = m_visibleItems.value(i);
            if (widget) {
                widget->setData(m_model->data(i), roles);
            }
        }

        if (m_grouped && roles.contains(m_model->sortRole())) {
            // The sort-role has been changed which might result
            // in modified group headers
            updateVisibleGroupHeaders();
            doLayout(NoAnimation);
        }

        QAccessibleTableModelChangeEvent ev(this, QAccessibleTableModelChangeEvent::DataChanged);
        ev.setFirstRow(itemRange.index);
        ev.setLastRow(itemRange.index + itemRange.count);
        QAccessible::updateAccessibility(&ev);
    }
```

#### AUTO 


```{c}
const auto mime = QMimeDatabase().mimeTypeForFile(inputPath).name();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &filter){
        m_sortModel->setFilterFixedString(filter);
    }
```

#### AUTO 


```{c}
const auto tagTerms = [](const QString &tag) { return QStringList{QStringLiteral("tag:%1").arg(tag)}; };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : m_actionIds) {
                const QAction* action = m_actions->action(id);
                if (action) {
                    addRow(action->icon().name(), action->text(), id, entryVisible(id));
                }
            }
```

#### AUTO 


```{c}
auto menuItem
```

#### AUTO 


```{c}
auto navigatorWidget = new QWidget(m_splitter.get());
```

#### AUTO 


```{c}
auto *client
```

#### AUTO 


```{c}
auto subTermsMatchIterator = subTermsRegExp.globalMatch(text);
```

#### AUTO 


```{c}
auto args = QStringList{"--passivepopup", i18n("Dolphin service menu installation failed"), "15"};
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : widgets) {
        const QPointF mappedPos = widget->mapFromItem(m_view, pos);
        if (widget->contains(mappedPos) || widget->selectionRect().contains(mappedPos)) {
            return widget;
        }
    }
```

#### AUTO 


```{c}
auto state
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        insertedCount += range.count;
    }
```

#### AUTO 


```{c}
auto disableSessionManagement = [](QSessionManager &sm) {
            sm.setRestartHint(QSessionManager::RestartNever);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (DolphinUrlNavigator *urlNavigator : s_instances) {
            urlNavigator->setUrlEditable(GeneralSettings::editableUrl());
            urlNavigator->setShowFullPath(GeneralSettings::showFullPath());
            urlNavigator->setHomeUrl(Dolphin::homeUrl());
        }
```

#### AUTO 


```{c}
const auto mappedPos = row->mapFromItem(m_view, pos);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : services) {
        files << QStandardPaths::locate(QStandardPaths::GenericDataLocation, "kservices5/" % service->entryPath());
    }
```

#### AUTO 


```{c}
const auto filelightService = KService::serviceByDesktopName("org.kde.filelight");
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { if (job->error()) emit errorMessage(job->errorString()); }
```

#### AUTO 


```{c}
auto zoomFactor = qExp(m_zoomLevel / 13.0);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagName](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            emit facetChanged();

            m_tagsSelector->menu()->show();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        const ItemData* itemData = m_itemData.at(index);
        const ItemData* parent = itemData->parent;

        while (parent && parent != lastAddedItem) {
            parent = parent->parent;
        }

        if (parent && parent == lastAddedItem) {
            // A parent of 'itemData' has been added already.
            continue;
        }

        lastAddedItem = itemData;
        const KFileItem& item = itemData->item;
        if (!item.isNull()) {
            urls << item.targetUrl();

            bool isLocal;
            mostLocalUrls << item.mostLocalUrl(isLocal);
            if (!isLocal) {
                canUseMostLocalUrls = false;
            }
        }
    }
```

#### AUTO 


```{c}
auto leadingSpacing = new QWidget{navigatorWidget};
```

#### LAMBDA EXPRESSION 


```{c}
[](QSessionManager &sm) {
            sm.setRestartHint(QSessionManager::RestartNever);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : files) {
        if (m_shownUrl == QUrl::fromUserInput(fileName)) {
            showItemInfo();
            break;
        }
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
            bool needsResorting = false;

            const int first = range.index;
            const int last = range.index + range.count - 1;

            // Resorting the model is necessary if
            // (a)  The first item in the range is "lessThan" its predecessor,
            // (b)  the successor of the last item is "lessThan" the last item, or
            // (c)  the internal order of the items in the range is incorrect.
            if (first > 0
                && lessThan(m_itemData.at(first), m_itemData.at(first - 1), m_collator)) {
                needsResorting = true;
            } else if (last < count() - 1
                && lessThan(m_itemData.at(last + 1), m_itemData.at(last), m_collator)) {
                needsResorting = true;
            } else {
                for (int index = first; index < last; ++index) {
                    if (lessThan(m_itemData.at(index + 1), m_itemData.at(index), m_collator)) {
                        needsResorting = true;
                        break;
                    }
                }
            }

            if (needsResorting) {
                m_resortAllItemsTimer->start();
                return;
            }
        }
```

#### AUTO 


```{c}
auto distance = std::distance(rangeBegin, rangeEnd);
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces, this](bool checked){
        actionShowAllPlaces->setIcon(QIcon::fromTheme(checked ? QStringLiteral("visibility") : QStringLiteral("hint")));
        m_placesPanel->showHiddenEntries(checked);
    }
```

#### AUTO 


```{c}
auto urlNavigator = new DolphinUrlNavigator(navigatorWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : roles) {
            m_data[role] = data[role];
        }
```

#### AUTO 


```{c}
auto factory = new KXMLGUIFactory(m_konsolePart->clientBuilder(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : visibleRoles) {
                const QString& text = roleText(role, values);
                const qreal requiredWidth = fontMetrics.horizontalAdvance(text);
                maximumRequiredWidth = qMax(maximumRequiredWidth, requiredWidth);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QDBusPendingCallWatcher* watcher) {
        watcher->deleteLater();
        if (reply.isError()) {
            // KIOFuse errored out... just show the normal URL
            emit changeUrl(url);
        } else {
            // Our location happens to be in a KIOFuse mount and is mounted.
            // Let's change the DolphinView to point to the remote URL equivalent.
            emit changeUrl(QUrl::fromUserInput(reply.value()));
        }
    }
```

#### AUTO 


```{c}
const auto mappedPos = newHoveredWidget->mapFromItem(m_view, pos);
```

#### AUTO 


```{c}
const auto startFilelightDirectoryAction = addAction(i18nc("@action:inmenu %1 service name", "%1 - current folder", filelightService->genericName()));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : actions) {
        menu.addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& interface: dolphinInterfaces) {
        if (!interface.second.isEmpty()) {
            auto reply = openFiles ? interface.first->openFiles(interface.second, splitView) : interface.first->openDirectories(interface.second, splitView);
            reply.waitForFinished();
            if (!reply.isError()) {
                interface.first->activateWindow();
                attached = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        const ItemData* itemData = m_itemData.at(index);
        const ItemData* parent = itemData->parent;

        while (parent && parent != lastAddedItem) {
            parent = parent->parent;
        }

        if (parent && parent == lastAddedItem) {
            // A parent of 'itemData' has been added already.
            continue;
        }

        lastAddedItem = itemData;
        const KFileItem& item = itemData->item;
        if (!item.isNull()) {
            urls << item.url();

            bool isLocal;
            mostLocalUrls << item.mostLocalUrl(isLocal);
            if (!isLocal) {
                canUseMostLocalUrls = false;
            }
        }
    }
```

#### AUTO 


```{c}
const auto& matchedPlaces = placesModel->match(placesModel->index(0,0), KFilePlacesModel::UrlRole, url, 1, Qt::MatchExactly);
```

#### AUTO 


```{c}
const auto iPadding = 2.0 * padding;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { if (job->error()) Q_EMIT errorMessage(job->errorString()); }
```

#### AUTO 


```{c}
auto res = subItemsCount(path, options);
```

#### AUTO 


```{c}
const auto tabPage = tabPageAt(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : mimeTypeToCommand) {
        if (pair.first.contains(mime)) {
            command = pair.second;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tagName : qAsConst(allTags)) {
        QAction* action = m_tagsSelector->menu()->addAction(QIcon::fromTheme(QStringLiteral("tag")), tagName);
        action->setCheckable(true);
        action->setChecked(m_searchTags.contains(tagName));

        connect(action, &QAction::triggered, this, [this, tagName](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            emit facetChanged();
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : itemSet) {
        result.insert(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& visibleRole : qAsConst(m_visibleRoles)) {
                qreal maxWidth = widths.value(visibleRole, 0);
                const qreal width = creator->preferredRoleColumnWidth(visibleRole, i, this);
                maxWidth = qMax(width, maxWidth);
                widths.insert(visibleRole, maxWidth);
            }
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto trashDirContentChanged = [this]() {
        bool isTrashEmpty = m_trashDirLister->items().isEmpty();
        emit emptinessChanged(isTrashEmpty);
    };
```

#### AUTO 


```{c}
const auto visibleRoles = m_view->visibleRoles();
```

#### AUTO 


```{c}
const auto dimensions = roleValue.toSize();
```

#### AUTO 


```{c}
auto roles = QSet<QByteArray>(visibleRoles.constBegin(), visibleRoles.constEnd());
```

#### AUTO 


```{c}
auto actionShowAllPlaces = new QAction(QIcon::fromTheme(QStringLiteral("hint")), i18nc("@item:inmenu", "Show Hidden Places"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AccessibleIdWrapper idWrapper : qAsConst(m_cells)) {
        if (idWrapper.isValid) {
            QAccessible::deleteAccessibleInterface(idWrapper.id);
        }
    }
```

#### AUTO 


```{c}
auto deleteShortcuts = m_action->shortcuts();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& interface: dolphinInterfaces) {
        if (!interface.second.isEmpty()) {
            interface.first->call(openFiles ? QStringLiteral("openFiles") : QStringLiteral("openDirectories"), interface.second, splitView);
            interface.first->call(QStringLiteral("activateWindow"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        const ItemData* itemData = m_itemData.at(index);
        const ItemData* parent = itemData->parent;

        while (parent && parent != lastAddedItem) {
            parent = parent->parent;
        }

        if (parent && parent == lastAddedItem) {
            // A parent of 'itemData' has been added already.
            continue;
        }

        lastAddedItem = itemData;
        const KFileItem& item = itemData->item;
        if (!item.isNull()) {
            urls << item.url();

            bool isLocal;
            mostLocalUrls << item.mostLocalUrl(&isLocal);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* child : childrenObjects) {
        DolphinDockWidget* dock = qobject_cast<DolphinDockWidget*>(child);
        if (dock) {
            dock->setLocked(newLockState);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QChar& c1, const QChar& c2) -> bool {
                    return m_collator.compare(c1, c2) < 0;
                }
```

#### AUTO 


```{c}
auto reply = openFiles ? interface.first->openFiles(newUrls, splitView) : interface.first->openDirectories(newUrls, splitView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : m_actionIds) {
            const QAction* action = m_actions->action(id);
            if (action) {
                addRow(action->icon().name(), action->text(), id, entryVisible(id));
            }
        }
```

#### AUTO 


```{c}
auto secondaryUrlNavigator = navigators->secondaryUrlNavigator()
```

#### RANGE FOR STATEMENT 


```{c}
for(const QModelIndex &sourceIndex : m_sourceModel->groupIndexes(group)) {
        PlacesItem *item = placesItem(mapFromSource(sourceIndex));
        if (item) {
            item->setGroupHidden(hidden);
        }
    }
```

#### AUTO 


```{c}
auto iteratorResult = m_urlListMatchesUrlCache.constFind(destUrl);
```

#### AUTO 


```{c}
const auto tabPage = tabPageAt(i);
```

#### AUTO 


```{c}
auto tabWidget = m_mainWindow->findChild<DolphinTabWidget*>("tabWidget");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& service: dolphinServices) {
            QDBusReply<bool> isUrlOpen = service.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpen.isValid() && isUrlOpen.value()) {
                service.second.append(url);
                urlFound = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : qAsConst(m_itemRanges)) {
        *it++ = range.index;
        *it++ = range.index + range.count;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& searchTerm : searchTerms) {
        m_facetsWidget->setRatingTerm(searchTerm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KOverlayIconPlugin *it : qAsConst(m_overlayIconsPlugin)) {
        overlays.append(it->getOverlays(item.url()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KNS3::Entry::List &changedEntries) {
           if (!changedEntries.isEmpty()) {
               m_serviceModel->clear();
               loadServices();
           }
    }
```

#### AUTO 


```{c}
const auto linkLocationDir = QFileInfo(link.localPath()).absoluteDir();
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : itemSet) {
        Q_ASSERT(result.contains(i));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : qAsConst(itemsToMove)) {
            KItemListWidget* widget = m_visibleItems.value(i);
            Q_ASSERT(widget);
            const int newIndex = i - count;
            if (hasMultipleRanges) {
                setWidgetIndex(widget, newIndex);
            } else {
                // Try to animate the moving of the item
                moveWidgetToIndex(widget, newIndex);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &destination, QDropEvent *event) {
        m_view->dropUrls(destination, event, urlNavigator->dropWidget());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &tag) { return QStringList{QStringLiteral("tag:%1").arg(tag)}; }
```

#### AUTO 


```{c}
const auto entry =  static_cast<KIO::StatJob *>(job)->statResult();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto menuItem : actions) {
        menuItem->setEnabled(isFolderWritable);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_columns)) {
            rx += m_columnWidths.value(role);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        QList<QUrl> selectedUrls;
        selectedUrls.reserve(m_selectedItems.count());
        for (const KFileItem &item : qAsConst(m_selectedItems)) {
            selectedUrls.append(item.url());
        }

        KIO::RestoreJob *job = KIO::restoreFromTrash(selectedUrls);
        KJobWidgets::setWindow(job, m_mainWindow);
        job->uiDelegate()->setAutoErrorHandlingEnabled(true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_activeViewContainer->view()->selectedItems()) {
        QUrl url = item.targetUrl();
        if (item.isFile()) {
            url.setPath(QFileInfo(url.path()).absolutePath());
        }
        if (!urls.contains(url)) {
            urls << url;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[kdiskfreeService](bool) {
            KRun::runService(*kdiskfreeService, { }, nullptr);
        }
```

#### AUTO 


```{c}
const auto roles = visibleRoles();
```

#### LAMBDA EXPRESSION 


```{c}
[destUrl](const QUrl& url) {
        return url.matches(destUrl, QUrl::StripTrailingSlash);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
            if (m_anchorItem < itemRange.index) {
                break;
            }
            inc += itemRange.count;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { updateVisibleIndexes(); }
```

#### AUTO 


```{c}
auto& service
```

#### LAMBDA EXPRESSION 


```{c}
[useDefaults](auto &&v) {
        v->useDefaults(useDefaults);
    }
```

#### AUTO 


```{c}
auto configurationWidget = previewPlugin->createConfigurationWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &widget) {
        return widget->expansionAreaHovered();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *client : guiClients) {
            if (client->actionCollection()->associatedWidgets().contains(m_terminalWidget)) {
                return client->actionCollection();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QUrl &url : urlsToExpand) {
            const int indexForUrl = index(url);
            if (indexForUrl >= 0) {
                m_urlsToExpand.remove(url);
                if (setExpanded(indexForUrl, true)) {
                    // The dir lister has been triggered. This slot will be called
                    // again after the directory has been expanded.
                    return;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& overlay : overlays) {
            if (!overlay.isEmpty()) {
                int state = KIconLoader::DefaultState;

                switch (mode) {
                case QIcon::Normal:
                    break;
                case QIcon::Active:
                    state = KIconLoader::ActiveState;
                    break;
                case QIcon::Disabled:
                    state = KIconLoader::DisabledState;
                    break;
                case QIcon::Selected:
                    state = KIconLoader::SelectedState;
                    break;
                }

                // There is at least one overlay, draw all overlays above m_pixmap
                // and cancel the check
                KIconLoader::global()->drawOverlays(overlays, pixmap, KIconLoader::Desktop, state);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : widgets) {
        const QPointF mappedPos = widget->mapFromItem(m_view, pos);

        const bool hovered = widget->contains(mappedPos) &&
                             !widget->expansionToggleRect().contains(mappedPos);
        if (hovered) {
            return widget;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& info : additionalInfo) {
            QString visibleRole = info;
            int index = visibleRole.indexOf('_');
            if (index >= 0 && index + 1 < visibleRole.length()) {
                ++index;
                if (visibleRole[index] == QLatin1Char('L')) {
                    visibleRole.replace(QLatin1String("LinkDestination"), QLatin1String("destination"));
                } else {
                    visibleRole[index] = visibleRole[index].toLower();
                }
            }
            if (!visibleRoles.contains(visibleRole)) {
                visibleRoles.append(visibleRole);
            }
        }
```

#### AUTO 


```{c}
auto *dialog = new QInputDialog(m_view);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : files) {
        removeFile(path);
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::Apply, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &sourceIndex : groupIndexes) {
        PlacesItem *item = placesItem(mapFromSource(sourceIndex));
        if (item) {
            item->setGroupHidden(hidden);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[useSystemFont](auto &&v) {
        v->setUseSystemFont(useSystemFont);
    }
```

#### AUTO 


```{c}
auto *placesModel = static_cast<KFilePlacesModel *>(model());
```

#### LAMBDA EXPRESSION 


```{c}
[applyButton](bool isDirty) {
        applyButton->setEnabled(isDirty);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewSettingsTab* tab : qAsConst(m_tabs)) {
        tab->restoreDefaultSettings();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](qreal sum, const auto &role){ return sum + columnWidth(role); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        const ItemData* itemData = m_itemData.at(index);
        const ItemData* parent = itemData->parent;

        while (parent && parent != lastAddedItem) {
            parent = parent->parent;
        }

        if (parent && parent == lastAddedItem) {
            // A parent of 'itemData' has been added already.
            continue;
        }

        lastAddedItem = itemData;
        const KFileItem& item = itemData->item;
        if (!item.isNull()) {
            urls << item.url();

            bool isLocal;
            mostLocalUrls << item.mostLocalUrl(isLocal);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_inConfigurationMode = false; }
```

#### AUTO 


```{c}
const auto serviceDir = getServiceMenusDir();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : qAsConst(m_selectedItems)) {
            const QUrl& url = DolphinView::openItemAsFolderUrl(item);
            if (url.isEmpty()) {
                selectionHasOnlyDirs = false;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        removedItemsCount += range.count;

        for (int index = range.index; index < range.index + range.count; ++index) {
            if (behavior == DeleteItemData) {
                delete m_itemData.at(index);
            }

            m_itemData[index] = nullptr;
        }
    }
```

#### AUTO 


```{c}
auto& interface
```

#### AUTO 


```{c}
auto *middleClickEventFilter = new MiddleClickActionEventFilter(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mimeType : qAsConst(m_mimeTypes)) {
        if (item.mimetype() == mimeType) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            // TODO: It would be great having a mechanism to tell PreviewJob that only previews
            // for a specific MIME-type should be regenerated. As this is not available yet we
            // delete the whole thumbnails directory.
            previewPlugin->writeConfiguration(configurationWidget);

            // https://specifications.freedesktop.org/thumbnail-spec/thumbnail-spec-latest.html#DIRECTORY
            const QString thumbnailsPath = QStandardPaths::writableLocation(QStandardPaths::GenericCacheLocation) + QLatin1String("/thumbnails/");
            KIO::del(QUrl::fromLocalFile(thumbnailsPath), KIO::HideProgressInfo);
        }
```

#### AUTO 


```{c}
const auto mime = mimeType(inputPath);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        QString text = roleText(role, values);

        // Elide the text in case it does not fit into the available column-width
        qreal requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        const qreal roleWidth = columnWidth(role);
        qreal availableTextWidth = roleWidth - columnWidthInc;

        const bool isTextRole = (role == "text");
        if (isTextRole) {
            availableTextWidth -= firstColumnInc - sidePadding();
        }

        if (requiredWidth > availableTextWidth) {
            text = elideRightKeepExtension(text, availableTextWidth);
            requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        }

        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);
        textInfo->pos = QPointF(x + columnWidthInc / 2, y);
        x += roleWidth;

        if (isTextRole) {
            const qreal textWidth = option.extendedSelectionRegion
                                    ? size().width() - textInfo->pos.x()
                                    : requiredWidth + 2 * option.padding;
            m_textRect = QRectF(textInfo->pos.x() - option.padding, 0,
                                textWidth, size().height());

            // The column after the name should always be aligned on the same x-position independent
            // from the expansion-level shown in the name column
            x -= firstColumnInc - sidePadding();
        } else if (isRoleRightAligned(role)) {
            textInfo->pos.rx() += roleWidth - requiredWidth - columnWidthInc;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        QPixmap pixmap = model()->data(index).value("iconPixmap").value<QPixmap>();
        if (pixmap.isNull()) {
            QIcon icon = QIcon::fromTheme(model()->data(index).value("iconName").toString());
            pixmap = icon.pixmap(size, size);
        } else {
            KPixmapModifier::scale(pixmap, QSize(size, size) * dpr);
        }

        painter.drawPixmap(x, y, pixmap);

        x += size + 1;
        if (x >= dragPixmap.width()) {
            x = 0;
            y += size + 1;
        }

        if (y >= dragPixmap.height()) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : widgets) {
        const QPointF mappedPos = widget->mapFromItem(m_view, pos);
        if (widget->contains(mappedPos)) {
            return widget;
        }
    }
```

#### AUTO 


```{c}
auto hamburgerMenu = static_cast<KHamburgerMenu *>(
                    ac->action(KStandardAction::name(KStandardAction::HamburgerMenu)));
```

#### AUTO 


```{c}
auto extensionWidth = m_customizedFontMetrics.width(text.right(extensionLength));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : dirs) {
        result.insert(dir);
    }
```

#### AUTO 


```{c}
auto secondaryNavigator = navigatorsWidget->secondaryUrlNavigator();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : visibleRoles) {
            const int width = header->columnWidth(role);
            columnWidths.append(width);
        }
```

#### AUTO 


```{c}
auto arrowSize = qMax(PLAY_ARROW_SIZE, maxDim / 8);
```

#### AUTO 


```{c}
auto localeAwareLessThan = [this](QChar c1, QChar c2) -> bool {
                    return m_collator.compare(c1, c2) < 0;
                };
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : itemSet) {
        testQVector.append(i);
    }
```

#### AUTO 


```{c}
auto additionalInfoBox = new KCollapsibleGroupBox();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemModel::RoleInfo& info : rolesInfo) {
        if (!isSortGroup && info.role == "text") {
            // It should not be possible to hide the "text" role
            continue;
        }

        KToggleAction* action = nullptr;
        const QString name = groupPrefix + info.role;
        if (info.group.isEmpty()) {
            action = m_actionCollection->add<KToggleAction>(name);
            action->setActionGroup(rolesActionGroup);
        } else {
            if (!groupMenu || info.group != groupName) {
                groupName = info.group;
                groupMenu = m_actionCollection->add<KActionMenu>(groupName);
                groupMenu->setText(groupName);
                groupMenu->setActionGroup(rolesActionGroup);

                groupMenuGroup = new QActionGroup(groupMenu);
                groupMenuGroup->setExclusive(isSortGroup);
                if (isSortGroup) {
                    connect(groupMenuGroup, &QActionGroup::triggered,
                            this, &DolphinViewActionHandler::slotSortTriggered);
                } else {
                    connect(groupMenuGroup, &QActionGroup::triggered,
                            this, &DolphinViewActionHandler::toggleVisibleRole);
                }
            }

            action = new KToggleAction(groupMenu);
            action->setActionGroup(groupMenuGroup);
            groupMenu->addAction(action);
        }
        action->setText(info.translation);
        action->setData(info.role);

        const bool enable = (!info.requiresBaloo && !info.requiresIndexer) ||
                            (info.requiresBaloo) ||
                            (info.requiresIndexer && indexingEnabled);
        action->setEnabled(enable);

        if (isSortGroup) {
            m_sortByActions.insert(info.role, action);
        } else {
            m_visibleRoles.insert(info.role, action);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& service : dbusServices) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            // Check if instance can handle our URLs
            QSharedPointer<OrgKdeDolphinMainWindowInterface> interface(
                        new OrgKdeDolphinMainWindowInterface(service,
                            QStringLiteral("/dolphin/Dolphin_1"),
                            QDBusConnection::sessionBus()));
            if (interface->isValid() && !interface->lastError().isValid()) {
                dolphinInterfaces.append(qMakePair(interface, QStringList()));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
        const int startIndex = itemRange.index;
        const int endIndex = startIndex + itemRange.count - 1;

        for (int i = startIndex; i <= endIndex; ++i) {
            for (const QByteArray& visibleRole : qAsConst(m_visibleRoles)) {
                qreal maxWidth = widths.value(visibleRole, 0);
                const qreal width = creator->preferredRoleColumnWidth(visibleRole, i, this);
                maxWidth = qMax(width, maxWidth);
                widths.insert(visibleRole, maxWidth);
            }

            if (calculatedItemCount > 100 && timer.elapsed() > 200) {
                // When having several thousands of items calculating the sizes can get
                // very expensive. We accept a possibly too small role-size in favour
                // of having no blocking user interface.
                maxTimeExceeded = true;
                break;
            }
            ++calculatedItemCount;
        }
        if (maxTimeExceeded) {
            break;
        }
    }
```

#### AUTO 


```{c}
auto isUrlOpenReply = interface.first->isUrlOpen(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* subAction : actions) {
                subAction->setChecked(false);
            }
```

#### AUTO 


```{c}
const auto tabPage = tabPageAt(viewLocation.first);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : visibleRolesGroupActions) {
        visibleRolesMenu->addAction(action);
    }
```

#### AUTO 


```{c}
const auto dest = QDir(serviceDir).absoluteFilePath(QFileInfo(archive).fileName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& searchTerm : searchTerms) {
        m_facetsWidget->setSearchTerm(searchTerm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : qAsConst(indexes)) {
            const KFileItem item = m_model->fileItem(index);
            if (!m_finishedItems.contains(item)) {
                m_pendingPreviewItems.append(item);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
        const QString pluginName = plugin.name();
        addRow(QStringLiteral("code-class"),
               pluginName,
               VersionControlServicePrefix + pluginName,
               enabledPlugins.contains(pluginName));
        loadedPlugins += pluginName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KHelpMenu::MenuId menuId, const QString &whatsThis) {
        if (auto *action = m_helpMenu->action(menuId)) {
            action->setWhatsThis(whatsThis);
        }
    }
```

#### AUTO 


```{c}
auto dir = QT_OPENDIR(QFile::encodeName(path));
```

#### AUTO 


```{c}
auto maxDim = qMax(p.width(), p.height());
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData* itemData : itemDataList) {
            if (m_filter.matches(itemData->item)) {
                m_pendingItemsToInsert.append(itemData);
            } else {
                m_filteredItems.insert(itemData->item, itemData);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        QString text = roleText(role, values);

        // Elide the text in case it does not fit into the available column-width
        qreal requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        const qreal roleWidth = columnWidth(role);
        qreal availableTextWidth = roleWidth - columnWidthInc;

        const bool isTextRole = (role == "text");
        if (isTextRole) {
            availableTextWidth -= firstColumnInc;
        }

        if (requiredWidth > availableTextWidth) {
            text = elideRightKeepExtension(text, availableTextWidth);
            requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        }

        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);
        textInfo->pos = QPointF(x + columnWidthInc / 2, y);
        x += roleWidth;

        if (isTextRole) {
            const qreal textWidth = option.extendedSelectionRegion
                                    ? size().width() - textInfo->pos.x()
                                    : requiredWidth + 2 * option.padding;
            m_textRect = QRectF(textInfo->pos.x() - option.padding, 0,
                                textWidth, size().height());

            // The column after the name should always be aligned on the same x-position independent
            // from the expansion-level shown in the name column
            x -= firstColumnInc;
        } else if (isRoleRightAligned(role)) {
            textInfo->pos.rx() += roleWidth - requiredWidth - columnWidthInc;
        }
    }
```

#### AUTO 


```{c}
static const auto map = QHash<Property, QByteArray> {
            { Property::Rating,            QByteArrayLiteral("rating") },
            { Property::Comment,           QByteArrayLiteral("comment") },
            { Property::Title,             QByteArrayLiteral("title") },
            { Property::WordCount,         QByteArrayLiteral("wordCount") },
            { Property::LineCount,         QByteArrayLiteral("lineCount") },
            { Property::Width,             QByteArrayLiteral("width") },
            { Property::Height,            QByteArrayLiteral("height") },
            { Property::ImageDateTime,     QByteArrayLiteral("imageDateTime") },
            { Property::ImageOrientation,  QByteArrayLiteral("orientation") },
            { Property::Artist,            QByteArrayLiteral("artist") },
            { Property::Genre,             QByteArrayLiteral("genre")  },
            { Property::Album,             QByteArrayLiteral("album") },
            { Property::Duration,          QByteArrayLiteral("duration") },
            { Property::BitRate,           QByteArrayLiteral("bitrate") },
            { Property::AspectRatio,       QByteArrayLiteral("aspectRatio") },
            { Property::FrameRate,         QByteArrayLiteral("frameRate") },
            { Property::ReleaseYear,       QByteArrayLiteral("releaseYear") },
            { Property::TrackNumber,       QByteArrayLiteral("track") }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[this](KHelpMenu::MenuId menuId) {
        if (auto *action = m_helpMenu->action(menuId)) {
            action->setShortcut(QKeySequence());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces] (bool checked){
        actionShowAllPlaces->setChecked(checked);
        actionShowAllPlaces->setIcon(QIcon::fromTheme(checked ? QStringLiteral("view-visible") : QStringLiteral("view-hidden")));
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pair : qAsConst(mimeTypeToCommand)) {
        if (pair.first.contains(mime)) {
            command = pair.second;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->viewFont();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : fileNames) {
        const KFileItem item(QUrl::fromLocalFile(prefix + name), QString(), KFileItem::Unknown);
        result << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->previewSize();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &file : qAsConst(files)) {
        const QList<KServiceAction> serviceActions = KDesktopFileActions::userDefinedServices(KService(file), true);

        const KDesktopFile desktopFile(file);
        const QString subMenuName = desktopFile.desktopGroup().readEntry("X-KDE-Submenu");

        for (const KServiceAction &action : serviceActions) {
            const QString serviceName = action.name();
            const bool addService = !action.noDisplay() && !action.isSeparator() && !isInServicesList(serviceName);

            if (addService) {
                const QString itemName = subMenuName.isEmpty()
                                         ? action.text()
                                         : i18nc("@item:inmenu", "%1: %2", subMenuName, action.text());
                const bool checked = showGroup.readEntry(serviceName, true);
                addRow(action.icon(), itemName, serviceName, checked);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
        if (index < itemRange.index) {
            break;
        }

        dec += itemRange.count;

        const int firstIndexAfterRange = itemRange.index + itemRange.count;
        if (index < firstIndexAfterRange) {
            // The index is part of the removed range
            if (behaviour == DiscardRemovedIndex) {
                return -1;
            } else {
                // Use the first item after the range as new index
                index = firstIndexAfterRange;
                break;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces, this]{
        actionShowAllPlaces->setEnabled(m_placesPanel->hiddenListCount());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        if (role == "text") {
            continue;
        }

        const QString text = roleText(role, values);
        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);

        qreal requiredWidth = 0;

        QTextLayout layout(text, m_customizedFont);
        QTextOption textOption;
        textOption.setWrapMode(QTextOption::NoWrap);
        layout.setTextOption(textOption);

        layout.beginLayout();
        QTextLine textLine = layout.createLine();
        if (textLine.isValid()) {
            textLine.setLineWidth(maxWidth);
            requiredWidth = textLine.naturalTextWidth();
            if (requiredWidth > maxWidth) {
                const QString elidedText = elideRightKeepExtension(text, maxWidth);
                textInfo->staticText.setText(elidedText);
                requiredWidth = m_customizedFontMetrics.horizontalAdvance(elidedText);
            } else if (role == "rating") {
                // Use the width of the rating pixmap, because the rating text is empty.
                requiredWidth = m_rating.width();
            }
        }
        layout.endLayout();

        textInfo->pos = QPointF(padding, y);
        textInfo->staticText.setTextWidth(maxWidth);

        const QRectF textRect(padding + (maxWidth - requiredWidth) / 2, y, requiredWidth, lineSpacing);
        m_textRect |= textRect;

        y += lineSpacing;
    }
```

#### AUTO 


```{c}
auto rangeEnd = std::find_if(rangeBegin, propMap.constKeyValueEnd(),
            [key](const entry& e) { return e.first != key; });
```

#### AUTO 


```{c}
auto valueA = a->values.value("count");
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : widgets) {
        if (widget->isHovered()) {
            return widget;
        }
    }
```

#### AUTO 


```{c}
const auto &dir
```

#### AUTO 


```{c}
const auto job = KIO::statDetails(m_model->rootItem().url(), KIO::StatJob::SourceSide, KIO::StatRecursiveSize);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& s1, const QString& s2){ return coll.compare(s1, s2) < 0; }
```

#### AUTO 


```{c}
const auto topLevelWidgets = QApplication::topLevelWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        slotTearDownRequested(index);
    }
```

#### AUTO 


```{c}
auto renameAction = KStandardAction::renameFile(this, &DolphinViewActionHandler::slotRename, m_actionCollection);
```

#### AUTO 


```{c}
auto *storageAccess = static_cast<Solid::StorageAccess*>(sender());
```

#### AUTO 


```{c}
const auto& propMap = file.properties();
```

#### AUTO 


```{c}
auto ejectAction = m_model->ejectAction(index);
```

#### AUTO 


```{c}
auto helpMenu = m_helpMenu->menu();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& visibleRole : visibleRoles) {
        if (visibleRole.startsWith(prefix)) {
            const QByteArray role = visibleRole.right(visibleRole.length() - prefixLength).toLatin1();
            if (role != "text") {
                roles.append(role);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : files) {
        createFile(path);
    }
```

#### AUTO 


```{c}
auto fontFactor = option.fontMetrics.averageCharWidth() / 9.0;
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
                m_mainWindow->openNewTab(KIO::upUrl(m_fileInfo.url()));
            }
```

#### AUTO 


```{c}
auto installKonsoleAction = new QAction(i18n("Install Konsole"), this);
```

#### AUTO 


```{c}
const auto plugins = KPluginMetaData::findPlugins(QStringLiteral("kf5/overlayicon"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_metaDataWidget->setConfigurationMode(Baloo::ConfigurationMode::Accept);
                m_configureButtons->setVisible(false);
                m_configureLabel->setVisible(false);
                Q_EMIT configurationFinished();
            }
```

#### AUTO 


```{c}
auto *centeringLayout = new QVBoxLayout(m_container);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& service : services) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            // Check if instance can handle our URLs
            QSharedPointer<QDBusInterface> instance(
                new QDBusInterface(service,
                QStringLiteral("/dolphin/Dolphin_1"),
                QStringLiteral("org.kde.dolphin.MainWindow"))
            );
            if (!instance->isValid()) {
                continue;
            }
            dolphinServices.append(qMakePair(instance, QStringList()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData* itemData : qAsConst(itemDataList)) {
            if (itemData->values.isEmpty()) {
                const KFileItem item = itemData->item;
                if (item.isDir() || item.isMimeTypeKnown()) {
                    itemData->values = retrieveData(itemData->item, itemData->parent);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        QPixmap pixmap = model()->data(index).value("iconPixmap").value<QPixmap>();
        if (pixmap.isNull()) {
            QIcon icon = QIcon::fromTheme(model()->data(index).value("iconName").toString());
            if (icon.isNull()) {
                icon = QIcon::fromTheme("unknown");
            }
            if (!icon.isNull()) {
                pixmap = icon.pixmap(size, size);
            } else {
                pixmap = QPixmap(size, size);
                pixmap.fill(Qt::transparent);
            }
        } else {
            KPixmapModifier::scale(pixmap, QSize(size, size) * dpr);
        }

        painter.drawPixmap(x, y, pixmap);

        x += size + 1;
        if (x >= dragPixmap.width()) {
            x = 0;
            y += size + 1;
        }

        if (y >= dragPixmap.height()) {
            break;
        }
    }
```

#### AUTO 


```{c}
const auto row = m_view->m_visibleItems.value(m_pressedIndex.value());
```

#### LAMBDA EXPRESSION 


```{c}
[this, mountPath]() {
        setViewsToHomeIfMountPathOpen(mountPath);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[urlNavigator, this]() {
        // Update URL navigator to show a server URL entry placeholder text if we
        // just loaded the remote:/ page, to make it easier for users to figure out
        // that they can enter arbitrary remote URLs. See bug 414670
        if (urlNavigator->locationUrl().scheme() == QLatin1String("remote")) {
            if (!urlNavigator->isUrlEditable()) {
                urlNavigator->setUrlEditable(true);
            }
            urlNavigator->clearText();
            urlNavigator->setPlaceholderText(i18n("Enter server URL (e.g. smb://[ip address])"));
        } else {
            urlNavigator->setPlaceholderText(QString());
        }

        // We have to wait for DolphinUrlNavigator::sizeHint() to update which
        // happens a little bit later than when urlChanged is emitted.
        this->m_adjustSpacingTimer->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *groupAction : qAsConst(m_sortByActions)) {
        KActionMenu* actionMenu = qobject_cast<KActionMenu*>(groupAction);
        if (actionMenu) {
            foreach (QAction* subAction, actionMenu->menu()->actions()) {
                subAction->setChecked(false);
            }
        } else if (groupAction->actionGroup()) {
            groupAction->setChecked(false);
        }
    }
```

#### AUTO 


```{c}
const auto& matchedPlaces = s_placesModel.match(s_placesModel.index(0,0), KFilePlacesModel::UrlRole, url, 1, Qt::MatchExactly);
```

#### AUTO 


```{c}
const auto extensionIndex = text.lastIndexOf('.');
```

#### LAMBDA EXPRESSION 


```{c}
[factory, this] {
                    factory->removeClient(m_konsolePart);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewSettingsTab* tab : qAsConst(m_tabs)) {
        tab->applySettings();
    }
```

#### AUTO 


```{c}
auto newFileMenu = m_mainWindow->findChild<DolphinNewFileMenu*>("new_menu");
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        for (int i = range.index; i < range.index + range.count; ++i) {
            result.append(i);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->useSystemFont();
    }
```

#### AUTO 


```{c}
auto moreSearchToolsButton = new QToolButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        resetSearchTags();
        Q_EMIT facetChanged();
    }
```

#### AUTO 


```{c}
const auto filelightIcon = QIcon::fromTheme(filelightService->icon());
```

#### RANGE FOR STATEMENT 


```{c}
for (SettingsPageBase* page : qAsConst(m_pages)) {
        page->applySettings();
    }
```

#### AUTO 


```{c}
const auto dirs = m_expandedDirs;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        for (int i = range.index; i < range.index + range.count; ++i) {
            result.insert(i);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        Trash::empty(m_mainWindow);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget* widget : widgets) {
        QMenu* menu = qobject_cast<QMenu*>(widget);
        if (menu) {
            connect(menu, &QMenu::aboutToShow, this, &DolphinMainWindow::updateOpenPreferredSearchToolAction);
        }
    }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"));
    });
```

#### AUTO 


```{c}
auto res = walkDir(QFile::encodeName(path), countHiddenFiles, countDirectoriesOnly, dirEntry, maxRecursiveLevel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : visibleRoles) {
                columnWidths.append(header->columnWidth(role));
            }
```

#### AUTO 


```{c}
auto root = plugin->localRepositoryRoot(directory.path());
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        QPixmap pixmap = model()->data(index).value("iconPixmap").value<QPixmap>();
        if (pixmap.isNull()) {
            QIcon icon = QIcon::fromTheme(model()->data(index).value("iconName").toString());
            if (!icon.isNull()) {
                pixmap = icon.pixmap(size, size);
            } else {
                pixmap = QPixmap(size, size);
                pixmap.fill(Qt::transparent);
            }
        } else {
            KPixmapModifier::scale(pixmap, QSize(size, size) * dpr);
        }

        painter.drawPixmap(x, y, pixmap);

        x += size + 1;
        if (x >= dragPixmap.width()) {
            x = 0;
            y += size + 1;
        }

        if (y >= dragPixmap.height()) {
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filelightService, url](bool) {
                KMountPoint::Ptr mountPoint = KMountPoint::currentMountPoints().findByPath(url.toLocalFile());
                KRun::runService(*filelightService, { mountPoint->mountPoint() }, nullptr);
            }
```

#### AUTO 


```{c}
auto deleteShortcuts = deleteAction->shortcuts();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : changedItems) {
        const int index = m_model->index(item);

        if (index < 0) {
            m_changedItems.remove(item);
            continue;
        }

        if (index >= m_firstVisibleIndex && index <= m_lastVisibleIndex) {
            visibleChangedIndexes.append(index);
        } else {
            invisibleChangedIndexes.append(index);
        }
    }
```

#### AUTO 


```{c}
const auto widgets = m_view->visibleItemListWidgets();
```

#### AUTO 


```{c}
const auto urlsToExpand = m_urlsToExpand;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        bool isTrashEmpty = m_trashDirLister->items().isEmpty();
        Q_EMIT emptinessChanged(isTrashEmpty);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DolphinUrlNavigator *urlNavigator : s_instances)
        {
            urlNavigator->editor()->setCompletionMode(completionMode);
        }
```

#### AUTO 


```{c}
auto newFileMenu = m_mainWindow->findChild<DolphinNewFileMenu*>("newFileMenu");
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item : qAsConst(m_selectedItems)) {
            selectedUrls.append(item.url());
        }
```

#### AUTO 


```{c}
auto trailingSpacing = new QWidget{navigatorWidget};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        QString text = roleText(role, values);

        // Elide the text in case it does not fit into the available column-width
        qreal requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        const qreal roleWidth = columnWidth(role);
        qreal availableTextWidth = roleWidth - columnWidthInc;

        const bool isTextRole = (role == "text");
        if (isTextRole) {
            availableTextWidth -= firstColumnInc - leadingPadding();
        }

        if (requiredWidth > availableTextWidth) {
            text = elideRightKeepExtension(text, availableTextWidth);
            requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        }

        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);
        textInfo->pos = QPointF(x + columnWidthInc / 2, y);
        x += roleWidth;

        if (isTextRole) {
            const qreal textWidth = option.extendedSelectionRegion
                                    ? size().width() - textInfo->pos.x()
                                    : requiredWidth + 2 * option.padding;
            m_textRect = QRectF(textInfo->pos.x() - option.padding, 0,
                                textWidth, size().height());

            // The column after the name should always be aligned on the same x-position independent
            // from the expansion-level shown in the name column
            x -= firstColumnInc - leadingPadding();
        } else if (isRoleRightAligned(role)) {
            textInfo->pos.rx() += roleWidth - requiredWidth - columnWidthInc;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : QUrl::toStringList(urls)) {
        bool urlFound = false;
        for (auto& service: dolphinServices) {
            QDBusReply<bool> isUrlOpen = service.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpen.isValid() && isUrlOpen.value()) {
                    service.second.append(url);
                    urlFound = true;
                    break;
            }
        }
        if (!urlFound) {
            newUrls.append(url);
        }
    }
```

#### AUTO 


```{c}
const auto &it
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QDBusPendingCallWatcher* watcher) {
            watcher->deleteLater();
            if (!reply.isError()) {
                // Successfully mounted, point to the KIOFuse equivalent path.
                sendCdToTerminal(reply.value());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        bool urlFound = false;
        for (auto& interface: dolphinInterfaces) {
            QDBusReply<bool> isUrlOpenReply = interface.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpenReply.isValid() && isUrlOpenReply.value()) {
                interface.second.append(url);
                urlFound = true;
                break;
            }
        }
        if (!urlFound) {
            newUrls.append(url);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->save();
    }
```

#### AUTO 


```{c}
auto instance = QPluginLoader(data.fileName()).instance();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& info : additionalInfo) {
            QString visibleRole = info;
            int index = visibleRole.indexOf('_');
            if (index >= 0 && index + 1 < visibleRole.length()) {
                ++index;
                if (visibleRole[index] == QLatin1Char('L')) {
                    visibleRole.replace(QLatin1String("LinkDestination"), QLatin1String("destination"));
                } else {
                    visibleRole[index] = visibleRole[index].toLower();
                }
            }
            visibleRoles.append(visibleRole);
        }
```

#### AUTO 


```{c}
const auto unhoverOldHoveredWidget = [&]() {
        if (auto oldHoveredWidget = hoveredWidget(); oldHoveredWidget) {
            // handle the text+icon one
            oldHoveredWidget->setHovered(false);
            Q_EMIT itemUnhovered(oldHoveredWidget->index());
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : argVariants) {
            if (runScriptOnce(path, {arg})) {
                return true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, groupType, hideGroupAction]{
        m_model->setGroupHidden(groupType, hideGroupAction->isChecked());
    }
```

#### AUTO 


```{c}
auto bookmark = m_model->placesItem(tempDirIndex)->bookmark();
```

#### AUTO 


```{c}
auto helpMenu = new KHelpMenu(menu);
```

#### AUTO 


```{c}
auto trashShortcuts = m_action->shortcuts();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_visibleRoles)) {
        widget->setColumnWidth(role, m_headerWidget->columnWidth(role));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        removedItemsCount += range.count;

        for (int index = range.index; index < range.index + range.count; ++index) {
            if (behavior == DeleteItemData || (behavior == DeleteItemDataIfUnfiltered && !m_filteredItems.contains(m_itemData.at(index)->item))) {
                delete m_itemData.at(index);
            }

            m_itemData[index] = nullptr;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemList) {
        const QUrl originalURL  = item.url();
        const QString originalDirectoryPath = originalURL.adjusted(QUrl::RemoveFilename).path();
        const QString originalFileName = item.name();

        QString extension = db.suffixForFileName(originalFileName);

        QUrl duplicateURL = originalURL;

        // No extension; new filename is "<oldfilename> copy"
        if (extension.isEmpty()) {
            duplicateURL.setPath(originalDirectoryPath + i18nc("<filename> copy", "%1 copy", originalFileName));
        // There's an extension; new filename is "<oldfilename> copy.<extension>"
        } else {
            // Need to add a dot since QMimeDatabase::suffixForFileName() doesn't include it
            extension = QLatin1String(".") + extension;
            const QString originalFilenameWithoutExtension = originalFileName.chopped(extension.size());
            // Preserve file's original filename extension in case the casing differs
            // from what QMimeDatabase::suffixForFileName() returned
            const QString originalExtension = originalFileName.right(extension.size());
            duplicateURL.setPath(originalDirectoryPath + i18nc("<filename> copy", "%1 copy", originalFilenameWithoutExtension) + originalExtension);
        }

        KIO::CopyJob* job = KIO::copyAs(originalURL, duplicateURL);
        KJobWidgets::setWindow(job, this);

        if (job) {
            newSelection << duplicateURL;
            KIO::FileUndoManager::self()->recordCopyJob(job);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        const int indexForItem = index(item);
        if (indexForItem >= 0) {
            indexesToRemove.append(indexForItem);
        } else {
            // Probably the item has been filtered.
            QHash<KFileItem, ItemData*>::iterator it = m_filteredItems.find(item);
            if (it != m_filteredItems.end()) {
                delete it.value();
                m_filteredItems.erase(it);
            }
        }

        QUrl parentUrl = item.url().adjusted(QUrl::RemoveFilename | QUrl::StripTrailingSlash);
        if (dirsChanged.findByUrl(parentUrl).isNull()) {
            dirsChanged << KFileItem(parentUrl);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : entries) {
        const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, "kservices5/" % service->entryPath());
        const QList<KServiceAction> serviceActions = KDesktopFileActions::userDefinedServices(KService(file), true);

        const KDesktopFile desktopFile(file);
        const QString subMenuName = desktopFile.desktopGroup().readEntry("X-KDE-Submenu");

        for (const KServiceAction &action : serviceActions) {
            const QString serviceName = action.name();
            const bool addService = !action.noDisplay() && !action.isSeparator() && !isInServicesList(serviceName);

            if (addService) {
                const QString itemName = subMenuName.isEmpty()
                                         ? action.text()
                                         : i18nc("@item:inmenu", "%1: %2", subMenuName, action.text());
                const bool checked = showGroup.readEntry(serviceName, true);
                addRow(action.icon(), itemName, serviceName, checked);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : previous) {
            if (index >= itemRange.index && index < itemRange.index + itemRange.count) {
                m_selectedItems.insert(movedToIndexes.at(index - itemRange.index));
            }
            else {
                m_selectedItems.insert(index);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &searchToken : searchTokens) {
            if (term.startsWith(searchToken)) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
            int index = itemRange.index;
            for (int count = itemRange.count; count > 0; --count) {
                const KFileItem item = m_model->fileItem(index);
                m_hoverSequenceLoadedItems.remove(item);
                ++index;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&font](auto &&v) {
        v->setViewFont(font);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
                m_mainWindow->changeUrl(KIO::upUrl(m_fileInfo.url()));
                m_mainWindow->activeViewContainer()->view()->markUrlsAsSelected({m_fileInfo.url()});
                m_mainWindow->activeViewContainer()->view()->markUrlAsCurrent(m_fileInfo.url());
            }
```

#### AUTO 


```{c}
const auto oldTitle = m_mainWindow->windowTitle();
```

#### AUTO 


```{c}
auto header = new QLabel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        KFileItem item = m_model->fileItem(index);
        const QUrl& url = openItemAsFolderUrl(item);

        if (!url.isEmpty()) { // Open folders in new tabs
            Q_EMIT tabRequested(url, DolphinTabWidget::AfterLastTab);
        } else {
            items.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointer<KVersionControlPlugin> &plugin : qAsConst(m_plugins)) {
        if (!plugin) {
            continue;
        }

        // first naively check if we are at working copy root
        const QString fileName = directory.path() + '/' + plugin->fileName();
        if (QFile::exists(fileName)) {
            m_localRepoRoot = directory.path();
            return plugin;
        }
        const QString root = plugin->localRepositoryRoot(directory.path());
        if (!root.isEmpty()) {
            m_localRepoRoot = root;
            return plugin;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
        showErrorMessage(errorMessage);
    }
```

#### AUTO 


```{c}
auto *delegate = new KNotificationJobUiDelegate;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : plugins) {
        auto instance = QPluginLoader(data.fileName()).instance();
        auto plugin = qobject_cast<KOverlayIconPlugin *>(instance);
        if (plugin) {
            m_overlayIconsPlugin.append(plugin);
            connect(plugin, &KOverlayIconPlugin::overlaysChanged, this, &KFileItemModelRolesUpdater::slotOverlaysChanged);
        } else {
            // not our/valid plugin, so delete the created object
            delete instance;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : pluginServices) {
        const QString pluginName = plugin->name();
        if (loadedPlugins.contains(pluginName)) {
            continue;
        }
        addRow(QStringLiteral("code-class"),
               pluginName,
               VersionControlServicePrefix + pluginName,
               enabledPlugins.contains(pluginName));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filelightService](bool) {
            KRun::runService(*filelightService, { }, nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto const &tag : m_searchTags) {
            if (tag.contains(QLatin1Char(' '))) {
                terms << QStringLiteral("tag:\"%1\"").arg(tag);
            } else {
                terms << QStringLiteral("tag:%1").arg(tag);
            }
        }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto oldHoveredWidget = hoveredWidget(); oldHoveredWidget && oldHoveredWidget != newHoveredWidget) {
                oldHoveredWidget->setHovered(false);
                Q_EMIT itemUnhovered(oldHoveredWidget->index());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, listOpenFilesJob](KJob*) {
                const KProcessList::KProcessInfoList blockingProcesses = listOpenFilesJob->processInfoList();
                QString errorString;
                if (blockingProcesses.isEmpty()) {
                    errorString = i18n("One or more files on this device are open within an application.");
                } else {
                    QStringList blockingApps;
                    for (const auto& process : blockingProcesses) {
                        blockingApps << process.name();
                    }
                    blockingApps.removeDuplicates();
                    errorString = xi18np("One or more files on this device are opened in application <application>\"%2\"</application>.",
                            "One or more files on this device are opened in following applications: <application>%2</application>.",
                            blockingApps.count(), blockingApps.join(i18nc("separator in list of apps blocking device unmount", ", ")));
                }
                emit errorMessage(errorString);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        slotItemActivated(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &destination, QDropEvent *event) {
        m_view->dropUrls(destination, event, m_urlNavigator->dropWidget());
    }
```

#### AUTO 


```{c}
const auto stderrResult = QString::fromUtf8(process.readAllStandardError()).trimmed();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (auto oldHoveredWidget = hoveredWidget(); oldHoveredWidget) {
            // handle the text+icon one
            oldHoveredWidget->setHovered(false);
            Q_EMIT itemUnhovered(oldHoveredWidget->index());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QDBusPendingCallWatcher* watcher) {
        watcher->deleteLater();
        if (reply.isError()) {
            // KIOFuse errored out... just show the normal URL
            Q_EMIT changeUrl(url);
        } else {
            // Our location happens to be in a KIOFuse mount and is mounted.
            // Let's change the DolphinView to point to the remote URL equivalent.
            Q_EMIT changeUrl(QUrl::fromUserInput(reply.value()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& service: dolphinServices) {
            QDBusReply<bool> isUrlOpen = service.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpen.isValid() && isUrlOpen.value()) {
                    service.second.append(url);
                    urlFound = true;
                    break;
            }
        }
```

#### AUTO 


```{c}
auto backShortcuts = backAction->shortcuts();
```

#### AUTO 


```{c}
const auto visibleRoles = this->visibleRoles();
```

#### AUTO 


```{c}
const auto serviceName = isDaemon() ? QString() : QStringLiteral("org.kde.dolphin-%1").arg(QCoreApplication::applicationPid());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : customActions) {
            popup->addAction(action);
        }
```

#### AUTO 


```{c}
const auto tobeRemoved = m_tobeRemoved;
```

#### AUTO 


```{c}
auto &plugin
```

#### AUTO 


```{c}
const auto startFilelightDeviceAction = addAction(filelightService->genericName() + " - "
                                                    + i18nc("@action:inmenu", "current device"));
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->iconSize();
    }
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
            if (m_currentItem < itemRange.index) {
                break;
            }
            inc += itemRange.count;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        QString text = roleText(role, values);

        // Elide the text in case it does not fit into the available column-width
        qreal requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        const qreal roleWidth = columnWidth(role);
        qreal availableTextWidth = roleWidth - columnWidthInc;

        const QHash<QByteArray, QVariant> values = data();
        const int expandedParentsCount = values.value("expandedParentsCount", 0).toInt();
        const int expansionOffset = size().height() * expandedParentsCount;

        const bool isTextRole = (role == "text");
        if (isTextRole) {
            availableTextWidth -= firstColumnOffset - leadingPadding();
        }

        if (requiredWidth > availableTextWidth) {
            text = elideRightKeepExtension(text, availableTextWidth);
            requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        }

        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);
        textInfo->pos = QPointF(x - (layoutDirection() == Qt::LeftToRight ? 0 : firstColumnOffset), y);
        if (layoutDirection() == Qt::LeftToRight) {
            textInfo->pos.rx() += columnWidthInc/2 + expansionOffset;
        } else {
            textInfo->pos.rx() -= expansionOffset;
            if (textInfo->pos.x() < iconSize()) {
                textInfo->pos.rx() = iconSize();
            }
        }
        x += roleWidth;

        if (isTextRole) {
            const qreal textWidth = option.extendedSelectionRegion
                                    ? size().width() - textInfo->pos.x()
                                    : requiredWidth + 2 * option.padding;
            m_textRect = QRectF(textInfo->pos.x() - option.padding, 0,
                                textWidth, size().height());

            // The column after the name should always be aligned on the same x-position independent
            // from the expansion-level shown in the name column
            x -= firstColumnOffset - leadingPadding();
        } else if (isRoleRightAligned(role)) {
            textInfo->pos.rx() += roleWidth - requiredWidth - columnWidthInc;
        }
    }
```

#### AUTO 


```{c}
auto navigators = static_cast<DolphinNavigatorsWidgetAction *>
                          (actionCollection()->action(QStringLiteral("url_navigators")));
```

#### AUTO 


```{c}
auto configureMenu = menu->addMenu(QIcon::fromTheme(QStringLiteral("configure")),
                            i18nc("@action:inmenu menu for configure actions", "Configure"));
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::instantiatePlugins(QStringLiteral("kf5/overlayicon"), nullptr, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const KFileItemModel::ItemData* a, const KFileItemModel::ItemData* b)
            {
                const QByteArray role = roleForType(m_sortRole);
                return a->values.value(role).toString() < b->values.value(role).toString();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& var : previouslyExpandedChildren) {
            m_urlsToExpand.insert(var.toUrl());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemList) {
        const QUrl originalURL  = item.url();
        const QString originalFileName = item.name();
        QString extension = db.suffixForFileName(originalFileName);

        QUrl duplicateURL = originalURL;

        // No extension; new filename is "<oldfilename> copy"
        if (extension.isEmpty()) {
            duplicateURL.setPath(i18nc("<file path> copy", "%1 copy", originalURL.path()));
        // There's an extension; new filename is "<oldfilename> copy.<extension>"
        } else {
            // Need to add a dot since QMimeDatabase::suffixForFileName() doesn't include it
            extension = QLatin1String(".") + extension;
            const QString directoryPath = originalURL.adjusted(QUrl::RemoveFilename).path();
            const QString originalFilenameWithoutExtension = originalFileName.chopped(extension.size());
            // Preserve file's original filename extension in case the casing differs
            // from what QMimeDatabase::suffixForFileName() returned
            const QString originalExtension = originalFileName.right(extension.size());
            duplicateURL.setPath(i18nc("<file path><filename> copy.<extension>", "%1%2 copy%3", directoryPath, originalFilenameWithoutExtension, originalExtension));
        }

        KIO::CopyJob* job = KIO::copyAs(originalURL, duplicateURL, KIO::HideProgressInfo);
        KJobWidgets::setWindow(job, this);

        if (job) {
            newSelection << duplicateURL;
            KIO::FileUndoManager::self()->recordCopyJob(job);
        }
    }
```

#### AUTO 


```{c}
const auto& service
```

#### AUTO 


```{c}
const auto plugins = KPluginLoader::instantiatePlugins(QStringLiteral("kf5/overlayicon"), nullptr, qApp);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tabPage]() {
        const int tabIndex = indexOf(tabPage);
        Q_ASSERT(tabIndex >= 0);
        tabBar()->setTabText(tabIndex, tabName(tabPage));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &searchToken : searchTokens) {
            if (term.startsWith(searchToken)) {
                return searchToken;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces, this](bool checked){
        actionShowAllPlaces->setIcon(QIcon::fromTheme(checked ? QStringLiteral("view-visible") : QStringLiteral("view-hidden")));
        m_placesPanel->showHiddenEntries(checked);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : visibleItems) {
            const int i = widget->index();
            if (i < firstRemovedIndex) {
                continue;
            } else if (i > lastRemovedIndex) {
                itemsToMove.append(i);
                continue;
            }

            m_animation->stop(widget);
            // Stopping the animation might lead to recycling the widget if
            // it is invisible (see slotAnimationFinished()).
            // Check again whether it is still visible:
            if (!m_visibleItems.contains(i)) {
                continue;
            }

            if (m_model->count() == 0 || hasMultipleRanges || !animateChangedItemCount(count)) {
                // Remove the widget without animation
                recycleWidget(widget);
            } else {
                // Animate the removing of the items. Special case: When removing an item there
                // is no valid model index available anymore. For the
                // remove-animation the item gets removed from m_visibleItems but the widget
                // will stay alive until the animation has been finished and will
                // be recycled (deleted) in KItemListView::slotAnimationFinished().
                m_visibleItems.remove(i);
                widget->setIndex(-1);
                m_animation->start(widget, KItemListViewAnimation::DeleteAnimation);
            }
        }
```

#### AUTO 


```{c}
const auto actions = this->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem &item: items) {
        allTags.append(item.name());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KConfigGroup &group) {
        group.deleteEntry("FontFamily");
        group.deleteEntry("FontWeight");
        group.deleteEntry("ItalicFont");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_visibleRoles)) {
        widthsSum += m_headerWidget->columnWidth(role);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[key](const entry& e) { return e.first != key; }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : qAsConst(reusableItems)) {
        recycleWidget(m_visibleItems.value(index));
    }
```

#### AUTO 


```{c}
const auto paintPadding = [&](int section, const QRectF &rect, const QStyleOptionHeader::SectionPosition &pos){
        QStyleOptionHeader padding;
        padding.state = QStyle::State_None | QStyle::State_Raised | QStyle::State_Horizontal;
        padding.section = section;
        padding.sortIndicator = QStyleOptionHeader::None;
        padding.rect = rect.toRect();
        padding.position = pos;
        padding.text = QString();
        style()->drawControl(QStyle::CE_Header, &padding, painter, widget);
    };
```

#### AUTO 


```{c}
auto dolphinInterfaces = dolphinGuiInstances(preferredService);
```

#### AUTO 


```{c}
const auto uniqueKeys = indexesForUrl.uniqueKeys();
```

#### AUTO 


```{c}
auto dir = QT_OPENDIR(QFile::encodeName(dirPath));
```

#### AUTO 


```{c}
auto mountPoint = KMountPoint::currentMountPoints().findByPath(storageAccess->filePath());
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, i]() { m_tabWidget->activateTab(i); }
```

#### AUTO 


```{c}
const auto changedItems = m_changedItems;
```

#### AUTO 


```{c}
auto setHelpActionWhatsThis = [this](KHelpMenu::MenuId menuId, const QString &whatsThis) {
        if (auto *action = m_helpMenu->action(menuId)) {
            action->setWhatsThis(whatsThis);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_lastHandleUrlOpenJob = nullptr;
        }
```

#### AUTO 


```{c}
auto job = new KTerminalLauncherJob(QString());
```

#### AUTO 


```{c}
const auto unhoverOldExpansionWidget = [&]() {
        if (oldHoveredExpansionWidget) {
            // then the expansion toggle
            (*oldHoveredExpansionWidget)->setExpansionAreaHovered(false);
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool active) {
        if (active) {
            m_indicatorAnimation->setDuration(150);
            m_indicatorAnimation->setStartValue(QPointF(1, 1));
            m_indicatorAnimation->setEndValue(QPointF(40, 40));
            m_indicatorAnimation->start();
        }
        update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *groupName : {"CompactMode", "DetailsMode", "IconsMode"}) {
            KConfigGroup group = config->group(groupName);
            const QString family = group.readEntry("FontFamily", QString{});
            if (family.isEmpty()) {
                removeEntries(group);
                continue;
            }

            QFont font;
            font.setFamily(family);
            const int weight = group.readEntry<int>("FontWeight", QFont::Normal);
            font.setWeight(static_cast<QFont::Weight>(weight));
            font.setItalic(group.readEntry("ItalicFont", false));
            removeEntries(group);

            // Write the new config entry
            group.writeEntry("ViewFont", font);
        }
```

#### AUTO 


```{c}
const auto startKDiskFreeAction = addAction("KDiskFree" + notInstalled);
```

#### AUTO 


```{c}
const auto extensionLength = text.length() - extensionIndex;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemModel::RoleInfo& info : rolesInfo) {
        if (info.role == "text") {
            // It should not be possible to hide the "text" role
            continue;
        }

        const QString text = m_model->roleDescription(info.role);
        QAction* action = nullptr;
        if (info.group.isEmpty()) {
            action = menu->addAction(text);
        } else {
            if (!groupMenu || info.group != groupName) {
                groupName = info.group;
                groupMenu = menu->addMenu(groupName);
            }

            action = groupMenu->addAction(text);
        }

        action->setCheckable(true);
        action->setChecked(visibleRolesSet.contains(info.role));
        action->setData(info.role);

        const bool enable = (!info.requiresBaloo && !info.requiresIndexer) ||
                            (info.requiresBaloo) ||
                            (info.requiresIndexer && indexingEnabled);
        action->setEnabled(enable);
    }
```

#### AUTO 


```{c}
auto removeEntries = [](KConfigGroup &group) {
        group.deleteEntry("FontFamily");
        group.deleteEntry("FontWeight");
        group.deleteEntry("ItalicFont");
    };
```

#### AUTO 


```{c}
auto qsg = qScopeGuard([this] { updateVisibleIndexes(); });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : itemList) {
        const QUrl originalURL  = item.url();
        const QString originalDirectoryPath = originalURL.adjusted(QUrl::RemoveFilename).path();
        const QString originalFileName = item.name();

        QString extension = db.suffixForFileName(originalFileName);

        QUrl duplicateURL = originalURL;

        // No extension; new filename is "<oldfilename> copy"
        if (extension.isEmpty()) {
            duplicateURL.setPath(originalDirectoryPath + i18nc("<filename> copy", "%1 copy", originalFileName));
        // There's an extension; new filename is "<oldfilename> copy.<extension>"
        } else {
            // Need to add a dot since QMimeDatabase::suffixForFileName() doesn't include it
            extension = QLatin1String(".") + extension;
            const QString originalFilenameWithoutExtension = originalFileName.chopped(extension.size());
            // Preserve file's original filename extension in case the casing differs
            // from what QMimeDatabase::suffixForFileName() returned
            const QString originalExtension = originalFileName.right(extension.size());
            duplicateURL.setPath(originalDirectoryPath + i18nc("<filename> copy", "%1 copy", originalFilenameWithoutExtension) + originalExtension);
        }

        KIO::CopyJob* job = KIO::copyAs(originalURL, duplicateURL, KIO::HideProgressInfo);
        KJobWidgets::setWindow(job, this);

        if (job) {
            newSelection << duplicateURL;
            KIO::FileUndoManager::self()->recordCopyJob(job);
        }
    }
```

#### AUTO 


```{c}
auto openNewTabAfterLastTabConfigured = GeneralSettings::openNewTabAfterLastTab();
```

#### AUTO 


```{c}
auto menu = hamburgerMenu->menu();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : argVariants) {
            if (runInstallerScriptOnce(path, QStringList{arg}, dir)) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
            if (m_customContextMenuActions.contains(action)) {
                removeAction(action);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=] { hideToolTip(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& visibleRole : qAsConst(m_visibleRoles)) {
        const QString headerText = m_model->roleDescription(visibleRole);
        const qreal headerWidth = fontMetrics.width(headerText) + gripMargin + headerMargin * 2;
        widths.insert(visibleRole, headerWidth);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int n : qAsConst(sizes)) {
        QStringList allStrings;
        for (int i = 0; i < n; ++i) {
            allStrings << QString::number(i);
        }

        // We want to keep the sorting overhead in the benchmark low.
        // Therefore, we do not use natural sorting. However, this
        // means that our list is currently not sorted.
        allStrings.sort();

        KFileItemList all = createFileItemList(allStrings);

        KFileItemList firstHalf, secondHalf, even, odd;
        for (int i = 0; i < n; ++i) {
            if (i < n / 2) {
                firstHalf << all.at(i);
            } else {
                secondHalf << all.at(i);
            }

            if (i % 2 == 0) {
                even << all.at(i);
            } else {
                odd << all.at(i);
            }
        }

        KItemRangeList itemRangeListFirstHalf;
        itemRangeListFirstHalf << KItemRange(0, firstHalf.count());

        KItemRangeList itemRangeListSecondHalf;
        itemRangeListSecondHalf << KItemRange(firstHalf.count(), secondHalf.count());

        KItemRangeList itemRangeListOddInserted, itemRangeListOddRemoved;
        for (int i = 0; i < odd.count(); ++i) {
            // Note that the index in the KItemRange is the index of
            // the model *before* the items have been inserted.
            itemRangeListOddInserted << KItemRange(i + 1, 1);
            itemRangeListOddRemoved << KItemRange(2 * i + 1, 1);
        }

        const int bufferSize = 128;
        char buffer[bufferSize];

        snprintf(buffer, bufferSize, "all--n=%i", n);
        QTest::newRow(buffer) << all << KFileItemList() << KFileItemList() << all << KItemRangeList() << KItemRangeList();

        snprintf(buffer, bufferSize, "1st half + 2nd half--n=%i", n);
        QTest::newRow(buffer) << firstHalf << secondHalf << KFileItemList() << all << itemRangeListSecondHalf << KItemRangeList();

        snprintf(buffer, bufferSize, "2nd half + 1st half--n=%i", n);
        QTest::newRow(buffer) << secondHalf << firstHalf << KFileItemList() << all << itemRangeListFirstHalf << KItemRangeList();

        snprintf(buffer, bufferSize, "even + odd--n=%i", n);
        QTest::newRow(buffer) << even << odd << KFileItemList() << all << itemRangeListOddInserted << KItemRangeList();

        snprintf(buffer, bufferSize, "all - 2nd half--n=%i", n);
        QTest::newRow(buffer) << all << KFileItemList() << secondHalf << firstHalf << KItemRangeList() << itemRangeListSecondHalf;

        snprintf(buffer, bufferSize, "all - 1st half--n=%i", n);
        QTest::newRow(buffer) << all << KFileItemList() << firstHalf << secondHalf << KItemRangeList() << itemRangeListFirstHalf;

        snprintf(buffer, bufferSize, "all - odd--n=%i", n);
        QTest::newRow(buffer) << all << KFileItemList() << odd << even << KItemRangeList() << itemRangeListOddRemoved;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        const QString text = roleText(role, values);
        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);

        qreal requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        if (requiredWidth > maxWidth) {
            requiredWidth = maxWidth;
            const QString elidedText = elideRightKeepExtension(text, maxWidth);
            textInfo->staticText.setText(elidedText);
        }

        textInfo->pos = QPointF(x, y);
        textInfo->staticText.setTextWidth(maxWidth);

        maximumRequiredTextWidth = qMax(maximumRequiredTextWidth, requiredWidth);

        y += lineSpacing;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        for (int index = range.index; index < range.index + range.count; ++index) {
            parents.insert(m_itemData.at(index));
        }
    }
```

#### AUTO 


```{c}
auto innerLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto localeAwareLessThan = [this](QChar c1, QChar c2) -> bool {
                        return m_collator.compare(c1, c2) < 0;
                    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto state : { QPalette::Active, QPalette::Inactive, QPalette::Disabled }) {
        pal.setBrush(state, QPalette::WindowText, pal.toolTipText());
        pal.setBrush(state, QPalette::Window, pal.toolTipBase());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemListWidget* widget : widgets) {
        const int index = widget->index();

        const QRectF widgetRect = m_view->itemRect(index);
        if (widgetRect.intersects(rubberBandRect)) {
            const QRectF iconRect = widget->iconRect().translated(widgetRect.topLeft());
            const QRectF textRect = widget->textRect().translated(widgetRect.topLeft());
            if (iconRect.intersects(rubberBandRect) || textRect.intersects(rubberBandRect)) {
                selectedItems.insert(index);
            }
        }
    }
```

#### AUTO 


```{c}
auto *effect = new QGraphicsOpacityEffect(m_placeholderLabel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& service : services) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            // Check if instance can handle our URLs
            QSharedPointer<QDBusInterface> instance(
                new QDBusInterface(service,
                QStringLiteral("/dolphin/Dolphin_1"),
                QStringLiteral("org.kde.dolphin.MainWindow"))
            );
            if (instance->isValid() && !instance->lastError().isValid()) {
                dolphinServices.append(qMakePair(instance, QStringList()));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        // range.index is related to the model before anything has been inserted.
        // As in each loop the current item-range gets inserted the index must
        // be increased by the already previously inserted items.
        const int index = range.index + previouslyInsertedCount;
        const int count = range.count;
        if (index < 0 || count <= 0) {
            qCWarning(DolphinDebug) << "Invalid item range (index:" << index << ", count:" << count << ")";
            continue;
        }
        previouslyInsertedCount += count;

        // Determine which visible items must be moved
        QList<int> itemsToMove;
        QHashIterator<int, KItemListWidget*> it(m_visibleItems);
        while (it.hasNext()) {
            it.next();
            const int visibleItemIndex = it.key();
            if (visibleItemIndex >= index) {
                itemsToMove.append(visibleItemIndex);
            }
        }

        // Update the indexes of all KItemListWidget instances that are located
        // after the inserted items. It is important to adjust the indexes in the order
        // from the highest index to the lowest index to prevent overlaps when setting the new index.
        std::sort(itemsToMove.begin(), itemsToMove.end());
        for (int i = itemsToMove.count() - 1; i >= 0; --i) {
            KItemListWidget* widget = m_visibleItems.value(itemsToMove[i]);
            Q_ASSERT(widget);
            const int newIndex = widget->index() + count;
            if (hasMultipleRanges) {
                setWidgetIndex(widget, newIndex);
            } else {
                // Try to animate the moving of the item
                moveWidgetToIndex(widget, newIndex);
            }
        }

        if (m_model->count() == count && m_activeTransactions == 0) {
            // Check whether a scrollbar is required to show the inserted items. In this case
            // the size of the layouter will be decreased before calling doLayout(): This prevents
            // an unnecessary temporary animation due to the geometry change of the inserted scrollbar.
            const bool verticalScrollOrientation = (scrollOrientation() == Qt::Vertical);
            const bool decreaseLayouterSize = ( verticalScrollOrientation && maximumScrollOffset() > size().height()) ||
                                              (!verticalScrollOrientation && maximumScrollOffset() > size().width());
            if (decreaseLayouterSize) {
                const int scrollBarExtent = style()->pixelMetric(QStyle::PM_ScrollBarExtent);

                int scrollbarSpacing = 0;
                if (style()->styleHint(QStyle::SH_ScrollView_FrameOnlyAroundContents)) {
                    scrollbarSpacing = style()->pixelMetric(QStyle::PM_ScrollView_ScrollBarSpacing);
                }

                QSizeF layouterSize = m_layouter->size();
                if (verticalScrollOrientation) {
                    layouterSize.rwidth() -= scrollBarExtent + scrollbarSpacing;
                } else {
                    layouterSize.rheight() -= scrollBarExtent + scrollbarSpacing;
                }
                m_layouter->setSize(layouterSize);
            }
        }

        if (!hasMultipleRanges) {
            doLayout(animateChangedItemCount(count) ? Animation : NoAnimation, index, count);
            updateSiblingsInformation();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_visibleRoles)) {
            m_headerWidget->setPreferredColumnWidth(role, preferredWidths.value(role));
        }
```

#### AUTO 


```{c}
auto sort = Dolphin::sortOrderForUrl(qurl);
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewSettingsTab *tab : qAsConst(m_tabs)) {
        tab->applySettings();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = QMimeDatabase().mimeTypeForName(commonMimeType);
        foreach (const auto& supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemData* itemData : qAsConst(m_itemData)) {
        oldUrls.append(itemData->item.url());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
            // TODO: It would be great having a mechanism to tell PreviewJob that only previews
            // for a specific MIME-type should be regenerated. As this is not available yet we
            // delete the whole thumbnails directory.
            previewPlugin->writeConfiguration(configurationWidget);

            // http://specifications.freedesktop.org/thumbnail-spec/thumbnail-spec-latest.html#DIRECTORY
            const QString thumbnailsPath = QStandardPaths::writableLocation(QStandardPaths::GenericCacheLocation) + QLatin1String("/thumbnails/");
            KIO::del(QUrl::fromLocalFile(thumbnailsPath), KIO::HideProgressInfo);
        }
```

#### AUTO 


```{c}
const auto groups = m_model->groups();
```

#### AUTO 


```{c}
const auto x = textInfo->pos.x();
```

#### AUTO 


```{c}
const auto scheme = m_baseUrl.scheme();
```

#### AUTO 


```{c}
const auto& matchedPlaces = placesModel->match(placesModel->index(0,0), KFilePlacesModel::UrlRole, url(), 1, Qt::MatchExactly);
```

#### LAMBDA EXPRESSION 


```{c}
[=](){
            QObject::disconnect(*connection);
            delete connection;

            m_view->editRole(index, "text");

            hideToolTip();

            connect(m_view, &DolphinItemListView::roleEditingFinished,
                    this, &DolphinView::slotRoleEditingFinished);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        popup.addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KOverlayIconPlugin *it : qAsConst(m_overlayIconsPlugin)) {
        overlays.append(it->getOverlays(url));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &format){ return QMovie::supportedFormats().contains(format); }
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces] (bool checked){
        actionShowAllPlaces->setChecked(checked);
        actionShowAllPlaces->setIcon(QIcon::fromTheme(checked ? QStringLiteral("visibility") : QStringLiteral("hint")));
   }
```

#### AUTO 


```{c}
const auto konsoleInstallUrl = QUrl("appstream://org.kde.konsole.desktop");
```

#### AUTO 


```{c}
auto emptyTrashButton = newEmptyTrashButton(urlNavigator, navigatorWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto widget : topLevelWidgets) {
            if (qobject_cast<DolphinMainWindow *>(widget)) {
                m_mainWindow = static_cast<DolphinMainWindow *>(widget);
                break;
            }
        }
```

#### AUTO 


```{c}
const auto dirToAdd = m_activeViewContainer->view()->selectedItems().first();
```

#### AUTO 


```{c}
const auto startFilelightAllDevicesAction = addAction(filelightService->genericName() + " - "
                + i18nc("@action:inmenu", "all devices"));
```

#### AUTO 


```{c}
auto extensionLength = text.length() - extensionIndex;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        if (item.isNull()) {
            qCWarning(DolphinDebug) << "Requesting version-control-actions for empty items";
            hasNullItems = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto visibleItemListWidgets = m_view->visibleItemListWidgets();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *groupAction : qAsConst(m_sortByActions)) {
        KActionMenu* actionMenu = qobject_cast<KActionMenu*>(groupAction);
        if (actionMenu) {
            const auto actions = actionMenu->menu()->actions();
            for (QAction* subAction : actions) {
                subAction->setChecked(false);
            }
        } else if (groupAction->actionGroup()) {
            groupAction->setChecked(false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemModel::RoleInfo& info : rolesInfo) {
            QListWidgetItem* item = new QListWidgetItem(info.translation, m_listWidget);
            item->setCheckState(visibleRoles.contains(info.role) ? Qt::Checked : Qt::Unchecked);

            const bool enable = ((!info.requiresBaloo && !info.requiresIndexer) ||
                                (info.requiresBaloo) ||
                                (info.requiresIndexer && indexingEnabled)) && info.role != "text";

            if (!enable) {
                item->setFlags(item->flags() & ~Qt::ItemIsEnabled);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        bool urlFound = false;
        for (auto& service: dolphinServices) {
            QDBusReply<bool> isUrlOpen = service.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpen.isValid() && isUrlOpen.value()) {
                    service.second.append(url);
                    urlFound = true;
                    break;
            }
        }
        if (!urlFound) {
            newUrls.append(url);
        }
    }
```

#### AUTO 


```{c}
auto removeHelpActionShortcut = [this](KHelpMenu::MenuId menuId) {
        if (auto *action = m_helpMenu->action(menuId)) {
            action->setShortcut(QKeySequence());
        }
    };
```

#### AUTO 


```{c}
auto plugin = qobject_cast<KOverlayIconPlugin*>(it);
```

#### AUTO 


```{c}
auto primaryNavigator = navigatorsWidget->primaryUrlNavigator();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : uniqueKeys) {
                if (indexesForUrl.count(url) > 1) {
                    qCWarning(DolphinDebug) << "Multiple items found with the URL" << url;

                    auto it = indexesForUrl.find(url);
                    while (it != indexesForUrl.end() && it.key() == url) {
                        const ItemData* data = m_itemData.at(it.value());
                        qCWarning(DolphinDebug) << "index" << it.value() << ":" << data->item;
                        if (data->parent) {
                            qCWarning(DolphinDebug) << "parent" << data->parent->item;
                        }
                        ++it;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[job]() {
            QUrl statUrl;
            if (!job->error()) {
                statUrl = job->mostLocalUrl();
            }

            KToolInvocation::invokeTerminal(QString(), {}, statUrl.isLocalFile() ? statUrl.toLocalFile() : QDir::homePath());
        }
```

#### AUTO 


```{c}
const auto& item = *changedItemsIt;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : qAsConst(m_itemRanges)) {
        result += range.count;
    }
```

#### AUTO 


```{c}
auto *placesModel = DolphinPlacesModelSingleton::instance().placesModel();
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QLatin1String("KFileItemAction/Plugin"));
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *it : plugins) {
        auto plugin = qobject_cast<KOverlayIconPlugin*>(it);
        if (plugin) {
            m_overlayIconsPlugin.append(plugin);
            connect(plugin, &KOverlayIconPlugin::overlaysChanged, this, &KFileItemModelRolesUpdater::slotOverlaysChanged);
        } else {
            // not our/valid plugin, so delete the created object
            it->deleteLater();
        }
    }
```

#### AUTO 


```{c}
const auto visibleRolesGroupActions = visibleRolesGroup->actions();
```

#### AUTO 


```{c}
auto rightViewContainer = tabWidget->currentTabPage()->secondaryViewContainer();
```

#### RANGE FOR STATEMENT 


```{c}
for (ViewSettingsTab *tab : qAsConst(m_tabs)) {
        tab->restoreDefaultSettings();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : qAsConst(basenames1)) {
            const auto path = findRecursive(dir, basename);
            if (!path.isEmpty()) {
                deinstallPath = path;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagName](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            emit facetChanged();
        }
```

#### AUTO 


```{c}
const auto startKDiskFreeAction = addAction(i18nc("@action:inmenu", "KDiskFree [not installed]"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QUrl &url) {
        Dolphin::openNewWindow({url}, this);
    }
```

#### AUTO 


```{c}
const auto childrenObjects = children();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : argVariants) {
            if (runInstallerScriptOnce(path, QStringList{arg})) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : qAsConst(basenames2)) {
            const auto path = findRecursive(dir, basename);
            if (!path.isEmpty()) {
                installerPath = path;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto startFilelightDirectoryAction = addAction(i18nc("@action:inmenu", "Filelight [not installed]"));
```

#### AUTO 


```{c}
auto trashShortcuts = trashAction->shortcuts();
```

#### AUTO 


```{c}
const auto& interface
```

#### AUTO 


```{c}
const auto &p
```

#### AUTO 


```{c}
const auto filelightService = KService::serviceByDesktopName("filelight");
```

#### RANGE FOR STATEMENT 


```{c}
for (int index: previous) {
            int inc = 0;
            foreach (const KItemRange& itemRange, itemRanges) {
                if (index < itemRange.index) {
                    break;
                }
                inc += itemRange.count;
            }
            m_selectedItems.insert(index + inc);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[emptyTrashButton, urlNavigator]() {
        emptyTrashButton->setVisible(urlNavigator->locationUrl().scheme() == QLatin1String("trash"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : qAsConst(indexesToRemove)) {
            indexesToRemoveWithChildren.append(index);

            const int parentLevel = expandedParentsCount(index);
            int childIndex = index + 1;
            while (childIndex < itemCount && expandedParentsCount(childIndex) > parentLevel) {
                indexesToRemoveWithChildren.append(childIndex);
                ++childIndex;
            }
        }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, settings, url](KJob* job) {
            if (job->error() == 0 && qobject_cast<KIO::StatJob*>(job)->statResult().isDir()) {
                settings->setHomeUrl(url.toDisplayString(QUrl::PreferLocalFile));
            } else {
                showSetDefaultDirectoryError();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        const QString pattern = dialog->textValue();
        if (!pattern.isEmpty()) {
            QStringList items = dialog->comboBoxItems();
            items.removeAll(pattern);
            items.prepend(pattern);

            // Need to evaluate this again here, because the captured value is const
            // (even if the const were removed from 'const KConfigGroup group =' above).
            KConfigGroup group = KSharedConfig::openConfig("dolphinpartrc")->group("Select Dialog");
            // Limit the size of the saved history.
            group.writeEntry("History", items.mid(0, 10));
            group.sync();

            const QRegularExpression patternRegExp(QRegularExpression::wildcardToRegularExpression(pattern));
            m_view->selectItems(patternRegExp, selectItems);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tagName : qAsConst(allTags)) {
        QAction *action = tagsMenu->addAction(QIcon::fromTheme(QStringLiteral("tag")), tagName);
        action->setCheckable(true);
        action->setChecked(m_searchTags.contains(tagName));

        connect(action, &QAction::triggered, this, [this, tagName, onlyOneTag](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            Q_EMIT facetChanged();

            if (!onlyOneTag) {
                m_tagsSelector->menu()->show();
            }
        });
    }
```

#### AUTO 


```{c}
const auto visibleRoles = view->visibleRoles();
```

#### AUTO 


```{c}
auto trashAction = KStandardAction::moveToTrash(this, &DolphinViewActionHandler::slotTrashActivated, m_actionCollection);
```

#### LAMBDA EXPRESSION 


```{c}
[this, groupType, hideGroupAction]{
        m_model->setGroupHidden(groupType, hideGroupAction->isChecked());
        if (!m_model->hiddenCount()) {
            showHiddenEntries(false);
        }
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (KItemListWidget *newHoveredWidget = widgetForPos(pos); newHoveredWidget) {
        // something got hovered, work out which part and set hover for the appropriate widget
        const auto mappedPos = newHoveredWidget->mapFromItem(m_view, pos);
        const bool isOnExpansionToggle = newHoveredWidget->expansionToggleRect().contains(mappedPos);

        if (isOnExpansionToggle) {
            // make sure we unhover the old one first if old!=new
            if (oldHoveredExpansionWidget && *oldHoveredExpansionWidget != newHoveredWidget) {
                (*oldHoveredExpansionWidget)->setExpansionAreaHovered(false);
            }
            // we also unhover any old icon+text hovers, in case the mouse movement from icon+text to expansion toggle is too fast (i.e. newHoveredWidget is never null between the transition)
            unhoverOldHoveredWidget();


            newHoveredWidget->setExpansionAreaHovered(true);
        } else {
            // make sure we unhover the old one first if old!=new
            auto oldHoveredWidget = hoveredWidget();
            if (oldHoveredWidget && oldHoveredWidget != newHoveredWidget) {
                oldHoveredWidget->setHovered(false);
                Q_EMIT itemUnhovered(oldHoveredWidget->index());
            }
            // we also unhover any old expansion toggle hovers, in case the mouse movement from expansion toggle to icon+text is too fast (i.e. newHoveredWidget is never null between the transition)
            unhoverOldExpansionWidget();

            const bool isOverIconAndText = newHoveredWidget->iconRect().contains(mappedPos) || newHoveredWidget->textRect().contains(mappedPos);
            const bool hasMultipleSelection = m_selectionManager->selectedItems().count() > 1;

            if (hasMultipleSelection && !isOverIconAndText) {
                // In case we have multiple selections, clicking on any row will deselect the selection.
                // So, as a visual cue for signalling that clicking anywhere won't select, but clear current highlights,
                // we disable hover of the *row*(i.e. blank space to the right of the icon+text)

                // (no-op in this branch for masked hover)
            } else {
                newHoveredWidget->setHoverPosition(mappedPos);
                if (oldHoveredWidget != newHoveredWidget) {
                    newHoveredWidget->setHovered(true);
                    Q_EMIT itemHovered(newHoveredWidget->index());
                }
            }
        }
    } else {
        // unhover any currently hovered expansion and text+icon widgets
        unhoverOldHoveredWidget();
        unhoverOldExpansionWidget();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : files) {
        if (m_shownUrl == QUrl::fromLocalFile(fileName)) {
            showItemInfo();
            break;
        }
    }
```

#### AUTO 


```{c}
auto const &tag
```

#### AUTO 


```{c}
const auto actions = m_newFileMenu->menu()->actions();
```

#### AUTO 


```{c}
auto *downloadButton = new KNS3::Button(i18nc("@action:button", "Download New Services..."),
                                                  QStringLiteral("servicemenu.knsrc"),
                                                  this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const ItemData *item) {
                return item->item.time(KFileItem::ModificationTime);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces, this]{
        actionShowAllPlaces->setEnabled(DolphinPlacesModelSingleton::instance().placesModel()->hiddenCount());
    }
```

#### AUTO 


```{c}
auto networkFolderButton = newNetworkFolderButton(urlNavigator, navigatorWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[actionShowAllPlaces, this](bool checked){
        m_placesPanel->setShowAll(checked);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[destUrl](const QUrl& url) {
            return url.matches(destUrl, QUrl::StripTrailingSlash);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : widgets) {
            initializeItemListWidget(widget);
        }
```

#### AUTO 


```{c}
auto changedItemsIt = m_changedItems.begin();
```

#### AUTO 


```{c}
const auto& role
```

#### AUTO 


```{c}
const auto viewContainers = m_mainWindow->viewContainers();
```

#### RANGE FOR STATEMENT 


```{c}
for (bool groupingEnabled : qAsConst(groupingEnabledList)) {
                    QList<QPair<KeyPress, ViewState> > testList;

                    // First, key presses which should have the same effect
                    // for any layout and any number of columns.
                    testList
                        << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(3, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(4, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey), ViewState(3, KItemSet() << 3))
                        << qMakePair(KeyPress(Qt::Key_Home, Qt::ShiftModifier), ViewState(0, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(18, KItemSet() << 18 << 19))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(0, KItemSet(), true))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_3), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(0, KItemSet()));

                    // Next, we test combinations of key presses which only work for a
                    // particular number of columns and either enabled or disabled grouping.

                    // One column.
                    if (columnCount == 1) {
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ControlModifier), ViewState(3, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(previousRowKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(previousItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    // Multiple columns: we test both 3 and 5 columns with grouping
                    // enabled or disabled. For each case, the layout of the items
                    // in the view is shown (both using file names and indices) to
                    // make it easier to understand what the tests do.

                    if (columnCount == 3 && !groupingEnabled) {
                        // 3 columns, no grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1 c1 c2 |  3  4  5
                        // c3 c4 c5 |  6  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4 e1 e2 | 12 13 14
                        // e3 e4 e5 | 15 16 17
                        // e6 e7    | 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(3, KItemSet() << 3))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 3))
                            << qMakePair(KeyPress(nextRowKey), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(9, KItemSet() << 7 << 8 << 9))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 5 << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextRowKey), ViewState(10, KItemSet() << 10))
                            << qMakePair(KeyPress(nextItemKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && !groupingEnabled) {
                        // 5 columns, no grouping:
                        //
                        // a1 a2 a3 b1 c1 |  0  1  2  3  4
                        // c2 c3 c4 c5 d1 |  5  6  7  8  9
                        // d2 d3 d4 e1 e2 | 10 11 12 13 14
                        // e3 e4 e5 e6 e7 | 15 16 17 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(5, KItemSet() << 5))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(6, KItemSet() << 5))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(17, KItemSet() << 12 << 13 << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7 << 8 << 9 << 10 << 11 << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ControlModifier), ViewState(19, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 3 && groupingEnabled) {
                        // 3 columns, with grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1       |  3
                        // c1 c2 c3 |  4  5  6
                        // c4 c5    |  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4       | 12
                        // e1 e2 e3 | 13 14 15
                        // e4 e5 e6 | 16 17 18
                        // e7       | 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 2 << 3 << 4 << 5 << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(8, KItemSet() << 8))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(12, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(13, KItemSet() << 13))
                            << qMakePair(KeyPress(nextRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(nextItemKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && groupingEnabled) {
                        // 5 columns, with grouping:
                        //
                        // a1 a2 a3       |  0  1  2
                        // b1             |  3
                        // c1 c2 c3 c4 c5 |  4  5  6  7  8
                        // d1 d2 d3 d4    |  9 10 11 12
                        // e1 e2 e3 e4 e5 | 13 14 15 16 17
                        // e6 e7          | 18 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 1 << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 1 << 2 << 3 << 4 << 5))
                            << qMakePair(KeyPress(nextItemKey), ViewState(6, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(7, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(8, KItemSet() << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ShiftModifier), ViewState(19, KItemSet() << 17 << 18 << 19))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(14, KItemSet() << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    const QString testName =
                        layoutNames[layout] + ", " +
                        QString("%1 columns, ").arg(columnCount) +
                        selectionBehaviorNames[selectionBehavior] + ", " +
                        groupingEnabledNames[groupingEnabled];

                    const QByteArray testNameAscii = testName.toLatin1();

                    QTest::newRow(testNameAscii.data())
                        << layout
                        << scrollOrientation
                        << columnCount
                        << selectionBehavior
                        << groupingEnabled
                        << testList;
                }
```

#### AUTO 


```{c}
const auto kdiskfreeService = KService::serviceByDesktopName("kdf");
```

#### LAMBDA EXPRESSION 


```{c}
[](const ItemData *item) {
                return item->values.value("deletiontime").toDateTime();
            }
```

#### AUTO 


```{c}
auto networkFolderButton = new QPushButton(QIcon::fromTheme(QStringLiteral("folder-add")),
                                        i18nc("@action:button", "Add Network Folder"), parent);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
            setActive(true);
            setFocus();
        }
```

#### AUTO 


```{c}
auto actionShowAllPlaces = new QAction(QIcon::fromTheme(QStringLiteral("view-hidden")), i18nc("@item:inmenu", "Show Hidden Places"), this);
```

#### AUTO 


```{c}
const auto guiClients = m_konsolePart->childClients();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
        const int index = itemRange.index;
        const int count = itemRange.count;

        if (updateSizeHints) {
            m_sizeHintResolver->itemsChanged(index, count, roles);
            m_layouter->markAsDirty();
        }

        // Apply the changed roles to the visible item-widgets
        const int lastIndex = index + count - 1;
        for (int i = index; i <= lastIndex; ++i) {
            KItemListWidget* widget = m_visibleItems.value(i);
            if (widget) {
                widget->setData(m_model->data(i), roles);
            }
        }

        if (m_grouped && roles.contains(m_model->sortRole())) {
            // The sort-role has been changed which might result
            // in modified group headers
            updateVisibleGroupHeaders();
            doLayout(NoAnimation);
        }

        QAccessibleTableModelChangeEvent ev(this, QAccessibleTableModelChangeEvent::DataChanged);
        ev.setFirstRow(itemRange.index);
        ev.setLastRow(itemRange.index + itemRange.count);
        QAccessible::updateAccessibility(&ev);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[filelightService, url](bool) {
                KRun::runService(*filelightService, { url }, nullptr);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : devices) {
        if (!hasSSHFS && device.vendor() == QLatin1String("fuse.sshfs")) {
            // Ignore kdeconnect SSHFS mounts, we already know that people have those.
            auto storageAccess = device.as<Solid::StorageAccess>();
            if (storageAccess) {
                auto mountPoint = KMountPoint::currentMountPoints().findByPath(storageAccess->filePath());
                if (!mountPoint->mountedFrom().startsWith(QLatin1String("kdeconnect@"))) {
                    hasSSHFS = true;
                    continue;
                }
            }
        }

        if (!device.is<Solid::NetworkShare>()) {
            continue;
        }

        switch (device.as<Solid::NetworkShare>()->type()) {
        case Solid::NetworkShare::Cifs:
            hasSambaShare = true;
            continue;
        case Solid::NetworkShare::Nfs:
            hasNfsShare = true;
            continue;
        default:
            continue;
        }
    }
```

#### AUTO 


```{c}
auto hamburgerMenu = static_cast<KHamburgerMenu *>(actionCollection()->action(
                                    KStandardAction::name(KStandardAction::HamburgerMenu)));
```

#### AUTO 


```{c}
const auto &searchToken
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemModel::RoleInfo& info : rolesInfo) {
            const QListWidgetItem* item = m_listWidget->item(index);
             if (item->checkState() == Qt::Checked) {
                visibleRoles.append(info.role);
            }
            ++index;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                setActive(true);
                setFocus();
            }
```

#### AUTO 


```{c}
const auto items = selectionManager->selectedItems();
```

#### AUTO 


```{c}
auto rangeBegin = propMap.constKeyValueBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &jsonMetadata : jsonPlugins) {
        const QString desktopEntryName = jsonMetadata.pluginId();
        if (!isInServicesList(desktopEntryName)) {
            const bool checked = showGroup.readEntry(desktopEntryName, true);
            addRow(jsonMetadata.iconName(), jsonMetadata.name(), desktopEntryName, checked);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        bool urlFound = false;
        for (auto& service: dolphinServices) {
            QDBusReply<bool> isUrlOpen = service.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpen.isValid() && isUrlOpen.value()) {
                service.second.append(url);
                urlFound = true;
                break;
            }
        }
        if (!urlFound) {
            newUrls.append(url);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& service : dbusServices) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            // Check if instance can handle our URLs
            QSharedPointer<QDBusInterface> interface(
                new QDBusInterface(service,
                QStringLiteral("/dolphin/Dolphin_1"),
                QStringLiteral("org.kde.dolphin.MainWindow"))
            );
            if (interface->isValid() && !interface->lastError().isValid()) {
                dolphinInterfaces.append(qMakePair(interface, QStringList()));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& interface: qAsConst(dolphinInterfaces)) {
        auto reply = openFiles ? interface.first->openFiles(newUrls, splitView) : interface.first->openDirectories(newUrls, splitView);
        reply.waitForFinished();
        if (!reply.isError()) {
            interface.first->activateWindow();
            attached = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto key = (*rangeBegin).first;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QSize &newSize) {
        int iconSize = qMin(newSize.width(), newSize.height());
        if (iconSize == 0) {
            // Don't store 0 size, let's keep -1 for default/small/automatic
            iconSize = -1;
        }
        PlacesPanelSettings* settings = PlacesPanelSettings::self();
        settings->setIconSize(iconSize);
        settings->save();
    }
```

#### AUTO 


```{c}
const auto result = KMessageBox::createKMessageBox(dialog,
            buttons,
            QMessageBox::Warning,
            i18n("You have multiple tabs open in this window, are you sure you want to quit?"),
            QStringList(),
            i18n("Do not ask again"),
            &doNotAskAgainCheckboxResult,
            KMessageBox::Notify);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& role : propertyRoleMap()) {
        m_roles.insert(role);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
                if (index < itemRange.index) {
                    break;
                }
                inc += itemRange.count;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : list) {
        const QUrl& url = DolphinView::openItemAsFolderUrl(item);
        if (!url.isEmpty()) {
            openNewTab(url);
            tabCreated = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : files) {
        if (m_shownUrl == QUrl::fromUserInput(fileName)) {
            // the currently shown item has been removed, show
            // the parent directory as fallback
            markUrlAsInvalid();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& interface: dolphinInterfaces) {
            QDBusReply<bool> isUrlOpenReply = interface.first->call(QStringLiteral("isUrlOpen"), url);
            if (isUrlOpenReply.isValid() && isUrlOpenReply.value()) {
                interface.second.append(url);
                urlFound = true;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto modifiers = QGuiApplication::keyboardModifiers();
```

#### AUTO 


```{c}
auto reply = m_kiofuseInterface.remoteUrl(m_konsolePartCurrentDirectory);
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<KVersionControlPlugin>(p).plugin;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : visibleRoles) {
                    columnWidths.append(header->columnWidth(role));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (int columnCount : qAsConst(columnCountList)) {
            for (const KItemListController::SelectionBehavior& selectionBehavior : qAsConst(selectionBehaviorList)) {
                for (bool groupingEnabled : qAsConst(groupingEnabledList)) {
                    QList<QPair<KeyPress, ViewState> > testList;

                    // First, key presses which should have the same effect
                    // for any layout and any number of columns.
                    testList
                        << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(3, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(4, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey), ViewState(3, KItemSet() << 3))
                        << qMakePair(KeyPress(Qt::Key_Home, Qt::ShiftModifier), ViewState(0, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(18, KItemSet() << 18 << 19))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(0, KItemSet(), true))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_3), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(0, KItemSet()));

                    // Next, we test combinations of key presses which only work for a
                    // particular number of columns and either enabled or disabled grouping.

                    // One column.
                    if (columnCount == 1) {
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ControlModifier), ViewState(3, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(previousRowKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(previousItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    // Multiple columns: we test both 3 and 5 columns with grouping
                    // enabled or disabled. For each case, the layout of the items
                    // in the view is shown (both using file names and indices) to
                    // make it easier to understand what the tests do.

                    if (columnCount == 3 && !groupingEnabled) {
                        // 3 columns, no grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1 c1 c2 |  3  4  5
                        // c3 c4 c5 |  6  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4 e1 e2 | 12 13 14
                        // e3 e4 e5 | 15 16 17
                        // e6 e7    | 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(3, KItemSet() << 3))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 3))
                            << qMakePair(KeyPress(nextRowKey), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(9, KItemSet() << 7 << 8 << 9))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 5 << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextRowKey), ViewState(10, KItemSet() << 10))
                            << qMakePair(KeyPress(nextItemKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && !groupingEnabled) {
                        // 5 columns, no grouping:
                        //
                        // a1 a2 a3 b1 c1 |  0  1  2  3  4
                        // c2 c3 c4 c5 d1 |  5  6  7  8  9
                        // d2 d3 d4 e1 e2 | 10 11 12 13 14
                        // e3 e4 e5 e6 e7 | 15 16 17 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(5, KItemSet() << 5))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(6, KItemSet() << 5))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(17, KItemSet() << 12 << 13 << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7 << 8 << 9 << 10 << 11 << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ControlModifier), ViewState(19, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 3 && groupingEnabled) {
                        // 3 columns, with grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1       |  3
                        // c1 c2 c3 |  4  5  6
                        // c4 c5    |  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4       | 12
                        // e1 e2 e3 | 13 14 15
                        // e4 e5 e6 | 16 17 18
                        // e7       | 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 2 << 3 << 4 << 5 << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(8, KItemSet() << 8))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(12, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(13, KItemSet() << 13))
                            << qMakePair(KeyPress(nextRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(nextItemKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && groupingEnabled) {
                        // 5 columns, with grouping:
                        //
                        // a1 a2 a3       |  0  1  2
                        // b1             |  3
                        // c1 c2 c3 c4 c5 |  4  5  6  7  8
                        // d1 d2 d3 d4    |  9 10 11 12
                        // e1 e2 e3 e4 e5 | 13 14 15 16 17
                        // e6 e7          | 18 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 1 << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 1 << 2 << 3 << 4 << 5))
                            << qMakePair(KeyPress(nextItemKey), ViewState(6, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(7, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(8, KItemSet() << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ShiftModifier), ViewState(19, KItemSet() << 17 << 18 << 19))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(14, KItemSet() << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    const QString testName =
                        layoutNames[layout] + ", " +
                        QString("%1 columns, ").arg(columnCount) +
                        selectionBehaviorNames[selectionBehavior] + ", " +
                        groupingEnabledNames[groupingEnabled];

                    const QByteArray testNameAscii = testName.toLatin1();

                    QTest::newRow(testNameAscii.data())
                        << layout
                        << scrollOrientation
                        << columnCount
                        << selectionBehavior
                        << groupingEnabled
                        << testList;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemListController::SelectionBehavior& selectionBehavior : qAsConst(selectionBehaviorList)) {
                for (bool groupingEnabled : qAsConst(groupingEnabledList)) {
                    QList<QPair<KeyPress, ViewState> > testList;

                    // First, key presses which should have the same effect
                    // for any layout and any number of columns.
                    testList
                        << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(3, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(4, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey), ViewState(3, KItemSet() << 3))
                        << qMakePair(KeyPress(Qt::Key_Home, Qt::ShiftModifier), ViewState(0, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(18, KItemSet() << 18 << 19))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(0, KItemSet(), true))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_3), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(0, KItemSet()));

                    // Next, we test combinations of key presses which only work for a
                    // particular number of columns and either enabled or disabled grouping.

                    // One column.
                    if (columnCount == 1) {
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ControlModifier), ViewState(3, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(previousRowKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(previousItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    // Multiple columns: we test both 3 and 5 columns with grouping
                    // enabled or disabled. For each case, the layout of the items
                    // in the view is shown (both using file names and indices) to
                    // make it easier to understand what the tests do.

                    if (columnCount == 3 && !groupingEnabled) {
                        // 3 columns, no grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1 c1 c2 |  3  4  5
                        // c3 c4 c5 |  6  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4 e1 e2 | 12 13 14
                        // e3 e4 e5 | 15 16 17
                        // e6 e7    | 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(3, KItemSet() << 3))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 3))
                            << qMakePair(KeyPress(nextRowKey), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(9, KItemSet() << 7 << 8 << 9))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 5 << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextRowKey), ViewState(10, KItemSet() << 10))
                            << qMakePair(KeyPress(nextItemKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && !groupingEnabled) {
                        // 5 columns, no grouping:
                        //
                        // a1 a2 a3 b1 c1 |  0  1  2  3  4
                        // c2 c3 c4 c5 d1 |  5  6  7  8  9
                        // d2 d3 d4 e1 e2 | 10 11 12 13 14
                        // e3 e4 e5 e6 e7 | 15 16 17 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(5, KItemSet() << 5))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(6, KItemSet() << 5))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(17, KItemSet() << 12 << 13 << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7 << 8 << 9 << 10 << 11 << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ControlModifier), ViewState(19, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 3 && groupingEnabled) {
                        // 3 columns, with grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1       |  3
                        // c1 c2 c3 |  4  5  6
                        // c4 c5    |  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4       | 12
                        // e1 e2 e3 | 13 14 15
                        // e4 e5 e6 | 16 17 18
                        // e7       | 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 2 << 3 << 4 << 5 << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(8, KItemSet() << 8))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(12, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(13, KItemSet() << 13))
                            << qMakePair(KeyPress(nextRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(nextItemKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && groupingEnabled) {
                        // 5 columns, with grouping:
                        //
                        // a1 a2 a3       |  0  1  2
                        // b1             |  3
                        // c1 c2 c3 c4 c5 |  4  5  6  7  8
                        // d1 d2 d3 d4    |  9 10 11 12
                        // e1 e2 e3 e4 e5 | 13 14 15 16 17
                        // e6 e7          | 18 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 1 << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 1 << 2 << 3 << 4 << 5))
                            << qMakePair(KeyPress(nextItemKey), ViewState(6, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(7, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(8, KItemSet() << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ShiftModifier), ViewState(19, KItemSet() << 17 << 18 << 19))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(14, KItemSet() << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    const QString testName =
                        layoutNames[layout] + ", " +
                        QString("%1 columns, ").arg(columnCount) +
                        selectionBehaviorNames[selectionBehavior] + ", " +
                        groupingEnabledNames[groupingEnabled];

                    const QByteArray testNameAscii = testName.toLatin1();

                    QTest::newRow(testNameAscii.data())
                        << layout
                        << scrollOrientation
                        << columnCount
                        << selectionBehavior
                        << groupingEnabled
                        << testList;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (DolphinViewContainer *viewContainer : theViewContainers) {
        if (viewContainer && viewContainer->url().toLocalFile().startsWith(mountPath)) {
            viewContainer->setUrl(QUrl::fromLocalFile(QDir::homePath()));
        }
    }
```

#### AUTO 


```{c}
auto oldHoveredWidget = hoveredWidget();
```

#### AUTO 


```{c}
const auto startFilelightAllDevicesAction = addAction(i18nc("@action:inmenu %1 service name", "%1 - all devices", filelightService->genericName()));
```

#### AUTO 


```{c}
const auto items = view()->controller()->selectionManager()->selectedItems();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url](const QString &mimetype) {
                    if (mimetype == QLatin1String("inode/directory")) {
                        // If it's a dir, we'll take it from here
                        m_lastHandleUrlOpenJob->kill();
                        m_lastHandleUrlOpenJob = nullptr;
                        activeViewContainer()->setUrl(url);
                    }
        }
```

#### AUTO 


```{c}
const auto actions = customContextMenuActions();
```

#### AUTO 


```{c}
auto *listJob = qobject_cast<KIO::ListJob *>(job)
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : qAsConst(invisibleChangedIndexes)) {
            m_pendingPreviewItems.append(m_model->fileItem(index));
        }
```

#### AUTO 


```{c}
const auto searchText = i18n("Search for %1", m_activeViewContainer->currentSearchText());
```

#### AUTO 


```{c}
auto lambdaLessThan = [&] (const KFileItemModel::ItemData* a, const KFileItemModel::ItemData* b)
    {
        return lessThan(a, b, m_collator);
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (DolphinUrlNavigator *urlNavigator : s_instances) {
        urlNavigator->setPlacesSelectorVisible(s_placesSelectorVisible);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : qAsConst(basenames1)) {
            const auto path = findRecursive(dir, basename);
            if (!path.isEmpty()) {
                installItPath = path;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        const QString text = roleText(role, values);
        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);

        qreal requiredWidth = m_customizedFontMetrics.horizontalAdvance(text);
        if (requiredWidth > maxWidth) {
            requiredWidth = maxWidth;
            const QString elidedText = elideRightKeepExtension(text, maxWidth);
            textInfo->staticText.setText(elidedText);
        }

        if (layoutDirection() == Qt::LeftToRight) {
            textInfo->pos = QPointF(x, y);
        } else {
            textInfo->pos = QPointF(x - size().height(), y);
        }
        textInfo->staticText.setTextWidth(maxWidth);

        maximumRequiredTextWidth = qMax(maximumRequiredTextWidth, requiredWidth);

        y += lineSpacing;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QVariant&) {
            update();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (m_tapAndHoldIndicator->isActive()) {
            update();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagName, onlyOneTag](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            emit facetChanged();

            if (!onlyOneTag) {
                m_tagsSelector->menu()->show();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : qAsConst(m_plugins)) {
            actions << plugin->outOfVersionControlActions(items);
        }
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"));
```

#### LAMBDA EXPRESSION 


```{c}
[parent]() { Trash::empty(parent); }
```

#### AUTO 


```{c}
const auto tagUrl   = [](const QString &tag) { return QUrl(QStringLiteral("tags:/%1/").arg(tag)); };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& service : services) {
        if (service.startsWith(pattern) && !service.endsWith(myPid)) {
            // Check if instance can handle our URLs
            QSharedPointer<QDBusInterface> instance(
                new QDBusInterface(service,
                QStringLiteral("/dolphin/Dolphin_1"),
                QStringLiteral("org.kde.dolphin.MainWindow"))
            );
            if (!instance->isValid() || instance->lastError().isValid()) {
                continue;
            }
            dolphinServices.append(qMakePair(instance, QStringList()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &tag) { return QUrl(QStringLiteral("tags:/%1/").arg(tag)); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : list) {
        const QUrl& url = DolphinView::openItemAsFolderUrl(item);
        if (!url.isEmpty()) {
            openNewTabAfterCurrentTab(url);
            tabCreated = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (const KFileItemModel::ItemData* a, const KFileItemModel::ItemData* b)
    {
        return lessThan(a, b, m_collator);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int i : tobeRemoved) {
        int before = m_model->count();
        m_model->deleteItem(i);
        QTRY_COMPARE(m_model->count(), before - 1);
    }
```

#### AUTO 


```{c}
const auto widgets = visibleItemListWidgets();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_metaDataWidget->setConfigurationMode(Baloo::ConfigurationMode::Cancel);
                m_configureButtons->setVisible(false);
                m_configureLabel->setVisible(false);
                Q_EMIT configurationFinished();
            }
```

#### AUTO 


```{c}
const auto serviceName = QStringLiteral("org.kde.dolphin-%1").arg(QCoreApplication::applicationPid());
```

#### RANGE FOR STATEMENT 


```{c}
for (const DolphinUrlNavigator *urlNavigator : s_instances) {
            urlNavigator->editor()->setCompletionMode(completionMode);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : qAsConst(result)) {
        Q_ASSERT(itemSet.contains(i));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        if (role == "text") {
            continue;
        }

        const QString text = roleText(role, values);
        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);

        qreal requiredWidth = 0;

        QTextLayout layout(text, m_customizedFont);
        QTextOption textOption;
        textOption.setWrapMode(QTextOption::NoWrap);
        layout.setTextOption(textOption);

        layout.beginLayout();
        QTextLine textLine = layout.createLine();
        if (textLine.isValid()) {
            textLine.setLineWidth(maxWidth);
            requiredWidth = textLine.naturalTextWidth();
            if (requiredWidth > maxWidth) {
                const QString elidedText = elideRightKeepExtension(text, maxWidth);
                textInfo->staticText.setText(elidedText);
                requiredWidth = m_customizedFontMetrics.horizontalAdvance(elidedText);
            } else if (role == "rating") {
                // Use the width of the rating pixmap, because the rating text is empty.
                requiredWidth = m_rating.width();
            }
        }
        layout.endLayout();

        textInfo->pos = QPointF(padding, y);
        textInfo->staticText.setTextWidth(maxWidth);

        const QRectF textRect(padding + (maxWidth - requiredWidth) / 2, y, requiredWidth, lineSpacing);

        // Ignore empty roles. Avoids a text rect taller than the area that actually contains text.
        if (!textRect.isEmpty()) {
            m_textRect |= textRect;
        }

        y += lineSpacing;
    }
```

#### AUTO 


```{c}
const auto& process
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        const int indexForItem = index(item);
        if (indexForItem >= 0) {
            indexesToRemove.append(indexForItem);
        } else {
            // Probably the item has been filtered.
            QHash<KFileItem, ItemData*>::iterator it = m_filteredItems.find(item);
            if (it != m_filteredItems.end()) {
                delete it.value();
                m_filteredItems.erase(it);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[italic](auto &&v) {
        v->setItalicFont(italic);
    }
```

#### AUTO 


```{c}
const auto pair = s_cache->value(resolvedPath);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QUrl &destination, QDropEvent *event) {
#if KIO_VERSION >= QT_VERSION_CHECK(5, 37, 0)
        m_view->dropUrls(destination, event, m_urlNavigator->dropWidget());
#else
        // TODO: remove as soon as we can hard-depend of KF5 >= 5.37
        m_view->dropUrls(destination, event, m_view);
#endif
    }
```

#### AUTO 


```{c}
auto backShortcuts = m_backAction->shortcuts();
```

#### LAMBDA EXPRESSION 


```{c}
[&](int section, const QRectF &rect, const QStyleOptionHeader::SectionPosition &pos){
        QStyleOptionHeader padding;
        padding.state = QStyle::State_None | QStyle::State_Raised | QStyle::State_Horizontal;
        padding.section = section;
        padding.sortIndicator = QStyleOptionHeader::None;
        padding.rect = rect.toRect();
        padding.position = pos;
        padding.text = QString();
        style()->drawControl(QStyle::CE_Header, &padding, painter, widget);
    }
```

#### AUTO 


```{c}
const auto formats = mimeData->formats();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : devices) {
        if (!hasSSHFS && device.vendor() == QLatin1String("fuse.sshfs")) {
            // Ignore kdeconnect SSHFS mounts, we already know that people have those.
            auto storageAccess = device.as<Solid::StorageAccess>();
            if (storageAccess) {
                auto mountPoint = KMountPoint::currentMountPoints().findByPath(storageAccess->filePath());
                if (mountPoint && !mountPoint->mountedFrom().startsWith(QLatin1String("kdeconnect@"))) {
                    hasSSHFS = true;
                    continue;
                }
            }
        }

        if (!device.is<Solid::NetworkShare>()) {
            continue;
        }

        switch (device.as<Solid::NetworkShare>()->type()) {
        case Solid::NetworkShare::Cifs:
            hasSambaShare = true;
            continue;
        case Solid::NetworkShare::Nfs:
            hasNfsShare = true;
            continue;
        default:
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : m_activeViewContainer->view()->selectedItems()) {
        QUrl url = item.url();
        if (item.isFile()) {
            url.setPath(QFileInfo(url.path()).absolutePath());
        }
        if (!urls.contains(url)) {
            urls << url;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // We have to wait for DolphinUrlNavigator::sizeHint() to update which
        // happens a little bit later than when urlChanged is emitted.
        this->m_adjustSpacingTimer->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KStandardAction::StandardAction actionId,
                                             const QString &whatsThis) {
        if (auto *action = actionCollection()->action(KStandardAction::name(actionId))) {
            action->setWhatsThis(whatsThis);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[fontSize](auto &&v) {
        v->setFontSize(fontSize);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : plugins) {
            if (enabledPlugins.contains(p.name())) {
                auto plugin = KPluginFactory::instantiatePlugin<KVersionControlPlugin>(p, parent()).plugin;
                if (plugin) {
                    m_plugins.append(plugin);
                    loadedPlugins += p.name();
                }
            }
        }
```

#### AUTO 


```{c}
auto contextMenuSettingsPage = new ContextMenuSettingsPage(this, actions, {
        QStringLiteral("add_to_places"),
        QStringLiteral("sort"),
        QStringLiteral("view_mode"),
        QStringLiteral("open_in_new_tab"),
        QStringLiteral("open_in_new_window"),
        QStringLiteral("copy_location"),
        QStringLiteral("duplicate")
    });
```

#### AUTO 


```{c}
auto animation = new QVariantAnimation(this);
```

#### AUTO 


```{c}
const auto &format
```

#### AUTO 


```{c}
const auto oldHoveredExpansionWidget = oldHoveredExpansionWidgetIterator == visibleItemListWidgets.end() ?
                                           std::nullopt : std::make_optional(*oldHoveredExpansionWidgetIterator);
```

#### AUTO 


```{c}
const auto& matchedPlaces = placesModel->match(placesModel->index(0,0), KFilePlacesModel::UrlRole, QRegularExpression::anchoredPattern(pattern), 1, Qt::MatchRegularExpression);
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<KVersionControlPlugin>(p, parent()).plugin;
```

#### AUTO 


```{c}
auto navigators = static_cast<DolphinNavigatorsWidgetAction *>
                        (actionCollection()->action(QStringLiteral("url_navigators")));
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service, networkFolderButton);
```

#### LAMBDA EXPRESSION 


```{c}
[&fontFamily](auto &&v) {
        v->setFontFamily(fontFamily);
    }
```

#### AUTO 


```{c}
auto trashDirContentChanged = [this]() {
        bool isTrashEmpty = m_trashDirLister->items().isEmpty();
        Q_EMIT emptinessChanged(isTrashEmpty);
    };
```

#### AUTO 


```{c}
const auto result = KMessageBox::createKMessageBox(
                dialog,
                buttons,
                QMessageBox::Warning,
                i18n("The program '%1' is still running in the Terminal panel. Are you sure you want to quit?", m_terminalPanel->runningProgramName()),
                QStringList(),
                i18n("Do not ask again"),
                &doNotAskAgainCheckboxResult,
                KMessageBox::Dangerous);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemListView::ItemLayout& layout : layoutList) {
        // The following settings depend on the layout.
        // Note that 'columns' are actually 'rows' in
        // Compact layout.
        Qt::Orientation scrollOrientation;
        QList<int> columnCountList;
        Qt::Key nextItemKey;
        Qt::Key previousItemKey;
        Qt::Key nextRowKey;
        Qt::Key previousRowKey;

        switch (layout) {
        case KFileItemListView::IconsLayout:
            scrollOrientation = Qt::Vertical;
            columnCountList << 1 << 3 << 5;
            nextItemKey = Qt::Key_Right;
            previousItemKey = Qt::Key_Left;
            nextRowKey = Qt::Key_Down;
            previousRowKey = Qt::Key_Up;
            break;
        case KFileItemListView::CompactLayout:
            scrollOrientation = Qt::Horizontal;
            columnCountList << 1 << 3 << 5;
            nextItemKey = Qt::Key_Down;
            previousItemKey = Qt::Key_Up;
            nextRowKey = Qt::Key_Right;
            previousRowKey = Qt::Key_Left;
            break;
        case KFileItemListView::DetailsLayout:
            scrollOrientation = Qt::Vertical;
            columnCountList << 1;
            nextItemKey = Qt::Key_Down;
            previousItemKey = Qt::Key_Up;
            nextRowKey = Qt::Key_Down;
            previousRowKey = Qt::Key_Up;
            break;
        }

        for (int columnCount : qAsConst(columnCountList)) {
            for (const KItemListController::SelectionBehavior& selectionBehavior : qAsConst(selectionBehaviorList)) {
                for (bool groupingEnabled : qAsConst(groupingEnabledList)) {
                    QList<QPair<KeyPress, ViewState> > testList;

                    // First, key presses which should have the same effect
                    // for any layout and any number of columns.
                    testList
                        << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(1, KItemSet() << 1, true))
                        << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(3, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 2))
                        << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Return), ViewState(4, KItemSet() << 2 << 3, true))
                        << qMakePair(KeyPress(previousItemKey), ViewState(3, KItemSet() << 3))
                        << qMakePair(KeyPress(Qt::Key_Home, Qt::ShiftModifier), ViewState(0, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(1, KItemSet() << 0 << 1 << 2 << 3))
                        << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                        << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(18, KItemSet() << 18 << 19))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Enter), ViewState(0, KItemSet(), true))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Space, Qt::ControlModifier), ViewState(0, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Space), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_3), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(14, KItemSet() << 14))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(15, KItemSet() << 15))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(15, KItemSet()))
                        << qMakePair(KeyPress(Qt::Key_E), ViewState(13, KItemSet() << 13))
                        << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0))
                        << qMakePair(KeyPress(Qt::Key_Escape), ViewState(0, KItemSet()));

                    // Next, we test combinations of key presses which only work for a
                    // particular number of columns and either enabled or disabled grouping.

                    // One column.
                    if (columnCount == 1) {
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(2, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ControlModifier), ViewState(3, KItemSet() << 1 << 2))
                            << qMakePair(KeyPress(previousRowKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(previousItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    // Multiple columns: we test both 3 and 5 columns with grouping
                    // enabled or disabled. For each case, the layout of the items
                    // in the view is shown (both using file names and indices) to
                    // make it easier to understand what the tests do.

                    if (columnCount == 3 && !groupingEnabled) {
                        // 3 columns, no grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1 c1 c2 |  3  4  5
                        // c3 c4 c5 |  6  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4 e1 e2 | 12 13 14
                        // e3 e4 e5 | 15 16 17
                        // e6 e7    | 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(3, KItemSet() << 3))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(4, KItemSet() << 3))
                            << qMakePair(KeyPress(nextRowKey), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(9, KItemSet() << 7 << 8 << 9))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(8, KItemSet() << 7 << 8))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(previousItemKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 5 << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 6 << 7))
                            << qMakePair(KeyPress(nextItemKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7))
                            << qMakePair(KeyPress(nextRowKey), ViewState(10, KItemSet() << 10))
                            << qMakePair(KeyPress(nextItemKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && !groupingEnabled) {
                        // 5 columns, no grouping:
                        //
                        // a1 a2 a3 b1 c1 |  0  1  2  3  4
                        // c2 c3 c4 c5 d1 |  5  6  7  8  9
                        // d2 d3 d4 e1 e2 | 10 11 12 13 14
                        // e3 e4 e5 e6 e7 | 15 16 17 18 19
                        testList
                            << qMakePair(KeyPress(nextRowKey), ViewState(5, KItemSet() << 5))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(6, KItemSet() << 5))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(17, KItemSet() << 12 << 13 << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(7, KItemSet() << 7 << 8 << 9 << 10 << 11 << 12))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ControlModifier), ViewState(19, KItemSet() << 12))
                            << qMakePair(KeyPress(previousRowKey), ViewState(14, KItemSet() << 14))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 3 && groupingEnabled) {
                        // 3 columns, with grouping:
                        //
                        // a1 a2 a3 |  0  1  2
                        // b1       |  3
                        // c1 c2 c3 |  4  5  6
                        // c4 c5    |  7  8
                        // d1 d2 d3 |  9 10 11
                        // d4       | 12
                        // e1 e2 e3 | 13 14 15
                        // e4 e5 e6 | 16 17 18
                        // e7       | 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextItemKey), ViewState(2, KItemSet() << 2))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(6, KItemSet() << 2 << 3 << 4 << 5 << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(8, KItemSet() << 8))
                            << qMakePair(KeyPress(nextRowKey), ViewState(11, KItemSet() << 11))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(12, KItemSet() << 11))
                            << qMakePair(KeyPress(nextRowKey), ViewState(13, KItemSet() << 13))
                            << qMakePair(KeyPress(nextRowKey), ViewState(16, KItemSet() << 16))
                            << qMakePair(KeyPress(nextItemKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    if (columnCount == 5 && groupingEnabled) {
                        // 5 columns, with grouping:
                        //
                        // a1 a2 a3       |  0  1  2
                        // b1             |  3
                        // c1 c2 c3 c4 c5 |  4  5  6  7  8
                        // d1 d2 d3 d4    |  9 10 11 12
                        // e1 e2 e3 e4 e5 | 13 14 15 16 17
                        // e6 e7          | 18 19
                        testList
                            << qMakePair(KeyPress(nextItemKey), ViewState(1, KItemSet() << 1))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(3, KItemSet() << 1 << 2 << 3))
                            << qMakePair(KeyPress(nextRowKey, Qt::ShiftModifier), ViewState(5, KItemSet() << 1 << 2 << 3 << 4 << 5))
                            << qMakePair(KeyPress(nextItemKey), ViewState(6, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(7, KItemSet() << 6))
                            << qMakePair(KeyPress(nextItemKey, Qt::ControlModifier), ViewState(8, KItemSet() << 6))
                            << qMakePair(KeyPress(nextRowKey), ViewState(12, KItemSet() << 12))
                            << qMakePair(KeyPress(nextRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(nextRowKey), ViewState(19, KItemSet() << 19))
                            << qMakePair(KeyPress(previousRowKey), ViewState(17, KItemSet() << 17))
                            << qMakePair(KeyPress(Qt::Key_End, Qt::ShiftModifier), ViewState(19, KItemSet() << 17 << 18 << 19))
                            << qMakePair(KeyPress(previousRowKey, Qt::ShiftModifier), ViewState(14, KItemSet() << 14 << 15 << 16 << 17))
                            << qMakePair(KeyPress(Qt::Key_Home), ViewState(0, KItemSet() << 0));
                    }

                    const QString testName =
                        layoutNames[layout] + ", " +
                        QString("%1 columns, ").arg(columnCount) +
                        selectionBehaviorNames[selectionBehavior] + ", " +
                        groupingEnabledNames[groupingEnabled];

                    const QByteArray testNameAscii = testName.toLatin1();

                    QTest::newRow(testNameAscii.data())
                        << layout
                        << scrollOrientation
                        << columnCount
                        << selectionBehavior
                        << groupingEnabled
                        << testList;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_emptyTrashButton->setVisible(m_view->url().scheme() == QLatin1String("trash"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
                Dolphin::openNewWindow({m_fileInfo.url()}, m_mainWindow, Dolphin::OpenNewWindowFlag::Select);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
            const int lastIndex = insertedCount + range.index + range.count - 1;
            for (int i = insertedCount + range.index; i <= lastIndex; ++i) {
                if (timer.elapsed() < MaxBlockTimeout) {
                    applySortRole(i);
                } else {
                    m_pendingSortRoleItems.insert(m_model->fileItem(i));
                }
            }
            insertedCount += range.count;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        const QUrl itemUrl = placesItem(index)->url();
        if (itemUrl.isValid()) {
            urls << itemUrl;
        }
        stream << index;
    }
```

#### AUTO 


```{c}
auto reply = openFiles ? interface.first->openFiles(interface.second, splitView) : interface.first->openDirectories(interface.second, splitView);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIO::UDSEntry& entry : list) {
        const QString name = entry.stringValue(KIO::UDSEntry::UDS_NAME);
        if (name != QLatin1Char('.') && name != QLatin1String("..") && entry.isDir()) {
            ++m_progress;

            QUrl url(m_dir);
            url = url.adjusted(QUrl::StripTrailingSlash);
            url.setPath(url.path() + '/' + name);

            Q_ASSERT(m_viewProps);

            ViewProperties props(url);
            props.setDirProperties(*m_viewProps);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KServiceAction &action : serviceActions) {
            const QString serviceName = action.name();
            const bool addService = !action.noDisplay() && !action.isSeparator() && !isInServicesList(serviceName);

            if (addService) {
                const QString itemName = subMenuName.isEmpty()
                                         ? action.text()
                                         : i18nc("@item:inmenu", "%1: %2", subMenuName, action.text());
                const bool checked = showGroup.readEntry(serviceName, true);
                addRow(action.icon(), itemName, serviceName, checked);
            }
        }
```

#### AUTO 


```{c}
const auto locations = QStandardPaths::locateAll(QStandardPaths::GenericDataLocation, QStringLiteral("kio/servicemenus"), QStandardPaths::LocateDirectory);
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QString(), [](const KPluginMetaData& metaData) {
        return metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"));
    });
```

#### AUTO 


```{c}
const auto checkedRoles = QSet<QByteArray>(current.constBegin(), current.constEnd());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : visibleRoles) {
            const qreal width = columnWidths.value(role);
            m_headerWidget->setColumnWidth(role, width);
        }
```

#### AUTO 


```{c}
const auto normalColor = option.palette.color(normalTextColorRole());
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : sortByActionGroupActions) {
        sortByActionMenu->addAction(action);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&list](const entry& s) { list.append(s.second); }
```

#### AUTO 


```{c}
auto storageAccess = device.as<Solid::StorageAccess>();
```

#### AUTO 


```{c}
const auto pair = s_cache->value(path);
```

#### AUTO 


```{c}
const auto visibleItems = m_visibleItems;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &changedEntries) {
           if (!changedEntries.isEmpty()) {
               m_serviceModel->clear();
               loadServices();
           }
    }
```

#### AUTO 


```{c}
const auto groupIndexes = m_sourceModel->groupIndexes(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : items) {
        selectedItems.append(m_model->fileItem(index));
    }
```

#### AUTO 


```{c}
const auto stdoutResult = QString::fromUtf8(process.readAllStandardOutput()).trimmed();
```

#### RANGE FOR STATEMENT 


```{c}
for (int index: previous) {
            int inc = 0;
            for (const KItemRange& itemRange : itemRanges) {
                if (index < itemRange.index) {
                    break;
                }
                inc += itemRange.count;
            }
            m_selectedItems.insert(index + inc);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& str : uriList) {
        const QUrl url = QUrl::fromUserInput(str, currentDir, QUrl::AssumeLocalFile);
        if (url.isValid()) {
            urls.append(url);
        } else {
            qCWarning(DolphinDebug) << "Invalid URL: " << str;
        }
    }
```

#### AUTO 


```{c}
auto it = indexesForUrl.find(url);
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
            KNotification::event(QStringLiteral("Trash: emptied"), i18n("Trash Emptied"),
                                 i18n("The Trash was emptied."), QStringLiteral("user-trash"),
                                 nullptr, KNotification::DefaultEvent);
        }
```

#### AUTO 


```{c}
const auto sortByActionGroupActions = sortByActionGroup->actions();
```

#### AUTO 


```{c}
auto contextMenuSettingsPage = new ContextMenuSettingsPage(this, actions, {
        QStringLiteral("add_to_places"),
        QStringLiteral("sort"),
        QStringLiteral("view_mode"),
        QStringLiteral("open_in_new_tab"),
        QStringLiteral("open_in_new_window"),
        QStringLiteral("copy_location"),
        QStringLiteral("duplicate"),
        QStringLiteral("open_terminal"),
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &searchToken : searchTokens) {
        if (term.startsWith(searchToken)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItemModel::RoleInfo& info : rolesInfo) {
        m_sorting->addItem(info.translation, info.role);
    }
```

#### AUTO 


```{c}
const auto &arg
```

#### AUTO 


```{c}
auto *delegate = new ServiceItemDelegate(m_listView, m_listView);
```

#### AUTO 


```{c}
const auto startFilelightDeviceAction = addAction(i18nc("@action:inmenu %1 service name", "%1 - current device", filelightService->genericName()));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        bool isTrashEmpty = m_trashDirLister->items().isEmpty();
        emit emptinessChanged(isTrashEmpty);
    }
```

#### AUTO 


```{c}
auto linkDestination = link.linkDest();
```

#### AUTO 


```{c}
const auto devices = Solid::Device::listFromType(Solid::DeviceInterface::NetworkShare);
```

#### AUTO 


```{c}
const auto width = (scaledIconSize + m_scaledPixmapSize.width()) / 2.0;
```

#### AUTO 


```{c}
const auto konsoleNotInstalledText = i18n("Terminal cannot be shown because Konsole is not installed. "
                                                      "Please install it and then reopen the panel.");
```

#### AUTO 


```{c}
const auto direction = widget ? widget->layoutDirection() : qApp->layoutDirection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& visibleRole : qAsConst(m_visibleRoles)) {
        const QString headerText = m_model->roleDescription(visibleRole);
        const qreal headerWidth = fontMetrics.horizontalAdvance(headerText) + gripMargin + headerMargin * 2;
        widths.insert(visibleRole, headerWidth);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : files) {
        const QUrl dir(url.adjusted(QUrl::RemoveFilename));
        if (!dirs.contains(dir)) {
            dirs.append(dir);
        }
    }
```

#### AUTO 


```{c}
auto standardButtons = QDialogButtonBox::Yes | QDialogButtonBox::Cancel;
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData* itemData : qAsConst(itemDataList)) {
            if (itemData->values.isEmpty()) {
                itemData->values = retrieveData(itemData->item, itemData->parent);
            }
        }
```

#### AUTO 


```{c}
const auto item = changedFileItems.findByUrl(m_shownUrl);
```

#### AUTO 


```{c}
auto valueB = b->values.value("count");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : plugins) {
            if (enabledPlugins.contains(p.name())) {
                auto plugin = KPluginFactory::instantiatePlugin<KVersionControlPlugin>(p).plugin;
                if (plugin) {
                    m_plugins.append(plugin);
                    loadedPlugins += p.name();
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->fontFamily();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tagName : qAsConst(allTags)) {
        QAction* action = m_tagsSelector->menu()->addAction(QIcon::fromTheme(QStringLiteral("tag")), tagName);
        action->setCheckable(true);
        action->setChecked(m_searchTags.contains(tagName));

        connect(action, &QAction::triggered, this, [this, tagName, onlyOneTag](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            emit facetChanged();

            if (!onlyOneTag) {
                m_tagsSelector->menu()->show();
            }
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : argVariants) {
            if (runInstallerScriptOnce(path, {arg})) {
                return true;
            }
        }
```

#### AUTO 


```{c}
auto res = walkDir(path, countHiddenFiles, countDirectoriesOnly, dirEntry, maxRecursiveLevel);
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginLoader::findPlugins(QStringLiteral("kf5/kfileitemaction"), [=](const KPluginMetaData& metaData) {
        if (!metaData.serviceTypes().contains(QStringLiteral("KFileItemAction/Plugin"))) {
            return false;
        }

        auto mimeType = QMimeDatabase().mimeTypeForName(commonMimeType);
        foreach (const auto& supportedMimeType, metaData.mimeTypes()) {
            if (mimeType.inherits(supportedMimeType)) {
                return true;
            }
        }

        return false;
    });
```

#### AUTO 


```{c}
const auto basenames2 = QStringList{"install-it.sh", "install-it", "installKDE4.sh",
                                                "installKDE4", "install.sh", "install"};
```

#### AUTO 


```{c}
auto innerLayout = new QVBoxLayout(additionalInfoBox);
```

#### AUTO 


```{c}
auto okButton = buttonBox->button(QDialogButtonBox::Ok);
```

#### AUTO 


```{c}
const auto entry =  job->statResult();
```

#### AUTO 


```{c}
auto setStandardActionWhatsThis = [this](KStandardAction::StandardAction actionId,
                                             const QString &whatsThis) {
        if (auto *action = actionCollection()->action(KStandardAction::name(actionId))) {
            action->setWhatsThis(whatsThis);
        }
    };
```

#### AUTO 


```{c}
auto lambdaLessThan = [&] (const KFileItemModel::ItemData* a, const KFileItemModel::ItemData* b)
            {
                const QByteArray role = roleForType(m_sortRole);
                return a->values.value(role).toString() < b->values.value(role).toString();
            };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
        openTerminalJob(url);
    }
```

#### AUTO 


```{c}
const auto response = KMessageBox::warningYesNoCancel(this,
                                        i18n("You have unsaved changes. Do you want to apply the changes or discard them?"),
                                        i18n("Warning"),
                                        KStandardGuiItem::save(),
                                        KStandardGuiItem::discard(),
                                        KStandardGuiItem::cancel());
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto *navigatorsWidgetAction = new DolphinNavigatorsWidgetAction(this);
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->fontSize();
    }
```

#### AUTO 


```{c}
const auto startKDiskFreeAction = addAction(kdiskfreeService->genericName());
```

#### AUTO 


```{c}
const auto& matchedPlaces = placesModel->match(placesModel->index(0,0), KFilePlacesModel::UrlRole, QUrl(url().adjusted(QUrl::StripTrailingSlash).toString(QUrl::FullyEncoded).append("/?")), 1, Qt::MatchRegExp);
```

#### AUTO 


```{c}
auto undoAction = actionCollection()->action(KStandardAction::name(KStandardAction::Undo));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& tagName : qAsConst(allTags)) {
        QAction* action = m_tagsSelector->menu()->addAction(QIcon::fromTheme(QStringLiteral("tag")), tagName);
        action->setCheckable(true);
        action->setChecked(m_searchTags.contains(tagName));

        connect(action, &QAction::triggered, this, [this, tagName](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            emit facetChanged();

            m_tagsSelector->menu()->show();
        });
    }
```

#### AUTO 


```{c}
auto contextMenuSettingsPage = new ContextMenuSettingsPage(this, actions, {
        QStringLiteral("add_to_places"),
        QStringLiteral("sort"),
        QStringLiteral("view_mode"),
        QStringLiteral("open_in_new_tab"),
        QStringLiteral("open_in_new_window"),
        QStringLiteral("copy_location"),
        QStringLiteral("duplicate"),
        QStringLiteral("open_terminal_here")
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](QChar c1, QChar c2) -> bool {
                    return m_collator.compare(c1, c2) < 0;
                }
```

#### AUTO 


```{c}
auto basicActionsMenuActions = basicActionsMenu->menu()->actions();
```

#### AUTO 


```{c}
const auto viewContainer
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : qAsConst(m_plugins)) {
        const QString fileName = directory.path() + '/' + it.second;
        if (QFile::exists(fileName)) {
            // The score of this plugin is 0 (best), so we can just return this plugin,
            // instead of going through the plugin scoring procedure, we can't find a better one ;)
            return it.first;
        }

        // Version control systems like Git provide the version information
        // file only in the root directory. Check whether the version information file can
        // be found in one of the parent directories. For performance reasons this
        // step is only done, if the previous directory was marked as versioned by
        // m_versionedDirectory. Drawback: Until e. g. Git is recognized, the root directory
        // must be shown at least once.
        if (m_versionedDirectory) {
            QUrl dirUrl(directory);
            QUrl upUrl = KIO::upUrl(dirUrl);
            int upUrlCounter = 1;
            while ((upUrlCounter < bestScore) && (upUrl != dirUrl)) {
                const QString fileName = dirUrl.path() + '/' + it.second;
                if (QFile::exists(fileName)) {
                    if (upUrlCounter < bestScore) {
                        bestPlugin = it.first;
                        bestScore = upUrlCounter;
                    }
                    break;
                }
                dirUrl = upUrl;
                upUrl = KIO::upUrl(dirUrl);
                ++upUrlCounter;
            }
        }
    }
```

#### AUTO 


```{c}
auto plugin = qobject_cast<KOverlayIconPlugin *>(instance);
```

#### AUTO 


```{c}
auto formatDate = [formatter, local](const QDateTime& time) {
        if (DetailsModeSettings::useShortRelativeDates()) {
            return formatter.formatRelativeDateTime(time, QLocale::ShortFormat);
        } else {
            return local.toString(time, QLocale::ShortFormat);
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPointer<KVersionControlPlugin> &plugin : qAsConst(m_plugins)) {
            actions << plugin->outOfVersionControlActions(items);
        }
```

#### AUTO 


```{c}
const auto basenames1 = QStringList{"install-it.sh", "install-it"};
```

#### AUTO 


```{c}
auto localeAwareLessThan = [this](const QChar& c1, const QChar& c2) -> bool {
                    return m_collator.compare(c1, c2) < 0;
                };
```

#### LAMBDA EXPRESSION 


```{c}
[networkFolderButton, urlNavigator, service]() {
        networkFolderButton->setVisible(service && urlNavigator->locationUrl().scheme() == QLatin1String("remote"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tagName, onlyOneTag](bool isChecked) {
            if (isChecked) {
                addSearchTag(tagName);
            } else {
                removeSearchTag(tagName);
            }
            Q_EMIT facetChanged();

            if (!onlyOneTag) {
                m_tagsSelector->menu()->show();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        KFileItem item = m_model->fileItem(index);
        const QUrl& url = openItemAsFolderUrl(item);

        if (!url.isEmpty()) { // Open folders in new tabs
            Q_EMIT tabRequested(url);
        } else {
            items.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData* itemData : itemDataList) {
            if (m_filter.matches(itemData->item)) {
                m_pendingItemsToInsert.append(itemData);
                if (itemData->parent) {
                    parentsToEnsureVisible.insert(itemData->parent);
                }
            } else {
                m_filteredItems.insert(itemData->item, itemData);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[previewSize](auto &&v) {
        v->setPreviewSize(previewSize);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job]() {
            QUrl statUrl;
            if (!job->error()) {
                statUrl = job->mostLocalUrl();
            }

            KToolInvocation::invokeTerminal(QString(), statUrl.isLocalFile() ? statUrl.toLocalFile() : QDir::homePath());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : qAsConst(m_watchedDirs)) {
                m_dirWatcher->removeDir(path);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& service: dolphinServices) {
        if (!service.second.isEmpty()) {
            service.first->call(openFiles ? QStringLiteral("openFiles") : QStringLiteral("openDirectories"), service.second, splitView);
            service.first->call(QStringLiteral("activateWindow"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : files) {
        if (m_shownUrl == QUrl::fromLocalFile(fileName)) {
            // the currently shown item has been removed, show
            // the parent directory as fallback
            markUrlAsInvalid();
            break;
        }
    }
```

#### AUTO 


```{c}
auto feedbackProvider = DolphinFeedbackProvider::instance();
```

#### AUTO 


```{c}
const auto oldHoveredExpansionWidgetIterator = std::find_if(visibleItemListWidgets.begin(), visibleItemListWidgets.end(), [](auto &widget) {
        return widget->expansionAreaHovered();
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (oldHoveredExpansionWidget) {
            // then the expansion toggle
            (*oldHoveredExpansionWidget)->setExpansionAreaHovered(false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[networkFolderButton, service]() {
                auto *job = new KIO::ApplicationLauncherJob(service, networkFolderButton);
                auto *delegate = new KNotificationJobUiDelegate;
                delegate->setAutoErrorHandlingEnabled(true);
                job->setUiDelegate(delegate);
                job->start();
            }
```

#### AUTO 


```{c}
auto kdeGlobalsConfig = KConfigGroup(KSharedConfig::openConfig(), QStringLiteral("KDE"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : itemRanges) {
        rangesItemCount += range.count;
    }
```

#### AUTO 


```{c}
const auto groupType = KFilePlacesModel::groupType(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (KItemListWidget* widget : widgets) {
        if (widget->isHovered()) {
            widget->setHovered(false);
            Q_EMIT itemUnhovered(widget->index());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_columns)) {
        ++index;
        x += m_columnWidths.value(role);
        if (pos.x() <= x) {
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QChar c1, QChar c2) -> bool {
                        return m_collator.compare(c1, c2) < 0;
                    }
```

#### AUTO 


```{c}
auto menu = menuFactory.createMenuFromGroupingNames(
            { "disk-usage", "more:", "disk-partitions" }, m_url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : basenames1) {
            const auto path = findRecursive(dir, basename);
            if (!path.isEmpty()) {
                installItPath = path;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr& service : plugins) {
        const bool configurable = service->property(QStringLiteral("Configurable"), QVariant::Bool).toBool();
        const bool show = m_enabledPreviewPlugins.contains(service->desktopEntryName());

        model->insertRow(0);
        const QModelIndex index = model->index(0, 0);
        model->setData(index, show, Qt::CheckStateRole);
        model->setData(index, configurable, ServiceModel::ConfigurableRole);
        model->setData(index, service->name(), Qt::DisplayRole);
        model->setData(index, service->desktopEntryName(), ServiceModel::DesktopEntryNameRole);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int oldIndex : previous) {
            const int index = indexAfterRangesRemoving(oldIndex, itemRanges, DiscardRemovedIndex);
            if (index >= 0)  {
                m_selectedItems.insert(index);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        KFileItem item = m_model->fileItem(index);
        const QUrl& url = openItemAsFolderUrl(item);

        if (!url.isEmpty()) { // Open folders in new tabs
            emit tabRequested(url);
        } else {
            items.append(item);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        if (view()->mode() == DolphinView::Mode::DetailsView) {
            view()->reload();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : basenames1) {
            const auto path = findRecursive(dir, basename);
            if (!path.isEmpty()) {
                deinstallPath = path;
                break;
            }
        }
```

#### AUTO 


```{c}
auto leftViewContainer = tabWidget->currentTabPage()->primaryViewContainer();
```

#### AUTO 


```{c}
const auto urls = QUrl::toStringList(inputUrls);
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : items) {
        cells.append(cell(index));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[formatter, local](const QDateTime& time) {
        if (DetailsModeSettings::useShortRelativeDates()) {
            return formatter.formatRelativeDateTime(time, QLocale::ShortFormat);
        } else {
            return local.toString(time, QLocale::ShortFormat);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int value) {
            m_recursiveDirectorySizeLimit->setSuffix(i18np(" level deep", " levels deep", value));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_visibleRoles)) {
                if (m_headerWidget->columnWidth(role) == 0) {
                    const qreal width = m_headerWidget->preferredColumnWidth(role);
                    m_headerWidget->setColumnWidth(role, width);
                }
            }
```

#### AUTO 


```{c}
const auto job = KIO::statDetails(m_model->rootItem().url(), KIO::StatJob::SourceSide, KIO::StatRecursiveSize, KIO::HideProgressInfo);
```

#### AUTO 


```{c}
const auto extensionWidth = m_customizedFontMetrics.boundingRect(text.right(extensionLength)).width();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, KIO::filesize_t size, KIO::filesize_t available) {
            // even if we receive an error we want to refresh lastUpdated to avoid repeatedly querying in this case
            m_freeSpaceInfo.lastUpdated.setRemainingTime(CAPACITYBAR_CACHE_TTL);

            if (job->error()) {
                return;
            }

            m_freeSpaceInfo.size = size;
            m_freeSpaceInfo.used = size - available;
            m_freeSpaceInfo.usedRatio = (qreal)m_freeSpaceInfo.used / (qreal)m_freeSpaceInfo.size;
            m_drawCapacityBar = size > 0;

            update();
        }
```

#### AUTO 


```{c}
auto deleteAction = KStandardAction::deleteFile(this, &DolphinViewActionHandler::slotDeleteItems, m_actionCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto animation : qAsConst(m_rubberBandAnimations)) {
        QRectF rubberBandRect = animation->property(RubberPropertyName).toRectF();

        const QPointF topLeft = rubberBandRect.topLeft();
        if (scrollOrientation() == Qt::Vertical) {
            rubberBandRect.moveTo(topLeft.x(), topLeft.y() - scrollOffset());
        } else {
            rubberBandRect.moveTo(topLeft.x() - scrollOffset(), topLeft.y());
        }

        QStyleOptionRubberBand opt;
        initStyleOption(&opt);
        opt.shape = QRubberBand::Rectangle;
        opt.opaque = false;
        opt.rect = rubberBandRect.toRect();

        painter->save();

        painter->setOpacity(animation->currentValue().toReal());
        style()->drawControl(QStyle::CE_RubberBand, &opt, painter);

        painter->restore();
    }
```

#### AUTO 


```{c}
static const auto map = QHash<Property, QByteArray> {
            { Property::Rating,            QByteArrayLiteral("rating") },
            { Property::Comment,           QByteArrayLiteral("comment") },
            { Property::Title,             QByteArrayLiteral("title") },
            { Property::Author,            QByteArrayLiteral("author") },
            { Property::WordCount,         QByteArrayLiteral("wordCount") },
            { Property::LineCount,         QByteArrayLiteral("lineCount") },
            { Property::Width,             QByteArrayLiteral("width") },
            { Property::Height,            QByteArrayLiteral("height") },
            { Property::ImageDateTime,     QByteArrayLiteral("imageDateTime") },
            { Property::ImageOrientation,  QByteArrayLiteral("orientation") },
            { Property::Artist,            QByteArrayLiteral("artist") },
            { Property::Genre,             QByteArrayLiteral("genre")  },
            { Property::Album,             QByteArrayLiteral("album") },
            { Property::Duration,          QByteArrayLiteral("duration") },
            { Property::BitRate,           QByteArrayLiteral("bitrate") },
            { Property::AspectRatio,       QByteArrayLiteral("aspectRatio") },
            { Property::FrameRate,         QByteArrayLiteral("frameRate") },
            { Property::ReleaseYear,       QByteArrayLiteral("releaseYear") },
            { Property::TrackNumber,       QByteArrayLiteral("track") }
        };
```

#### AUTO 


```{c}
const auto basenames2 = QStringList{"installKDE4.sh", "installKDE4", "install.sh", "install"};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &service : entries) {
        const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, "kservices5/" % service->entryPath());
        const QList<KServiceAction> serviceActions = KDesktopFileActions::userDefinedServices(file, true);

        const KDesktopFile desktopFile(file);
        const QString subMenuName = desktopFile.desktopGroup().readEntry("X-KDE-Submenu");

        for (const KServiceAction &action : serviceActions) {
            const QString serviceName = action.name();
            const bool addService = !action.noDisplay() && !action.isSeparator() && !isInServicesList(serviceName);

            if (addService) {
                const QString itemName = subMenuName.isEmpty()
                                         ? action.text()
                                         : i18nc("@item:inmenu", "%1: %2", subMenuName, action.text());
                const bool checked = showGroup.readEntry(serviceName, true);
                addRow(action.icon(), itemName, serviceName, checked);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_sortedVisibleRoles)) {
        if (role == "text") {
            continue;
        }

        const QString text = roleText(role, values);
        TextInfo* textInfo = m_textInfo.value(role);
        textInfo->staticText.setText(text);

        qreal requiredWidth = 0;

        QTextLayout layout(text, m_customizedFont);
        QTextOption textOption;
        textOption.setWrapMode(QTextOption::NoWrap);
        layout.setTextOption(textOption);

        layout.beginLayout();
        QTextLine textLine = layout.createLine();
        if (textLine.isValid()) {
            textLine.setLineWidth(maxWidth);
            requiredWidth = textLine.naturalTextWidth();
            if (requiredWidth > maxWidth) {
                const QString elidedText = elideRightKeepExtension(text, maxWidth);
                textInfo->staticText.setText(elidedText);
                requiredWidth = m_customizedFontMetrics.horizontalAdvance(elidedText);
            } else if (role == "rating") {
                // Use the width of the rating pixmap, because the rating text is empty.
                requiredWidth = m_rating.width() / m_rating.devicePixelRatioF();
            }
        }
        layout.endLayout();

        textInfo->pos = QPointF(padding, y);
        textInfo->staticText.setTextWidth(maxWidth);

        const QRectF textRect(padding + (maxWidth - requiredWidth) / 2, y, requiredWidth, lineSpacing);

        // Ignore empty roles. Avoids a text rect taller than the area that actually contains text.
        if (!textRect.isEmpty()) {
            m_textRect |= textRect;
        }

        y += lineSpacing;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : qAsConst(basenames2)) {
                const auto path = findRecursive(dir, basename);
                if (!path.isEmpty()) {
                    installerPath = path;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &format : formats) {
        // from KFilePlacesModel::_k_internalMimetype
        if (format.startsWith(QLatin1String("application/x-kfileplacesmodel-"))) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        KFileItem item = m_model->fileItem(index);
        const QUrl& url = openItemAsFolderUrl(item);

        if (!url.isEmpty()) { // Open folders in new tabs
            emit tabRequested(url, DolphinTabWidget::AfterLastTab);
        } else {
            items.append(item);
        }
    }
```

#### AUTO 


```{c}
const auto associatedWidgets = action->associatedWidgets();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& interface: dolphinInterfaces) {
            auto isUrlOpenReply = interface.first->isUrlOpen(url);
            isUrlOpenReply.waitForFinished();
            if (!isUrlOpenReply.isError() && isUrlOpenReply.value()) {
                interface.second.append(url);
                urlFound = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[iconSize](auto &&v) {
        v->setIconSize(iconSize);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : basenames2) {
                const auto path = findRecursive(dir, basename);
                if (!path.isEmpty()) {
                    installerPath = path;
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->italicFont();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        m_currentView->setSortOrder(Qt::DescendingOrder);
    }
```

#### AUTO 


```{c}
auto *downloadButton = new NewStuffButton(i18nc("@action:button", "Download New Services..."),
                                              QStringLiteral("servicemenu.knsrc"),
                                              this);
```

#### AUTO 


```{c}
const auto code = KMessageBox::questionYesNo(this,
                                                             oldItem.isFile() ? i18n("Adding a dot to the beginning of this file's name will hide it from view.\n"
                                                                                     "Do you still want to rename it?")
                                                                              : i18n("Adding a dot to the beginning of this folder's name will hide it from view.\n"
                                                                                     "Do you still want to rename it?"),
                                                             oldItem.isFile() ? i18n("Hide this File?") : i18n("Hide this Folder?"),
                                                             yesGuiItem,
                                                             KStandardGuiItem::cancel(),
                                                             QStringLiteral("ConfirmHide")
                                                            );
```

#### RANGE FOR STATEMENT 


```{c}
for (SettingsPageBase* page : qAsConst(m_pages)) {
        page->restoreDefaults();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                // We have to wait for DolphinUrlNavigator::sizeHint() to update which
                // happens a little bit later than when urlChanged is emitted.
                this->m_adjustSpacingTimer->start();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](){
            KNotification::event(QStringLiteral("Trash: emptied"), QString(), QPixmap(), nullptr, KNotification::DefaultEvent);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_metaDataWidget->setConfigurationMode(Baloo::ConfigurationMode::Accept);
                m_configureButtons->setVisible(false);
                m_configureLabel->setVisible(false);
                emit configurationFinished();
            }
```

#### AUTO 


```{c}
auto navigators = static_cast<DolphinNavigatorsWidgetAction *>
        (actionCollection()->action(QStringLiteral("url_navigators")));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& itemRange : itemRanges) {
        int index = itemRange.index;
        for (int count = itemRange.count; count > 0; --count) {
            const KFileItem item = m_model->fileItem(index);
            targetSet.insert(item);
            ++index;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const ItemData *item) {
                return item->item.time(KFileItem::AccessTime);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : argVariants) {
            if (runScriptOnce(path, {arg}, ScriptExecution::Process)) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : qAsConst(itemSet)) {
        Q_ASSERT(result.contains(i));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_metaDataWidget->setConfigurationMode(Baloo::ConfigurationMode::Cancel);
                m_configureButtons->setVisible(false);
                m_configureLabel->setVisible(false);
                emit configurationFinished();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { Trash::empty(this); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : pluginServices) {
        const QString pluginName = plugin->name();
        addRow(QStringLiteral("code-class"),
               pluginName,
               VersionControlServicePrefix + pluginName,
               enabledPlugins.contains(pluginName));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData *item : newVisibleItems) {
        for (ItemData *parent = item->parent; parent && !parentsToEnsureVisible.contains(parent); parent = parent->parent) {
            parentsToEnsureVisible.insert(parent);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        const bool show = m_enabledPreviewPlugins.contains(plugin.pluginId());

        model->insertRow(0);
        const QModelIndex index = model->index(0, 0);
        model->setData(index, show, Qt::CheckStateRole);
        model->setData(index, plugin.name(), Qt::DisplayRole);
        model->setData(index, plugin.pluginId(), ServiceModel::DesktopEntryNameRole);

#if KIOWIDGETS_BUILD_DEPRECATED_SINCE(5, 87)
        const bool configurable = plugin.value(QStringLiteral("Configurable"), false);
        model->setData(index, configurable, ServiceModel::ConfigurableRole);
#endif
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        ItemData* itemData = new ItemData();
        itemData->item = item;
        itemData->parent = parentItem;
        itemDataList.append(itemData);
    }
```

#### AUTO 


```{c}
const auto urlsFromMimeData = KUrlMimeData::urlsFromMimeData(mimeData);
```

#### AUTO 


```{c}
const auto jsonPlugins = KPluginMetaData::findPlugins(QStringLiteral("kf5/kfileitemaction"));
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
        KFileItem item = m_model->fileItem(index);
        const QUrl& url = openItemAsFolderUrl(item);

        if (!url.isEmpty()) {
            // Open folders in new tabs or in new windows depending on the modifier
            // The ctrl+shift behavior is ignored because we are handling multiple items
            // keep in sync with KUrlNavigator::slotNavigatorButtonClicked
            if (modifiers & Qt::ShiftModifier && !(modifiers & Qt::ControlModifier)) {
                Q_EMIT windowRequested(url);
            } else {
                Q_EMIT tabRequested(url);
            }
        } else {
            items.append(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : roles) {
        if (changedRoles.contains(role)) {
            return true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] (QDBusPendingCallWatcher* watcher) {
        watcher->deleteLater();
        if (!reply.isError()) {
            // Successfully mounted, point to the KIOFuse equivalent path.
            sendCdToTerminal(reply.value());
        }
    }
```

#### AUTO 


```{c}
auto animation
```

#### AUTO 


```{c}
const auto startFilelightDirectoryAction = addAction(filelightService->genericName() + " - "
                    + i18nc("@action:inmenu", "current folder"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const ItemData *item) {
                return item->item.time(KFileItem::CreationTime);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KItemRange& range : qAsConst(other.m_itemRanges)) {
        *it++ = range.index;
        *it++ = range.index + range.count;
    }
```

#### AUTO 


```{c}
auto plugins = KPluginLoader::instantiatePlugins(QStringLiteral("kf5/overlayicon"), nullptr, qApp);
```

#### AUTO 


```{c}
auto *action = m_helpMenu->action(menuId)
```

#### LAMBDA EXPRESSION 


```{c}
[this, listOpenFilesJob](KJob*) {
                const KProcessList::KProcessInfoList blockingProcesses = listOpenFilesJob->processInfoList();
                QString errorString;
                if (blockingProcesses.isEmpty()) {
                    errorString = i18n("One or more files on this device are open within an application.");
                } else {
                    QStringList blockingApps;
                    for (const auto& process : blockingProcesses) {
                        blockingApps << process.name();
                    }
                    blockingApps.removeDuplicates();
                    errorString = xi18np("One or more files on this device are opened in application <application>\"%2\"</application>.",
                            "One or more files on this device are opened in following applications: <application>%2</application>.",
                            blockingApps.count(), blockingApps.join(i18nc("separator in list of apps blocking device unmount", ", ")));
                }
                Q_EMIT errorMessage(errorString);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : roles) {
        if (!m_columnWidths.contains(role)) {
            m_preferredColumnWidths.remove(role);
        }
    }
```

#### AUTO 


```{c}
auto cutShortcuts = cut->shortcuts();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& visibleRole : qAsConst(m_columns)) {
        if (visibleRole == role) {
            return x;
        }

        x += m_columnWidths.value(visibleRole);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](auto &&v) {
        return v->fontWeight();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            m_rubberBandAnimations.removeAll(animation);
            delete animation;
        }
```

#### AUTO 


```{c}
const auto startFilelightDirectoryAction = addAction("Filelight" + notInstalled);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto viewContainer : viewContainers) {
        bookmarks << FutureBookmark(title(viewContainer), url(viewContainer), icon(viewContainer));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : qAsConst(m_columns)) {
        const qreal roleWidth = m_columnWidths.value(role);
        const QRectF rect(x, 0, roleWidth, size().height());
        paintRole(painter, role, rect, orderIndex, widget);
        x += roleWidth;
        ++orderIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& overlay : overlays) {
            if (!overlay.isEmpty()) {
                // There is at least one overlay, draw all overlays above m_pixmap
                // and cancel the check
                KIconLoader::global()->drawOverlays(overlays, scaledPixmap, KIconLoader::Desktop);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : qAsConst(m_plugins)) {
        // first naively check if we are at working copy root
        const QString fileName = directory.path() + '/' + plugin->fileName();
        if (QFile::exists(fileName)) {
            m_localRepoRoot = directory.path();
            return plugin;
        }
        auto root = plugin->localRepositoryRoot(directory.path());
        if (!root.isEmpty()) {
            m_localRepoRoot = root;
            return plugin;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QWidget* widget : associatedWidgets) {
        if (widget == toolBarWidget) {
            return false;
        }
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (auto oldHoveredWidget = hoveredWidget(); oldHoveredWidget) {
            // handle the text+icon one
            oldHoveredWidget->setHovered(false);
            Q_EMIT itemUnhovered(oldHoveredWidget->index());
        }
```

#### AUTO 


```{c}
const auto &jsonMetadata
```

#### AUTO 


```{c}
const auto &file
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData *parent : parentsToEnsureVisible) {
            for (; parent && m_filteredItems.remove(parent->item); parent = parent->parent) {
                m_pendingItemsToInsert.append(parent);
            }
        }
```

#### AUTO 


```{c}
auto secondaryNavigator = m_navigatorsWidget->secondaryUrlNavigator();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &plugin : plugins) {
        const bool configurable = plugin.value(QStringLiteral("Configurable"), false);
        const bool show = m_enabledPreviewPlugins.contains(plugin.pluginId());

        model->insertRow(0);
        const QModelIndex index = model->index(0, 0);
        model->setData(index, show, Qt::CheckStateRole);
        model->setData(index, configurable, ServiceModel::ConfigurableRole);
        model->setData(index, plugin.name(), Qt::DisplayRole);
        model->setData(index, plugin.pluginId(), ServiceModel::DesktopEntryNameRole);
    }
```

#### AUTO 


```{c}
auto emptyTrashButton = new QPushButton(QIcon::fromTheme(QStringLiteral("user-trash")),
                                        i18nc("@action:button", "Empty Trash"), parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemState& item : items) {
            const KFileItem& fileItem = item.first;
            const KVersionControlPlugin::ItemVersion version = item.second;
            QHash<QByteArray, QVariant> values;
            values.insert("version", QVariant(version));
            m_model->setData(m_model->index(fileItem), values);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &plugin : qAsConst(m_plugins)) {
            connect(plugin, &KVersionControlPlugin::itemVersionsChanged,
                this, &VersionControlObserver::silentDirectoryVerification);
            connect(plugin, &KVersionControlPlugin::infoMessage,
                this, &VersionControlObserver::infoMessage);
            connect(plugin, &KVersionControlPlugin::errorMessage,
                this, &VersionControlObserver::errorMessage);
            connect(plugin, &KVersionControlPlugin::operationCompletedMessage,
                this, &VersionControlObserver::operationCompletedMessage);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : items) {
        // Only determine mime types for files here. For directories,
        // KFileItem::determineMimeType() reads the .directory file inside to
        // load the icon, but this is not necessary at all if we just need the
        // type. Some special code for setting the correct mime type for
        // directories is in retrieveData().
        if (!item.isDir()) {
            item.determineMimeType();
        }

        if (timer.elapsed() > timeout) {
            // Don't block the user interface, let the remaining items
            // be resolved asynchronously.
            return;
        }
    }
```

#### AUTO 


```{c}
auto layout = new QFormLayout(this);
```

#### AUTO 


```{c}
const auto loadedIt = std::find(m_hoverSequenceLoadedItems.begin(),
                m_hoverSequenceLoadedItems.end(), item);
```

#### AUTO 


```{c}
auto *action = actionCollection()->action(KStandardAction::name(actionId))
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemData *parent : parentsToEnsureVisible) {
        // We make sure they are all unfiltered.
        if (m_filteredItems.remove(parent->item)) {
            // If it is being unfiltered now, we mark it to be inserted by appending it to newVisibleItems
            newVisibleItems.append(parent);
            // It could be in newFilteredIndexes, we must remove it if it's there:
            const int parentIndex = index(parent->item);
            if (parentIndex >= 0) {
                QVector<int>::iterator it = std::lower_bound(newFilteredIndexes.begin(), newFilteredIndexes.end(), parentIndex);
                if (it != newFilteredIndexes.end() && *it == parentIndex) {
                    newFilteredIndexes.erase(it);
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto &basename
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : qAsConst(m_plugins)) {
            actions << plugin.first->outOfVersionControlActions(items);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[job]() {
            QUrl statUrl;
            if (!job->error()) {
                statUrl = job->mostLocalUrl();
            }

            auto job = new KTerminalLauncherJob(QString());
            job->setWorkingDirectory(statUrl.isLocalFile() ? statUrl.toLocalFile() : QDir::homePath());
            job->start();
        }
```

#### AUTO 


```{c}
const auto highlightColor = option.palette.color(expansionAreaHovered() ? QPalette::Highlight : normalTextColorRole());
```

#### AUTO 


```{c}
const auto path = findRecursive(dir, basename);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KFileItem& item : list) {
            if (item.isDir()) {
                ++folderCount;
            } else {
                ++fileCount;
                totalFileSize += item.size();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : qAsConst(visibleChangedIndexes)) {
            m_pendingPreviewItems.append(m_model->fileItem(index));
        }
```

#### AUTO 


```{c}
const auto basenames1 = QStringList{"deinstall.sh", "deinstall"};
```

#### AUTO 


```{c}
const auto extensionWidth = m_customizedFontMetrics.horizontalAdvance(text.right(extensionLength));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : plugins) {
            if (enabledPlugins.contains(p.name())) {
                KPluginLoader loader(p.fileName());
                KPluginFactory *factory = loader.factory();
                KVersionControlPlugin *plugin = factory->create<KVersionControlPlugin>();
                if (plugin) {
                    m_plugins.append(plugin);
                    loadedPlugins += p.name();
                }
            }
        }
```

#### AUTO 


```{c}
auto* trashSettingsPage = createTrashSettingsPage(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : m_tobeRemoved) {
        int before = m_model->count();
        m_model->deleteItem(i);
        QTRY_COMPARE(m_model->count(), before - 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& role : roles) {
        newVisibleRoles.append(prefix + role);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &basename : basenames2) {
            const auto path = findRecursive(dir, basename);
            if (!path.isEmpty()) {
                installerPath = path;
                break;
            }
        }
```

#### AUTO 


```{c}
auto viewGeometries = m_viewGeometriesHelper.viewGeometries();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& process : blockingProcesses) {
                        blockingApps << process.name();
                    }
```

#### AUTO 


```{c}
auto reply = m_kiofuseInterface.mountUrl(url.toString());
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service, window);
```

