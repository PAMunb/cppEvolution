#### RANGE FOR STATEMENT 


```{c}
for (KGrSprite * sprite : std::as_const(m_sprites)) {
        if (sprite != nullptr) {
            sprite->animate (missed);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrSprite * sprite : qAsConst(m_sprites)) {
            if (sprite) {
                sprite->changeCoordinateSystem
                        (m_topLeftX, m_topLeftY, tileSize);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, code] { game->kbControl(code); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QKeySequence &s : keyBindings) {
        pauseKeys.append(s.toString(QKeySequence::NativeText));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * d : std::as_const(gameList)) {
        if (d->owner == o) {
            OK = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto keyBindings = myPause->shortcut().keyBindings(QKeySequence::StandardKey::Cancel);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(PAUSE); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, code] { game->gameActions(code); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int dirn) { game->kbControl(dirn); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : std::as_const(enemies)) {
        connect (enemy, &KGrEnemy::incScore, game, &KGrGame::incScore);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : qAsConst(enemies)) {
        connect (enemy, &KGrEnemy::startAnimation, view->gameScene(), &KGrScene::startAnimation);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : qAsConst(enemies)) {
        pointsPerCell = enemy->whereAreYou (enemyX, enemyY);
        if (((enemyY == (y + pointsPerCell)) ||
             (enemyY == (y + pointsPerCell - 1))) &&
            (enemyX > (x - pointsPerCell)) &&
            (enemyX < (x + pointsPerCell))) {
            return enemy;
        }
    }
```

#### AUTO 


```{c}
auto *dlg = new KShortcutsDialog(KShortcutsEditor::AllActions, KShortcutsEditor::LetterShortcutsAllowed, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (char sortItem1 : qAsConst(sortOrder1)) {
        for (char sortItem2 : qAsConst(sortOrder2)) {
            for (i = 0; i < imax; i++) {
                if ((myGameList.at (i)->skill == sortItem1) &&
                    (myGameList.at (i)->rules == sortItem2)) {
                    QStringList data;
                    data
                        << myGameList.at (i)->name
                        << ((myGameList.at (i)->rules == 'K') ? 
                            i18nc ("Rules", "KGoldrunner") :
                            i18nc ("Rules", "Traditional"))
                        << QString().setNum (myGameList.at (i)->nLevels)
                        << ((myGameList.at (i)->skill == 'T') ? 
                            i18nc ("Skill Level", "Tutorial") :
                            ((myGameList.at (i)->skill == 'N') ? 
                            i18nc ("Skill Level", "Normal") :
                            i18nc ("Skill Level", "Championship")));
                    KGrGameListItem * thisGame = new KGrGameListItem (data, i);
                    games->addTopLevelItem (thisGame);

                    if (slGameIndex < 0) {
                        slGameIndex = i; // There is at least one game.
                    }
                    if (i == cIndex) {
                        // Mark the currently selected game (default 0).
                        games->setCurrentItem (thisGame);
                    }
                }
            } // End "for" loop.
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * gData : qAsConst(gameList)) {
        if (gData->owner == o) {
            line = QStringLiteral ("%1 %2 %3 %4\n")
                            .arg (gData->nLevels, 3, 10, QLatin1Char('0')) // int 00n
                            .arg (gData->rules)                      // char
                            .arg (gData->prefix)                     // QString
                            .arg (gData->name);                      // QString
            lineC = line.toUtf8();
            len = lineC.length();
            for (i = 0; i < len; ++i) {
                c.putChar (lineC.at (i));
            }

            len = gData->about.length();
            if (len > 0) {
                QByteArray aboutC = gData->about;
                len = aboutC.length();		// Might be longer now.
                for (i = 0; i < len; ++i) {
                    ch = aboutC[i];
                    if (ch != '\n') {
                        c.putChar (ch);		// Copy the character.
                    }
                    else {
                        c.putChar ('\\');	// Change newline to \ and n.
                        c.putChar ('n');
                    }
                }
                c.putChar ('\n');		// Add a real newline.
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : std::as_const(enemies)) {
        enemy->showState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : std::as_const(enemies)) {
        enemy->run (scaledTime);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(LOAD); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        gameFreeze(frozen);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, code] { game->settings(code); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(SAVE_GAME); }
```

#### RANGE FOR STATEMENT 


```{c}
for (char sortItem2 : qAsConst(sortOrder2)) {
            for (i = 0; i < imax; i++) {
                if ((myGameList.at (i)->skill == sortItem1) &&
                    (myGameList.at (i)->rules == sortItem2)) {
                    QStringList data;
                    data
                        << myGameList.at (i)->name
                        << ((myGameList.at (i)->rules == 'K') ? 
                            i18nc ("Rules", "KGoldrunner") :
                            i18nc ("Rules", "Traditional"))
                        << QString().setNum (myGameList.at (i)->nLevels)
                        << ((myGameList.at (i)->skill == 'T') ? 
                            i18nc ("Skill Level", "Tutorial") :
                            ((myGameList.at (i)->skill == 'N') ? 
                            i18nc ("Skill Level", "Normal") :
                            i18nc ("Skill Level", "Championship")));
                    KGrGameListItem * thisGame = new KGrGameListItem (data, i);
                    games->addTopLevelItem (thisGame);

                    if (slGameIndex < 0) {
                        slGameIndex = i; // There is at least one game.
                    }
                    if (i == cIndex) {
                        // Mark the currently selected game (default 0).
                        games->setCurrentItem (thisGame);
                    }
                }
            } // End "for" loop.
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : std::as_const(enemies)) {
        pointsPerCell = enemy->whereAreYou (enemyX, enemyY);
        if (((enemyY == (y + pointsPerCell)) ||
             (enemyY == (y + pointsPerCell - 1))) &&
            (enemyX > (x - pointsPerCell)) &&
            (enemyX < (x + pointsPerCell))) {
            return enemy;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(HIGH_SCORE); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * gameData : qAsConst(gameList)) {
        dbk1 << "Trying:" << n << gameData->prefix;
        if (gameData->prefix == prevGamePrefix) {
            gameIndex = n;
            level     = prevLevel;
            dbk1 << "FOUND:" << gameIndex << prevGamePrefix << level;
            break;
        }
        n++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (char sortItem2 : qAsConst(sortOrder2)) {
            for (i = 0; i < imax; ++i) {
                if ((myGameList.at (i)->skill == sortItem1) &&
                    (myGameList.at (i)->rules == sortItem2)) {
                    QStringList data;
                    data
                        << myGameList.at (i)->name
                        << ((myGameList.at (i)->rules == 'K') ? 
                            i18nc ("Rules", "KGoldrunner") :
                            i18nc ("Rules", "Traditional"))
                        << QString().setNum (myGameList.at (i)->nLevels)
                        << ((myGameList.at (i)->skill == 'T') ? 
                            i18nc ("Skill Level", "Tutorial") :
                            ((myGameList.at (i)->skill == 'N') ? 
                            i18nc ("Skill Level", "Normal") :
                            i18nc ("Skill Level", "Championship")));
                    KGrGameListItem * thisGame = new KGrGameListItem (data, i);
                    games->addTopLevelItem (thisGame);

                    if (slGameIndex < 0) {
                        slGameIndex = i; // There is at least one game.
                    }
                    if (i == cIndex) {
                        // Mark the currently selected game (default 0).
                        games->setCurrentItem (thisGame);
                    }
                }
            } // End "for" loop.
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * gData : std::as_const(gameList)) {
        if (gData->owner == o) {
            line = QStringLiteral ("%1 %2 %3 %4\n")
                            .arg (gData->nLevels, 3, 10, QLatin1Char('0')) // int 00n
                            .arg (gData->rules)                      // char
                            .arg (gData->prefix)                     // QString
                            .arg (gData->name);                      // QString
            lineC = line.toUtf8();
            len = lineC.length();
            for (i = 0; i < len; ++i) {
                c.putChar (lineC.at (i));
            }

            len = gData->about.length();
            if (len > 0) {
                QByteArray aboutC = gData->about;
                len = aboutC.length();		// Might be longer now.
                for (i = 0; i < len; ++i) {
                    ch = aboutC[i];
                    if (ch != '\n') {
                        c.putChar (ch);		// Copy the character.
                    }
                    else {
                        c.putChar ('\\');	// Change newline to \ and n.
                        c.putChar ('n');
                    }
                }
                c.putChar ('\n');		// Add a real newline.
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (char sortItem1 : std::as_const(sortOrder1)) {
        for (char sortItem2 : std::as_const(sortOrder2)) {
            for (i = 0; i < imax; ++i) {
                if ((myGameList.at (i)->skill == sortItem1) &&
                    (myGameList.at (i)->rules == sortItem2)) {
                    QStringList data;
                    data
                        << myGameList.at (i)->name
                        << ((myGameList.at (i)->rules == 'K') ? 
                            i18nc ("Rules", "KGoldrunner") :
                            i18nc ("Rules", "Traditional"))
                        << QString().setNum (myGameList.at (i)->nLevels)
                        << ((myGameList.at (i)->skill == 'T') ? 
                            i18nc ("Skill Level", "Tutorial") :
                            ((myGameList.at (i)->skill == 'N') ? 
                            i18nc ("Skill Level", "Normal") :
                            i18nc ("Skill Level", "Championship")));
                    KGrGameListItem * thisGame = new KGrGameListItem (data, i);
                    games->addTopLevelItem (thisGame);

                    if (slGameIndex < 0) {
                        slGameIndex = i; // There is at least one game.
                    }
                    if (i == cIndex) {
                        // Mark the currently selected game (default 0).
                        games->setCurrentItem (thisGame);
                    }
                }
            } // End "for" loop.
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : qAsConst(enemies)) {
        connect (enemy, &KGrEnemy::incScore, game, &KGrGame::incScore);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, code] { game->editToolbarActions(code); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrSprite * sprite : std::as_const(m_sprites)) {
            if (sprite) {
                sprite->changeCoordinateSystem
                        (m_topLeftX, m_topLeftY, tileSize);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme * actorsTheme : themes) {
	if (actorsTheme->customData("Set") ==
            currentSetTheme->customData("Set")) {
	    m_actorsProvider->setCurrentTheme (actorsTheme);
	    break;
	}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : qAsConst(files)) {
        if (filename == QLatin1String("game_ende.txt")) {
            continue;			// Skip the "ENDE" file.
        }

        filePath = dir + filename;
        KGrGameData * g = initGameData (o);
        gameList.append (g);
        // //qCDebug(KGOLDRUNNER_LOG)<< "GAME PATH:" << filePath;

        openFile.setFileName (filePath);

        // Check that the game-file exists.
        if (! openFile.exists()) {
            return (NotFound);
        }

        // Open the file for read-only.
        if (! openFile.open (QIODevice::ReadOnly)) {
            return (NoRead);
        }

        char c;
        QByteArray textLine;
        QByteArray gameName;

        // Find the first line of game-data.
        c = getALine (kgr3Format, textLine);
        if (kgr3Format) {
            while ((c != 'G') && (c != '\0')) {
                c = getALine (kgr3Format, textLine);
            }
        }
        if (c == '\0') {
            openFile.close();
            return (UnexpectedEOF);	// We reached end-of-file unexpectedly.
        }

        // Loop to extract the game-data for each game on the file.
        while (c != '\0') {
            if (kgr3Format && (c == 'L')) {
                break;			// End of KGr 3 game-file header.
            }
            // Decode line 1 of the game-data.
            QList<QByteArray> fields = textLine.split (' ');
            g->nLevels = fields.at (0).toInt();
            g->rules   = fields.at (1).at (0);
            g->prefix  = QString::fromLatin1(fields.at (2));
            // //qCDebug(KGOLDRUNNER_LOG) << "Levels:" << g->nLevels << "Rules:" << g->rules <<
                // "Prefix:" << g->prefix;

            if (kgr3Format) {
                // KGr 3 Format: get skill, get game-name from a later line.
                g->skill = fields.at (3).at (0);
            }
            else {
                // KGr 2 Format: get game-name from end of line 1.
                int n = 0;
                // Skip the first 3 fields and extract the rest of the line.
                n = textLine.indexOf (' ', n) + 1;
                n = textLine.indexOf (' ', n) + 1;
                n = textLine.indexOf (' ', n) + 1;
                gameName = removeNewline (textLine.right (textLine.size() - n));
                g->name  = i18n (gameName.constData());
            }

            // Check for further settings in this game.
            // bool usedDwfOpt = false;		// For debug.
            while ((c = getALine (kgr3Format, textLine)) == '.') {
                if (textLine.startsWith ("dwf ")) {
                    // Dig while falling is allowed in this game, or not.
                    g->digWhileFalling = textLine.endsWith (" false\n") ?
                                         false : true;
                    // usedDwfOpt = true;		// For debug.
                }
            }

            if (kgr3Format && (c == ' ')) {
                gameName = removeNewline (textLine);
                g->name  = i18n (gameName.constData());
                c = getALine (kgr3Format, textLine);
            }
            //qCDebug(KGOLDRUNNER_LOG) << "Dig while falling" << g->digWhileFalling
                     // << "usedDwfOpt" << usedDwfOpt << "Game" << g->name;
            //qCDebug(KGOLDRUNNER_LOG) << "Skill:" << g->skill << "Name:" << g->name;

            // Loop to accumulate lines of about-data.  If kgr3Format, exit on
            // EOF or 'L' line.  If not kgr3Format, exit on EOF or numeric line.
            while (c != '\0') {
                if ((c == '\0') ||
                    (kgr3Format && (c == 'L')) ||
                    ((! kgr3Format) &&
                    (textLine.at (0) >= '0') && (textLine.at (0) <= '9'))) {
                    break;
                }
                g->about.append (textLine);
                c = getALine (kgr3Format, textLine);
            }
            g->about = removeNewline (g->about);	// Remove final '\n'.
            // //qCDebug(KGOLDRUNNER_LOG) << "Info about: [" + g->about + "]";

            if ((! kgr3Format) && (c != '\0')) {
                filePath = dir + filename;
                g = initGameData (o);
                gameList.append (g);
            }
        } // END: game-data loop

        openFile.close();

    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, code] { game->editActions(code); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : qAsConst(m_tiles)) {
            if (tile) {
                setTile (tile, tileSize, index/m_tilesHigh, index%m_tilesHigh);
            }
            index++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(DEMO); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : std::as_const(files)) {
        if (filename == QLatin1String("game_ende.txt")) {
            continue;			// Skip the "ENDE" file.
        }

        filePath = dir + filename;
        KGrGameData * g = initGameData (o);
        gameList.append (g);
        // //qCDebug(KGOLDRUNNER_LOG)<< "GAME PATH:" << filePath;

        openFile.setFileName (filePath);

        // Check that the game-file exists.
        if (! openFile.exists()) {
            return (NotFound);
        }

        // Open the file for read-only.
        if (! openFile.open (QIODevice::ReadOnly)) {
            return (NoRead);
        }

        char c;
        QByteArray textLine;
        QByteArray gameName;

        // Find the first line of game-data.
        c = getALine (kgr3Format, textLine);
        if (kgr3Format) {
            while ((c != 'G') && (c != '\0')) {
                c = getALine (kgr3Format, textLine);
            }
        }
        if (c == '\0') {
            openFile.close();
            return (UnexpectedEOF);	// We reached end-of-file unexpectedly.
        }

        // Loop to extract the game-data for each game on the file.
        while (c != '\0') {
            if (kgr3Format && (c == 'L')) {
                break;			// End of KGr 3 game-file header.
            }
            // Decode line 1 of the game-data.
            QList<QByteArray> fields = textLine.split (' ');
            g->nLevels = fields.at (0).toInt();
            g->rules   = fields.at (1).at (0);
            g->prefix  = QString::fromLatin1(fields.at (2));
            // //qCDebug(KGOLDRUNNER_LOG) << "Levels:" << g->nLevels << "Rules:" << g->rules <<
                // "Prefix:" << g->prefix;

            if (kgr3Format) {
                // KGr 3 Format: get skill, get game-name from a later line.
                g->skill = fields.at (3).at (0);
            }
            else {
                // KGr 2 Format: get game-name from end of line 1.
                int n = 0;
                // Skip the first 3 fields and extract the rest of the line.
                n = textLine.indexOf (' ', n) + 1;
                n = textLine.indexOf (' ', n) + 1;
                n = textLine.indexOf (' ', n) + 1;
                gameName = removeNewline (textLine.right (textLine.size() - n));
                g->name  = i18n (gameName.constData());
            }

            // Check for further settings in this game.
            // bool usedDwfOpt = false;		// For debug.
            while ((c = getALine (kgr3Format, textLine)) == '.') {
                if (textLine.startsWith ("dwf ")) {
                    // Dig while falling is allowed in this game, or not.
                    g->digWhileFalling = textLine.endsWith (" false\n") ?
                                         false : true;
                    // usedDwfOpt = true;		// For debug.
                }
            }

            if (kgr3Format && (c == ' ')) {
                gameName = removeNewline (textLine);
                g->name  = i18n (gameName.constData());
                c = getALine (kgr3Format, textLine);
            }
            //qCDebug(KGOLDRUNNER_LOG) << "Dig while falling" << g->digWhileFalling
                     // << "usedDwfOpt" << usedDwfOpt << "Game" << g->name;
            //qCDebug(KGOLDRUNNER_LOG) << "Skill:" << g->skill << "Name:" << g->name;

            // Loop to accumulate lines of about-data.  If kgr3Format, exit on
            // EOF or 'L' line.  If not kgr3Format, exit on EOF or numeric line.
            while (c != '\0') {
                if ((c == '\0') ||
                    (kgr3Format && (c == 'L')) ||
                    ((! kgr3Format) &&
                    (textLine.at (0) >= '0') && (textLine.at (0) <= '9'))) {
                    break;
                }
                g->about.append (textLine);
                c = getALine (kgr3Format, textLine);
            }
            g->about = removeNewline (g->about);	// Remove final '\n'.
            // //qCDebug(KGOLDRUNNER_LOG) << "Info about: [" + g->about + "]";

            if ((! kgr3Format) && (c != '\0')) {
                filePath = dir + filename;
                g = initGameData (o);
                gameList.append (g);
            }
        } // END: game-data loop

        openFile.close();

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (char sortItem1 : qAsConst(sortOrder1)) {
        for (char sortItem2 : qAsConst(sortOrder2)) {
            for (i = 0; i < imax; ++i) {
                if ((myGameList.at (i)->skill == sortItem1) &&
                    (myGameList.at (i)->rules == sortItem2)) {
                    QStringList data;
                    data
                        << myGameList.at (i)->name
                        << ((myGameList.at (i)->rules == 'K') ? 
                            i18nc ("Rules", "KGoldrunner") :
                            i18nc ("Rules", "Traditional"))
                        << QString().setNum (myGameList.at (i)->nLevels)
                        << ((myGameList.at (i)->skill == 'T') ? 
                            i18nc ("Skill Level", "Tutorial") :
                            ((myGameList.at (i)->skill == 'N') ? 
                            i18nc ("Skill Level", "Normal") :
                            i18nc ("Skill Level", "Championship")));
                    KGrGameListItem * thisGame = new KGrGameListItem (data, i);
                    games->addTopLevelItem (thisGame);

                    if (slGameIndex < 0) {
                        slGameIndex = i; // There is at least one game.
                    }
                    if (i == cIndex) {
                        // Mark the currently selected game (default 0).
                        games->setCurrentItem (thisGame);
                    }
                }
            } // End "for" loop.
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int &offset : std::as_const(hiddenLadders)) {
        int i = offset % width;
        int j = offset / width;
        changeCellAt (i, j, LADDER);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : std::as_const(enemies)) {
        pointsPerCell_1 = enemy->whereAreYou (enemyX, enemyY) - 1;
        if (((heroX < enemyX) ? ((heroX + pointsPerCell_1) >= enemyX) :
                                 (heroX <= (enemyX + pointsPerCell_1))) &&
            ((heroY < enemyY) ? ((heroY + pointsPerCell_1) > enemyY) :
                                 (heroY <= (enemyY + pointsPerCell_1)))) {
            // dbk << "Caught by";
            // enemy->showState();
            return true;
        }
    }
```

#### AUTO 


```{c}
const auto themes = m_actorsProvider->themes();
```

#### AUTO 


```{c}
const auto tse = std::chrono::system_clock::now().time_since_epoch();
```

#### RANGE FOR STATEMENT 


```{c}
for (const int &offset : ladders) {
        int i = offset % width;
        int j = offset / width;
        paintCell (i, j, LADDER);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KgTheme * actorsTheme : themes) {
    if (actorsTheme->customData(QStringLiteral("Set")) ==
            currentSetTheme->customData(QStringLiteral("Set"))) {
	    m_actorsProvider->setCurrentTheme (actorsTheme);
	    break;
	}
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : std::as_const(enemies)) {
        connect (enemy, &KGrEnemy::startAnimation, view->gameScene(), &KGrScene::startAnimation);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(SOLVE); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, code] { game->dbgControl(code); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : qAsConst(enemies)) {
        enemy->showState();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * gData : qAsConst(gameList)) {
        if (gData->owner == o) {
            line = QStringLiteral ("%1 %2 %3 %4\n")
                            .arg (gData->nLevels, 3, 10, QLatin1Char('0')) // int 00n
                            .arg (gData->rules)                      // char
                            .arg (gData->prefix)                     // QString
                            .arg (gData->name);                      // QString
            lineC = line.toUtf8();
            len = lineC.length();
            for (i = 0; i < len; i++) {
                c.putChar (lineC.at (i));
            }

            len = gData->about.length();
            if (len > 0) {
                QByteArray aboutC = gData->about;
                len = aboutC.length();		// Might be longer now.
                for (i = 0; i < len; i++) {
                    ch = aboutC[i];
                    if (ch != '\n') {
                        c.putChar (ch);		// Copy the character.
                    }
                    else {
                        c.putChar ('\\');	// Change newline to \ and n.
                        c.putChar ('n');
                    }
                }
                c.putChar ('\n');		// Add a real newline.
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(NEW); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * gameData : std::as_const(gameList)) {
        dbk1 << "Trying:" << n << gameData->prefix;
        if (gameData->prefix == prevGamePrefix) {
            gameIndex = n;
            level     = prevLevel;
            dbk1 << "FOUND:" << gameIndex << prevGamePrefix << level;
            break;
        }
        n++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGameRenderedItem * tile : std::as_const(m_tiles)) {
            if (tile) {
                setTile (tile, tileSize, index/m_tilesHigh, index%m_tilesHigh);
            }
            index++;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { game->gameActions(HINT); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrSprite * sprite : qAsConst(m_sprites)) {
        if (sprite != 0) {
            sprite->animate (missed);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : qAsConst(files)) {
        if (filename == "game_ende.txt") {
            continue;			// Skip the "ENDE" file.
        }

        filePath = dir + filename;
        KGrGameData * g = initGameData (o);
        gameList.append (g);
        // //qCDebug(KGOLDRUNNER_LOG)<< "GAME PATH:" << filePath;

        openFile.setFileName (filePath);

        // Check that the game-file exists.
        if (! openFile.exists()) {
            return (NotFound);
        }

        // Open the file for read-only.
        if (! openFile.open (QIODevice::ReadOnly)) {
            return (NoRead);
        }

        char c;
        QByteArray textLine;
        QByteArray gameName;

        // Find the first line of game-data.
        c = getALine (kgr3Format, textLine);
        if (kgr3Format) {
            while ((c != 'G') && (c != '\0')) {
                c = getALine (kgr3Format, textLine);
            }
        }
        if (c == '\0') {
            openFile.close();
            return (UnexpectedEOF);	// We reached end-of-file unexpectedly.
        }

        // Loop to extract the game-data for each game on the file.
        while (c != '\0') {
            if (kgr3Format && (c == 'L')) {
                break;			// End of KGr 3 game-file header.
            }
            // Decode line 1 of the game-data.
            QList<QByteArray> fields = textLine.split (' ');
            g->nLevels = fields.at (0).toInt();
            g->rules   = fields.at (1).at (0);
            g->prefix  = fields.at (2);
            // //qCDebug(KGOLDRUNNER_LOG) << "Levels:" << g->nLevels << "Rules:" << g->rules <<
                // "Prefix:" << g->prefix;

            if (kgr3Format) {
                // KGr 3 Format: get skill, get game-name from a later line.
                g->skill = fields.at (3).at (0);
            }
            else {
                // KGr 2 Format: get game-name from end of line 1.
                int n = 0;
                // Skip the first 3 fields and extract the rest of the line.
                n = textLine.indexOf (' ', n) + 1;
                n = textLine.indexOf (' ', n) + 1;
                n = textLine.indexOf (' ', n) + 1;
                gameName = removeNewline (textLine.right (textLine.size() - n));
                g->name  = i18n (gameName.constData());
            }

            // Check for further settings in this game.
            // bool usedDwfOpt = false;		// For debug.
            while ((c = getALine (kgr3Format, textLine)) == '.') {
                if (textLine.startsWith ("dwf ")) {
                    // Dig while falling is allowed in this game, or not.
                    g->digWhileFalling = textLine.endsWith (" false\n") ?
                                         false : true;
                    // usedDwfOpt = true;		// For debug.
                }
            }

            if (kgr3Format && (c == ' ')) {
                gameName = removeNewline (textLine);
                g->name  = i18n (gameName.constData());
                c = getALine (kgr3Format, textLine);
            }
            //qCDebug(KGOLDRUNNER_LOG) << "Dig while falling" << g->digWhileFalling
                     // << "usedDwfOpt" << usedDwfOpt << "Game" << g->name;
            //qCDebug(KGOLDRUNNER_LOG) << "Skill:" << g->skill << "Name:" << g->name;

            // Loop to accumulate lines of about-data.  If kgr3Format, exit on
            // EOF or 'L' line.  If not kgr3Format, exit on EOF or numeric line.
            while (c != '\0') {
                if ((c == '\0') ||
                    (kgr3Format && (c == 'L')) ||
                    ((! kgr3Format) &&
                    (textLine.at (0) >= '0') && (textLine.at (0) <= '9'))) {
                    break;
                }
                g->about.append (textLine);
                c = getALine (kgr3Format, textLine);
            }
            g->about = removeNewline (g->about);	// Remove final '\n'.
            // //qCDebug(KGOLDRUNNER_LOG) << "Info about: [" + g->about + "]";

            if ((! kgr3Format) && (c != '\0')) {
                filePath = dir + filename;
                g = initGameData (o);
                gameList.append (g);
            }
        } // END: game-data loop

        openFile.close();

    }
```

#### AUTO 


```{c}
const auto keyBindings = myPause->shortcuts();
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : qAsConst(enemies)) {
        enemy->run (scaledTime);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (char sortItem2 : std::as_const(sortOrder2)) {
            for (i = 0; i < imax; ++i) {
                if ((myGameList.at (i)->skill == sortItem1) &&
                    (myGameList.at (i)->rules == sortItem2)) {
                    QStringList data;
                    data
                        << myGameList.at (i)->name
                        << ((myGameList.at (i)->rules == 'K') ? 
                            i18nc ("Rules", "KGoldrunner") :
                            i18nc ("Rules", "Traditional"))
                        << QString().setNum (myGameList.at (i)->nLevels)
                        << ((myGameList.at (i)->skill == 'T') ? 
                            i18nc ("Skill Level", "Tutorial") :
                            ((myGameList.at (i)->skill == 'N') ? 
                            i18nc ("Skill Level", "Normal") :
                            i18nc ("Skill Level", "Championship")));
                    KGrGameListItem * thisGame = new KGrGameListItem (data, i);
                    games->addTopLevelItem (thisGame);

                    if (slGameIndex < 0) {
                        slGameIndex = i; // There is at least one game.
                    }
                    if (i == cIndex) {
                        // Mark the currently selected game (default 0).
                        games->setCurrentItem (thisGame);
                    }
                }
            } // End "for" loop.
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * gData : qAsConst(gameList)) {
        if (gData->owner == o) {
            line = QString ("%1 %2 %3 %4\n")
                            .arg (gData->nLevels, 3, 10, QChar('0')) // int 00n
                            .arg (gData->rules)                      // char
                            .arg (gData->prefix)                     // QString
                            .arg (gData->name);                      // QString
            lineC = line.toUtf8();
            len = lineC.length();
            for (i = 0; i < len; i++) {
                c.putChar (lineC.at (i));
            }

            len = gData->about.length();
            if (len > 0) {
                QByteArray aboutC = gData->about;
                len = aboutC.length();		// Might be longer now.
                for (i = 0; i < len; i++) {
                    ch = aboutC[i];
                    if (ch != '\n') {
                        c.putChar (ch);		// Copy the character.
                    }
                    else {
                        c.putChar ('\\');	// Change newline to \ and n.
                        c.putChar ('n');
                    }
                }
                c.putChar ('\n');		// Add a real newline.
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int &offset : qAsConst(hiddenLadders)) {
        int i = offset % width;
        int j = offset / width;
        changeCellAt (i, j, LADDER);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrGameData * d : qAsConst(gameList)) {
        if (d->owner == o) {
            OK = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrEnemy * enemy : qAsConst(enemies)) {
        pointsPerCell_1 = enemy->whereAreYou (enemyX, enemyY) - 1;
        if (((heroX < enemyX) ? ((heroX + pointsPerCell_1) >= enemyX) :
                                 (heroX <= (enemyX + pointsPerCell_1))) &&
            ((heroY < enemyY) ? ((heroY + pointsPerCell_1) > enemyY) :
                                 (heroY <= (enemyY + pointsPerCell_1)))) {
            // dbk << "Caught by";
            // enemy->showState();
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KGrSprite * sprite : qAsConst(m_sprites)) {
        if (sprite != nullptr) {
            sprite->animate (missed);
        }
    }
```

