#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : KTp::accountManager()->validAccounts()->accounts()) {
        const QString name = account->normalizedName().isEmpty() ? account->displayName() : account->normalizedName();
        m_accounts[account->uniqueIdentifier()] = name;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &text) { if (text.isEmpty()) { slotClearGlobalSearch(); } }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : group.keyList()) {
        if (!m_accounts.contains(key)) {
            continue;
        }
        QListWidgetItem *item = new QListWidgetItem();
        item->setData(AccountIdRole, key);
        item->setData(AccountNameRole, m_accounts.value(key));
        item->setData(EmoticonsThemeRole, group.readEntry<QString>(key, QString()));
        ui.listWidget->addItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&] (bool found) { Q_EMIT searchTextComplete(found); }
```

