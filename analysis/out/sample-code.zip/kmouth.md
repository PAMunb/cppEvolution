#### RANGE FOR STATEMENT 


```{c}
for (const QString &locale: locales) {
            const QStringList fileNames =
                QDir(dir + QLatin1Char('/') + locale).entryList(QStringList() << QStringLiteral("*.phrasebook"));
            for (const QString &file : fileNames) {
                bookPaths.append(dir + QLatin1Char('/') + locale + QLatin1Char('/') + file);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QStringList locales = QDir(dir).entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        for (const QString &locale: locales) {
            const QStringList fileNames =
                QDir(dir + QLatin1Char('/') + locale).entryList(QStringList() << QStringLiteral("*.phrasebook"));
            for (const QString &file : fileNames) {
                bookPaths.append(dir + QLatin1Char('/') + locale + QLatin1Char('/') + file);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex index : selected) {
        xml += serializeBook(index);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVoice &voice: voices) {
        if (voice.name() == ttsVoice) {
            m_speech->setVoice(voice);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : fileNames) {
                bookPaths.append(dir + QLatin1Char('/') + locale + QLatin1Char('/') + file);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &engine : engines) {
        engineComboBox->addItem(engine);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVoice &voice : voices) {
        voiceComboBox->addItem(voice.name());
    }
```

