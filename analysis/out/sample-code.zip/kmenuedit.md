#### LAMBDA EXPRESSION 


```{c}
[this]() {sort(SortAllByName);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        sort(SortByDescription);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        sort(SortByName);
    }
```

#### AUTO 


```{c}
auto *menuEdit = new KMenuEdit();
```

#### AUTO 


```{c}
auto useArgs = [menuEdit](const QCommandLineParser &parser) {
        const QStringList args = parser.positionalArguments();
        if (!args.isEmpty()) {
            menuEdit->selectMenu(args.at(0));
            if (args.count() > 1) {
                menuEdit->selectMenuEntry(args.at(1));
            }
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        sort(SortAllByDescription);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &e : folder->entries(true, !m_showHidden, true, m_detailedMenuEntries && !m_detailedEntriesNamesFirst))
    {
        if (e->isType(KST_KServiceGroup))
        {
            const KServiceGroup::Ptr serviceGroup(static_cast<KServiceGroup*>(e.data()));
            MenuFolderInfo *subFolderInfo = new MenuFolderInfo();
            readMenuFolderInfo(subFolderInfo, serviceGroup, folderInfo->fullId);
            folderInfo->add(subFolderInfo, true);
        }
        else if (e->isType(KST_KService))
        {
            const KService::Ptr service(static_cast<KService*>(e.data()));
            folderInfo->add(new MenuEntryInfo(service), true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &e : folder->entries(true, !m_showHidden, true, m_detailedMenuEntries && !m_detailedEntriesNamesFirst)) {
        if (e->isType(KST_KServiceGroup)) {
            const KServiceGroup::Ptr serviceGroup(static_cast<KServiceGroup *>(e.data()));
            MenuFolderInfo *subFolderInfo = new MenuFolderInfo();
            readMenuFolderInfo(subFolderInfo, serviceGroup, folderInfo->fullId);
            folderInfo->add(subFolderInfo, true);
        } else if (e->isType(KST_KService)) {
            const KService::Ptr service(static_cast<KService *>(e.data()));
            folderInfo->add(new MenuEntryInfo(service), true);
        } else if (e->isType(KST_KServiceSeparator)) {
            folderInfo->add(m_separator, true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &e : folder->entries(true, !m_showHidden, true, m_detailedMenuEntries && !m_detailedEntriesNamesFirst))
    {
        if (e->isType(KST_KServiceGroup))
        {
            const KServiceGroup::Ptr serviceGroup(static_cast<KServiceGroup*>(e.data()));
            MenuFolderInfo *subFolderInfo = new MenuFolderInfo();
            readMenuFolderInfo(subFolderInfo, serviceGroup, folderInfo->fullId);
            folderInfo->add(subFolderInfo, true);
        }
        else if (e->isType(KST_KService))
        {
            const KService::Ptr service(static_cast<KService*>(e.data()));
            folderInfo->add(new MenuEntryInfo(service), true);
        }
        else if (e->isType(KST_KServiceSeparator))
        {
            folderInfo->add(m_separator, true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QString base = dir + QStringLiteral("/desktop-directories");
        if (canonical.startsWith(base)) {
            return canonical.mid(base.length() + 1);
        }
    }
```

#### AUTO 


```{c}
const auto args = parser.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QString base = dir + QLatin1String("/desktop-directories");
        if (canonical.startsWith(base))
            return canonical.mid(base.length()+1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dir : dirs) {
        const QString base = dir + QStringLiteral("/desktop-directories");
        if (canonical.startsWith(base))
            return canonical.mid(base.length()+1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[useArgs, &parser, menuEdit](const QStringList &args, const QString & /*workDir*/) {
        parser.parse(args);
        useArgs(parser);

        KWindowSystem::updateStartupId(menuEdit->windowHandle());
        KWindowSystem::activateWindow(menuEdit->windowHandle());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[menuEdit](const QCommandLineParser &parser) {
        const QStringList args = parser.positionalArguments();
        if (!args.isEmpty()) {
            menuEdit->selectMenu(args.at(0));
            if (args.count() > 1) {
                menuEdit->selectMenuEntry(args.at(1));
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KSycocaEntry::Ptr &e : folder->entries(true, !m_showHidden, true, m_detailedMenuEntries && !m_detailedEntriesNamesFirst))
    {
        if (e->isType(KST_KServiceGroup))
        {
            MenuFolderInfo *subFolderInfo = new MenuFolderInfo();
            readMenuFolderInfo(subFolderInfo, KServiceGroup::Ptr(e), folderInfo->fullId);
            folderInfo->add(subFolderInfo, true);
        }
        else if (e->isType(KST_KService))
        {
            folderInfo->add(new MenuEntryInfo(KService::Ptr(e)), true);
        }
        else if (e->isType(KST_KServiceSeparator))
        {
            folderInfo->add(m_separator, true);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        sort(SortAllByName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {sort(SortByDescription);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {sort(SortAllByDescription);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {sort(SortByName);}
```

