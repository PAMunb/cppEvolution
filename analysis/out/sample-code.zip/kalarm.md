#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
                if (event.category() & types)
                    eventHash[event.id()] = event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        if (agent.type().mimeTypes().indexOf(MatchMimeType) >= 0)
        {
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
            job->fetchScope().setResource(agent.identifier());
            connect(job, &CollectionFetchJob::result, mDuplicateResourceObject, &DuplicateResourceObject::collectionFetchResult);
        }
    }
```

#### AUTO 


```{c}
const auto* model = static_cast<const EventListModel*>(list[0].model());
```

#### AUTO 


```{c}
auto* to = new KMime::Headers::To;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& res : resources)
    {
        if (res.location() == url)
        {
            const QString path = url.toDisplayString(QUrl::PrettyDecoded | QUrl::PreferLocalFile);
            qCWarning(KALARM_LOG) << "FileResourceCreator::validateFileUrl: Duplicate path for new resource:" << path;
            return xi18nc("@info", "Error!  The file is already used by an existing resource.", path);
        }
    }
```

#### AUTO 


```{c}
auto* job = qobject_cast<Akonadi::CollectionFetchJob*>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (mEventMap.contains(EventId(event)))
            deleteEventInternal(event, resource, false);
    }
```

#### AUTO 


```{c}
auto* almodel = qobject_cast<AlarmListModel*>(model());
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource& resource : allResources)
        slotResourceAdded(resource);
```

#### AUTO 


```{c}
auto* topLayout = new QVBoxLayout(topWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& addr : mailParams)
        {
            QString a(addr);
            if (!KAMail::checkAddress(a))
                d->setError(xi18nc("@info:shell", "<icode>%1</icode>: invalid email address", d->optionName(MAIL)));
            KCalendarCore::Person person(QString(), addr);
            mAddressees += person;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(it.value()))
                                resource.addEvent(event);
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(mCmdPadding);
```

#### AUTO 


```{c}
auto agent = new KMime::Headers::UserAgent;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr& kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        auto* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "DisplayCalendar::updateKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        mEventList += event;
        mEventMap[kcalevent->uid()] = event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds) {
                const QTimeZone z(zoneId);
                if (z.offsetFromUtc(dtUTC) == utcOffset) {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset) {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous) {
                            return KADateTime();
                        }
                        if (dateOnly) {
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        }
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = z;
                }
            }
```

#### AUTO 


```{c}
auto glayout = new QVBoxLayout(mRepeatGroupBox);
```

#### AUTO 


```{c}
auto units = static_cast<Units>(index + mDateOnlyOffset);
```

#### AUTO 


```{c}
auto* ie = (QInputEvent*)e;
```

#### AUTO 


```{c}
auto* box =  new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(mTimeZoneBox);
```

#### AUTO 


```{c}
const auto& w
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                qdt.setTimeZone(tz);
                // TODO: This may not find abbreviations for second occurrence of
                // the time zone time, after a daylight savings time shift.
                if (tz.abbreviation(qdt) == zoneAbbrev) {
                    int offset2;
                    int offset = offsetAtZoneTime(tz, qdt, &offset2);
                    if (offset == InvalidOffset) {
                        return {};
                    }
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid()) {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous || offset != utcOffset) {
                            return {};
                        }
                        useUtcOffset = true;
                    } else {
                        zone = tz;
                        utcOffset = offset;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWin* win : qAsConst(mWindowList))
        {
            if (win->mAlwaysHide)
                --count;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int month : months) {
            if (first < 0) {
                first = month;
            } else {
                const int span = QDate(2001, last, 1).daysTo(QDate(2001, month, 1));
                if (span > maxgap) {
                    maxgap = span;
                }
            }
            last = month;
        }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate& exceptionDate : std::as_const(mExceptionDates))
        new QListWidgetItem(QLocale().toString(exceptionDate, QLocale::LongFormat), mExceptionDateList);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto it : qAsConst(iteratorsToDelete))
        mEvents.erase(it);
```

#### AUTO 


```{c}
auto it = eventIds.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : lstActions)
        action->setShortcutContext(Qt::WidgetWithChildrenShortcut);
```

#### AUTO 


```{c}
auto it = mResourceNodes.find(r);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : *mUndos)
    {
        switch (item->calendar())
        {
            case CalEvent::ACTIVE:
                return i18nc("@info", "Delete multiple alarms");
            case CalEvent::TEMPLATE:
                return i18nc("@info", "Delete multiple templates");
            case CalEvent::ARCHIVED:
                break;    // check if they are ALL archived
            default:
                return QString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : sel)
    {
        // Try to enable the collection, but untick it if not possible
        mModel->resource(ix).setEnabled(mAlarmType, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& file : qAsConst(files))
                {
                    if (file.scheme() == mailto)
                        newEmails.append(file.path());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        if ((collectionId == -1  ||  collectionId == colId)
        &&  !model->data(model->collectionIndex(colId), AkonadiModel::IsPopulatedRole).toBool())
        {
            Collection c(colId);
            model->refresh(c);    // update with latest data
            if (!c.hasAttribute<CollectionAttribute>()
            ||  c.attribute<CollectionAttribute>()->enabled() == CalEvent::EMPTY)
                return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate& exceptionDate : mExceptionDates)
        new QListWidgetItem(QLocale().toString(exceptionDate, QLocale::LongFormat), mExceptionDateList);
```

#### AUTO 


```{c}
auto* vlayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(actionBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection::Id& id : collectionIds)
        {
            const Resource res = AkonadiModel::instance()->resource(id);
            const QUrl cLocation = res.location();
            if (id != resource.id()  &&  cLocation == location)
            {
                // The collection duplicates the backend storage
                // used by another enabled collection.
                // N.B. don't refresh this collection - assume no change.
                qCDebug(KALARM_LOG) << "CollectionControlModel::checkTypesToEnable:" << id << "duplicates backend for" << resource.id();
                types &= ~res.enabledTypes();
                if (!types)
                    break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& regionCode : regions)
    {
        const QString name = HolidayRegion::name(regionCode);
        const QString languageName = QLocale::languageToString(QLocale(HolidayRegion::languageCode(regionCode)).language());
        const QString label = languageName.isEmpty() ? name : i18nc("Holiday region, region language", "%1 (%2)", name, languageName);
        regionsMap.insert(label, regionCode);
    }
```

#### AUTO 


```{c}
auto statJob = KIO::stat(KIO::upUrl(mUrl));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            qCDebug(KALARM_LOG) << "AkonadiModel::collectionFetchResult:" << c.id();
            auto it = mResources.find(c.id());
            if (it == mResources.end())
                continue;
            Resource& resource = it.value();
            setCollectionChanged(resource, c, false);
        }
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto it = mResources.constBegin();
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto* ke = (QKeyEvent*)e;
```

#### AUTO 


```{c}
auto he = static_cast<QHelpEvent*>(e);
```

#### AUTO 


```{c}
auto id = new KMime::Headers::MessageID;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Person& addr : addresses)
    {
        if (!addr.email().isEmpty())
            append(addr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (mResourceMap.value(key).contains(event.id()))
            deleteEventInternal(event, resource, false);
    }
```

#### AUTO 


```{c}
auto ctype = new KMime::Headers::ContentType;
```

#### AUTO 


```{c}
auto tfLayout = new QVBoxLayout(topFontColour);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        KAEvent* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "DisplayCalendar::updateKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        event->setResourceId(key);
        events += event;
        mEventMap[EventId(key, kcalevent->uid())] = event;
    }
```

#### AUTO 


```{c}
auto getJob = KIO::storedGet(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds) {
                const QTimeZone z(zoneId);
                if (z.offsetFromUtc(dtUTC) == utcOffset) {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset) {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous)
                            return KADateTime();
                        if (dateOnly)
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = z;
                }
            }
```

#### AUTO 


```{c}
auto* vlayout = new QVBoxLayout(mCmdOutputBox);
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(mTimeZoneBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : indexes)
    {
        if (ix.isValid())
        {
            Item::Id id = ix.data(ItemIdRole).toLongLong();
            if (id >= 0)
            {
                if (colId < 0
                ||  ix.data(ParentCollectionRole).value<Collection>().id() == colId)
                    return id;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
```

#### AUTO 


```{c}
auto* model = new ResourceFilterModel(parent);
```

#### AUTO 


```{c}
auto* soundLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : *list)
    {
        // Check whether this item should be ignored because it is a
        // dependent undo. If not, add this item's ID to the ignore list.
        bool omit = false;
        if (item->operation() == UndoItem::MULTI)
        {
            // If any item in a multi-undo is disqualified, omit the whole multi-undo
            QStringList newIDs;
            const Undo::List* undos = ((UndoMultiBase*)item)->undos();
            for (const UndoItem* undo : *undos)
            {
                const QString evid = undo->eventID();
                if (ignoreIDs.contains(evid))
                    omit = true;
                else if (omit)
                    ignoreIDs.append(evid);
                else
                    newIDs.append(evid);
            }
            if (omit)
            {
                for (const QString& newID : std::as_const(newIDs))
                    ignoreIDs.append(newID);
            }
        }
        else
        {
            omit = ignoreIDs.contains(item->eventID());
            if (!omit)
                ignoreIDs.append(item->eventID());
            if (item->operation() == UndoItem::EDIT)
                ignoreIDs.append(item->oldEventID());   // continue looking for its post-edit ID
        }
        if (!omit)
            ids.append(item->id());
//else qCDebug(KALARM_LOG)<<"Undo::ids(): omit"<<item->actionText()<<":"<<item->description();
    }
```

#### AUTO 


```{c}
auto grid = new QGridLayout();
```

#### AUTO 


```{c}
auto* groupLayout = new QVBoxLayout(group);
```

#### AUTO 


```{c}
auto main = static_cast<StackedScrollWidget*>(mTabs->widget(0));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& msg : mErrorMsgs())
        {
            label = new QLabel(msg, topWidget);
            label->setFixedSize(label->sizeHint());
            vlayout->addWidget(label, 0, Qt::AlignLeft);
        }
```

#### AUTO 


```{c}
auto filterEdit = new QLineEdit(this);
```

#### AUTO 


```{c}
auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatDetail::StatDefaultDetails);
```

#### AUTO 


```{c}
const auto customProperties = mEvent.customProperties();
```

#### AUTO 


```{c}
auto comp = new KUrlCompletion(KUrlCompletion::FileCompletion);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& att : attachments)
        {
            const QString attachment = QString::fromLatin1(att.toLocal8Bit());
            const QUrl url = QUrl::fromUserInput(attachment, QString(), QUrl::AssumeLocalFile);
            const QString attachError = xi18nc("@info", "Error attaching file: <filename>%1</filename>", attachment);
            QByteArray contents;
            bool atterror = false;
            if (!url.isLocalFile())
            {
#if KIO_VERSION < QT_VERSION_CHECK(5, 69, 0)
                auto statJob = KIO::stat(url, KIO::StatJob::SourceSide, 2);
#else
                auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatDetail::StatDefaultDetails);
#endif
                KJobWidgets::setWindow(statJob, MainWindow::mainMainWindow());
                if (!statJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not found:" << attachment;
                    return xi18nc("@info", "Attachment not found: <filename>%1</filename>", attachment);
                }
                KFileItem fi(statJob->statResult(), url);
                if (fi.isDir()  ||  !fi.isReadable())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not file/not readable:" << attachment;
                    return attachError;
                }

                // Read the file contents
                auto downloadJob = KIO::storedGet(url);
                KJobWidgets::setWindow(downloadJob, MainWindow::mainMainWindow());
                if (!downloadJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = downloadJob->data();
                if (static_cast<unsigned>(contents.size()) < fi.size())
                {
                    qCDebug(KALARM_LOG) << "KAMail::appendBodyAttachments: Read error:" << attachment;
                    atterror = true;
                }
            }
            else
            {
                QFile f(url.toLocalFile());
                if (!f.open(QIODevice::ReadOnly))
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = f.readAll();
            }

            QByteArray coded = KCodecs::base64Encode(contents);
            KMime::Content* content = new KMime::Content();
            content->setBody(coded + "\n\n");

            // Set the content type
            QMimeDatabase mimeDb;
            QString typeName = mimeDb.mimeTypeForUrl(url).name();
            KMime::Headers::ContentType* ctype = new KMime::Headers::ContentType;
            ctype->fromUnicodeString(typeName, autoDetectCharset(typeName));
            ctype->setName(attachment, "local");
            content->setHeader(ctype);

            // Set the encoding
            KMime::Headers::ContentTransferEncoding* cte = new KMime::Headers::ContentTransferEncoding;
            cte->setEncoding(KMime::Headers::CEbase64);
            cte->setDecoded(false);
            content->setHeader(cte);
            content->assemble();
            message.addContent(content);
            if (atterror)
                return attachError;
        }
```

#### AUTO 


```{c}
auto* agent = new KMime::Headers::UserAgent;
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageDisplayHelper* h : std::as_const(mInstanceList))
    {
        if (h->mErrorWindow  &&  h->mEventId == eid
        &&  h->mErrorMsgs == errmsgs  &&  h->mDontShowAgain == dontShowAgain)
            return false;
    }
```

#### AUTO 


```{c}
auto topGeneral = new StackedGroupWidget(tabgroup);
```

#### AUTO 


```{c}
const auto &phase
```

#### AUTO 


```{c}
auto topFontColour = new StackedGroupWidget(tabgroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        Event::Ptr kcalEvent(new Event);
        const CalEvent::Type type = event.category();
        const QString id = CalEvent::uid(kcalEvent->uid(), type);
        kcalEvent->setUid(id);
        event.updateKCalEvent(kcalEvent, KAEvent::UID_IGNORE);
        if (calendar->addEvent(kcalEvent))
            exported = true;
        else
            success = false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id id : colIds)
    {
        Collection c(id);
        AkonadiModel::instance()->refresh(c);    // update with latest data
        if ((allTypes  ||  c.contentMimeTypes().contains(mimeType))
        &&  agentManager->instance(c.resource()).isValid())
            result += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        if (agent.type().mimeTypes().contains(mimeType))
        {
            {
                CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::FirstLevel);
                job->fetchScope().setResource(agent.identifier());
                mCollectionJobs << job;
                connect(job, &CollectionFetchJob::result, this, &CollectionSearch::collectionFetchResult);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Resource& a, const Resource& b) { return a.displayName().compare(b.displayName(), Qt::CaseInsensitive) < 0; }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Collection c(colId);
        if (c.contentMimeTypes().contains(mimeType)
        &&  (!writable  ||  AkonadiModel::isWritable(c)))
            result += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int month : months) {
            d->mRecurrence->addYearlyMonth(month);
        }
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(mPadding);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        slotInitHamburgerMenu();
        // Needs to be run on demand, but the contents won't change, so disconnect now.
        disconnect(mHamburgerMenu, &KHamburgerMenu::aboutToShowMenu, this, nullptr);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &id](Resource& r) {
                    if (r.id() == id) loop.quit(); }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto* fe = (QFocusEvent*)e;
```

#### AUTO 


```{c}
auto view = new QTextBrowser(topWidget);
```

#### AUTO 


```{c}
auto* mainPage = new PageFrame(mainScroll);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProcData* pd : qAsConst(mCommandProcesses))
                {
                    if (pd->event->id() == event.id()  &&  (pd->flags & ProcData::PRE_ACTION))
                    {
                        qCDebug(KALARM_LOG) << "KAlarmApp::execAlarm: Already executing pre-DISPLAY command";
                        return pd->process;   // already executing - don't duplicate the action
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Collection c(colId);
        if (!writable)
            AkonadiModel::instance()->refresh(c);    // update with latest data
        else if (AkonadiModel::isWritable(c) != 1)   // this refreshes 'c' (needed for mime type check)
            continue;
        if (c.contentMimeTypes().contains(mimeType))
            result += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* w : std::as_const(mWindowList))
            w->move(desk.topLeft());
```

#### AUTO 


```{c}
auto view = static_cast<EventListView*>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent *event : events) {
        KAEventPrivate *const p = event->d;
        if (p->mStartDateTime.isDateOnly()  &&  p->checkRecur() != KARecurrence::NO_RECUR) {
            p->mRecurrence->setStartDateTime(p->mStartDateTime.effectiveKDateTime(), true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule *rule : rulelist)
        if (rule->recursOn(dt, Private::toTimeZone(timeSpec))) {
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MonthPos& posn : posns)
            d->mRecurrence->addMonthlyPos(posn.weeknum, posn.days);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : eventlist)
    {
        if (event->templateName() == templateName)
            return event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id id : colIds)
    {
        Collection c(id);
        AkonadiModel::instance()->refresh(c);    // update with latest data
        if (c.resource() == resourceId)
            return c;
    }
```

#### AUTO 


```{c}
auto ref = new QEventLoopLocker();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().indexOf(MatchMimeType) >= 0)
            {
                ResourceCol thisRes(job->fetchScope().resource(), c.id());
                auto it = mAgentPaths.constFind(c.remoteId());
                if (it != mAgentPaths.constEnd())
                {
                    // Remove the resource containing the higher numbered Collection
                    // ID, which is likely to be the more recently created.
                    const ResourceCol prevRes = it.value();
                    if (thisRes.collectionId > prevRes.collectionId)
                    {
                        qCWarning(KALARM_LOG) << "AkonadiResource::collectionFetchResult: Removing duplicate resource" << thisRes.resourceId;
                        agentManager->removeInstance(agentManager->instance(thisRes.resourceId));
                        continue;
                    }
                    qCWarning(KALARM_LOG) << "AkonadiResource::collectionFetchResult: Removing duplicate resource" << prevRes.resourceId;
                    agentManager->removeInstance(agentManager->instance(prevRes.resourceId));
                }
                mAgentPaths[c.remoteId()] = thisRes;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : eventlist)
    {
        if (event.name() == templateName)
            return event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
            {
                if (alarm->type() == Alarm::Display)
                {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext)
                        alarm->setDisplayAlarm(newtext);
                }
            }
```

#### AUTO 


```{c}
auto descendantsModel = new KDescendantsProxyModel(parent);
```

#### AUTO 


```{c}
auto *rrule2 = new RecurrenceRule();
```

#### AUTO 


```{c}
auto model = new ResourceFilterModel(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Collection c(colId);
        AkonadiModel::instance()->refresh(c);    // update with latest data
        if (c.resource() == resourceId)
            return c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        if (collectionId == -1  ||  collectionId == colId)
        {
            const Resource res = model->resource(colId);
            if (!res.isLoaded()
            &&  res.enabledTypes() != CalEvent::EMPTY)
                return false;
        }
    }
```

#### AUTO 


```{c}
const auto effects = mPath.effects();
```

#### AUTO 


```{c}
auto statJob = static_cast<KIO::StatJob*>(job);
```

#### AUTO 


```{c}
auto* comp = new KUrlCompletion(KUrlCompletion::FileCompletion);
```

#### AUTO 


```{c}
auto wgrid = new QGridLayout(daybox);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &menu, act] { showHideColumn(menu, act); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
    {
        if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
            continue;    // ignore events without alarms, or usable alarms
        CalEvent::Type type = CalEvent::status(event);
        if (type == CalEvent::TEMPLATE)
        {
            // If we know the event was not created by KAlarm, don't treat it as a template
            if (!currentFormat)
                type = CalEvent::ACTIVE;
        }
        if (!(type & alarmTypes))
            continue;

        Event::Ptr newev(new Event(*event));

        // If there is a display alarm without display text, use the event
        // summary text instead.
        if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
        {
            const Alarm::List& alarms = newev->alarms();
            for (Alarm::Ptr alarm : alarms)
            {
                if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                    alarm->setText(newev->summary());
            }
            newev->setSummary(QString());   // KAlarm only uses summary for template names
        }

        // Give the event a new ID, or ensure that it is in the correct format.
        const QString id = newId ? CalFormat::createUniqueId() : newev->uid();
        newev->setUid(CalEvent::uid(id, type));

        alarmList[type] += KAEvent(newev);
    }
```

#### AUTO 


```{c}
auto model = new ResourceListModel(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                if (!mUid.isEmpty())
                {
                    if (item.mimeType() == mMimeType  &&  item.hasPayload<Event::Ptr>())
                    {
                        const Event::Ptr kcalEvent = item.payload<Event::Ptr>();
                        if (kcalEvent->uid() != mUid)
                            continue;
                    }
                }
                else if (mGid.isEmpty())
                    continue;
                ItemDeleteJob* djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs.value(job);
                connect(djob, &ItemDeleteJob::result, this, &AkonadiCollectionSearch::itemDeleteResult);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceType::StorageType t : types)
            typeDescs += Resource::storageTypeString(t);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageDisplayHelper* h : std::as_const(mInstanceList))
        {
            if (h->mParent != exclude  &&  h->mEventId == eventId  &&  !h->mErrorWindow)
                return h->mParent;
        }
```

#### AUTO 


```{c}
auto job = static_cast<ItemDeleteJob*>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            qCDebug(KALARM_LOG) << "AkonadiModel::collectionFetchResult:" << c.id();
            auto it = mResources.find(c.id());
            if (it == mResources.end())
                continue;
            Resource& resource = it.value();
            Collection& resourceCol = AkonadiResource::collection(resource);
            QSet<QByteArray> attrNames;
            if (c.hasAttribute<CollectionAttribute>())
            {
                if (!resourceCol.hasAttribute<CollectionAttribute>()
                ||  *c.attribute<CollectionAttribute>() != *resourceCol.attribute<CollectionAttribute>())
                    attrNames.insert(CollectionAttribute::name());
            }
            if (c.hasAttribute<CompatibilityAttribute>())
            {
                if (!resourceCol.hasAttribute<CompatibilityAttribute>()
                ||  *c.attribute<CompatibilityAttribute>() != *resourceCol.attribute<CompatibilityAttribute>())
                    attrNames.insert(CompatibilityAttribute::name());
            }
            resourceCol = c;   // update our copy of the collection
            if (!attrNames.isEmpty())
            {
                // Process the changed attribute values.
                setCollectionChanged(resource, c, attrNames, false);
            }
        }
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr& alarm : alarms)
    {
        bool done = false;
        switch (alarm->type())
        {
            case Alarm::Display:
            case Alarm::Procedure:
                audioOnly = false;
                done = true;   // exit from the 'for' loop
                break;
            case Alarm::Audio:
                audioOnly = true;
                break;
            default:
                break;
        }
        if (done)
            break;
    }
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(mainWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& templ : templates)
    {
        const QString name = templ.name();
        int j = 0;
        for (int jend = sorted.count();
             j < jend  &&  QString::localeAwareCompare(name, sorted[j]) > 0;
             ++j) ;
        sorted.insert(j, name);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent* const event : eventlist)
    {
        if (!event->enabled())
        {
            disabled = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                if (tz.offsetFromUtc(dtUTC) == utcOffset) {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset) {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous) {
                            return KADateTime();
                        }
                        if (dateOnly) {
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        }
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = tz;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        // Parse the next alarm's text
        AlarmData data;
        readAlarm(alarm, data, audioOnly, cmdDisplay);
        if (data.type != INVALID_ALARM) {
            alarmMap->insert(data.type, data);
        }
    }
```

#### AUTO 


```{c}
auto elm = qobject_cast<EventListModel*>(model);
```

#### AUTO 


```{c}
auto* parent = static_cast<Label*>(parentWidget());
```

#### AUTO 


```{c}
auto* label = new KSqueezedTextLabel(texts.fileName, topWidget);
```

#### AUTO 


```{c}
auto dlg = qobject_cast<EditAlarmDlg*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (DailyTimer* timer : qAsConst(mFixedTimers))
        if (timer->mTime == timeOfDay)
            return timer;
```

#### RANGE FOR STATEMENT 


```{c}
for (QByteArray encoding : {"us-ascii", "iso-8859-1", "locale", "utf-8"})
    {
        if (encoding == "locale")
            encoding = QTextCodec::codecForLocale()->name().toLower();
        if (text.isEmpty())
            return encoding;
        if (encoding == "us-ascii")
        {
            if (KMime::isUsAscii(text))
                return encoding;
        }
        else
        {
            const QTextCodec* codec = codecForName(encoding);
            if (!codec)
                qCDebug(KALARM_LOG) << "KAMail::autoDetectCharset: Something is wrong and I cannot get a codec. [" << encoding <<"]";
            else
            {
                 if (codec->canEncode(text))
                     return encoding;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& resourceGroup : qAsConst(resourceGroups))
        {
            int groupIndex = resourceGroup.midRef(9).toInt();
            FileResourceSettings::Ptr settings(new FileResourceSettings(manager->mConfig, resourceGroup));
            if (!settings->isValid())
            {
                qCWarning(KALARM_LOG) << "FileResourceConfigManager: Invalid config for" << resourceGroup;
                manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
            }
            else
            {
                // Check for and remove duplicate URL or 'standard' setting
                for (auto it = manager->mResources.constBegin();  it != manager->mResources.constEnd();  ++it)
                {
                    const ResourceData& data = it.value();
                    if (settings->url() == data.resource.location())
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate URL in config for" << resourceGroup;
                        manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Deleted duplicate resource" << settings->displayName();
                        settings.clear();
                        break;
                    }
                    const CalEvent::Types std = settings->standardTypes() & data.settings->standardTypes();
                    if (std)
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate 'standard' setting in config for" << resourceGroup;
                        settings->setStandard(settings->standardTypes() ^ std);
                    }
                }
                if (settings)
                {
                    Resource resource(createResource(settings));
                    manager->mResources[settings->id()] = ResourceData(resource, settings);
                    manager->mConfigGroups[groupIndex] = settings->id();

                    Resources::notifyNewResourceInitialised(resource);

                    // Update the calendar to the current KAlarm format if necessary, and
                    // if the user agrees.
                    FileResourceCalendarUpdater::updateToCurrentFormat(resource, false, parent);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance& agent : agents)
            {
                const QString type = agent.type().identifier();
                if (type == KALARM_DIR_RESOURCE)
                {
                    // Fetch the resource's collection to determine its alarm types
                    Akonadi::CollectionFetchJob* job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::FirstLevel);
                    job->fetchScope().setResource(agent.identifier());
                    mFetchesPending << job;
                    connect(job, &KJob::result, this, &FileResourceMigrator::collectionFetchResult);

                    mMigrateKResources = false;   // ignore KResources if Akonadi resources exist
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().contains(mMimeType))
            {
                ItemFetchJob* ijob;
                if (!mGid.isEmpty())
                {
                    // Search for all Items with the specified GID
                    Item item;
                    item.setGid(mGid);
                    ijob = new ItemFetchJob(item, this);
                    ijob->setCollection(c);
                }
                else if (!mUid.isEmpty())
                {
                    // Search for all Events with the specified UID
                    ijob = new ItemFetchJob(c, this);
                    ijob->fetchScope().fetchFullPayload(true);
                }
                else
                {
                    mCollections << c;
                    continue;
                }
                mItemFetchJobs[ijob] = c.id();
                connect(ijob, &ItemFetchJob::result, this, &CollectionSearch::itemFetchResult);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool on) { mSoundVolumeSlider->setEnabled(on); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        QHash<QString, KAEvent>::iterator it = mEvents.find(event.id());
        if (it != mEvents.end())
        {
            eventsToDelete += event.id();
            if (event.category() & types)
                eventsToNotify += event;
        }
    }
```

#### AUTO 


```{c}
auto dlg = qobject_cast<EditDisplayAlarmDlg*>(editDlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
        {
            if (!event.enabled()  &&  (event.actionTypes() & KAEvent::ACT_DISPLAY))
            {
                MessageDisplay* win = MessageDisplay::findEvent(EventId(event));
                delete win;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Person& who : toList)
        to->addAddress(who.email().toLatin1(), who.name());
```

#### AUTO 


```{c}
auto it = mResources.find(c.id());
```

#### AUTO 


```{c}
auto dlg = qobject_cast<DeferAlarmDlg*>(obj);
```

#### AUTO 


```{c}
auto* ctype = new KMime::Headers::ContentType;
```

#### RANGE FOR STATEMENT 


```{c}
for (const MonthPos& posn : posns)
            d->mRecurrence->addYearlyPos(posn.weeknum, posn.days);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& eventId : eventIds)
        events += resource.event(eventId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Undo::Event& event : events)
        mUndos->append(new T(Undo::NONE, event));
```

#### AUTO 


```{c}
auto* topFontColour = new StackedWidgetT<QWidget>(tabgroup);
```

#### AUTO 


```{c}
auto typeBoxLayout = new QHBoxLayout(mTypeBox);
```

#### AUTO 


```{c}
auto it = customProperties.cbegin(), end = customProperties.cend();
```

#### AUTO 


```{c}
auto m = qobject_cast<EventListModel*>(model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        const KADateTime dateTime = event.nextTrigger(KAEvent::DISPLAY_TRIGGER).effectiveKDateTime().toLocalZone();
        Akonadi::Collection c(event.collectionId());
        AkonadiModel::instance()->refresh(c);
        QString text(c.resource() + QLatin1String(":"));
        text += event.id() + QLatin1Char(' ')
             +  dateTime.toString(QStringLiteral("%Y%m%dT%H%M "))
             +  AlarmText::summary(event, 1);
        alarms << text;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos &p : pos) {
            const int day = p.day() - 1;  // Monday = 0
            if (mWorkDays.testBit(day)) {
                noWorkPos = false;    // found a working day occurrence
            }
            allDaysMask |= 1 << day;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            const QUrl cLocation = QUrl::fromUserInput(c.remoteId(), QString(), QUrl::AssumeLocalFile);
            if (c.id() != collection.id()  &&  cLocation == location)
            {
                // The collection duplicates the backend storage
                // used by another enabled collection.
                // N.B. don't refresh this collection - assume no change.
                qCDebug(KALARM_LOG) << "Collection" << c.id() << "duplicates backend for" << collection.id();
                if (c.hasAttribute<CollectionAttribute>())
                {
                    types &= ~c.attribute<CollectionAttribute>()->enabled();
                    if (!types)
                        break;
                }
            }
        }
```

#### AUTO 


```{c}
const auto action = static_cast<QueuedAction>(int(QueuedAction::List) | int(QueuedAction::Exit));
```

#### AUTO 


```{c}
auto* id = new KMime::Headers::MessageID;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& att : attachments)
        {
            const QString attachment = QString::fromLatin1(att.toLocal8Bit());
            const QUrl url = QUrl::fromUserInput(attachment, QString(), QUrl::AssumeLocalFile);
            const QString attachError = xi18nc("@info", "Error attaching file: <filename>%1</filename>", attachment);
            QByteArray contents;
            bool atterror = false;
            if (!url.isLocalFile())
            {
                auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatDetail::StatDefaultDetails);
                KJobWidgets::setWindow(statJob, MainWindow::mainMainWindow());
                if (!statJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not found:" << attachment;
                    return xi18nc("@info", "Attachment not found: <filename>%1</filename>", attachment);
                }
                KFileItem fi(statJob->statResult(), url);
                if (fi.isDir()  ||  !fi.isReadable())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not file/not readable:" << attachment;
                    return attachError;
                }

                // Read the file contents
                auto downloadJob = KIO::storedGet(url);
                KJobWidgets::setWindow(downloadJob, MainWindow::mainMainWindow());
                if (!downloadJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = downloadJob->data();
                if (static_cast<unsigned>(contents.size()) < fi.size())
                {
                    qCDebug(KALARM_LOG) << "KAMail::appendBodyAttachments: Read error:" << attachment;
                    atterror = true;
                }
            }
            else
            {
                QFile f(url.toLocalFile());
                if (!f.open(QIODevice::ReadOnly))
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = f.readAll();
            }

            QByteArray coded = KCodecs::base64Encode(contents);
            auto* content = new KMime::Content();
            content->setBody(coded + "\n\n");

            // Set the content type
            QMimeDatabase mimeDb;
            QString typeName = mimeDb.mimeTypeForUrl(url).name();
            auto* ctype = new KMime::Headers::ContentType;
            ctype->fromUnicodeString(typeName, autoDetectCharset(typeName));
            ctype->setName(attachment, "local");
            content->setHeader(ctype);

            // Set the encoding
            auto* cte = new KMime::Headers::ContentTransferEncoding;
            cte->setEncoding(KMime::Headers::CEbase64);
            cte->setDecoded(false);
            content->setHeader(cte);
            content->assemble();
            message.addContent(content);
            if (atterror)
                return attachError;
        }
```

#### AUTO 


```{c}
auto freqLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto it = manager->mConfigGroups.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(eventsToAdd))
            {
                KAEvent* ev = new KAEvent(event);
                ev->setResourceId(resource.id());
                Node* node = new Node(ev, resource);
                resourceEventNodes += node;
                mEventNodes[ev->id()] = node;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto instance : std::as_const(mInstances))
    {
        instance->mActiveModel->disable();
        instance->mArchivedModel->disable();
        instance->mTemplateModel->disable();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Undo::Event& event : events)
            removeRedos(event.event.id());
```

#### AUTO 


```{c}
auto model = new AlarmListModel(parent);
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(mPadding);
```

#### RANGE FOR STATEMENT 


```{c}
for (Node* node : eventNodes)
    {
        KAEvent* event = node->event();
        if (event)
        {
            const QString eventId = event->id();
            mEventNodes.remove(eventId);
            ++count;
        }
        delete node;
    }
```

#### AUTO 


```{c}
auto itemModel = qobject_cast<EventListModel*>(model);
```

#### AUTO 


```{c}
auto* colourLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto fader = new Phonon::VolumeFaderEffect(mAudioObject);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageDisplayHelper* h : qAsConst(mInstanceList))
    {
        if (h->mErrorWindow  &&  h->mEventId == eid
        &&  h->mErrorMsgs == errmsgs  &&  h->mDontShowAgain == dontShowAgain)
            return false;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { updateFormat(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
    {
        if (event->actionSubType() == KAEvent::MESSAGE
        &&  event->recurType() == KARecurrence::ANNUAL_DATE
        &&  (prefix.isEmpty()  ||  event->message().startsWith(prefix)))
            mContactsWithAlarm.append(event->message());
    }
```

#### AUTO 


```{c}
auto* ttLayout = new QVBoxLayout(topTypes);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length && txt[i].isDigit()) {
                        ;
                    }
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (const Alarm::Ptr &alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display) {
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                    }
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : mEventList)
    {
        mEventMap.remove(event->id());
        delete event;
    }
```

#### AUTO 


```{c}
auto it = mEvents.constFind(eventId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&service](int ret) { service.setExitValue(ret); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
        {
            if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
                continue;    // ignore events without alarms, or usable alarms
            CalEvent::Type type = CalEvent::status(event);
            if (type == CalEvent::TEMPLATE)
            {
                // If we know the event was not created by KAlarm, don't treat it as a template
                if (!currentFormat)
                    type = CalEvent::ACTIVE;
            }
            Resource res;
            if (resource.isValid())
            {
                if (!(type & wantedTypes))
                    continue;
                res = resource;
            }
            else
            {
                switch (type)
                {
                    case CalEvent::ACTIVE:
                    case CalEvent::ARCHIVED:
                    case CalEvent::TEMPLATE:
                        break;
                    default:
                        continue;
                }
//TODO: does this prompt for every alarm if no default is set?
                res = Resources::destination(type);
            }

            Event::Ptr newev(new Event(*event));

            // If there is a display alarm without display text, use the event
            // summary text instead.
            if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
            {
                const Alarm::List& alarms = newev->alarms();
                for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
                newev->setSummary(QString());   // KAlarm only uses summary for template names
            }

            // Give the event a new ID and add it to the calendars
            newev->setUid(CalEvent::uid(CalFormat::createUniqueId(), type));
            if (!res.addEvent(KAEvent(newev)))
                success = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* act : qAsConst(actions))
        {
            if (act->data().toInt() == AlarmListModel::TimeColumn)
            {
                act->setEnabled(false);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : std::as_const(it.value()))
                    resource.addEvent(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (includeCmdAlarms  ||  !(event.actionTypes() & KAEvent::ACT_COMMAND))
            templates.append(event);
    }
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(mCmdOutputBox);
```

#### AUTO 


```{c}
auto* vlayout = new QVBoxLayout(mButtonBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList)
            {
                qdt.setTimeZone(tz);
                // TODO: This may not find abbreviations for second occurrence of
                // the time zone time, after a daylight savings time shift.
                if (tz.abbreviation(qdt) == zoneAbbrev)
                {
                    int offset2;
                    int offset = offsetAtZoneTime(tz, qdt, &offset2);
                    if (offset == InvalidOffset)
                        return {};
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid())
                    {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous || offset != utcOffset)
                            return {};
                        useUtcOffset = true;
                    }
                    else
                    {
                        zone = tz;
                        utcOffset = offset;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Phonon::Effect* effect : effects)
    {
        mPath.removeEffect(effect);
        delete effect;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageDisplayHelper* h : qAsConst(mInstanceList))
        {
            if (h->mAlwaysHide)
                --count;
        }
```

#### AUTO 


```{c}
auto* output = new Phonon::AudioOutput(Phonon::NotificationCategory, mAudioObject);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& newID : qAsConst(newIDs))
                    ignoreIDs.append(newID);
```

#### AUTO 


```{c}
const auto &transition = *it;
```

#### AUTO 


```{c}
auto page = qobject_cast<DirResourceImportTypeWidget*>(currentPage()->widget());
```

#### AUTO 


```{c}
auto* output = new Phonon::AudioOutput(Phonon::MusicCategory, mPlayer);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
        if (alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
            if (!converted) {
                event->startUpdates();   // prevent multiple update notifications
                if (readOnly) {
                    event->setReadOnly(false);
                }
                if ((alarm->snoozeTime().asSeconds() % (24 * 3600)) != 0) {
                    recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                } else {
                    recur->setDaily(alarm->snoozeTime().asDays());
                }
                recur->setDuration(alarm->repeatCount() + 1);
                converted = true;
            }
            alarm->setRepeatCount(0);
            alarm->setSnoozeTime(0);
        }
    }
```

#### AUTO 


```{c}
auto djob = new ItemDeleteJob(item, this);
```

#### AUTO 


```{c}
auto it = model->mResources.find(res->id());
```

#### AUTO 


```{c}
auto it = mResources.begin();
```

#### AUTO 


```{c}
auto eventL = left.payload<KAEvent>();
```

#### AUTO 


```{c}
auto it
```

#### AUTO 


```{c}
auto ke = static_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto page = static_cast<DirResourceImportWidgetBase*>(current->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageDisplayHelper* h : qAsConst(mInstanceList))
        {
            if (h->mParent != exclude  &&  h->mEventId == eventId  &&  !h->mErrorWindow)
                return h->mParent;
        }
```

#### AUTO 


```{c}
auto* model = new TemplateListModel(parent);
```

#### AUTO 


```{c}
auto* topTypes = new StackedWidgetT<QWidget>(tabgroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AkonadiModel::Event& event : events)
        slotEventChanged(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource res : resources)
            if (!res.save(&msg))
            {
                res.reload(true);    // retrieve the events which couldn't be deleted
                status.setError(SAVE_FAILED, status.failedCount(), msg);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : indexes)
    {
        QModelIndex proxyIndex = mapFromSource(ix);
        if (proxyIndex.isValid())
            matches += proxyIndex;
    }
```

#### AUTO 


```{c}
auto* dlg = qobject_cast<EditAudioAlarmDlg*>(editDlg);
```

#### AUTO 


```{c}
auto* hbox = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto options = new CommandOptions;
```

#### AUTO 


```{c}
auto* model = new ResourceListModel(parent);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto action = static_cast<QueuedAction>(int((command == CommandOptions::TRIGGER_EVENT) ? QueuedAction::Trigger : QueuedAction::Cancel)
                                                      | int(QueuedAction::Exit));
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == AkonadiResource::KALARM_RESOURCE  ||  type == AkonadiResource::KALARM_DIR_RESOURCE)
        {
            // Fetch the resource's collection to determine its alarm types
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending << job;
            connect(job, &KJob::result, this, &AkonadiResourceMigrator::collectionFetchResult);
            // Note: Once all collections have been fetched, any missing
            //       default resources will be created.
        }
    }
```

#### AUTO 


```{c}
auto statJob = KIO::stat(url.url(), KIO::StatJob::SourceSide, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : std::as_const(mEventsUpdated))
        Resources::notifyEventUpdated(this, event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& w : mWidgets)
        sz = sz.expandedTo(w->T::minimumSizeHint());
```

#### AUTO 


```{c}
auto* mainLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& att : attachments)
        {
            const QString attachment = QString::fromLatin1(att.toLocal8Bit());
            const QUrl url = QUrl::fromUserInput(attachment, QString(), QUrl::AssumeLocalFile);
            const QString attachError = xi18nc("@info", "Error attaching file: <filename>%1</filename>", attachment);
            QByteArray contents;
            bool atterror = false;
            if (!url.isLocalFile())
            {
                auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatDetail::StatDefaultDetails);
                KJobWidgets::setWindow(statJob, MainWindow::mainMainWindow());
                if (!statJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not found:" << attachment;
                    return xi18nc("@info", "Attachment not found: <filename>%1</filename>", attachment);
                }
                KFileItem fi(statJob->statResult(), url);
                if (fi.isDir()  ||  !fi.isReadable())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not file/not readable:" << attachment;
                    return attachError;
                }

                // Read the file contents
                auto downloadJob = KIO::storedGet(url);
                KJobWidgets::setWindow(downloadJob, MainWindow::mainMainWindow());
                if (!downloadJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = downloadJob->data();
                if (static_cast<unsigned>(contents.size()) < fi.size())
                {
                    qCDebug(KALARM_LOG) << "KAMail::appendBodyAttachments: Read error:" << attachment;
                    atterror = true;
                }
            }
            else
            {
                QFile f(url.toLocalFile());
                if (!f.open(QIODevice::ReadOnly))
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = f.readAll();
            }

            QByteArray coded = KCodecs::base64Encode(contents);
            KMime::Content* content = new KMime::Content();
            content->setBody(coded + "\n\n");

            // Set the content type
            QMimeDatabase mimeDb;
            QString typeName = mimeDb.mimeTypeForUrl(url).name();
            KMime::Headers::ContentType* ctype = new KMime::Headers::ContentType;
            ctype->fromUnicodeString(typeName, autoDetectCharset(typeName));
            ctype->setName(attachment, "local");
            content->setHeader(ctype);

            // Set the encoding
            KMime::Headers::ContentTransferEncoding* cte = new KMime::Headers::ContentTransferEncoding;
            cte->setEncoding(KMime::Headers::CEbase64);
            cte->setDecoded(false);
            content->setHeader(cte);
            content->assemble();
            message.addContent(content);
            if (atterror)
                return attachError;
        }
```

#### AUTO 


```{c}
auto* grid = new QGridLayout(mShowInSystemTrayGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == KALARM_RESOURCE  ||  type == KALARM_DIR_RESOURCE)
        {
            // Fetch the resource's collection to determine its alarm types
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending << job;
            connect(job, &KJob::result, this, &AkonadiResourceMigrator::collectionFetchResult);
            // Note: Once all collections have been fetched, any missing
            //       default resources will be created.
        }
    }
```

#### AUTO 


```{c}
auto encodings = KMime::encodingsForData(message.body());
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOUR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (Alarm::Ptr alarm : alarms) {
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QLatin1String("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QLatin1String("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (Alarm::Ptr alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList list = prop.split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                QStringList types = property.split(QChar::fromLatin1(','), QString::SkipEmptyParts);
#else
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
#endif
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOUR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (Alarm::Ptr alarm : alarms) {
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList list = prop.split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                QStringList types = property.split(QChar::fromLatin1(','), QString::SkipEmptyParts);
#else
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
#endif
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (event.actionSubType() == KAEvent::MESSAGE
        &&  event.recurType() == KARecurrence::ANNUAL_DATE
        &&  (prefix.isEmpty()  ||  event.message().startsWith(prefix)))
            mContactsWithAlarm.append(event.message());
    }
```

#### AUTO 


```{c}
auto label = new KSqueezedTextLabel(texts.fileName, topWidget);
```

#### AUTO 


```{c}
const auto &qdt
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                QStringList types = property.split(QChar::fromLatin1(','), QString::SkipEmptyParts);
#else
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
#endif
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos &day : days)
            if (day.pos() == 0) {
                ds[day.day() - 1] = true;
            }
```

#### AUTO 


```{c}
auto* model = new ResourceCheckListModel(type, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection::Id& id : collectionIds)
        {
            const Collection c(id);
            const QUrl cLocation = QUrl::fromUserInput(c.remoteId(), QString(), QUrl::AssumeLocalFile);
            if (id != collection.id()  &&  cLocation == location)
            {
                // The collection duplicates the backend storage
                // used by another enabled collection.
                // N.B. don't refresh this collection - assume no change.
                qCDebug(KALARM_LOG) << "CollectionControlModel::checkTypesToEnable:" << id << "duplicates backend for" << collection.id();
                if (c.hasAttribute<CollectionAttribute>())
                {
                    types &= ~c.attribute<CollectionAttribute>()->enabled();
                    if (!types)
                        break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length && txt[i].isDigit()) {
                        ;
                    }
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
```

#### AUTO 


```{c}
auto* he = (QHoverEvent*)e;
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
        {
            CalEvent::Types types;
            Resource res = model->resource(colId);
            if (colId == resource.id())
                types = ctypes | type;
            else
            {
                types = res.configStandardTypes();
                if (!(types & type))
                    continue;
                types &= ~type;
            }
            res.configSetStandard(types);
        }
```

#### AUTO 


```{c}
auto timeBoxHLayout = new QHBoxLayout(timeBox);
```

#### AUTO 


```{c}
auto* akres = resource<AkonadiResource>(res);
```

#### AUTO 


```{c}
auto topTypes = new StackedGroupWidget(tabgroup);
```

#### AUTO 


```{c}
auto* bcc = new KMime::Headers::Bcc;
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     QLocale::c().toString(dt, dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent* const event : events)
            {
                KAEvent ev = *event;
                if (!cancelReminderAndDeferral(ev))
                {
                    if (mAlarmsEnabled)
                        queueAlarmId(ev);
                }
            }
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource, agent.identifier());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {
        bool done = false;
        switch (alarm->type()) {
        case Alarm::Display:
        case Alarm::Procedure:
            audioOnly = false;
            done = true;   // exit from the 'for' loop
            break;
        case Alarm::Audio:
            audioOnly = true;
            break;
        default:
            break;
        }
        if (done) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : std::as_const(mEventList))
    {
        mEventMap.remove(event->id());
        delete event;
    }
```

#### AUTO 


```{c}
const auto phases = ktz.phases();
```

#### AUTO 


```{c}
auto downloadJob = KIO::storedGet(url);
```

#### AUTO 


```{c}
auto* vbox = new QVBoxLayout(febBox);
```

#### AUTO 


```{c}
auto* typePage = qobject_cast<DirResourceImportTypeWidget*>(page);
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(actionBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceId id : resourceIds)
        {
            Resource res = Resources::resource(id);
            if (!res.save(&msg))
            {
                // Don't reload resource after failed save. It's better to
                // keep the new enabled status of the alarms at least until
                // KAlarm is restarted.
                status.setError(SAVE_FAILED, status.failedCount(), msg);
            }
        }
```

#### AUTO 


```{c}
auto* wgrid = new QGridLayout(daybox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection::Id& id : colIds)
                {
                    const Resource res = AkonadiModel::instance()->resource(id);
                    if (res.isValid())
                    {
                        const CalEvent::Types t = stdTypes & res.alarmTypes();
                        if (t  &&  resource.isCompatible())
                        {
                            disallowedStdTypes |= res.configStandardTypes() & t;
                            if (disallowedStdTypes == stdTypes)
                                break;
                        }
                    }
                }
```

#### AUTO 


```{c}
auto* job = new ItemDeleteJob(item);
```

#### AUTO 


```{c}
auto to = new KMime::Headers::To;
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* const event : events)
            {
                if (!cancelReminderAndDeferral(*event))
                {
                    if (mAlarmsEnabled)
                        queueAlarmId(*event);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : *list)
    {
        // Check whether this item should be ignored because it is a
        // dependent undo. If not, add this item's ID to the ignore list.
        bool omit = false;
        if (item->operation() == UndoItem::MULTI)
        {
            // If any item in a multi-undo is disqualified, omit the whole multi-undo
            QStringList newIDs;
            const Undo::List* undos = ((UndoMultiBase*)item)->undos();
            for (const UndoItem* undo : *undos)
            {
                const QString evid = undo->eventID();
                if (ignoreIDs.contains(evid))
                    omit = true;
                else if (omit)
                    ignoreIDs.append(evid);
                else
                    newIDs.append(evid);
            }
            if (omit)
            {
                for (const QString& newID : qAsConst(newIDs))
                    ignoreIDs.append(newID);
            }
        }
        else
        {
            omit = ignoreIDs.contains(item->eventID());
            if (!omit)
                ignoreIDs.append(item->eventID());
            if (item->operation() == UndoItem::EDIT)
                ignoreIDs.append(item->oldEventID());   // continue looking for its post-edit ID
        }
        if (!omit)
            ids.append(item->id());
//else qCDebug(KALARM_LOG)<<"Undo::ids(): omit"<<item->actionText()<<":"<<item->description();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int day : days) {
            d->mRecurrence->addMonthlyDate(day);
        }
```

#### AUTO 


```{c}
auto* attr = collection.attribute<CollectionAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sw : mWidgets)
    {
        QWidget* w = static_cast<StackedScrollWidget*>(sw)->widget();
        if (!w)
            return QSize();
        const QSize s = w->minimumSizeHint();
        if (!s.isValid())
            return QSize();
        sz = sz.expandedTo(s);
    }
```

#### AUTO 


```{c}
const auto& sw
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds) {
                const QTimeZone z(zoneId);
                if (z.offsetFromUtc(dtUTC) == utcOffset) {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset) {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous) {
                            return {};
                        }
                        if (dateOnly) {
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        }
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = z;
                }
            }
```

#### AUTO 


```{c}
auto* cte = new KMime::Headers::ContentTransferEncoding;
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        KAEvent* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "DisplayCalendar::updateKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        mEventList += event;
        mEventMap[kcalevent->uid()] = event;
    }
```

#### AUTO 


```{c}
auto grid = new QGridLayout(textGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& att : attachments)
        {
            const QString attachment = QString::fromLatin1(att.toLocal8Bit());
            const QUrl url = QUrl::fromUserInput(attachment, QString(), QUrl::AssumeLocalFile);
            const QString attachError = xi18nc("@info", "Error attaching file: <filename>%1</filename>", attachment);
            QByteArray contents;
            bool atterror = false;
            if (!url.isLocalFile())
            {
                KIO::UDSEntry uds;
                auto statJob = KIO::stat(url, KIO::StatJob::SourceSide, 2);
                KJobWidgets::setWindow(statJob, MainWindow::mainMainWindow());
                if (!statJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not found:" << attachment;
                    return xi18nc("@info", "Attachment not found: <filename>%1</filename>", attachment);
                }
                KFileItem fi(statJob->statResult(), url);
                if (fi.isDir()  ||  !fi.isReadable())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not file/not readable:" << attachment;
                    return attachError;
                }

                // Read the file contents
                auto downloadJob = KIO::storedGet(url);
                KJobWidgets::setWindow(downloadJob, MainWindow::mainMainWindow());
                if (!downloadJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = downloadJob->data();
                if (static_cast<unsigned>(contents.size()) < fi.size())
                {
                    qCDebug(KALARM_LOG) << "KAMail::appendBodyAttachments: Read error:" << attachment;
                    atterror = true;
                }
            }
            else
            {
                QFile f(url.toLocalFile());
                if (!f.open(QIODevice::ReadOnly))
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = f.readAll();
            }

            QByteArray coded = KCodecs::base64Encode(contents);
            KMime::Content* content = new KMime::Content();
            content->setBody(coded + "\n\n");

            // Set the content type
            QMimeDatabase mimeDb;
            QString typeName = mimeDb.mimeTypeForUrl(url).name();
            KMime::Headers::ContentType* ctype = new KMime::Headers::ContentType;
            ctype->fromUnicodeString(typeName, autoDetectCharset(typeName));
            ctype->setName(attachment, "local");
            content->setHeader(ctype);

            // Set the encoding
            KMime::Headers::ContentTransferEncoding* cte = new KMime::Headers::ContentTransferEncoding;
            cte->setEncoding(KMime::Headers::CEbase64);
            cte->setDecoded(false);
            content->setHeader(cte);
            content->assemble();
            message.addContent(content);
            if (atterror)
                return attachError;
        }
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto subject = new KMime::Headers::Subject;
```

#### AUTO 


```{c}
auto* radio = new QRadioButton(args[0], group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().indexOf(matchMimeType) >= 0)
            {
                ResourceCol thisRes(job->fetchScope().resource(), c.id());
                auto it = mAgentPaths.constFind(c.remoteId());
                if (it != mAgentPaths.constEnd())
                {
                    // Remove the resource containing the higher numbered Collection
                    // ID, which is likely to be the more recently created.
                    ResourceCol prevRes = it.value();
                    if (thisRes.collectionId > prevRes.collectionId)
                    {
                        qCWarning(KALARM_LOG) << "CollectionControlModel::collectionFetchResult: Removing duplicate resource" << thisRes.resourceId;
                        agentManager->removeInstance(agentManager->instance(thisRes.resourceId));
                        continue;
                    }
                    qCWarning(KALARM_LOG) << "CollectionControlModel::collectionFetchResult: Removing duplicate resource" << prevRes.resourceId;
                    agentManager->removeInstance(agentManager->instance(prevRes.resourceId));
                }
                mAgentPaths[c.remoteId()] = thisRes;
            }
        }
```

#### AUTO 


```{c}
auto* subject = new KMime::Headers::Subject;
```

#### AUTO 


```{c}
auto* mailjob = new MailTransport::MessageQueueJob(qApp);
```

#### AUTO 


```{c}
auto errit = cmdErrors.begin();
```

#### AUTO 


```{c}
auto topGeneral = new QVBoxLayout(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr& alarm : alarms)
                {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display)
                    {
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == KALARM_RESOURCE)
        {
            // Fetch the resource's collection to determine its alarm types
            Akonadi::CollectionFetchJob* job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending << job;
            connect(job, &KJob::result, this, &FileResourceMigrator::collectionFetchResult);

            mMigrateKResources = false;   // ignore KResources if Akonadi resources exist
        }
    }
```

#### AUTO 


```{c}
auto* proxyModel = static_cast<KDescendantsProxyModel*>(sourceModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        if (agent.type().mimeTypes().indexOf(MatchMimeType) >= 0)
        {
            ++mDuplicateResourceObject->agentCount;
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
            job->fetchScope().setResource(agent.identifier());
            connect(job, &CollectionFetchJob::result, mDuplicateResourceObject, &DuplicateResourceObject::collectionFetchResult);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        auto it = mEvents.find(event.id());
        if (it == mEvents.end())
        {
            mEvents[event.id()] = event;
            if (event.category() & types)
                eventsAdded += event;
        }
        else
        {
            KAEvent& ev = it.value();
            bool changed = !ev.compare(event, KAEvent::Compare::Id | KAEvent::Compare::CurrentState);
            ev = event;   // update existing event
            if (changed  &&  (event.category() & types))
                Resources::notifyEventUpdated(this, event);
        }
    }
```

#### AUTO 


```{c}
const auto* model = static_cast<const EventListModel*>(ixlist[0].model());
```

#### AUTO 


```{c}
auto* iface = writeBasicConfig<OrgKdeAkonadiKAlarmSettingsInterface>();
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : qAsConst(mItems))
    {
        if (item->isEmpty())
            continue;
        const QSize size = item->sizeHint();
        int right = x + size.width();
        if (right > rect.right()  &&  x > rect.x())
        {
            x = rect.x();
            y = y + yrow + spacing();
            right = x + size.width();
            yrow = size.height();
        }
        else
            yrow = qMax(yrow, size.height());
        items.append(item);
        posn.append(QRect(QPoint(x, y), size));
        x = right + spacing();
    }
```

#### AUTO 


```{c}
auto* we = (QWheelEvent*)e;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : std::as_const(it.value()))
                        resource.addEvent(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : indexes)
    {
        if (ix.isValid())
        {
            const Item::Id id = ix.data(ItemIdRole).toLongLong();
            if (id >= 0)
            {
                if (colId < 0
                ||  ix.data(ParentCollectionRole).value<Collection>().id() == colId)
                    return id;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProcData* pd : std::as_const(mCommandProcesses))
    {
        if (pd->process == proc)
        {
            pd->messageBoxParent = parent;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& resourceGroup : std::as_const(resourceGroups))
        {
            const int groupIndex = resourceGroup.midRef(9).toInt();
            FileResourceSettings::Ptr settings(new FileResourceSettings(manager->mConfig, resourceGroup));
            if (!settings->isValid())
            {
                qCWarning(KALARM_LOG) << "FileResourceConfigManager: Invalid config for" << resourceGroup;
                manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
            }
            else
            {
                // Check for and remove duplicate URL or 'standard' setting
                for (auto it = manager->mResources.constBegin();  it != manager->mResources.constEnd();  ++it)
                {
                    const ResourceData& data = it.value();
                    if (settings->url() == data.resource.location())
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate URL in config for" << resourceGroup;
                        manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Deleted duplicate resource" << settings->displayName();
                        settings.clear();
                        break;
                    }
                    const CalEvent::Types std = settings->standardTypes() & data.settings->standardTypes();
                    if (std)
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate 'standard' setting in config for" << resourceGroup;
                        settings->setStandard(settings->standardTypes() ^ std);
                    }
                }
                if (settings)
                {
                    Resource resource(createResource(settings));
                    manager->mResources[settings->id()] = ResourceData(resource, settings);
                    manager->mConfigGroups[groupIndex] = settings->id();

                    Resources::notifyNewResourceInitialised(resource);

                    // Update the calendar to the current KAlarm format if necessary, and
                    // if the user agrees.
                    FileResourceCalendarUpdater::updateToCurrentFormat(resource, false, parent);
                }
            }
        }
```

#### AUTO 


```{c}
auto model = new TemplateListModel(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
    {
        const QModelIndex nameIndex     = index.model()->index(index.row(), 0);
        const QModelIndex birthdayIndex = index.model()->index(index.row(), 1);
        const QString name = nameIndex.data(Qt::DisplayRole).toString();
        QDate date = birthdayIndex.data(BirthdayModel::DateRole).toDate();
        date.setDate(thisYear, date.month(), date.day());
        if (date <= today)
            date.setDate(thisYear + 1, date.month(), date.day());
        KAEvent event(KADateTime(date, KADateTime::LocalZone),
                      (mName ? mName->text() : QString()),
                      mPrefix->text() + name + mSuffix->text(),
                      mFontColourButton->bgColour(), mFontColourButton->fgColour(),
                      mFontColourButton->font(), KAEvent::MESSAGE, mLateCancel->minutes(),
                      mFlags, true);
        float fadeVolume;
        int   fadeSecs;
        const float volume = mSoundPicker->volume(fadeVolume, fadeSecs);
        const int   repeatPause = mSoundPicker->repeatPause();
        event.setAudioFile(mSoundPicker->file().toDisplayString(), volume, fadeVolume, fadeSecs, repeatPause);
        const QVector<int> months(1, date.month());
        event.setRecurAnnualByDate(1, months, 0, KARecurrence::defaultFeb29Type(), -1, QDate());
        event.setRepetition(mSubRepetition->repetition());
        event.setNextOccurrence(todayStart);
        if (reminder)
            event.setReminder(reminder, false);
        if (mSpecialActionsButton)
            event.setActions(mSpecialActionsButton->preAction(),
                             mSpecialActionsButton->postAction(),
                             mSpecialActionsButton->options());
        event.endChanges();
        list.append(event);
    }
```

#### AUTO 


```{c}
auto job1 = mJobs.head();
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(group);
```

#### AUTO 


```{c}
auto* recorder = new Akonadi::ChangeRecorder;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        if (agent.type().mimeTypes().indexOf(matchMimeType) >= 0)
        {
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
            job->fetchScope().setResource(agent.identifier());
            connect(job, &CollectionFetchJob::result, instance(), &CollectionControlModel::collectionFetchResult);
        }
    }
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(mainPage);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(actionBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
                rit.value().remove(event.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& alarm : alarms)
                        std::cout << alarm.toUtf8().constData() << std::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
    {
        const QModelIndex nameIndex     = index.model()->index(index.row(), 0);
        const QModelIndex birthdayIndex = index.model()->index(index.row(), 1);
        const QString name = nameIndex.data(Qt::DisplayRole).toString();
        QDate date = birthdayIndex.data(BirthdayModel::DateRole).toDate();
        date.setDate(thisYear, date.month(), date.day());
        if (date <= today)
            date.setDate(thisYear + 1, date.month(), date.day());
        KAEvent event(KADateTime(date, KADateTime::LocalZone),
                      mPrefix->text() + name + mSuffix->text(),
                      mFontColourButton->bgColour(), mFontColourButton->fgColour(),
                      mFontColourButton->font(), KAEvent::MESSAGE, mLateCancel->minutes(),
                      mFlags, true);
        float fadeVolume;
        int   fadeSecs;
        const float volume = mSoundPicker->volume(fadeVolume, fadeSecs);
        const int   repeatPause = mSoundPicker->repeatPause();
        event.setAudioFile(mSoundPicker->file().toDisplayString(), volume, fadeVolume, fadeSecs, repeatPause);
        const QVector<int> months(1, date.month());
        event.setRecurAnnualByDate(1, months, 0, KARecurrence::defaultFeb29Type(), -1, QDate());
        event.setRepetition(mSubRepetition->repetition());
        event.setNextOccurrence(todayStart);
        if (reminder)
            event.setReminder(reminder, false);
        if (mSpecialActionsButton)
            event.setActions(mSpecialActionsButton->preAction(),
                             mSpecialActionsButton->postAction(),
                             mSpecialActionsButton->options());
        event.endChanges();
        list.append(event);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarUpdater* instance : qAsConst(mInstances))
    {
        if (instance->mResourceId == id)
            return true;
    }
```

#### AUTO 


```{c}
const auto e = item.payload<KAEvent>();
```

#### AUTO 


```{c}
auto* event = new KAEvent(evnt);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource res : resources)
            if (!res.save(&msg))
            {
                res.reload(true);    // retrieve the templates which couldn't be deleted
                status.status.message = msg;
                status.setError(SAVE_FAILED, status.failedCount(), msg);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds) {
                const QTimeZone z(zoneId);
                qdt.setTimeZone(z);
                if (z.abbreviation(qdt) == zoneAbbrev) {
                    // TODO: This may not find abbreviations for second occurrence of
                    // the time zone time, after a daylight savings time shift.
                    int offset2;
                    int offset = offsetAtZoneTime(z, qdt, &offset2);
                    if (offset == InvalidOffset) {
                        return {};
                    }
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid()) {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous || offset != utcOffset) {
                            return {};
                        }
                        useUtcOffset = true;
                    } else {
                        zone = z;
                        utcOffset = offset;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& g1, const QString& g2)
                  {
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
                      return g1.midRef(9).toInt() < g2.midRef(9).toInt();
#else
                      return QStringView(g1).mid(9).toInt() < QStringView(g2).mid(9).toInt();
#endif
                  }
```

#### AUTO 


```{c}
auto model = qobject_cast<QStandardItemModel*>(mTypeCombo->model());
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(recurGroup);
```

#### AUTO 


```{c}
auto newit = newEvents.constBegin();
```

#### AUTO 


```{c}
auto getJob = KIO::storedGet(url.url());
```

#### AUTO 


```{c}
auto action = static_cast<QueuedAction>(int((command == CommandOptions::TRIGGER_EVENT) ? QueuedAction::Trigger : QueuedAction::Cancel)
                                                                | int(QueuedAction::Exit));
```

#### AUTO 


```{c}
const auto& metaData
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { validate(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ActionQEntry& entry : std::as_const(mActionQueue))
    {
        if (entry.action == QueuedAction::Handle  &&  entry.eventId == id)
            return;  // the alarm is already queued
    }
```

#### AUTO 


```{c}
const auto* attr = collection.attribute<CollectionAttribute>();
```

#### AUTO 


```{c}
auto from = new KMime::Headers::From;
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
    {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty())
            continue;    // KAlarm isn't interested in events without alarms
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly)
            event->setReadOnly(false);
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay())
        {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9)
        {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms)
            {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit())
                {
                    while (++i < length && txt[i].isDigit()) {}
                    if (i < length  &&  txt[i++] == SEPARATOR)
                    {
                        while (i < length)
                        {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR)
                                break;
                            if (ch == LATE_CANCEL_CODE)
                                lateCancel = true;
                            else if (ch == AT_LOGIN_CODE)
                                atLogin = true;
                            else if (ch == DEFERRAL_CODE)
                                deferral = true;
                        }
                    }
                    else
                        i = 0;    // invalid prefix
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i)
                    i += TEXT_PREFIX.length();
                else if (txt.indexOf(FILE_PREFIX, i) == i)
                {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                }
                else if (txt.indexOf(COMMAND_PREFIX, i) == i)
                {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                }
                else
                    i = 0;
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action)
                {
                    case KAAlarm::FILE:
                        types += KAEventPrivate::FILE_TYPE;
                        Q_FALLTHROUGH(); // fall through to MESSAGE
                    case KAAlarm::MESSAGE:
                        alarm->setDisplayAlarm(altxt);
                        break;
                    case KAAlarm::COMMAND:
                        setProcedureAlarm(alarm, altxt);
                        break;
                    case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                    case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                        break;
                }
                if (atLogin)
                {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                }
                else if (deferral)
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                if (lateCancel)
                    addLateCancel = true;
                if (types.count() > 0)
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0)
                {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence* recur = event->recurrence();
                    if (recur  &&  recur->recurs())
                    {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime)
                {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm* dtm = localtime(&t);
                    if (dtm->tm_isdst)
                    {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2)
        {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED)
                event->setCreated(event->dtEnd());
            QDateTime start = event->dtStart();
            if (event->allDay())
            {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms)
                alarm->setStartOffset(start.secsTo(alarm->time()));

            if (!cats.isEmpty())
            {
                for (const Alarm::Ptr& alarm : alarms)
                {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display)
                    {
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                    }
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0)
                {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd())
                    {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1)
        {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0)
            {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1)
        {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms)
            {
                if (alarm->type() == Alarm::Display)
                {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext)
                        alarm->setDisplayAlarm(newtext);
                }
            }
        }

        if (pre_1_3_0)
        {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0)
            {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1)
        {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0)
            {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0)
        {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();)
            {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY)
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                else if (cat == CONFIRM_ACK_CATEGORY)
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                else if (cat == EMAIL_BCC_CATEGORY)
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                else if (cat == KORGANIZER_CATEGORY)
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                else if (cat.startsWith(DEFER_CATEGORY))
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY))
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                else if (cat.startsWith(LATE_CANCEL_CATEGORY))
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                else if (cat.startsWith(AUTO_CLOSE_CATEGORY))
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                else if (cat.startsWith(KMAIL_SERNUM_CATEGORY))
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                else if (cat == ARCHIVE_CATEGORY)
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                else if (cat.startsWith(ARCHIVE_CATEGORIES))
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                else if (cat.startsWith(LOG_CATEGORY))
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                else
                {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2)
        {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel)
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        if (!flags.isEmpty())
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs())
        {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
            const QStringList flagsProp = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
            const bool dateOnly = flagsProp.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly)
                startDateTime.setDateOnly(true);
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms)
            {
                if (!alarm->hasStartOffset())
                    continue;
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString& type : types)
                {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE)
                    {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm)
                {
                    if (mainExpired)
                    {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime)
                        {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     QLocale::c().toString(dt, dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired)
            {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            }
            else
                adjustment = startDateTime.secsTo(nextMainDateTime);
            if (adjustment)
            {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms)
                {
                    if (!alarm->hasStartOffset())
                        continue;
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString& type : types)
                    {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE)
                        {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0))
        {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr& alarm : alarms)
            {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty())
                    continue;
                const uint id = Identities::identityUoid(name);
                if (id)
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10)
        {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event))
                converted = true;
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0))
        {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event))
                converted = true;
        }

        if (pre_2_7_0)
        {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList preFlags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty())
            {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
                preFlags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                preFlags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0"))
                { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                    for (const QString& pr : list)
                    {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE)
                            preFlags << KAEventPrivate::AT_LOGIN_TYPE;
                        else if (pr == ARCHIVE_REMINDER_ONCE_TYPE)
                            reminderOnce = true;
                        else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-')))
                            reminder = pr;
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, preFlags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms)
            {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList alflags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty())
                {
                    alflags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty())
                {
                    alflags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty())
                {
                    alflags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty())
                {
                    alflags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!alflags.isEmpty())
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, alflags.join(KAEventPrivate::SC));

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset())
                    continue;
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0)
                {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE))
                {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0)
                    {
                        alarm->setStartOffset(0);
                        converted = true;
                    }
                    else if (offset < 0)
                        reminder = reminderToString(offset / 60);
                }
            }
            if (!reminder.isEmpty())
            {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid)
                    preFlags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                if (!preFlags.contains(KAEventPrivate::REMINDER_TYPE))
                {
                    preFlags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce)
                        preFlags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    preFlags += reminder;
                }
            }
        }

        if (readOnly)
            event->setReadOnly(true);
        event->endUpdates();     // finally issue an update notification
    }
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(mCmdPadding);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : eventsToDelete)
        mEvents.remove(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& msg : mErrorMsgs())
        {
            label = new QLabel(msg, topWidget);
            vlayout->addWidget(label, 0, Qt::AlignLeft);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
        ok = ok && addEvent(*event, resource);
```

#### AUTO 


```{c}
auto statJob = KIO::stat(url, KIO::StatJob::SourceSide, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mime : mimeTypes)
            addMimeTypeInclusionFilter(mime);
```

#### AUTO 


```{c}
auto it = mEventIds.constFind(event.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (ProcData* pd : qAsConst(mCommandProcesses))
    {
        if (pd->process == proc)
        {
            pd->messageBoxParent = parent;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent* event : events)
    {
        // Update the window lists
        // Delete the template from the calendar file
        if (!cal->deleteEvent(*event, false))   // don't save calendar after deleting
            status.setError(UPDATE_ERROR);
    }
```

#### AUTO 


```{c}
auto* view = static_cast<EventListView*>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
```

#### AUTO 


```{c}
auto* dlg = qobject_cast<EditEmailAlarmDlg*>(editDlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), QString::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : autostartDirs)
    {
        const QString file = dir + QLatin1String("/autostart/") + AUTOSTART_FILE;
        if (QFile::exists(file))
        {
            QFileInfo info(file);
            if (info.isReadable())
            {
                autostartFile = file;
                existingRO = !info.isWritable();
                if (!existingRO)
                    configDirRW = dir;
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto* he = static_cast<QHelpEvent*>(e);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& email : splitEmails)
    {
        normalizedEmail << KEmailAddress::extractEmailAddress(KEmailAddress::normalizeAddressesAndEncodeIdn(email));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
        {
            CalEvent::Types types;
            Collection c(colId);
            if (colId == collection.id())
            {
                c = collection;    // update with latest data
                types = ctypes | type;
            }
            else
            {
                model->refresh(c);    // update with latest data
                types = c.hasAttribute<CollectionAttribute>()
                      ? c.attribute<CollectionAttribute>()->standard() : CalEvent::EMPTY;
                if (!(types & type))
                    continue;
                types &= ~type;
            }
            const QModelIndex index = model->collectionIndex(c);
            model->setData(index, static_cast<int>(types), AkonadiModel::IsStandardRole);
        }
```

#### AUTO 


```{c}
auto typePage = qobject_cast<DirResourceImportTypeWidget*>(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            qCDebug(KALARM_LOG) << "AkonadiDataModel::collectionFetchResult:" << c.id();
            auto it = mResources.find(c.id());
            if (it == mResources.end())
                continue;
            Resource& resource = it.value();
            setCollectionChanged(resource, c, false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr& kcalEvent : std::as_const(events))
    {
        if (kcalEvent->alarms().isEmpty())
            qCDebug(KALARM_LOG) << "SingleFileResource::readFromFile:" << displayId() << "KCalendarCore::Event has no alarms:" << kcalEvent->uid();
        else
            addLoadedEvent(kcalEvent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event::Ptr& kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        auto* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "DisplayCalendar::updateKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        mEventList += event;
        mEventMap[kcalevent->uid()] = event;
    }
```

#### AUTO 


```{c}
auto* job = static_cast<Akonadi::CollectionFetchJob*>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (Qt::DayOfWeek weekDay : std::as_const(weekDays))
            if (++day < weekDay)
            {
                lastWorkDay = (day == 1) ? weekDays.at(weekDays.size() - 1) : day - 1;
                firstWorkDay = weekDay;
                break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* w : std::as_const(mWindowList))
    {
        if (w->pos() != topLeft)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : ixs)
    {
        if (ix.isValid())
            return ix;
    }
```

#### AUTO 


```{c}
auto ref = job->property("QEventLoopLocker").value<QEventLoopLocker*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* const event : events)
            if (type & event->category())
                list += event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == KALARM_RESOURCE  ||  type == KALARM_DIR_RESOURCE)
        {
            // Fetch the resource's collection to determine its alarm types
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending << job;
            connect(job, &KJob::result, this, &CalendarMigrator::collectionFetchResult);
            // Note: Once all collections have been fetched, any missing
            //       default resources will be created.
        }
    }
```

#### AUTO 


```{c}
auto* grid = new QGridLayout(group);
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(febBox);
```

#### AUTO 


```{c}
auto* box = new QHBoxLayout();
```

#### AUTO 


```{c}
auto soundLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos &day : days) {
        if (day.pos() != 0) {
            return false;
        }
        found = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& type : types)
    {
        if (type == ALARM_ACTIVE)
            alarmTypes |= CalEvent::ACTIVE;
        else if (type == ALARM_ARCHIVED)
            alarmTypes |= CalEvent::ARCHIVED;
        else if (type == ALARM_TEMPLATE)
            alarmTypes |= CalEvent::TEMPLATE;
    }
```

#### AUTO 


```{c}
auto* job = qobject_cast<ItemFetchJob*>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
                {
                    if (!alarm->hasStartOffset())
                        continue;
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString& type : types)
                    {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE)
                        {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
```

#### AUTO 


```{c}
auto* descendantsModel = new KDescendantsProxyModel(this);
```

#### AUTO 


```{c}
auto encodings = KMime::encodingsForData(content->body());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : std::as_const(eventsToDelete))
        mEvents.remove(id);
```

#### AUTO 


```{c}
auto* job = new Akonadi::ItemFetchJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : activeEvents)
    {
        if (event.actionSubType() == KAEvent::MESSAGE
        &&  event.recurType() == KARecurrence::ANNUAL_DATE
        &&  (mPrefixText.isEmpty()  ||  event.message().startsWith(mPrefixText)))
            alarmMessageList.append(event.message());
    }
```

#### AUTO 


```{c}
auto win = new MessageWindow;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().indexOf(matchMimeType) >= 0)
            {
                ResourceCol thisRes(job->fetchScope().resource(), c.id());
                auto it = mAgentPaths.constFind(c.remoteId());
                if (it != mAgentPaths.constEnd())
                {
                    // Remove the resource containing the higher numbered Collection
                    // ID, which is likely to be the more recently created.
                    const ResourceCol prevRes = it.value();
                    if (thisRes.collectionId > prevRes.collectionId)
                    {
                        qCWarning(KALARM_LOG) << "CollectionControlModel::collectionFetchResult: Removing duplicate resource" << thisRes.resourceId;
                        agentManager->removeInstance(agentManager->instance(thisRes.resourceId));
                        continue;
                    }
                    qCWarning(KALARM_LOG) << "CollectionControlModel::collectionFetchResult: Removing duplicate resource" << prevRes.resourceId;
                    agentManager->removeInstance(agentManager->instance(prevRes.resourceId));
                }
                mAgentPaths[c.remoteId()] = thisRes;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& qdt : l)
        rv << qdt;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : desel)
        CollectionControlModel::setEnabled(mModel->collection(ix), mAlarmType, false);
```

#### AUTO 


```{c}
auto it = mCollectionPaths.constFind(collection.remoteId());
```

#### AUTO 


```{c}
auto uploadJob = KIO::storedPut(&qFile, url.url(), -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (MainWindow* w : std::as_const(mWindowList))
    {
        w->mActionImportAlarms->setEnabled(active || templat);
        if (w->mActionImportBirthdays)
            w->mActionImportBirthdays->setEnabled(active);
        w->mActionCreateTemplate->setEnabled(templat);
        // Note: w->mActionNew enabled status is set in the NewAlarmAction class.
        w->slotSelection();
    }
```

#### AUTO 


```{c}
auto browseButton = new QPushButton(box);
```

#### AUTO 


```{c}
auto it = manager->mResources.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& resourceGroup : resourceGroups)
        {
            int groupIndex = resourceGroup.mid(9).toInt();
            FileResourceSettings::Ptr settings(new FileResourceSettings(manager->mConfig, resourceGroup));
            if (!settings->isValid())
            {
                qCWarning(KALARM_LOG) << "FileResourceConfigManager: Invalid config for" << resourceGroup;
                manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
            }
            else
            {
                // Check for and remove duplicate URL or 'standard' setting
                for (auto it = manager->mResources.constBegin();  it != manager->mResources.constEnd();  ++it)
                {
                    const ResourceData& data = it.value();
                    if (settings->url() == data.resource.location())
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate URL in config for" << resourceGroup;
                        manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Deleted duplicate resource" << settings->displayName();
                        settings.clear();
                        break;
                    }
                    const CalEvent::Types std = settings->standardTypes() & data.settings->standardTypes();
                    if (std)
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate 'standard' setting in config for" << resourceGroup;
                        settings->setStandard(settings->standardTypes() ^ std);
                    }
                }
                if (settings)
                {
                    Resource resource(createResource(settings));
                    manager->mResources[settings->id()] = ResourceData(resource, settings);
                    manager->mConfigGroups[groupIndex] = settings->id();

                    Resources::notifyNewResourceInitialised(resource);

                    // Update the calendar to the current KAlarm format if necessary, and
                    // if the user agrees.
                    FileResourceCalendarUpdater::updateToCurrentFormat(resource, false, parent);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        if ((collectionId == -1  ||  collectionId == colId)
        &&  !model->data(model->collectionIndex(colId), AkonadiModel::IsPopulatedRole).toBool())
        {
            Collection c(colId);
            model->refresh(c);    // update with latest data
            if (!c.hasAttribute<CollectionAttribute>()
            ||  c.attribute<CollectionAttribute>()->enabled() != CalEvent::EMPTY)
                return false;
        }
    }
```

#### AUTO 


```{c}
const auto &tzid
```

#### AUTO 


```{c}
auto statJob =  KIO::stat(url, KIO::StatJob::SourceSide, 0, KIO::HideProgressInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AkonadiModel::Event& event : events)
    {
        if (!event.isConsistent())
            qCCritical(KALARM_LOG) << "AlarmCalendar::slotEventsToBeRemoved: Inconsistent AkonadiModel::Event: event:" << event.event.collectionId() << ", collection" << event.collection.id();
        else if (mEventMap.contains(event.eventId()))
        {
            Resource resource = AkonadiModel::instance()->resource(event.collection.id());
            deleteEventInternal(event.event, resource, false);
        }
    }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto* job = static_cast<AgentInstanceCreateJob*>(j);
```

#### AUTO 


```{c}
const auto model = static_cast<const EventListModel*>(list[0].model());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            const KConfigGroup configGroup = config.group(QLatin1String("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            QString agentType;
            if (resourceType == QLatin1String("file"))
                agentType = AkonadiResource::KALARM_RESOURCE;
            else if (resourceType == QLatin1String("dir"))
                agentType = AkonadiResource::KALARM_DIR_RESOURCE;
            else if (resourceType == QLatin1String("remote"))
                agentType = AkonadiResource::KALARM_RESOURCE;
            else
                continue;   // unknown resource type - can't convert

            creator = new CalendarCreator(resourceType, configGroup);
            if (!creator->isValid())
                delete creator;
            else
            {
                connect(creator, &CalendarCreator::finished, this, &AkonadiResourceMigrator::calendarCreated);
                connect(creator, &CalendarCreator::creating, this, &AkonadiResourceMigrator::creatingCalendar);
                mExistingAlarmTypes |= creator->alarmType();
                mCalendarsPending << creator;
                creator->createAgent(agentType, this);
            }
        }
```

#### AUTO 


```{c}
auto* boxLayout = new QGridLayout();
```

#### AUTO 


```{c}
auto mimeTypeFilter = new Akonadi::EntityMimeTypeFilterModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
    {
        if (index.isValid())
        {
            // Wait to ensure that the base EntityTreeModel has processed the
            // itemChanged() signal first, before we Q_EMIT eventChanged().
            Collection c = data(index, ParentCollectionRole).value<Collection>();
            evnt.setCollectionId(c.id());
            mPendingEventChanges.enqueue(Event(evnt, c));
            QTimer::singleShot(0, this, &AkonadiModel::slotEmitEventChanged);
            break;
        }
    }
```

#### AUTO 


```{c}
auto* boxLayout = new QHBoxLayout(box);
```

#### AUTO 


```{c}
auto* job = new ItemModifyJob(newItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : eventsToDelete)
                {
                    Resource res = Resources::resource(event.resourceId());
                    if (!cal->deleteEvent(event, res, false))
                        status.setError(UPDATE_ERROR);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& g1, const QString& g2)
                  {
                      return g1.midRef(9).toInt() < g2.midRef(9).toInt();
                  }
```

#### AUTO 


```{c}
const auto &kdt
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sw : mWidgets)
    {
        QWidget* w = static_cast<StackedScrollWidget*>(sw)->widget();
        if (!w)
            return {};
        const QSize s = w->minimumSizeHint();
        if (!s.isValid())
            return {};
        sz = sz.expandedTo(s);
    }
```

#### AUTO 


```{c}
auto rrule2 = new RecurrenceRule();
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(recurGroup);
```

#### AUTO 


```{c}
auto* job = new CollectionModifyJob(c, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& att : attParams)
            mAttachments += att;
```

#### AUTO 


```{c}
auto text = new MessageText(topWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : qAsConst(eventsToDelete))
        mEvents.remove(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& att : attachments)
        {
            const QString attachment = QString::fromLatin1(att.toLocal8Bit());
            const QUrl url = QUrl::fromUserInput(attachment, QString(), QUrl::AssumeLocalFile);
            const QString attachError = xi18nc("@info", "Error attaching file: <filename>%1</filename>", attachment);
            QByteArray contents;
            bool atterror = false;
            if (!url.isLocalFile())
            {
                auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatDetail::StatDefaultDetails);
                KJobWidgets::setWindow(statJob, MainWindow::mainMainWindow());
                if (!statJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not found:" << attachment;
                    return xi18nc("@info", "Attachment not found: <filename>%1</filename>", attachment);
                }
                KFileItem fi(statJob->statResult(), url);
                if (fi.isDir()  ||  !fi.isReadable())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Not file/not readable:" << attachment;
                    return attachError;
                }

                // Read the file contents
                auto downloadJob = KIO::storedGet(url);
                KJobWidgets::setWindow(downloadJob, MainWindow::mainMainWindow());
                if (!downloadJob->exec())
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = downloadJob->data();
                if (static_cast<unsigned>(contents.size()) < fi.size())
                {
                    qCDebug(KALARM_LOG) << "KAMail::appendBodyAttachments: Read error:" << attachment;
                    atterror = true;
                }
            }
            else
            {
                QFile f(url.toLocalFile());
                if (!f.open(QIODevice::ReadOnly))
                {
                    qCCritical(KALARM_LOG) << "KAMail::appendBodyAttachments: Load failure:" << attachment;
                    return attachError;
                }
                contents = f.readAll();
            }

            QByteArray coded = KCodecs::base64Encode(contents);
            auto content = new KMime::Content();
            content->setBody(coded + "\n\n");

            // Set the content type
            QMimeDatabase mimeDb;
            QString typeName = mimeDb.mimeTypeForUrl(url).name();
            auto ctype = new KMime::Headers::ContentType;
            ctype->fromUnicodeString(typeName, autoDetectCharset(typeName));
            ctype->setName(attachment, "local");
            content->setHeader(ctype);

            // Set the encoding
            auto cte = new KMime::Headers::ContentTransferEncoding;
            cte->setEncoding(KMime::Headers::CEbase64);
            cte->setDecoded(false);
            content->setHeader(cte);
            content->assemble();
            message.addContent(content);
            if (atterror)
                return attachError;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[]() { qCDebug(KALARM_LOG) << "MessageDisplayHelper: Audio thread deleted"; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds)
            {
                const QTimeZone z(zoneId);
                if (z.offsetFromUtc(dtUTC) == utcOffset)
                {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset)
                    {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous)
                            return {};
                        if (dateOnly)
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = z;
                }
            }
```

#### AUTO 


```{c}
auto rit = mDateFilterCache.find(resource.id());
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<PluginBase>(metaData, this).plugin;
```

#### AUTO 


```{c}
auto output = new Phonon::AudioOutput(Phonon::MusicCategory, mPlayer);
```

#### AUTO 


```{c}
auto ev = new KAEvent(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            const KConfigGroup configGroup = config.group(QLatin1String("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            QString agentType;
            if (resourceType == QLatin1String("file"))
                agentType = KALARM_RESOURCE;
            else if (resourceType == QLatin1String("dir"))
                agentType = KALARM_DIR_RESOURCE;
            else if (resourceType == QLatin1String("remote"))
                agentType = KALARM_RESOURCE;
            else
                continue;   // unknown resource type - can't convert

            creator = new CalendarCreator(resourceType, configGroup);
            if (!creator->isValid())
                delete creator;
            else
            {
                connect(creator, &CalendarCreator::finished, this, &AkonadiResourceMigrator::calendarCreated);
                connect(creator, &CalendarCreator::creating, this, &AkonadiResourceMigrator::creatingCalendar);
                mExistingAlarmTypes |= creator->alarmType();
                mCalendarsPending << creator;
                creator->createAgent(agentType, this);
            }
        }
```

#### AUTO 


```{c}
auto updater = new FileResourceCalendarUpdater(resource, true, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* act : qAsConst(actions))
        {
            if (act->data().toInt() == AlarmListModel::TimeToColumn)
            {
                act->setEnabled(false);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        auto it = mEvents.find(event.id());
        if (it == mEvents.end())
        {
            mEvents[event.id()] = event;
            if (event.category() & types)
                mEventsAdded += event;
        }
        else
        {
            KAEvent& ev = it.value();
            bool changed = !ev.compare(event, KAEvent::Compare::Id | KAEvent::Compare::CurrentState);
            ev = event;   // update existing event
            if (changed  &&  (event.category() & types))
            {
                if (notify)
                    Resources::notifyEventUpdated(this, event);
                else
                    mEventsUpdated += event;
            }
        }
    }
```

#### AUTO 


```{c}
auto tabgroup = new StackedGroupT<QWidget>(mTabs);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        const Collection c(colId);
        if (c.resource() == resourceId)
            return c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : names)
    {
        if (shortName  &&  name.size() == 1)
            return QStringLiteral("-") + name;
        else if (!shortName  &&  name.size() > 1)
            return QStringLiteral("--") + name;
    }
```

#### AUTO 


```{c}
auto* tfLayout = new QVBoxLayout(topFontColour);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : sel)
    {
        // Try to enable the resource, but untick it if not possible
        Resource resource = mModel->resource(ix);
        resource.setEnabled(mAlarmType, true);
        if (!resource.isEnabled(mAlarmType))
            mSelectionModel->select(ix, QItemSelectionModel::Deselect);
    }
```

#### AUTO 


```{c}
auto akstate = Akonadi::ServerManager::state();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr& alarm : alarms)
    {
        // Parse the next alarm's text
        AlarmData data;
        readAlarm(alarm, data, audioOnly, cmdDisplay);
        if (data.type != INVALID_ALARM)
            alarmMap->insert(data.type, data);
    }
```

#### AUTO 


```{c}
auto bgroup = new QButtonGroup(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls)
    {
        if (!url.isValid())
        {
            qCDebug(KALARM_LOG) << "KAlarm::importAlarms: Invalid URL";
            continue;
        }
        qCDebug(KALARM_LOG) << "KAlarm::importAlarms:" << url.toDisplayString();
        importCalendarFile(url, alarmTypes, true, parent, events);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
        {
            if (!event->enabled()  &&  (event->actionTypes() & KAEvent::ACT_DISPLAY))
            {
                MessageWin* win = MessageWin::findEvent(EventId(*event));
                delete win;
            }
        }
```

#### AUTO 


```{c}
const auto model = static_cast<const EventListModel*>(ixlist[0].model());
```

#### LAMBDA EXPRESSION 


```{c}
[this, deferButton](QAbstractButton *btn)
            {
                if (btn == deferButton)
                    slotCancelDeferral();
            }
```

#### AUTO 


```{c}
auto tz = QTimeZone(kdt.timeZone().name().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& cmdErr : cmdErrs)
        {
            int i = cmdErr.indexOf(CMD_ERROR_SEPARATOR);
            if (i > 0  &&  i < cmdErr.size() - 1)
            {
                KAEvent::CmdErrType type;
                const QString typeStr = cmdErr.mid(i + 1);
                if (typeStr == CMD_ERROR_VALUE)
                    type = KAEvent::CMD_ERROR;
                else if (typeStr == CMD_ERROR_PRE_VALUE)
                    type = KAEvent::CMD_ERROR_PRE;
                else if (typeStr == CMD_ERROR_POST_VALUE)
                    type = KAEvent::CMD_ERROR_POST;
                else if (typeStr == CMD_ERROR_PRE_POST_VALUE)
                    type = KAEvent::CMD_ERROR_PRE_POST;
                else
                    continue;
                mCommandErrors[cmdErr.left(i)] = type;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos& day : days)
    {
        if (day.pos() != 0)
            return false;
        found = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                if (!mUid.isEmpty())
                {
                    if (item.mimeType() == mMimeType  &&  item.hasPayload<Event::Ptr>())
                    {
                        const Event::Ptr kcalEvent = item.payload<Event::Ptr>();
                        if (kcalEvent->uid() != mUid)
                            continue;
                    }
                }
                else if (mGid.isEmpty())
                    continue;
                auto djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs.value(job);
                connect(djob, &ItemDeleteJob::result, this, &AkonadiCollectionSearch::itemDeleteResult);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* win : qAsConst(mRestoredWindows))
                win->display();
```

#### AUTO 


```{c}
auto content = new KMime::Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (const MessageDisplayHelper* h : std::as_const(mInstanceList))
        {
            if (h->mAlwaysHide)
                --count;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                ItemDeleteJob* djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs[job];
                connect(djob, &ItemDeleteJob::result, this, &CollectionSearch::itemDeleteResult);
            }
```

#### AUTO 


```{c}
const auto lstActions = actions->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
            if (type & event.category())
                list += event;
```

#### AUTO 


```{c}
auto it = mResources.find(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule *rule : rulelist) {
        if (rule->recursOn(dt, Private::toTimeZone(timeSpec))) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
        {
            if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
                continue;    // ignore events without alarms, or usable alarms
            CalEvent::Type type = CalEvent::status(event);
            if (type == CalEvent::TEMPLATE)
            {
                // If we know the event was not created by KAlarm, don't treat it as a template
                if (caltype == KACalendar::Incompatible)
                    type = CalEvent::ACTIVE;
            }
            Resource res;
            if (resource.isValid())
            {
                if (!(type & wantedTypes))
                    continue;
                res = resource;
            }
            else
            {
                switch (type)
                {
                    case CalEvent::ACTIVE:
                    case CalEvent::ARCHIVED:
                    case CalEvent::TEMPLATE:
                        break;
                    default:
                        continue;
                }
                res = CollectionControlModel::destination(type);
            }

            Event::Ptr newev(new Event(*event));

            // If there is a display alarm without display text, use the event
            // summary text instead.
            if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
            {
                const Alarm::List& alarms = newev->alarms();
                for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
                newev->setSummary(QString());   // KAlarm only uses summary for template names
            }

            // Give the event a new ID and add it to the calendars
            newev->setUid(CalEvent::uid(CalFormat::createUniqueId(), type));
            KAEvent* newEvent = new KAEvent(newev);
            if (!AkonadiModel::instance()->addEvent(*newEvent, res))
                success = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : eventlist)
    {
        if (event.templateName() == templateName)
            return event;
    }
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto& sw
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& templ : templates)
    {
        const QString name = templ.templateName();
        int j = 0;
        for (int jend = sorted.count();
             j < jend  &&  QString::localeAwareCompare(name, sorted[j]) > 0;
             ++j) ;
        sorted.insert(j, name);
    }
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos& day : days)
            {
                if (day.pos() == 0)
                    ds[day.day() - 1] = true;
            }
```

#### AUTO 


```{c}
auto* recurScroll = new StackedScrollWidget(mTabScrollGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* win : qAsConst(mWindowList))
        {
            if (win->mAlwaysHidden())
                --count;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        if (collectionId == -1  ||  collectionId == colId)
        {
            const QModelIndex ix = model->resourceIndex(colId);
            if (!model->data(ix, AkonadiModel::IsPopulatedRole).toBool())
            {
                const Resource res = model->resource(ix);
                if (res.enabledTypes() != CalEvent::EMPTY)
                    return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProcData* pd : qAsConst(mCommandProcesses))
    {
        if (pd->event->id() == eventId)
            return pd;
    }
```

#### AUTO 


```{c}
const auto action = static_cast<QueuedAction>(int(entry.action) & int(QueuedAction::ActionMask));
```

#### AUTO 


```{c}
auto eventR = right.payload<KAEvent>();
```

#### AUTO 


```{c}
auto job = mJobs.head();
```

#### RANGE FOR STATEMENT 


```{c}
for (const int id : ids)
    {
        const QString actText = Undo::actionText(type, id);
        const QString descrip = Undo::description(type, id);
        const QString text = descrip.isEmpty()
                           ? i18nc("@action Undo/Redo [action]", "%1 %2", action, actText)
                           : i18nc("@action Undo [action]: message", "%1 %2: %3", action, actText, descrip);
        QAction* act = menu->addAction(text);
        mUndoMenuIds[act] = id;
    }
```

#### AUTO 


```{c}
auto putJob = KIO::storedPut(&file, mICalUrl, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* undo : *undos)
            {
                const QString evid = undo->eventID();
                if (ignoreIDs.contains(evid))
                    omit = true;
                else if (omit)
                    ignoreIDs.append(evid);
                else
                    newIDs.append(evid);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(mEventsUpdated))
        Resources::notifyEventUpdated(this, event);
```

#### AUTO 


```{c}
const auto eit = resourceHash.constFind(ev.id());
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& newID : std::as_const(newIDs))
                    ignoreIDs.append(newID);
```

#### AUTO 


```{c}
auto* itemModel = qobject_cast<EventListModel*>(model);
```

#### AUTO 


```{c}
auto* box = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto* content = new KMime::Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOUR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (Alarm::Ptr alarm : alarms) {
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QLatin1String("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QLatin1String("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (Alarm::Ptr alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
                    const QStringList list = prop.split(KAEventPrivate::SC, QString::SkipEmptyParts);
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), QString::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMime::Types::Mailbox& mailbox : mailboxes)
    {
        const KCalendarCore::Person person(mailbox.name(), mailbox.addrSpec().asString());
        list += person;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& sw : mWidgets)
            {
                sw->setMinimumHeight(mMinHeight);
                sw->resize(QSize(sw->width(), mMinHeight));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event::Ptr& kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        KAEvent* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "DisplayCalendar::updateKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        mEventList += event;
        mEventMap[kcalevent->uid()] = event;
    }
```

#### AUTO 


```{c}
auto* topWindows = new QVBoxLayout(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList)
            {
                if (tz.offsetFromUtc(dtUTC) == utcOffset)
                {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset)
                    {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous)
                            return {};
                        if (dateOnly)
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = tz;
                }
            }
```

#### AUTO 


```{c}
auto topFontColour = new StackedWidgetT<QWidget>(tabgroup);
```

#### AUTO 


```{c}
auto *evAttr = dynamic_cast<EventAttribute *>(a);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KAEvent& e) { notifyQueued(e); }
```

#### RANGE FOR STATEMENT 


```{c}
for (ProcData* pd : std::as_const(mCommandProcesses))
    {
        if (pd->event->id() == eventId)
            return pd;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent* event : events)
    {
        Resource resource = Resources::resource(event->resourceId());
        if (resource.isValid())
            deleteEventInternal(event->id(), *event, resource, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
        slotEventUpdated(resource, event);
```

#### AUTO 


```{c}
auto* grid = new QGridLayout(templateTimeBox);
```

#### AUTO 


```{c}
auto topTypes = new StackedWidgetT<QWidget>(tabgroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            // Read the resource configuration parameters from the config
            const KConfigGroup configGroup = config.group(QLatin1String("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            const char* pathKey = nullptr;
            FileResourceSettings::StorageType storageType;
            if (resourceType == QLatin1String("file"))
            {
                storageType = FileResourceSettings::File;
                pathKey = "CalendarURL";
            }
            else if (resourceType == QLatin1String("dir"))
            {
                storageType = FileResourceSettings::Directory;
                pathKey = "CalendarURL";
            }
            else if (resourceType == QLatin1String("remote"))
            {
                storageType = FileResourceSettings::File;
                pathKey = "DownloadUrl";
            }
            else
            {
                qCWarning(KALARM_LOG) << "CalendarCreator: Invalid resource type:" << resourceType;
                continue;   // unknown resource type - can't convert
            }

            const QUrl url = QUrl::fromUserInput(configGroup.readPathEntry(pathKey, QString()));
            CalEvent::Type alarmType = CalEvent::EMPTY;
            switch (configGroup.readEntry("AlarmType", (int)0))
            {
                case 1:  alarmType = CalEvent::ACTIVE;    break;
                case 2:  alarmType = CalEvent::ARCHIVED;  break;
                case 4:  alarmType = CalEvent::TEMPLATE;  break;
                default:
                    qCWarning(KALARM_LOG) << "FileResourceMigrator::migrateKResources: Invalid alarm type for resource";
                    continue;
            }
            const QString name  = configGroup.readEntry("ResourceName", QString());
            const bool enabled  = configGroup.readEntry("ResourceIsActive", false);
            const bool standard = configGroup.readEntry("Standard", false);
            qCDebug(KALARM_LOG) << "FileResourceMigrator::migrateKResources: Migrating:" << name << ", type=" << alarmType << ", path=" << url.toString();
            FileResourceSettings::Ptr settings(new FileResourceSettings(
                          storageType, url, alarmType, name,
                          configGroup.readEntry("Color", QColor()),
                          (enabled ? alarmType : CalEvent::EMPTY),
                          (standard ? alarmType : CalEvent::EMPTY),
                          configGroup.readEntry("ResourceIsReadOnly", true)));
            Resource resource = FileResourceConfigManager::addResource(settings);

            // Update the calendar to the current KAlarm format if necessary,
            // and if the user agrees.
            auto* updater = new FileResourceCalendarUpdater(resource, true, this);
            connect(updater, &QObject::destroyed, this, &FileResourceMigrator::checkIfComplete);
            updater->update();   // note that 'updater' will auto-delete when finished

            mExistingAlarmTypes |= alarmType;
        }
```

#### AUTO 


```{c}
auto* glayout = new QVBoxLayout(mRepeatGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate& exceptionDate : qAsConst(mExceptionDates))
        new QListWidgetItem(QLocale().toString(exceptionDate, QLocale::LongFormat), mExceptionDateList);
```

#### AUTO 


```{c}
auto descendantsModel = new KDescendantsProxyModel(this);
```

#### AUTO 


```{c}
auto* updater = new AkonadiCalendarUpdater(collection, dirResource, ignoreKeepFormat, false, parent, qobject_cast<QWidget*>(parent));
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
        {
            if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
                continue;    // ignore events without alarms, or usable alarms
            CalEvent::Type type = CalEvent::status(event);
            if (type == CalEvent::TEMPLATE)
            {
                // If we know the event was not created by KAlarm, don't treat it as a template
                if (caltype == KACalendar::Incompatible)
                    type = CalEvent::ACTIVE;
            }
            Resource res;
            if (resource.isValid())
            {
                if (!(type & wantedTypes))
                    continue;
                res = resource;
            }
            else
            {
                switch (type)
                {
                    case CalEvent::ACTIVE:
                    case CalEvent::ARCHIVED:
                    case CalEvent::TEMPLATE:
                        break;
                    default:
                        continue;
                }
                res = CollectionControlModel::destination(type);
            }

            Event::Ptr newev(new Event(*event));

            // If there is a display alarm without display text, use the event
            // summary text instead.
            if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
            {
                const Alarm::List& alarms = newev->alarms();
                for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
                newev->setSummary(QString());   // KAlarm only uses summary for template names
            }

            // Give the event a new ID and add it to the calendars
            newev->setUid(CalEvent::uid(CalFormat::createUniqueId(), type));
            if (!res.addEvent(KAEvent(newev)))
                success = false;
        }
```

#### AUTO 


```{c}
auto* dlg = qobject_cast<EditDisplayAlarmDlg*>(editDlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds) {
                const QTimeZone z(zoneId);
                qdt.setTimeZone(z);
                if (z.abbreviation(qdt) == zoneAbbrev) {
                    // TODO: This may not find abbreviations for second occurrence of
                    // the time zone time, after a daylight savings time shift.
                    int offset2;
                    int offset = offsetAtZoneTime(z, qdt, &offset2);
                    if (offset == InvalidOffset)
                        return KADateTime();
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid()) {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous  ||  offset != utcOffset)
                            return KADateTime();
                        useUtcOffset = true;
                    } else {
                        zone = z;
                        utcOffset = offset;
                    }
                }
            }
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto colourLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto* sjob = new ResourceSynchronizationJob(mAgent);
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* win : mRestoredWindows)
                win->display();
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
    {
        KAEventPrivate* const p = event->d;
        if (p->mStartDateTime.isDateOnly()  &&  p->checkRecur() != KARecurrence::NO_RECUR)
            p->mRecurrence->setStartDateTime(p->mStartDateTime.effectiveKDateTime(), true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr& kcalEvent : qAsConst(events))
    {
        if (kcalEvent->alarms().isEmpty())
            qCDebug(KALARM_LOG) << "SingleFileResource::readFromFile:" << displayId() << "KCalendarCore::Event has no alarms:" << kcalEvent->uid();
        else
            addLoadedEvent(kcalEvent);
    }
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& alarm : alarms)
                            std::cout << qUtf8Printable(alarm) << std::endl;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                if (tz.offsetFromUtc(dtUTC) == utcOffset) {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset) {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous)
                            return KADateTime();
                        if (dateOnly)
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = tz;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
            {
                if (!alarm->hasStartOffset())
                    continue;
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString& type : types)
                {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE)
                    {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm)
                {
                    if (mainExpired)
                    {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime)
                        {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     QLocale::c().toString(dt, dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        if (agent.type().mimeTypes().contains(mimeType))
        {
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
            job->fetchScope().setResource(agent.identifier());
            mCollectionJobs << job;
            connect(job, &CollectionFetchJob::result, this, &CollectionSearch::collectionFetchResult);
        }
    }
```

#### AUTO 


```{c}
auto* att = c.attribute<CollectionAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
```

#### AUTO 


```{c}
auto boxHLayout = new QHBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
    {
        mEventMap.remove(EventId(key, event->id()));
        delete event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : desel)
        mModel->resource(ix).setEnabled(mAlarmType, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource& resource : resources)
        ok = ok && resource.save();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ActionQEntry& entry : qAsConst(mActionQueue))
    {
        if (entry.action == QueuedAction::Handle  &&  entry.eventId == id)
            return;  // the alarm is already queued
    }
```

#### AUTO 


```{c}
auto* grid = new QGridLayout(w);
```

#### AUTO 


```{c}
auto statJob = KIO::stat(mUrl, KIO::StatJob::SourceSide, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
        {
            if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
                continue;    // ignore events without alarms, or usable alarms
            CalEvent::Type type = CalEvent::status(event);
            if (type == CalEvent::TEMPLATE)
            {
                // If we know the event was not created by KAlarm, don't treat it as a template
                if (caltype == KACalendar::Incompatible)
                    type = CalEvent::ACTIVE;
            }
            Resource res;
            if (resource.isValid())
            {
                if (!(type & wantedTypes))
                    continue;
                res = resource;
            }
            else
            {
                switch (type)
                {
                    case CalEvent::ACTIVE:
                    case CalEvent::ARCHIVED:
                    case CalEvent::TEMPLATE:
                        break;
                    default:
                        continue;
                }
                res = Resources::destination(type);
            }

            Event::Ptr newev(new Event(*event));

            // If there is a display alarm without display text, use the event
            // summary text instead.
            if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
            {
                const Alarm::List& alarms = newev->alarms();
                for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
                newev->setSummary(QString());   // KAlarm only uses summary for template names
            }

            // Give the event a new ID and add it to the calendars
            newev->setUid(CalEvent::uid(CalFormat::createUniqueId(), type));
            if (!res.addEvent(KAEvent(newev)))
                success = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* w : qAsConst(mWindowList))
            {
                if ((!errmsgs && w->mErrorWindow())
                ||  (errmsgs && !w->mErrorWindow()))
                    continue;
                const QSize sz = w->frameGeometry().size();
                if (x + sz.width() > desk.right())
                {
                    x = desk.left();
                    y = ynext;
                }
                int ytmp = y;
                if (y + sz.height() > desk.bottom())
                {
                    ytmp = desk.bottom() - sz.height();
                    if (ytmp < desk.top())
                        ytmp = desk.top();
                }
                w->move(x, ytmp);
                x += sz.width();
                if (ytmp + sz.height() > ynext)
                    ynext = ytmp + sz.height();
            }
```

#### AUTO 


```{c}
const auto resourceHash = rit.value();
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
        // Parse the next alarm's text
        AlarmData data;
        readAlarm(alarm, data, audioOnly, cmdDisplay);
        if (data.type != INVALID_ALARM) {
            alarmMap->insert(data.type, data);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : std::as_const(mItems))
    {
        if (item->isEmpty())
            continue;
        const QSize size = item->sizeHint();
        int right = x + size.width();
        if (right > rect.right()  &&  x > rect.x())
        {
            x = rect.x();
            y = y + yrow + verticalSpacing();
            right = x + size.width();
            yrow = size.height();
        }
        else
            yrow = qMax(yrow, size.height());
        items.append(item);
        posn.append(QRect(QPoint(x, y), size));
        x = right + horizontalSpacing();
    }
```

#### AUTO 


```{c}
auto output = new Phonon::AudioOutput(Phonon::NotificationCategory, mAudioObject);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (event.category() != CalEvent::ACTIVE
        ||  mPendingAlarms.contains(event.id()))
            continue;
        const KADateTime dt = event.nextTrigger(KAEvent::ALL_TRIGGER).effectiveKDateTime();
        if (dt.isValid())
        {
            if (!earliest.isValid() || dt < earliestTime)
            {
                earliestTime = dt;
                earliest = event;
            }
            if (!(event.actionTypes() & KAEvent::ACT_DISPLAY))
            {
                if (!earliestNonDisp.isValid() || dt < earliestNonDispTime)
                {
                    earliestNonDispTime = dt;
                    earliestNonDisp = event;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto radio = new QRadioButton(args[0], group);
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos &day : days) {
            if (day.pos() == 0) {
                ds[day.day() - 1] = true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& ix : sel)
    {
        // Try to enable the collection, but untick it if not possible
        if (!CollectionControlModel::setEnabled(mModel->collection(ix), mAlarmType, true))
            mSelectionModel->select(ix, QItemSelectionModel::Deselect);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource& resource : resources)
            resource.reload();
```

#### AUTO 


```{c}
auto putJob = KIO::storedPut(&file, mICalUrl.url(), -1);
```

#### AUTO 


```{c}
auto* job = new AgentInstanceCreateJob(mAgentType, mParent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& addr : mailParams)
        {
            QString a(addr);
            if (!KAMail::checkAddress(a))
                setError(xi18nc("@info:shell", "<icode>%1</icode>: invalid email address", optionName(MAIL)));
            KCalendarCore::Person person(QString(), addr);
            mAddressees += person;
        }
```

#### AUTO 


```{c}
auto grid = new QGridLayout(mShowInSystemTrayGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* win : std::as_const(mWindowList))
        {
            if (win->mAlwaysHidden())
                --count;
        }
```

#### AUTO 


```{c}
auto it = mCommandErrors.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : autostartDirs)
    {
        const QString file = dir + QStringLiteral("/autostart/") + AUTOSTART_FILE;
        if (QFile::exists(file))
        {
            QFileInfo info(file);
            if (info.isReadable())
            {
                autostartFile = file;
                existingRO = !info.isWritable();
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos& p : pos)
        {
            const int day = p.day() - 1;  // Monday = 0
            if (mWorkDays.testBit(day))
                noWorkPos = false;    // found a working day occurrence
            allDaysMask |= 1 << day;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : mimeTypes) {
        if (type == MIME_ACTIVE) {
            types |= ACTIVE;
        } else if (type == MIME_ARCHIVED) {
            types |= ARCHIVED;
        } else if (type == MIME_TEMPLATE) {
            types |= TEMPLATE;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& sw : mWidgets)
    {
        QWidget* w = static_cast<StackedScrollWidget*>(sw)->widget();
        if (!w)
            return {};
        const QSize s = w->minimumSizeHint();
        if (!s.isValid())
            return QSize();
        sz = sz.expandedTo(s);
    }
```

#### AUTO 


```{c}
auto* topGeneral = new QVBoxLayout(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
        {
            Node* node = new Node(new KAEvent(event), resource);
            resourceEventNodes += node;
            mEventNodes[event.id()] = node;
        }
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(mCheckboxFrame);
```

#### AUTO 


```{c}
auto* win = new MessageWindow;
```

#### AUTO 


```{c}
auto* mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                if (!mUid.isEmpty())
                {
                    if (item.mimeType() == mMimeType  &&  item.hasPayload<Event::Ptr>())
                    {
                        const Event::Ptr kcalEvent = item.payload<Event::Ptr>();
                        if (kcalEvent->uid() != mUid)
                            continue;
                    }
                }
                else if (mGid.isEmpty())
                    continue;
                ItemDeleteJob* djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs[job];
                connect(djob, &ItemDeleteJob::result, this, &AkonadiCollectionSearch::itemDeleteResult);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (mEvents.constFind(event.id()) != mEvents.constEnd())
        {
            eventsToDelete += event.id();
            if (event.category() & types)
                eventsToNotify += event;
        }
    }
```

#### AUTO 


```{c}
auto* timeBoxHLayout = new QHBoxLayout(timeBox);
```

#### AUTO 


```{c}
auto job = qobject_cast<ItemFetchJob*>(j);
```

#### AUTO 


```{c}
const auto msIana = QTimeZone::windowsIdToDefaultIanaId(ktz.name().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dtime : dtlist)
        if (dtime.date() == dt) {
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& sw : mWidgets)
    {
        sw->setMinimumHeight(maxTabHeight);
        QWidget* w = static_cast<StackedScrollWidget*>(sw)->widget();
        if (w)
            w->resize(s);
    }
```

#### AUTO 


```{c}
auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatBasic, KIO::HideProgressInfo);
```

#### AUTO 


```{c}
auto it = mEventMap.find(id);
```

#### AUTO 


```{c}
auto* filterEdit = new QLineEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ProcData* pd : std::as_const(mCommandProcesses))
                {
                    if (pd->event->id() == event.id()  &&  (pd->flags & ProcData::PRE_ACTION))
                    {
                        qCDebug(KALARM_LOG) << "KAlarmApp::execAlarm: Already executing pre-DISPLAY command";
                        return pd->process;   // already executing - don't duplicate the action
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (MainWindow* w : std::as_const(mWindowList))
    {
        w->mActionImportAlarms->setEnabled(active || templat);
        w->mActionImportBirthdays->setEnabled(active);
        w->mActionCreateTemplate->setEnabled(templat);
        // Note: w->mActionNew enabled status is set in the NewAlarmAction class.
        w->slotSelection();
    }
```

#### AUTO 


```{c}
auto it = transitions.rbegin(), end = transitions.rend();
```

#### AUTO 


```{c}
const auto l = d->mRecurrence.exDateTimes();
```

#### AUTO 


```{c}
auto* model = qobject_cast<QStandardItemModel*>(mTypeCombo->model());
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
const auto& qdt
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLabel* label : qAsConst(mLabels))
        {
            const int x = label->mapTo(this, QPoint(0, 0)).x();
            xpos += x;
            const int w = x + label->sizeHint().width();
            if (w > wid)
                wid = w;
        }
```

#### AUTO 


```{c}
auto dgrid = new QGridLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& resourceGroup : std::as_const(resourceGroups))
        {
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
            const int groupIndex = resourceGroup.midRef(9).toInt();
#else
            const int groupIndex = QStringView(resourceGroup).mid(9).toInt();
#endif
            FileResourceSettings::Ptr settings(new FileResourceSettings(manager->mConfig, resourceGroup));
            if (!settings->isValid())
            {
                qCWarning(KALARM_LOG) << "FileResourceConfigManager: Invalid config for" << resourceGroup;
                manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
            }
            else
            {
                // Check for and remove duplicate URL or 'standard' setting
                for (auto it = manager->mResources.constBegin();  it != manager->mResources.constEnd();  ++it)
                {
                    const ResourceData& data = it.value();
                    if (settings->url() == data.resource.location())
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate URL in config for" << resourceGroup;
                        manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Deleted duplicate resource" << settings->displayName();
                        settings.clear();
                        break;
                    }
                    const CalEvent::Types std = settings->standardTypes() & data.settings->standardTypes();
                    if (std)
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate 'standard' setting in config for" << resourceGroup;
                        settings->setStandard(settings->standardTypes() ^ std);
                    }
                }
                if (settings)
                {
                    Resource resource(createResource(settings));
                    manager->mResources[settings->id()] = ResourceData(resource, settings);
                    manager->mConfigGroups[groupIndex] = settings->id();

                    Resources::notifyNewResourceInitialised(resource);

                    // Update the calendar to the current KAlarm format if necessary, and
                    // if the user agrees.
                    FileResourceCalendarUpdater::updateToCurrentFormat(resource, false, parent);
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
                    if (type & event.category())
                        list += event;
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos& posn : posns)
                {
                    if (!posn.pos())
                        rDays.setBit(posn.day() - 1, true);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Resource& r) { return DataModel::instance()->resourceIndex(r); }
```

#### AUTO 


```{c}
auto* boxHLayout = new QHBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource& resource : resources)
        ok = ok && resource.reload();
```

#### AUTO 


```{c}
auto* m = qobject_cast<EventListModel*>(model());
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* updater = new FileResourceCalendarUpdater(resource, ignoreKeepFormat, parent, qobject_cast<QWidget*>(parent));
```

#### AUTO 


```{c}
auto almodel = qobject_cast<AlarmListModel*>(model());
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url);
```

#### AUTO 


```{c}
auto* grid = new QGridLayout(frame);
```

#### AUTO 


```{c}
auto* mimeTypeFilter = new Akonadi::EntityMimeTypeFilterModel(this);
```

#### AUTO 


```{c}
auto* vlayout = new QVBoxLayout(group);
```

#### AUTO 


```{c}
const auto candidates = QTimeZone::availableTimeZoneIds(standardUtcOffset);
```

#### AUTO 


```{c}
auto dlg = qobject_cast<EditEmailAlarmDlg*>(editDlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (int month : months)
            d->mRecurrence->addYearlyMonth(month);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(eventsToAdd))
            {
                auto* ev = new KAEvent(event);
                ev->setResourceId(resource.id());
                Node* node = new Node(ev, resource);
                resourceEventNodes += node;
                mEventNodes[ev->id()] = node;
            }
```

#### AUTO 


```{c}
auto it = mResources.find(resource.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            // Read the resource configuration parameters from the config
            const KConfigGroup configGroup = config.group(QLatin1String("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            const char* pathKey = nullptr;
            FileResourceSettings::StorageType storageType;
            if (resourceType == QLatin1String("file"))
            {
                storageType = FileResourceSettings::File;
                pathKey = "CalendarURL";
            }
            else if (resourceType == QLatin1String("dir"))
            {
                storageType = FileResourceSettings::Directory;
                pathKey = "CalendarURL";
            }
            else if (resourceType == QLatin1String("remote"))
            {
                storageType = FileResourceSettings::File;
                pathKey = "DownloadUrl";
            }
            else
            {
                qCWarning(KALARM_LOG) << "CalendarCreator: Invalid resource type:" << resourceType;
                continue;   // unknown resource type - can't convert
            }

            const QUrl url = QUrl::fromUserInput(configGroup.readPathEntry(pathKey, QString()));
            CalEvent::Type alarmType = CalEvent::EMPTY;
            switch (configGroup.readEntry("AlarmType", (int)0))
            {
                case 1:  alarmType = CalEvent::ACTIVE;    break;
                case 2:  alarmType = CalEvent::ARCHIVED;  break;
                case 4:  alarmType = CalEvent::TEMPLATE;  break;
                default:
                    qCWarning(KALARM_LOG) << "FileResourceMigrator::migrateKResources: Invalid alarm type for resource";
                    continue;
            }
            const QString name  = configGroup.readEntry("ResourceName", QString());
            const bool enabled  = configGroup.readEntry("ResourceIsActive", false);
            const bool standard = configGroup.readEntry("Standard", false);
            qCDebug(KALARM_LOG) << "FileResourceMigrator::migrateKResources: Migrating:" << name << ", type=" << alarmType << ", path=" << url.toString();
            FileResourceSettings::Ptr settings(new FileResourceSettings(
                          storageType, url, alarmType, name,
                          configGroup.readEntry("Color", QColor()),
                          (enabled ? alarmType : CalEvent::EMPTY),
                          (standard ? alarmType : CalEvent::EMPTY),
                          configGroup.readEntry("ResourceIsReadOnly", true)));
            Resource resource = FileResourceConfigManager::addResource(settings);

            // Update the calendar to the current KAlarm format if necessary,
            // and if the user agrees.
            FileResourceCalendarUpdater* updater = new FileResourceCalendarUpdater(resource, true, this);
            connect(updater, &QObject::destroyed, this, &FileResourceMigrator::checkIfComplete);
            updater->update();   // note that 'updater' will auto-delete when finished

            mExistingAlarmTypes |= alarmType;
        }
```

#### AUTO 


```{c}
auto getJob = KIO::storedGet(mUrl.url());
```

#### RANGE FOR STATEMENT 


```{c}
for (const ActionQEntry& entry : qAsConst(mActionQueue))
    {
        if (entry.function == EVENT_HANDLE  &&  entry.eventId == id)
            return;  // the alarm is already queued
    }
```

#### AUTO 


```{c}
auto* iface = writeBasicConfig<OrgKdeAkonadiKAlarmDirSettingsInterface>();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* w : std::as_const(mWindowList))
            {
                if ((!errmsgs && w->mErrorWindow())
                ||  (errmsgs && !w->mErrorWindow()))
                    continue;
                const QSize sz = w->frameGeometry().size();
                if (x + sz.width() > desk.right())
                {
                    x = desk.left();
                    y = ynext;
                }
                int ytmp = y;
                if (y + sz.height() > desk.bottom())
                {
                    ytmp = desk.bottom() - sz.height();
                    if (ytmp < desk.top())
                        ytmp = desk.top();
                }
                w->move(x, ytmp);
                x += sz.width();
                if (ytmp + sz.height() > ynext)
                    ynext = ytmp + sz.height();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AgentInstance& agent : agents)
    {
        if (agent.type().mimeTypes().contains(mimeType))
        {
            CollectionFetchJob* job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
            job->fetchScope().setResource(agent.identifier());
            mCollectionJobs << job;
            connect(job, &CollectionFetchJob::result, this, &AkonadiCollectionSearch::collectionFetchResult);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        Resource resource = Resources::resource(event.resourceId());
        if (resource.isValid())
            deleteEventInternal(event.id(), event, resource, true);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& resource : resources)
        {
            needed &= ~resource.alarmTypes();
            if (!needed)
            {
                mCompleted = true;
                return mInstance;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : qAsConst(*mUndos))
    {
        switch (item->calendar())
        {
            case CalEvent::ACTIVE:
                return i18nc("@info", "Delete multiple alarms");
            case CalEvent::TEMPLATE:
                return i18nc("@info", "Delete multiple templates");
            case CalEvent::ARCHIVED:
                break;    // check if they are ALL archived
            default:
                return QString();
        }
    }
```

#### AUTO 


```{c}
auto* itemBox = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        const KADateTime dateTime = event.nextTrigger(KAEvent::DISPLAY_TRIGGER).effectiveKDateTime().toLocalZone();
        const Resource resource = Resources::resource(event.resourceId());
        QString text(resource.configName() + QLatin1String(":"));
        text += event.id() + QLatin1Char(' ')
             +  dateTime.toString(QStringLiteral("%Y%m%dT%H%M "))
             +  AlarmText::summary(event, 1);
        alarms << text;
    }
```

#### AUTO 


```{c}
auto* dattr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event::Ptr& kcalEvent : kcalEvents)
        {
            bool showDefer, showEdit;
            reinstateFromDisplaying(kcalEvent, event, resource, showEdit, showDefer);
            const EventId eventId(event);
            if (findEvent(eventId))
                qCDebug(KALARM_LOG) << "MessageDisplay::redisplayAlarms: Message display already exists:" << eventId;
            else
            {
                // This event should be displayed, but currently isn't being
                const KAAlarm alarm = event.convertDisplayingAlarm();
                if (alarm.type() == KAAlarm::INVALID_ALARM)
                {
                    qCCritical(KALARM_LOG) << "MessageDisplay::redisplayAlarms: Invalid alarm: id=" << eventId;
                    continue;
                }
                qCDebug(KALARM_LOG) << "MessageDisplay::redisplayAlarms:" << eventId;
                const bool login = alarm.repeatAtLogin();
                const int flags = NO_RESCHEDULE | (login ? NO_DEFER : 0) | NO_INIT_VIEW;
                MessageDisplay* d = new MessageWindow(&event, alarm, flags);
                MessageDisplayHelper* h = d->mHelper;
                h->mResource = resource;
                const bool rw = resource.isWritable(event.category());
                h->mShowEdit = rw ? showEdit : false;
                h->mNoDefer  = (rw && !login) ? !showDefer : true;
                d->setUpDisplay();
                d->showDisplay();
            }
        }
```

#### AUTO 


```{c}
auto* elm = qobject_cast<EventListModel*>(model);
```

#### AUTO 


```{c}
const auto candidateTransition = candidateTransitions[0];
```

#### RANGE FOR STATEMENT 


```{c}
for (const AkonadiModel::Event& event : events)
    {
        if (!event.isConsistent())
            qCCritical(KALARM_LOG) << "AlarmCalendar::slotEventsToBeRemoved: Inconsistent AkonadiModel::Event: event:" << event.event.collectionId() << ", collection" << event.collection.id();
        else if (mEventMap.contains(event.eventId()))
            deleteEventInternal(event.event, event.collection, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
        {
            if (!event.enabled()  &&  (event.actionTypes() & KAEvent::ACT_DISPLAY))
            {
                MessageWin* win = MessageWin::findEvent(EventId(event));
                delete win;
            }
        }
```

#### AUTO 


```{c}
auto& resourceHash = mDateFilterCache[ev.resourceId()];
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto &abv
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                if (tz.id() == name) {
                    zone = tz;
                    zname = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MonthPos& posn : posns) {
            d->mRecurrence->addYearlyPos(posn.weeknum, posn.days);
        }
```

#### AUTO 


```{c}
auto recorder = new Akonadi::ChangeRecorder;
```

#### AUTO 


```{c}
auto* buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
auto getJob = KIO::storedGet(mUrl);
```

#### AUTO 


```{c}
auto* job = new ItemCreateJob(item, mCollection);
```

#### AUTO 


```{c}
const auto rit = mDateFilterCache.constFind(ev.resourceId());
```

#### AUTO 


```{c}
auto* model = new EventListModel(types, parent);
```

#### AUTO 


```{c}
auto date = new KMime::Headers::Date;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& resource : resources)
        mExistingAlarmTypes |= resource.alarmTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* w : qAsConst(mWindowList))
    {
        if (w->pos() != topLeft)
            return true;
    }
```

#### AUTO 


```{c}
auto* me = static_cast<QMouseEvent*>(e);
```

#### AUTO 


```{c}
auto it = manager->mResources.constFind(resource.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &phase : phases) {
        if (!phase.isDst()) {
            standardUtcOffset = phase.utcOffset();
            matched = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
            {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit())
                {
                    while (++i < length && txt[i].isDigit()) {}
                    if (i < length  &&  txt[i++] == SEPARATOR)
                    {
                        while (i < length)
                        {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR)
                                break;
                            if (ch == LATE_CANCEL_CODE)
                                lateCancel = true;
                            else if (ch == AT_LOGIN_CODE)
                                atLogin = true;
                            else if (ch == DEFERRAL_CODE)
                                deferral = true;
                        }
                    }
                    else
                        i = 0;    // invalid prefix
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i)
                    i += TEXT_PREFIX.length();
                else if (txt.indexOf(FILE_PREFIX, i) == i)
                {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                }
                else if (txt.indexOf(COMMAND_PREFIX, i) == i)
                {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                }
                else
                    i = 0;
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action)
                {
                    case KAAlarm::FILE:
                        types += KAEventPrivate::FILE_TYPE;
                        Q_FALLTHROUGH(); // fall through to MESSAGE
                    case KAAlarm::MESSAGE:
                        alarm->setDisplayAlarm(altxt);
                        break;
                    case KAAlarm::COMMAND:
                        setProcedureAlarm(alarm, altxt);
                        break;
                    case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                    case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                        break;
                }
                if (atLogin)
                {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                }
                else if (deferral)
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                if (lateCancel)
                    addLateCancel = true;
                if (types.count() > 0)
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0)
                {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence* recur = event->recurrence();
                    if (recur  &&  recur->recurs())
                    {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime)
                {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm* dtm = localtime(&t);
                    if (dtm->tm_isdst)
                    {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
```

#### AUTO 


```{c}
auto* date = new KMime::Headers::Date;
```

#### AUTO 


```{c}
auto* iface = AkonadiResource::getAgentInterface<Interface>(agent, errorMessage, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tzid : candidates) {
        const QTimeZone candidate(tzid);
        // This would be a fallback
        if (candidate.hasTransitions() != ktz.hasTransitions()) {
            matchedCandidates.insert(0, candidate);
            continue;
        }

        // Without transitions, we can't do any more precise matching, so just
        // accept this candidate and be done with it
        if (!candidate.hasTransitions() && !ktz.hasTransitions()) {
            return candidate;
        }

        // Calculate how many transitions this candidate shares with the ktz.
        // The candidate with the most matching transitions will win.
        const auto transitions = ktz.transitions(QDateTime(), QDateTime::currentDateTimeUtc());
        int matchedTransitions = 0;
        for (auto it = transitions.rbegin(), end = transitions.rend(); it != end; ++it) {
            const auto &transition = *it;
            const QTimeZone::OffsetDataList candidateTransitions = candidate.transitions(transition.time(), transition.time());
            if (candidateTransitions.isEmpty()) {
                continue;
            }
            const auto candidateTransition = candidateTransitions[0];
            const auto abvs = transition.phase().abbreviations();
            for (const auto &abv : abvs) {
                if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                    ++matchedTransitions;
                    break;
                }
            }
        }
        matchedCandidates.insert(matchedTransitions, candidate); 
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const int month : months)
            {
                if (first < 0)
                    first = month;
                else
                {
                    const int span = QDate(2001, last, 1).daysTo(QDate(2001, month, 1));
                    if (span > maxgap)
                        maxgap = span;
                }
                last = month;
            }
```

#### AUTO 


```{c}
auto* newUndos = new Undo::List;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == KALARM_RESOURCE  ||  type == KALARM_DIR_RESOURCE)
        {
            Akonadi::CollectionFetchJob* job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending[job] = (type == KALARM_DIR_RESOURCE);
            connect(job, &KJob::result, this, &FileResourceMigrator::collectionFetchResult);

            mMigrateKResources = false;   // Akonadi resources exist, so ignore KResources
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarUpdater* instance : mInstances)
    {
        if (instance->mCollection.id() == id)
            return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DailyTimer* timer : std::as_const(mFixedTimers))
        if (timer->mTime == timeOfDay)
            return timer;
```

#### RANGE FOR STATEMENT 


```{c}
for (const MonthPos& posn : posns) {
            d->mRecurrence->addMonthlyPos(posn.weeknum, posn.days);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[loop, &id](Resource& r) {
                    if (r.id() == id) loop->quit(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                qdt.setTimeZone(tz);
                // TODO: This may not find abbreviations for second occurrence of
                // the time zone time, after a daylight savings time shift.
                if (tz.abbreviation(qdt) == zoneAbbrev) {
                    int offset2;
                    int offset = offsetAtZoneTime(tz, qdt, &offset2);
                    if (offset == InvalidOffset) {
                        return KADateTime();
                    }
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid()) {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous || offset != utcOffset) {
                            return KADateTime();
                        }
                        useUtcOffset = true;
                    } else {
                        zone = tz;
                        utcOffset = offset;
                    }
                }
            }
```

#### AUTO 


```{c}
auto* dgrid = new QGridLayout(box);
```

#### AUTO 


```{c}
auto* job = qobject_cast<CollectionFetchJob*>(j);
```

#### AUTO 


```{c}
auto* proc = (ShellProcess*)result;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& resourceGroup : std::as_const(resourceGroups))
        {
            int groupIndex = resourceGroup.midRef(9).toInt();
            FileResourceSettings::Ptr settings(new FileResourceSettings(manager->mConfig, resourceGroup));
            if (!settings->isValid())
            {
                qCWarning(KALARM_LOG) << "FileResourceConfigManager: Invalid config for" << resourceGroup;
                manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
            }
            else
            {
                // Check for and remove duplicate URL or 'standard' setting
                for (auto it = manager->mResources.constBegin();  it != manager->mResources.constEnd();  ++it)
                {
                    const ResourceData& data = it.value();
                    if (settings->url() == data.resource.location())
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate URL in config for" << resourceGroup;
                        manager->mConfig->deleteGroup(resourceGroup);   // invalid config for this resource
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Deleted duplicate resource" << settings->displayName();
                        settings.clear();
                        break;
                    }
                    const CalEvent::Types std = settings->standardTypes() & data.settings->standardTypes();
                    if (std)
                    {
                        qCWarning(KALARM_LOG) << "FileResourceConfigManager: Duplicate 'standard' setting in config for" << resourceGroup;
                        settings->setStandard(settings->standardTypes() ^ std);
                    }
                }
                if (settings)
                {
                    Resource resource(createResource(settings));
                    manager->mResources[settings->id()] = ResourceData(resource, settings);
                    manager->mConfigGroups[groupIndex] = settings->id();

                    Resources::notifyNewResourceInitialised(resource);

                    // Update the calendar to the current KAlarm format if necessary, and
                    // if the user agrees.
                    FileResourceCalendarUpdater::updateToCurrentFormat(resource, false, parent);
                }
            }
        }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(kalarmWidgets);
```

#### AUTO 


```{c}
auto newit = newEvents.find(id);
```

#### AUTO 


```{c}
auto it = mEventNodes.constFind(event.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent* event : events)
    {
        // Update the window lists
        // Delete the template from the calendar file
        AlarmCalendar* cal = AlarmCalendar::resources();
        if (!cal->deleteEvent(*event, false))   // don't save calendar after deleting
            status.setError(UPDATE_ERROR);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        Node* node = mEventNodes.value(event.id(), nullptr);
        if (node  &&  node->parent() == resource)
        {
            int row = eventNodes.indexOf(node);
            if (row >= 0)
                rowsToDelete << row;
        }
    }
```

#### AUTO 


```{c}
auto itr = manager->mResources.constBegin();
```

#### AUTO 


```{c}
auto* attr = item.attribute<EventAttribute>(Item::AddIfMissing);
```

#### AUTO 


```{c}
auto grid = new QGridLayout(templateTimeBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (Qt::DayOfWeek weekDay : std::as_const(weekDays))
            workDays |= 1 << (weekDay - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* const event : events)
                    if (type & event->category())
                        list += event;
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        const KADateTime dateTime = event.nextTrigger(KAEvent::DISPLAY_TRIGGER).effectiveKDateTime().toLocalZone();
        const Resource resource = AkonadiModel::instance()->resource(event.resourceId());
        QString text(resource.configName() + QLatin1String(":"));
        text += event.id() + QLatin1Char(' ')
             +  dateTime.toString(QStringLiteral("%Y%m%dT%H%M "))
             +  AlarmText::summary(event, 1);
        alarms << text;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLabel* label : std::as_const(mLabels))
        {
            const int x = label->mapTo(this, QPoint(0, 0)).x();
            xpos += x;
            const int w = x + label->sizeHint().width();
            if (w > wid)
                wid = w;
        }
```

#### AUTO 


```{c}
auto it = mResources.constFind(instance->id());
```

#### AUTO 


```{c}
auto* main = static_cast<StackedScrollWidget*>(mTabs->widget(0));
```

#### AUTO 


```{c}
auto* f29box = new QHBoxLayout;
```

#### AUTO 


```{c}
auto it = mEvents.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(it.value()))
        {
            if (!res.addEvent(event))
                success = false;
        }
```

#### AUTO 


```{c}
auto boxLayout = new QHBoxLayout(box);
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* page = static_cast<DirResourceImportWidgetBase*>(current->widget());
```

#### AUTO 


```{c}
auto* model = new AlarmListModel(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Resource res = model->resource(colId);
        if (res.isValid()  &&  (allTypes  ||  res.alarmTypes() & type))
        {
            Collection* c = model->collection(colId);
            if (c)
                result += *c;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id id : colIds)
    {
        Collection c(id);
        if (c.resource() == resourceId)
            return c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
    {
        // Update the window lists
        // Delete the template from the calendar file
        AlarmCalendar* cal = AlarmCalendar::resources();
        if (!cal->deleteEvent(*event, false))   // don't save calendar after deleting
            status.setError(UPDATE_ERROR);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : sorted)
    {
        QAction* act = m->addAction(name);
        mOriginalTexts[act] = name;   // keep original text, since action text has shortcuts added
    }
```

#### AUTO 


```{c}
auto* mainScroll = new StackedScrollWidget(mTabScrollGroup);
```

#### AUTO 


```{c}
auto model = new EventListModel(types, parent);
```

#### AUTO 


```{c}
auto fileBoxHLayout = new QHBoxLayout(mFileBox);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& id) { return DataModel::instance()->eventIndex(id); }
```

#### AUTO 


```{c}
auto data = new DeferDlgData(dlg);
```

#### LAMBDA EXPRESSION 


```{c}
[this, deferButton](QAbstractButton *btn) {
                if (btn == deferButton) {
                    slotCancelDeferral();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList)
            {
                if (tz.id() == name)
                {
                    zone = tz;
                    zname = true;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(eventsToAdd))
            {
                auto ev = new KAEvent(event);
                ev->setResourceId(resource.id());
                Node* node = new Node(ev, resource);
                resourceEventNodes += node;
                mEventNodes[ev->id()] = node;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& type : types)
                {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE)
                    {
                        mainAlarm = false;
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(mDeferGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : eventsToDelete)
                {
                    Resource res = Resources::resource(event.resourceId());
                    if (!ResourcesCalendar::deleteEvent(event, res, false))
                        status.setError(UPDATE_ERROR);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event::Ptr& kcalEvent : kcalEvents)
        {
            bool showDefer, showEdit;
            reinstateFromDisplaying(kcalEvent, event, resource, showEdit, showDefer);
            const EventId eventId(event);
            if (findEvent(eventId))
                qCDebug(KALARM_LOG) << "MessageDisplay::redisplayAlarms: Message display already exists:" << eventId;
            else
            {
                // This event should be displayed, but currently isn't being
                const KAAlarm alarm = event.convertDisplayingAlarm();
                if (alarm.type() == KAAlarm::INVALID_ALARM)
                {
                    qCCritical(KALARM_LOG) << "MessageDisplay::redisplayAlarms: Invalid alarm: id=" << eventId;
                    continue;
                }
                qCDebug(KALARM_LOG) << "MessageDisplay::redisplayAlarms:" << eventId;
                const bool login = alarm.repeatAtLogin();
                const int flags = NoReschedule | (login ? NoDefer : 0) | NoInitView;
                MessageDisplay* d = create(event, alarm, flags);
                MessageDisplayHelper* h = d->mHelper;
                h->mResource = resource;
                const bool rw = resource.isWritable(event.category());
                h->mShowEdit = rw ? showEdit : false;
                h->mNoDefer  = (rw && !login) ? !showDefer : true;
                d->setUpDisplay();
                d->showDisplay();
            }
        }
```

#### AUTO 


```{c}
auto me = static_cast<QMouseEvent*>(e);
```

#### AUTO 


```{c}
auto topGeneral = new StackedWidgetT<QWidget>(tabgroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event::Ptr& event : events)
    {
        if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
            continue;    // ignore events without alarms, or usable alarms
        CalEvent::Type type = CalEvent::status(event);
        if (type == CalEvent::TEMPLATE)
        {
            // If we know the event was not created by KAlarm, don't treat it as a template
            if (!currentFormat)
                type = CalEvent::ACTIVE;
        }
        if (!(type & alarmTypes))
            continue;

        Event::Ptr newev(new Event(*event));

        // If there is a display alarm without display text, use the event
        // summary text instead.
        if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
        {
            const Alarm::List& alarms = newev->alarms();
            for (Alarm::Ptr alarm : alarms)
            {
                if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                    alarm->setText(newev->summary());
            }
            newev->setSummary(QString());   // KAlarm only uses summary for template names
        }

        // Give the event a new ID, or ensure that it is in the correct format.
        const QString id = newId ? CalFormat::createUniqueId() : newev->uid();
        newev->setUid(CalEvent::uid(id, type));

        alarmList[type] += KAEvent(newev);
    }
```

#### AUTO 


```{c}
const auto abvs = transition.phase().abbreviations();
```

#### AUTO 


```{c}
auto grid = new QGridLayout(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        KAEvent* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "AlarmCalendar::updateDisplayKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        event->setResourceId(key);
        events += event;
        mEventMap[EventId(key, kcalevent->uid())] = event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event::Ptr& kcalEvent : kcalEvents)
        {
            bool showDefer, showEdit;
            if (!reinstateFromDisplaying(kcalEvent, event, resource, showEdit, showDefer))
                continue;
            const EventId eventId(event);
            if (findEvent(eventId))
                qCDebug(KALARM_LOG) << "MessageDisplay::redisplayAlarms: Message display already exists:" << eventId;
            else
            {
                // This event should be displayed, but currently isn't being
                const KAAlarm alarm = event.convertDisplayingAlarm();
                if (alarm.type() == KAAlarm::INVALID_ALARM)
                {
                    qCCritical(KALARM_LOG) << "MessageDisplay::redisplayAlarms: Invalid alarm: id=" << eventId;
                    continue;
                }
                qCDebug(KALARM_LOG) << "MessageDisplay::redisplayAlarms:" << eventId;
                const bool login = alarm.repeatAtLogin();
                const int flags = NoReschedule | (login ? NoDefer : 0) | NoInitView;
                MessageDisplay* d = create(event, alarm, flags);
                MessageDisplayHelper* h = d->mHelper;
                h->mResource = resource;
                const bool rw = resource.isWritable(event.category());
                h->mShowEdit = rw ? showEdit : false;
                h->mNoDefer  = (rw && !login) ? !showDefer : true;
                d->setUpDisplay();
                d->showDisplay();
            }
        }
```

#### AUTO 


```{c}
auto* me = (QMouseEvent*)e;
```

#### AUTO 


```{c}
const auto transitions = ktz.transitions(QDateTime(), QDateTime::currentDateTimeUtc());
```

#### AUTO 


```{c}
auto* grid = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* win : std::as_const(mRestoredWindows))
                win->display();
```

#### AUTO 


```{c}
auto* bgroup = new QButtonGroup(group);
```

#### AUTO 


```{c}
auto boxLayout = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().indexOf(MatchMimeType) >= 0)
            {
                ResourceCol thisRes(job->fetchScope().resource(), c);
                auto it = mAgentPaths.constFind(c.remoteId());
                if (it != mAgentPaths.constEnd())
                {
                    // Remove the resource which, in decreasing order of priority:
                    // - Is disabled;
                    // - Is not a standard resource;
                    // - Contains the higher numbered Collection ID, which is likely
                    //   to be the more recently created.
                    const ResourceCol prevRes = it.value();
                    const CollectionProperties properties[2] = { CollectionProperties(prevRes.collection),
                                                                 CollectionProperties(thisRes.collection) };
                    int propToUse = (thisRes.collection.id() < prevRes.collection.id()) ? 1 : 0;
                    if (properties[1 - propToUse].standardTypes  &&  !properties[propToUse].standardTypes)
                        propToUse = 1 - propToUse;
                    if (properties[1 - propToUse].enabledTypes  &&  !properties[propToUse].enabledTypes)
                        propToUse = 1 - propToUse;

                    if (propToUse == 0)
                    {
                        qCWarning(KALARM_LOG) << "AkonadiResource::collectionFetchResult: Removing duplicate resource" << thisRes.resourceId;
                        agentManager->removeInstance(agentManager->instance(thisRes.resourceId));
                        continue;
                    }
                    qCWarning(KALARM_LOG) << "AkonadiResource::collectionFetchResult: Removing duplicate resource" << prevRes.resourceId;
                    agentManager->removeInstance(agentManager->instance(prevRes.resourceId));
                }
                mAgentPaths[c.remoteId()] = thisRes;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == KALARM_RESOURCE  ||  type == KALARM_DIR_RESOURCE)
        {
            Akonadi::CollectionFetchJob* job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending[job] = (type == KALARM_DIR_RESOURCE);
            connect(job, &KJob::result, this, &AkonadiResourceMigrator::collectionFetchResult);
            migrating = true;
        }
    }
```

#### AUTO 


```{c}
auto it = mConfigGroups.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageNotification* notif : qAsConst(mNotificationList))
        {
            if (notif->mAlwaysHidden())
                --count;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (MainWindow* w : qAsConst(mWindowList))
    {
        w->mActionImportAlarms->setEnabled(active || templat);
        w->mActionImportBirthdays->setEnabled(active);
        w->mActionCreateTemplate->setEnabled(templat);
        // Note: w->mActionNew enabled status is set in the NewAlarmAction class.
        w->slotSelection();
    }
```

#### AUTO 


```{c}
auto cte = new KMime::Headers::ContentTransferEncoding;
```

#### AUTO 


```{c}
auto* ke = static_cast<QKeyEvent*>(e);
```

#### AUTO 


```{c}
auto* tgLayout = new QVBoxLayout(topGeneral);
```

#### AUTO 


```{c}
auto evit = newEvents.find(errit.key());
```

#### AUTO 


```{c}
const auto it = changedProperties.find(QStringLiteral("Inhibited"));
```

#### RANGE FOR STATEMENT 


```{c}
for (MessageWindow* w : qAsConst(mWindowList))
            w->move(desk.topLeft());
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
        {
            if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
                continue;    // ignore events without alarms, or usable alarms
            CalEvent::Type type = CalEvent::status(event);
            if (type == CalEvent::TEMPLATE)
            {
                // If we know the event was not created by KAlarm, don't treat it as a template
                if (caltype == KACalendar::Incompatible)
                    type = CalEvent::ACTIVE;
            }
            Resource res;
            if (resource.isValid())
            {
                if (!(type & wantedTypes))
                    continue;
                res = resource;
            }
            else
            {
                switch (type)
                {
                    case CalEvent::ACTIVE:
                    case CalEvent::ARCHIVED:
                    case CalEvent::TEMPLATE:
                        break;
                    default:
                        continue;
                }
                res = Resources::destination<AkonadiModel>(type);
            }

            Event::Ptr newev(new Event(*event));

            // If there is a display alarm without display text, use the event
            // summary text instead.
            if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
            {
                const Alarm::List& alarms = newev->alarms();
                for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
                newev->setSummary(QString());   // KAlarm only uses summary for template names
            }

            // Give the event a new ID and add it to the calendars
            newev->setUid(CalEvent::uid(CalFormat::createUniqueId(), type));
            if (!res.addEvent(KAEvent(newev)))
                success = false;
        }
```

#### AUTO 


```{c}
auto rrule = new RecurrenceRule();
```

#### AUTO 


```{c}
auto moreLayout = new QVBoxLayout(mMoreOptions);
```

#### AUTO 


```{c}
auto* event = new KAEvent(kcalevent);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Resource& r, CalEvent::Types t) { return DataModel::instance()->tooltip(r, t); }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarUpdater* instance : std::as_const(mInstances))
    {
        if (instance->mResourceId == id)
            return true;
    }
```

#### AUTO 


```{c}
auto uploadJob = KIO::storedPut(&qFile, url, -1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &qdt : l) {
        rv << qdt;
    }
```

#### AUTO 


```{c}
auto* dlg = qobject_cast<EditAlarmDlg*>(sender());
```

#### AUTO 


```{c}
auto grid = new QGridLayout(frame);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& file : std::as_const(files))
                {
                    if (file.scheme() == mailto)
                        newEmails.append(file.path());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
    {
        if (alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0)
        {
            if (!converted)
            {
                event->startUpdates();   // prevent multiple update notifications
                if (readOnly)
                    event->setReadOnly(false);
                if ((alarm->snoozeTime().asSeconds() % (24 * 3600)) != 0)
                    recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                else
                    recur->setDaily(alarm->snoozeTime().asDays());
                recur->setDuration(alarm->repeatCount() + 1);
                converted = true;
            }
            alarm->setRepeatCount(0);
            alarm->setSnoozeTime(0);
        }
    }
```

#### AUTO 


```{c}
auto* view = new QTextBrowser(topWidget);
```

#### AUTO 


```{c}
auto boxLayout = new QHBoxLayout(w);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget* w : children)
            w->installEventFilter(this);
```

#### AUTO 


```{c}
auto* topLayout = new QVBoxLayout(mainPage);
```

#### AUTO 


```{c}
auto ttLayout = new QVBoxLayout(topTypes);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& type : types)
                    {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE)
                        {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
```

#### AUTO 


```{c}
auto updater = new FileResourceCalendarUpdater(resource, ignoreKeepFormat, parent, qobject_cast<QWidget*>(parent));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime& dtime : dtlist)
    {
        if (dtime.date() == dt)
            return true;
    }
```

#### AUTO 


```{c}
auto* helpEvent = static_cast<QHelpEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event& event : events)
            qCDebug(KALARM_LOG) << "Collection:" << event.collection.id() << ", Event ID:" << event.event.id();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : qAsConst(it.value()))
                        resource.addEvent(event);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, deferButton](QAbstractButton* btn)
                {
                    if (btn == deferButton)
                        slotCancelDeferral();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& collection : collections)
    {
        mMonitor->setCollectionMonitored(collection, false);
        mMonitor->setCollectionMonitored(collection, true);
    }
```

#### AUTO 


```{c}
auto downloadJob = KIO::storedGet(url.url());
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
    {
        if (includeCmdAlarms  ||  !(event->actionTypes() & KAEvent::ACT_COMMAND))
            templates.append(event);
    }
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Collection c(colId);
        AkonadiModel::instance()->refresh(c);    // update with latest data
        if (c.contentMimeTypes().contains(mimeType)
        &&  (!writable || ((c.rights() & writableRights) == writableRights)))
            result += c;
    }
```

#### AUTO 


```{c}
auto* fader = new Phonon::VolumeFaderEffect(mAudioObject);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection::Id& id : collectionIds)
        {
            const Collection c(id);
            const QUrl cLocation = QUrl::fromUserInput(c.remoteId(), QString(), QUrl::AssumeLocalFile);
            if (id != collection.id()  &&  cLocation == location)
            {
                // The collection duplicates the backend storage
                // used by another enabled collection.
                // N.B. don't refresh this collection - assume no change.
                qCDebug(KALARM_LOG) << "CollectionControlModel::checkTypesToEnable:" << c.id() << "duplicates backend for" << collection.id();
                if (c.hasAttribute<CollectionAttribute>())
                {
                    types &= ~c.attribute<CollectionAttribute>()->enabled();
                    if (!types)
                        break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            const KConfigGroup configGroup = config.group(QLatin1String("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            QString agentType;
            if (resourceType == QLatin1String("file"))
                agentType = KALARM_RESOURCE;
            else if (resourceType == QLatin1String("dir"))
                agentType = KALARM_DIR_RESOURCE;
            else if (resourceType == QLatin1String("remote"))
                agentType = KALARM_RESOURCE;
            else
                continue;   // unknown resource type - can't convert

            creator = new CalendarCreator(resourceType, configGroup);
            if (!creator->isValid())
                delete creator;
            else
            {
                connect(creator, &CalendarCreator::finished, this, &CalendarMigrator::calendarCreated);
                connect(creator, &CalendarCreator::creating, this, &CalendarMigrator::creatingCalendar);
                mExistingAlarmTypes |= creator->alarmType();
                mCalendarsPending << creator;
                creator->createAgent(agentType, this);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display) {
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                    }
                }
```

#### AUTO 


```{c}
auto* page = qobject_cast<DirResourceImportTypeWidget*>(currentPage()->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                if (tz.offsetFromUtc(dtUTC) == utcOffset) {
                    // Found a time zone which uses this offset at the specified time
                    if (zone.isValid()  ||  !utcOffset) {
                        // UTC offset is used by more than one time zone
                        if (!offsetIfAmbiguous) {
                            return {};
                        }
                        if (dateOnly) {
                            return KADateTime(qdt.date(), Spec(OffsetFromUTC, utcOffset));
                        }
                        return KADateTime(qdt.date(), qdt.time(), Spec(OffsetFromUTC, utcOffset));
                    }
                    zone = tz;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr& kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        auto event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "DisplayCalendar::updateKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        mEventList += event;
        mEventMap[kcalevent->uid()] = event;
    }
```

#### AUTO 


```{c}
auto* job = new AgentInstanceCreateJob(agentType, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
            {
                if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                    alarm->setText(newev->summary());
            }
```

#### AUTO 


```{c}
auto* options = new CommandOptions;
```

#### AUTO 


```{c}
auto tgLayout = new QVBoxLayout(topGeneral);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mimeType : mimeTypes)
            if (mimeType.startsWith(QStringLiteral("audio/")))
            {
                const QMimeType mt = db.mimeTypeForName(mimeType);
                audioFilter += mt.globPatterns().join(QLatin1Char(' '));
                audioFilter += QLatin1Char(' ');
            }
```

#### AUTO 


```{c}
auto mainPage = new PageFrame(mainScroll);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (event.category() != CalEvent::ACTIVE
        ||  mPendingAlarms.contains(event.id()))
            continue;
        const KADateTime dt = event.nextTrigger(KAEvent::ALL_TRIGGER).effectiveKDateTime();
        if (dt.isValid()  &&  (!earliest.isValid() || dt < earliestTime))
        {
            earliestTime = dt;
            earliest = event;
        }
    }
```

#### AUTO 


```{c}
auto itr = manager->mResources.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds) {
                const QTimeZone z(zoneId);
                qdt.setTimeZone(z);
                if (z.abbreviation(qdt) == zoneAbbrev) {
                    // TODO: This may not find abbreviations for second occurrence of
                    // the time zone time, after a daylight savings time shift.
                    int offset2;
                    int offset = offsetAtZoneTime(z, qdt, &offset2);
                    if (offset == InvalidOffset) {
                        return KADateTime();
                    }
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid()) {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous || offset != utcOffset) {
                            return KADateTime();
                        }
                        useUtcOffset = true;
                    } else {
                        zone = z;
                        utcOffset = offset;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zone : zones)
        if (zone != utc)
        {
            mZoneNames << zone;
            addItem(i18n(zone).replace(QLatin1Char('_'), QLatin1Char(' ')));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& res : resources)
            {
                if (res.location() == url)
                {
                    qCWarning(KALARM_LOG) << "AkonadiResourceCreator::agentInstanceCreated: Duplicate path for new resource:" << path;
                    AgentManager::self()->removeInstance(mAgentInstance);
                    KMessageBox::sorry(nullptr, xi18nc("@info", "<para>The file or directory is already used by an existing resource:</para><para><filename>%1</filename></para>", path));
                    deleteLater();   // error result
                    return;
                }
            }
```

#### AUTO 


```{c}
auto* typeBoxLayout = new QHBoxLayout(mTypeBox);
```

#### AUTO 


```{c}
auto it = cmdErrors.find(event.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection::Id& id : colIds)
                {
                    Collection c(id);
                    AkonadiModel::instance()->refresh(c);    // update with latest data
                    if (c.isValid())
                    {
                        const CalEvent::Types t = stdTypes & CalEvent::types(c.contentMimeTypes());
                        if (t)
                        {
                            if (c.hasAttribute<CollectionAttribute>()
                            &&  AkonadiModel::isCompatible(c))
                            {
                                disallowedStdTypes |= c.attribute<CollectionAttribute>()->standard() & t;
                                if (disallowedStdTypes == stdTypes)
                                    break;
                            }
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Collection c(colId);
        AkonadiModel::instance()->refresh(c);    // update with latest data
        if ((allTypes  ||  c.contentMimeTypes().contains(mimeType))
        &&  agentManager->instance(c.resource()).isValid())
            result += c;
    }
```

#### AUTO 


```{c}
auto* moreLayout = new QVBoxLayout(mMoreOptions);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& mtype : mimeTypes)
    {
        if (mtype == MIME_ACTIVE)
            types |= ACTIVE;
        else if (mtype == MIME_ARCHIVED)
            types |= ARCHIVED;
        else if (mtype == MIME_TEMPLATE)
            types |= TEMPLATE;
    }
```

#### AUTO 


```{c}
auto event = new KAEvent(evnt);
```

#### AUTO 


```{c}
auto* data = new DeferDlgData(dlg);
```

#### AUTO 


```{c}
auto model = new ResourceCheckListModel(type, parent);
```

#### AUTO 


```{c}
auto it = mEvents.find(event.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        auto it = mEvents.find(event.id());
        if (it == mEvents.end())
        {
            KAEvent& ev = mEvents[event.id()];
            ev = event;
            ev.setResourceId(mId);
            if (event.category() & types)
                mEventsAdded += ev;
        }
        else
        {
            KAEvent& ev = it.value();
            bool changed = !ev.compare(event, KAEvent::Compare::Id | KAEvent::Compare::CurrentState);
            ev = event;   // update existing event
            ev.setResourceId(mId);
            if (changed  &&  (event.category() & types))
            {
                if (notify)
                    Resources::notifyEventUpdated(this, event);
                else
                    mEventsUpdated += event;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Qt::DayOfWeek weekDay : qAsConst(weekDays))
            if (++day < weekDay)
            {
                lastWorkDay = (day == 1) ? weekDays.at(weekDays.size() - 1) : day - 1;
                firstWorkDay = weekDay;
                break;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dtime : dtlist) {
        if (dtime.date() == dt) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
```

#### AUTO 


```{c}
auto it = mCollectionPaths.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday& holiday : list)
        if (!holiday.name().isEmpty())
            holidaysByDate[holiday.observedStartDate()].append(holiday.name());
```

#### AUTO 


```{c}
auto hlayout = new QHBoxLayout(mDeferGroup);
```

#### AUTO 


```{c}
auto* job = static_cast<ItemDeleteJob*>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().contains(mMimeType))
            {
                if (mGid.isEmpty())
                    mCollections << c;
                else
                {
                    // Search for all Items with the specified GID
                    Item item;
                    item.setGid(mGid);
                    ItemFetchJob* ijob = new ItemFetchJob(item, this);
                    ijob->setCollection(c);
                    mItemFetchJobs[ijob] = c.id();
                    connect(ijob, &ItemFetchJob::result, this, &CollectionSearch::itemFetchResult);
                }
            }
        }
```

#### AUTO 


```{c}
auto *rrule = new RecurrenceRule();
```

#### AUTO 


```{c}
auto it = mResources.find(collection.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
        ok = ok && addEvent(*event, collection);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { setStatus(false); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance& agent : agents)
            {
                const QString type = agent.type().identifier();
                if (type == KALARM_RESOURCE)
                {
                    // Fetch the resource's collection to determine its alarm types
                    Akonadi::CollectionFetchJob* job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::FirstLevel);
                    job->fetchScope().setResource(agent.identifier());
                    mFetchesPending << job;
                    connect(job, &KJob::result, this, &FileResourceMigrator::collectionFetchResult);

                    mMigrateKResources = false;   // ignore KResources if Akonadi resources exist
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& resource : resources)
    {
        const QList<KAEvent> events = resource.events();
        const CalEvent::Types types = resource.enabledTypes() & CalEvent::ACTIVE;
        for (const KAEvent& event : events)
        {
            if (event.enabled()  &&  (event.category() & types))
            {
                // The event has an enabled alarm type.
                // Find all its recurrences/repetitions within the time period.
                DateTime nextDt;
                for (KADateTime from = before;  ;  )
                {
                    event.nextOccurrence(from, nextDt, KAEvent::RETURN_REPETITION);
                    if (!nextDt.isValid())
                        break;
                    from = nextDt.effectiveKDateTime().toTimeSpec(timeSpec);
                    if (from > to)
                        break;
                    if (!event.excludedByWorkTimeOrHoliday(from))
                    {
                        mEventDates += from.date();
                        if (mEventDates.count() >= NUMDAYS)
                            break;   // all days have alarms due
                    }

                    // If the alarm recurs more than once per day, don't waste
                    // time checking any more occurrences for the same day.
                    from.setTime(QTime(23,59,0));
                }
                if (mEventDates.count() >= NUMDAYS)
                    break;   // all days have alarms due
            }
        }
        if (mEventDates.count() >= NUMDAYS)
            break;   // all days have alarms due
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &kdt : exdates) {
        l << kdt;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule::WDayPos& posn : posns)
                {
                    if (!posn.pos())
                        rDays.setBit(posn.day() - 1, 1);
                }
```

#### AUTO 


```{c}
auto* job = static_cast<CollectionFetchJob*>(j);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex& ix) { return DataModel::instance()->event(ix); }
```

#### AUTO 


```{c}
auto mainScroll = new StackedScrollWidget(mTabScrollGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (int day : days)
            d->mRecurrence->addMonthlyDate(day);
```

#### AUTO 


```{c}
auto* grid = new QGridLayout(textGroup);
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto it = mAgentPaths.constFind(c.remoteId());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : std::as_const(sorted))
    {
        QAction* act = m->addAction(name);
        mOriginalTexts[act] = name;   // keep original text, since action text has shortcuts added
    }
```

#### AUTO 


```{c}
auto statJob = KIO::statDetails(mUrl, KIO::StatJob::SourceSide, KIO::StatDetail::StatDefaultDetails);
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Collection c(colId);
        const Resource resource = AkonadiModel::instance()->resource(colId);
        if (writable  &&  !resource.isWritable())
            continue;
        if (resource.alarmTypes() & type)
            result += c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(page);
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (Alarm::Ptr alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### AUTO 


```{c}
auto it = events.constBegin();
```

#### AUTO 


```{c}
auto it = manager->mResources.find(resource.id());
```

#### AUTO 


```{c}
auto output = new Phonon::AudioOutput(Phonon::NotificationCategory, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Qt::DayOfWeek weekDay : qAsConst(weekDays))
            workDays |= 1 << (weekDay - 1);
```

#### AUTO 


```{c}
auto mailjob = new MailTransport::MessageQueueJob(qApp);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& regionCode : regions)
    {
        const QString name = HolidayRegion::name(regionCode);
        const QString languageName = QLocale::languageToString(QLocale(HolidayRegion::languageCode(regionCode)).language());
        const QString labelText = languageName.isEmpty() ? name : i18nc("Holiday region, region language", "%1 (%2)", name, languageName);
        regionsMap.insert(labelText, regionCode);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events)
        {
            if (event->alarms().isEmpty()  ||  !KAEvent(event).isValid())
                continue;    // ignore events without alarms, or usable alarms
            CalEvent::Type type = CalEvent::status(event);
            if (type == CalEvent::TEMPLATE)
            {
                // If we know the event was not created by KAlarm, don't treat it as a template
                if (caltype == KACalendar::Incompatible)
                    type = CalEvent::ACTIVE;
            }
            Collection* coll;
            if (collection  &&  collection->isValid())
            {
                if (!(type & wantedTypes))
                    continue;
                coll = collection;
            }
            else
            {
                switch (type)
                {
                    case CalEvent::ACTIVE:    coll = &activeColl;  break;
                    case CalEvent::ARCHIVED:  coll = &archiveColl;  break;
                    case CalEvent::TEMPLATE:  coll = &templateColl;  break;
                    default:  continue;
                }
                if (!coll->isValid())
                    *coll = CollectionControlModel::destination(type);
            }

            Event::Ptr newev(new Event(*event));

            // If there is a display alarm without display text, use the event
            // summary text instead.
            if (type == CalEvent::ACTIVE  &&  !newev->summary().isEmpty())
            {
                const Alarm::List& alarms = newev->alarms();
                for (Alarm::Ptr alarm : alarms)
                {
                    if (alarm->type() == Alarm::Display  &&  alarm->text().isEmpty())
                        alarm->setText(newev->summary());
                }
                newev->setSummary(QString());   // KAlarm only uses summary for template names
            }

            // Give the event a new ID and add it to the calendars
            newev->setUid(CalEvent::uid(CalFormat::createUniqueId(), type));
            KAEvent* newEvent = new KAEvent(newev);
            if (!AkonadiModel::instance()->addEvent(*newEvent, *coll))
                success = false;
        }
```

#### AUTO 


```{c}
auto tabgroup = new StackedGroup(mTabs);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
    {
        if (mResourceMap[key].contains(event.id()))
            deleteEventInternal(event, resource, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Person &addr : addresses) {
        if (!addr.email().isEmpty()) {
            append(addr);
        }
    }
```

#### AUTO 


```{c}
auto groupLayout = new QVBoxLayout(group);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
                alarm->setStartOffset(start.secsTo(alarm->time()));
```

#### AUTO 


```{c}
auto box = new QHBoxLayout(widget);
```

#### AUTO 


```{c}
auto f29box = new QHBoxLayout;
```

#### AUTO 


```{c}
auto* vlayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (const Alarm::Ptr &alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
        {
            CalEvent::Types t;
            Collection c(colId);
            if (colId == collection.id())
            {
                c = collection;    // update with latest data
                t = types;
            }
            else
            {
                model->refresh(c);    // update with latest data
                t = c.hasAttribute<CollectionAttribute>()
                  ? c.attribute<CollectionAttribute>()->standard() : CalEvent::EMPTY;
                if (!(t & types))
                    continue;
                t &= ~types;
            }
            const QModelIndex index = model->collectionIndex(c);
            model->setData(index, static_cast<int>(t), AkonadiModel::IsStandardRole);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
    {
        const QModelIndex nameIndex     = index.model()->index(index.row(), 0);
        const QModelIndex birthdayIndex = index.model()->index(index.row(), 1);
        const QString name = nameIndex.data(Qt::DisplayRole).toString();
        QDate date = birthdayIndex.data(mBirthdayModel_DateRole).toDate();
        date.setDate(thisYear, date.month(), date.day());
        if (date <= today)
            date.setDate(thisYear + 1, date.month(), date.day());
        KAEvent event(KADateTime(date, KADateTime::LocalZone),
                      (mName ? mName->text() : QString()),
                      mPrefix->text() + name + mSuffix->text(),
                      mFontColourButton->bgColour(), mFontColourButton->fgColour(),
                      mFontColourButton->font(), KAEvent::MESSAGE, mLateCancel->minutes(),
                      mFlags, true);
        float fadeVolume;
        int   fadeSecs;
        const float volume = mSoundPicker->volume(fadeVolume, fadeSecs);
        const int   repeatPause = mSoundPicker->repeatPause();
        event.setAudioFile(mSoundPicker->file().toDisplayString(), volume, fadeVolume, fadeSecs, repeatPause);
        const QVector<int> months(1, date.month());
        event.setRecurAnnualByDate(1, months, 0, KARecurrence::defaultFeb29Type(), -1, QDate());
        event.setRepetition(mSubRepetition->repetition());
        event.setNextOccurrence(todayStart);
        if (reminder)
            event.setReminder(reminder, false);
        if (mSpecialActionsButton)
            event.setActions(mSpecialActionsButton->preAction(),
                             mSpecialActionsButton->postAction(),
                             mSpecialActionsButton->options());
        event.endChanges();
        list.append(event);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceId id : resourceIds)
    {
        Resource resource = Resources::resource(id);
        if (!mResourceNodes.contains(resource))
            addResource(resource);
    }
```

#### AUTO 


```{c}
const auto dtlist = d->mRecurrence.rDateTimes();
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
    {
        Resource res = AkonadiModel::instance()->resource(colId);
        if (res.configName() == resourceName)
            return res.id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : std::as_const(*mUndos))
    {
        switch (item->calendar())
        {
            case CalEvent::ACTIVE:
                return i18nc("@info", "Delete multiple alarms");
            case CalEvent::TEMPLATE:
                return i18nc("@info", "Delete multiple templates");
            case CalEvent::ARCHIVED:
                break;    // check if they are ALL archived
            default:
                return QString();
        }
    }
```

#### AUTO 


```{c}
auto box = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length && txt[i].isDigit()) {
                        ;
                    }
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (const Alarm::Ptr &alarm : alarms) {     //clazy:exclude=range-loop   Can't use reference because 'alarms' is const
                    if (alarm->type() == Alarm::Display) {
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                    }
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     QLocale::c().toString(dt, dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : eventlist)
    {
        if (!event.enabled())
        {
            disabled = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& res : resources)
    {
        if (res.location() == url)
        {
            const QString path = url.toDisplayString(QUrl::PrettyDecoded | QUrl::PreferLocalFile);
            qCWarning(KALARM_LOG) << "FileResourceCreator::validateFileUrl: Duplicate path for new resource:" << path;
            return xi18nc("@info", "Error!  The file <filename>%1</filename> is already used by an existing resource.", path);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* act : actions)
        {
            if (act->data().toInt() == AlarmListModel::TimeToColumn)
            {
                act->setEnabled(false);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : list)
    {
        if (item->id() == id)
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            // Read the resource configuration parameters from the config
            const KConfigGroup configGroup = config.group(QLatin1String("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            const char* pathKey = nullptr;
            FileResourceSettings::StorageType storageType;
            if (resourceType == QLatin1String("file"))
            {
                storageType = FileResourceSettings::File;
                pathKey = "CalendarURL";
            }
            else if (resourceType == QLatin1String("dir"))
            {
                storageType = FileResourceSettings::Directory;
                pathKey = "CalendarURL";
            }
            else if (resourceType == QLatin1String("remote"))
            {
                storageType = FileResourceSettings::File;
                pathKey = "DownloadUrl";
            }
            else
            {
                qCWarning(KALARM_LOG) << "CalendarCreator: Invalid resource type:" << resourceType;
                continue;   // unknown resource type - can't convert
            }

            const QUrl url = QUrl::fromUserInput(configGroup.readPathEntry(pathKey, QString()));
            CalEvent::Type alarmType = CalEvent::EMPTY;
            switch (configGroup.readEntry("AlarmType", (int)0))
            {
                case 1:  alarmType = CalEvent::ACTIVE;    break;
                case 2:  alarmType = CalEvent::ARCHIVED;  break;
                case 4:  alarmType = CalEvent::TEMPLATE;  break;
                default:
                    qCWarning(KALARM_LOG) << "FileResourceMigrator::migrateKResources: Invalid alarm type for resource";
                    continue;
            }
            const QString name  = configGroup.readEntry("ResourceName", QString());
            const bool enabled  = configGroup.readEntry("ResourceIsActive", false);
            const bool standard = configGroup.readEntry("Standard", false);
            qCDebug(KALARM_LOG) << "FileResourceMigrator::migrateKResources: Migrating:" << name << ", type=" << alarmType << ", path=" << url.toString();
            FileResourceSettings::Ptr settings(new FileResourceSettings(
                          storageType, url, alarmType, name,
                          configGroup.readEntry("Color", QColor()),
                          (enabled ? alarmType : CalEvent::EMPTY),
                          (standard ? alarmType : CalEvent::EMPTY),
                          configGroup.readEntry("ResourceIsReadOnly", true)));
            Resource resource = FileResourceConfigManager::addResource(settings);

            // Update the calendar to the current KAlarm format if necessary,
            // and if the user agrees.
            auto updater = new FileResourceCalendarUpdater(resource, true, this);
            connect(updater, &QObject::destroyed, this, &FileResourceMigrator::checkIfComplete);
            updater->update();   // note that 'updater' will auto-delete when finished

            mExistingAlarmTypes |= alarmType;
        }
```

#### AUTO 


```{c}
auto* updater = new FileResourceCalendarUpdater(resource, true, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Person& address : addresses)
    {
        const QByteArray email = address.email().toLocal8Bit();
        const char* em = email.constData();
        if (!email.isEmpty()
        &&  HeaderParsing::parseAddress(em, em + email.length(), addr))
        {
            const QString domain = addr.mailboxList.at(0).addrSpec().domain;
            if (!domain.isEmpty()  &&  domain != localhost  &&  domain != hostname)
            {
                KAMessageBox::information(MainWindow::mainMainWindow(), i18nc("@info", "An email has been queued to be sent"), QString(), Preferences::EMAIL_QUEUED_NOTIFY);
                return;
            }
        }
    }
```

#### AUTO 


```{c}
auto* from = new KMime::Headers::From;
```

#### AUTO 


```{c}
auto grid = new QGridLayout(w);
```

#### AUTO 


```{c}
auto statJob = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatDetail::Basic, KIO::HideProgressInfo);
```

#### AUTO 


```{c}
const auto oldUnits = static_cast<Units>(mUnitsCombo->currentIndex() + mDateOnlyOffset);
```

#### AUTO 


```{c}
auto it = mResourceNodes.find(resource);
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecurrenceRule* rule : rulelist)
    {
        if (rule->recursOn(dt, Private::toTimeZone(timeSpec)))
            return true;
    }
```

#### AUTO 


```{c}
const auto& dateRange = mFilterDates[i];
```

#### AUTO 


```{c}
auto* boxLayout = new QHBoxLayout(w);
```

#### AUTO 


```{c}
auto recurScroll = new StackedScrollWidget(mTabScrollGroup);
```

#### AUTO 


```{c}
const auto l = d->mRecurrence.timesInInterval(start.qDateTime(), end.qDateTime());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent* event : events)
    {
        deleteEventInternal(*event);
    }
```

#### AUTO 


```{c}
const auto* akres = resource<AkonadiResource>(res);
```

#### AUTO 


```{c}
auto* topGeneral = new StackedWidgetT<QWidget>(tabgroup);
```

#### AUTO 


```{c}
auto itemBox = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                if (!mUid.isEmpty())
                {
                    if (item.mimeType() == mMimeType  &&  item.hasPayload<KCalendarCore::Event::Ptr>())
                    {
                        const KCalendarCore::Event::Ptr kcalEvent = item.payload<KCalendarCore::Event::Ptr>();
                        if (kcalEvent->uid() != mUid)
                            continue;
                    }
                }
                else if (mGid.isEmpty())
                    continue;
                auto djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs.value(job);
                connect(djob, &ItemDeleteJob::result, this, &AkonadiCollectionSearch::itemDeleteResult);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : std::as_const(it.value()))
        {
            if (!res.addEvent(event))
                success = false;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id id : qAsConst(collectionIds))
        addCollection(Collection(id));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                if (!mUid.isEmpty())
                {
                    if (item.mimeType() == mMimeType  &&  item.hasPayload<Event::Ptr>())
                    {
                        const Event::Ptr kcalEvent = item.payload<Event::Ptr>();
                        if (kcalEvent->uid() != mUid)
                            continue;
                    }
                }
                else if (mGid.isEmpty())
                    continue;
                ItemDeleteJob* djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs[job];
                connect(djob, &ItemDeleteJob::result, this, &CollectionSearch::itemDeleteResult);
            }
```

#### AUTO 


```{c}
auto vlayout = new QVBoxLayout(mButtonBox);
```

#### AUTO 


```{c}
auto* job = new ItemModifyJob(qitem);
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource, mAgentInstance.identifier());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : cols)
            {
                if (c.remoteId() == path)
                {
                    qCWarning(KALARM_LOG) << "AkonadiResourceCreator::agentInstanceCreated: Duplicate path for new resource:" << path;
                    AgentManager::self()->removeInstance(mAgentInstance);
                    const QUrl url = QUrl::fromUserInput(path, QString(), QUrl::AssumeLocalFile);
                    if (url.isLocalFile())
                        path = url.path();
                    KMessageBox::sorry(nullptr, xi18nc("@info", "<para>The file or directory is already used by an existing resource:</para><para><filename>%1</filename></para>", path));
                    Q_EMIT finished(this, false);
                    return;
                }
            }
```

#### AUTO 


```{c}
auto event = new KAEvent(kcalevent);
```

#### AUTO 


```{c}
auto job = qobject_cast<Akonadi::CollectionFetchJob*>(j);
```

#### AUTO 


```{c}
auto inst = new FileResourceDataModel(parent);
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (Collection::Id colId : colIds)
        {
            CalEvent::Types t;
            Collection c(colId);
            Resource res = model->resource(colId);
            if (colId == resource.id())
                t = types;
            else
            {
                t = res.configStandardTypes();
                if (!(t & types))
                    continue;
                t &= ~types;
            }
            res.configSetStandard(t);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms)
            {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList alflags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty())
                {
                    alflags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty())
                {
                    alflags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty())
                {
                    alflags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty())
                {
                    alflags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!alflags.isEmpty())
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, alflags.join(KAEventPrivate::SC));

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset())
                    continue;
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0)
                {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE))
                {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0)
                    {
                        alarm->setStartOffset(0);
                        converted = true;
                    }
                    else if (offset < 0)
                        reminder = reminderToString(offset / 60);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : qAsConst(mEventList))
    {
        mEventMap.remove(event->id());
        delete event;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& alarm : alarms)
                            std::cout << alarm.toUtf8().constData() << std::endl;
```

#### AUTO 


```{c}
auto newerr = static_cast<KAEvent::CmdErrType>(event.commandError() & ~err);
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent& ev : list)
        ev.setResourceId(id);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Resource& resource : resources)
            mUi->mergeResource->addItem(resource.displayName(), QVariant(resource.id()));
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : qAsConst(mItems))
    {
        if (item->isEmpty())
            continue;
        const QSize size = item->sizeHint();
        int right = x + size.width();
        if (right > rect.right()  &&  x > rect.x())
        {
            x = rect.x();
            y = y + yrow + verticalSpacing();
            right = x + size.width();
            yrow = size.height();
        }
        else
            yrow = qMax(yrow, size.height());
        items.append(item);
        posn.append(QRect(QPoint(x, y), size));
        x = right + horizontalSpacing();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KHolidays::Holiday& holiday : list)
            if (holiday.dayType() == KHolidays::Holiday::NonWorkday)
                nonWorkHolidays += holiday.observedStartDate();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& pr : list)
                    {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE)
                            preFlags << KAEventPrivate::AT_LOGIN_TYPE;
                        else if (pr == ARCHIVE_REMINDER_ONCE_TYPE)
                            reminderOnce = true;
                        else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-')))
                            reminder = pr;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr kcalevent : kcalevents)
    {
        if (kcalevent->alarms().isEmpty())
            continue;    // ignore events without alarms

        KAEvent* event = new KAEvent(kcalevent);
        if (!event->isValid())
        {
            qCWarning(KALARM_LOG) << "AlarmCalendar::updateDisplayKAEvents: Ignoring unusable event" << kcalevent->uid();
            delete event;
            continue;    // ignore events without usable alarms
        }
        event->setCollectionId(key);
        events += event;
        mEventMap[EventId(key, kcalevent->uid())] = event;
    }
```

#### AUTO 


```{c}
auto* hlayout = new QHBoxLayout(mCheckboxFrame);
```

#### AUTO 


```{c}
auto* text = new MessageText(topWidget);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
        {
            if (event.enabled()  &&  (event.category() & types))
            {
                // The event has an enabled alarm type.
                // Find all its recurrences/repetitions within the time period.
                DateTime nextDt;
                for (KADateTime from = before;  ;  )
                {
                    event.nextOccurrence(from, nextDt, KAEvent::RETURN_REPETITION);
                    if (!nextDt.isValid())
                        break;
                    from = nextDt.effectiveKDateTime().toTimeSpec(timeSpec);
                    if (from > to)
                        break;
                    if (!event.excludedByWorkTimeOrHoliday(from))
                    {
                        mEventDates += from.date();
                        if (mEventDates.count() >= NUMDAYS)
                            break;   // all days have alarms due
                    }

                    // If the alarm recurs more than once per day, don't waste
                    // time checking any more occurrences for the same day.
                    from.setTime(QTime(23,59,0));
                }
                if (mEventDates.count() >= NUMDAYS)
                    break;   // all days have alarms due
            }
        }
```

#### AUTO 


```{c}
auto* tabgroup = new StackedGroupT<QWidget>(mTabs);
```

#### AUTO 


```{c}
auto instance
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
    {
        if (event->category() != CalEvent::ACTIVE
        ||  mPendingAlarms.contains(event->id()))
            continue;
        const KADateTime dt = event->nextTrigger(KAEvent::ALL_TRIGGER).effectiveKDateTime();
        if (dt.isValid()  &&  (!earliest || dt < earliestTime))
        {
            earliestTime = dt;
            earliest = event;
        }
    }
```

#### AUTO 


```{c}
auto statJob = KIO::stat(url);
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarUpdater* instance : mInstances)
    {
        if (instance->mResourceId == id)
            return true;
    }
```

#### AUTO 


```{c}
auto* ev = new KAEvent(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this, deferButton](const QAbstractButton* btn)
                {
                    if (btn == deferButton)
                        slotCancelDeferral();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, deferButton](QAbstractButton* btn)
            {
                if (btn == deferButton)
                    slotCancelDeferral();
            }
```

#### AUTO 


```{c}
auto* topLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
                const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance& agent : agents)
    {
        const QString type = agent.type().identifier();
        if (type == KALARM_DIR_RESOURCE)
        {
            // Fetch the resource's collection to determine its alarm types
            Akonadi::CollectionFetchJob* job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::FirstLevel);
            job->fetchScope().setResource(agent.identifier());
            mFetchesPending << job;
            connect(job, &KJob::result, this, &FileResourceMigrator::collectionFetchResult);

            mMigrateKResources = false;   // ignore KResources if Akonadi resources exist
        }
    }
```

#### AUTO 


```{c}
auto dlg = qobject_cast<EditAudioAlarmDlg*>(editDlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : qAsConst(sorted))
    {
        QAction* act = m->addAction(name);
        mOriginalTexts[act] = name;   // keep original text, since action text has shortcuts added
    }
```

#### AUTO 


```{c}
const auto l = d->mRecurrence.timesInInterval(k2q(start), k2q(end));
```

#### AUTO 


```{c}
auto proxyModel = static_cast<KDescendantsProxyModel*>(sourceModel());
```

#### RANGE FOR STATEMENT 


```{c}
for (KAEvent* event : events)
        {
            if (event->category() == CalEvent::ACTIVE  &&  event->repeatAtLogin())
                atlogins += event;
        }
```

#### AUTO 


```{c}
auto* browseButton = new QPushButton(box);
```

#### AUTO 


```{c}
auto it = mEventNodes.find(event.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &abv : abvs) {
                if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                    ++matchedTransitions;
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : cols)
            {
                if (c.remoteId() == path)
                {
                    qCWarning(KALARM_LOG) << "AkonadiResourceCreator::agentInstanceCreated: Duplicate path for new resource:" << path;
                    AgentManager::self()->removeInstance(mAgentInstance);
                    const QUrl url = QUrl::fromUserInput(path, QString(), QUrl::AssumeLocalFile);
                    if (url.isLocalFile())
                        path = url.path();
                    KMessageBox::sorry(nullptr, xi18nc("@info", "<para>The file or directory is already used by an existing resource:</para><para><filename>%1</filename></para>", path));
                    deleteLater();   // error result
                    return;
                }
            }
```

#### AUTO 


```{c}
auto* statJob = static_cast<KIO::StatJob*>(job);
```

#### AUTO 


```{c}
const auto resourceToRemove = saveThis ? prevRes.resourceId : thisRes.resourceId;
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
        bool done = false;
        switch (alarm->type()) {
        case Alarm::Display:
        case Alarm::Procedure:
            audioOnly = false;
            done = true;   // exit from the 'for' loop
            break;
        case Alarm::Audio:
            audioOnly = true;
            break;
        default:
            break;
        }
        if (done) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UndoItem* item : std::as_const(*mUndos))
    {
        switch (item->calendar())
        {
            case CalEvent::ACTIVE:
                return i18nc("@info", "Delete multiple alarms");
            case CalEvent::TEMPLATE:
                return i18nc("@info", "Delete multiple templates");
            case CalEvent::ARCHIVED:
                break;    // check if they are ALL archived
            default:
                return {};
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString& g1, const QString& g2)
                  {
                      return g1.mid(9).toInt() < g2.mid(9).toInt();
                  }
```

#### AUTO 


```{c}
auto newit = newEvents.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : zoneIds)
            {
                const QTimeZone z(zoneId);
                qdt.setTimeZone(z);
                if (z.abbreviation(qdt) == zoneAbbrev)
                {
                    // TODO: This may not find abbreviations for second occurrence of
                    // the time zone time, after a daylight savings time shift.
                    int offset2;
                    int offset = offsetAtZoneTime(z, qdt, &offset2);
                    if (offset == InvalidOffset)
                        return {};
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid())
                    {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous || offset != utcOffset)
                            return {};
                        useUtcOffset = true;
                    }
                    else
                    {
                        zone = z;
                        utcOffset = offset;
                    }
                }
            }
```

#### AUTO 


```{c}
auto statJob = KIO::stat(mUrl.url(), KIO::StatJob::SourceSide, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zone : zones)
        if (zone != utc)
        {
            mZoneNames << zone;
            addItem(i18n(zone.constData()).replace(QLatin1Char('_'), QLatin1Char(' ')));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Event::Ptr event : events) {
        const Alarm::List alarms = event->alarms();
        if (alarms.isEmpty()) {
            continue;    // KAlarm isn't interested in events without alarms
        }
        event->startUpdates();   // prevent multiple update notifications
        const bool readOnly = event->isReadOnly();
        if (readOnly) {
            event->setReadOnly(false);
        }
        QStringList cats = event->categories();
        bool addLateCancel = false;
        QStringList flags;

        if (pre_0_7  &&  event->allDay()) {
            // It's a KAlarm pre-0.7 calendar file.
            // Ensure that when the calendar is saved, the alarm time isn't lost.
            event->setAllDay(false);
        }

        if (pre_0_9) {
            /*
             * It's a KAlarm pre-0.9 calendar file.
             * All alarms were of type DISPLAY. Instead of the X-KDE-KALARM-TYPE
             * alarm property, characteristics were stored as a prefix to the
             * alarm DESCRIPTION property, as follows:
             *   SEQNO;[FLAGS];TYPE:TEXT
             * where
             *   SEQNO = sequence number of alarm within the event
             *   FLAGS = C for late-cancel, L for repeat-at-login, D for deferral
             *   TYPE = TEXT or FILE or CMD
             *   TEXT = message text, file name/URL or command
             */
            for (Alarm::Ptr alarm : alarms) {
                bool atLogin    = false;
                bool deferral   = false;
                bool lateCancel = false;
                KAAlarm::Action action = KAAlarm::MESSAGE;
                const QString txt = alarm->text();
                const int length = txt.length();
                int i = 0;
                if (txt[0].isDigit()) {
                    while (++i < length  &&  txt[i].isDigit()) ;
                    if (i < length  &&  txt[i++] == SEPARATOR) {
                        while (i < length) {
                            const QChar ch = txt[i++];
                            if (ch == SEPARATOR) {
                                break;
                            }
                            if (ch == LATE_CANCEL_CODE) {
                                lateCancel = true;
                            } else if (ch == AT_LOGIN_CODE) {
                                atLogin = true;
                            } else if (ch == DEFERRAL_CODE) {
                                deferral = true;
                            }
                        }
                    } else {
                        i = 0;    // invalid prefix
                    }
                }
                if (txt.indexOf(TEXT_PREFIX, i) == i) {
                    i += TEXT_PREFIX.length();
                } else if (txt.indexOf(FILE_PREFIX, i) == i) {
                    action = KAAlarm::FILE;
                    i += FILE_PREFIX.length();
                } else if (txt.indexOf(COMMAND_PREFIX, i) == i) {
                    action = KAAlarm::COMMAND;
                    i += COMMAND_PREFIX.length();
                } else {
                    i = 0;
                }
                const QString altxt = txt.mid(i);

                QStringList types;
                switch (action) {
                case KAAlarm::FILE:
                    types += KAEventPrivate::FILE_TYPE;
                    // fall through to MESSAGE
                    Q_FALLTHROUGH();
                case KAAlarm::MESSAGE:
                    alarm->setDisplayAlarm(altxt);
                    break;
                case KAAlarm::COMMAND:
                    setProcedureAlarm(alarm, altxt);
                    break;
                case KAAlarm::EMAIL:     // email alarms were introduced in KAlarm 0.9
                case KAAlarm::AUDIO:     // audio alarms (with no display) were introduced in KAlarm 2.3.2
                    break;
                }
                if (atLogin) {
                    types += KAEventPrivate::AT_LOGIN_TYPE;
                    lateCancel = false;
                } else if (deferral) {
                    types += KAEventPrivate::TIME_DEFERRAL_TYPE;
                }
                if (lateCancel) {
                    addLateCancel = true;
                }
                if (types.count() > 0) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QLatin1Char(',')));
                }

                if (pre_0_7  &&  alarm->repeatCount() > 0  &&  alarm->snoozeTime().value() > 0) {
                    // It's a KAlarm pre-0.7 calendar file.
                    // Minutely recurrences were stored differently.
                    Recurrence *recur = event->recurrence();
                    if (recur  &&  recur->recurs()) {
                        recur->setMinutely(alarm->snoozeTime().asSeconds() / 60);
                        recur->setDuration(alarm->repeatCount() + 1);
                        alarm->setRepeatCount(0);
                        alarm->setSnoozeTime(0);
                    }
                }

                if (adjustSummerTime) {
                    // The calendar file was written by the KDE 3.0.0 version of KAlarm 0.5.7.
                    // Summer time was ignored when converting to UTC.
                    KADateTime dt(alarm->time());
                    const qint64 t64 = dt.toSecsSinceEpoch();
                    const time_t t = (static_cast<quint64>(t64) >= uint(-1)) ? uint(-1) : static_cast<uint>(t64);
                    const struct tm *dtm = localtime(&t);
                    if (dtm->tm_isdst) {
                        dt = dt.addSecs(-3600);
                        alarm->setTime(dt.qDateTime());
                    }
                }
            }
        }

        if (pre_0_9_2) {
            /*
             * It's a KAlarm pre-0.9.2 calendar file.
             * For the archive calendar, set the CREATED time to the DTEND value.
             * Convert date-only DTSTART to date/time, and add category "DATE".
             * Set the DTEND time to the DTSTART time.
             * Convert all alarm times to DTSTART offsets.
             * For display alarms, convert the first unlabelled category to an
             * X-KDE-KALARM-FONTCOLOR property.
             * Convert BEEP category into an audio alarm with no audio file.
             */
            if (CalEvent::status(event) == CalEvent::ARCHIVED) {
                event->setCreated(event->dtEnd());
            }
            QDateTime start = event->dtStart();
            if (event->allDay()) {
                start.setTime(QTime(0, 0));
                flags += KAEventPrivate::DATE_ONLY_FLAG;
            }
            event->setDtEnd(QDateTime());

            for (Alarm::Ptr alarm : alarms) {
                alarm->setStartOffset(start.secsTo(alarm->time()));
            }

            if (!cats.isEmpty()) {
                for (Alarm::Ptr alarm : alarms) {
                    if (alarm->type() == Alarm::Display)
                        alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FONT_COLOUR_PROPERTY,
                                                 QStringLiteral("%1;;").arg(cats.at(0)));
                }
                cats.removeAt(0);
            }

            {
                int i = cats.indexOf(BEEP_CATEGORY);
                if (i >= 0) {
                    cats.removeAt(i);

                    Alarm::Ptr alarm = event->newAlarm();
                    alarm->setEnabled(true);
                    alarm->setAudioAlarm();
                    QDateTime dt = event->dtStart();    // default

                    // Parse and order the alarms to know which one's date/time to use
                    KAEventPrivate::AlarmMap alarmMap;
                    KAEventPrivate::readAlarms(event, &alarmMap);
                    KAEventPrivate::AlarmMap::ConstIterator it = alarmMap.constBegin();
                    if (it != alarmMap.constEnd()) {
                        dt = it.value().alarm->time();
                        break;
                    }
                    alarm->setStartOffset(start.secsTo(dt));
                    break;
                }
            }
        }

        if (pre_1_1_1) {
            /*
             * It's a KAlarm pre-1.1.1 calendar file.
             * Convert simple LATECANCEL category to LATECANCEL:n where n = minutes late.
             */
            int i;
            while ((i = cats.indexOf(LATE_CANCEL_CAT)) >= 0) {
                cats.removeAt(i);
                addLateCancel = true;
            }
        }

        if (pre_1_2_1) {
            /*
             * It's a KAlarm pre-1.2.1 calendar file.
             * Convert email display alarms from translated to untranslated header prefixes.
             */
            for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
        }

        if (pre_1_3_0) {
            /*
             * It's a KAlarm pre-1.3.0 calendar file.
             * Convert simple TMPLDEFTIME category to TMPLAFTTIME:n where n = minutes after.
             */
            int i;
            while ((i = cats.indexOf(TEMPL_DEF_TIME_CAT)) >= 0) {
                cats.removeAt(i);
                (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += QStringLiteral("0");
            }
        }

        if (pre_1_3_1) {
            /*
             * It's a KAlarm pre-1.3.1 calendar file.
             * Convert simple XTERM category to LOG:xterm:
             */
            int i;
            while ((i = cats.indexOf(EXEC_IN_XTERM_CAT)) >= 0) {
                cats.removeAt(i);
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, KAEventPrivate::xtermURL);
            }
        }

        if (pre_1_9_0) {
            /*
             * It's a KAlarm pre-1.9 calendar file.
             * Add the X-KDE-KALARM-STATUS custom property.
             * Convert KAlarm categories to custom fields.
             */
            CalEvent::setStatus(event, CalEvent::status(event));
            for (int i = 0;  i < cats.count();) {
                const QString cat = cats.at(i);
                if (cat == DATE_ONLY_CATEGORY) {
                    flags += KAEventPrivate::DATE_ONLY_FLAG;
                } else if (cat == CONFIRM_ACK_CATEGORY) {
                    flags += KAEventPrivate::CONFIRM_ACK_FLAG;
                } else if (cat == EMAIL_BCC_CATEGORY) {
                    flags += KAEventPrivate::EMAIL_BCC_FLAG;
                } else if (cat == KORGANIZER_CATEGORY) {
                    flags += KAEventPrivate::KORGANIZER_FLAG;
                } else if (cat.startsWith(DEFER_CATEGORY)) {
                    (flags += KAEventPrivate::DEFER_FLAG) += cat.mid(DEFER_CATEGORY.length());
                } else if (cat.startsWith(TEMPL_AFTER_TIME_CATEGORY)) {
                    (flags += KAEventPrivate::TEMPL_AFTER_TIME_FLAG) += cat.mid(TEMPL_AFTER_TIME_CATEGORY.length());
                } else if (cat.startsWith(LATE_CANCEL_CATEGORY)) {
                    (flags += KAEventPrivate::LATE_CANCEL_FLAG) += cat.mid(LATE_CANCEL_CATEGORY.length());
                } else if (cat.startsWith(AUTO_CLOSE_CATEGORY)) {
                    (flags += KAEventPrivate::AUTO_CLOSE_FLAG) += cat.mid(AUTO_CLOSE_CATEGORY.length());
                } else if (cat.startsWith(KMAIL_SERNUM_CATEGORY)) {
                    (flags += KAEventPrivate::KMAIL_ITEM_FLAG) += cat.mid(KMAIL_SERNUM_CATEGORY.length());
                } else if (cat == ARCHIVE_CATEGORY) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, QStringLiteral("0"));
                } else if (cat.startsWith(ARCHIVE_CATEGORIES)) {
                    event->setCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY, cat.mid(ARCHIVE_CATEGORIES.length()));
                } else if (cat.startsWith(LOG_CATEGORY)) {
                    event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::LOG_PROPERTY, cat.mid(LOG_CATEGORY.length()));
                } else {
                    ++i;   // Not a KAlarm category, so leave it
                    continue;
                }
                cats.removeAt(i);
            }
        }

        if (pre_1_9_2) {
            /*
             * It's a KAlarm pre-1.9.2 calendar file.
             * Convert from clock time to the local system time zone.
             */
            event->shiftTimes(localZone, localZone);
            converted = true;
        }

        if (addLateCancel) {
            (flags += KAEventPrivate::LATE_CANCEL_FLAG) += QStringLiteral("1");
        }
        if (!flags.isEmpty()) {
            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
        }
        event->setCategories(cats);

        if ((pre_1_4_14  || (pre_1_9_7 && !pre_1_9_0))
        &&  event->recurrence()  &&  event->recurrence()->recurs()) {
            /*
             * It's a KAlarm pre-1.4.14 or KAlarm 1.9 series pre-1.9.7 calendar file.
             * For recurring events, convert the main alarm offset to an absolute
             * time in the X-KDE-KALARM-NEXTRECUR property, and set main alarm
             * offsets to zero, and convert deferral alarm offsets to be relative to
             * the next recurrence.
             */
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
            const QStringList flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
            const bool dateOnly = flags.contains(KAEventPrivate::DATE_ONLY_FLAG);
            KADateTime startDateTime(event->dtStart());
            if (dateOnly) {
                startDateTime.setDateOnly(true);
            }
            // Convert the main alarm and get the next main trigger time from it
            KADateTime nextMainDateTime;
            bool mainExpired = true;
            for (Alarm::Ptr alarm : alarms) {
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                // Find whether the alarm triggers at the same time as the main
                // alarm, in which case its offset needs to be set to 0. The
                // following trigger with the main alarm:
                //  - Additional audio alarm
                //  - PRE_ACTION_TYPE
                //  - POST_ACTION_TYPE
                //  - DISPLAYING_TYPE
                bool mainAlarm = true;
                QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
                if (mainAlarm) {
                    if (mainExpired) {
                        // All main alarms are supposed to be at the same time, so
                        // don't readjust the event's time for subsequent main alarms.
                        mainExpired = false;
                        nextMainDateTime = KADateTime(alarm->time());
                        nextMainDateTime.setDateOnly(dateOnly);
                        nextMainDateTime = nextMainDateTime.toTimeSpec(startDateTime);
                        if (nextMainDateTime != startDateTime) {
                            QDateTime dt = nextMainDateTime.qDateTime();
                            event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::NEXT_RECUR_PROPERTY,
                                                     dt.toString(dateOnly ? QStringLiteral("yyyyMMdd") : QStringLiteral("yyyyMMddThhmmss")));
                        }
                    }
                    alarm->setStartOffset(0);
                    converted = true;
                }
            }
            int adjustment;
            if (mainExpired) {
                // It's an expired recurrence.
                // Set the alarm offset relative to the first actual occurrence
                // (taking account of possible exceptions).
                KADateTime dt(event->recurrence()->getNextDateTime(startDateTime.qDateTime().addDays(-1)));
                dt.setDateOnly(dateOnly);
                adjustment = startDateTime.secsTo(dt);
            } else {
                adjustment = startDateTime.secsTo(nextMainDateTime);
            }
            if (adjustment) {
                // Convert deferred alarms
                for (Alarm::Ptr alarm : alarms) {
                    if (!alarm->hasStartOffset()) {
                        continue;
                    }
                    const QString property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList types = property.split(QLatin1Char(','), QString::SkipEmptyParts);
#else
                    const QStringList types = property.split(QLatin1Char(','), Qt::SkipEmptyParts);
#endif
                    for (const QString &type : types) {
                        if (type == KAEventPrivate::TIME_DEFERRAL_TYPE
                        ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE) {
                            alarm->setStartOffset(alarm->startOffset().asSeconds() - adjustment);
                            converted = true;
                            break;
                        }
                    }
                }
            }
        }

        if (pre_1_5_0  || (pre_1_9_9 && !pre_1_9_0)) {
            /*
             * It's a KAlarm pre-1.5.0 or KAlarm 1.9 series pre-1.9.9 calendar file.
             * Convert email identity names to uoids.
             */
            for (const Alarm::Ptr &alarm : alarms) {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty()) {
                    continue;
                }
                const uint id = Identities::identityUoid(name);
                if (id) {
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                }
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
        }

        if (pre_1_9_10) {
            /*
             * It's a KAlarm pre-1.9.10 calendar file.
             * Convert simple repetitions without a recurrence, to a recurrence.
             */
            if (KAEventPrivate::convertRepetition(event)) {
                converted = true;
            }
        }

        if (pre_2_2_9  || (pre_2_3_2 && !pre_2_3_0)) {
            /*
             * It's a KAlarm pre-2.2.9 or KAlarm 2.3 series pre-2.3.2 calendar file.
             * Set the time in the calendar for all date-only alarms to 00:00.
             */
            if (KAEventPrivate::convertStartOfDay(event)) {
                converted = true;
            }
        }

        if (pre_2_7_0) {
            /*
             * It's a KAlarm pre-2.7.0 calendar file.
             * Archive and at-login flags were stored in event's ARCHIVE property when the main alarm had expired.
             * Reminder parameters were stored in event's ARCHIVE property when no reminder was pending.
             * Negative reminder periods (i.e. alarm offset > 0) were invalid, so convert to 0.
             * Now store reminder information in FLAGS property, whether reminder is pending or not.
             * Move EMAILID, SPEAK, ERRCANCEL and ERRNOSHOW alarm properties into new FLAGS property.
             */
            bool flagsValid = false;
            QStringList flags;
            QString reminder;
            bool    reminderOnce = false;
            const QString prop = event->customProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            if (!prop.isEmpty()) {
                // Convert the event's ARCHIVE property to parameters in the FLAGS property
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                flags << KAEventPrivate::ARCHIVE_FLAG;
                flagsValid = true;
                if (prop != QLatin1String("0")) { // "0" was a dummy parameter if no others were present
                    // It's the archive property containing a reminder time and/or repeat-at-login flag.
                    // This was present when no reminder/at-login alarm was pending.
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    const QStringList list = prop.split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                    const QStringList list = prop.split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                    for (const QString &pr : list) {
                        if (pr == KAEventPrivate::AT_LOGIN_TYPE) {
                            flags << KAEventPrivate::AT_LOGIN_TYPE;
                        } else if (pr == ARCHIVE_REMINDER_ONCE_TYPE) {
                            reminderOnce = true;
                        } else if (!pr.isEmpty()  &&  !pr.startsWith(QChar::fromLatin1('-'))) {
                            reminder = pr;
                        }
                    }
                }
                event->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                event->removeCustomProperty(KACalendar::APPNAME, ARCHIVE_PROPERTY);
            }

            for (Alarm::Ptr alarm : alarms) {
                // Convert EMAILID, SPEAK, ERRCANCEL, ERRNOSHOW properties
                QStringList flags;
                QString property = alarm->customProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                if (!property.isEmpty()) {
                    flags << KAEventPrivate::EMAIL_ID_FLAG << property;
                    alarm->removeCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, SPEAK_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::SPEAK_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, SPEAK_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::CANCEL_ON_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, CANCEL_ON_ERROR_PROPERTY);
                }
                if (!alarm->customProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY).isEmpty()) {
                    flags << KAEventPrivate::DONT_SHOW_ERROR_FLAG;
                    alarm->removeCustomProperty(KACalendar::APPNAME, DONT_SHOW_ERROR_PROPERTY);
                }
                if (!flags.isEmpty()) {
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY, flags.join(KAEventPrivate::SC));
                }

                // Invalidate negative reminder periods in alarms
                if (!alarm->hasStartOffset()) {
                    continue;
                }
                property = alarm->customProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY);
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                QStringList types = property.split(QChar::fromLatin1(','), QString::SkipEmptyParts);
#else
                QStringList types = property.split(QChar::fromLatin1(','), Qt::SkipEmptyParts);
#endif
                const int r = types.indexOf(REMINDER_ONCE_TYPE);
                if (r >= 0) {
                    // Move reminder-once indicator from the alarm to the event's FLAGS property
                    types[r] = KAEventPrivate::REMINDER_TYPE;
                    alarm->setCustomProperty(KACalendar::APPNAME, KAEventPrivate::TYPE_PROPERTY, types.join(QChar::fromLatin1(',')));
                    reminderOnce = true;
                }
                if (r >= 0  ||  types.contains(KAEventPrivate::REMINDER_TYPE)) {
                    // The alarm is a reminder alarm
                    const int offset = alarm->startOffset().asSeconds();
                    if (offset > 0) {
                        alarm->setStartOffset(0);
                        converted = true;
                    } else if (offset < 0) {
                        reminder = reminderToString(offset / 60);
                    }
                }
            }
            if (!reminder.isEmpty()) {
                // Write reminder parameters into the event's FLAGS property
                if (!flagsValid) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, QString::SkipEmptyParts);
#else
                    flags = event->customProperty(KACalendar::APPNAME, KAEventPrivate::FLAGS_PROPERTY).split(KAEventPrivate::SC, Qt::SkipEmptyParts);
#endif
                }
                if (!flags.contains(KAEventPrivate::REMINDER_TYPE)) {
                    flags += KAEventPrivate::REMINDER_TYPE;
                    if (reminderOnce) {
                        flags += KAEventPrivate::REMINDER_ONCE_FLAG;
                    }
                    flags += reminder;
                }
            }
        }

        if (readOnly) {
            event->setReadOnly(true);
        }
        event->endUpdates();     // finally issue an update notification
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(kalarmWidgets);
```

#### AUTO 


```{c}
auto* fileBoxHLayout = new QHBoxLayout(mFileBox);
```

#### AUTO 


```{c}
auto bcc = new KMime::Headers::Bcc;
```

#### AUTO 


```{c}
auto newUndos = new Undo::List;
```

#### AUTO 


```{c}
auto* inst = new FileResourceDataModel(parent);
```

#### AUTO 


```{c}
auto* iface = AkonadiResource::getAgentInterface<Interface>(mAgent, mErrorMessage, this);
```

#### AUTO 


```{c}
auto* cmjob = new CollectionModifyJob(c, this);
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(topWidget);
```

#### AUTO 


```{c}
auto job = qobject_cast<CollectionFetchJob*>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTimeZone& tz : zoneList) {
                qdt.setTimeZone(tz);
                // TODO: This may not find abbreviations for second occurrence of
                // the time zone time, after a daylight savings time shift.
                if (tz.abbreviation(qdt) == zoneAbbrev) {
                    int offset2;
                    int offset = offsetAtZoneTime(tz, qdt, &offset2);
                    if (offset == InvalidOffset)
                        return KADateTime();
                    // Found a time zone which uses this abbreviation at the specified date/time
                    if (zone.isValid()) {
                        // Abbreviation is used by more than one time zone
                        if (!offsetIfAmbiguous  ||  offset != utcOffset)
                            return KADateTime();
                        useUtcOffset = true;
                    } else {
                        zone = tz;
                        utcOffset = offset;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* act : actions)
        {
            if (act->data().toInt() == AlarmListModel::TimeColumn)
            {
                act->setEnabled(false);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : std::as_const(eventsToAdd))
            {
                auto ev = new KAEvent(event);
                ev->setResourceId(resource.id());
                Node* node = new Node(ev, resource);
                resourceEventNodes += node;
                mEventNodes[ev->id()] = node;
            }
```

#### AUTO 


```{c}
auto* djob = new ItemDeleteJob(item, this);
```

#### AUTO 


```{c}
auto mimeTypeFilter = new Akonadi::EntityMimeTypeFilterModel(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& id : keys)
        {
            const KConfigGroup configGroup = config.group(QStringLiteral("Resource_") + id);
            const QString resourceType = configGroup.readEntry("ResourceType", QString());
            QString agentType;
            if (resourceType == QStringLiteral("file"))
                agentType = KALARM_RESOURCE;
            else if (resourceType == QStringLiteral("dir"))
                agentType = KALARM_DIR_RESOURCE;
            else if (resourceType == QStringLiteral("remote"))
                agentType = KALARM_RESOURCE;
            else
                continue;   // unknown resource type - can't convert

            creator = new CalendarCreator(resourceType, configGroup);
            if (!creator->isValid())
                delete creator;
            else
            {
                connect(creator, &CalendarCreator::finished, this, &CalendarMigrator::calendarCreated);
                connect(creator, &CalendarCreator::creating, this, &CalendarMigrator::creatingCalendar);
                mExistingAlarmTypes |= creator->alarmType();
                mCalendarsPending << creator;
                creator->createAgent(agentType, this);
            }
        }
```

#### AUTO 


```{c}
auto recurTabLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &type : types) {
                    if (type == KAEventPrivate::AT_LOGIN_TYPE
                    ||  type == KAEventPrivate::TIME_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::DATE_DEFERRAL_TYPE
                    ||  type == KAEventPrivate::REMINDER_TYPE
                    ||  type == REMINDER_ONCE_TYPE) {
                        mainAlarm = false;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : autostartDirs)
    {
        const QString file = dir + QLatin1String("/autostart/") + AUTOSTART_FILE;
        if (QFile::exists(file))
        {
            QFileInfo info(file);
            if (info.isReadable())
            {
                autostartFile = file;
                existingRO = !info.isWritable();
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Alarm::Ptr alarm : alarms) {
                if (alarm->type() == Alarm::Display) {
                    const QString oldtext = alarm->text();
                    const QString newtext = AlarmText::toCalendarText(oldtext);
                    if (oldtext != newtext) {
                        alarm->setDisplayAlarm(newtext);
                    }
                }
            }
```

#### AUTO 


```{c}
auto* freqLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection& c : collections)
        {
            if (c.contentMimeTypes().contains(mMimeType))
            {
                ItemFetchJob* ijob;
                if (!mGid.isEmpty())
                {
                    // Search for all Items with the specified GID
                    Item item;
                    item.setGid(mGid);
                    ijob = new ItemFetchJob(item, this);
                    ijob->setCollection(c);
                }
                else if (!mUid.isEmpty())
                {
                    // Search for all Events with the specified UID
                    ijob = new ItemFetchJob(c, this);
                    ijob->fetchScope().fetchFullPayload(true);
                }
                else
                {
                    mCollections << c;
                    continue;
                }
                mItemFetchJobs[ijob] = c.id();
                connect(ijob, &ItemFetchJob::result, this, &AkonadiCollectionSearch::itemFetchResult);
            }
        }
```

#### AUTO 


```{c}
auto* parent = (Label*)parentWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { if (mAudioOwner == parent()) mAudioOwner = nullptr; }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr& alarm : alarms)
            {
                const QString name = alarm->customProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                if (name.isEmpty())
                    continue;
                const uint id = Identities::identityUoid(name);
                if (id)
                    alarm->setCustomProperty(KACalendar::APPNAME, EMAIL_ID_PROPERTY, QString::number(id));
                alarm->removeCustomProperty(KACalendar::APPNAME, KMAIL_ID_PROPERTY);
                converted = true;
            }
```

#### AUTO 


```{c}
auto topWindows = new QVBoxLayout(widget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KAEvent& event : events)
        eventCopies += event;
```

#### AUTO 


```{c}
auto data = new DeferDlgData(this, dlg);
```

#### AUTO 


```{c}
auto* recurTabLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& metaData : plugins)
    {
        qCDebug(KALARMPLUGINLIB_LOG) << "PluginManager::loadPlugins: found " << metaData.pluginId();
        if (pluginVersion() != metaData.version())
            qCWarning(KALARMPLUGINLIB_LOG) << "Error! Plugin" << metaData.name() << "has wrong version";
        else
        {
            // Load the plugin
            auto plugin = KPluginFactory::instantiatePlugin<PluginBase>(metaData, this).plugin;
            if (plugin)
            {
                if (metaData.pluginId() == QStringLiteral("akonadi"))
                    mAkonadiPlugin = (AkonadiPlugin*)plugin;
            }
        }
    }
```

#### AUTO 


```{c}
auto tz = QTimeZone(spec.timeZone().name().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item& item : items)
            {
                if (!mUid.isEmpty())
                {
                    if (item.mimeType() == mMimeType  &&  item.hasPayload<Event::Ptr>())
                    {
                        const Event::Ptr kcalEvent = item.payload<Event::Ptr>();
                        if (kcalEvent->uid() != mUid)
                            continue;
                    }
                }
                else if (mGid.isEmpty())
                    continue;
                auto* djob = new ItemDeleteJob(item, this);
                mItemDeleteJobs[djob] = mItemFetchJobs.value(job);
                connect(djob, &ItemDeleteJob::result, this, &AkonadiCollectionSearch::itemDeleteResult);
            }
```

