#### AUTO 


```{c}
auto dialog =
      new KConfigDialog(this, QStringLiteral("settings"), Settings::self());
```

#### AUTO 


```{c}
auto line = new QGraphicsLineItem(lineFromIndex(index));
```

#### AUTO 


```{c}
auto anim = new HighlightAnimation(lineFromIndex(index));
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto mainWindow = new KSquaresWindow;
```

#### AUTO 


```{c}
auto aiSettingsDialog = new QWidget;
```

#### AUTO 


```{c}
auto buttonBox =
      new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto animGroup = new QSequentialAnimationGroup(this);
```

#### AUTO 


```{c}
auto w = new QWidget;
```

#### AUTO 


```{c}
auto scoreTableModel = new QStandardItemModel(&scoresDialog);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close);
```

#### AUTO 


```{c}
auto displaySettingsDialog = new QWidget;
```

#### AUTO 


```{c}
auto demoWindow = new KSquaresDemoWindow;
```

#### AUTO 


```{c}
auto dot = new QGraphicsEllipseItem(QRectF(-2, -2, 4, 4));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto animation = new QPropertyAnimation(this, "opacity", this);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget;
```

