#### AUTO 


```{c}
auto widget = new MigrationStatusWidget(mScheduler, dlg);
```

#### AUTO 


```{c}
auto searchLine = new KLineEdit(this);
```

#### AUTO 


```{c}
const auto stdByMonthDayVector = std::vector<int>(bymonthdayVector.begin(), bymonthdayVector.end());
```

#### AUTO 


```{c}
auto job = new OXA::ObjectRequestJob(object, this);
```

#### AUTO 


```{c}
auto *fetchJob = new Akonadi::CollectionFetchJob(topLevelCollection, Akonadi::CollectionFetchJob::Recursive);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        qDebug() << "Item:" << item.url();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attachment &att : eAttachments) {
        Kolab::Attachment a;
        if (att.isUri()) {
            a.setUri(toStdString(att.uri()), toStdString(att.mimeType()));
        } else {
            a.setData(std::string(att.decodedData().data(), att.decodedData().size()), toStdString(att.mimeType()));
        }
        a.setLabel(toStdString(att.label()));
        attachments.push_back(a);
    }
```

#### AUTO 


```{c}
auto *replace = new ReplaceMessageJob(mMessage, mSession, mMailbox, uidNext, mOldUids, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::Address a : addresses) {
        addressee.removeAddress(a);
        a.setPostOfficeBox(QString()); //Not supported anymore
        addressee.insertAddress(a);
    }
```

#### AUTO 


```{c}
auto id = resp.item()[EwsItemFieldItemId].value<EwsId>();
```

#### AUTO 


```{c}
auto attr = new DefaultReminderAttribute();
```

#### AUTO 


```{c}
const auto reqResponses{req->responses()};
```

#### AUTO 


```{c}
auto *uidNext = c.attribute<UidNextAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : attachmentNames) {
        const Kolab::Attachment extracted = Mime::getAttachmentByName(name, msg);
        if (extracted.isValid()) {
            allAttachments.push_back(extracted);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : lst ) {
        addIfComplete(item);
    }
```

#### AUTO 


```{c}
auto *vboxLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(extraItems);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            emitError(job->errorText());
            return;
        }

        const auto json = QJsonDocument::fromJson(qobject_cast<KIO::StoredTransferJob *>(job)->data());
        const auto me = json.object();

        d->userName = me.value(QStringLiteral("name")).toString();
        d->id = me.value(QStringLiteral("id")).toString();
        d->wallet->writeMap(mIdentifier,
                            { { KWalletKeyToken, d->token },
                                { KWalletKeyName, d->userName },
                                { KWalletKeyId, d->id },
                                { KWalletKeyCookies, QString::fromUtf8(d->cookies) }});
        emitResult();
    }
```

#### AUTO 


```{c}
auto dependentItems = createJob->property("dependentItems").value<Akonadi::Item::List>();
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(dlg);
```

#### AUTO 


```{c}
auto *capJob = qobject_cast<KIMAP::CapabilitiesJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::AccountPromise *promise) {
                    if (promise->account()) {
                        promise = KGAPI2::AccountManager::instance()->refreshTokens(
                            GOOGLE_API_KEY, GOOGLE_API_SECRET, mResource->settings()->userName());
                    } else {
                        promise = KGAPI2::AccountManager::instance()->getAccount(
                            GOOGLE_API_KEY, GOOGLE_API_SECRET, mResource->settings()->userName(),
                            { KGAPI2::Account::mailScopeUrl() });
                    }
                    connect(promise, &KGAPI2::AccountPromise::finished,
                            this, &GmailPasswordRequester::onTokenRequestFinished);
                    mPendingPromise = promise;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &limits : std::as_const(allLimits)) {
        QMap<QByteArray, qint64> limitsMap;
        const QStringList strLines = limits.split(QStringLiteral("%%"));
        QList<QByteArray> lines;
        lines.reserve(strLines.count());
        for (const QString &strLine : strLines) {
            lines << strLine.trimmed().toUtf8();
        }

        for (const QByteArray &line : std::as_const(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            limitsMap[key] = value.toLongLong();
        }

        mLimits << limitsMap;
    }
```

#### AUTO 


```{c}
const auto event = Kolab::fromXML<KCalendarCore::Event::Ptr, KolabV2::Event>(QString::fromUtf8(s.c_str()).toUtf8(), attachments);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mTags)) {
        auto *createJob = new Akonadi::TagCreateJob(tag, this);
        createJob->setMergeIfExisting(true);
        connect(createJob, &Akonadi::TagCreateJob::result, this, &CreateAndSetTagsJob::onCreateDone);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : qAsConst(objects)) {
        const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();

        QString realName = group->title();

        if (group->isSystemGroup()) {
            if (group->title().contains(QStringLiteral("Coworkers"))) {
                realName = i18nc("Name of a group of contacts", "Coworkers");
            } else if (group->title().contains(QStringLiteral("Friends"))) {
                realName = i18nc("Name of a group of contacts", "Friends");
            } else if (group->title().contains(QStringLiteral("Family"))) {
                realName = i18nc("Name of a group of contacts", "Family");
            } else if (group->title().contains(QStringLiteral("My Contacts"))) {
                // Yes, skip My Contacts group, we store "My Contacts" in root collection
                continue;
            }
        } else {
            if (group->title().contains(QStringLiteral("Other Contacts"))) {
                realName = i18nc("Name of a group of contacts", "Other Contacts");
            }
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KContacts::Addressee::mimeType());
        collection.setName(group->id());
        collection.setParentCollection(m_rootCollection);
        collection.setRights(Collection::CanLinkItem
                             |Collection::CanUnlinkItem
                             |Collection::CanChangeItem);
        if (!group->isSystemGroup()) {
            collection.setRights(collection.rights()
                                 |Collection::CanChangeCollection
                                 |Collection::CanDeleteCollection);
        }
        collection.setRemoteId(group->id());
        collection.setVirtual(true);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(realName);
        attr->setIconName(QStringLiteral("view-pim-contacts"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QXmlResultItems &ri, const QXmlNamePool &)
            {
                if (ri.hasError()) {
                    qDebug() << "XQuery result has errors.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlItem item = ri.next();
                if (item.isNull()) {
                    qDebug() << "XQuery result has no items.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (!item.isNode()) {
                    qDebug() << "XQuery result is not a XML node.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlNodeModelIndex index = item.toNodeModelIndex();
                if (index.isNull()) {
                    qDebug() << "XQuery XML node is NULL.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (index.model()->stringValue(index) != QStringLiteral("test")) {
                    qDebug() << "Unexpected item value:" << index.model()->stringValue(index);
                    return FakeEwsServer::EmptyResponse;
                }
                return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<b/>"), 200);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Attendee &a : attendees) {
        /*
         * KCalendarCore always sets a UID if empty, but that's just a pointer, and not the uid of a real contact.
         * Since that means the semantics of the two are different, we have to store the kolab uid as a custom property.
         */
        KCalendarCore::Attendee attendee(fromStdString(a.contact().name()),
                                         fromStdString(a.contact().email()),
                                         a.rsvp(),
                                         toPartStat(a.partStat()),
                                         toRole(a.role()));
        if (!a.contact().uid().empty()) { // TODO Identify contact from addressbook based on uid
            attendee.customProperties().setNonKDECustomProperty(CUSTOM_KOLAB_CONTACT_UUID, fromStdString(a.contact().uid()));
        }
        if (!a.delegatedTo().empty()) {
            if (a.delegatedTo().size() > 1) {
                qCWarning(PIMKOLAB_LOG) << "multiple delegatees are not supported";
            }
            attendee.setDelegate(toMailto(a.delegatedTo().front().email(), a.delegatedTo().front().name()).toString());
        }
        if (!a.delegatedFrom().empty()) {
            if (a.delegatedFrom().size() > 1) {
                qCWarning(PIMKOLAB_LOG) << "multiple delegators are not supported";
            }
            attendee.setDelegator(toMailto(a.delegatedFrom().front().email(), a.delegatedFrom().front().name()).toString());
        }
        if (a.cutype() != Kolab::CutypeIndividual) {
            attendee.customProperties().setNonKDECustomProperty(CUSTOM_KOLAB_CONTACT_CUTYPE, QString::number(a.cutype()));
        }
        i.addAttendee(attendee);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                qCDebug(GOOGLE_CONTACTS_LOG) << "Contacts groups retrieved";

                const ObjectsList objects = qobject_cast<ContactsGroupFetchJob *>(job)->items();
                Collection::List collections;
                collections.reserve(objects.count());
                std::transform(objects.cbegin(), objects.cend(), std::back_inserter(collections),
                        [this, &rootCollection](const ObjectPtr &object){
                            const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();
                            qCDebug(GOOGLE_CONTACTS_LOG) << " -" << group->title() << "(" << group->id() << ")";
                            Collection collection;
                            setupCollection(collection, group);
                            collection.setParentCollection(rootCollection);
                            m_collections[ collection.remoteId() ] = collection;
                            return collection;
                        });
                m_iface->collectionsRetrievedFromHandler(collections);
            }
```

#### AUTO 


```{c}
const auto items = job->requestedItems();
```

#### AUTO 


```{c}
const auto initAccount = wizard()->property("initAccount");
```

#### AUTO 


```{c}
auto CTagAttr = collection.attribute<CTagAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(c, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *urlConfigAccepted = new Settings::UrlConfiguration();
```

#### AUTO 


```{c}
auto req = new EwsPoxAutodiscoverRequest(url, mEmail, mUserAgent, mEnableNTLMv2, this);
```

#### AUTO 


```{c}
auto *store = new KIMAP::StoreJob(m_session);
```

#### AUTO 


```{c}
auto *progress = new QProgressBar(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<FileStore::Job*> &jobs) { d->processJobs(jobs); }
```

#### AUTO 


```{c}
auto *req = new EwsMoveItemRequest(mEwsClient, this);
```

#### AUTO 


```{c}
const auto &loc
```

#### AUTO 


```{c}
auto job = new EwsFetchFoldersJob(mEwsClient, mRootCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::cDateTime &dt : exceptionDates) {
        const QDateTime &date = toDate(dt);
        if (dt.isDateOnly()) {
            e.recurrence()->addExDate(date.date());
        } else {
            e.recurrence()->addExDateTime(date);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReminderPtr &rem : qAsConst(m_reminders)) {
        QVariantMap reminder;

        if (rem->type() == KCalCore::Alarm::Display) {
            reminder[QStringLiteral("type")] = QLatin1String("display");
        } else if (rem->type() == KCalCore::Alarm::Email) {
            reminder[QStringLiteral("type")] = QLatin1String("email");
        }

        reminder[QStringLiteral("time")] = rem->startOffset().asSeconds();

        list << reminder;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
                    const CalendarPtr calendar = object.dynamicCast<Calendar>();

                    QListWidgetItem *item = new QListWidgetItem(calendar->title());
                    item->setData(Qt::UserRole, calendar->uid());
                    item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
                    item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
                    m_ui->calendarsList->addItem(item);
                }
```

#### AUTO 


```{c}
auto *getItemReq = new EwsGetItemRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        const KMIndexDataPtr data = indexReader.dataByFileName(entry);
        if (data != nullptr) {
            mIndexData.insert(entry, data);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
            if (!hasKeysToWrite || keysToWrite.contains(item.key)) {
                typename ValueHash::const_iterator it = values.find(item.key);
                if (it != values.end()) {
                    if (!item.writeFn) {
                        qCWarning(EWSCLI_LOG)
                            << QStringLiteral("Failed to write %1 element - no write support for %2 element.").arg(parentElm).arg(item.elmName);
                        return false;
                    }
                    writer.writeStartElement(nsUri, item.elmName);
                    bool status = item.writeFn(writer, *it);
                    writer.writeEndElement();
                    if (!status) {
                        return false;
                    }
                }
            }
        }
```

#### AUTO 


```{c}
const auto &instance
```

#### AUTO 


```{c}
auto subOnlyCheckBox = new QCheckBox(i18nc("@option:check", "Subscribed only"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setPassword(QStringLiteral("foo"));
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return false;
                                    };
        wallet->createFolderCallback = [&createFolderCalled](const QString &) {
                                           createFolderCalled = true;
                                           return true;
                                       };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return false;
                                    };
        wallet->writePasswordCallback = [&](const QString &, const QString &p) {
                                            password = p;
                                            loop.exit(0);
                                            return true;
                                        };
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &object : calendars) {
                    const CalendarPtr &calendar = object.dynamicCast<Calendar>();
                    qCDebug(GOOGLE_CALENDAR_LOG) << " -" << calendar->title() << "(" << calendar->uid() << ")";
                    if (!activeCalendars.contains(calendar->uid())) {
                        qCDebug(GOOGLE_CALENDAR_LOG) << "Skipping, not subscribed";
                        continue;
                    }
                    Collection collection;
                    setupCollection(collection, calendar);
                    collection.setParentCollection(rootCollection);
                    collections << collection;
                }
```

#### AUTO 


```{c}
auto localItemIter = m_localItems.find(fileName);
```

#### AUTO 


```{c}
auto it = std::find_if(m_handlers.cbegin(), m_handlers.cend(), [&collection](const GenericHandler::Ptr &handler) {
        return collection.contentMimeTypes().contains(handler->mimeType());
    });
```

#### AUTO 


```{c}
const auto customProperties = mEvent.customProperties();
```

#### AUTO 


```{c}
const auto tagsProperties = EwsItemHandler::tagsProperties();
```

#### AUTO 


```{c}
auto rights = new KIMAP::MyRightsJob(session);
```

#### AUTO 


```{c}
auto tokens = subtype.split(QChar::fromLatin1(':'));
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsFindFolderRequest *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : folders) {
        Collection c;
        c.setRemoteId(id.id());
        auto *job = new CollectionFetchJob(c, CollectionFetchJob::Base);
        job->setFetchScope(changeRecorder()->collectionFetchScope());
        job->fetchScope().setResource(identifier());
        job->fetchScope().setListFilter(CollectionFetchScope::Sync);
        connect(job, &KJob::result, this, &EwsResource::foldersModifiedCollectionSyncFinished);
    }
```

#### AUTO 


```{c}
auto itemJob = new ItemFetchJob(mCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : events) {
        // If this event is transparent it shouldn't be in the freebusy list.
        if (event->transparency() == KCalendarCore::Event::Transparent) {
            continue;
        }

        if (event->hasRecurrenceId()) {
            continue; // TODO apply special period exception (duration could be different)
        }

        const QDateTime eventStart = event->dtStart().toUTC();
        const QDateTime eventEnd = event->dtEnd().toUTC();

        std::vector<Kolab::Period> periods;
        if (event->recurs()) {
            const KCalendarCore::Duration duration(eventStart, eventEnd);
            const auto list = event->recurrence()->timesInInterval(start, end);
            for (const auto &dt : list) {
                const auto utc = dt.toUTC();
                const Kolab::Period &period = addLocalPeriod(utc, duration.end(utc), start, end, allDay);
                if (period.isValid()) {
                    periods.push_back(period);
                }
            }
        } else {
            const Kolab::Period &period = addLocalPeriod(eventStart, eventEnd, start, end, allDay);
            if (period.isValid()) {
                periods.push_back(period);
            }
        }
        if (!periods.empty()) {
            Kolab::FreebusyPeriod period;
            period.setPeriods(periods);
            // TODO get busy type from event (out-of-office, tentative)
            period.setType(Kolab::FreebusyPeriod::Busy);
            period.setEvent(Kolab::Conversion::toStdString(event->uid()),
                            Kolab::Conversion::toStdString(event->summary()),
                            Kolab::Conversion::toStdString(event->location()));
            freebusyPeriods.push_back(period);
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int OnlineStateChangeTimeoutMs = 20000;
```

#### AUTO 


```{c}
const auto &newItem
```

#### AUTO 


```{c}
const auto calendar = Calendar::Ptr(new MemoryCalendar(QTimeZone::utc()));
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry::Pair &entry : std::as_const(movedEntries)) {
                const KMIndexDataPtr data = indexData.value(entry.first.messageOffset());
                mIndexData.insert(entry.second.messageOffset(), data);
            }
```

#### AUTO 


```{c}
const auto authStatus = performAuthAction(oAuth, 2000, [](EwsOAuth *oAuth) {
        return oAuth->authenticate(true);
    });
```

#### AUTO 


```{c}
const auto collections = var.value<Collection::List>();
```

#### AUTO 


```{c}
const auto remoteUrlsLst = remoteUrls();
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsModifyItemJob *>(job);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsSubscribeRequest *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { fetchDone(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(randomList1)) {
        Item item1;
        item1.setId(KRandom::random());
        item1.setRemoteId(QString::number(entry.messageOffset()));
        item1.setParentCollection(collection1);

        job = mStore->fetchItem(item1);
        job->fetchScope().fetchPayloadPart(MessagePart::Header);
        job->fetchScope().fetchPayloadPart(MessagePart::Body);

        spy = new QSignalSpy(job, &FileStore::ItemFetchJob::itemsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        items = job->items();
        QCOMPARE((int)items.count(), 1);
        QCOMPARE(itemsFromSpy(spy), items);

        Item item = items.first();
        QCOMPARE(item, item1);
        QVERIFY(item.hasPayload<KMime::Message::Ptr>());

        KMime::Message::Ptr msgPtr = item.payload<KMime::Message::Ptr>();
        QVERIFY(msgPtr != 0);

        const QSet<QByteArray> parts = messageParts(msgPtr);
        qCDebug(MIXEDMAILDIRRESOURCE_LOG) << msgPtr->messageID()->identifier();
        QVERIFY(!parts.isEmpty());
        QVERIFY(parts.contains(MessagePart::Header));
        if (msgPtr->messageID()->identifier() == messageIdOfEmptyBodyMsg) {
            QVERIFY(!parts.contains(MessagePart::Body));
        } else {
            QVERIFY(parts.contains(MessagePart::Body));
        }
    }
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::ItemFetchJob(tags.first());
```

#### AUTO 


```{c}
auto iter = groupsMap.constBegin(), iterEnd = groupsMap.constEnd();
```

#### AUTO 


```{c}
auto *selectJob = new KIMAP::SelectJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsUpdateItemRequest *req) {
                return req->responses();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int seenTime : seenUidTimeListValue) {
        QVERIFY(seenTime >= time(nullptr) - 10 * 60);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &desc : namespaces) {
        if (path.startsWith(desc.name.left(desc.name.size() - 1))) { //Namespace ends with path separator and path doesn't
            if (!matchCompletePath || path.size() - desc.name.size() <= 1) {      //We want to match only for the complete path
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
const auto fbPeriods{fb.periods()};
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            if (!d->wallet->isOpen()) {
                delete d->wallet;
                d->wallet = nullptr;
                emitError(i18n("Failed to open KWallet"));
                return;
            }

            if (!d->wallet->hasFolder(KWalletFolder)) {
                d->wallet->createFolder(KWalletFolder);
            }

            d->wallet->setFolder(KWalletFolder);

            doStart();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &h : qAsConst(headers)) {
        if (first) {
            first = false;
        } else {
            ret.append(",");
        }
        ret.append(h.name);
        ret.append("=\"");
        ret.append(QUrl::toPercentEncoding(h.value));
        ret.append("\"");
    }
```

#### AUTO 


```{c}
auto *job = new FileStore::CollectionCreateJob(collection, targetParent, d->mSession);
```

#### AUTO 


```{c}
const auto mailAttachments{a->mailAttachments()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &strLine : std::as_const(strLines)) {
            lines << strLine.trimmed().toUtf8();
        }
```

#### AUTO 


```{c}
auto job = Graph::job(QStringLiteral("me"), d->token, {QStringLiteral("id"), QStringLiteral("name")});
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cat : lst) {
            if (categories.contains(cat)) {
                hasCategory = true;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsUpdateItemRequest::ItemChange::List::const_iterator firstChange, EwsUpdateItemRequest::ItemChange::List::const_iterator lastChange) {
                auto req = new EwsUpdateItemRequest(mClient, this);
                for (auto it = firstChange; it != lastChange; ++it) {
                    req->addItemChange(*it);
                }
                return req;
            }
```

#### AUTO 


```{c}
const auto event = item.payload<KAEvent>();
```

#### AUTO 


```{c}
auto *job = new CollectionModifyJob(col);
```

#### AUTO 


```{c}
auto *search = static_cast<KIMAP::SearchJob *>(job);
```

#### AUTO 


```{c}
auto job = new KIMAP::SetMetaDataJob(m_session);
```

#### AUTO 


```{c}
auto task = new RetrieveItemTask(createResourceState(TaskArguments(item, parts)), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const StringPair &item : std::as_const(userAgents)) {
        mUi->userAgentCombo->addItem(item.first, item.second);
        if (mSettings->userAgent() == item.second) {
            selectedIndex = i;
        }
        i++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KService::Ptr &provider : providers) {
        offers.append(QPair<QString, QString>(provider->name(), provider->entryPath()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            settleLoop.exit(0);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const BaseHandler::Ptr &handler) {
        return collection.contentMimeTypes().contains(handler->mimeType());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { checkFuture(); }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::TagFetchJob(tag);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::SentActionAttribute::Action &action : lstAct) {
                mSentActionHandler->runAction(action);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
            flagList.append(QString::fromLatin1(flag));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &collection : collections) {
        addModelRow(collection.displayName(), collection.url().toDisplayString());
    }
```

#### AUTO 


```{c}
auto job = new OXA::FolderDeleteJob(folder, this);
```

#### AUTO 


```{c}
auto attr = new HighestModSeqAttribute(m_highestModSeq);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FakeEwsServer::DialogEntry &de : dialogs) {
        QXmlResultItems ri;
        QByteArray resultBytes;
        QString result;
        QBuffer resultBuffer(&resultBytes);
        resultBuffer.open(QIODevice::WriteOnly);
        QXmlQuery query;
        QXmlSerializer xser(query, &resultBuffer);
        if (!de.xQuery.isNull()) {
            query.setFocus(content);
            query.setQuery(de.xQuery);
            query.evaluateTo(&xser);
            query.evaluateTo(&ri);
            if (ri.hasError()) {
                qCDebugNC(EWSFAKE_LOG) << QStringLiteral("XQuery failed due to errors - skipping");
                continue;
            }
            result = QString::fromUtf8(resultBytes);
        }

        if (!result.trimmed().isEmpty()) {
            qCDebugNC(EWSFAKE_LOG) << QStringLiteral("Got match for \"") << de.description << QStringLiteral("\"");
            if (de.replyCallback) {
                resp = de.replyCallback(content, ri, query.namePool());
                qCInfoNC(EWSFAKE_LOG) << QStringLiteral("Returning response from callback ") << resp.second << QStringLiteral(": ") << resp.first;
            } else {
                resp = {result.trimmed(), 200};
                qCInfoNC(EWSFAKE_LOG) << QStringLiteral("Returning response from XQuery ") << resp.second << QStringLiteral(": ") << resp.first;
            }
            break;
        }
    }
```

#### AUTO 


```{c}
const auto res = instances.calendarResource.isValid()
                             ? instances.calendarResource.identifier()
                             : instances.contactResource.identifier();
```

#### AUTO 


```{c}
const auto remoteId = col.remoteId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SetupWizard::Url &url : urls) {
        KDAV::DavUrl davUrl;
        davUrl.setProtocol(url.protocol);

        QUrl serverUrl(url.url);
        serverUrl.setUserName(wizard()->field(QStringLiteral("credentialsUserName")).toString());
        serverUrl.setPassword(wizard()->field(QStringLiteral("credentialsPassword")).toString());
        davUrl.setUrl(serverUrl);

        davUrls << davUrl;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &desc : namespaces) {
        if (path.startsWith(desc.name.left(desc.name.size() - 1))) { // Namespace ends with path separator and path doesn't
            if (!matchCompletePath || path.size() - desc.name.size() <= 1) { // We want to match only for the complete path
                return true;
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned monthNameCount = sizeof(monthNames) / sizeof(monthNames[0]);
```

#### AUTO 


```{c}
const auto attachments{n.attachments()};
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {
        return parseFoldersResponse(reader);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Attachment &a : attachments) {
        Kolab::Attachment attachment;
        attachment.setLabel(a.label());
        const std::string cid = a.uri().empty() ? createCid() : a.uri();
        attachmentCids.push_back(cid);
        attachment.setUri(cid, a.mimetype()); // Serialize the attachment as attachment with uri, referencing the created mime-part
        attachmentsWithReferences.push_back(attachment);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &rootCollection](const ObjectPtr &object){
                            const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();
                            qCDebug(GOOGLE_CONTACTS_LOG) << " -" << group->title() << "(" << group->id() << ")";
                            Collection collection;
                            setupCollection(collection, group);
                            collection.setParentCollection(rootCollection);
                            m_collections[ collection.remoteId() ] = collection;
                            return collection;
                        }
```

#### AUTO 


```{c}
const auto *attribute = sentItem.attribute<MailTransport::SentActionAttribute>();
```

#### AUTO 


```{c}
auto newJob = new TaskModifyJob(task, item.parentCollection().remoteId(), job->account(), this);
```

#### AUTO 


```{c}
const auto hasDomainReply = dBusSetAndWaitReply<bool>(
        std::bind(&OrgKdeAkonadiEwsSettingsInterface::setHasDomain, mEwsSettingsInterface.data(), false),
        std::bind(&OrgKdeAkonadiEwsSettingsInterface::hasDomain, mEwsSettingsInterface.data()),
        QStringLiteral("has domain"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QXmlResultItems &ri, const QXmlNamePool &)
            {
                if (ri.hasError()) {
                    qDebug() << "XQuery result has errors.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlItem item = ri.next();
                if (item.isNull()) {
                    qDebug() << "XQuery result has no items.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (!item.isNode()) {
                    qDebug() << "XQuery result is not a XML node.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlNodeModelIndex index = item.toNodeModelIndex();
                if (index.isNull()) {
                    qDebug() << "XQuery XML node is NULL.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (index.model()->stringValue(index) != QLatin1String("test")) {
                    qDebug() << "Unexpected item value:" << index.model()->stringValue(index);
                    return FakeEwsServer::EmptyResponse;
                }
                return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<b/>"), 200);
            }
```

#### AUTO 


```{c}
auto *syncItemsReq = new EwsSyncFolderItemsRequest(mClient, this);
```

#### AUTO 


```{c}
auto job = new NewMailNotifierShowMessageJob(mItem.id());
```

#### AUTO 


```{c}
auto blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<OXA::FoldersRequestJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](FakeTransferJob *job, const QByteArray &req){
        verifier(job, req, request, response);
    }
```

#### AUTO 


```{c}
auto *select = new KIMAP::SelectJob(store->session());
```

#### AUTO 


```{c}
auto *search = new KIMAP::SearchJob(mSession);
```

#### AUTO 


```{c}
auto *fetchJob
        = new Akonadi::CollectionFetchJob(rootCollection, Akonadi::CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const GenericHandler::Ptr &handler) {
        return collection.contentMimeTypes().contains(handler->mimeType());
    }
```

#### AUTO 


```{c}
const auto phoneNumbers{addressee.phoneNumbers()};
```

#### AUTO 


```{c}
const auto *attr = it.key().attribute<Akonadi::EntityDisplayAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QMap<QString, QString> &map) {
        mAuthMap = map;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const User &user : users) {
        mUsers.insert(user.uid(), user);
    }
```

#### AUTO 


```{c}
auto *currentUidValidity = new UidValidityAttribute(m_uidValidity);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : attachments) {
        QByteArray type;
        KMime::Content *content = Mime::findContentByName(mimeData, name, type);
        if (!content) { // guard against malformed events with non-existent attachments
            qCWarning(PIMKOLAB_LOG) <<"could not find attachment: "<< name.toUtf8() << type;
            continue;
        }
        const QByteArray c = content->decodedContent().toBase64();
        KCalCore::Attachment::Ptr attachment(new KCalCore::Attachment(c, QString::fromLatin1(type)));
        attachment->setLabel(name);
        incidence->addAttachment(attachment);
        qCDebug(PIMKOLAB_LOG) << "ATTACHMENT NAME" << name << type;
    }
```

#### AUTO 


```{c}
auto it = customProperties.cbegin(), end = customProperties.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. " << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (!davCollection.displayName().isEmpty()) {
            EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        DavProtocolAttribute *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after sucessfull sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### AUTO 


```{c}
auto *tab = new QTabWidget(parent);
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<OXA::ObjectsRequestDeltaJob *>(job);
```

#### AUTO 


```{c}
auto queryJob = qobject_cast<FreeBusyQueryJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("loadFiles:")
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->akonadiFetchResult(job);
    }
```

#### AUTO 


```{c}
auto *modifyJob = qobject_cast<FileStore::CollectionModifyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMailbox &mbox : mboxList) {
                msg->to()->addAddress(mbox);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &kcalEvent : std::as_const(events)) {
        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KCalendarCore::Event has no alarms:" << kcalEvent->uid();
            continue; // ignore events without alarms
        }

        const KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KAEvent has no alarms:" << event.id();
            continue; // event has no usable alarms
        }

        Item item(mime);
        item.setRemoteId(kcalEvent->uid());
        item.setPayload(event);
        items << item;
    }
```

#### AUTO 


```{c}
const auto s = Settings::self();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settleLoop.exit(0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *c : contents) {
        //         qCDebug(PIMKOLAB_LOG) << c->contentType()->mimeType() << type;
        if (c->contentType()->mimeType() == type) {
            return c;
        }
    }
```

#### AUTO 


```{c}
const auto id = uid.mid(1, uid.indexOf(QLatin1Char('@')) - 1);
```

#### AUTO 


```{c}
auto dstCol = req->property("destinationCollection").value<Collection>();
```

#### AUTO 


```{c}
auto bjob = qobject_cast<BirthdayListJob *>(job)
```

#### AUTO 


```{c}
auto zone
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : qAsConst(mIncidences)) {
        Item item;
        item.setRemoteId(incidence->instanceIdentifier());
        item.setMimeType(incidence->mimeType());
        items.append(item);
    }
```

#### AUTO 


```{c}
auto loginJob = new KIMAP::LoginJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : std::as_const(collections)) {
        QVERIFY(!collection.remoteId().isEmpty());
        QCOMPARE(collection.remoteId(), collection.name());
        QCOMPARE(collection.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

        QCOMPARE(collection.rights(),
                 Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                     | Collection::CanChangeCollection | Collection::CanDeleteCollection);

        QCOMPARE(collection.parentCollection(), mStore->topLevelCollection());
        QVERIFY(firstLevelNames.contains(collection.name()));
    }
```

#### AUTO 


```{c}
auto *session1 = sessionSpy.at(0).at(1).value<KIMAP::Session *>();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Item &item){
        return ContactPtr(new Contact(item.payload<KContacts::Addressee>()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                        if (!d->wallet->isOpen()) {
                            delete d->wallet;
                            d->wallet = nullptr;
                            emitError(i18n("Failed to open KWallet"));
                            return;
                        }

                        if (!d->wallet->hasFolder(KWalletFolder)) {
                            d->wallet->createFolder(KWalletFolder);
                        }

                        d->wallet->setFolder(KWalletFolder);

                        doStart();
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const BaseHandler::Ptr &handler) {
                               return collection.contentMimeTypes().contains(handler->mimeType());
                           }
```

#### AUTO 


```{c}
const auto baseUrlReply = dBusSetAndWaitReply<QString>(
        std::bind(&OrgKdeAkonadiEwsSettingsInterface::setBaseUrl, mEwsSettingsInterface.data(), url),
        std::bind(&OrgKdeAkonadiEwsSettingsInterface::baseUrl, mEwsSettingsInterface.data()),
        QStringLiteral("Base URL"));
```

#### AUTO 


```{c}
auto *modifyJob = new ItemModifyJob(updatedItem);
```

#### AUTO 


```{c}
auto progressBar = new QProgressBar(this);
```

#### AUTO 


```{c}
auto const len = etebase_item_get_content(etesyncItem, content.data(), ITEM_SIZE_INITIAL_TRY);
```

#### RANGE FOR STATEMENT 


```{c}
for (int deletedId : std::as_const(mDeletedIDs)) {
        idsOfMessagesDownloadedButNotDeleted.removeAll(deletedId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&callbackCalled](const QString &, QXmlResultItems &, const QXmlNamePool &)
            {
                callbackCalled = true;
                return FakeEwsServer::EmptyResponse;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        try {
            KMime::Message::Ptr msg = item.payload<KMime::Message::Ptr>();
            const QByteArray messageId = msg->messageID()->asUnicodeString().toUtf8();
            if (!messageId.isEmpty()) {
                m_messageIds.insert(item.id(), messageId);
            }

            set.add(item.remoteId().toLong());
        } catch (const Akonadi::PayloadException &e) {
            Q_UNUSED(e)
            qCWarning(IMAPRESOURCE_LOG) << "Move failed, payload exception " << item.id() << item.remoteId();
            cancelTask(i18n("Failed to move item, it has no message payload. Remote id: %1", item.remoteId()));
            return;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                localFoldersChanged();
            }
```

#### AUTO 


```{c}
auto end = it;
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsUpdateItemRequest *req) {
            return req->responses();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Custom &custom : std::as_const(mCustomList)) {
        QString key(QString::fromUtf8(custom.key));
        Q_ASSERT(!key.isEmpty());
        if (key.startsWith(QLatin1String("X-KDE-KolabUnhandled-"))) {
            key = key.mid(strlen("X-KDE-KolabUnhandled-"));
            writeString(element, key, custom.value);
        } else {
            // Let's use attributes so that other tag-preserving-code doesn't need sub-elements
            QDomElement e = element.ownerDocument().createElement(QStringLiteral("x-custom"));
            element.appendChild(e);
            e.setAttribute(QStringLiteral("key"), key);
            e.setAttribute(QStringLiteral("value"), custom.value);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &ptr : eAttendees) {
        const QString &uid = ptr.customProperties().nonKDECustomProperty(CUSTOM_KOLAB_CONTACT_UUID);
        Kolab::Attendee a(Kolab::ContactReference(toStdString(ptr.email()), toStdString(ptr.name()), toStdString(uid)));
        a.setRSVP(ptr.RSVP());
        a.setPartStat(fromPartStat(ptr.status()));
        a.setRole(fromRole(ptr.role()));
        if (!ptr.delegate().isEmpty()) {
            std::string name;
            const std::string &email = fromMailto(QUrl(ptr.delegate()), name);
            a.setDelegatedTo(std::vector<Kolab::ContactReference>() << Kolab::ContactReference(email, name));
        }
        if (!ptr.delegator().isEmpty()) {
            std::string name;
            const std::string &email = fromMailto(QUrl(ptr.delegator()), name);
            a.setDelegatedFrom(std::vector<Kolab::ContactReference>() << Kolab::ContactReference(email, name));
        }
        const QString &cutype = ptr.customProperties().nonKDECustomProperty(CUSTOM_KOLAB_CONTACT_CUTYPE);
        if (!cutype.isEmpty()) {
            a.setCutype(static_cast<Kolab::Cutype>(cutype.toInt()));
        }

        attendees.push_back(a);
    }
```

#### AUTO 


```{c}
auto *quitJob = new QuitJob(mPopSession);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto key = qobject_cast<FacebookResource *>(parent())->identifier();
```

#### AUTO 


```{c}
auto job = new ContactCreateJob(contact, m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : req->items()) {
        if (mSubManager) {
            mSubManager->queueUpdate(EwsModifiedEvent, item.remoteId(), item.remoteRevision());
        }
        mQueuedUpdates[item.parentCollection().remoteId()].append({item.remoteId(), item.remoteRevision(), EwsModifiedEvent});
    }
```

#### AUTO 


```{c}
auto idJob = new KIMAP::IdJob(capJob->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job){
                if (!handleError(job) || !m_account) {
                    m_ui->taskListsBox->setDisabled(true);
                    return;
                }

                const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

                QStringList activeTaskLists;
                if (m_account->accountName() == m_settings->account()) {
                    activeTaskLists = m_settings->taskLists();
                }
                m_ui->taskListsList->clear();
                for (const ObjectPtr &object : objects) {
                    const TaskListPtr taskList = object.dynamicCast<TaskList>();

                    QListWidgetItem *item = new QListWidgetItem(taskList->title());
                    item->setData(Qt::UserRole, taskList->uid());
                    item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
                    item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
                    m_ui->taskListsList->addItem(item);
                }

                m_ui->taskListsBox->setEnabled(true);

            }
```

#### AUTO 


```{c}
auto job = new TomboyItemUploadJob(item, JobType::DeleteItem, mManager, this);
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<EwsFetchItemsJob *>(job);
```

#### AUTO 


```{c}
const auto &transition = *it;
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsUpdateItemRequest::ItemChange::List::const_iterator firstChange, EwsUpdateItemRequest::ItemChange::List::const_iterator lastChange) {
                auto req = new EwsUpdateItemRequest(mClient, this);
                req->addItemChanges(firstChange, lastChange);
                return req;
            }
```

#### AUTO 


```{c}
auto job = new KIMAP::RenameJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const OXA::Object &object : deletedObjects) {
        Item item;

        const RemoteInformation remoteInformation(object.objectId(), object.module(), object.lastModified());
        remoteInformation.store(item);

        removedItems.append(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }

        ContactsGroupPtr group = qobject_cast<ContactsGroupCreateJob *>(job)->items().first().dynamicCast<ContactsGroup>();
        qCDebug(GOOGLE_CONTACTS_LOG) << "Contact group created:" << group->id();
        Collection newCollection(collection);
        setupCollection(newCollection, group);
        m_collections[ newCollection.remoteId() ] = newCollection;
        m_iface->collectionChangeCommitted(newCollection);
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsUpdateItemRequest *>(job);
```

#### AUTO 


```{c}
auto job = new FileStore::CollectionFetchJob(collection, type, d->mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestMap();
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return true;
                                    };
        wallet->createFolderCallback = [](const QString &) {
                                           return false;
                                       };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return true;
                                    };
        wallet->readMapCallback = [](const QString &, QMap<QString, QString> &map) {
                                      map[accessTokenMapKey] = QStringLiteral("afoo");
                                      map[refreshTokenMapKey] = QStringLiteral("rfoo");
                                      return true;
                                  };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("&Select All"), this);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(col, this);
```

#### AUTO 


```{c}
auto *davJob = qobject_cast<KIO::DavJob *>(job);
```

#### AUTO 


```{c}
const auto t = element.text();
```

#### AUTO 


```{c}
auto alarm = KCalendarCore::Alarm::Ptr::create(event.data());
```

#### LAMBDA EXPRESSION 


```{c}
[](const Collection &col, const DesiredState &state) {
        auto attr = col.attribute<EntityDisplayAttribute>();
        QString iconName;
        if (attr) {
            iconName = attr->iconName();
        }
        return col.parentCollection().remoteId() == state.parentId && iconName == state.iconName;
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
            if (col.resource() == AgentManager::self()->instance(mMaildirIdentifier).identifier() && col.remoteId() == maildirRootPath) {
                mMaildirCollection = col;
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &kcalEvent : qAsConst(events)) {
        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KCalendarCore::Event has no alarms:" << kcalEvent->uid();
            continue; // ignore events without alarms
        }

        const KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KAEvent has no alarms:" << event.id();
            continue; // event has no usable alarms
        }

        Item item(mime);
        item.setRemoteId(kcalEvent->uid());
        item.setPayload(event);
        items << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { emitResult(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&events](const QString &event) {
            events.append(event);
        }
```

#### AUTO 


```{c}
auto event = reinterpret_cast<KCalendarCore::Event *>(incidence.data());
```

#### AUTO 


```{c}
auto *reply = qobject_cast<QNetworkReply *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready){
        if (ready) {
            m_account = m_settings->accountPtr();
            accountChanged();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : list) {
            writer.writeTextElement(ewsTypeNsUri, QStringLiteral("String"), str);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::string &member : members) {
                d->mTagMembers << Conversion::fromStdString(member);
            }
```

#### AUTO 


```{c}
auto requestJob = new Akonadi::SpecialMailCollectionsRequestJob(this);
```

#### AUTO 


```{c}
const auto item = m_messageHelper->createItemFromMessage(msg->message, msg->uid, msg->size, msg->attributes, msg->flags, fetch->scope(), ok);
```

#### AUTO 


```{c}
auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item){
                return item.remoteId() == parentId;
            });
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReminderPtr &rem : qAsConst(m_reminders)) {
        QVariantMap reminder;

        if (rem->type() == KCalendarCore::Alarm::Display) {
            reminder[QStringLiteral("type")] = QLatin1String("display");
        } else if (rem->type() == KCalendarCore::Alarm::Email) {
            reminder[QStringLiteral("type")] = QLatin1String("email");
        }

        reminder[QStringLiteral("time")] = rem->startOffset().asSeconds();

        list << reminder;
    }
```

#### AUTO 


```{c}
auto fetchJob = new EwsFetchItemsJob(col, mEwsClient, getCollectionSyncState(col), mItemsToCheck.value(col.remoteId()), mTagStore, this);
```

#### AUTO 


```{c}
auto *itemJob = qobject_cast<FileStore::ItemModifyJob *>(job);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsGetFolderRequest *>(job);
```

#### AUTO 


```{c}
auto *job = new KIMAP::AppendJob(mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Notification &nfy : notifications) {
                numEv += nfy.events().size();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsSyncFolderItemsRequest::Change &change : reqChanges) {
            switch (change.type()) {
            case EwsSyncFolderItemsRequest::Create:
                mRemoteAddedItems.append(change.item());
                break;
            case EwsSyncFolderItemsRequest::Update:
                mRemoteChangedItems.append(change.item());
                break;
            case EwsSyncFolderItemsRequest::Delete:
                mRemoteDeletedIds.append(change.itemId());
                break;
            case EwsSyncFolderItemsRequest::ReadFlagChange:
                mRemoteFlagChangedIds.insert(change.itemId(), change.isRead());
                break;
            default:
                break;
            }
        }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(settings);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : collections) {
            const Collection::Id id = collection.id();
            if (!mSynchronizedCollections.contains(id) && !mPendingSynchronizeCollections.contains(id)) {
                qCDebug(MIXEDMAILDIR_LOG) << "Requesting sync of collection" << collection.name() << ", id=" << collection.id();
                mPendingSynchronizeCollections << id;
                synchronizeCollection(id);
            }
        }
```

#### AUTO 


```{c}
auto buttonContainer = new QWidget(this);
```

#### AUTO 


```{c}
const auto count = std::min<int>(batchSize, m_messageIds.size() - batchIdx);
```

#### AUTO 


```{c}
auto task = new KolabChangeItemsRelationsTask(createResourceState(TaskArguments(items, addedRelations, removedRelations)));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : colList) {
        ++m_pendingJobs;
        job = new CollectionCreateJob(collection, this);
        job->setProperty(collectionIdMappingProperty, collection.id());
        connect(job, &CollectionCreateJob::result, this, &EntityTreeCreateJob::collectionCreateJobDone);
    }
```

#### AUTO 


```{c}
auto button = new QPushButton(i18n("Test Connection"));
```

#### AUTO 


```{c}
auto job = new NewMailNotifierReplyMessageJob(mItem.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
            // We don't link contacts to "My Contacts"
            if (group != myContactsRemoteId()) {
                groupsMap[group] << item;
            }
        }
```

#### AUTO 


```{c}
auto *j = new Akonadi::ItemModifyJob(updatedItem);
```

#### AUTO 


```{c}
auto dlg = new AuthDialog(d->cookies, qobject_cast<FacebookResource*>(parent()));
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        qCDebug(GOOGLE_TASKS_LOG) << "Task lists retrieved";

        const ObjectsList taskLists = qobject_cast<TaskListFetchJob *>(job)->items();
        const QStringList activeTaskLists = m_settings->taskLists();
        Collection::List collections;
        for (const ObjectPtr &object : taskLists) {
            const TaskListPtr &taskList = object.dynamicCast<TaskList>();
            qCDebug(GOOGLE_TASKS_LOG) << " -" << taskList->title() << "(" << taskList->uid() << ")";

            if (!activeTaskLists.contains(taskList->uid())) {
                qCDebug(GOOGLE_TASKS_LOG) << "Skipping, not subscribed";
                continue;
            }

            Collection collection;
            setupCollection(collection, taskList);
            collection.setParentCollection(rootCollection);
            collections << collection;
        }

        m_iface->collectionsRetrievedFromHandler(collections);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cookie : parsedCookies) {
            mCookies += QStringLiteral("%1=%2; ").arg(QString::fromUtf8(cookie.name()),
                                                      QString::fromUtf8(cookie.value()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        CalendarPtr calendar = object.dynamicCast<Calendar>();

        QListWidgetItem *item = new QListWidgetItem(calendar->title());
        item->setData(Qt::UserRole, calendar->uid());
        item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
        item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
        m_calendarsList->addItem(item);

    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(collection);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int p) {
        Q_EMIT percent(p);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                settings()->setSubscriptionEnabled(mSubscriptions->subscriptionEnabled());
                settings()->save();
                Q_EMIT configurationDialogAccepted();
                reconnect();
            }
```

#### AUTO 


```{c}
const auto phases = ktz.phases();
```

#### AUTO 


```{c}
auto *aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *job = new OXA::FolderDeleteJob(folder, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &chunk) {
        const QString respHead = QStringLiteral(
            "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
            "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
            "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
            "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
            "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
            "<soap:Header>"
            "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
            "</soap:Header>"
            "<soap:Body>"
            "<m:GetStreamingEventsResponse>"
            "<m:ResponseMessages>"
            "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
            "<m:ResponseCode>NoError</m:ResponseCode>"
            "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral(
            "</m:GetStreamingEventsResponseMessage>"
            "</m:ResponseMessages>"
            "</m:GetStreamingEventsResponse>"
            "</soap:Body>"
            "</soap:Envelope>");
        const QString eventHead = QStringLiteral(
            "<m:Notifications>"
            "<m:Notification>"
            "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral(
            "<NewMailEvent>"
            "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
            "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
            "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
            "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediately" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    }
```

#### AUTO 


```{c}
auto it = std::find_if(items.cbegin(), items.cend(), [&contact](const Item &item) {
            return item.remoteId() == contact->uid();
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (int idToSave : std::as_const(mIdsToSave)) {
            idsToDeleteFromServer.removeAll(idToSave);
        }
```

#### AUTO 


```{c}
auto *attachDisposition
                = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto *modifyJob = new Akonadi::ItemModifyJob(item);
```

#### AUTO 


```{c}
auto *rights = new KIMAP::MyRightsJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const Item &item) {
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        contact->removeGroup(collection.remoteId());
        return contact;
    }
```

#### AUTO 


```{c}
auto cal = KCalCore::MemoryCalendar::Ptr::create(QTimeZone::systemTimeZone());
```

#### AUTO 


```{c}
auto wallet = qobject_cast<Wallet *>(sender());
```

#### AUTO 


```{c}
auto job = new KIO::ApplicationLauncherJob(service, this);
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(collection, CollectionFetchJob::FirstLevel);
```

#### AUTO 


```{c}
auto items = job->property("items").value<Item::List>();
```

#### AUTO 


```{c}
auto job = new KIMAP::CapabilitiesJob(s);
```

#### AUTO 


```{c}
auto itemJob = qobject_cast<FileStore::ItemCreateJob *>(job);
```

#### AUTO 


```{c}
const auto paging = obj.value(QLatin1String("paging")).toObject();
```

#### AUTO 


```{c}
auto *job = new KDAV::DavPrincipalSearchJob(url, KDAV::DavPrincipalSearchJob::EmailAddress, email);
```

#### AUTO 


```{c}
auto tokenJob = new GetTokenJob(mIdentifier, parent());
```

#### AUTO 


```{c}
auto *session = static_cast<KIMAP::Session *>(object);
```

#### LAMBDA EXPRESSION 


```{c}
[this](Job *job){
                if (!handleError(job) || !m_account) {
                    m_ui->calendarsBox->setEnabled(false);
                    return;
                }

                const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

                QStringList activeCalendars;
                if (m_account->accountName() == m_settings->account()) {
                    activeCalendars = m_settings->calendars();
                }
                m_ui->calendarsList->clear();
                for (const ObjectPtr &object : objects) {
                    const CalendarPtr calendar = object.dynamicCast<Calendar>();

                    QListWidgetItem *item = new QListWidgetItem(calendar->title());
                    item->setData(Qt::UserRole, calendar->uid());
                    item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
                    item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
                    m_ui->calendarsList->addItem(item);
                }

                m_ui->calendarsBox->setEnabled(true);
            }
```

#### AUTO 


```{c}
auto *buttonContainerLayout = new QVBoxLayout(buttonContainer);
```

#### AUTO 


```{c}
const auto memberMailbox{member.mailbox};
```

#### AUTO 


```{c}
auto label =
            new QLabel(QStringLiteral("<a href=\"%1\">%2</a>").arg(index.data(MigratorModel::LogfileRole).toString()).arg(ki18n("Logfile").toString()), widget);
```

#### AUTO 


```{c}
const auto freePeriods{freebusy.periods()};
```

#### AUTO 


```{c}
auto *colJob = qobject_cast<FileStore::CollectionMoveJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : qAsConst(mFlags)) {
        result += flag + ' ';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OXA::Object &object : modifiedObjects) {
        Item item;
        switch (object.module()) {
        case OXA::Folder::Contacts:
            if (!object.contact().isEmpty()) {
                item.setMimeType(KContacts::Addressee::mimeType());
                item.setPayload<KContacts::Addressee>(object.contact());
            } else {
                item.setMimeType(KContacts::ContactGroup::mimeType());
                item.setPayload<KContacts::ContactGroup>(object.contactGroup());
            }
            break;
        case OXA::Folder::Calendar:
            item.setMimeType(KCalendarCore::Event::eventMimeType());
            item.setPayload<KCalendarCore::Incidence::Ptr>(object.event());
            break;
        case OXA::Folder::Tasks:
            item.setMimeType(KCalendarCore::Todo::todoMimeType());
            item.setPayload<KCalendarCore::Incidence::Ptr>(object.task());
            break;
        case OXA::Folder::Unbound:
            Q_ASSERT(false);
            break;
        }
        const RemoteInformation remoteInformation(object.objectId(), object.module(), object.lastModified());
        remoteInformation.store(item);

        // the value of objectsLastSync is determined by the maximum last modified value
        // of the added or changed objects
        objectsLastSync = qMax(objectsLastSync, object.lastModified().toULongLong());

        changedItems.append(item);
    }
```

#### AUTO 


```{c}
auto examine = new KIMAP::SelectJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : itemsLst) {
        const QString rid = item.remoteId();
        if (rid.isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onCreateInitialCacheReady: Found an item without remote ID. " << item.id();
            continue;
        }

        const Akonadi::Collection collection = item.parentCollection();
        if (collection.remoteId().isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onCreateInitialCacheReady: Found an item in a collection without remote ID. "
                                     << item.remoteId();
            continue;
        }

        const QString etag = item.remoteRevision();
        if (etag.isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onCreateInitialCacheReady: Found an item without ETag. " << item.remoteId();
            continue;
        }

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }

        mEtagCaches[collection.remoteId()]->setEtag(rid, etag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(mMailboxes)) {
            const QStringList parts = mailbox.split(mSeparator);
            if (!parts.isEmpty()) {
                if (isNamespaceFolder(mailbox, mUserNamespace) && parts.length() >= 2) {
                    // Other Users can be too big to request with a single command so we request Other Users/<user>/*
                    toplevelMailboxes << parts.at(0) + mSeparator + parts.at(1) + mSeparator;
                } else if (!isNamespaceFolder(mailbox, mSharedNamespace)) {
                    toplevelMailboxes << parts.first();
                }
            }
        }
```

#### AUTO 


```{c}
const auto defaultRRByDays{defaultRR->byDays()};
```

#### AUTO 


```{c}
auto dependentItems = modifyJob->property("dependentItems").value<Akonadi::Item::List>();
```

#### AUTO 


```{c}
const auto it = location.constFind(loc);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rid : lstUrls) {
        if (rid.startsWith(ridBase) && rid != item.remoteId()) {
            Akonadi::Item extraItem;
            extraItem.setRemoteId(rid);
            extraItems << extraItem;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        applyConfigurationChanges();
        reloadFile();
        synchronizeCollectionTree();
    }
```

#### AUTO 


```{c}
auto resp = new EwsSyncFolderItemsRequest::Response(reader);
```

#### LAMBDA EXPRESSION 


```{c}
[this, items, detachItems](KGAPI2::Job *job){
                            if (job->error()) {
                                m_iface->cancelTask(i18n("Failed to reparent subtasks: %1", job->errorString()));
                                return;
                            }
                            // Update items inside Akonadi DB too
                            new ItemModifyJob(detachItems);
                            // Perform actual removal
                            doRemoveTasks(items);
                        }
```

#### AUTO 


```{c}
auto *searchJob = qobject_cast<KIMAP::SearchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &i : l) {
        ba += toString(i);
    }
```

#### AUTO 


```{c}
auto *job = new OXA::FolderCreateJob(folder, this);
```

#### AUTO 


```{c}
auto nsJob = qobject_cast<KIMAP::NamespaceJob *>(job);
```

#### AUTO 


```{c}
auto disposition = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto job = new LoginJob(mResource);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &alarm : alarms) {
                event->addAlarm(alarm);
            }
```

#### AUTO 


```{c}
const auto authStatus = performAuthAction(oAuth, 2000, [](EwsOAuth *oAuth) {
            return oAuth->authenticate(true);
        });
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                applyConfigurationChanges();
                reloadFile();
                synchronizeCollectionTree();
            }
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectsRequestDeltaJob(folder, lastSyncInfo.lastSync(collection.id()), this);
```

#### AUTO 


```{c}
auto job = new GetTokenJob(qobject_cast<FacebookResource*>(parent()));
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsFolder &folder : qAsConst(mFolders)) {
        QStandardItem *item = new QStandardItem(folder[EwsFolderFieldDisplayName].toString());
        item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        item->setCheckable(true);
        EwsId id = folder[EwsFolderFieldFolderId].value<EwsId>();
        item->setData(id.id(), ItemIdRole);
        if (mSubscribedIds.contains(EwsId(id.id()))) {
            item->setCheckState(Qt::Checked);
        }
        EwsId parentId = folder[EwsFolderFieldParentFolderId].value<EwsId>();
        if (parentId.type() != EwsId::Unspecified) {
            QStandardItem *parentItem = mFolderItemHash.value(parentId.id());
            if (parentItem) {
                parentItem->appendRow(item);
            }
        }
        mFolderItemHash.insert(id.id(), item);
    }
```

#### AUTO 


```{c}
const auto excList = ewsItem[EwsItemFieldModifiedOccurrences].value<EwsOccurrence::List>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsFolder &folder : std::as_const(mRemoteChangedFolders)) {
        /* Create a collection for each folder. */
        Collection c = createFolderCollection(folder);

        /* Insert it into the global collection list. */
        mCollectionMap.insert(c.remoteId(), c);

        /* Determine the parent and insert a parent->child relationship.
         * Don't use Collection::setParentCollection() yet as the collection object will be updated
         * which will cause the parent->child relationship to be broken. This happens because the
         * collection object holds a copy of the parent collection object. An update to that
         * object in the list will not be visible in the copy inside of the child object. */
        auto parentId = folder[EwsFolderFieldParentFolderId].value<EwsId>();
        mParentMap.insert(parentId.id(), c.remoteId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QString memberUrl = KolabHelpers::createMemberUrl(item, username);
        if (!memberUrl.isEmpty()) {
            itemRemoteIds << memberUrl;
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::RenameJob(session);
```

#### AUTO 


```{c}
auto *job = new KIMAP::SubscribeJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->calendarsBox->setEnabled(false);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeCalendars;
        if (m_account->accountName() == m_settings->account()) {
            activeCalendars = m_settings->calendars();
        }
        m_ui->calendarsList->clear();
        for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            QListWidgetItem *item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }

        m_ui->calendarsBox->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(content, srv->portNumber(), [&](const QString &chunk) {
        const QString respHead = QStringLiteral("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
                "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
                "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
                "<soap:Header>"
                "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
                "</soap:Header>"
                "<soap:Body>"
                "<m:GetStreamingEventsResponse>"
                "<m:ResponseMessages>"
                "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
                "<m:ResponseCode>NoError</m:ResponseCode>"
                "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral("</m:GetStreamingEventsResponseMessage>"
                "</m:ResponseMessages>"
                "</m:GetStreamingEventsResponse>"
                "</soap:Body>"
                "</soap:Envelope>");
        const QString eventHead = QStringLiteral("<m:Notifications>"
                "<m:Notification>"
                "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral("<NewMailEvent>"
                "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
                "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
                "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
                "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediatelly" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready){
                if (ready) {
                    m_account = m_settings->accountPtr();
                    accountChanged();
                }
            }
```

#### AUTO 


```{c}
auto *storeList = qobject_cast<FileStore::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsSyncFolderHierarchyRequest::Change &ch : reqChanges) {
        FolderDescr fd;
        Collection c;

        switch (ch.type()) {
        case EwsSyncFolderHierarchyRequest::Update: {
            fd.ewsFolder = ch.folder();
            fd.flags |= FolderDescr::RemoteUpdated;
            auto id = fd.ewsFolder[EwsFolderFieldFolderId].value<EwsId>();
            mFolderHash.insert(id.id(), fd);

            /* For updated folders fetch the collection corresponding to that folder and its parent
             * (the parent will be needed in case of a collection move) */
            Collection c2;
            c2.setRemoteId(fd.parent());
            localFetchHash.insert(c2.remoteId(), c2);

            c.setRemoteId(id.id());
            localFetchHash.insert(c.remoteId(), c);
            break;
        }
        case EwsSyncFolderHierarchyRequest::Create: {
            fd.ewsFolder = ch.folder();
            fd.flags |= FolderDescr::RemoteCreated;
            auto id = fd.ewsFolder[EwsFolderFieldFolderId].value<EwsId>();
            mFolderHash.insert(id.id(), fd);

            c.setRemoteId(fd.parent());
            /* For created folders fetch the parent collection on Exchange side. Don't do this
             * when the parent collection has also been created as it would fail. */
            if (!mFolderHash.value(fd.parent()).isCreated()) {
                localFetchHash.insert(c.remoteId(), c);
            }
            break;
        }
        case EwsSyncFolderHierarchyRequest::Delete:
            fd.flags |= FolderDescr::RemoteDeleted;
            mFolderHash.insert(ch.folderId().id(), fd);

            /* For deleted folders fetch the collection corresponding to the deleted folder. */
            c.setRemoteId(ch.folderId().id());
            localFetchHash.insert(c.remoteId(), c);
            break;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
auto *subscribe = new KIMAP::SubscribeJob(create->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. " << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (davCollection.color().isValid()) {
            CollectionColorAttribute *colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
            colorAttr->setColor(davCollection.color());
        }

        if (!davCollection.displayName().isEmpty()) {
            EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalendarCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalendarCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalendarCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalendarCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        DavProtocolAttribute *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after successful sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        readFile();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : supportedProtocols) {
        Url url;

        if (protocol == QLatin1String("CalDav")) {
            url.protocol =KDAV::CalDav;
        } else if (protocol == QLatin1String("CardDav")) {
            url.protocol = KDAV::CardDav;
        } else if (protocol == QLatin1String("GroupDav")) {
            url.protocol = KDAV::GroupDav;
        } else {
            return urls;
        }

        QString urlStr = settingsToUrl(this, protocol);

        if (!urlStr.isEmpty()) {
            url.url = urlStr;
            url.userName = QStringLiteral("$default$");
            urls << url;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QByteArray data = md.readEntry(item.remoteId());

        KMime::Message *mail = new KMime::Message();
        mail->setContent(KMime::CRLFtoLF(data));
        mail->parse();
        // Some messages may have an empty body
        if (mail->body().isEmpty()) {
            if (parts.contains("PLD:BODY") || parts.contains("PLD:RFC822")) {
                // In that case put a space in as body so that it gets cached
                // otherwise we'll wrongly believe the body part is missing from the cache
                mail->setBody(" ");
            }
        }

        Item i(item);
        i.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, i);
        rv.push_back(i);
    }
```

#### AUTO 


```{c}
const auto transportAttribute = item.attribute<TransportAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("fileChanged:")
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Agent,
                                                                  QStringLiteral("akonadi_mailfilter_agent"));
```

#### AUTO 


```{c}
auto flagsAttribute = new Akonadi::CollectionFlagsAttribute(m_flags);
```

#### AUTO 


```{c}
auto it = data.constBegin(), end = data.constEnd();
```

#### AUTO 


```{c}
const auto networkError = reply->networkError();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &zone : zones) {
        const QString cityName = QString::fromUtf8(zone.split('/').last());
        Q_ASSERT(!countryMap.contains(cityName));
        countryMap.insert(cityName, QString::fromUtf8(zone));
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::AppendJob(session);
```

#### AUTO 


```{c}
auto *colJob = qobject_cast<FileStore::CollectionDeleteJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &root : qAsConst(allRoots)) {
        const QMap<QByteArray, qint64> limit = quotaJob->allLimits(root);
        const QMap<QByteArray, qint64> usage = quotaJob->allUsages(root);

        // Process IMAP Quota roots with associated quotas only
        if (!limit.isEmpty() && !usage.isEmpty()) {
            newRoots << root;
            newLimits << limit;
            newUsages << usage;

            const QString &decodedRoot = QString::fromUtf8(KIMAP::decodeImapFolderName(root));

            if (decodedRoot == mailBox) {
                newCurrent = newUsages.last()["STORAGE"] * 1024;
                newMax = newLimits.last()["STORAGE"] * 1024;
            }
        }
    }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsPoxAutodiscoverRequest *>(job);
```

#### AUTO 


```{c}
auto *compactJob = qobject_cast<FileStore::StoreCompactJob *>(job);
```

#### AUTO 


```{c}
const auto transport = TransportManager::self()->transportById(transportAttribute->transportId(), false);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &, const Akonadi::Collection &) {
            settleTimer.start(serverSettleTimeout);
        }
```

#### AUTO 


```{c}
auto colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto job = new FreeBusyQueryJob(email, QDateTime::currentDateTimeUtc(), QDateTime::currentDateTimeUtc().addSecs(3600), m_settings->accountPtr(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        bool translationOk = true;
        imapItems << translateToImap(item, translationOk);
        if (!translationOk) {
            ok = false;
        }
    }
```

#### AUTO 


```{c}
auto *fetchJob = new CollectionFetchJob(collection, CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[&contact](const Item &item) {
            return item.remoteId() == contact->uid();
        }
```

#### AUTO 


```{c}
const auto uidNext = parent.attribute<UidNextAttribute>();
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::ItemModifyJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : tags) {
            if (!mTagStore->containsId(tag.id())) {
                unknownTags.append(tag);
            }
        }
```

#### AUTO 


```{c}
const auto transportResult = static_cast<TransportResourceBase::TransportResult>(result);
```

#### AUTO 


```{c}
const auto respToken = buildAuthResponse(params);
```

#### AUTO 


```{c}
auto *d = reinterpret_cast<EwsItemPrivate *>(this->d.data());
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenJob, url]() {
                        if (tokenJob->error()) {
                            emitError(tokenJob->errorText());
                            return;
                        }

                        QUrl url_ = url;
                        url_.removeQueryItem(QStringLiteral("access_token"));
                        url_.addQueryItem(QStringLiteral("access_token"), tokenJob->token());
                        sendRequest(url_);
                    }
```

#### AUTO 


```{c}
auto col = fetchJob->collection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            qCDebug(KOLABRESOURCE_LOG) << "member(localid, remoteid): " << item.id() << item.remoteId();
        }
```

#### AUTO 


```{c}
auto &attendee
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &incidence : std::as_const(mIncidences)) {
        Item item;
        item.setRemoteId(incidence->instanceIdentifier());
        item.setMimeType(incidence->mimeType());
        items.append(item);
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(pathPart);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { dispatch(); }
```

#### AUTO 


```{c}
auto deleteJob = new ItemDeleteJob(Akonadi::valuesToVector(mServerItemsByRemoteId), transaction());
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<FileStore::ItemFetchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, QXmlResultItems &, const QXmlNamePool &) {
        requestTriggered = true;
        return FakeEwsServer::DialogEntry::HttpResponse(IsolatedTestBase::loadResourceAsString(QStringLiteral(":/xml/errorserverbusy")), 200);
    }
```

#### AUTO 


```{c}
auto *itemModify = new ItemModifyJob(item, transaction());
```

#### AUTO 


```{c}
auto contact = item.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto job = qobject_cast<EwsPKeyAuthJob *>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee &attendee : attendees) {
            const User user = Users::self()->lookupEmail(attendee.email());

            if (!user.isValid()) {
                continue;
            }

            QString status;
            switch (attendee.status()) {
            case KCalCore::Attendee::Accepted:
                status = QStringLiteral("accept");
                break;
            case KCalCore::Attendee::Declined:
                status = QStringLiteral("decline");
                break;
            default:
                status = QStringLiteral("none");
                break;
            }

            QDomElement element = DAVUtils::addOxElement(document, members, QStringLiteral("user"), OXUtils::writeNumber(user.uid()));
            DAVUtils::setOxAttribute(element, QStringLiteral("confirm"), status);
        }
```

#### AUTO 


```{c}
auto *job = new ItemDeleteJob(items);
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsGetItemRequest *req) {
            return req->responses();
        }
```

#### AUTO 


```{c}
auto msg = mItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto toolbar = new QToolBar(QStringLiteral("MigrationControlToolbar"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &day : days) {
        auto dowIndex = decodeEnumString<short>(day, dayOfWeekNames, dayOfWeekNameCount, &ok);
        if (reader.error() != QXmlStreamReader::NoError || !ok) {
            qCWarning(EWSCLI_LOG) << QStringLiteral("Failed to read EWS request - invalid %1 element (value: %2).").arg(QStringLiteral("DaysOfWeek").arg(day));
            return false;
        }
        if (dowIndex == 7) { // "Day"
            dow.fill(true, 0, 7);
        } else if (dowIndex == 8) { // "Weekday"
            dow.fill(true, 0, 5);
        } else if (dowIndex == 9) { // "WeekendDay"
            dow.fill(true, 5, 7);
        } else {
            dow.setBit(dowIndex);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &h : std::as_const(parameters)) {
        if (first) {
            first = false;
        } else {
            ret.append("&");
        }
        ret.append(QUrl::toPercentEncoding(QString::fromLatin1(h.name)) + "=" + QUrl::toPercentEncoding(QString::fromLatin1(h.value)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavCollection &collection : collections) {
        addModelRow(collection.displayName(), collection.url());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &id : ids) {
                KIMAP::SetAclJob *job = new KIMAP::SetAclJob(session);
                job->setMailBox(mailBoxForCollection(collection()));
                job->setIdentifier(id);
                job->setRights(KIMAP::SetAclJob::Change, rights[id]);

                connect(job, &KIMAP::SetAclJob::result, this, &ChangeCollectionTask::onSetAclDone);

                job->start();

                m_pendingJobs++;
            }
```

#### AUTO 


```{c}
auto status = qobject_cast<KIMAP::StatusJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        try {
            auto msg = item.payload<KMime::Message::Ptr>();
            const QByteArray messageId = msg->messageID()->asUnicodeString().toUtf8();
            if (!messageId.isEmpty()) {
                m_messageIds.insert(item.id(), messageId);
            }

            set.add(item.remoteId().toLong());
        } catch (const Akonadi::PayloadException &e) {
            Q_UNUSED(e)
            qCWarning(IMAPRESOURCE_LOG) << "Move failed, payload exception " << item.id() << item.remoteId();
            cancelTask(i18n("Failed to move item, it has no message payload. Remote id: %1", item.remoteId()));
            return;
        }
    }
```

#### AUTO 


```{c}
auto *quotaAttribute
        = m_collection.attribute<Akonadi::CollectionQuotaAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const AgentInstance &instance, bool state) {
                if (instance == *mEwsInstance && state == online) {
                    qDebug() << "is online" << state;
                    loop.exit(0);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
                const QVariant tagListVar = tagListHash[item.remoteId()];
                if (tagListVar.isValid()) {
                    const QStringList tagList = tagListVar.toStringList();
                    if (!tagListHash.isEmpty()) {
                        TagContext tag;
                        tag.mItem = item;
                        tag.mTagList = tagList;

                        taggedItems << tag;
                    }
                }
            }
```

#### AUTO 


```{c}
auto job = new TomboyItemsDownloadJob(collection.id(), mManager, this);
```

#### AUTO 


```{c}
const auto &tzid
```

#### AUTO 


```{c}
static const auto KWalletFolder = QStringLiteral("Facebook");
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const BaseHandler::Ptr &handler) {
                               return handler->mimeType() == mimeType;
                           }
```

#### AUTO 


```{c}
const auto event
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                mSubscriptions.reset();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ]() {
        Q_EMIT status(Akonadi::AgentBase::Idle, QString());
    }
```

#### AUTO 


```{c}
auto job = new TaskListDeleteJob(collection.remoteId(), m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        qCWarning(EWSRES_LOG) << "Timeout waiting for wallet open for read";
        onWalletOpenedForRead(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto iType : toFetchItems.keys()) {
        for (int i = 0; i < toFetchItems[iType].size(); i += fetchBatchSize) {
            EwsItemHandler *handler = EwsItemHandler::itemHandler(static_cast<EwsItemType>(iType));
            if (!handler) {
                // TODO: Temporarily ignore unsupported item types.
                qCWarning(EWSRES_LOG) << QStringLiteral("Unable to initialize fetch for item type %1").arg(iType);
                /*setErrorMsg(QStringLiteral("Unable to initialize fetch for item type %1").arg(iType));
                emitResult();
                return;*/
            } else {
                EwsFetchItemDetailJob *job = handler->fetchItemDetailJob(mClient, this, mCollection);
                Item::List itemList = toFetchItems[iType].mid(i, fetchBatchSize);
                job->setItemLists(itemList, &mDeletedItems);
                connect(job, &KJob::result, this, &EwsFetchItemsJob::itemDetailFetchDone);
                addSubjob(job);
                fetch = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::string &s : l) {
        list.append(Conversion::fromStdString(s));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Attendee *delegatee : std::as_const(delegateesRef)) {
        std::vector<Kolab::ContactReference> delegatedFrom = delegatee->delegatedFrom();
        for (Attendee *delegator : std::as_const(delegatorsRef)) {
            // Set the delegator on each delegatee
            const ContactReference &delegatorRef = delegator->contact();
            if (!contains(delegatorRef, delegatedFrom)) {
                delegatedFrom.emplace_back(Kolab::ContactReference::EmailReference, delegatorRef.email(), delegatorRef.name());
            }

            // Set the delegatee on each delegator
            std::vector<Kolab::ContactReference> delegatedTo = delegator->delegatedTo();
            const ContactReference &delegaeeRef = delegatee->contact();
            if (!contains(delegaeeRef, delegatedTo)) {
                delegatedTo.emplace_back(Kolab::ContactReference::EmailReference, delegaeeRef.email(), delegaeeRef.name());
            }
            delegator->setDelegatedTo(delegatedTo);
        }
        delegatee->setDelegatedFrom(delegatedFrom);
    }
```

#### AUTO 


```{c}
auto closeJob = new KIMAP::CloseJob(mSession);
```

#### AUTO 


```{c}
auto *tokenReply = qobject_cast<QNetworkReply *>(sender());
```

#### AUTO 


```{c}
const auto itemsToMove = items();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        localFoldersChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&oAuth, &events, password](bool) {
            events.append(QStringLiteral("RequestWalletPassword"));
            oAuth.walletPasswordRequestFinished(password);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &capability : expected) {
        if (!m_capabilities.contains(capability)) {
            missing << capability;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { doEmitResult(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &outbox : principalScheduleOutboxFromEmail) {
        ++mRequestsTracker[email].retrievalJobCount;
        const uint requestId = mNextRequestId++;

        QUrl url(outbox);
        KIO::StoredTransferJob *job = KIO::storedHttpPost(fbData, url);
        job->addMetaData(QStringLiteral("content-type"), QStringLiteral("text/calendar"));
        job->setProperty("email", QVariant::fromValue(email));
        job->setProperty("request-id", QVariant::fromValue(requestId));
        connect(job, &KDAV::DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onRetrieveFreeBusyJobFinished);
        job->start();
    }
```

#### AUTO 


```{c}
const auto changedPhotos = map[QStringLiteral("modified")].toStringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : keys) {
        QString val = map[key].toString();
        val.replace(QLatin1Char('"'), QStringLiteral("\\\""));
        elems.append(QStringLiteral("\"%1\":\"%2\"").arg(key, val));
    }
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        CalendarPtr calendar = object.dynamicCast<Calendar>();

        QListWidgetItem *item = new QListWidgetItem(calendar->title());
        item->setData(Qt::UserRole, calendar->uid());
        item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
        item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
        m_calendarsList->addItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return true;
                                    };
        wallet->createFolderCallback = [](const QString &) {
                                           return false;
                                       };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return true;
                                    };
        wallet->readPasswordCallback = [](const QString &, QString &password) {
                                           password = QStringLiteral("foo");
                                           return true;
                                       };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<OXA::ObjectsRequestDeltaJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : qAsConst(response)) {
                extraTokens.insert(key, response.value(key));
            }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::RelationFetchJob(relation);
```

#### AUTO 


```{c}
auto *listJob = qobject_cast<ListJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &exception : qAsConst(exceptions)) {
            if (exception->status() == KCalCore::Incidence::StatusCanceled) {
                QDateTime exDateTime(exception->recurrenceId());
                mainIncidence->recurrence()->addExDateTime(exDateTime);
            } else {
                // The exception remote id will contain a fragment pointing to
                // its instance identifier to distinguish it from the main
                // event.
                QString rid = target.remoteId() + QLatin1String("#") + exception->instanceIdentifier();
                qCDebug(DAVRESOURCE_LOG) << "Extra incidence at" << rid;
                Akonadi::Item extraItem = target;
                extraItem.setRemoteId(rid);
                extraItem.setRemoteRevision(source.etag());
                extraItem.setMimeType(exception->mimeType());
                extraItem.setPayload<IncidencePtr>(exception);
                extraItems << extraItem;
            }
        }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsModifyItemFlagsJob *>(job);
```

#### AUTO 


```{c}
const auto contactAddresses{addressee.addresses()};
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(request, srv->portNumber());
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsFetchFoldersIncrJob *>(job);
```

#### AUTO 


```{c}
auto *idJob = new KIMAP::IdJob(nsJob->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &alreadyDownloadedUID : seenUidList) {
        const int alreadyDownloadedID = mUidsToIdsMap.value(alreadyDownloadedUID, -1);
        if (alreadyDownloadedID != -1) {
            bytesRemainingOnServer += mIdsToSizeMap.value(alreadyDownloadedID);
        }
    }
```

#### AUTO 


```{c}
const auto intervals{m_currentSet.intervals()};
```

#### AUTO 


```{c}
auto normalizedId = QTimeZone::windowsIdToDefaultIanaId(tz.toLatin1());
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader, const QString &) {
        if (!readResponseElement(reader)) {
            setErrorMsg(QStringLiteral("Failed to read EWS request - invalid response element."));
            return false;
        }
        return true;
    }
```

#### AUTO 


```{c}
auto grp = new QGroupBox(i18n("Choose which fields to show:"), parent);
```

#### AUTO 


```{c}
auto *job = new RetrieveItemsJob(col, md, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::cDateTime &dt : recurrenceDates) {
        const QDateTime &date = toDate(dt);
        if (dt.isDateOnly()) {
            e.recurrence()->addRDate(date.date());
        } else {
            e.recurrence()->addRDateTime(date);
        }
    }
```

#### AUTO 


```{c}
auto migrator = new GidMigrator(mimeType);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
auto job = new EwsGlobalTagsReadJob(mTagStore, mEwsClient, mRootCollection, this);
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(QStringLiteral("testreq"), srv->portNumber());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        mItemQueue.enqueue(item);
    }
```

#### AUTO 


```{c}
auto *vLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto ref = job->property("QEventLoopLocker").value<QEventLoopLocker *>();
```

#### LAMBDA EXPRESSION 


```{c}
[&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return false;
        }
```

#### AUTO 


```{c}
auto idRef = reader.attributes().value(QStringLiteral("Id"));
```

#### AUTO 


```{c}
auto listJob = qobject_cast<UIDListJob *>(job);
```

#### AUTO 


```{c}
const auto eAttachments{e.attachments()};
```

#### AUTO 


```{c}
const auto utc = dt.toUTC();
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemDeleteJob(davItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (Attendee *delegatee : qAsConst(delegateesRef)) {
        std::vector<Kolab::ContactReference> delegatedFrom = delegatee->delegatedFrom();
        for (Attendee *delegator : qAsConst(delegatorsRef)) {
            // Set the delegator on each delegatee
            const ContactReference &delegatorRef = delegator->contact();
            if (!contains(delegatorRef, delegatedFrom)) {
                delegatedFrom.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegatorRef.email(), delegatorRef.name()));
            }

            // Set the delegatee on each delegator
            std::vector<Kolab::ContactReference> delegatedTo = delegator->delegatedTo();
            const ContactReference &delegaeeRef = delegatee->contact();
            if (!contains(delegaeeRef, delegatedTo)) {
                delegatedTo.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegaeeRef.email(), delegaeeRef.name()));
            }
            delegator->setDelegatedTo(delegatedTo);
        }
        delegatee->setDelegatedFrom(delegatedFrom);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : tags) {
        QByteArray serialized = serializeTag(tag);
        auto it = mTagData.find(tag.gid());
        /* First check if the tag exists or if it has been changed. Only once that is done
         * check if the store knows the tag name and Akonadi id. The separation is necessary as
         * the store might have the full list of tags from Exchange, but without Akonadi IDs. When
         * a sync is done it may only yield those IDs without any of the tags changed. In such case
         * the function should return false as no actual change has been made.
         */
        if ((it == mTagData.end()) || (*it != serialized)) {
            mTagData.insert(tag.gid(), serialized);
            changed = true;
        }
        if (it != mTagData.end()) {
            tagIds.removeOne(tag.gid());
        }
        if (!mTagIdMap.contains(tag.id())) {
            mTagIdMap.insert(tag.id(), tag.gid());
            QString name;
            if (tag.hasAttribute<TagAttribute>()) {
                name = tag.attribute<TagAttribute>()->displayName();
            } else {
                name = tag.name();
            }
            if (!name.isEmpty()) {
                mTagNameMap.insert(tag.id(), tag.name());
            }
        }
    }
```

#### AUTO 


```{c}
const auto attendees{e.attendees()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &addressee : qAsConst(mAddressees)) {
        Item item;
        item.setRemoteId(addressee.uid());
        item.setMimeType(KContacts::Addressee::mimeType());
        items.append(item);
    }
```

#### AUTO 


```{c}
const auto totalItems = mRemoteAddedItems.size() + mRemoteChangedItems.size() + mRemoteDeletedIds.size() +
            mRemoteFlagChangedIds.size();
```

#### AUTO 


```{c}
auto *detailJob = qobject_cast<EwsFetchItemDetailJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            const User user = Users::self()->lookupEmail(attendee->email());

            if (!user.isValid()) {
                continue;
            }

            QString status;
            switch (attendee->status()) {
            case KCalCore::Attendee::Accepted: status = QStringLiteral("accept"); break;
            case KCalCore::Attendee::Declined: status = QStringLiteral("decline"); break;
            default: status = QStringLiteral("none"); break;
            }

            QDomElement element = DAVUtils::addOxElement(document, members, QStringLiteral("user"), OXUtils::writeNumber(user.uid()));
            DAVUtils::setOxAttribute(element, QStringLiteral("confirm"), status);
        }
```

#### AUTO 


```{c}
auto *requestJob = new Akonadi::SpecialMailCollectionsRequestJob(this);
```

#### AUTO 


```{c}
const auto bhAttribute = sentItem.attribute<MailTransport::SentBehaviourAttribute>();
```

#### AUTO 


```{c}
auto collectionColor = QString::fromUtf8(etebase_collection_metadata_get_color(metaData.get()));
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto const aclAttribute = m_collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto search = new KIMAP::SearchJob(mSession);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(mMaildirCollection);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsMoveFolderRequest *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return false;
        }
```

#### AUTO 


```{c}
auto *vboxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto etag = mEtagCaches[collection.remoteId()];
```

#### AUTO 


```{c}
const auto document = QJsonDocument::fromJson(data);
```

#### AUTO 


```{c}
const auto &head = mFetchItemsJobQueue.head();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        itemFetched(job);
    }
```

#### AUTO 


```{c}
auto *const fetchJob = qobject_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(collection, CollectionFetchJob::Base);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate &date : exclusions) {
        writeString(e, QStringLiteral("exclusion"), dateToString(date));
    }
```

#### AUTO 


```{c}
auto *session2 = sessionSpy.at(1).at(1).value<KIMAP::Session *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            onSelectDone(job);
        }
```

#### AUTO 


```{c}
auto promise = KGAPI2::AccountManager::instance()->getAccount(GOOGLE_API_KEY,
                                                                      GOOGLE_API_SECRET,
                                                                      mResource->settings()->userName(),
                                                                      {KGAPI2::Account::mailScopeUrl()});
```

#### AUTO 


```{c}
auto attr = new ImapAclAttribute(mRights, mOldRights);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetEventsRequest::Notification &nfy : notifications) {
            const auto nfyEvents{nfy.events()};
            for (const EwsGetEventsRequest::Event &event : nfyEvents) {
                bool skip = false;
                mSettings->setEventSubscriptionWatermark(event.watermark());
                if (!skip) {
                    switch (event.type()) {
                    case EwsCopiedEvent:
                    case EwsMovedEvent:
                        if (!event.itemIsFolder()) {
                            mUpdatedFolderIds.insert(event.oldParentFolderId());
                        }
                    /* fall through */
                    case EwsCreatedEvent:
                    case EwsDeletedEvent:
                    case EwsModifiedEvent:
                    case EwsNewMailEvent:
                        if (event.itemIsFolder()) {
                            mFolderTreeChanged = true;
                        } else {
                            mUpdatedFolderIds.insert(event.parentFolderId());
                        }
                        break;
                    case EwsStatusEvent:
                        // Do nothing
                        break;
                    default:
                        break;
                    }
                }
            }
            if (nfy.hasMoreEvents()) {
                moreEvents = true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentId](const Item &item) {
                return item.remoteId() == parentId;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            qCDebug(ETESYNC_LOG) << "Login finished";
            static_cast<LoginPage *>(page(W_LoginPage))->setLoginResult(static_cast<LoginJob *>(job)->getLoginResult());
            static_cast<LoginPage *>(page(W_LoginPage))->setUserInfoResult(static_cast<LoginJob *>(job)->getUserInfoResult());
            static_cast<LoginPage *>(page(W_LoginPage))->setErrorCode(job->error());
            static_cast<LoginPage *>(page(W_LoginPage))->setErrorMessage(job->errorText());
            static_cast<LoginPage *>(page(W_LoginPage))->hideProgressBar();
            nextId() == -1 ? QWizard::accept() : QWizard::next();
        }
```

#### AUTO 


```{c}
auto it = usages.cbegin(), end = usages.cend();
```

#### AUTO 


```{c}
auto handler = fetchHandlerByMimetype(items.first().mimeType());
```

#### AUTO 


```{c}
auto job = KIO::storedGet(url, KIO::NoReload, KIO::HideProgressInfo);
```

#### AUTO 


```{c}
auto tab = new QTabWidget(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return false;
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job){
            if (!m_iface->handleError(job)) {
                return;
            }

            ContactsGroupPtr group = qobject_cast<ContactsGroupCreateJob *>(job)->items().first().dynamicCast<ContactsGroup>();
            qCDebug(GOOGLE_CONTACTS_LOG) << "Contact group created:" << group->id();
            Collection newCollection(collection);
            setupCollection(newCollection, group);
            m_collections[ newCollection.remoteId() ] = newCollection;
            m_iface->collectionChangeCommitted(newCollection);
            emitReadyStatus();
        }
```

#### AUTO 


```{c}
auto job = createRetrieveCollectionsJob();
```

#### AUTO 


```{c}
const auto flagsProperties = EwsMailHandler::flagsProperties();
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        CalendarPtr calendar = qobject_cast<CalendarCreateJob *>(job)->items().first().dynamicCast<Calendar>();
        qCDebug(GOOGLE_CALENDAR_LOG) << "Created calendar" << calendar->uid();
        // Enable newly added calendar in settings, otherwise user won't see it
        m_settings->addCalendar(calendar->uid());
        // TODO: the calendar returned by google is almost empty, i.e. it's not "editable",
        // does not contain the color, etc
        calendar->setEditable(true);
        // Populate remoteId & other stuff
        Collection newCollection(collection);
        setupCollection(newCollection, calendar);
        m_iface->collectionChangeCommitted(newCollection);
        emitReadyStatus();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QNetworkCookie &cookie) {
                mCookies.remove(cookie.name());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &childId : children) {
        Collection child(mCollectionMap.take(childId));
        child.setParentCollection(col);
        q->mFolders.append(child);
        buildChildCollectionList(child);
    }
```

#### AUTO 


```{c}
auto attendeeRsvp = [](const QString & status) {
        if (status == QLatin1String("maybe")) {
            return KCalCore::Attendee::Tentative;
        } else if (status == QLatin1String("attending")) {
            return KCalCore::Attendee::Accepted;
        } else if (status == QLatin1String("declined")) {
            return KCalCore::Attendee::Declined;
        } else {
            return KCalCore::Attendee::NeedsAction;
        }
    };
```

#### AUTO 


```{c}
auto quotaJob = qobject_cast<KIMAP::GetQuotaRootJob *>(job);
```

#### AUTO 


```{c}
auto *annotationsAttribute = m_collection.attribute<Akonadi::CollectionAnnotationsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[](KWallet::MyWallet *) {
                                      return nullptr;
                                  }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->taskListsBox->setDisabled(true);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeTaskLists;
        if (m_account->accountName() == m_settings->account()) {
            activeTaskLists = m_settings->taskLists();
        }
        m_ui->taskListsList->clear();
        for (const ObjectPtr &object : objects) {
            const TaskListPtr taskList = object.dynamicCast<TaskList>();

            auto item = new QListWidgetItem(taskList->title());
            item->setData(Qt::UserRole, taskList->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->taskListsList->addItem(item);
        }

        m_ui->taskListsBox->setEnabled(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob*, const Akonadi::Item::List &items) {
                    itemsRetrieved(items);
                }
```

#### AUTO 


```{c}
const auto event = Kolab::fromXML<KCalendarCore::Journal::Ptr, KolabV2::Journal>(QString::fromUtf8(s.c_str()).toUtf8(), attachments);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tokenPair : std::as_const(tokens)) {
        // FIXME: We are decoding key and value again. This helps with Google OAuth, but is it mandated by the standard?
        QString key = QUrl::fromPercentEncoding(tokenPair.first.trimmed().toLatin1());
        QString value = QUrl::fromPercentEncoding(tokenPair.second.trimmed().toLatin1());
        queryParams.insert(key, value);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job){
                auto queryJob = qobject_cast<FreeBusyQueryJob *>(job);
                if (!m_iface->handleError(job, false)) {
                    m_iface->handlesFreeBusy(queryJob->id(), false);
                    return;
                }
                m_iface->handlesFreeBusy(queryJob->id(), true);
            }
```

#### AUTO 


```{c}
auto job = new SpecialMailCollectionsRequestJob(this);
```

#### AUTO 


```{c}
const auto dialogs{server->dialog()};
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &item) { return item.remoteId().isEmpty(); }
```

#### AUTO 


```{c}
auto j = qobject_cast<Akonadi::ItemModifyJob *>(job);
```

#### AUTO 


```{c}
auto it = mFolderHash.cbegin(), end = mFolderHash.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &subFolder : maildirSubFolders) {
        const Maildir subMd = md.subFolder(subFolder);

        if (!mMaildirs.contains(subMd.path())) {
            const MaildirPtr mdPtr = MaildirPtr(new MaildirContext(subMd));
            mMaildirs.insert(subMd.path(), mdPtr);
        }

        Collection col;
        col.setRemoteId(subFolder);
        col.setName(subFolder);
        col.setParentCollection(collection);
        fillMaildirCollectionDetails(subMd, col);
        collections << col;

        if (recurse) {
            fillMaildirTreeDetails(subMd, col, collections, true);
        }
    }
```

#### AUTO 


```{c}
const auto key = mIdentifier;
```

#### AUTO 


```{c}
auto *quotaJob = qobject_cast<KIMAP::GetQuotaRootJob *>(job);
```

#### AUTO 


```{c}
auto *fetchJob = new CollectionFetchJob(targetCollection,
                                                                  CollectionFetchJob::Base);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &kcalEvent : qAsConst(events)) {
        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KCalCore::Event has no alarms:" << kcalEvent->uid();
            continue;    // ignore events without alarms
        }

        const KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KAEvent has no alarms:" << event.id();
            continue;   // event has no usable alarms
        }

        Item item(mime);
        item.setRemoteId(kcalEvent->uid());
        item.setPayload(event);
        items << item;
    }
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto button = new QRadioButton(i18n("Use one of those servers:"), this);
```

#### AUTO 


```{c}
auto *expunge = new KIMAP::ExpungeJob(m_session);
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemCreateJob(davItem);
```

#### AUTO 


```{c}
const auto supportedFlags = fromAkonadiToSupportedImapFlags(addedFlags().toList(), items().at(0).parentCollection());
```

#### AUTO 


```{c}
auto it = firstChange;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry::Pair &entry : std::as_const(movedEntries)) {
                mIndexData.remove(entry.first.messageOffset());
            }
```

#### AUTO 


```{c}
auto quitJob = new QuitJob(mPopSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, account, instances](KJob *) {
        if (job->error()) {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: Failed to create new Google Groupware Resource:" << job->errorString();
            Q_EMIT message(Error, i18n("Failed to create a new Google Groupware Resource: %1", job->errorString()));
            setMigrationState(MigratorBase::Failed);
            return;
        }

        const auto newInstance = job->instance();
        if (!migrateAccount(account, instances, newInstance)) {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: failed to migrate account" << account;
            Q_EMIT message(Error, i18n("Failed to migrate account %1", account));
            setMigrationState(MigratorBase::Failed);
            return;
        }

        removeLegacyInstances(account, instances);

        // Reconfigure and restart the new instance
        newInstance.reconfigure();
        newInstance.restart();

        if (instances.calendarResource.isValid() ^ instances.contactResource.isValid()) {
            const auto res = instances.calendarResource.isValid() ? instances.calendarResource.identifier() : instances.contactResource.identifier();
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from" << res << "to" << newInstance.identifier();
        } else {
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from" << instances.calendarResource.identifier() << "and"
                                  << instances.contactResource.identifier() << "to" << newInstance.identifier();
        }
        Q_EMIT message(Success, i18n("Migrated account %1 to new Google Groupware Resource", account));

        ++mMigrationsDone;
        migrateNextAccount();
    }
```

#### AUTO 


```{c}
const auto removedTags{resourceState()->removedTags()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fileInfo : fileInfos) {
        if (fileInfo.isHidden() || !fileInfo.isReadable()) {
            continue;
        }

        const QString mboxPath = fileInfo.absoluteFilePath();

        MBoxPtr mbox = getOrCreateMBoxPtr(mboxPath);
        if (mbox->load(mboxPath)) {
            const QString subFolder = fileInfo.fileName();
            Collection col;
            col.setRemoteId(subFolder);
            col.setName(subFolder);
            col.setParentCollection(collection);
            mbox->mCollection = col;

            fillMBoxCollectionDetails(mbox, col);
            collections << col;

            if (recurse) {
                const QString subDirPath = Maildir::subDirPathForFolderPath(fileInfo.absoluteFilePath());
                const Maildir subMd(subDirPath, true);
                fillMaildirTreeDetails(subMd, col, collections, true);
            }
        } else {
            mMBoxes.remove(fileInfo.absoluteFilePath());
        }
    }
```

#### AUTO 


```{c}
auto it = sourceIds.cbegin();
```

#### AUTO 


```{c}
auto it = propertyHash.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uidOnServer : std::as_const(mIdsToUidsMap)) {
            if (alreadyDownloadedUIDs.contains(uidOnServer)) {
                const int idOfUIDOnServer = mUidsToIdsMap.value(uidOnServer, -1);
                Q_ASSERT(idOfUIDOnServer != -1);
                idsToDownload.removeAll(idOfUIDOnServer);
            }
        }
```

#### AUTO 


```{c}
auto *subscribe = new KIMAP::SubscribeJob(m_session);
```

#### AUTO 


```{c}
const auto members{relation.members()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : results) {
        if (result.value.startsWith(QLatin1Char('/'))) {
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            QUrl tmp(result.value);
            tmp.setUserInfo(QString());
            url = tmp;
        }
        davUrl.setUrl(url);

        if (result.property == caldav->principalHomeSet()) {
            davUrl.setProtocol(KDAV::CalDav);
        } else {
            davUrl.setProtocol(KDAV::CardDav);
        }

        KDAV::DavCollectionsFetchJob *fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
        connect(fetchJob, &KDAV::DavCollectionsFetchJob::result, this, &SearchDialog::onCollectionsFetchJobFinished);
        fetchJob->start();
        ++mSubJobCount;
    }
```

#### AUTO 


```{c}
auto *req = new EwsCreateFolderRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto &contactItem
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsOAuth *oAuth) {
            oAuth->init();
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : std::as_const(mDeletedItemOffsets)) {
        entries << KMBox::MBoxEntry(offset);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &contact) {
        Item item;
        item.setRemoteId(contact);
        return item;
    }
```

#### AUTO 


```{c}
auto *ntf = KNotification::event(QStringLiteral("authNeeded"),
                                     i18nc("@title", "%1 needs your attention.", agentName()),
                                     msg,
                                     QStringLiteral("im-google"),
                                     /*widget=*/ nullptr,
                                     KNotification::Persistent | KNotification::SkipGrouping);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MailTransport::SentActionAttribute::Action &action : lstAct) {
                sentActionHandler->runAction(action);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        ContactPtr contact = qobject_cast<ContactCreateJob *>(job)->items().first().dynamicCast<Contact>();
        Item newItem = item;
        qCDebug(GOOGLE_CONTACTS_LOG) << "Contact" << contact->uid() << "created";
        newItem.setRemoteId(contact->uid());
        newItem.setRemoteRevision(contact->etag());
        m_iface->itemChangeCommitted(newItem);
        newItem.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
        new ItemModifyJob(newItem, this);
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
const auto notifications{resp.notifications()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &loc : { QLatin1String("street"), QLatin1String("city"),
                                    QLatin1String("zip"), QLatin1String("country") }) {
                const auto it = location.constFind(loc);
                if (it != placeEnd) {
                    locationStr << it->toString();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. " << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (davCollection.color().isValid()) {
            CollectionColorAttribute *colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
            colorAttr->setColor(davCollection.color());
        }

        if (!davCollection.displayName().isEmpty()) {
            EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        DavProtocolAttribute *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after successful sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(Collection(collectionId(item.remoteId())), CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(parent);
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(msg, mList);
```

#### AUTO 


```{c}
auto authJob = qobject_cast<AuthJob *>(job);
```

#### AUTO 


```{c}
static const auto KWalletKeyToken = QStringLiteral("token");
```

#### AUTO 


```{c}
auto job = new FakeTransferJob(postData, vfy.fn, vfy.object);
```

#### AUTO 


```{c}
auto dialog = new QDialog(parent, Qt::Dialog);
```

#### AUTO 


```{c}
auto *store = new KIMAP::StoreJob(mSession);
```

#### AUTO 


```{c}
auto colorAttr = collection.attribute<CollectionColorAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QueuedUpdate &upd : updates) {
        mQueuedUpdates[upd.type].insert(upd.id, upd.changeKey);
        qCDebugNC(EWSRES_LOG) << QStringLiteral("Queued update %1 for item %2").arg(upd.type).arg(ewsHash(upd.id));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : calendars) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalendarCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection
                                 |Collection::CanCreateItem
                                 |Collection::CanChangeItem
                                 |Collection::CanDeleteItem);
        } else {
            collection.setRights(Collection::ReadOnly);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        auto colorAttr = collection.attribute<CollectionColorAttribute>(Collection::AddIfMissing);
        colorAttr->setColor(calendar->backgroundColor());

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(toplevelMailboxes)) {
            KIMAP::GetMetaDataJob *meta = new KIMAP::GetMetaDataJob(mSession);
            meta->setMailBox(mailbox + QLatin1String("*"));
            if (mServerCapabilities.contains(QLatin1String("METADATA"))) {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Metadata);
            } else {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Annotatemore);
            }
            meta->setDepth(KIMAP::GetMetaDataJob::AllLevels);
            for (const QByteArray &requestedEntry : qAsConst(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
            connect(meta, &KJob::result, this, &RetrieveMetadataJob::onGetMetaDataDone);
            mJobs++;
            meta->start();
        }
```

#### AUTO 


```{c}
auto *createJob = new Akonadi::TagCreateJob(tag, this);
```

#### AUTO 


```{c}
const auto cth = reply->header(QNetworkRequest::ContentTypeHeader);
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsOAuth *oAuth) {
        return oAuth->authenticate(true);
    }
```

#### AUTO 


```{c}
auto job = new TomboyCollectionsDownloadJob(Settings::collectionName(), mManager, this);
```

#### AUTO 


```{c}
auto *job = new FileStore::ItemFetchJob(collection, d->mSession);
```

#### AUTO 


```{c}
auto treeContainer = new QWidget(this);
```

#### AUTO 


```{c}
auto lineEdit = new KPasswordLineEdit();
```

#### AUTO 


```{c}
auto *agentCreateJob = new AgentInstanceCreateJob(ewsType);
```

#### AUTO 


```{c}
auto attr = new ImapAclAttribute();
```

#### AUTO 


```{c}
auto *aclAttribute = m_collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cat : categories) {
        writer.writeTextElement(ewsTypeNsUri, QStringLiteral("String"), cat);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const GenericHandler::Ptr &handler) {
        return handler->mimeType() == mimeType;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event &event : events) {
        KCalendarCore::Event::Ptr kcalEvent = Conversion::toKCalendarCore(event);
        kcalEvent->setCreated(QDateTime::currentDateTimeUtc()); //sets dtstamp
        calendar->addEvent(kcalEvent);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(mItem);
```

#### AUTO 


```{c}
const auto socket = mRedirectServer.nextPendingConnection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &info : infoList) {
        if (info.isDir()) {
            if (!removeDirectory(QDir(info.absoluteFilePath()))) {
                return false;
            }
        } else {
            if (!QFile::remove(info.filePath())) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(items)) {
        const auto flags = item.flags();
        for (const QByteArray &flag : flags) {
            ++flagCounts[flag];
        }
    }
```

#### AUTO 


```{c}
auto it = transitions.rbegin(), end = transitions.rend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &exception : qAsConst(exceptions)) {
            if (exception->status() == KCalendarCore::Incidence::StatusCanceled) {
                const QDateTime exDateTime(exception->recurrenceId());
                mainIncidence->recurrence()->addExDateTime(exDateTime);
            } else {
                // The exception remote id will contain a fragment pointing to
                // its instance identifier to distinguish it from the main
                // event.
                const QString rid = target.remoteId() + QLatin1String("#") + exception->instanceIdentifier();
                qCDebug(DAVRESOURCE_LOG) << "Extra incidence at" << rid;
                Akonadi::Item extraItem = target;
                extraItem.setRemoteId(rid);
                extraItem.setRemoteRevision(source.etag());
                extraItem.setMimeType(exception->mimeType());
                extraItem.setPayload<IncidencePtr>(exception);
                extraItems << extraItem;
            }
        }
```

#### AUTO 


```{c}
auto modJob = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(items.first().parentCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        error(QStringLiteral("User cancellation"), QStringLiteral("The authentication browser was closed"), QUrl());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : qAsConst(list)) {
        //We have to filter the list by time
        if (event->dtEnd() >= s && e >= event->dtStart()) {
            eventlist.push_back(Kolab::Conversion::fromKCalendarCore(*event));
        }
    }
```

#### AUTO 


```{c}
auto *examine = new KIMAP::SelectJob(session);
```

#### AUTO 


```{c}
auto attribute = collection.attribute<EntityDisplayAttribute>();
```

#### AUTO 


```{c}
auto *attr
        = mboxCollection.attribute<DeletedItemsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *aclAttribute = m_collection.attribute<Akonadi::ImapAclAttribute>();
```

#### AUTO 


```{c}
auto *attribute = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setPassword(QStringLiteral("foo"));
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return false;
        };
        wallet->createFolderCallback = [&createFolderCalled](const QString &) {
            createFolderCalled = true;
            return true;
        };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return false;
        };
        wallet->writePasswordCallback = [&](const QString &, const QString &p) {
            password = p;
            loop.exit(0);
            return true;
        };
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setPassword(QStringLiteral("foo"));
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return false;
        };
        wallet->createFolderCallback = [&createFolderCalled](const QString &) {
            createFolderCalled = true;
            return true;
        };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return false;
        };
        wallet->writePasswordCallback = [&](const QString &, const QString &p) {
            password = p;
            loop.exit(0);
            return true;
        };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto cache = mEtagCaches.value(collection.remoteId());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        doTransport();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            emitError(job->errorText());
            return;
        }

        const auto json = QJsonDocument::fromJson(qobject_cast<KIO::StoredTransferJob *>(job)->data());
        const auto me = json.object();

        d->userName = me.value(QStringLiteral("name")).toString();
        d->id = me.value(QStringLiteral("id")).toString();
        d->wallet->writeMap(
            mIdentifier,
            {{KWalletKeyToken, d->token}, {KWalletKeyName, d->userName}, {KWalletKeyId, d->id}, {KWalletKeyCookies, QString::fromUtf8(d->cookies)}});
        emitResult();
    }
```

#### AUTO 


```{c}
const auto collection = data(index, Akonadi::EntityTreeModel::CollectionRole).value<Akonadi::Collection>();
```

#### AUTO 


```{c}
const auto entries{mMBox.entries()};
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectRequestJob(object, this);
```

#### AUTO 


```{c}
auto req = new EwsGetItemRequest(mClient, this);
```

#### CONST EXPRESSION 


```{c}
constexpr int serverSettleTimeout = 200;
```

#### AUTO 


```{c}
auto *acl = qobject_cast<KIMAP::GetAclJob *>(job);
```

#### AUTO 


```{c}
auto checkBox = new QCheckBox(i18nc("@option:check", "Subscribed only"), mainWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this](FakeTransferJob* job, const QByteArray &req){
        verifier(job, req, request, response);
    }
```

#### AUTO 


```{c}
const auto *attr = col.attribute<DeletedItemsAttribute>()
```

#### AUTO 


```{c}
auto folderReq = new EwsGetFolderRequest(mClient, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
                if (job->error()) {
                    emitError(job->errorText());
                    return;
                }

                auto cal = KCalCore::MemoryCalendar::Ptr::create(KDateTime::LocalZone);
                KCalCore::ICalFormat format;
                if (!format.fromRawString(cal, job->data(), false)) {
                    emitError(i18n("Failed to parse birthday calendar"));
                    return;
                }

                const auto events = cal->events();
                for (const auto &event : events) {
                    processEvent(event);
                }

                emitResult();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsSyncFolderHierarchyRequest::Change &ch : reqChanges) {
        if (ch.type() == EwsSyncFolderHierarchyRequest::Create) {
            mRemoteFolderIds.append(ch.folder()[EwsFolderFieldFolderId].value<EwsId>());
        } else {
            q->setErrorMsg(QStringLiteral("Got non-create change for full sync."));
            q->emitResult();
            return;
        }
    }
```

#### AUTO 


```{c}
auto job = new OXA::FoldersRequestDeltaJob(Settings::self()->foldersLastSync(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, account, instances](KJob *) {
                if (job->error()) {
                    qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: Failed to create new Google Groupware Resource:" << job->errorString();
                    message(Error, i18n("Failed to create a new Google Groupware Resource: %1", job->errorString()));
                    setMigrationState(MigratorBase::Failed);
                    return;
                }

                const auto newInstance = job->instance();
                if (!migrateAccount(account, instances, newInstance)) {
                    qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: failed to migrate account" << account;
                    message(Error, i18n("Failed to migrate account %1", account));
                    setMigrationState(MigratorBase::Failed);
                    return;
                }

                removeLegacyInstances(account, instances);

                // Reconfigure and restart the new instance
                newInstance.reconfigure();
                newInstance.restart();

                if (instances.calendarResource.isValid() ^ instances.contactResource.isValid()) {
                    const auto res = instances.calendarResource.isValid()
                                        ? instances.calendarResource.identifier()
                                        : instances.contactResource.identifier();
                    qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from" << res
                                           << "to" << newInstance.identifier();
                } else {
                    qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from"
                                           << instances.calendarResource.identifier() << "and"
                                           << instances.contactResource.identifier() << "to"
                                           << newInstance.identifier();
                }
                message(Success, i18n("Migrated account %1 to new Google Groupware Resource", account));

                ++mMigrationsDone;
                migrateNextAccount();
            }
```

#### AUTO 


```{c}
auto *noSelectAttribute = new NoSelectAttribute();
```

#### AUTO 


```{c}
auto syncFoldersReq = new EwsSyncFolderHierarchyRequest(d->mClient, this);
```

#### AUTO 


```{c}
auto job = new FileStore::CollectionDeleteJob(collection, d->mSession);
```

#### AUTO 


```{c}
auto event = KCalendarCore::Event::Ptr::create();
```

#### AUTO 


```{c}
auto *select = new KIMAP::SelectJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : changedItems) {
                if (item.isValid()) {
                    mChangedItems.append(item);
                } else {
                    mNewItems.append(item);
                }
            }
```

#### AUTO 


```{c}
auto vboxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto currentUidValidity = new UidValidityAttribute(m_uidValidity);
```

#### AUTO 


```{c}
auto deleteJob = new DeletePasswordJob(QStringLiteral("imap"));
```

#### AUTO 


```{c}
const auto result = etesync_journal_manager_delete(mClientState->journalManager(), journal.get());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : addressesEmails) {
        if ((prefEmail == -1) && (e == addressee.preferredEmail())) {
            prefEmail = count;
        }
        count++;
        emails.emplace_back(toStdString(e), emailTypesFromStringlist(addressee.custom(QStringLiteral("KOLAB"), QStringLiteral("EmailTypes%1").arg(e))));
    }
```

#### AUTO 


```{c}
auto *loginJob = new KIMAP::LoginJob(session);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        Item newItem = item;
        const TaskPtr task = qobject_cast<TaskCreateJob *>(job)->items().first().dynamicCast<Task>();
        qCDebug(GOOGLE_TASKS_LOG) << "Task added";
        newItem.setRemoteId(task->uid());
        newItem.setRemoteRevision(task->etag());
        newItem.setGid(task->uid());
        m_iface->itemChangeCommitted(newItem);
        newItem.setPayload<KCalendarCore::Todo::Ptr>(task.dynamicCast<KCalendarCore::Todo>());
        new ItemModifyJob(newItem, this);
        emitReadyStatus();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, items, detachItems](KGAPI2::Job *job){
            if (job->error()) {
                m_iface->cancelTask(i18n("Failed to reparent subtasks: %1", job->errorString()));
                return;
            }
            // Update items inside Akonadi DB too
            new ItemModifyJob(detachItems);
            // Perform actual removal
            doRemoveTasks(items);
        }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(dlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMoveItemRequest::Response &resp : reqResponses) {
        Item &item = *it;
        if (resp.isSuccess()) {
            qCDebugNC(EWSRES_AGENTIF_LOG)
                << QStringLiteral("itemsMoved: succeeded for item %1 (new id: %2)").arg(ewsHash(item.remoteId()), ewsHash(resp.itemId().id()));
            if (item.isValid()) {
                item.setRemoteId(resp.itemId().id());
                item.setRemoteRevision(resp.itemId().changeKey());
                movedItems.append(item);
            }
        } else {
            Q_EMIT warning(QStringLiteral("Move failed for item %1").arg(item.remoteId()));
            qCDebugNC(EWSRES_AGENTIF_LOG) << QStringLiteral("itemsMoved: failed for item %1").arg(ewsHash(item.remoteId()));
            failedIds.append(EwsId(item.remoteId(), QString()));
        }
        ++it;
    }
```

#### AUTO 


```{c}
auto *syncFoldersReq = new EwsSyncFolderHierarchyRequest(mClient, this);
```

#### AUTO 


```{c}
const auto json = QJsonDocument::fromJson(qobject_cast<KIO::StoredTransferJob *>(job)->data());
```

#### AUTO 


```{c}
auto updateJob = new UpdateJob(col, this);
```

#### AUTO 


```{c}
auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
```

#### AUTO 


```{c}
auto login = static_cast<KIMAP::LoginJob *>(job);
```

#### AUTO 


```{c}
auto *req = new EwsFindFolderRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &day : days) {
        short dowIndex = decodeEnumString<short>(day, dayOfWeekNames, dayOfWeekNameCount, &ok);
        if (reader.error() != QXmlStreamReader::NoError || !ok) {
            qCWarning(EWSCLI_LOG) << QStringLiteral("Failed to read EWS request - invalid %1 element (value: %2).")
                .arg(QStringLiteral("DaysOfWeek").arg(day));
            return false;
        }
        if (dowIndex == 7) { // "Day"
            dow.fill(true, 0, 7);
        } else if (dowIndex == 8) { // "Weekday"
            dow.fill(true, 0, 5);
        } else if (dowIndex == 9) { // "WeekendDay"
            dow.fill(true, 5, 7);
        } else {
            dow.setBit(dowIndex);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &childCollection : list) {
            QCOMPARE(childCollection.parentCollection(), collection);

            QVERIFY(!childCollection.remoteId().isEmpty());
            QCOMPARE(childCollection.remoteId(), childCollection.name());
            QCOMPARE(childCollection.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

            QCOMPARE(childCollection.rights(),
                     Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                         | Collection::CanChangeCollection | Collection::CanDeleteCollection);
        }
```

#### AUTO 


```{c}
const auto &note
```

#### AUTO 


```{c}
auto modJob = new Akonadi::CollectionModifyJob(col, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QMap<QString, QString> &m) {
        map = m;
        loop.exit(0);
    }
```

#### AUTO 


```{c}
const auto colorAttr = collection.attribute<Akonadi::CollectionColorAttribute>();
```

#### AUTO 


```{c}
const auto supportedFlags = fromAkonadiToSupportedImapFlags(removedFlags().values(), items().at(0).parentCollection());
```

#### AUTO 


```{c}
const auto obj = json.object();
```

#### AUTO 


```{c}
auto collection = job->property("collection").value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(toplevelMailboxes)) {
            auto meta = new KIMAP::GetMetaDataJob(mSession);
            meta->setMailBox(mailbox + QLatin1String("*"));
            if (mServerCapabilities.contains(QLatin1String("METADATA"))) {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Metadata);
            } else {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Annotatemore);
            }
            meta->setDepth(KIMAP::GetMetaDataJob::AllLevels);
            for (const QByteArray &requestedEntry : qAsConst(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
            connect(meta, &KJob::result, this, &RetrieveMetadataJob::onGetMetaDataDone);
            mJobs++;
            meta->start();
        }
```

#### AUTO 


```{c}
auto fetch = new KIMAP::FetchJob(m_session);
```

#### AUTO 


```{c}
auto task = new KolabChangeTagTask(createResourceState(TaskArguments(tag)), QSharedPointer<TagConverter>(new TagConverter), this);
```

#### AUTO 


```{c}
auto *syncFoldersReq = new EwsSyncFolderHierarchyRequest(d->mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        QHash<Akonadi::Collection, QList<Akonadi::Item::Id>>::iterator end(mNewMails.end());
        for (QHash<Akonadi::Collection, QList<Akonadi::Item::Id>>::iterator it = mNewMails.begin(); it != end; ++it) {
            QList<Akonadi::Item::Id> idList = it.value();
            if (idList.contains(item.id()) && addedFlags.contains("\\SEEN")) {
                idList.removeAll(item.id());
                if (idList.isEmpty()) {
                    mNewMails.remove(it.key());
                    break;
                } else {
                    (*it) = idList;
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mTags)) {
        Akonadi::TagCreateJob *createJob = new Akonadi::TagCreateJob(tag, this);
        createJob->setMergeIfExisting(true);
        connect(createJob, &Akonadi::TagCreateJob::result, this, &CreateAndSetTagsJob::onCreateDone);
    }
```

#### AUTO 


```{c}
auto journalColor = ETESYNC_COLLECTION_DEFAULT_COLOR;
```

#### AUTO 


```{c}
const auto dataEnd = data.constEnd();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            listEntry(entryForItem(item));
        }
```

#### AUTO 


```{c}
const auto *attr = collection.attribute<EntityDisplayAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : std::as_const(folderTypeNames)) {
        if (name == reader.name()) {
            d->mType = static_cast<EwsFolderType>(i);
            break;
        }
        i++;
    }
```

#### AUTO 


```{c}
const auto idleMailBox = m_state->mailBoxForCollection(m_state->collection());
```

#### RANGE FOR STATEMENT 


```{c}
for (O2Reply *timedReply : std::as_const(replies_)) {
        if (timedReply->reply == reply) {
            return timedReply;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<const Update> &upd : std::as_const(mUpdates)) {
        if (!upd->write(writer, mType)) {
            retVal = false;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folderId : ids) {
        xQueryFolderIds.append(QStringLiteral("//m:GetFolder/m:FolderIds/t:FolderId[position()=%1 and @Id=\"%2\"]").arg(++folderIndex).arg(folderId));
        responseXml += QStringLiteral("<m:GetFolderResponseMessage ResponseClass=\"Success\">");
        responseXml += QStringLiteral("<m:ResponseCode>NoError</m:ResponseCode>");
        responseXml += QStringLiteral("<m:Folders><t:Folder>");
        responseXml += QStringLiteral("<t:FolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folderId);
        responseXml += QStringLiteral("</t:Folder></m:Folders>");
        responseXml += QStringLiteral("</m:GetFolderResponseMessage>");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Attachment &a : attachments) {
        KCalendarCore::Attachment att;
        if (!a.uri().empty()) {
            att = KCalendarCore::Attachment(fromStdString(a.uri()), fromStdString(a.mimetype()));
        } else {
            att = KCalendarCore::Attachment(QByteArray::fromRawData(a.data().c_str(), a.data().size()).toBase64(), fromStdString(a.mimetype()));
        }
        if (!a.label().empty()) {
            att.setLabel(fromStdString(a.label()));
        }
        i.addAttachment(att);
    }
```

#### AUTO 


```{c}
auto responses = mChunkedJob.responses();
```

#### AUTO 


```{c}
auto select = new KIMAP::SelectJob(m_session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &result : results) {
            const QStringList split = result.split(QLatin1Char('|'));
            KDAV::Protocol protocol = KDAV::Utils::protocolByName(split.at(0));
            if (!Settings::self()->urlConfiguration(protocol, split.at(1))) {
                Settings::UrlConfiguration *urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = split.at(1);
                if (dlg->useDefaultCredentials()) {
                    urlConfig->mUser = QStringLiteral("$default$");
                } else {
                    urlConfig->mUser = dlg->username();
                    urlConfig->mPassword = dlg->password();
                }
                urlConfig->mProtocol = protocol;

                Settings::self()->newUrlConfiguration(urlConfig);

                addModelRow(Utils::translatedProtocolName(protocol), split.at(1));
                mAddedUrls << QPair<QString, KDAV::Protocol>(split.at(1), protocol);
                checkUserInput();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto zone : zones) {
        const QString cityName = zone.split('/').last();
        Q_ASSERT(!countryMap.contains(cityName));
        countryMap.insert(cityName, zone);
    }
```

#### AUTO 


```{c}
auto task = new KolabRetrieveTagTask(createResourceState(TaskArguments()), KolabRetrieveTagTask::RetrieveTags, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const ContactPtr contact = object.dynamicCast<Contact>();

        Item item;
        item.setMimeType(mimeType());
        item.setParentCollection(collection);
        item.setRemoteId(contact->uid());
        item.setRemoteRevision(contact->etag());
        item.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());

        if (contact->deleted()
            || (collection.remoteId() == OTHERCONTACTS_REMOTEID && !contact->groups().isEmpty())
            || (collection.remoteId() == myContactsRemoteId() && contact->groups().isEmpty())) {
            qCDebug(GOOGLE_CONTACTS_LOG) << " - removed" << contact->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_CONTACTS_LOG) << " - changed" << contact->uid();
            changedItems << item;
            changedPhotos << contact->uid();
        }

        const QStringList groups = contact->groups();
        for (const QString &group : groups) {
            // We don't link contacts to "My Contacts"
            if (group != myContactsRemoteId()) {
                groupsMap[group] << item;
            }
        }
    }
```

#### AUTO 


```{c}
auto id = fd.ewsFolder[EwsFolderFieldFolderId].value<EwsId>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto event : events) {
        qDebug() << "Got event:" << event;
    }
```

#### AUTO 


```{c}
auto job = new JournalsFetchJob(mClient.get(), this);
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(collection, CollectionFetchJob::Base);
```

#### AUTO 


```{c}
const auto exclusions{mRecurrence.exclusions};
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsMoveItemRequest *>(job);
```

#### AUTO 


```{c}
auto it = itemHash.find(id.id());
```

#### AUTO 


```{c}
const auto detailJob = qobject_cast<EwsFetchItemDetailJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : qAsConst(entryList)) {
        // TODO: Use cache policy to see what actually has to been set as payload.
        //       Currently most views need a minimal amount of information so the
        //       Items get Envelopes as payload.
        KMime::Message *mail = new KMime::Message();
        mail->setHead(KMime::CRLFtoLF(mMBox->readMessageHeaders(entry)));
        mail->parse();

        Item item;
        item.setRemoteId(colId + QLatin1String("::") + colRid + QLatin1String("::") + QString::number(entry.messageOffset()));
        item.setMimeType(QStringLiteral("message/rfc822"));
        item.setSize(entry.messageSize());
        item.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, item);
        Q_EMIT percent(count++ / entryListSize);
        items << item;
    }
```

#### AUTO 


```{c}
auto *modifyJob = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
auto *account = new ImapAccount;
```

#### AUTO 


```{c}
auto entries = etesync_entry_manager_list(entry_manager, charArrFromQString(prev_uid), limit);
```

#### AUTO 


```{c}
auto task = new RemoveCollectionRecursiveTask(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UrlPair &url : std::as_const(mRemovedUrls)) {
        Settings::self()->removeUrlConfiguration(url.second, url.first);
    }
```

#### AUTO 


```{c}
auto *job = new CollectionModifyJob(collection, transaction());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { modifyDone(job); }
```

#### AUTO 


```{c}
const auto infos{info.split(QLatin1Char(','), Qt::SkipEmptyParts)};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &entry : entries) {
        if (entry.fileName() == QLatin1String("WARNING_README.txt")) {
            continue;
        }

        Item item;
        item.setRemoteId(entry.fileName());

        if (entry.fileName().endsWith(QLatin1String(".vcf"))) {
            item.setMimeType(KContacts::Addressee::mimeType());
        } else if (entry.fileName().endsWith(QLatin1String(".ctg"))) {
            item.setMimeType(KContacts::ContactGroup::mimeType());
        } else {
            cancelTask(i18n("Found file of unknown format: '%1'", entry.absoluteFilePath()));
            return;
        }

        items.append(item);
    }
```

#### AUTO 


```{c}
auto uidNext = c.attribute<UidNextAttribute>();
```

#### AUTO 


```{c}
const auto contactsSettings = settingsForResource(oldInstances.contactResource);
```

#### AUTO 


```{c}
const auto collections = fetchJob->collections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsOccurrence &exc : excList) {
                addItems.append(exc.itemId());
            }
```

#### AUTO 


```{c}
auto i = item.payload<Incidence::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
                auto queryJob = qobject_cast<FreeBusyQueryJob *>(job);

                if (!m_iface->handleError(job, false)) {
                    m_iface->freeBusyRetrieved(queryJob->id(), QString(), false, QString());
                    return;
                }

                KCalendarCore::FreeBusy::Ptr fb(new KCalendarCore::FreeBusy);
                fb->setUid(QStringLiteral("%1%2@google.com").arg(QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyyMMddTHHmmssZ"))));
                fb->setOrganizer(job->account()->accountName());
                fb->addAttendee(KCalendarCore::Attendee(QString(), queryJob->id()));
                // FIXME: is it really sort?
                fb->setDateTime(QDateTime::currentDateTimeUtc(), KCalendarCore::IncidenceBase::RoleSort);
                const auto ranges = queryJob->busy();
                for (const auto &range : ranges) {
                    fb->addPeriod(range.busyStart, range.busyEnd);
                }

                KCalendarCore::ICalFormat format;
                const QString fbStr = format.createScheduleMessage(fb, KCalendarCore::iTIPRequest);

                m_iface->freeBusyRetrieved(queryJob->id(), fbStr, true, QString());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsOAuth *oAuth) {
        return oAuth->authenticate(false);
    }
```

#### AUTO 


```{c}
const auto placeIt = data.constFind(QLatin1String("place"));
```

#### AUTO 


```{c}
const auto transitions = ktz.transitions(QDateTime(), QDateTime::currentDateTimeUtc());
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }

        TaskListPtr taskList = qobject_cast<TaskListCreateJob *>(job)->items().first().dynamicCast<TaskList>();
        qCDebug(GOOGLE_TASKS_LOG) << "Task list created:" << taskList->uid();
        // Enable newly added task list in settings
        m_settings->addTaskList(taskList->uid());
        // Populate remoteId & other stuff
        Collection newCollection(collection);
        setupCollection(newCollection, taskList);
        m_iface->collectionChangeCommitted(newCollection);
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
const auto attr = collection.attribute<CompatibilityAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *c : list) {
        if (c->contentType()->mimeType() == type) {
            return c;
        }
    }
```

#### AUTO 


```{c}
auto *modifiedJob = new FoldersRequestJob(mLastSync, FoldersRequestJob::Modified, this);
```

#### AUTO 


```{c}
auto sourceIds = req->property("ids").value<EwsId::List>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *j) {
        loop.exit(j->error());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&createFolderCalled](const QString &) {
                                           createFolderCalled = true;
                                           return true;
                                       }
```

#### AUTO 


```{c}
const auto responses{response.split('&')};
```

#### LAMBDA EXPRESSION 


```{c}
[&fail, &job] {
        if (fail) {
            job->postResponse("");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SpecialFolders &sf : std::as_const(specialFolderList)) {
        queryItems.append(EwsId(sf.did));
    }
```

#### AUTO 


```{c}
const auto totalItems = mRemoteAddedItems.size() + mRemoteChangedItems.size() + mRemoteDeletedIds.size() + mRemoteFlagChangedIds.size();
```

#### AUTO 


```{c}
auto bodyType = reader.attributes().value(QStringLiteral("BodyType"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(entry);
        item.setParentCollection(collection);

        if (md->hasIndexData()) {
            const KMIndexDataPtr indexData = md->indexData(entry);
            if (indexData != nullptr && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                const quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has" << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            }
        }
        const Akonadi::Item::Flags flags = md->maildir().readEntryFlags(entry);
        for (const Akonadi::Item::Flag &flag : flags) {
            item.setFlag(flag);
        }

        items << item;
    }
```

#### AUTO 


```{c}
const auto supportedFlags = fromAkonadiToSupportedImapFlags(removedFlags().toList(), items().at(0).parentCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const GenericHandler::Ptr &handler){
        return handler->mimeType() == mimeType;
    }
```

#### AUTO 


```{c}
auto job = new ItemModifyJob(item);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        loadFiles();
    }
```

#### AUTO 


```{c}
auto idJob = new KIMAP::IdJob(nsJob->session());
```

#### AUTO 


```{c}
auto *fetchJob = new KDAV::DavItemsFetchJob(davUrl, changedRids);
```

#### AUTO 


```{c}
auto quotaAttribute = m_collection.attribute<Akonadi::CollectionQuotaAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *job = new KIMAP::CapabilitiesJob(session);
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectsRequestJob(folder, 0, OXA::ObjectsRequestJob::Modified, this);
```

#### AUTO 


```{c}
auto appendJob = new KIMAP::AppendJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool success, const QString &error) {
            itemFetchFinished(success, error);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &scope : scopes) {
        scopeUrls << QUrl(scope);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    auto page = qobject_cast<WebPage*>(mView->page());
                    if (auto err = page->lastCeritificateError()) {
                        QMessageBox msg;
                        msg.setIconPixmap(QIcon::fromTheme(QStringLiteral("security-low")).pixmap(64));
                        msg.setText(err->errorDescription());
                        msg.addButton(QMessageBox::Ok);
                        msg.exec();
                    }
                }
```

#### AUTO 


```{c}
auto req = new EwsUpdateFolderRequest(mClient, this);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(trashCollection, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto msg = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
static const auto KWalletKeyCookies = QStringLiteral("cookies");
```

#### AUTO 


```{c}
auto vLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto *ntf = KNotification::event(QStringLiteral("authNeeded"),
                                     i18nc("@title", "%1 needs your attention.", agentName()),
                                     msg,
                                     QStringLiteral("im-google"),
                                     /*widget=*/nullptr,
                                     KNotification::Persistent | KNotification::SkipGrouping);
```

#### AUTO 


```{c}
const auto &col
```

#### AUTO 


```{c}
const auto message = mItem.payload<Message::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collection](const Item &item){
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        contact->removeGroup(collection.remoteId());
        return contact;
    }
```

#### AUTO 


```{c}
auto *itemFetch = qobject_cast<ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &right : rights) {
        const QByteArray trimmed = right.trimmed();
        const int wsIndex = trimmed.indexOf(' ');
        const QByteArray id = trimmed.mid(0, wsIndex).trimmed();
        if (!id.isEmpty()) {
            const bool noValue = (wsIndex == -1);
            if (noValue) {
                map[id] = KIMAP::Acl::None;
            } else {
                const QByteArray value = trimmed.mid(wsIndex + 1, right.length() - wsIndex).trimmed();
                map[id] = KIMAP::Acl::rightsFromString(value);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : std::as_const(mIdsToSave)) {
                    sizeOnServerAfterDeletion += mIdsToSizeMap.value(id);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const UrlPair &url : std::as_const(mAddedUrls)) {
        Settings::self()->removeUrlConfiguration(url.second, url.first);
    }
```

#### AUTO 


```{c}
const auto incidence = item.payload<Incidence::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob*job) { storeListResult(job);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : qAsConst(list)) {
        // We have to filter the list by time
        if (event->dtEnd() >= s && e >= event->dtStart()) {
            eventlist.push_back(Kolab::Conversion::fromKCalendarCore(*event));
        }
    }
```

#### AUTO 


```{c}
auto srJob = static_cast<StoreResultJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UrlPair &url : qAsConst(mRemovedUrls)) {
        Settings::self()->removeUrlConfiguration(url.second, url.first);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        settings()->setSubscriptionEnabled(mSubscriptions->subscriptionEnabled());
        settings()->save();
        Q_EMIT configurationDialogAccepted();
        reconnect();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Period &p : fbPeriodPeriods) {
            KCalendarCore::FreeBusyPeriod period(Kolab::Conversion::toDate(p.start), Kolab::Conversion::toDate(p.end));
            //             period.setSummary("summary"); Doesn't even work. X-SUMMARY is read though (just not written out)s
            // TODO
            list.append(period);
        }
```

#### AUTO 


```{c}
auto meta = new KIMAP::GetMetaDataJob(mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::CustomProperty &prop : properties) {
        if (prop.identifier == id) {
            return prop.value;
        }
    }
```

#### AUTO 


```{c}
auto f = finally([&fail, &job] {
        if (fail) {
            job->postResponse("");
        }
    });
```

#### AUTO 


```{c}
auto createJob = qobject_cast<OXA::ObjectCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (Attendee *delegator : std::as_const(delegatorsRef)) {
            // Set the delegator on each delegatee
            const ContactReference &delegatorRef = delegator->contact();
            if (!contains(delegatorRef, delegatedFrom)) {
                delegatedFrom.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegatorRef.email(), delegatorRef.name()));
            }

            // Set the delegatee on each delegator
            std::vector<Kolab::ContactReference> delegatedTo = delegator->delegatedTo();
            const ContactReference &delegaeeRef = delegatee->contact();
            if (!contains(delegaeeRef, delegatedTo)) {
                delegatedTo.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegaeeRef.email(), delegaeeRef.name()));
            }
            delegator->setDelegatedTo(delegatedTo);
        }
```

#### AUTO 


```{c}
auto it = mFolderHash.begin();
```

#### AUTO 


```{c}
auto job = new OXA::ObjectsRequestDeltaJob(folder, lastSyncInfo.lastSync(collection.id()), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : collections) {
        modifiedCollections << processAnnotations(col);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &offset : offsets) {
        mDeletedItemOffsets.insert(offset.toULongLong());
    }
```

#### AUTO 


```{c}
const auto networkError = senderReply->networkError();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate &date : exceptionList) {
        dates.append(OXUtils::writeDate(date));
    }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsCreateItemRequest *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const UrlPair &url : qAsConst(mAddedUrls)) {
        Settings::self()->removeUrlConfiguration(url.second, url.first);
    }
```

#### AUTO 


```{c}
auto *job = new ItemDeleteJob(item);
```

#### AUTO 


```{c}
const auto json = QJsonDocument::fromJson(qobject_cast<KIO::StoredTransferJob*>(job)->data());
```

#### AUTO 


```{c}
auto itemIt = mItems.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const ContactPtr contact = object.dynamicCast<Contact>();

        Item item;
        item.setMimeType( mimeType() );
        item.setParentCollection(collection);
        item.setRemoteId(contact->uid());
        item.setRemoteRevision(contact->etag());
        item.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());

        if (contact->deleted()
                || (collection.remoteId() == OTHERCONTACTS_REMOTEID && !contact->groups().isEmpty())
                || (collection.remoteId() == myContactsRemoteId() && contact->groups().isEmpty())) {
            qCDebug(GOOGLE_CONTACTS_LOG) << " - removed" << contact->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_CONTACTS_LOG) << " - changed" << contact->uid();
            changedItems << item;
            changedPhotos << contact->uid();
        }

        const QStringList groups = contact->groups();
        for (const QString &group : groups) {
            // We don't link contacts to "My Contacts"
            if (group != myContactsRemoteId()) {
                groupsMap[group] << item;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : lstKeys) {
        if (mMailCollections.contains(mailbox)) {
            const KIMAP::Acl::Rights imapRights = rights.value(mailbox);
            QStringList parts = mailbox.split(separatorCharacter());
            parts.removeLast();
            QString parentMailbox = parts.join(separatorCharacter());

            KIMAP::Acl::Rights parentImapRights;
            //If the parent folder is not existing we cant rename
            if (!parentMailbox.isEmpty() && rights.contains(parentMailbox)) {
                parentImapRights = rights.value(parentMailbox);
            }
            // qCDebug(KOLABRESOURCE_LOG) << mailbox << parentMailbox << imapRights << parentImapRights;

            Akonadi::Collection &collection = mMailCollections[mailbox];
            CollectionMetadataHelper::applyRights(collection, imapRights, parentImapRights);

            // Store the mailbox ACLs
            auto *aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
            const KIMAP::Acl::Rights oldRights = aclAttribute->myRights();
            if (oldRights != imapRights) {
                aclAttribute->setMyRights(imapRights);
            }
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Can't find mailbox " << mailbox;
        }
    }
```

#### AUTO 


```{c}
auto *itemJob = new ItemFetchJob(mCollection);
```

#### AUTO 


```{c}
auto itemJob = qobject_cast<FileStore::ItemDeleteJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto special : specialFolders) {
        const IsolatedTestBase::Folder *folder = folderHash[special];
        if (QTest::qVerify(folder != nullptr, "folder != nullptr", "", __FILE__, __LINE__)) {
            xml += QStringLiteral("<m:GetFolderResponseMessage ResponseClass=\"Success\">");
            xml += QStringLiteral("<m:ResponseCode>NoError</m:ResponseCode>");
            xml += QStringLiteral("<m:Folders><t:Folder>");
            xml += QStringLiteral("<t:FolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folder->id);
            xml += QStringLiteral("</t:Folder></m:Folders>");
            xml += QStringLiteral("</m:GetFolderResponseMessage>");
        }
    }
```

#### AUTO 


```{c}
auto *job = new EwsGlobalTagsWriteJob(mTagStore, mEwsClient, mRootCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(entry);
        item.setParentCollection(collection);

        if (md->hasIndexData()) {
            const KMIndexDataPtr indexData = md->indexData(entry);
            if (indexData != Q_NULLPTR && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                const quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has"
                                                      << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            }
        }
        const Akonadi::Item::Flags flags = md->maildir().readEntryFlags(entry);
        for (const Akonadi::Item::Flag &flag : flags) {
            item.setFlag(flag);
        }

        items << item;
    }
```

#### AUTO 


```{c}
const auto atts{attendees()};
```

#### AUTO 


```{c}
const auto tokens = str.split(QLatin1Char(':'));
```

#### AUTO 


```{c}
auto it = mMap.begin();
```

#### AUTO 


```{c}
auto *itemJob = qobject_cast<FileStore::ItemDeleteJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Item &item){
                return ContactPtr(new Contact(item.payload<KContacts::Addressee>()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : info.split(QLatin1Char(','), QString::SkipEmptyParts)) {
        const auto keyval = token.trimmed().split(QLatin1Char('='));
        if (keyval.count() == 2) {
            if (stringToKnownCertInfoType.contains(keyval[0])) {
                map.insert(stringToKnownCertInfoType[keyval[0]], keyval[1]);
            }
        }
    }
```

#### AUTO 


```{c}
auto *modifyJob = qobject_cast<FileStore::ItemModifyJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[reply, &resp, &chunkFn, &loop]() {
        QString chunk = QString::fromUtf8(reply->readAll());
        if (chunkFn) {
            bool cont = chunkFn(chunk);
            if (!cont) {
                reply->close();
                loop.exit(200);
                return;
            }
        } else {
            resp += chunk;
        }
    }
```

#### AUTO 


```{c}
auto *colorAttribute = col.attribute<Akonadi::CollectionColorAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (Attribute *attr : std::as_const(attributes)) {
        tag.addAttribute(attr);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned responseTypeNameCount = sizeof(responseTypeNames) / sizeof(responseTypeNames[0]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const  KDAV::DavUrl &url : urls) {
        if (url.protocol() == KDAV::CalDav) {
            ++mRequestsTracker[email].handlingJobCount;
            KDAV::DavPrincipalSearchJob *job = new KDAV::DavPrincipalSearchJob(url, KDAV::DavPrincipalSearchJob::EmailAddress, email);
            job->setProperty("email", QVariant::fromValue(email));
            job->setProperty("url", QVariant::fromValue(url.url().toString()));
            job->fetchProperty(QStringLiteral("schedule-inbox-URL"), QStringLiteral("urn:ietf:params:xml:ns:caldav"));
            connect(job, &KDAV::DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onPrincipalSearchJobFinished);
            job->start();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StringPair &item : qAsConst(userAgents)) {
        mUi->userAgentCombo->addItem(item.first, item.second);
        if (mSettings->userAgent() == item.second) {
            selectedIndex = i;
        }
        i++;
    }
```

#### AUTO 


```{c}
auto *listView = new QListView(widget);
```

#### AUTO 


```{c}
auto *job = static_cast<CollectionFetchJob *>(j);
```

#### AUTO 


```{c}
const auto contactItems = fetchJob->items();
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const GenericHandler::Ptr &handler){
        return collection.contentMimeTypes().contains(handler->mimeType());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &limits : qAsConst(allLimits)) {
        QMap<QByteArray, qint64> limitsMap;
        const QStringList strLines = limits.split(QStringLiteral("%%"));
        QList<QByteArray> lines;
        lines.reserve(strLines.count());
        for (const QString &strLine : strLines) {
            lines << strLine.trimmed().toUtf8();
        }

        for (const QByteArray &line : qAsConst(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            limitsMap[key] = value.toLongLong();
        }

        mLimits << limitsMap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!contains(item.remoteId())) {
            setEtagInternal(item.remoteId(), item.remoteRevision());
        }
    }
```

#### AUTO 


```{c}
auto fetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsSubscribeRequest *>(job);
```

#### AUTO 


```{c}
auto job = new OXA::FolderCreateJob(folder, this);
```

#### AUTO 


```{c}
auto moveJob = new TaskMoveJob(detachTasks, items.first().parentCollection().remoteId(),
                        QString(), m_settings->accountPtr(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &result : results) {
            const QStringList split = result.split(QLatin1Char('|'));
            DavUtils::Protocol protocol = DavUtils::protocolByName(split.at(0));
            if (!Settings::self()->urlConfiguration(protocol, split.at(1))) {
                Settings::UrlConfiguration *urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = split.at(1);
                if (dlg->useDefaultCredentials()) {
                    urlConfig->mUser = QStringLiteral("$default$");
                } else {
                    urlConfig->mUser = dlg->username();
                    urlConfig->mPassword = dlg->password();
                }
                urlConfig->mProtocol = protocol;

                Settings::self()->newUrlConfiguration(urlConfig);

                addModelRow(DavUtils::translatedProtocolName(protocol), split.at(1));
                mAddedUrls << QPair<QString, DavUtils::Protocol>(split.at(1), protocol);
                checkUserInput();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemChange &ch : qAsConst(mChanges)) {
        ch.write(writer);
    }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsEventRequestBase *>(job);
```

#### AUTO 


```{c}
auto *search = new KIMAP::SearchJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::DayPos &dp : bydays) {
                daypos.append(toWeekDayPos(dp));
            }
```

#### AUTO 


```{c}
const auto stdByMonthVector = std::vector<int>(byMonthVector.begin(), byMonthVector.end());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const EwsId::List::const_iterator &firstId, const EwsId::List::const_iterator &lastId) {
            auto req = new EwsGetItemRequest(mClient, this);
            EwsId::List ids;
            for (auto it = firstId; it != lastId; ++it) {
                ids.append(*it);
            }
            req->setItemIds(ids);
            EwsItemShape shape(EwsShapeIdOnly);
            shape << EwsPropertyField(QStringLiteral("item:MimeContent"));
            req->setItemShape(shape);
            return req;
        }
```

#### AUTO 


```{c}
auto *req = new EwsUpdateFolderRequest(mClient, this);
```

#### AUTO 


```{c}
auto *closeJob = new KIMAP::CloseJob(mSession);
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<OXA::ObjectsRequestJob *>(job);
```

#### AUTO 


```{c}
auto *replaceJob = static_cast<UpdateMessageJob *>(job);
```

#### AUTO 


```{c}
auto *fetchJob = new Akonadi::CollectionFetchJob(rootCollection, Akonadi::CollectionFetchJob::Base);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &childId : children) {
        FolderDescr &childFd = mFolderHash[childId];
        if (!childFd.isProcessed() && childFd.isModified()
            && childFd.parent() != childFd.collection.parentCollection().remoteId()) {
            qCDebugNC(EWSRES_LOG) << QStringLiteral("Found moved collection");
            /* Found unprocessed collection move. */
            moveCollection(childFd);
        }

        childFd.collection.setParentCollection(fd.collection);
        reparentRemoteFolder(childId);
    }
```

#### AUTO 


```{c}
auto subscribe = new KIMAP::SubscribeJob(m_session);
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::CollectionFetchJob(c, Akonadi::CollectionFetchJob::Base, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &, const Akonadi::Collection &) {
        settleTimer.start(serverSettleTimeout);
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *rights = static_cast<KIMAP::MyRightsJob *>(job);
```

#### AUTO 


```{c}
auto *req = new EwsDeleteItemRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : std::as_const(paths)) {
        if (!QFileInfo::exists(p)) {
            if (!createMissingFolders) {
                lastError = i18n("Error opening %1; this folder is missing.", p);
                return false;
            }
            QDir().mkpath(p);
            if (!QFileInfo::exists(p)) {
                lastError = i18n("Error opening %1; this folder is missing.", p);
                return false;
            }
        }
        if (!canAccess(p)) {
            lastError = i18n(
                "Error opening %1; either this is not a valid "
                "maildir folder, or you do not have sufficient access permissions.",
                p);
            return false;
        }
    }
```

#### AUTO 


```{c}
auto account = new ImapAccount;
```

#### AUTO 


```{c}
const auto tz = str.rightRef(5);
```

#### AUTO 


```{c}
auto *login = new KIMAP::LoginJob(m_session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entries) {
        const quint64 indexOffset = entry.messageOffset() + entry.separatorSize();
        const KMIndexDataPtr data = indexReader.dataByOffset(indexOffset);
        if (data != Q_NULLPTR) {
            mIndexData.insert(entry.messageOffset(), data);
        }
    }
```

#### AUTO 


```{c}
auto *req = new EwsGetItemRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : taskLists) {
                    const TaskListPtr &taskList = object.dynamicCast<TaskList>();
                    qCDebug(GOOGLE_TASKS_LOG) << " -" << taskList->title() << "(" << taskList->uid() << ")";

                    if (!activeTaskLists.contains(taskList->uid())) {
                        qCDebug(GOOGLE_TASKS_LOG) << "Skipping, not subscribed";
                        continue;
                    }

                    Collection collection;
                    setupCollection(collection, taskList);
                    collection.setParentCollection(rootCollection);
                    collections << collection;
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entries) {
        const KMIndexDataPtr data = indexReader.dataByFileName(entry);
        if (data != Q_NULLPTR) {
            mIndexData.insert(entry, data);
        }
    }
```

#### AUTO 


```{c}
const auto results = search->results();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            qCDebug(ETESYNC_LOG) << "Login finished";
            static_cast<LoginPage *>(page(W_LoginPage))->setLoginResult(static_cast<LoginJob *>(job)->getLoginResult());
            static_cast<LoginPage *>(page(W_LoginPage))->setAccountStatusResult(static_cast<LoginJob *>(job)->getAccountStatusResult());
            static_cast<LoginPage *>(page(W_LoginPage))->setErrorCode(job->error());
            static_cast<LoginPage *>(page(W_LoginPage))->setErrorMessage(job->errorText());
            static_cast<LoginPage *>(page(W_LoginPage))->hideProgressBar();
            nextId() == -1 ? QWizard::accept() : QWizard::next();
        }
```

#### AUTO 


```{c}
auto *job = new NewMailNotifierShowMessageJob(mItem.id());
```

#### AUTO 


```{c}
auto *h = new KMime::Headers::Generic(X_KOLAB_TYPE_HEADER);
```

#### AUTO 


```{c}
auto nameRef = attrs.value(QStringLiteral("Version"));
```

#### AUTO 


```{c}
auto *networkConfigMgr = new QNetworkConfigurationManager(QCoreApplication::instance());
```

#### AUTO 


```{c}
auto unsubscribe = new KIMAP::UnsubscribeJob(m_session);
```

#### AUTO 


```{c}
const auto exDates = rec->exDates();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsDeleteItemRequest::Response &resp : responses) {
        QCOMPARE(resp.responseClass(), EwsResponseSuccess);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate &dt : exDates) {
        exdates.push_back(fromDate(QDateTime(dt, {}), true));
    }
```

#### AUTO 


```{c}
auto aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : allInstances) {
        if (isLegacyGoogleResource(instance)) {
            const auto account = getAccountNameFromResourceSettings(instance);
            if (account.isEmpty()) {
                qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: resource" << instance.identifier() << "is not configued, removing";
                Akonadi::AgentManager::self()->removeInstance(instance);
                continue;
            }
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: discovered resource" << instance.identifier()
                                  << "for account" << account;
            if (instance.type().identifier() == akonadiGoogleCalendarResource) {
                mMigrations[account].calendarResource = instance;
            } else if (instance.type().identifier() == akonadiGoogleContactsResource) {
                mMigrations[account].contactResource = instance;
            }
        } else if (isGoogleGroupwareResource(instance)) {
            const auto account = getAccountNameFromResourceSettings(instance);
            mMigrations[account].alreadyExists = true;
        }
    }
```

#### AUTO 


```{c}
auto task = new KolabRemoveTagTask(createResourceState(TaskArguments(tag)), this);
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyItemUploadJob *>(kjob);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : itemsLst) {
        const QString rid = item.remoteId();
        if (rid.isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onCreateInitialCacheReady: Found an item without remote ID. " << item.id();
            continue;
        }

        const Akonadi::Collection collection = item.parentCollection();
        if (collection.remoteId().isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onCreateInitialCacheReady: Found an item in a collection without remote ID. " << item.remoteId();
            continue;
        }

        const QString etag = item.remoteRevision();
        if (etag.isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onCreateInitialCacheReady: Found an item without ETag. " << item.remoteId();
            continue;
        }

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }

        mEtagCaches[collection.remoteId()]->setEtag(rid, etag);
    }
```

#### AUTO 


```{c}
auto promise = KGAPI2::AccountManager::instance()->getAccount(
            GOOGLE_API_KEY, GOOGLE_API_SECRET, mResource->settings()->userName(),
            { KGAPI2::Account::mailScopeUrl() });
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<FileStore::Job *> &jobs) {
        d->processJobs(jobs);
    }
```

#### AUTO 


```{c}
auto task = new MoveItemsTask(state);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &item) {
        return item.remoteId().isEmpty();
    }
```

#### AUTO 


```{c}
const auto configFile = Akonadi::ServerManager::self()->addNamespace(instance.identifier()) + QStringLiteral("rc");
```

#### AUTO 


```{c}
auto rights = static_cast<KIMAP::MyRightsJob *>(job);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(d->mCollection, this);
```

#### AUTO 


```{c}
auto it = messages.cbegin(), end = messages.cend();
```

#### AUTO 


```{c}
auto markAsReadAllJob = new Akonadi::MarkAsCommand(messageStatus, Akonadi::Item::List() << mItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &cap : customCapabilities) {
        caps += " " + cap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        Item newItem(item);
        if (!doRetrieveItem(newItem)) {
            return false;
        }
        resultItems.append(newItem);
    }
```

#### AUTO 


```{c}
auto *mainWidget = new QWidget(parent);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsDeleteItemRequest *>(job);
```

#### AUTO 


```{c}
const auto flags = item.flags();
```

#### AUTO 


```{c}
auto fullListJob = new KIMAP::ListJob(session);
```

#### AUTO 


```{c}
auto authJob = new AuthJob(m_account, m_settings->clientId(), m_settings->clientSecret());
```

#### AUTO 


```{c}
auto req = new EwsMoveFolderRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto group = config()->group("TomboyNotesConfigWidget");
```

#### LAMBDA EXPRESSION 


```{c}
[&events](const QString &event) {
        events.append(event);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : std::as_const(mFetchItemsJobQueue)) {
            // Don't enqueue the same collection twice, unless it's for the currently synced collection.
            if (item.col != mFetchItemsJobQueue.head().col && item.col == col) {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Sync already queued - skipping");
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &param : params) {
        requestData.addQueryItem(QString::fromLatin1(param.name), QString::fromLatin1(QUrl::toPercentEncoding(QString::fromLatin1(param.value))));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : attachments) {
        QByteArray type;
        KMime::Content *content = Mime::findContentByName(mimeData, name, type);
        if (!content) { // guard against malformed events with non-existent attachments
            qCWarning(PIMKOLAB_LOG) << "could not find attachment: " << name.toUtf8() << type;
            continue;
        }
        const QByteArray c = content->decodedContent().toBase64();
        KCalendarCore::Attachment attachment(c, QString::fromLatin1(type));
        attachment.setLabel(name);
        incidence->addAttachment(attachment);
        qCDebug(PIMKOLAB_LOG) << "ATTACHMENT NAME" << name << type;
    }
```

#### AUTO 


```{c}
auto queryJob = qobject_cast<KGAPI2::FreeBusyQueryJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event &event : events) {
        KCalCore::Event::Ptr kcalEvent = Conversion::toKCalCore(event);
        kcalEvent->setCreated(QDateTime::currentDateTimeUtc()); //sets dtstamp
        calendar->addEvent(kcalEvent);
    }
```

#### AUTO 


```{c}
const auto stdByYearDayVector = std::vector<int>(byYearDaysVector.begin(), byYearDaysVector.end());
```

#### AUTO 


```{c}
auto job = new KDAV::DavPrincipalSearchJob(davUrl, filter, mUi.searchParam->text(), this);
```

#### AUTO 


```{c}
auto acc = KGAPI2::AccountPtr::create(mResource->settings()->userName(),
                                          QString(), refreshToken,
                                          QList<QUrl>{ QUrl(QStringLiteral("https://mail.google.com/")) });
```

#### AUTO 


```{c}
const auto addressee = job->items().at(0).payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
const auto item = handleResponse(it->toObject());
```

#### AUTO 


```{c}
auto task = new RetrieveItemsTask(createResourceState(TaskArguments(col)), this);
```

#### AUTO 


```{c}
auto createJob = static_cast<Akonadi::TagCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &l : list) {
        QVariantMap reminder = l.toMap();

        KGAPI2::ReminderPtr rem(new KGAPI2::Reminder);

        if (reminder[QStringLiteral("type")].toString() == QLatin1String("display")) {
            rem->setType(KCalCore::Alarm::Display);
        } else if (reminder[QStringLiteral("type")].toString() == QLatin1String("email")) {
            rem->setType(KCalCore::Alarm::Email);
        }

        KCalCore::Duration offset(reminder[QStringLiteral("time")].toInt(), KCalCore::Duration::Seconds);
        rem->setStartOffset(offset);

        m_reminders << rem;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &) {
        settleTimer.start(serverSettleTimeout);
    }
```

#### AUTO 


```{c}
const auto message = messages.cbegin();
```

#### AUTO 


```{c}
auto contact = contactItem.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
auto majorBuildRef = attrs.value(QStringLiteral("MajorBuildNumber"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString & status) {
        if (status == QLatin1String("maybe")) {
            return KCalCore::Attendee::Tentative;
        } else if (status == QLatin1String("attending")) {
            return KCalCore::Attendee::Accepted;
        } else if (status == QLatin1String("declined")) {
            return KCalCore::Attendee::Declined;
        } else {
            return KCalCore::Attendee::NeedsAction;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->fetchDone(job); }
```

#### AUTO 


```{c}
auto acl = qobject_cast<KIMAP::GetAclJob *>(job);
```

#### AUTO 


```{c}
auto *j = new Akonadi::ItemModifyJob(remoteDependentItems);
```

#### AUTO 


```{c}
auto *refreshReply = qobject_cast<QNetworkReply *>(sender());
```

#### AUTO 


```{c}
static const auto rootId = QStringLiteral("cm9vdA==");
```

#### AUTO 


```{c}
const auto relateds{contact.relateds()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &entry : annotationKeys) {
                auto job = new KIMAP::SetMetaDataJob(session);
                if (serverCapabilities().contains(QLatin1String("METADATA"))) {
                    job->setServerCapability(KIMAP::MetaDataJobBase::Metadata);
                } else {
                    job->setServerCapability(KIMAP::MetaDataJobBase::Annotatemore);
                }
                job->setMailBox(mailBoxForCollection(collection()));

                if (!entry.startsWith("/shared") && !entry.startsWith("/private")) {
                    // Support for legacy annotations that don't include the prefix
                    job->addMetaData(QByteArray("/shared") + entry, annotations[entry]);
                } else {
                    job->addMetaData(entry, annotations[entry]);
                }

                qCDebug(IMAPRESOURCE_LOG) << "Job got entry:" << entry << "value:" << annotations[entry];

                connect(job, &KIMAP::SetMetaDataJob::result, this, &ChangeCollectionTask::onSetMetaDataDone);

                job->start();

                m_pendingJobs++;
            }
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<UsersRequestJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Item &item){
                return item.remoteId();
            }
```

#### AUTO 


```{c}
auto *job = new OXA::UpdateUsersJob(this);
```

#### AUTO 


```{c}
auto store = new KIMAP::StoreJob(copy->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                if (job->error()) {
                    ui->loginStatusLbl->setText(job->errorText());
                } else {
                    checkToken();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : std::as_const(member.mailbox)) {
            Akonadi::Collection col;
            col.setRemoteId(separatorCharacter() + QString::fromLatin1(part));
            col.setParentCollection(parent);
            parent = col;
        }
```

#### AUTO 


```{c}
const auto newInstance = job->instance();
```

#### AUTO 


```{c}
auto davJob = qobject_cast<KIO::DavJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { itemFetchResult(job); }
```

#### AUTO 


```{c}
auto *job = new SpecialNotifierJob(mListEmails, currentPath, item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : lstKeys) {
        if (mMailCollections.contains(mailbox)) {
            const KIMAP::Acl::Rights imapRights = rights.value(mailbox);
            QStringList parts = mailbox.split(separatorCharacter());
            parts.removeLast();
            QString parentMailbox = parts.join(separatorCharacter());

            KIMAP::Acl::Rights parentImapRights;
            // If the parent folder is not existing we cant rename
            if (!parentMailbox.isEmpty() && rights.contains(parentMailbox)) {
                parentImapRights = rights.value(parentMailbox);
            }
            // qCDebug(KOLABRESOURCE_LOG) << mailbox << parentMailbox << imapRights << parentImapRights;

            Akonadi::Collection &collection = mMailCollections[mailbox];
            CollectionMetadataHelper::applyRights(collection, imapRights, parentImapRights);

            // Store the mailbox ACLs
            auto aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
            const KIMAP::Acl::Rights oldRights = aclAttribute->myRights();
            if (oldRights != imapRights) {
                aclAttribute->setMyRights(imapRights);
            }
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Can't find mailbox " << mailbox;
        }
    }
```

#### AUTO 


```{c}
auto colJob = qobject_cast<FileStore::CollectionDeleteJob *>(job);
```

#### AUTO 


```{c}
auto job = new EwsAkonadiTagsSyncJob(mTagStore, mClient, qobject_cast<EwsResource *>(parent())->rootCollection(), this);
```

#### AUTO 


```{c}
auto moveJob = new TaskMoveJob(detachTasks, items.first().parentCollection().remoteId(), QString(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto initStatus = performAuthAction(oAuth, 1000, [](EwsOAuth *oAuth) {
            oAuth->init();
            return true;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : std::as_const(mTags)) {
        auto createJob = new Akonadi::TagCreateJob(tag, this);
        createJob->setMergeIfExisting(true);
        connect(createJob, &Akonadi::TagCreateJob::result, this, &CreateAndSetTagsJob::onCreateDone);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &attendee : std::as_const(mAttendees)) {
        KCalendarCore::Attendee::PartStat status = attendeeStringToStatus(attendee.status);
        KCalendarCore::Attendee::Role role = attendeeStringToRole(attendee.role);
        KCalendarCore::Attendee a(attendee.displayName, attendee.smtpAddress, attendee.requestResponse, status, role);
        a.setDelegate(attendee.delegate);
        a.setDelegator(attendee.delegator);
        incidence->addAttendee(a);
    }
```

#### AUTO 


```{c}
auto *resp = new EwsSyncFolderHierarchyRequest::Response(reader);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::ItemFetchJob(col, session);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready){
        if (accountId() > 0) {
            return;
        }
        if (!ready) {
            Q_EMIT status(Broken, i18n("Can't access KWallet"));
            return;
        }

        const auto account = m_settings->accountPtr();
        if (account.isNull()) {
            Q_EMIT status(NotConfigured);
            return;
        }

        if (!accountIsValid(account)) {
            requestAuthenticationFromUser(account);
        } else {
            emitReadyStatus();
            synchronize();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &a : eAlarms) {
        Kolab::Alarm alarm;
        // TODO KCalendarCore disables alarms using KCalendarCore::Alarm::enabled() (X-KDE-KCALCORE-ENABLED) We should either delete the alarm, or store the
        // attribute . Ideally we would store the alarm somewhere and temporarily delete it, so we can restore it when parsing. For now we just remove disabled
        // alarms.
        if (!a->enabled()) {
            qCWarning(PIMKOLAB_LOG) << "skipping disabled alarm";
            continue;
        }
        switch (a->type()) {
        case KCalendarCore::Alarm::Display:
            alarm = Kolab::Alarm(toStdString(a->text()));
            break;
        case KCalendarCore::Alarm::Email: {
            std::vector<Kolab::ContactReference> receipents;
            const auto mailAddresses = a->mailAddresses();
            for (const KCalendarCore::Person &p : mailAddresses) {
                receipents.push_back(Kolab::ContactReference(toStdString(p.email()), toStdString(p.name())));
            }
            alarm = Kolab::Alarm(toStdString(a->mailSubject()), toStdString(a->mailText()), receipents);
            break;
        }
        case KCalendarCore::Alarm::Audio: {
            Kolab::Attachment audioFile;
            audioFile.setUri(toStdString(a->audioFile()), std::string());
            alarm = Kolab::Alarm(audioFile);
            break;
        }
        default:
            qCCritical(PIMKOLAB_LOG) << "unhandled alarm";
        }

        if (a->hasTime()) {
            alarm.setStart(fromDate(a->time(), false));
        } else if (a->hasStartOffset()) {
            alarm.setRelativeStart(fromDuration(a->startOffset()), Kolab::Start);
        } else if (a->hasEndOffset()) {
            alarm.setRelativeStart(fromDuration(a->endOffset()), Kolab::End);
        } else {
            qCCritical(PIMKOLAB_LOG) << "alarm trigger is missing";
            continue;
        }

        alarm.setDuration(fromDuration(a->snoozeTime()), a->repeatCount());

        alarms.push_back(alarm);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&parentId](const Item &item){
                return item.remoteId() == parentId;
            }
```

#### AUTO 


```{c}
auto userAgent = o365FakeUserAgent;
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &instance]() {
                qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: timeout while waiting for resource" << instance.identifier() << "to be removed";
                loop.quit();
            }
```

#### AUTO 


```{c}
auto *metadata = static_cast<RetrieveMetadataJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *j) {
            loop.exit(j->error());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : qAsConst(taskLists)) {
        const TaskListPtr &taskList = object.dynamicCast<TaskList>();

        if (!activeTaskLists.contains(taskList->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalendarCore::Todo::todoMimeType());
        collection.setName(taskList->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(taskList->uid());
        collection.setRights(Collection::CanChangeCollection
                             |Collection::CanCreateItem
                             |Collection::CanChangeItem
                             |Collection::CanDeleteItem);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(taskList->title());
        attr->setIconName(QStringLiteral("view-pim-tasks"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxPtr &mbox : qAsConst(mMBoxes)) {
        if (mbox->mCollection.isValid()) {
            MBoxPtr updatedMBox = mbox;
            updatedMBox->mCollection = updateMBoxCollectionTree(mbox->mCollection, collection, renamedCollection);
        }
    }
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(topLevelCollection, Akonadi::CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto it = mTagData.cbegin(), end = mTagData.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(mMailboxes)) {
        mMetadata.insert(mailbox, QMap<QByteArray, QByteArray>());
    }
```

#### AUTO 


```{c}
auto job = new EwsFetchItemPayloadJob(mEwsClient, this, items);
```

#### AUTO 


```{c}
auto *job = new CollectionDeleteJob(collection);
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(calendar->title());
```

#### AUTO 


```{c}
auto annotationsAttribute = m_collection.attribute<Akonadi::CollectionAnnotationsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *fetchJob = new Akonadi::CollectionFetchJob(trashCollection, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *lineEdit = new KPasswordLineEdit();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : entries) {
        ent.push_back(Conversion::toStdString(e));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : std::as_const(collections)) {
        job = mStore->fetchCollections(collection, FileStore::CollectionFetchJob::FirstLevel);

        spy = new QSignalSpy(job, &FileStore::CollectionFetchJob::collectionsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        const Collection::List list = collectionsFromSpy(spy);
        QCOMPARE(job->collections(), list);

        for (const Collection &childCollection : list) {
            QCOMPARE(childCollection.parentCollection(), collection);

            QVERIFY(!childCollection.remoteId().isEmpty());
            QCOMPARE(childCollection.remoteId(), childCollection.name());
            QCOMPARE(childCollection.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

            QCOMPARE(childCollection.rights(),
                     Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                         | Collection::CanChangeCollection | Collection::CanDeleteCollection);
        }

        if (firstLevelNames.contains(collection.name())) {
            for (const Collection &childCollection : list) {
                QVERIFY(secondLevelNames.contains(childCollection.name()));
            }
        } else if (secondLevelNames.contains(collection.name())) {
            for (const Collection &childCollection : list) {
                QVERIFY(thirdLevelNames.contains(childCollection.name()));
            }
            if (collection.name() == md1_2.name()) {
                QCOMPARE(list.count(), 1);
                QCOMPARE(list.first().name(), md1_2_1.name());
            } else if (collection.name() == fileInfo1_1.fileName()) {
                QCOMPARE(list.count(), 2);
            }
        } else {
            QCOMPARE(list.count(), 0);
        }
    }
```

#### AUTO 


```{c}
auto job = new CalendarModifyJob(calendar, m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QXmlResultItems &ri, const QXmlNamePool &) {
                                                          if (ri.hasError()) {
                                                              qDebug() << "XQuery result has errors.";
                                                              return FakeEwsServer::EmptyResponse;
                                                          }
                                                          QXmlItem item = ri.next();
                                                          if (item.isNull()) {
                                                              qDebug() << "XQuery result has no items.";
                                                              return FakeEwsServer::EmptyResponse;
                                                          }
                                                          if (!item.isNode()) {
                                                              qDebug() << "XQuery result is not a XML node.";
                                                              return FakeEwsServer::EmptyResponse;
                                                          }
                                                          QXmlNodeModelIndex index = item.toNodeModelIndex();
                                                          if (index.isNull()) {
                                                              qDebug() << "XQuery XML node is NULL.";
                                                              return FakeEwsServer::EmptyResponse;
                                                          }
                                                          if (index.model()->stringValue(index) != QLatin1String("test")) {
                                                              qDebug() << "Unexpected item value:" << index.model()->stringValue(index);
                                                              return FakeEwsServer::EmptyResponse;
                                                          }
                                                          return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<b/>"), 200);
                                                      }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        loop.exit(0);
    }
```

#### AUTO 


```{c}
auto fj = static_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new TaskFetchJob(collection.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &addressee : qAsConst(mAddressees)) {
        v.push_back(addressee);
    }
```

#### AUTO 


```{c}
auto job = new RetrieveItemsJob(col, md, this);
```

#### AUTO 


```{c}
auto job = new OXA::ObjectCreateJob(object, this);
```

#### AUTO 


```{c}
auto *tagJob = new EwsGlobalTagsWriteJob(mTagStore, mClient, mRootCollection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenJob, url]() {
                        if (tokenJob->error()) {
                            emitError(tokenJob->errorText());
                            return;
                        }

                        QUrl url_ = url;
                        QUrlQuery query(url);

                        query.removeQueryItem(QStringLiteral("access_token"));
                        query.addQueryItem(QStringLiteral("access_token"), tokenJob->token());
                        url_.setQuery(query);
                        sendRequest(url_);
                    }
```

#### AUTO 


```{c}
auto job = new EwsFetchFoldersIncrJob(mEwsClient, mFolderSyncState, mRootCollection, this);
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionDeleteJob(davUrl);
```

#### AUTO 


```{c}
auto job = new OXA::FolderModifyJob(folder, this);
```

#### AUTO 


```{c}
auto job = new ItemDeleteJob(item);
```

#### AUTO 


```{c}
const auto attr = col.attribute<DeletedItemsAttribute>()
```

#### AUTO 


```{c}
auto item = createJob->property("item").value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : qAsConst(objects)) {
        const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();

        QString realName = group->title();

        if (group->isSystemGroup()) {
            if (group->title().contains(QStringLiteral("Coworkers"))) {
                realName = i18nc("Name of a group of contacts", "Coworkers");
            } else if (group->title().contains(QStringLiteral("Friends"))) {
                realName = i18nc("Name of a group of contacts", "Friends");
            } else if (group->title().contains(QStringLiteral("Family"))) {
                realName = i18nc("Name of a group of contacts", "Family");
            } else if (group->title().contains(QStringLiteral("My Contacts"))) {
                // Yes, skip My Contacts group, we store "My Contacts" in root collection
                continue;
            }
        } else {
            if (group->title().contains(QStringLiteral("Other Contacts"))) {
                realName = i18nc("Name of a group of contacts", "Other Contacts");
            }
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KContacts::Addressee::mimeType());
        collection.setName(group->id());
        collection.setParentCollection(m_rootCollection);
        collection.setRights(Collection::CanLinkItem |
                             Collection::CanUnlinkItem |
                             Collection::CanChangeItem);
        if (!group->isSystemGroup()) {
            collection.setRights(collection.rights() |
                                 Collection::CanChangeCollection |
                                 Collection::CanDeleteCollection);
        }
        collection.setRemoteId(group->id());
        collection.setVirtual(true);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(realName);
        attr->setIconName(QStringLiteral("view-pim-contacts"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### AUTO 


```{c}
const auto authUrlString = Mock::authUrlString(authUrl, testClientId, testReturnUri, testEmail, resource, testState);
```

#### AUTO 


```{c}
auto attr = c.attribute<Akonadi::BlockAlarmsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Person &p : mailAddresses) {
                receipents.push_back(Kolab::ContactReference(toStdString(p.email()), toStdString(p.name())));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {postJobResult(job);}
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsUpdateFolderRequest *>(job);
```

#### AUTO 


```{c}
const auto server = qobject_cast<FakeEwsServer *>(parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folder : list) {
        if (folder.type == IsolatedTestBase::Folder::Root) {
            continue;
        }
        xml += QStringLiteral("<t:Create>");
        xml += QStringLiteral("<t:Folder>");
        xml += QStringLiteral("<t:FolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folder.id);
        xml += QStringLiteral("<t:ParentFolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folder.parentId);
        QString folderClass;
        QString extraXml;
        switch (folder.type) {
        case IsolatedTestBase::Folder::Calendar:
            folderClass = QStringLiteral("IPF.Calendar");
            break;
        case IsolatedTestBase::Folder::Contacts:
            folderClass = QStringLiteral("IPF.Contacts");
            break;
        case IsolatedTestBase::Folder::Tasks:
            folderClass = QStringLiteral("IPF.Tasks");
            break;
        default:
            folderClass = QStringLiteral("IPF.Note");
            extraXml = QStringLiteral("<t:UnreadCount>0</t:UnreadCount>");
        }
        xml += QStringLiteral("<t:FolderClass>%1</t:FolderClass>").arg(folderClass);
        xml += QStringLiteral("<t:TotalCount>0</t:TotalCount>");
        xml += QStringLiteral("<t:DisplayName>%1</t:DisplayName>").arg(folder.name);
        xml += QStringLiteral("<t:ChildFolderCount>%1</t:ChildFolderCount>").arg(childCount[folder.id]);
        xml += extraXml;
        xml += QStringLiteral("</t:Folder>");
        xml += QStringLiteral("</t:Create>");

    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Item &item) {
        return ContactPtr(new Contact(item.payload<KContacts::Addressee>()));
    }
```

#### AUTO 


```{c}
auto currentUser = new KUser();
```

#### AUTO 


```{c}
const auto authoritiesInfo = parseCertSubjectInfo(params[QStringLiteral("certauthorities")]);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rid : lstUrl) {
            if (rid.startsWith(ridBase) && rid != item.remoteId()) {
                Akonadi::Item extraItem;
                extraItem.setRemoteId(rid);
                extraItems << extraItem;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { fetchChangedResult(job); }
```

#### AUTO 


```{c}
const auto key = qobject_cast<FacebookResource*>(parent())->identifier();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item){
                    return item.isValid() && (!item.hasPayload<T>() || item.mimeType() != mimeType());
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &collection : collections) {
        QStandardItem *item = new QStandardItem(collection.displayName());
        QString data(KDAV::ProtocolInfo::protocolName(collection.url().protocol()) + QLatin1Char('|') + collection.url().toDisplayString());
        item->setData(data, Qt::UserRole + 1);
        item->setToolTip(collection.url().toDisplayString());
        if (collection.url().protocol() == KDAV::CalDav) {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-calendar")));
        } else {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-pim-contacts")));
        }
        mModel->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : qAsConst(mIds)) {
        id.writeFolderIds(writer);
    }
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<FoldersRequestJob *>(job);
```

#### AUTO 


```{c}
auto *job = new OXA::FolderModifyJob(folder, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry::Pair &offsetPair : std::as_const(movedEntries)) {
                const QString oldRemoteId(QString::number(offsetPair.first.messageOffset()));
                const QString newRemoteId(QString::number(offsetPair.second.messageOffset()));

                Item item;
                item.setRemoteId(oldRemoteId);
                item.setParentCollection(mbox->mCollection);
                item.attribute<FileStore::EntityCompactChangeAttribute>(Item::AddIfMissing)->setRemoteId(newRemoteId);

                items << item;
            }
```

#### AUTO 


```{c}
const auto next = paging.constFind(QLatin1String("next"));
```

#### AUTO 


```{c}
auto job = new TomboyCollectionsDownloadJob(Settings::collectionName(), mManager, refreshInterval, this);
```

#### AUTO 


```{c}
auto annotationsAttribute = c.attribute<Akonadi::CollectionAnnotationsAttribute>();
```

#### AUTO 


```{c}
const auto customProperties = n.customProperties();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {loadFiles();
                       }
```

#### AUTO 


```{c}
auto req = new EwsFindFolderRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &strLine : qAsConst(strLines)) {
            lines << strLine.trimmed().toUtf8();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &note : notes) {
        found = (note.toObject()[QLatin1String("guid")].toString() == mSourceItem.remoteId());
        if (found) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : std::as_const(collections)) {
        compactedCollections.insert(col.remoteId(), col);
    }
```

#### AUTO 


```{c}
auto move = static_cast<KIMAP::MoveJob *>(job);
```

#### AUTO 


```{c}
auto *dlg = qobject_cast<SetupServer *>(sender());
```

#### AUTO 


```{c}
const auto &phase
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *deleteJob = new KIMAP::DeleteJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            emitError(i18n("Failed to retrieve birthday calendar"));
            return;
        }

        auto url = findBirthdayIcalLink(job->data());
        if (url.isEmpty()) {
            emitError(i18n("Failed to retrieve birthday calendar"));
            return;
        }
        // switch webcal scheme for https so we can fetch it with KIO
        url.setScheme(QStringLiteral("https"));
        fetchBirthdayIcal(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        const EwsItem &ewsItem = resp.item();
        KMime::Message::Ptr msg(new KMime::Message);

        // Rebuild the message headers
        QVariant v = ewsItem[EwsItemFieldSubject];
        if (Q_LIKELY(v.isValid())) {
            msg->subject()->fromUnicodeString(v.toString(), "utf-8");
        }

        v = ewsItem[EwsItemFieldFrom];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox mbox = v.value<EwsMailbox>();
            msg->from()->addAddress(mbox);
        }

        v = ewsItem[EwsItemFieldToRecipients];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->to()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldCcRecipients];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->cc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldBccRecipients];
        if (v.isValid()) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->bcc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldInternetMessageId];
        if (v.isValid()) {
            msg->messageID()->from7BitString(v.toString().toAscii());
        }

        v = ewsItem[EwsItemFieldInReplyTo];
        if (v.isValid()) {
            msg->inReplyTo()->from7BitString(v.toString().toAscii());
        }

        v = ewsItem[EwsItemFieldDateTimeReceived];
        if (v.isValid()) {
            msg->date()->setDateTime(v.toDateTime());
        }

        v = ewsItem[EwsItemFieldReferences];
        if (v.isValid()) {
            msg->references()->from7BitString(v.toString().toAscii());
        }

        v = ewsItem[EwsItemFieldReplyTo];
        if (v.isValid()) {
            const EwsMailbox mbox = v.value<EwsMailbox>();
            msg->replyTo()->addAddress(mbox);
        }

        msg->assemble();
        item.setPayload(KMime::Message::Ptr(msg));

        v = ewsItem[EwsItemFieldSize];
        if (v.isValid()) {
            item.setSize(v.toUInt());
        }

        // Workaround for Akonadi bug
        // When setting flags, adding each of them separately vs. setting a list in one go makes
        // a difference. In the former case the item treats this as an incremental change and
        // records flags added and removed. In the latter it sets a flag indicating that flags were
        // reset.
        // For some strange reason Akonadi is not seeing the flags in the latter case.
        Q_FOREACH (const QByteArray &flag, EwsMailHandler::readFlags(ewsItem)) {
            item.setFlag(flag);
        }
        qCDebugNC(EWSRES_LOG) << "EwsFetchMailDetailJob::processItems:" << ewsHash(item.remoteId()) << item.flags();

        ++it;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &root : qAsConst(mRoots)) {
        result += root + " % ";
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_handlers.cbegin(), m_handlers.cend(), [&mimeType](const GenericHandler::Ptr &handler) {
        return handler->mimeType() == mimeType;
    });
```

#### AUTO 


```{c}
auto *attr = new Akonadi::EntityDisplayAttribute;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &object : objects) {
        const TaskPtr task = object.dynamicCast<Task>();

        Item item;
        item.setMimeType(mimeType());
        item.setParentCollection(collection);
        item.setRemoteId(task->uid());
        item.setRemoteRevision(task->etag());
        item.setPayload<KCalendarCore::Todo::Ptr>(task.dynamicCast<KCalendarCore::Todo>());

        if (task->deleted()) {
            qCDebug(GOOGLE_TASKS_LOG) << " - removed" << task->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_TASKS_LOG) << " - changed" << task->uid();
            changedItems << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attachment : std::as_const(attachments)) {
            mAttachments.push_back(Conversion::toStdString(attachment));
        }
```

#### AUTO 


```{c}
static const auto pkeyRedirectUri = QStringLiteral("urn:http-auth:PKeyAuth");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &root : std::as_const(mRoots)) {
        result += root + " % ";
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int s, const QString &message) {
        Q_EMIT status(s, message);
    }
```

#### AUTO 


```{c}
auto *tagJob = qobject_cast<TagFetchJob *>(job);
```

#### AUTO 


```{c}
auto *fetchJob
        = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QUrl &, QVariantMap &map){
            map[QStringLiteral("code")] = QUrl::toPercentEncoding(refreshToken);
        }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsEventRequestBase *>(job);
```

#### AUTO 


```{c}
auto fetchJob = dynamic_cast<CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto recurrenceDates{event.recurrenceDates()};
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setPassword(QStringLiteral("foo"));
        if (wallet) {
            qDebug() << "Wallet is not null";
            loop.exit(1);
            return;
        }
        loop.exit(0);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        postJobResult(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. "
                                     << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (davCollection.color().isValid()) {
            auto colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
            colorAttr->setColor(davCollection.color());
        }

        if (!davCollection.displayName().isEmpty()) {
            auto attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalendarCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalendarCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalendarCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalendarCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        auto protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after successful sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &oldFlag : flags) {
        if (oldFlag == ImapFlags::Seen) {
            newFlags.append(Akonadi::MessageFlags::Seen);
        } else if (oldFlag == ImapFlags::Deleted) {
            newFlags.append(Akonadi::MessageFlags::Deleted);
        } else if (oldFlag == ImapFlags::Answered) {
            newFlags.append(Akonadi::MessageFlags::Answered);
        } else if (oldFlag == ImapFlags::Flagged) {
            newFlags.append(Akonadi::MessageFlags::Flagged);
        } else if (oldFlag.isEmpty()) {
            // filter out empty flags, to avoid isNull/isEmpty confusions higher up
            continue;
        } else {
            newFlags.append(oldFlag);
        }
    }
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : std::as_const(mIds)) {
        id.writeFolderIds(writer);
    }
```

#### AUTO 


```{c}
auto *job = new ItemModifyJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collectionSource, &collectionDestination](const Item &item){
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        // MyContacts -> OtherContacts
        if (collectionSource.remoteId() == myContactsRemoteId()
            && collectionDestination.remoteId() == OTHERCONTACTS_REMOTEID) {
            contact->clearGroups();
            // OtherContacts -> MyContacts
        } else if (collectionSource.remoteId() == OTHERCONTACTS_REMOTEID
                   && collectionDestination.remoteId() == myContactsRemoteId()) {
            contact->addGroup(myContactsRemoteId());
        }

        return contact;
    }
```

#### AUTO 


```{c}
auto contacts = static_cast<KContacts::Addressee::List *>(preloadedData);
```

#### AUTO 


```{c}
auto *createJob = new Akonadi::CollectionCreateJob(mRelationCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : tags) {
            if (!containsId(tag.id())) {
                return false;
            }
            tagList.append(QString::fromLatin1(tagRemoteId(tag.id())));
            const QString name = tagName(tag.id());
            if (!name.isEmpty()) {
                categoryList.append(name);
            }
        }
```

#### AUTO 


```{c}
auto *job = new EventCreateJob(event, collection.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(c, CollectionFetchJob::Base);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        authFinished = true;
        loop.exit(0);
    }
```

#### AUTO 


```{c}
auto special
```

#### RANGE FOR STATEMENT 


```{c}
for (const OXA::Object &object : objects) {
        Item item;
        switch (object.module()) {
        case OXA::Folder::Contacts:
            if (!object.contact().isEmpty()) {
                item.setMimeType(KContacts::Addressee::mimeType());
                item.setPayload<KContacts::Addressee>(object.contact());
            } else {
                item.setMimeType(KContacts::ContactGroup::mimeType());
                item.setPayload<KContacts::ContactGroup>(object.contactGroup());
            }
            break;
        case OXA::Folder::Calendar:
            item.setMimeType(KCalendarCore::Event::eventMimeType());
            item.setPayload<KCalendarCore::Incidence::Ptr>(object.event());
            break;
        case OXA::Folder::Tasks:
            item.setMimeType(KCalendarCore::Todo::todoMimeType());
            item.setPayload<KCalendarCore::Incidence::Ptr>(object.task());
            break;
        case OXA::Folder::Unbound:
            Q_ASSERT(false);
            break;
        }
        const RemoteInformation remoteInformation(object.objectId(), object.module(), object.lastModified());
        remoteInformation.store(item);

        items.append(item);
    }
```

#### AUTO 


```{c}
auto *appendJob = new KIMAP::AppendJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collectionSource, &collectionDestination](const Item &item){
                ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
                // MyContacts -> OtherContacts
                if (collectionSource.remoteId() == myContactsRemoteId()
                    && collectionDestination.remoteId() == OTHERCONTACTS_REMOTEID) {
                    contact->clearGroups();
                    // OtherContacts -> MyContacts
                } else if (collectionSource.remoteId() == OTHERCONTACTS_REMOTEID
                           && collectionDestination.remoteId() == myContactsRemoteId()) {
                    contact->addGroup(myContactsRemoteId());
                }

                return contact;
            }
```

#### AUTO 


```{c}
auto bodyMessage = new KMime::Content;
```

#### AUTO 


```{c}
auto *listJob = qobject_cast<UIDListJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        itemStrs.append(ewsHash(item.remoteId()));
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::MoveJob(session);
```

#### AUTO 


```{c}
auto subscribe = new KIMAP::SubscribeJob(create->session());
```

#### AUTO 


```{c}
const auto affRelateds{aff.relateds()};
```

#### AUTO 


```{c}
const auto attr = collection.attribute<Akonadi::NewMailNotifierAttribute>();
```

#### AUTO 


```{c}
const auto eventsList = calendar->events();
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("fileDeleted:")
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &collection : collections) {
        QStandardItem *item = new QStandardItem(collection.displayName());
        QString data(KDAV::Utils::protocolName(collection.url().protocol()) + QLatin1Char('|') + collection.url().toDisplayString());
        item->setData(data, Qt::UserRole + 1);
        item->setToolTip(collection.url().toDisplayString());
        if (collection.url().protocol() == KDAV::CalDav) {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-calendar")));
        } else {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-pim-contacts")));
        }
        mModel->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &it : lstItems) {
            if (it.remoteId() == oldUid) {
                item = it;
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { itemCreateJobResult(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[](QKeychain::Job *baseJob) {
            if (baseJob->error()) {
                qCWarning(POP3RESOURCE_LOG) << "Error writing password using QKeychain:" << baseJob->errorString();
            }
        }
```

#### AUTO 


```{c}
const auto attachments{e.attachments()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : qAsConst(dict)) {
            entries.push_back(Conversion::toStdString(e));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsServerVersion &ver : knownVersions) {
        if (*this == ver) {
            version.append(QStringLiteral(" (") + ver.mFriendlyName + QStringLiteral(")"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        // const EwsItem &ewsItem = resp.item();

        // TODO: Implement

        ++it;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &addressee : qAsConst(mAddressees)) {
        Item item;
        item.setRemoteId(addressee.uid());
        item.setMimeType(KContacts::Addressee::mimeType());
        item.setPayload(addressee);
        items.append(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsOAuth *oAuth) {
        oAuth->init();
        return true;
    }
```

#### AUTO 


```{c}
auto *rights = new KIMAP::MyRightsJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsId::List::const_iterator firstId, EwsId::List::const_iterator lastId) {
            auto req = new EwsGetItemRequest(mClient, this);
            EwsId::List ids;
            for (auto it = firstId; it != lastId; ++it) {
                ids.append(*it);
            }
            req->setItemIds(ids);
            EwsItemShape shape(EwsShapeIdOnly);
            shape << EwsPropertyField(QStringLiteral("item:MimeContent"));
            req->setItemShape(shape);
            return req;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        qCDebug(GOOGLE_CONTACTS_LOG) << "Contacts groups retrieved";

        const ObjectsList objects = qobject_cast<ContactsGroupFetchJob *>(job)->items();
        Collection::List collections;
        collections.reserve(objects.count());
        std::transform(objects.cbegin(), objects.cend(), std::back_inserter(collections), [this, &rootCollection](const ObjectPtr &object) {
            const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();
            qCDebug(GOOGLE_CONTACTS_LOG) << " -" << group->title() << "(" << group->id() << ")";
            Collection collection;
            setupCollection(collection, group);
            collection.setParentCollection(rootCollection);
            m_collections[collection.remoteId()] = collection;
            return collection;
        });
        m_iface->collectionsRetrievedFromHandler(collections);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &a : eAlarms) {
        Kolab::Alarm alarm;
        // TODO KCalendarCore disables alarms using KCalendarCore::Alarm::enabled() (X-KDE-KCALCORE-ENABLED) We should either delete the alarm, or store the
        // attribute . Ideally we would store the alarm somewhere and temporarily delete it, so we can restore it when parsing. For now we just remove disabled
        // alarms.
        if (!a->enabled()) {
            qCWarning(PIMKOLAB_LOG) << "skipping disabled alarm";
            continue;
        }
        switch (a->type()) {
        case KCalendarCore::Alarm::Display:
            alarm = Kolab::Alarm(toStdString(a->text()));
            break;
        case KCalendarCore::Alarm::Email: {
            std::vector<Kolab::ContactReference> receipents;
            const auto mailAddresses = a->mailAddresses();
            for (const KCalendarCore::Person &p : mailAddresses) {
                receipents.emplace_back(toStdString(p.email()), toStdString(p.name()));
            }
            alarm = Kolab::Alarm(toStdString(a->mailSubject()), toStdString(a->mailText()), receipents);
            break;
        }
        case KCalendarCore::Alarm::Audio: {
            Kolab::Attachment audioFile;
            audioFile.setUri(toStdString(a->audioFile()), std::string());
            alarm = Kolab::Alarm(audioFile);
            break;
        }
        default:
            qCCritical(PIMKOLAB_LOG) << "unhandled alarm";
        }

        if (a->hasTime()) {
            alarm.setStart(fromDate(a->time(), false));
        } else if (a->hasStartOffset()) {
            alarm.setRelativeStart(fromDuration(a->startOffset()), Kolab::Start);
        } else if (a->hasEndOffset()) {
            alarm.setRelativeStart(fromDuration(a->endOffset()), Kolab::End);
        } else {
            qCCritical(PIMKOLAB_LOG) << "alarm trigger is missing";
            continue;
        }

        alarm.setDuration(fromDuration(a->snoozeTime()), a->repeatCount());

        alarms.push_back(alarm);
    }
```

#### AUTO 


```{c}
auto urlConfig = new UrlConfiguration(serializedUrl);
```

#### AUTO 


```{c}
auto *job = new FakeTransferJob(postData, vfy.fn, vfy.object);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : qAsConst(mFolderIds)) {
        id.writeFolderIds(writer);
    }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(), Akonadi::CollectionFetchJob::FirstLevel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Attendee *delegator : std::as_const(delegatorsRef)) {
            // Set the delegator on each delegatee
            const ContactReference &delegatorRef = delegator->contact();
            if (!contains(delegatorRef, delegatedFrom)) {
                delegatedFrom.emplace_back(Kolab::ContactReference::EmailReference, delegatorRef.email(), delegatorRef.name());
            }

            // Set the delegatee on each delegator
            std::vector<Kolab::ContactReference> delegatedTo = delegator->delegatedTo();
            const ContactReference &delegaeeRef = delegatee->contact();
            if (!contains(delegaeeRef, delegatedTo)) {
                delegatedTo.emplace_back(Kolab::ContactReference::EmailReference, delegaeeRef.email(), delegaeeRef.name());
            }
            delegator->setDelegatedTo(delegatedTo);
        }
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Message:"), parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : std::as_const(results)) {
        qCDebug(DAVRESOURCE_LOG) << result.value;
        QUrl url(davJob->property("url").toString());
        if (result.value.startsWith(QLatin1Char('/'))) {
            // href is only a path, use request url to complete
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            // href is a complete url
            url = QUrl::fromUserInput(result.value);
        }

        if (!mPrincipalScheduleOutbox[email].contains(url.url())) {
            mPrincipalScheduleOutbox[email] << url.url();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : infos) {
        const auto keyval = token.trimmed().split(QLatin1Char('='));
        if (keyval.count() == 2) {
            if (stringToKnownCertInfoType.contains(keyval[0])) {
                map.insert(stringToKnownCertInfoType[keyval[0]], keyval[1]);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, todo, item](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                TaskPtr task(new Task(*todo));
                auto newJob = new TaskModifyJob(task, item.parentCollection().remoteId(), job->account(), this);
                newJob->setProperty(ITEM_PROPERTY, QVariant::fromValue(item));
                connect(newJob, &TaskModifyJob::finished, this, &TaskHandler::slotGenericJobFinished);
            }
```

#### AUTO 


```{c}
auto busyCursorHelper = new BusyCursorHelper(mServerTest);
```

#### AUTO 


```{c}
auto fetchedMsgPtr = fetchedItem.payload<KMime::Message::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        modifyDone(job);
    }
```

#### AUTO 


```{c}
auto authJob = qobject_cast<KGAPI2::AuthJob*>(job);
```

#### AUTO 


```{c}
auto *dialog = new ServerInfoDialog(m_parentResource, this);
```

#### AUTO 


```{c}
const auto seenUidList{mSettings.seenUidList()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : qAsConst(entryList)) {
        // TODO: Use cache policy to see what actually has to been set as payload.
        //       Currently most views need a minimal amount of information so the
        //       Items get Envelopes as payload.
        auto mail = new KMime::Message();
        mail->setHead(KMime::CRLFtoLF(mMBox->readMessageHeaders(entry)));
        mail->parse();

        Item item;
        item.setRemoteId(colId + QLatin1String("::") + colRid + QLatin1String("::") + QString::number(entry.messageOffset()));
        item.setMimeType(QStringLiteral("message/rfc822"));
        item.setSize(entry.messageSize());
        item.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, item);
        Q_EMIT percent(count++ / entryListSize);
        items << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        mSubscriptions.reset();
    }
```

#### AUTO 


```{c}
auto modifiedJob = new FoldersRequestJob(mLastSync, FoldersRequestJob::Modified, this);
```

#### AUTO 


```{c}
auto modJob = new Akonadi::TagModifyJob(updateTag);
```

#### AUTO 


```{c}
auto writeJob = new EwsGlobalTagsWriteJob(mTagStore, mClient, res->rootCollection(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Incidence::Ptr &incidence : qAsConst(mIncidences)) {
        Item item;
        item.setRemoteId(incidence->instanceIdentifier());
        item.setMimeType(incidence->mimeType());
        items.append(item);
    }
```

#### AUTO 


```{c}
auto j = new Akonadi::ItemModifyJob(dependentItems);
```

#### AUTO 


```{c}
const auto &iType
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(targetCollection, CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *job = new CollectionModifyJob(col, Private::mInstance->parent());
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(col, this);
```

#### AUTO 


```{c}
static const auto o365FakeUserAgent = QStringLiteral("Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36");
```

#### AUTO 


```{c}
auto queryJob = qobject_cast<KGAPI2::FreeBusyQueryJob*>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        auto itemMail = item.payload<KMime::Message::Ptr>();
        QByteArray itemMailBody = itemMail->body();

        // For some reason, the body in the maildir has one additional newline.
        // Get rid of this so we can compare them.
        // FIXME: is this a bug? Find out where the newline comes from!
        itemMailBody.chop(1);
        itemMailBodies.insert(itemMailBody);
    }
```

#### AUTO 


```{c}
auto msg = messages.cbegin(), end = messages.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item item : qAsConst(origItems)) {   //krazy:exclude=foreach non-const is intended here
        const KDAV::DavItem davItem = davJob->item(item.remoteId());

        // No data was retrieved for this item, maybe because it is not out of date
        if (davItem.data().isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Empty item returned. " << item.remoteId();
            if (!cache->isOutOfDate(item.remoteId())) {
                qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Item is not changed, including it. " << item.remoteId();
                items << item;
            }
            continue;
        }

        Akonadi::Item::List extraItems;
        if (!Utils::parseDavData(davItem, item, extraItems)) {
            qCWarning(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Failed to parse item data. " << item.remoteId();
            continue;
        }

        // update etag
        item.setRemoteRevision(davItem.etag());
        cache->setEtag(item.remoteId(), davItem.etag());
        items << item;
        for (const Akonadi::Item &extraItem : qAsConst(extraItems)) {
            cache->setEtag(extraItem.remoteId(), davItem.etag());
            items << extraItem;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg]() {
        dlg->deleteLater();
        d->token = dlg->token();
        d->cookies = dlg->cookies();
        if (d->token.isEmpty()) {
            emitError(i18n("Failed to obtain access token from Facebook"));
            return;
        }

        fetchUserInfo();
    }
```

#### AUTO 


```{c}
auto *fetchJob = new KIMAP::FetchJob(mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &scope : resourceScopes) {
            if (!account->scopes().contains(scope)) {
                account->addScope(scope);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : std::as_const(idsOfMessagesDownloadedButNotDeleted)) {
        const QString uid = mIdsToUidsMap.value(id);
        if (!uid.isEmpty()) {
            uidsOfMessagesDownloadedButNotDeleted.append(uid);
        }
    }
```

#### AUTO 


```{c}
auto itemMail = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto *idJob = qobject_cast<KIMAP::IdJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        const EwsItem &ewsItem = resp.item();
        QString mimeContent = ewsItem[EwsItemFieldMimeContent].toString();
        KCalendarCore::Calendar::Ptr memcal(new KCalendarCore::MemoryCalendar(QTimeZone::utc()));
        format.fromString(memcal, mimeContent);
        qCDebugNC(EWSRES_LOG) << QStringLiteral("Found %1 events").arg(memcal->events().count());
        KCalendarCore::Incidence::Ptr incidence;
        if (memcal->events().count() > 1) {
            const auto memcalEvents{memcal->events()};
            for (const KCalendarCore::Event::Ptr &event : memcalEvents) {
                qCDebugNC(EWSRES_LOG) << QString::number(event->recurrence()->recurrenceType(), 16) << event->recurrenceId() << event->recurrenceId().isValid();
                if (!event->recurrenceId().isValid()) {
                    incidence = event;
                }
            }
            const auto excList = ewsItem[EwsItemFieldModifiedOccurrences].value<EwsOccurrence::List>();
            for (const EwsOccurrence &exc : excList) {
                addItems.append(exc.itemId());
            }
        } else if (memcal->events().count() == 1) {
            incidence = memcal->events()[0];
        }
        // KCalendarCore::Incidence::Ptr incidence(format.fromString(mimeContent));

        if (incidence) {
            QDateTime dt(incidence->dtStart());
            if (dt.isValid()) {
                incidence->setDtStart(dt);
            }
            if (incidence->type() == KCalendarCore::Incidence::TypeEvent) {
                auto event = reinterpret_cast<KCalendarCore::Event *>(incidence.data());
                dt = event->dtEnd();
                if (dt.isValid()) {
                    event->setDtEnd(dt);
                }
            }
            dt = incidence->recurrenceId();
            if (dt.isValid()) {
                incidence->setRecurrenceId(dt);
            }

            item.setPayload<KCalendarCore::Incidence::Ptr>(incidence);
        }

        ++it;
    }
```

#### AUTO 


```{c}
auto modifyJob = qobject_cast<FileStore::ItemModifyJob *>(job);
```

#### AUTO 


```{c}
auto *disposition
                = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto authJob = qobject_cast<KGAPI2::AuthJob *>(job);
```

#### AUTO 


```{c}
auto listView = new QListView(widget);
```

#### AUTO 


```{c}
const auto mailAddresses = a->mailAddresses();
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyItemsDownloadJob*>(kjob);
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
                const QVariant tagListVar = tagListHash[ item.remoteId() ];
                if (tagListVar.isValid()) {
                    const QStringList tagList = tagListVar.toStringList();
                    if (!tagListHash.isEmpty()) {
                        TagContext tag;
                        tag.mItem = item;
                        tag.mTagList = tagList;

                        taggedItems << tag;
                    }
                }
            }
```

#### AUTO 


```{c}
auto *changeHelper = new TagChangeHelper(this);
```

#### AUTO 


```{c}
auto promise = KGAPI2::AccountManager::instance()->findAccount(GOOGLE_API_KEY, mResource->settings()->userName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &abv : abvs) {
//                 if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                ++matchedTransitions;
                break;
//                 }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folder : list) {
        ++childCount[folder.parentId];
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &h : qAsConst(headers)) {
        if (first) {
            first = false;
        } else {
            ret.append(",");
        }
        ret.append(h.name);
        ret.append("=\"");
        ret.append(QUrl::toPercentEncoding(QString::fromLatin1(h.value)));
        ret.append("\"");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &entry : entries) {
        QDir subdir(entry.absoluteFilePath());

        Collection collection;
        collection.setParentCollection(parentCollection);
        collection.setRemoteId(entry.fileName());
        collection.setName(entry.fileName());
        collection.setContentMimeTypes(mSupportedMimeTypes);
        collection.setRights(supportedRights(false));

        collections << collection;
        collections << createCollectionsForDirectory(subdir, collection);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Item &item) {
        return item.remoteId();
    }
```

#### AUTO 


```{c}
const auto fileStorage = FileStorage::Ptr(new FileStorage(calendar, path, new ICalFormat()));
```

#### AUTO 


```{c}
auto it = d->attendees.begin(), end = d->attendees.end();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Custom &custom : std::as_const(mCustomList)) {
        incidence->setNonKDECustomProperty(custom.key, custom.value);
    }
```

#### AUTO 


```{c}
const auto collection = arg.value<Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &tmpItem : allRemoteItems) {
            if (tmpItem.payloadData() != localItem.payloadData()) {
                if (remoteItem.isValid()) {
                    // Oops, we can only manage one changed item at this stage, sorry...
                    // TODO: make this translatable
                    cancelTask(i18n("Unable to change item: %1", QStringLiteral("more than one item was changed in the backend")));
                    return;
                }
                remoteItem = tmpItem;
            } else {
                remoteDependentItems << tmpItem;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : qAsConst(mListEmails)) {
            if (mFrom.contains(email)) {
                // Exclude this notification
                deleteLater();
                return;
            }
        }
```

#### AUTO 


```{c}
const auto *attr = c.attribute<CompatibilityAttribute>();
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource, mResourceId);
```

#### AUTO 


```{c}
auto modifyJob = new ItemModifyJob(updatedItem);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->checkFuture(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(mMailboxes)) {
            // "Shared Folders" is not a valid mailbox, so we have to skip the ACL request for this folder
            if (isNamespaceFolder(mailbox, mSharedNamespace, true)) {
                continue;
            }
            auto *rights = new KIMAP::MyRightsJob(mSession);
            rights->setMailBox(mailbox);
            connect(rights, &KJob::result, this, &RetrieveMetadataJob::onRightsReceived);
            mJobs++;
            rights->start();
        }
```

#### AUTO 


```{c}
auto kEvent = fromXML<KCalendarCore::Event::Ptr, KolabV2::Event>(xmlData, attachments);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto token : info.split(',', QString::SkipEmptyParts)) {
        const auto keyval = token.trimmed().split('=');
        if (keyval.count() == 2) {
            if (stringToKnownCertInfoType.contains(keyval[0])) {
                map.insert(stringToKnownCertInfoType[keyval[0]], keyval[1]);
            }
        }
    }
```

#### AUTO 


```{c}
auto bjob = qobject_cast<BirthdayListJob*>(job)
```

#### AUTO 


```{c}
auto job = new FileStore::ItemDeleteJob(item, d->mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QNetworkCookie &cookie) {
                    mCookies.remove(cookie.name());
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        Item newItem(item);
        const EventPtr event = qobject_cast<EventCreateJob *>(job)->items().first().dynamicCast<Event>();
        qCDebug(GOOGLE_CALENDAR_LOG) << "Event added";
        newItem.setRemoteId(event->id());
        newItem.setRemoteRevision(event->etag());
        newItem.setGid(event->uid());
        m_iface->itemChangeCommitted(newItem);
        newItem.setPayload<KCalendarCore::Event::Ptr>(event.dynamicCast<KCalendarCore::Event>());
        new ItemModifyJob(newItem, this);
        emitReadyStatus();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : memcalEvents) {
                qCDebugNC(EWSRES_LOG) << QString::number(event->recurrence()->recurrenceType(), 16) << event->recurrenceId() << event->recurrenceId().isValid();
                if (!event->recurrenceId().isValid()) {
                    incidence = event;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int prot : qAsConst(protocols)) {
        addAuthenticationItem(m_ui->authenticationCombo, (MailTransport::Transport::EnumAuthenticationType::type) prot);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return false;
        };
        wallet->createFolderCallback = [](const QString &) {
            return false;
        };
    }
```

#### AUTO 


```{c}
auto job = new EwsUpdateItemsTagsJob(items, mTagStore, mEwsClient, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int s, const QString & message) {
        Q_EMIT status(s, message);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                CalendarPtr calendar = qobject_cast<CalendarCreateJob *>(job)->items().first().dynamicCast<Calendar>();
                qCDebug(GOOGLE_CALENDAR_LOG) << "Created calendar" << calendar->uid();
                // Enable newly added calendar in settings, otherwise user won't see it
                m_settings->addCalendar(calendar->uid());
                // TODO: the calendar returned by google is almost empty, i.e. it's not "editable",
                // does not contain the color, etc
                calendar->setEditable(true);
                // Populate remoteId & other stuff
                Collection newCollection(collection);
                setupCollection(newCollection, calendar);
                m_iface->collectionChangeCommitted(newCollection);
                emitReadyStatus();
            }
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(newCol, transaction());
```

#### LAMBDA EXPRESSION 


```{c}
[this] {loadFiles();}
```

#### AUTO 


```{c}
auto json = QJsonDocument::fromJson(tjob->data(), &error);
```

#### AUTO 


```{c}
static const auto o365AuthorizationUrl = QUrl(QStringLiteral("https://login.microsoftonline.com/common/oauth2/authorize"));
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<EwsFetchItemPayloadJob *>(job);
```

#### AUTO 


```{c}
auto *annotationsAttribute = c.attribute<Akonadi::CollectionAnnotationsAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Folder &folder : folders) {
        if (folder.folderId() == 1) {
            // Found folder with 'Private Folders' as parent, so the owner must
            // be the user that is currently logged in.
            mUserId = folder.owner();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &colId : collections) {
        collection = Akonadi::Collection(id);
        collection.setRemoteId(separator + colId);
        collection.setParentCollection(parent);

        parent = collection;
        id++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &resp : mChunkedJob.responses()) {
        if (!resp.isSuccess()) {
            setErrorText(QStringLiteral("Item update failed: ") + resp.responseMessage());
            emitResult();
            return;
        }

        /* In general EWS guarantees that the order of response items will match the order of request items.
         * It is therefore safe to iterate these in parallel. */
        if (it->remoteId() == resp.itemId().id()) {
            it->setRemoteRevision(resp.itemId().changeKey());
            ++it;
        } else {
            setErrorText(i18nc("@info:status", "Item out of order while processing update item response."));
            emitResult();
            return;
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned dayOfWeekIndexNameCount = sizeof(dayOfWeekIndexNames) / sizeof(dayOfWeekIndexNames[0]);
```

#### AUTO 


```{c}
const auto token
```

#### AUTO 


```{c}
const auto stdVectorByMinutes = std::vector<int>(byMinutesVector.begin(), byMinutesVector.end());
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemDeleteJob(mItem);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsSyncFolderHierarchyRequest *>(job);
```

#### AUTO 


```{c}
auto *login = static_cast<KIMAP::LoginJob *>(job);
```

#### AUTO 


```{c}
auto cookieStore = profile->cookieStore();
```

#### AUTO 


```{c}
auto generator = QRandomGenerator::global();
```

#### AUTO 


```{c}
auto attr = col.attribute<CompatibilityAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto memcalEvents{memcal->events()};
```

#### AUTO 


```{c}
auto *search = new KIMAP::SearchJob(m_session);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection & col, const Akonadi::Collection &) {
        stateChanged(col);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            runNextJob();
        }
```

#### AUTO 


```{c}
auto *expandJob = qobject_cast<Akonadi::ContactGroupExpandJob *>(job);
```

#### AUTO 


```{c}
auto *meta = new KIMAP::GetMetaDataJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(QString::number(entry.messageOffset()));
        item.setParentCollection(collection);

        if (mbox->hasIndexData()) {
            const KMIndexDataPtr indexData = mbox->indexData(entry.messageOffset());
            if (indexData != nullptr && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has"
                                                      << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            } else if (indexData == nullptr) {
                Akonadi::MessageStatus status;
                status.setDeleted(true),
                item.setFlags(status.statusFlags());
                qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "no index for item" << item.remoteId() << "in MBox" << mbox->fileName()
                                                  << "so it has been deleted but not purged. Marking it as"
                                                  << item.flags();
            }
        }

        items << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int deletedId : std::as_const(mDeletedIDs)) {
        const QString deletedUID = mIdsToUidsMap.value(deletedId);
        if (!deletedUID.isEmpty()) {
            int index = seenUIDs.indexOf(deletedUID);
            if (index != -1) {
                // TEST
                qCDebug(POP3RESOURCE_LOG) << "Removing UID" << deletedUID << "from the seen UID list, as it was deleted.";
                seenUIDs.removeAt(index);
                timeOfSeenUids.removeAt(index);
            }
        }
        mIdsToUidsMap.remove(deletedId);
        mIdsToSizeMap.remove(deletedId);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->dispatch(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : ids) {
        mAllowedRetrieves.append(id.toUtf8());
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int fetchBatchSize = 50;
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxPtr &mbox : qAsConst(mMBoxes)) {
        if (mbox->mCollection.isValid()) {
            MBoxPtr updatedMBox = mbox;
            updatedMBox->mCollection = updateMBoxCollectionTree(mbox->mCollection, moveCollection, movedCollection);
        }
    }
```

#### AUTO 


```{c}
const auto attr = c.attribute<CompatibilityAttribute>();
```

#### AUTO 


```{c}
auto precommandJob = new PrecommandJob(mSettings.precommand(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto folderId : ids) {
        xQueryFolderIds.append(QStringLiteral("//m:GetFolder/m:FolderIds/t:FolderId[position()=%1 and @Id=\"%2\"]")
                               .arg(++folderIndex).arg(folderId));
        responseXml += QStringLiteral("<m:GetFolderResponseMessage ResponseClass=\"Success\">");
        responseXml += QStringLiteral("<m:ResponseCode>NoError</m:ResponseCode>");
        responseXml += QStringLiteral("<m:Folders><t:Folder>");
        responseXml += QStringLiteral("<t:FolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folderId);
        responseXml += QStringLiteral("</t:Folder></m:Folders>");
        responseXml += QStringLiteral("</m:GetFolderResponseMessage>");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QNetworkCookie &cookie) {
                    if (cookie.domain() == QLatin1String(".facebook.com")) {
                        mCookies.insert(cookie.name(), cookie.toRawForm());
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &p) {
        password = p;
        loop.exit(0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : taglist) {
        QByteArray tagdata = qUncompress(QByteArray::fromBase64(tag.toLatin1()));
        if (tagdata.isNull()) {
            qCDebugNC(EWSRES_LOG) << QStringLiteral("Incorrect tag data");
        } else {
            QDataStream stream(tagdata);
            stream.setVersion(QDataStream::Qt_5_4);
            QByteArray key, data;
            stream >> key >> data;
            if (stream.status() != QDataStream::Ok) {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Incorrect tag entry");
                mTagData.clear();
                return false;
            } else {
                mTagData.insert(key, data);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            processNextBatch();
        }
```

#### AUTO 


```{c}
auto expandJob = qobject_cast<Akonadi::ContactGroupExpandJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setTestPassword(QStringLiteral("foo"));
    }
```

#### AUTO 


```{c}
auto *requester = new DummyPasswordRequester(this);
```

#### AUTO 


```{c}
auto itemFetch = qobject_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *job = new FileStore::CollectionModifyJob(collection, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : calendars) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection |
                                 Collection::CanCreateItem |
                                 Collection::CanChangeItem |
                                 Collection::CanDeleteItem);
        } else {
            collection.setRights(Q_NULLPTR);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int p) {
        percent(p);
    }
```

#### AUTO 


```{c}
auto lab = new QLabel(i18nc("@label:chooser for the folder that messages will be archived under", "Archive into:"));
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto fetchJob = new ItemFetchJob(mCollection, this);
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto it = inputFiles.begin();
```

#### AUTO 


```{c}
auto *select = new KIMAP::SelectJob(m_session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        const Collection collection = item.parentCollection();
        const qint64 revision = collection.remoteRevision().toLongLong();

        RevisionChangeMap &changesByRevision = d->mChangesByCollection[collection.id()];
        OldIdItemMap &changes = changesByRevision[revision];
        changes.insert(item.remoteId(), item);

        if (!updateBatch.collection.isValid()) {
            updateBatch.collection = collection;
        } else if (updateBatch.collection != collection) {
            d->mPendingUpdates << updateBatch;
            updateBatch.items.clear();
            updateBatch.collection = collection;
        }

        updateBatch.items << item;
    }
```

#### AUTO 


```{c}
auto *widget = new MigrationStatusWidget(mScheduler, dlg);
```

#### AUTO 


```{c}
auto *fetch = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(mItems)) {
        EwsItemType type = EwsItemHandler::mimeToItemType(item.mimeType());
        if (type == EwsItemTypeUnknown) {
            setErrorText(QStringLiteral("Unknown item type %1 for item %2").arg(item.mimeType(), item.remoteId()));
            emitResult();
            return;
        } else {
            items[type].append(item);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { abort(); }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavCollectionDeleteJob(davUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : folders) {
        Collection c;
        c.setRemoteId(id.id());
        auto job = new CollectionFetchJob(c, CollectionFetchJob::Base);
        job->setFetchScope(changeRecorder()->collectionFetchScope());
        job->fetchScope().setResource(identifier());
        job->fetchScope().setListFilter(CollectionFetchScope::Sync);
        connect(job, &KJob::result, this, &EwsResource::foldersModifiedCollectionSyncFinished);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        qCritical() << "SELECTED DATA: " << index.data(Qt::UserRole + 1).toString();
        ret << index.data(Qt::UserRole + 1).toString();
    }
```

#### AUTO 


```{c}
const auto networkError = mAuthReply->networkError();
```

#### AUTO 


```{c}
auto session = new Akonadi::Session(resourceName().toLatin1() + "_body_checker", this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsFetchItemsJob *fetchJob) {
        auto col = fetchJob->collection();
        if (fetchJob->error()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Item fetch error:") << fetchJob->errorString() << fetchJob->error();
            const auto syncState = getCollectionSyncState(fetchJob->collection());
            if (!syncState.isEmpty()) {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Retrying with empty state.");
                // Retry with a clear sync state.
                saveCollectionSyncState(col, QString());
                retrieveItems(col);
            } else {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Clean sync failed.");
                // No more hope
                cancelTask(i18nc("@info:status", "Failed to retrieve items"));
                return;
            }
        } else {
            saveCollectionSyncState(col, fetchJob->syncState());
            itemsRetrievedIncremental(fetchJob->newItems() + fetchJob->changedItems(), fetchJob->deletedItems());
        }
        saveState();
        mItemsToCheck.remove(fetchJob->collection().remoteId());
        emitReadyStatus();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        auto queryJob = qobject_cast<FreeBusyQueryJob *>(job);
        if (!m_iface->handleError(job, false)) {
            m_iface->handlesFreeBusy(queryJob->id(), false);
            return;
        }
        m_iface->handlesFreeBusy(queryJob->id(), true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
                if (job->error()) {
                    emitError(job->errorText());
                    return;
                }

                auto cal = KCalCore::MemoryCalendar::Ptr::create(QTimeZone::systemTimeZone());
                KCalCore::ICalFormat format;
                if (!format.fromRawString(cal, job->data(), false)) {
                    emitError(i18n("Failed to parse birthday calendar"));
                    return;
                }

                const auto events = cal->events();
                for (const auto &event : events) {
                    processEvent(event);
                }

                emitResult();
            }
```

#### AUTO 


```{c}
const auto location = locationIt->toObject();
```

#### AUTO 


```{c}
auto job = new ContactModifyJob(contact, m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto copy = new FileStore::EntityCompactChangeAttribute();
```

#### AUTO 


```{c}
auto urlConfig = new Settings::UrlConfiguration();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        auth->walletMapRequestFinished(mAuthMap);
    }
```

#### AUTO 


```{c}
const auto *flagAttr = collection.attribute<Akonadi::CollectionFlagsAttribute>();
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(mResourceCollection, CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
const auto mailAddresses{a->mailAddresses()};
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { transactionResult(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            ui->loginStatusLbl->setText(job->errorText());
        } else {
            const auto token = job->token();
            if (token.isEmpty()) {
                ui->loginStatusLbl->setText(i18n("Not logged in"));
                ui->logoutBtn->setVisible(false);
                ui->loginBtn->setVisible(true);
            } else {
                ui->loginStatusLbl->setText(i18n("Logged in as <b>%1</b>", job->userName()));
                ui->loginBtn->setVisible(false);
                ui->logoutBtn->setVisible(true);
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new RetrieveItemsJob(col, mStore, this);
```

#### AUTO 


```{c}
auto job = new ContactModifyJob(contacts, m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto rsvp = Graph::rsvpFromString(col.remoteId());
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::CollectionFetchJob(rootCollection, Akonadi::CollectionFetchJob::Base);
```

#### RANGE FOR STATEMENT 


```{c}
for (Attendee *delegatee : std::as_const(delegateesRef)) {
        std::vector<Kolab::ContactReference> delegatedFrom = delegatee->delegatedFrom();
        for (Attendee *delegator : std::as_const(delegatorsRef)) {
            // Set the delegator on each delegatee
            const ContactReference &delegatorRef = delegator->contact();
            if (!contains(delegatorRef, delegatedFrom)) {
                delegatedFrom.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegatorRef.email(), delegatorRef.name()));
            }

            // Set the delegatee on each delegator
            std::vector<Kolab::ContactReference> delegatedTo = delegator->delegatedTo();
            const ContactReference &delegaeeRef = delegatee->contact();
            if (!contains(delegaeeRef, delegatedTo)) {
                delegatedTo.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegaeeRef.email(), delegaeeRef.name()));
            }
            delegator->setDelegatedTo(delegatedTo);
        }
        delegatee->setDelegatedFrom(delegatedFrom);
    }
```

#### AUTO 


```{c}
auto authJob = new AuthJob(account, m_settings->clientId(), m_settings->clientSecret(), this);
```

#### AUTO 


```{c}
auto *davJob = qobject_cast< KDAV::DavCollectionsFetchJob *>(job);
```

#### AUTO 


```{c}
auto *hLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader, const QString &) {
            if (!readResponseElement(reader)) {
                setErrorMsg(QStringLiteral("Failed to read EWS request - invalid response element."));
                return false;
            }
            return true;
        }
```

#### AUTO 


```{c}
const auto attribute = sentItem.attribute<MailTransport::SentActionAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[](QString cur, const QSslError &error) {
            if (!cur.isEmpty())
                cur += QLatin1Char('\n');
            cur += error.errorString();
            return cur;
        }
```

#### AUTO 


```{c}
auto ref = job->property("QEventLoopLocker").value<QEventLoopLocker*>();
```

#### AUTO 


```{c}
auto fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(Item::fromUrl(url));
```

#### AUTO 


```{c}
auto modifyJob = new Akonadi::CollectionModifyJob(collection);
```

#### AUTO 


```{c}
auto *itemCreateJob = new ItemCreateJob(item, mTargetCollection);
```

#### AUTO 


```{c}
auto *attr = c.attribute<Akonadi::CollectionIdentificationAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto storeJob = new KIMAP::StoreJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsOAuth *oAuth) {
            return oAuth->authenticate(true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Job *job){
        if (!handleError(job) || !m_account) {
            m_ui->calendarsBox->setEnabled(false);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeCalendars;
        if (m_account->accountName() == m_settings->account()) {
            activeCalendars = m_settings->calendars();
        }
        m_ui->calendarsList->clear();
        for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            QListWidgetItem *item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }

        m_ui->calendarsBox->setEnabled(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            authFinished = true;
            loop.exit(0);
        }
```

#### AUTO 


```{c}
auto *job = new ItemDeleteJob(c);
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxReconnectTimeout = 300;
```

#### LAMBDA EXPRESSION 


```{c}
[](const Collection &col, const DesiredState &state) {
            auto attr = col.attribute<SpecialCollectionAttribute>();
            QByteArray specialType;
            if (attr) {
                specialType = attr->collectionType();
            }
            return col.parentCollection().remoteId() == state.parentId && specialType == state.specialType;
        }
```

#### AUTO 


```{c}
auto job = new TomboyItemDownloadJob(item, mManager, this);
```

#### AUTO 


```{c}
auto req = new EwsGetFolderRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(mMailboxes)) {
            // "Shared Folders" is not a valid mailbox, so we have to skip the ACL request for this folder
            if (isNamespaceFolder(mailbox, mSharedNamespace, true)) {
                continue;
            }
            KIMAP::MyRightsJob *rights = new KIMAP::MyRightsJob(mSession);
            rights->setMailBox(mailbox);
            connect(rights, &KJob::result, this, &RetrieveMetadataJob::onRightsReceived);
            mJobs++;
            rights->start();
        }
```

#### AUTO 


```{c}
auto *job = new KIMAP::AppendJob(session);
```

#### AUTO 


```{c}
auto job = new JournalsFetchJob(mClientState->account(), mRootCollection, collectionsCacheDirectoryPath(), this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int listBatchSize = 100;
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(m_collection, this);
```

#### AUTO 


```{c}
const auto code = err.value(QLatin1String("code")).toInt();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : query.queryItems()) {
        params[it.first.toLower()] = QUrl::fromPercentEncoding(it.second.toLatin1());
    }
```

#### AUTO 


```{c}
auto *attribute = collection.attribute<EntityDisplayAttribute>();
```

#### AUTO 


```{c}
auto *job = new FileStore::CollectionDeleteJob(collection, d->mSession);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto *d = reinterpret_cast<const EwsItemPrivate *>(this->d.data());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &chunk) {
        const QString respHead = QStringLiteral("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
                "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
                "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
                "<soap:Header>"
                "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
                "</soap:Header>"
                "<soap:Body>"
                "<m:GetStreamingEventsResponse>"
                "<m:ResponseMessages>"
                "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
                "<m:ResponseCode>NoError</m:ResponseCode>"
                "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral("</m:GetStreamingEventsResponseMessage>"
                "</m:ResponseMessages>"
                "</m:GetStreamingEventsResponse>"
                "</soap:Body>"
                "</soap:Envelope>");
        const QString eventHead = QStringLiteral("<m:Notifications>"
                "<m:Notification>"
                "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral("<NewMailEvent>"
                "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
                "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
                "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
                "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediatelly" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(mLocalItems)) {
        itemHash.insert(item.remoteId(), item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ItemChange &ch : std::as_const(mChanges)) {
        ch.write(writer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &scope : resourceScopes) {
        if (!m_account->scopes().contains(scope)) {
            m_account->addScope(scope);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Alarm &a : alarms) {
        KCalendarCore::Alarm::Ptr alarm = KCalendarCore::Alarm::Ptr(new KCalendarCore::Alarm(&i));
        switch (a.type()) {
        case Kolab::Alarm::EMailAlarm: {
            KCalendarCore::Person::List receipents;
            const auto aAttendees{a.attendees()};
            for (Kolab::ContactReference c : aAttendees) {
                KCalendarCore::Person person(fromStdString(c.name()), fromStdString(c.email()));
                receipents.append(person);
            }
            alarm->setEmailAlarm(fromStdString(a.summary()), fromStdString(a.description()), receipents);
            break;
        }
        case Kolab::Alarm::DisplayAlarm:
            alarm->setDisplayAlarm(fromStdString(a.text()));
            break;
        case Kolab::Alarm::AudioAlarm:
            alarm->setAudioAlarm(fromStdString(a.audioFile().uri()));
            break;
        default:
            qCCritical(PIMKOLAB_LOG) << "invalid alarm";
        }

        if (a.start().isValid()) {
            alarm->setTime(toDate(a.start()));
        } else if (a.relativeStart().isValid()) {
            if (a.relativeTo() == Kolab::End) {
                alarm->setEndOffset(toDuration(a.relativeStart()));
            } else {
                alarm->setStartOffset(toDuration(a.relativeStart()));
            }
        }

        alarm->setSnoozeTime(toDuration(a.duration()));
        alarm->setRepeatCount(a.numrepeat());
        alarm->setEnabled(true);
        i.addAlarm(alarm);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : fetchJob->collections()) {
            const auto remoteId = col.remoteId();
            const auto state = mStateHash.find(remoteId);
            if (state != mStateHash.end()) {
                stateChanged(col);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {return parseItemsResponse(reader);}
```

#### AUTO 


```{c}
auto msg = item().payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
const auto keys{mEtagCaches.keys()};
```

#### AUTO 


```{c}
auto job = new ItemDeleteJob(c);
```

#### AUTO 


```{c}
auto *renameJob = static_cast<KIMAP::RenameJob *>(job);
```

#### AUTO 


```{c}
auto colorAttribute = col.attribute<Akonadi::CollectionColorAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        Item newItem(item);
        const EventPtr event = qobject_cast<EventCreateJob *>(job)->items().first().dynamicCast<Event>();
        qCDebug(GOOGLE_CALENDAR_LOG) << "Event added";
        newItem.setRemoteId(event->id());
        newItem.setRemoteRevision(event->etag());
        newItem.setGid(event->uid());
        m_iface->itemChangeCommitted(newItem);
        newItem.setPayload<KCalendarCore::Event::Ptr>(event.dynamicCast<KCalendarCore::Event>());
        new ItemModifyJob(newItem, this);
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
auto *job = new ItemCreateJob(item, c);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(item);
```

#### AUTO 


```{c}
const auto rawCode = reader.readElementText();
```

#### AUTO 


```{c}
auto select = new KIMAP::SelectJob(mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &str : list) {
            writer.writeTextElement(ewsTypeNsUri, QStringLiteral("Value"), str);
        }
```

#### AUTO 


```{c}
auto attribute = mDavCollectionRoot.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
        if (flag == MessageFlags::Seen) {
            isRead = true;
        } else if (flag == MessageFlags::Flagged) {
            isFlagged = true;
        } else if (flag == MessageFlags::HasAttachment || flag == MessageFlags::HasInvitation || flag == MessageFlags::Signed
                   || flag == MessageFlags::Encrypted) {
            // These flags are read-only. Remove them from the unknown list but don't do anything with them.
        } else {
            unknownFlags.insert(flag);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &a : alarms) {
        mAlarms.push_back(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(QString::number(entry.messageOffset()));
        item.setParentCollection(collection);

        if (mbox->hasIndexData()) {
            const KMIndexDataPtr indexData = mbox->indexData(entry.messageOffset());
            if (indexData != nullptr && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has" << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            } else if (indexData == nullptr) {
                Akonadi::MessageStatus status;
                status.setDeleted(true);
                item.setFlags(status.statusFlags());
                qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "no index for item" << item.remoteId() << "in MBox" << mbox->fileName()
                                                  << "so it has been deleted but not purged. Marking it as" << item.flags();
            }
        }

        items << item;
    }
```

#### AUTO 


```{c}
auto *aclAttribute = new Akonadi::ImapAclAttribute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QStringLiteral("etag:"), Qt::CaseInsensitive)) {
            etag = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->calendarsList->setEnabled(false);
            m_ui->reloadCalendarsBtn->setEnabled(false);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeCalendars;
        if (m_account->accountName() == m_settings->account()) {
            activeCalendars = m_settings->calendars();
        }
        m_ui->calendarsList->clear();
        for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            auto item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }

        m_ui->calendarsList->setEnabled(true);
        m_ui->reloadCalendarsBtn->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QIcon::fromTheme(QStringLiteral("dialog-warning")), msg);
```

#### AUTO 


```{c}
const auto supportedFlags = fromAkonadiToSupportedImapFlags(addedFlags().values(), items().at(0).parentCollection());
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready){
                if (accountId() > 0) {
                    return;
                }
                if (!ready) {
                    Q_EMIT status(Broken, i18n("Can't access KWallet"));
                    return;
                }
                if (m_settings->accountPtr().isNull()) {
                    Q_EMIT status(NotConfigured);
                    return;
                }
                emitReadyStatus();
                synchronize();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, startFn, fetchJob](KJob *) {
        startFn(fetchJob);
        dequeueFetchItemsJob();
    }
```

#### AUTO 


```{c}
auto *fetch
            = new Akonadi::CollectionFetchJob(collection,
                                              Akonadi::CollectionFetchJob::Base,
                                              this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attachment : qAsConst(attachments)) {
            mAttachments.push_back(Conversion::toStdString(attachment));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &a : std::as_const(mAlarms)) {
            a->setParent(incidence.data());
            incidence->addAlarm(a);
        }
```

#### AUTO 


```{c}
auto groupboxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto modifyJob = new CollectionModifyJob(mboxCollection);
```

#### AUTO 


```{c}
auto *job = new FileStore::ItemMoveJob(item, targetParent, d->mSession);
```

#### AUTO 


```{c}
auto job = new TaskListModifyJob(taskList, m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const Item &item){
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        contact->removeGroup(collection.remoteId());
        return contact;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : qAsConst(idsToDownload)) {
            sizesOfMessagesToDownload.append(mIdsToSizeMap.value(id));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(entrySet2)) {
        QVERIFY(md2.removeEntry(entry));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &kept : keptItems) {
            if (kept.remoteId() == ridBase && extraItems.isEmpty()) {
                mainItem = kept;
            } else {
                extraItems << kept;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : removedTags) {
        mChangedTags.append(tag);
    }
```

#### AUTO 


```{c}
auto searchJob = new KIMAP::SearchJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &oldId : oldIds) {
                if (!ids.contains(oldId)) {
                    auto job = new KIMAP::SetAclJob(session);
                    job->setMailBox(mailBoxForCollection(collection()));
                    job->setIdentifier(oldId);
                    job->setRights(KIMAP::SetAclJob::Remove, oldRights[oldId]);

                    connect(job, &KIMAP::SetAclJob::result, this, &ChangeCollectionTask::onSetAclDone);

                    job->start();

                    m_pendingJobs++;
                }
            }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QIcon::fromTheme(QStringLiteral("dialog-information")), msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (O2Reply *timedReply : std::as_const(replies_)) {
        delete timedReply;
    }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavCollectionModifyJob(davUrl);
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(QStringLiteral("<test1><a /></test1>"), srv->portNumber());
```

#### AUTO 


```{c}
auto attr = root.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
static const auto KWalletKeyName = QStringLiteral("name");
```

#### AUTO 


```{c}
static const auto WalletFolder = QStringLiteral("Akonadi Google");
```

#### AUTO 


```{c}
const auto origItems = job->property("items").value<Akonadi::Item::List>();
```

#### AUTO 


```{c}
static const auto o365AccessTokenUrl = QUrl(QStringLiteral("https://login.microsoftonline.com/common/oauth2/token"));
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<EventFetchJob *>(job);
```

#### AUTO 


```{c}
auto search = static_cast<KIMAP::SearchJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this, items](KJob *job){
        if (job->error()) {
            m_iface->cancelTask(i18n("Failed to delete task: %1", job->errorString()));
            return;
        }
        const Item::List fetchedItems = qobject_cast<ItemFetchJob *>(job)->items();
        Item::List detachItems;
        TasksList detachTasks;
        for (const Item &fetchedItem : fetchedItems) {
            auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
            TaskPtr task(new Task(*todo));
            const QString parentId = task->relatedTo(KCalendarCore::Incidence::RelTypeParent);
            if (parentId.isEmpty()) {
                continue;
            }

            auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item){
                return item.remoteId() == parentId;
            });
            if (it != items.cend()) {
                Item newItem(fetchedItem);
                qCDebug(GOOGLE_TASKS_LOG) << "Detaching child" << newItem.remoteId() << "from" << parentId;
                todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
                newItem.setPayload<KCalendarCore::Todo::Ptr>(todo);
                detachItems << newItem;
                detachTasks << task;
            }
        }
        /* If there are no items do detach, then delete the task right now */
        if (detachItems.isEmpty()) {
            doRemoveTasks(items);
            return;
        }

        qCDebug(GOOGLE_TASKS_LOG) << "Reparenting" << detachItems.count() << "children...";
        auto moveJob = new TaskMoveJob(detachTasks, items.first().parentCollection().remoteId(),
                                       QString(), m_settings->accountPtr(), this);
        connect(moveJob, &TaskMoveJob::finished, this, [this, items, detachItems](KGAPI2::Job *job){
            if (job->error()) {
                m_iface->cancelTask(i18n("Failed to reparent subtasks: %1", job->errorString()));
                return;
            }
            // Update items inside Akonadi DB too
            new ItemModifyJob(detachItems);
            // Perform actual removal
            doRemoveTasks(items);
        });
    }
```

#### AUTO 


```{c}
auto transferJob = qobject_cast<KIO::StoredTransferJob *>(job);
```

#### AUTO 


```{c}
auto *modifyJob = qobject_cast<OXA::FolderModifyJob *>(job);
```

#### AUTO 


```{c}
const auto contactTelephones{contact.telephones()};
```

#### AUTO 


```{c}
const auto addressesEmails{addressee.emails()};
```

#### AUTO 


```{c}
auto *attr = item.attribute<Akonadi::Pop3ResourceAttribute>(Akonadi::Item::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : eventsList) {
        events.push_back(Conversion::fromKCalendarCore(*event));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dlg]() {
                dlg->deleteLater();
                d->token = dlg->token();
                d->cookies = dlg->cookies();
                if (d->token.isEmpty()) {
                    emitError(i18n("Failed to obtain access token from Facebook"));
                    return;
                }

                fetchUserInfo();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        dispatch();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](unsigned int progress) {
                Q_EMIT reportPercent(progress);
            }
```

#### AUTO 


```{c}
auto *deleteJob = qobject_cast<FileStore::CollectionDeleteJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &parsedCookie : parsedCookies) {
            cookieStore->setCookie(parsedCookie, QUrl(QStringLiteral("https://www.facebook.com")));
            mCookies.insert(parsedCookie.name(), parsedCookie.toRawForm());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &incidence : incidences) {
        Item item(incidence->mimeType());
        item.setRemoteId(incidence->instanceIdentifier());
        item.setPayload(Incidence::Ptr(incidence->clone()));
        items << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : std::as_const(keys)) {
        QString val = map[key].toString();
        val.replace(QLatin1Char('"'), QStringLiteral("\\\""));
        elems.append(QStringLiteral("\"%1\":\"%2\"").arg(key, val));
    }
```

#### AUTO 


```{c}
auto it = limits.cbegin(), end = limits.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : qAsConst(paths)) {
        if (!QFileInfo::exists(p)) {
            if (!createMissingFolders) {
                lastError = i18n("Error opening %1; this folder is missing.", p);
                return false;
            }
            QDir().mkpath(p);
            if (!QFileInfo::exists(p)) {
                lastError = i18n("Error opening %1; this folder is missing.", p);
                return false;
            }
        }
        if (!canAccess(p)) {
            lastError = i18n(
                "Error opening %1; either this is not a valid "
                "maildir folder, or you do not have sufficient access permissions.",
                p);
            return false;
        }
    }
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(mMaildirCollection);
```

#### AUTO 


```{c}
const auto alarms{e.alarms()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : allInstances) {
        if (isLegacyGoogleResource(instance)) {
            const auto account = getAccountNameFromResourceSettings(instance);
            if (account.isEmpty()) {
                qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: resource" << instance.identifier() << "is not configured, removing";
                Akonadi::AgentManager::self()->removeInstance(instance);
                continue;
            }
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: discovered resource" << instance.identifier() << "for account" << account;
            if (instance.type().identifier() == akonadiGoogleCalendarResource) {
                mMigrations[account].calendarResource = instance;
            } else if (instance.type().identifier() == akonadiGoogleContactsResource) {
                mMigrations[account].contactResource = instance;
            }
        } else if (isGoogleGroupwareResource(instance)) {
            const auto account = getAccountNameFromResourceSettings(instance);
            mMigrations[account].alreadyExists = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            const int numberOfItemsRemoved = idList.removeAll(item.id());
            if (numberOfItemsRemoved > 0) {
                itemFound = true;
            }
        }
```

#### AUTO 


```{c}
auto *subscribe = new KIMAP::SubscribeJob(rename->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &eventXml : events) {
        resp += eventXml;
    }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavItemDeleteJob(davItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. " << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (davCollection.color().isValid()) {
            CollectionColorAttribute *colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
            colorAttr->setColor(davCollection.color());
        }

        if (!davCollection.displayName().isEmpty()) {
            EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        DavProtocolAttribute *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after sucessfull sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### AUTO 


```{c}
auto mail = new KMime::Message();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &rootCollection](const ObjectPtr &object){
            const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();
            qCDebug(GOOGLE_CONTACTS_LOG) << " -" << group->title() << "(" << group->id() << ")";
            Collection collection;
            setupCollection(collection, group);
            collection.setParentCollection(rootCollection);
            m_collections[ collection.remoteId() ] = collection;
            return collection;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsEventType type : qAsConst(mEventTypes)) {
        writer.writeTextElement(ewsTypeNsUri, QStringLiteral("EventType"), eventTypeNames[type]);
    }
```

#### AUTO 


```{c}
auto fid = resp.folder()[EwsFolderFieldFolderId].value<EwsId>();
```

#### AUTO 


```{c}
auto *attribute
        = item.attribute<FileStore::EntityCompactChangeAttribute>();
```

#### AUTO 


```{c}
const auto &val
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(newCol, transaction());
```

#### LAMBDA EXPRESSION 


```{c}
[this](Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->calendarsBox->setEnabled(false);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeCalendars;
        if (m_account->accountName() == m_settings->account()) {
            activeCalendars = m_settings->calendars();
        }
        m_ui->calendarsList->clear();
        for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            QListWidgetItem *item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }

        m_ui->calendarsBox->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto modifyJob = qobject_cast<OXA::ObjectModifyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &requestedEntry : qAsConst(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
```

#### AUTO 


```{c}
const auto &handler
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventFile &data : std::as_const(mEvents)) {
            createItem(data.event);
        }
```

#### AUTO 


```{c}
auto *job = new EwsUpdateItemsTagsJob(items, mTagStore, mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsPropertyField &prop : std::as_const(mProps)) {
            prop.write(writer);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Address &a : contactAddresses) {
            bool pref = false;
            if (index == contact.addressPreferredIndex()) {
                pref = true;
            }
            KContacts::Address adr(toAddressType(a.types(), pref));
            adr.setLabel(fromStdString(a.label()));
            adr.setStreet(fromStdString(a.street()));
            adr.setLocality(fromStdString(a.locality()));
            adr.setRegion(fromStdString(a.region()));
            adr.setPostalCode(fromStdString(a.code()));
            adr.setCountry(fromStdString(a.country()));

            index++;
            addressee.insertAddress(adr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &messageId : qAsConst(m_messageIds)) {
            subterms << KIMAP::Term(QStringLiteral("Message-ID"), QString::fromLatin1(messageId));
        }
```

#### AUTO 


```{c}
const auto recExDateTimes{rec->exDateTimes()};
```

#### AUTO 


```{c}
const auto tasksResult = createDefaultJournal(QStringLiteral(ETESYNC_COLLECTION_TYPE_TASKS), i18n("My Tasks"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : qAsConst(mListEmails)) {
            if (mFrom.contains(email)) {
                //Exclude this notification
                deleteLater();
                return;
            }
        }
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionsMultiFetchJob(davUrls, this);
```

#### AUTO 


```{c}
auto replace = new ReplaceMessageJob(mMessage, mSession, mMailbox, uidNext, mOldUids, this);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<ContactFetchJob *>(job);
```

#### AUTO 


```{c}
auto moveJob = qobject_cast<OXA::FolderMoveJob *>(job);
```

#### AUTO 


```{c}
const auto reauthStatus = performAuthAction(oAuth, 2000, [](EwsOAuth *oAuth) {
            return oAuth->authenticate(false);
        });
```

#### AUTO 


```{c}
auto *meta = qobject_cast<KIMAP::GetMetaDataJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Row> &row : qAsConst(mMigrators)) {
        if (row->mMigrator->identifier() == identifier) {
            return row->mMigrator;
        }
    }
```

#### AUTO 


```{c}
auto attr = c.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Select which folders to monitor for new message notifications:"));
```

#### AUTO 


```{c}
auto *status = qobject_cast<KIMAP::StatusJob *>(job);
```

#### AUTO 


```{c}
auto *attribute = c.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto &folderId
```

#### AUTO 


```{c}
auto *job = new EwsFetchFoldersJob(mEwsClient, mRootCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Url &u : urls) {
            if (u.type() == Kolab::Url::Blog) {
                addressee.insertCustom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("BlogFeed"), fromStdString(u.url()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : ranges) {
            fb->addPeriod(range.busyStart, range.busyEnd);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attachment &a : attachments) {
        mAttachments.push_back(a);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Attendee *delegator : qAsConst(delegatorsRef)) {
            // Set the delegator on each delegatee
            const ContactReference &delegatorRef = delegator->contact();
            if (!contains(delegatorRef, delegatedFrom)) {
                delegatedFrom.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegatorRef.email(), delegatorRef.name()));
            }

            // Set the delegatee on each delegator
            std::vector<Kolab::ContactReference> delegatedTo = delegator->delegatedTo();
            const ContactReference &delegaeeRef = delegatee->contact();
            if (!contains(delegaeeRef, delegatedTo)) {
                delegatedTo.push_back(Kolab::ContactReference(Kolab::ContactReference::EmailReference, delegaeeRef.email(), delegaeeRef.name()));
            }
            delegator->setDelegatedTo(delegatedTo);
        }
```

#### AUTO 


```{c}
auto job = new LogoutJob(mResource);
```

#### AUTO 


```{c}
const auto contents = msg->contents();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : std::as_const(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            limitsMap[key] = value.toLongLong();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavUrl &url : urls) {
        if (url.protocol() == KDAV::CalDav) {
            ++mRequestsTracker[email].handlingJobCount;
            KDAV::DavPrincipalSearchJob *job = new KDAV::DavPrincipalSearchJob(url, KDAV::DavPrincipalSearchJob::EmailAddress, email);
            job->setProperty("email", QVariant::fromValue(email));
            job->setProperty("url", QVariant::fromValue(url.url().toString()));
            job->fetchProperty(QStringLiteral("schedule-inbox-URL"), QStringLiteral("urn:ietf:params:xml:ns:caldav"));
            connect(job, &KDAV::DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onPrincipalSearchJobFinished);
            job->start();
        }
    }
```

#### AUTO 


```{c}
auto imapCreateJob = new KIMAP::CreateJob(mImapSession);
```

#### AUTO 


```{c}
auto settings = NewMailNotifierAgentSettings::self();
```

#### AUTO 


```{c}
auto job = new EntriesFetchJob(mClient.get(), journalUid, prevUid, this);
```

#### AUTO 


```{c}
auto *req = new EwsGetFolderRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item item : items) {
        if (!item.hasPayload<KCalendarCore::Todo::Ptr>()) {
            qCDebug(GOOGLE_CALENDAR_LOG) << "Item " << item.remoteId() << " does not have Todo payload";
            continue;
        }

        KCalendarCore::Todo::Ptr todo = item.payload<KCalendarCore::Todo::Ptr>();
        /* If this item is child of the item we want to remove then add it to detach list */
        if (todo->relatedTo(KCalendarCore::Incidence::RelTypeParent) == removedItem.remoteId()) {
            todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
            item.setPayload(todo);
            detachItems << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : std::as_const(mRemoteDeletedIds)) {
            QHash<QString, Item>::iterator it = itemHash.find(id.id());
            if (it == itemHash.end()) {
                /* If an item is not found locally, it can mean two things:
                 *  1. The item got deleted earlier without the resource being told about it.
                 *  2. The item was never known by Akonadi due to a sync problem.
                 * Either way the item doesn't exist any more and there is no point crying about it. */
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Got delete for item %1, but item not found in local store.").arg(ewsHash(id.id()));
            } else {
                mDeletedItems.append(*it);
            }
        }
```

#### AUTO 


```{c}
auto quota = new KIMAP::GetQuotaRootJob(session);
```

#### AUTO 


```{c}
auto imapQuotaAttribute = m_collection.attribute<Akonadi::ImapQuotaAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {return parseSubscribeResponse(reader);}
```

#### AUTO 


```{c}
auto *fetchJob = new ItemFetchJob(mCollection, this);
```

#### AUTO 


```{c}
auto urlStandardItem = new QStandardItem(url);
```

#### AUTO 


```{c}
auto *item = new QStandardItem(pathPart);
```

#### AUTO 


```{c}
auto *item = new QListWidgetItem(msg, mList);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(dlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsDeleteItemRequest::Response &resp : reqResponses) {
        Item &item = *it;
        if (resp.isSuccess()) {
            qCDebugNC(EWSRES_AGENTIF_LOG) << QStringLiteral("itemsRemoved: succeeded for item %1").arg(ewsHash(item.remoteId()));
        } else {
            Q_EMIT warning(QStringLiteral("Delete failed for item %1").arg(item.remoteId()));
            qCWarningNC(EWSRES_AGENTIF_LOG) << QStringLiteral("itemsRemoved: failed for item %1").arg(ewsHash(item.remoteId()));
            EwsId colId = EwsId(item.parentCollection().remoteId(), QString());
            mItemsToCheck[colId.id()].append(EwsId(item.remoteId(), QString()));
            if (!foldersToSync.contains(colId)) {
                foldersToSync.append(colId);
            }
        }
        ++it;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qDebug() << "timeout";
        loop.exit(1);
        status = 1;
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Cancel | QDialogButtonBox::No | QDialogButtonBox::Yes, dialog);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<QString, QString> &m) {
            map = m;
            loop.exit(0);
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rid : keys) {
        if (!seenCollectionsUrls.contains(rid)) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Collection disappeared. " << rid;
            mEtagCaches[rid]->deleteLater();
            mEtagCaches.remove(rid);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &usages : qAsConst(allUsages)) {
        QMap<QByteArray, qint64> usagesMap;
        const QStringList strLines = usages.split(QStringLiteral("%%"));
        QList<QByteArray> lines;
        lines.reserve(strLines.count());
        for (const QString &strLine : qAsConst(strLines)) {
            lines << strLine.trimmed().toUtf8();
        }

        for (const QByteArray &line : qAsConst(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            usagesMap[key] = value.toLongLong();
        }

        mUsages << usagesMap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Email &email : contactEmailAddresses) {
            emails << fromStdString(email.address());
            const QString types = emailTypesToStringList(email.types());
            if (!types.isEmpty()) {
                addressee.insertCustom(QStringLiteral("KOLAB"), QStringLiteral("EmailTypes%1").arg(fromStdString(email.address())), types);
            }
        }
```

#### AUTO 


```{c}
auto treeContainerLayout = new QHBoxLayout(treeContainer);
```

#### AUTO 


```{c}
const auto configPath = QStandardPaths::locate(QStandardPaths::ConfigLocation, configFile);
```

#### AUTO 


```{c}
const auto candidates = QTimeZone::availableTimeZoneIds(standardUtcOffset);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &kcalEvent : qAsConst(events)) {
        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << "doRetrieveItems: KCalCore::Event has no alarms:" << kcalEvent->uid();
            continue;    // ignore events without alarms
        }

        const KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << "doRetrieveItems: KAEvent has no alarms:" << event.id();
            continue;   // event has no usable alarms
        }

        Item item(mime);
        item.setRemoteId(kcalEvent->uid());
        item.setPayload(event);
        items << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {
        return parseUnsubscribeResponse(reader);
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::RecursiveItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : qAsConst(mIds)) {
        id.writeItemIds(writer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetFolderRequest::Response &resp : responses) {
            if (resp.isSuccess()) {
                // Take just the id without the change key as the actual folder version is irrelevant
                // here
                const QString id = resp.folder()[EwsFolderFieldFolderId].value<EwsId>().id();
                mFolders << EwsId(id);
                idList << id;
            } else {
                qCWarningNC(EWSRES_LOG) << QStringLiteral("Invalid folder %1 - skipping").arg(it->id());
            }
            it++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : taskLists) {
        const TaskListPtr &taskList = object.dynamicCast<TaskList>();

        if (!activeTaskLists.contains(taskList->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalCore::Todo::todoMimeType());
        collection.setName(taskList->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(taskList->uid());
        collection.setRights(Collection::CanChangeCollection
                             |Collection::CanCreateItem
                             |Collection::CanChangeItem
                             |Collection::CanDeleteItem);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(taskList->title());
        attr->setIconName(QStringLiteral("view-pim-tasks"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### AUTO 


```{c}
auto fetchJob = new KDAV::DavItemsFetchJob(davUrl, changedRids);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : updJob->items()) {
        if (mSubManager) {
            mSubManager->queueUpdate(EwsModifiedEvent, item.remoteId(), item.remoteRevision());
        }
        mQueuedUpdates[item.parentCollection().remoteId()].append({item.remoteId(), item.remoteRevision(), EwsModifiedEvent});
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : std::as_const(mIds)) {
        id.writeItemIds(writer);
    }
```

#### AUTO 


```{c}
auto *wallet = qobject_cast<Wallet *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : qAsConst(paths)) {
        if (!QFileInfo::exists(p)) {
            if (!createMissingFolders) {
                lastError = i18n("Error opening %1; this folder is missing.", p);
                return false;
            }
            QDir().mkpath(p);
            if (!QFileInfo::exists(p)) {
                lastError = i18n("Error opening %1; this folder is missing.", p);
                return false;
            }
        }
        if (!canAccess(p)) {
            lastError = i18n("Error opening %1; either this is not a valid "
                             "maildir folder, or you do not have sufficient access permissions.", p);
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Alarm::Ptr &a : alarms) {
        mAlarms.push_back(a);
    }
```

#### AUTO 


```{c}
const auto exceptionDates{event.exceptionDates()};
```

#### AUTO 


```{c}
auto job = new CalendarFetchJob(m_settings->accountPtr(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &phase : phases) {
        if (!phase.isDst()) {
            standardUtcOffset = phase.utcOffset();
            matched = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : std::as_const(topLevelList)) {
            reparentRemoteFolder(id);
        }
```

#### AUTO 


```{c}
const auto tz = strView.right(5);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : taskLists) {
        const TaskListPtr &taskList = object.dynamicCast<TaskList>();

        if (!activeTaskLists.contains(taskList->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalCore::Todo::todoMimeType());
        collection.setName(taskList->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(taskList->uid());
        collection.setRights(Collection::CanChangeCollection |
                             Collection::CanCreateItem |
                             Collection::CanChangeItem |
                             Collection::CanDeleteItem);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(taskList->title());
        attr->setIconName(QStringLiteral("view-pim-tasks"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : events) {
            processEvent(event);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(items)) {
        const auto flags = item.flags();
        for (const QByteArray &flag : flags) {
            ++flagCounts[flag];
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &testDataName : testDataNames) {
        if (testDataName.startsWith(QLatin1String("mbox"))) {
            QVERIFY(TestDataUtil::folderType(testDataName) == TestDataUtil::MBoxFolder);
        } else {
            QVERIFY(TestDataUtil::folderType(testDataName) == TestDataUtil::MaildirFolder);
        }
    }
```

#### AUTO 


```{c}
auto fetch = static_cast<KIMAP::FetchJob *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &item) {
            return item.remoteId().isEmpty();
        }
```

#### AUTO 


```{c}
auto legacyMsgStatus = (KMLegacyMsgStatus)mCachedLongParts[KMIndexReader::MsgLegacyStatusPart];
```

#### AUTO 


```{c}
auto userIdJob = new UserIdRequestJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : qAsConst(m_taskList)) {
        task->kill();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        loop.exit(1);
    }
```

#### AUTO 


```{c}
auto itemJob = qobject_cast<FileStore::ItemModifyJob *>(job);
```

#### AUTO 


```{c}
const auto headerB64 = header.toUtf8().toBase64(QByteArray::Base64UrlEncoding | QByteArray::OmitTrailingEquals);
```

#### AUTO 


```{c}
auto *deletedJob = new FoldersRequestJob(mLastSync, FoldersRequestJob::Deleted, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        varmap[item.first] = item.second;
    }
```

#### AUTO 


```{c}
auto *w = new NewMailNotifierSelectCollectionWidget;
```

#### AUTO 


```{c}
const auto calendarResult = createDefaultJournal(QStringLiteral(ETESYNC_COLLECTION_TYPE_CALENDAR), i18n("My Calendar"));
```

#### AUTO 


```{c}
auto h = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto minorRef = attrs.value(QStringLiteral("MinorVersion"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        const EwsItem &ewsItem = resp.item();
        KMime::Message::Ptr msg(new KMime::Message);

        // Rebuild the message headers
        QVariant v = ewsItem[EwsItemFieldSubject];
        if (Q_LIKELY(v.isValid())) {
            msg->subject()->fromUnicodeString(v.toString(), "utf-8");
        }

        v = ewsItem[EwsItemFieldFrom];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox mbox = v.value<EwsMailbox>();
            msg->from()->addAddress(mbox);
        }

        v = ewsItem[EwsItemFieldToRecipients];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->to()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldCcRecipients];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->cc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldBccRecipients];
        if (v.isValid()) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->bcc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldInternetMessageId];
        if (v.isValid()) {
            msg->messageID()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldInReplyTo];
        if (v.isValid()) {
            msg->inReplyTo()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldDateTimeReceived];
        if (v.isValid()) {
            msg->date()->setDateTime(v.toDateTime());
        }

        v = ewsItem[EwsItemFieldReferences];
        if (v.isValid()) {
            msg->references()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldReplyTo];
        if (v.isValid()) {
            const EwsMailbox mbox = v.value<EwsMailbox>();
            msg->replyTo()->addAddress(mbox);
        }

        msg->assemble();
        item.setPayload(KMime::Message::Ptr(msg));

        v = ewsItem[EwsItemFieldSize];
        if (v.isValid()) {
            item.setSize(v.toUInt());
        }

        // Workaround for Akonadi bug
        // When setting flags, adding each of them separately vs. setting a list in one go makes
        // a difference. In the former case the item treats this as an incremental change and
        // records flags added and removed. In the latter it sets a flag indicating that flags were
        // reset.
        // For some strange reason Akonadi is not seeing the flags in the latter case.
        Q_FOREACH (const QByteArray &flag, EwsMailHandler::readFlags(ewsItem)) {
            item.setFlag(flag);
        }
        qCDebugNC(EWSRES_LOG) << "EwsFetchMailDetailJob::processItems:" << ewsHash(item.remoteId()) << item.flags();

        ++it;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : entries) {
        if (!entry) {
            qCDebug(ETESYNC_LOG) << "SetupItems: Entry is null";
            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            continue;
        }
        EteSyncSyncEntryPtr syncEntry = etesync_entry_get_sync_entry(entry.get(), cryptoManager.get(), prevUid);

        if (!syncEntry) {
            qCDebug(ETESYNC_LOG) << "SetupItems: syncEntry is null for entry" << etesync_entry_get_uid(entry.get());
            qCDebug(ETESYNC_LOG) << "EteSync error" << QStringFromCharPtr(CharPtr(etesync_get_error_message()));
            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            continue;
        }

        KContacts::VCardConverter converter;
        CharPtr contentStr(etesync_sync_entry_get_content(syncEntry.get()));
        QByteArray content(contentStr.get());
        const KContacts::Addressee contact = converter.parseVCard(content);

        if ((contact.uid()).isEmpty()) {
            qCDebug(ETESYNC_LOG) << "Couldn't parse entry with uid" << etesync_entry_get_uid(entry.get());
            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            continue;
        }

        qCDebug(ETESYNC_LOG) << "Entry parsed into contact - UID" << contact.uid();

        const QString action = QStringFromCharPtr(CharPtr(etesync_sync_entry_get_action(syncEntry.get())));
        if (action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_ADD) || action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_CHANGE)) {
            contacts[contact.uid()] = contact;
        } else if (action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_DELETE)) {
            if (contacts.contains(contact.uid())) {
                contacts.remove(contact.uid());
            } else {
                Item item;
                item.setMimeType(mimeType());
                item.setParentCollection(collection);
                item.setRemoteId(contact.uid());
                removedItems.push_back(item);

                deleteLocalContact(contact.uid());
            }
        }

        prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto col : fetchJob->collections()) {
            const auto remoteId = col.remoteId();
            const auto state = mStateHash.find(remoteId);
            if (state != mStateHash.end()) {
                stateChanged(col);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsServerVersion &ver : knownVersions) {
        if (*this == ver) {
            version.append(QStringLiteral(" (") + ver.mFriendlyName + QLatin1Char(')'));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : addedTags) {
        mChangedTags.append(tag);
    }
```

#### AUTO 


```{c}
auto it = contacts.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventFile &data : qAsConst(mEvents)) {
            const KAEvent &event = data.event;
            mCompatibility |= event.compatibility();
            if ((mCompatibility & AllCompat) == AllCompat) {
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collection](const Item &item){
                ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
                contact->removeGroup(collection.remoteId());
                return contact;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            ui->loginStatusLbl->setText(job->errorText());
        } else {
            checkToken();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            emitError(job->errorText());
            return;
        }

        auto cal = KCalCore::MemoryCalendar::Ptr::create(QTimeZone::systemTimeZone());
        KCalCore::ICalFormat format;
        if (!format.fromRawString(cal, job->data(), false)) {
            emitError(i18n("Failed to parse birthday calendar"));
            return;
        }

        const auto events = cal->events();
        for (const auto &event : events) {
            processEvent(event);
        }

        emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &outbox : principalScheduleOutboxFromEmail) {
        ++mRequestsTracker[email].retrievalJobCount;
        uint requestId = mNextRequestId++;

        QUrl url(outbox);
        KIO::StoredTransferJob *job = KIO::storedHttpPost(fbData, url);
        job->addMetaData(QStringLiteral("content-type"), QStringLiteral("text/calendar"));
        job->setProperty("email", QVariant::fromValue(email));
        job->setProperty("request-id", QVariant::fromValue(requestId));
        connect(job, &KDAV::DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onRetrieveFreeBusyJobFinished);
        job->start();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qDebug() << "succeeded";
        loop.exit(0);
        status = 0;
    }
```

#### AUTO 


```{c}
auto res = qobject_cast<EwsResource *>(parent());
```

#### AUTO 


```{c}
auto *itemJob = qobject_cast<FileStore::ItemCreateJob *>(job);
```

#### AUTO 


```{c}
auto cal = KCalendarCore::MemoryCalendar::Ptr::create(QTimeZone::systemTimeZone());
```

#### AUTO 


```{c}
auto *storeJob = new KIMAP::StoreJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }

                TaskListPtr taskList = qobject_cast<TaskListCreateJob *>(job)->items().first().dynamicCast<TaskList>();
                qCDebug(GOOGLE_TASKS_LOG) << "Task list created:" << taskList->uid();
                // Enable newly added task list in settings
                m_settings->addTaskList(taskList->uid());
                // Populate remoteId & other stuff
                Collection newCollection(collection);
                setupCollection(newCollection, taskList);
                m_iface->collectionChangeCommitted(newCollection);
                emitReadyStatus();
            }
```

#### AUTO 


```{c}
auto d = reinterpret_cast<EwsItemPrivate *>(this->d.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::CustomProperty &a : customProperties) {
        note.custom().insert(fromStdString(a.identifier), fromStdString(a.value));
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::ContactGroupExpandJob(object.contactGroup());
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                qCDebug(GOOGLE_CALENDAR_LOG) << "Calendars retrieved";

                const ObjectsList calendars = qobject_cast<CalendarFetchJob *>(job)->items();
                Collection::List collections;
                collections.reserve(calendars.count());
                const QStringList activeCalendars = m_settings->calendars();
                for (const auto &object : calendars) {
                    const CalendarPtr &calendar = object.dynamicCast<Calendar>();
                    qCDebug(GOOGLE_CALENDAR_LOG) << " -" << calendar->title() << "(" << calendar->uid() << ")";
                    if (!activeCalendars.contains(calendar->uid())) {
                        qCDebug(GOOGLE_CALENDAR_LOG) << "Skipping, not subscribed";
                        continue;
                    }
                    Collection collection;
                    setupCollection(collection, calendar);
                    collection.setParentCollection(rootCollection);
                    collections << collection;
                }

                m_iface->collectionsRetrievedFromHandler(collections);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &dependentItem : qAsConst(dependentItems)) {
            calendar->addIncidence(dependentItem.payload<IncidencePtr>());
        }
```

#### AUTO 


```{c}
auto fetch = qobject_cast<KIMAP::FetchJob *>(sender());
```

#### AUTO 


```{c}
auto *createJob = static_cast<Akonadi::TagCreateJob *>(job);
```

#### AUTO 


```{c}
auto handler = fetchHandlerByMimetype(item.mimeType());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &fetchedItem : fetchedItems) {
            auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
            TaskPtr task(new Task(*todo));
            const QString parentId = task->relatedTo(KCalendarCore::Incidence::RelTypeParent);
            if (parentId.isEmpty()) {
                continue;
            }

            auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item) {
                return item.remoteId() == parentId;
            });
            if (it != items.cend()) {
                Item newItem(fetchedItem);
                qCDebug(GOOGLE_TASKS_LOG) << "Detaching child" << newItem.remoteId() << "from" << parentId;
                todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
                newItem.setPayload<KCalendarCore::Todo::Ptr>(todo);
                detachItems << newItem;
                detachTasks << task;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &) {
                                           return false;
                                       }
```

#### AUTO 


```{c}
auto setMetadataJob = new KIMAP::SetMetaDataJob(mImapSession);
```

#### AUTO 


```{c}
auto *flagsAttribute = new Akonadi::CollectionFlagsAttribute(m_flags);
```

#### AUTO 


```{c}
auto group = config()->group(myConfigGroupName);
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyServerAuthenticateJob *>(kjob);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : folders) {
        Collection c;
        c.setRemoteId(id.id());
        CollectionFetchJob *job = new CollectionFetchJob(c, CollectionFetchJob::Base);
        job->setFetchScope(changeRecorder()->collectionFetchScope());
        job->fetchScope().setResource(identifier());
        job->fetchScope().setListFilter(CollectionFetchScope::Sync);
        connect(job, &KJob::result, this, &EwsResource::foldersModifiedCollectionSyncFinished);
    }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::FirstLevel);
```

#### AUTO 


```{c}
auto *colJob = qobject_cast<FileStore::CollectionModifyJob *>(job);
```

#### AUTO 


```{c}
auto *contacts = static_cast<KContacts::Addressee::List *>(preloadedData);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : items) {
        const Akonadi::Item::Id contactId = item.remoteId().mid(1).toLongLong();
        contactIds << contactId;
    }
```

#### AUTO 


```{c}
auto *attr = mboxCollection.attribute<DeletedItemsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { postJobResult(job); }
```

#### AUTO 


```{c}
const auto abvs = transition.phase().abbreviations();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &kcalEvent : qAsConst(events)) {
        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << "KCalCore::Event has no alarms:" << kcalEvent->uid();
            continue;    // ignore events without alarms
        }

        const KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << "KAEvent has no alarms:" << event.id();
            continue;   // event has no usable alarms
        }

        Item item(mime);
        item.setRemoteId(kcalEvent->uid());
        item.setPayload(event);
        items << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &usages : std::as_const(allUsages)) {
        QMap<QByteArray, qint64> usagesMap;
        const QStringList strLines = usages.split(QStringLiteral("%%"));
        QList<QByteArray> lines;
        lines.reserve(strLines.count());
        for (const QString &strLine : std::as_const(strLines)) {
            lines << strLine.trimmed().toUtf8();
        }

        for (const QByteArray &line : std::as_const(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            usagesMap[key] = value.toLongLong();
        }

        mUsages << usagesMap;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsSyncFolderHierarchyRequest::Change &ch : reqChanges) {
        if (ch.type() == EwsSyncFolderHierarchyRequest::Create) {
            mRemoteChangedFolders.append(ch.folder());
        } else {
            q->setErrorMsg(QStringLiteral("Got non-create change for full sync."));
            q->emitResult();
            return;
        }
    }
```

#### AUTO 


```{c}
const auto nfyEvents{nfy.events()};
```

#### AUTO 


```{c}
auto job = new FoldersRequestJob(0, FoldersRequestJob::Modified, this);
```

#### AUTO 


```{c}
const auto flags{remoteItem.flags()};
```

#### AUTO 


```{c}
auto *const aclAttribute
        = m_collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : events) {
        qDebug() << "Got event:" << event;
    }
```

#### AUTO 


```{c}
auto *logout = new KIMAP::LogoutJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts) {
            job->fetchScope().fetchPayloadPart(part, true);
        }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsDeleteFolderRequest *>(job);
```

#### AUTO 


```{c}
auto job = new FileStore::StoreCompactJob(d->mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int p) {
                Q_EMIT reportPercent(p);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
            const TaskListPtr taskList = object.dynamicCast<TaskList>();

            QListWidgetItem *item = new QListWidgetItem(taskList->title());
            item->setData(Qt::UserRole, taskList->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->taskListsList->addItem(item);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &left, const Akonadi::Item &right) {
        return left.parentCollection().remoteId().compare(right.parentCollection().remoteId()) < 0
        || (left.parentCollection().remoteId() == right.parentCollection().remoteId() && changedOffset(left) < changedOffset(right));
    }
```

#### AUTO 


```{c}
auto vLayout = new QVBoxLayout(this);
```

#### CONST EXPRESSION 


```{c}
constexpr int walletTimeout = 30000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : lst) {
        mScheduler.abort(index.data(MigratorModel::IdentifierRole).toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : qAsConst(results)) {
        qCDebug(DAVRESOURCE_LOG) << result.value;
        QUrl url(davJob->property("url").toString());
        if (result.value.startsWith(QLatin1Char('/'))) {
            // href is only a path, use request url to complete
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            // href is a complete url
            url = QUrl::fromUserInput(result.value);
        }

        if (!mPrincipalScheduleOutbox[email].contains(url.url())) {
            mPrincipalScheduleOutbox[email] << url.url();
        }
    }
```

#### AUTO 


```{c}
auto *acl = new KIMAP::GetAclJob(m_session);
```

#### AUTO 


```{c}
auto task = new RetrieveItemTask(state);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {
        return parseNotificationsResponse(reader);
    }
```

#### AUTO 


```{c}
auto *fetchJob = new CollectionFetchJob(mRootCollection,
                                                              CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *fetch = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto changeHelper = new TagChangeHelper(this);
```

#### AUTO 


```{c}
auto select = static_cast<KIMAP::SelectJob *>(job);
```

#### AUTO 


```{c}
auto *moveJob = qobject_cast<OXA::ObjectMoveJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }

        ContactsGroupPtr group = qobject_cast<ContactsGroupCreateJob *>(job)->items().first().dynamicCast<ContactsGroup>();
        qCDebug(GOOGLE_CONTACTS_LOG) << "Contact group created:" << group->id();
        Collection newCollection(collection);
        setupCollection(newCollection, group);
        m_collections[newCollection.remoteId()] = newCollection;
        m_iface->collectionChangeCommitted(newCollection);
        emitReadyStatus();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { slotSentMailCollectionFetched(job);}
```

#### AUTO 


```{c}
auto &entry
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &) {
            return false;
        }
```

#### AUTO 


```{c}
auto replaceJob = static_cast<ReplaceMessageJob *>(job);
```

#### AUTO 


```{c}
auto req = new EwsSubscribeRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto job = new TomboyItemUploadJob(item, JobType::AddItem, mManager, this);
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(targetCollection, CollectionFetchJob::Base);
```

#### AUTO 


```{c}
const auto contactsResult = createDefaultJournal(QStringLiteral(ETESYNC_COLLECTION_TYPE_ADDRESS_BOOK), i18n("My Contacts"));
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(dlg);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsGetItemRequest *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        TaskListPtr taskList = object.dynamicCast<TaskList>();

        QListWidgetItem *item = new QListWidgetItem(taskList->title());
        item->setData(Qt::UserRole, taskList->uid());
        item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
        item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
        m_taskListsList->addItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folder : list) {
        if (specialFolders.contains(folder.type)) {
            folderHash.insert(folder.type, &folder);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KJob *job) {
        if (job->error()) {
            qCWarningNC(EWSRES_LOG) << "Special folders fetch failed:" << job->errorString();
        }
    }
```

#### AUTO 


```{c}
auto attribute = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Related &related : affRelateds) {
            if (related.type() != Kolab::Related::Text) {
                qCCritical(PIMKOLAB_LOG) << "invalid relation type";
                continue;
            }
            if (related.relationTypes() & Kolab::Related::Assistant) {
                addressee.insertCustom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("X-AssistantsName"), fromStdString(related.text()));
            }
            if (related.relationTypes() & Kolab::Related::Manager) {
                addressee.insertCustom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("X-ManagersName"), fromStdString(related.text()));
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        fetchNewResult(job);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(mHandlers.cbegin(), mHandlers.cend(),
                           [&collection](const BaseHandler::Ptr &handler) {
                               return collection.contentMimeTypes().contains(handler->mimeType());
                           });
```

#### AUTO 


```{c}
auto collectionColor = etesync_collection_info_get_color(info.get());
```

#### AUTO 


```{c}
auto job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            const Collection coll = item.parentCollection();
            Q_ASSERT(!coll.remoteId().isEmpty());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            qDebug() << "timeout";
            loop.exit(1);
            status = 1;
        }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close, dlg);
```

#### AUTO 


```{c}
const auto contactEmailAddresses{contact.emailAddresses()};
```

#### AUTO 


```{c}
auto *store = static_cast<KIMAP::StoreJob *>(job);
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray part : qAsConst(member.mailbox)) {
            Akonadi::Collection col;
            col.setRemoteId(separatorCharacter() + QString::fromLatin1(part));
            col.setParentCollection(parent);
            parent = col;
        }
```

#### AUTO 


```{c}
auto req = new EwsMoveItemRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : std::as_const(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            usagesMap[key] = value.toLongLong();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &recurrence : days) {
        writeString(e, QStringLiteral("day"), recurrence);
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto getItemReq = new EwsGetItemRequest(mClient, this);
```

#### AUTO 


```{c}
auto it = std::find_if(mHandlers.cbegin(), mHandlers.cend(),
                           [&mimeType](const BaseHandler::Ptr &handler) {
                               return handler->mimeType() == mimeType;
                           });
```

#### AUTO 


```{c}
auto *dlg = new SetupServer(this, windowId);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(d->mCollection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            qCDebug(ETESYNC_LOG) << "Login finished";
            static_cast<LoginPage *>(page(W_LoginPage))->setLoginResult(static_cast<LoginJob *>(job)->getLoginResult());
            static_cast<LoginPage *>(page(W_LoginPage))->setErrorCode(job->error());
            static_cast<LoginPage *>(page(W_LoginPage))->setErrorMessage(job->errorText());
            static_cast<LoginPage *>(page(W_LoginPage))->hideProgressBar();
            nextId() == -1 ? QWizard::accept() : QWizard::next();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attachment &a : attachments) {
        mAttachments.push_back(a);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(mHandlers.cbegin(), mHandlers.cend(),
                           [&collection](const BaseHandler::Ptr &handler) {
        return collection.contentMimeTypes().contains(handler->mimeType());
    });
```

#### AUTO 


```{c}
auto job = new OXA::ObjectMoveJob(object, destinationFolder, this);
```

#### AUTO 


```{c}
auto job = new CollectionModifyJob(c);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QAbstractOAuth::Stage stage, QVariantMap *parameters) {
        modifyParametersFunction(stage, parameters);
    }
```

#### AUTO 


```{c}
const auto contactItem = fj->items().at(0);
```

#### AUTO 


```{c}
auto fetch = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
const auto items = q.queryItems(QUrl::FullyDecoded);
```

#### AUTO 


```{c}
auto hv3 = new KMime::Headers::Generic(X_KOLAB_MIME_VERSION_HEADER);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item item : qAsConst(origItems)) { // krazy:exclude=foreach non-const is intended here
        const KDAV::DavItem davItem = davJob->item(item.remoteId());

        // No data was retrieved for this item, maybe because it is not out of date
        if (davItem.data().isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Empty item returned. " << item.remoteId();
            if (!cache->isOutOfDate(item.remoteId())) {
                qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Item is not changed, including it. " << item.remoteId();
                items << item;
            }
            continue;
        }

        Akonadi::Item::List extraItems;
        if (!Utils::parseDavData(davItem, item, extraItems)) {
            qCWarning(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Failed to parse item data. " << item.remoteId();
            continue;
        }

        // update etag
        item.setRemoteRevision(davItem.etag());
        cache->setEtag(item.remoteId(), davItem.etag());
        items << item;
        for (const Akonadi::Item &extraItem : qAsConst(extraItems)) {
            cache->setEtag(extraItem.remoteId(), davItem.etag());
            items << extraItem;
        }
    }
```

#### AUTO 


```{c}
auto *readJob = qobject_cast<EwsGlobalTagsReadJob *>(job);
```

#### AUTO 


```{c}
auto *displayNameStandardItem = new QStandardItem(displayName);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<EwsFetchItemsJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &a : delegators) {
        if (Attendee *attendee = getAttendee(a.contact())) {
            delegatorsRef.push_back(attendee);
        } else {
            std::cout << "missing delegator";
        }
    }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavItemCreateJob(davItem);
```

#### LAMBDA EXPRESSION 


```{c}
[&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return true;
                                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
            const TaskListPtr taskList = object.dynamicCast<TaskList>();

            auto item = new QListWidgetItem(taskList->title());
            item->setData(Qt::UserRole, taskList->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->taskListsList->addItem(item);
        }
```

#### AUTO 


```{c}
const auto object = document.object();
```

#### AUTO 


```{c}
auto *currentNextUid = col.attribute<UidNextAttribute>()
```

#### AUTO 


```{c}
auto *job = new OXA::FolderMoveJob(folder, destinationFolder, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QString rid = item.remoteId();
        const KCalendarCore::Event::Ptr kcalEvent = calendar()->event(rid);
        if (!kcalEvent) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItem: Event not found:" << rid;
            Q_EMIT error(errorMessage(KAlarmResourceCommon::UidNotFound, rid));
            return false;
        }

        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItem: KCalendarCore::Event has no alarms:" << rid;
            Q_EMIT error(errorMessage(KAlarmResourceCommon::EventNoAlarms, rid));
            return false;
        }

        KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItem: KAEvent has no alarms:" << rid;
            Q_EMIT error(errorMessage(KAlarmResourceCommon::EventNoAlarms, rid));
            return false;
        }
        event.setCompatibility(mCompatibility);
        const Item newItem = KAlarmResourceCommon::retrieveItem(item, event);
        resultItems.append(newItem);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        storeListResult(job);
    }
```

#### AUTO 


```{c}
auto attr = c.attribute<Akonadi::CollectionIdentificationAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto errors{Kolab::ErrorHandler::instance().getErrors()};
```

#### AUTO 


```{c}
auto *subContainerLayout = new QVBoxLayout(d->mSubContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urlScopes) {
        scopes << url.toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->abort(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : collections) {
        mCollectionsMap.insert(collection.remoteId().toULongLong(), collection);
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::CopyJob(session);
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<UserIdRequestJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uidOnServer : qAsConst(mIdsToUidsMap)) {
            if (alreadyDownloadedUIDs.contains(uidOnServer)) {
                const int idOfUIDOnServer = mUidsToIdsMap.value(uidOnServer, -1);
                Q_ASSERT(idOfUIDOnServer != -1);
                idsToDownload.removeAll(idOfUIDOnServer);
            }
        }
```

#### AUTO 


```{c}
auto acceptedFn = std::bind(&EwsResource::reauthNotificationDismissed, this, true);
```

#### AUTO 


```{c}
auto *annotationsAttribute
        = m_collection.attribute<Akonadi::CollectionAnnotationsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Item &item){
        return item.remoteId();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const GenericHandler::Ptr &handler){
                return handler->mimeType() == mimeType;
            }
```

#### AUTO 


```{c}
auto buttonContainerLayout = new QVBoxLayout(buttonContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &oldFlag : flags) {
        if (oldFlag == Akonadi::MessageFlags::Seen) {
            newFlags.append(ImapFlags::Seen);
        } else if (oldFlag == Akonadi::MessageFlags::Deleted) {
            newFlags.append(ImapFlags::Deleted);
        } else if (oldFlag == Akonadi::MessageFlags::Answered || oldFlag == Akonadi::MessageFlags::Replied) {
            newFlags.append(ImapFlags::Answered);
        } else if (oldFlag == Akonadi::MessageFlags::Flagged) {
            newFlags.append(ImapFlags::Flagged);
        } else {
            newFlags.append(oldFlag);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &a : delegatees) {
        if (Attendee *attendee = getAttendee(a.contact())) {
            delegateesRef.push_back(attendee);
        } else {
            d->attendees.push_back(a);
            delegateesRef.push_back(&d->attendees.back());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pair : pairs) {
#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
                const QStringList entry = pair.split(QLatin1Char('='), QString::KeepEmptyParts);
#else
                const QStringList entry = pair.split(QLatin1Char('='), Qt::KeepEmptyParts);
#endif
                mObjectsMap.insert(entry.at(0).toLongLong(), entry.at(1).toULongLong());
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qDebug() << "Timeout waiting for desired resource online state.";
        loop.exit(1);
    }
```

#### AUTO 


```{c}
auto *resp = new EwsSyncFolderItemsRequest::Response(reader);
```

#### LAMBDA EXPRESSION 


```{c}
[&parentId](const Item &item){
                                return item.remoteId() == parentId;
                            }
```

#### AUTO 


```{c}
auto *attachDisposition = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto *itemReq = qobject_cast<EwsSyncFolderItemsRequest *>(job);
```

#### AUTO 


```{c}
const auto kwalletData = backupKWalletData(account);
```

#### AUTO 


```{c}
auto *bodyDisposition = new KMime::Headers::ContentDisposition();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SetupWizard::Url &url : urls) {
                auto urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = url.url;
                urlConfig->mProtocol = url.protocol;
                urlConfig->mUser = url.userName;
                urlConfig->mPassword = wizard.field(QStringLiteral("credentialsPassword")).toString();

                Settings::self()->newUrlConfiguration(urlConfig);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this, socket]() {
                const auto response = QStringLiteral(
                                          "HTTP/1.1 200 OK\n\n<!DOCTYPE html>\n<html><body><p>You will be redirected "
                                          "shortly.</p><script>window.location.href=\"%1\";</script></body></html>\n")
                                          .arg(mPKeyAuthSubmitUrl);
                socket->write(response.toLocal8Bit());
            }
```

#### AUTO 


```{c}
auto *req = new EwsSubscribeRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto *create = static_cast<KIMAP::CreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts)  {
        if (part.startsWith("PLD:RFC822")) {
            bodyChanged = true;
        } else if (part.startsWith("PLD:HEAD")) {
            headChanged = true;
        }
        if (part.contains("FLAGS")) {
            flagsChanged = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tag &tag : tags) {
                Q_ASSERT(mTagStore->containsId(tag.id()));
                tagList.append(QString::fromLatin1(mTagStore->tagRemoteId(tag.id())));
                QString name = mTagStore->tagName(tag.id());
                if (!name.isEmpty()) {
                    categoryList.append(name);
                }
            }
```

#### AUTO 


```{c}
auto *fetchJob = new FetchJob(mPopSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { collectionFetched(job);}
```

#### AUTO 


```{c}
auto finishedDeleteJob = qobject_cast<DeleteJob *>(job);
```

#### AUTO 


```{c}
auto attr = mboxCollection.attribute<DeletedItemsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *session = static_cast<KIMAP::Session *>(sender());
```

#### AUTO 


```{c}
auto storeList = qobject_cast<FileStore::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavUrl &url : urls) {
        if (url.protocol() == KDAV::CalDav) {
            ++mRequestsTracker[email].handlingJobCount;
            auto *job = new KDAV::DavPrincipalSearchJob(url, KDAV::DavPrincipalSearchJob::EmailAddress, email);
            job->setProperty("email", QVariant::fromValue(email));
            job->setProperty("url", QVariant::fromValue(url.url().toString()));
            job->fetchProperty(QStringLiteral("schedule-inbox-URL"), QStringLiteral("urn:ietf:params:xml:ns:caldav"));
            connect(job, &KDAV::DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onPrincipalSearchJobFinished);
            job->start();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : items) {
        const QString rid = item.remoteId();
        const quint64 offset = itemOffset(rid);
        KMime::Message *mail = mMBox->readMessage(KMBox::MBoxEntry(offset));
        if (!mail) {
            Q_EMIT error(i18n("Failed to read message with uid '%1'.", rid));
            return false;
        }

        Item i(item);
        i.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, i);
        rv.push_back(i);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *, const Akonadi::Item::List &items) {
            itemsRetrieved(items);
        }
```

#### AUTO 


```{c}
auto dlg = new AuthDialog(d->cookies, qobject_cast<FacebookResource *>(parent()));
```

#### AUTO 


```{c}
auto list = new KIMAP::ListJob(m_session);
```

#### AUTO 


```{c}
auto req = new EwsGetFolderRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto copy = static_cast<KIMAP::CopyJob *>(job);
```

#### AUTO 


```{c}
auto nsJob = new KIMAP::NamespaceJob(capJob->session());
```

#### AUTO 


```{c}
auto settings = new QWidget;
```

#### AUTO 


```{c}
const auto c
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(contactItems, this);
```

#### AUTO 


```{c}
auto task = new MoveCollectionTask(state);
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        CalendarPtr calendar = qobject_cast<CalendarCreateJob *>(job)->items().first().dynamicCast<Calendar>();
        qCDebug(GOOGLE_CALENDAR_LOG) << "Created calendar" << calendar->uid();
        // Enable newly added calendar in settings, otherwise user won't see it
        m_settings->addCalendar(calendar->uid());
        // TODO: the calendar returned by google is almost empty, i.e. it's not "editable",
        // does not contain the color, etc
        calendar->setEditable(true);
        // Populate remoteId & other stuff
        Collection newCollection(collection);
        setupCollection(newCollection, calendar);
        m_iface->collectionChangeCommitted(newCollection);
        emitReadyStatus();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            qDebug() << "Timeout waiting for desired resource online state.";
            loop.exit(1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->akonadiFetchResult(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->processNextBatch(); }
```

#### AUTO 


```{c}
const auto name = place.constFind(QLatin1String("name"));
```

#### AUTO 


```{c}
const auto relation = job->property("relation").value<Akonadi::Relation>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (ignoreStatusMail(item)) {
            continue;
        }

        if (excludeSpecialCollection(collectionSource)) {
            continue; // outbox, sent-mail, trash, drafts or templates.
        }

        if (mNewMails.contains(collectionSource)) {
            QList<Akonadi::Item::Id> idListFrom = mNewMails[ collectionSource ];
            if (idListFrom.contains(item.id())) {
                idListFrom.removeAll(item.id());

                if (idListFrom.isEmpty()) {
                    mNewMails.remove(collectionSource);
                } else {
                    mNewMails[ collectionSource ] = idListFrom;
                }
                if (!excludeSpecialCollection(collectionDestination)) {
                    QList<Akonadi::Item::Id> idListTo = mNewMails[ collectionDestination ];
                    idListTo.append(item.id());
                    mNewMails[ collectionDestination ] = idListTo;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new KIMAP::AppendJob(mSession);
```

#### AUTO 


```{c}
auto cancelButton = new QPushButton(this);
```

#### AUTO 


```{c}
const auto flagsLst = ResourceTask::toAkonadiFlags(flags);
```

#### AUTO 


```{c}
auto time = QDateTime::currentSecsSinceEpoch();
```

#### RANGE FOR STATEMENT 


```{c}
for (const SpecialFolders &sf : qAsConst(specialFolderList)) {
        queryItems.append(EwsId(sf.did));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int prot : std::as_const(protocols)) {
        addAuthenticationItem(m_ui->authenticationCombo, (MailTransport::Transport::EnumAuthenticationType::type)prot);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {return parseFoldersResponse(reader);}
```

#### AUTO 


```{c}
const auto qitup = mQueuedUpdates[EwsModifiedEvent].find(id.id());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &kcalAttendee : attendees) {
        Attendee attendee;

        attendee.displayName = kcalAttendee.name();
        attendee.smtpAddress = kcalAttendee.email();
        attendee.status = attendeeStatusToString(kcalAttendee.status());
        attendee.requestResponse = kcalAttendee.RSVP();
        // TODO: KCalendarCore::Attendee::mFlag is not accessible
        // attendee.invitationSent = kcalAttendee->mFlag;
        // DF: Hmm? mFlag is set to true and never used at all.... Did you mean another field?
        attendee.role = attendeeRoleToString(kcalAttendee.role());
        attendee.delegate = kcalAttendee.delegate();
        attendee.delegator = kcalAttendee.delegator();

        addAttendee(attendee);
    }
```

#### AUTO 


```{c}
auto wallet = getWallet();
```

#### AUTO 


```{c}
auto item = fetchJob->property("item").value<Akonadi::Item>();
```

#### AUTO 


```{c}
auto job = new JournalsFetchJob(mClientState->client(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Event &event : std::as_const(inputevents)) {
        cal.addEvent(event);
    }
```

#### AUTO 


```{c}
auto moveJob = new TaskMoveJob(detachTasks, items.first().parentCollection().remoteId(),
                                       QString(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto *userIdJob = new UserIdRequestJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : calendars) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalendarCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection
                                 |Collection::CanCreateItem
                                 |Collection::CanChangeItem
                                 |Collection::CanDeleteItem);
        } else {
            collection.setRights(nullptr);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        auto colorAttr = collection.attribute<CollectionColorAttribute>(Collection::AddIfMissing);
        colorAttr->setColor(calendar->backgroundColor());

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### AUTO 


```{c}
auto *senderReply = qobject_cast<QNetworkReply *>(sender());
```

#### AUTO 


```{c}
const auto instances{Akonadi::AgentManager::self()->instances()};
```

#### AUTO 


```{c}
auto *resp = new EwsFindFolderResponse(reader);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto item : query.queryItems()) {
        varmap[item.first] = item.second;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int prot : qAsConst(protocols)) {
        addAuthenticationItem(m_ui->authenticationCombo, (MailTransport::Transport::EnumAuthenticationType::type)prot);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &desc : qAsConst(mSharedNamespace)) {
            toplevelMailboxes << desc.name;
        }
```

#### AUTO 


```{c}
const auto payload = imapItem.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto job = new OXA::ConnectionTestJob(mServerEdit->text(), mUserEdit->text(), mPasswordEdit->text(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        KMime::Message::Ptr itemMail = item.payload<KMime::Message::Ptr>();
        QByteArray itemMailBody = itemMail->body();

        // For some reason, the body in the maildir has one additional newline.
        // Get rid of this so we can compare them.
        // FIXME: is this a bug? Find out where the newline comes from!
        itemMailBody.chop(1);
        itemMailBodies.insert(itemMailBody);
    }
```

#### AUTO 


```{c}
auto task = new RetrieveCollectionsTask(state);
```

#### AUTO 


```{c}
auto retrieveJob = qobject_cast<RetrieveItemsJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
        onCollectionChangedFinished(job, collection);
    }
```

#### AUTO 


```{c}
const auto allInstances = Akonadi::AgentManager::self()->instances();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsItem &ewsItem : items) {
        auto id(ewsItem[EwsItemFieldItemId].value<EwsId>());
        auto it = itemHash.find(id.id());
        if (it == itemHash.end()) {
            setErrorMsg(QStringLiteral("Got update for item %1, but item not found in local store.").arg(ewsHash(id.id())));
            emitResult();
            return false;
        }
        const auto qitup = mQueuedUpdates[EwsModifiedEvent].find(id.id());
        if (qitup != mQueuedUpdates[EwsModifiedEvent].end() && *qitup == id.changeKey()) {
            qCDebugNC(EWSRES_LOG) << QStringLiteral("Match for queued modification of item %1").arg(ewsHash(id.id()));
            continue;
        }
        Item &item = *it;
        if (item.remoteRevision() == id.changeKey()) {
            qCDebugNC(EWSRES_LOG) << QStringLiteral("Matching change key for item %1 - not syncing").arg(ewsHash(id.id()));
            continue;
        }
        item.clearPayload();
        item.setRemoteRevision(id.changeKey());
        if (!mTagStore->readEwsProperties(item, ewsItem, mTagsSynced)) {
            qCDebugNC(EWSRES_LOG) << QStringLiteral("Missing tags encountered - forcing sync");
            syncTags();
            return false;
        }
        EwsItemType type = ewsItem.internalType();
        toFetchItems[type].append(item);
        ++mTotalItemsToFetch;
    }
```

#### AUTO 


```{c}
auto *hboxLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto stdVectorBySeconds = std::vector<int>(bySecondsVector.begin(), bySecondsVector.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : info.split(QLatin1Char(','), Qt::SkipEmptyParts)) {
        const auto keyval = token.trimmed().split(QLatin1Char('='));
        if (keyval.count() == 2) {
            if (stringToKnownCertInfoType.contains(keyval[0])) {
                map.insert(stringToKnownCertInfoType[keyval[0]], keyval[1]);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, todo, item](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        TaskPtr task(new Task(*todo));
        auto newJob = new TaskModifyJob(task, item.parentCollection().remoteId(), job->account(), this);
        newJob->setProperty(ITEM_PROPERTY, QVariant::fromValue(item));
        connect(newJob, &TaskModifyJob::finished, this, &TaskHandler::slotGenericJobFinished);
    }
```

#### AUTO 


```{c}
auto *attr = col.attribute<HighestModSeqAttribute>();
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsCreateItemJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &eventXml : std::as_const(events)) {
            resp += eventXml;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mb : memberMailbox) {
        path << QUrl::toPercentEncoding(QString::fromUtf8(mb));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : lstPath) {
        QDir dir(p);
        if (!dir.exists(p)) {
            if (!dir.mkpath(p)) {
                return false;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(toplevelMailboxes)) {
            KIMAP::GetMetaDataJob *meta = new KIMAP::GetMetaDataJob(mSession);
            meta->setMailBox(mailbox + QLatin1String("*"));
            if (mServerCapabilities.contains(QStringLiteral("METADATA"))) {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Metadata);
            } else {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Annotatemore);
            }
            meta->setDepth(KIMAP::GetMetaDataJob::AllLevels);
            for (const QByteArray &requestedEntry : qAsConst(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
            connect(meta, &KJob::result, this, &RetrieveMetadataJob::onGetMetaDataDone);
            mJobs++;
            meta->start();
        }
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionModifyJob(davUrl);
```

#### AUTO 


```{c}
auto job = new FileStore::ItemFetchJob(collection, d->mSession);
```

#### AUTO 


```{c}
auto job = new EwsSubscribedFoldersJob(mEwsClient, mSettings, this);
```

#### AUTO 


```{c}
auto renameJob = new KIMAP::RenameJob(session);
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *req = new EwsMoveItemRequest(mClient, this);
```

#### AUTO 


```{c}
auto it = std::find_if(items.cbegin(), items.cend(), [&contact](const Item &item){
                        return item.remoteId() == contact->uid();
                    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::CustomProperty &prop : customProperties) {
        QString key;
        if (prop.identifier.compare(0, 5, "X-KDE")) {
            key.append(QLatin1String("X-KOLAB-"));
        }
        key.append(fromStdString(prop.identifier));
        props.insert(key.toLatin1(), fromStdString(prop.value));
        //         i.setCustomProperty("KOLAB", fromStdString(prop.identifier).toLatin1(), fromStdString(prop.value));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &object : objects) {
        const TaskPtr task = object.dynamicCast<Task>();

        Item item;
        item.setMimeType( mimeType() );
        item.setParentCollection(collection);
        item.setRemoteId(task->uid());
        item.setRemoteRevision(task->etag());
        item.setPayload<KCalendarCore::Todo::Ptr>(task.dynamicCast<KCalendarCore::Todo>());

        if (task->deleted()) {
            qCDebug(GOOGLE_TASKS_LOG) << " - removed" << task->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_TASKS_LOG) << " - changed" << task->uid();
            changedItems << item;
        }
    }
```

#### AUTO 


```{c}
const auto responses{req->responses()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventFile &data : qAsConst(mEvents)) {
        const KAEvent &event = data.event;
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMDIRRESOURCE_LOG) << "retrieveItems: KAEvent has no alarms:" << event.id();
            continue; // event has no usable alarms
        }
        if (!mimeTypes.contains(mime)) {
            continue; // restrict alarms returned to the defined types
        }

        Item item(mime);
        item.setRemoteId(event.id());
        item.setPayload(event);
        items.append(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item){
            return item.isValid() && (!item.hasPayload<T>() || item.mimeType() != mimeType());
        }
```

#### AUTO 


```{c}
const auto annotationKeys{annotations.keys()};
```

#### AUTO 


```{c}
auto *interact = (sasl_interact_t *)in;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &newItem : newItems) {
                new ItemCreateJob(newItem, collection, this);
            }
```

#### AUTO 


```{c}
auto searchJob = new Akonadi::ContactSearchJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        contactChanged(item);
    }
```

#### AUTO 


```{c}
const auto elmName = reader.name();
```

#### AUTO 


```{c}
auto *mail = new KMime::Message();
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectDeleteJob(object, this);
```

#### AUTO 


```{c}
auto renameJob = static_cast<KIMAP::RenameJob *>(job);
```

#### AUTO 


```{c}
auto logout = new KIMAP::LogoutJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[](EwsOAuth *oAuth) {
            return oAuth->authenticate(false);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &token : info.split(QLatin1Char(','), Qt::SkipEmptyParts)) {
#endif
        const auto keyval = token.trimmed().split(QLatin1Char('='));
        if (keyval.count() == 2) {
            if (stringToKnownCertInfoType.contains(keyval[0])) {
                map.insert(stringToKnownCertInfoType[keyval[0]], keyval[1]);
            }
        }
    }
```

#### AUTO 


```{c}
auto *aclAttribute = c.attribute<Akonadi::ImapAclAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : std::as_const(mDeletedOffsets)) {
                mIndexData.remove(offset);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &a : atts) {
        if (a.contact().uid() == s || a.contact().email() == s || a.contact().name() == s) {
            return a;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setPassword(QString());
        if (wallet) {
            qDebug() << "Wallet is not null";
            loop.exit(1);
            return;
        }
        loop.exit(0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &root : qAsConst(newRoots)) {
        newLimits << quotaJob->allLimits(root);
        newUsages << quotaJob->allUsages(root);

        const QString &decodedRoot = QString::fromUtf8(KIMAP::decodeImapFolderName(root));

        if (newRoots.size() == 1 || decodedRoot == mailBox) {
            newCurrent = newUsages.last()["STORAGE"] * 1024;
            newMax = newLimits.last()["STORAGE"] * 1024;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QLatin1String("location:"), Qt::CaseInsensitive)) {
            location = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        ids << EwsId(item.remoteId(), item.remoteRevision());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
                const QVariant tagListVar = tagListHash[ item.remoteId() ];
                if (tagListVar.isValid()) {
                    const QStringList tagList = tagListVar.value<QStringList>();
                    if (!tagListHash.isEmpty()) {
                        TagContext tag;
                        tag.mItem = item;
                        tag.mTagList = tagList;

                        taggedItems << tag;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QByteArray data = md.readEntry(item.remoteId());

        KMime::Message *mail = new KMime::Message();
        mail->setContent(KMime::CRLFtoLF(data));
        mail->parse();

        Item i(item);
        i.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, i);
        rv.push_back(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventFile &data : std::as_const(mEvents)) {
        const KAEvent &event = data.event;
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMDIRRESOURCE_LOG) << "retrieveItems: KAEvent has no alarms:" << event.id();
            continue; // event has no usable alarms
        }
        if (!mimeTypes.contains(mime)) {
            continue; // restrict alarms returned to the defined types
        }

        Item item(mime);
        item.setRemoteId(event.id());
        item.setPayload(event);
        items.append(item);
    }
```

#### AUTO 


```{c}
auto job = new ContactsGroupCreateJob(group, m_settings->accountPtr(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. "
                                     << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (davCollection.color().isValid()) {
            auto *colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
            colorAttr->setColor(davCollection.color());
        }

        if (!davCollection.displayName().isEmpty()) {
            auto *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalendarCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalendarCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalendarCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalendarCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        auto *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after successful sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, items](KGAPI2::Job *job, const ContactPtr &contact) {
        qCDebug(GOOGLE_CONTACTS_LOG) << " - fetched photo for contact" << contact->uid();
        int processedItems = job->property("processedItems").toInt();
        processedItems++;
        job->setProperty("processedItems", processedItems);
        m_iface->emitPercent(100.0f * processedItems / items.count());

        auto it = std::find_if(items.cbegin(), items.cend(), [&contact](const Item &item) {
            return item.remoteId() == contact->uid();
        });
        if (it != items.cend()) {
            Item newItem(*it);
            newItem.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
            new ItemModifyJob(newItem, this);
        }
    }
```

#### AUTO 


```{c}
auto createJob = qobject_cast<OXA::FolderCreateJob *>(job);
```

#### AUTO 


```{c}
auto notify = new KNotification(QStringLiteral("sendingfailed"));
```

#### AUTO 


```{c}
auto writeJob = new WritePasswordJob(QStringLiteral("pop3"), this);
```

#### AUTO 


```{c}
auto profile = new QWebEngineProfile(resource->identifier(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &chunk) {
        const QString respHead = QStringLiteral("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
                "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
                "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
                "<soap:Header>"
                "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
                "</soap:Header>"
                "<soap:Body>"
                "<m:GetStreamingEventsResponse>"
                "<m:ResponseMessages>"
                "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
                "<m:ResponseCode>NoError</m:ResponseCode>"
                "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral("</m:GetStreamingEventsResponseMessage>"
                "</m:ResponseMessages>"
                "</m:GetStreamingEventsResponse>"
                "</soap:Body>"
                "</soap:Envelope>");
        const QString eventHead = QStringLiteral("<m:Notifications>"
                "<m:Notification>"
                "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral("<NewMailEvent>"
                "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
                "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
                "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
                "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediately" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &day : days) {
        for (int i = 0; i < 7; ++i) {
            if (day == QLatin1String(s_weekDayName[i])) {
                arr.setBit(i, true);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &result : results) {
            const QStringList split = result.split(QLatin1Char('|'));
            KDAV::Protocol protocol = KDAV::ProtocolInfo::protocolByName(split.at(0));
            if (!Settings::self()->urlConfiguration(protocol, split.at(1))) {
                auto urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = split.at(1);
                if (dlg->useDefaultCredentials()) {
                    urlConfig->mUser = QStringLiteral("$default$");
                } else {
                    urlConfig->mUser = dlg->username();
                    urlConfig->mPassword = dlg->password();
                }
                urlConfig->mProtocol = protocol;

                Settings::self()->newUrlConfiguration(urlConfig);

                addModelRow(Utils::translatedProtocolName(protocol), split.at(1));
                mAddedUrls << QPair<QString, KDAV::Protocol>(split.at(1), protocol);
                checkUserInput();
            }
        }
```

#### AUTO 


```{c}
auto modifyJob = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
const auto ct = cth.isNull() ? QStringLiteral("text/html") : cth.toString();
```

#### AUTO 


```{c}
auto settings = Settings::self();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &instance : allInstances) {
        if (isLegacyGoogleResource(instance)) {
            const auto account = getAccountNameFromResourceSettings(instance);
            if (account.isEmpty()) {
                qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: resource" << instance.identifier() << "is not configued, removing";
                Akonadi::AgentManager::self()->removeInstance(instance);
                continue;
            }
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: discovered resource" << instance.identifier() << "for account" << account;
            if (instance.type().identifier() == akonadiGoogleCalendarResource) {
                mMigrations[account].calendarResource = instance;
            } else if (instance.type().identifier() == akonadiGoogleContactsResource) {
                mMigrations[account].contactResource = instance;
            }
        } else if (isGoogleGroupwareResource(instance)) {
            const auto account = getAccountNameFromResourceSettings(instance);
            mMigrations[account].alreadyExists = true;
        }
    }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsCreateFolderRequest *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job){
        if (!handleError(job) || !m_account) {
            m_ui->taskListsBox->setDisabled(true);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeTaskLists;
        if (m_account->accountName() == m_settings->account()) {
            activeTaskLists = m_settings->taskLists();
        }
        m_ui->taskListsList->clear();
        for (const ObjectPtr &object : objects) {
            const TaskListPtr taskList = object.dynamicCast<TaskList>();

            QListWidgetItem *item = new QListWidgetItem(taskList->title());
            item->setData(Qt::UserRole, taskList->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->taskListsList->addItem(item);
        }

        m_ui->taskListsBox->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto *itemCreate = new ItemCreateJob(item, mCollection, transaction());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : std::as_const(uidsOfMessagesDownloadedButNotDeleted)) {
        if (!seenUIDs.contains(uid)) {
            seenUIDs.append(uid);
            timeOfSeenUIDs.append(time(nullptr));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {
        return parseItemsResponse(reader);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=, &tokenReplyData] (QString &data, QMap<Mock::QNetworkRequest::KnownHeaders, QVariant> &headers) {
            QVariantMap map;
            map[QStringLiteral("token_type")] = QStringLiteral("Bearer");
            map[QStringLiteral("scope")] = QStringLiteral("ReadWrite.All");
            map[QStringLiteral("expires_in")] = QString::number(tokenLifetime);
            map[QStringLiteral("ext_expires_in")] = QString::number(extTokenLifetime);
            map[QStringLiteral("expires_on")] = QString::number(time + tokenLifetime);
            map[QStringLiteral("not_before")] = QString::number(time);
            map[QStringLiteral("resource")] = resource;
            map[QStringLiteral("access_token")] = accessToken;
            map[QStringLiteral("refresh_token")] = refreshToken;
            map[QStringLiteral("foci")] = QStringLiteral("1");
            map[QStringLiteral("id_token")] = idToken;
            tokenReplyData = formatJsonSorted(map);
            data = tokenReplyData;
            headers[Mock::QNetworkRequest::ContentTypeHeader] = QStringLiteral("application/json; charset=utf-8");

            return Mock::QNetworkReply::NoError;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Freebusy &fb : fbList) {
        const QDateTime &tmpStart = Kolab::Conversion::toDate(fb.start());
        if (!start.isValid() || tmpStart < start) {
            start = tmpStart;
            allDay |= fb.start().isDateOnly();
        }
        const QDateTime &tmpEnd = Kolab::Conversion::toDate(fb.end());
        if (!end.isValid() || tmpEnd > end) {
            end = tmpEnd;
            allDay |= fb.start().isDateOnly();
        }

        const auto fbPeriods{fb.periods()};
        for (const Kolab::FreebusyPeriod &period : fbPeriods) {
            Kolab::FreebusyPeriod simplifiedPeriod;
            simplifiedPeriod.setPeriods(period.periods());
            simplifiedPeriod.setType(period.type());
            if (!simple) { // Don't copy and reset to avoid unintentional information leaking into simple lists
                simplifiedPeriod.setEvent(period.eventSummary(), period.eventUid(), period.eventLocation());
            }
            periods.push_back(simplifiedPeriod);
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_handlers.cbegin(), m_handlers.cend(),
                           [&collection](const GenericHandler::Ptr &handler){
        return collection.contentMimeTypes().contains(handler->mimeType());
    });
```

#### AUTO 


```{c}
auto *req = new EwsGetEventsRequest(mEwsClient, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&events](const QString &event) {
                events.append(event);
            }
```

#### AUTO 


```{c}
auto *modifyJob = new CollectionModifyJob(mboxCollection);
```

#### AUTO 


```{c}
auto *job = new EwsGlobalTagsReadJob(mTagStore, mEwsClient, mRootCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dt : recExDateTimes) {
        exdates.push_back(fromDate(dt, e.allDay()));
    }
```

#### AUTO 


```{c}
auto aclAttribute = c.attribute<Akonadi::ImapAclAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("changeAlarmTypes exit:")
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &param : responses) {
        const QList<QByteArray> kv = param.split('=');
        if (kv.length() == 2) {
            ret.insert(QUrl::fromPercentEncoding(kv[0]), QUrl::fromPercentEncoding(kv[1]));
        }
    }
```

#### AUTO 


```{c}
auto expunge = new KIMAP::ExpungeJob(session);
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<OXA::ObjectRequestJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
                                 if (loop.isRunning()) {
                                     loop.exit(1);
                                 } else {
                                     error = true;
                                 }
                             }
```

#### AUTO 


```{c}
const auto items = req->property("items").value<Item::List>();
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : std::as_const(d->mSubscribedIds)) {
        list.append(id.id());
    }
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(collection, CollectionFetchJob::FirstLevel);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
                if (job->error()) {
                    ui->loginStatusLbl->setText(job->errorText());
                } else {
                    const auto token = job->token();
                    if (token.isEmpty()) {
                        ui->loginStatusLbl->setText(i18n("Not logged in"));
                        ui->logoutBtn->setVisible(false);
                        ui->loginBtn->setVisible(true);
                    } else {
                        ui->loginStatusLbl->setText(i18n("Logged in as <b>%1</b>", job->userName()));
                        ui->loginBtn->setVisible(false);
                        ui->logoutBtn->setVisible(true);
                    }
                }
            }
```

#### AUTO 


```{c}
auto job = new TaskListFetchJob(m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(parent);
```

#### AUTO 


```{c}
const auto key
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QString rid = item.remoteId();
        Incidence::Ptr incidence = calendar()->instance(rid);
        if (!incidence) {
            qCritical() << "akonadi_ical_resource: Can't find incidence with uid " << rid << "; item.id() = " << item.id();
            Q_EMIT error(i18n("Incidence with uid '%1' not found.", rid));
            return false;
            ;
        }

        Incidence::Ptr incidencePtr(incidence->clone());

        Item i = item;
        i.setMimeType(incidencePtr->mimeType());
        i.setPayload<Incidence::Ptr>(incidencePtr);
        resultItems.append(i);
    }
```

#### AUTO 


```{c}
auto store = new KIMAP::StoreJob(m_session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &scope : resourceScopes) {
            if (!account->scopes().contains(scope)) {
                account->addScope(scope);
                scopesChanged = true;
            }
        }
```

#### AUTO 


```{c}
auto it = queries.cbegin(), end = queries.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Lang &n : langs) {
        languages.push_back(toStdString(n.language()));
    }
```

#### AUTO 


```{c}
auto *job = new TagFetchJob(unknownTags, this);
```

#### AUTO 


```{c}
auto item = new QStandardItem(QIcon::fromTheme(QStringLiteral("dialog-error")), msg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QHash<Akonadi::Collection, QList<Akonadi::Item::Id>>::iterator end(mNewMails.end());
        for (QHash<Akonadi::Collection, QList<Akonadi::Item::Id>>::iterator it = mNewMails.begin(); it != end; ++it) {
            QList<Akonadi::Item::Id> idList = it.value();
            if (idList.contains(item.id()) && addedFlags.contains("\\SEEN")) {
                idList.removeAll(item.id());
                if (idList.isEmpty()) {
                    mNewMails.remove(it.key());
                    break;
                } else {
                    (*it) = idList;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        collectionFetched(job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        qCWarning(EWSRES_LOG) << "Timeout waiting for wallet open";
        onWalletOpened(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &loc : { QLatin1String("street"), QLatin1String("city"),
                                     QLatin1String("zip"), QLatin1String("country") }) {
                const auto it = location.constFind(loc);
                if (it != placeEnd) {
                    locationStr << it->toString();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto event : expectedEvents) {
            qDebug() << "Expected event:" << event;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &mail : mails) {
        KMime::Message::Ptr ourMail(new KMime::Message());
        ourMail->setContent(KMime::CRLFtoLF(mail));
        ourMail->parse();
        QByteArray ourMailBody = ourMail->body();
        ourMailBodies.insert(ourMailBody);
    }
```

#### AUTO 


```{c}
const auto notifications = resp.notifications();
```

#### LAMBDA EXPRESSION 


```{c}
[this](int s, const QString & message) {
        status(s, message);
    }
```

#### AUTO 


```{c}
auto progressContainer = new QWidget(this);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(mItem, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        if (loop.isRunning()) {
            loop.exit(1);
        } else {
            error = true;
        }
    }
```

#### AUTO 


```{c}
auto *attr2 = new CollectionAnnotationsAttribute();
```

#### AUTO 


```{c}
auto url = findBirthdayIcalLink(job->data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dt : list) {
                const auto utc = dt.toUTC();
                const Kolab::Period &period = addLocalPeriod(utc, duration.end(utc), start, end, allDay);
                if (period.isValid()) {
                    periods.push_back(period);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item::Flag &flag : flags) {
            item.setFlag(flag);
        }
```

#### AUTO 


```{c}
auto select = new KIMAP::SelectJob(move->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this, items](KJob *job){
                if (job->error()) {
                    m_iface->cancelTask(i18n("Failed to delete task: %1", job->errorString()));
                    return;
                }
                const Item::List fetchedItems = qobject_cast<ItemFetchJob *>(job)->items();
                Item::List detachItems;
                TasksList detachTasks;
                for (const Item &fetchedItem : fetchedItems) {
                    auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
                    TaskPtr task(new Task(*todo));
                    const QString parentId = task->relatedTo(KCalendarCore::Incidence::RelTypeParent);
                    if (parentId.isEmpty()) {
                        continue;
                    }

                    auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item){
                                return item.remoteId() == parentId;
                            });
                    if (it != items.cend()) {
                        Item newItem(fetchedItem);
                        qCDebug(GOOGLE_TASKS_LOG) << "Detaching child" << newItem.remoteId() << "from" << parentId;
                        todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
                        newItem.setPayload<KCalendarCore::Todo::Ptr>(todo);
                        detachItems << newItem;
                        detachTasks << task;
                    }
                }
                /* If there are no items do detach, then delete the task right now */
                if (detachItems.isEmpty()) {
                    doRemoveTasks(items);
                    return;
                }

                qCDebug(GOOGLE_TASKS_LOG) << "Reparenting" << detachItems.count() << "children...";
                auto moveJob = new TaskMoveJob(detachTasks, items.first().parentCollection().remoteId(),
                        QString(), m_settings->accountPtr(), this);
                connect(moveJob, &TaskMoveJob::finished, this, [this, items, detachItems](KGAPI2::Job *job){
                            if (job->error()) {
                                m_iface->cancelTask(i18n("Failed to reparent subtasks: %1", job->errorString()));
                                return;
                            }
                            // Update items inside Akonadi DB too
                            new ItemModifyJob(detachItems);
                            // Perform actual removal
                            doRemoveTasks(items);
                        });
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &err) {
            error(QStringLiteral("Network reply error"), err, QUrl());
        }
```

#### AUTO 


```{c}
auto senderReply = qobject_cast<QNetworkReply *>(sender());
```

#### AUTO 


```{c}
auto colorAttr = collection.attribute<Akonadi::CollectionColorAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto notify = new KNotification(QStringLiteral("emailsent"));
```

#### AUTO 


```{c}
const auto initStatus = performAuthAction(oAuth, 1000, [](EwsOAuth *oAuth) {
        oAuth->init();
        return true;
    });
```

#### AUTO 


```{c}
auto *socket = qobject_cast<QTcpSocket *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this](int s, const QString &message) {
                Q_EMIT reportStatus(s, message);
            }
```

#### AUTO 


```{c}
auto saslError = [&]() {
        closeConnection();
        return Result::fail(ERR_SASL_FAILURE, i18n("An error occurred during authentication: %1", QString::fromUtf8(sasl_errdetail(conn))));
    };
```

#### AUTO 


```{c}
auto *aclAttribute
        = m_collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *req = new EwsPoxAutodiscoverRequest(url, mEmail, mUserAgent,
                                                                   mEnableNTLMv2, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KContacts::Address a : addresses) {
        addressee.removeAddress(a);
        a.setPostOfficeBox(QString()); // Not supported anymore
        addressee.insertAddress(a);
    }
```

#### AUTO 


```{c}
auto job = new OXA::FolderMoveJob(folder, destinationFolder, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &fileInfo : dirEntries) {
        if (dir.exists(indexFilePattern.arg(fileInfo.fileName()))) {
            result << fileInfo.fileName();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QMap<QString, QString> &map) {
            mAuthMap = map;
        }
```

#### AUTO 


```{c}
auto attr1 = new CollectionAnnotationsAttribute();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QNetworkCookie &cookie) {
            mCookies.remove(cookie.name());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : qAsConst(objects)) {
        const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();

        QString realName = group->title();

        if (group->isSystemGroup()) {
            if (group->title().contains(QLatin1String("Coworkers"))) {
                realName = i18nc("Name of a group of contacts", "Coworkers");
            } else if (group->title().contains(QLatin1String("Friends"))) {
                realName = i18nc("Name of a group of contacts", "Friends");
            } else if (group->title().contains(QLatin1String("Family"))) {
                realName = i18nc("Name of a group of contacts", "Family");
            } else if (group->title().contains(QLatin1String("My Contacts"))) {
                // Yes, skip My Contacts group, we store "My Contacts" in root collection
                continue;
            }
        } else {
            if (group->title().contains(QLatin1String("Other Contacts"))) {
                realName = i18nc("Name of a group of contacts", "Other Contacts");
            }
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KContacts::Addressee::mimeType());
        collection.setName(group->id());
        collection.setParentCollection(m_rootCollection);
        collection.setRights(Collection::CanLinkItem
                             |Collection::CanUnlinkItem
                             |Collection::CanChangeItem);
        if (!group->isSystemGroup()) {
            collection.setRights(collection.rights()
                                 |Collection::CanChangeCollection
                                 |Collection::CanDeleteCollection);
        }
        collection.setRemoteId(group->id());
        collection.setVirtual(true);

        EntityDisplayAttribute *collAttr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        collAttr->setDisplayName(realName);
        collAttr->setIconName(QStringLiteral("view-pim-contacts"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts) {
        if (part.startsWith("PLD:")) {
            payloadChanged = true;
        }
        if (part.contains("FLAGS")) {
            flagsChanged = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const AgentInstance &_instance, bool online) {
        if (_instance.identifier() == mTestInstance->identifier()) {
            switch (instanceState) {
            case InitialOffline:
                QVERIFY(online);
                if (online) {
                    qDebug() << "Initial resource online state reached";
                    instanceState = InitialOnline;
                }
                break;
            case InitialOnline:
                if (!online && requestTriggered) {
                    qDebug() << "Resource state changed to offline after busy response";
                    instanceState = BusyOffline;
                    requestTriggered = false;
                }
                break;
            case BusyOffline:
                QVERIFY(online);
                if (online) {
                    qDebug() << "Resource online after retry";
                    instanceState = RetryOnline;
                }
                break;
            case RetryOnline:
                if (!online) {
                    qDebug() << "Resource state changed to offline after busy response";
                    instanceState = RetryOffline;
                    loop.exit(0);
                }
                break;
            default:
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Person &person : mailAddresses) {
                writeString(addresses, QStringLiteral("address"), person.fullName());
            }
```

#### AUTO 


```{c}
auto protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
static const auto IdleTimeout = std::chrono::minutes(1);
```

#### AUTO 


```{c}
auto *job = new EwsSubscribedFoldersJob(mEwsClient, mSettings, this);
```

#### AUTO 


```{c}
auto urlConfigAccepted = new Settings::UrlConfiguration();
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(mOutbox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
            ++flagCounts[flag];
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                        postJobResult(job);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : supportedProtocols) {
        Url url;

        if (protocol == QLatin1String("CalDav")) {
            url.protocol = DavUtils::CalDav;
        } else if (protocol == QLatin1String("CardDav")) {
            url.protocol = DavUtils::CardDav;
        } else if (protocol == QLatin1String("GroupDav")) {
            url.protocol = DavUtils::GroupDav;
        } else {
            return urls;
        }

        QString urlStr = settingsToUrl(this, protocol);

        if (!urlStr.isEmpty()) {
            url.url = urlStr;
            url.userName = QStringLiteral("$default$");
            urls << url;
        }
    }
```

#### AUTO 


```{c}
auto davJob = qobject_cast<KDAV::DavPrincipalSearchJob *>(job);
```

#### AUTO 


```{c}
const auto zones = QTimeZone::availableTimeZoneIds();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enabled) {
        updateReplyMail(enabled);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::FreebusyPeriod &fbPeriod : freePeriods) {
        const auto fbPeriodPeriods{fbPeriod.periods()};
        for (const Kolab::Period &p : fbPeriodPeriods) {
            KCalendarCore::FreeBusyPeriod period(Kolab::Conversion::toDate(p.start), Kolab::Conversion::toDate(p.end));
            //             period.setSummary("summary"); Doesn't even work. X-SUMMARY is read though (just not written out)s
            // TODO
            list.append(period);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Collection &col, const DesiredState &state) {
                                                      auto attr = col.attribute<SpecialCollectionAttribute>();
                                                      QByteArray specialType;
                                                      if (attr) {
                                                          specialType = attr->collectionType();
                                                      }
                                                      return col.parentCollection().remoteId() == state.parentId && specialType == state.specialType;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : std::as_const(mFolderIds)) {
        id.writeFolderIds(writer);
    }
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto data = reply->readAll();
```

#### AUTO 


```{c}
auto job = new CollectionMoveJob(fd.collection, mFolderHash[fd.parent()].collection);
```

#### AUTO 


```{c}
auto j = new Akonadi::ItemModifyJob(remoteDependentItems);
```

#### AUTO 


```{c}
auto trJob = qobject_cast<KIO::TransferJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready) {
        if (accountId() > 0) {
            return;
        }
        if (!ready) {
            Q_EMIT status(Broken, i18n("Can't access KWallet"));
            return;
        }

        const auto account = m_settings->accountPtr();
        if (account.isNull()) {
            Q_EMIT status(NotConfigured);
            return;
        }

        if (!accountIsValid(account)) {
            requestAuthenticationFromUser(account);
        } else {
            emitReadyStatus();
            synchronize();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attachment &a : std::as_const(mAttachments)) {
        incidence->addAttachment(a);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&oAuth, &events, map]() {
            events.append("RequestWalletMap");
            oAuth.walletMapRequestFinished(map);
        }
```

#### AUTO 


```{c}
const auto CTagAttr = collection.attribute<CTagAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &tagId : std::as_const(tagIds)) {
        mTagData.remove(tagId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attendee::Ptr &attendee : attendees) {
            const User user = Users::self()->lookupEmail(attendee->email());

            if (!user.isValid()) {
                continue;
            }

            QString status;
            switch (attendee->status()) {
            case KCalCore::Attendee::Accepted:
                status = QStringLiteral("accept");
                break;
            case KCalCore::Attendee::Declined:
                status = QStringLiteral("decline");
                break;
            default:
                status = QStringLiteral("none");
                break;
            }

            QDomElement element = DAVUtils::addOxElement(document, members, QStringLiteral("user"), OXUtils::writeNumber(user.uid()));
            DAVUtils::setOxAttribute(element, QStringLiteral("confirm"), status);
        }
```

#### AUTO 


```{c}
auto *davJob = qobject_cast<KDAV::DavCollectionsFetchJob *>(job);
```

#### AUTO 


```{c}
auto didText = attrs.value(QStringLiteral("DistinguishedPropertySetId"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, collection](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }

        TaskListPtr taskList = qobject_cast<TaskListCreateJob *>(job)->items().first().dynamicCast<TaskList>();
        qCDebug(GOOGLE_TASKS_LOG) << "Task list created:" << taskList->uid();
        // Enable newly added task list in settings
        m_settings->addTaskList(taskList->uid());
        // Populate remoteId & other stuff
        Collection newCollection(collection);
        setupCollection(newCollection, taskList);
        m_iface->collectionChangeCommitted(newCollection);
        emitReadyStatus();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : calendars) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection |
                                 Collection::CanCreateItem |
                                 Collection::CanChangeItem |
                                 Collection::CanDeleteItem);
        } else {
            collection.setRights(nullptr);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        auto colorAttr = collection.attribute<CollectionColorAttribute>(Collection::AddIfMissing);
        colorAttr->setColor(calendar->backgroundColor());

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : lstKeys) {
        if (mMailCollections.contains(mailbox)) {
            const KIMAP::Acl::Rights imapRights = rights.value(mailbox);
            QStringList parts = mailbox.split(separatorCharacter());
            parts.removeLast();
            QString parentMailbox = parts.join(separatorCharacter());

            KIMAP::Acl::Rights parentImapRights;
            // If the parent folder is not existing we cant rename
            if (!parentMailbox.isEmpty() && rights.contains(parentMailbox)) {
                parentImapRights = rights.value(parentMailbox);
            }
            // qCDebug(KOLABRESOURCE_LOG) << mailbox << parentMailbox << imapRights << parentImapRights;

            Akonadi::Collection &collection = mMailCollections[mailbox];
            CollectionMetadataHelper::applyRights(collection, imapRights, parentImapRights);

            // Store the mailbox ACLs
            auto *aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
            const KIMAP::Acl::Rights oldRights = aclAttribute->myRights();
            if (oldRights != imapRights) {
                aclAttribute->setMyRights(imapRights);
            }
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Can't find mailbox " << mailbox;
        }
    }
```

#### AUTO 


```{c}
auto payload = item.payload<Incidence::Ptr>();
```

#### AUTO 


```{c}
auto *cancelButton = new QPushButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->localFoldersChanged(); }
```

#### AUTO 


```{c}
auto id(ewsItem[EwsItemFieldItemId].value<EwsId>());
```

#### AUTO 


```{c}
auto *listJob = new KIMAP::ListJob(session);
```

#### AUTO 


```{c}
const auto account = getAccountNameFromResourceSettings(instance);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &contactItem : contactItems) {
        if (!contactItem.hasPayload<KContacts::Addressee>()) {
            cancelTask();
            return;
        }
        auto contact = contactItem.payload<KContacts::Addressee>();
        contacts.insert(contactItem.id(), contact);
    }
```

#### AUTO 


```{c}
auto job = new ContactDeleteJob(contactIds, m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto list = event->recurrence()->timesInInterval(start, end);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item item : items) {
        if (!item.hasPayload<KCalCore::Todo::Ptr>()) {
            qDebug() << "Item " << item.remoteId() << " does not have Todo payload";
            continue;
        }

        KCalCore::Todo::Ptr todo = item.payload<KCalCore::Todo::Ptr>();
        /* If this item is child of the item we want to remove then add it to detach list */
        if (todo->relatedTo(KCalCore::Incidence::RelTypeParent) == removedItem.remoteId()) {
            todo->setRelatedTo(QString(), KCalCore::Incidence::RelTypeParent);
            item.setPayload(todo);
            detachItems << item;
        }
    }
```

#### AUTO 


```{c}
auto task = new ExpungeCollectionTask(createResourceState(TaskArguments(collection)), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : qAsConst(m_taskList)) {
            task->kill();
            delete task;
        }
```

#### AUTO 


```{c}
auto page = qobject_cast<WebPage *>(mView->page());
```

#### AUTO 


```{c}
const auto username = QStringLiteral("test");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : cols) {
        if (!contactFilter.isWantedCollection(col)) {
            continue;
        }
        auto job = new ItemFetchJob(col, this);
        job->fetchScope().fetchFullPayload();
        connect(job, &ItemFetchJob::itemsReceived, this, &BirthdaysResource::createEvents);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Person &p : mailAddresses) {
                receipents.emplace_back(toStdString(p.email()), toStdString(p.name()));
            }
```

#### AUTO 


```{c}
auto tokenReply = qobject_cast<QNetworkReply *>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                emitStatusReady();
            }
```

#### AUTO 


```{c}
auto parentId = folder[EwsFolderFieldParentFolderId].value<EwsId>();
```

#### AUTO 


```{c}
auto *renameJob = new KIMAP::RenameJob(session);
```

#### AUTO 


```{c}
auto colJob = qobject_cast<FileStore::CollectionMoveJob *>(job);
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<Akonadi::RecursiveItemFetchJob *>(job);
```

#### AUTO 


```{c}
const auto members = distlist.members();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                auto page = qobject_cast<WebPage *>(mView->page());
                if (auto err = page->lastCeritificateError()) {
                    QMessageBox msg;
                    msg.setIconPixmap(QIcon::fromTheme(QStringLiteral("security-low")).pixmap(64));
                    msg.setText(err->errorDescription());
                    msg.addButton(QMessageBox::Ok);
                    msg.exec();
                }
            }
```

#### AUTO 


```{c}
auto *mjob = new ItemModifyJob(item);
```

#### AUTO 


```{c}
auto akonadiNote = KMime::Message::Ptr::create();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        qCWarning(EWSRES_LOG) << "Timeout waiting for wallet open for write";
        onWalletOpenedForWrite(false);
    }
```

#### AUTO 


```{c}
auto conn = new FakeEwsConnection(sock, this);
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive);
```

#### AUTO 


```{c}
auto it = std::find_if(m_handlers.cbegin(), m_handlers.cend(),
                           [&mimeType](const GenericHandler::Ptr &handler){
        return handler->mimeType() == mimeType;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &handler : m_handlers) {
        handler->retrieveCollections(m_rootCollection);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : qAsConst(member.mailbox)) {
            Akonadi::Collection col;
            col.setRemoteId(separatorCharacter() + QString::fromLatin1(part));
            col.setParentCollection(parent);
            parent = col;
        }
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemsListJob(davUrl, mEtagCaches.value(collection.remoteId()));
```

#### AUTO 


```{c}
auto item = modifyJob->property("item").value<Akonadi::Item>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &msg) {
        qDebug() << "failed" << msg;
        loop.exit(1);
        status = 1;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QString cur, const QSslError &error) {
                    if (!cur.isEmpty())
                        cur += QLatin1Char('\n');
                    cur += error.errorString();
                    return cur;
                }
```

#### AUTO 


```{c}
auto *job = new KIMAP::CapabilitiesJob(session1);
```

#### AUTO 


```{c}
auto *protocolStandardItem = new QStandardItem(protocol);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileStore::Job *job : jobs) {
        mCurrentJob = job;

        if (job->error() == 0) {
            if (!job->accept(&mTopLevelCollectionFetcher)) {
                q->processJob(job);
            }
        }
        mSession->emitResult(job);
        mCurrentJob = Q_NULLPTR;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(items)) {
        const auto flags{item.flags()};
        for (const QByteArray &flag : flags) {
            ++flagCounts[flag];
        }
    }
```

#### AUTO 


```{c}
auto writeJob = new WritePasswordJob(QStringLiteral("pop3"));
```

#### AUTO 


```{c}
auto respClassRef = reader.attributes().value(QStringLiteral("ResponseClass"));
```

#### AUTO 


```{c}
auto job = new KGAPI2::FreeBusyQueryJob(email, start.dateTime(), end.dateTime(),
                                            account(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &flag : flagList) {
            flags.insert(flag.toAscii());
        }
```

#### AUTO 


```{c}
const auto group = item.payload<KContacts::ContactGroup>();
```

#### LAMBDA EXPRESSION 


```{c}
[&wallet](KWallet::MyWallet *) {
        return nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsEventType type : std::as_const(mEventTypes)) {
        writer.writeTextElement(ewsTypeNsUri, QStringLiteral("EventType"), eventTypeNames[type]);
    }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsFetchFoldersIncrJob *>(job);
```

#### AUTO 


```{c}
auto *retrieveJob = qobject_cast<RetrieveItemsJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attendee &attendee : attendees) {
            const User user = Users::self()->lookupEmail(attendee.email());

            if (!user.isValid()) {
                continue;
            }

            QString status;
            switch (attendee.status()) {
            case KCalendarCore::Attendee::Accepted:
                status = QStringLiteral("accept");
                break;
            case KCalendarCore::Attendee::Declined:
                status = QStringLiteral("decline");
                break;
            default:
                status = QStringLiteral("none");
                break;
            }

            QDomElement element = DAVUtils::addOxElement(document, members, QStringLiteral("user"), OXUtils::writeNumber(user.uid()));
            DAVUtils::setOxAttribute(element, QStringLiteral("confirm"), status);
        }
```

#### AUTO 


```{c}
auto dialog = new SubscriptionDialog();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        const EwsItem &ewsItem = resp.item();
        KMime::Message::Ptr msg(new KMime::Message);

        // Rebuild the message headers
        QVariant v = ewsItem[EwsItemFieldSubject];
        if (Q_LIKELY(v.isValid())) {
            msg->subject()->fromUnicodeString(v.toString(), "utf-8");
        }

        v = ewsItem[EwsItemFieldFrom];
        if (Q_LIKELY(v.isValid())) {
            const auto mbox = v.value<EwsMailbox>();
            msg->from()->addAddress(mbox);
        }

        v = ewsItem[EwsItemFieldToRecipients];
        if (Q_LIKELY(v.isValid())) {
            const auto mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->to()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldCcRecipients];
        if (Q_LIKELY(v.isValid())) {
            const auto mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->cc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldBccRecipients];
        if (v.isValid()) {
            const auto mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->bcc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldInternetMessageId];
        if (v.isValid()) {
            msg->messageID()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldInReplyTo];
        if (v.isValid()) {
            msg->inReplyTo()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldDateTimeReceived];
        if (v.isValid()) {
            msg->date()->setDateTime(v.toDateTime());
        }

        v = ewsItem[EwsItemFieldReferences];
        if (v.isValid()) {
            msg->references()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldReplyTo];
        if (v.isValid()) {
            const auto mbox = v.value<EwsMailbox>();
            msg->replyTo()->addAddress(mbox);
        }

        msg->assemble();
        item.setPayload(KMime::Message::Ptr(msg));

        v = ewsItem[EwsItemFieldSize];
        if (v.isValid()) {
            item.setSize(v.toUInt());
        }

        // Workaround for Akonadi bug
        // When setting flags, adding each of them separately vs. setting a list in one go makes
        // a difference. In the former case the item treats this as an incremental change and
        // records flags added and removed. In the latter it sets a flag indicating that flags were
        // reset.
        // For some strange reason Akonadi is not seeing the flags in the latter case.
        Q_FOREACH (const QByteArray &flag, EwsMailHandler::readFlags(ewsItem)) {
            item.setFlag(flag);
        }
        qCDebugNC(EWSRES_LOG) << "EwsFetchMailDetailJob::processItems:" << ewsHash(item.remoteId()) << item.flags();

        ++it;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::ContactGroup::ContactReference &ref : std::as_const(toAdd)) {
            contactGroup.append(ref);
        }
```

#### AUTO 


```{c}
auto job = new FileStore::ItemCreateJob(item, collection, d->mSession);
```

#### AUTO 


```{c}
auto responses = respGetFn(req);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const QString kmailInterface = QStringLiteral("org.kde.kmail");
        QDBusInterface kmail(kmailInterface, QStringLiteral("/KMail"), QStringLiteral("org.kde.kmail.kmail"));
        if (kmail.isValid()) {
            kmail.call(QStringLiteral("showMail"), mId);
        } else {
            qCWarning(NEWMAILNOTIFIER_LOG) << "Impossible to access to DBus interface";
        }
        emitResult();
    }
```

#### AUTO 


```{c}
auto resp = new EwsFindFolderResponse(reader);
```

#### AUTO 


```{c}
auto job = new FileStore::CollectionMoveJob(collection, targetParent, d->mSession);
```

#### AUTO 


```{c}
auto login = new KIMAP::LoginJob(m_session);
```

#### AUTO 


```{c}
auto *errorAttribute = new ErrorAttribute(mMessage);
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::string &member : members) {
                    d->mTagMembers << Conversion::fromStdString(member);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &val : results) {
        if (val.first == "UIDNEXT") {
            m_nextUid = val.second;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : events) {
                    processEvent(event);
                }
```

#### AUTO 


```{c}
const auto item
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenJob]() {
        if (tokenJob->error()) {
            emitError(tokenJob->errorText());
            return;
        }

        // Convert the cookies into a HTTP Cookie header that we can pass
        // to KIO
        mCookies = QStringLiteral("Cookie: ");
        const auto parsedCookies = QNetworkCookie::parseCookies(tokenJob->cookies());
        for (const auto &cookie : parsedCookies) {
            mCookies += QStringLiteral("%1=%2; ").arg(QString::fromUtf8(cookie.name()), QString::fromUtf8(cookie.value()));
        }
        fetchFacebookEventsPage();
    }
```

#### AUTO 


```{c}
const auto flags{item.flags()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::ContactGroup::ContactReference &ref : qAsConst(toAdd)) {
        gidOnlyContactGroup.append(ref);
    }
```

#### AUTO 


```{c}
auto j = new Akonadi::ItemModifyJob(updatedItem);
```

#### AUTO 


```{c}
auto *imapQuotaAttribute
        = m_collection.attribute<Akonadi::ImapQuotaAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto usernameReply = dBusSetAndWaitReply<QString>(std::bind(&OrgKdeAkonadiEwsSettingsInterface::setUsername, mEwsSettingsInterface.data(), username),
                                                            std::bind(&OrgKdeAkonadiEwsSettingsInterface::username, mEwsSettingsInterface.data()),
                                                            QStringLiteral("Username"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate &dt : recRDates) {
        rdates.push_back(fromDate(QDateTime(dt, {}), true));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            emitError(job->errorText());
            return;
        }

        auto cal = KCalendarCore::MemoryCalendar::Ptr::create(QTimeZone::systemTimeZone());
        KCalendarCore::ICalFormat format;
        if (!format.fromRawString(cal, job->data(), false)) {
            emitError(i18n("Failed to parse birthday calendar"));
            return;
        }

        const auto events = cal->events();
        for (const auto &event : events) {
            processEvent(event);
        }

        emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item::Flag &flag : flags) {
        item.setFlag(flag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : qAsConst(mDeletedItemOffsets)) {
        serialized += QByteArray::number(offset) + ',';
    }
```

#### AUTO 


```{c}
auto deleteJob = qobject_cast<FileStore::CollectionDeleteJob *>(job);
```

#### AUTO 


```{c}
auto *job = new FileStore::CollectionFetchJob(collection, type, d->mSession);
```

#### AUTO 


```{c}
auto *job = new EwsFetchFoldersIncrJob(mEwsClient, mFolderSyncState,
                                                                 mRootCollection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : itemsMarkedAsDeleted) {
        deleteJob = mStore->deleteItem(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KWallet::MyWallet *) {
        return nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::ImapInterval &interval : lstInterval) {
        for (qint64 i = interval.begin(), end = interval.end(); i <= end; ++i) {
            list << i;
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::CreateJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {emitStatusReady();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &desc : std::as_const(mSharedNamespace)) {
            toplevelMailboxes << desc.name;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item & left, const Akonadi::Item & right) {
        return left.parentCollection().remoteId().compare(right.parentCollection().remoteId()) < 0 ||
               (left.parentCollection().remoteId() == right.parentCollection().remoteId() && changedOffset(left) < changedOffset(right));
    }
```

#### AUTO 


```{c}
auto usersJob = new UsersRequestJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob* job) {localFoldersRequestResult(job);}
```

#### AUTO 


```{c}
const auto &zone
```

#### AUTO 


```{c}
auto it = firstId;
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        Q_EMIT status(Akonadi::AgentBase::Idle, QString());
    }
```

#### AUTO 


```{c}
auto job = new OXA::ObjectModifyJob(object, this);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsCreateItemRequest *>(job);
```

#### AUTO 


```{c}
const auto queueEmpty = mFetchItemsJobQueue.empty();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : attachments) {
        QByteArray type;
        KMime::Content *content = Mime::findContentByName(mimeData, name, type);
        if (!content) { // guard against malformed events with non-existent attachments
            qCWarning(PIMKOLAB_LOG) <<"could not find attachment: "<< name.toUtf8() << type;
            continue;
        }
        const QByteArray c = content->decodedContent().toBase64();
        KCalCore::Attachment attachment(c, QString::fromLatin1(type));
        attachment.setLabel(name);
        incidence->addAttachment(attachment);
        qCDebug(PIMKOLAB_LOG) << "ATTACHMENT NAME" << name << type;
    }
```

#### AUTO 


```{c}
auto *job = new KIMAP::SetAclJob(session);
```

#### AUTO 


```{c}
auto *attr = new ImapAclAttribute(mRights, mOldRights);
```

#### AUTO 


```{c}
auto propTypeText = attrs.value(QStringLiteral("PropertyType"));
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(mRootCollection, CollectionFetchJob::Recursive, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item) {
        itemRemoved(item);
    }
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyItemsDownloadJob *>(kjob);
```

#### AUTO 


```{c}
auto job = new JournalsFetchJob(mClientState.get(), mRootCollection, this);
```

#### AUTO 


```{c}
const auto eAlarms{e.alarms()};
```

#### AUTO 


```{c}
auto task = new RetrieveItemsTask(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &oldFlag : flags) {
        if (oldFlag == ImapFlags::Seen) {
            newFlags.insert(Akonadi::MessageFlags::Seen);
        } else if (oldFlag == ImapFlags::Deleted) {
            newFlags.insert(Akonadi::MessageFlags::Deleted);
        } else if (oldFlag == ImapFlags::Answered) {
            newFlags.insert(Akonadi::MessageFlags::Answered);
        } else if (oldFlag == ImapFlags::Flagged) {
            newFlags.insert(Akonadi::MessageFlags::Flagged);
        } else if (oldFlag.isEmpty()) {
            // filter out empty flags, to avoid isNull/isEmpty confusions higher up
            continue;
        } else {
            newFlags.insert(oldFlag);
        }
    }
```

#### AUTO 


```{c}
auto deleteJob = new KIMAP::DeleteJob(mSession);
```

#### AUTO 


```{c}
auto it = std::find_if(items.cbegin(), items.cend(), [&contact](const Item &item){
            return item.remoteId() == contact->uid();
        });
```

#### AUTO 


```{c}
auto conn = connect(AgentManager::self(), &AgentManager::instanceOnline, this,
                            [&](const AgentInstance &instance, bool state) {
            if (instance == *mEwsInstance && state == online) {
                qDebug() << "is online" << state;
                loop.exit(0);
            }
        }, Qt::QueuedConnection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsUpdateItemRequest::Response &resp : responses) {
        if (!resp.isSuccess()) {
            setErrorText(QStringLiteral("Item update failed: ") + resp.responseMessage());
            emitResult();
            return;
        }

        it->setRemoteRevision(resp.itemId().changeKey());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &email : std::as_const(mListEmails)) {
            if (mFrom.contains(email)) {
                // Exclude this notification
                deleteLater();
                return;
            }
        }
```

#### AUTO 


```{c}
auto j = new Akonadi::ItemModifyJob(extraItems);
```

#### AUTO 


```{c}
auto listJob = qobject_cast<ListJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&oAuth, &events, password](bool) {
        events.append(QStringLiteral("RequestWalletPassword"));
        oAuth.walletPasswordRequestFinished(password);
    }
```

#### AUTO 


```{c}
const auto baseUrlReply = dBusSetAndWaitReply<QString>(std::bind(&OrgKdeAkonadiEwsSettingsInterface::setBaseUrl, mEwsSettingsInterface.data(), url),
                                                           std::bind(&OrgKdeAkonadiEwsSettingsInterface::baseUrl, mEwsSettingsInterface.data()),
                                                           QStringLiteral("Base URL"));
```

#### AUTO 


```{c}
auto createJob = qobject_cast<FileStore::ItemCreateJob *>(job);
```

#### AUTO 


```{c}
auto attr = col.attribute<HighestModSeqAttribute>();
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(mRootCollection, CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto account = KGAPI2::AccountPtr::create();
```

#### AUTO 


```{c}
auto *attr3 = new CollectionAnnotationsAttribute();
```

#### AUTO 


```{c}
auto fetchJob = static_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
const auto jobs{subjobs()};
```

#### LAMBDA EXPRESSION 


```{c}
[this](FakeTransferJob *job, const QByteArray &req) {
        verifier(job, req, request, response);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : std::as_const(m_taskList)) {
        task->kill();
    }
```

#### AUTO 


```{c}
const auto stdVectorByHours = std::vector<int>(byHoursVector.begin(), byHoursVector.end());
```

#### AUTO 


```{c}
auto *idJob = new KIMAP::IdJob(capJob->session());
```

#### AUTO 


```{c}
const auto result = etesync_journal_manager_update(mClientState->journalManager(), journal.get());
```

#### AUTO 


```{c}
auto wallet = new MyWallet();
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &instance]() {
                qCDebug(MIGRATION_LOG) << "GoogleResourceMigrator: resource" << instance.identifier() << "has disappeared from DBus";
                loop.quit();
            }
```

#### AUTO 


```{c}
auto modJob = new Akonadi::ItemModifyJob(mItem, this);
```

#### AUTO 


```{c}
auto err = page->lastCeritificateError()
```

#### AUTO 


```{c}
auto *fetchJob = new KDAV::DavItemFetchJob(davItem);
```

#### AUTO 


```{c}
const auto calendarSettings = settingsForResource(oldInstances.calendarResource);
```

#### AUTO 


```{c}
const auto updated = mUpdatedFolderIds.values();
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMailbox &mbox : mboxList) {
                msg->cc()->addAddress(mbox);
            }
```

#### AUTO 


```{c}
auto *req = new EwsUpdateItemRequest(mClient, this);
```

#### AUTO 


```{c}
auto resp = new EwsSyncFolderHierarchyRequest::Response(reader);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Event::Ptr &event : qAsConst(list)) {
        //We have to filter the list by time
        if (event->dtEnd() >= s && e >= event->dtStart()) {
            eventlist.push_back(Kolab::Conversion::fromKCalCore(*event));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(toplevelMailboxes)) {
            auto *meta = new KIMAP::GetMetaDataJob(mSession);
            meta->setMailBox(mailbox + QLatin1String("*"));
            if (mServerCapabilities.contains(QLatin1String("METADATA"))) {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Metadata);
            } else {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Annotatemore);
            }
            meta->setDepth(KIMAP::GetMetaDataJob::AllLevels);
            for (const QByteArray &requestedEntry : qAsConst(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
            connect(meta, &KJob::result, this, &RetrieveMetadataJob::onGetMetaDataDone);
            mJobs++;
            meta->start();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            error(QStringLiteral("User cancellation"), QStringLiteral("The authentication browser was closed"), QUrl());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : certs.certificates()) {
        if (c.issuerInfo() == authoritiesInfo) {
            cert = c;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource,
                                                                  mResourceId);
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : intList) {
        idList += QString::number(id) + QLatin1Char(',');
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavItem &davItem : listJobChangedItems) {
        seenRids.insert(davItem.url().toDisplayString());

        Akonadi::Item item;
        item.setParentCollection(collection);
        item.setRemoteId(davItem.url().toDisplayString());
        item.setMimeType(davItem.contentType());
        item.setRemoteRevision(davItem.etag());

        cache->markAsChanged(item.remoteId());
        changedRids << item.remoteId();
        changedItems << item;

        // Only clear the payload (and therefore trigger a refetch from the backend) if we
        // do not use multiget, because in this case we fetch the complete payload
        // some lines below already.
        if (!protocolSupportsMultiget) {
            qCDebug(DAVRESOURCE_LOG) << "Outdated item " << item.remoteId() << " (etag = " << davItem.etag() << ")";
            item.clearPayload();
        }
    }
```

#### AUTO 


```{c}
const auto *sentBehaviourAttribute = item.attribute<SentBehaviourAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : jobs) {
        job->kill(KJob::Quietly);
    }
```

#### AUTO 


```{c}
auto deleteJob = new DeletePasswordJob(QStringLiteral("pop3"));
```

#### AUTO 


```{c}
auto v = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto service = KService::serviceByDesktopName(QStringLiteral("org.kde.kmail2"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QMap<QString, QString> &map) {
                                      map[accessTokenMapKey] = QStringLiteral("afoo");
                                      map[refreshTokenMapKey] = QStringLiteral("rfoo");
                                      return true;
                                  }
```

#### AUTO 


```{c}
const auto recRDates{rec->rDates()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : calendars) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection
                                 |Collection::CanCreateItem
                                 |Collection::CanChangeItem
                                 |Collection::CanDeleteItem);
        } else {
            collection.setRights(nullptr);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        auto colorAttr = collection.attribute<CollectionColorAttribute>(Collection::AddIfMissing);
        colorAttr->setColor(calendar->backgroundColor());

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsFetchFoldersJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &instance]() {
            qCDebug(MIGRATION_LOG) << "GoogleResourceMigrator: resource" << instance.identifier() << "has disappeared from DBus";
            loop.quit();
        }
```

#### AUTO 


```{c}
const auto response = QStringLiteral(
                                          "HTTP/1.1 200 OK\n\n<!DOCTYPE html>\n<html><body><p>You will be redirected "
                                          "shortly.</p><script>window.location.href=\"%1\";</script></body></html>\n")
                                          .arg(mPKeyAuthSubmitUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : collections) {
            const Collection::Id id = collection.id();
            if (!mSynchronizedCollections.contains(id) && !mPendingSynchronizeCollections.contains(id)) {
                qCDebug(MIXEDMAILDIR_LOG) << "Requesting sync of collection" << collection.name()
                                          << ", id=" << collection.id();
                mPendingSynchronizeCollections << id;
                synchronizeCollection(id);
            }
        }
```

#### AUTO 


```{c}
auto const fetchJob = qobject_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
const auto changedItems = detailJob->changedItems();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        Q_ASSERT(QThread::currentThread() != qApp->thread());
        mProtocol->closeConnection();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &left, const Akonadi::Item &right) {
        return left.parentCollection().remoteId().compare(right.parentCollection().remoteId()) < 0
            || (left.parentCollection().remoteId() == right.parentCollection().remoteId() && changedOffset(left) < changedOffset(right));
    }
```

#### AUTO 


```{c}
auto removedItem = job->property("removedItem").value<Akonadi::Item>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReminderPtr &rem : std::as_const(m_reminders)) {
        QVariantMap reminder;

        if (rem->type() == KCalendarCore::Alarm::Display) {
            reminder[QStringLiteral("type")] = QLatin1String("display");
        } else if (rem->type() == KCalendarCore::Alarm::Email) {
            reminder[QStringLiteral("type")] = QLatin1String("email");
        }

        reminder[QStringLiteral("time")] = rem->startOffset().asSeconds();

        list << reminder;
    }
```

#### AUTO 


```{c}
auto handler = fetchHandlerForCollection(collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::AgentInstance agent : instances) {
        agent.setIsOnline(false);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collection](const Item &item){
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        contact->addGroup(collection.remoteId());
        return contact;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        ContactPtr contact = qobject_cast<ContactCreateJob *>(job)->items().first().dynamicCast<Contact>();
        Item newItem = item;
        qCDebug(GOOGLE_CONTACTS_LOG) << "Contact" << contact->uid() << "created";
        newItem.setRemoteId(contact->uid());
        newItem.setRemoteRevision(contact->etag());
        m_iface->itemChangeCommitted(newItem);
        newItem.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
        new ItemModifyJob(newItem, this);
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
auto tokenJob = qobject_cast<GetTokenJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                    slotSentMailCollectionFetched(job);
                }
```

#### AUTO 


```{c}
const auto type = tokens.size() == 1 ? tokens[0] : tokens[1];
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entries) {
        const quint64 indexOffset = entry.messageOffset() + entry.separatorSize();
        const KMIndexDataPtr data = indexReader.dataByOffset(indexOffset);
        if (data != nullptr) {
            mIndexData.insert(entry.messageOffset(), data);
        }
    }
```

#### AUTO 


```{c}
const auto tags{mItem.tags()};
```

#### AUTO 


```{c}
auto *nsJob = new KIMAP::NamespaceJob(capJob->session());
```

#### AUTO 


```{c}
auto *session = sessionSpy.at(0).at(1).value<KIMAP::Session *>();
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned int tokenLifetime = 86399;
```

#### AUTO 


```{c}
auto dlg = new QDialog(this);
```

#### AUTO 


```{c}
auto *filterBarLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const FolderChange &ch : std::as_const(mChanges)) {
        ch.write(writer);
    }
```

#### AUTO 


```{c}
auto job = new LoginJob(mClientState, serverUrl, username, password, this);
```

#### AUTO 


```{c}
auto conn = connect(
            AgentManager::self(),
            &AgentManager::instanceOnline,
            this,
            [&](const AgentInstance &instance, bool state) {
                if (instance == *mEwsInstance && state == online) {
                    qDebug() << "is online" << state;
                    loop.exit(0);
                }
            },
            Qt::QueuedConnection);
```

#### AUTO 


```{c}
auto conn = connect(AgentManager::self(), &AgentManager::instanceOnline, this,
                [&](const AgentInstance &instance, bool state) {
            if (instance == *mEwsInstance && state == online) {
                qDebug() << "is online" << state;
                loop.exit(0);
            }
        }, Qt::QueuedConnection);
```

#### AUTO 


```{c}
auto job = new ItemDeleteJob(Item::fromUrl(url));
```

#### AUTO 


```{c}
auto *attribute = item.attribute<FileStore::EntityCompactChangeAttribute>();
```

#### AUTO 


```{c}
const auto &object
```

#### AUTO 


```{c}
auto *modJob = new Akonadi::TagModifyJob(updateTag);
```

#### AUTO 


```{c}
const auto itemsMarkedAsDeleted{retrieveJob->itemsMarkedAsDeleted()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : parameters.keys()) {
        if (first) {
            first = false;
        } else {
            body.append("&");
        }
        QString value = parameters.value(key);
        body.append(QUrl::toPercentEncoding(key) + QStringLiteral("=").toUtf8() + QUrl::toPercentEncoding(value));
    }
```

#### AUTO 


```{c}
auto itemReq = qobject_cast<EwsSyncFolderItemsRequest *>(job);
```

#### AUTO 


```{c}
auto *CTagAttr = collection.attribute<CTagAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Event &event : result) {
        qDebug() << QTest::toString(event.start()) << QTest::toString(event.end());
    }
```

#### AUTO 


```{c}
auto otherJob = job->property(JOB_PROPERTY).value<KGAPI2::Job *>();
```

#### AUTO 


```{c}
auto it = mCookies.cbegin(), end = mCookies.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : qAsConst(collections)) {
        compactedCollections.insert(col.remoteId(), col);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                transactionResult(job);
            }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { processNextBatch(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(randomList1)) {
        Item item1;
        item1.setId(KRandom::random());
        item1.setRemoteId(entry);
        item1.setParentCollection(collection1);

        job = mStore->fetchItem(item1);
        job->fetchScope().fetchPayloadPart(MessagePart::Header);

        spy = new QSignalSpy(job, &FileStore::ItemFetchJob::itemsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        items = job->items();
        QCOMPARE((int)items.count(), 1);
        QCOMPARE(itemsFromSpy(spy), items);

        Item item = items.first();
        QCOMPARE(item, item1);
        QVERIFY(item.hasPayload<KMime::Message::Ptr>());

        KMime::Message::Ptr msgPtr = item.payload<KMime::Message::Ptr>();
        QVERIFY(msgPtr != 0);

        const QSet<QByteArray> parts = messageParts(msgPtr);
        QVERIFY(!parts.isEmpty());
        QVERIFY(parts.contains(MessagePart::Header));
        QVERIFY(!parts.contains(MessagePart::Body));
    }
```

#### AUTO 


```{c}
auto event = KCalCore::Event::Ptr::create();
```

#### AUTO 


```{c}
auto tagCreateJob = new Akonadi::TagCreateJob(Akonadi::Tag(categoryToCheck), this);
```

#### AUTO 


```{c}
auto flags = CryptoFlags(ba.at(1));
```

#### AUTO 


```{c}
auto *attr1 = new CollectionAnnotationsAttribute();
```

#### AUTO 


```{c}
auto &contact = *it;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : lstKeys) {
        if (mMailCollections.contains(mailbox)) {
            const KIMAP::Acl::Rights imapRights = rights.value(mailbox);
            QStringList parts = mailbox.split(separatorCharacter());
            parts.removeLast();
            QString parentMailbox = parts.join(separatorCharacter());

            KIMAP::Acl::Rights parentImapRights;
            //If the parent folder is not existing we cant rename
            if (!parentMailbox.isEmpty() && rights.contains(parentMailbox)) {
                parentImapRights = rights.value(parentMailbox);
            }
            // qCDebug(KOLABRESOURCE_LOG) << mailbox << parentMailbox << imapRights << parentImapRights;

            Akonadi::Collection &collection = mMailCollections[mailbox];
            CollectionMetadataHelper::applyRights(collection, imapRights, parentImapRights);

            // Store the mailbox ACLs
            Akonadi::ImapAclAttribute *aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
            const KIMAP::Acl::Rights oldRights = aclAttribute->myRights();
            if (oldRights != imapRights) {
                aclAttribute->setMyRights(imapRights);
            }
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Can't find mailbox " << mailbox;
        }
    }
```

#### AUTO 


```{c}
auto collection = job->property(COLLECTION_PROPERTY).value<Collection>();
```

#### AUTO 


```{c}
auto task =
        new KolabChangeItemsTagsTask(createResourceState(TaskArguments(items, addedTags, removedTags)), QSharedPointer<TagConverter>(new TagConverter), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDate &i : l) {
        ba += i.toString().toLatin1();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned int extTokenLifetime = 345599;
```

#### AUTO 


```{c}
auto job = new TagFetchJob(this);
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionModifyJob(collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Row> &row : std::as_const(mMigrators)) {
        migrators << row->mMigrator;
    }
```

#### AUTO 


```{c}
auto subscribeJob = new KIMAP::SubscribeJob(renameJob->session());
```

#### LAMBDA EXPRESSION 


```{c}
[&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return false;
                                    }
```

#### AUTO 


```{c}
auto req = new EwsDeleteItemRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(item, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : qAsConst(entryList)) {
        // TODO: Use cache policy to see what actually has to been set as payload.
        //       Currently most views need a minimal amount of information so the
        //       Items get Envelopes as payload.
        auto *mail = new KMime::Message();
        mail->setHead(KMime::CRLFtoLF(mMBox->readMessageHeaders(entry)));
        mail->parse();

        Item item;
        item.setRemoteId(colId + QLatin1String("::") + colRid + QLatin1String("::") + QString::number(entry.messageOffset()));
        item.setMimeType(QStringLiteral("message/rfc822"));
        item.setSize(entry.messageSize());
        item.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, item);
        Q_EMIT percent(count++ / entryListSize);
        items << item;
    }
```

#### AUTO 


```{c}
auto req = new EwsGetStreamingEventsRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto select = qobject_cast<KIMAP::SelectJob *>(job);
```

#### AUTO 


```{c}
const auto col
```

#### AUTO 


```{c}
auto job = new TagFetchJob(unknownTags, this);
```

#### AUTO 


```{c}
static const auto KWalletKeyId = QStringLiteral("id");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto it : items) {
            tokens.insert(it.first, it.second);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsPropertyField &field : flagsProperties) {
        shape << field;
    }
```

#### AUTO 


```{c}
auto *status = new KIMAP::StatusJob(m_session);
```

#### AUTO 


```{c}
auto *otherJob = job->property(JOB_PROPERTY).value<KGAPI2::Job *>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
                if (job->error()) {
                    emitError(i18n("Failed to retrieve birthday calendar"));
                    return;
                }

                auto url = findBirthdayIcalLink(job->data());
                if (url.isEmpty()) {
                    emitError(i18n("Failed to retrieve birthday calendar"));
                    return;
                }
                // switch webcal scheme for https so we can fetch it with KIO
                url.setScheme(QStringLiteral("https"));
                fetchBirthdayIcal(url);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : serverSubscriptionList) {
            ids << EwsId(id);
        }
```

#### AUTO 


```{c}
auto *attr = col.attribute<Akonadi::CollectionAnnotationsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto mails{e.emails()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &day : days) {
        short dowIndex = decodeEnumString<short>(day, dayOfWeekNames, dayOfWeekNameCount, &ok);
        if (reader.error() != QXmlStreamReader::NoError || !ok) {
            qCWarning(EWSCLI_LOG) << QStringLiteral("Failed to read EWS request - invalid %1 element (value: %2).")
                                  .arg(QStringLiteral("DaysOfWeek").arg(day));
            return false;
        }
        if (dowIndex == 7) { // "Day"
            dow.fill(true, 0, 7);
        } else if (dowIndex == 8) { // "Weekday"
            dow.fill(true, 0, 5);
        } else if (dowIndex == 9) { // "WeekendDay"
            dow.fill(true, 5, 7);
        } else {
            dow.setBit(dowIndex);
        }
    }
```

#### AUTO 


```{c}
auto *attribute = trash.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &addressee : std::as_const(mAddressees)) {
        Item item;
        item.setRemoteId(addressee.uid());
        item.setMimeType(KContacts::Addressee::mimeType());
        items.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Freebusy &fb : fbList) {
        const QDateTime &tmpStart = Kolab::Conversion::toDate(fb.start());
        if (!start.isValid() || tmpStart < start) {
            start = tmpStart;
            allDay |= fb.start().isDateOnly();
        }
        const QDateTime &tmpEnd = Kolab::Conversion::toDate(fb.end());
        if (!end.isValid() || tmpEnd > end) {
            end = tmpEnd;
            allDay |= fb.start().isDateOnly();
        }

        Q_FOREACH (const Kolab::FreebusyPeriod &period, fb.periods()) {
            Kolab::FreebusyPeriod simplifiedPeriod;
            simplifiedPeriod.setPeriods(period.periods());
            simplifiedPeriod.setType(period.type());
            if (!simple) { //Don't copy and reset to avoid unintentional information leaking into simple lists
                simplifiedPeriod.setEvent(period.eventSummary(), period.eventUid(), period.eventLocation());
            }
            periods.push_back(simplifiedPeriod);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const ContactPtr contact = object.dynamicCast<Contact>();

        Item item;
        item.setMimeType(mimeType());
        item.setParentCollection(collection);
        item.setRemoteId(contact->uid());
        item.setRemoteRevision(contact->etag());
        item.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());

        if (contact->deleted() || (collection.remoteId() == OTHERCONTACTS_REMOTEID && !contact->groups().isEmpty())
            || (collection.remoteId() == myContactsRemoteId() && contact->groups().isEmpty())) {
            qCDebug(GOOGLE_CONTACTS_LOG) << " - removed" << contact->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_CONTACTS_LOG) << " - changed" << contact->uid();
            changedItems << item;
            changedPhotos << contact->uid();
        }

        const QStringList groups = contact->groups();
        for (const QString &group : groups) {
            // We don't link contacts to "My Contacts"
            if (group != myContactsRemoteId()) {
                groupsMap[group] << item;
            }
        }
    }
```

#### AUTO 


```{c}
auto attr2 = new CollectionAnnotationsAttribute();
```

#### AUTO 


```{c}
auto *job = qobject_cast<ReadPasswordJob *>(baseJob);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : storedItems) {
        // messages marked as deleted have been deleted from mbox files but never got purged
        Akonadi::MessageStatus status;
        status.setStatusFromFlags(item.flags());
        if (status.isDeleted()) {
            mItemsMarkedAsDeleted << item;
            continue;
        }

        mAvailableItems << item;

        const QHash<QString, Item>::iterator it = mServerItemsByRemoteId.find(item.remoteId());
        if (it == mServerItemsByRemoteId.end()) {
            // item not in server items -> new
            mNewItems << item;
        } else {
            // item both on server and in store, check modification time
            const QDateTime modTime = item.modificationTime();
            if (!modTime.isValid() || modTime.toMSecsSinceEpoch() > collectionTimestamp) {
                mChangedItems << it.value();
            }

            // remove from hash so only no longer existing items remain
            mServerItemsByRemoteId.erase(it);
        }
    }
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectModifyJob(object, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &dependentItem : std::as_const(dependentItems)) {
            calendar->addIncidence(dependentItem.payload<IncidencePtr>());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : std::as_const(response)) {
                extraTokens.insert(key, response.value(key));
            }
```

#### AUTO 


```{c}
auto attr = col.attribute<SpecialCollectionAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            localFoldersRequestResult(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : query.queryItems()) {
        params[it.first.toLower()] = QUrl::fromPercentEncoding(it.second.toAscii());
    }
```

#### AUTO 


```{c}
auto attr3 = new CollectionAnnotationsAttribute();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Alarm::Ptr &a : std::as_const(mAlarms)) {
        QDomElement e = list.ownerDocument().createElement(QStringLiteral("alarm"));
        list.appendChild(e);

        writeString(e, QStringLiteral("enabled"), a->enabled() ? QStringLiteral("1") : QStringLiteral("0"));
        if (a->hasStartOffset()) {
            writeString(e, QStringLiteral("start-offset"), QString::number(a->startOffset().asSeconds() / 60));
        }
        if (a->hasEndOffset()) {
            writeString(e, QStringLiteral("end-offset"), QString::number(a->endOffset().asSeconds() / 60));
        }
        if (a->repeatCount()) {
            writeString(e, QStringLiteral("repeat-count"), QString::number(a->repeatCount()));
            writeString(e, QStringLiteral("repeat-interval"), QString::number(a->snoozeTime().asSeconds()));
        }

        switch (a->type()) {
        case KCalendarCore::Alarm::Invalid:
            break;
        case KCalendarCore::Alarm::Display:
            e.setAttribute(QStringLiteral("type"), QStringLiteral("display"));
            writeString(e, QStringLiteral("text"), a->text());
            break;
        case KCalendarCore::Alarm::Procedure:
            e.setAttribute(QStringLiteral("type"), QStringLiteral("procedure"));
            writeString(e, QStringLiteral("program"), a->programFile());
            writeString(e, QStringLiteral("arguments"), a->programArguments());
            break;
        case KCalendarCore::Alarm::Email: {
            e.setAttribute(QStringLiteral("type"), QStringLiteral("email"));
            QDomElement addresses = e.ownerDocument().createElement(QStringLiteral("addresses"));
            e.appendChild(addresses);
            const auto mailAddresses{a->mailAddresses()};
            for (const KCalendarCore::Person &person : mailAddresses) {
                writeString(addresses, QStringLiteral("address"), person.fullName());
            }
            writeString(e, QStringLiteral("subject"), a->mailSubject());
            writeString(e, QStringLiteral("mail-text"), a->mailText());
            QDomElement attachments = e.ownerDocument().createElement(QStringLiteral("attachments"));
            e.appendChild(attachments);
            const auto mailAttachments{a->mailAttachments()};
            for (const QString &attachment : mailAttachments) {
                writeString(attachments, QStringLiteral("attachment"), attachment);
            }
            break;
        }
        case KCalendarCore::Alarm::Audio:
            e.setAttribute(QStringLiteral("type"), QStringLiteral("audio"));
            writeString(e, QStringLiteral("file"), a->audioFile());
            break;
        default:
            qCWarning(PIMKOLAB_LOG) << "Unhandled alarm type:" << a->type();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : std::as_const(mFlags)) {
        result += flag + ' ';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        itemHash.insert(item.remoteId(), item);
    }
```

#### AUTO 


```{c}
auto *imapCreateJob = new KIMAP::CreateJob(mImapSession);
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &instance]() {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: timeout while waiting for resource" << instance.identifier() << "to be removed";
            loop.quit();
        }
```

#### AUTO 


```{c}
const auto tag = job->property("tag").value<Akonadi::Tag>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {return parseNotificationsResponse(reader);}
```

#### AUTO 


```{c}
const auto collections = req->property("collections").value<Collection::List>();
```

#### AUTO 


```{c}
auto collectionCreateJob = qobject_cast<CollectionCreateJob *>(job);
```

#### AUTO 


```{c}
auto attachMessage = new KMime::Content;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob * job) {
        if (job->error()) {
            qCWarningNC(EWSRES_LOG) << "Special folders fetch failed:" << job->errorString();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &req, QXmlResultItems &, const QXmlNamePool &) {
        qDebug() << "Unknown EWS request encountered." << req;
        unknownRequestEncountered = true;
        return FakeEwsServer::EmptyResponse;
    }
```

#### AUTO 


```{c}
auto attribute = c.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            auto item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }
```

#### AUTO 


```{c}
const auto *attr = collection.attribute<EntityDisplayAttribute>()
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : std::as_const(m_taskList)) {
        delete task;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attribute *attr : attrs) {
        stream << attr->type();
        stream << attr->serialized();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&loop](bool ok) {
            loop.exit(ok ? 1 : 0);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            qCWarningNC(EWSRES_LOG) << "Special folders fetch failed:" << job->errorString();
        }
    }
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<OXA::FoldersRequestDeltaJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[=, &tokenReplyData](QString &data, QMap<Mock::QNetworkRequest::KnownHeaders, QVariant> &headers) {
        QVariantMap map;
        map[QStringLiteral("token_type")] = QStringLiteral("Bearer");
        map[QStringLiteral("scope")] = QStringLiteral("ReadWrite.All");
        map[QStringLiteral("expires_in")] = QString::number(tokenLifetime);
        map[QStringLiteral("ext_expires_in")] = QString::number(extTokenLifetime);
        map[QStringLiteral("expires_on")] = QString::number(time + tokenLifetime);
        map[QStringLiteral("not_before")] = QString::number(time);
        map[QStringLiteral("resource")] = resource;
        map[QStringLiteral("access_token")] = accessToken;
        map[QStringLiteral("refresh_token")] = refreshToken;
        map[QStringLiteral("foci")] = QStringLiteral("1");
        map[QStringLiteral("id_token")] = idToken;
        tokenReplyData = formatJsonSorted(map);
        data = tokenReplyData;
        headers[Mock::QNetworkRequest::ContentTypeHeader] = QStringLiteral("application/json; charset=utf-8");

        return Mock::QNetworkReply::NoError;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavUrl &url : urls) {
        if (url.protocol() == KDAV::CalDav) {
            ++mRequestsTracker[email].handlingJobCount;
            auto job = new KDAV::DavPrincipalSearchJob(url, KDAV::DavPrincipalSearchJob::EmailAddress, email);
            job->setProperty("email", QVariant::fromValue(email));
            job->setProperty("url", QVariant::fromValue(url.url().toString()));
            job->fetchProperty(QStringLiteral("schedule-inbox-URL"), QStringLiteral("urn:ietf:params:xml:ns:caldav"));
            connect(job, &KDAV::DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onPrincipalSearchJobFinished);
            job->start();
        }
    }
```

#### AUTO 


```{c}
auto colJob = qobject_cast<FileStore::CollectionCreateJob *>(job);
```

#### AUTO 


```{c}
auto job = new GetTokenJob(identifier(), this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(collection);
```

#### AUTO 


```{c}
const auto rDateTimes{rec->rDateTimes()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sub : lstDir) {
        Collection c;
        c.setName(sub);
        c.setRemoteId(sub);
        c.setParentCollection(root);
        c.setContentMimeTypes(mimeTypes);

        const Maildir md = maildirForCollection(c);
        if (!md.isValid()) {
            continue;
        }

        list << c;
        list += listRecursive(c, md);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collectionSource, &collectionDestination](const Item &item) {
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        // MyContacts -> OtherContacts
        if (collectionSource.remoteId() == myContactsRemoteId() && collectionDestination.remoteId() == OTHERCONTACTS_REMOTEID) {
            contact->clearGroups();
            // OtherContacts -> MyContacts
        } else if (collectionSource.remoteId() == OTHERCONTACTS_REMOTEID && collectionDestination.remoteId() == myContactsRemoteId()) {
            contact->addGroup(myContactsRemoteId());
        }

        return contact;
    }
```

#### AUTO 


```{c}
auto interact = (sasl_interact_t *)in;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : std::as_const(mMailboxes)) {
            // "Shared Folders" is not a valid mailbox, so we have to skip the ACL request for this folder
            if (isNamespaceFolder(mailbox, mSharedNamespace, true)) {
                continue;
            }
            auto rights = new KIMAP::MyRightsJob(mSession);
            rights->setMailBox(mailbox);
            connect(rights, &KJob::result, this, &RetrieveMetadataJob::onRightsReceived);
            mJobs++;
            rights->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!mCache.contains(item.remoteId())) {
            mCache[item.remoteId()] = item.remoteRevision();
        }
    }
```

#### AUTO 


```{c}
auto *fj = static_cast<ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *job = new CollectionModifyJob(c);
```

#### AUTO 


```{c}
const auto account = m_settings->accountPtr();
```

#### AUTO 


```{c}
auto append = qobject_cast<KIMAP::AppendJob *>(job);
```

#### AUTO 


```{c}
auto *sock = qobject_cast<QSslSocket *>(socket())
```

#### AUTO 


```{c}
auto rename = static_cast<KIMAP::RenameJob *>(job);
```

#### AUTO 


```{c}
const auto certificates = certs.certificates();
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsSubscribedFoldersJob *>(job);
```

#### AUTO 


```{c}
auto *bodyMessage = new KMime::Content;
```

#### AUTO 


```{c}
const auto attr = it.key().attribute<Akonadi::EntityDisplayAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        if (modifiedItems.contains(item.remoteId())) {
            const KContacts::Addressee addressee = item.payload<KContacts::Addressee>();
            const ContactPtr contact(new Contact(addressee));
            contacts << contact;
        }
    }
```

#### AUTO 


```{c}
auto *job = new CollectionModifyJob(mCurrentUpdate.collection, mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(randomList1)) {
        Item item1;
        item1.setId(KRandom::random());
        item1.setRemoteId(entry);
        item1.setParentCollection(collection1);

        job = mStore->fetchItem(item1);
        job->fetchScope().fetchPayloadPart(MessagePart::Header);
        job->fetchScope().fetchPayloadPart(MessagePart::Body);

        spy = new QSignalSpy(job, &FileStore::ItemFetchJob::itemsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        items = job->items();
        QCOMPARE((int)items.count(), 1);
        QCOMPARE(itemsFromSpy(spy), items);

        Item item = items.first();
        QCOMPARE(item, item1);
        QVERIFY(item.hasPayload<KMime::Message::Ptr>());

        KMime::Message::Ptr msgPtr = item.payload<KMime::Message::Ptr>();
        QVERIFY(msgPtr != 0);

        const QSet<QByteArray> parts = messageParts(msgPtr);
        QVERIFY(!parts.isEmpty());
        QVERIFY(parts.contains(MessagePart::Header));
        QVERIFY(parts.contains(MessagePart::Body));
    }
```

#### AUTO 


```{c}
auto *fetchJob = new CollectionFetchJob(targetCollection,
                                                              CollectionFetchJob::Base,
                                                              this);
```

#### AUTO 


```{c}
static const auto pkeyAuthSuffix = QStringLiteral(" PKeyAuth/1.0");
```

#### AUTO 


```{c}
auto noSelectAttribute = new NoSelectAttribute();
```

#### AUTO 


```{c}
auto *fetchJob = new ItemFetchJob(tagContext.mItem);
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(QStringLiteral(""), srv->portNumber());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : results) {
        if (result.value.startsWith(QLatin1Char('/'))) {
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            QUrl tmp(result.value);
            tmp.setUserInfo(QString());
            url = tmp;
        }
        davUrl.setUrl(url);

        if (result.property == KDAV::ProtocolInfo::principalHomeSet(KDAV::CalDav)) {
            davUrl.setProtocol(KDAV::CalDav);
        } else {
            davUrl.setProtocol(KDAV::CardDav);
        }

        auto *fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
        connect(fetchJob, &KDAV::DavCollectionsFetchJob::result, this, &SearchDialog::onCollectionsFetchJobFinished);
        fetchJob->start();
        ++mSubJobCount;
    }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsPoxAutodiscoverRequest *>(job);
```

#### AUTO 


```{c}
auto job = new OXA::ObjectsRequestJob(folder, 0, OXA::ObjectsRequestJob::Modified, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entries) {
            if (!mDeletedOffsets.contains(entry.messageOffset())) {
                result << entry;
            }
        }
```

#### AUTO 


```{c}
auto modifyJob = qobject_cast<Akonadi::CollectionModifyJob *>(job);
```

#### AUTO 


```{c}
const auto mimetypes{Mime::getContentMimeTypeList(msg)};
```

#### AUTO 


```{c}
auto remoteId = col.remoteId();
```

#### AUTO 


```{c}
auto content = new KMime::Content();
```

#### AUTO 


```{c}
auto &item
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(Collection::root(), CollectionFetchJob::Recursive, this);
```

#### AUTO 


```{c}
auto *store = new KIMAP::StoreJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &addressee : std::as_const(mAddressees)) {
        v.push_back(addressee);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::ErrorHandler::Err &error : errors) {
        errorMsg.append(error.message);
        errorMsg.append(QLatin1Char('\n'));
    }
```

#### AUTO 


```{c}
auto *fetchJob
            = new CollectionFetchJob(collection, CollectionFetchJob::Base);
```

#### CONST EXPRESSION 


```{c}
constexpr int DesiredStateTimeoutMs = 20000;
```

#### AUTO 


```{c}
auto *vLayout = new QVBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QXmlResultItems &, const QXmlNamePool &)
            {
                return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<a/>"), 200);
            }
```

#### AUTO 


```{c}
auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item){
                                return item.remoteId() == parentId;
                            });
```

#### AUTO 


```{c}
auto *bodyDisposition
            = new KMime::Headers::ContentDisposition();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(QString::number(entry.messageOffset()));
        item.setParentCollection(collection);

        if (mbox->hasIndexData()) {
            const KMIndexDataPtr indexData = mbox->indexData(entry.messageOffset());
            if (indexData != nullptr && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has"
                                                      << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            } else if (indexData == nullptr) {
                Akonadi::MessageStatus status;
                status.setDeleted(true);
                item.setFlags(status.statusFlags());
                qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "no index for item" << item.remoteId() << "in MBox" << mbox->fileName()
                                                  << "so it has been deleted but not purged. Marking it as"
                                                  << item.flags();
            }
        }

        items << item;
    }
```

#### AUTO 


```{c}
auto attachDisposition = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto *monitor = new Monitor(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : std::as_const(m_taskList)) {
        if (!ret.isEmpty()) {
            ret += QLatin1String(", ");
        }
        ret += QLatin1String(task->metaObject()->className());
    }
```

#### AUTO 


```{c}
auto searchJob = qobject_cast<KIMAP::SearchJob *>(job);
```

#### AUTO 


```{c}
auto authJob = new AuthJob(m_account, m_settings->clientId(), m_settings->clientSecret(), this);
```

#### AUTO 


```{c}
auto capJob = qobject_cast<KIMAP::CapabilitiesJob *>(job);
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(c, CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *agentCreateJob = new AgentInstanceCreateJob(maildirType);
```

#### AUTO 


```{c}
const auto collection = requestJob->property("collection").value<Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (Item item : items) {
        if (!item.hasPayload<KCalCore::Todo::Ptr>()) {
            qCDebug(GOOGLE_CALENDAR_LOG) << "Item " << item.remoteId() << " does not have Todo payload";
            continue;
        }

        KCalCore::Todo::Ptr todo = item.payload<KCalCore::Todo::Ptr>();
        /* If this item is child of the item we want to remove then add it to detach list */
        if (todo->relatedTo(KCalCore::Incidence::RelTypeParent) == removedItem.remoteId()) {
            todo->setRelatedTo(QString(), KCalCore::Incidence::RelTypeParent);
            item.setPayload(todo);
            detachItems << item;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->doTransport(); }
```

#### AUTO 


```{c}
auto *const aclAttribute = m_collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QUrl &, QVariantMap &map) {
        map[QStringLiteral("code")] = QUrl::toPercentEncoding(refreshToken);
    }
```

#### AUTO 


```{c}
const auto err = obj.value(QLatin1String("error")).toObject();
```

#### AUTO 


```{c}
auto collection = job->property("collection").value<Collection>();
```

#### AUTO 


```{c}
auto fetch = new Akonadi::ItemFetchJob(tags.first());
```

#### AUTO 


```{c}
const auto customProperties{e.customProperties()};
```

#### AUTO 


```{c}
auto job = new TomboyItemUploadJob(item, JobType::ModifyItem, mManager, this);
```

#### AUTO 


```{c}
auto *job = new Akonadi::ContactSearchJob(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QByteArray data = md.readEntry(item.remoteId());

        auto *mail = new KMime::Message();
        mail->setContent(KMime::CRLFtoLF(data));
        mail->parse();
        // Some messages may have an empty body
        if (mail->body().isEmpty()) {
            if (parts.contains("PLD:BODY") || parts.contains("PLD:RFC822")) {
                // In that case put a space in as body so that it gets cached
                // otherwise we'll wrongly believe the body part is missing from the cache
                mail->setBody(" ");
            }
        }

        Item i(item);
        i.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, i);
        rv.push_back(i);
    }
```

#### AUTO 


```{c}
auto ewsRights = folder[EwsFolderFieldEffectiveRights].value<EwsEffectiveRights>();
```

#### AUTO 


```{c}
auto itemCreate = new ItemCreateJob(item, mCollection, transaction());
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString&) {
            authFinished = true;
            loop.exit(0);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &oldEntry : entryList1) {
        entryList3.removeAll(oldEntry);
    }
```

#### AUTO 


```{c}
auto sock = qobject_cast<QSslSocket *>(socket())
```

#### AUTO 


```{c}
auto aclAttribute = m_collection.attribute<Akonadi::ImapAclAttribute>();
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(mItem, this);
```

#### AUTO 


```{c}
auto defaultReplyCallback = server->defaultReplyCallback();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Row> &r : qAsConst(mMigrators)) {
        if (row == *r) {
            return pos;
        }
        pos++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool success, const QString &error) {
                updateItemsFinished(success, error);
            }
```

#### AUTO 


```{c}
const auto reqChanges{itemReq->changes()};
```

#### AUTO 


```{c}
auto modifiedJob = new ObjectsRequestJob(mFolder, mLastSync, ObjectsRequestJob::Modified, this);
```

#### AUTO 


```{c}
auto job = new KIMAP::SetMetaDataJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[=](KJob *job) {
            onCollectionChangedFinished(job, collection);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &requestedEntry : std::as_const(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        const Collection collection = item.parentCollection();
        const qint64 revision = collection.remoteRevision().toLongLong();

        RevisionChangeMap &changesByRevision = d->mChangesByCollection[ collection.id() ];
        OldIdItemMap &changes = changesByRevision[ revision ];
        changes.insert(item.remoteId(), item);

        if (!updateBatch.collection.isValid()) {
            updateBatch.collection = collection;
        } else if (updateBatch.collection != collection) {
            d->mPendingUpdates << updateBatch;
            updateBatch.items.clear();
            updateBatch.collection = collection;
        }

        updateBatch.items << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
        try {
            KMime::Message::Ptr msg = item.payload<KMime::Message::Ptr>();
            const QByteArray messageId = msg->messageID()->asUnicodeString().toUtf8();
            if (!messageId.isEmpty()) {
                m_messageIds.insert(item.id(), messageId);
            }

            set.add(item.remoteId().toLong());
        } catch (const Akonadi::PayloadException &e) {
            Q_UNUSED(e);
            qCWarning(IMAPRESOURCE_LOG) << "Move failed, payload exception " << item.id() << item.remoteId();
            cancelTask(i18n("Failed to move item, it has no message payload. Remote id: %1", item.remoteId()));
            return;
        }
    }
```

#### AUTO 


```{c}
auto monitor = new Monitor(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &member : members) {
        m.push_back(Conversion::toStdString(member));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : qAsConst(m_taskList)) {
        if (!ret.isEmpty()) {
            ret += QLatin1String(", ");
        }
        ret += QLatin1String(task->metaObject()->className());
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, dlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const ContactPtr contact = object.dynamicCast<Contact>();

        if (((collection.remoteId() == OTHERCONTACTS_REMOTEID) && !contact->groups().isEmpty())
            || ((collection.remoteId() == MYCONTACTS_REMOTEID) && contact->groups().isEmpty())) {
            continue;
        }

        Item item;
        item.setMimeType(KContacts::Addressee::mimeType());
        item.setParentCollection(m_collections[MYCONTACTS_REMOTEID]);
        item.setRemoteId(contact->uid());
        item.setRemoteRevision(contact->etag());
        item.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());

        if (contact->deleted()) {
            removedItems << item;
        } else {
            changedItems << item;
            changedPhotos << contact->uid();
        }

        const QStringList groups = contact->groups();
        for (const QString &group : groups) {
            groupsMap[group] << item;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMoveItemRequest::Response &resp : reqResponses) {
        QCOMPARE(resp.responseClass(), EwsResponseSuccess);
        QCOMPARE(resp.itemId(), *newIdsIt);
        newIdsIt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SetupWizard::Url &url : urls) {
                Settings::UrlConfiguration *urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = url.url;
                urlConfig->mProtocol = url.protocol;
                urlConfig->mUser = url.userName;
                urlConfig->mPassword = wizard.field(QStringLiteral("credentialsPassword")).toString();

                Settings::self()->newUrlConfiguration(urlConfig);
            }
```

#### AUTO 


```{c}
const auto res = instances.calendarResource.isValid()
                                        ? instances.calendarResource.identifier()
                                        : instances.contactResource.identifier();
```

#### AUTO 


```{c}
auto moveJob = qobject_cast<FileStore::ItemMoveJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReminderPtr &reminder : qAsConst(m_reminders)) {
        KCalCore::Alarm::Ptr alarm(new KCalCore::Alarm(incidence));

        alarm->setType(reminder->type());
        alarm->setTime(incidence->dtStart());
        alarm->setStartOffset(reminder->startOffset());
        alarm->setEnabled(true);

        alarms << alarm;
    }
```

#### AUTO 


```{c}
auto *hv3 = new KMime::Headers::Generic(X_KOLAB_MIME_VERSION_HEADER);
```

#### AUTO 


```{c}
auto status = new KIMAP::StatusJob(m_session);
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectMoveJob(object, destinationFolder, this);
```

#### AUTO 


```{c}
auto it = m_messageIds.begin();
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(extraItems);
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : idList) {
        const int idTime = idToTime(id);
        if (idTime < timeOfOldestMessage) {
            timeOfOldestMessage = idTime;
            idOfOldestMessage = id;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { dispatch();}
```

#### AUTO 


```{c}
const auto contents = data->contents();
```

#### AUTO 


```{c}
auto *req = new EwsUpdateFolderRequest(mEwsClient, this);
```

#### AUTO 


```{c}
const auto noteAttachments = note.attachments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &type : mimetypes) {
        Kolab::ObjectType t = getObjectType(type.toStdString()); // works for v2 types
        if (t != InvalidObject) {
            return t;
        }
    }
```

#### AUTO 


```{c}
auto job = new CalendarCreateJob(calendar, m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob*job) { onSelectDone(job); }
```

#### AUTO 


```{c}
auto *job = new EwsAkonadiTagsSyncJob(mTagStore, mClient,
                                                               qobject_cast<EwsResource *>(parent())->rootCollection(), this);
```

#### AUTO 


```{c}
auto authJob = new KGAPI2::AuthJob(acc, GOOGLE_API_KEY, GOOGLE_API_SECRET, this);
```

#### AUTO 


```{c}
auto collectionColor = QString::fromUtf8(etebase_item_metadata_get_color(metaData.get()));
```

#### AUTO 


```{c}
const auto networkError = tokenReply->networkError();
```

#### AUTO 


```{c}
auto job = new KIMAP::SetAclJob(session);
```

#### AUTO 


```{c}
auto *modJob = new KDAV::DavItemModifyJob(davItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *content : contents) {
            content->changeEncoding(KMime::Headers::CEbase64);
            content->contentTransferEncoding(true)->setEncoding(KMime::Headers::CEbase64);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::Item &left, const Akonadi::Item &right) {
            return left.parentCollection().remoteId().compare(right.parentCollection().remoteId()) < 0 ||
                    (left.parentCollection().remoteId() == right.parentCollection().remoteId() && changedOffset(left) < changedOffset(right));
          }
```

#### AUTO 


```{c}
auto *srJob = static_cast<StoreResultJob *>(job);
```

#### AUTO 


```{c}
auto job = createGetJob(url);
```

#### AUTO 


```{c}
auto *nsJob = qobject_cast<KIMAP::NamespaceJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        const auto tags{item.tags()};
        for (const Tag &tag : tags) {
            if (!mTagStore->containsId(tag.id())) {
                unknownTags.append(tag);
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(Item(contactId), this);
```

#### AUTO 


```{c}
const auto mode = authMode();
```

#### AUTO 


```{c}
auto task = new AddItemTask(state);
```

#### AUTO 


```{c}
auto kTodo = fromXML<KCalendarCore::Todo::Ptr, KolabV2::Task>(xmlData, attachments);
```

#### AUTO 


```{c}
const auto wallet = getWallet();
```

#### AUTO 


```{c}
auto job = new AgentInstanceCreateJob(typeId, this);
```

#### AUTO 


```{c}
auto *attribute = mDavCollectionRoot.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        fetchChangedResult(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(items)) {
        Q_FOREACH (const QByteArray &flag, item.flags()) {
            ++flagCounts[flag];
        }
    }
```

#### AUTO 


```{c}
auto job = new KGAPI2::FreeBusyQueryJob(email, start.dateTime(), end.dateTime(),
                                           account(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &note : notes) {
        Akonadi::Item item(Akonadi::NoteUtils::noteMimeType());
        item.setRemoteId(note.toObject()[QLatin1String("guid")].toString());
        mResultItems << item;
        qCDebug(TOMBOYNOTESRESOURCE_LOG) << "TomboyItemsDownloadJob: Retrieving note with id" << item.remoteId();
    }
```

#### AUTO 


```{c}
auto req = new EwsDeleteFolderRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &contact : *contacts) {
                QDomElement email = DAVUtils::addOxElement(document, distributionList, QStringLiteral("email"), OXUtils::writeString(contact.preferredEmail()));

                DAVUtils::setOxAttribute(email, QStringLiteral("folder_id"), OXUtils::writeNumber(0));
                DAVUtils::setOxAttribute(email, QStringLiteral("emailfield"), OXUtils::writeNumber(0));
                DAVUtils::setOxAttribute(email, QStringLiteral("id"), OXUtils::writeNumber(0));
                DAVUtils::setOxAttribute(email, QStringLiteral("displayname"), OXUtils::writeString(contact.realName()));
            }
```

#### AUTO 


```{c}
auto *treeView = new QTreeView(this);
```

#### AUTO 


```{c}
auto notification =
            new KNotification(QStringLiteral("new-email"),
                              NewMailNotifierAgentSettings::keepPersistentNotification() ? KNotification::Persistent | KNotification::SkipGrouping
                                                                                         : KNotification::CloseOnTimeout);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxPtr &mbox : std::as_const(mMBoxes)) {
        if (mbox->mCollection.isValid()) {
            MBoxPtr updatedMBox = mbox;
            updatedMBox->mCollection = updateMBoxCollectionTree(mbox->mCollection, collection, renamedCollection);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : std::as_const(collections)) {
        job = mStore->fetchCollections(collection, FileStore::CollectionFetchJob::Base);

        spy = new QSignalSpy(job, &FileStore::CollectionFetchJob::collectionsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);
        QCOMPARE(spy->count(), 1);

        const Collection::List list = collectionsFromSpy(spy);
        QCOMPARE(list.count(), 1);
        QCOMPARE(list.first(), collection);
        QCOMPARE(job->collections(), list);

        const Collection col = list.first();
        QVERIFY(!col.remoteId().isEmpty());
        QCOMPARE(col.remoteId(), col.name());
        QCOMPARE(col.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

        QCOMPARE(col.rights(),
                 Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                     | Collection::CanChangeCollection | Collection::CanDeleteCollection);
    }
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyCollectionsDownloadJob*>(kjob);
```

#### AUTO 


```{c}
auto task = new AddCollectionTask(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : qAsConst(mDeletedItemOffsets)) {
        entries << KMBox::MBoxEntry(offset);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &attachment : attachments) {
        const std::string data = attachment.data();
        const std::string cid = attachmentCids.empty() ? attachment.uri() : attachmentCids.at(index);
        msg->addContent(Mime::createAttachmentPart(Mime::fromCid(QString::fromStdString(cid.c_str())).toLatin1(),
                                                   QByteArray(attachment.mimetype().c_str()),
                                                   QString::fromStdString(attachment.label()),
                                                   QByteArray(data.c_str(), data.size())));
        index++;
    }
```

#### AUTO 


```{c}
auto pkeyAuthJob = new EwsPKeyAuthJob(url, q->mPKeyCertFile, q->mPKeyKeyFile, mPKeyPassword, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        qCDebug(GOOGLE_CALENDAR_LOG) << "Calendars retrieved";

        const ObjectsList calendars = qobject_cast<CalendarFetchJob *>(job)->items();
        Collection::List collections;
        collections.reserve(calendars.count());
        const QStringList activeCalendars = m_settings->calendars();
        for (const auto &object : calendars) {
            const CalendarPtr &calendar = object.dynamicCast<Calendar>();
            qCDebug(GOOGLE_CALENDAR_LOG) << " -" << calendar->title() << "(" << calendar->uid() << ")";
            if (!activeCalendars.contains(calendar->uid())) {
                qCDebug(GOOGLE_CALENDAR_LOG) << "Skipping, not subscribed";
                continue;
            }
            Collection collection;
            setupCollection(collection, calendar);
            collection.setParentCollection(rootCollection);
            collections << collection;
        }

        m_iface->collectionsRetrievedFromHandler(collections);
    }
```

#### AUTO 


```{c}
auto *job = new EwsModifyItemFlagsJob(mEwsClient, this, items, addedFlags, removedFlags);
```

#### AUTO 


```{c}
auto webpage = new WebPage(profile, mView);
```

#### AUTO 


```{c}
const auto syncState = getCollectionSyncState(fetchJob->collection());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            qDebug() << "succeeded";
            loop.exit(0);
            status = 0;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col, const Akonadi::Collection &) {
        stateChanged(col);
    }
```

#### AUTO 


```{c}
auto job = new SpecialNotifierJob(mListEmails, currentPath, item, this);
```

#### AUTO 


```{c}
auto job = new GetTokenJob(mIdentifier, parent());
```

#### AUTO 


```{c}
const auto &tokenPair
```

#### AUTO 


```{c}
auto deleteJob = new DeletePasswordJob(googleWalletFolder);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto key : keys) {
        QString val = map[key].toString();
        val.replace('"', QStringLiteral("\\\""));
        elems.append(QStringLiteral("\"%1\":\"%2\"").arg(key, val));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::PhoneNumber &n : phoneNumbers) {
        Kolab::Telephone p;
        p.setNumber(toStdString(n.number()));
        bool pref = false;
        p.setTypes(fromPhoneType(n.type(), pref));
        prefCounter++;
        if (pref) {
            prefNum = prefCounter;
        }
        phones.push_back(p);
    }
```

#### AUTO 


```{c}
auto *rightsJob = qobject_cast<KIMAP::MyRightsJob *>(job);
```

#### AUTO 


```{c}
auto attribute = mResourceCollection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Resource,
                                                                  resourceId);
```

#### AUTO 


```{c}
const auto accessToken = tokens.value(QStringLiteral("access_token"));
```

#### AUTO 


```{c}
auto *select = new KIMAP::SelectJob(mSession);
```

#### AUTO 


```{c}
auto *modJob = new ItemModifyJob(item, this);
```

#### AUTO 


```{c}
auto attr = mapIt->attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsMoveFolderRequest *>(job);
```

#### AUTO 


```{c}
const auto items = query.queryItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::ImapInterval &interval : intervals) {
            if (!interval.hasDefinedEnd()) {
                // If we get an interval without a defined end we simply fetch everything
                qCDebug(IMAPRESOURCE_LOG) << "Received interval without defined end, fetching everything in one batch";
                toFetch.add(interval);
                newSet = KIMAP::ImapSet();
                break;
            }
            const qint64 wantedItems = m_batchSize - counter;
            if (counter < m_batchSize) {
                if (interval.size() <= wantedItems) {
                    counter += interval.size();
                    toFetch.add(interval);
                } else {
                    counter += wantedItems;
                    toFetch.add(KIMAP::ImapInterval(interval.begin(), interval.begin() + wantedItems - 1));
                    newSet.add(KIMAP::ImapInterval(interval.begin() + wantedItems, interval.end()));
                }
            } else {
                newSet.add(interval);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : providers) {
        const KDesktopFile provider(fileName);
        offers.append(QPair<QString, QString>(provider.readName(), fileName));
    }
```

#### AUTO 


```{c}
auto socket = qobject_cast<QTcpSocket *>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetEventsRequest::Event &event : nfyEvents) {
                bool skip = false;
                mSettings->setEventSubscriptionWatermark(event.watermark());
                if (!skip) {
                    switch (event.type()) {
                    case EwsCopiedEvent:
                    case EwsMovedEvent:
                        if (!event.itemIsFolder()) {
                            mUpdatedFolderIds.insert(event.oldParentFolderId());
                        }
                    /* fall through */
                    case EwsCreatedEvent:
                    case EwsDeletedEvent:
                    case EwsModifiedEvent:
                    case EwsNewMailEvent:
                        if (event.itemIsFolder()) {
                            mFolderTreeChanged = true;
                        } else {
                            mUpdatedFolderIds.insert(event.parentFolderId());
                        }
                        break;
                    case EwsStatusEvent:
                        // Do nothing
                        break;
                    default:
                        break;
                    }
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {return parseUnsubscribeResponse(reader);}
```

#### AUTO 


```{c}
const auto d = reinterpret_cast<const EwsItemPrivate *>(this->d.data());
```

#### AUTO 


```{c}
auto it = std::find_if(m_handlers.cbegin(), m_handlers.cend(),
            [&mimeType](const GenericHandler::Ptr &handler){
                return handler->mimeType() == mimeType;
            });
```

#### AUTO 


```{c}
const auto attr = collection.attribute<EntityDisplayAttribute>()
```

#### AUTO 


```{c}
auto it = specialFolderList.cbegin();
```

#### AUTO 


```{c}
const auto ranges = queryJob->busy();
```

#### AUTO 


```{c}
const auto serverSubscriptionList = mSettings->serverSubscriptionList();
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsUpdateItemRequest *>(job);
```

#### AUTO 


```{c}
const auto contact = item.payload<KContacts::Addressee>();
```

#### AUTO 


```{c}
const auto candidateTransition = candidateTransitions[0];
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { setTemporaryOffline(reconnectTimeout()); }
```

#### AUTO 


```{c}
const auto events = cal->events();
```

#### AUTO 


```{c}
auto *fetch = static_cast<KIMAP::FetchJob *>(sender());
```

#### AUTO 


```{c}
const auto &cookie
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            setSslIcon(QStringLiteral("security-low"));
        }
```

#### AUTO 


```{c}
const auto result = etesync_entry_manager_create(entryManager.get(), entries, collection.remoteRevision());
```

#### AUTO 


```{c}
const auto langs{addressee.langs()};
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionsFetchJob(davUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Addressee &addressee : std::as_const(mAddressees)) {
        Item item;
        item.setRemoteId(addressee.uid());
        item.setMimeType(KContacts::Addressee::mimeType());
        item.setPayload(addressee);
        items.append(item);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        auto queryJob = qobject_cast<FreeBusyQueryJob *>(job);

        if (!m_iface->handleError(job, false)) {
            m_iface->freeBusyRetrieved(queryJob->id(), QString(), false, QString());
            return;
        }

        KCalendarCore::FreeBusy::Ptr fb(new KCalendarCore::FreeBusy);
        fb->setUid(QStringLiteral("%1%2@google.com").arg(QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyyMMddTHHmmssZ"))));
        fb->setOrganizer(job->account()->accountName());
        fb->addAttendee(KCalendarCore::Attendee(QString(), queryJob->id()));
        // FIXME: is it really sort?
        fb->setDateTime(QDateTime::currentDateTimeUtc(), KCalendarCore::IncidenceBase::RoleSort);
        const auto ranges = queryJob->busy();
        for (const auto &range : ranges) {
            fb->addPeriod(range.busyStart, range.busyEnd);
        }

        KCalendarCore::ICalFormat format;
        const QString fbStr = format.createScheduleMessage(fb, KCalendarCore::iTIPRequest);

        m_iface->freeBusyRetrieved(queryJob->id(), fbStr, true, QString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OXA::Folder &folder : deletedFolders) {
        Collection collection;
        collection.setRemoteId(QString::number(folder.objectId()));

        removedCollections.append(collection);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return true;
        };
        wallet->createFolderCallback = [](const QString &) {
            return false;
        };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return true;
        };
        wallet->readPasswordCallback = [](const QString &, QString &password) {
            password = QStringLiteral("foo");
            return true;
        };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
const auto parsedCode = parseEwsResponseCode(parseNamespacedString(rawCode, reader.namespaceDeclarations()));
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *item : qAsConst(mFolderItemHash)) {
        if (!item->parent()) {
            mFolderTreeModel->appendRow(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FileStore::Job *job : jobs) {
        mCurrentJob = job;

        if (job->error() == 0) {
            if (!job->accept(&mTopLevelCollectionFetcher)) {
                q->processJob(job);
            }
        }
        mSession->emitResult(job);
        mCurrentJob = nullptr;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int size : std::as_const(sizes)) {
        mTotalBytesToDownload += size;
    }
```

#### AUTO 


```{c}
auto label =
            new QLabel(QStringLiteral("<a href=\"%1\">%2</a>").arg(index.data(MigratorModel::LogfileRole).toString(), ki18n("Logfile").toString()), widget);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &rootCollection](const ObjectPtr &object) {
            const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();
            qCDebug(GOOGLE_CONTACTS_LOG) << " -" << group->title() << "(" << group->id() << ")";
            Collection collection;
            setupCollection(collection, group);
            collection.setParentCollection(rootCollection);
            m_collections[collection.remoteId()] = collection;
            return collection;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : qAsConst(objects)) {
        const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();

        QString realName = group->title();

        if (group->isSystemGroup()) {
            if (group->title().contains(QLatin1String("Coworkers"))) {
                realName = i18nc("Name of a group of contacts", "Coworkers");
            } else if (group->title().contains(QLatin1String("Friends"))) {
                realName = i18nc("Name of a group of contacts", "Friends");
            } else if (group->title().contains(QLatin1String("Family"))) {
                realName = i18nc("Name of a group of contacts", "Family");
            } else if (group->title().contains(QLatin1String("My Contacts"))) {
                // Yes, skip My Contacts group, we store "My Contacts" in root collection
                continue;
            }
        } else {
            if (group->title().contains(QLatin1String("Other Contacts"))) {
                realName = i18nc("Name of a group of contacts", "Other Contacts");
            }
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KContacts::Addressee::mimeType());
        collection.setName(group->id());
        collection.setParentCollection(m_rootCollection);
        collection.setRights(Collection::CanLinkItem
                             |Collection::CanUnlinkItem
                             |Collection::CanChangeItem);
        if (!group->isSystemGroup()) {
            collection.setRights(collection.rights()
                                 |Collection::CanChangeCollection
                                 |Collection::CanDeleteCollection);
        }
        collection.setRemoteId(group->id());
        collection.setVirtual(true);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(realName);
        attr->setIconName(QStringLiteral("view-pim-contacts"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Attachment &attachment : attachments) {
        if (!attachment.uri().empty()) {
            const Kolab::Attachment extracted = Mime::getAttachment(attachment.uri(), msg);
            if (extracted.isValid()) {
                allAttachments.push_back(extracted);
            }
        } else {
            allAttachments.push_back(attachment);
        }
    }
```

#### AUTO 


```{c}
auto *attr = col.attribute<CompatibilityAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsDeleteItemRequest *>(job);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsSyncFolderHierarchyRequest *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString & req, QXmlResultItems &, const QXmlNamePool &) {
        qDebug() << "Unknown EWS request encountered." << req;
        unknownRequestEncountered = true;
        return FakeEwsServer::EmptyResponse;
    }
```

#### AUTO 


```{c}
static const auto inboxId = QStringLiteral("aW5ib3g=");
```

#### AUTO 


```{c}
auto *writeJob = new EwsGlobalTagsWriteJob(mTagStore, mClient,
                                                                res->rootCollection(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsFetchItemsJob *fetchJob) {
        auto col = fetchJob->collection();
        if (fetchJob->error()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Item fetch error:") << fetchJob->errorString() << fetchJob->error() << fetchJob->ewsResponseCode();
            if (!isEwsResponseCodeTemporaryError(fetchJob->ewsResponseCode())) {
                const auto syncState = getCollectionSyncState(fetchJob->collection());
                if (!syncState.isEmpty()) {
                    qCDebugNC(EWSRES_LOG) << QStringLiteral("Retrying with empty state.");
                    // Retry with a clear sync state.
                    saveCollectionSyncState(col, QString());
                    retrieveItems(col);
                } else {
                    qCDebugNC(EWSRES_LOG) << QStringLiteral("Clean sync failed.");
                    // No more hope
                    cancelTask(i18nc("@info:status", "Failed to retrieve items"));
                    return;
                }
            } else {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Sync failed due to temporary error - not clearing state");
                cancelTask(i18nc("@info:status", "Failed to retrieve items"));
                setTemporaryOffline(reconnectTimeout());
                return;
            }
        } else {
            saveCollectionSyncState(col, fetchJob->syncState());
            itemsRetrievedIncremental(fetchJob->newItems() + fetchJob->changedItems(), fetchJob->deletedItems());
        }
        saveState();
        mItemsToCheck.remove(fetchJob->collection().remoteId());
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
auto sock = tcpSocket()
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : job->requestedItems()) {
            const Collection coll = item.parentCollection();
            Q_ASSERT(!coll.remoteId().isEmpty());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &extraItem : std::as_const(extraItems)) {
            cache->setEtag(extraItem.remoteId(), davItem.etag());
            items << extraItem;
        }
```

#### AUTO 


```{c}
static const auto o365Resource = QStringLiteral("https%3A%2F%2Foutlook.office365.com%2F");
```

#### LAMBDA EXPRESSION 


```{c}
[this](QKeychain::Job *baseJob) {
                if (baseJob->error()) {
                    qCWarning(POP3RESOURCE_LOG) << "Error writing password using QKeychain:" << baseJob->errorString();
                }
                finish();
            }
```

#### AUTO 


```{c}
auto *attr = c.attribute<Akonadi::BlockAlarmsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemDeleteJob(Akonadi::valuesToVector(m_localItems), transaction());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : cols) {
        if (!contactFilter.isWantedCollection(col)) {
            continue;
        }
        auto *job = new ItemFetchJob(col, this);
        job->fetchScope().fetchFullPayload();
        connect(job, &ItemFetchJob::itemsReceived, this, &BirthdaysResource::createEvents);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                    setSslIcon(QStringLiteral("security-low"));
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &h : std::as_const(headers)) {
        if (first) {
            first = false;
        } else {
            ret.append(",");
        }
        ret.append(h.name);
        ret.append("=\"");
        ret.append(QUrl::toPercentEncoding(QString::fromLatin1(h.value)));
        ret.append("\"");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return false;
                                    };
        wallet->createFolderCallback = [](const QString &) {
                                           return false;
                                       };
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : std::as_const(idsToDownload)) {
            sizesOfMessagesToDownload.append(mIdsToSizeMap.value(id));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        // qCritical() << "SELECTED DATA: " << index.data(Qt::UserRole + 1).toString();
        ret << index.data(Qt::UserRole + 1).toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        Q_ASSERT(QThread::currentThread() != qApp->thread());
        const Result result = protocol->get(path);
        disconnect(protocol, &POP3Protocol::data, this, &BaseJob::slotData);
        Q_EMIT jobDone(result);
    }
```

#### AUTO 


```{c}
const auto newItems = fetchJob->newItems();
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("changeAlarmTypes:")
```

#### AUTO 


```{c}
auto folderId
```

#### AUTO 


```{c}
auto ntf = KNotification::event(QStringLiteral("authNeeded"),
                                    i18nc("@title", "%1 needs your attention.", agentName()),
                                    msg,
                                    QStringLiteral("im-google"),
                                    /*widget=*/nullptr,
                                    KNotification::Persistent | KNotification::SkipGrouping);
```

#### LAMBDA EXPRESSION 


```{c}
[this](unsigned int progress) {
            Q_EMIT reportPercent(progress);
        }
```

#### AUTO 


```{c}
auto handler = fetchHandlerForMimeType(item.mimeType());
```

#### AUTO 


```{c}
const auto *uidNext = parent.attribute<UidNextAttribute>();
```

#### AUTO 


```{c}
auto *colJob = qobject_cast<FileStore::CollectionCreateJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        qCDebug(GOOGLE_CONTACTS_LOG) << "Contacts groups retrieved";

        const ObjectsList objects = qobject_cast<ContactsGroupFetchJob *>(job)->items();
        Collection::List collections;
        collections.reserve(objects.count());
        std::transform(objects.cbegin(), objects.cend(), std::back_inserter(collections),
                       [this, &rootCollection](const ObjectPtr &object){
            const ContactsGroupPtr group = object.dynamicCast<ContactsGroup>();
            qCDebug(GOOGLE_CONTACTS_LOG) << " -" << group->title() << "(" << group->id() << ")";
            Collection collection;
            setupCollection(collection, group);
            collection.setParentCollection(rootCollection);
            m_collections[ collection.remoteId() ] = collection;
            return collection;
        });
        m_iface->collectionsRetrievedFromHandler(collections);
    }
```

#### AUTO 


```{c}
auto session = static_cast<KIMAP::Session *>(object);
```

#### AUTO 


```{c}
auto job = new FileStore::ItemFetchJob(items, d->mSession);
```

#### AUTO 


```{c}
auto *replaceJob = static_cast<ReplaceMessageJob *>(job);
```

#### AUTO 


```{c}
auto job = new FileStore::ItemModifyJob(item, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : lst) {
        addIfComplete(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
        if (flag == MessageFlags::Seen) {
            isRead = true;
        } else if (flag == MessageFlags::Flagged) {
            isFlagged = true;
        } else if (flag == MessageFlags::HasAttachment || flag == MessageFlags::HasInvitation ||
                   flag == MessageFlags::Signed || flag == MessageFlags::Encrypted) {
            // These flags are read-only. Remove them from the unknown list but don't do anything with them.
        } else {
            unknownFlags.insert(flag);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *c : contents) {
        //         qCDebug(PIMKOLAB_LOG) << "searching: " << c->contentType()->name().toUtf8();
        if (c->contentType()->name() == name) {
            type = c->contentType()->mimeType();
            return c;
        }
    }
```

#### AUTO 


```{c}
auto widget = new QWidget(dlg);
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : std::as_const(mDeletedOffsets)) {
            deletedEntries << KMBox::MBoxEntry(offset);
        }
```

#### AUTO 


```{c}
auto *modJob = new Akonadi::CollectionModifyJob(col, this);
```

#### AUTO 


```{c}
auto *copy = static_cast<KIMAP::CopyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &l : list) {
        QVariantMap reminder = l.toMap();

        KGAPI2::ReminderPtr rem(new KGAPI2::Reminder);

        if (reminder[QStringLiteral("type")].toString() == QLatin1String("display")) {
            rem->setType(KCalendarCore::Alarm::Display);
        } else if (reminder[QStringLiteral("type")].toString() == QLatin1String("email")) {
            rem->setType(KCalendarCore::Alarm::Email);
        }

        KCalendarCore::Duration offset(reminder[QStringLiteral("time")].toInt(), KCalendarCore::Duration::Seconds);
        rem->setStartOffset(offset);

        m_reminders << rem;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &davCollection : davCollections) {
        if (seenCollectionsUrls.contains(davCollection.url().toDisplayString())) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveCollectionsFinished: Duplicate collection reported. " << davCollection.url().toDisplayString();
            continue;
        } else {
            seenCollectionsUrls.insert(davCollection.url().toDisplayString());
        }

        Akonadi::Collection collection;
        collection.setParentCollection(mDavCollectionRoot);
        collection.setRemoteId(davCollection.url().toDisplayString());
        collection.setName(collection.remoteId());

        if (davCollection.color().isValid()) {
            auto *colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
            colorAttr->setColor(davCollection.color());
        }

        if (!davCollection.displayName().isEmpty()) {
            auto *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
            attr->setDisplayName(davCollection.displayName());
        }

        QStringList mimeTypes;
        mimeTypes << Collection::mimeType();

        const KDAV::DavCollection::ContentTypes contentTypes = davCollection.contentTypes();
        if (contentTypes & KDAV::DavCollection::Calendar) {
            mimeTypes << QStringLiteral("text/calendar");
        }

        if (contentTypes & KDAV::DavCollection::Events) {
            mimeTypes << KCalendarCore::Event::eventMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Todos) {
            mimeTypes << KCalendarCore::Todo::todoMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Contacts) {
            mimeTypes << KContacts::Addressee::mimeType();
        }

        if (contentTypes & KDAV::DavCollection::FreeBusy) {
            mimeTypes << KCalendarCore::FreeBusy::freeBusyMimeType();
        }

        if (contentTypes & KDAV::DavCollection::Journal) {
            mimeTypes << KCalendarCore::Journal::journalMimeType();
        }

        collection.setContentMimeTypes(mimeTypes);
        setCollectionIcon(collection /*by-ref*/);

        auto *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
        protoAttr->setDavProtocol(davCollection.url().protocol());

        /*
         * We unfortunately have to update the CTag now in the cache
         * as this information will not be available when retrieveItems()
         * is called. We leave it untouched in the collection attribute
         * and will only update it there after successful sync.
         */
        if (!davCollection.CTag().isEmpty()) {
            mCTagCache.insert(davCollection.url().toDisplayString(), davCollection.CTag());
        }

        KDAV::Privileges privileges = davCollection.privileges();
        Akonadi::Collection::Rights rights;

        if (privileges & KDAV::All || privileges & KDAV::Write) {
            rights |= Akonadi::Collection::AllRights;
        }

        if (privileges & KDAV::WriteContent) {
            rights |= Akonadi::Collection::CanChangeItem;
        }

        if (privileges & KDAV::Bind) {
            rights |= Akonadi::Collection::CanCreateItem;
        }

        if (privileges & KDAV::Unbind) {
            rights |= Akonadi::Collection::CanDeleteItem;
        }

        if (privileges == KDAV::Read) {
            rights |= Akonadi::Collection::ReadOnly;
        }

        collection.setRights(rights);
        collections << collection;

        if (!mEtagCaches.contains(collection.remoteId())) {
            auto cache = std::shared_ptr<KDAV::EtagCache>(new AkonadiEtagCache(collection));
            mEtagCaches.insert(collection.remoteId(), cache);
        }
    }
```

#### AUTO 


```{c}
auto errorAttribute = new ErrorAttribute(mMessage);
```

#### AUTO 


```{c}
auto dlg = qobject_cast<SetupServer *>(sender());
```

#### AUTO 


```{c}
const auto *colorAttr
            = collection.attribute<Akonadi::CollectionColorAttribute>();
```

#### AUTO 


```{c}
auto replaceJob = static_cast<UpdateMessageJob *>(job);
```

#### AUTO 


```{c}
auto tjob = qobject_cast<KIO::StoredTransferJob*>(job);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsModifyItemJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &contact){
        Item item;
        item.setRemoteId(contact);
        return item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : lst) {
        mScheduler.pause(index.data(MigratorModel::IdentifierRole).toString());
    }
```

#### AUTO 


```{c}
auto requestJob = new SpecialMailCollectionsRequestJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QMap<QString, QString> &map) {
        if (map.contains(pkeyPasswordMapKey)) {
            mUi->pkeyAuthPassword->setPassword(map[pkeyPasswordMapKey]);
        }
    }
```

#### AUTO 


```{c}
auto createJob = qobject_cast<FileStore::CollectionCreateJob *>(job);
```

#### AUTO 


```{c}
const auto fbPeriodPeriods{fbPeriod.periods()};
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool successful) {
        qCDebug(ETESYNC_LOG) << "Resource intialised";
        if (successful) synchronize();
    }
```

#### AUTO 


```{c}
auto job = new GidMigrationJob(QStringList() << mMimeType, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &extraItem : qAsConst(extraItems)) {
            cache->setEtag(extraItem.remoteId(), davItem.etag());
            items << extraItem;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&wallet](KWallet::MyWallet *w) {
        wallet = w;
        return w;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return false;
                                    };
        wallet->createFolderCallback = [](const QString &) {
                                           return false;
                                       };
        wallet->doOpen(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&wallet](KWallet::MyWallet *w) {
                                      wallet = w;
                                      return w;
                                  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Event &e : events) {
        list.append(Kolab::Conversion::toKCalCore(e));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : results) {
        if (result.value.startsWith(QLatin1Char('/'))) {
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            QUrl tmp(result.value);
            tmp.setUserInfo(QString());
            url = tmp;
        }
        davUrl.setUrl(url);

        if (result.property == KDAV::ProtocolInfo::principalHomeSet(KDAV::CalDav)) {
            davUrl.setProtocol(KDAV::CalDav);
        } else {
            davUrl.setProtocol(KDAV::CardDav);
        }

        auto fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
        connect(fetchJob, &KDAV::DavCollectionsFetchJob::result, this, &SearchDialog::onCollectionsFetchJobFinished);
        fetchJob->start();
        ++mSubJobCount;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {itemFetched(job); }
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(content, srv->portNumber(), [&](const QString &chunk) {
        const QString respHead = QStringLiteral("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
                "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
                "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
                "<soap:Header>"
                "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
                "</soap:Header>"
                "<soap:Body>"
                "<m:GetStreamingEventsResponse>"
                "<m:ResponseMessages>"
                "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
                "<m:ResponseCode>NoError</m:ResponseCode>"
                "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral("</m:GetStreamingEventsResponseMessage>"
                "</m:ResponseMessages>"
                "</m:GetStreamingEventsResponse>"
                "</soap:Body>"
                "</soap:Envelope>");
        const QString eventHead = QStringLiteral("<m:Notifications>"
                "<m:Notification>"
                "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral("<NewMailEvent>"
                "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
                "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
                "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
                "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediately" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, reply]() {
        loop.exit(reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toUInt());
    }
```

#### AUTO 


```{c}
auto fetchJob = new KDAV::DavItemFetchJob(davItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems)  {
            if (!item.cachedPayloadParts().contains(Akonadi::MessagePart::Body)) {
                qCWarning(IMAPRESOURCE_LOG) << "Item " << item.id() << " is missing the payload! Cached payloads: " << item.cachedPayloadParts();
                uids.append(item.remoteId().toInt());
                i++;
            }
        }
```

#### AUTO 


```{c}
auto *req = new EwsCreateItemRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *c : contents) {
        //         qCDebug(PIMKOLAB_LOG) << "searching: " << c->contentID()->identifier();
        if (c->contentID()->identifier() == id) {
            type = c->contentType()->mimeType();
            name = c->contentType()->name();
            return c;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &p) {
        if (!testSecondSignal) {
            password = p;
            loop.exit(0);
        } else {
            loop.exit(1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            qCWarning(ETESYNC_LOG) << "Error in fetching journals";
            return;
        }
        qCDebug(ETESYNC_LOG) << "Retrieving collections";
        EteSyncJournal **journals = qobject_cast<JournalsFetchJob *>(job)->journals();
        Collection::List list;
        for (EteSyncJournal **iter = journals; *iter; iter++) {
            EteSyncJournalPtr journal(*iter);

            Collection collection;

            /// TODO: Remove temporary hack to handle only addressbooks
            if (setupCollection(collection, journal.get())) continue;

            list << collection;
        }
        free(journals);
        collectionsRetrieved(list);
    }
```

#### AUTO 


```{c}
auto attr = col.attribute<EwsSyncStateAttribute>();
```

#### AUTO 


```{c}
auto collection = fetchJob->property("collection").value<Akonadi::Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &descriptor : descriptors) {
        mSubscribedMailboxes.insert(descriptor.name);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &memberUrl : lstMemberUrl) {
        Kolab::RelationMember member = Kolab::parseMemberUrl(memberUrl);
        const Akonadi::Item i = extractMember(member);
        //TODO implement fallback to search if uid is not available
        if (!i.remoteId().isEmpty() || !i.gid().isEmpty()) {
            members << i;
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Failed to parse member: " << memberUrl;
        }
    }
```

#### AUTO 


```{c}
const auto *attr = collection.attribute<Akonadi::NewMailNotifierAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : changedItems) {
        EwsId id(item.remoteId(), item.remoteRevision());
        ids.append(id);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : lstKeys) {
        if (mMailCollections.contains(mailbox)) {
            const KIMAP::Acl::Rights imapRights = rights.value(mailbox);
            QStringList parts = mailbox.split(separatorCharacter());
            parts.removeLast();
            QString parentMailbox = parts.join(separatorCharacter());

            KIMAP::Acl::Rights parentImapRights;
            // If the parent folder is not existing we can't rename
            if (!parentMailbox.isEmpty() && rights.contains(parentMailbox)) {
                parentImapRights = rights.value(parentMailbox);
            }
            // qCDebug(KOLABRESOURCE_LOG) << mailbox << parentMailbox << imapRights << parentImapRights;

            Akonadi::Collection &collection = mMailCollections[mailbox];
            CollectionMetadataHelper::applyRights(collection, imapRights, parentImapRights);

            // Store the mailbox ACLs
            auto aclAttribute = collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
            const KIMAP::Acl::Rights oldRights = aclAttribute->myRights();
            if (oldRights != imapRights) {
                aclAttribute->setMyRights(imapRights);
            }
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Can't find mailbox " << mailbox;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &iType : toFetchItems.keys()) {
        for (int i = 0; i < toFetchItems[iType].size(); i += fetchBatchSize) {
            EwsItemHandler *handler = EwsItemHandler::itemHandler(static_cast<EwsItemType>(iType));
            if (!handler) {
                // TODO: Temporarily ignore unsupported item types.
                qCWarning(EWSRES_LOG) << QStringLiteral("Unable to initialize fetch for item type %1").arg(iType);
                /*setErrorMsg(QStringLiteral("Unable to initialize fetch for item type %1").arg(iType));
                emitResult();
                return;*/
            } else {
                EwsFetchItemDetailJob *job = handler->fetchItemDetailJob(mClient, this, mCollection);
                Item::List itemList = toFetchItems[iType].mid(i, fetchBatchSize);
                job->setItemLists(itemList, &mDeletedItems);
                connect(job, &KJob::result, this, &EwsFetchItemsJob::itemDetailFetchDone);
                addSubjob(job);
                fetch = true;
            }
        }
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(QIcon::fromTheme(QStringLiteral("dialog-ok-apply")), msg);
```

#### AUTO 


```{c}
const auto event = Kolab::fromXML<KCalendarCore::Todo::Ptr, KolabV2::Task>(QString::fromUtf8(s.c_str()).toUtf8(), attachments);
```

#### AUTO 


```{c}
auto search = new KIMAP::SearchJob(session);
```

#### AUTO 


```{c}
auto attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this, items](KJob *job) {
        if (job->error()) {
            m_iface->cancelTask(i18n("Failed to delete task: %1", job->errorString()));
            return;
        }
        const Item::List fetchedItems = qobject_cast<ItemFetchJob *>(job)->items();
        Item::List detachItems;
        TasksList detachTasks;
        for (const Item &fetchedItem : fetchedItems) {
            auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
            TaskPtr task(new Task(*todo));
            const QString parentId = task->relatedTo(KCalendarCore::Incidence::RelTypeParent);
            if (parentId.isEmpty()) {
                continue;
            }

            auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item) {
                return item.remoteId() == parentId;
            });
            if (it != items.cend()) {
                Item newItem(fetchedItem);
                qCDebug(GOOGLE_TASKS_LOG) << "Detaching child" << newItem.remoteId() << "from" << parentId;
                todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
                newItem.setPayload<KCalendarCore::Todo::Ptr>(todo);
                detachItems << newItem;
                detachTasks << task;
            }
        }
        /* If there are no items do detach, then delete the task right now */
        if (detachItems.isEmpty()) {
            doRemoveTasks(items);
            return;
        }

        qCDebug(GOOGLE_TASKS_LOG) << "Reparenting" << detachItems.count() << "children...";
        auto moveJob = new TaskMoveJob(detachTasks, items.first().parentCollection().remoteId(), QString(), m_settings->accountPtr(), this);
        connect(moveJob, &TaskMoveJob::finished, this, [this, items, detachItems](KGAPI2::Job *job) {
            if (job->error()) {
                m_iface->cancelTask(i18n("Failed to reparent subtasks: %1", job->errorString()));
                return;
            }
            // Update items inside Akonadi DB too
            new ItemModifyJob(detachItems);
            // Perform actual removal
            doRemoveTasks(items);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(mItems)) {
        itemId = EwsId(item.remoteId(), item.remoteRevision());

        if (mParts.contains("FLAGS")) {
            EwsUpdateItemRequest::ItemChange ic(itemId, EwsItemTypeMessage);
            QHash<EwsPropertyField, QVariant> propertyHash = EwsMailHandler::writeFlags(item.flags());

            for (auto it = propertyHash.cbegin(), end = propertyHash.cend(); it != end; ++it) {
                EwsUpdateItemRequest::Update *upd;
                if (it.value().isNull()) {
                    upd = new EwsUpdateItemRequest::DeleteUpdate(it.key());
                } else {
                    upd = new EwsUpdateItemRequest::SetUpdate(it.key(), it.value());
                }
                ic.addUpdate(upd);
            }

            req->addItemChange(ic);
            doSubmit = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection &col) {
        stateChanged(col);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int InitialReconnectTimeout = 15;
```

#### RANGE FOR STATEMENT 


```{c}
for (int idToSave : qAsConst(mIdsToSave)) {
            idsToDeleteFromServer.removeAll(idToSave);
        }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(mResourceCollection, CollectionFetchJob::Recursive, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : lstCols) {
            if (!collection.contentMimeTypes().contains(KolabHelpers::getMimeType(Kolab::ConfigurationType))) {
                // Skip parents of the actual Configuration folder
                continue;
            }
            const QString mailBox = mailBoxForCollection(collection);
            if (!mailBox.isEmpty()) {
                mRelationCollection = collection;
                startRelationTask(mImapSession);
                return;
            }
        }
```

#### AUTO 


```{c}
auto modifyJob = new CollectionModifyJob(c, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        itemFetchResult(job);
    }
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<FoldersRequestJob *>(job);
```

#### AUTO 


```{c}
auto req = new EwsCreateFolderRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folderId : ids) {
        xQueryFolderIds.append(QStringLiteral("//m:GetFolder/m:FolderIds/t:FolderId[position()=%1 and @Id=\"%2\"]")
                               .arg(++folderIndex).arg(folderId));
        responseXml += QStringLiteral("<m:GetFolderResponseMessage ResponseClass=\"Success\">");
        responseXml += QStringLiteral("<m:ResponseCode>NoError</m:ResponseCode>");
        responseXml += QStringLiteral("<m:Folders><t:Folder>");
        responseXml += QStringLiteral("<t:FolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folderId);
        responseXml += QStringLiteral("</t:Folder></m:Folders>");
        responseXml += QStringLiteral("</m:GetFolderResponseMessage>");
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto attr = m_rootCollection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &, const QSet<QByteArray> &) {
        settleTimer.start(serverSettleTimeout);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &entry : entries) {
        if (!entry) {
            qCDebug(ETESYNC_LOG) << "SetupItems: Entry is null";
            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            continue;
        }
        EteSyncSyncEntryPtr syncEntry = etesync_entry_get_sync_entry(entry.get(), cryptoManager.get(), prevUid);

        if (!syncEntry) {
            qCDebug(ETESYNC_LOG) << "SetupItems: syncEntry is null for entry" << etesync_entry_get_uid(entry.get());
            qCDebug(ETESYNC_LOG) << "EteSync error" << QStringFromCharPtr(CharPtr(etesync_get_error_message()));
            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            continue;
        }

        CharPtr contentStr(etesync_sync_entry_get_content(syncEntry.get()));

        KCalendarCore::ICalFormat format;
        const KCalendarCore::Incidence::Ptr incidence = format.fromString(QStringFromCharPtr(contentStr));

        if (!incidence || (incidence->uid()).isEmpty()) {
            qCDebug(ETESYNC_LOG) << "Couldn't parse entry with uid" << etesync_entry_get_uid(entry.get());
            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            continue;
        }

        qCDebug(ETESYNC_LOG) << "Entry parsed into incidence - UID" << incidence->uid();

        const QString action = QStringFromCharPtr(CharPtr(etesync_sync_entry_get_action(syncEntry.get())));
        if (action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_ADD) || action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_CHANGE)) {
            incidences[incidence->uid()] = incidence;
        } else if (action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_DELETE)) {
            if (incidences.contains(incidence->uid())) {
                incidences.remove(incidence->uid());
            } else {
                Item item;
                item.setMimeType(mimeType());
                item.setParentCollection(collection);
                item.setRemoteId(incidence->uid());
                removedItems.push_back(item);

                deleteLocalCalendar(incidence->uid());
            }
        }

        prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
    }
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(collection, CollectionFetchJob::Base);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &oldId : oldIds) {
                if (!ids.contains(oldId)) {
                    KIMAP::SetAclJob *job = new KIMAP::SetAclJob(session);
                    job->setMailBox(mailBoxForCollection(collection()));
                    job->setIdentifier(oldId);
                    job->setRights(KIMAP::SetAclJob::Remove, oldRights[oldId]);

                    connect(job, &KIMAP::SetAclJob::result, this, &ChangeCollectionTask::onSetAclDone);

                    job->start();

                    m_pendingJobs++;
                }
            }
```

#### AUTO 


```{c}
auto w = new QWidget(parent);
```

#### AUTO 


```{c}
auto textToSpeakLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto job = new EntriesFetchJob(mClientState->account(), collection, std::move(etesyncCollection), itemsCacheDirectoryPath(), this);
```

#### AUTO 


```{c}
const auto &c
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### AUTO 


```{c}
const auto endTime = data.constFind(QLatin1String("end_time"));
```

#### AUTO 


```{c}
auto *urlStandardItem = new QStandardItem(url);
```

#### AUTO 


```{c}
auto folderJob = qobject_cast<EwsSubscribedFoldersJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&oAuth, &events, password](bool) {
            events.append("RequestWalletPassword");
            oAuth.walletPasswordRequestFinished(password);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=, &tokenReplyData](QString &data, QMap<Mock::QNetworkRequest::KnownHeaders, QVariant> &headers) {
            QVariantMap map;
            map[QStringLiteral("token_type")] = QStringLiteral("Bearer");
            map[QStringLiteral("scope")] = QStringLiteral("ReadWrite.All");
            map[QStringLiteral("expires_in")] = QString::number(tokenLifetime);
            map[QStringLiteral("ext_expires_in")] = QString::number(extTokenLifetime);
            map[QStringLiteral("expires_on")] = QString::number(time + tokenLifetime);
            map[QStringLiteral("not_before")] = QString::number(time);
            map[QStringLiteral("resource")] = resource;
            map[QStringLiteral("access_token")] = accessToken;
            map[QStringLiteral("refresh_token")] = refreshToken;
            map[QStringLiteral("foci")] = QStringLiteral("1");
            map[QStringLiteral("id_token")] = idToken;
            tokenReplyData = formatJsonSorted(map);
            data = tokenReplyData;
            headers[Mock::QNetworkRequest::ContentTypeHeader] = QStringLiteral("application/json; charset=utf-8");

            return Mock::QNetworkReply::NoError;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : std::as_const(mFetchItemsJobQueue)) {
        dump += QStringLiteral(" %1:%2\n").arg(item.col.id()).arg(item.type);
    }
```

#### AUTO 


```{c}
auto *fjob = new ItemFetchJob(collection);
```

#### AUTO 


```{c}
auto *attr = new ImapAclAttribute();
```

#### AUTO 


```{c}
auto srcCol = req->property("sourceCollection").value<Collection>();
```

#### AUTO 


```{c}
auto state = mStateHash.find(remoteId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : cols) {
        if (!contactFilter.isWantedCollection(col)) {
            continue;
        }
        ItemFetchJob *job = new ItemFetchJob(col, this);
        job->fetchScope().fetchFullPayload();
        connect(job, &ItemFetchJob::itemsReceived, this, &BirthdaysResource::createEvents);
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(akonadiGoogleGroupwareResource.toString(), this);
```

#### AUTO 


```{c}
const auto keyval = token.trimmed().split(QLatin1Char('='));
```

#### AUTO 


```{c}
auto cjob = new EventCreateJob(kevent, collection.remoteId(), account(), this);
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(content, srv->portNumber(), [&](const QString &chunk) {
        const QString respHead = QStringLiteral(
            "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
            "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
            "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
            "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
            "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
            "<soap:Header>"
            "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
            "</soap:Header>"
            "<soap:Body>"
            "<m:GetStreamingEventsResponse>"
            "<m:ResponseMessages>"
            "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
            "<m:ResponseCode>NoError</m:ResponseCode>"
            "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral(
            "</m:GetStreamingEventsResponseMessage>"
            "</m:ResponseMessages>"
            "</m:GetStreamingEventsResponse>"
            "</soap:Body>"
            "</soap:Envelope>");
        const QString eventHead = QStringLiteral(
            "<m:Notifications>"
            "<m:Notification>"
            "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral(
            "<NewMailEvent>"
            "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
            "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
            "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
            "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediately" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    });
```

#### AUTO 


```{c}
auto *updJob = qobject_cast<EwsUpdateItemsTagsJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : lstItems) {
            if (!item.cachedPayloadParts().contains(Akonadi::MessagePart::Body)) {
                qCWarning(IMAPRESOURCE_LOG) << "Item " << item.id() << " is missing the payload! Cached payloads: " << item.cachedPayloadParts();
                uids.append(item.remoteId().toInt());
                i++;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &date : exceptionDates) {
                deleteExceptions.append(OXUtils::readDate(date));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : qAsConst(folderTypeNames)) {
        if (name == reader.name()) {
            d->mType = static_cast<EwsFolderType>(i);
            break;
        }
        i++;
    }
```

#### AUTO 


```{c}
auto h = new KMime::Headers::Generic(X_KOLAB_TYPE_HEADER);
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsModifyItemFlagsJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (int prot : qAsConst(supportedAuths)) {
        authCombo->addItem(Transport::authenticationTypeString(prot), prot);
    }
```

#### AUTO 


```{c}
auto *attr = c.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto createJob = new Akonadi::TagCreateJob(tag, this);
```

#### AUTO 


```{c}
auto deleteJob = new Akonadi::ItemDeleteJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : qAsConst(mDeletedOffsets)) {
            deletedEntries << KMBox::MBoxEntry(offset);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Attachment &a : attachments) {
        if (!a.uri().empty()) {
            Akonadi::NoteUtils::Attachment attachment(QUrl(fromStdString(a.uri())), fromStdString(a.mimetype()));
            attachment.setLabel(fromStdString(a.label()));
            note.attachments().append(attachment);
        } else {
            Akonadi::NoteUtils::Attachment attachment(fromStdString(a.data()).toLatin1(), fromStdString(a.mimetype()));
            attachment.setLabel(fromStdString(a.label()));
            note.attachments().append(attachment);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            dispatch();
        }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavItemFetchJob(davItem);
```

#### AUTO 


```{c}
const auto tagListHash = var.value<QHash<QString, QVariant>>();
```

#### AUTO 


```{c}
auto *fetch = new KIMAP::FetchJob(m_session);
```

#### AUTO 


```{c}
const auto data = obj.value(QLatin1String("data")).toArray();
```

#### AUTO 


```{c}
auto job = new OXA::FoldersRequestJob(0, OXA::FoldersRequestJob::Modified, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &childId : children) {
        FolderDescr &childFd = mFolderHash[childId];
        if (!childFd.isProcessed() && childFd.isModified() && childFd.parent() != childFd.collection.parentCollection().remoteId()) {
            qCDebugNC(EWSRES_LOG) << QStringLiteral("Found moved collection");
            /* Found unprocessed collection move. */
            moveCollection(childFd);
        }

        childFd.collection.setParentCollection(fd.collection);
        reparentRemoteFolder(childId);
    }
```

#### AUTO 


```{c}
auto w = new NewMailNotifierSelectCollectionWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setMap(expectedMap);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return false;
                                    };
        wallet->createFolderCallback = [&createFolderCalled](const QString &) {
                                           createFolderCalled = true;
                                           return true;
                                       };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return false;
                                    };
        wallet->writeMapCallback = [&](const QString &, const QMap<QString, QString> &m) {
                                       map = m;
                                       loop.exit(0);
                                       return true;
                                   };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsFetchFoldersJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &root : std::as_const(allRoots)) {
        const QMap<QByteArray, qint64> limit = quotaJob->allLimits(root);
        const QMap<QByteArray, qint64> usage = quotaJob->allUsages(root);

        // Process IMAP Quota roots with associated quotas only
        if (!limit.isEmpty() && !usage.isEmpty()) {
            newRoots << root;
            newLimits << limit;
            newUsages << usage;

            const QString &decodedRoot = QString::fromUtf8(KIMAP::decodeImapFolderName(root));

            if (decodedRoot == mailBox) {
                newCurrent = newUsages.last()["STORAGE"] * 1024;
                newMax = newLimits.last()["STORAGE"] * 1024;
            }
        }
    }
```

#### AUTO 


```{c}
auto kJournal = fromXML<KCalendarCore::Journal::Ptr, KolabV2::Journal>(xmlData, attachments);
```

#### AUTO 


```{c}
auto *attr = collection.attribute<Akonadi::NewMailNotifierAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (quint64 offset : std::as_const(mDeletedItemOffsets)) {
        serialized += QByteArray::number(offset) + ',';
    }
```

#### AUTO 


```{c}
auto *list = new KIMAP::ListJob(m_session);
```

#### AUTO 


```{c}
auto *itemJob = qobject_cast<FileStore::ItemMoveJob *>(job);
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned ChunkSize = 10;
```

#### AUTO 


```{c}
const auto me = json.object();
```

#### AUTO 


```{c}
const auto collection = collectionVariant.value<Collection>();
```

#### AUTO 


```{c}
auto metadata = new RetrieveMetadataJob(mSession,
                                                metadataMailboxes,
                                                serverCapabilities(),
                                                mRequestedMetadata,
                                                separatorCharacter(),
                                                resourceState()->sharedNamespaces(),
                                                resourceState()->userNamespaces(),
                                                this);
```

#### AUTO 


```{c}
auto attr = col.attribute<EntityDisplayAttribute>();
```

#### AUTO 


```{c}
auto *s = sessionSpy.at(0).at(1).value<KIMAP::Session *>();
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<UsersRequestJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts)  {
        if (part.startsWith("PLD:")) {
            payloadChanged = true;
        }
        if (part.contains("FLAGS")) {
            flagsChanged = true;
        }
    }
```

#### AUTO 


```{c}
auto *expunge = new KIMAP::ExpungeJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &a : list) {
        result += a + c;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mail : mails) {
        QCOMPARE(e.custom(QLatin1String("KOLAB"), QString::fromLatin1("EmailTypes%1").arg(mail)),
                 kcal.custom(QLatin1String("KOLAB"), QString::fromLatin1("EmailTypes%1").arg(mail)));
    }
```

#### AUTO 


```{c}
auto attendees = incidence->attendees();
```

#### AUTO 


```{c}
auto textSpeakWidget = new QWidget;
```

#### AUTO 


```{c}
auto job = new EventFetchJob(collection.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto tagJob = qobject_cast<TagFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &scope : resourceScopes) {
            if (!m_account->scopes().contains(scope)) {
                m_account->addScope(scope);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const EwsUpdateItemRequest::ItemChange::List::const_iterator &firstChange,
                   const EwsUpdateItemRequest::ItemChange::List::const_iterator &lastChange) {
                auto req = new EwsUpdateItemRequest(mClient, this);
                req->addItemChanges(firstChange, lastChange);
                return req;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uid : qAsConst(uidsOfMessagesDownloadedButNotDeleted)) {
        if (!seenUIDs.contains(uid)) {
            seenUIDs.append(uid);
            timeOfSeenUIDs.append(time(nullptr));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->taskListsBox->setDisabled(true);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeTaskLists;
        if (m_account->accountName() == m_settings->account()) {
            activeTaskLists = m_settings->taskLists();
        }
        m_ui->taskListsList->clear();
        for (const ObjectPtr &object : objects) {
            const TaskListPtr taskList = object.dynamicCast<TaskList>();

            QListWidgetItem *item = new QListWidgetItem(taskList->title());
            item->setData(Qt::UserRole, taskList->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->taskListsList->addItem(item);
        }

        m_ui->taskListsBox->setEnabled(true);
    }
```

#### AUTO 


```{c}
const auto session{m_unusedPool + m_reservedPool + m_connectingPool};
```

#### AUTO 


```{c}
auto syncFoldersReq = new EwsSyncFolderHierarchyRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const SetupWizard::Url &url : urls) {
        DavUtils::DavUrl davUrl;
        davUrl.setProtocol(url.protocol);

        QUrl serverUrl(url.url);
        serverUrl.setUserName(wizard()->field(QStringLiteral("credentialsUserName")).toString());
        serverUrl.setPassword(wizard()->field(QStringLiteral("credentialsPassword")).toString());
        davUrl.setUrl(serverUrl);

        davUrls << davUrl;
    }
```

#### AUTO 


```{c}
auto store = new KIMAP::StoreJob(mSession);
```

#### AUTO 


```{c}
auto *resetButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto *attr = collection.attribute<DefaultReminderAttribute>();
```

#### AUTO 


```{c}
auto job = new GetTokenJob(qobject_cast<FacebookResource *>(parent()));
```

#### AUTO 


```{c}
auto *authJob = qobject_cast<AuthJob *>(job);
```

#### AUTO 


```{c}
auto task = new ChangeCollectionTask(createResourceState(TaskArguments(collection, p)), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
        i.setFlag(flag);
    }
```

#### AUTO 


```{c}
auto attr = collection.attribute<EntityDisplayAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &zone : zones) {
        const QString cityName = zone.split('/').last();
        Q_ASSERT(!countryMap.contains(cityName));
        countryMap.insert(cityName, zone);
    }
```

#### AUTO 


```{c}
const auto res = instances.calendarResource.isValid() ? instances.calendarResource.identifier() : instances.contactResource.identifier();
```

#### AUTO 


```{c}
auto job = new CollectionModifyJob(col, Private::mInstance->parent());
```

#### AUTO 


```{c}
auto item = job->property("item").value<Akonadi::Item>();
```

#### AUTO 


```{c}
const auto *attr = collection.attribute<CompatibilityAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready) {
        if (ready) {
            m_account = m_settings->accountPtr();
            accountChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Collection & col) {
        stateChanged(col);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::AccountPromise *promise) {
            if (promise->account()) {
                promise = KGAPI2::AccountManager::instance()->refreshTokens(
                    GOOGLE_API_KEY, GOOGLE_API_SECRET, mResource->settings()->userName());
            } else {
                promise = KGAPI2::AccountManager::instance()->getAccount(
                    GOOGLE_API_KEY, GOOGLE_API_SECRET, mResource->settings()->userName(),
                    { KGAPI2::Account::mailScopeUrl() });
            }
            connect(promise, &KGAPI2::AccountPromise::finished,
                    this, &GmailPasswordRequester::onTokenRequestFinished);
            mPendingPromise = promise;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &msg) {
            qDebug() << "failed" << msg;
            loop.exit(1);
            status = 1;
        }
```

#### AUTO 


```{c}
auto *uidNext = relationCollection().attribute<UidNextAttribute>();
```

#### AUTO 


```{c}
auto *select = new KIMAP::SelectJob(move->session());
```

#### AUTO 


```{c}
auto *job = new KIMAP::UnsubscribeJob(session);
```

#### AUTO 


```{c}
auto rightsJob = qobject_cast<KIMAP::MyRightsJob *>(job);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsSubscribedFoldersJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : qAsConst(topLevelList)) {
            reparentRemoteFolder(id);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setMap(expectedMap);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return false;
        };
        wallet->createFolderCallback = [&createFolderCalled](const QString &) {
            createFolderCalled = true;
            return true;
        };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return false;
        };
        wallet->writeMapCallback = [&](const QString &, const QMap<QString, QString> &m) {
            map = m;
            loop.exit(0);
            return true;
        };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto updJob = qobject_cast<EwsUpdateItemsTagsJob *>(job);
```

#### AUTO 


```{c}
auto *subscribeJob = new KIMAP::SubscribeJob(renameJob->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsFetchItemsJob *fetchJob) {
        auto collection = fetchJob->collection();
        if (fetchJob->error()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Item fetch error:") << fetchJob->errorString() << fetchJob->error();
            synchronizeCollection(collection.id());
        } else {
            const auto newItems = fetchJob->newItems();
            for (const auto &newItem : newItems) {
                new ItemCreateJob(newItem, collection, this);
            }
            if (!fetchJob->changedItems().isEmpty()) {
                new ItemModifyJob(fetchJob->changedItems());
            }
            if (!fetchJob->deletedItems().isEmpty()) {
                new ItemDeleteJob(fetchJob->deletedItems());
            }
            saveCollectionSyncState(collection, fetchJob->syncState());
            emitReadyStatus();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return true;
                                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, account, instances](KJob *) {
        if (job->error()) {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: Failed to create new Google Groupware Resource:" << job->errorString();
            message(Error, i18n("Failed to create a new Google Groupware Resource: %1", job->errorString()));
            setMigrationState(MigratorBase::Failed);
            return;
        }

        const auto newInstance = job->instance();
        if (!migrateAccount(account, instances, newInstance)) {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: failed to migrate account" << account;
            message(Error, i18n("Failed to migrate account %1", account));
            setMigrationState(MigratorBase::Failed);
            return;
        }

        removeLegacyInstances(account, instances);

        // Reconfigure and restart the new instance
        newInstance.reconfigure();
        newInstance.restart();

        if (instances.calendarResource.isValid() ^ instances.contactResource.isValid()) {
            const auto res = instances.calendarResource.isValid()
                             ? instances.calendarResource.identifier()
                             : instances.contactResource.identifier();
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from" << res
                                  << "to" << newInstance.identifier();
        } else {
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from"
                                  << instances.calendarResource.identifier() << "and"
                                  << instances.contactResource.identifier() << "to"
                                  << newInstance.identifier();
        }
        message(Success, i18n("Migrated account %1 to new Google Groupware Resource", account));

        ++mMigrationsDone;
        migrateNextAccount();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { doTransport(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        itemId = EwsId(item.remoteId(), item.remoteRevision());

        if (mParts.contains("FLAGS")) {
            EwsUpdateItemRequest::ItemChange ic(itemId, EwsItemTypeMessage);
            QHash<EwsPropertyField, QVariant> propertyHash = EwsMailHandler::writeFlags(item.flags());

            for (auto it = propertyHash.cbegin(), end = propertyHash.cend(); it != end; ++it) {
                EwsUpdateItemRequest::Update *upd;
                if (it.value().isNull()) {
                    upd = new EwsUpdateItemRequest::DeleteUpdate(it.key());
                } else {
                    upd = new EwsUpdateItemRequest::SetUpdate(it.key(), it.value());
                }
                ic.addUpdate(upd);
            }

            req->addItemChange(ic);
            doSubmit = true;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        itemCreateJobResult(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::ContactReference &ref : list) {
        if (delegatorRef.uid() == ref.uid() || delegatorRef.email() == ref.email() || delegatorRef.name() == ref.name()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto rejectedFn = std::bind(&EwsResource::reauthNotificationDismissed, this, false);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &id : ids) {
                auto *job = new KIMAP::SetAclJob(session);
                job->setMailBox(mailBoxForCollection(collection()));
                job->setIdentifier(id);
                job->setRights(KIMAP::SetAclJob::Change, rights[id]);

                connect(job, &KIMAP::SetAclJob::result, this, &ChangeCollectionTask::onSetAclDone);

                job->start();

                m_pendingJobs++;
            }
```

#### AUTO 


```{c}
auto job = new ContactsGroupModifyJob(group, m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {d->itemFetched(job); }
```

#### AUTO 


```{c}
auto attr = collection.attribute<DefaultReminderAttribute>();
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("A password is required for user %1", (user == QLatin1String("$default$") ? defaultUsername() : user)), mainWidget);
```

#### AUTO 


```{c}
auto aclAttribute = new Akonadi::ImapAclAttribute();
```

#### AUTO 


```{c}
auto msg = new KMime::Message;
```

#### AUTO 


```{c}
auto mimeTypeProxy = new Akonadi::CollectionFilterProxyModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::Address &a : contactAddresses) {
        Kolab::Address adr;
        bool pref = false;
        adr.setTypes(fromAddressType(a.type(), pref));
        prefCounter++;
        if (pref) {
            prefNum = prefCounter;
        }
        adr.setLabel(toStdString(a.label()));
        adr.setStreet(toStdString(a.street()));
        adr.setLocality(toStdString(a.locality()));
        adr.setRegion(toStdString(a.region()));
        adr.setCode(toStdString(a.postalCode()));
        adr.setCountry(toStdString(a.country()));
        addresses.push_back(adr);
    }
```

#### AUTO 


```{c}
auto page = qobject_cast<WebPage*>(mView->page());
```

#### AUTO 


```{c}
auto req = new EwsUpdateFolderRequest(mEwsClient, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&callbackOk](const QString &, QXmlResultItems &ri, const QXmlNamePool &)
            {
                if (ri.hasError()) {
                    qDebug() << "XQuery result has errors.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlItem item = ri.next();
                if (item.isNull()) {
                    qDebug() << "XQuery result has no items.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (!item.isNode()) {
                    qDebug() << "XQuery result is not a XML node.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlNodeModelIndex index = item.toNodeModelIndex();
                if (index.isNull()) {
                    qDebug() << "XQuery XML node is NULL.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (index.model()->stringValue(index) != QStringLiteral("test")) {
                    qDebug() << "Unexpected item value:" << index.model()->stringValue(index);
                    return FakeEwsServer::EmptyResponse;
                }
                return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<b/>"), 200);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::ContactReference &m : members) {
        switch (m.type()) {
        case Kolab::ContactReference::EmailReference:
            cg.append(KContacts::ContactGroup::Data(fromStdString(m.name()), fromStdString(m.email())));
            break;
        case Kolab::ContactReference::UidReference:
            cg.append(KContacts::ContactGroup::ContactReference(fromStdString(m.uid())));
            break;
        default:
            qCCritical(PIMKOLAB_LOG) << "invalid contact reference";
        }
    }
```

#### AUTO 


```{c}
auto *modifyJob = qobject_cast<OXA::ObjectModifyJob *>(job);
```

#### AUTO 


```{c}
const auto flags{EwsMailHandler::readFlags(ewsItem)};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::ContactGroup::ContactReference &ref : std::as_const(toAdd)) {
        gidOnlyContactGroup.append(ref);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : results) {
        if (result.value.startsWith(QLatin1Char('/'))) {
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            QUrl tmp(result.value);
            tmp.setUserInfo(QString());
            url = tmp;
        }
        davUrl.setUrl(url);

        if (result.property == caldav->principalHomeSet()) {
            davUrl.setProtocol(KDAV::CalDav);
        } else {
            davUrl.setProtocol(KDAV::CardDav);
        }

        KDAV::DavCollectionsFetchJob *fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
        connect(fetchJob, & KDAV::DavCollectionsFetchJob::result, this, &SearchDialog::onCollectionsFetchJobFinished);
        fetchJob->start();
        ++mSubJobCount;
    }
```

#### AUTO 


```{c}
auto parentIt = mFolderHash.find(it->parent());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cookie : parsedCookies) {
                    mCookies += QStringLiteral("%1=%2; ").arg(QString::fromUtf8(cookie.name()),
                                                              QString::fromUtf8(cookie.value()));
                }
```

#### AUTO 


```{c}
auto fetchJob = new FetchJob(mPopSession);
```

#### AUTO 


```{c}
auto tokenJob = new GetTokenJob(qobject_cast<FacebookResource *>(parent()));
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsFindFolderRequest *>(job);
```

#### AUTO 


```{c}
auto createJob = qobject_cast<ItemCreateJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &) {
            settleTimer.start(serverSettleTimeout);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &exception : qAsConst(exceptions)) {
            if (exception->status() == KCalCore::Incidence::StatusCanceled) {
                KDateTime exDateTime = exception->recurrenceId();
                mainIncidence->recurrence()->addExDateTime(exDateTime);
            } else {
                // The exception remote id will contain a fragment pointing to
                // its instance identifier to distinguish it from the main
                // event.
                QString rid = target.remoteId() + QLatin1String("#") + exception->instanceIdentifier();
                qCDebug(DAVRESOURCE_LOG) << "Extra incidence at" << rid;
                Akonadi::Item extraItem = target;
                extraItem.setRemoteId(rid);
                extraItem.setRemoteRevision(source.etag());
                extraItem.setMimeType(exception->mimeType());
                extraItem.setPayload<IncidencePtr>(exception);
                extraItems << extraItem;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : std::as_const(mFetchItemsJobQueue).mid(1)) {
            if ((item.col == col) && (item.type == type)) {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Sync already queued - skipping");
                return;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
            if (idList.contains(item.id())) {
                idList.removeAll(item.id());
                itemFound = true;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                qCDebug(GOOGLE_TASKS_LOG) << "Task lists retrieved";

                const ObjectsList taskLists = qobject_cast<TaskListFetchJob *>(job)->items();
                const QStringList activeTaskLists = m_settings->taskLists();
                Collection::List collections;
                for (const ObjectPtr &object : taskLists) {
                    const TaskListPtr &taskList = object.dynamicCast<TaskList>();
                    qCDebug(GOOGLE_TASKS_LOG) << " -" << taskList->title() << "(" << taskList->uid() << ")";

                    if (!activeTaskLists.contains(taskList->uid())) {
                        qCDebug(GOOGLE_TASKS_LOG) << "Skipping, not subscribed";
                        continue;
                    }

                    Collection collection;
                    setupCollection(collection, taskList);
                    collection.setParentCollection(rootCollection);
                    collections << collection;
                }

                m_iface->collectionsRetrievedFromHandler(collections);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FolderChange &ch : qAsConst(mChanges)) {
        ch.write(writer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::NoteUtils::Attachment &a : noteAttachments) {
        Kolab::Attachment attachment;
        if (a.url().isValid()) {
            attachment.setUri(toStdString(a.url().toString()), toStdString(a.mimetype()));
        } else {
            attachment.setData(toStdString(QString::fromUtf8(a.data())), toStdString(a.mimetype()));
        }
        attachment.setLabel(toStdString(a.label()));
        attachments.push_back(attachment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &col : collections) {
            const auto remoteId = col.remoteId();
            const auto state = mStateHash.find(remoteId);
            if (state != mStateHash.end()) {
                stateChanged(col);
            }
        }
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(col, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
const auto iType
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(items, this);
```

#### AUTO 


```{c}
const auto collection = map[QStringLiteral("collection")].value<Collection>();
```

#### AUTO 


```{c}
auto *select = qobject_cast<KIMAP::SelectJob *>(job);
```

#### AUTO 


```{c}
auto attr = c.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *resp = new EwsFindItemResponse(reader);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            auth->walletMapRequestFinished(mAuthMap);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item item : std::as_const(origItems)) { // krazy:exclude=foreach non-const is intended here
        const KDAV::DavItem davItem = davJob->item(item.remoteId());

        // No data was retrieved for this item, maybe because it is not out of date
        if (davItem.data().isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Empty item returned. " << item.remoteId();
            if (!cache->isOutOfDate(item.remoteId())) {
                qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Item is not changed, including it. " << item.remoteId();
                items << item;
            }
            continue;
        }

        Akonadi::Item::List extraItems;
        if (!Utils::parseDavData(davItem, item, extraItems)) {
            qCWarning(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Failed to parse item data. " << item.remoteId();
            continue;
        }

        // update etag
        item.setRemoteRevision(davItem.etag());
        cache->setEtag(item.remoteId(), davItem.etag());
        items << item;
        for (const Akonadi::Item &extraItem : std::as_const(extraItems)) {
            cache->setEtag(extraItem.remoteId(), davItem.etag());
            items << extraItem;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto iType : toFetchItems.keys()) {
        for (int i = 0; i < toFetchItems[iType].size(); i += fetchBatchSize) {
            EwsItemHandler *handler = EwsItemHandler::itemHandler(static_cast<EwsItemType>(iType));
            if (!handler) {
                // TODO: Temporarily ignore unsupported item types.
                qCWarning(EWSRES_LOG) << QStringLiteral("Unable to initialize fetch for item type %1")
                    .arg(iType);
                /*setErrorMsg(QStringLiteral("Unable to initialize fetch for item type %1").arg(iType));
                emitResult();
                return;*/
            } else {
                EwsFetchItemDetailJob *job = handler->fetchItemDetailJob(mClient, this, mCollection);
                Item::List itemList = toFetchItems[iType].mid(i, fetchBatchSize);
                job->setItemLists(itemList, &mDeletedItems);
                connect(job, &KJob::result, this, &EwsFetchItemsJob::itemDetailFetchDone);
                addSubjob(job);
                fetch = true;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &root : std::as_const(roots)) {
        mRoots << root.trimmed().toUtf8();
    }
```

#### AUTO 


```{c}
auto *conn = new FakeEwsConnection(sock, this);
```

#### AUTO 


```{c}
auto tjob = qobject_cast<KIO::StoredTransferJob *>(job);
```

#### AUTO 


```{c}
auto job = new KGAPI2::FreeBusyQueryJob(email,
                                            QDateTime::currentDateTimeUtc(),
                                            QDateTime::currentDateTimeUtc().addSecs(3600),
                                            const_cast<CalendarResource*>(this)->account(),
                                            const_cast<CalendarResource*>(this));
```

#### AUTO 


```{c}
auto page = new QWidget(this);
```

#### AUTO 


```{c}
auto col = SingleFileResource<Settings>::rootCollection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &value : entries) {
            convertedEntries.push_back(Conversion::toStdString(value));
        }
```

#### AUTO 


```{c}
auto fetchJob = new ItemFetchJob(tagContext.mItem);
```

#### AUTO 


```{c}
auto job = new KGAPI2::FreeBusyQueryJob(email,
                                            QDateTime::currentDateTimeUtc(),
                                            QDateTime::currentDateTimeUtc().addSecs(3600),
                                            const_cast<CalendarResource *>(this)->account(),
                                            const_cast<CalendarResource *>(this));
```

#### AUTO 


```{c}
auto job = new KIMAP::CapabilitiesJob(session1);
```

#### AUTO 


```{c}
auto fetchJob = new KIMAP::FetchJob(mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Freebusy &fb : fbList) {
        const QDateTime &tmpStart = Kolab::Conversion::toDate(fb.start());
        if (!start.isValid() || tmpStart < start) {
            start = tmpStart;
            allDay |= fb.start().isDateOnly();
        }
        const QDateTime &tmpEnd = Kolab::Conversion::toDate(fb.end());
        if (!end.isValid() || tmpEnd > end) {
            end = tmpEnd;
            allDay |= fb.start().isDateOnly();
        }

        Q_FOREACH (const Kolab::FreebusyPeriod &period, fb.periods()) {
            Kolab::FreebusyPeriod simplifiedPeriod;
            simplifiedPeriod.setPeriods(period.periods());
            simplifiedPeriod.setType(period.type());
            if (!simple) { // Don't copy and reset to avoid unintentional information leaking into simple lists
                simplifiedPeriod.setEvent(period.eventSummary(), period.eventUid(), period.eventLocation());
            }
            periods.push_back(simplifiedPeriod);
        }
    }
```

#### AUTO 


```{c}
auto *rename = static_cast<KIMAP::RenameJob *>(job);
```

#### AUTO 


```{c}
const auto addedTags{resourceState()->addedTags()};
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("removeEvent:")
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QMap<QString, QString> &m) {
                                       map = m;
                                       loop.exit(0);
                                       return true;
                                   }
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<OXA::ObjectRequestJob *>(job);
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<OXA::FoldersRequestJob *>(job);
```

#### AUTO 


```{c}
auto *modifiedJob = new ObjectsRequestJob(mFolder, mLastSync, ObjectsRequestJob::Modified, this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QMap<QString, QString> &map) {
            map[accessTokenMapKey] = QStringLiteral("afoo");
            map[refreshTokenMapKey] = QStringLiteral("rfoo");
            return true;
        }
```

#### AUTO 


```{c}
auto dowIndex = decodeEnumString<short>(day, dayOfWeekNames, dayOfWeekNameCount, &ok);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        Q_FOREACH (const Tag &tag, item.tags()) {
            if (!mTagStore->containsId(tag.id())) {
                unknownTags.append(tag);
            }
        }
    }
```

#### AUTO 


```{c}
auto *fetchJob = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### AUTO 


```{c}
auto *listJob = new ListJob(mPopSession);
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyItemUploadJob*>(kjob);
```

#### AUTO 


```{c}
auto tz = QTimeZone(spec.timeZone().name().toUtf8());
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsDeleteItemRequest::Response &resp : responses) {
        qDebug() << "Verifying response" << i++;
        QCOMPARE(resp.responseClass(), *respClassesIt);
        respClassesIt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : query.queryItems()) {
        varmap[item.first] = item.second;
    }
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto place = placeIt->toObject();
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : qAsConst(mIdsToSave)) {
                    sizeOnServerAfterDeletion += mIdsToSizeMap.value(id);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const Item &item){
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        contact->addGroup(collection.remoteId());
        return contact;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(items)) {
        Q_FOREACH (const QByteArray &flag, item.flags()) {
            ++flagCounts[flag];
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : certs.certificates()) {
        if (c.issuerInfo() == authoritiesInfo) {
            cert = c;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *j = new Akonadi::ItemModifyJob(dependentItems);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->taskListsList->setDisabled(true);
            m_ui->reloadTaskListsBtn->setDisabled(true);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeTaskLists;
        if (m_account->accountName() == m_settings->account()) {
            activeTaskLists = m_settings->taskLists();
        }
        m_ui->taskListsList->clear();
        for (const ObjectPtr &object : objects) {
            const TaskListPtr taskList = object.dynamicCast<TaskList>();

            auto item = new QListWidgetItem(taskList->title());
            item->setData(Qt::UserRole, taskList->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->taskListsList->addItem(item);
        }

        m_ui->taskListsList->setEnabled(true);
        m_ui->reloadTaskListsBtn->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto todo = item.payload<KCalendarCore::Todo::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &kcalEvent : qAsConst(events)) {
        if (kcalEvent->alarms().isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KCalendarCore::Event has no alarms:" << kcalEvent->uid();
            continue;    // ignore events without alarms
        }

        const KAEvent event(kcalEvent);
        const QString mime = CalEvent::mimeType(event.category());
        if (mime.isEmpty()) {
            qCWarning(KALARMRESOURCE_LOG) << identifier() << "doRetrieveItems: KAEvent has no alarms:" << event.id();
            continue;   // event has no usable alarms
        }

        Item item(mime);
        item.setRemoteId(kcalEvent->uid());
        item.setPayload(event);
        items << item;
    }
```

#### AUTO 


```{c}
auto *j = qobject_cast<Akonadi::ItemModifyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &folder : list) {
        if (folder.type == IsolatedTestBase::Folder::Root) {
            continue;
        }
        xml += QStringLiteral("<t:Create>");
        xml += QStringLiteral("<t:Folder>");
        xml += QStringLiteral("<t:FolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folder.id);
        xml += QStringLiteral("<t:ParentFolderId Id=\"%1\" ChangeKey=\"MDAx\" />").arg(folder.parentId);
        QString folderClass;
        QString extraXml;
        switch (folder.type) {
        case IsolatedTestBase::Folder::Calendar:
            folderClass = QStringLiteral("IPF.Calendar");
            break;
        case IsolatedTestBase::Folder::Contacts:
            folderClass = QStringLiteral("IPF.Contacts");
            break;
        case IsolatedTestBase::Folder::Tasks:
            folderClass = QStringLiteral("IPF.Tasks");
            break;
        default:
            folderClass = QStringLiteral("IPF.Note");
            extraXml = QStringLiteral("<t:UnreadCount>0</t:UnreadCount>");
        }
        xml += QStringLiteral("<t:FolderClass>%1</t:FolderClass>").arg(folderClass);
        xml += QStringLiteral("<t:TotalCount>0</t:TotalCount>");
        xml += QStringLiteral("<t:DisplayName>%1</t:DisplayName>").arg(folder.name);
        xml += QStringLiteral("<t:ChildFolderCount>%1</t:ChildFolderCount>").arg(childCount[folder.id]);
        xml += extraXml;
        xml += QStringLiteral("</t:Folder>");
        xml += QStringLiteral("</t:Create>");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : jobs) {
        job->start();
    }
```

#### AUTO 


```{c}
const auto item = m_messageHelper->createItemFromMessage(
            msg->message, msg->uid, msg->size, msg->attributes,
            msg->flags, fetch->scope(), ok);
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<FileStore::CollectionCreateJob *>(job);
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(settings);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item item : std::as_const(origItems)) {
        const KDAV::DavItem davItem = davJob->item(item.remoteId());

        // No data was retrieved for this item, maybe because it is not out of date
        if (davItem.data().isEmpty()) {
            qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Empty item returned. " << item.remoteId();
            if (!cache->isOutOfDate(item.remoteId())) {
                qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Item is not changed, including it. " << item.remoteId();
                items << item;
            }
            continue;
        }

        Akonadi::Item::List extraItems;
        if (!Utils::parseDavData(davItem, item, extraItems)) {
            qCWarning(DAVRESOURCE_LOG) << "DavGroupwareResource::onMultigetFinished: Failed to parse item data. " << item.remoteId();
            continue;
        }

        // update etag
        item.setRemoteRevision(davItem.etag());
        cache->setEtag(item.remoteId(), davItem.etag());
        items << item;
        for (const Akonadi::Item &extraItem : std::as_const(extraItems)) {
            cache->setEtag(extraItem.remoteId(), davItem.etag());
            items << extraItem;
        }
    }
```

#### AUTO 


```{c}
auto *res = qobject_cast<EwsResource *>(parent());
```

#### AUTO 


```{c}
auto deletedJob = new FoldersRequestJob(mLastSync, FoldersRequestJob::Deleted, this);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &contact){
                Item item;
                item.setRemoteId(contact);
                return item;
            }
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(mRootCollection, CollectionFetchJob::Recursive, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : expectedEvents) {
            qDebug() << "Expected event:" << event;
        }
```

#### AUTO 


```{c}
const auto error = tokens.value(QStringLiteral("error"));
```

#### AUTO 


```{c}
auto itemCreateJob = new ItemCreateJob(item, mTargetCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tag : tagList) {
        if (tag.isEmpty()) {
            qCWarning(MIXEDMAILDIRRESOURCE_LOG) << "TagList for item" << item.url() << "contains an empty tag";
        } else {
            tags << Akonadi::Tag(tag);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestMap();
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return true;
        };
        wallet->createFolderCallback = [](const QString &) {
            return false;
        };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
            setFolderCalled = true;
            return true;
        };
        wallet->readMapCallback = [](const QString &, QMap<QString, QString> &map) {
            map[accessTokenMapKey] = QStringLiteral("afoo");
            map[refreshTokenMapKey] = QStringLiteral("rfoo");
            return true;
        };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
const auto alreadyFetchedBegin = job->property("alreadyFetched").value<KIMAP::ImapSet::Id>();
```

#### AUTO 


```{c}
auto *req = new EwsGetFolderRequest(mClient, this);
```

#### AUTO 


```{c}
const auto addresses{aff.addresses()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsItem &item : std::as_const(mItems)) {
        item.write(writer);
    }
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<FileStore::ItemCreateJob *>(job);
```

#### AUTO 


```{c}
auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item) {
                return item.remoteId() == parentId;
            });
```

#### AUTO 


```{c}
auto *colorAttr = collection.attribute<CollectionColorAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &key : keys) {
        keyCache->removeKey(d->path, key);
    }
```

#### AUTO 


```{c}
auto tokenJob = qobject_cast<GetTokenJob*>(job);
```

#### AUTO 


```{c}
auto job = new TaskCreateJob(task, item.parentCollection().remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto resp = new EwsFindItemResponse(reader);
```

#### AUTO 


```{c}
auto acl = new KIMAP::GetAclJob(m_session);
```

#### AUTO 


```{c}
auto *attr = col.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : job->requestedItems()) {
            const Collection coll = item.parentCollection();
            Q_ASSERT(!coll.remoteId().isEmpty());

        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &h : qAsConst(parameters)) {
        if (first) {
            first = false;
        } else {
            ret.append("&");
        }
        ret.append(QUrl::toPercentEncoding(h.name) + "=" + QUrl::toPercentEncoding(h.value));
    }
```

#### AUTO 


```{c}
auto dialog = new ServerInfoDialog(m_parentResource, this);
```

#### AUTO 


```{c}
auto createJob = new Akonadi::CollectionCreateJob(mRelationCollection, this);
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
const auto parent = item().parentCollection();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { processNextItem(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMailbox &mbox : mboxList) {
                msg->bcc()->addAddress(mbox);
            }
```

#### AUTO 


```{c}
auto *req = new EwsGetStreamingEventsRequest(mEwsClient, this);
```

#### AUTO 


```{c}
const auto state = mStateHash.find(remoteId);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &result : results) {
            const QStringList split = result.split(QLatin1Char('|'));
            KDAV::Protocol protocol = KDAV::ProtocolInfo::protocolByName(split.at(0));
            if (!Settings::self()->urlConfiguration(protocol, split.at(1))) {
                Settings::UrlConfiguration *urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = split.at(1);
                if (dlg->useDefaultCredentials()) {
                    urlConfig->mUser = QStringLiteral("$default$");
                } else {
                    urlConfig->mUser = dlg->username();
                    urlConfig->mPassword = dlg->password();
                }
                urlConfig->mProtocol = protocol;

                Settings::self()->newUrlConfiguration(urlConfig);

                addModelRow(Utils::translatedProtocolName(protocol), split.at(1));
                mAddedUrls << QPair<QString, KDAV::Protocol>(split.at(1), protocol);
                checkUserInput();
            }
        }
```

#### AUTO 


```{c}
auto lay = new QFormLayout(this);
```

#### AUTO 


```{c}
auto loginJob = new LoginJob(mPopSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetEventsRequest::Response &resp : responses) {
        const auto notifications{resp.notifications()};
        for (const EwsGetEventsRequest::Notification &nfy : notifications) {
            const auto nfyEvents{nfy.events()};
            for (const EwsGetEventsRequest::Event &event : nfyEvents) {
                bool skip = false;
                mSettings->setEventSubscriptionWatermark(event.watermark());
                if (!skip) {
                    switch (event.type()) {
                    case EwsCopiedEvent:
                    case EwsMovedEvent:
                        if (!event.itemIsFolder()) {
                            mUpdatedFolderIds.insert(event.oldParentFolderId());
                        }
                    /* fall through */
                    case EwsCreatedEvent:
                    case EwsDeletedEvent:
                    case EwsModifiedEvent:
                    case EwsNewMailEvent:
                        if (event.itemIsFolder()) {
                            mFolderTreeChanged = true;
                        } else {
                            mUpdatedFolderIds.insert(event.parentFolderId());
                        }
                        break;
                    case EwsStatusEvent:
                        // Do nothing
                        break;
                    default:
                        break;
                    }
                }
            }
            if (nfy.hasMoreEvents()) {
                moreEvents = true;
            }
        }
        if (mStreamingEvents) {
            auto req2 = qobject_cast<EwsGetStreamingEventsRequest *>(req);
            if (req2) {
                req2->eventsProcessed(resp);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : std::as_const(mCreatedTags)) {
            mItem.setTag(tag);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : ranges) {
                    fb->addPeriod(range.busyStart, range.busyEnd);
                }
```

#### AUTO 


```{c}
auto colJob = qobject_cast<FileStore::CollectionModifyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dt : list) {
        dtList.push_back(Kolab::Conversion::fromDate(dt, start.isDateOnly()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.setPassword(QStringLiteral("foo"));
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
                                        hasFolderCalled = true;
                                        return false;
                                    };
        wallet->createFolderCallback = [&createFolderCalled](const QString &) {
                                           createFolderCalled = true;
                                           return true;
                                       };
        wallet->setFolderCallback = [&setFolderCalled](const QString &) {
                                        setFolderCalled = true;
                                        return false;
                                    };
        wallet->writePasswordCallback = [&](const QString &, const QString &p) {
                                            password = p;
                                            loop.exit(0);
                                            return true;
                                        };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (FileStore::Job *job : std::as_const(d->mJobQueue)) {
        job->kill(KJob::EmitResult);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        fetchDone(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item::Flag &flag : flags) {
        if (flag == Akonadi::MessageFlags::Forwarded) {
            mailDirFlags << QStringLiteral("P");
        } else if (flag == Akonadi::MessageFlags::Replied) {
            mailDirFlags << QStringLiteral("R");
        } else if (flag == Akonadi::MessageFlags::Seen) {
            mailDirFlags << QStringLiteral("S");
        } else if (flag == Akonadi::MessageFlags::Deleted) {
            mailDirFlags << QStringLiteral("T");
        } else if (flag == Akonadi::MessageFlags::Flagged) {
            mailDirFlags << QStringLiteral("F");
        }
    }
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto days{mRecurrence.days};
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyItemDownloadJob *>(kjob);
```

#### LAMBDA EXPRESSION 


```{c}
[this, todo, item](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        TaskPtr task(new Task(*todo));
        auto newJob = new TaskModifyJob(task, item.parentCollection().remoteId(), job->account(), this);
        newJob->setProperty(ITEM_PROPERTY, QVariant::fromValue(item));
        connect(newJob, &TaskModifyJob::finished, this, &TaskHandler::slotGenericJobFinished);
    }
```

#### AUTO 


```{c}
auto tokenJob = new LoginJob(qobject_cast<FacebookResource *>(parent()));
```

#### AUTO 


```{c}
auto *attr = c.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
const auto authMode = mSettings->authMode();
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const EventPtr event = object.dynamicCast<Event>();
        if (event->useDefaultReminders() && attr) {
            const KCalendarCore::Alarm::List alarms = attr->alarms(event.data());
            for (const KCalendarCore::Alarm::Ptr &alarm : alarms) {
                event->addAlarm(alarm);
            }
        }

        Item item;
        item.setMimeType( mimeType() );
        item.setParentCollection(collection);
        item.setRemoteId(event->id());
        item.setRemoteRevision(event->etag());
        item.setPayload<KCalendarCore::Event::Ptr>(event.dynamicCast<KCalendarCore::Event>());

        if (event->deleted()) {
            qCDebug(GOOGLE_CALENDAR_LOG) << " - removed" << event->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_CALENDAR_LOG) << " - changed" << event->uid();
            changedItems << item;
        }
    }
```

#### AUTO 


```{c}
auto job = new ContactFetchJob(m_settings->accountPtr(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
        QByteArray lineData(line.toUtf8());

        if (lineData.contains(mailSizeMarker)) {
            Q_ASSERT(mMails.size() > sizeIndex);
            lineData.replace(mailSizeMarker, QString::number(mMails[sizeIndex++].size()).toLatin1());
        }
        if (lineData.contains(mailMarker)) {
            while (exceptions.contains(mailIndex + 1)) {
                mailIndex++;
            }
            Q_ASSERT(mMails.size() > mailIndex);
            lineData.replace(mailMarker, mMails[mailIndex++]);
        }

        if (lineData.startsWith("S: ")) {
            mWriteData.append(lineData.mid(3) + "\r\n");
            mode = Server;
        } else if (line.startsWith(QLatin1String("C: "))) {
            mReadData.append(lineData.mid(3) + "\r\n");
            mode = Client;
        } else {
            switch (mode) {
            case Server:
                mWriteData.last() += (lineData + "\r\n");
                break;
            case Client:
                mReadData.last() += (lineData + "\r\n");
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto itemModify = new ItemModifyJob(item, transaction());
```

#### AUTO 


```{c}
auto req2 = qobject_cast<EwsGetStreamingEventsRequest *>(req);
```

#### AUTO 


```{c}
auto *usersJob = new UsersRequestJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QString &p) {
            password = p;
            loop.exit(0);
            return true;
        }
```

#### AUTO 


```{c}
auto protocolStandardItem = new QStandardItem(protocol);
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(mOutbox);
```

#### AUTO 


```{c}
auto examine = static_cast<KIMAP::SelectJob *>(job);
```

#### AUTO 


```{c}
auto postJob = qobject_cast<KIO::StoredTransferJob *>(job);
```

#### AUTO 


```{c}
auto job = Graph::job(QStringLiteral("me"), d->token, { QStringLiteral("id"), QStringLiteral("name") });
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job){
            if (!m_iface->handleError(job)) {
                return;
            }
            ContactPtr contact = qobject_cast<ContactCreateJob *>(job)->items().first().dynamicCast<Contact>();
            Item newItem = item;
            qCDebug(GOOGLE_CONTACTS_LOG) << "Contact" << contact->uid() << "created";
            newItem.setRemoteId(contact->uid());
            newItem.setRemoteRevision(contact->etag());
            m_iface->itemChangeCommitted(newItem);
            newItem.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
            new ItemModifyJob(newItem, this);
            emitReadyStatus();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (ignoreStatusMail(item)) {
            continue;
        }

        if (excludeSpecialCollection(collectionSource)) {
            continue; // outbox, sent-mail, trash, drafts or templates.
        }

        if (mNewMails.contains(collectionSource)) {
            QList<Akonadi::Item::Id> idListFrom = mNewMails[ collectionSource ];
            const int removeItems = idListFrom.removeAll(item.id());
            if (removeItems > 0) {
                if (idListFrom.isEmpty()) {
                    mNewMails.remove(collectionSource);
                } else {
                    mNewMails[ collectionSource ] = idListFrom;
                }
                if (!excludeSpecialCollection(collectionDestination)) {
                    QList<Akonadi::Item::Id> idListTo = mNewMails[ collectionDestination ];
                    idListTo.append(item.id());
                    mNewMails[ collectionDestination ] = idListTo;
                }
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, items, detachItems](KGAPI2::Job *job) {
            if (job->error()) {
                m_iface->cancelTask(i18n("Failed to reparent subtasks: %1", job->errorString()));
                return;
            }
            // Update items inside Akonadi DB too
            new ItemModifyJob(detachItems);
            // Perform actual removal
            doRemoveTasks(items);
        }
```

#### AUTO 


```{c}
auto search = new KIMAP::SearchJob(m_session);
```

#### AUTO 


```{c}
auto attr = mRootCollection.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto photoJob = new ContactFetchPhotoJob(contacts, m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto &range
```

#### RANGE FOR STATEMENT 


```{c}
for (QStandardItem *item : std::as_const(mFolderItemHash)) {
        if (!item->parent()) {
            mFolderTreeModel->appendRow(item);
        }
    }
```

#### AUTO 


```{c}
auto mjob = new ItemModifyJob(item);
```

#### AUTO 


```{c}
auto *examine = static_cast<KIMAP::SelectJob *>(job);
```

#### AUTO 


```{c}
auto *capJob = new KIMAP::CapabilitiesJob(login->session());
```

#### AUTO 


```{c}
auto job = new KGAPI2::FreeBusyQueryJob(email, start, end, account(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(randomList1)) {
        Item item1;
        item1.setId(KRandom::random());
        item1.setRemoteId(QString::number(entry.messageOffset()));
        item1.setParentCollection(collection1);

        job = mStore->fetchItem(item1);
        job->fetchScope().fetchFullPayload(true);

        spy = new QSignalSpy(job, &FileStore::ItemFetchJob::itemsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        items = job->items();
        QCOMPARE((int)items.count(), 1);
        QCOMPARE(itemsFromSpy(spy), items);

        Item item = items.first();
        QCOMPARE(item, item1);
        QVERIFY(item.hasPayload<KMime::Message::Ptr>());

        KMime::Message::Ptr msgPtr = item.payload<KMime::Message::Ptr>();
        QVERIFY(msgPtr != 0);

        const QSet<QByteArray> parts = messageParts(msgPtr);
        QVERIFY(!parts.isEmpty());
        QVERIFY(parts.contains(MessagePart::Header));
        if (msgPtr->messageID()->identifier() == messageIdOfEmptyBodyMsg) {
            QVERIFY(!parts.contains(MessagePart::Body));
        } else {
            QVERIFY(parts.contains(MessagePart::Body));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        itemModifyJobResult(job);
    }
```

#### AUTO 


```{c}
const auto &resp
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
        if (flag == MessageFlags::Seen) {
            isRead = true;
        } else if (flag == MessageFlags::Flagged) {
            isFlagged = true;
        } else if (flag == MessageFlags::HasAttachment || flag == MessageFlags::HasInvitation
                   || flag == MessageFlags::Signed || flag == MessageFlags::Encrypted) {
            // These flags are read-only. Remove them from the unknown list but don't do anything with them.
        } else {
            unknownFlags.insert(flag);
        }
    }
```

#### AUTO 


```{c}
const auto mbox = v.value<EwsMailbox>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const AccountPtr &account : accounts) {
        m_accComboBox->addItem(account->accountName());
    }
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto auth = prepareAuth();
```

#### AUTO 


```{c}
const auto token = job->token();
```

#### AUTO 


```{c}
auto job = new EntriesFetchJob(mClientState->client(), collection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&contact](const Item &item){
                        return item.remoteId() == contact->uid();
                    }
```

#### AUTO 


```{c}
const auto &token
```

#### AUTO 


```{c}
auto *job = new TagFetchJob(this);
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(mWebDialog);
```

#### AUTO 


```{c}
auto tokenJob = new LoginJob(mIdentifier, parent());
```

#### AUTO 


```{c}
auto item = new QListWidgetItem(taskList->title());
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsUpdateItemRequest::ItemChange::List::const_iterator firstChange, EwsUpdateItemRequest::ItemChange::List::const_iterator lastChange) {
            auto req = new EwsUpdateItemRequest(mClient, this);
            for (auto it = firstChange; it != lastChange; ++it) {
                req->addItemChange(*it);
            }
            return req;
        }
```

#### AUTO 


```{c}
const auto attr = collection.attribute<EntityDisplayAttribute>();
```

#### AUTO 


```{c}
auto *busyCursorHelper = new BusyCursorHelper(mServerTest);
```

#### AUTO 


```{c}
auto *uidListJob = new UIDListJob(mPopSession);
```

#### AUTO 


```{c}
auto *job = new FileStore::ItemDeleteJob(item, d->mSession);
```

#### AUTO 


```{c}
const auto overrideReplyCallback = server->overrideReplyCallback();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &fetchedItem : fetchedItems) {
            auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
            TaskPtr task(new Task(*todo));
            const QString parentId = task->relatedTo(KCalendarCore::Incidence::RelTypeParent);
            if (parentId.isEmpty()) {
                continue;
            }

            auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item){
                return item.remoteId() == parentId;
            });
            if (it != items.cend()) {
                Item newItem(fetchedItem);
                qCDebug(GOOGLE_TASKS_LOG) << "Detaching child" << newItem.remoteId() << "from" << parentId;
                todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
                newItem.setPayload<KCalendarCore::Todo::Ptr>(todo);
                detachItems << newItem;
                detachTasks << task;
            }
        }
```

#### AUTO 


```{c}
auto job = createGetJob(QUrl(QStringLiteral("https://www.facebook.com/events/birthdays")));
```

#### AUTO 


```{c}
static const auto o365FakeUserAgent =
    QStringLiteral("Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36");
```

#### AUTO 


```{c}
const auto count = std::min(batchSize, m_messageIds.size() - batchIdx);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &, const QSet< QByteArray > &) {
            settleTimer.start(serverSettleTimeout);
        }
```

#### AUTO 


```{c}
auto *filterLineEdit = new QLineEdit(this);
```

#### AUTO 


```{c}
auto job = new TaskMoveJob(item.remoteId(), item.parentCollection().remoteId(), parentUid, m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReminderPtr &reminder : std::as_const(m_reminders)) {
        KCalendarCore::Alarm::Ptr alarm(new KCalendarCore::Alarm(incidence));

        alarm->setType(reminder->type());
        alarm->setTime(incidence->dtStart());
        alarm->setStartOffset(reminder->startOffset());
        alarm->setEnabled(true);

        alarms << alarm;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::RecurrenceRule::WDayPos &dp : defaultRRByDays) {
        daypos.push_back(fromWeekDayPos(dp));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        EwsUpdateItemRequest::ItemChange ic(EwsId(item.remoteId(), item.remoteRevision()), EwsItemHandler::mimeToItemType(item.mimeType()));
        if (!item.tags().isEmpty()) {
            QStringList tagList;
            QStringList categoryList;
            tagList.reserve(item.tags().count());
            const auto tags{item.tags()};
            for (const Tag &tag : tags) {
                Q_ASSERT(mTagStore->containsId(tag.id()));
                tagList.append(QString::fromLatin1(mTagStore->tagRemoteId(tag.id())));
                QString name = mTagStore->tagName(tag.id());
                if (!name.isEmpty()) {
                    categoryList.append(name);
                }
            }
            EwsUpdateItemRequest::Update *upd = new EwsUpdateItemRequest::SetUpdate(EwsResource::tagsProperty, tagList);
            ic.addUpdate(upd);
            upd = new EwsUpdateItemRequest::SetUpdate(EwsPropertyField(QStringLiteral("item:Categories")), categoryList);
            ic.addUpdate(upd);
        } else {
            EwsUpdateItemRequest::Update *upd = new EwsUpdateItemRequest::DeleteUpdate(EwsResource::tagsProperty);
            ic.addUpdate(upd);
            upd = new EwsUpdateItemRequest::DeleteUpdate(EwsPropertyField(QStringLiteral("item:Categories")));
            ic.addUpdate(upd);
        }
        itemChanges.append(ic);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, items](KGAPI2::Job *job, const ContactPtr &contact){
            qCDebug(GOOGLE_CONTACTS_LOG) << " - fetched photo for contact" << contact->uid();
            int processedItems = job->property("processedItems").toInt();
            processedItems++;
            job->setProperty("processedItems", processedItems);
            m_iface->emitPercent(100.0f*processedItems / items.count());

            auto it = std::find_if(items.cbegin(), items.cend(), [&contact](const Item &item){
                        return item.remoteId() == contact->uid();
                    });
            if (it != items.cend())  {
                Item newItem(*it);
                newItem.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
                new ItemModifyJob(newItem, this);
            }
        }
```

#### AUTO 


```{c}
auto it = std::find_if(mHandlers.cbegin(), mHandlers.cend(),
                           [&mimeType](const BaseHandler::Ptr &handler) {
        return handler->mimeType() == mimeType;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &resp : responses) {
        if (resp.isSuccess()) {
            itemIt->setRemoteRevision(resp.itemId().changeKey());
        }
        ++itemIt;
    }
```

#### AUTO 


```{c}
auto *job = new OXA::ObjectCreateJob(object, this);
```

#### AUTO 


```{c}
const auto urls{contact.urls()};
```

#### AUTO 


```{c}
const auto account = authJob->account();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Akonadi::Item &, const QSet< QByteArray > &) {
        settleTimer.start(serverSettleTimeout);
    }
```

#### AUTO 


```{c}
auto store = new KIMAP::StoreJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mLocalItems)) {
        itemHash.insert(item.remoteId(), item);
    }
```

#### AUTO 


```{c}
auto create = static_cast<KIMAP::CreateJob *>(job);
```

#### AUTO 


```{c}
auto attribute = trash.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : reqResponses) {
            if (resp.isSuccess()) {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Checked item %1 found - readding").arg(ewsHash(it->id()));
                mRemoteAddedItems.append(resp.item());
            } else {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Checked item %1 not found - removing").arg(ewsHash(it->id()));
                mRemoteDeletedIds.append(*it);
            }
            ++it;
        }
```

#### AUTO 


```{c}
auto detailJob = qobject_cast<EwsFetchItemDetailJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        Item newItem = item;
        const TaskPtr task = qobject_cast<TaskCreateJob *>(job)->items().first().dynamicCast<Task>();
        qCDebug(GOOGLE_TASKS_LOG) << "Task added";
        newItem.setRemoteId(task->uid());
        newItem.setRemoteRevision(task->etag());
        newItem.setGid(task->uid());
        m_iface->itemChangeCommitted(newItem);
        newItem.setPayload<KCalendarCore::Todo::Ptr>(task.dynamicCast<KCalendarCore::Todo>());
        new ItemModifyJob(newItem, this);
        emitReadyStatus();
    }
```

#### AUTO 


```{c}
auto journalColor = EteSyncDEFAULT_COLOR;
```

#### AUTO 


```{c}
const auto *protoAttr = collection.attribute<DavProtocolAttribute>();
```

#### AUTO 


```{c}
const auto collection = fetchColJob->collections().at(0);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { runNextJob(); }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::ItemFetchJob(resourceState()->tag());
```

#### AUTO 


```{c}
auto *j = new Akonadi::ItemModifyJob(extraItems);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &tagRid : tagRids) {
            const Tag::Id tagId = tagIdForRid(tagRid.toLatin1());
            if (tagId == -1) {
                /* Tag not found. */
                qCDebug(EWSRES_LOG) << QStringLiteral("Found missing tag: %1").arg(tagRid);
                if (ignoreMissing) {
                    continue;
                } else {
                    return false;
                }
            }
            Tag tag(tagId);
            item.setTag(tag);
        }
```

#### AUTO 


```{c}
auto dlg = new AuthDialog(d->cookies, mIdentifier);
```

#### AUTO 


```{c}
const auto service = Akonadi::ServerManager::agentServiceName(Akonadi::ServerManager::Agent, QStringLiteral("akonadi_mailfilter_agent"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &object : calendars) {
            const CalendarPtr &calendar = object.dynamicCast<Calendar>();
            qCDebug(GOOGLE_CALENDAR_LOG) << " -" << calendar->title() << "(" << calendar->uid() << ")";
            if (!activeCalendars.contains(calendar->uid())) {
                qCDebug(GOOGLE_CALENDAR_LOG) << "Skipping, not subscribed";
                continue;
            }
            Collection collection;
            setupCollection(collection, calendar);
            collection.setParentCollection(rootCollection);
            collections << collection;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&mimeType](const BaseHandler::Ptr &handler) {
        return handler->mimeType() == mimeType;
    }
```

#### AUTO 


```{c}
auto *store = new KIMAP::StoreJob(copy->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenJob]() {
        if (tokenJob->error()) {
            emitError(tokenJob->errorText());
            return;
        }

        // Convert the cookies into a HTTP Cookie header that we can pass
        // to KIO
        mCookies = QStringLiteral("Cookie: ");
        const auto parsedCookies = QNetworkCookie::parseCookies(tokenJob->cookies());
        for (const auto &cookie : parsedCookies) {
            mCookies += QStringLiteral("%1=%2; ").arg(QString::fromUtf8(cookie.name()),
                                                      QString::fromUtf8(cookie.value()));
        }
        fetchFacebookEventsPage();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &id : ids) {
                auto job = new KIMAP::SetAclJob(session);
                job->setMailBox(mailBoxForCollection(collection()));
                job->setIdentifier(id);
                job->setRights(KIMAP::SetAclJob::Change, rights[id]);

                connect(job, &KIMAP::SetAclJob::result, this, &ChangeCollectionTask::onSetAclDone);

                job->start();

                m_pendingJobs++;
            }
```

#### AUTO 


```{c}
static const auto IdleTimeout = std::chrono::minutes(29);
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(content, srv->portNumber(), [&](const QString &chunk) {
        const QString respHead = QStringLiteral("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                                                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                                                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                                                "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
                                                "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
                                                "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
                                                "<soap:Header>"
                                                "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
                                                "</soap:Header>"
                                                "<soap:Body>"
                                                "<m:GetStreamingEventsResponse>"
                                                "<m:ResponseMessages>"
                                                "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
                                                "<m:ResponseCode>NoError</m:ResponseCode>"
                                                "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral("</m:GetStreamingEventsResponseMessage>"
                                                "</m:ResponseMessages>"
                                                "</m:GetStreamingEventsResponse>"
                                                "</soap:Body>"
                                                "</soap:Envelope>");
        const QString eventHead = QStringLiteral("<m:Notifications>"
                                                 "<m:Notification>"
                                                 "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral("<NewMailEvent>"
                                              "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
                                              "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
                                              "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
                                              "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediately" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    });
```

#### AUTO 


```{c}
auto statusLabel = new QLabel(this);
```

#### AUTO 


```{c}
auto selectJob = new KIMAP::SelectJob(mSession);
```

#### LAMBDA EXPRESSION 


```{c}
[&contact](const Item &item){
            return item.remoteId() == contact->uid();
        }
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::CollectionFetchJob(collection, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *davJob = qobject_cast<KDAV::DavPrincipalSearchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const O0RequestParameter &h : qAsConst(parameters)) {
        if (first) {
            first = false;
        } else {
            ret.append("&");
        }
        ret.append(QUrl::toPercentEncoding(QString::fromLatin1(h.name)) + "=" + QUrl::toPercentEncoding(QString::fromLatin1(h.value)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : calendars) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection |
                                 Collection::CanCreateItem |
                                 Collection::CanChangeItem |
                                 Collection::CanDeleteItem);
        } else {
            collection.setRights(nullptr);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### AUTO 


```{c}
auto item = new QStandardItem(collection.displayName());
```

#### AUTO 


```{c}
const auto *dispatchModeAttribute = item.attribute<DispatchModeAttribute>();
```

#### AUTO 


```{c}
auto tokenJob = new LoginJob(qobject_cast<FacebookResource*>(parent()));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : l) {
        list.push_back(toStdString(s));
    }
```

#### AUTO 


```{c}
auto *requestJob = new SpecialMailCollectionsRequestJob(this);
```

#### AUTO 


```{c}
auto s = sessionSpy.at(0).at(1).value<KIMAP::Session *>();
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(this);
```

#### AUTO 


```{c}
const auto tags{item.tags()};
```

#### AUTO 


```{c}
auto job = new TaskDeleteJob(taskIds, items.first().parentCollection().remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto stdWeekNumberVector = std::vector<int>(byWeekNumberVector.begin(), byWeekNumberVector.end());
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
    }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<FileStore::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto *job = new ItemFetchJob(item);
```

#### AUTO 


```{c}
auto dt = QDateTime::fromString(str.left(19), QStringLiteral("yyyy-MM-ddTHH:mm:ss"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : std::as_const(mMailboxes)) {
        mMetadata.insert(mailbox, QMap<QByteArray, QByteArray>());
    }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
auto collection = createJob->property("collection").value<Akonadi::Collection>();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &chunk) {
        const QString respHead = QStringLiteral("<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                                                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                                                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                                                "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
                                                "xmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\" "
                                                "xmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\">"
                                                "<soap:Header>"
                                                "<t:ServerVersionInfo MajorVersion=\"8\" MinorVersion=\"0\" MajorBuildNumber=\"628\" MinorBuildNumber=\"0\" />"
                                                "</soap:Header>"
                                                "<soap:Body>"
                                                "<m:GetStreamingEventsResponse>"
                                                "<m:ResponseMessages>"
                                                "<m:GetStreamingEventsResponseMessage ResponseClass=\"Success\">"
                                                "<m:ResponseCode>NoError</m:ResponseCode>"
                                                "<m:ConnectionStatus>OK</m:ConnectionStatus>");
        const QString respTail = QStringLiteral("</m:GetStreamingEventsResponseMessage>"
                                                "</m:ResponseMessages>"
                                                "</m:GetStreamingEventsResponse>"
                                                "</soap:Body>"
                                                "</soap:Envelope>");
        const QString eventHead = QStringLiteral("<m:Notifications>"
                                                 "<m:Notification>"
                                                 "<SubscriptionId>f6bc657d-dde1-4f94-952d-143b95d6483d<SubscriptionId>");
        const QString eventTail = QStringLiteral("</m:Notification></m:Notifications>");
        const QString event2 = QStringLiteral("<NewMailEvent>"
                                              "<TimeStamp>2006-08-22T01:00:50Z</TimeStamp>"
                                              "<ItemId Id=\"AQApAHRw\" ChangeKey=\"CQAAAA==\" />"
                                              "<ParentFolderId Id=\"AQApAH\" ChangeKey=\"AQAAAA==\" />"
                                              "</NewMailEvent>");
        callbackCalled = true;

        QString expResp = respHead;
        if (responseNo == 0) {
            expResp += eventHead + event + eventTail;
        } else if (responseNo == 2) {
            expResp += eventHead + event2 + eventTail;
        }
        expResp += respTail;

        if (chunk != expResp) {
            qWarning() << "Unexpected GetStreamingEventsResponse";
            callbackError = true;
            return false;
        }

        if (responseNo == 1) {
            srv->queueEventsXml(QStringList() << event2);
            pushEventTime = QDateTime::currentDateTime();
        } else if (responseNo == 2) {
            /* Check if the response to the above event came "immediately" */
            QDateTime now = QDateTime::currentDateTime();
            if (pushEventTime.msecsTo(now) > 200) {
                qWarning() << "Push event maximum roundtrip time exceeded";
                callbackError = true;
                return false;
            }
        }

        responseNo++;
        return true;
    }
```

#### AUTO 


```{c}
auto progress = new QProgressBar(this);
```

#### AUTO 


```{c}
auto *req = new EwsGetItemRequest(mClient, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        abort();
    }
```

#### AUTO 


```{c}
auto meta = qobject_cast<KIMAP::GetMetaDataJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QByteArray data = md.readEntry(item.remoteId());

        auto mail = new KMime::Message();
        mail->setContent(KMime::CRLFtoLF(data));
        mail->parse();
        // Some messages may have an empty body
        if (mail->body().isEmpty()) {
            if (parts.contains("PLD:BODY") || parts.contains("PLD:RFC822")) {
                // In that case put a space in as body so that it gets cached
                // otherwise we'll wrongly believe the body part is missing from the cache
                mail->setBody(" ");
            }
        }

        Item i(item);
        i.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, i);
        rv.push_back(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        itemId = EwsId(item.remoteId(), item.remoteRevision());

        if (mParts.contains("FLAGS")) {
            EwsUpdateItemRequest::ItemChange ic(itemId, EwsItemTypeMessage);
            QHash<EwsPropertyField, QVariant> propertyHash = EwsMailHandler::writeFlags(item.flags());

            for (auto it = propertyHash.cbegin(), end = propertyHash.cend(); it != end; ++it) {
                EwsUpdateItemRequest::Update *upd;
                if (it.value().isNull()) {
                    upd = new EwsUpdateItemRequest::DeleteUpdate(it.key());
                } else {
                    upd = new EwsUpdateItemRequest::SetUpdate(it.key(), it.value());
                }
                ic.addUpdate(upd);
            }

            itemChanges.append(ic);
            doSubmit = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::CustomProperty &p : props) {
        if (fromStdString(p.identifier) == id) {
            return fromStdString(p.value);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->processNextBatch();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMoveItemRequest::Response &resp : reqResponses) {
        qDebug() << "Verifying response" << i++;
        QCOMPARE(resp.responseClass(), *respClassesIt);
        if (resp.isSuccess()) {
            QCOMPARE(resp.itemId(), *newIdsIt);
        } else {
            QCOMPARE(resp.itemId(), EwsId());
        }
        newIdsIt++;
        respClassesIt++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::FreebusyPeriod &period : fbPeriods) {
            Kolab::FreebusyPeriod simplifiedPeriod;
            simplifiedPeriod.setPeriods(period.periods());
            simplifiedPeriod.setType(period.type());
            if (!simple) { // Don't copy and reset to avoid unintentional information leaking into simple lists
                simplifiedPeriod.setEvent(period.eventSummary(), period.eventUid(), period.eventLocation());
            }
            periods.push_back(simplifiedPeriod);
        }
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Row> &row : std::as_const(mMigrators)) {
        if (row->mMigrator->identifier() == identifier) {
            return row->mMigrator;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsFolder &folder : qAsConst(mFolders)) {
        folder.write(writer);
    }
```

#### AUTO 


```{c}
auto job = new OXA::ObjectDeleteJob(object, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, items](KGAPI2::Job *job, const ContactPtr &contact){
        qCDebug(GOOGLE_CONTACTS_LOG) << " - fetched photo for contact" << contact->uid();
        int processedItems = job->property("processedItems").toInt();
        processedItems++;
        job->setProperty("processedItems", processedItems);
        m_iface->emitPercent(100.0f*processedItems / items.count());

        auto it = std::find_if(items.cbegin(), items.cend(), [&contact](const Item &item){
            return item.remoteId() == contact->uid();
        });
        if (it != items.cend()) {
            Item newItem(*it);
            newItem.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
            new ItemModifyJob(newItem, this);
        }
    }
```

#### AUTO 


```{c}
auto job = new EntriesFetchJob(mClientState.get(), collection, std::move(etesyncCollection), this);
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(col, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto id = folder[EwsFolderFieldFolderId].value<EwsId>();
```

#### AUTO 


```{c}
auto col = job->property("collection").value<Collection>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &rmd : listJobDeleteItems) {
        // We don't want to delete dependent items if the main item was seen
        if (rmd.contains(QLatin1Char('#'))) {
            const QString base = rmd.left(rmd.indexOf(QLatin1Char('#')));
            if (seenRids.contains(base)) {
                continue;
            }
        }

        qCDebug(DAVRESOURCE_LOG) << "DavGroupwareResource::onRetrieveItemsFinished: Item disappeared. " << rmd;
        Akonadi::Item item;
        item.setParentCollection(collection);
        item.setRemoteId(rmd);
        cache->removeEtag(rmd);

        // Use a job to delete items as itemsRetrievedIncremental seem to choke
        // when many items are given with just their RID.
        auto deleteJob = new Akonadi::ItemDeleteJob(item);
        deleteJob->start();
    }
```

#### AUTO 


```{c}
auto statusLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto networkError = mReply->networkError();
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { fetchNewResult(job);}
```

#### AUTO 


```{c}
auto mjob = new EventModifyJob(kevent, item.parentCollection().remoteId(), account(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavPrincipalSearchJob::Result &result : results) {
        if (result.value.startsWith(QLatin1Char('/'))) {
            url.setPath(result.value, QUrl::TolerantMode);
        } else {
            QUrl tmp(result.value);
            tmp.setUserInfo(QString());
            url = tmp;
        }
        davUrl.setUrl(url);

        if (result.property == KDAV::ProtocolInfo::principalHomeSet(KDAV::CalDav)) {
            davUrl.setProtocol(KDAV::CalDav);
        } else {
            davUrl.setProtocol(KDAV::CardDav);
        }

        KDAV::DavCollectionsFetchJob *fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
        connect(fetchJob, &KDAV::DavCollectionsFetchJob::result, this, &SearchDialog::onCollectionsFetchJobFinished);
        fetchJob->start();
        ++mSubJobCount;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const ContactPtr contact = object.dynamicCast<Contact>();

        if (((collection.remoteId() == OTHERCONTACTS_REMOTEID) && !contact->groups().isEmpty()) ||
                ((collection.remoteId() == MYCONTACTS_REMOTEID) && contact->groups().isEmpty())) {
            continue;
        }

        Item item;
        item.setMimeType(KContacts::Addressee::mimeType());
        item.setParentCollection(m_collections[MYCONTACTS_REMOTEID]);
        item.setRemoteId(contact->uid());
        item.setRemoteRevision(contact->etag());
        item.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());

        if (contact->deleted()) {
            removedItems << item;
        } else {
            changedItems << item;
            changedPhotos << contact->uid();
        }

        const QStringList groups = contact->groups();
        for (const QString &group : groups) {
            groupsMap[group] << item;
        }
    }
```

#### AUTO 


```{c}
auto tagJob = new EwsGlobalTagsWriteJob(mTagStore, mClient, mRootCollection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool ready){
        if (accountId() > 0) {
            return;
        }
        if (!ready) {
            Q_EMIT status(Broken, i18n("Can't access KWallet"));
            return;
        }
        if (m_settings->accountPtr().isNull()) {
            Q_EMIT status(NotConfigured);
            return;
        }
        emitReadyStatus();
        synchronize();
    }
```

#### AUTO 


```{c}
auto *searchLine = new KLineEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QString rid = item.remoteId();
        Incidence::Ptr incidence = calendar()->instance(rid);
        if (!incidence) {
            qCritical() << "akonadi_ical_resource: Can't find incidence with uid " << rid << "; item.id() = " << item.id();
            Q_EMIT error(i18n("Incidence with uid '%1' not found.", rid));
            return false;
        }

        Incidence::Ptr incidencePtr(incidence->clone());

        Item i = item;
        i.setMimeType(incidencePtr->mimeType());
        i.setPayload<Incidence::Ptr>(incidencePtr);
        resultItems.append(i);
    }
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<OXA::FolderCreateJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsItem &ewsItem : std::as_const(mRemoteAddedItems)) {
        /* In case of a full sync all existing items appear as added on the remote side. Therefore
         * look for the item in the local list before creating a new copy. */
        auto id(ewsItem[EwsItemFieldItemId].value<EwsId>());
        QHash<QString, Item>::iterator it = itemHash.find(id.id());
        EwsItemType type = ewsItem.internalType();
        if (type == EwsItemTypeUnknown) {
            /* Ignore unknown items. */
            continue;
        }
        QString mimeType = EwsItemHandler::itemHandler(type)->mimeType();
        if (it == itemHash.end()) {
            Item item(mimeType);
            item.setParentCollection(mCollection);
            auto id = ewsItem[EwsItemFieldItemId].value<EwsId>();
            item.setRemoteId(id.id());
            item.setRemoteRevision(id.changeKey());
            if (!mTagStore->readEwsProperties(item, ewsItem, mTagsSynced)) {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Missing tags encountered - forcing sync");
                syncTags();
                return;
            }
            toFetchItems[type].append(item);
            ++mTotalItemsToFetch;
        } else {
            Item &item = *it;
            /* In case of a full sync even unchanged items appear as new. Compare the change keys
             * to determine if a fetch is needed. */
            if (item.remoteRevision() != id.changeKey()) {
                item.clearPayload();
                item.setRemoteRevision(id.changeKey());
                if (!mTagStore->readEwsProperties(item, ewsItem, mTagsSynced)) {
                    qCDebugNC(EWSRES_LOG) << QStringLiteral("Missing tags encountered - forcing sync");
                    syncTags();
                    return;
                }
                toFetchItems[type].append(item);
                ++mTotalItemsToFetch;
            } else {
                qCDebugNC(EWSRES_LOG) << QStringLiteral("Matching change key for item %1 - not syncing").arg(ewsHash(id.id()));
            }
            itemHash.erase(it);
        }
    }
```

#### AUTO 


```{c}
auto job = new FileStore::CollectionCreateJob(collection, targetParent, d->mSession);
```

#### AUTO 


```{c}
const auto &folder
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &flag : flagList) {
            flags.insert(flag.toLatin1());
        }
```

#### AUTO 


```{c}
const auto tz = QTimeZone::systemTimeZoneId();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &childCollection : list) {
            QVERIFY(childCollection.parentCollection() == collection || childCollection.parentCollection().parentCollection() == collection);
            QVERIFY(!childCollection.remoteId().isEmpty());
            QCOMPARE(childCollection.remoteId(), childCollection.name());
            QCOMPARE(childCollection.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

            QCOMPARE(childCollection.rights(),
                     Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                         | Collection::CanChangeCollection | Collection::CanDeleteCollection);
        }
```

#### AUTO 


```{c}
auto *select = static_cast<KIMAP::SelectJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                Item newItem = item;
                const TaskPtr task = qobject_cast<TaskCreateJob *>(job)->items().first().dynamicCast<Task>();
                qCDebug(GOOGLE_TASKS_LOG) << "Task added";
                newItem.setRemoteId(task->uid());
                newItem.setRemoteRevision(task->etag());
                newItem.setGid(task->uid());
                m_iface->itemChangeCommitted(newItem);
                newItem.setPayload<KCalendarCore::Todo::Ptr>(task.dynamicCast<KCalendarCore::Todo>());
                new ItemModifyJob(newItem, this);
                emitReadyStatus();
            }
```

#### AUTO 


```{c}
auto task = new DummyResourceTask(actionIfNoSession, state);
```

#### AUTO 


```{c}
auto networkConfigMgr = new QNetworkConfigurationManager(QCoreApplication::instance());
```

#### AUTO 


```{c}
auto *disposition = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto expunge = new KIMAP::ExpungeJob(m_session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : ids) {
        mAllowedDeletions.append(id.toUtf8());
    }
```

#### AUTO 


```{c}
auto *meta = static_cast<KIMAP::GetMetaDataJob *>(job);
```

#### AUTO 


```{c}
const auto parsedCookies = QNetworkCookie::parseCookies(cookies);
```

#### AUTO 


```{c}
auto filterBarLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsUpdateFolderRequest *>(job);
```

#### AUTO 


```{c}
auto modJob = new CollectionModifyJob(*mapIt, this);
```

#### AUTO 


```{c}
auto *currentUser = new KUser();
```

#### RANGE FOR STATEMENT 


```{c}
for (int request : std::as_const(m_pendingRequests)) {
            Q_EMIT sessionRequestDone(request, nullptr, LoginFailError, i18n("Disconnected from server during login."));
        }
```

#### AUTO 


```{c}
const auto result = etesync_journal_manager_create(mClientState->journalManager(), journal.get());
```

#### AUTO 


```{c}
auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ns : namespaces) {
            if (ns.prefix() == tokens[0]) {
                return {ns.namespaceUri(), tokens[1]};
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qDebug() << "Test timeout";
        loop.exit(2);
    }
```

#### AUTO 


```{c}
auto err = etesync_get_error_code();
```

#### AUTO 


```{c}
auto *attr = m_rootCollection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool success, const QString &error) {
            updateItemsTagsRequestFinished(success, error);
        }
```

#### AUTO 


```{c}
auto hboxLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            auto page = qobject_cast<WebPage *>(mView->page());
            if (auto err = page->lastCeritificateError()) {
                QMessageBox msg;
                msg.setIconPixmap(QIcon::fromTheme(QStringLiteral("security-low")).pixmap(64));
                msg.setText(err->errorDescription());
                msg.addButton(QMessageBox::Ok);
                msg.exec();
            }
        }
```

#### AUTO 


```{c}
auto *transferJob = qobject_cast<KIO::StoredTransferJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        settings.requestPassword(false);
        if (!wallet) {
            qDebug() << "Wallet is null";
            loop.exit(1);
            return;
        }
        wallet->hasFolderCallback = [&hasFolderCalled](const QString &) {
            hasFolderCalled = true;
            return false;
        };
        wallet->createFolderCallback = [](const QString &) {
            return false;
        };
        wallet->doOpen(true);
    }
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyCollectionsDownloadJob *>(kjob);
```

#### AUTO 


```{c}
auto *msg = new KMime::Message;
```

#### AUTO 


```{c}
const auto listJobDeleteItems{listJob->deletedItems()};
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned dayOfWeekNameCount = sizeof(dayOfWeekNames) / sizeof(dayOfWeekNames[0]);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        qCDebug(ETESYNC_LOG) << "emitResult from LoginJob";
        emitResult();
    }
```

#### AUTO 


```{c}
auto job = new EventMoveJob(eventIds, collectionSource.remoteId(), collectionDestination.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto *req = new EwsMoveFolderRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto *job = new EwsSubscribedFoldersJob(mClient, mSettings, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
        listEntry(entryForCollection(col));
    }
```

#### AUTO 


```{c}
auto dlg = new QDialog();
```

#### AUTO 


```{c}
auto bodyDisposition = new KMime::Headers::ContentDisposition();
```

#### AUTO 


```{c}
auto select = new KIMAP::SelectJob(session);
```

#### AUTO 


```{c}
auto *migrator = new GidMigrator(mimeType);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &tagId : qAsConst(tagIds)) {
        mTagData.remove(tagId);
    }
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<OXA::ObjectsRequestJob *>(job);
```

#### AUTO 


```{c}
auto *attr = new HighestModSeqAttribute(m_highestModSeq);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        transportResult(job);
    }
```

#### AUTO 


```{c}
auto *finishedDeleteJob = qobject_cast<DeleteJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (int count : std::as_const(flagCounts)) {
        flagCountTotal += count;
    }
```

#### AUTO 


```{c}
auto *moveJob = qobject_cast<FileStore::CollectionMoveJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            setTemporaryOffline(reconnectTimeout());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &attachment : mailAttachments) {
                writeString(attachments, QStringLiteral("attachment"), attachment);
            }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsDeleteFolderRequest *>(job);
```

#### AUTO 


```{c}
auto it = map.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, ntf, account, args]() {
        runAuthJob(account, args);
        ntf->close();
    }
```

#### AUTO 


```{c}
auto remoteId = col.remoteId() == QStringLiteral("INBOX") ? mInboxId : col.remoteId();
```

#### AUTO 


```{c}
const auto status = parseStatus(data);
```

#### AUTO 


```{c}
auto tokenJob = new GetTokenJob(qobject_cast<FacebookResource*>(parent()));
```

#### AUTO 


```{c}
auto *layout = new QFormLayout(this);
```

#### AUTO 


```{c}
auto *fetch = new KIMAP::FetchJob(select->session());
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsMoveItemRequest *>(job);
```

#### AUTO 


```{c}
auto *job = new KIMAP::CapabilitiesJob(s);
```

#### AUTO 


```{c}
auto *job = new CollectionFetchJob(c, CollectionFetchJob::Base, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &col : cols) {
        itemStrs.append(EwsClient::folderHash.value(col.remoteId(), ewsHash(col.remoteId())));
    }
```

#### AUTO 


```{c}
auto journalColor = ETESYNC_DEFAULT_COLLECTION_COLOR;
```

#### AUTO 


```{c}
auto modifyJob = qobject_cast<OXA::FolderModifyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pair : pairs) {
                const QStringList entry = pair.split(QLatin1Char('='), Qt::KeepEmptyParts);
                mObjectsMap.insert(entry.at(0).toLongLong(), entry.at(1).toULongLong());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Row> &row : qAsConst(mMigrators)) {
        migrators << row->mMigrator;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &exception : qAsConst(exceptions)) {
            if (exception->status() == KCalendarCore::Incidence::StatusCanceled) {
                QDateTime exDateTime(exception->recurrenceId());
                mainIncidence->recurrence()->addExDateTime(exDateTime);
            } else {
                // The exception remote id will contain a fragment pointing to
                // its instance identifier to distinguish it from the main
                // event.
                QString rid = target.remoteId() + QLatin1String("#") + exception->instanceIdentifier();
                qCDebug(DAVRESOURCE_LOG) << "Extra incidence at" << rid;
                Akonadi::Item extraItem = target;
                extraItem.setRemoteId(rid);
                extraItem.setRemoteRevision(source.etag());
                extraItem.setMimeType(exception->mimeType());
                extraItem.setPayload<IncidencePtr>(exception);
                extraItems << extraItem;
            }
        }
```

#### AUTO 


```{c}
auto requestJob = qobject_cast<UserIdRequestJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[socket]() {
                socket->deleteLater();
            }
```

#### AUTO 


```{c}
const auto *CTagAttr = collection.attribute<CTagAttribute>();
```

#### AUTO 


```{c}
auto modJob = new KDAV::DavItemModifyJob(davItem);
```

#### AUTO 


```{c}
auto f = finally([&fail,&job]{
        if (fail) {
            job->postResponse("");
        }
    });
```

#### AUTO 


```{c}
auto attr = col.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : tags) {
        if (!mTagStore->containsId(tag.id())) {
            syncNeeded = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &attendee : std::as_const(mAttendees)) {
        saveAttendeeAttribute(element, attendee);
    }
```

#### AUTO 


```{c}
auto *job = new OXA::FoldersRequestDeltaJob(Settings::self()->foldersLastSync(), this);
```

#### AUTO 


```{c}
auto *job = new FileStore::StoreCompactJob(d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (int idToDelete : idsOnServer) {
                    const int msgTime = idToTime(idToDelete);
                    if (msgTime >= timeLimit) {
                        mIdsToSave << idToDelete;
                    } else {
                        qCDebug(POP3RESOURCE_LOG) << "Message" << idToDelete << "is too old and will be deleted.";
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cookie : parsedCookies) {
            mCookies += QStringLiteral("%1=%2; ").arg(QString::fromUtf8(cookie.name()), QString::fromUtf8(cookie.value()));
        }
```

#### AUTO 


```{c}
auto pkeyAuthJob = new EwsPKeyAuthJob(url, mPKeyCertFile, mPKeyKeyFile, mPKeyPassword, this);
```

#### AUTO 


```{c}
const auto members{dl.members()};
```

#### AUTO 


```{c}
auto uidNext = relationCollection().attribute<UidNextAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { localFoldersChanged(); }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsGetItemRequest *>(job);
```

#### AUTO 


```{c}
auto req = new EwsCreateItemRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
        attendee.setUid(attendee.email());
    }
```

#### RANGE FOR STATEMENT 


```{c}
DEBUG_DATA("fileCreated:")
```

#### AUTO 


```{c}
auto collection = modifyJob->property("collection").value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto *modifyJob = qobject_cast<Akonadi::CollectionModifyJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &resp : mChunkedJob.responses()) {
        const EwsItem &ewsItem = resp.item();
        auto id = ewsItem[EwsItemFieldItemId].value<EwsId>();
        if (it->remoteId() != id.id()) {
            qCWarningNC(EWSRES_AGENTIF_LOG) << QStringLiteral("retrieveItems: Akonadi item not found for item %1.").arg(id.id());
            setErrorText(i18nc("@info:status", "Failed to retrieve items - Akonadi item not found for item %1", id.id()));
            emitResult();
            return;
        }
        EwsItemType type = ewsItem.internalType();
        if (type == EwsItemTypeUnknown) {
            qCWarningNC(EWSRES_AGENTIF_LOG) << QStringLiteral("retrieveItems: Unknown item type for item %1!").arg(id.id());
            setErrorText(i18nc("@info:status", "Failed to retrieve items - Unknown item type for item %1", id.id()));
            emitResult();
            return;
        }
        if (!EwsItemHandler::itemHandler(type)->setItemPayload(*it, ewsItem)) {
            qCWarningNC(EWSRES_AGENTIF_LOG) << "retrieveItems: Failed to fetch item payload";
            setErrorText(i18nc("@info:status", "Failed to fetch item payload"));
            emitResult();
            return;
        }
        ++it;
    }
```

#### AUTO 


```{c}
auto requester = new DummyPasswordRequester(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMoveItemRequest::Response &resp : reqResponses) {
        qDebug() << "Verifying response" << i++;
        QCOMPARE(resp.responseClass(), *respClassesIt);
        if (resp.isSuccess()) {
            QCOMPARE(resp.itemId(), *newIdsIt);
        } else {
            QCOMPARE(resp.itemId(), EwsId());
        }
        ++newIdsIt;
        ++respClassesIt;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tzid : candidates) {
        const QTimeZone candidate(tzid);
        // This would be a fallback
        if (candidate.hasTransitions() != ktz.hasTransitions()) {
            matchedCandidates.insert(0, candidate);
            continue;
        }

        // Without transitions, we can't do any more precise matching, so just
        // accept this candidate and be done with it
        if (!candidate.hasTransitions() && !ktz.hasTransitions()) {
            return candidate;
        }

        // Calculate how many transitions this candidate shares with the ktz.
        // The candidate with the most matching transitions will win.
        const auto transitions = ktz.transitions(QDateTime(), QDateTime::currentDateTimeUtc());
        int matchedTransitions = 0;
        for (auto it = transitions.rbegin(), end = transitions.rend(); it != end; ++it) {
            const auto &transition = *it;
            const QTimeZone::OffsetDataList candidateTransitions = candidate.transitions(transition.time(), transition.time());
            if (candidateTransitions.isEmpty()) {
                continue;
            }
            const auto candidateTransition = candidateTransitions[0];
            const auto abvs = transition.phase().abbreviations();
            for (const auto &abv : abvs) {
//                 if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                ++matchedTransitions;
                break;
//                 }
            }
        }
        matchedCandidates.insert(matchedTransitions, candidate);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int request : qAsConst(m_pendingRequests)) {
            Q_EMIT sessionRequestDone(request, nullptr, LoginFailError, i18n("Disconnected from server during login."));
        }
```

#### AUTO 


```{c}
auto alarm = KCalCore::Alarm::Ptr::create(event.data());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &root : qAsConst(roots)) {
        mRoots << root.trimmed().toUtf8();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool) {
            auth->walletPasswordRequestFinished(mUi->passwordEdit->password());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
        if (job->error()) {
            emitError(job->errorText());
            return;
        }

        const auto json = QJsonDocument::fromJson(qobject_cast<KIO::StoredTransferJob *>(job)->data());
        const auto me = json.object();

        d->userName = me.value(QStringLiteral("name")).toString();
        d->id = me.value(QStringLiteral("id")).toString();
        d->wallet->writeMap(qobject_cast<FacebookResource *>(parent())->identifier(),
                            { { KWalletKeyToken, d->token },
                              { KWalletKeyName, d->userName },
                              { KWalletKeyId, d->id },
                              { KWalletKeyCookies, QString::fromUtf8(d->cookies) }});
        emitResult();
    }
```

#### AUTO 


```{c}
auto syncItemsReq = new EwsSyncFolderItemsRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetFolderRequest::Response &resp : reqResponses) {
        if (resp.isSuccess()) {
            mRemoteChangedFolders.append(resp.folder());
        } else {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch folder details.");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &accountName : qAsConst(walletEntries)) {
        const AccountPtr newAccount = findAccountInWallet(accountName);

        m_accounts[newAccount->accountName()] = newAccount;
        Q_EMIT accountAdded(newAccount);
    }
```

#### AUTO 


```{c}
auto session2 = sessionSpy.at(1).at(1).value<KIMAP::Session *>();
```

#### AUTO 


```{c}
const auto subtype = reader.attributes().value(QStringLiteral("xsi:type"));
```

#### AUTO 


```{c}
auto fetchJob = qobject_cast<FileStore::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto job = new LoginJob(identifier(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsPropertyField &field : tagsProperties) {
        shape << field;
    }
```

#### AUTO 


```{c}
auto capJob = new KIMAP::CapabilitiesJob(login->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : std::as_const(collections)) {
        job = mStore->fetchCollections(collection, FileStore::CollectionFetchJob::Recursive);

        spy = new QSignalSpy(job, &FileStore::CollectionFetchJob::collectionsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        const Collection::List list = collectionsFromSpy(spy);
        QCOMPARE(job->collections(), list);

        for (const Collection &childCollection : list) {
            QVERIFY(childCollection.parentCollection() == collection || childCollection.parentCollection().parentCollection() == collection);
            QVERIFY(!childCollection.remoteId().isEmpty());
            QCOMPARE(childCollection.remoteId(), childCollection.name());
            QCOMPARE(childCollection.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

            QCOMPARE(childCollection.rights(),
                     Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                         | Collection::CanChangeCollection | Collection::CanDeleteCollection);
        }

        if (firstLevelNames.contains(collection.name())) {
            for (const Collection &childCollection : list) {
                QVERIFY(secondLevelNames.contains(childCollection.name()) || thirdLevelNames.contains(childCollection.name()));
            }
        } else if (secondLevelNames.contains(collection.name())) {
            for (const Collection &childCollection : list) {
                QVERIFY(thirdLevelNames.contains(childCollection.name()));
            }
            if (collection.name() == md1_2.name()) {
                QCOMPARE(list.count(), 1);
                QCOMPARE(list.first().name(), md1_2_1.name());
            } else if (collection.name() == fileInfo1_1.fileName()) {
                QCOMPARE(list.count(), 2);
            }
        } else {
            QCOMPARE(list.count(), 0);
        }
    }
```

#### AUTO 


```{c}
auto collection = parameter.value<Akonadi::Collection>();
```

#### AUTO 


```{c}
auto displayNameStandardItem = new QStandardItem(displayName);
```

#### CONST EXPRESSION 


```{c}
constexpr int DesiredStateTimeoutMs = 200000;
```

#### AUTO 


```{c}
auto *job = new FileStore::ItemFetchJob(items, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item.");
            continue;
        }
        const EwsItem &ewsItem = resp.item();

        Item item(KCalendarCore::Event::eventMimeType());
        item.setParentCollection(mCollection);
        auto id = ewsItem[EwsItemFieldItemId].value<EwsId>();
        item.setRemoteId(id.id());
        item.setRemoteRevision(id.changeKey());

        QString mimeContent = ewsItem[EwsItemFieldMimeContent].toString();
        KCalendarCore::Calendar::Ptr memcal(new KCalendarCore::MemoryCalendar(QTimeZone::utc()));
        format.fromString(memcal, mimeContent);
        KCalendarCore::Incidence::Ptr incidence(memcal->events().last());
        incidence->clearRecurrence();

        QDateTime dt(incidence->dtStart());
        if (dt.isValid()) {
            incidence->setDtStart(dt);
        }
        if (incidence->type() == KCalendarCore::Incidence::TypeEvent) {
            auto event = reinterpret_cast<KCalendarCore::Event *>(incidence.data());
            dt = event->dtEnd();
            if (dt.isValid()) {
                event->setDtEnd(dt);
            }
        }
        dt = incidence->recurrenceId();
        if (dt.isValid()) {
            incidence->setRecurrenceId(dt);
        }

        item.setPayload<KCalendarCore::Incidence::Ptr>(incidence);

        mChangedItems.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsPropertyField &prop : qAsConst(mProps)) {
            prop.write(writer);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(QString::number(entry.messageOffset()));
        item.setParentCollection(collection);

        if (mbox->hasIndexData()) {
            const KMIndexDataPtr indexData = mbox->indexData(entry.messageOffset());
            if (indexData != nullptr && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has"
                                                      << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            } else if (indexData == nullptr) {
                Akonadi::MessageStatus status;
                status.setDeleted(true),
                                  item.setFlags(status.statusFlags());
                qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "no index for item" << item.remoteId() << "in MBox" << mbox->fileName()
                                                  << "so it has been deleted but not purged. Marking it as"
                                                  << item.flags();
            }
        }

        items << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&wallet](KWallet::MyWallet *) {
                                      return nullptr;
                                  }
```

#### AUTO 


```{c}
auto req = new EwsGetItemRequest(mEwsClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mTags)) {
        auto createJob = new Akonadi::TagCreateJob(tag, this);
        createJob->setMergeIfExisting(true);
        connect(createJob, &Akonadi::TagCreateJob::result, this, &CreateAndSetTagsJob::onCreateDone);
    }
```

#### AUTO 


```{c}
auto job = new EventModifyJob(event, item.parentCollection().remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto &key
```

#### RANGE FOR STATEMENT 


```{c}
for (Kolab::ContactReference c : aAttendees) {
                KCalendarCore::Person person(fromStdString(c.name()), fromStdString(c.email()));
                receipents.append(person);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const OXA::Object &object : objects) {
        Item item;
        switch (object.module()) {
        case OXA::Folder::Contacts:
            if (!object.contact().isEmpty()) {
                item.setMimeType(KContacts::Addressee::mimeType());
                item.setPayload<KContacts::Addressee>(object.contact());
            } else {
                item.setMimeType(KContacts::ContactGroup::mimeType());
                item.setPayload<KContacts::ContactGroup>(object.contactGroup());
            }
            break;
        case OXA::Folder::Calendar:
            item.setMimeType(KCalCore::Event::eventMimeType());
            item.setPayload<KCalCore::Incidence::Ptr>(object.event());
            break;
        case OXA::Folder::Tasks:
            item.setMimeType(KCalCore::Todo::todoMimeType());
            item.setPayload<KCalCore::Incidence::Ptr>(object.task());
            break;
        case OXA::Folder::Unbound:
            Q_ASSERT(false);
            break;
        }
        const RemoteInformation remoteInformation(object.objectId(), object.module(), object.lastModified());
        remoteInformation.store(item);

        items.append(item);
    }
```

#### AUTO 


```{c}
auto *postJob = qobject_cast<KIO::StoredTransferJob *>(job);
```

#### AUTO 


```{c}
auto *annotationsAttribute
            = c.attribute<Akonadi::CollectionAnnotationsAttribute>();
```

#### AUTO 


```{c}
auto *folderJob = qobject_cast<EwsSubscribedFoldersJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : addressesEmails) {
        if ((prefEmail == -1) && (e == addressee.preferredEmail())) {
            prefEmail = count;
        }
        count++;
        emails.push_back(
            Kolab::Email(toStdString(e), emailTypesFromStringlist(addressee.custom(QStringLiteral("KOLAB"), QStringLiteral("EmailTypes%1").arg(e)))));
    }
```

#### AUTO 


```{c}
auto *job = new FileStore::ItemModifyJob(item, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavUtils::DavUrl &url : urls) {
        if (url.protocol() == DavUtils::CalDav) {
            ++mRequestsTracker[email].handlingJobCount;
            DavPrincipalSearchJob *job = new DavPrincipalSearchJob(url, DavPrincipalSearchJob::EmailAddress, email);
            job->setProperty("email", QVariant::fromValue(email));
            job->setProperty("url", QVariant::fromValue(url.url().toString()));
            job->fetchProperty(QStringLiteral("schedule-inbox-URL"), QStringLiteral("urn:ietf:params:xml:ns:caldav"));
            connect(job, &DavPrincipalSearchJob::result, this, &DavFreeBusyHandler::onPrincipalSearchJobFinished);
            job->start();
        }
    }
```

#### AUTO 


```{c}
auto job = new CalendarDeleteJob(collection.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto *copy = new FileStore::EntityCompactChangeAttribute();
```

#### AUTO 


```{c}
auto *requestJob = qobject_cast<OXA::FoldersRequestDeltaJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                setSslIcon(QStringLiteral("security-low"));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &l : list) {
        const QVariantMap reminder = l.toMap();

        KGAPI2::ReminderPtr rem(new KGAPI2::Reminder);

        const QString reminderType = reminder[QStringLiteral("type")].toString();
        if (reminderType == QLatin1String("display")) {
            rem->setType(KCalendarCore::Alarm::Display);
        } else if (reminderType == QLatin1String("email")) {
            rem->setType(KCalendarCore::Alarm::Email);
        }

        KCalendarCore::Duration offset(reminder[QStringLiteral("time")].toInt(), KCalendarCore::Duration::Seconds);
        rem->setStartOffset(offset);

        m_reminders << rem;
    }
```

#### AUTO 


```{c}
auto job = new KDAV::DavPrincipalSearchJob(url, KDAV::DavPrincipalSearchJob::EmailAddress, email);
```

#### LAMBDA EXPRESSION 


```{c}
[](const Akonadi::AgentInstance &instance) {
        qDebug() << "AgentInstanceAdded" << instance.identifier();
    }
```

#### AUTO 


```{c}
auto *updateJob = new UpdateJob(col, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &folder : lstKeys) {
        mMetadata.insert(folder, metadata.value(folder));
    }
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::TagFetchJob(tag);
```

#### AUTO 


```{c}
auto listJob = new KIMAP::ListJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &messageId : qAsConst(m_messageIds)) {
            QByteArray header = "Message-ID ";
            header += messageId;
            subterms << KIMAP::Term(QStringLiteral("Message-ID"), QString::fromLatin1(messageId));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&fail,&job]{
        if (fail) {
            job->postResponse("");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &note : notes) {
        Akonadi::Item item(Akonadi::NoteUtils::noteMimeType());
        item.setRemoteId(note.toObject()[QLatin1String("guid")].toString());
        mResultItems << item;
        qCDebug(TOMBOYNOTESRESOURCE_LOG) << "TomboyItemsDownloadJob: Retriving note with id" << item.remoteId();
    }
```

#### AUTO 


```{c}
auto *fetch = new Akonadi::RelationFetchJob(relation);
```

#### AUTO 


```{c}
auto subContainerLayout = new QVBoxLayout(d->mSubContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (Item item : qAsConst(items)) {
        if (item.remoteId() == contact->uid()) {
            item.setPayload<KContacts::Addressee>(*contact.dynamicCast<KContacts::Addressee>());
            new ItemModifyJob(item, this);
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int prot : std::as_const(supportedAuths)) {
        authCombo->addItem(Transport::authenticationTypeString(prot), prot);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attachment &a : std::as_const(mAttachments)) {
        if (a.isUri()) {
            writeString(element, QStringLiteral("link-attachment"), a.uri());
        } else if (a.isBinary()) {
            writeString(element, QStringLiteral("inline-attachment"), a.label());
        }
    }
```

#### AUTO 


```{c}
auto job = new ContactsGroupFetchJob(m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        qCDebug(ETESYNC_LOG) << "emitResult from JournalsFetchJob";
        emitResult();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : std::as_const(m_taskList)) {
            task->kill();
            delete task;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &childCollection : list) {
                QVERIFY(secondLevelNames.contains(childCollection.name()) || thirdLevelNames.contains(childCollection.name()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Related &rel : relateds) {
            if (rel.type() != Kolab::Related::Text) {
                qCCritical(PIMKOLAB_LOG) << "relation type not supported";
                continue;
            }
            if (rel.relationTypes() & Kolab::Related::Spouse) {
                addressee.insertCustom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("X-SpousesName"), fromStdString(rel.text())); // TODO support multiple
            } else {
                qCWarning(PIMKOLAB_LOG) << "relation not supported";
                continue;
            }
        }
```

#### AUTO 


```{c}
auto *unsubscribe = new KIMAP::UnsubscribeJob(m_session);
```

#### AUTO 


```{c}
auto *modifyJob = new CollectionModifyJob(c, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const AgentInstance &instance, bool state) {
            if (instance == *mEwsInstance && state == online) {
                qDebug() << "is online" << state;
                loop.exit(0);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenJob]() {
                if (tokenJob->error()) {
                    emitError(tokenJob->errorText());
                    return;
                }

                // Convert the cookies into a HTTP Cookie header that we can pass
                // to KIO
                mCookies = QStringLiteral("Cookie: ");
                const auto parsedCookies = QNetworkCookie::parseCookies(tokenJob->cookies());
                for (const auto &cookie : parsedCookies) {
                    mCookies += QStringLiteral("%1=%2; ").arg(QString::fromUtf8(cookie.name()),
                                                              QString::fromUtf8(cookie.value()));
                }
                fetchFacebookEventsPage();
            }
```

#### AUTO 


```{c}
auto task = new ChangeCollectionTask(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsId &id : qAsConst(d->mSubscribedIds)) {
        list.append(id.id());
    }
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(randomList1)) {
        Item item1;
        item1.setId(KRandom::random());
        item1.setRemoteId(entry);
        item1.setParentCollection(collection1);

        job = mStore->fetchItem(item1);
        job->fetchScope().fetchFullPayload(true);

        spy = new QSignalSpy(job, &FileStore::ItemFetchJob::itemsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        items = job->items();
        QCOMPARE((int)items.count(), 1);
        QCOMPARE(itemsFromSpy(spy), items);

        Item item = items.first();
        QCOMPARE(item, item1);
        QVERIFY(item.hasPayload<KMime::Message::Ptr>());

        KMime::Message::Ptr msgPtr = item.payload<KMime::Message::Ptr>();
        QVERIFY(msgPtr != 0);

        const QSet<QByteArray> parts = messageParts(msgPtr);
        QVERIFY(!parts.isEmpty());
        QVERIFY(parts.contains(MessagePart::Header));
        QVERIFY(parts.contains(MessagePart::Body));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SetupWizard::Url &url : urls) {
                auto *urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = url.url;
                urlConfig->mProtocol = url.protocol;
                urlConfig->mUser = url.userName;
                urlConfig->mPassword = wizard.field(QStringLiteral("credentialsPassword")).toString();

                Settings::self()->newUrlConfiguration(urlConfig);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsFolder &folder : qAsConst(mFolders)) {
        auto item = new QStandardItem(folder[EwsFolderFieldDisplayName].toString());
        item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        item->setCheckable(true);
        auto id = folder[EwsFolderFieldFolderId].value<EwsId>();
        item->setData(id.id(), ItemIdRole);
        if (mSubscribedIds.contains(EwsId(id.id()))) {
            item->setCheckState(Qt::Checked);
        }
        auto parentId = folder[EwsFolderFieldParentFolderId].value<EwsId>();
        if (parentId.type() != EwsId::Unspecified) {
            QStandardItem *parentItem = mFolderItemHash.value(parentId.id());
            if (parentItem) {
                parentItem->appendRow(item);
            }
        }
        mFolderItemHash.insert(id.id(), item);
    }
```

#### AUTO 


```{c}
auto *deletedJob = new ObjectsRequestJob(mFolder, mLastSync, ObjectsRequestJob::Deleted, this);
```

#### AUTO 


```{c}
auto entries = qobject_cast<EntriesFetchJob *>(job)->getEntries();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Event &e : events) {
        list.append(Kolab::Conversion::toKCalendarCore(e));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AgentInstance agent : AgentManager::self()->instances()) {
        agent.setIsOnline(false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        EwsId id(item.remoteId(), item.remoteRevision());
        ids.append(id);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        doEmitResult(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
        EwsItemType type = EwsItemHandler::mimeToItemType(item.mimeType());
        if (type == EwsItemTypeUnknown) {
            setErrorText(QStringLiteral("Unknown item type %1 for item %2").arg(item.mimeType(), item.remoteId()));
            emitResult();
            return;
        } else {
            items[type].append(item);
        }
    }
```

#### AUTO 


```{c}
auto append = new UpdateMessageJob(message, session, tag.gid(), QSharedPointer<TagMerger>(new TagMerger), mailBox, uidNext, oldUid, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const Item &item) {
        ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
        contact->addGroup(collection.remoteId());
        return contact;
    }
```

#### AUTO 


```{c}
auto *fetchJob = new Akonadi::ItemFetchJob(col, session);
```

#### LAMBDA EXPRESSION 


```{c}
[&receivedReq](const QString & req, QXmlResultItems &, const QXmlNamePool &) {
        receivedReq = req;
        return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("testresp"), 200);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::RecurrenceRule::WDayPos &i : l) {
        ba += QByteArray::number(i.pos()) + " ";
        ba += QByteArray::number(i.day()) + ", ";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : qAsConst(mFetchItemsJobQueue)) {
        dump += QStringLiteral(" %1:%2\n").arg(item.col.id()).arg(item.type);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        Q_ASSERT(QThread::currentThread() != qApp->thread());
        const Result result = protocol->openConnection();
        Q_EMIT jobDone(result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QString &password) {
                                           password = QStringLiteral("foo");
                                           return true;
                                       }
```

#### AUTO 


```{c}
auto it = mTagData.cbegin(), end(mTagData.cend());
```

#### AUTO 


```{c}
auto minorBuildRef = attrs.value(QStringLiteral("MinorBuildNumber"));
```

#### AUTO 


```{c}
const auto aAttendees{a.attendees()};
```

#### AUTO 


```{c}
auto deletedJob = new ObjectsRequestJob(mFolder, mLastSync, ObjectsRequestJob::Deleted, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : qAsConst(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            usagesMap[key] = value.toLongLong();
        }
```

#### AUTO 


```{c}
const auto *transportAttribute = item.attribute<TransportAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        qCDebug(ETESYNC_LOG) << "emitResult from EntriesFetchJob";
        emitResult();
    }
```

#### AUTO 


```{c}
auto agentCreateJob = new AgentInstanceCreateJob(ewsType);
```

#### AUTO 


```{c}
auto *fetchJob
        = new CollectionFetchJob(collection, CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto job = static_cast<CollectionFetchJob *>(j);
```

#### AUTO 


```{c}
const auto mail = item.payload<KMime::Message::Ptr>();
```

#### AUTO 


```{c}
auto tokens = subtype.split(QLatin1Char(':'));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flagsLst) {
            i.setFlag(flag);
        }
```

#### AUTO 


```{c}
const auto item = m_messageHelper->createItemFromMessage(
                                msg->message, msg->uid, msg->size, msg->attributes,
                                msg->flags, fetch->scope(), ok);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsItem &item : qAsConst(mItems)) {
        item.write(writer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &incidence : qAsConst(incidences)) {
            if (incidence->hasRecurrenceId()) {
                qCDebug(DAVRESOURCE_LOG) << "Exception found with ID" << incidence->instanceIdentifier();
                exceptions << incidence;
            } else {
                mainIncidence = incidence;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Collection &col, const DesiredState &state) {
        auto attr = col.attribute<SpecialCollectionAttribute>();
        QByteArray specialType;
        if (attr) {
            specialType = attr->collectionType();
        }
        return col.parentCollection().remoteId() == state.parentId && specialType == state.specialType;
    }
```

#### AUTO 


```{c}
auto group = config()->group("BirthdaysConfigWidget");
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &exception : std::as_const(exceptions)) {
            if (exception->status() == KCalendarCore::Incidence::StatusCanceled) {
                const QDateTime exDateTime(exception->recurrenceId());
                mainIncidence->recurrence()->addExDateTime(exDateTime);
            } else {
                // The exception remote id will contain a fragment pointing to
                // its instance identifier to distinguish it from the main
                // event.
                const QString rid = target.remoteId() + QLatin1String("#") + exception->instanceIdentifier();
                qCDebug(DAVRESOURCE_LOG) << "Extra incidence at" << rid;
                Akonadi::Item extraItem = target;
                extraItem.setRemoteId(rid);
                extraItem.setRemoteRevision(source.etag());
                extraItem.setMimeType(exception->mimeType());
                extraItem.setPayload<IncidencePtr>(exception);
                extraItems << extraItem;
            }
        }
```

#### AUTO 


```{c}
auto *quota = new KIMAP::GetQuotaRootJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &entry : entries) {
        const QString entryFileName = entry.fileName();
        if (entryFileName == QLatin1String("WARNING_README.txt")) {
            continue;
        }

        Item item;
        item.setRemoteId(entryFileName);

        if (entryFileName.endsWith(QLatin1String(".vcf"))) {
            item.setMimeType(KContacts::Addressee::mimeType());
        } else if (entryFileName.endsWith(QLatin1String(".ctg"))) {
            item.setMimeType(KContacts::ContactGroup::mimeType());
        } else {
            cancelTask(i18n("Found file of unknown format: '%1'", entry.absoluteFilePath()));
            return;
        }

        items.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Telephone &tel : contactTelephones) {
            bool pref = false;
            if (index == contact.telephonesPreferredIndex()) {
                pref = true;
            }
            KContacts::PhoneNumber number(fromStdString(tel.number()), toPhoneType(tel.types(), pref));
            index++;
            addressee.insertPhoneNumber(number);
        }
```

#### AUTO 


```{c}
auto *quotaAttribute = m_collection.attribute<Akonadi::CollectionQuotaAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto *fetchJob = qobject_cast<FileStore::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        qDebug() << "Verifying response" << i++;
        QCOMPARE(resp.responseClass(), *respClassesIt);
        if (resp.isSuccess()) {
            auto id = resp.item()[EwsItemFieldItemId].value<EwsId>();
            QCOMPARE(id, *idsIt);
        }
        ++idsIt;
        ++respClassesIt;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &loc : {QLatin1String("street"), QLatin1String("city"), QLatin1String("zip"), QLatin1String("country")}) {
                const auto it = location.constFind(loc);
                if (it != placeEnd) {
                    locationStr << it->toString();
                }
            }
```

#### AUTO 


```{c}
auto fetch = static_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : qAsConst(calendars)) {
        const CalendarPtr &calendar = object.dynamicCast<Calendar>();

        if (!activeCalendars.contains(calendar->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalendarCore::Event::eventMimeType());
        collection.setName(calendar->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(calendar->uid());
        if (calendar->editable()) {
            collection.setRights(Collection::CanChangeCollection
                                 |Collection::CanCreateItem
                                 |Collection::CanChangeItem
                                 |Collection::CanDeleteItem);
        } else {
            collection.setRights(Collection::ReadOnly);
        }

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(calendar->title());
        attr->setIconName(QStringLiteral("view-calendar"));

        auto colorAttr = collection.attribute<CollectionColorAttribute>(Collection::AddIfMissing);
        colorAttr->setColor(calendar->backgroundColor());

        DefaultReminderAttribute *reminderAttr = collection.attribute<DefaultReminderAttribute>(Collection::AddIfMissing);
        reminderAttr->setReminders(calendar->defaultReminders());

        // Block email reminders, since Google sends them for us
        BlockAlarmsAttribute *blockAlarms = collection.attribute<BlockAlarmsAttribute>(Collection::AddIfMissing);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Audio, false);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Display, false);
        blockAlarms->blockAlarmType(KCalendarCore::Alarm::Procedure, false);

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QString &password) {
            password = QStringLiteral("foo");
            return true;
        }
```

#### AUTO 


```{c}
auto job = new CollectionModifyJob(collection, transaction());
```

#### AUTO 


```{c}
auto *server = qobject_cast<FakeEwsServer *>(parent());
```

#### AUTO 


```{c}
auto colorAttr = newCollection.attribute<Akonadi::CollectionColorAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &err) {
        error(QStringLiteral("Network reply error"), err, QUrl());
    }
```

#### AUTO 


```{c}
const auto *colorAttr = collection.attribute<Akonadi::CollectionColorAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &c : certificates) {
        if (c.issuerInfo() == authoritiesInfo) {
            cert = c;
            break;
        }
    }
```

#### AUTO 


```{c}
auto *statusLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto majorRef = attrs.value(QStringLiteral("MajorVersion"));
```

#### AUTO 


```{c}
auto *modJob = new Akonadi::ItemModifyJob(mItem, this);
```

#### AUTO 


```{c}
auto itemJob = qobject_cast<FileStore::ItemMoveJob *>(job);
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<ItemCreateJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->processNextBatch();
    }
```

#### AUTO 


```{c}
auto search = new KIMAP::SearchJob(select->session());
```

#### AUTO 


```{c}
auto job = new Akonadi::RecursiveItemFetchJob(mDavCollectionRoot, QStringList());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &desc : namespaces) {
        if (path.startsWith(desc.name.left(desc.name.size() - 1))) { //Namespace ends with path separator and pathPart doesn't
            if (!matchCompletePath || path.size() - desc.name.size() <= 1) {      //We want to match only for the complete path
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
auto job = new TomboyServerAuthenticateJob(mManager, this);
```

#### AUTO 


```{c}
auto *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto collection = fetchJob->collection();
```

#### RANGE FOR STATEMENT 


```{c}
for (KMime::Content *c : contents) {
        typeList.append(c->contentType()->mimeType());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Attribute *attr : qAsConst(attributes)) {
        tag.addAttribute(attr);
    }
```

#### AUTO 


```{c}
auto rights = new KIMAP::MyRightsJob(mSession);
```

#### AUTO 


```{c}
auto task = new ChangeItemTask(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : std::as_const(mMailboxes)) {
            const QStringList parts = mailbox.split(mSeparator);
            if (!parts.isEmpty()) {
                if (isNamespaceFolder(mailbox, mUserNamespace) && parts.length() >= 2) {
                    // Other Users can be too big to request with a single command so we request Other Users/<user>/*
                    toplevelMailboxes << parts.at(0) + mSeparator + parts.at(1) + mSeparator;
                } else if (!isNamespaceFolder(mailbox, mSharedNamespace)) {
                    toplevelMailboxes << parts.first();
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &flag : flags) {
            item.setFlag(flag);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](KGAPI2::Job *job){
                if (!m_iface->handleError(job)) {
                    return;
                }
                Item newItem(item);
                const EventPtr event = qobject_cast<EventCreateJob *>(job)->items().first().dynamicCast<Event>();
                qCDebug(GOOGLE_CALENDAR_LOG) << "Event added";
                newItem.setRemoteId(event->id());
                newItem.setRemoteRevision(event->etag());
                newItem.setGid(event->uid());
                m_iface->itemChangeCommitted(newItem);
                newItem.setPayload<KCalendarCore::Event::Ptr>(event.dynamicCast<KCalendarCore::Event>());
                new ItemModifyJob(newItem, this);
                emitReadyStatus();
            }
```

#### AUTO 


```{c}
auto job = new KIMAP::UnsubscribeJob(session);
```

#### AUTO 


```{c}
auto nameRef = reader.attributes().value(QStringLiteral("HeaderName"));
```

#### AUTO 


```{c}
const auto longitude = place.constFind(QLatin1String("longitude"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &fetchedItem : fetchedItems) {
                    auto todo = fetchedItem.payload<KCalendarCore::Todo::Ptr>();
                    TaskPtr task(new Task(*todo));
                    const QString parentId = task->relatedTo(KCalendarCore::Incidence::RelTypeParent);
                    if (parentId.isEmpty()) {
                        continue;
                    }

                    auto it = std::find_if(items.cbegin(), items.cend(), [&parentId](const Item &item){
                                return item.remoteId() == parentId;
                            });
                    if (it != items.cend()) {
                        Item newItem(fetchedItem);
                        qCDebug(GOOGLE_TASKS_LOG) << "Detaching child" << newItem.remoteId() << "from" << parentId;
                        todo->setRelatedTo(QString(), KCalendarCore::Incidence::RelTypeParent);
                        newItem.setPayload<KCalendarCore::Todo::Ptr>(todo);
                        detachItems << newItem;
                        detachTasks << task;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsMoveItemRequest::Response &resp : reqResponses) {
        QCOMPARE(resp.responseClass(), EwsResponseSuccess);
        QCOMPARE(resp.itemId(), *newIdsIt);
        ++newIdsIt;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : remoteUrlsLst) {
        QStringList splitUrl = url.split(QLatin1Char('|'));

        if (splitUrl.size() == 3) {
            const KDAV::Protocol protocol = Utils::protocolByTranslatedName(splitUrl.at(1));
            splitUrl[1] = KDAV::ProtocolInfo::protocolName(protocol);
            updatedUrls << splitUrl.join(QLatin1Char('|'));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventFile &data : qAsConst(mEvents)) {
            createItem(data.event);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::AccountPromise *promise) {
            if (promise->account()) {
                promise = KGAPI2::AccountManager::instance()->refreshTokens(GOOGLE_API_KEY, GOOGLE_API_SECRET, mResource->settings()->userName());
            } else {
                promise = KGAPI2::AccountManager::instance()->getAccount(GOOGLE_API_KEY,
                                                                         GOOGLE_API_SECRET,
                                                                         mResource->settings()->userName(),
                                                                         {KGAPI2::Account::mailScopeUrl()});
            }
            connect(promise, &KGAPI2::AccountPromise::finished, this, &GmailPasswordRequester::onTokenRequestFinished);
            mPendingPromise = promise;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetFolderRequest::Response &resp : responses) {
        if (resp.isSuccess()) {
            auto fid = resp.folder()[EwsFolderFieldFolderId].value<EwsId>();
            QMap<QString, Collection>::iterator mapIt = map.find(fid.id());
            if (mapIt != map.end()) {
                qCDebugNC(EWSRES_LOG)
                    << QStringLiteral("Registering folder %1(%2) as special collection %3").arg(ewsHash(mapIt->remoteId())).arg(mapIt->id()).arg(it->type);
                SpecialMailCollections::self()->registerCollection(it->type, *mapIt);
                if (!mapIt->hasAttribute<EntityDisplayAttribute>()) {
                    auto attr = mapIt->attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
                    attr->setIconName(it->iconName);
                    auto modJob = new CollectionModifyJob(*mapIt, this);
                    modJob->start();
                }
            }
        }
        it++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job){
        if (!m_iface->handleError(job)) {
            return;
        }
        qCDebug(GOOGLE_TASKS_LOG) << "Task lists retrieved";

        const ObjectsList taskLists = qobject_cast<TaskListFetchJob *>(job)->items();
        const QStringList activeTaskLists = m_settings->taskLists();
        Collection::List collections;
        for (const ObjectPtr &object : taskLists) {
            const TaskListPtr &taskList = object.dynamicCast<TaskList>();
            qCDebug(GOOGLE_TASKS_LOG) << " -" << taskList->title() << "(" << taskList->uid() << ")";

            if (!activeTaskLists.contains(taskList->uid())) {
                qCDebug(GOOGLE_TASKS_LOG) << "Skipping, not subscribed";
                continue;
            }

            Collection collection;
            setupCollection(collection, taskList);
            collection.setParentCollection(rootCollection);
            collections << collection;
        }

        m_iface->collectionsRetrievedFromHandler(collections);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&collection](const GenericHandler::Ptr &handler){
                return collection.contentMimeTypes().contains(handler->mimeType());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::AgentInstance &instance : lst) {
                    if (instance.identifier() == it.key().resource()) {
                        mCacheResourceName.insert(instance.identifier(), instance.name());
                        resourceName = instance.name();
                        break;
                    }
                }
```

#### AUTO 


```{c}
auto *trJob = qobject_cast<KIO::TransferJob *>(job);
```

#### AUTO 


```{c}
auto job = new KIMAP::CreateJob(session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : lst) {
        mScheduler.start(index.data(MigratorModel::IdentifierRole).toString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(QString::number(entry.messageOffset()));
        item.setParentCollection(collection);

        if (mbox->hasIndexData()) {
            const KMIndexDataPtr indexData = mbox->indexData(entry.messageOffset());
            if (indexData != Q_NULLPTR && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has"
                                                      << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            } else if (indexData == Q_NULLPTR) {
                Akonadi::MessageStatus status;
                status.setDeleted(true),
                                  item.setFlags(status.statusFlags());
                qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "no index for item" << item.remoteId() << "in MBox" << mbox->fileName()
                                                  << "so it has been deleted but not purged. Marking it as"
                                                  << item.flags();
            }
        }

        items << item;
    }
```

#### AUTO 


```{c}
const auto networkError = refreshReply->networkError();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &fragment : fragments) {
        path.append(ownUrlDecode(fragment).toUtf8());
    }
```

#### AUTO 


```{c}
auto req = new EwsMoveItemRequest(mClient, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &childCollection : list) {
                QVERIFY(secondLevelNames.contains(childCollection.name()));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KIMAP::MailBoxDescriptor &descriptor : descriptors) {
        m_fullReportedCollections.insert(descriptor.name);
    }
```

#### AUTO 


```{c}
const auto url = info.requestUrl();
```

#### AUTO 


```{c}
auto modifyJob = qobject_cast<FileStore::CollectionModifyJob *>(job);
```

#### AUTO 


```{c}
auto profile = new QWebEngineProfile(resourceIdentifier, this);
```

#### AUTO 


```{c}
auto reply = qobject_cast<QNetworkReply *>(sender());
```

#### AUTO 


```{c}
const auto keys{metadataMap.keys()};
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qDebug() << "Test timeout";
        loop.exit(1);
    }
```

#### AUTO 


```{c}
const auto latitude = place.constFind(QLatin1String("latitude"));
```

#### AUTO 


```{c}
auto resp = synchronousHttpReq(QStringLiteral("<test1><a /></test1>"), thread.portNumber());
```

#### AUTO 


```{c}
auto *job = new Akonadi::CollectionModifyJob(collection);
```

#### AUTO 


```{c}
const auto owner = data.constFind(QLatin1String("owner"));
```

#### AUTO 


```{c}
const auto protoAttr = collection.attribute<DavProtocolAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[this, job]() {
                if (job->error()) {
                    emitError(job->errorText());
                    return;
                }

                const auto json = QJsonDocument::fromJson(qobject_cast<KIO::StoredTransferJob*>(job)->data());
                const auto me = json.object();

                d->userName = me.value(QStringLiteral("name")).toString();
                d->id = me.value(QStringLiteral("id")).toString();
                d->wallet->writeMap(qobject_cast<FacebookResource*>(parent())->identifier(),
                                    { { KWalletKeyToken, d->token },
                                      { KWalletKeyName, d->userName },
                                      { KWalletKeyId, d->id },
                                      { KWalletKeyCookies, QString::fromUtf8(d->cookies) }
                                    });
                emitResult();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &oldId : oldIds) {
                if (!ids.contains(oldId)) {
                    auto *job = new KIMAP::SetAclJob(session);
                    job->setMailBox(mailBoxForCollection(collection()));
                    job->setIdentifier(oldId);
                    job->setRights(KIMAP::SetAclJob::Remove, oldRights[oldId]);

                    connect(job, &KIMAP::SetAclJob::result, this, &ChangeCollectionTask::onSetAclDone);

                    job->start();

                    m_pendingJobs++;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const std::string &entry : entries) {
            d->mDictionary.append(Conversion::fromStdString(entry));
        }
```

#### AUTO 


```{c}
const auto payloadB64 = payload.toUtf8().toBase64(QByteArray::Base64UrlEncoding | QByteArray::OmitTrailingEquals);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &, QXmlResultItems &, const QXmlNamePool &) {
                                                          return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<a/>"), 200);
                                                      }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : indexes) {
        //qCritical() << "SELECTED DATA: " << index.data(Qt::UserRole + 1).toString();
        ret << index.data(Qt::UserRole + 1).toString();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventPtr &event : qAsConst(recurrentEvents)) {
            Item item;
            item.setRemoteId(event->uid());
            item.setRemoteRevision(event->etag());
            item.setPayload< KCalCore::Event::Ptr >(event.dynamicCast<KCalCore::Event>());
            item.setMimeType(KCalCore::Event::eventMimeType());
            item.setParentCollection(collection);

            changedItems << item;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavCollection &collection : collections) {
        QStandardItem *item = new QStandardItem(collection.displayName());
        QString data(DavUtils::protocolName(collection.protocol()) + QLatin1Char('|') + collection.url());
        item->setData(data, Qt::UserRole + 1);
        item->setToolTip(collection.url());
        if (collection.protocol() == DavUtils::CalDav) {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-calendar")));
        } else {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-pim-contacts")));
        }
        mModel->appendRow(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavCollection &collection : collections) {
        auto item = new QStandardItem(collection.displayName());
        QString data(KDAV::ProtocolInfo::protocolName(collection.url().protocol()) + QLatin1Char('|') + collection.url().toDisplayString());
        item->setData(data, Qt::UserRole + 1);
        item->setToolTip(collection.url().toDisplayString());
        if (collection.url().protocol() == KDAV::CalDav) {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-calendar")));
        } else {
            item->setIcon(QIcon::fromTheme(QStringLiteral("view-pim-contacts")));
        }
        mModel->appendRow(item);
    }
```

#### AUTO 


```{c}
auto server = qobject_cast<FakeEwsServer *>(parent());
```

#### AUTO 


```{c}
auto it = mItems.begin();
```

#### AUTO 


```{c}
auto select = new KIMAP::SelectJob(store->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (int size : qAsConst(sizes)) {
        mTotalBytesToDownload += size;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QXmlStreamReader &reader) {
        return parseSubscribeResponse(reader);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            qCWarning(ETESYNC_LOG) << job->errorText();
            return;
        }

        Collection collection = currentCollection();
        QString prevUid = collection.remoteRevision();
        QString journalUid = collection.remoteId();

        bool isIncremental = false;

        if (!prevUid.isEmpty() && !prevUid.isNull()) {
            isIncremental = true;
        }

        qCDebug(ETESYNC_LOG) << "Retrieving entries";
        EteSyncEntry **entries = qobject_cast<EntriesFetchJob *>(job)->entries();

        EteSyncJournalPtr journal(etesync_journal_manager_fetch(journalManager.get(), journalUid));
        EteSyncCryptoManagerPtr cryptoManager(etesync_journal_get_crypto_manager(journal.get(), derived, keypair.get()));

        QMap<QString, KContacts::Addressee> contacts;
        QMap<QString, QString> remoteIDs;

        Item::List changedItems;
        Item::List removedItems;

        for (EteSyncEntry **iter = entries; *iter; iter++) {
            EteSyncEntryPtr entry(*iter);
            EteSyncSyncEntryPtr syncEntry(etesync_entry_get_sync_entry(entry.get(), cryptoManager.get(), prevUid));

            KContacts::VCardConverter converter;
            CharPtr contentStr(etesync_sync_entry_get_content(syncEntry.get()));
            QByteArray content(contentStr.get());
            const KContacts::Addressee contact = converter.parseVCard(content);

            const QString action = QStringFromCharPtr(CharPtr(etesync_sync_entry_get_action(syncEntry.get())));
            // qCDebug(ETESYNC_LOG) << action;
            // qCDebug(ETESYNC_LOG) << contact.uid();
            if (action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_ADD) || action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_CHANGE)) {
                contacts[contact.uid()] = contact;
                remoteIDs[contact.uid()] = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
            } else if (action == QStringLiteral(ETESYNC_SYNC_ENTRY_ACTION_DELETE)) {
                if (contacts.contains(contact.uid())) {
                    contacts.remove(contact.uid());
                } else {
                    Item item;
                    item.setMimeType(KContacts::Addressee::mimeType());
                    item.setParentCollection(collection);
                    item.setRemoteId(contact.uid());
                    item.setPayload<KContacts::Addressee>(contact);
                    removedItems << item;
                }
            }

            prevUid = QStringFromCharPtr(CharPtr(etesync_entry_get_uid(entry.get())));
        }

        free(entries);

        collection.setRemoteRevision(prevUid);
        new CollectionModifyJob(collection, this);

        for (auto it = contacts.constBegin(); it != contacts.constEnd(); it++) {
            Item item;
            item.setMimeType(KContacts::Addressee::mimeType());
            item.setParentCollection(collection);
            item.setRemoteId(it.key());
            item.setPayload<KContacts::Addressee>(it.value());
            changedItems << item;
        }

        if (isIncremental)
            itemsRetrievedIncremental(changedItems, removedItems);
        else
            itemsRetrieved(changedItems);
    }
```

#### AUTO 


```{c}
auto *job = new FileStore::CollectionMoveJob(collection, targetParent, d->mSession);
```

#### AUTO 


```{c}
const auto seenUidTimeListValue{mPOP3SettingsInterface->seenUidTimeList().value()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!item.remoteId().isEmpty()) {
            m_localItems.insert(item.remoteId(), item);
        }
    }
```

#### AUTO 


```{c}
const auto params{requestParameters()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sf : lstMaildir) {
            const Maildir subMd = Maildir(path() + QLatin1Char('/') + sf);
            if (!subMd.isValid(createMissingFolders)) {
                d->lastError = subMd.lastError();
                return false;
            }
        }
```

#### AUTO 


```{c}
auto vboxLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto msIana = QTimeZone::windowsIdToDefaultIanaId(ktz.name().toUtf8());
```

#### AUTO 


```{c}
const auto map = argument.value<QVariantMap>();
```

#### AUTO 


```{c}
auto *move = static_cast<KIMAP::MoveJob *>(job);
```

#### AUTO 


```{c}
auto moveJob = qobject_cast<OXA::ObjectMoveJob *>(job);
```

#### AUTO 


```{c}
auto fetch = new KIMAP::FetchJob(select->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item) {
        itemFetched(item);
    }
```

#### AUTO 


```{c}
auto req = new EwsGetEventsRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto *fetchJob = new KDAV::DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
const auto &parsedCookie
```

#### AUTO 


```{c}
auto dlg = new SetupServer(this, windowId);
```

#### AUTO 


```{c}
auto readJob = new ReadPasswordJob(QStringLiteral("pop3"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const OXA::Object &object : modifiedObjects) {
        Item item;
        switch (object.module()) {
        case OXA::Folder::Contacts:
            if (!object.contact().isEmpty()) {
                item.setMimeType(KContacts::Addressee::mimeType());
                item.setPayload<KContacts::Addressee>(object.contact());
            } else {
                item.setMimeType(KContacts::ContactGroup::mimeType());
                item.setPayload<KContacts::ContactGroup>(object.contactGroup());
            }
            break;
        case OXA::Folder::Calendar:
            item.setMimeType(KCalCore::Event::eventMimeType());
            item.setPayload<KCalCore::Incidence::Ptr>(object.event());
            break;
        case OXA::Folder::Tasks:
            item.setMimeType(KCalCore::Todo::todoMimeType());
            item.setPayload<KCalCore::Incidence::Ptr>(object.task());
            break;
        case OXA::Folder::Unbound:
            Q_ASSERT(false);
            break;
        }
        const RemoteInformation remoteInformation(object.objectId(), object.module(), object.lastModified());
        remoteInformation.store(item);

        // the value of objectsLastSync is determined by the maximum last modified value
        // of the added or changed objects
        objectsLastSync = qMax(objectsLastSync, object.lastModified().toULongLong());

        changedItems.append(item);
    }
```

#### AUTO 


```{c}
auto *attachMessage = new KMime::Content;
```

#### AUTO 


```{c}
auto job = new EwsGlobalTagsWriteJob(mTagStore, mEwsClient, mRootCollection, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        checkFuture();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        closeConnection();
        return Result::fail(ERR_SASL_FAILURE, i18n("An error occurred during authentication: %1", QString::fromUtf8(sasl_errdetail(conn))));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int seenTime : seenUidTimeListValue) {
        // Those message were just downloaded from the fake server, so they are at maximum
        // 10 minutes old (for slooooow running tests)
        QVERIFY(seenTime >= time(nullptr) - 10 * 60);
    }
```

#### AUTO 


```{c}
const auto uid = event->uid();
```

#### AUTO 


```{c}
auto task = new KolabRetrieveTagTask(createResourceState(TaskArguments()), KolabRetrieveTagTask::RetrieveRelations, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : keys) {
        const QMap<QByteArray, QByteArray> metadata = metadataMap.value(mailbox);
        if (mMailCollections.contains(mailbox)) {
            Akonadi::Collection &collection = mMailCollections[mailbox];
            // qCDebug(KOLABRESOURCE_LOG) << mailbox << metadata << type << folderType << KolabHelpers::getContentMimeTypes(folderType);
            collection.attribute<Akonadi::CollectionAnnotationsAttribute>(Akonadi::Collection::AddIfMissing)->setAnnotations(metadata);
            const QByteArray type = KolabHelpers::getFolderTypeAnnotation(metadata);
            const Kolab::FolderType folderType = KolabHelpers::folderTypeFromString(type);
            collection.setContentMimeTypes(KolabHelpers::getContentMimeTypes(folderType));
            const QColor color = KolabHelpers::getFolderColor(metadata);
            if (color.isValid()) {
                collection.attribute<Akonadi::CollectionColorAttribute>(Akonadi::Collection::AddIfMissing)->setColor(color);
            }
            QSet<QByteArray> keepLocalChanges = collection.keepLocalChanges();
            keepLocalChanges.remove(cContentMimeTypes);
            collection.setKeepLocalChanges(keepLocalChanges);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {itemModifyJobResult(job); }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavCollectionsMultiFetchJob(davUrls, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { transportResult(job);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &result : results) {
            const QStringList split = result.split(QLatin1Char('|'));
            KDAV::Protocol protocol = KDAV::ProtocolInfo::protocolByName(split.at(0));
            if (!Settings::self()->urlConfiguration(protocol, split.at(1))) {
                auto *urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = split.at(1);
                if (dlg->useDefaultCredentials()) {
                    urlConfig->mUser = QStringLiteral("$default$");
                } else {
                    urlConfig->mUser = dlg->username();
                    urlConfig->mPassword = dlg->password();
                }
                urlConfig->mProtocol = protocol;

                Settings::self()->newUrlConfiguration(urlConfig);

                addModelRow(Utils::translatedProtocolName(protocol), split.at(1));
                mAddedUrls << QPair<QString, KDAV::Protocol>(split.at(1), protocol);
                checkUserInput();
            }
        }
```

#### AUTO 


```{c}
auto meta = static_cast<KIMAP::GetMetaDataJob *>(job);
```

#### AUTO 


```{c}
const auto &dt
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &memberUrl : lstMemberUrl) {
        Kolab::RelationMember member = Kolab::parseMemberUrl(memberUrl);
        const Akonadi::Item i = extractMember(member);
        // TODO implement fallback to search if uid is not available
        if (!i.remoteId().isEmpty() || !i.gid().isEmpty()) {
            members << i;
        } else {
            qCWarning(KOLABRESOURCE_LOG) << "Failed to parse member: " << memberUrl;
        }
    }
```

#### AUTO 


```{c}
const auto listJobChangedItems{listJob->changedItems()};
```

#### AUTO 


```{c}
auto attr = item.attribute<Akonadi::Pop3ResourceAttribute>(Akonadi::Item::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        //const EwsItem &ewsItem = resp.item();

        // TODO: Implement

        ++it;
    }
```

#### AUTO 


```{c}
auto listJob = new ListJob(mPopSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : jobs) {
            removeSubjob(job);
            job->kill();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsFolder &folder : std::as_const(mFolders)) {
        auto item = new QStandardItem(folder[EwsFolderFieldDisplayName].toString());
        item->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);
        item->setCheckable(true);
        auto id = folder[EwsFolderFieldFolderId].value<EwsId>();
        item->setData(id.id(), ItemIdRole);
        if (mSubscribedIds.contains(EwsId(id.id()))) {
            item->setCheckState(Qt::Checked);
        }
        auto parentId = folder[EwsFolderFieldParentFolderId].value<EwsId>();
        if (parentId.type() != EwsId::Unspecified) {
            QStandardItem *parentItem = mFolderItemHash.value(parentId.id());
            if (parentItem) {
                parentItem->appendRow(item);
            }
        }
        mFolderItemHash.insert(id.id(), item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &childCollection : list) {
                QVERIFY(thirdLevelNames.contains(childCollection.name()));
            }
```

#### AUTO 


```{c}
auto *imapQuotaAttribute = m_collection.attribute<Akonadi::ImapQuotaAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto job = new ContactsGroupDeleteJob(collection.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto fetchJob = new Akonadi::ItemFetchJob(Akonadi::Item::List() << relation.left() << relation.right());
```

#### AUTO 


```{c}
auto refreshReply = qobject_cast<QNetworkReply *>(sender());
```

#### AUTO 


```{c}
auto *moveJob = qobject_cast<FileStore::ItemMoveJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &collection : std::as_const(collections)) {
        QVERIFY(!collection.remoteId().isEmpty());
        QCOMPARE(collection.remoteId(), collection.name());
        QCOMPARE(collection.contentMimeTypes(), QStringList() << Collection::mimeType() << KMime::Message::mimeType());

        QCOMPARE(collection.rights(),
                 Collection::CanCreateItem | Collection::CanChangeItem | Collection::CanDeleteItem | Collection::CanCreateCollection
                     | Collection::CanChangeCollection | Collection::CanDeleteCollection);

        if (firstLevelNames.contains(collection.name())) {
            QCOMPARE(collection.parentCollection(), mStore->topLevelCollection());
        } else if (secondLevelNames.contains(collection.name())) {
            QVERIFY(firstLevelNames.contains(collection.parentCollection().name()));
            QCOMPARE(collection.parentCollection().parentCollection(), mStore->topLevelCollection());
        } else if (thirdLevelNames.contains(collection.name())) {
            QVERIFY(secondLevelNames.contains(collection.parentCollection().name()));
            QCOMPARE(collection.parentCollection().parentCollection().parentCollection(), mStore->topLevelCollection());
        }
    }
```

#### AUTO 


```{c}
auto *job = new Akonadi::ItemFetchJob(m_collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsFolder &folder : std::as_const(mFolders)) {
        folder.write(writer);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Attachment::Ptr &a : attachments) {
        mAttachments.push_back(a);
    }
```

#### AUTO 


```{c}
const auto &abv
```

#### AUTO 


```{c}
auto job = new LogoutJob(identifier(), this);
```

#### AUTO 


```{c}
auto *meta = new KIMAP::GetMetaDataJob(mSession);
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemFetchJob(davItem);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &day : days) {
        auto dowIndex = decodeEnumString<short>(day, dayOfWeekNames, dayOfWeekNameCount, &ok);
        if (reader.error() != QXmlStreamReader::NoError || !ok) {
            qCWarning(EWSCLI_LOG) << QStringLiteral("Failed to read EWS request - invalid %1 element (value: %2).")
                .arg(QStringLiteral("DaysOfWeek").arg(day));
            return false;
        }
        if (dowIndex == 7) { // "Day"
            dow.fill(true, 0, 7);
        } else if (dowIndex == 8) { // "Weekday"
            dow.fill(true, 0, 5);
        } else if (dowIndex == 9) { // "WeekendDay"
            dow.fill(true, 5, 7);
        } else {
            dow.setBit(dowIndex);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
        /* Retrieve the folder descriptor for this collection. Note that a new descriptor will be
         * created if it does not yet exist. */
        FolderDescr &fd = mFolderHash[col.remoteId()];
        fd.collection = col;
        if (!fd.flags) {
            /* This collection has just been created and this means that it's a parent collection
             * added in response to a created folder. Since the collection is here just for reference
             * it will not be processed by processRemoteFolders() and can be marked accordingly. */
            fd.flags |= FolderDescr::Processed;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &status) {
        if (status == QLatin1String("maybe")) {
            return KCalCore::Attendee::Tentative;
        } else if (status == QLatin1String("attending")) {
            return KCalCore::Attendee::Accepted;
        } else if (status == QLatin1String("declined")) {
            return KCalCore::Attendee::Declined;
        } else {
            return KCalCore::Attendee::NeedsAction;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {readFile();}
```

#### AUTO 


```{c}
const auto &it
```

#### AUTO 


```{c}
const auto mb = mItem.payload<KMime::Message::Ptr>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item) {
                return item.isValid() && (!item.hasPayload<T>() || item.mimeType() != mimeType());
            }
```

#### AUTO 


```{c}
auto *fullListJob = new KIMAP::ListJob(session);
```

#### AUTO 


```{c}
auto *createJob = qobject_cast<OXA::ObjectCreateJob *>(job);
```

#### AUTO 


```{c}
auto aclAttribute = m_collection.attribute<Akonadi::ImapAclAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            QListWidgetItem *item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }
```

#### AUTO 


```{c}
auto *attribute = mResourceCollection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto task = new ExpungeCollectionTask(state);
```

#### AUTO 


```{c}
const auto aclAttribute = col.attribute<Akonadi::ImapAclAttribute>();
```

#### AUTO 


```{c}
auto currentNextUid = col.attribute<UidNextAttribute>()
```

#### AUTO 


```{c}
auto job = new ItemFetchJob(item, this);
```

#### AUTO 


```{c}
const auto dispatchModeAttribute = item.attribute<DispatchModeAttribute>();
```

#### LAMBDA EXPRESSION 


```{c}
[&oAuth, &events, map]() {
        events.append(QStringLiteral("RequestWalletMap"));
        oAuth.walletMapRequestFinished(map);
    }
```

#### AUTO 


```{c}
auto subscribe = new KIMAP::SubscribeJob(rename->session());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Event &event : events) {
        KCalendarCore::Event::Ptr kcalEvent = Conversion::toKCalendarCore(event);
        kcalEvent->setCreated(QDateTime::currentDateTimeUtc()); // sets dtstamp
        calendar->addEvent(kcalEvent);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&callbackCalled](const QString &, QXmlResultItems &, const QXmlNamePool &) {
                                                          callbackCalled = true;
                                                          return FakeEwsServer::EmptyResponse;
                                                      }
```

#### LAMBDA EXPRESSION 


```{c}
[this, rootCollection](KGAPI2::Job *job) {
        if (!m_iface->handleError(job)) {
            return;
        }
        qCDebug(GOOGLE_CALENDAR_LOG) << "Calendars retrieved";

        const ObjectsList calendars = qobject_cast<CalendarFetchJob *>(job)->items();
        Collection::List collections;
        collections.reserve(calendars.count());
        const QStringList activeCalendars = m_settings->calendars();
        for (const auto &object : calendars) {
            const CalendarPtr &calendar = object.dynamicCast<Calendar>();
            qCDebug(GOOGLE_CALENDAR_LOG) << " -" << calendar->title() << "(" << calendar->uid() << ")";
            if (!activeCalendars.contains(calendar->uid())) {
                qCDebug(GOOGLE_CALENDAR_LOG) << "Skipping, not subscribed";
                continue;
            }
            Collection collection;
            setupCollection(collection, calendar);
            collection.setParentCollection(rootCollection);
            collections << collection;
        }

        m_iface->collectionsRetrievedFromHandler(collections);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Event &event : list) {
            qDebug() << QTest::toString(event.start()) << QTest::toString(event.end());
        }
```

#### AUTO 


```{c}
auto *job = new KIMAP::SetMetaDataJob(m_session);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &item : items) {
        itemStrs.append(QString::fromLatin1(item));
    }
```

#### AUTO 


```{c}
auto id = ewsItem[EwsItemFieldItemId].value<EwsId>();
```

#### AUTO 


```{c}
auto it = propertyHash.cbegin(), end = propertyHash.cend();
```

#### AUTO 


```{c}
auto job = new EventCreateJob(event, collection.remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto job = new Akonadi::ItemFetchJob(item, this);
```

#### AUTO 


```{c}
auto agentCreateJob = new AgentInstanceCreateJob(maildirType);
```

#### AUTO 


```{c}
const auto &event
```

#### AUTO 


```{c}
auto job = new EwsFetchItemsJob(collection, mEwsClient, mSyncState.value(rid), mItemsToCheck.value(rid), mTagStore, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<Row> &r : std::as_const(mMigrators)) {
        if (row == *r) {
            return pos;
        }
        pos++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : lstKeys) {
            if (!mailbox.isEmpty() && !isNamespaceFolder(mailbox, resourceState()->userNamespaces() + resourceState()->sharedNamespaces())) {
                mailboxes << mailbox;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::SearchTerm &subterm : lstSearchTermsList) {
            const KIMAP::Term newTerm = recursiveEmailTermMapping(subterm);
            if (!newTerm.isNull()) {
                subterms << newTerm;
            }
        }
```

#### AUTO 


```{c}
auto job = new FileStore::CollectionModifyJob(collection, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : std::as_const(mItems)) {
            mItemHash.insert(item.elmName, item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        qDebug() << "Verifying response" << i++;
        QCOMPARE(resp.responseClass(), *respClassesIt);
        if (resp.isSuccess()) {
            auto id = resp.item()[EwsItemFieldItemId].value<EwsId>();
            QCOMPARE(id, *idsIt);
        }
        idsIt++;
        respClassesIt++;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QNetworkCookie &cookie) {
            if (cookie.domain() == QLatin1String(".facebook.com")) {
                mCookies.insert(cookie.name(), cookie.toRawForm());
            }
        }
```

#### AUTO 


```{c}
auto *textToSpeakLayout = new QHBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                postJobResult(job);
            }
```

#### AUTO 


```{c}
auto session = static_cast<KIMAP::Session *>(sender());
```

#### AUTO 


```{c}
auto *treeContainerLayout = new QHBoxLayout(treeContainer);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        QHash< Akonadi::Collection, QList<Akonadi::Item::Id> >::iterator end(mNewMails.end());
        for (QHash< Akonadi::Collection, QList<Akonadi::Item::Id> >::iterator it = mNewMails.begin(); it != end; ++it) {
            QList<Akonadi::Item::Id> idList = it.value();
            if (idList.contains(item.id()) && addedFlags.contains("\\SEEN")) {
                idList.removeAll(item.id());
                if (idList.isEmpty()) {
                    mNewMails.remove(it.key());
                    break;
                } else {
                    (*it) = idList;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto mainWidget = new QWidget(dlg);
```

#### LAMBDA EXPRESSION 


```{c}
[this, job, account, instances](KJob *) {
        if (job->error()) {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: Failed to create new Google Groupware Resource:" << job->errorString();
            Q_EMIT message(Error, i18n("Failed to create a new Google Groupware Resource: %1", job->errorString()));
            setMigrationState(MigratorBase::Failed);
            return;
        }

        const auto newInstance = job->instance();
        if (!migrateAccount(account, instances, newInstance)) {
            qCWarning(MIGRATION_LOG) << "GoogleResourceMigrator: failed to migrate account" << account;
            Q_EMIT message(Error, i18n("Failed to migrate account %1", account));
            setMigrationState(MigratorBase::Failed);
            return;
        }

        removeLegacyInstances(account, instances);

        // Reconfigure and restart the new instance
        newInstance.reconfigure();
        newInstance.restart();

        if (instances.calendarResource.isValid() ^ instances.contactResource.isValid()) {
            const auto res = instances.calendarResource.isValid()
                             ? instances.calendarResource.identifier()
                             : instances.contactResource.identifier();
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from" << res
                                  << "to" << newInstance.identifier();
        } else {
            qCInfo(MIGRATION_LOG) << "GoogleResourceMigrator: migrated configuration from"
                                  << instances.calendarResource.identifier() << "and"
                                  << instances.contactResource.identifier() << "to"
                                  << newInstance.identifier();
        }
        Q_EMIT message(Success, i18n("Migrated account %1 to new Google Groupware Resource", account));

        ++mMigrationsDone;
        migrateNextAccount();
    }
```

#### AUTO 


```{c}
auto req = qobject_cast<EwsGetFolderRequest *>(job);
```

#### AUTO 


```{c}
auto fetchColJob = qobject_cast<CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : entryList) {
        Item item;
        item.setMimeType(KMime::Message::mimeType());
        item.setRemoteId(entry);
        item.setParentCollection(collection);

        if (md->hasIndexData()) {
            const KMIndexDataPtr indexData = md->indexData(entry);
            if (indexData != nullptr && !indexData->isEmpty()) {
                item.setFlags(indexData->status().statusFlags());

                const quint64 uid = indexData->uid();
                if (uid != 0) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has UID" << uid;
                    uidHash.insert(item.remoteId(), QString::number(uid));
                }

                const QStringList tagList = indexData->tagList();
                if (!tagList.isEmpty()) {
                    qCDebug(MIXEDMAILDIRRESOURCE_LOG) << "item" << item.remoteId() << "has"
                                                      << tagList.count() << "tags:" << tagList;
                    tagListHash.insert(item.remoteId(), tagList);
                }
            }
        }
        const Akonadi::Item::Flags flags = md->maildir().readEntryFlags(entry);
        for (const Akonadi::Item::Flag &flag : flags) {
            item.setFlag(flag);
        }

        items << item;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : std::as_const(list)) {
        // We have to filter the list by time
        if (event->dtEnd() >= s && e >= event->dtStart()) {
            eventlist.push_back(Kolab::Conversion::fromKCalendarCore(*event));
        }
    }
```

#### AUTO 


```{c}
auto job = new TaskListFetchJob(m_account, this);
```

#### AUTO 


```{c}
auto *moveJob = qobject_cast<OXA::FolderMoveJob *>(job);
```

#### AUTO 


```{c}
const auto locationIt = place.constFind(QLatin1String("location"));
```

#### AUTO 


```{c}
auto *searchJob = new KIMAP::SearchJob(session);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        const auto socket = mRedirectServer.nextPendingConnection();
        if (socket) {
            connect(socket, &QIODevice::readyRead, this, [this, socket]() {
                const auto response = QStringLiteral(
                                          "HTTP/1.1 200 OK\n\n<!DOCTYPE html>\n<html><body><p>You will be redirected "
                                          "shortly.</p><script>window.location.href=\"%1\";</script></body></html>\n")
                                          .arg(mPKeyAuthSubmitUrl);
                socket->write(response.toLocal8Bit());
            });
            connect(socket, &QIODevice::bytesWritten, this, [socket]() {
                socket->deleteLater();
            });
        }
    }
```

#### AUTO 


```{c}
const auto reqChanges{req->changes()};
```

#### AUTO 


```{c}
const auto &ns
```

#### AUTO 


```{c}
auto *search = new KIMAP::SearchJob(select->session());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item) { itemRemoved(item); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pair : pairs) {
                const QStringList entry = pair.split(QLatin1Char('='), QString::KeepEmptyParts);
                mObjectsMap.insert(entry.at(0).toLongLong(), entry.at(1).toULongLong());
            }
```

#### AUTO 


```{c}
auto it = mTagData.find(tag.gid());
```

#### RANGE FOR STATEMENT 


```{c}
for (const KContacts::ContactGroup::ContactReference &ref : qAsConst(toAdd)) {
            contactGroup.append(ref);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
        qWarning() << "Timeout waiting for desired resource online state.";
        loop.exit(1);
    }
```

#### AUTO 


```{c}
auto job = new TaskListCreateJob(taskList, m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
const auto bydays{rrule.byday()};
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDAV::DavUrl &url : lstUrls) {
        QUrl displayUrl = url.url();
        displayUrl.setUserInfo(QString());
        addModelRow(Utils::translatedProtocolName(url.protocol()), displayUrl.toDisplayString());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const IncidencePtr &incidence : std::as_const(incidences)) {
            if (incidence->hasRecurrenceId()) {
                qCDebug(DAVRESOURCE_LOG) << "Exception found with ID" << incidence->instanceIdentifier();
                exceptions << incidence;
            } else {
                mainIncidence = incidence;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        const QFileInfo sourceFileInfo(sourceDir, file);
        const QFileInfo targetFileInfo(targetDir, file);
        if (!copyFile(sourceFileInfo.absoluteFilePath(), targetFileInfo.absoluteFilePath())) {
            qCritical() << "Failed to copy" << sourceFileInfo.absoluteFilePath() << "to" << targetFileInfo.absoluteFilePath();
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &instance]() {
                            qCDebug(MIGRATION_LOG) << "GoogleResourceMigrator: resource" << instance.identifier() << "has disappeared from DBus";
                            loop.quit();
                         }
```

#### AUTO 


```{c}
auto uidListJob = new UIDListJob(mPopSession);
```

#### AUTO 


```{c}
const auto placeEnd = place.constEnd();
```

#### AUTO 


```{c}
auto *attr = mRootCollection.attribute<Akonadi::EntityDisplayAttribute>(Akonadi::Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
        const QFileInfo sourceFileInfo(sourceDir, file);
        const QFileInfo targetFileInfo(targetDir, file);
        if (!copyFile(sourceFileInfo.absoluteFilePath(), targetFileInfo.absoluteFilePath())) {
            qCritical() << "Failed to copy" << sourceFileInfo.absoluteFilePath()
                        << "to" << targetFileInfo.absoluteFilePath();
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Collection &col : collections) {
        map.insert(col.remoteId(), col);
    }
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsCreateItemJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : taskLists) {
            const TaskListPtr &taskList = object.dynamicCast<TaskList>();
            qCDebug(GOOGLE_TASKS_LOG) << " -" << taskList->title() << "(" << taskList->uid() << ")";

            if (!activeTaskLists.contains(taskList->uid())) {
                qCDebug(GOOGLE_TASKS_LOG) << "Skipping, not subscribed";
                continue;
            }

            Collection collection;
            setupCollection(collection, taskList);
            collection.setParentCollection(rootCollection);
            collections << collection;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &) {
        authFinished = true;
        loop.exit(0);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : std::as_const(entryList)) {
        // TODO: Use cache policy to see what actually has to been set as payload.
        //       Currently most views need a minimal amount of information so the
        //       Items get Envelopes as payload.
        auto mail = new KMime::Message();
        mail->setHead(KMime::CRLFtoLF(mMBox->readMessageHeaders(entry)));
        mail->parse();

        Item item;
        item.setRemoteId(colId + QLatin1String("::") + colRid + QLatin1String("::") + QString::number(entry.messageOffset()));
        item.setMimeType(QStringLiteral("message/rfc822"));
        item.setSize(entry.messageSize());
        item.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, item);
        Q_EMIT percent(count++ / entryListSize);
        items << item;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        processNextItem();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::Address &address : addresses) {
            addressee.insertCustom(QStringLiteral("KADDRESSBOOK"), QStringLiteral("X-Office"), fromStdString(address.label())); // TODO support proper addresses
        }
```

#### AUTO 


```{c}
auto idJob = qobject_cast<KIMAP::IdJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &accountName : accountNames) {
        m_accounts[accountName] = findAccountInWallet(accountName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() {
            qWarning() << "Timeout waiting for desired resource online state.";
            loop.exit(1);
        }
```

#### AUTO 


```{c}
auto task = new KolabAddTagTask(createResourceState(TaskArguments(tag)), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sf : lstMaildir) {
            const Maildir subMd = Maildir(path() + QLatin1Char('/') + sf);
            if (!subMd.isValid()) {
                d->lastError = subMd.lastError();
                return false;
            }
        }
```

#### AUTO 


```{c}
auto attr = newCollection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### LAMBDA EXPRESSION 


```{c}
[this, tokenJob, url]() {
                if (tokenJob->error()) {
                    emitError(tokenJob->errorText());
                    return;
                }

                QUrl url_ = url;
                QUrlQuery query(url);

                query.removeQueryItem(QStringLiteral("access_token"));
                query.addQueryItem(QStringLiteral("access_token"), tokenJob->token());
                url_.setQuery(query);
                sendRequest(url_);
            }
```

#### AUTO 


```{c}
auto attr = new Akonadi::EntityDisplayAttribute;
```

#### AUTO 


```{c}
auto job = new GetTokenJob(mResource);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job){
        auto queryJob = qobject_cast<FreeBusyQueryJob *>(job);
        if (!m_iface->handleError(job, false)) {
            m_iface->handlesFreeBusy(queryJob->id(), false);
            return;
        }
        m_iface->handlesFreeBusy(queryJob->id(), true);
    }
```

#### AUTO 


```{c}
auto it = contacts.constFind(contactId);
```

#### LAMBDA EXPRESSION 


```{c}
[](QKeychain::Job *baseJob) {
        if (baseJob->error()) {
            qCWarning(POP3RESOURCE_LOG) << "Error writing password using QKeychain:" << baseJob->errorString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dt : rDateTimes) {
        rdates.push_back(fromDate(dt, e.allDay()));
    }
```

#### AUTO 


```{c}
const auto it
```

#### AUTO 


```{c}
auto job = new CollectionFetchJob(c, CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto job = new FileStore::ItemMoveJob(item, targetParent, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxPtr &mbox : std::as_const(mMBoxes)) {
        if (mbox->mCollection.isValid()) {
            MBoxPtr updatedMBox = mbox;
            updatedMBox->mCollection = updateMBoxCollectionTree(mbox->mCollection, moveCollection, movedCollection);
        }
    }
```

#### AUTO 


```{c}
auto job = new FreeBusyQueryJob(email,
                                    QDateTime::currentDateTimeUtc(),
                                    QDateTime::currentDateTimeUtc().addSecs(3600),
                                    m_settings->accountPtr(),
                                    this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KGAPI2::Job *job) {
        if (!handleError(job) || !m_account) {
            m_ui->calendarsBox->setEnabled(false);
            return;
        }

        const ObjectsList objects = qobject_cast<FetchJob *>(job)->items();

        QStringList activeCalendars;
        if (m_account->accountName() == m_settings->account()) {
            activeCalendars = m_settings->calendars();
        }
        m_ui->calendarsList->clear();
        for (const ObjectPtr &object : objects) {
            const CalendarPtr calendar = object.dynamicCast<Calendar>();

            auto item = new QListWidgetItem(calendar->title());
            item->setData(Qt::UserRole, calendar->uid());
            item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            item->setCheckState((activeCalendars.isEmpty() || activeCalendars.contains(calendar->uid())) ? Qt::Checked : Qt::Unchecked);
            m_ui->calendarsList->addItem(item);
        }

        m_ui->calendarsBox->setEnabled(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](EwsUpdateItemRequest::ItemChange::List::const_iterator firstChange, EwsUpdateItemRequest::ItemChange::List::const_iterator lastChange) {
            auto req = new EwsUpdateItemRequest(mClient, this);
            req->addItemChanges(firstChange, lastChange);
            return req;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &attendee : attendees) {
        attendee->setUid(attendee->email());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ReminderPtr &reminder : qAsConst(m_reminders)) {
        KCalendarCore::Alarm::Ptr alarm(new KCalendarCore::Alarm(incidence));

        alarm->setType(reminder->type());
        alarm->setTime(incidence->dtStart());
        alarm->setStartOffset(reminder->startOffset());
        alarm->setEnabled(true);

        alarms << alarm;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventFile &data : std::as_const(mEvents)) {
            const KAEvent &event = data.event;
            mCompatibility |= event.compatibility();
            if ((mCompatibility & AllCompat) == AllCompat) {
                break;
            }
        }
```

#### AUTO 


```{c}
auto button = new QRadioButton(i18n("Use one of those servers:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        const EwsItem &ewsItem = resp.item();
        KMime::Message::Ptr msg(new KMime::Message);

        // Rebuild the message headers
        QVariant v = ewsItem[EwsItemFieldSubject];
        if (Q_LIKELY(v.isValid())) {
            msg->subject()->fromUnicodeString(v.toString(), "utf-8");
        }

        v = ewsItem[EwsItemFieldFrom];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox mbox = v.value<EwsMailbox>();
            msg->from()->addAddress(mbox);
        }

        v = ewsItem[EwsItemFieldToRecipients];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            Q_FOREACH (const EwsMailbox &mbox, mboxList) {
                msg->to()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldCcRecipients];
        if (Q_LIKELY(v.isValid())) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->cc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldBccRecipients];
        if (v.isValid()) {
            const EwsMailbox::List mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->bcc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldInternetMessageId];
        if (v.isValid()) {
            msg->messageID()->from7BitString(v.toString().toAscii());
        }

        v = ewsItem[EwsItemFieldInReplyTo];
        if (v.isValid()) {
            msg->inReplyTo()->from7BitString(v.toString().toAscii());
        }

        v = ewsItem[EwsItemFieldDateTimeReceived];
        if (v.isValid()) {
            msg->date()->setDateTime(v.toDateTime());
        }

        v = ewsItem[EwsItemFieldReferences];
        if (v.isValid()) {
            msg->references()->from7BitString(v.toString().toAscii());
        }

        v = ewsItem[EwsItemFieldReplyTo];
        if (v.isValid()) {
            const EwsMailbox mbox = v.value<EwsMailbox>();
            msg->replyTo()->addAddress(mbox);
        }

        msg->assemble();
        item.setPayload(KMime::Message::Ptr(msg));

        v = ewsItem[EwsItemFieldSize];
        if (v.isValid()) {
            item.setSize(v.toUInt());
        }

        // Workaround for Akonadi bug
        // When setting flags, adding each of them separately vs. setting a list in one go makes
        // a difference. In the former case the item treats this as an incremental change and
        // records flags added and removed. In the latter it sets a flag indicating that flags were
        // reset.
        // For some strange reason Akonadi is not seeing the flags in the latter case.
        Q_FOREACH (const QByteArray &flag, EwsMailHandler::readFlags(ewsItem)) {
            item.setFlag(flag);
        }
        qCDebugNC(EWSRES_LOG) << "EwsFetchMailDetailJob::processItems:" << ewsHash(item.remoteId()) << item.flags();

        ++it;
    }
```

#### AUTO 


```{c}
auto job = new CollectionDeleteJob(collection);
```

#### RANGE FOR STATEMENT 


```{c}
for (int request : qAsConst(m_pendingRequests)) {
            Q_EMIT sessionRequestDone(request, nullptr,
                                      LoginFailError, i18n("Disconnected from server during login."));
        }
```

#### AUTO 


```{c}
auto treeView = new QTreeView(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
                    const TaskListPtr taskList = object.dynamicCast<TaskList>();

                    QListWidgetItem *item = new QListWidgetItem(taskList->title());
                    item->setData(Qt::UserRole, taskList->uid());
                    item->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
                    item->setCheckState((activeTaskLists.isEmpty() || activeTaskLists.contains(taskList->uid())) ? Qt::Checked : Qt::Unchecked);
                    m_ui->taskListsList->addItem(item);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : items) {
        ids << EwsId(item.remoteId(), item.remoteRevision());
    }
```

#### AUTO 


```{c}
auto *collectionCreateJob = qobject_cast<CollectionCreateJob *>(job);
```

#### AUTO 


```{c}
auto item = new QStandardItem(QIcon::fromTheme(QStringLiteral("dialog-ok")), msg);
```

#### AUTO 


```{c}
const auto reauthPrompt = mAuth->reauthPrompt();
```

#### AUTO 


```{c}
auto job = new Akonadi::ContactSearchJob(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, &collection](const Item &item){
                ContactPtr contact(new Contact(item.payload<KContacts::Addressee>()));
                contact->addGroup(collection.remoteId());
                return contact;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : queriedItems) {
        const QString remoteId = item.remoteId();
        const Akonadi::Item::Id contactId = remoteId.mid(1).toLongLong();
        auto it = contacts.constFind(contactId);
        if (it == contacts.constEnd()) {
            cancelTask();
            return;
        }
        auto &contact = *it;

        KCalendarCore::Incidence::Ptr ev;
        if (remoteId.startsWith(QLatin1Char('b'))) {
            ev = createBirthday(contact, contactId);
        } else if (remoteId.startsWith(QLatin1Char('a'))) {
            ev = createAnniversary(contact, contactId);
        }
        if (!ev) {
            cancelTask();
            return;
        }

        Item i(item);
        i.setPayload<Incidence::Ptr>(ev);
        resultItems.append(i);
    }
```

#### AUTO 


```{c}
auto davJob = qobject_cast<KDAV::DavCollectionsFetchJob *>(job);
```

#### AUTO 


```{c}
const auto keyval = token.trimmed().split('=');
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : l) {
        ba += QByteArray::number(i) + ", ";
    }
```

#### AUTO 


```{c}
auto req = new EwsUpdateItemRequest(mClient, this);
```

#### AUTO 


```{c}
auto *req = qobject_cast<EwsCreateFolderRequest *>(job);
```

#### AUTO 


```{c}
const auto isCanceled = data.constFind(QLatin1String("is_canceled"));
```

#### RANGE FOR STATEMENT 


```{c}
for (KIMAP::Session *s : session) {
        killSession(s, termination);
    }
```

#### AUTO 


```{c}
auto job = new EwsModifyItemFlagsJob(mEwsClient, this, items, addedFlags, removedFlags);
```

#### RANGE FOR STATEMENT 


```{c}
for (const MBoxEntry &entry : entryList2) {
        entrySet2 << entry.messageOffset();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &entry : std::as_const(randomList1)) {
        Item item1;
        item1.setId(KRandom::random());
        item1.setRemoteId(QString::number(entry.messageOffset()));
        item1.setParentCollection(collection1);

        job = mStore->fetchItem(item1);
        job->fetchScope().fetchPayloadPart(MessagePart::Header);

        spy = new QSignalSpy(job, &FileStore::ItemFetchJob::itemsReceived);

        QVERIFY(job->exec());
        QCOMPARE(job->error(), 0);

        items = job->items();
        QCOMPARE((int)items.count(), 1);
        QCOMPARE(itemsFromSpy(spy), items);

        Item item = items.first();
        QCOMPARE(item, item1);
        QVERIFY(item.hasPayload<KMime::Message::Ptr>());

        KMime::Message::Ptr msgPtr = item.payload<KMime::Message::Ptr>();
        QVERIFY(msgPtr != 0);

        const QSet<QByteArray> parts = messageParts(msgPtr);
        QVERIFY(!parts.isEmpty());
        QVERIFY(parts.contains(MessagePart::Header));
        QVERIFY(!parts.contains(MessagePart::Body));
    }
```

#### AUTO 


```{c}
auto job = new EventDeleteJob(eventIds, items.first().parentCollection().remoteId(), m_settings->accountPtr(), this);
```

#### AUTO 


```{c}
auto howIsItWork = new QLabel(i18n("<a href=\"whatsthis\">How does this work?</a>"), parent);
```

#### AUTO 


```{c}
auto *attr = new DefaultReminderAttribute();
```

#### AUTO 


```{c}
auto attr = col.attribute<Akonadi::CollectionAnnotationsAttribute>(Akonadi::Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto attr = collection.attribute<Akonadi::NewMailNotifierAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Tag &tag : qAsConst(mCreatedTags)) {
            mItem.setTag(tag);
        }
```

#### AUTO 


```{c}
auto *job = new SpecialMailCollectionsRequestJob(this);
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyItemDownloadJob*>(kjob);
```

#### AUTO 


```{c}
auto attr = otherCollection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionsMultiFetchJob(Settings::self()->configuredDavUrls());
```

#### RANGE FOR STATEMENT 


```{c}
for (qint64 id : results) {
            mOldUids.add(id);
        }
```

#### AUTO 


```{c}
const auto reauthStatus = performAuthAction(oAuth, 2000, [](EwsOAuth *oAuth) {
        return oAuth->authenticate(false);
    });
```

#### AUTO 


```{c}
auto *fetch = qobject_cast<KIMAP::FetchJob *>(sender());
```

#### AUTO 


```{c}
auto it = mFolderHash.begin(), end = mFolderHash.end();
```

#### AUTO 


```{c}
auto acc = KGAPI2::AccountPtr::create(mResource->settings()->userName(),
                                          QString(), QString(),
                                          QList<QUrl>{ QUrl(QStringLiteral("https://mail.google.com/")) });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &part : parts) {
        if (part.startsWith("PLD:RFC822")) {
            bodyChanged = true;
        } else if (part.startsWith("PLD:HEAD")) {
            headChanged = true;
        }
        if (part.contains("FLAGS")) {
            flagsChanged = true;
        }
    }
```

#### AUTO 


```{c}
auto *job = new FileStore::ItemCreateJob(item, collection, d->mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EventPtr &event : qAsConst(recurrentEvents)) {

            Item item;
            item.setRemoteId(event->uid());
            item.setRemoteRevision(event->etag());
            item.setPayload< KCalCore::Event::Ptr >(event.dynamicCast<KCalCore::Event>());
            item.setMimeType(KCalCore::Event::eventMimeType());
            item.setParentCollection(collection);

            changedItems << item;
        }
```

#### AUTO 


```{c}
auto fetch = new Akonadi::CollectionFetchJob(collection, Akonadi::CollectionFetchJob::Base, this);
```

#### AUTO 


```{c}
auto *mimeTypeProxy = new Akonadi::CollectionFilterProxyModel(this);
```

#### AUTO 


```{c}
auto *job = qobject_cast<EwsPKeyAuthJob *>(j);
```

#### AUTO 


```{c}
auto *req = new EwsDeleteFolderRequest(mEwsClient, this);
```

#### AUTO 


```{c}
auto job = new KIMAP::SubscribeJob(session);
```

#### AUTO 


```{c}
auto *fetchJob = static_cast<Akonadi::CollectionFetchJob *>(job);
```

#### AUTO 


```{c}
auto *fetchJob = dynamic_cast<CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        const QByteArray data = md.readEntry(item.remoteId());
        KMime::Message *mail = new KMime::Message();
        mail->setContent(KMime::CRLFtoLF(data));
        mail->parse();

        Item i(item);
        i.setPayload(KMime::Message::Ptr(mail));
        Akonadi::MessageFlags::copyMessageFlags(*mail, i);
        rv.push_back(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMBox::MBoxEntry &entry : lstEntry) {
            if (entry.messageOffset() == offset) {
                return true;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : attachments) {
        QByteArray type;
        KMime::Content *content = Mime::findContentByName(mimeData, name, type);
        if (!content) { // guard against malformed events with non-existent attachments
            qCWarning(PIMKOLAB_LOG) <<"could not find attachment: "<< name.toUtf8() << type;
            continue;
        }
        const QByteArray c = content->decodedContent().toBase64();
        KCalendarCore::Attachment attachment(c, QString::fromLatin1(type));
        attachment.setLabel(name);
        incidence->addAttachment(attachment);
        qCDebug(PIMKOLAB_LOG) << "ATTACHMENT NAME" << name << type;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (ignoreStatusMail(item)) {
            continue;
        }

        if (excludeSpecialCollection(collectionSource)) {
            continue; // outbox, sent-mail, trash, drafts or templates.
        }

        if (mNewMails.contains(collectionSource)) {
            QList<Akonadi::Item::Id> idListFrom = mNewMails[collectionSource];
            const int removeItems = idListFrom.removeAll(item.id());
            if (removeItems > 0) {
                if (idListFrom.isEmpty()) {
                    mNewMails.remove(collectionSource);
                } else {
                    mNewMails[collectionSource] = idListFrom;
                }
                if (!excludeSpecialCollection(collectionDestination)) {
                    QList<Akonadi::Item::Id> idListTo = mNewMails[collectionDestination];
                    idListTo.append(item.id());
                    mNewMails[collectionDestination] = idListTo;
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto filterLineEdit = new QLineEdit(this);
```

#### AUTO 


```{c}
auto *job = new FoldersRequestJob(0, FoldersRequestJob::Modified, this);
```

#### AUTO 


```{c}
auto moveJob = qobject_cast<FileStore::CollectionMoveJob *>(job);
```

#### AUTO 


```{c}
const auto totalItems = mRemoteAddedItems.size() + mRemoteChangedItems.size() + mRemoteDeletedIds.size()
                                +mRemoteFlagChangedIds.size();
```

#### AUTO 


```{c}
auto job = new CollectionModifyJob(mCurrentUpdate.collection, mSession);
```

#### RANGE FOR STATEMENT 


```{c}
for (Akonadi::Item::Id contactId : std::as_const(contactIds)) {
        contactItems.append(Item(contactId));
    }
```

#### AUTO 


```{c}
auto *job = new AgentInstanceCreateJob(typeId, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KMime::Types::Mailbox &mbox : mb) {
        stream << mbox.name()
               << mbox.addrSpec().localPart
               << mbox.addrSpec().domain;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &strLine : strLines) {
            lines << strLine.trimmed().toUtf8();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &resultStr : results) {
            const QStringList split = resultStr.split(QLatin1Char('|'));
            KDAV::Protocol protocol = KDAV::ProtocolInfo::protocolByName(split.at(0));
            if (!Settings::self()->urlConfiguration(protocol, split.at(1))) {
                auto urlConfig = new Settings::UrlConfiguration();

                urlConfig->mUrl = split.at(1);
                if (dlg->useDefaultCredentials()) {
                    urlConfig->mUser = QStringLiteral("$default$");
                } else {
                    urlConfig->mUser = dlg->username();
                    urlConfig->mPassword = dlg->password();
                }
                urlConfig->mProtocol = protocol;

                Settings::self()->newUrlConfiguration(urlConfig);

                addModelRow(Utils::translatedProtocolName(protocol), split.at(1));
                mAddedUrls << QPair<QString, KDAV::Protocol>(split.at(1), protocol);
                checkUserInput();
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&callbackOk](const QString &, QXmlResultItems & ri, const QXmlNamePool &)
            {
                if (ri.hasError()) {
                    qDebug() << "XQuery result has errors.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlItem item = ri.next();
                if (item.isNull()) {
                    qDebug() << "XQuery result has no items.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (!item.isNode()) {
                    qDebug() << "XQuery result is not a XML node.";
                    return FakeEwsServer::EmptyResponse;
                }
                QXmlNodeModelIndex index = item.toNodeModelIndex();
                if (index.isNull()) {
                    qDebug() << "XQuery XML node is NULL.";
                    return FakeEwsServer::EmptyResponse;
                }
                if (index.model()->stringValue(index) != QStringLiteral("test")) {
                    qDebug() << "Unexpected item value:" << index.model()->stringValue(index);
                    return FakeEwsServer::EmptyResponse;
                }
                return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("<b/>"), 200);
            }
```

#### AUTO 


```{c}
auto fetchJob = new CollectionFetchJob(localFetchHash.values().toVector(), CollectionFetchJob::Base);
```

#### AUTO 


```{c}
auto *job = new EwsAkonadiTagsSyncJob(mTagStore,
                                                               mClient, qobject_cast<EwsResource *>(parent())->rootCollection(), this);
```

#### AUTO 


```{c}
auto *append = qobject_cast<KIMAP::AppendJob *>(job);
```

#### AUTO 


```{c}
auto resetButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto *urlConfig = new Settings::UrlConfiguration();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &serializedUrl : remoteUrlsLst) {
        auto urlConfig = new UrlConfiguration(serializedUrl);
        const QString key = urlConfig->mUrl + QLatin1Char(',') + KDAV::ProtocolInfo::protocolName(KDAV::Protocol(urlConfig->mProtocol));
        const QString pass = loadPassword(key, urlConfig->mUser);
        if (!pass.isNull()) {
            urlConfig->mPassword = pass;
            mUrls[key] = urlConfig;
        } else {
            delete urlConfig;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int streamingEventsHeartbeatIntervalSeconds = 5;
```

#### AUTO 


```{c}
const auto hasDomainReply = dBusSetAndWaitReply<bool>(std::bind(&OrgKdeAkonadiEwsSettingsInterface::setHasDomain, mEwsSettingsInterface.data(), false),
                                                          std::bind(&OrgKdeAkonadiEwsSettingsInterface::hasDomain, mEwsSettingsInterface.data()),
                                                          QStringLiteral("has domain"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const EwsGetItemRequest::Response &resp : responses) {
        Item &item = *it;

        if (!resp.isSuccess()) {
            qCWarningNC(EWSRES_LOG) << QStringLiteral("Failed to fetch item %1").arg(item.remoteId());
            continue;
        }

        const EwsItem &ewsItem = resp.item();
        KMime::Message::Ptr msg(new KMime::Message);

        // Rebuild the message headers
        QVariant v = ewsItem[EwsItemFieldSubject];
        if (Q_LIKELY(v.isValid())) {
            msg->subject()->fromUnicodeString(v.toString(), "utf-8");
        }

        v = ewsItem[EwsItemFieldFrom];
        if (Q_LIKELY(v.isValid())) {
            const auto mbox = v.value<EwsMailbox>();
            msg->from()->addAddress(mbox);
        }

        v = ewsItem[EwsItemFieldToRecipients];
        if (Q_LIKELY(v.isValid())) {
            const auto mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->to()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldCcRecipients];
        if (Q_LIKELY(v.isValid())) {
            const auto mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->cc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldBccRecipients];
        if (v.isValid()) {
            const auto mboxList = v.value<EwsMailbox::List>();
            for (const EwsMailbox &mbox : mboxList) {
                msg->bcc()->addAddress(mbox);
            }
        }

        v = ewsItem[EwsItemFieldInternetMessageId];
        if (v.isValid()) {
            msg->messageID()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldInReplyTo];
        if (v.isValid()) {
            msg->inReplyTo()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldDateTimeReceived];
        if (v.isValid()) {
            msg->date()->setDateTime(v.toDateTime());
        }

        v = ewsItem[EwsItemFieldReferences];
        if (v.isValid()) {
            msg->references()->from7BitString(v.toString().toLatin1());
        }

        v = ewsItem[EwsItemFieldReplyTo];
        if (v.isValid()) {
            const auto mbox = v.value<EwsMailbox>();
            msg->replyTo()->addAddress(mbox);
        }

        msg->assemble();
        item.setPayload(KMime::Message::Ptr(msg));

        v = ewsItem[EwsItemFieldSize];
        if (v.isValid()) {
            item.setSize(v.toUInt());
        }

        // Workaround for Akonadi bug
        // When setting flags, adding each of them separately vs. setting a list in one go makes
        // a difference. In the former case the item treats this as an incremental change and
        // records flags added and removed. In the latter it sets a flag indicating that flags were
        // reset.
        // For some strange reason Akonadi is not seeing the flags in the latter case.
        const auto flags{EwsMailHandler::readFlags(ewsItem)};
        for (const QByteArray &flag : flags) {
            item.setFlag(flag);
        }
        qCDebugNC(EWSRES_LOG) << "EwsFetchMailDetailJob::processItems:" << ewsHash(item.remoteId()) << item.flags();

        ++it;
    }
```

#### AUTO 


```{c}
auto session1 = sessionSpy.at(0).at(1).value<KIMAP::Session *>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Item &item : qAsConst(mItems)) {
        Q_FOREACH (const Tag &tag, item.tags()) {
            if (!mTagStore->containsId(tag.id())) {
                unknownTags.append(tag);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : qAsConst(keys)) {
        QString val = map[key].toString();
        val.replace(QLatin1Char('"'), QStringLiteral("\\\""));
        elems.append(QStringLiteral("\"%1\":\"%2\"").arg(key, val));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sub : lstDir) {
        Collection c;
        c.setName(sub);
        c.setRemoteId(sub);
        c.setParentCollection(root);
        c.setContentMimeTypes(mimeTypes);
        if (sub.compare(QLatin1String("inbox"), Qt::CaseInsensitive) == 0) {
            c.attribute<SpecialCollectionAttribute>(Collection::AddIfMissing)->setCollectionType("inbox");
        }

        const Maildir md = maildirForCollection(c);
        if (!md.isValid()) {
            continue;
        }

        list << c;
        list += listRecursive(c, md);
    }
```

#### AUTO 


```{c}
auto session = sessionSpy.at(0).at(1).value<KIMAP::Session *>();
```

#### AUTO 


```{c}
auto store = static_cast<KIMAP::StoreJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &resp : mChunkedJob.responses()) {
        if (!resp.isSuccess()) {
            setErrorText(i18nc("@info:status", "Item update failed: ") + resp.responseMessage());
            emitResult();
            return;
        }

        /* In general EWS guarantees that the order of response items will match the order of request items.
         * It is therefore safe to iterate these in parallel. */
        if (it->remoteId() == resp.itemId().id()) {
            it->setRemoteRevision(resp.itemId().changeKey());
            ++it;
        } else {
            setErrorText(i18nc("@info:status", "Item out of order while processing update item response."));
            emitResult();
            return;
        }
    }
```

#### AUTO 


```{c}
auto moveItemReq = new EwsMoveItemRequest(mClient, this);
```

#### AUTO 


```{c}
auto cal = KCalCore::MemoryCalendar::Ptr::create(KDateTime::LocalZone);
```

#### AUTO 


```{c}
auto it = incidences.constBegin();
```

#### AUTO 


```{c}
auto *job = new RetrieveItemsJob(col, mStore, this);
```

#### LAMBDA EXPRESSION 


```{c}
[&receivedReq](const QString &req, QXmlResultItems &, const QXmlNamePool &) {
        receivedReq = req;
        return FakeEwsServer::DialogEntry::HttpResponse(QStringLiteral("testresp"), 200);
    }
```

#### AUTO 


```{c}
const auto usernameReply = dBusSetAndWaitReply<QString>(
        std::bind(&OrgKdeAkonadiEwsSettingsInterface::setUsername, mEwsSettingsInterface.data(), username),
        std::bind(&OrgKdeAkonadiEwsSettingsInterface::username, mEwsSettingsInterface.data()),
        QStringLiteral("Username"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : taskLists) {
        const TaskListPtr &taskList = object.dynamicCast<TaskList>();

        if (!activeTaskLists.contains(taskList->uid())) {
            continue;
        }

        Collection collection;
        collection.setContentMimeTypes(QStringList() << KCalendarCore::Todo::todoMimeType());
        collection.setName(taskList->uid());
        collection.setParentCollection(m_rootCollection);
        collection.setRemoteId(taskList->uid());
        collection.setRights(Collection::CanChangeCollection
                             |Collection::CanCreateItem
                             |Collection::CanChangeItem
                             |Collection::CanDeleteItem);

        EntityDisplayAttribute *attr = collection.attribute<EntityDisplayAttribute>(Collection::AddIfMissing);
        attr->setDisplayName(taskList->title());
        attr->setIconName(QStringLiteral("view-pim-tasks"));

        m_collections[ collection.remoteId() ] = collection;
    }
```

#### AUTO 


```{c}
auto *groupboxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
const auto *aclAttribute = col.attribute<Akonadi::ImapAclAttribute>();
```

#### AUTO 


```{c}
auto item = new QStandardItem(folder[EwsFolderFieldDisplayName].toString());
```

#### AUTO 


```{c}
auto hLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto it = std::find_if(m_handlers.cbegin(), m_handlers.cend(),
            [&collection](const GenericHandler::Ptr &handler){
                return collection.contentMimeTypes().contains(handler->mimeType());
            });
```

#### AUTO 


```{c}
const auto config = settingsForResource(instance);
```

#### AUTO 


```{c}
const auto eAttendees{e.attendees()};
```

#### AUTO 


```{c}
auto job = new FreeBusyQueryJob(email, start, end, m_settings->accountPtr(), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &, const QString &p) {
                                            password = p;
                                            loop.exit(0);
                                            return true;
                                        }
```

#### AUTO 


```{c}
auto job = qobject_cast<TomboyServerAuthenticateJob*>(kjob);
```

#### AUTO 


```{c}
const auto parsedCookies = QNetworkCookie::parseCookies(tokenJob->cookies());
```

#### AUTO 


```{c}
auto meta = new KIMAP::GetMetaDataJob(session);
```

#### AUTO 


```{c}
auto *content = new KMime::Content();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &it : items) {
            tokens.insert(it.first, it.second);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &e : std::as_const(dict)) {
            entries.push_back(Conversion::toStdString(e));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &protocol : supportedProtocols) {
        Url url;

        if (protocol == QLatin1String("CalDav")) {
            url.protocol = KDAV::CalDav;
        } else if (protocol == QLatin1String("CardDav")) {
            url.protocol = KDAV::CardDav;
        } else if (protocol == QLatin1String("GroupDav")) {
            url.protocol = KDAV::GroupDav;
        } else {
            return urls;
        }

        QString urlStr = settingsToUrl(this, protocol);

        if (!urlStr.isEmpty()) {
            url.url = urlStr;
            url.userName = QStringLiteral("$default$");
            urls << url;
        }
    }
```

#### AUTO 


```{c}
const auto sentBehaviourAttribute = item.attribute<SentBehaviourAttribute>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &group : groups) {
            groupsMap[group] << item;
        }
```

#### AUTO 


```{c}
const auto flagAttr = collection.attribute<Akonadi::CollectionFlagsAttribute>();
```

#### AUTO 


```{c}
auto job = new ItemCreateJob(item, c);
```

#### AUTO 


```{c}
auto metadata = static_cast<RetrieveMetadataJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[&oAuth, &events, map]() {
            events.append(QStringLiteral("RequestWalletMap"));
            oAuth.walletMapRequestFinished(map);
        }
```

#### AUTO 


```{c}
auto job = new OXA::UpdateUsersJob(this);
```

#### AUTO 


```{c}
auto compactJob = qobject_cast<FileStore::StoreCompactJob *>(job);
```

#### AUTO 


```{c}
const auto mboxList = v.value<EwsMailbox::List>();
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceTask *task : qAsConst(m_taskList)) {
        delete task;
    }
```

#### AUTO 


```{c}
auto attribute = item.attribute<FileStore::EntityCompactChangeAttribute>();
```

#### AUTO 


```{c}
auto job = new KIMAP::CapabilitiesJob(session);
```

#### AUTO 


```{c}
auto *loginJob = new LoginJob(mPopSession);
```

#### LAMBDA EXPRESSION 


```{c}
[this, reqSetupFn, respGetFn, progressFn, resultFn, itemsToDo](KJob *job) {
        if (job->error()) {
            resultFn(false, job->errorString());
            return;
        }

        Req *req = qobject_cast<Req *>(job);
        if (!req) {
            resultFn(false, QStringLiteral("Incorrect request object type"));
            return;
        }

        auto responses = respGetFn(req);
        Q_ASSERT(responses.size() == itemsToDo);
        mResponses += responses;

        progressFn(mItemsDone * 100 / mItems.size());

        start(reqSetupFn, respGetFn, progressFn, resultFn);
    }
```

#### AUTO 


```{c}
const auto collections{fetchJob->collections()};
```

#### AUTO 


```{c}
const auto str = QString::fromUtf8(data.constData() + start, end - start);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : std::as_const(toplevelMailboxes)) {
            auto meta = new KIMAP::GetMetaDataJob(mSession);
            meta->setMailBox(mailbox + QLatin1String("*"));
            if (mServerCapabilities.contains(QLatin1String("METADATA"))) {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Metadata);
            } else {
                meta->setServerCapability(KIMAP::MetaDataJobBase::Annotatemore);
            }
            meta->setDepth(KIMAP::GetMetaDataJob::AllLevels);
            for (const QByteArray &requestedEntry : std::as_const(mRequestedMetadata)) {
                meta->addRequestedEntry(requestedEntry);
            }
            connect(meta, &KJob::result, this, &RetrieveMetadataJob::onGetMetaDataDone);
            mJobs++;
            meta->start();
        }
```

#### AUTO 


```{c}
auto job = new EwsSubscribedFoldersJob(mClient, mSettings, this);
```

#### AUTO 


```{c}
const auto transportResult
        = static_cast<TransportResourceBase::TransportResult>(result);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QNetworkCookie &cookie) {
                if (cookie.domain() == QLatin1String(".facebook.com")) {
                    mCookies.insert(cookie.name(), cookie.toRawForm());
                }
            }
```

#### AUTO 


```{c}
const auto contactAddresses{contact.addresses()};
```

#### AUTO 


```{c}
auto job = Graph::job(url);
```

#### AUTO 


```{c}
auto fetchJob = new CalendarFetchJob(m_account, this);
```

#### LAMBDA EXPRESSION 


```{c}
[reply, &resp]() {
        resp += QString::fromUtf8(reply->readAll());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QUrl &, QVariantMap &map){
        map[QStringLiteral("code")] = QUrl::toPercentEncoding(refreshToken);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kolab::ContactReference &contact : members) {
        QVERIFY(!contact.uid().empty());
    }
```

#### AUTO 


```{c}
auto attendeeRsvp = [](const QString &status) {
        if (status == QLatin1String("maybe")) {
            return KCalCore::Attendee::Tentative;
        } else if (status == QLatin1String("attending")) {
            return KCalCore::Attendee::Accepted;
        } else if (status == QLatin1String("declined")) {
            return KCalCore::Attendee::Declined;
        } else {
            return KCalCore::Attendee::NeedsAction;
        }
    };
```

#### AUTO 


```{c}
auto readJob = qobject_cast<EwsGlobalTagsReadJob *>(job);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            emitResult();
        }
```

#### AUTO 


```{c}
auto task = new RetrieveCollectionMetadataTask(state);
```

#### AUTO 


```{c}
auto *fetch
        = new Akonadi::CollectionFetchJob(c, Akonadi::CollectionFetchJob::Base, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mailbox : qAsConst(mMailboxes)) {
            // "Shared Folders" is not a valid mailbox, so we have to skip the ACL request for this folder
            if (isNamespaceFolder(mailbox, mSharedNamespace, true)) {
                continue;
            }
            auto rights = new KIMAP::MyRightsJob(mSession);
            rights->setMailBox(mailbox);
            connect(rights, &KJob::result, this, &RetrieveMetadataJob::onRightsReceived);
            mJobs++;
            rights->start();
        }
```

#### AUTO 


```{c}
auto layout = new QFormLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool) {
        auth->walletPasswordRequestFinished(mUi->passwordEdit->password());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&createFolderCalled](const QString &) {
            createFolderCalled = true;
            return true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ObjectPtr &object : objects) {
        const EventPtr event = object.dynamicCast<Event>();
        if (event->useDefaultReminders() && attr) {
            const KCalendarCore::Alarm::List alarms = attr->alarms(event.data());
            for (const KCalendarCore::Alarm::Ptr &alarm : alarms) {
                event->addAlarm(alarm);
            }
        }

        Item item;
        item.setMimeType(mimeType());
        item.setParentCollection(collection);
        item.setRemoteId(event->id());
        item.setRemoteRevision(event->etag());
        item.setPayload<KCalendarCore::Event::Ptr>(event.dynamicCast<KCalendarCore::Event>());

        if (event->deleted()) {
            qCDebug(GOOGLE_CALENDAR_LOG) << " - removed" << event->uid();
            removedItems << item;
        } else {
            qCDebug(GOOGLE_CALENDAR_LOG) << " - changed" << event->uid();
            changedItems << item;
        }
    }
```

#### AUTO 


```{c}
auto *setMetadataJob = new KIMAP::SetMetaDataJob(mImapSession);
```

#### AUTO 


```{c}
auto job = new ItemDeleteJob(items);
```

#### AUTO 


```{c}
auto *job = new OXA::FoldersRequestJob(0, OXA::FoldersRequestJob::Modified, this);
```

#### AUTO 


```{c}
auto *protoAttr = collection.attribute<DavProtocolAttribute>(Collection::AddIfMissing);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line : qAsConst(lines)) {
            QByteArray trimmed = line.trimmed();
            int wsIndex = trimmed.indexOf('%');
            const QByteArray key = trimmed.mid(0, wsIndex).trimmed();
            const QByteArray value = trimmed.mid(wsIndex + 1, line.length() - wsIndex).trimmed();
            limitsMap[key] = value.toLongLong();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Akonadi::Item &item) { itemFetched(item);}
```

#### AUTO 


```{c}
auto fjob = new ItemFetchJob(collection);
```

