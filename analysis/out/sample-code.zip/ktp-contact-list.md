#### LAMBDA EXPRESSION 


```{c}
[=] (bool checked) {
                m_comboBoxes[i]->setEnabled(checked);
                KTp::Presence presence;
                if (checked) {
                    setComboLineEdit();
                    presence = m_comboBoxes[i]->currentData(KTp::PresenceModel::PresenceRole).value<KTp::Presence>();
                } else {
                    m_comboBoxes[i]->lineEdit()->setPlaceholderText(m_comboBoxes[i]->currentData(Qt::DisplayRole).value<QString>());
                    presence.setStatus(Tp::ConnectionPresenceTypeUnset, QLatin1String("unset"), QString());
                }

                m_accountsModel->setData(index, QVariant::fromValue<KTp::Presence>(presence), KTp::AccountsListModel::StatusHandlerPresenceRole);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Tp::AccountPtr &account : m_globalPresence->accountManager()->enabledAccounts()->accounts()) {
                KTp::Presence accountPresence(account->currentPresence());
                QString presenceIconPath = KIconLoader::global()->iconPath(accountPresence.icon().name(), 1);
                QString presenceIconString = QString::fromLatin1("<img src=\"%1\">").arg(presenceIconPath);
                QString accountIconPath = KIconLoader::global()->iconPath(account->iconName(), 1);
                QString accountIconString = QString::fromLatin1("<img src=\"%1\" width=\"%2\" height=\"%2\">").arg(accountIconPath).arg(KIconLoader::SizeSmallMedium);
                QString presenceString;
                if (account->connectionStatus() == Tp::ConnectionStatusConnecting) {
                    presenceString = i18nc("Presence string when the account is connecting", "Connecting...");
                } else if (!account->currentPresence().statusMessage().isEmpty()){
                    presenceString = QString::fromLatin1("(%1) ").arg(accountPresence.displayString()) + accountPresence.statusMessage();
                } else {
                    presenceString = accountPresence.displayString();
                }
                toolTipText.append(QString::fromLatin1("<tr><td>%1 %2</td></tr><tr><td style=\"padding-left: 24px\">%3&nbsp;%4</td></tr>").arg(accountIconString, account->displayName(), presenceIconString, presenceString));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
                setComboLineEdit();

                if (m_comboBoxes[i]->currentIndex() < m_presenceModel->rowCount()) {
                    m_extendedModels[i]->removeTemporaryPresence();
                }

                m_accountsModel->setData(index, m_comboBoxes[i]->currentData(KTp::PresenceModel::PresenceRole), KTp::AccountsListModel::StatusHandlerPresenceRole);
            }
```

#### AUTO 


```{c}
auto setComboLineEdit = [=] () {
                if (m_comboBoxes[i]->currentData(KTp::PresenceModel::PresenceRole).value<KTp::Presence>().statusMessage().isEmpty()) {
                    m_comboBoxes[i]->lineEdit()->setPlaceholderText(i18n("Set a status message ..."));
                    m_comboBoxes[i]->lineEdit()->setReadOnly(false);
                } else {
                    m_comboBoxes[i]->lineEdit()->setPlaceholderText(m_comboBoxes[i]->currentData(Qt::DisplayRole).value<QString>());
                    m_comboBoxes[i]->lineEdit()->setReadOnly(true);
                }

                m_comboBoxes[i]->lineEdit()->setToolTip(m_comboBoxes[i]->currentData(Qt::DisplayRole).value<QString>());
            };
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
                if (m_comboBoxes[i]->currentData(KTp::PresenceModel::PresenceRole).value<KTp::Presence>().statusMessage().isEmpty()) {
                    m_comboBoxes[i]->lineEdit()->setPlaceholderText(i18n("Set a status message ..."));
                    m_comboBoxes[i]->lineEdit()->setReadOnly(false);
                } else {
                    m_comboBoxes[i]->lineEdit()->setPlaceholderText(m_comboBoxes[i]->currentData(Qt::DisplayRole).value<QString>());
                    m_comboBoxes[i]->lineEdit()->setReadOnly(true);
                }

                m_comboBoxes[i]->lineEdit()->setToolTip(m_comboBoxes[i]->currentData(Qt::DisplayRole).value<QString>());
            }
```

