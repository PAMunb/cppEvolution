#### RANGE FOR STATEMENT 


```{c}
for (QString author : qAsConst(foundAuthors)) {
            // ensure dot at the end of copyright
            if (!author.endsWith(QLatin1Char('.'))) author += QLatin1Char('.');
            commentList.append(author);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KAutoSaveFile *stale : staleFiles) {
        if (stale->open(QIODevice::ReadOnly) && !autoSave) {
            autoSave = stale;
            autoSave->setParent(this);
        } else
            stale->deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int i : indexes)
                possibleRefMatches << ref.tags.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filepath : files)
        map[filepath] = true;
```

#### AUTO 


```{c}
const auto addedPhases = m_model->addedPhases();
```

#### AUTO 


```{c}
const auto words = enTerm.split(m_rxSplit, Qt::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& note : languageToolNotes)
            html += note.toHtmlEscaped() + MsgCtxtView::BR;
```

#### AUTO 


```{c}
const auto items = selectedIndexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& word : words)
            idsByLangWord[sourceLangCode].remove(stem(sourceLangCode, word), entryId);
```

#### RANGE FOR STATEMENT 


```{c}
for (Kross::Action* action : actions) {
            if (action->property("autorun").toBool())
                action->trigger();
            if (action->property("first-run").toBool() && Project::local()->firstRun())
                action->trigger();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](int fuzzy, int translated, int untranslated, bool done) {
        QCOMPARE(fuzzy, 1);
        QCOMPARE(translated, 3);
        QCOMPARE(untranslated, 2);
        QCOMPARE(done, true);
    }
```

#### AUTO 


```{c}
const auto urls = event->mimeData()->urls();
```

#### LAMBDA EXPRESSION 


```{c}
[srcFileRelPath]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                QDesktopServices::openUrl(QUrl::fromLocalFile(absFilePath));
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { slotRemoveSuggestion(i); }
```

#### AUTO 


```{c}
auto *model = new ProjectModel(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QMdiSubWindow* subwindow : subwindows) {
        if (subwindow == m_translationMemorySubWindow && m_translationMemorySubWindow)
            subwindow->deleteLater();
        else if (qobject_cast<EditorTab*>(subwindow->widget())) {
            m_fileToEditor.remove(static_cast<EditorTab*>(subwindow->widget())->currentFilePath());//safety
            m_mdiArea->removeSubWindow(subwindow);
            subwindow->deleteLater();
        } else if (subwindow == m_projectSubWindow && m_projectSubWindow)
            static_cast<ProjectTab*>(m_projectSubWindow->widget())->showWelcomeScreen();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRegExp& re : regExps) {
        int pos = re.indexIn(string);
        if (pos != -1)
            return string.replace(pos, re.matchedLength(), QStringLiteral("<b>") + re.cap(0) + QStringLiteral("</b>"));
    }
```

#### AUTO 


```{c}
const auto collections = collection->collections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Note& note : developerNotes) {
        html += MsgCtxtView::BR + escapeWithLinks(note.content).replace('\n', BR);
    }
```

#### AUTO 


```{c}
auto clit=concordanceLevelToIds.constEnd();
```

#### AUTO 


```{c}
const auto subwindows = m_mdiArea->subWindowList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filepath : filepaths) {
        Catalog catalog(QThread::currentThread());
        if (catalog.loadFromUrl(filepath, QString()) != 0)
            continue;

        const auto indexes = map.values(filepath);
        for (int index : indexes) {
            SearchResult& sr = searchResults[index];
            DocPosition docPos = sr.docPos.toDocPosition();
            if (catalog.target(docPos) != sr.target) {
                qCWarning(LOKALIZE_LOG) << "skipping replace because" << catalog.target(docPos) << "!=" << sr.target;
                continue;
            }

            CatalogString s = catalog.targetWithTags(docPos);
            int pos = replaceWhat.indexIn(s.string);
            while (pos != -1) {
                if (!s.string.midRef(pos, replaceWhat.matchedLength()).contains(TAGRANGE_IMAGE_SYMBOL)) {
                    docPos.offset = pos;
                    catalog.targetDelete(docPos, replaceWhat.matchedLength());
                    catalog.targetInsert(docPos, replaceWith);
                    s.string.replace(pos, replaceWhat.matchedLength(), replaceWith);
                    pos += replaceWith.length();
                } else {
                    pos += replaceWhat.matchedLength();
                    qCWarning(LOKALIZE_LOG) << "skipping replace because matched text contains markup" << s.string;
                }

                if (pos > s.string.length() || replaceWhat.pattern().startsWith('^'))
                    break;

                pos = replaceWhat.indexIn(s.string, pos);
            }
        }

        catalog.save();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& rc : rcs)
        if (rc != scriptsrc)
            qCWarning(LOKALIZE_LOG) << rc << collection->readXmlFile(rcdir.absoluteFilePath(rc));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Note& note : qAsConst(notes)) {
        QDomElement elem = phaseElem.appendChild(m_doc.createElement(NOTE)).toElement();
        elem.appendChild(m_doc.createTextNode(note.content));
        if (!note.from.isEmpty()) elem.setAttribute(QStringLiteral("from"), note.from);
        if (note.priority) elem.setAttribute(QStringLiteral("priority"), note.priority);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &fileRef : fileRefs) {
            result << fileRef.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& row : rows)
        model()->removeRow(row.row());
```

#### AUTO 


```{c}
const auto selectedRows = m_browser->selectionModel()->selectedRows();
```

#### AUTO 


```{c}
const auto pologyNotes = m_pologyNotes.values(m_entry.entry);
```

#### AUTO 


```{c}
auto doOpen = [srcFileRelPath]()
        {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/')+1).toUtf8();
            auto it=sourceFilePaths.constFind(fn);
            while (it!=sourceFilePaths.constEnd() && it.key() == fn)
            {
                const QString absFilePath = QString::fromUtf8(it.value()+'/'+fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath) ) //for the case when link contained also folders
                {
                    it++;
                    continue;
                }
                found = true;
                QDesktopServices::openUrl(QUrl::fromLocalFile(absFilePath));
                it++;
            }
            if (!found)
            {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                i18nc("@info","Could not find source file in the folder specified.\n"
                                                      "Do you want to change source files folder?"),i18nc("@title:window","Source file lookup"),
                                                      KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org"))))
                {
                    case KMessageBox::Cancel:
                        Project::instance()->local()->setSourceDir(QString());
                        Project::instance()->resetSourceFilePaths();
                        openLxrSearch(srcFileRelPath);
                    case KMessageBox::No:
                        return;
                    default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length())
                {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &targetTerm : targetTerms)
        appendTerm(targetElem, targetTerm);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& item : items) {
        if (item.column() == 0)
            recursiveAdd(list, m_proxyModel->mapToSource(item));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[ = ](int fuzzy, int translated, int untranslated, bool done) {
        QCOMPARE(fuzzy, 0);
        QCOMPARE(translated, 0);
        QCOMPARE(untranslated, 0);
        QCOMPARE(done, true);
    }
```

#### AUTO 


```{c}
const auto notes = m_catalog->notes(index.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : itemList)
        size = size.expandedTo(item->minimumSize());
```

#### AUTO 


```{c}
const auto rcs = QDir(PROJECTRCFILEDIR).entryList(QStringList("*.rc"), QDir::Files);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Note &note : notes)
            result += note.content;
```

#### AUTO 


```{c}
auto yes = KGuiItem(
            i18np("&Open %1 File", "&Open %1 Files", i),
            QStringLiteral("document-open")
        );
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : itemList) {
        int nextX = x + item->sizeHint().width() + spacing();
        if (nextX - spacing() > rect.right() && lineHeight > 0) {
            x = rect.x();
            y = y + lineHeight + spacing();
            nextX = x + item->sizeHint().width() + spacing();
            lineHeight = 0;
        }

        if (!testOnly)
            item->setGeometry(QRect(QPoint(x, y), item->sizeHint()));

        x = nextX;
        lineHeight = qMax(lineHeight, item->sizeHint().height());
    }
```

#### AUTO 


```{c}
auto kcfg_ProjLangTeam = ui_prefs_projectmain.kcfg_ProjLangTeam;
```

#### LAMBDA EXPRESSION 


```{c}
[&loaded]() {
        loaded.fetchAndAddRelaxed(1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, i] { slotUseSuggestion(i); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& id : m_idsForEntriesById)
        result.insert(subjectField(id));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls)
        files.append(url.toLocalFile());
```

#### RANGE FOR STATEMENT 


```{c}
for (const InlineTag& tag : target.tags) {
            if (id2tagIndex.contains(tag.id))
                sourceForReferencing.tags[id2tagIndex.value(tag.id)].id = REMOVEME;
        }
```

#### AUTO 


```{c}
const auto actions = c->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceFile : sourceFiles)
            html += QString(QStringLiteral("<a href=\"src:/%1\">%2</a><br />")).arg(sourceFile, sourceFile);
```

#### AUTO 


```{c}
auto sourceFilePaths = Project::instance()->sourceFilePaths();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& termId : termIdSet) {
        // now check which of them are really hits...
        const auto enTerms = glossary.terms(termId, sourceLangCode);
        for (const QString& enTerm : enTerms) {
            // ...and if so, which part of termEn list we must thank for match ...
            bool ok = msg.contains(enTerm); //,//Qt::CaseInsensitive  //we lowered terms on load
            if (!ok) {
                QString enTermStemmed;
                const auto words = enTerm.split(m_rxSplit, Qt::SkipEmptyParts);
                for (const QString& word : words)
                    enTermStemmed += stem(sourceLangCode, word) + ' ';
                ok = msgStemmed.contains(enTermStemmed);
            }
            if (ok) {
                //insert it into label
                found = true;
                int pos = sourceLowered.indexOf(enTerm);
                m_flowLayout->addTerm(enTerm, termId,/*uppercase*/pos != -1 && source.at(pos).isUpper());
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pologyTmp : pologyTmpLines) {
                    if (pologyTmp.startsWith(QStringLiteral("[note]")))
                        m_pologyData += pologyTmp;
                }
```

#### AUTO 


```{c}
const auto rows = selectionModel()->selectedRows();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &current : array) {
        if (current.type() == QJsonValue::Object) {
            const QJsonObject suggestionObject = current.toObject();
            lst.append(suggestionObject[QLatin1String("value")].toString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls)
        if (url.path().endsWith(QLatin1String(".rc")))
            scriptsModel->rootCollection()->readXmlFile(url.path());
```

#### AUTO 


```{c}
const auto filePaths = parser.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filepath : filepaths)
        map[filepath] = true;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& termText : termTexts) {
        const auto words = termText.split(' ', Qt::SkipEmptyParts);
        for (const QString& word : words)
            idsByLangWord[sourceLangCode].insert(stem(sourceLangCode, word), entryId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& rowIndex : selectedRows)
        m_qaModel->removeRow(rowIndex);
```

#### AUTO 


```{c}
const auto tempNotes = m_tempNotes.values(m_entry.entry);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& note : pologyNotes)
            html += note.toHtmlEscaped() + MsgCtxtView::BR;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : filePaths)
            if (filePath.endsWith(QLatin1String(".lokalize")))
                projectFilePath = filePath;
            else if (QFileInfo::exists(filePath))
                urls.append(filePath);
```

#### AUTO 


```{c}
const auto words = termText.split(' ', Qt::SkipEmptyParts);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Note& note : notes)
        m_hasErrorNotes = m_hasErrorNotes || note.content.contains(QLatin1String("[ERROR]"));
```

#### LAMBDA EXPRESSION 


```{c}
[=](int fuzzy, int translated, int untranslated, bool done) {
        QCOMPARE(fuzzy, 0);
        QCOMPARE(translated, 0);
        QCOMPARE(untranslated, 0);
        QCOMPARE(done, true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[kcfg_ProjLangTeam] { kcfg_ProjLangTeam->setFocus(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cppLine : cppLines) {
        const auto fileRefs = cppLine.midRef(3).split(' ');
        for (const QStringRef &fileRef : fileRefs) {
            if (hasUi && fileRef.startsWith(QLatin1String("rc.cpp:"))) {
                continue;
            }
            result << fileRef.toString();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& word : words)
                    enTermStemmed += stem(sourceLangCode, word) + ' ';
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringRef &fileRef : fileRefs) {
            if (hasUi && fileRef.startsWith(QLatin1String("rc.cpp:"))) {
                continue;
            }
            result << fileRef.toString();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& lang : langsToTry) {
        QString d = glossary->definition(m_id, lang);
        if (!d.isEmpty()) {
            if (m_defLang != lang)
                m_definitionLang->setCurrentIndex(LanguageListModel::emptyLangInstance()->sortModelRowForLangCode(lang));
            m_defLang = lang;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &collectionname : collections) {
        Kross::ActionCollection* c = collection->collection(collectionname);
        if (!c->isEnabled()) continue;

        const auto actions = c->actions();
        for (Kross::Action* action : actions) {
            if (action->property("autorun").toBool())
                action->trigger();
            if (action->property("first-run").toBool() && Project::local()->firstRun())
                action->trigger();
        }
    }
```

#### AUTO 


```{c}
auto yes = KGuiItem(
                       i18np("&Open %1 File", "&Open %1 Files", i),
                       QStringLiteral("document-open")
                   );
```

#### RANGE FOR STATEMENT 


```{c}
for (int mergePosition : mergePositions) {
        const QList<int>& basePositions = backMap.values(mergePosition);
        if (basePositions.size() == 1)
            continue;

        //qCDebug(LOKALIZE_LOG)<<"kv"<<mergePosition<<basePositions;
        QList<MatchItem> scores;
        for (int value : basePositions)
            scores << calcMatchItem(DocPosition(value), mergePosition);

        std::sort(scores.begin(), scores.end(), std::greater<MatchItem>());
        int i = scores.size();
        while (--i > 0) {
            //qCDebug(LOKALIZE_LOG)<<"erasing"<<scores.at(i).baseEntry<<m_map[scores.at(i).baseEntry]<<",m_map["<<scores.at(i).baseEntry<<"]=-1";
            m_map[scores.at(i).baseEntry] = -1;
        }
    }
```

#### AUTO 


```{c}
const auto ws = msg.split(m_rxSplit, Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[kcfg_ProjLangTeam](int index) { kcfg_ProjLangTeam->setEnabled(static_cast<Project::LangSource>(index) == Project::LangSource::Project); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& enTerm : enTerms) {
            // ...and if so, which part of termEn list we must thank for match ...
            bool ok = msg.contains(enTerm); //,//Qt::CaseInsensitive  //we lowered terms on load
            if (!ok) {
                QString enTermStemmed;
                const auto words = enTerm.split(m_rxSplit, Qt::SkipEmptyParts);
                for (const QString& word : words)
                    enTermStemmed += stem(sourceLangCode, word) + ' ';
                ok = msgStemmed.contains(enTermStemmed);
            }
            if (ok) {
                //insert it into label
                found = true;
                int pos = sourceLowered.indexOf(enTerm);
                m_flowLayout->addTerm(enTerm, termId,/*uppercase*/pos != -1 && source.at(pos).isUpper());
                break;
            }
        }
```

#### AUTO 


```{c}
const auto cppLines = commentLines.filter(cpp_re);
```

#### AUTO 


```{c}
const auto enTerms = glossary.terms(termId, sourceLangCode);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& filePath : qAsConst(files)) {
        Catalog catalog(nullptr);
        if (Q_UNLIKELY(catalog.loadFromUrl(filePath, QString(), &m_size, true) != 0))
            continue;

        //QVector<FileSearchResult> catalogResults;
        int numberOfEntries = catalog.numberOfEntries();
        DocPosition pos(0);
        for (; pos.entry < numberOfEntries; pos.entry++) {
            //if (!searchParams.states[catalog.state(pos)])
            //    return false;
            int lim = catalog.isPlural(pos.entry) ? catalog.numberOfPluralForms() : 1;
            for (pos.form = 0; pos.form < lim; pos.form++) {
                int sp = 0;
                int tp = 0;
                if (!searchParams.sourcePattern.isEmpty())
                    sp = searchParams.sourcePattern.indexIn(removeAmpFromSource ? catalog.source(pos).remove(QLatin1Char('&')) : catalog.source(pos));
                if (!searchParams.targetPattern.isEmpty())
                    tp = searchParams.targetPattern.indexIn(removeAmpFromTarget ? catalog.target(pos).remove(QLatin1Char('&')) : catalog.target(pos));
                //int np=searchParams.notesPattern.indexIn(catalog.notes(pos));

                if ((sp != -1) != searchParams.invertSource && (tp != -1) != searchParams.invertTarget) {
                    //TODO handle multiple results in same column
                    //FileSearchResult r;
                    SearchResult r;
                    r.filepath = filePath;
                    r.docPos = pos;
                    if (!searchParams.sourcePattern.isEmpty() && !searchParams.invertSource)
                        r.sourcePositions << StartLen(searchParams.sourcePattern.pos(), searchParams.sourcePattern.matchedLength());
                    if (!searchParams.targetPattern.isEmpty() && !searchParams.invertTarget)
                        r.targetPositions << StartLen(searchParams.targetPattern.pos(), searchParams.targetPattern.matchedLength());
                    r.source = catalog.source(pos);
                    r.target = catalog.target(pos);
                    r.state = catalog.state(pos);
                    r.isApproved = catalog.isApproved(pos);
                    //r.activePhase=catalog.activePhase();
                    if (rules.size()) {
                        QVector<StartLen> positions(2);
                        int matchedQaRule = findMatchingRule(rules, r.source, r.target, positions);
                        if (matchedQaRule == -1)
                            continue;
                        if (positions.at(0).len)
                            r.sourcePositions << positions.at(0);
                        if (positions.at(1).len)
                            r.targetPositions << positions.at(1);
                    }

                    r.sourcePositions.squeeze();
                    r.targetPositions.squeeze();
                    //catalogResults<<r;
                    results << r;
                }
            }
        }
        //if (catalogResults.size())
        //    results[path]=catalogResults;
    }
```

#### AUTO 


```{c}
const auto column = static_cast<ProjectModelColumns>(section);
```

#### LAMBDA EXPRESSION 


```{c}
[=](int fuzzy, int translated, int untranslated, bool done) {
        QCOMPARE(fuzzy, 1);
        QCOMPARE(translated, 3);
        QCOMPARE(untranslated, 2);
        QCOMPARE(done, true);
    }
```

#### AUTO 


```{c}
const auto filepaths = m_model->stringList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &uiLine : uiLines) {
        const auto fileRefs = uiLine.midRef(15).split(' ');
        for (const QStringRef &fileRef : fileRefs) {
            result << fileRef.toString();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[srcFileRelPath, line]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                openLocalSource(absFilePath, line);
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        }
```

#### AUTO 


```{c}
const auto fileRefs = uiLine.midRef(15).split(' ');
```

#### AUTO 


```{c}
const auto developerNotes = m_catalog->developerNotes(m_entry.toDocPosition());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& id : qAsConst(m_idsForEntriesById)) {
        if (rx.exactMatch(QString::fromLatin1(id)))
            busyIdNumbers.append(rx.cap(1).toInt());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Phase& p : qAsConst(phases)) {
        if (!(options & ForceAdd) && p.contact == phase.contact && p.process == phase.process) {
            phase = p;
            break;
        }
        names.insert(p.name);
    }
```

#### AUTO 


```{c}
const auto indexes = tagType2tagIndex.values(targetTag.type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : note) {
        if (s.size() >= preLen) {
            content += s.midRef(preLen);
            content += QLatin1Char('\n');
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Phase& phase : addedPhases)
        static_cast<QUndoStack*>(m_catalog)->push(new UpdatePhaseCmd(m_catalog, last = phase));
```

#### AUTO 


```{c}
const auto indexes = map.values(filepath);
```

#### AUTO 


```{c}
auto doOpen = [srcFileRelPath]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                QDesktopServices::openUrl(QUrl::fromLocalFile(absFilePath));
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        };
```

#### LAMBDA EXPRESSION 


```{c}
[kcfg_ProjLangTeam](int index) {
        kcfg_ProjLangTeam->setEnabled(static_cast<Project::LangSource>(index) == Project::LangSource::Project);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int index : indexes) {
            SearchResult& sr = searchResults[index];
            DocPosition docPos = sr.docPos.toDocPosition();
            if (catalog.target(docPos) != sr.target) {
                qCWarning(LOKALIZE_LOG) << "skipping replace because" << catalog.target(docPos) << "!=" << sr.target;
                continue;
            }

            CatalogString s = catalog.targetWithTags(docPos);
            int pos = replaceWhat.indexIn(s.string);
            while (pos != -1) {
                if (!s.string.midRef(pos, replaceWhat.matchedLength()).contains(TAGRANGE_IMAGE_SYMBOL)) {
                    docPos.offset = pos;
                    catalog.targetDelete(docPos, replaceWhat.matchedLength());
                    catalog.targetInsert(docPos, replaceWith);
                    s.string.replace(pos, replaceWhat.matchedLength(), replaceWith);
                    pos += replaceWith.length();
                } else {
                    pos += replaceWhat.matchedLength();
                    qCWarning(LOKALIZE_LOG) << "skipping replace because matched text contains markup" << s.string;
                }

                if (pos > s.string.length() || replaceWhat.pattern().startsWith('^'))
                    break;

                pos = replaceWhat.indexIn(s.string, pos);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& termText : termTexts) {
        const auto words = termText.split(' ', Qt::SkipEmptyParts);
        for (const QString& word : words)
            idsByLangWord[sourceLangCode].remove(stem(sourceLangCode, word), entryId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int entry : changed) {
        pos.entry = entry;
        if (options & EmptyOnly && !m_baseCatalog->isEmpty(entry))
            continue;
        if (options & HigherOnly && !m_baseCatalog->isEmpty(entry) && m_baseCatalog->state(pos) >= state(pos))
            continue;

        int formsCount = (m_baseCatalog->isPlural(entry)) ? m_baseCatalog->numberOfPluralForms() : 1;
        pos.form = 0;
        while (pos.form < formsCount) {
            //m_baseCatalog->push(new DelTextCmd(m_baseCatalog,pos,m_baseCatalog->msgstr(pos.entry,0))); ?
            //some forms may still contain translation...
            if (!(options & EmptyOnly && !m_baseCatalog->isEmpty(pos)) /*&&
                !(options&HigherOnly && !m_baseCatalog->isEmpty(pos) && m_baseCatalog->state(pos)>=state(pos))*/) {
                if (!insHappened) {
                    //stop basecatalog from sending signalEntryModified to us
                    //when we are the ones who does the modification
                    disconnect(m_baseCatalog, &Catalog::signalEntryModified, this, &MergeCatalog::copyFromBaseCatalogIfInDiffIndex);
                    insHappened = true;
                    m_baseCatalog->beginMacro(i18nc("@item Undo action item", "Accept all new translations"));
                }

                copyToBaseCatalog(pos);
                /// ///
                /// m_baseCatalog->push(new InsTextCmd(m_baseCatalog,pos,mergeCatalog.msgstr(pos)));
                /// ///
            }
            ++(pos.form);
        }
        /// ///
        /// removeFromDiffIndex(m_pos.entry);
        /// ///
    }
```

#### LAMBDA EXPRESSION 


```{c}
[srcFileRelPath, dir, line]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            QString absFilePath = QString("%1/%2").arg(dir, srcFileRelPath);
            if (QFileInfo::exists(absFilePath)) {
                openLocalSource(absFilePath, line);
                return;
            }
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                openLocalSource(absFilePath, line);
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        }
```

#### AUTO 


```{c}
auto doOpen = [srcFileRelPath, dir, line]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            QString absFilePath = QString("%1/%2").arg(dir, srcFileRelPath);
            if (QFileInfo::exists(absFilePath)) {
                openLocalSource(absFilePath, line);
                return;
            }
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                openLocalSource(absFilePath, line);
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(nullptr, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &sourceTerm : sourceTerms)
        appendTerm(sourceElem, sourceTerm);
```

#### AUTO 


```{c}
auto it = sourceFilePaths.constFind(fn);
```

#### AUTO 


```{c}
const auto fileRefs = cppLine.midRef(3).split(' ');
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pologyTmp : pologyTmpLines) {
            if (pologyTmp.startsWith(QStringLiteral("[note]")))
                m_pologyData += pologyTmp;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Catalog* altCat : d._altTransCatalogs) {
        if (pos.entry >= altCat->numberOfEntries()) {
            qCDebug(LOKALIZE_LOG) << "ignoring" << altCat->url() << "this time because" << pos.entry << "<" << altCat->numberOfEntries();
            continue;
        }

        if (altCat->source(pos) != source(pos)) {
            qCDebug(LOKALIZE_LOG) << "ignoring" << altCat->url() << "this time because <source>s don't match";
            continue;
        }

        QString target = altCat->msgstr(pos);
        if (!target.isEmpty() && altCat->isApproved(pos)) {
            result << AltTrans();
            result.last().target = target;
            result.last().type = AltTrans::Reference;
            result.last().origin = altCat->url();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& str : qAsConst(resultString))
        result << str;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& note : tempNotes)
            html += note.toHtmlEscaped() + MsgCtxtView::BR;
```

#### AUTO 


```{c}
const auto selectedIndexes = itemSelection().indexes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& word : words)
            idsByLangWord[sourceLangCode].insert(stem(sourceLangCode, word), entryId);
```

#### AUTO 


```{c}
const auto column = static_cast<ProjectModelColumns>(index.column());
```

#### AUTO 


```{c}
auto doOpen = [srcFileRelPath, dir, line]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            QString absFilePath = QString("%1/%2").arg(dir, srcFileRelPath);
            if (QFileInfo::exists(absFilePath)) {
                openLocalSource(absFilePath, line);
                return;
            }
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                openLocalSource(absFilePath, line);
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const HighlightingRule &rule : qAsConst(highlightingRules)) {
        QRegExp expression(rule.pattern);
        int index = expression.indexIn(text);
        while (index >= 0) {
            int length = expression.matchedLength();
            QTextCharFormat f = rule.format;
            f.setFontItalic(!m_approved);
            setFormat(index, length, f);
            index = expression.indexIn(text, index + length);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &index : selectedIndexes) {
        Action* action = ActionCollectionModel::action(index);
        static_cast<WebQueryController*>(action->object("WebQueryController"))->query(data);


        //we pass us into the queue.
//         qCWarning(LOKALIZE_LOG)<<action->object("WebQueryController");
//         Project::instance()->aaaaa()->postQuery(data,
//                           static_cast<WebQueryController*>(action->object("WebQueryController")));
//         QMetaObject::invokeMethod(action->object("WebQueryController"),
//                                   SLOT(query(const CatalogData&)),
//                                   Q_ARG(CatalogData,data)
//                                  );
//         connect(this,SIGNAL(query(const CatalogData&)),
//                action->object("WebQueryController"),SLOT(query(const CatalogData&)),Qt::QueuedConnection);
//         Q_EMIT query(data);
//         disconnect(this,SIGNAL(query(const CatalogData&)),
//                action->object("WebQueryController"),SLOT(query(const CatalogData&)));

    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int value : basePositions)
            scores << calcMatchItem(DocPosition(value), mergePosition);
```

#### RANGE FOR STATEMENT 


```{c}
for (const InlineTag& tag : qAsConst(oldTags)) {
        if (tag.isPaired())
            target.remove(tag.end, 1);
        target.remove(tag.start, 1);
    }
```

#### AUTO 


```{c}
auto doOpen = [srcFileRelPath, line]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                openLocalSource(absFilePath, line);
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (int key : list) {
        if (Q_UNLIKELY(key > index)) {
            nextIndex = key;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& word : words) {
            if (word.length() < wordCompletionLength)
                continue;
            m_words[word]++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : actions) {
            TermLabel* label = new TermLabel(action); /*this,m_keys.at(count())*/
            connect(action, &QAction::triggered, label, &GlossaryNS::TermLabel::insert);
            connect(label, &GlossaryNS::TermLabel::insertTerm, (GlossaryNS::GlossaryView*)m_receiver, &GlossaryNS::GlossaryView::termInsertRequested);
            label->hide();
            addWidget(label);
        }
```

#### AUTO 


```{c}
const auto termTexts = terms(entryId, sourceLangCode);
```

#### RANGE FOR STATEMENT 


```{c}
for (int key : list) {
        if (Q_UNLIKELY(key >= index))
            break;
        prevIndex = key;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QJsonValue &current : array) {
        //qDebug() << " current " << current;
        if (current.type() == QJsonValue::Object) {
            const QJsonObject languageToolObject = current.toObject();
            LanguageToolGrammarError error;
            infos.append(error.parse(languageToolObject, text));
        }
    }
```

#### AUTO 


```{c}
const auto languageToolNotes = m_languageToolNotes.values(m_entry.entry);
```

#### LAMBDA EXPRESSION 


```{c}
[srcFileRelPath]()
        {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/')+1).toUtf8();
            auto it=sourceFilePaths.constFind(fn);
            while (it!=sourceFilePaths.constEnd() && it.key() == fn)
            {
                const QString absFilePath = QString::fromUtf8(it.value()+'/'+fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath) ) //for the case when link contained also folders
                {
                    it++;
                    continue;
                }
                found = true;
                QDesktopServices::openUrl(QUrl::fromLocalFile(absFilePath));
                it++;
            }
            if (!found)
            {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                i18nc("@info","Could not find source file in the folder specified.\n"
                                                      "Do you want to change source files folder?"),i18nc("@title:window","Source file lookup"),
                                                      KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org"))))
                {
                    case KMessageBox::Cancel:
                        Project::instance()->local()->setSourceDir(QString());
                        Project::instance()->resetSourceFilePaths();
                        openLxrSearch(srcFileRelPath);
                    case KMessageBox::No:
                        return;
                    default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(0, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length())
                {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        }
```

#### AUTO 


```{c}
const auto uiLines = commentLines.filter(i18n_file_re);
```

#### AUTO 


```{c}
const auto filepaths = map.keys();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Note& note : notes) {
            if (!note.from.isEmpty())
                t.insertHtml(QStringLiteral("<i>") + note.from + QStringLiteral(":</i> "));

            if (i == active)
                realOffset = t.position();
            QString content = escapeWithLinks(note.content);
            if (!multiple && content.contains('\n')) content += '\n';
            content.replace('\n', BR);
            content += QString(QStringLiteral(" (<a href=\"note:/%1\">")).arg(i) + i18nc("link to edit note", "edit...") + QStringLiteral("</a>)<br />");
            t.insertHtml(content);
            i++;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& w : ws) {
        QString word = stem(sourceLangCode, w);
        QList<QByteArray> indexes = glossary.idsForLangWord(sourceLangCode, word);
        //if (indexes.size())
        //qCWarning(LOKALIZE_LOG)<<"found entry for:" <<word;
        termIds += indexes;
        msgStemmed += word + ' ';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QLayoutItem* item : qAsConst(itemList))
        static_cast<TermLabel*>(item->widget())->hide();
```

#### AUTO 


```{c}
auto clit = concordanceLevelToIds.constEnd();
```

#### AUTO 


```{c}
auto it=sourceFilePaths.constFind(fn);
```

#### LAMBDA EXPRESSION 


```{c}
[srcFileRelPath, dir, line]() {
            auto sourceFilePaths = Project::instance()->sourceFilePaths();
            QString absFilePath = QString("%1/%2").arg(dir, srcFileRelPath);
            if (QFileInfo::exists(absFilePath)) {
                openLocalSource(absFilePath, line);
                return;
            }
            bool found = false;
            QByteArray fn = srcFileRelPath.midRef(srcFileRelPath.lastIndexOf('/') + 1).toUtf8();
            auto it = sourceFilePaths.constFind(fn);
            while (it != sourceFilePaths.constEnd() && it.key() == fn) {
                const QString absFilePath = QString::fromUtf8(it.value() + '/' + fn);
                if (!absFilePath.endsWith(srcFileRelPath) || !QFileInfo::exists(absFilePath)) { //for the case when link contained also folders
                    it++;
                    continue;
                }
                found = true;
                openLocalSource(absFilePath, line);
                it++;
            }
            if (!found) {
                switch (KMessageBox::warningYesNoCancel(SettingsController::instance()->mainWindowPtr(),
                                                        i18nc("@info", "Could not find source file in the folder specified.\n"
                                                                "Do you want to change source files folder?"), i18nc("@title:window", "Source file lookup"),
                                                        KStandardGuiItem::yes(), KStandardGuiItem::no(), KGuiItem(i18n("lxr.kde.org")))) {
                case KMessageBox::Cancel:
                    Project::instance()->local()->setSourceDir(QString());
                    Project::instance()->resetSourceFilePaths();
                    openLxrSearch(srcFileRelPath);
                case KMessageBox::No:
                    return;
                default: ; //fall through to dir selection
                }

                QString dir = QFileDialog::getExistingDirectory(nullptr, i18n("Select project's base folder for source file lookup"), Project::instance()->local()->sourceDir());
                if (dir.length()) {
                    Project::instance()->local()->setSourceDir(dir);
                    Project::instance()->resetSourceFilePaths();
                }

            }
        }
```

