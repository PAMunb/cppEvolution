#### RANGE FOR STATEMENT 


```{c}
for (QWidget *win : tlws) {
        if (qobject_cast<QMainWindow *>(win)) {
            win->show();
            win->setAttribute(Qt::WA_NativeWindow, true);
            KStartupInfo::setNewStartupId(win->windowHandle(), startupId); // this moves 'win' to the current desktop
#ifdef Q_OS_WIN
            KWindowSystem::forceActiveWindow(win->winId());
#endif
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->checkNewDay(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *win : tlws) {
        if (qobject_cast<QMainWindow *>(win)) {
            win->show();
            KStartupInfo::setNewStartupId(win, startupId);
#ifdef Q_OS_WIN
            KWindowSystem::forceActiveWindow(win->winId());
#endif
            break;
        }
    }
```

#### AUTO 


```{c}
auto job = new KIO::CommandLauncherJob(d->executableName);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *win : tlws) {
        if (qobject_cast<QMainWindow *>(win)) {
            win->show();
            win->setAttribute(Qt::WA_NativeWindow, true);
            if (KWindowSystem::isPlatformX11()) {
                KStartupInfo::setNewStartupId(win->windowHandle(), startupId); // this moves 'win' to the current desktop
            } else if (KWindowSystem::isPlatformWayland()) {
                KWindowSystem::activateWindow(win->windowHandle());
            }
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QObject *obj) {
            d->slotPartDestroyed(obj);
        }
```

#### AUTO 


```{c}
auto timer = new QTimer(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                d->partDestroyed();
            }
```

#### AUTO 


```{c}
auto drag = new QDrag(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QObject* obj) { d->slotPartDestroyed(obj);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->checkNewDay();
    }
```

#### AUTO 


```{c}
auto box = new QWidget(parent);
```

#### AUTO 


```{c}
auto label = new QLabel(box);
```

#### AUTO 


```{c}
const auto result = KPluginFactory::instantiatePlugin<KParts::Part>(KPluginMetaData(QString::fromLatin1(libname)), this);
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(box);
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *win : tlws) {
        if (qobject_cast<QMainWindow*>(win)) {
            win->show();
            KStartupInfo::setNewStartupId(win, startupId);
#ifdef Q_OS_WIN
            KWindowSystem::forceActiveWindow(win->winId());
#endif
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->partDestroyed(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *win : tlws) {
        if (qobject_cast<QMainWindow *>(win)) {
            win->show();
            KStartupInfo::setNewStartupId(win, startupId); // this moves 'win' to the current desktop
#ifdef Q_OS_WIN
            KWindowSystem::forceActiveWindow(win->winId());
#endif
            break;
        }
    }
```

