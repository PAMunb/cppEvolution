#### LAMBDA EXPRESSION 


```{c}
[url] {
            reqs.localData().remove(url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Target &t : targetlist) {
        // m_editor->targets->insertItems(0, m_buildServices[current->data(Qt::UserRole).toString()].targets());
        m_editor->targets->insertItem(0, t.name, t.id);
        // FIXME: target id.
        qDebug() << "target:" << t.name << t.id;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dev : _d) {
        devs << dev.trimmed();
    }
```

#### AUTO 


```{c}
const auto providerFiles = d->m_internals->getDefaultProviderFiles();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Category &category : categories) {
        categoryIds.append(category.id());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const BuildService &bs : itemList) {
            m_buildServices[bs.id()] = bs;
            qDebug() << "New OBS:" << bs.id() << bs.name() << bs.url();
            output.append(QString(QLatin1String("<br />%1 (%2) at %3")).arg(bs.name(), bs.id(), bs.url()));
            QListWidgetItem *new_bs = new QListWidgetItem(bs.name(), m_editor->buildServices);
            new_bs->setData(Qt::UserRole, QVariant(bs.id()));

            m_editor->accountsServers->insertItem(0, bs.name(), bs.id());
            //QListWidgetItem* new_bsa = new QListWidgetItem(bs.name(), m_editor->accountsServers);
            //new_bsa->setData(Qt::UserRole, QVariant(bs.id()));

        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &dependency : dependenciesList) {
        postParameters.insert(QString::fromLatin1("dependencies[%1]").arg(QString::number(i++)), dependency);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const License &license : licenses) {
        licenseIds.append(QString(license.id()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const License &license : licenses) {
        licenseIds.append(QString::number(license.id()));
    }
```

#### AUTO 


```{c}
const auto optionsList = newAchievement.options();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Distribution &distribution : distributions) {
        distributionIds.append(QString(distribution.id()));
    }
```

#### AUTO 


```{c}
const auto providerFiles  = d->m_internals->getDefaultProviderFiles();
```

#### AUTO 


```{c}
const auto optionsList = achievement.options();
```

#### RANGE FOR STATEMENT 


```{c}
for (const BuildServiceJob &bsj : itemList) {
            m_buildServiceJobs[bsj.id()] = bsj;
            qDebug() << "New BuildServiceJob:" << bsj.id() << bsj.name() << bsj.target();
            output.append(QString(QLatin1String("<br />%1 (%2) for %3")).arg(bsj.name(), bsj.id(), bsj.target()));
            QListWidgetItem *new_bsj = new QListWidgetItem(bsj.name(), m_editor->buildServiceJobs);
            new_bsj->setData(Qt::UserRole, QVariant(bsj.id()));
        }
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### LAMBDA EXPRESSION 


```{c}
[this, url]() {
                fileFinished(url.toString());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Project &p : itemList) {
            m_projects[p.id()] = p;
            qDebug() << "New project:" << p.id() << p.name();
            output.append(QString(QLatin1String("<br />%1 (%2)")).arg(p.name(), p.id()));
            projectIds << p.id();
            m_editor->projects->insertItem(0, p.name(), p.id());
            // TODO: start project jobs here
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &string : stringList) {
        if (str == string)
            return true;
    }
```

#### AUTO 


```{c}
const auto itemList = listJob->itemList();
```

#### LAMBDA EXPRESSION 


```{c}
[](QNetworkReply::NetworkError code) {
        qCDebug(ATTICA) << "error found" << code;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : urls) {
        if (url.isParentOf(reply->url())) {
            baseUrl = url;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Target &t : targetlist) {
        //m_editor->targets->insertItems(0, m_buildServices[current->data(Qt::UserRole).toString()].targets());
        m_editor->targets->insertItem(0, t.name, t.id);
        // FIXME: target id.
        qDebug() << "target:" << t.name << t.id;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](QNetworkReply::NetworkError code) {
                qCDebug(ATTICA) << "error found" << code;
            }
```

#### AUTO 


```{c}
const auto dependenciesList = newAchievement.dependencies();
```

#### RANGE FOR STATEMENT 


```{c}
for (const BuildService &bs : itemList) {
            m_buildServices[bs.id()] = bs;
            qDebug() << "New OBS:" << bs.id() << bs.name() << bs.url();
            output.append(QString(QLatin1String("<br />%1 (%2) at %3")).arg(bs.name(), bs.id(), bs.url()));
            QListWidgetItem *new_bs = new QListWidgetItem(bs.name(), m_editor->buildServices);
            new_bs->setData(Qt::UserRole, QVariant(bs.id()));

            m_editor->accountsServers->insertItem(0, bs.name(), bs.id());
            // QListWidgetItem* new_bsa = new QListWidgetItem(bs.name(), m_editor->accountsServers);
            // new_bsa->setData(Qt::UserRole, QVariant(bs.id()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &option : optionsList) {
        postParameters.insert(QString::fromLatin1("options[%1]").arg(QString::number(j++)), option);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl &url : providerFiles) {
        addProviderFile(url);
    }
```

#### AUTO 


```{c}
const auto height = attributes.value(QLatin1String("height"));
```

#### LAMBDA EXPRESSION 


```{c}
[](QNetworkReply::NetworkError code){
          qCDebug(ATTICA) << "error found" << code;
    }
```

#### AUTO 


```{c}
const auto width = attributes.value(QLatin1String("width"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_errorReceived = true;
        m_eventloop->quit();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &string : stringList) {
        if (str == string) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Distribution &distribution : distributions) {
        distributionIds.append(QString::number(distribution.id()));
    }
```

#### AUTO 


```{c}
const auto &string
```

#### AUTO 


```{c}
const auto dependenciesList = achievement.dependencies();
```

