#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : shapesInArea) {
            QRectF sr = itemRect(s);
            sr.moveLeft(area.right());
            newlayout[s] = sr;
            debugChartLayout<<"shift in area:"<<dbg(s)<<sr;
            area.setRight(sr.left() - m_spacing.x());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ConfigSubWidgetBase *w : findChildren<ConfigSubWidgetBase*>()) {
        w->open(chart);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
```

#### AUTO 


```{c}
const auto controller = canvasController();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sRegion : substrings) {

        // check for a named area first
        const Region namedAreaRegion = namedAreaManager()->namedArea(sRegion);
        if (namedAreaRegion.isValid()) {
            res.add(namedAreaRegion, sheet);
            continue;
        }

        // Single cell or cell range
        int delimiterPos = sRegion.indexOf(':');
        if (delimiterPos > -1) {
            // range
            QString sUL = sRegion.left(delimiterPos);
            QString sLR = sRegion.mid(delimiterPos + 1);

            SheetBase* firstSheet = filterSheetName(sUL);
            SheetBase* lastSheet = filterSheetName(sLR);
            // TODO: lastSheet is silently ignored if it is different from firstSheet

            // Still has the sheet name separator?
            if (sUL.contains('!') || sLR.contains('!'))
                return res;

            if (!firstSheet)
                firstSheet = sheet;
            if (!lastSheet)
                lastSheet = sheet;

            // TODO: shouldn't use Region::Point, the cell name needs to be moved elsewhere
            Region::Point ul(sUL);
            Region::Point lr(sLR);

            if (ul.isValid() && lr.isValid()) {
                QRect range = QRect(ul.pos(), lr.pos());
                res.add(range, firstSheet);
            } else if (ul.isValid()) {
                res.add(ul.pos(), firstSheet);
            } else { // lr.isValid()
                res.add(lr.pos(), firstSheet);
            }
        } else {
            // single cell
            SheetBase* targetSheet = filterSheetName(sRegion);
            // Still has the sheet name separator?
            if (sRegion.contains('!'))
                return res;
            if (!targetSheet) targetSheet = sheet;
            Region::Point pt(sRegion);
            res.add(pt.pos(), targetSheet);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString k : m_userfields.keys()) {
            if (lst.first().startsWith(k)) {
                field = m_userfields[k];
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ConfigSubWidgetBase *w : findChildren<ConfigSubWidgetBase*>()) {
            w->deactivate();
        }
```

#### AUTO 


```{c}
auto root = static_cast<QSGTransformNode*>(node);
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : shapes) {
        // There exists a problem on msvc with for(each) and QVector<QPointF>
        QVector<QPointF> points(pointsFromShape(shape));
        for (int i = 0; i < points.count(); ++i) {
            const QPointF point(points[i]);
            if (rect.contains(point))
                result.append(point);
        }
    }
```

#### AUTO 


```{c}
auto m = map();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QList<KoShape*> &list) {
                selectionChanged(list);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->returnPressed(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &ranges : d->unfinalizedRanges.values()) {
        for (KoTextRange *range : ranges) {
            range->finalizePosition();
            insert(range);
        }
    }
```

#### AUTO 


```{c}
const auto &leftId = left.templateId.isEmpty() ? left.id : left.templateId;
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : project.allCalendars()) {
        Calendar *calendar = m_project->findCalendar(c->id());
        if (calendar) {
            if (!calendar->isShared()) {
                // User has probably created shared resources from this project,
                // so the calendar exists but are local ones.
                // Convert to shared and do not load the resource from shared.
                removecalendars << c;
                calendar->setShared(true);
                debugPlanShared<<"Set calendar to shared:"<<calendar<<calendar->id();
            }
            *calendar = *c;
            debugPlanShared<<"Updated calendar:"<<calendar<<calendar->id();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : charsetToCodec) {
	        if (entry.id == value) {
	            m_fontTableEntry.setCodec(QTextCodec::codecForName(entry.name));
	            break;
	        }
	    }
```

#### AUTO 


```{c}
auto it = list.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Function* function : checkedFunctions) {
                // It is okay to recreate the shared pointers, as they were not used.
                d->functions.append(QSharedPointer<Function>(function));
            }
```

#### AUTO 


```{c}
auto viewRect = d->paCanvas->viewConverter()->documentToView(pageRect).toRect();
```

#### AUTO 


```{c}
auto paPage = dynamic_cast<KoPAPage*> (page);
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *a : d->plotArea->axes()) {
        a->plotAreaChartTypeChanged(chartType);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->noMatchFound(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : shapes) {
        d->shape = dynamic_cast<ChartShape*>(s);
    }
```

#### AUTO 


```{c}
auto deleter = [this](KoGenStyle *ptr) { delete ptr; m_currentFontStyle = nullptr; };
```

#### AUTO 


```{c}
const auto &docIndex
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharedSubStyle& subStyle : style.subStyles()) {
            bool foundShared = false;
            typedef const QList< SharedSubStyle> StoredSubStyleList;
            StoredSubStyleList& storedSubStyles(d->subStyles.value(subStyle->type()));
            StoredSubStyleList::ConstIterator end(storedSubStyles.end());
            for (StoredSubStyleList::ConstIterator it(storedSubStyles.begin()); it != end; ++it) {
                if (Style::compare(subStyle.data(), (*it).data())) {
        //             debugSheetsStyle <<"[REUSING EXISTING SUBSTYLE]";
                    subStyles.append(qMakePair(reg, *it));
                    foundShared = true;
                    break;
                }
            }
            if (!foundShared) {
                // insert substyle and add to the used substyle list
                //if (reg.contains(QPoint(1,1))) {debugSheetsStyle<<"load:"<<reg<<':'; subStyle.data()->dump();}
                subStyles.append(qMakePair(reg, subStyle));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *shape : m_shapes) {
            QRectF r = shape->boundingRect();
            if (r.left() > middle.x()) {
                // to the right
                m_rightX << shape;
            } else if (r.right() >= middle.x()) {
                // overlaps
                m_overlapX << shape;
            }
            if (r.top() > middle.y()) {
                // below
                m_belowY << shape;
            } else if (r.bottom() >= middle.y()) {
                // overlaps
                m_overlapY << shape;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int id, KoRuler::Tab *tab) { d->tabChanged(id, tab); }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataSet *ds : m_chart->proxyModel()->dataSets()) {
        CellRegion region = ds->xDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiScatter<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->yDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiScatter<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->customDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
        region = ds->categoryDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
        region = ds->labelDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto texture = window()->createTextureFromImage(*d->zoomProxy);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : field->columns) {
                QString value = field->headerData(name);
                writer.startElement("table:table-cell");
                writer.addAttribute("office:value-type", "string");
                writer.startElement("text:p");
                writer.addTextNode(value);
                writer.endElement();
                writer.endElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : project.resourceList()) {
        Resource *resource = m_project->findResource(r->id());
        if (resource) {
            resource->setName(r->name());
            resource->setInitials(r->initials());
            resource->setEmail(r->email());
            resource->setType(r->type());
            resource->setAutoAllocate(r->autoAllocate());
            resource->setAvailableFrom(r->availableFrom());
            resource->setAvailableUntil(r->availableUntil());
            resource->setUnits(r->units());
            resource->setNormalRate(r->normalRate());
            resource->setOvertimeRate(r->overtimeRate());

            QString id = r->calendar(true) ? r->calendar(true)->id() : QString();
            resource->setCalendar(m_project->findCalendar(id));

            id = r->account() ? r->account()->name() : QString();
            resource->setAccount(m_project->accounts().findAccount(id));

            resource->setRequiredIds(r->requiredIds());

            resource->setTeamMemberIds(r->teamMemberIds());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int level) { d->styleChanged(level); }
```

#### AUTO 


```{c}
auto store = std::unique_ptr<KoStore>(KoStore::createStore(&buffer/*file*/, KoStore::Write, mimeType, backend));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &text) {
                        d->cellEditor->setText(text);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiScatter<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape* s : d->shapes) {
        if (dynamic_cast<ShapeApplicationData*>(s->applicationData())->isAnchoredToCell()) {
            if (s->position().x() >= minX && s->position().x() < maxX) {
                QPointF p = s->position();
                p.setX(qMax(minX, p.x() + delta));
                s->setPosition(p);
            }
        }
    }
```

#### AUTO 


```{c}
const auto styleAttributes = additionalStyleAttributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : sortedShapes) {
                    QRectF r(itemRect(s));
                    if (r.intersects(area)) {
                        r.moveRight(area.right());
                        newlayout[s] = r;
                        debugChartLayout<<"Move right:"<<dbg(s)<<r;
                        area.setRight(r.left() - m_spacing.y());
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int v) { d_func()->angleDeltaChanged(v); }
```

#### AUTO 


```{c}
auto layer = dynamic_cast<KoShapeLayer*> (masterShapes.last());
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase* sheet : map->sheetList()) {
        Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
        QDomElement e = saveSheet (fullSheet, doc);
        if (e.isNull())
            return e;
        mymap.appendChild(e);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : map) {
        Q_ASSERT(!idx.parent().isValid()); // must be flat
        m->removeRow(idx.row(), idx.parent());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(QToolButton *tb : tblst) {
        tw.horizontalLayout->insertWidget( i++, tb );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sheet *sheet : sheets) {
        SheetPrint *const pageManager = sheet->print();
        if (*sheetPageNumber <= pageManager->pageCount())
            return sheet;
        *sheetPageNumber -= pageManager->pageCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : p.resourceList()) {
                    Resource *res = m_project->resource(r->id());
                    if (res && res->isShared()) {
                        Appointment *app = new Appointment();
                        app->setAuxcilliaryInfo(p.name());
                        for (const Appointment *a : r->appointments(sm->scheduleId())) {
                            *app += *a;
                        }
                        if (app->isEmpty()) {
                            delete app;
                        } else {
                            res->addExternalAppointment(p.id(), app);
                            debugPlanShared<<res->name()<<"added:"<<app->auxcilliaryInfo()<<app;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : project.resourceGroups()) {
        ResourceGroup *group = m_project->findResourceGroup(g->id());
        if (group) {
            group->setName(g->name());
            group->setType(g->type());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QSize sz) {
        d->canvasController->proxyObject->updateDocumentSize(sz);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : removedResources) {
                r->setShared(false);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CellBase &c : consumers) {
        generateDepths(c, computedDepths);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *element : d->cells) {
        cellRects.append(element->rect());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : m_project->resourceList()) {
        if (r->isShared() && !project.findResource(r->id())) {
            removedResources << r;
            removed << i18n("Resource: %1", r->name());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int a, const QVariant &b) {
                d->resourceChanged(a, b);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : m_selectedShapes) {
        if (m_chartShapes.contains(s)) {
            m_chartShapes[s]->createCommand(cmd);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TemplateAction &templateAction : koAsConst(m_templateActions)) {
        connect(templateAction.action, &QAction::triggered, this, [this, templateAction] { insert(templateAction.data); });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ItemModelBase *m : m_basemodels) {
        m->setProject(m_project);
        m->setScheduleManager(m_manager);
        if (qobject_cast<ChartItemModel*>(m)) {
            qobject_cast<ChartItemModel*>(m)->setNodes(QList<Node*>() << m_project);
            dbgRGChart<<"chart:"<<m_project<<m_manager<<"set nodes"<<m_project;
        }
    }
```

#### AUTO 


```{c}
auto comp = [](KoTextRange *r, int value) {
            return r->rangeStart() <= value;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for(KoCharacterStyle *style: m_draftCharStyleList) {
        removeCharacterStyle(style);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int value) { d->sliderValueChanged(value); }
```

#### RANGE FOR STATEMENT 


```{c}
for (FunctionDescription* description : d->descriptions) {
        if (group.isNull() || (description->group() == group))
            lst.append(description->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPluginLoader *loader : offers) {

        QJsonObject metaData = loader->metaData().value("MetaData").toObject();
        int version = metaData.value("X-CalligraSheets-InterfaceVersion").toInt();
        if (version != 0) {
            debugSheetsFormula << "Skipping" << loader->fileName() << ", because interface version is" << version;
            continue;
        }
        QJsonObject pluginData = metaData.value("KPlugin").toObject();
        QString category = pluginData.value("Category").toString();
        if (category != "FunctionModule") {
            debugSheetsFormula << "Skipping" << loader->fileName() << ", because category is " << category;
            continue;
        }

        const QString pluginId = pluginData.value("Id").toString();
        const QString pluginConfigEnableKey = pluginId + QLatin1String("Enabled");
        const bool isPluginEnabled = pluginsConfigGroup.hasKey(pluginConfigEnableKey) ?
            pluginsConfigGroup.readEntry(pluginConfigEnableKey, true) :
            pluginData.value("EnabledByDefault").toBool(true);

        if (isPluginEnabled) {
            if(contains(pluginId)) {
                continue;
            }
            // Plugin enabled, but not registered. Add it.
            KPluginFactory* const factory = qobject_cast<KPluginFactory *>(loader->instance());
            if (!factory) {
                debugSheetsFormula << "Unable to create plugin factory for" << loader->fileName();
                continue;
            }
            FunctionModule* const module = factory->create<FunctionModule>();
            if (!module) {
                debugSheetsFormula << "Unable to create function module for" << loader->fileName();
                continue;
            }

            add(pluginId, module);
            debugSheetsFormula << "Loaded" << pluginId;

            // Delays the function registration until the user needs one.
            if (d->repositoryInitialized) {
                d->registerFunctionModule(module);
            }
        } else {
            if (!contains(pluginId)) {
                continue;
            }
            // Plugin disabled, but registered. Remove it.
            FunctionModule* const module = get(pluginId);
            // Delay the function registration until the user needs one.
            if (d->repositoryInitialized) {
                d->removeFunctionModule(module);
            }
            remove(pluginId);
            if (module->isRemovable()) {
                delete module;
                KPluginFactory* factory = qobject_cast<KPluginFactory *>(loader->instance());
                delete factory;
                loader->unload();
            } else {
                // Put it back in.
                add(pluginId, module);
                // Delay the function registration until the user needs one.
                if (d->repositoryInitialized) {
                    d->registerFunctionModule(module);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &oldname : m_uiFiles) {
            QString newname = oldname;
            newname.replace(m_oldAppName, m_newAppName);
            if (oldname == newname) {
                continue;
            }
            const QString oldfile = newui + QLatin1Char('/') + oldname;
            QFile f(oldfile);
            if (f.exists()) {
                const QString newfile = newui + QLatin1Char('/') + newname;
                f.rename(newfile);
                didSomething = true;
                QFileInfo fi(f);
                qCDebug(CALLIGRA2MIGRATION)<<"ui renamed:"<<oldfile<<"->"<<fi.filePath();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : removedResources) {
                RemoveResourceCmd cc(r->parentGroup(), r);
                cc.execute();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* bsheet : m_map->sheetList()) {
        Sheet *sheet = dynamic_cast<Sheet *>(bsheet);
        t.append(sheet->objectName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape* s : d->shapes) {
        if (dynamic_cast<ShapeApplicationData*>(s->applicationData())->isAnchoredToCell()) {
            if (s->position().y() >= minY && s->position().y() < maxY) {
                QPointF p = s->position();
                p.setY(qMax(minY, p.y() + delta));
                s->setPosition(p);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pluginPath) {
        debugPlugin << "Trying to load" << pluginPath;
        QPluginLoader *loader = new QPluginLoader(pluginPath);
        QJsonObject metaData = loader->metaData().value("MetaData").toObject();

        if (metaData.isEmpty()) {
            debugPlugin << pluginPath << "has no MetaData!";
            return;
        }

        if (!mimeType.isEmpty()) {
            QJsonObject pluginData = metaData.value("KPlugin").toObject();
            QStringList mimeTypes = pluginData.value("MimeTypes").toVariant().toStringList();
            mimeTypes += metaData.value("X-KDE-ExtraNativeMimeTypes").toVariant().toStringList();
            mimeTypes += metaData.value("X-KDE-NativeMimeType").toString();
            if (! mimeTypes.contains(mimeType)) {
                return;
            }
        }

        list.append(loader);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &p : field->properties) {
                if (p.startsWith("values")) {
                    QStringList vl = p.split("=");
                    Q_ASSERT(vl.count() > 1);
                    Q_ASSERT(vl.at(0) == "values");
                    for (const QString &v : vl.at(1).split(',')) {
                        values << v.toLower().trimmed();
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : allShapes) {
        if (! shape->isVisible(true))
            continue;
        if (ignoredShapes.contains(shape))
            continue;

        filteredShapes.append(shape);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[sortKeys] (KoInlineCite *c1, KoInlineCite *c2) {
        return compare_on(sortKeys, 0, c1, c2);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool) { d->optionChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiScatter<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### DECLTYPE 


```{c}
typedef typeof(((elf_aux_entry*) 0)->a_un.a_val) elf_aux_val_t;
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : shapes) {
        d->shape = dynamic_cast<ChartShape*>(s);
        if (!d->shape) {
            for (KoShape *parent = s->parent(); parent; parent = parent->parent()) {
                d->shape = dynamic_cast<ChartShape*>(parent);
                if (d->shape) {
                    break;
                }
            }
        }
        if (d->shape) {
            break;
        }
    }
```

#### AUTO 


```{c}
const auto &rightId = right.templateId.isEmpty() ? right.id : right.templateId;
```

#### LAMBDA EXPRESSION 


```{c}
[this](QAction *action, const QKeySequence &seq) {
            if (action != m_action) {
                return;
            }
            setKeySequence(seq);
        }
```

#### AUTO 


```{c}
auto res = d->hidden.search(row, v, firstRow, lastRow);
```

#### AUTO 


```{c}
auto subs = style.subStyles();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KoShapeLayer *layer) {
                currentLayerChanged(layer);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->copy(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : m_project->resourceGroups()) {
        if (g->isShared() && !project.findResourceGroup(g->id())) {
            removedGroups << g;
            removed << i18n("Group: %1", g->name());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : shapes) {
        KoPathShape * path = dynamic_cast<KoPathShape*>(shape);
        if (! path) {
            continue;
        }
        QTransform matrix = path->absoluteTransformation(0);

        const int subpathCount = path->subpathCount();
        for (int subpathIndex = 0; subpathIndex < subpathCount; ++subpathIndex) {
            if (path->isClosedSubpath(subpathIndex))
                continue;

            int pointCount = path->subpathPointCount(subpathIndex);

            // check the extension from the start point
            KoPathPoint * first = path->pointByIndex(KoPathPointIndex(subpathIndex, 0));
            QPointF firstSnapPosition = mousePosition;
            if (snapToExtension(firstSnapPosition, first, matrix)) {
                qreal distance = squareDistance(firstSnapPosition, mousePosition);
                if (distance < maxDistance) {
                    if (distance < minDistances[0]) {
                        minDistances[1] = minDistances[0];
                        snappedPoints[1] = snappedPoints[0];
                        startPoints[1] = startPoints[0];

                        minDistances[0] = distance;
                        snappedPoints[0] = firstSnapPosition;
                        startPoints[0] = matrix.map(first->point());
                    }
                    else if (distance < minDistances[1]) {
                        minDistances[1] = distance;
                        snappedPoints[1] = firstSnapPosition;
                        startPoints[1] = matrix.map(first->point());
                    }
                }
            }

            // now check the extension from the last point
            KoPathPoint * last = path->pointByIndex(KoPathPointIndex(subpathIndex, pointCount - 1));
            QPointF lastSnapPosition = mousePosition;
            if (snapToExtension(lastSnapPosition, last, matrix)) {
                qreal distance = squareDistance(lastSnapPosition, mousePosition);
                if (distance < maxDistance) {
                    if (distance < minDistances[0]) {
                        minDistances[1] = minDistances[0];
                        snappedPoints[1] = snappedPoints[0];
                        startPoints[1] = startPoints[0];

                        minDistances[0] = distance;
                        snappedPoints[0] = lastSnapPosition;
                        startPoints[0] = matrix.map(last->point());
                    }
                    else if (distance < minDistances[1]) {
                        minDistances[1] = distance;
                        snappedPoints[1] = lastSnapPosition;
                        startPoints[1] = matrix.map(last->point());
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (LayoutData *data: m_layoutItems)
        delete data;
```

#### AUTO 


```{c}
auto texture = window()->createTextureFromImage(d->data);
```

#### RANGE FOR STATEMENT 


```{c}
for (BaseStorage *storage : storages)
        storage->storeUndo(true);
```

#### AUTO 


```{c}
auto it = m_colors.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (ConfigObjectBase *w : findChildren<ConfigObjectBase*>()) {
        w->updateData(d->type, d->subtype);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : lst) {
        ChartShape *chart = dynamic_cast<ChartShape*>(s);
        if (chart && chart != d->shape) {
            activateTool(KoInteractionTool_ID);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const CellBase &cell : depths.keys()) {
        QString cellName = cell.name();
        while (cellName.count() < 4) cellName.prepend(' ');
        debugSheetsFormula << "depth(" << cellName << " ) =" << depths[cell];
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appointment *a : r->appointments()) {
                        Appointment *app = new Appointment(*a);
                        app->setAuxcilliaryInfo(p.name());
                        res->addExternalAppointment(p.id(), app);
                        debugPlan<<res->name()<<"added:"<<app->auxcilliaryInfo()<<app;
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ModelDepthProfile& dstCS : listModels) {
            QVERIFY2(KoColorSpaceRegistry::instance()->colorConversionSystem()->existsPath(srcCS.model, srcCS.depth, srcCS.profile, dstCS.model, dstCS.depth, dstCS.profile) , QString("No path between %1 / %2 and %3 / %4").arg(srcCS.model).arg(srcCS.depth).arg(dstCS.model).arg(dstCS.depth).toLatin1());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : sortedShapes) {
                QRectF r(itemRect(s));
                if (r.intersects(area)) {
                    r.moveLeft(area.left());
                    newlayout[s] = r;
                    area.setLeft(r.right() + m_spacing.x());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : project.resourceList()) {
        r->setShared(true);
    }
```

#### AUTO 


```{c}
auto it = rowStyles.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { itemSelected(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectedRows()) {
        QString name = model->index(idx.row(), 0).data().toString();
        QString tmp = model->index(idx.row(), 1).data(FULLPATHROLE).toString();
        QString file = model->index(idx.row(), 2).data().toString();
        if (tmp.isEmpty()) {
            QMessageBox::information(this, xi18nc("@title:window", "Generate Report"),
                                     i18n("Failed to generate %1."
                                          "\nTemplate file name is empty.", name));
            continue;
        }
        if (file.isEmpty()) {
            debugPlan<<"No files for report:"<<name<<tmp<<file;
            QMessageBox::information(this, xi18nc("@title:window", "Generate Report"),
                                     i18n("Failed to generate %1."
                                          "\nReport file name is empty.", name));
            continue;
        }
        QString addition = model->index(idx.row(), 3).data(Qt::UserRole).toString();
        if (addition == "Date") {
            int dotpos = file.lastIndexOf('.');
            QString date = QDate::currentDate().toString();
            file = file.insert(dotpos, date.prepend('-'));
        } else if (addition == "Number") {
            int dotpos = file.lastIndexOf('.');
            QString fn = file;
            for (int i = 1; QFile::exists(fn); ++i) {
                fn = file.insert(dotpos, QString::number(i).prepend('-'));
            }
            file = fn;
        }
        // warn if file exists
        if (QFile::exists(QUrl(file).path())) {
            if (QMessageBox::question(this, i18n("Report Generation"), i18n("File exists. Continue?")) == QMessageBox::No) {
                return;
            }
        }
        generateReport(tmp, file);
    }
```

#### AUTO 


```{c}
auto deleter = [this](XlsxCellFormat *ptr) { delete ptr; m_currentCellFormat = nullptr; };
```

#### RANGE FOR STATEMENT 


```{c}
for(Calligra::Sheets::SheetBase* sheet : kspreadDoc()->map()->sheetList()) {
        names.append(sheet->sheetName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *sheet : d->lstSheets)
        delete sheet;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appointment *a : r->appointments(sm->scheduleId())) {
                            Appointment *app = new Appointment(*a);
                            app->setAuxcilliaryInfo(p.name());
                            res->addExternalAppointment(p.id(), app);
                            debugPlan<<res->name()<<"added:"<<app->auxcilliaryInfo()<<app;
                        }
```

#### AUTO 


```{c}
auto it = values.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractCondition* c : list) {
        if (!c) {
            continue;
        } else if (c->type() == AbstractCondition::And) {
            out.append(new Filter::And(*static_cast<Filter::And*>(c)));
        } else if (c->type() == AbstractCondition::Or) {
            out.append(new Filter::Or(*static_cast<Filter::Or*>(c)));
        } else {
            out.append(new Filter::Condition(*static_cast<Filter::Condition*>(c)));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KoResource *res, const QString &tag) { Q_UNUSED(res); onTriggered(tag); }
```

#### AUTO 


```{c}
auto it = cellStyles.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->updateCanvas(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(QAction *a : lst) {
        tb->addAction( a );
        connect( a, SIGNAL(triggered(bool)), SLOT(slotInsertAction()) );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : lst) {
        if (!shared.calendar(c->id())) {
            result << c;
        }
        result += sortedRemoveCalendars(shared, c->calendars());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroupRequest *r : t->requests().requests()) {
            RemoveResourceGroupRequestCmd *c = new RemoveResourceGroupRequestCmd(r);
            c->execute(); // need to remove everyting before we add anything
            cmd->addCommand(c);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Account *a : project.accounts().accountList()) {
        debugPlanShared<<"Project not empty, delete account:"<<a<<a->name();
        RemoveAccountCmd cmd(project, a);
        cmd.execute();
    }
```

#### AUTO 


```{c}
auto it = columnStyles.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : project.allCalendars()) {
        c->setShared(true);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { emit changedTool(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : map->sheetList()) {
            Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
            loadSheetSettings(fullSheet, sheetsMap);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : m_project->resourceList()) {
        if (!project.findResource(r->id())) {
            removedResources << r;
            removed << "Resource: " + r->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : removedCalendars) {
        removed << i18n("Calendar: %1", c->name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CostPlace *cp : m_costPlaces) {
        if (cp->node() == &node && cp->running()) {
            return cp;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoCharacterStyle* style : sharedData->characterStyles(false)) {
        fixupStyle(style);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoCanvasController* c) {
                d->detachCanvas(c);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { showPageStyle(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { cleanupImageCache(); }
```

#### AUTO 


```{c}
auto i = d->visibilityCodes.constBegin() ;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString k : keys) {
        if (key.startsWith(k)) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataSet *ds : m_chart->proxyModel()->dataSets()) {
        CellRegion region = ds->xDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiScatter<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->yDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiScatter<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->customDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
        region = ds->categoryDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
        region = ds->labelDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& errorLine : errorLines) {
                writer.startElement("text:p");
                writer.addTextNode(errorLine);
                writer.endElement();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const TRegion& tr : m_data) {
        const Region& reg = tr.first;
        const T& d = tr.second;

        int index = m_storage->m_storedData.indexOf(d);
        if (index != -1) {
            treeData.append(qMakePair(reg, m_storage->m_storedData[index]));
        } else {
            treeData.append(tr);
            m_storage->m_storedData.append(d);
        }
    }
```

#### AUTO 


```{c}
auto kwdocument = qobject_cast<KWDocument*>(document);
```

#### AUTO 


```{c}
auto res = d->hasPageBreak.search(row, v, firstRow, lastRow);
```

#### AUTO 


```{c}
auto layout = d->page->pageLayout();
```

#### AUTO 


```{c}
_cimg_constructor_cpp11(siz>values.size())
```

#### RANGE FOR STATEMENT 


```{c}
for (ConfigSubWidgetBase *w : findChildren<ConfigSubWidgetBase*>()) {
        w->updateData(d->type, d->subtype);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : shapes) {
        // There exists a problem on msvc with for(each) and QVector<QPointF>
        QVector<QPointF> points(pointsFromShape(shape));
        for (int i = 0; i < points.count(); ++i) {
            const QPointF point(points[i]);
            if (rect.contains(point))
                points.append(point);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& missingDescription : missingDescriptions) {
                debugSheetsUI << "\t" << missingDescription;
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->toggleCollapsed(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *axis : plotarea->axes()) {
                KoShape *title = axis->title();
                title->rotate(-title->rotation());
                switch (axis->kchartAxisPosition()) {
                    case KChart::CartesianAxis::Left:
                        title->rotate(-90);
                        break;
                    case KChart::CartesianAxis::Right:
                        title->rotate(90);
                        break;
                    default:
                        break;
                }
            }
```

#### AUTO 


```{c}
const auto stats = doc.statistics();
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : project.resourceGroups()) {
        ResourceGroup *group = m_project->findResourceGroup(g->id());
        if (group) {
            if (!group->isShared()) {
                // User has probably created shared resources from this project,
                // so the resources exists but are local ones.
                // Convert to shared and do not load the group from shared.
                removegroups << g;
                group->setShared(true);
                debugPlanShared<<"Set group to shared:"<<group<<group->id();
            }
            group->setName(g->name());
            group->setType(g->type());
            debugPlanShared<<"Updated group:"<<group<<group->id();
        }
    }
```

#### AUTO 


```{c}
auto itShape
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : shapes) {
        QVector<QPointF> points = proxy->pointsFromShape(shape);
        // There exists a problem on msvc with for(each) and QVector<QPointF>
        for (int i = 0; i < points.count(); ++i) {
            const QPointF point(points[i]);
            qreal dx = fabs(point.x() - mousePosition.x());
            if (dx < minHorzDist && dx < maxSnapDistance) {
                minHorzDist = dx;
                horzSnap = point;
            }
            qreal dy = fabs(point.y() - mousePosition.y());
            if (dy < minVertDist && dy < maxSnapDistance) {
                minVertDist = dy;
                vertSnap = point;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : resourceGroupIdDict) {
        g->blockChanged();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->replaceAll(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QWidget *old, QWidget *now) {
                d->movedFocus(old, now);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPair< QRectF, QUrl >& link : d->links )
    {
        QRectF hitTarget{
            link.first.x() - Private::wiggleFactor,
            link.first.y() - Private::wiggleFactor,
            link.first.width() + Private::wiggleFactor * 2,
            link.first.height() + Private::wiggleFactor * 2
        };

        if( hitTarget.contains( point ) )
        {
            return link.second;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->timeout(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : d->lstSheets) {
        if (returnNext) return sheet;
        if (sheet == currentSheet) returnNext = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *element : d->cells) {
        if (element->sheet() != sheet)
            continue;

        if (element->rect().intersects (normalizedRange)) {
            delete element;
            toRemove.push_back (element);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ConditionalFormat* cf : conditionals) {
        Calligra::Sheets::Region r;
        for (QRect rect : cf->region().translated(1, 1))
            r.add(rect, os);
        QLinkedList<Calligra::Sheets::Conditional> conds;
        foreach (const Conditional& c, cf->conditionals()) {
            Calligra::Sheets::Conditional kc;
            switch (c.cond) {
            case Conditional::None:
                kc.cond = Calligra::Sheets::Validity::None;
                break;
            case Conditional::Formula:
                kc.cond = Calligra::Sheets::Validity::IsTrueFormula;
                break;
            case Conditional::Between:
                kc.cond = Calligra::Sheets::Validity::Between;
                break;
            case Conditional::Outside:
                kc.cond = Calligra::Sheets::Validity::Different;
                break;
            case Conditional::Equal:
                kc.cond = Calligra::Sheets::Validity::Equal;
                break;
            case Conditional::NotEqual:
                kc.cond = Calligra::Sheets::Validity::DifferentTo;
                break;
            case Conditional::Greater:
                kc.cond = Calligra::Sheets::Validity::Superior;
                break;
            case Conditional::Less:
                kc.cond = Calligra::Sheets::Validity::Inferior;
                break;
            case Conditional::GreaterOrEqual:
                kc.cond = Calligra::Sheets::Validity::SuperiorEqual;
                break;
            case Conditional::LessOrEqual:
                kc.cond = Calligra::Sheets::Validity::InferiorEqual;
                break;
            }
            qCDebug(lcExcelImport) << "FRM:" << c.cond << kc.cond;
            kc.value1 = convertValue(c.value1);
            kc.value2 = convertValue(c.value2);
            kc.baseCellAddress = Swinder::encodeAddress(is->name(), cf->region().boundingRect().left(), cf->region().boundingRect().top());

            Calligra::Sheets::CustomStyle* style = new Calligra::Sheets::CustomStyle(QString("Excel-Condition-Style-%1").arg(styleNameId++));
            kc.styleName = style->name();

            // TODO: valueFormat
            if (c.hasFontItalic()) {
                style->setFontItalic(c.font().italic());
            }
            if (c.hasFontStrikeout()) {
                style->setFontStrikeOut(c.font().strikeout());
            }
            if (c.hasFontBold()) {
                style->setFontBold(c.font().bold());
            }
            // TODO: sub/superscript
            if (c.hasFontUnderline()) {
                style->setFontUnderline(c.font().underline());
            }
            if (c.hasFontColor()) {
                style->setFontColor(c.font().color());
            }
            // TODO: other properties

            styleManager->insertStyle(style);
            conds.append(kc);
        }
        Calligra::Sheets::Conditions kcs;
        kcs.setConditionList(conds);
        cellConditions.append(qMakePair(r, kcs));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sheet *sheet : d->sheets)
            sheetNames.append(sheet->sheetName());
```

#### RANGE FOR STATEMENT 


```{c}
for (KChart::AbstractCartesianDiagram *diag : diagrams) {
        diag->addAxis(kdAxis);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : lst) {
        QString r = s.trimmed();
        if (!r.isEmpty()) {
            rlst << r;

        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &v : vl.at(1).split(',')) {
                        values << v.toLower().trimmed();
                    }
```

#### AUTO 


```{c}
auto zoomHandler = static_cast<KoZoomHandler*>(canvas->viewConverter());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : dir.entryList(QStringList()<<"*.plan")) {
            QString path = dir.canonicalPath();
            if (path.isEmpty()) {
                continue;
            }
            path += '/' + f;
            QUrl u(path);
            u.setScheme("file");
            m_sharedProjectsFiles << u;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
```

#### AUTO 


```{c}
auto textImpl = new TextContentsModelImpl{d->document->koDocument(), dynamic_cast<KoCanvasBase*>(d->document->canvas())};
```

#### RANGE FOR STATEMENT 


```{c}
for (DataSet *dataSet : m_dataSets) {
        QString title = dataSet->labelData().toString();
        if (title.isEmpty()) {
            title = i18n("Data Set %1", dataSet->number());
        }
        m_ui.dataSets->addItem(title);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, styleId] { updateName(styleId); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int i) { horizPosChanged(i); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &regexp: subs_syl_regexp) {
                if (word.indexOf(regexp) != -1) {
                    word_syllables--;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool) { d->addToHistory(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *axis : plotarea->axes()) {
                KoShape *title = axis->title();
                title->rotate(-title->rotation());
                switch (axis->actualAxisPosition()) {
                    case KChart::CartesianAxis::Bottom:
                        title->rotate(verticalXAxis ? -90 : 0);
                        break;
                    case KChart::CartesianAxis::Top:
                        title->rotate(verticalXAxis ? -90 : 0);
                        break;
                    case KChart::CartesianAxis::Left:
                        title->rotate(verticalXAxis ? 0 : -90);
                        break;
                    case KChart::CartesianAxis::Right:
                        title->rotate(verticalXAxis ? 0 : 90);
                        break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (int col : m_columnFormats.keys()) {
            m_sheet->columnFormats()->setColFormat(col, col, m_columnFormats.value(col));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (ToolHelper *tool) { toolActivated(tool); }
```

#### AUTO 


```{c}
auto res = d->filtered.search(col, v, firstCol, lastCol);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : rows) {
            Node *node = m_view->baseModel()->node( idx );
            if (node) {
                switch ( node->type() ) {
                    case Node::Type_Task:
                        tasks << static_cast<Task*>(node); break;
                    case Node::Type_Milestone:
                        milestones << static_cast<Task*>(node); break;
                    case Node::Type_Summarytask:
                        summarytasks << static_cast<Task*>(node); break;
                    default: break;
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int i) { vertPosChanged(i); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->toggleTab(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : removedCalendars) {
                CalendarRemoveCmd cmd(m_project, c);
                cmd.redo();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : shapesInArea) {
            QRectF sr = itemRect(s);
            sr.moveTop(area.top());
            newlayout[s] = sr;
            debugChartLayout<<"shift in area:"<<dbg(s)<<sr;
            area.setTop(sr.bottom() + m_spacing.y());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->resetUndo();
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n :  project.childNodeIterator()) {
        delete n;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal t : d->extrema()) {
            if (t >= 0.0 && t <= 1.0) {
                QPointF p = pointAt(t);
                rect.setLeft(qMin(rect.left(), p.x()));
                rect.setRight(qMax(rect.right(), p.x()));
                rect.setTop(qMin(rect.top(), p.y()));
                rect.setBottom(qMax(rect.bottom(), p.y()));
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase* sheet : consumers.keys()) {
        const QList< QPair<QRectF, CellBase> > pairs = consumers[sheet]->intersectingPairs(QRect(1, 1, KS_colMax, KS_rowMax)).values();
        QHash<QString, QString> table;
        for (int i = 0; i < pairs.count(); ++i) {
            Region tmpRange(pairs[i].first.toRect(), sheet);
            table.insertMulti(tmpRange.name(), pairs[i].second.name());
        }
        for(const QString &uniqueKey : table.uniqueKeys()) {
            QStringList debugStr(table.values(uniqueKey));
            debugSheetsFormula << uniqueKey << " provides values for:" << debugStr.join(",");
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : shapes) {
        qreal shapeMinDistance = HUGE_VAL;
        // first check the corner and center points
        for (int i = 0; i < 5; ++i) {
            m_boxPoints[i] = shape->absolutePosition(pointId[i]);
            qreal d = squareDistance(mousePosition, m_boxPoints[i]);
            if (d < minDistance && d < maxDistance) {
                shapeMinDistance = d;
                minDistance = d;
                snappedPoint = m_boxPoints[i];
            }
        }
        // prioritize points over edges
        if (shapeMinDistance < maxDistance)
            continue;

        // now check distances to edges of bounding box
        for (int i = 0; i < 4; ++i) {
            QPointF pointOnLine;
            qreal d = squareDistanceToLine(m_boxPoints[i], m_boxPoints[(i+1)%4], mousePosition, pointOnLine);
            if (d < minDistance && d < maxDistance) {
                minDistance = d;
                snappedPoint = pointOnLine;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* bsheet : m_map->sheetList()) {
        Sheet *sheet = dynamic_cast<Sheet *>(bsheet);
        names.append(sheet->objectName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase* sheet : map->sheetList()) {
        for (int c = 0; c < sheet->formulaStorage()->count(); ++c, ++cellCurrent) {
            cell = CellBase(sheet, sheet->formulaStorage()->col(c), sheet->formulaStorage()->row(c));

            d->generateDependencies(cell, sheet->formulaStorage()->data(c));
            if (!sheet->formulaStorage()->data(c).isValid())
                cell.setValue(Value::errorPARSE());

            if (updater)
                updater->setProgress(int(qreal(cellCurrent) / qreal(cellsCount) * 50.));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : ac->actions()) {
        action->setShortcutContext(Qt::WidgetWithChildrenShortcut);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KoTextRange *r, int value) {
                return r->rangeStart() <= value;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QPersistentModelIndex &idx : m_tasks) {
        if (idx.isValid()) {
            lst << idx;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &c : field->headerNames) {
                field->columns << c;
            }
```

#### AUTO 


```{c}
auto currentFontStyleSetter = std::unique_ptr<KoGenStyle, decltype(deleter)>(m_currentFontStyle, deleter);
```

#### RANGE FOR STATEMENT 


```{c}
for (Calligra::Sheets::SheetBase* bsheet : m_doc->map()->sheetList()) {
            QImage thumbnail(thumbSize, QImage::Format_RGB32);
            thumbnail.fill(QColor(Qt::white).rgb());
            QPainter p(&thumbnail);

            KoPageLayout pageLayout;
            pageLayout.format = KoPageFormat::IsoA4Size;
            pageLayout.leftMargin = 0;
            pageLayout.rightMargin = 0;
            pageLayout.topMargin = 0;
            pageLayout.bottomMargin = 0;
            Calligra::Sheets::Sheet *sheet = dynamic_cast<Calligra::Sheets::Sheet *>(bsheet);
            sheet->printSettings()->setPageLayout(pageLayout);
            sheet->print()->setSettings(*sheet->printSettings(), true);

            Calligra::Sheets::SheetView sheetView(sheet);

            // only paint first page for now
            KoZoomHandler zoomHandler;
            KoPAUtil::setZoom(pageLayout, thumbSize, zoomHandler);
            sheetView.setViewConverter(&zoomHandler);

            QRect range(sheet->print()->cellRange(1));
            // paint also half cells on page edge
            range.setWidth(range.width() + 1);
            sheetView.setPaintCellRange(range); // first page

            QRect pRect(KoPAUtil::pageRect(pageLayout, thumbSize, zoomHandler));

            p.setClipRect(pRect);
            p.translate(pRect.topLeft());
            sheetView.paintCells(p, QRect(0, 0, pageLayout.width, pageLayout.height), QPointF(0, 0));

            const Qt::LayoutDirection direction = sheet->layoutDirection();

            KoShapePainter shapePainter(direction == Qt::LeftToRight ? (KoShapeManagerPaintingStrategy *)0 : (KoShapeManagerPaintingStrategy *)0 /*RightToLeftPaintingStrategy(shapeManager, d->canvas)*/);
            shapePainter.setShapes(sheet->shapes());
            shapePainter.paint(p, zoomHandler);

            thumbnails.append(thumbnail);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : project.resourceGroups()) {
        g->setShared(true);
    }
```

#### AUTO 


```{c}
auto type = Global::documentType(source);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : m_project->resourceList()) {
        r->clearExternalAppointments();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : removeresources) {
        debugPlanShared<<"Delete resource:"<<r<<r->id();
        RemoveResourceCmd cmd(r->parentGroup(), r);
        cmd.execute();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CellBase &c : consumers)
        removeDepths(c);
```

#### AUTO 


```{c}
auto controller = new ComponentsKoCanvasController{new KActionCollection{this}};
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : m_snapGuide->ignoredShapes()) {
        int index = shapes.indexOf(shape);
        if (index >= 0)
            shapes.removeAt(index);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->sliderReleased(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Sheet *sheet) { setActiveSheet(sheet); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSet<KoTextRange*> &docRanges: d->m_textRanges.values()) {
        allRanges.append(docRanges.values());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : map()->sheetList()) {
        for (int i = first; i <= last; ++i) {
            QPoint p = isColumn ? QPoint(rect.left(), i) : QPoint(i, rect.top());
            sheet->changeNameCellRef(p, fullRowOrColumn, ref, sheetName(), number);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, index] { pixmapReady(index); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : m_next.keys()) {
        m_next[s] = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : removedGroups) {
                if (g->resources().isEmpty()) {
                    g->setShared(false);
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int key, const QVariant &value) {
        Q_UNUSED(value);
        d->canvasResourceChanged(key);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiBubble<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : removedGroups) {
                g->setShared(false);
                m_project->removeResourceGroupId(g->id());
                g->setId(m_project->uniqueResourceGroupId());
                m_project->insertResourceGroupId(g->id(), g);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KWFrameSet *fs) {
        KWTextFrameSet *tfs = qobject_cast<KWTextFrameSet*>(fs);
        if (tfs)
            connect(tfs->document(), &QTextDocument::contentsChanged, d->timer, QOverload<>::of(&QTimer::start));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->toggleFloating(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QSize sz) { Q_UNUSED(sz); setAvailableSize(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectedRows()) {
        QString name = model->index(idx.row(), 0).data().toString();
        QString tmp = model->index(idx.row(), 1).data(FULLPATHROLE).toString();
        QString file = model->index(idx.row(), 2).data().toString();
        if (tmp.isEmpty()) {
            QMessageBox::information(this, xi18nc("@title:window", "Generate Report"),
                                     i18n("Failed to generate %1."
                                          "\nTemplate file name is empty.", name));
            continue;
        }
        if (file.isEmpty()) {
            debugPlan<<"No files for report:"<<name<<tmp<<file;
            QMessageBox::information(this, xi18nc("@title:window", "Generate Report"),
                                     i18n("Failed to generate %1."
                                          "\nReport file name is empty.", name));
            continue;
        }
        QString addition = model->index(idx.row(), 3).data(Qt::UserRole).toString();
        if (addition == "Date") {
            int dotpos = file.lastIndexOf('.');
            QString date = QDate::currentDate().toString();
            file = file.insert(dotpos, date.prepend('-'));
        } else if (addition == "Number") {
            int dotpos = file.lastIndexOf('.');
            QString fn = file;
            for (int i = 1; QFile::exists(fn); ++i) {
                fn = file.insert(dotpos, QString::number(i).prepend('-'));
            }
            file = fn;
        }
        generateReport(tmp, file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *axis : plotarea->axes()) {
                KoShape *title = axis->title();
                title->rotate(-title->rotation());
                switch (axis->actualAxisPosition()) {
                    case KChart::CartesianAxis::Left:
                        title->rotate(-90);
                        break;
                    case KChart::CartesianAxis::Right:
                        title->rotate(90);
                        break;
                    default:
                        break;
                }
            }
```

#### AUTO 


```{c}
auto currentCellFormatSetter = std::unique_ptr<XlsxCellFormat, decltype(deleter)>(m_currentCellFormat, deleter);
```

#### AUTO 


```{c}
auto it = d->csMap.find(idsToCacheName(csID, profileName));
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool v) { d->topLevelChanged(v); }
```

#### AUTO 


```{c}
const auto &docIndex = d->indexes.value(doc).value(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiScatter<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : sortedShapes) {
                QRectF r(itemRect(s));
                if (r.intersects(area)) {
                    r.moveBottom(area.bottom());
                    newlayout[s] = r;
                    area.setBottom(r.top() - m_spacing.y());
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : map->sheetList()) {
        for (int c = 0; c < sheet->formulaStorage()->count(); ++c, ++cellCurrent) {
            cell = CellBase(sheet, sheet->formulaStorage()->col(c), sheet->formulaStorage()->row(c));

            if (!d->depths.contains(cell)) {
                int depth = d->computeDepth(cell);
                d->depths.insert(cell , depth);
            }

            if (updater)
                updater->setProgress(50 + int(qreal(cellCurrent) / qreal(cellsCount) * 50.));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const Sheet *sheet : d->sheetViews.keys()) {
        disconnect(sheet, &QObject::destroyed, this, &View::sheetDestroyed);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->insertRows(position, number);
```

#### AUTO 


```{c}
auto res = d->hidden.search(col, v, firstCol, lastCol);
```

#### AUTO 


```{c}
auto doc = textRange->document();
```

#### RANGE FOR STATEMENT 


```{c}
for (QString format : d->timeFormats) {
        res = readTime(str, format, ok);
        if (*ok) return res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool v) { d->selectionChanged(v); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ModelDepthProfile& dstCS : listModels) {
            QByteArray name = QString("Path: %1/%2 to %3/%4").arg(srcCS.model).arg(srcCS.depth).arg(dstCS.model).arg(dstCS.depth).toLocal8Bit();
            QTest::newRow(name) << srcCS.model << srcCS.depth << srcCS.profile << dstCS.model << dstCS.depth << dstCS.profile << true;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QSizeF &sz) {
                    d->zoomController->setDocumentSize(sz);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : removedResources) {
                r->setShared(false);
                m_project->removeResourceId(r->id());
                r->setId(m_project->uniqueResourceId());
                m_project->insertResourceId(r->id(), r);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const RectBoolPair& pair : pairs) {
        if (pair.first.isNull())
            continue;
        if (pair.second == false)
            continue;
        // more than just the master cell in the region?
        const QPoint topLeft = pair.first.toRect().topLeft();
        if (pair.first.width() >= 1) {
            if (region.contains(topLeft + QPoint(1, 0), d->sheet))
                return true;
        }
        if (pair.first.height() >= 1) {
            if (region.contains(topLeft + QPoint(0, 1), d->sheet))
                return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *shape : m_chart->shapes()) {
            if (!shape->isVisible()) {
                continue;
            }
            if (shape->shapeId() == "ChartShapePlotArea") {
                // Plot area shall be resized
                m_plotArea = shape;
                m_plotAreaStartSize = shape->size();
                rect = shape->boundingRect();
                middle = QPointF(rect.left() + ((rect.right() - rect.left()) * 0.5), rect.top() + ((rect.bottom() - rect.top()) * 0.5));
            } else {
                m_shapes << shape;
                m_startPositions << shape->position();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : removedGroups) {
                if (g->resources().isEmpty()) {
                    RemoveResourceGroupCmd cmd(m_project, g);
                    cmd.redo();
                } else {
                    // we may have put local resource(s) in this group
                    // so we need to keep it
                    g->setShared(false);
                    m_project->removeResourceGroupId(g->id());
                    g->setId(m_project->uniqueResourceGroupId());
                    m_project->insertResourceGroupId(g->id(), g);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleManager *m : p.allScheduleManagers()) {
                if (m->isBaselined()) {
                    sm = m;
                    break;
                }
                if (m->isScheduled()) {
                    sm = m; // take the last one, more likely to be subschedule
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal root : rootParams) {
        dist = point - pointAt(root);
        oldDistanceSquared = distanceSquared;
        distanceSquared = dist.x() * dist.x() + dist.y() * dist.y();

        if (distanceSquared < oldDistanceSquared)
            resultParam = root;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Vertex* v : endNode->outputVertexes) {
                if (v->dstNode->isInitialized && !p.contains(v->dstNode)) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = v->dstNode;
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                            Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                            // Can we do better than dumping memory values???
                            // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                            currentBestPath = newP;
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        Node2PathHash::Iterator it = node2path.find(newEndNode);
                        if (it != node2path.end()) {
                            Path &p2 = it.value();
                            if (pQC.lessWorseThan(newP, p2)) {
                                p2 = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path.insert(newEndNode, newP);
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
auto i = d->data.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Conditional& co : c.conditionList()) {
        res ^= qHash(co);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : map()->sheetList())
        sheet->changeNameCellRef(rect, ref, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QString sRegion : substrings) {

        // check for a named area first
        const Region namedAreaRegion = namedAreaManager()->namedArea(sRegion);
        if (namedAreaRegion.isValid()) {
            res.add(namedAreaRegion, sheet);
            continue;
        }

        // Single cell or cell range
        int delimiterPos = sRegion.indexOf(':');
        if (delimiterPos > -1) {
            // range
            QString sUL = sRegion.left(delimiterPos);
            QString sLR = sRegion.mid(delimiterPos + 1);

            SheetBase* firstSheet = filterSheetName(sUL);
            SheetBase* lastSheet = filterSheetName(sLR);
            // TODO: lastSheet is silently ignored if it is different from firstSheet

            // Still has the sheet name separator?
            if (sUL.contains('!') || sLR.contains('!'))
                return res;

            if (!firstSheet)
                firstSheet = sheet;
            if (!lastSheet)
                lastSheet = sheet;

            // TODO: shouldn't use Region::Point, the cell name needs to be moved elsewhere
            Region::Point ul(sUL);
            Region::Point lr(sLR);

            if (ul.isValid() && lr.isValid()) {
                QRect range = QRect(ul.pos(), lr.pos());
                res.add(range, firstSheet, ul.isTopFixed(), ul.isLeftFixed(), lr.isBottomFixed(), lr.isRightFixed());
            } else if (ul.isValid()) {
                res.add(ul.pos(), firstSheet, ul.isTopFixed(), ul.isLeftFixed());
            } else { // lr.isValid()
                res.add(lr.pos(), firstSheet, lr.isTopFixed(), lr.isLeftFixed());
            }
        } else {
            // single cell
            SheetBase* targetSheet = filterSheetName(sRegion);
            // Still has the sheet name separator?
            if (sRegion.contains('!'))
                return res;
            if (!targetSheet) targetSheet = sheet;
            Region::Point pt(sRegion);
            res.add(pt.pos(), targetSheet, pt.isColumnFixed(), pt.isRowFixed());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : m_manifestfiles) {
        copyFile(*reader.store(), *outStore, f);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KChart::AbstractCartesianDiagram *diag : d->diagrams) {
        diag->takeAxis(d->kdAxis);
    }
```

#### AUTO 


```{c}
auto gradient = context.stylesReader().drawStyles("gradient");
```

#### AUTO 


```{c}
auto it = m_ranges.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->documentCommandAdded(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *sheet : sheetList()) {
        Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
        if (!fullSheet) continue;
        if (fullSheet->isHidden())
            result.append(sheet->sheetName());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : m_project->resourceGroups()) {
        l2 << g->id();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CostPlace *cp : m_costPlaces) {
        if (cp->node() == &node && cp->startup()) {
            return cp;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QUrl &url) {
        slotFileHighlighted(url.toString());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pluginPath) {
        debugPlugin << "Trying to load" << pluginPath;
        QPluginLoader *loader = new QPluginLoader(pluginPath);
        QJsonObject metaData = loader->metaData().value("MetaData").toObject();

        if (metaData.isEmpty()) {
            debugPlugin << pluginPath << "has no MetaData!";
            return;
        }

        if (!mimeType.isEmpty()) {
#ifdef OLD_PLUGIN_MIMETYPE_DATA
            QStringList mimeTypes = metaData.value("MimeType").toString().split(';');
#else
            QJsonObject pluginData = metaData.value("KPlugin").toObject();
            QStringList mimeTypes = pluginData.value("MimeTypes").toVariant().toStringList();
#endif
            mimeTypes += metaData.value("X-KDE-ExtraNativeMimeTypes").toString().split(QLatin1Char(','));
            mimeTypes += metaData.value("X-KDE-NativeMimeType").toString();
            if (! mimeTypes.contains(mimeType)) {
                return;
            }
        }

        list.append(loader);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto itShape : shapeList) {
        KoPathShape* pathShape = dynamic_cast<KoPathShape*>(itShape);
        if (pathShape) {
            pathShapeList << pathShape;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(Node *n : nodeIdDict) {
        n->blockChanged();
    }
```

#### AUTO 


```{c}
auto rootArea = d->layout->rootAreaForPosition(block.position());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : columns) {
            if (idx.column() == 0) {
                disableDelete = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal t : s.d->extrema()) {
        if (t >= 0.0 && t <= 1.0) {
            QPointF p = pointAt(t);
            qreal dist = s.d->distanceFromChord(p);
            minDist = qMin(dist, minDist);
            maxDist = qMax(dist, maxDist);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, styleId] (const QString &) { updateName(styleId); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoColorPatch *patch) { thePublic->d->colorTriggered(patch); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->cut(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataSet *ds : m_chart->proxyModel()->dataSets()) {
        CellRegion region = ds->xDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiBubble<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->yDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiBubble<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->customDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
        region = ds->categoryDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
        region = ds->labelDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto shapeManager = d->paCanvas->shapeManager();
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape * shape : shapes) {
        QList<KoPathSegment> shapeSegments;
        QRectF rectOnShape = shape->documentToShape(rect);
        KoPathShape * path = dynamic_cast<KoPathShape*>(shape);
        if (path) {
            shapeSegments = path->segmentsAt(rectOnShape);
        } else {
            for (const KoPathSegment & s : shape->snapData().snapSegments()) {
                QRectF controlRect = s.controlPointRect();
                if (! rect.intersects(controlRect) && ! controlRect.contains(rect))
                    continue;
                QRectF bound = s.boundingRect();
                if (! rect.intersects(bound) && ! bound.contains(rect))
                    continue;
                shapeSegments.append(s);
            }
        }

        QTransform m = shape->absoluteTransformation(0);
        // transform segments to document coordinates
        for (const KoPathSegment & s : shapeSegments) {
            if (ignoredPoints.contains(s.first()) || ignoredPoints.contains(s.second()))
                continue;
            segments.append(s.mapped(m));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoPathSegment & s : shape->snapData().snapSegments()) {
                QRectF controlRect = s.controlPointRect();
                if (! rect.intersects(controlRect) && ! controlRect.contains(rect))
                    continue;
                QRectF bound = s.boundingRect();
                if (! rect.intersects(bound) && ! bound.contains(rect))
                    continue;
                shapeSegments.append(s);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->textTimeout->start(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : m_project->resourceGroups()) {
        if (!project.findResourceGroup(g->id())) {
            removedGroups << g;
            removed << "Group: " + g->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &docIndex: d->indexes.value(doc).values())
        {
            auto comp = [](KoTextRange *r, int value) {
                return r->rangeStart() <= value;
            };

            // First, singlePoints
            auto it = std::lower_bound(docIndex.singlePoints.constBegin(), docIndex.singlePoints.constEnd(), first, comp);
            for (; it != docIndex.singlePoints.constEnd(); ++it) {
                if ((*it)->rangeStart() < first)
                    continue;
                if ((*it)->rangeStart() > last)
                    break;
                ranges.insertMulti((*it)->rangeStart(), (*it));
            }

            // Second, non-overlapping
            it = std::lower_bound(docIndex.nonOverlapping.constBegin(), docIndex.nonOverlapping.constEnd(), first, comp);
            for (; it != docIndex.nonOverlapping.constEnd(); ++it) {
                KoTextRange *range = *it;
                if (range->rangeEnd() < first)
                    continue;
                if (range->rangeStart() > last)
                    break;
                // We have excluded what is completely out of scope.
                // Now for the few remaining ranges…
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insertMulti(range->rangeStart(), range);
                        }
                    }
                }
                if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                    if (matchLast == -1 || range->rangeStart() <= matchLast) {
                        if (range->rangeStart() >= matchFirst) {
                            ranges.insertMulti(range->rangeEnd(), range);
                        }
                    }
                }
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insert(range->rangeStart(), range);
                        }
                    }
                }
            }

            // Last, overlapppings
            for (KoTextRange *range : docIndex.overlapping) {
                if (range->rangeStart() < first)
                    continue;
                if (range->rangeStart() > last)
                    break;

                if (!range->hasRange()) {
                    if (range->rangeStart() >= first && range->rangeStart() <= last) {
                        ranges.insertMulti(range->rangeStart(), range);
                    }
                } else {
                    if (range->rangeStart() >= first && range->rangeStart() <= last) {
                        if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                            if (range->rangeEnd() >= matchFirst) {
                                ranges.insertMulti(range->rangeStart(), range);
                            }
                        }
                    }
                    if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                        if (matchLast == -1 || range->rangeStart() <= matchLast) {
                            if (range->rangeStart() >= matchFirst) {
                                ranges.insertMulti(range->rangeEnd(), range);
                            }
                        }
                    }
                    if (range->rangeStart() >= first && range->rangeStart() <= last) {
                        if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                            if (range->rangeEnd() >= matchFirst) {
                                ranges.insert(range->rangeStart(), range);
                            }
                        }
                    }
                }
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QCursor &cursor) { updateCursor(cursor); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *axis : m_plotArea->axes()) {
            if (axis->title()->isVisible()) {
                debugChartUiAxes<<axis->actualAxisPosition();
                int rotation = axis->title()->rotation();
                switch (axis->actualAxisPosition()) {
                    case KChart::CartesianAxis::Bottom:
                    case KChart::CartesianAxis::Top:
                        axis->title()->rotate(-rotation);
                        break;
                    case KChart::CartesianAxis::Left:
                        axis->title()->rotate(-rotation);
                        axis->title()->rotate(-90);
                        break;
                    case KChart::CartesianAxis::Right:
                        axis->title()->rotate(-rotation);
                        axis->title()->rotate(90);
                        break;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *bsheet : d->doc->map()->sheetList()) {
        Sheet *sheet = dynamic_cast<Sheet *>(bsheet);
        sheet->fullCellStorage()->invalidateStyleCache();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLineF &line : m_lines) {
        decoration.moveTo(line.p1());
        decoration.lineTo(line.p2());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, key] { actionTriggered(key); }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : removedCalendars) {
        removed << "Calendar: " + c->name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : lst) {
        if (c->isShared() && !shared.calendar(c->id())) {
            result << c;
        }
        result += sortedRemoveCalendars(shared, c->calendars());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QSize &sz) {
                d->canvasController->proxyObject->updateDocumentSize(sz);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sheet *sheet : sheets) {
        SheetPrint *const pageManager = sheet->print();
        PrintSettings *settings = sheet->printSettings();
        // Set the print region, if the selection should be painted.
        // Temporarily! The print region is solely used for the page creation
        // of the current printout, but we are working with the permanent
        // SheetPrint object in this case.
        const Region printRegion = settings->printRegion();
        if (printer.printRange() == QPrinter::Selection)
            settings->setPrintRegion(*view->selection());
        sheet->setPrintSettings(*settings, forceRecreation);
        pageCount += pageManager->pageCount();
        if (printer.printRange() == QPrinter::Selection) {
            // Restore the former print region.
            settings->setPrintRegion(printRegion);
            sheet->setPrintSettings(*settings, true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoTextRange *range: docRanges) {
            if (!range->hasRange()) {
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    ranges.insertMulti(range->rangeStart(), range);
                }
            } else {
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insertMulti(range->rangeStart(), range);
                        }
                    }
                }
                if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                    if (matchLast == -1 || range->rangeStart() <= matchLast) {
                        if (range->rangeStart() >= matchFirst) {
                            ranges.insertMulti(range->rangeEnd(), range);
                        }
                    }
                }
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insert(range->rangeStart(), range);
                        }
                    }
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : map->sheetList()) {
        Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
        saveSheet(fullSheet, tableContext);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : tasks) {
        if (idx.column() != NodeModel::NodeAllocation) {
            continue;
        }
        Node *n = m->node(idx);
        if (n->type() != Node::Type_Task) {
            continue;
        }
        m_tasks << QPersistentModelIndex(idx);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : m_selectedShapes) {
        if (s->shapeId() == ChartShapeId) {
            m_chartShapes.insert(s, new ChartResizeStrategy(s));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *a : d->plotArea->axes()) {
            layout()->setPosition(a->title(), FloatingPosition);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { update(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { styleChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *bsheet : sheets) {
            Sheet *sheet = dynamic_cast<Sheet *>(bsheet);
            PageLayoutCommand* command = new PageLayoutCommand(sheet, settings, macroCommand);
            Q_UNUSED(command);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CellBase &c : dependentLocations) {
            updateFormula(c, (*it), locationOffset);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : resources) {
            if (!groups.contains(r->parentGroup())) {
                groups[r->parentGroup()] = new ResourceGroupRequest(r->parentGroup());
                AddResourceGroupRequestCmd *c = new AddResourceGroupRequestCmd(*t, groups[r->parentGroup()]);
                c->execute();
                cmd->addCommand(c);
            }
            ResourceRequest *rr = new ResourceRequest(r);
            rr->setUnits(100); // defaults to 100%
            AddResourceRequestCmd *c = new AddResourceRequestCmd(groups[r->parentGroup()], rr);
            c->execute();
            cmd->addCommand(c);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : removedCalendars) {
                c->setShared(false);
                m_project->removeCalendarId(c->id());
                c->setId(m_project->uniqueCalendarId());
                m_project->insertCalendarId(c->id(), c);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase* sheet : map->sheetList()) {
        sheetAdded(sheet);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *t : m_tasks) {
        MacroCommand *c = m_resourcesTab->buildCommand(t);
        if (c) {
            m->addCommand(c);
            modified = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& rect : dataRegion.first.rects()) {
            qreal h = calcLoadingRectValue(rect);
            rectData.append(LoadData(rect, &dataRegion.second, h));
            indices.append(indices.size());
        }
```

#### AUTO 


```{c}
auto currentBlock = textEditor->constCursor().block();
```

#### RANGE FOR STATEMENT 


```{c}
for(const RecentFileEntry &item : d->recents) {
        files << item.fileName;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { startFind(); }
```

#### LAMBDA EXPRESSION 


```{c}
[sheetView]() {
                    sheetView->updateAccessedCellRange();
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataSet *ds : remove) {
        d->dataSets.removeAll(ds);
        delete ds;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal guidePos : guidesData->verticalGuideLines()) {
        qreal distance = qAbs(guidePos - mousePosition.x());
        if (distance < minVertSnapDistance) {
            snappedPoint.setX(guidePos);
            minVertSnapDistance = distance;
            m_orientation |= Qt::Vertical;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase* sheet : sheets) {
            Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
            if (fullSheet) fullSheet->updateLocale();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : sortedShapes) {
            if (s->isVisible()) {
                QRectF sr = itemRect(s);
                if (sr.intersects(area)) {
                    shapesInArea << s;
                }
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Calligra::Sheets::SheetBase* sheet : kspreadDoc()->map()->sheetList()) {
        if (sheet->sheetName() == name) {
            Calligra::Sheets::Sheet *fullSheet = dynamic_cast<Calligra::Sheets::Sheet *>(sheet);
            return fullSheet->findChild< Calligra::Sheets::SheetAdaptor* >(); {
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString k : m_keys) {
                const QString vname = tags.first();
                if (!vname.startsWith(k)) {
                    continue;
                }
                if (tags.count() == 1) {
                    // this is the main definition (eg: name: "table1", value: "tasks ...")
                    if (!m_userfields.contains(vname)) {
                        m_userfields[vname] = new UserField();
                    }
                    UserField *field = m_userfields[vname];
                    field->name = vname;
                    field->type = k;
                    QStringList vl = trimmed(value.toLower().split(';', QString::SkipEmptyParts));
                    field->dataName = vl.takeFirst();
                    field->properties += vl;
                    field->setModel(dataModel(field->dataName), m_headerrole[field->dataName]);
                    if (k == "chart") {
                        dbgRGChart<<"  "<<"added tag:"<<field<<field->properties;
                    } else {
                        dbgRG<<"  "<<"added tag:"<<field<<field->properties;
                    }
                } else {
                    // this is the fields column definitions (eg: name: "table1.type" value: "<not used>")
                    if (!m_userfields.contains(vname)) {
                        m_userfields[vname] = new UserField();
                    }
                    UserField *field = m_userfields[vname];
                    field->name = vname;
                    field->columns << value.trimmed().toLower();
                    dbgRG<<"  "<<"added column:"<<field->name<<field->columns;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleManager *m :  project.scheduleManagers()) {
        debugPlanShared<<"Project not empty, delete schedule:"<<m<<m->name();
        DeleteScheduleManagerCmd cmd(project, m);
        cmd.execute();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](ToolHelper *helper) {
                d->toolActivated(helper);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetView *sheetView : sheetViews) {
        disconnect(sheetView, &SheetView::visibleSizeChanged,
                   d->canvas, &Canvas::setDocumentSize);
        disconnect(sheetView, &SheetView::visibleSizeChanged,
                   d->zoomController, nullptr);
        disconnect(sheetView->sheet(), &Sheet::visibleSizeChanged,
                   sheetView, nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : resourceIdDict) {
        r->blockChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString e : list) {
        QStringList parts = e.split(' ');
        if (parts.size() < 6) continue;
        bool ok;
        int x1 = parts.at(1).toUInt(&ok);
        if (!ok) continue;
        int y1 = parts.at(2).toUInt(&ok);
        if (!ok) continue;
        int x2 = parts.at(3).toUInt(&ok);
        if (!ok) continue;
        int y2 = parts.at(4).toUInt(&ok);
        if (!ok) continue;
        QString sheetName;
        for (int i = 5; i < parts.size(); ++i) {
            if (i > 5) sheetName += ' ';
            sheetName += parts.at(i);
        }
        QRect rect = QRect(QPoint(x1, y1), QPoint(x2, y2));
        SheetBase *sheet = m_sheet->map()->findSheet (sheetName);
        if (!sheet) sheet = m_sheet;
        rects.append(rect);
        sheets.append(sheet);
        areas++;
    }
```

#### AUTO 


```{c}
const auto styleAttributes = title->additionalStyleAttributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : rows) {
            if (idx.row() == 0) {
                disableDelete = true;
            }
        }
```

#### AUTO 


```{c}
auto prDocument = qobject_cast<KPrDocument*>(document);
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : d->lstSheets) {
        if (sheet == currentSheet) {
            if (prev) return prev;
            return currentSheet;  // this means that currentSheet was first in the list
        }
        prev = sheet;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString format : d->dateTimeFormats) {
        res = readDateTime(str, format, ok);
        if (*ok) return res;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QXmlStreamNamespaceDeclaration &ns : xml.namespaceDeclarations()) {
                writer->addAttribute((s + ns.prefix()).toLatin1(), ns.namespaceUri().toUtf8());
                dbgRGTmp<<"add namespace:"<<(s + ns.prefix())<<ns.namespaceUri();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto screen: qGuiApp->screens()) {
        if (screen == qGuiApp->primaryScreen()) {
            ui.monitorComboBox->addItem( i18n( "Monitor %1 (primary)", screen->name() ) );
        } else {
            ui.monitorComboBox->addItem( i18n( "Monitor %1", screen->name() ) );
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KoTextRange *r, int value) {
            return r->rangeStart() <= value;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (DataSet *ds : m_chart->proxyModel()->dataSets()) {
        CellRegion region = ds->xDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiBubble<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->yDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiBubble<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
        region = ds->customDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
        region = ds->categoryDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
        region = ds->labelDataRegion();
        for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : manager->areaNames()) {
        QDomElement e = doc.createElement("reference");
        QDomElement tabname = doc.createElement("tabname");
        tabname.appendChild(doc.createTextNode(manager->sheet(name)->sheetName()));
        e.appendChild(tabname);

        QDomElement refname = doc.createElement("refname");
        refname.appendChild(doc.createTextNode(name));
        e.appendChild(refname);

        QDomElement rect = doc.createElement("rect");
        QRect r = manager->namedArea(name).boundingRect();
        rect.setAttribute("left-rect", QString::number(r.left()));
        rect.setAttribute("right-rect", QString::number(r.right()));
        rect.setAttribute("top-rect", QString::number(r.top()));
        rect.setAttribute("bottom-rect", QString::number(r.bottom()));
        e.appendChild(rect);
        element.appendChild(e);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMetaObject *type: d->indexes.value(doc).keys())
    {
        bool found = false;
        for (const QMetaObject *requestedType: types) {
            if (type->inherits(requestedType)) {
                found = true;
                break;
            }
        }
        if (!found)
            continue;
        const auto &docIndex = d->indexes.value(doc).value(type);

        auto comp = [](KoTextRange *r, int value) {
            return r->rangeStart() <= value;
        };

        // First, singlePoints
        auto it = std::lower_bound(docIndex.singlePoints.constBegin(), docIndex.singlePoints.constEnd(), first, comp);
        for (; it != docIndex.singlePoints.constEnd(); ++it) {
            if ((*it)->rangeStart() < first)
                continue;
            if ((*it)->rangeStart() > last)
                break;
            ranges.insertMulti((*it)->rangeStart(), (*it));
        }

        // Second, non-overlapping
        it = std::lower_bound(docIndex.nonOverlapping.constBegin(), docIndex.nonOverlapping.constEnd(), first, comp);
        for (; it != docIndex.nonOverlapping.constEnd(); ++it) {
            KoTextRange *range = *it;
            if (range->rangeEnd() < first)
                continue;
            if (range->rangeStart() > last)
                break;
            // We have excluded what is completely out of scope.
            // Now for the few remaining ranges…
            if (range->rangeStart() >= first && range->rangeStart() <= last) {
                if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                    if (range->rangeEnd() >= matchFirst) {
                        ranges.insertMulti(range->rangeStart(), range);
                    }
                }
            }
            if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                if (matchLast == -1 || range->rangeStart() <= matchLast) {
                    if (range->rangeStart() >= matchFirst) {
                        ranges.insertMulti(range->rangeEnd(), range);
                    }
                }
            }
            if (range->rangeStart() >= first && range->rangeStart() <= last) {
                if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                    if (range->rangeEnd() >= matchFirst) {
                        ranges.insert(range->rangeStart(), range);
                    }
                }
            }
        }

        // Last, overlapppings
        for (KoTextRange *range : docIndex.overlapping) {
            if (range->rangeStart() < first)
                continue;
            if (range->rangeStart() > last)
                break;

            if (!range->hasRange()) {
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    ranges.insertMulti(range->rangeStart(), range);
                }
            } else {
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insertMulti(range->rangeStart(), range);
                        }
                    }
                }
                if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                    if (matchLast == -1 || range->rangeStart() <= matchLast) {
                        if (range->rangeStart() >= matchFirst) {
                            ranges.insertMulti(range->rangeEnd(), range);
                        }
                    }
                }
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insert(range->rangeStart(), range);
                        }
                    }
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoInlineCite *existingCite: m_cites.values(dialog.shortName->text())) {
                    *existingCite = *toCite();                       //update all cites with new values
                    existingCite->setType(KoInlineCite::ClonedCitation);    //change type to ClonedCitation
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoCanvasController* c) {
                d->attachCanvas(c);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { gotoPage(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Lab:"<<first<<':'<<r;
                ds->setLabelDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->matchFound(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction *a : m_designer->itemActions(m_actionGroup) ) {
        if ( itemtypes.contains( a->objectName() ) ) {
            lst.insert(itemtypes.indexOf(a->objectName()), a);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ConfigObjectBase *w : findChildren<ConfigObjectBase*>()) {
        w->open(chart);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : project.resourceList()) {
        Resource *resource = m_project->findResource(r->id());
        if (resource) {
            if (!resource->isShared()) {
                // User has probably created shared resources from this project,
                // so the resources exists but are local ones.
                // Convert to shared and do not load the resource from shared.
                removeresources << r;
                resource->setShared(true);
                debugPlanShared<<"Set resource to shared:"<<resource<<resource->id();
            }
            resource->setName(r->name());
            resource->setInitials(r->initials());
            resource->setEmail(r->email());
            resource->setType(r->type());
            resource->setAutoAllocate(r->autoAllocate());
            resource->setAvailableFrom(r->availableFrom());
            resource->setAvailableUntil(r->availableUntil());
            resource->setUnits(r->units());
            resource->setNormalRate(r->normalRate());
            resource->setOvertimeRate(r->overtimeRate());

            QString id = r->calendar(true) ? r->calendar(true)->id() : QString();
            resource->setCalendar(m_project->findCalendar(id));

            id = r->account() ? r->account()->name() : QString();
            resource->setAccount(m_project->accounts().findAccount(id));

            resource->setRequiredIds(r->requiredIds());

            resource->setTeamMemberIds(r->teamMemberIds());
            debugPlanShared<<"Updated resource:"<<resource<<resource->id();
        }
    }
```

#### AUTO 


```{c}
auto targetPoint = std::lower_bound(d->pageNumbers.keyBegin(), d->pageNumbers.keyEnd(), point.y(), [this] (int id, qreal pt) {
        // id is the key in d->pageNumbers
        return d->pageOffsets[d->pageNumbers[id]] <= pt;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { d->_k_slotUploadFinished(job); }
```

#### AUTO 


```{c}
auto result = std::unique_ptr<PptxSlideProperties>(new PptxSlideProperties());
```

#### AUTO 


```{c}
const auto stats = m_document->statistics();
```

#### RANGE FOR STATEMENT 


```{c}
for (const TemplateAction &templateAction : koAsConst(m_templateActions)) {
        disconnect(templateAction.action, &QAction::triggered, this, nullptr);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StyleRegion& styleArea : m_styles) {
        const Region& reg = styleArea.first;
        const Style& style = styleArea.second;
        if (style.isEmpty()) continue;

        // update used areas
        QRect bound = reg.boundingRect();
        if ((bound.top() == 1 && bound.bottom() >= KS_rowMax) || (bound.left() == 1 && bound.right() >= KS_colMax)) {
            for (const QRect& rect : reg.rects()) {
                if (rect.top() == 1 && rect.bottom() >= KS_rowMax) {
                    for (int i = rect.left(); i <= rect.right(); ++i) {
                        d->usedColumns.insert(i, true);
                    }
                } else if (rect.left() == 1 && rect.right() >= KS_colMax) {
                    for (int i = rect.top(); i <= rect.bottom(); ++i) {
                        d->usedRows.insert(i, true);
                    }
                } else {
                    d->usedArea.add(rect);
                }
            }
        } else {
            d->usedArea.add(reg);
        }

        // find substyles
        for (const SharedSubStyle& subStyle : style.subStyles()) {
            bool foundShared = false;
            typedef const QList< SharedSubStyle> StoredSubStyleList;
            StoredSubStyleList& storedSubStyles(d->subStyles.value(subStyle->type()));
            StoredSubStyleList::ConstIterator end(storedSubStyles.end());
            for (StoredSubStyleList::ConstIterator it(storedSubStyles.begin()); it != end; ++it) {
                if (Style::compare(subStyle.data(), (*it).data())) {
        //             debugSheetsStyle <<"[REUSING EXISTING SUBSTYLE]";
                    subStyles.append(qMakePair(reg, *it));
                    foundShared = true;
                    break;
                }
            }
            if (!foundShared) {
                // insert substyle and add to the used substyle list
                //if (reg.contains(QPoint(1,1))) {debugSheetsStyle<<"load:"<<reg<<':'; subStyle.data()->dump();}
                subStyles.append(qMakePair(reg, subStyle));
            }
        }
    }
```

#### AUTO 


```{c}
auto it = d->availableColorspaces.find(profile->name());
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiBubble<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : d->lstSheets) {
        if (_name.toLower() == sheet->sheetName().toLower())
            return sheet;
    }
```

#### AUTO 


```{c}
auto i = bases.begin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Path &p : currentPaths) {
            const Node* endNode = p.endNode();
            for (Vertex* v : endNode->outputVertexes) {
                if (v->dstNode->isInitialized && !p.contains(v->dstNode)) {
                    Path newP = p;  // Candidate
                    newP.appendVertex(v);
                    Node* newEndNode = v->dstNode;
                    if (newEndNode == dstNode) {
                        if (pQC.isGoodPath(newP)) { // Victory
                            newP.isGood = true;
                            return newP;
                        } else if (pQC.lessWorseThan(newP, currentBestPath)) {
                            Q_ASSERT(newP.startNode()->id() == currentBestPath.startNode()->id());
                            Q_ASSERT(newP.endNode()->id() == currentBestPath.endNode()->id());
                            // Can we do better than dumping memory values???
                            // warnPigment << pQC.lessWorseThan(newP, currentBestPath) << " " << newP << "  " << currentBestPath;
                            currentBestPath = newP;
                        }
                    } else {
                        // This is an incomplete path. Check if there's a better way to get to its endpoint.
                        Node2PathHash::Iterator it = node2path.find(newEndNode);
                        if (it != node2path.end()) {
                            Path &p2 = it.value();
                            if (pQC.lessWorseThan(newP, p2)) {
                                p2 = newP;
                                possiblePaths.append(newP);
                            }
                        } else {
                            node2path.insert(newEndNode, newP);
                            possiblePaths.append(newP);
                        }
                    }
                }
            }
            possiblePaths.removeAll(p); // Remove from list of remaining paths
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase *sheet : sheetList()) {
        Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
        if (fullSheet) fullSheet->deleteShapes();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { updateCanvasSize(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* bsheet : doc()->map()->sheetList()) {
        Sheet *sheet = dynamic_cast<Sheet *>(bsheet);
        if (sheet) addSheet(sheet);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool final) { Q_UNUSED(final); d->indentsChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *sheet : map()->sheetList())
        sheet->changeCellTabName(old_name, name);
```

#### LAMBDA EXPRESSION 


```{c}
[this, key] { q_ptr->slotButtonClicked(key); }
```

#### AUTO 


```{c}
auto fontSizeAction = new KFontSizeAction(i18n("Select Font Size"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *element : d->cells) {
      if (element->sheet() != s) continue;
      if (element->type() == Element::Point) {
        Point* point = static_cast<Point*>(element);
        if (rect.contains (point->pos()))
          result.add (point->pos(), s);
      } else {
        QRect rect2 = element->rect();
        if (rect2.intersects (rect))
          result.add (rect2.intersected (rect), s);
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : removedGroups) {
                if (g->resources().isEmpty()) {
                    RemoveResourceGroupCmd cc(m_project, g);
                    cc.execute();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->removeColumns(position, number);
```

#### AUTO 


```{c}
auto data = currentData(Region(rect));
```

#### AUTO 


```{c}
auto pageIt( masterPagesToUpdate.constBegin() );
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &uniqueKey : table.uniqueKeys()) {
            QStringList debugStr(table.values(uniqueKey));
            debugSheetsFormula << uniqueKey << " provides values for:" << debugStr.join(",");
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString format : d->dateFormats) {
        res = readDate(str, format, ok);
        if (*ok) return res;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QFont &ft) { d->_ko_slotFontChanged(ft); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : field->columns) {
                        QVariant value = field->model.index(r, field->column(name)).data();
                        writer.startElement("table:table-cell");
                        writer.addAttribute("office:value-type", "float");
                        writer.addAttribute("office:value", value.toDouble());
                        writer.startElement("text:p");
                        writer.addTextNode(QString::number(value.toDouble()));
                        writer.endElement();
                        writer.endElement();
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->insertColumns(position, number);
```

#### AUTO 


```{c}
auto sheet = d->document->map()->sheet(0);
```

#### LAMBDA EXPRESSION 


```{c}
[this, sheet] (const QString &oldName, const QString &name) { Q_UNUSED(name); sheetNameChanged(sheet, oldName); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &id : keys()) {
        get(id)->deleteLater();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](XlsxCellFormat *ptr) { delete ptr; m_currentCellFormat = nullptr; }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *sheet : sheetList()) {
        Sheet *fullSheet = dynamic_cast<Sheet *>(sheet);
        if (!fullSheet) continue;
        if (!fullSheet->isHidden())
            result.append(sheet->sheetName());
    }
```

#### AUTO 


```{c}
auto item = dynamic_cast<QGraphicsItem*> (d->paCanvas);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QPair< QRectF, QUrl >& link : d->links )
    {
        QRectF hitTarget{
            link.first.x() - Private::wiggleFactor,
            link.first.y() - Private::wiggleFactor,
            link.first.width() + Private::wiggleFactor * 2,
            link.first.height() + Private::wiggleFactor * 2
        };

        if( hitTarget.contains( point + (d->canvas->documentOffset() / zoomController()->zoomAction()->effectiveZoom()) ) )
            return link.second;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (int id, qreal pt) {
        // id is the key in d->pageNumbers
        return d->pageOffsets[d->pageNumbers[id]] <= pt;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Sheet *sheet : d->sheets)
        pageCount += sheet->print()->pageCount();
```

#### LAMBDA EXPRESSION 


```{c}
[printJob]() { printJob->startPrinting(); }
```

#### AUTO 


```{c}
auto canvasQObject = dynamic_cast<QObject*>(canvas);
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
            storage->storeUndo(true);
```

#### RANGE FOR STATEMENT 


```{c}
for(Calligra::Sheets::SheetBase* bsheet : doc->map()->sheetList()) {
            Calligra::Sheets::Sheet *sheet = dynamic_cast<Calligra::Sheets::Sheet *>(bsheet);
            if (! sheet || sheet->isHidden())
                continue;
            QRect area = sheet->usedArea();
            bool enabled = area.isValid();
            Q_UNUSED(enabled);
            QList< QStandardItem* > items;

            QStandardItem* nameitem = new QStandardItem(sheet->sheetName());
            nameitem->setEditable(false);
            if (m_selectiontype == MultiSelect) {
                nameitem->setCheckable(true);
                nameitem->setCheckState((activeSheet == sheet) ? Qt::Checked : Qt::Unchecked);
            }
            items << nameitem;

            if (m_editortype != Disabled) {
                QString range;
                for(const QVariant &v : m_prevlist) {
                    QVariantList l = v.toList();
                    if (l.count() < 1 || l[0].toString() != sheet->sheetName())
                        continue;
                    if (l.count() >= 2)
                        if (m_selectiontype == MultiSelect)
                            nameitem->setCheckState(l[1].toBool() ? Qt::Checked : Qt::Unchecked);
                    if (l.count() >= 3) {
                        QStringList rangelist;
                        for (int i = 2; i < l.count(); ++i) {
                            const QRect rect = l[i].toRect();
                            if (rect.isNull())
                                continue;
                            Calligra::Sheets::Region region(rect, sheet);
                            for (Calligra::Sheets::Region::ConstIterator it = region.constBegin(); it != region.constEnd(); ++it) {
                                const QString n = (*it)->name(sheet);
                                if (! n.isEmpty())
                                    rangelist.append(n);
                            }
                        }
                        range = rangelist.join(";");
                    }
                    break;
                }
                if (range.isEmpty() && area.isValid())
                    range = Calligra::Sheets::Region(area, sheet).name(sheet);
                if (m_editortype == Cell) {
                    int p = range.indexOf(':');
                    range = p > 0 ? range.left(p) : "A1";
                }
                items << new QStandardItem(range);
            }

            model->appendRow(items);
            if (activeSheet == sheet)
                m_view->setCurrentIndex(nameitem->index());
        }
```

#### AUTO 


```{c}
auto colorAction = new KoColorPopupAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : project.allCalendars()) {
        Calendar *calendar = m_project->findCalendar(c->id());
        if (calendar) {
            *calendar = *c;
        }
    }
```

#### AUTO 


```{c}
auto masterPage = paPage->masterPage();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pluginPath) {
        debugPlugin << "Trying to load" << pluginPath;
        QPluginLoader *loader = new QPluginLoader(pluginPath);
        QJsonObject metaData = loader->metaData().value("MetaData").toObject();

        if (metaData.isEmpty()) {
            debugPlugin << pluginPath << "has no MetaData!";
            return;
        }

        if (!mimeType.isEmpty()) {
#ifdef CALLIGRA_OLD_PLUGIN_METADATA
            QStringList mimeTypes = metaData.value("MimeType").toString().split(';');
            mimeTypes += metaData.value("X-KDE-ExtraNativeMimeTypes").toString().split(QLatin1Char(','));
#else
            QJsonObject pluginData = metaData.value("KPlugin").toObject();
            QStringList mimeTypes = pluginData.value("MimeTypes").toVariant().toStringList();
            mimeTypes += metaData.value("X-KDE-ExtraNativeMimeTypes").toVariant().toStringList();
#endif
            mimeTypes += metaData.value("X-KDE-NativeMimeType").toString();
            if (! mimeTypes.contains(mimeType)) {
                return;
            }
        }

        list.append(loader);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase* sheet : map->sheetList()) {
        if (sheet->isHidden())
            continue;
        d->sheetComboBox->addItem(sheet->sheetName());
        //d->sheetComboBox->setCurrentIndex( d->sheetComboBox->count()-1 );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : p.resourceList()) {
                Resource *res = m_project->resource(r->id());
                debugPlan<<"Resource:"<<r->name()<<"->"<<res;
                if (res && res->isShared()) {
                    for (const Appointment *a : r->appointments()) {
                        Appointment *app = new Appointment(*a);
                        app->setAuxcilliaryInfo(p.name());
                        res->addExternalAppointment(p.id(), app);
                        debugPlan<<res->name()<<"added:"<<app->auxcilliaryInfo()<<app;
                    }
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (CostPlace *cp : m_costPlaces) {
        if (cp->node() == &node && cp->shutdown()) {
            return cp;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QString line : lines) {
        if (line.startsWith("row ")) return false;
        if (line.startsWith("column ")) return false;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (SharedSubStyle style : d->tree.intersects(rect))
            d->tree.remove(rect, style);
```

#### AUTO 


```{c}
auto masterShapes = masterPage->shapes();
```

#### RANGE FOR STATEMENT 


```{c}
for (Task *t : m_tasks) {
        if (!leaderfield->isHidden() && t->leader() != leaderfield->text()) {
            cmd->addCommand(new NodeModifyLeaderCmd(*t, leaderfield->text()));
            modified = true;
        }
        Node::ConstraintType c = (Node::ConstraintType)schedulingType();
        if (c != t->constraint()) {
            cmd->addCommand(new NodeModifyConstraintCmd(*t, c));
            modified = true;
        }
        if (startDateTime() != t->constraintStartTime() &&
            (c == Node::FixedInterval || c == Node::StartNotEarlier || c == Node::MustStartOn)) {
            cmd->addCommand(new NodeModifyConstraintStartTimeCmd(*t, startDateTime()));
            modified = true;
        }
        if (endDateTime() != t->constraintEndTime() &&
            (c == Node::FinishNotLater || c == Node::FixedInterval || c == Node::MustFinishOn)) {
            cmd->addCommand(new NodeModifyConstraintEndTimeCmd(*t, endDateTime()));
            modified = true;
        }
        int et = estimationType();
        if (et == 2 /*Milestome*/) {
            et = 0; /*Effort*/
        }
        if (et != t->estimate()->type()) {
            cmd->addCommand(new ModifyEstimateTypeCmd(*t,  t->estimate()->type(), et));
            modified = true;
        }
        bool unitchanged = estimate->unit() != t->estimate()->unit();
        if ( unitchanged ) {
            cmd->addCommand( new ModifyEstimateUnitCmd( *t, t->estimate()->unit(), estimate->unit() ) );
            modified = true;
        }
        bool expchanged = estimationValue() != t->estimate()->expectedEstimate();
        if ( expchanged ) {
            cmd->addCommand(new ModifyEstimateCmd(*t, t->estimate()->expectedEstimate(), estimationValue()));
            modified = true;
        }
        int x = optimistic();
        if ( x != t->estimate()->optimisticRatio() || expchanged || unitchanged ) {
            cmd->addCommand(new EstimateModifyOptimisticRatioCmd(*t, t->estimate()->optimisticRatio(), x));
            modified = true;
        }
        x = pessimistic();
        if ( x != t->estimate()->pessimisticRatio() || expchanged || unitchanged ) {
            cmd->addCommand(new EstimateModifyPessimisticRatioCmd(*t, t->estimate()->pessimisticRatio(), x));
            modified = true;
        }
        if (t->estimate()->risktype() != risktype()) {
            cmd->addCommand(new EstimateModifyRiskCmd(*t, t->estimate()->risktype(), risktype()));
            modified = true;
        }
        if (t->estimate()->calendar() != calendar()) {
            cmd->addCommand(new ModifyEstimateCalendarCmd(*t, t->estimate()->calendar(), calendar()));
            modified = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharedSubStyle& subStyle : subs) {
        Region::ConstIterator end(region.constEnd());
        for (Region::ConstIterator it(region.constBegin()); it != end; ++it) {
            // insert substyle
            insert((*it)->rect(), subStyle, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Appointment *a : r->appointments(sm->scheduleId())) {
                            *app += *a;
                        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { selectionChangedEvent(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->tabChangeInitiated(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &name : m_styles.keys()) {
        debugSheetsStyle << name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : shapesInArea) {
            QRectF sr = itemRect(s);
            sr.moveBottom(area.bottom());
            newlayout[s] = sr;
            debugChartLayout<<"shift in area:"<<dbg(s)<<sr;
            area.setBottom(sr.top() - m_spacing.y());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPair<QString, QString> &a : element.attributeFullNames()) {
        QString prefix = KoXmlNS::nsURI2NS(a.first);
        if (prefix.isEmpty()) {
            dbgRG<<"  Skipping unknown namespace:"<<a.first<<a.second;
            continue;
        }
        QString attr = QString(prefix + ':' + a.second);
        if (exclude.contains(attr)) {
            continue;
        }
        m_tags << attr.toUtf8(); // save
//         dbgRGa.first<<a.second<<"->"<<attr;
        //dbgRG<<" : "<<m_tags.last().constData()<<'='<<e.attributeNS(a.first, a.second);
        writer.addAttribute(m_tags.last().constData(), element.attributeNS(a.first, a.second));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QVariant &v : m_prevlist) {
                    QVariantList l = v.toList();
                    if (l.count() < 1 || l[0].toString() != sheet->sheetName())
                        continue;
                    if (l.count() >= 2)
                        if (m_selectiontype == MultiSelect)
                            nameitem->setCheckState(l[1].toBool() ? Qt::Checked : Qt::Unchecked);
                    if (l.count() >= 3) {
                        QStringList rangelist;
                        for (int i = 2; i < l.count(); ++i) {
                            const QRect rect = l[i].toRect();
                            if (rect.isNull())
                                continue;
                            Calligra::Sheets::Region region(rect, sheet);
                            for (Calligra::Sheets::Region::ConstIterator it = region.constBegin(); it != region.constEnd(); ++it) {
                                const QString n = (*it)->name(sheet);
                                if (! n.isEmpty())
                                    rangelist.append(n);
                            }
                        }
                        range = rangelist.join(";");
                    }
                    break;
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this, key] (bool) { q_ptr->slotButtonClicked(key); }
```

#### AUTO 


```{c}
auto itNext = it + 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : removedResources) {
                RemoveResourceCmd cmd(r->parentGroup(), r);
                cmd.redo();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Token &token : tokens) {
        //parse each cell/range and put it to our expression
        if (token.type() == Token::Cell || token.type() == Token::Range) {
            // FIXME Stefan: Special handling for named areas
            const Region region = sheet->map()->regionFromName (token.text(), sheet);
            //debugSheetsFormula << region.name();

            // the offset contains a sheet, only if it was an intersheet move.
            if ((oldLocation->sheet() == region.firstSheet()) &&
                    (oldLocation->rect().contains(region.firstRange()))) {
                const Region yetAnotherRegion(region.firstRange().translated(offset.pos()),
                                              offset.sheet() ? offset.sheet() : sheet);
                expression.append(yetAnotherRegion.name(sheet));
            } else {
                expression.append(token.text());
            }
        } else {
            expression.append(token.text());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& rect : rects) {
        for (int col = rect.left(); col <= rect.right(); ++col) {
            for (int row = rect.top(); row <= rect.bottom(); ++row)
                m_cache.remove(QPoint(col, row));     // also deletes it
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &regexp: add_syl_regexp) {
                if (word.indexOf(regexp) != -1) {
                    word_syllables++;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (LayoutData *l : m_layoutItems) {
        if (l->itemType == PlotAreaType) {
            plotArea = m_layoutItems.key(l);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoInlineCite *cite: KoTextDocument(m_editor->document()).inlineTextObjectManager()->citations()) {
        existingCites << cite->identifier();
        m_cites[cite->identifier()] = cite;
    }
```

#### AUTO 


```{c}
auto &regexp
```

#### LAMBDA EXPRESSION 


```{c}
[this, newFrame](){
        if (d->document->mainFrameSet()) {
            newFrame(d->document->mainFrameSet());
        }
    }
```

#### AUTO 


```{c}
auto entry = d->entries.at(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *a : d->plotArea->axes()) {
        l->setPosition(a->title(), FloatingPosition);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& helpLine : helpLines) {
                writer.startElement("text:p");
                writer.addTextNode(helpLine);
                writer.endElement();
            }
```

#### AUTO 


```{c}
auto canvas = static_cast<KoPACanvasItem*>(d->part->canvasItem(d->document));
```

#### LAMBDA EXPRESSION 


```{c}
[this, templateAction] { insert(templateAction.data); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { updateCanvasSize(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DataRegion& dataRegion : data) {
        for (const QRect& rect : dataRegion.first.rects()) {
            qreal h = calcLoadingRectValue(rect);
            rectData.append(LoadData(rect, &dataRegion.second, h));
            indices.append(indices.size());
        }
    }
```

#### AUTO 


```{c}
auto comp = [](KoTextRange *r, int value) {
                return r->rangeStart() <= value;
            };
```

#### LAMBDA EXPRESSION 


```{c}
[this](KWFrameSet *fs) {
        KWTextFrameSet *tfs = qobject_cast<KWTextFrameSet*>(fs);
        if (tfs) {
            connect(tfs->document(), &QTextDocument::contentsChanged, d->timer, QOverload<>::of(&QTimer::start), Qt::UniqueConnection);
            KoTextDocumentLayout *lay = qobject_cast<KoTextDocumentLayout*>(tfs->document()->documentLayout());
            if (lay) {
                connect(lay, &KoTextDocumentLayout::finishedLayout, d->timer, QOverload<>::of(&QTimer::start), Qt::UniqueConnection);
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr bool value = sizeof(test<T>(0)) == sizeof(y_type);
```

#### RANGE FOR STATEMENT 


```{c}
for (QPersistentModelIndex &idx : lst) {
        Node *n = m->node(idx);
        if (!n || n->type() != Node::Type_Task) {
            continue;
        }
        Task *t = static_cast<Task*>(n);
        // remove any requests before adding new ones
        for (ResourceGroupRequest *r : t->requests().requests()) {
            RemoveResourceGroupRequestCmd *c = new RemoveResourceGroupRequestCmd(r);
            c->execute(); // need to remove everyting before we add anything
            cmd->addCommand(c);
        }
        QMap<ResourceGroup*, ResourceGroupRequest*> groups;
        for (Resource *r : resources) {
            if (!groups.contains(r->parentGroup())) {
                groups[r->parentGroup()] = new ResourceGroupRequest(r->parentGroup());
                AddResourceGroupRequestCmd *c = new AddResourceGroupRequestCmd(*t, groups[r->parentGroup()]);
                c->execute();
                cmd->addCommand(c);
            }
            ResourceRequest *rr = new ResourceRequest(r);
            rr->setUnits(100); // defaults to 100%
            AddResourceRequestCmd *c = new AddResourceRequestCmd(groups[r->parentGroup()], rr);
            c->execute();
            cmd->addCommand(c);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Axis *a : d->axes) {
        a->updateKChartStockAttributes();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (const QString &oldText, int start, const QString &newText) {
                replace(start, oldText, newText);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectionModel()->selectedRows()) {
            Resource *r = m->resource(idx);
            if (r) {
                resources << r;
            }
        }
```

#### AUTO 


```{c}
auto selectAction = new KSelectAction(i18n("Style"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : m_project->resourceGroups()) {
        if (g->isShared() && !project.findResourceGroup(g->id())) {
            removedGroups << g;
            removed << "Group: " + g->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoTextRange *range : ranges) {
            range->finalizePosition();
            insert(range);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (bool v) { d->selectionChanged(v); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiScatter<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Account::CostPlace *cp : m_account->costPlaces()) {
        if (cp->node()) {
            if (cp->running()) {
                m_cmd.addCommand(new NodeModifyRunningAccountCmd(*cp->node(), cp->node()->runningAccount(), 0));
            }
            if (cp->startup()) {
                m_cmd.addCommand(new NodeModifyStartupAccountCmd(*cp->node(), cp->node()->startupAccount(), 0));
            }
            if (cp->shutdown()) {
                m_cmd.addCommand(new NodeModifyShutdownAccountCmd(*cp->node(), cp->node()->shutdownAccount(), 0));
            }
        } else if (cp->resource()) {
            m_cmd.addCommand(new ResourceModifyAccountCmd(*cp->resource(), cp->resource()->account(), 0));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool direction) { d->searchWrapped(direction); }
```

#### AUTO 


```{c}
auto shapes = page->shapes();
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->inputTimeout(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int col : m_columnFormats.keys()) {
        m_sheet->columnFormats()->setColFormat(col, col, m_columnFormats.value(col));
    }
```

#### AUTO 


```{c}
auto texNode = static_cast<QSGSimpleTextureNode*>(center->firstChild());
```

#### RANGE FOR STATEMENT 


```{c}
for (const RecentFileEntry& entry : recents) {
                if (entry.filePath == value) {
                    continue;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->stopPressed(); }
```

#### AUTO 


```{c}
auto newFrame = [this](KWFrameSet *fs) {
        KWTextFrameSet *tfs = qobject_cast<KWTextFrameSet*>(fs);
        if (tfs) {
            connect(tfs->document(), &QTextDocument::contentsChanged, d->timer, QOverload<>::of(&QTimer::start), Qt::UniqueConnection);
            KoTextDocumentLayout *lay = qobject_cast<KoTextDocumentLayout*>(tfs->document()->documentLayout());
            if (lay) {
                connect(lay, &KoTextDocumentLayout::finishedLayout, d->timer, QOverload<>::of(&QTimer::start), Qt::UniqueConnection);
            }
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const CellBase& c : consumers) 
        region.add(c.cellPosition(), c.sheet());
```

#### RANGE FOR STATEMENT 


```{c}
for (SheetBase *s : map->sheetList()) {
            d->sheetComboBox->addItem(s->sheetName());
            //d->sheetComboBox->setCurrentIndex( d->sheetComboBox->count()-1 );
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoTextRange *range : docIndex.overlapping) {
            if (range->rangeStart() < first)
                continue;
            if (range->rangeStart() > last)
                break;

            if (!range->hasRange()) {
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    ranges.insertMulti(range->rangeStart(), range);
                }
            } else {
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insertMulti(range->rangeStart(), range);
                        }
                    }
                }
                if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                    if (matchLast == -1 || range->rangeStart() <= matchLast) {
                        if (range->rangeStart() >= matchFirst) {
                            ranges.insertMulti(range->rangeEnd(), range);
                        }
                    }
                }
                if (range->rangeStart() >= first && range->rangeStart() <= last) {
                    if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                        if (range->rangeEnd() >= matchFirst) {
                            ranges.insert(range->rangeStart(), range);
                        }
                    }
                }
            }
        }
```

#### AUTO 


```{c}
auto &ranges
```

#### AUTO 


```{c}
auto center = static_cast<QSGTransformNode*>(root->firstChild());
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->insertShiftRight(rect);
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : m_rowFormats.keys()) {
        m_sheet->rowFormats()->setRowFormat(row, row, m_rowFormats.value(row));
    }
```

#### AUTO 


```{c}
auto map = this->map();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString &pluginPath) {
        qDebug() << "Trying to load" << pluginPath;
        QPluginLoader *loader = new QPluginLoader(pluginPath);
        QJsonObject metaData = loader->metaData().value("MetaData").toObject();

        if (metaData.isEmpty()) {
            //qDebug() << dirIter.filePath() << "has no json!";
            return;
        }

        if (!mimeType.isEmpty()) {
#ifdef OLD_PLUGIN_MIMETYPE_DATA
            QStringList mimeTypes = metaData.value("MimeType").toString().split(';');
#else
            QJsonObject pluginData = metaData.value("KPlugin").toObject();
            QStringList mimeTypes = pluginData.value("MimeTypes").toVariant().toStringList();
#endif
            mimeTypes += metaData.value("X-KDE-ExtraNativeMimeTypes").toString().split(QLatin1Char(','));
            mimeTypes += metaData.value("X-KDE-NativeMimeType").toString();
            if (! mimeTypes.contains(mimeType)) {
                return;
            }
        }

        list.append(loader);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &f : modules) {
                m_dirwatch.addFile(f);
            }
```

#### AUTO 


```{c}
auto masterShapeManager = d->paCanvas->masterShapeManager();
```

#### RANGE FOR STATEMENT 


```{c}
for (Node *n :  project.childNodeIterator()) {
        debugPlanShared<<"Project not empty, delete node:"<<n<<n->name();
        NodeDeleteCmd cmd(n);
        cmd.execute();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : map.keys()) {
        s->setPosition(map[s].topLeft());
        s->setSize(map[s].size());
    }
```

#### AUTO 


```{c}
auto fontAction = new KFontAction(i18n("Select Font..."), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TRegion& tr : m_data) {
        const QRegion& reg = tr.first;
        const T& d = tr.second;

        int index = m_storage->m_storedData.indexOf(d);
        if (index != -1) {
            treeData.append(qMakePair(reg, m_storage->m_storedData[index]));
        } else {
            treeData.append(tr);
            m_storage->m_storedData.append(d);
        }
    }
```

#### AUTO 


```{c}
auto it = gradient.constFind(styleName);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { startReplace(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QSizeF &sz) { m_zoomController->setDocumentSize(sz); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : dir.entryList(QDir::Files|QDir::QDir::NoDotAndDotDot)) {
            QUrl url;
            url.setUrl(path + '/' + file);
            qDebug()<<"templates:"<<url<<path<<file;
            del->files.insert(url.fileName(), url);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *cc : c->calendars()) {
        if (!lst.contains(cc)) {
            return false;
        }
        if (!canRemoveCalendar(cc, lst)) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& rect : region.rects()) {
        for (int col = rect.left(); col <= rect.right(); ++col) {
            for (int row = rect.top(); row <= rect.bottom(); ++row) {
//                 debugSheetsStyle <<"StyleStorage: Removing cached style for" << Cell::name( col, row );
                d->cache.remove(QPoint(col, row));     // also deletes it
            }
        }
    }
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->removeShiftUp(rect);
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : project.resourceGroups()) {
        l1 << g->id();
    }
```

#### AUTO 


```{c}
auto layout = page->pageLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (KoParagraphStyle *style: m_draftParStyleList) {
        removeParagraphStyle(style);
    }
```

#### AUTO 


```{c}
auto pageIt( masterPagesToUpdate.constFind( masterPage ) );
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { exportToPdf(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QMetaObject *requestedType: types) {
            if (type->inherits(requestedType)) {
                found = true;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setYDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                debugChartUiBubble<<"move Y:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int v) { d_func()->angleSnapChanged(v); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : m_rowFormats.keys()) {
            m_sheet->rowFormats()->setRowFormat(row, row, m_rowFormats.value(row));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KPluginFactory* factory : pluginFactories) {
        QObject *object = factory->create<QObject>(this, QVariantList());
        KXMLGUIClient *clientPlugin = dynamic_cast<KXMLGUIClient*>(object);
        if (clientPlugin) {
            insertChildClient(clientPlugin);
        } else {
            // not our/valid plugin, so delete the created object
            object->deleteLater();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { generatePreview(); }
```

#### AUTO 


```{c}
auto res = rowHeights.search(row, v, firstRow, lastRow);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->lineEditFinished(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QAction *a : m_designer->itemActions( ag ) ) {
        int pos = itemtypes.indexOf( a->objectName() );
        if ( pos >= 0 ) {
            QToolButton *tb = new QToolButton( w );
            tb->setObjectName( a->objectName() );
            tb->setIcon( a->icon() );
            tb->setText( a->text() );
//             tb.setToolTip( itemTooltips.value( pos ));
            tb->setCheckable( true );
            tblst[pos] = tb;
            connect(tb, SIGNAL(clicked(bool)), SLOT(slotInsertAction()));
            connect(this, SIGNAL(resetButtonState(bool)), tb, SLOT(setChecked(bool)));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Calendar *c : removedCalendars) {
                c->setShared(false);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroup *g : removegroups) {
        debugPlanShared<<"Delete group:"<<g<<g->id();
        RemoveResourceGroupCmd cmd(&project, g);
        cmd.execute();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Node *n : nodeIdDict) {
            cs->startTime = qMin(cs->startTime, n->startTime(cs->id()));
            cs->endTime = qMax(cs->endTime, n->endTime(cs->id()));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cust:"<<first<<':'<<r;
                ds->setCustomDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex &idx : selectedRows()) {
        QString name = model->index(idx.row(), 0).data().toString();
        QString tmp = model->index(idx.row(), 1).data(FULLPATHROLE).toString();
        QString file = model->index(idx.row(), 2).data().toString();
        if (tmp.isEmpty() || file.isEmpty()) {
            debugPlan<<"No files for report:"<<name<<tmp<<file;
            continue;
        }
        QString addition = model->index(idx.row(), 3).data().toString();
        if (addition == "Date") {

        } else if (addition == "Number") {

        }
        generateReport(tmp, file);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QXmlStreamAttribute &a : xml.attributes()) {
                dbgRGTmp<<"add attribute:"<<a.qualifiedName()<<a.value();
                writer->addAttribute(a.qualifiedName().toLatin1(), a.value().toUtf8());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoCharacterStyle* style : sharedData->characterStyles(true)) {
        fixupStyle(style);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect rect : cf->region().translated(1, 1))
            r.add(rect, os);
```

#### AUTO 


```{c}
auto res = d->filtered.search(row, v, firstRow, lastRow);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QAction *a : m_designer->itemActions( ag ) ) {
        int pos = itemtypes.indexOf( a->objectName() );
        if ( pos >= 0 ) {
            QToolButton *tb = new QToolButton( w );
            tb->setObjectName( a->objectName() );
            tb->setIcon( a->icon() );
            tb->setText( a->text() );
            tb->setToolTip( a->text() );
            tb->setCheckable( true );
            tblst[pos] = tb;
            connect(tb, SIGNAL(clicked(bool)), SLOT(slotInsertAction()));
            connect(this, SIGNAL(resetButtonState(bool)), tb, SLOT(setChecked(bool)));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ArtisticTextRange &textRange : m_ranges) {
        if (textRange.hasEqualStyle(text)) {
            textRange.appendText(text.text());
            merged = true;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KoGenStyle *ptr) { delete ptr; m_currentFontStyle = nullptr; }
```

#### AUTO 


```{c}
auto it = std::lower_bound(docIndex.singlePoints.constBegin(), docIndex.singlePoints.constEnd(), first, comp);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect& rect : reg.rects()) {
                if (rect.top() == 1 && rect.bottom() >= KS_rowMax) {
                    for (int i = rect.left(); i <= rect.right(); ++i) {
                        d->usedColumns.insert(i, true);
                    }
                } else if (rect.left() == 1 && rect.right() >= KS_colMax) {
                    for (int i = rect.top(); i <= rect.bottom(); ++i) {
                        d->usedRows.insert(i, true);
                    }
                } else {
                    d->usedArea.add(rect);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiScatter<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d_func()->helpLinkClicked(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->removeRows(position, number);
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->paste(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->storeUndo(true);
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->removeShiftLeft(rect);
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                break;
            }
        }
```

#### AUTO 


```{c}
auto texNode = static_cast<QSGSimpleTextureNode*>(node);
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                debugChartUiBubble<<"move Cat:"<<first<<':'<<r;
                ds->setCategoryDataRegion(CellRegion(region.table(), r.adjusted(1, 0, 1, 0)));
                break;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { slotSelected(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape* shape : shapes) {
        d->tableShape = dynamic_cast<TableShape*>(shape);
        if (d->tableShape)
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KoPathSegment & s : shapeSegments) {
            if (ignoredPoints.contains(s.first()) || ignoredPoints.contains(s.second()))
                continue;
            segments.append(s.mapped(m));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Element *el : toRemove)
        d->cells.removeAll(el);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (Qt::DockWidgetArea v) { d->locationChanged(v); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &oldname : m_configFiles) {
            QString newname = oldname;
            newname.replace(m_oldAppName, m_newAppName);
            if (oldname == newname) {
                continue;
            }
            QString oldfile = QStandardPaths::locate(QStandardPaths::GenericConfigLocation, oldname);
            if (!oldfile.isEmpty()) {
                qCDebug(CALLIGRA2MIGRATION)<<"config rename:"<<oldfile;
                QFile f(oldfile);
                QFileInfo fi(f);
                f.rename(fi.absolutePath() + '/' + newname);
                didSomething = true;
                qCDebug(CALLIGRA2MIGRATION)<<"config renamed:"<<f.fileName();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoTextRange *range : docIndex.overlapping) {
                if (range->rangeStart() < first)
                    continue;
                if (range->rangeStart() > last)
                    break;

                if (!range->hasRange()) {
                    if (range->rangeStart() >= first && range->rangeStart() <= last) {
                        ranges.insertMulti(range->rangeStart(), range);
                    }
                } else {
                    if (range->rangeStart() >= first && range->rangeStart() <= last) {
                        if (matchLast == -1 || range->rangeEnd() <= matchLast) {
                            if (range->rangeEnd() >= matchFirst) {
                                ranges.insertMulti(range->rangeStart(), range);
                            }
                        }
                    }
                    if (range->rangeEnd() >= first && range->rangeEnd() <= last) {
                        if (matchLast == -1 || range->rangeStart() <= matchLast) {
                            if (range->rangeStart() >= matchFirst) {
                                ranges.insertMulti(range->rangeEnd(), range);
                            }
                        }
                    }
                    if (range->rangeStart() >= first && range->rangeStart() <= last) {
                        if (matchLast == -1 || range->rangeEnd() >= matchLast) {
                            if (range->rangeEnd() >= matchFirst) {
                                ranges.insert(range->rangeStart(), range);
                            }
                        }
                    }
                }
            }
```

#### AUTO 


```{c}
_cimg_constructor_cpp11(repeat_values)
```

#### RANGE FOR STATEMENT 


```{c}
for(const RecentFileEntry &item : d->recents) {
        files << item.filePath;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ResourceGroupRequest *g : task->requests().requests()) {
        cmd->addCommand(new RemoveResourceGroupRequestCmd(g));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->restoringDone(); }
```

#### AUTO 


```{c}
auto margins = contentsMargins();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &s : files) {
        lst.prepend(s);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : m_project->resourceList()) {
        if (r->isShared() && !project.findResource(r->id())) {
            removedResources << r;
            removed << "Resource: " + r->name();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : sortedShapes) {
                QRectF r(itemRect(s));
                if (r.intersects(area)) {
                    r.moveTop(r.top() - yoffset);
                    newlayout[s] = r;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] () { d->updateTree(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QAction *a : m_designer->itemActions( ag ) ) {
        int pos = itemtypes.indexOf( a->objectName() );
        if ( pos >= 0 ) {
            QToolButton *tb = new QToolButton( w );
            tb->setObjectName( a->objectName() );
            tb->setIcon( a->icon() );
            tb->setText( a->text() );
            tb->setToolTip( itemTooltips.value( pos ) );
            tb->setCheckable( true );
            tblst[pos] = tb;
            connect(tb, SIGNAL(clicked(bool)), SLOT(slotInsertAction()));
            connect(this, SIGNAL(resetButtonState(bool)), tb, SLOT(setChecked(bool)));
        }
    }
```

#### AUTO 


```{c}
auto screen
```

#### RANGE FOR STATEMENT 


```{c}
for (QAbstractItemModel *m : m_datamodels) {
        if (!m_basemodels.contains(qobject_cast<ItemModelBase*>(m))) {
            delete m;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ScheduleManager *m :  project.allScheduleManagers()) {
        delete m;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(SheetBase* sheet : map->sheetList()) {
        item = new QListWidgetItem(sheet->sheetName(), m_dialog->m_sheetList);
        item->setCheckState(Qt::Checked);
        m_dialog->m_sheetList->addItem(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const CellBase &c : namedAreaConsumersList) {
        generateDependencies(c, c.formula());
        region.add(c.cellPosition(), c.sheet());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (qreal guidePos : guidesData->horizontalGuideLines()) {
        qreal distance = qAbs(guidePos - mousePosition.y());
        if (distance < minHorzDistance) {
            snappedPoint.setY(guidePos);
            minHorzDistance = distance;
            m_orientation |= Qt::Horizontal;
        }
    }
```

#### AUTO 


```{c}
auto res = colWidths.search(col, v, firstCol, lastCol);
```

#### RANGE FOR STATEMENT 


```{c}
for (Resource *r : p.resourceList()) {
                    Resource *res = m_project->resource(r->id());
                    if (res && res->isShared()) {
                        for (const Appointment *a : r->appointments(sm->scheduleId())) {
                            Appointment *app = new Appointment(*a);
                            app->setAuxcilliaryInfo(p.name());
                            res->addExternalAppointment(p.id(), app);
                            debugPlan<<res->name()<<"added:"<<app->auxcilliaryInfo()<<app;
                        }
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (KoShape *s : shapesInArea) {
            QRectF sr = itemRect(s);
            sr.moveLeft(area.right());
            newlayout[s] = sr;
            debugChartLayout<<"shift in area:"<<dbg(s)<<sr;
            area.setRight(sr.right() + m_spacing.x());
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QModelIndex &idx : deselected.indexes()) {
        if (m_tasks.contains(idx)) {
            m_tasks.removeAt(m_tasks.indexOf(idx));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QRect r : region.rects()) {
            if (r.left() >= first) {
                ds->setXDataRegion(CellRegion(region.table(), r.adjusted(-count, 0, -count, 0)));
                debugChartUiBubble<<"move X:"<<first<<':'<<r<<region.toString()<<':'<<ds->xDataRegion().toString();
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SheetBase* sheet : map->sheetList())
            cellsCount += sheet->formulaStorage()->count();
```

#### AUTO 


```{c}
auto res = d->hasPageBreak.search(col, v, firstCol, lastCol);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDockWidget::DockWidgetFeatures f) { d->featuresChanged(f); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const SharedSubStyle& ss : style.subStyles()) {
        hash ^= ss->koHash();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { d->addRemoveColors(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QColorDialog *dlg : lst) {
        dlg->reject();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { d->replace(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, suggestion] { replaceWord(suggestion); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (qreal r, const QPointF pt) { requestZoomRelative(r, pt); }
```

#### RANGE FOR STATEMENT 


```{c}
for (BaseStorage *storage : storages)
        storage->resetUndo();
```

#### AUTO 


```{c}
auto listFormat = textList->format();
```

#### RANGE FOR STATEMENT 


```{c}
for (StorageBase *storage : storages)
        storage->insertShiftDown(rect);
```

