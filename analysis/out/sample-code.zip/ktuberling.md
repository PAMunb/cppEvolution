#### LAMBDA EXPRESSION 


```{c}
[this, soundsButton] {
      m_soundEnabled = !m_soundEnabled;
      soundsButton->setIcon(QPixmap(m_soundEnabled ? ":/audio-volume-high.png" : ":/audio-volume-muted.png"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[job, &eventLoop, &success] { success = !job->error(); eventLoop.quit(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
      m_themesWidget->showFullScreen();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &mimeName : imageWriterMimetypes)
  {
    const QMimeType mime = mimedb.mimeTypeForName(mimeName);
    if (mime.isValid())
    {
      QStringList suffixes;
      for(const QString &suffix : mime.suffixes())
      {
          suffixes << QStringLiteral("*.%1").arg(suffix);
      }

      // Favor png
      const QString pattern = i18nc("%1 is mimetype and %2 is the file extensions", "%1 (%2)", mime.comment(), suffixes.join(' '));
      if (mimeName == "image/png")
      {
        patterns.prepend(pattern);
      }
      else
      {
        patterns << pattern;
      }
    }
  }
```

#### AUTO 


```{c}
auto it = sortedByName.begin();
```

#### AUTO 


```{c}
const auto &mimeName
```

#### RANGE FOR STATEMENT 


```{c}
for (QString &suffix : suffixes) {
        suffix = suffix.mid(1); // Remove the * from the start, we want the actual suffix
      }
```

#### LAMBDA EXPRESSION 


```{c}
[this, boardFile] {
      m_playground->loadPlayGround(boardFile);
      m_themesWidget->hide();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &suffix : mime.suffixes())
      {
          suffixes << QStringLiteral("*.%1").arg(suffix);
      }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto mimeName : imageWriterMimetypes)
  {
    const QMimeType mime = mimedb.mimeTypeForName(mimeName);
    if (mime.isValid())
    {
      qDebug() << mimeName << mime.comment()   << mime.suffixes();
      QStringList suffixes;
      for(const QString &suffix : mime.suffixes())
      {
          suffixes << QString("*.%1").arg(suffix);
      }

      // Favor png
      const QString pattern = i18nc("%1 is mimetype and %2 is the file extensions", "%1 (%2)", mime.comment(), suffixes.join(' '));
      if (mimeName == "image/png")
      {
        patterns.prepend(pattern);
      }
      else
      {
        patterns << pattern;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &suffix : selectedSuffixes) {
    if (url.path().endsWith(suffix)) {
      validSuffix = true;
      break;
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this, soundFile] {
    changeLanguage(soundFile);
  }
```

#### AUTO 


```{c}
auto mimeName
```

#### LAMBDA EXPRESSION 


```{c}
[this, t, board] {
    if (t->isChecked())
    {
      changeGameboard(board);
    }
  }
```

#### LAMBDA EXPRESSION 


```{c}
[this, mainWidget] {
      m_themesWidget->showFullScreen();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &systemLanguage : systemLanguages)
    {
      QString sound = sounds.value(systemLanguage);
      if (!sound.isEmpty())
      {
        language = sound;
        break;
      }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto mimeName : imageWriterMimetypes)
  {
    const QMimeType mime = mimedb.mimeTypeForName(mimeName);
    if (mime.isValid())
    {
      QStringList suffixes;
      for(const QString &suffix : mime.suffixes())
      {
          suffixes << QString("*.%1").arg(suffix);
      }

      // Favor png
      const QString pattern = i18nc("%1 is mimetype and %2 is the file extensions", "%1 (%2)", mime.comment(), suffixes.join(' '));
      if (mimeName == "image/png")
      {
        patterns.prepend(pattern);
      }
      else
      {
        patterns << pattern;
      }
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &suffix : mime.suffixes())
      {
          suffixes << QString("*.%1").arg(suffix);
      }
```

