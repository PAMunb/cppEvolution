#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &id) {
                    return id.startsWith("UTC"); // krazy:exclude=strings
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (IncidenceObserver *o : qAsConst(d->mObservers)) {
            o->incidenceUpdated(uid(), rid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Incidence::Ptr instance : instances) {
        deleteIncidence(instance);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dt : std::as_const(dateTimeList)) {
        icalcomponent_add_property(parent, writeICalDateTimeProperty(ICAL_EXDATE_PROPERTY, dt, tzUsedList));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &category : d->mCategories) {
        category = category.trimmed();
    }
```

#### AUTO 


```{c}
auto calendar = MemoryCalendar::Ptr(new MemoryCalendar(QTimeZone::utc()));
```

#### AUTO 


```{c}
auto it = events.cbegin(), end = events.cend();
```

#### AUTO 


```{c}
const auto tzids = QTimeZone::availableTimeZoneIds(tz.daylight.utcOffset);
```

#### LAMBDA EXPRESSION 


```{c}
[](const T &val) {
        return QVariant::fromValue(val);
    }
```

#### AUTO 


```{c}
auto attendees = incidenceBase->attendees();
```

#### AUTO 


```{c}
auto it = std::find_if(d->mAttendees.cbegin(), d->mAttendees.cend(), [&uid](const Attendee &a) {
        return a.uid() == uid;
    });
```

#### AUTO 


```{c}
auto matchFunc = [](const Alarm::Ptr &a, const Alarm::Ptr &b) {
        return *a == *b;
    };
```

#### AUTO 


```{c}
auto it = dts.begin();
```

#### AUTO 


```{c}
auto [it1, it2] = std::mismatch(list.cbegin(), list.cend(), otherList.cbegin(), otherList.cend());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tzid : candidates) {
        const QTimeZone candidate(tzid);
        // This would be a fallback, candidate has transitions, but the phase does not
        if (candidate.hasTransitions() == phase.transitions.isEmpty()) {
            matchedCandidates.insert(0, candidate);
            continue;
        }

        // Without transitions, we can't do any more precise matching, so just
        // accept this candidate and be done with it
        if (!candidate.hasTransitions() && phase.transitions.isEmpty()) {
            return candidate;
        }

        // Calculate how many transitions this candidate shares with the phase.
        // The candidate with the most matching transitions will win.
        auto begin = std::lower_bound(phase.transitions.cbegin(), phase.transitions.cend(), now.addYears(-20));
        // If no transition older than 20 years is found, we will start from beginning
        if (begin == phase.transitions.cend()) {
            begin = phase.transitions.cbegin();
        }
        auto end = std::upper_bound(begin, phase.transitions.cend(), now);
        int matchedTransitions = 0;
        for (auto it = begin; it != end; ++it) {
            const auto &transition = *it;
            const QTimeZone::OffsetDataList candidateTransitions = candidate.transitions(transition, transition);
            if (candidateTransitions.isEmpty()) {
                continue;
            }
            ++matchedTransitions; // 1 point for a matching transition
            const auto candidateTransition = candidateTransitions[0];
            // FIXME: THIS IS HOW IT SHOULD BE:
            //const auto abvs = transition.abbreviations();
            const auto abvs = phase.abbrevs;
            for (const auto &abv : abvs) {
                if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                    matchedTransitions += 1024; // lots of points for a transition with a matching abbreviation
                    break;
                }
            }
        }
        matchedCandidates.insert(matchedTransitions, candidate); 
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RecurrenceRule *rule : qAsConst(r->d->mRRules)) {
        out << rule;
    }
```

#### AUTO 


```{c}
const auto dtrecur = dt.toTimeZone(d->mStartDateTime.timeZone());
```

#### AUTO 


```{c}
auto it = relatedToUid.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &rDt : d->mRDateTimes) {
        auto periodIt = oldPeriods.find(rDt);
        periodIt->shiftTimes(oldTz, newTz);
        rDt = rDt.toTimeZone(oldTz);
        rDt.setTimeZone(newTz);
        // Now there are QDateTime objects in the hash? is this shifting times?
        d->mRDateTimePeriods.insert(rDt, *periodIt);
    }
```

#### AUTO 


```{c}
const auto itEnd = std::upper_bound(it, d->mCachedDates.constEnd(), enddt);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : qAsConst(other.mAlarms)) {
        Alarm::Ptr b(new Alarm(*alarm.data()));
        b->setParent(q);
        mAlarms.append(b);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto alarm : d->mAlarms) {
            alarm->shiftTimes(oldZone, newZone);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto rule : d->mExRules) {
                allowed = allowed && !rule->recursAt(prevDT);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[&uid](const Incidence::Ptr &in) {
        return in->schedulingID() == uid;
    }
```

#### AUTO 


```{c}
auto it = std::find(d_ptr->mComments.begin(), d_ptr->mComments.end(), comment);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &table : d->mDeletedIncidences) {
        table.clear();
    }
```

#### AUTO 


```{c}
auto it = std::find_if(d_ptr->mAttendees.cbegin(), d_ptr->mAttendees.cend(), [&mails](const Attendee &a) {
        return mails.contains(a.email());
    });
```

#### AUTO 


```{c}
auto role
```

#### AUTO 


```{c}
const auto rid = recurrenceId();
```

#### AUTO 


```{c}
auto it = std::lower_bound(c.cbegin(), c.cend(), v);
```

#### AUTO 


```{c}
auto extIt = dateTimeList.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (Incidence::Ptr incidence : incidences) {
            QHash<Incidence::Ptr, bool>::Iterator it = d->mIncidenceVisibility.find(incidence);
            if (it != d->mIncidenceVisibility.end()) {
                *it = isVisible;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &cat : std::as_const(thisCats)) {
            if (!uniqueCategories.contains(cat)) {
                uniqueCategories.append(cat);
            }
        }
```

#### AUTO 


```{c}
const auto &rule
```

#### AUTO 


```{c}
const auto &conf
```

#### AUTO 


```{c}
auto dtsTzId = std::find_if(tzids.cbegin(), tzids.cend(),
                                            [](const QByteArray &id) {
                                                return id.startsWith("UTC");
                                            });
```

#### AUTO 


```{c}
const auto i = d->mContacts.indexOf(contact);
```

#### AUTO 


```{c}
auto it = mPropertyParameters.cbegin();
```

#### AUTO 


```{c}
const auto &ad
```

#### AUTO 


```{c}
auto vtimezone = ICalTimeZoneParser::vcaltimezoneFromQTimeZone(QTimeZone("Europe/Prague"), QDateTime({1970, 1, 1}, {0, 0}));
```

#### AUTO 


```{c}
const auto &incidence
```

#### LAMBDA EXPRESSION 


```{c}
[this, &alarmList, &from, &to](const Todo::Ptr &t) {
        if (!t->isCompleted()) {
            appendAlarms(alarmList, t, from, to);
            if (t->recurs()) {
                appendRecurringAlarms(alarmList, t, from, to);
            } else {
                appendAlarms(alarmList, t, from, to);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Journal::Ptr &journal : allJournals) {
        const QDate journalStart = journal->dtStart().toTimeZone(start.timeZone()).date();
        if (journal->dtStart().isValid() &&
                journalStart >= start.date() &&
                journalStart <= end.date()) {
            journals << journal;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto role : {IncidenceBase::RoleStartTimeZone, IncidenceBase::RoleEndTimeZone}) {
        const auto dt = incidence->dateTime(role);
        if (dt.isValid() && dt.timeZone() != QTimeZone::utc()) {
            if (!d->mTimeZones.contains(dt.timeZone())) {
                d->mTimeZones.push_back(dt.timeZone());
            }
        }
    }
```

#### AUTO 


```{c}
auto &table
```

#### AUTO 


```{c}
auto it2 = alarms.constBegin();
```

#### AUTO 


```{c}
auto visibleIt = d->mIncidenceVisibility.find(incidence);
```

#### AUTO 


```{c}
auto calendar3 = MemoryCalendar::Ptr(new MemoryCalendar(QTimeZone::utc()));
```

#### AUTO 


```{c}
auto it = todoList.cbegin(), end = todoList.cend();
```

#### AUTO 


```{c}
const auto rightNow = QDateTime::currentDateTimeUtc().toTimeZone(nextOccurrenceDateTime.timeZone());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dt : std::as_const(dateTimeList)) {
        Period period = incidence->recurrence()->rDateTimePeriod(dt);
        if (period.isValid()) {
            icaldatetimeperiodtype tp;
            tp.time = icaltime_null_time();
            tp.period = icalperiodtype_null_period();
            tp.period.start = writeICalDateTime(period.start());
            if (period.hasDuration()) {
                tp.period.duration = writeICalDuration(period.duration());
            } else {
                tp.period.end = writeICalDateTime(period.end());
            }
            icalcomponent_add_property(parent, icalproperty_new_rdate(tp));
        } else {
            icalcomponent_add_property(parent, writeICalDateTimeProperty(ICAL_RDATE_PROPERTY, dt, tzUsedList));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &time : times) {
                tmp = QDateTime(tmpday, time, start.timeZone());
                if (endDateForStart(tmp) >= kdate) {
                    result << tmp;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment::Ptr &attachment : qAsConst(d->mAttachments)) {
        if (attachment->mimeType() == mime) {
            attachments.append(attachment);
        }
    }
```

#### AUTO 


```{c}
const auto it = std::upper_bound(d->mRDateTimes.constBegin(), d->mRDateTimes.constEnd(), nextDT);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : std::as_const(dateList)) {
        icalcomponent_add_property(parent, icalproperty_new_exdate(writeICalDate(date)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tzid : candidates) {
        const QTimeZone candidate(tzid);
        // This would be a fallback, candidate has transitions, but the phase does not
        if (candidate.hasTransitions() == phase.transitions.isEmpty()) {
            matchedCandidates.insert(0, candidate);
            continue;
        }

        // Without transitions, we can't do any more precise matching, so just
        // accept this candidate and be done with it
        if (!candidate.hasTransitions() && phase.transitions.isEmpty()) {
            return candidate;
        }

        // Calculate how many transitions this candidate shares with the phase.
        // The candidate with the most matching transitions will win.
        auto begin = std::lower_bound(phase.transitions.cbegin(), phase.transitions.cend(), now.addYears(-20));
        // If no transition older than 20 years is found, we will start from beginning
        if (begin == phase.transitions.cend()) {
            begin = phase.transitions.cbegin();
        }
        auto end = std::upper_bound(begin, phase.transitions.cend(), now);
        int matchedTransitions = 0;
        for (auto it = begin; it != end; ++it) {
            const auto &transition = *it;
            const QTimeZone::OffsetDataList candidateTransitions = candidate.transitions(transition, transition);
            if (candidateTransitions.isEmpty()) {
                continue;
            }
            ++matchedTransitions; // 1 point for a matching transition
            const auto candidateTransition = candidateTransitions[0];
            // FIXME: THIS IS HOW IT SHOULD BE:
            // const auto abvs = transition.abbreviations();
            const auto abvs = phase.abbrevs;
            for (const auto &abv : abvs) {
                if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                    matchedTransitions += 1024; // lots of points for a transition with a matching abbreviation
                    break;
                }
            }
        }
        matchedCandidates.insert(matchedTransitions, candidate);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parameter : sl) {
                icalparameter *param = icalparameter_new_from_string(parameter.toUtf8());
                if (param) {
                    icalproperty_add_parameter(p, param);
                }
            }
```

#### AUTO 


```{c}
auto later = now.addSecs(1);
```

#### AUTO 


```{c}
auto e2 = e1.clone();
```

#### AUTO 


```{c}
const auto &cat
```

#### AUTO 


```{c}
auto dr = d->dtRecurrence().toTimeZone(oldZone);
```

#### RANGE FOR STATEMENT 


```{c}
for (FreeBusyPeriod p : qAsConst(d->mBusyPeriods)) {
            p.shiftTimes(oldZone, newZone);
        }
```

#### AUTO 


```{c}
const auto event1 = events1[0];
```

#### AUTO 


```{c}
const auto &at
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &qtz : qAsConst(tzUsedList)) {
        if (qtz != QTimeZone::utc()) {
            icaltimezone *tz = ICalTimeZoneParser::icaltimezoneFromQTimeZone(qtz, earliestTzDt[qtz]);
            if (!tz) {
                qCritical() << "bad time zone";
            } else {
                icalcomponent *tzcomponent = icaltimezone_get_component(tz);
                icalcomponent_add_component(component, component);
                text.append(icalcomponent_as_ical_string(tzcomponent));
                icaltimezone_free(tz, 1);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e : d->mIncidences[Incidence::TypeEvent]) {
        const auto event = e.staticCast<Event>();
        QDateTime rStart = event->dtStart();
        if (nd.isValid() && nd < rStart) {
            continue;
        }
        if (inclusive && st.isValid() && rStart < st) {
            continue;
        }

        if (!event->recurs()) { // non-recurring events
            QDateTime rEnd = event->dtEnd();
            if (st.isValid() && rEnd < st) {
                continue;
            }
            if (inclusive && nd.isValid() && nd < rEnd) {
                continue;
            }
        } else { // recurring events
            switch (event->recurrence()->duration()) {
            case -1: // infinite
                if (inclusive) {
                    continue;
                }
                break;
            case 0: // end date given
            default: // count given
                QDateTime rEnd(event->recurrence()->endDate(), QTime(23, 59, 59, 999), ts);
                if (!rEnd.isValid()) {
                    continue;
                }
                if (st.isValid() && rEnd < st) {
                    continue;
                }
                if (inclusive && nd.isValid() && nd < rEnd) {
                    continue;
                }
                break;
            } // switch(duration)
        } // if(recurs)

        eventList.append(event);
    }
```

#### AUTO 


```{c}
auto it = alarms.cbegin(), end = alarms.cend();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Attachment &att) { return QVariant::fromValue(att); }
```

#### AUTO 


```{c}
const auto& transitions = prague.transitions(QDateTime({1949, 6, 6}, {0, 0}), QDateTime({1979, 6, 6}, {0, 0}));
```

#### AUTO 


```{c}
auto dateList = event.recurrence()->timesInInterval(start, end);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &attachment : qAsConst(d->mAttachments)) {
        if (attachment.mimeType() == mime) {
            attachments.append(attachment);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &attachment : qAsConst(d->mAttachments)) {
        out << attachment;
    }
```

#### AUTO 


```{c}
auto periodIt = oldPeriods.find(rDt);
```

#### AUTO 


```{c}
const auto events2 = calendar2->events();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &contact : contacts) {
        icalcomponent_add_property(parent, icalproperty_new_contact(contact.toUtf8().constData()));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &alarmList, &from, &to](const Event::Ptr &e) {
        if (e->recurs()) {
            appendRecurringAlarms(alarmList, e, from, to);
        } else {
            appendAlarms(alarmList, e, from, to);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &line: lines) {
        if (line.startsWith(QByteArray("DTSTART"))) {
            QCOMPARE(line.chopped(1), dtStartData);
            break;
        }
    }
```

#### AUTO 


```{c}
auto it = props.cbegin();
```

#### AUTO 


```{c}
auto d = static_cast<EventPrivate *>(d_ptr);
```

#### AUTO 


```{c}
auto calendar1 = MemoryCalendar::Ptr(new MemoryCalendar(QTimeZone::utc()));
```

#### AUTO 


```{c}
const auto dts = d->datesForInterval(interval, recurrenceType());
```

#### AUTO 


```{c}
const auto events3 = calendar3->events();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Conference &conf : qAsConst(d->mConferences)) {
        out << conf;
    }
```

#### AUTO 


```{c}
const auto icalDuration = icaldurationtype_from_string(duration.toUtf8().constData());
```

#### AUTO 


```{c}
auto it = std::find_if(incidences.cbegin(), itEnd, [&uid](const Incidence::Ptr &in) {
        return in->schedulingID() == uid;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &comment : comments) {
        icalcomponent_add_property(parent, icalproperty_new_comment(comment.toUtf8().constData()));
    }
```

#### AUTO 


```{c}
const auto LOCAL_TZ = "UTC";
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &al : alarms) {
        if (al && al->hasStartOffset()) {
            Duration offsetDuration = al->startOffset();
            int offs = offsetDuration.asSeconds();
            if (offs > 0) {
                offsetDuration = Duration(-offs);
            }
            al->setStartOffset(offsetDuration);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : qAsConst(d->mAlarms)) {
        if (alarm->enabled()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto calendar2 = MemoryCalendar::Ptr(new MemoryCalendar(QTimeZone::utc()));
```

#### AUTO 


```{c}
auto i2 = i1.clone();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto rule : d->mExRules) {
                allowed = allowed && !rule->recursAt(nextDT);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &parameter : sl) {
                icalparameter *param = icalparameter_new_from_string(parameter.toUtf8().constData());
                if (param) {
                    icalproperty_add_parameter(p, param);
                }
            }
```

#### AUTO 


```{c}
auto it = std::find(d_ptr->mContacts.begin(), d_ptr->mContacts.end(), contact);
```

#### AUTO 


```{c}
auto t2 = t1.clone();
```

#### AUTO 


```{c}
const auto &comment
```

#### AUTO 


```{c}
auto &incidence
```

#### AUTO 


```{c}
auto it = properties.cbegin();
```

#### AUTO 


```{c}
auto noAllocString = QStringView{dtStr};
```

#### AUTO 


```{c}
const auto &dt
```

#### AUTO 


```{c}
const auto attachmentList = attachments();
```

#### AUTO 


```{c}
auto dtsTzId = std::find_if(tzids.cbegin(), tzids.cend(),
                                            [](const QByteArray &id) {
                                                return id.startsWith("UTC"); //krazy:exclude=strings
                                            });
```

#### AUTO 


```{c}
auto alarm
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee::Ptr &attendee : qAsConst(i->d->mAttendees)) {
        out << attendee;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &transition : transitions) {
        if (transition.atUtc.date().year() == 1978) {
            occursIn1978 = true;
        }
    }
```

#### AUTO 


```{c}
const auto candidates = QTimeZone::availableTimeZoneIds(phase.utcOffset);
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
        observer->calendarIncidenceChanged(incidence);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const T &val) { return QVariant::fromValue(val); }
```

#### LAMBDA EXPRESSION 


```{c}
[&eventList](const Event::Ptr &event) {
        eventList.append(event);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const char *str1, const char *str2) {
                    return strcmp(str1, str2) < 0;
                }
```

#### AUTO 


```{c}
auto c = custom.cbegin();
```

#### AUTO 


```{c}
const auto dt = incidence->dateTime(role);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &elem : set2) {
        const auto it = std::lower_bound(beginIt, set1.end(), elem);
        if (it != set1.end() && *it == elem) {
            beginIt = set1.erase(it);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &tzid : candidates) {
        const QTimeZone candidate(tzid);
        // This would be a fallback, candidate has transitions, but the phase does not
        if (candidate.hasTransitions() == phase.transitions.isEmpty()) {
            matchedCandidates.insert(0, candidate);
            continue;
        }

        // Without transitions, we can't do any more precise matching, so just
        // accept this candidate and be done with it
        if (!candidate.hasTransitions() && phase.transitions.isEmpty()) {
            return candidate;
        }

        // Calculate how many transitions this candidate shares with the phase.
        // The candidate with the most matching transitions will win.
        auto begin = std::lower_bound(phase.transitions.cbegin(), phase.transitions.cend(), now.addYears(-20));
        // If no transition older than 20 years is found, we will start from beginning
        if (begin == phase.transitions.cend()) {
            begin = phase.transitions.cbegin();
        }
        auto end = std::upper_bound(begin, phase.transitions.cend(), now);
        int matchedTransitions = 0;
        for (auto it = begin; it != end; ++it) {
            const auto &transition = *it;
            const QTimeZone::OffsetDataList candidateTransitions = candidate.transitions(transition, transition);
            if (candidateTransitions.isEmpty()) {
                continue;
            }
            ++matchedTransitions; // 1 point for a matching transition
            const auto candidateTransition = candidateTransitions[0];
            // FIXME: THIS IS HOW IT SHOULD BE:
            //const auto abvs = transition.abbreviations();
            const auto abvs = phase.abbrevs;
            for (const auto &abv : abvs) {
                if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                    matchedTransitions += 1024; // lots of points for a transition with a matching abbreviation
                    break;
                }
            }
        }
        matchedCandidates.insert(matchedTransitions, candidate);
    }
```

#### AUTO 


```{c}
const auto it = std::lower_bound(begin, end, v);
```

#### AUTO 


```{c}
auto event = mkEvent(allDay, dtStart, dtEnd);
```

#### AUTO 


```{c}
auto it = alarms.constBegin();
```

#### AUTO 


```{c}
const auto candidateTransition = candidateTransitions[0];
```

#### AUTO 


```{c}
const auto events = cal->events();
```

#### AUTO 


```{c}
const auto &todoPtr
```

#### RANGE FOR STATEMENT 


```{c}
for (const Period &p : qAsConst(list)) {
        d->mBusyPeriods << FreeBusyPeriod(p);
    }
```

#### AUTO 


```{c}
const auto &abv
```

#### AUTO 


```{c}
auto beginIt = set1.begin();
```

#### AUTO 


```{c}
auto it = std::remove_if(journalList->begin(), journalList->end(), [=](const Incidence::Ptr &incidence) {
        return !filterIncidence(incidence);
    });
```

#### AUTO 


```{c}
auto event
```

#### RANGE FOR STATEMENT 


```{c}
for (auto role : { IncidenceBase::RoleStartTimeZone, IncidenceBase::RoleEndTimeZone }) {
        const auto dt = incidence->dateTime(role);
        if (dt.isValid()) {
            if (dt.timeZone() == QTimeZone::utc()) {
                continue;
            }
            const auto prev = earliest->value(incidence->dtStart().timeZone());
            if (!prev.isValid() || incidence->dtStart() < prev) {
                earliest->insert(incidence->dtStart().timeZone(), prev);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Alarm::Ptr &a, const Alarm::Ptr &b) {
        return *a == *b;
    }
```

#### AUTO 


```{c}
const auto otherAttachmentList = i2->attachments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rule : qAsConst(d->mRRules)) {
            QDateTime dt = rule->getNextDate(nextDT);
            if (dt.isValid()) {
                dates << dt;
            }
        }
```

#### AUTO 


```{c}
const auto [it1, it2] = std::mismatch(alarmList.cbegin(), alarmList.cend(), otherAlarmsList.cbegin(), otherAlarmsList.cend());
```

#### LAMBDA EXPRESSION 


```{c}
[&uid](const Attendee &a) {
        return a.uid() == uid;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
        observer->calendarIncidenceAdditionCanceled(incidence);
    }
```

#### AUTO 


```{c}
const auto &earliest = transitions.first().atUtc;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &qtz : qAsConst(zones)) {
            icaltimezone *icaltz = ICalTimeZoneParser::icaltimezoneFromQTimeZone(qtz, earliestTz[qtz]);
            if (!icaltz) {
                qCritical() << "bad time zone";
            } else {
                icalcomponent *tz = icalcomponent_new_clone(icaltimezone_get_component(icaltz));
                icalcomponent_add_component(message, tz);
                icaltimezone_free(icaltz, 1);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : qAsConst(d->mAlarms)) {
        out << alarm;
    }
```

#### AUTO 


```{c}
const auto ts = timeZone.isValid() ? timeZone : this->timeZone();
```

#### AUTO 


```{c}
const auto &reRule = *it;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &incidence : inc) {
        //     qDebug() << " ->" << incidence->summary() << "<-";

        //     incidence->recurrence()->dump();

        QDate dt(1996, 7, 1);
        if (outstream) {
            // Output to file for testing purposes
            int nr = 0;
            while (dt.year() <= 2020 && nr <= 500) {
                if (incidence->recursOn(dt, viewZone)) {
                    (*outstream) << dt.toString(Qt::ISODate) << '\n';
                    nr++;
                }
                dt = dt.addDays(1);
            }
        } else {
            dt = QDate(2005, 1, 1);
            while (dt.year() < 2007) {
                if (incidence->recursOn(dt, viewZone)) {
                    qDebug() << dt.toString(Qt::ISODate);
                }
                dt = dt.addDays(1);
            }
        }
    }
```

#### AUTO 


```{c}
auto it = std::find_if(d_ptr->mAttendees.cbegin(), d_ptr->mAttendees.cend(), [&email](const Attendee &att) {
        return att.email() == email;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &at : attachments) {
        icalcomponent_add_property(parent, writeAttachment(at));
    }
```

#### AUTO 


```{c}
const auto &transit = transits.at(i);
```

#### AUTO 


```{c}
auto it = d->mIncidences[incidence->type()].constFind(incidence->uid()), end = d->mIncidences[incidence->type()].constEnd();
```

#### AUTO 


```{c}
auto icalTz = icalcomponentFromQTimeZone(qtz, earliest);
```

#### AUTO 


```{c}
const auto &in
```

#### AUTO 


```{c}
const auto dts = r.timesInInterval(klocalStart, maxTime);
```

#### AUTO 


```{c}
auto &rDt
```

#### LAMBDA EXPRESSION 


```{c}
[&todoList](const Todo::Ptr &todo) {
        todoList.append(todo);
    }
```

#### AUTO 


```{c}
const auto yesterday = QDateTime::currentDateTimeUtc().addDays(-1);
```

#### AUTO 


```{c}
const auto abvs = phase.abbrevs;
```

#### AUTO 


```{c}
auto it = std::find(d->mComments.begin(), d->mComments.end(), comment);
```

#### AUTO 


```{c}
const auto timesInInterval = event->recurrence()->timesInInterval(start.addSecs(-20), end.addSecs(20));
```

#### AUTO 


```{c}
auto savedTimeZoneId = d->mCalendar->timeZoneId();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &id) {
                                                return id.startsWith("UTC");
                                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &incidence : list) {
                d->mNotebookIncidences.remove(old, incidence);
                d->mNotebookIncidences.insert(notebook, incidence);
            }
```

#### AUTO 


```{c}
auto end = std::upper_bound(begin, phase.transitions.cend(), now);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : qAsConst(d->mRDates)) {
            kdt.setDate(date);
            if (kdt > nextDT) {
                dates << kdt;
                break;
            }
        }
```

#### AUTO 


```{c}
auto duration = format.durationFromString(QStringLiteral("PT2H"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &at : attachments) {
                attach = icalattach_new_from_url(QFile::encodeName(at).constData());
                icalcomponent_add_property(a, icalproperty_new_attach(attach));
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *str : properties) {
            hasher.addData(str);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDateTime &dt : timesInInterval) {
        QCOMPARE(expectedEventOccurrences.removeAll(dt), 1);
    }
```

#### AUTO 


```{c}
const auto viewZone = tz.isEmpty() ? cal->timeZone() : QTimeZone(tz.toUtf8());
```

#### AUTO 


```{c}
auto &category
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &i : l) {
                if (i != incidence) {
                    tempList.append(i);
                }
            }
```

#### AUTO 


```{c}
auto rl = d->mRRules[i]->endDt();
```

#### AUTO 


```{c}
const auto it = std::upper_bound(dts.begin(), dts.end(), fromDate);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category : std::as_const(d->mCategoryList)) {
        if (incidenceCategories.contains(category)) {
            isFound = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto conference = conferences.at(0);
```

#### AUTO 


```{c}
const auto it = std::upper_bound(d->mCachedDates.constBegin(), d->mCachedDates.constEnd(), fromDate);
```

#### AUTO 


```{c}
const auto event2 = events2[0];
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &table : d->mIncidencesForDate) {
        table.clear();
    }
```

#### AUTO 


```{c}
const auto res = QString::compare(i1->categoriesStr(), i2->categoriesStr(), Qt::CaseSensitive);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &todoPtr : std::as_const(d->mTodosRelate)) {
        todoPtr->setRelatedTo(todoPtr->relatedTo());
    }
```

#### AUTO 


```{c}
auto it = mIncidences[type].find(uid), end = mIncidences[type].end();
```

#### AUTO 


```{c}
const auto phase = icalZone.standard;
```

#### AUTO 


```{c}
const auto &event
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i : list) {
        serializeQDateTimeAsKDateTime(out, i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& transition : transitions) {
        if(transition.atUtc.date().year() == 1978) {
            occursIn1978 = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &incidence : inc) {
        qDebug() << "*+*+*+*+*+*+*+*+*+*";
        qDebug() << " ->" << incidence->summary() << "<-";

        incidence->recurrence()->dump();

        QDateTime dt = incidence->recurrence()->endDateTime();
        int i = 0;
        if (outstream) {
            if (!dt.isValid()) {
                if (viewZone.isValid()) {
                    dt = QDateTime(QDate(2011, 1, 1), QTime(0, 0, 1), viewZone);
                } else {
                    dt = QDateTime(QDate(2011, 1, 1), QTime(0, 0, 1));
                }
            } else {
                dt = dt.addYears(2);
            }
            qDebug() << "-------------------------------------------";
            qDebug() << " *~*~*~*~ Starting with date:" << dumpTime(dt, viewZone);
            // Output to file for testing purposes
            while (dt.isValid() && i < 500) {
                ++i;
                dt = incidence->recurrence()->getPreviousDateTime(dt);
                if (dt.isValid()) {
                    (*outstream) << dumpTime(dt, viewZone) << '\n';
                }
            }
        } else {
            if (!dt.isValid()) {
                dt = QDateTime(QDate(2005, 7, 31), QTime(23, 59, 59), Qt::UTC);
            } else {
                dt = dt.addYears(2);
            }
            incidence->recurrence()->dump();
            qDebug() << "-------------------------------------------";
            qDebug() << " *~*~*~*~ Starting with date:" << dumpTime(dt, viewZone);
            // Output to konsole
            while (dt.isValid() && i < 50) {
                ++i;
                qDebug() << "-------------------------------------------";
                dt = incidence->recurrence()->getPreviousDateTime(dt);
                if (dt.isValid()) {
                    qDebug() << " *~*~*~*~ Previous date is:" << dumpTime(dt, viewZone);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto it = journals.cbegin(), end = journals.cend();
```

#### AUTO 


```{c}
const auto &transition = *it;
```

#### AUTO 


```{c}
const auto TEST_TZ = "Europe/Paris";
```

#### AUTO 


```{c}
const auto &elem
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : periods) {
        d->mBusyPeriods.append(FreeBusyPeriod(p.start(), p.end()));
    }
```

#### AUTO 


```{c}
auto rule
```

#### LAMBDA EXPRESSION 


```{c}
[](const Attendee &a) { return QVariant::fromValue(a); }
```

#### AUTO 


```{c}
auto itOther = other.mPropertyParameters.constFind(it.key());
```

#### AUTO 


```{c}
auto it = mProperties.cbegin();
```

#### AUTO 


```{c}
auto result = event->startDateTimesForDate(testDate, tz);
```

#### AUTO 


```{c}
const auto event3 = events3[0];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &incidence : d->mIncidences[Incidence::TypeTodo]) {
        const auto todo = incidence.staticCast<Todo>();
        if (!isVisible(todo)) {
            continue;
        }

        QDateTime rStart = todo->hasDueDate() ? todo->dtDue() :
                           todo->hasStartDate() ? todo->dtStart() : QDateTime();
        if (!rStart.isValid()) {
            continue;
        }

        if (!todo->recurs()) {   // non-recurring todos
            if (nd.isValid() && nd < rStart) {
                continue;
            }
            if (st.isValid() && rStart < st) {
                continue;
            }
        } else { // recurring events
            switch (todo->recurrence()->duration()) {
            case -1: // infinite
                break;
            case 0: // end date given
            default: // count given
                QDateTime rEnd(todo->recurrence()->endDate(), QTime(23, 59, 59, 999), ts);
                if (!rEnd.isValid()) {
                    continue;
                }
                if (st.isValid() && rEnd < st) {
                    continue;
                }
                break;
            } // switch(duration)
        } //if(recurs)

        todoList.append(todo);
    }
```

#### AUTO 


```{c}
auto dtsTzId = std::find_if(tzids.cbegin(), tzids.cend(), [](const QByteArray &id) {
                    return id.startsWith("UTC"); // krazy:exclude=strings
                });
```

#### AUTO 


```{c}
const auto rightNow =
                QDateTime::currentDateTimeUtc().toTimeZone(nextOccurrenceDateTime.timeZone());
```

#### AUTO 


```{c}
const auto &relUid
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : qAsConst(src.d->mAlarms)) {
            Alarm::Ptr b(new Alarm(*alarm.data()));
            b->setParent(dest);
            mAlarms.append(b);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
        observer->calendarIncidenceDeleted(incidence, this);
    }
```

#### AUTO 


```{c}
auto dateList = event->recurrence()->timesInInterval(start, end);
```

#### AUTO 


```{c}
const auto [it1, it2] = std::mismatch(alarmList.cbegin(), alarmList.cend(), otherAlarmsList.cbegin(), otherAlarmsList.cend(), matchFunc);
```

#### AUTO 


```{c}
auto alarms = incidence->alarms();
```

#### RANGE FOR STATEMENT 


```{c}
for (Incidence::Ptr incidence : incidences) {
            QHash<Incidence::Ptr, bool>::Iterator it = d->mIncidenceVisibility.find(incidence);
            if (it != d->mIncidenceVisibility.end())
                *it = isVisible;
        }
```

#### AUTO 


```{c}
const auto &date
```

#### LAMBDA EXPRESSION 


```{c}
[&mime](const Attachment &a) {
        return a.mimeType() == mime;
    }
```

#### AUTO 


```{c}
auto incidence = it->constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto event : eventList) {
        // If this event is transparent it shouldn't be in the freebusy list.
        if (event->transparency() == Event::Transparent) {
            continue;
        }

        // The code below can not handle all-day events. Fixing this resulted
        // in a lot of duplicated code. Instead, make a copy of the event and
        // set the period to the full day(s). This trick works for recurring,
        // multiday, and single day all-day events.
        Event::Ptr allDayEvent;
        if (event->allDay()) {
            // addDay event. Do the hack
            qCDebug(KCALCORE_LOG) << "All-day event";
            allDayEvent = Event::Ptr(new Event(*event));

            // Set the start and end times to be on midnight
            QDateTime st = allDayEvent->dtStart();
            st.setTime(QTime(0, 0));
            QDateTime nd = allDayEvent->dtEnd();
            nd.setTime(QTime(23, 59, 59, 999));
            allDayEvent->setAllDay(false);
            allDayEvent->setDtStart(st);
            allDayEvent->setDtEnd(nd);

            qCDebug(KCALCORE_LOG) << "Use:" << st.toString() << "to" << nd.toString();
            // Finally, use this event for the setting below
            event = allDayEvent;
        }

        // This whole for loop is for recurring events, it loops through
        // each of the days of the freebusy request

        for (qint64 i = 0; i <= duration; ++i) {
            day = start.addDays(i).date();
            tmpStart.setDate(day);
            tmpEnd.setDate(day);

            if (event->recurs()) {
                if (event->isMultiDay()) {
                    // FIXME: This doesn't work for sub-daily recurrences or recurrences with
                    //        a different time than the original event.
                    const qint64 extraDays = event->dtStart().daysTo(event->dtEnd());
                    for (qint64 x = 0; x <= extraDays; ++x) {
                        if (event->recursOn(day.addDays(-x), start.timeZone())) {
                            tmpStart.setDate(day.addDays(-x));
                            tmpStart.setTime(event->dtStart().time());
                            tmpEnd = event->duration().end(tmpStart);

                            addLocalPeriod(tmpStart, tmpEnd);
                            break;
                        }
                    }
                } else {
                    if (event->recursOn(day, start.timeZone())) {
                        tmpStart.setTime(event->dtStart().time());
                        tmpEnd.setTime(event->dtEnd().time());

                        addLocalPeriod(tmpStart, tmpEnd);
                    }
                }
            }
        }

        // Non-recurring events
        addLocalPeriod(event->dtStart(), event->dtEnd());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
            observer->calendarModified(modified, this);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &abv : abvs) {
                if (candidateTransition.abbreviation == QString::fromUtf8(abv)) {
                    matchedTransitions += 1024; // lots of points for a transition with a matching abbreviation
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &table : d->mIncidences) {
        for (const auto &incidence : table) {
            const QDateTime dt = incidence->dateTime(Incidence::RoleCalendarHashing);
            if (dt.isValid()) {
                d->mIncidencesForDate[incidence->type()].insert(dt.toTimeZone(timeZone).date(), incidence);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &time : times) {
                tmp = KDateTime(tmpday, time, start.timeSpec());
                if (endDateForStart(tmp) >= kdate) {
                    result << tmp;
                }
            }
```

#### AUTO 


```{c}
auto it = std::find(d->mContacts.begin(), d->mContacts.end(), contact);
```

#### AUTO 


```{c}
auto it = std::find_if(d->mAttendees.cbegin(), d->mAttendees.cend(), [&mails](const Attendee &a) {
        return mails.contains(a.email());
    });
```

#### AUTO 


```{c}
const auto &eventsForDate = d->mIncidencesForDate[Incidence::TypeEvent];
```

#### AUTO 


```{c}
const auto &freebusy
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : qAsConst(d->mAlarms)) {
        alarm->setParent(nullptr);
    }
```

#### AUTO 


```{c}
auto begin = std::lower_bound(phase.transitions.cbegin(), phase.transitions.cend(), now.addYears(-20));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Attendee &a) {
        return QVariant::fromValue(a);
    }
```

#### AUTO 


```{c}
auto it = d->mOrphans.cbegin();
```

#### AUTO 


```{c}
const auto events = calendar->events();
```

#### RANGE FOR STATEMENT 


```{c}
for (int day : expectedDays) {
        QVERIFY(timesInInterval.contains(QDateTime(QDate(2019, 10, day), QTime(12, 0), Qt::LocalTime)));
    }
```

#### AUTO 


```{c}
const auto icalDuration = d->mImpl.writeICalDuration(duration);
```

#### AUTO 


```{c}
auto icalZone = parseTimeZone(c);
```

#### AUTO 


```{c}
auto it = values.constBegin();
```

#### AUTO 


```{c}
const auto& transition
```

#### RANGE FOR STATEMENT 


```{c}
for (const KDateTime &dt : timesInInterval) {
//     qDebug() << dt;
        QCOMPARE(expectedEventOccurrences.removeAll(dt), 1);
    }
```

#### AUTO 


```{c}
const auto event = events.at(0);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &incidence : d->mIncidences[Incidence::TypeTodo]) {
        const auto todo = incidence.staticCast<Todo>();
        if (!isVisible(todo)) {
            continue;
        }

        QDateTime rStart = todo->hasDueDate() ? todo->dtDue() : todo->hasStartDate() ? todo->dtStart() : QDateTime();
        if (!rStart.isValid()) {
            continue;
        }

        if (!todo->recurs()) { // non-recurring todos
            if (nd.isValid() && nd < rStart) {
                continue;
            }
            if (st.isValid() && rStart < st) {
                continue;
            }
        } else { // recurring events
            switch (todo->recurrence()->duration()) {
            case -1: // infinite
                break;
            case 0: // end date given
            default: // count given
                QDateTime rEnd(todo->recurrence()->endDate(), QTime(23, 59, 59, 999), ts);
                if (!rEnd.isValid()) {
                    continue;
                }
                if (st.isValid() && rEnd < st) {
                    continue;
                }
                break;
            } // switch(duration)
        } // if(recurs)

        todoList.append(todo);
    }
```

#### AUTO 


```{c}
auto exR
```

#### AUTO 


```{c}
auto it = std::remove_if(todoList->begin(), todoList->end(), [=](const Incidence::Ptr &incidence) {
        return !filterIncidence(incidence);
    });
```

#### AUTO 


```{c}
const auto &category
```

#### RANGE FOR STATEMENT 


```{c}
for (auto event : eventList) {
        // If this event is transparent it shouldn't be in the freebusy list.
        if (event->transparency() == Event::Transparent) {
            continue;
        }

        // The code below can not handle all-day events. Fixing this resulted
        // in a lot of duplicated code. Instead, make a copy of the event and
        // set the period to the full day(s). This trick works for recurring,
        // multiday, and single day all-day events.
        Event::Ptr allDayEvent;
        if (event->allDay()) {
            // addDay event. Do the hack
            qCDebug(KCALCORE_LOG) << "All-day event";
            allDayEvent = Event::Ptr(new Event(*event));

            // Set the start and end times to be on midnight
            QDateTime st = allDayEvent->dtStart();
            st.setTime(QTime(0, 0));
            QDateTime nd = allDayEvent->dtEnd();
            nd.setTime(QTime(23, 59, 59, 999));
            allDayEvent->setAllDay(false);
            allDayEvent->setDtStart(st);
            allDayEvent->setDtEnd(nd);

            qCDebug(KCALCORE_LOG) << "Use:" << st.toString() << "to" << nd.toString();
            // Finally, use this event for the setting below
            event = allDayEvent;
        }

        // This whole for loop is for recurring events, it loops through
        // each of the days of the freebusy request

        for (qint64 i = 0; i <= duration; ++i) {
            day = start.addDays(i).date();
            tmpStart.setDate(day);
            tmpEnd.setDate(day);

            if (event->recurs()) {
                if (event->isMultiDay()) {
                    // FIXME: This doesn't work for sub-daily recurrences or recurrences with
                    //        a different time than the original event.
                    const qint64 extraDays = event->dtStart().daysTo(event->dtEnd());
                    for (qint64 x = 0; x <= extraDays; ++x) {
                        if (event->recursOn(day.addDays(-x), start.timeZone())) {
                            tmpStart.setDate(day.addDays(-x));
                            tmpStart.setTime(event->dtStart().time());
                            tmpEnd = event->duration().end(tmpStart);

                            addLocalPeriod(q, tmpStart, tmpEnd);
                            break;
                        }
                    }
                } else {
                    if (event->recursOn(day, start.timeZone())) {
                        tmpStart.setTime(event->dtStart().time());
                        tmpEnd.setTime(event->dtEnd().time());

                        addLocalPeriod(q, tmpStart, tmpEnd);
                    }
                }
            }
        }

        // Non-recurring events
        addLocalPeriod(q, event->dtStart(), event->dtEnd());
    }
```

#### AUTO 


```{c}
auto dc = d->completed().toTimeZone(oldZone);
```

#### AUTO 


```{c}
const auto conferences = event->conferences();
```

#### AUTO 


```{c}
const auto &e
```

#### AUTO 


```{c}
auto &exDt
```

#### AUTO 


```{c}
const auto it = std::lower_bound(beginIt, set1.end(), elem);
```

#### AUTO 


```{c}
const auto &i
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &time : times) {
                tmp = KDateTime(tmpday, time, start.timeSpec());
                if (!(tmp > datetime || endDateForStart(tmp) < datetime)) {
                    result << tmp;
                }
            }
```

#### AUTO 


```{c}
const auto LOCAL_TZ = "Europe/Paris";
```

#### AUTO 


```{c}
auto it = std::find_if(d_ptr->mAttendees.cbegin(), d_ptr->mAttendees.cend(), [&uid](const Attendee &a) {
        return a.uid() == uid;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[=](const Incidence::Ptr &incidence) {
        return !filterIncidence(incidence);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FreeBusyPeriod &p : qAsConst(d->mBusyPeriods)) {
        res << p;
    }
```

#### AUTO 


```{c}
const auto alarmList = alarms();
```

#### AUTO 


```{c}
const auto &p
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rule : qAsConst(d->mExRules)) {
                allowed = allowed && !rule->recursAt(nextDT);
            }
```

#### AUTO 


```{c}
auto dt = d->dtDue().toTimeZone(oldZone);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto exR : d->mExRules) {
        exR->shiftTimes(oldTz, newTz);
    }
```

#### AUTO 


```{c}
auto expect = QByteArray(VTZ_Prague);
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
        observer->calendarIncidenceDeleted(incidence);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : d->mRDates) {
            kdt.setDate(date);
            if (kdt < prevDT) {
                dates << kdt;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e: d->mIncidences[Incidence::TypeEvent]) {
        const auto event = e.staticCast<Event>();
        QDateTime rStart = event->dtStart();
        if (nd.isValid() && nd < rStart) {
            continue;
        }
        if (inclusive && st.isValid() && rStart < st) {
            continue;
        }

        if (!event->recurs()) {   // non-recurring events
            QDateTime rEnd = event->dtEnd();
            if (st.isValid() && rEnd < st) {
                continue;
            }
            if (inclusive && nd.isValid() && nd < rEnd) {
                continue;
            }
        } else { // recurring events
            switch (event->recurrence()->duration()) {
            case -1: // infinite
                if (inclusive) {
                    continue;
                }
                break;
            case 0: // end date given
            default: // count given
                QDateTime rEnd(event->recurrence()->endDate(), QTime(23, 59, 59, 999), ts);
                if (!rEnd.isValid()) {
                    continue;
                }
                if (st.isValid() && rEnd < st) {
                    continue;
                }
                if (inclusive && nd.isValid() && nd < rEnd) {
                    continue;
                }
                break;
            } // switch(duration)
        } //if(recurs)

        eventList.append(event);
    }
```

#### AUTO 


```{c}
const auto &a
```

#### AUTO 


```{c}
const auto o = static_cast<const Event *>(&other)->d_func();
```

#### AUTO 


```{c}
auto itz = icaltimezone_new();
```

#### AUTO 


```{c}
const auto it = std::lower_bound(c.begin(), c.end(), v);
```

#### AUTO 


```{c}
auto it = d->mIncidencesForDate[Incidence::TypeTodo].constFind(date);
```

#### AUTO 


```{c}
auto it = bys.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &attendee : qAsConst(i->d->mAttendees)) {
        out << attendee;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : std::as_const(dateList)) {
        icalcomponent_add_property(parent, icalproperty_new_rdate(writeICalDatePeriod(date)));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&journalList](const Journal::Ptr &journal) {
        journalList.append(journal);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &freebusy : lst) {
        qDebug() << freebusy.start().toString() << " " << freebusy.end().toString() << "+ " << freebusy.summary() << ":" << freebusy.location();
    }
```

#### AUTO 


```{c}
auto *c = icalcomponent_get_first_component(calendar, ICAL_VTIMEZONE_COMPONENT);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto rule : d->mRRules) {
            QDateTime dt = rule->getNextDate(nextDT);
            if (dt.isValid()) {
                dates << dt;
            }
        }
```

#### AUTO 


```{c}
auto vtimezone = ICalTimeZoneParser::vcaltimezoneFromQTimeZone(QTimeZone("Europe/Prague"), QDateTime({1979, 2, 1}, {0, 0}));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &conf : conferences) {
        icalcomponent_add_property(parent, writeConference(conf));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (RecurrenceRule *rule : qAsConst(r->d->mExRules)) {
        out << rule;
    }
```

#### AUTO 


```{c}
auto it = std::remove_if(eventList->begin(), eventList->end(), [=](const Incidence::Ptr &incidence) {
        return !filterIncidence(incidence);
    });
```

#### AUTO 


```{c}
const auto ianaTzid = QTimeZone::windowsIdToDefaultIanaId(icalTz.id);
```

#### AUTO 


```{c}
auto it = d->mVolatileProperties.begin(), end = d->mVolatileProperties.end();
```

#### AUTO 


```{c}
const auto conferences = incidence->conferences();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Journal::Ptr &journal : allJournals) {
        const QDate journalStart = journal->dtStart().toTimeZone(start.timeZone()).date();
        if (journal->dtStart().isValid() &&
                journalStart >= start.date() &&
                journalStart <= end.date()) {
            journals << journal;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dt : timesInInterval) {
        //     qDebug() << dt;
        QCOMPARE(expectedEventOccurrences.removeAll(dt), 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : d->mRDates) {
            kdt.setDate(date);
            if (kdt > nextDT) {
                dates << kdt;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto it = strictLowerBound(dts.begin(), dts.end(), prev);
```

#### AUTO 


```{c}
const auto now = QDateTime::currentDateTimeUtc();
```

#### LAMBDA EXPRESSION 


```{c}
[this, &todoList, &date](const Todo::Ptr &todo) {
        if (todo->recurs() && todo->recursOn(date, timeZone())) {
            todoList.append(todo);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&email](const Attendee &att) {
        return att.email() == email;
    }
```

#### AUTO 


```{c}
const auto &contact
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
        observer->calendarIncidenceAdded(incidence);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Incidence::Ptr &in) {
        return (incidence->dtStart() == in->dtStart() || (!incidence->dtStart().isValid() && !in->dtStart().isValid()))
            && incidence->summary() == in->summary();
    }
```

#### AUTO 


```{c}
auto dts = datesForInterval(interval, mPeriod);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &part : parts) {
                        if (part == QLatin1String("range=thisandfuture")) {
                            incidence->setThisAndFuture(true);
                            break;
                        }
                    }
```

#### AUTO 


```{c}
auto it = begin;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalCore::Journal::Ptr &journal : allJournals) {
        const QDate journalStart = journal->dtStart().toTimeSpec(start.timeSpec()).date();
        if (journal->dtStart().isValid() &&
                journalStart >= start.date() &&
                journalStart <= end.date()) {
            journals << journal;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &incidence : table) {
            const QDateTime dt = incidence->dateTime(Incidence::RoleCalendarHashing);
            if (dt.isValid()) {
                d->mIncidencesForDate[incidence->type()].insert(dt.toTimeZone(timeZone).date(), incidence);
            }
        }
```

#### AUTO 


```{c}
const auto i = d->mComments.indexOf(comment);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : exDates) {
            const QDateTime exDate = ISOToQDateTime(date);
            if (exDate.time().hour() == 0 && exDate.time().minute() == 0 && exDate.time().second() == 0) {
                anEvent->recurrence()->addExDate(ISOToQDate(date));
            } else {
                anEvent->recurrence()->addExDateTime(exDate);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&sid](const Incidence::Ptr &in) {
        return in->schedulingID() == sid;
    }
```

#### AUTO 


```{c}
const auto ev = event.staticCast<Event>();
```

#### AUTO 


```{c}
auto tzidProp = icalcomponent_get_first_property(vtimezone, ICAL_TZID_PROPERTY)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rule : qAsConst(d->mExRules)) {
                allowed = allowed && !rule->recursAt(prevDT);
            }
```

#### AUTO 


```{c}
auto noAllocString = QStringView{dateStr};
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Incidence::Ptr &incidence) {
        if (incidence->hasRecurrenceId()) {
            qCDebug(KCALCORE_LOG) << "deleting child"
                                  << ", type=" << int(incidence->type())
                                  << ", uid=" << incidence->uid()
//                   << ", start=" << i->dtStart()
                                  << " from calendar";
            deleteIncidence(incidence);
        }
    }
```

#### AUTO 


```{c}
auto tz = QTimeZone(timeZoneId);
```

#### AUTO 


```{c}
auto *conf = icalcomponent_get_first_property(parent, ICAL_CONFERENCE_PROPERTY);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dt : timesInInterval) {
//     qDebug() << dt;
        QCOMPARE(expectedEventOccurrences.removeAll(dt), 1);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &rr : d->mRRules) {
        rr->shiftTimes(oldTz, newTz);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &attendee : qAsConst(i->d_ptr->mAttendees)) {
        out << attendee;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[incidence] (const Incidence::Ptr &it) {
                                return (it->uid() == incidence->uid()
                                        && it->recurrenceId() == incidence->recurrenceId());
                            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &e: d->mIncidences[Incidence::TypeEvent]) {
        const auto event = e.staticCast<Event>();
        QDateTime rStart = event->dtStart();
        if (nd < rStart) {
            continue;
        }
        if (inclusive && rStart < st) {
            continue;
        }

        if (!event->recurs()) {   // non-recurring events
            QDateTime rEnd = event->dtEnd();
            if (rEnd < st) {
                continue;
            }
            if (inclusive && nd < rEnd) {
                continue;
            }
        } else { // recurring events
            switch (event->recurrence()->duration()) {
            case -1: // infinite
                if (inclusive) {
                    continue;
                }
                break;
            case 0: // end date given
            default: // count given
                QDateTime rEnd(event->recurrence()->endDate(), QTime(23, 59, 59, 999), ts);
                if (!rEnd.isValid()) {
                    continue;
                }
                if (rEnd < st) {
                    continue;
                }
                if (inclusive && nd < rEnd) {
                    continue;
                }
                break;
            } // switch(duration)
        } //if(recurs)

        eventList.append(event);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int day : expectedDays) {
        QVERIFY(timesInInterval.contains(QDateTime(QDate(2019, 10, day))));
    }
```

#### AUTO 


```{c}
const auto todo = incidence.staticCast<Todo>();
```

#### AUTO 


```{c}
const auto it = strictLowerBound(d->mCachedDates.constBegin(), d->mCachedDates.constEnd(), toDate);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &exDt : d->mExDateTimes) {
        exDt = exDt.toTimeZone(oldTz);
        exDt.setTimeZone(newTz);
    }
```

#### AUTO 


```{c}
auto itEnd = dts.end();
```

#### AUTO 


```{c}
const auto& earliest = transitions.first().atUtc;
```

#### AUTO 


```{c}
const auto &transition
```

#### AUTO 


```{c}
const auto dstPrev = greatestSmallerThan(tz.daylight.transitions, dt);
```

#### AUTO 


```{c}
auto noteIt = d->mNotebookIncidences.cbegin();
```

#### AUTO 


```{c}
auto alarms = anEvent->alarms();
```

#### AUTO 


```{c}
auto end = relatedToUid.cend();
```

#### AUTO 


```{c}
const auto timesInInterval = event->recurrence()->timesInInterval(start.addSecs(1), end.addSecs(-1));
```

#### AUTO 


```{c}
const auto stdPrev = greatestSmallerThan(tz.standard.transitions, dt);
```

#### AUTO 


```{c}
auto dts = timesInInterval(start, end);
```

#### AUTO 


```{c}
auto itOther = other.mProperties.constFind(it.key());
```

#### AUTO 


```{c}
const auto events1 = calendar1->events();
```

#### RANGE FOR STATEMENT 


```{c}
for (RecurrenceRule *rule : rrules) {
        icalcomponent_add_property(parent, icalproperty_new_rrule(writeRecurrenceRule(rule)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &ad : addresses) {
            if (!ad.email().isEmpty()) {
                icalproperty *p = icalproperty_new_attendee(QByteArray(QByteArray("MAILTO:") + ad.email().toUtf8()).constData());
                if (!ad.name().isEmpty()) {
                    icalproperty_add_parameter(p, icalparameter_new_cn(ad.name().toUtf8().constData()));
                }
                icalcomponent_add_property(a, p);
            }
        }
```

#### AUTO 


```{c}
const auto ct = d->mCreated.time();
```

#### LAMBDA EXPRESSION 


```{c}
[&mails](const Attendee &a) {
        return mails.contains(a.email());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &incidence : mIncidences[incidenceType]) {
        q->notifyIncidenceAboutToBeDeleted(incidence);
        incidence->unRegisterObserver(q);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &incidence : inc) {
        qDebug() << "*+*+*+*+*+*+*+*+*+*";
        qDebug() << " ->" << incidence->summary() << "<-";

        incidence->recurrence()->dump();

        QDateTime dt;
        if (incidence->allDay()) {
            dt = incidence->dtStart().addDays(-1);
        } else {
            dt = incidence->dtStart().addSecs(-1);
        }
        int i = 0;
        if (outstream) {
            // Output to file for testing purposes
            while (dt.isValid() && i < 500) {
                ++i;
                dt = incidence->recurrence()->getNextDateTime(dt);
                if (dt.isValid()) {
                    (*outstream) << dumpTime(dt, viewZone) << '\n';
                }
            }
        } else {
            incidence->recurrence()->dump();
            // Output to konsole
            while (dt.isValid() && i < 10) {
                ++i;
                qDebug() << "-------------------------------------------";
                dt = incidence->recurrence()->getNextDateTime(dt);
                if (dt.isValid()) {
                    qDebug() << " *~*~*~*~ Next date is:" << dumpTime(dt, viewZone);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto it = byd.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &qtz : qAsConst(tzUsedList)) {
        if (qtz != QTimeZone::utc()) {
            icaltimezone *tz = ICalTimeZoneParser::icaltimezoneFromQTimeZone(qtz, earliestTz[qtz]);
            if (!tz) {
                qCritical() << "bad time zone";
            } else {
                component = icalcomponent_new_clone(icaltimezone_get_component(tz));
                icalcomponent_add_component(calendar, component);
                icaltimezone_free(tz, 1);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        addAttendee(a, false);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto rule : d->mRRules) {
            QDateTime dt = rule->getPreviousDate(prevDT);
            if (dt.isValid()) {
                dates << dt;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Alarm::Ptr &alarm : qAsConst(src.d->mAlarms)) {
        Alarm::Ptr b(new Alarm(*alarm.data()));
        b->setParent(dest);
        mAlarms.append(b);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment::Ptr &attachment : qAsConst(d->mAttachments)) {
        out << attachment;
    }
```

#### AUTO 


```{c}
auto attendees = anEvent->attendees();
```

#### AUTO 


```{c}
const auto &tzid
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &cat : lstVal) {
                // ensure no duplicates
                if (!categories.contains(cat)) {
                    categories.append(cat);
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTime &time : times) {
                tmp = QDateTime(tmpday, time, start.timeZone());
                if (!(tmp > datetime || endDateForStart(tmp) < datetime)) {
                    result << tmp;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Journal::Ptr &journal : allJournals) {
        const QDate journalStart = journal->dtStart().toTimeZone(start.timeZone()).date();
        if (journal->dtStart().isValid() && journalStart >= start.date() && journalStart <= end.date()) {
            journals << journal;
        }
    }
```

#### AUTO 


```{c}
const auto it = std::lower_bound(d->mCachedDates.constBegin(), d->mCachedDates.constEnd(), start);
```

#### AUTO 


```{c}
auto now = QDateTime::currentDateTime();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : d->mIncidences[Incidence::TypeEvent]) {
        const auto ev = event.staticCast<Event>();
        if (ev->recurs()) {
            if (ev->isMultiDay()) {
                int extraDays = ev->dtStart().date().daysTo(ev->dtEnd().date());
                for (int i = 0; i <= extraDays; ++i) {
                    if (ev->recursOn(date.addDays(-i), ts)) {
                        eventList.append(ev);
                        break;
                    }
                }
            } else {
                if (ev->recursOn(date, ts)) {
                    eventList.append(ev);
                }
            }
        } else {
            if (ev->isMultiDay()) {
                if (ev->dtStart().toTimeZone(ts).date() <= date && ev->dtEnd().toTimeZone(ts).date() >= date) {
                    eventList.append(ev);
                }
            }
        }
    }
```

#### AUTO 


```{c}
const auto TEST_TZ = "UTC";
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &i : qAsConst(d->mIncidenceRelations[uid])) {
        if (!d->mOrphanUids.contains(i->uid())) {
            d->mOrphans.insert(uid, i);
            d->mOrphanUids.insert(i->uid(), i);
            i->setRelatedTo(uid);
        }
    }
```

#### AUTO 


```{c}
auto tmplst = lst;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &id) {
                                                return id.startsWith("UTC"); //krazy:exclude=strings
                                            }
```

#### AUTO 


```{c}
const auto &transitions = prague.transitions(QDateTime({1949, 6, 6}, {0, 0}), QDateTime({1979, 6, 6}, {0, 0}));
```

#### LAMBDA EXPRESSION 


```{c}
[&eventList](const Event::Ptr &event) {
       eventList.append(event);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(d->mAttendees.cbegin(), d->mAttendees.cend(), [&email](const Attendee &att) {
        return att.email() == email;
    });
```

#### AUTO 


```{c}
auto incidenceIt = d->mIncidences[type].constFind(uid);
```

#### RANGE FOR STATEMENT 


```{c}
for (const char *&str : properties) {
            str = icalproperty_as_ical_string(p);
            p = icalcomponent_get_next_property(parent, ICAL_ANY_PROPERTY);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Incidence::Ptr &inc : rawInc) {
        thisCats = inc->categories();
        for (const auto &cat : std::as_const(thisCats)) {
            if (!uniqueCategories.contains(cat)) {
                uniqueCategories.append(cat);
            }
        }
    }
```

#### AUTO 


```{c}
const auto prev = earliest->value(incidence->dtStart().timeZone());
```

#### AUTO 


```{c}
auto cIt = custom.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &in : std::as_const(lst)) {
                d->mOrphans.insert(relUid, in);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (IncidenceObserver *o : qAsConst(d_ptr->mObservers)) {
            o->incidenceUpdate(uid(), rid);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &rule : qAsConst(d->mRRules)) {
            QDateTime dt = rule->getPreviousDate(prevDT);
            if (dt.isValid()) {
                dates << dt;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto role : {IncidenceBase::RoleStartTimeZone, IncidenceBase::RoleEndTimeZone}) {
        const auto dt = incidence->dateTime(role);
        if (dt.isValid()) {
            if (dt.timeZone() == QTimeZone::utc()) {
                continue;
            }
            const auto prev = earliest->value(incidence->dtStart().timeZone());
            if (!prev.isValid() || incidence->dtStart() < prev) {
                earliest->insert(incidence->dtStart().timeZone(), prev);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (FreeBusyPeriod p : qAsConst(d->mBusyPeriods)) {
            p.shiftTimes(oldSpec, newSpec);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (IncidenceObserver *o : qAsConst(d->mObservers)) {
            o->incidenceUpdate(uid(), rid);
        }
```

#### AUTO 


```{c}
const auto otherAlarmsList = i2->alarms();
```

#### AUTO 


```{c}
auto dts = d->datesForInterval(interval, recurrenceType());
```

#### AUTO 


```{c}
auto rdtIt = dateTimeList.constBegin();
```

#### AUTO 


```{c}
const auto event = events[0];
```

#### AUTO 


```{c}
const auto dts = r.timesInInterval(localStart, maxTime);
```

#### AUTO 


```{c}
const auto it = std::lower_bound(dts.constBegin(), dts.constEnd(), start);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &relUid : std::as_const(relatedToUids)) {
            // Remove all to get access to the remaining entries
            Incidence::List lst = values(d->mOrphans, relUid);
            d->mOrphans.remove(relUid);
            lst.erase(std::remove(lst.begin(), lst.end(), incidence), lst.end());

            // Re-add those that point to a different orphan incidence
            for (const auto &in : std::as_const(lst)) {
                d->mOrphans.insert(relUid, in);
            }
        }
```

#### AUTO 


```{c}
auto it = d->mIncidencesForDate[Incidence::TypeJournal].constFind(date);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &date : qAsConst(d->mRDates)) {
            kdt.setDate(date);
            if (kdt < prevDT) {
                dates << kdt;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto itEnd = incidences.cend();
```

#### AUTO 


```{c}
auto it = std::remove_if(d->mAttachments.begin(), d->mAttachments.end(), [&mime](const Attachment &a) {
        return a.mimeType() == mime;
    });
```

#### AUTO 


```{c}
const auto it = strictLowerBound(d->mRDateTimes.constBegin(), d->mRDateTimes.constEnd(), prevDT);
```

#### AUTO 


```{c}
auto vcalendar = loadCALENDAR(calText.constData());
```

#### RANGE FOR STATEMENT 


```{c}
for (RecurrenceRule *rule : exrules) {
        icalcomponent_add_property(parent, icalproperty_new_exrule(writeRecurrenceRule(rule)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CalendarObserver *observer : qAsConst(d->mObservers)) {
        observer->calendarIncidenceAboutToBeDeleted(incidence);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const Alarm::Ptr &alarm) {
        return alarm->enabled();
    }
```

#### AUTO 


```{c}
const auto &eventPtr
```

#### AUTO 


```{c}
const auto timesInInterval = event->recurrence()->timesInInterval(start, end);
```

#### AUTO 


```{c}
const auto event = e.staticCast<Event>();
```

#### AUTO 


```{c}
auto vtimezone = ICalTimeZoneParser::vcaltimezoneFromQTimeZone(QTimeZone("Europe/Prague"),
                                                                   QDateTime::currentDateTimeUtc().addYears(-200));
```

#### AUTO 


```{c}
const auto dts = r.timesInInterval(utcStart, maxTime);
```

#### AUTO 


```{c}
auto it = d->mIncidences.constBegin();
```

#### AUTO 


```{c}
auto it = r->d->mRDateTimePeriods.cbegin();
```

#### AUTO 


```{c}
const auto transit = transits.at(i);
```

#### AUTO 


```{c}
auto it = relatedToUid.cbegin(), end = relatedToUid.cend();
```

#### RANGE FOR STATEMENT 


```{c}
for (IncidenceObserver *o : qAsConst(d_ptr->mObservers)) {
            o->incidenceUpdated(uid(), rid);
        }
```

#### AUTO 


```{c}
auto it = attendees.constBegin();
```

#### AUTO 


```{c}
const auto it = strictLowerBound(dts.begin(), dts.end(), mDateStart);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &eventPtr : std::as_const(d->mEventsRelate)) {
        eventPtr->setRelatedTo(eventPtr->relatedTo());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto role : { IncidenceBase::RoleStartTimeZone, IncidenceBase::RoleEndTimeZone }) {
        const auto dt = incidence->dateTime(role);
        if (dt.isValid() && dt.timeZone() != QTimeZone::utc()) {
            if (!d->mTimeZones.contains(dt.timeZone())) {
                d->mTimeZones.push_back(dt.timeZone());
            }
        }
    }
```

#### AUTO 


```{c}
auto &rr
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &incidence : list) {
            notifyIncidenceChanged(incidence);
        }
```

#### AUTO 


```{c}
auto it = eventsForDate.constFind(date);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Attendee &att) {
                    return d->mEmailList.contains(att.email());
                }
```

#### AUTO 


```{c}
const auto &qtz
```

#### AUTO 


```{c}
const auto [at1, at2] = std::mismatch(attachmentList.cbegin(), attachmentList.cend(), otherAttachmentList.cbegin(), otherAttachmentList.cend());
```

#### RANGE FOR STATEMENT 


```{c}
for (int day : expectedDays) {
        QVERIFY(timesInInterval.contains(QDate(2019, 10, day).startOfDay()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dt : timesInInterval) {
        QCOMPARE(expectedEventOccurrences.removeAll(dt), 1);
    }
```

#### AUTO 


```{c}
auto dateTimeList = incidence->recurrence()->exDateTimes();
```

#### RANGE FOR STATEMENT 


```{c}
for (int day : expectedDays) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 14, 0)
        QVERIFY(timesInInterval.contains(QDate(2019, 10, day).startOfDay()));
#else
        QVERIFY(timesInInterval.contains(QDateTime(QDate(2019, 10, day))));
#endif
    }
```

