#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { conflictingItemFetched(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavCollection &seen : qAsConst(d->mCollections)) {
                    if (seen.url().toDisplayString() == url.toDisplayString()) {
                        alreadySeen = true;
                    }
                }
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionsMultiFetchJob({davUrl1, davUrl2});
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : std::as_const(mFetchProperties)) {
        QDomElement elem = query.createElementNS(fetchProperty.first, fetchProperty.second);
        prop.appendChild(elem);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : qAsConst(mFetchProperties)) {
        QDomNodeList fetchNodes = propElement.elementsByTagNameNS(fetchProperty.first, fetchProperty.second);
        for (int i = 0; i < fetchNodes.size(); ++i) {
            QDomElement fetchElement = fetchNodes.at(i).toElement();
            DavPrincipalSearchJob::Result result;
            result.propertyNamespace = fetchProperty.first;
            result.property = fetchProperty.second;
            result.value = fetchElement.text();
            mResults << result;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        davJobFinished(job);
    }
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemFetchJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) {
        d->davJobFinished(job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { collectionsFetchFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavCollection &seen : qAsConst(mCollections)) {
                    if (seen.url().toDisplayString() == url.toDisplayString()) {
                        alreadySeen = true;
                    }
                }
```

#### AUTO 


```{c}
const auto fetchedItem = itemFetchJob->item();
```

#### AUTO 


```{c}
auto it = map.cbegin();
```

#### AUTO 


```{c}
auto url = mUrl;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QList<QByteArray> &scenario) {
        return !scenario.isEmpty() && scenario.at(0).mid(3) + "\r\n" == line;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : qAsConst(mFetchProperties)) {
        QDomNodeList fetchNodes = propElement.elementsByTagNameNS(fetchProperty.first, fetchProperty.second);
        for (int i = 0; i < fetchNodes.size(); ++i) {
            QDomElement fetchElement = fetchNodes.at(i).toElement();
            Result result;
            result.propertyNamespace = fetchProperty.first;
            result.property = fetchProperty.second;
            result.value = fetchElement.text();
            mResults << result;
        }
    }
```

#### AUTO 


```{c}
const auto queries = protocol->itemsQueries();
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) { d->principalFetchFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &homeSet : homeSets) {
        QUrl url = d->mUrl.url();

        if (homeSet.startsWith(QLatin1Char('/'))) {
            // homeSet is only a path, use request url to complete
            url.setPath(homeSet, QUrl::TolerantMode);
        } else {
            // homeSet is a complete url
            QUrl tmpUrl(homeSet);
            tmpUrl.setUserName(url.userName());
            tmpUrl.setPassword(url.password());
            url = tmpUrl;
        }

        doCollectionsFetch(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavCollection &seen : std::as_const(mCollections)) {
                    if (seen.url().toDisplayString() == url.toDisplayString()) {
                        alreadySeen = true;
                    }
                }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
                conflictingItemFetched(job);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (XMLQueryBuilder::Ptr builder : queries) {
        if (!d->mRangeStart.isEmpty()) {
            builder->setParameter(QStringLiteral("start"), d->mRangeStart);
        }
        if (!d->mRangeEnd.isEmpty()) {
            builder->setParameter(QStringLiteral("end"), d->mRangeEnd);
        }

        const QDomDocument props = builder->buildQuery();
        const QString mimeType = builder->mimeType();

        if (d->mMimeTypes.isEmpty() || d->mMimeTypes.contains(mimeType)) {
            ++d->mSubJobCount;
            if (protocol->useReport()) {
                KIO::DavJob *job = DavManager::self()->createReportJob(d->mUrl.url(), props.toString());
                job->addMetaData(QStringLiteral("PropagateHttpHeader"), QStringLiteral("true"));
                job->setProperty("davType", QStringLiteral("report"));
                job->setProperty("itemsMimeType", mimeType);
                connect(job, &KIO::DavJob::result, this, [d](KJob *job) {
                    d->davJobFinished(job);
                });
            } else {
                KIO::DavJob *job = DavManager::self()->createPropFindJob(d->mUrl.url(), props.toString());
                job->addMetaData(QStringLiteral("PropagateHttpHeader"), QStringLiteral("true"));
                job->setProperty("davType", QStringLiteral("propFind"));
                job->setProperty("itemsMimeType", mimeType);
                connect(job, &KIO::DavJob::result, this, [d](KJob *job) {
                    d->davJobFinished(job);
                });
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavUrl &url : std::as_const(urls)) {
        DavCollectionsFetchJob *job = new DavCollectionsFetchJob(url, this);
        connect(job, &DavCollectionsFetchJob::collectionDiscovered, this, &DavCollectionsMultiFetchJob::collectionDiscovered);
        addSubjob(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
            QDomElement hrefElement = document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("href"));
            const QDomText textNode = document.createTextNode(url);
            hrefElement.appendChild(textNode);

            multigetElement.appendChild(hrefElement);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : changedItems) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }

                cache->setEtag(item.url().toDisplayString(), item.etag());
            }
```

#### AUTO 


```{c}
auto job = new KDAV::DavCollectionsMultiFetchJob({davUrl1, davUrlError});
```

#### AUTO 


```{c}
const auto map = mEtagCache->etagCacheMap();
```

#### AUTO 


```{c}
auto createJob = new KDAV::DavItemCreateJob(item);
```

#### AUTO 


```{c}
auto url = d->mUrl;
```

#### AUTO 


```{c}
const auto [it, isInserted] = mSeenUrls.insert(itemUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &homeSet : homeSets) {
        QUrl url = mUrl.url();

        if (homeSet.startsWith(QLatin1Char('/'))) {
            // homeSet is only a path, use request url to complete
            url.setPath(homeSet, QUrl::TolerantMode);
        } else {
            // homeSet is a complete url
            QUrl tmpUrl(homeSet);
            tmpUrl.setUserName(url.userName());
            tmpUrl.setPassword(url.password());
            url = tmpUrl;
        }

        doCollectionsFetch(url);
    }
```

#### AUTO 


```{c}
auto itemListJob = new KDAV::DavItemsListJob(collectionUrl, cache);
```

#### AUTO 


```{c}
auto deleteJob = new KDAV::DavItemDeleteJob(item);
```

#### AUTO 


```{c}
const auto it = std::find_if(m_scenarios.begin(), m_scenarios.end(), [&](const QList<QByteArray> &scenario) {
        return !scenario.isEmpty() && scenario.at(0).mid(3) + "\r\n" == line;
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDomElement &element : std::as_const(d->mSetProperties)) {
            propElement.appendChild(element);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDomElement &element : qAsConst(d->mSetProperties)) {
            propElement.appendChild(element);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : qAsConst(mFetchProperties)) {
        QDomElement elem = query.createElementNS(fetchProperty.first, fetchProperty.second);
        prop.appendChild(elem);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) {
                    d->davJobFinished(job);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QStringLiteral("etag:"), Qt::CaseInsensitive)) {
            etag = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { davJobFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : qAsConst(d->mFetchProperties)) {
        QDomElement elem = query.createElementNS(fetchProperty.first, fetchProperty.second);
        prop.appendChild(elem);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { principalPropertySearchFinished(job); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavUrl &url : qAsConst(urls)) {
        DavCollectionsFetchJob *job = new DavCollectionsFetchJob(url, this);
        connect(job, &DavCollectionsFetchJob::collectionDiscovered, this, &DavCollectionsMultiFetchJob::collectionDiscovered);
        addSubjob(job);
    }
```

#### AUTO 


```{c}
const auto &collection
```

#### RANGE FOR STATEMENT 


```{c}
for (KJob *job : subjobs()) {
            job->start();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QLatin1String("location:"), Qt::CaseInsensitive)) {
            location = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### AUTO 


```{c}
auto collectionUrl = collection.url();
```

#### AUTO 


```{c}
const auto etagCacheUrls = d->mEtagCache->urls();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &value : qAsConst(mItems)) {
        values << value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : std::as_const(mFetchProperties)) {
        QDomNodeList fetchNodes = propElement.elementsByTagNameNS(fetchProperty.first, fetchProperty.second);
        for (int i = 0; i < fetchNodes.size(); ++i) {
            QDomElement fetchElement = fetchNodes.at(i).toElement();
            DavPrincipalSearchJob::Result result;
            result.propertyNamespace = fetchProperty.first;
            result.property = fetchProperty.second;
            result.value = fetchElement.text();
            mResults << result;
        }
    }
```

#### AUTO 


```{c}
const auto &value
```

#### AUTO 


```{c}
auto collectionModifyJob = new KDAV::DavCollectionModifyJob(collectionUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (const PropertyPair &fetchProperty : qAsConst(d->mFetchProperties)) {
        QDomNodeList fetchNodes = propElement.elementsByTagNameNS(fetchProperty.first, fetchProperty.second);
        for (int i = 0; i < fetchNodes.size(); ++i) {
            QDomElement fetchElement = fetchNodes.at(i).toElement();
            Result result;
            result.propertyNamespace = fetchProperty.first;
            result.property = fetchProperty.second;
            result.value = fetchElement.text();
            d->mResults << result;
        }
    }
```

#### AUTO 


```{c}
const auto collections = job->collections();
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) { d->principalCollectionSetSearchFinished(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        itemRefreshed(job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) {
        d->principalCollectionSetSearchFinished(job);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavUrl &url : qAsConst(mUrls)) {
        DavCollectionsFetchJob *job = new DavCollectionsFetchJob(url, this);
        connect(job, &DavCollectionsFetchJob::result, this, &DavCollectionsMultiFetchJob::davJobFinished);
        connect(job, &DavCollectionsFetchJob::collectionDiscovered, this, &DavCollectionsMultiFetchJob::collectionDiscovered);
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &header : allHeaders) {
        if (header.startsWith(QLatin1String("etag:"), Qt::CaseInsensitive)) {
            etag = header.section(QLatin1Char(' '), 1);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) { itemRefreshed(job); }
```

#### AUTO 


```{c}
auto collectionDeleteJob = new KDAV::DavCollectionDeleteJob(collectionUrl);
```

#### AUTO 


```{c}
auto itemsFetchJob = new KDAV::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QDomElement &element : qAsConst(mSetProperties)) {
            propElement.appendChild(element);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
        if (!contains(item.remoteId())) {
            setEtagInternal(item.remoteId(), item.remoteRevision());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) {
            d->principalFetchFinished(job);
        }
```

#### AUTO 


```{c}
auto *job = new KDAV::DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
auto _url = url;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
            QDomElement hrefElement = document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("href"));
            const QUrl pathUrl = QUrl::fromUserInput(url);
            const QDomText textNode = document.createTextNode(pathUrl.toString());
            hrefElement.appendChild(textNode);

            multigetElement.appendChild(hrefElement);
        }
```

#### AUTO 


```{c}
auto job = new KDAV::DavItemsListJob(davUrl, cache);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<QByteArray> &scenario : std::as_const(m_scenarios)) {
        if (!scenario.isEmpty()) {
            return false;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob* job) { d->davJobFinished(job); }
```

#### AUTO 


```{c}
auto modifyJob = new KDAV::DavItemModifyJob(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
        qDebug() << collection.displayName() << "PRIVS: " << collection.privileges();
        auto collectionUrl = collection.url();
        std::shared_ptr<KDAV::EtagCache> cache(new KDAV::EtagCache());
        int anz = -1;
        //Get all items in a collection add them to cache and make sure, that afterward no item is changed
        {
            auto itemListJob = new KDAV::DavItemsListJob(collectionUrl, cache);
            itemListJob->exec();
            anz = itemListJob->items().size();
            qDebug() << "items:" << itemListJob->items().size();
            qDebug() << "changed Items:" << itemListJob->changedItems().size();
            qDebug() << "deleted Items:" << itemListJob->deletedItems();
            const auto changedItems = itemListJob->changedItems();
            for (const auto &item : changedItems) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) {       //itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }

                cache->setEtag(item.url().toDisplayString(), item.etag());
            }
            cache->setEtag(QStringLiteral("invalid"),QStringLiteral("invalid"));
        }
        {
            qDebug() << "second run: (should be empty).";
            auto itemListJob = new KDAV::DavItemsListJob(collectionUrl, cache);
            itemListJob->exec();
            if (itemListJob->items().size() != anz) {
                qDebug() << "Items have added/deleted on server.";
            }
            if (itemListJob->changedItems().size() != 0) {
                qDebug() << "Items have changed on server.";
            }
            if (itemListJob->deletedItems() != QStringList() << QStringLiteral("invalid")) {
                qDebug() << "more items deleted:" << itemListJob->deletedItems();
            }
        }
    }
```

#### AUTO 


```{c}
const auto d = DavManagerPrivate::get(DavManager::self());
```

#### AUTO 


```{c}
auto *job = new DavCollectionsFetchJob(davUrl);
```

#### AUTO 


```{c}
const auto d = DavManager::self();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item : changedItems) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) { // itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }

                cache->setEtag(item.url().toDisplayString(), item.etag());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const DavUrl &url : qAsConst(d->mUrls)) {
        DavCollectionsFetchJob *job = new DavCollectionsFetchJob(url, this);
        connect(job, &DavCollectionsFetchJob::result, this, &DavCollectionsMultiFetchJob::davJobFinished);
        connect(job, &DavCollectionsFetchJob::collectionDiscovered, this, &DavCollectionsMultiFetchJob::collectionDiscovered);
        job->start();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &value : std::as_const(d->mItems)) {
        values << value;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d](KJob *job) { d->davJobFinished(job); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
            principalPropertySearchFinished(job);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
            QDomElement hrefElement = document.createElementNS(QStringLiteral("DAV:"), QStringLiteral("href"));
            const QUrl pathUrl = QUrl::fromUserInput(url);
            const QDomText textNode = document.createTextNode(pathUrl.path());
            hrefElement.appendChild(textNode);

            multigetElement.appendChild(hrefElement);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &value : qAsConst(d->mItems)) {
        values << value;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QList<QByteArray> &scenario : qAsConst(m_scenarios)) {
        if (!scenario.isEmpty()) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &collection : collections) {
        qDebug() << collection.displayName() << "PRIVS: " << collection.privileges();
        auto collectionUrl = collection.url();
        std::shared_ptr<KDAV::EtagCache> cache(new KDAV::EtagCache());
        int anz = -1;
        // Get all items in a collection add them to cache and make sure, that afterward no item is changed
        {
            auto itemListJob = new KDAV::DavItemsListJob(collectionUrl, cache);
            itemListJob->exec();
            anz = itemListJob->items().size();
            qDebug() << "items:" << itemListJob->items().size();
            qDebug() << "changed Items:" << itemListJob->changedItems().size();
            qDebug() << "deleted Items:" << itemListJob->deletedItems();
            const auto changedItems = itemListJob->changedItems();
            for (const auto &item : changedItems) {
                qDebug() << item.url().url() << item.contentType() << item.data();
                auto itemFetchJob = new KDAV::DavItemFetchJob(item);
                itemFetchJob->exec();
                const auto fetchedItem = itemFetchJob->item();
                qDebug() << fetchedItem.contentType() << fetchedItem.data();

                auto itemsFetchJob = new KDAV::DavItemsFetchJob(collectionUrl, QStringList() << item.url().toDisplayString());
                itemsFetchJob->exec();
                if (itemsFetchJob->item(item.url().toDisplayString()).contentType() != fetchedItem.contentType()) { // itemsfetchjob do not get contentType
                    qDebug() << "Fetched same item but got different contentType:" << itemsFetchJob->item(item.url().toDisplayString()).contentType();
                }

                if (itemsFetchJob->item(item.url().toDisplayString()).data() != fetchedItem.data()) {
                    qDebug() << "Fetched same item but got different data:" << itemsFetchJob->item(item.url().toDisplayString()).data();
                }

                cache->setEtag(item.url().toDisplayString(), item.etag());
            }
            cache->setEtag(QStringLiteral("invalid"), QStringLiteral("invalid"));
        }
        {
            qDebug() << "second run: (should be empty).";
            auto itemListJob = new KDAV::DavItemsListJob(collectionUrl, cache);
            itemListJob->exec();
            if (itemListJob->items().size() != anz) {
                qDebug() << "Items have added/deleted on server.";
            }
            if (itemListJob->changedItems().size() != 0) {
                qDebug() << "Items have changed on server.";
            }
            if (itemListJob->deletedItems() != QStringList() << QStringLiteral("invalid")) {
                qDebug() << "more items deleted:" << itemListJob->deletedItems();
            }
        }
    }
```

#### AUTO 


```{c}
auto itemFetchJob = new KDAV::DavItemFetchJob(item);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        collectionsFetchFinished(job);
    }
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto collectionModifyJob = new KDAV::DavCollectionModifyJob(testCollectionUrl);
```

#### AUTO 


```{c}
const auto changedItems = itemListJob->changedItems();
```

#### AUTO 


```{c}
const auto etagCacheUrls = mEtagCache->urls();
```

