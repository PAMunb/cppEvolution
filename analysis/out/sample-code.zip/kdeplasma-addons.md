#### AUTO 


```{c}
auto* validator = new Plasma::WeatherValidator(this);
```

#### AUTO 


```{c}
auto it = dicts.begin(), end = dicts.end();
```

#### AUTO 


```{c}
const auto matches = context.matches();
```

#### LAMBDA EXPRESSION 


```{c}
[this](auto reachability) {
        if (reachability != QNetworkInformation::Reachability::Online) {
            return;
        }
        qCDebug(PLASMA_COMIC) << "Online status changed to true, requesting comic" << mPreviousFailedIdentifier;
        mEngine->requestSource(mPreviousFailedIdentifier);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & item : items) {
        // remove still used item from unused list
        unusedMountPoints.removeOne(item.mountPoint());

        // insert or modify m_items
        int row = indexOfMountPoint(item.mountPoint(), m_items);
        if (row < 0) {
            // new item: append on end
            row = m_items.size();
            insertRow(row);
        }
        setData(createIndex(row, 0), QVariant::fromValue(item));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &context, &query, &speller](const QString &langCode = QString()) {
            if (!langCode.isEmpty()) {
                speller->setLanguage(langCode);
            }

            QStringList suggestions;
            const bool correct = speller->checkAndSuggest(query, suggestions);

            if (correct) {
                QueryMatch match(this);
                match.setType(QueryMatch::ExactMatch);
                match.setIconName(QStringLiteral("checkbox"));
                match.setText(query);
                match.setSubtext(i18nc("Term is spelled correctly", "Correct"));
                match.setData(query);
                context.addMatch(match);
            } else if (!suggestions.isEmpty()) {
                for (const auto &suggestion : std::as_const(suggestions)) {
                    QueryMatch match(this);
                    match.setType(QueryMatch::ExactMatch);
                    match.setIconName(QStringLiteral("edit-rename"));
                    match.setText(suggestion);
                    match.setSubtext(i18n("Suggested term"));
                    match.setData(suggestion);
                    context.addMatch(match);
                }
            } else {
                return false;
            }

            return true;
        }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("kate"), {
        QStringLiteral("--start"), match.data().toString(), QStringLiteral("-n")
    });
```

#### AUTO 


```{c}
auto it = dates.constBegin(), itEnd = dates.constEnd();
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog]() {
        const QUrl &url = QUrl::fromLocalFile(dialog->service()->entryPath());
        if (url.isValid()) {
            Q_EMIT launcherAdded(url.toString());
        }
    }
```

#### AUTO 


```{c}
const auto categories = converter->categories();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            m_services.append(ServiceItem(pluginInfo[0], pluginInfo[1]));
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("konsole"), {
        QStringLiteral("--profile"), profile
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &actionName : actions) {
                const KConfigGroup &actionGroup = f.actionGroup(actionName);

                if (!actionGroup.isValid() || !actionGroup.exists()) {
                    continue;
                }

                const QString &name = actionGroup.readEntry("Name");
                const QString &exec = actionGroup.readEntry("Exec");
                if (name.isEmpty() || exec.isEmpty()) {
                    continue;
                }

                jumpListActions << QVariantMap{{QStringLiteral("name"), name},
                                               {QStringLiteral("icon"), actionGroup.readEntry("Icon")},
                                               {QStringLiteral("exec"), exec}};
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &sessionFile : sessionFiles) {
        sessions.append(QUrl::fromPercentEncoding(sessionFile.baseName().toLocal8Bit()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : actions) {
        if (action) {
            desktopMenu->addAction(action);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        watcher->deleteLater();
        QDBusPendingReply<QColor> reply = *watcher;
        if (!reply.isError()) {
            setCurrentColor(reply.value());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList({QStringLiteral("*.profile")});
        for (const QString& fileName : fileNames) {
            profilesPaths.append(dir + QLatin1Char('/') + fileName);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
        Q_EMIT dictErrorOccurred(m_tcpSocket->error(), m_tcpSocket->errorString());
        socketClosed();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, &identifier, &args]() -> PotdClient * {
        auto pluginIt = m_providersMap.find(identifier);

        if (pluginIt == m_providersMap.end()) {
            // Not a valid identifier
            return nullptr;
        }

        qCDebug(WALLPAPERPOTD) << identifier << "is registered with arguments" << args;
        auto client = new PotdClient(pluginIt->second, args, this);
        m_clientMap.emplace(identifier, ClientPair{client, 1});

        return client;
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(url);
```

#### AUTO 


```{c}
auto jsonImageArray = QJsonDocument::fromJson(job->data())
        .object().value(QLatin1String("parse"))
        .toObject().value(QLatin1String("images"))
        .toArray();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMap<QString, QString> &dicts) {
        beginResetModel();
        m_availableDicts = {};
        m_availableDicts.resize(dicts.count());
        int i = 0;
        for (auto it = dicts.begin(), end = dicts.end(); it != end; ++it, ++i) {
            m_availableDicts[i] = AvailableDict{it.key(), it.value()};
        }
        endResetModel();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profilePath : qAsConst(profilesPaths)) {
        const QString profileName = QFileInfo(profilePath).baseName();

        const KConfig _config(profilePath, KConfig::SimpleConfig);
        if (_config.hasGroup("General")) {
            KonsoleProfileData profileData;
            const KConfigGroup cfg = _config.group("General");
            profileData.displayName = cfg.readEntry("Name", profileName);
            profileData.iconName = cfg.readEntry("Icon", QStringLiteral("utilities-terminal"));
            if (!profileData.displayName.isEmpty()) {
                m_profiles.append(profileData);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &zoneId : timeZoneIds) {
        QTimeZone timeZone(zoneId);

        const QString zoneName = QString::fromUtf8(zoneId);
        if (zoneName.contains(tz, Qt::CaseInsensitive)) {
            ret[zoneName] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        const QString country = QLocale::countryToString(timeZone.country());
        if (country.contains(tz, Qt::CaseInsensitive)) {
            ret[country] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        // FIXME: This only includes the current abbreviation and not old abbreviation or
        // other possible names.
        // Eg - depending on the current date, only CET or CEST will work
        const QString abbr = timeZone.abbreviation(QDateTime::currentDateTime());
        if (abbr.contains(tz, Qt::CaseInsensitive)) {
            ret[abbr] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }
    }
```

#### AUTO 


```{c}
const auto currencyCategory = converter.category(KUnitConversion::CurrencyCategory);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KJob* job) {
        imageRequestFinished(job);
    }
```

#### AUTO 


```{c}
const auto pluginResult = KPluginFactory::instantiatePlugin<PotdProvider>(metadata, this, m_args);
```

#### AUTO 


```{c}
auto screens = qApp->screens();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KonsoleProfileData &data : std::as_const(m_profiles)) {
        if (data.displayName.contains(term, Qt::CaseInsensitive)) {
            Plasma::QueryMatch match(this);
            match.setType(Plasma::QueryMatch::PossibleMatch);
            match.setIconName(data.iconName);
            match.setData(data.displayName);
            match.setText(QStringLiteral("Konsole: ") + data.displayName);
            match.setRelevance((float)term.length() / (float)data.displayName.length());
            context.addMatch(match);
        }
    }
```

#### AUTO 


```{c}
const auto & mountPoint
```

#### AUTO 


```{c}
const auto sessions = loadSessions();
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDate alt = m_calendarProvider->fromGregorian(offsetDate); alt != date) {
            alternateDatesData.insert(date, alt);
        }
```

#### AUTO 


```{c}
auto sublabel = CalendarEvents::CalendarEventsPlugin::SubLabel{};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : timeZoneIds) {
        QTimeZone timeZone(zoneId);

        const QString zoneName = QString::fromUtf8(zoneId);
        if (zoneName.contains(tz, Qt::CaseInsensitive)) {
            ret[zoneName] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        const QString country = QLocale::countryToString(timeZone.country());
        if (country.contains(tz, Qt::CaseInsensitive)) {
            ret[country] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        // FIXME: This only includes the current abbreviation and not old abbreviation or
        // other possible names.
        // Eg - depending on the current date, only CET or CEST will work
        const QString abbr = timeZone.abbreviation(QDateTime::currentDateTime());
        if (abbr.contains(tz, Qt::CaseInsensitive)) {
            ret[abbr] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KJob *job) {
        imageRequestFinished(job);
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString name = data.name(); !name.isEmpty()) {
        d->name = name;
    } else {
        d->name = QStringLiteral("Unknown");
    }
```

#### AUTO 


```{c}
const auto attrs = mXmlReader.attributes();
```

#### RANGE FOR STATEMENT 


```{c}
for (ThreadData *data : std::as_const(m_lockers)) {
        QMutexLocker locker(&data->mutex);
        /* Because of QString's CoW semantics, we don't have to worry about
         * the overhead of assigning this to every item. */
        data->definition = definition;
        data->waitCondition.wakeOne();
    }
```

#### AUTO 


```{c}
auto reply = xcb_grab_keyboard_reply(QX11Info::connection(), cookie, NULL);
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString path = CachedProvider::identifierToPath(m_identifier); QFile::exists(path)) {
        setImage(QImage(path));
    } else {
        resetData();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        self->deleteLater();

        if (d->state != Uninhibiting) {
            return;
        }

        const QDBusPendingReply<void> reply = *self;
        if (reply.isError()) {
            qCWarning(NIGHTCOLOR_CONTROL) << "Could not uninhibit Night Color:" << reply.error().message();
        }

        d->state = Uninhibited;
        Q_EMIT stateChanged();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Applet *applet : appletList) {
        if (!applet->pluginMetaData().isValid() || task == applet->pluginMetaData().pluginId()) {
            applet->destroy();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
//         qDebug() << line << isQuotaLine(line);
        if (!isQuotaLine(line)) {
            continue;
        }

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
        QStringList parts = line.split(QLatin1Char(' '), QString::SkipEmptyParts);
#else
        QStringList parts = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif
        // valid lines range from 7 to 9 parts (grace not always there):
        // Disk quotas for user dh (uid 1000):
        //      Filesystem   blocks  quota    limit     grace   files    quota   limit   grace
        //       /home     16296500  50000000 60000000          389155       0       0
        //       /home     16296500* 50000000 60000000      6   389155       0       0
        //       /home     16296500* 50000000 60000000      4   389155       0       0       5
        //       ^...........we want these...........^
        // NOTE: In case of a soft limit violation, a '*' is added in the used blocks.
        //       Hence, the star is removed below, if applicable

        if (parts.size() < 4) {
            continue;
        }

        // 'quota' uses kilo bytes -> factor 1024
        // NOTE: int is not large enough, hence qint64
        const qint64 used = parts[1].remove(QLatin1Char('*')).toLongLong() * 1024;
        qint64 softLimit = parts[2].toLongLong() * 1024;
        const qint64 hardLimit = parts[3].toLongLong() * 1024;
        if (softLimit == 0) { // softLimit might be unused (0)
            softLimit = hardLimit;
        }
        const qint64 freeSize = softLimit - used;
        const int percent = qMin(100, qMax(0, qRound(used * 100.0 / softLimit)));

        QuotaItem item;
        item.setIconName(iconNameForQuota(percent));
        item.setMountPoint(parts[0]);
        item.setUsage(percent);
        item.setMountString(i18nc("usage of quota, e.g.: '/home/bla: 38% used'", "%1: %2% used", parts[0], percent));
        item.setUsedString(i18nc("e.g.: 12 GiB of 20 GiB", "%1 of %2", fmt.formatByteSize(used), fmt.formatByteSize(softLimit)));
        item.setFreeString(i18nc("e.g.: 8 GiB free", "%1 free", fmt.formatByteSize(qMax(qint64(0), freeSize))));

        items.append(item);

        maxQuota = qMax(maxQuota, percent);
    }
```

#### AUTO 


```{c}
const auto phase = KHolidays::LunarPhase::phaseAtDate(date);
```

#### AUTO 


```{c}
const auto &word
```

#### AUTO 


```{c}
const auto msg = new KMessageWidget(i18nc("Message that config is corrupted",
            "Config entries for alias list and code list have different sizes, ignoring all."), this);
```

#### LAMBDA EXPRESSION 


```{c}
[&loop]() {
        loop.quit();
    }
```

#### AUTO 


```{c}
const auto times = datetime(tz);
```

#### AUTO 


```{c}
const auto it = m_idIndexProxyMap.find(dict);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &unitStringKey: compatibleUnits.keys()) {
                if (unitStringKey.startsWith(outputUnitString)) {
                    outputUnit = category.unit(compatibleUnits.value(unitStringKey));
                    if (!units.contains(outputUnit)) {
                        units << outputUnit;
                    }
                }
            }
```

#### AUTO 


```{c}
auto imageObj = randomArrayValueByKey(json.object(), QLatin1String("simonstalenhag.se"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &session : std::as_const(m_sessions)) {
        if (listAll || session.contains(term, Qt::CaseInsensitive)) {
            QueryMatch match(this);
            match.setType(QueryMatch::ExactMatch);
            match.setRelevance(session.compare(term, Qt::CaseInsensitive) == 0 ? 1 : 0.8);
            match.setIconName(m_triggerWord);
            match.setData(session);
            match.setText(session);
            match.setSubtext(i18n("Open Kate Session"));
            context.addMatch(match);
        }
    }
```

#### AUTO 


```{c}
const auto connectionType = Qt::ConnectionType(Qt::UniqueConnection | Qt::QueuedConnection);
```

#### LAMBDA EXPRESSION 


```{c}
[&identifier](const KPluginMetaData &metadata) {
        return identifier == metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& suggestion : qAsConst(suggestions)) {
                Plasma::QueryMatch match(this);
                match.setType(Plasma::QueryMatch::ExactMatch);
                match.setIconName(QStringLiteral("edit-rename"));
                match.setText(suggestion);
                match.setSubtext(i18n("Suggested term"));
                match.setData(suggestion);
                context.addMatch(match);
            }
```

#### AUTO 


```{c}
auto reply = xcb_get_modifier_mapping_reply(QX11Info::connection(), cookie, NULL);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category: categories) {
        const auto allUnits = category.allUnits();
        for (const auto &unit : allUnits) {
            compatibleUnits.insert(unit.toUpper(), unit);
        }
    }
```

#### AUTO 


```{c}
const auto &mountPoint
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &word : conversionWords) {
        conversionRegex.append(QLatin1Char(' ') + word + QStringLiteral(" |"));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, newSource](const auto &data) {
            dataUpdated(newSource, data);
        }
```

#### AUTO 


```{c}
const auto system = static_cast<CalendarSystem::System>(e.value(k));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto a : mActions) {
        a->setEnabled(mCurrent.isValid());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dict : std::as_const(enabledDictList)) {
        if (!dict.enabled) {
            continue;
        }

        m_enabledDictModel->appendDict(dict);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
//         qDebug() << line << isQuotaLine(line);
        if (!isQuotaLine(line)) {
            continue;
        }

        QStringList parts = line.split(QLatin1Char(' '), QString::SkipEmptyParts);
        // valid lines range from 7 to 9 parts (grace not always there):
        // Disk quotas for user dh (uid 1000):
        //      Filesystem   blocks  quota    limit     grace   files    quota   limit   grace
        //       /home     16296500  50000000 60000000          389155       0       0
        //       /home     16296500* 50000000 60000000      6   389155       0       0
        //       /home     16296500* 50000000 60000000      4   389155       0       0       5
        //       ^...........we want these...........^
        // NOTE: In case of a soft limit violation, a '*' is added in the used blocks.
        //       Hence, the star is removed below, if applicable

        if (parts.size() < 4) {
            continue;
        }

        // 'quota' uses kilo bytes -> factor 1024
        // NOTE: int is not large enough, hence qint64
        const qint64 used = parts[1].remove(QLatin1Char('*')).toLongLong() * 1024;
        qint64 softLimit = parts[2].toLongLong() * 1024;
        const qint64 hardLimit = parts[3].toLongLong() * 1024;
        if (softLimit == 0) { // softLimit might be unused (0)
            softLimit = hardLimit;
        }
        const qint64 freeSize = softLimit - used;
        const int percent = qMin(100, qMax(0, qRound(used * 100.0 / softLimit)));

        QuotaItem item;
        item.setIconName(iconNameForQuota(percent));
        item.setMountPoint(parts[0]);
        item.setUsage(percent);
        item.setMountString(i18nc("usage of quota, e.g.: '/home/bla: 38\% used'", "%1: %2% used", parts[0], percent));
        item.setUsedString(i18nc("e.g.: 12 GiB of 20 GiB", "%1 of %2", fmt.formatByteSize(used), fmt.formatByteSize(softLimit)));
        item.setFreeString(i18nc("e.g.: 8 GiB free", "%1 free", fmt.formatByteSize(qMax(qint64(0), freeSize))));

        items.append(item);

        maxQuota = qMax(maxQuota, percent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category: converter.categories()) {
        for (const auto &unit: category.allUnits()) {
            compatibleUnits.insert(unit.toUpper(), unit);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool isOnline) {
        if (!isOnline) {
            return;
        }
        qCDebug(PLASMA_COMIC) << "Online status changed to true, requesting comic" << mPreviousFailedIdentifier;
        mEngine->requestSource(mPreviousFailedIdentifier);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
                //operation took too long, abort it
                emit mParent->error(mParent);
            }
```

#### AUTO 


```{c}
const auto exp = QRegularExpression(QRegularExpression::wildcardToRegularExpression(pattern));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& suggestion : qAsConst(suggestions)) {
                Plasma::QueryMatch match(this);
                match.setType(Plasma::QueryMatch::InformationalMatch);
                match.setIconName(QStringLiteral("edit-rename"));
                match.setText(suggestion);
                match.setSubtext(i18n("Suggested term"));
                match.setData(suggestion);
                context.addMatch(match);
            }
```

#### AUTO 


```{c}
auto matches = context.matches();
```

#### LAMBDA EXPRESSION 


```{c}
[this, identifier](const auto &data) {
        dataUpdated(identifier, data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &outputUnit: outputUnits) {
        KUnitConversion::Value outputValue = inputCategory.convert(
            KUnitConversion::Value(numberValue, inputUnit), outputUnit);
        if (!outputValue.isValid() || inputUnit == outputUnit) {
            continue;
        }

        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-calculator"));
        if (outputUnit.categoryId() == KUnitConversion::CurrencyCategory) {
            outputValue.round(2);
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(0, 'f', 2), outputUnit.symbol()));
        } else {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(), outputUnit.symbol()));
        }
        match.setData(outputValue.number());
        match.setRelevance(1.0 - std::abs(std::log10(outputValue.number())) / 50.0);
        matches.append(match);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("konsole"), {
            QStringLiteral("--profile"), destination()
        });
```

#### AUTO 


```{c}
auto & item
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->jobDone(job);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&collator](const QString &a, const QString &b) {
        return collator.compare(a, b) < 0;
    }
```

#### AUTO 


```{c}
auto url = imageObj.toObject().value(QLatin1String("url"));
```

#### AUTO 


```{c}
const auto& imageMimeTypeName
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        self->deleteLater();

        if (d->state != Uninhibiting) {
            return;
        }

        const QDBusPendingReply<void> reply = *self;
        if (reply.isError()) {
            qCWarning(NIGHTCOLOR_CONTROL) << "Could not uninhibit Night Color:" << reply.error().message();
        }

        d->state = Uninhibited;
        emit stateChanged();
    }
```

#### AUTO 


```{c}
const auto res = KFuzzyMatcher::match(term, session);
```

#### LAMBDA EXPRESSION 


```{c}
[this](WId wid) { if (match(wid, false)) deactivate(false); }
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback, provider]() {
            error(provider, callback);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // operation took too long, abort it
            Q_EMIT mParent->error(mParent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
//         qDebug() << line << isQuotaLine(line);
        if (!isQuotaLine(line)) {
            continue;
        }

        QStringList parts = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
        // valid lines range from 7 to 9 parts (grace not always there):
        // Disk quotas for user dh (uid 1000):
        //      Filesystem   blocks  quota    limit     grace   files    quota   limit   grace
        //       /home     16296500  50000000 60000000          389155       0       0
        //       /home     16296500* 50000000 60000000      6   389155       0       0
        //       /home     16296500* 50000000 60000000      4   389155       0       0       5
        //       ^...........we want these...........^
        // NOTE: In case of a soft limit violation, a '*' is added in the used blocks.
        //       Hence, the star is removed below, if applicable

        if (parts.size() < 4) {
            continue;
        }

        // 'quota' uses kilo bytes -> factor 1024
        // NOTE: int is not large enough, hence qint64
        const qint64 used = parts[1].remove(QLatin1Char('*')).toLongLong() * 1024;
        qint64 softLimit = parts[2].toLongLong() * 1024;
        const qint64 hardLimit = parts[3].toLongLong() * 1024;
        if (softLimit == 0) { // softLimit might be unused (0)
            softLimit = hardLimit;
        }
        const qint64 freeSize = softLimit - used;
        const int percent = qMin(100, qMax(0, qRound(used * 100.0 / softLimit)));

        QuotaItem item;
        item.setIconName(iconNameForQuota(percent));
        item.setMountPoint(parts[0]);
        item.setUsage(percent);
        item.setMountString(i18nc("usage of quota, e.g.: '/home/bla: 38% used'", "%1: %2% used", parts[0], percent));
        item.setUsedString(i18nc("e.g.: 12 GiB of 20 GiB", "%1 of %2", fmt.formatByteSize(used), fmt.formatByteSize(softLimit)));
        item.setFreeString(i18nc("e.g.: 8 GiB free", "%1 free", fmt.formatByteSize(qMax(qint64(0), freeSize))));

        items.append(item);

        maxQuota = qMax(maxQuota, percent);
    }
```

#### AUTO 


```{c}
auto &defaultSpeller = defaultSpellerIt.value();
```

#### AUTO 


```{c}
auto oldMaxComicLimit = mMaxComicLimit;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            m_providers[pluginInfo[1]] = pluginInfo[0];
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (WId wid : windows) {
        KWindowSystem::minimizeWindow(wid);
    }
```

#### AUTO 


```{c}
const auto categories = converter.categories();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &arg : args) {
            const QDate date = QDate::fromString(arg.toString(), Qt::ISODate);
            if (date.isValid()) {
                d->date = date;
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profilePath : std::as_const(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileIdentifier = info.baseName();
        QString name = profileIdentifier;
        QString iconName;
        if (m_appName == QLatin1String("konsole")) {
            KConfig cfg(profilePath, KConfig::SimpleConfig);
            KConfigGroup grp(&cfg, "General");
            iconName = grp.readEntry("Icon", iconName);
            name = grp.readEntry("Name", name);
        } else {
            iconName = m_appName;
        }

        m_data.append(ProfileData{name, profileIdentifier, iconName});
    }
```

#### AUTO 


```{c}
const auto pluginResult = KPluginFactory::instantiatePlugin<PotdProvider>(metadata(m_currentIndex), this, m_args);
```

#### AUTO 


```{c}
const auto& dir
```

#### AUTO 


```{c}
const auto &imageMimeTypeName
```

#### AUTO 


```{c}
const auto msg = new KMessageWidget(i18nc("Message that config is corrupted", //
                                                  "Config entries for alias list and code list have different sizes, ignoring all."),
                                            this);
```

#### AUTO 


```{c}
auto sources = mEngine->sources();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &konsoleDataBaseDir : konsoleDataBaseDirs) {
        m_profileFilesWatch->addDir(konsoleDataBaseDir + QStringLiteral("/konsole"));
    }
```

#### AUTO 


```{c}
const auto codeList = grp.readEntry(CONFIG_CODES, QStringList());
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog, index]() {
        QUrl url = dialog->url();
        QString path = url.toLocalFile();

        // If the user has renamed the file, make sure that the new
        // file name has the extension ".desktop".
        if (!path.endsWith(QLatin1String(".desktop"))) {
            QFile::rename(path, path + QLatin1String(".desktop"));
            path += QLatin1String(".desktop");
            url = QUrl::fromLocalFile(path);
        }
        Q_EMIT launcherEdited(url.toString(), index);
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(m_items.cbegin(), m_items.cend(), [value](const CalendarSystemItem &item) {
        return item.value == value;
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this, url, desktopFileCreated]() {
        if (desktopFileCreated) {
            // User didn't save the data, delete the temporary desktop file.
            QFile::remove(url.toLocalFile());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &s, const QVariant &arg) {
        if (arg.canConvert(QMetaType::QString)) {
            return s + QStringLiteral(":%1").arg(arg.toString());
        }

        return s;
    }
```

#### AUTO 


```{c}
const auto interpreters = Kross::Manager::self().interpreters();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &outputUnit : outputUnits) {
        KUnitConversion::Value outputValue = inputCategory.convert(KUnitConversion::Value(numberValue, inputUnit), outputUnit);
        if (!outputValue.isValid() || inputUnit == outputUnit) {
            continue;
        }

        QueryMatch match(this);
        match.setType(QueryMatch::HelperMatch);
        match.setIconName(QStringLiteral("accessories-calculator"));
        if (outputUnit.categoryId() == KUnitConversion::CurrencyCategory) {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(0, 'f', 2), outputUnit.symbol()));
        } else {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(), outputUnit.symbol()));
        }
        match.setData(outputValue.number());
        match.setRelevance(1.0 - std::abs(std::log10(outputValue.number())) / 50.0);
        match.setActions(actionList);
        matches.append(match);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& profilePath : qAsConst(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileName = info.baseName();
        QString niceName = profileName;
        KConfig cfg(profilePath, KConfig::SimpleConfig);

        if ( cfg.hasGroup( "General" ) ) {
            KConfigGroup grp( &cfg, "General" );

            if ( grp.hasKey( "Name" ) ) {
                niceName = grp.readEntry( "Name" );
            }

            qDebug() << "adding sourcename: " << profileName << " ++" << niceName;
            setData(profileName, QStringLiteral("prettyName"), niceName);
        }
    }
```

#### AUTO 


```{c}
auto pr = m_clientMap.equal_range(identifier);
```

#### LAMBDA EXPRESSION 


```{c}
[this, identifier](const auto &data) {
            dataUpdated(identifier, data);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            const QString& ionId = pluginInfo[1];
            if (!services.contains(ionId)) {
                continue;
            }
            //qDebug() << "ion: " << pluginInfo[0] << pluginInfo[1];
            //d->ions.insert(pluginInfo[1], pluginInfo[0]);

            auto* validator = new Plasma::WeatherValidator(this);
            connect(validator, &Plasma::WeatherValidator::error, this, &LocationListModel::validatorError);
            connect(validator, &Plasma::WeatherValidator::finished, this, &LocationListModel::addSources);
            validator->setDataEngine(dataengine);
            validator->setIon(ionId);

            m_validators.append(validator);
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("konsole"), {QStringLiteral("--profile"), destination()});
```

#### AUTO 


```{c}
auto call = QDBusConnection::sessionBus().asyncCall(msg);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (KJob *job) {
        d->pageRequestFinished(job);
    }
```

#### AUTO 


```{c}
auto roleNames = QStandardItemModel::roleNames();
```

#### AUTO 


```{c}
const auto &dict
```

#### AUTO 


```{c}
auto comic
```

#### AUTO 


```{c}
const auto tz = QStringView(term).right(term.length() - dateWord.length() - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : plugins) {
        QString provider = metadata.value(QLatin1String("X-KDE-PlasmaPoTDProvider-Identifier"));
        if (provider.isEmpty()) {
            continue;
        }
        mFactories.insert(provider, metadata);
        setData(QLatin1String("Providers"), provider, metadata.name());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &code : std::as_const(m_availableLangCodes)) {
        families += code.left(2);
    }
```

#### AUTO 


```{c}
const auto item = m_items[index.row()];
```

#### AUTO 


```{c}
auto* validator
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& konsoleDataBaseDir : konsoleDataBaseDirs) {
            m_sessionWatch->addDir(konsoleDataBaseDir + QLatin1String("/konsole"));
        }
```

#### AUTO 


```{c}
const auto &dir
```

#### AUTO 


```{c}
const auto appletList = applets();
```

#### AUTO 


```{c}
auto obj = m_engine->newQObject(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &outputUnit: outputUnits) {
        KUnitConversion::Value outputValue = inputCategory.convert(
            KUnitConversion::Value(numberValue, inputUnit), outputUnit);
        if (!outputValue.isValid() || inputUnit == outputUnit) {
            continue;
        }

        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-calculator"));
        if (outputUnit.categoryId() == KUnitConversion::CurrencyCategory) {
            outputValue.round(2);
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(0, 'f', 2), outputUnit.symbol()));
        } else {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(), outputUnit.symbol()));
        }
        match.setData(outputValue.number());
        match.setRelevance(1.0 - std::abs(std::log10(outputValue.number())) / 50.0);
        match.setActions(actionList);
        matches.append(match);
    }
```

#### AUTO 


```{c}
const auto fractionParts = QStringView(value).split(QLatin1Char('/'), Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[this] (QDBusPendingCallWatcher *watcher) {
            watcher->deleteLater();
            QDBusPendingReply<QColor> reply = *watcher;
            if (!reply.isError()) {
                setColor(reply.value());
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *validator : qAsConst(m_validators)) {
        validator->validate(m_searchString);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[maxScore](double score) {
        return score / maxScore;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this] {
                    m_consumer = std::make_unique<Plasma::DataEngineConsumer>();
                    m_engine = std::make_unique<DictionaryMatchEngine>(m_consumer->dataEngine(QStringLiteral("dict")));
                }
```

#### AUTO 


```{c}
auto urlStr = imageObj.toObject().value(QLatin1String("imagebig")).toString();
```

#### AUTO 


```{c}
const auto &windows = KWindowSystem::windows();
```

#### AUTO 


```{c}
auto url = imageObject.value(QLatin1String("urlbase"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mountPoint : unusedMountPoints) {
        const int row = indexOfMountPoint(mountPoint, m_items);
        Q_ASSERT(row >= 0);
        removeRow(row);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(mCurrent.shopUrl());
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { deactivate(false); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KonsoleProfileData &data : qAsConst(m_profiles)) {
        if (data.displayName.contains(term, Qt::CaseInsensitive)) {
            Plasma::QueryMatch match(this);
            match.setType(Plasma::QueryMatch::PossibleMatch);
            match.setIconName(data.iconName);
            match.setData(data.displayName);
            match.setText(QStringLiteral("Konsole: ") + data.displayName);
            match.setRelevance((float)term.length() / (float)data.displayName.length());
            context.addMatch(match);
        }
    }
```

#### AUTO 


```{c}
auto keyrelease = reinterpret_cast<xcb_key_release_event_t*>(event);
```

#### AUTO 


```{c}
auto client = new PotdClient(pluginIt->second, args, this);
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(QStringLiteral("plasma_calendar_alternatecalendar"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool isOnline) {
        if (!isOnline) {
            return;
        }
        qCDebug(PLASMA_COMIC) << "Online status changed to true, requesting comic" << mPreviousFailedIdentifier;
        mEngine->requestSource(mPreviousFailedIdentifier, [this](const auto &data) {
            dataUpdated(mPreviousFailedIdentifier, data);
        });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo &sessionFile : sessionFiles) {
        const QString name = QUrl::fromPercentEncoding(sessionFile.baseName().toLocal8Bit()); // is this the right encoding?
        sessions.append(name);
    }
```

#### AUTO 


```{c}
auto sanitizeFileName = [](const QString &name){
        if (name.isEmpty()) {
            return name;
        }

        const char notAllowedChars[] = ",^@={}[]~!?:&*\"|#%<>$\"'();`'/\\";
        QString sanitizedName(name);

        for (const char *c = notAllowedChars; *c; c++) {
            sanitizedName.replace(QLatin1Char(*c), QLatin1Char('-'));
        }

        return sanitizedName;
    };
```

#### AUTO 


```{c}
auto url = imageObj.toObject().value(QLatin1String("urlbase"));
```

#### AUTO 


```{c}
const auto it = subLabelsData.insert(date, m_calendarProvider->subLabels(offsetDate));
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            m_saveStatusMessage = job->errorText();
            if (m_saveStatusMessage.isEmpty()) {
                m_saveStatusMessage = i18nc("@info:status after a save action", "The image was not saved.");
            }
            m_saveStatus = FileOperationStatus::Failed;
            Q_EMIT saveStatusChanged();
        } else {
            m_saveStatusMessage = i18nc("@info:status after a save action %1 file path %2 basename",
                                         "The image was saved as <a href=\"%1\">%2</a>",
                                         m_savedUrl.toString(),
                                         m_savedUrl.fileName());
            m_saveStatus = FileOperationStatus::Successful;
            Q_EMIT saveStatusChanged();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &name) {
        if (name.isEmpty()) {
            return name;
        }

        const char notAllowedChars[] = ",^@={}[]~!?:&*\"|#%<>$\"'();`'/\\";
        QString sanitizedName(name);

        for (const char *c = notAllowedChars; *c; c++) {
            sanitizedName.replace(QLatin1Char(*c), QLatin1Char('-'));
        }

        return sanitizedName;
    }
```

#### AUTO 


```{c}
auto factory = KPluginLoader(mFactories[providerName].fileName()).factory();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &dictName : std::as_const(m_dictNames)) {
        command += QByteArrayLiteral("DEFINE ") + dictName + QByteArrayLiteral(" \"") + m_currentWord.toUtf8() + QByteArrayLiteral("\"\n");
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog, isPopup]() {
        if (!dialog->service()) {
            return;
        }
        const QUrl &url = QUrl::fromLocalFile(dialog->service()->entryPath());
        if (url.isValid()) {
            Q_EMIT launcherAdded(url.toString(), isPopup);
        }
    }
```

#### AUTO 


```{c}
const auto langCodeIt = std::find_if(m_availableLangCodes.cbegin(), m_availableLangCodes.cend(), [&terms](const QString &languageCode) {
        return languageCode.startsWith(terms[0], Qt::CaseInsensitive);
    });
```

#### AUTO 


```{c}
auto keycodes = xcb_get_modifier_mapping_keycodes(reply);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& konsoleDataBaseDir : konsoleDataBaseDirs) {
            m_profileFilesWatch->addDir(konsoleDataBaseDir + QLatin1String("/konsole"));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : items) {
        list.append(item.mountPoint());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        self->deleteLater();

        const QDBusPendingReply<QVariantMap> properties = *self;
        if (properties.isError()) {
            return;
        }

        updateProperties(properties.value());
    }
```

#### AUTO 


```{c}
auto val = m_engine->globalObject().property(name).call(args);
```

#### RANGE FOR STATEMENT 


```{c}
for (Plasma::Containment *candidate : containments) {
            if (candidate->id() == id) {
                m_innerContainment = candidate;
                break;
            }
        }
```

#### AUTO 


```{c}
auto comics = KPackage::PackageLoader::self()->listPackages("Plasma/Comic");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &unit : allUnits) {
            compatibleUnits.insert(unit.toUpper(), unit);
        }
```

#### AUTO 


```{c}
auto factory = KPluginLoader(mFactories[ providerName ].fileName()).factory();
```

#### AUTO 


```{c}
const auto it = std::find_if(m_providers.cbegin(), m_providers.cend(), [&identifier](const KPluginMetaData &metadata) {
        return metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier")) == identifier;
    });
```

#### AUTO 


```{c}
auto end = roleNames.constEnd(), it = roleNames.constBegin();
```

#### AUTO 


```{c}
auto url = []() noexcept {
    return QStringLiteral("Url");
};
```

#### AUTO 


```{c}
auto a
```

#### AUTO 


```{c}
const auto& profileData = i.value();
```

#### LAMBDA EXPRESSION 


```{c}
[&terms](const QString &languageCode) {
        return languageCode.startsWith(terms[0], Qt::CaseInsensitive);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QUrl &newUrl) {
        d->slotRedirection(job, QUrl(), newUrl);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &category : categories) {
        const auto allUnits = category.allUnits();
        for (const auto &unit : allUnits) {
            compatibleUnits.insert(unit.toUpper(), unit);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[]() noexcept {
    return QStringLiteral("Image");
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metadata : plugins) {
        QString provider = metadata.value(QLatin1String( "X-KDE-PlasmaPoTDProvider-Identifier" ));
        if (provider.isEmpty()) {
            continue;
        }
        mFactories.insert(provider, metadata);
        setData( QLatin1String( "Providers" ), provider, metadata.name() );
    }
```

#### AUTO 


```{c}
auto *delegate = new KNotificationJobUiDelegate;
```

#### AUTO 


```{c}
auto json = QJsonDocument::fromJson(job->data());
```

#### AUTO 


```{c}
const auto fillMatch = [this, &context, &query, &speller](const QString &langCode = QString()) {
            if (!langCode.isEmpty()) {
                speller->setLanguage(langCode);
            }

            QStringList suggestions;
            const bool correct = speller->checkAndSuggest(query, suggestions);

            if (correct) {
                QueryMatch match(this);
                match.setType(QueryMatch::ExactMatch);
                match.setIconName(QStringLiteral("checkbox"));
                match.setText(query);
                match.setSubtext(i18nc("Term is spelled correctly", "Correct"));
                match.setData(query);
                context.addMatch(match);
            } else if (!suggestions.isEmpty()) {
                for (const auto &suggestion : std::as_const(suggestions)) {
                    QueryMatch match(this);
                    match.setType(QueryMatch::ExactMatch);
                    match.setIconName(QStringLiteral("edit-rename"));
                    match.setText(suggestion);
                    match.setSubtext(i18n("Suggested term"));
                    match.setData(suggestion);
                    context.addMatch(match);
                }
            } else {
                return false;
            }

            return true;
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &session: qAsConst(m_sessions)) {
        if (listAll || session.contains(term, Qt::CaseInsensitive)) {
            Plasma::QueryMatch match(this);
            match.setType(Plasma::QueryMatch::ExactMatch);
            match.setRelevance(session.compare(term, Qt::CaseInsensitive) == 0 ? 1 : 0.8);
            match.setIconName(m_triggerWord);
            match.setData(session);
            match.setText(session);
            match.setSubtext(i18n("Open Kate Session"));
            context.addMatch(match);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & mountPoint : unusedMountPoints) {
        const int row = indexOfMountPoint(mountPoint, m_items);
        Q_ASSERT(row >= 0);
        removeRow(row);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : fileNames) {
            profilesPaths.append(dir + QLatin1Char('/') + fileName);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Plasma::Applet *applet) {
        emit containment()->configureRequested(applet);
    }
```

#### AUTO 


```{c}
const auto it = std::find_if(m_items.cbegin(), m_items.cend(), [&id](const CalendarSystemItem &item) {
        return item.id == id;
    });
```

#### AUTO 


```{c}
auto pluginIt = m_providersMap.find(identifier);
```

#### LAMBDA EXPRESSION 


```{c}
[this](Plasma::Applet *applet) {
            emit containment()->configureRequested(applet);
        }
```

#### AUTO 


```{c}
const auto &profilePath
```

#### AUTO 


```{c}
auto urlAttr
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fcode : std::as_const(families)) {
        const QStringList family = avail.filter(fcode);
        QString code;
        // If we only have one code, use it.
        // If a string is the default language, use it
        if (family.contains(defaultSpeller->language())) {
            code = defaultSpeller->language();
        } else if (fcode == QLatin1String("en")) {
            // If the family is english, default to en_US.
            const auto enUS = QStringLiteral("en_US");
            if (family.contains(enUS)) {
                code = enUS;
            }
        } else if (family.contains(fcode + QLatin1Char('_') + fcode.toUpper())) {
            // If we have a speller of the form xx_XX, try that.
            // This gets us most European languages with more than one spelling.
            code = fcode + QLatin1Char('_') + fcode.toUpper();
        } else {
            // Otherwise, pick the first value as it is highest priority.
            code = family.first();
        }
        // Finally, add code to the map.
        // FIXME: We need someway to map languageCodeToName
        const QString name; // = locale->languageCodeToName(fcode);
        if (!name.isEmpty()) {
            m_languages[name.toLower()] = code;
        }
    }
```

#### AUTO 


```{c}
auto comics = KPackage::PackageLoader::self()->listPackages(QStringLiteral("Plasma/Comic"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &match : matches) {
        match.setRelevance(calculate_relevance(match.relevance()));
    }
```

#### AUTO 


```{c}
auto it = times.constBegin(), itEnd = times.constEnd();
```

#### AUTO 


```{c}
auto &match
```

#### AUTO 


```{c}
const auto allUnits = category.allUnits();
```

#### AUTO 


```{c}
auto imagesArray = json.object().value(QLatin1String("images"));
```

#### LAMBDA EXPRESSION 


```{c}
[&loop]() {
            loop.quit();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& imageMimeTypeName : imageMimeTypeNames) {
        const auto mimeType = mimeDb.mimeTypeForName(QLatin1String(imageMimeTypeName));
        m_filters << mimeType.globPatterns();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &zoneId : timeZoneIds) {
        QTimeZone timeZone(zoneId);

        const QString zoneName = QString::fromUtf8(zoneId);
        if (zoneName.contains(tz, Qt::CaseInsensitive)) {
            ret[zoneName] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        const QString displayName = timeZone.displayName(QDateTime::currentDateTime(), QTimeZone::LongName);
        if (displayName.contains(tz, Qt::CaseInsensitive)) {
            ret[displayName] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        const QString country = QLocale::countryToString(timeZone.country());
        if (country.contains(tz, Qt::CaseInsensitive)) {
            ret[country] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        // FIXME: This only includes the current abbreviation and not old abbreviation or
        // other possible names.
        // Eg - depending on the current date, only CET or CEST will work
        const QString abbr = timeZone.abbreviation(QDateTime::currentDateTime());
        if (abbr.contains(tz, Qt::CaseInsensitive)) {
            ret[abbr] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &session : std::as_const(sessions)) {
        // Does the query match exactly?
        // no query = perfect match => list everything
        if (listAll || session.compare(term, Qt::CaseInsensitive) == 0) {
            QueryMatch match(this);
            match.setType(QueryMatch::ExactMatch);
            match.setRelevance(session.compare(term, Qt::CaseInsensitive) == 0 ? 1 : 0.8);
            match.setIconName(m_triggerWord);
            match.setData(session);
            match.setText(session);
            match.setSubtext(i18n("Open Kate Session"));
            context.addMatch(match);
        } else {
            // Do fuzzy matching
            const auto res = KFuzzyMatcher::match(term, session);
            if (res.matched) {
                QueryMatch match(this);
                match.setRelevance(res.score); // store the score here for now
                match.setIconName(m_triggerWord);
                match.setData(session);
                match.setText(session);
                match.setSubtext(i18n("Open Kate Session"));
                matches.push_back(match);
                maxScore = std::max(res.score, maxScore);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const auto &data) {
            dataUpdated(mPreviousFailedIdentifier, data);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
        //         qDebug() << line << isQuotaLine(line);
        if (!isQuotaLine(line)) {
            continue;
        }

        QStringList parts = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
        // valid lines range from 7 to 9 parts (grace not always there):
        // Disk quotas for user dh (uid 1000):
        //      Filesystem   blocks  quota    limit     grace   files    quota   limit   grace
        //       /home     16296500  50000000 60000000          389155       0       0
        //       /home     16296500* 50000000 60000000      6   389155       0       0
        //       /home     16296500* 50000000 60000000      4   389155       0       0       5
        //       ^...........we want these...........^
        // NOTE: In case of a soft limit violation, a '*' is added in the used blocks.
        //       Hence, the star is removed below, if applicable

        if (parts.size() < 4) {
            continue;
        }

        // 'quota' uses kilo bytes -> factor 1024
        // NOTE: int is not large enough, hence qint64
        const qint64 used = parts[1].remove(QLatin1Char('*')).toLongLong() * 1024;
        qint64 softLimit = parts[2].toLongLong() * 1024;
        const qint64 hardLimit = parts[3].toLongLong() * 1024;
        if (softLimit == 0) { // softLimit might be unused (0)
            softLimit = hardLimit;
        }
        const qint64 freeSize = softLimit - used;
        const int percent = qMin(100, qMax(0, qRound(used * 100.0 / softLimit)));

        QuotaItem item;
        item.setIconName(iconNameForQuota(percent));
        item.setMountPoint(parts[0]);
        item.setUsage(percent);
        item.setMountString(i18nc("usage of quota, e.g.: '/home/bla: 38% used'", "%1: %2% used", parts[0], percent));
        item.setUsedString(i18nc("e.g.: 12 GiB of 20 GiB", "%1 of %2", fmt.formatByteSize(used), fmt.formatByteSize(softLimit)));
        item.setFreeString(i18nc("e.g.: 8 GiB free", "%1 free", fmt.formatByteSize(qMax(qint64(0), freeSize))));

        items.append(item);

        maxQuota = qMax(maxQuota, percent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto comic : comics) {
        mProviders << comic.pluginId();

        //qDebug() << "ComicEngine::loadProviders()  service name=" << comic.name();
        QStringList data;
        data << comic.name();
        QFileInfo file(comic.iconName());
        if (file.isRelative()) {
            data << QStandardPaths::locate(QStandardPaths::GenericDataLocation, QString::fromLatin1("plasma/comics/%1/%2").arg(comic.pluginId(), comic.iconName()));
        } else {
            data << comic.iconName();
        }
        setData(QLatin1String("providers"), comic.pluginId(), data);
    }
```

#### AUTO 


```{c}
const auto &metadata
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog, isPopup]() {
        const QUrl &url = QUrl::fromLocalFile(dialog->service()->entryPath());
        if (url.isValid()) {
            Q_EMIT launcherAdded(url.toString(), isPopup);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &metadata : plugins) {
        const QString identifier = metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier"));
        if (!identifier.isEmpty()) {
            m_providersMap.emplace(identifier, metadata);
        }
    }
```

#### AUTO 


```{c}
auto defaultSpeller = m_spellers[QString()];
```

#### AUTO 


```{c}
const auto& profilePath
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { giveUpBeingBusy(); }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QRegularExpressionMatch match = copyrightRegEx.match(copyright); match.hasMatch()) {
            // In some regions "title" is empty, so extract the title from the copyright text.
            potdProviderData()->wallpaperTitle = match.captured(1).trimmed();
            potdProviderData()->wallpaperAuthor = match.captured(2).remove(QStringLiteral("�")).trimmed();
        }
```

#### AUTO 


```{c}
const auto expMatch = exp.match(data);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dir : dirs) {
        const QStringList fileNames = QDir(dir).entryList({QStringLiteral("*.profile")});
        for (const QString &fileName : fileNames) {
            profilesPaths.append(dir + QLatin1Char('/') + fileName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            const QString &ionId = pluginInfo[1];
            if (!services.contains(ionId)) {
                continue;
            }
            // qDebug() << "ion: " << pluginInfo[0] << pluginInfo[1];
            // d->ions.insert(pluginInfo[1], pluginInfo[0]);

            auto *validator = new WeatherValidator(dataengine, ionId, this);
            connect(validator, &WeatherValidator::error, this, &LocationListModel::validatorError);
            connect(validator, &WeatherValidator::finished, this, &LocationListModel::addSources);

            m_validators.append(validator);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KonsoleProfileData &data : std::as_const(m_profiles)) {
        if (data.displayName.contains(term, Qt::CaseInsensitive)) {
            QueryMatch match(this);
            match.setType(QueryMatch::PossibleMatch);
            match.setIconName(data.iconName);
            match.setData(data.displayName);
            match.setText(QStringLiteral("Konsole: ") + data.displayName);
            match.setRelevance((float)term.length() / (float)data.displayName.length());
            context.addMatch(match);
        }
    }
```

#### AUTO 


```{c}
auto w = QX11Info::appRootWindow();
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const CalendarSystemItem &item) {
        return item.id == id;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &imageMimeTypeName : imageMimeTypeNames) {
        const auto mimeType = mimeDb.mimeTypeForName(QLatin1String(imageMimeTypeName));
        m_filters << mimeType.globPatterns();
    }
```

#### AUTO 


```{c}
auto defaultSpellerIt = m_spellers.find(QString());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& profilePath : qAsConst(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileName = info.baseName();

        KConfig _config(profilePath, KConfig::SimpleConfig);
        if (_config.hasGroup("General"))
        {
            KonsoleProfileData profileData;
            KConfigGroup cfg(&_config, "General");
            profileData.displayName = cfg.readEntry("Name", profileName);
            profileData.iconName = cfg.readEntry("Icon", QStringLiteral("utilities-terminal"));

            m_profiles.insert(profileName, profileData);
        }
    }
```

#### AUTO 


```{c}
const auto roleNames = this->roleNames();
```

#### AUTO 


```{c}
const auto &item = m_items.at(index.row());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &konsoleDataBaseDir : konsoleDataBaseDirs) {
        m_dirWatch->addDir(konsoleDataBaseDir + QLatin1Char('/') + m_appName);
    }
```

#### AUTO 


```{c}
const auto &currencyLocale
```

#### LAMBDA EXPRESSION 


```{c}
[url, desktopFileCreated]() {
        if (desktopFileCreated) {
            // User didn't save the data, delete the temporary desktop file.
            QFile::remove(url.toLocalFile());
        }
    }
```

#### AUTO 


```{c}
auto *schemeHandler = new DictSchemeHandler(this);
```

#### AUTO 


```{c}
const auto &category
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fcode : qAsConst(families)) {
        const QStringList family = avail.filter(fcode);
        QString code;
        // If we only have one code, use it.
        // If a string is the default language, use it
        if (family.contains(defaultSpeller->language())) {
            code = defaultSpeller->language();
        } else if (fcode == QLatin1String("en")) {
            // If the family is english, default to en_US.
            const auto enUS = QStringLiteral("en_US");
            if (family.contains(enUS)) {
                code = enUS;
            }
        } else if (family.contains(fcode + QLatin1Char('_') + fcode.toUpper())) {
            // If we have a speller of the form xx_XX, try that.
            // This gets us most European languages with more than one spelling.
            code = fcode + QLatin1Char('_') + fcode.toUpper();
        } else {
            // Otherwise, pick the first value as it is highest priority.
            code = family.first();
        }
        // Finally, add code to the map.
        // FIXME: We need someway to map languageCodeToName
        const QString name; // = locale->languageCodeToName(fcode);
        if (!name.isEmpty()) {
            m_languages[name.toLower()] = code;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[value](const CalendarSystemItem &item) {
        return item.value == value;
    }
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QString identifier = data.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier")); !identifier.isEmpty()) {
        d->identifier = identifier;
    } else {
        d->identifier = d->name;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fcode : std::as_const(families)) {
        const QStringList family = m_availableLangCodes.filter(fcode);
        QString code;
        // If we only have one code, use it.
        // If a string is the default language, use it
        if (family.contains(defaultSpeller->language())) {
            code = defaultSpeller->language();
        } else if (fcode == QLatin1String("en")) {
            // If the family is english, default to en_US.
            const auto enUS = QStringLiteral("en_US");
            if (family.contains(enUS)) {
                code = enUS;
            }
        } else if (family.contains(fcode + QLatin1Char('_') + fcode.toUpper())) {
            // If we have a speller of the form xx_XX, try that.
            // This gets us most European languages with more than one spelling.
            code = fcode + QLatin1Char('_') + fcode.toUpper();
        } else {
            // Otherwise, pick the first value as it is highest priority.
            code = family.first();
        }
        // Finally, add code to the map.
        // FIXME: We need someway to map languageCodeToName
        const QString name; // = locale->languageCodeToName(fcode);
        if (!name.isEmpty()) {
            m_languages[name.toLower()] = code;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fcode: qAsConst(families)) {
        const QStringList family = avail.filter(fcode);
        QString code;
        //If we only have one code, use it.
        //If a string is the default language, use it
        if (family.contains(defaultSpeller->language())) {
            code = defaultSpeller->language();
        } else if (fcode == QLatin1String("en")) {
            //If the family is english, default to en_US.
            const auto enUS = QStringLiteral("en_US");
            if (family.contains(enUS)) {
                code = enUS;
            }
        } else if (family.contains(fcode+QLatin1Char('_')+fcode.toUpper())) {
            //If we have a speller of the form xx_XX, try that.
            //This gets us most European languages with more than one spelling.
            code =  fcode+QLatin1Char('_')+fcode.toUpper();
        } else {
            //Otherwise, pick the first value as it is highest priority.
            code = family.first();
        }
        //Finally, add code to the map.
        // FIXME: We need someway to map languageCodeToName
        const QString name;// = locale->languageCodeToName(fcode);
        if (!name.isEmpty()) {
            m_languages[name.toLower()] = code;
        }
    }
```

#### AUTO 


```{c}
auto config = KSharedConfig::openConfig(QStringLiteral("plasma_calendar_astronomicalevents"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                mProvidersLoaded = true;
            }
```

#### AUTO 


```{c}
auto sym = xcb_key_press_lookup_keysym(m_syms, keypress, 0);
```

#### AUTO 


```{c}
const auto containments = c->containments();
```

#### AUTO 


```{c}
const auto &pr
```

#### RANGE FOR STATEMENT 


```{c}
for (auto comic : comics) {
        mProviders << comic.pluginId();

        // qDebug() << "ComicEngine::loadProviders()  service name=" << comic.name();
        QStringList data;
        data << comic.name();
        QFileInfo file(comic.iconName());
        if (file.isRelative()) {
            data << QStandardPaths::locate(QStandardPaths::GenericDataLocation,
                                           QString::fromLatin1("plasma/comics/%1/%2").arg(comic.pluginId(), comic.iconName()));
        } else {
            data << comic.iconName();
        }
        setData(QLatin1String("providers"), comic.pluginId(), data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (ThreadData *data : qAsConst(m_lockers)) {
        QMutexLocker locker(&data->mutex);
        /* Because of QString's CoW semantics, we don't have to worry about
         * the overhead of assigning this to every item. */
        data->definition = definition;
        data->waitCondition.wakeOne();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : std::as_const(lines)) {
        if (partOfSpeech.indexIn(line) == -1) {
            continue;
        }
        if (!partOfSpeech.cap(1).isEmpty()) {
            lastPartOfSpeech = partOfSpeech.cap(1);
        }
        QueryMatch match(this);
        match.setMultiLine(true);
        match.setText(lastPartOfSpeech + QLatin1String(": ") + partOfSpeech.cap(2));
        match.setRelevance(1 - (static_cast<double>(++item) / static_cast<double>(lines.length())));
        match.setType(QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-dictionary"));
        matches.append(match);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        const bool wasPendingUninhibit = d->pendingUninhibit;
        d->pendingUninhibit = false;

        const QDBusPendingReply<uint> reply = *self;
        self->deleteLater();

        if (reply.isError()) {
            qCWarning(NIGHTCOLOR_CONTROL()) << "Could not inhibit Night Color:" << reply.error().message();
            d->state = Uninhibited;
            emit stateChanged();
            return;
        }

        d->cookie = reply.value();
        d->state = Inhibited;
        emit stateChanged();

        if (wasPendingUninhibit) {
            uninhibit();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&identifier](const KPluginMetaData &metadata) {
        return metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier")) == identifier;
    }
```

#### AUTO 


```{c}
auto stringToDouble = [&locale](const QStringRef &value, bool *ok) {
        double numberValue = locale.toDouble(value, ok);
        if (!(*ok)) {
            numberValue = value.toDouble(ok);
        }
        return numberValue;
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profilePath : std::as_const(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileName = info.baseName();
        QString niceName = profileName;
        KConfig cfg(profilePath, KConfig::SimpleConfig);

        if (cfg.hasGroup("General")) {
            KConfigGroup grp(&cfg, "General");

            if (grp.hasKey("Name")) {
                niceName = grp.readEntry("Name");
            }

            qDebug() << "adding sourcename: " << profileName << " ++" << niceName;
            setData(profileName, QStringLiteral("prettyName"), niceName);
        }
    }
```

#### AUTO 


```{c}
auto it = configChanges.find(AppletConfigKeys::temperatureUnitId());
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
//         qDebug() << line << isQuotaLine(line);
        if (!isQuotaLine(line)) {
            continue;
        }

#if QT_VERSION < QT_VERSION_CHECK(5, 15, 0)
        QStringList parts = line.split(QLatin1Char(' '), QString::SkipEmptyParts);
#else
        QStringList parts = line.split(QLatin1Char(' '), Qt::SkipEmptyParts);
#endif
        // valid lines range from 7 to 9 parts (grace not always there):
        // Disk quotas for user dh (uid 1000):
        //      Filesystem   blocks  quota    limit     grace   files    quota   limit   grace
        //       /home     16296500  50000000 60000000          389155       0       0
        //       /home     16296500* 50000000 60000000      6   389155       0       0
        //       /home     16296500* 50000000 60000000      4   389155       0       0       5
        //       ^...........we want these...........^
        // NOTE: In case of a soft limit violation, a '*' is added in the used blocks.
        //       Hence, the star is removed below, if applicable

        if (parts.size() < 4) {
            continue;
        }

        // 'quota' uses kilo bytes -> factor 1024
        // NOTE: int is not large enough, hence qint64
        const qint64 used = parts[1].remove(QLatin1Char('*')).toLongLong() * 1024;
        qint64 softLimit = parts[2].toLongLong() * 1024;
        const qint64 hardLimit = parts[3].toLongLong() * 1024;
        if (softLimit == 0) { // softLimit might be unused (0)
            softLimit = hardLimit;
        }
        const qint64 freeSize = softLimit - used;
        const int percent = qMin(100, qMax(0, qRound(used * 100.0 / softLimit)));

        QuotaItem item;
        item.setIconName(iconNameForQuota(percent));
        item.setMountPoint(parts[0]);
        item.setUsage(percent);
        item.setMountString(i18nc("usage of quota, e.g.: '/home/bla: 38\% used'", "%1: %2% used", parts[0], percent));
        item.setUsedString(i18nc("e.g.: 12 GiB of 20 GiB", "%1 of %2", fmt.formatByteSize(used), fmt.formatByteSize(softLimit)));
        item.setFreeString(i18nc("e.g.: 8 GiB free", "%1 free", fmt.formatByteSize(qMax(qint64(0), freeSize))));

        items.append(item);

        maxQuota = qMax(maxQuota, percent);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &langCode : std::as_const(m_availableLangCodes)) {
                if (langCode == defaultLangCode) {
                    continue;
                }

                if (fillMatch(langCode)) {
                    // The dictionary returns valid results
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto urlAttr : fallbackList) {
                    // Get the best url.
                    QLatin1String urlAttrString(urlAttr);
                    if (attributes.hasAttribute(urlAttrString)) {
                        QString title, userId, photoId;
                        if (attributes.hasAttribute(QStringLiteral("title"))) {
                            title = QTextDocumentFragment::fromHtml(attributes.value(QStringLiteral("title")).toString().trimmed()).toPlainText();
                        }
                        if (attributes.hasAttribute(QStringLiteral("owner")) && attributes.hasAttribute(QStringLiteral("id"))) {
                            userId = attributes.value(QStringLiteral("owner")).toString();
                            photoId = attributes.value(QStringLiteral("id")).toString();
                        }
                        m_photoList.emplace_back(PhotoEntry{
                            attributes.value(urlAttrString).toString(),
                            title,
                            userId,
                            photoId,
                        });
                        found = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &fileName : fileNames) {
            profilesPaths.append(dir + QLatin1Char('/') + fileName);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &currencyLocale : allLocales) {
        const QString symbol = currencyLocale.currencySymbol(QLocale::CurrencySymbol);
        const QString isoCode = currencyLocale.currencySymbol(QLocale::CurrencyIsoCode);

        if (isoCode.isEmpty() || !symbol.contains(hasCurrencyRegex)) {
            continue;
        }
        if (availableISOCodes.contains(isoCode)) {
            compatibleUnits.insert(symbol.toUpper(), isoCode);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : timeZoneIds) {
        QTimeZone timeZone(zoneId);

        const QString zoneName = QString::fromUtf8(zoneId);
        if (zoneName.contains(tz, Qt::CaseInsensitive)) {
            tzName = zoneName;
            return QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
        }
    }
```

#### AUTO 


```{c}
const auto fractionParts = value.splitRef(QLatin1Char('/'), Qt::SkipEmptyParts);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &md) {
        return md.serviceTypes().contains(QStringLiteral("PlasmaPoTD/Plugin"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profilePath : qAsConst(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileName = info.baseName();
        QString niceName = profileName;
        KConfig cfg(profilePath, KConfig::SimpleConfig);

        if (cfg.hasGroup("General")) {
            KConfigGroup grp(&cfg, "General");

            if (grp.hasKey("Name")) {
                niceName = grp.readEntry("Name");
            }

            qDebug() << "adding sourcename: " << profileName << " ++" << niceName;
            setData(profileName, QStringLiteral("prettyName"), niceName);
        }
    }
```

#### AUTO 


```{c}
const auto mimeType = mimeDb.mimeTypeForName(QLatin1String(imageMimeTypeName));
```

#### AUTO 


```{c}
const auto &suggestion
```

#### AUTO 


```{c}
auto &dict = m_availableDicts.at(i);
```

#### AUTO 


```{c}
const auto aliasList = grp.readEntry(CONFIG_ALIASES, QList<QString>());
```

#### AUTO 


```{c}
const auto &sessionFiles = sessionsDir.entryInfoList({QStringLiteral("*.katesession")}, QDir::Files, QDir::Name);
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        if (job->error()) {
            m_saveStatusMessage = job->errorText();
            if (m_saveStatusMessage.isEmpty()) {
                m_saveStatusMessage = i18nc("@info:status after a save action", "The image was not saved.");
            }
            m_saveStatus = FileOperationStatus::Failed;
            Q_EMIT saveStatusChanged();
        } else {
            m_saveStatusMessage = i18nc("@info:status after a save action %1 file path %2 basename",
                                        "The image was saved as <a href=\"%1\">%2</a>",
                                        m_savedUrl.toString(),
                                        m_savedUrl.fileName());
            m_saveStatus = FileOperationStatus::Successful;
            Q_EMIT saveStatusChanged();
        }
    }
```

#### AUTO 


```{c}
auto imagesArray = json.object().value("images");
```

#### AUTO 


```{c}
const auto plugins = KPluginMetaData::findPlugins(QStringLiteral("potd"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const Plasma::QueryMatch &match) {
        return match.text() == QStringLiteral("hello") && match.iconName() == QStringLiteral("edit-rename");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KonsoleProfileData &data: qAsConst(m_profiles)) {
        if (data.displayName.contains(term, Qt::CaseInsensitive)) {
            Plasma::QueryMatch match(this);
            match.setType(Plasma::QueryMatch::PossibleMatch);
            match.setIconName(data.iconName);
            match.setData(data.displayName);
            match.setText(QStringLiteral("Konsole: ") + data.displayName);
            match.setRelevance((float) term.length() / (float) data.displayName.length());
            context.addMatch(match);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &curr : retLines) {
        if (curr.startsWith("554")) {
            // TODO: What happens if no DB available?
            // TODO: Eventually there will be functionality to change the server...
            break;
        }

        // ignore status code and empty lines
        if (curr.startsWith("250") || curr.startsWith("110") || curr.isEmpty()) {
            continue;
        }

        if (!curr.startsWith('-') && !curr.startsWith('.')) {
            const QString line = QString::fromUtf8(curr).trimmed();
            const QString id = line.section(' ', 0, 0);
            QString description = line.section(' ', 1);
            if (description.startsWith('"') && description.endsWith('"')) {
                description.remove(0, 1);
                description.chop(1);
            }
            availableDicts.insert(id, description);
        }
    }
```

#### AUTO 


```{c}
const auto reMatch = partOfSpeech.match(line);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QMap<QString, QString> &dicts) {
        beginResetModel();
        m_availableDicts = {};
        m_idIndexProxyMap.clear();
        m_availableDicts.resize(dicts.count());
        m_idIndexProxyMap.reserve(dicts.size());

        int i = 0;
        for (auto it = dicts.begin(), end = dicts.end(); it != end; ++it, ++i) {
            m_availableDicts[i] = AvailableDict{it.key(), it.value()};
            m_idIndexProxyMap.emplace(it.key(), i);
        }
        endResetModel();

        setEnabledDicts(m_enabledDicts);
    }
```

#### AUTO 


```{c}
const auto pressure = data[QStringLiteral("Pressure")];
```

#### AUTO 


```{c}
const auto pluginResult = KPluginFactory::instantiatePlugin<PotdProvider>(m_metadata, this, m_args);
```

#### AUTO 


```{c}
auto sanitizeFileName = [](const QString &name) {
        if (name.isEmpty()) {
            return name;
        }

        const char notAllowedChars[] = ",^@={}[]~!?:&*\"|#%<>$\"'();`'/\\";
        QString sanitizedName(name);

        for (const char *c = notAllowedChars; *c; c++) {
            sanitizedName.replace(QLatin1Char(*c), QLatin1Char('-'));
        }

        return sanitizedName;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[system](const std::pair<QString, CalendarSystemItem> &pr) {
            return pr.second.system == system;
        }
```

#### AUTO 


```{c}
auto *validator
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData & md) {
        return md.serviceTypes().contains(QStringLiteral("PlasmaPoTD/Plugin"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &session : qAsConst(m_sessions)) {
        if (listAll || session.contains(term, Qt::CaseInsensitive)) {
            Plasma::QueryMatch match(this);
            match.setType(Plasma::QueryMatch::ExactMatch);
            match.setRelevance(session.compare(term, Qt::CaseInsensitive) == 0 ? 1 : 0.8);
            match.setIconName(m_triggerWord);
            match.setData(session);
            match.setText(session);
            match.setSubtext(i18n("Open Kate Session"));
            context.addMatch(match);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suggestion : std::as_const(suggestions)) {
                QueryMatch match(this);
                match.setType(QueryMatch::ExactMatch);
                match.setIconName(QStringLiteral("edit-rename"));
                match.setText(suggestion);
                match.setSubtext(i18n("Suggested term"));
                match.setData(suggestion);
                context.addMatch(match);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &word: conversionWords) {
        conversionRegex.append(QLatin1Char(' ') + word + QStringLiteral(" |"));
    }
```

#### AUTO 


```{c}
auto metadataString = randomArrayValueByKey(json.object(), QLatin1String("simonstalenhag-se-entrypoint"));
```

#### RANGE FOR STATEMENT 


```{c}
for (int size : standardSizes) {
        sizes.append(QString::number(size));
    }
```

#### AUTO 


```{c}
auto url = imageObj.toObject().value("url");
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : timeZoneIds) {
        QTimeZone timeZone(zoneId);

        const QString zoneName = QString::fromUtf8(zoneId);
        if (zoneName.startsWith(tz, Qt::CaseInsensitive)) {
            ret[zoneName] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        const QString country = QLocale::countryToString(timeZone.country());
        if (country.startsWith(tz, Qt::CaseInsensitive)) {
            ret[country] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }

        // FIXME: This only includes the current abbreviation and not old abbreviation or
        // other possible names.
        // Eg - depending on the current date, only CET or CEST will work
        const QString abbr = timeZone.abbreviation(QDateTime::currentDateTime());
        if (abbr.startsWith(tz, Qt::CaseInsensitive)) {
            ret[abbr] = QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
            continue;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &curr : retLines) {
        if (curr.endsWith("420") || curr.startsWith("421")) {
            // TODO: what happens if the server is down
        }
        if (curr.startsWith("554")) {
            // TODO: What happens if no DB available?
            // TODO: Eventually there will be functionality to change the server...
            break;
        }

        // ignore status code and empty lines
        if (curr.startsWith("250") || curr.startsWith("110") || curr.isEmpty()) {
            continue;
        }

        if (!curr.startsWith('-') && !curr.startsWith('.')) {
            const QString line = QString::fromUtf8(curr).trimmed();
            const QString id = line.section(' ', 0, 0);
            QString description = line.section(' ', 1);
            if (description.startsWith('"') && description.endsWith('"')) {
                description.remove(0, 1);
                description.chop(1);
            }
            availableDicts.insert(id, description);
        }
    }
```

#### AUTO 


```{c}
auto it = configChanges.find(AppletConfigKeys::services());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &code : avail) {
        families += code.left(2);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&dict](const QString &id) {
            return id == dict.id;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        // everything finished, stop the timeout timer
        d->mTimer->stop();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &konsoleDataBaseDir : konsoleDataBaseDirs) {
        m_dirWatch->addDir(konsoleDataBaseDir + QLatin1String("/konsole"));
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("kate"), {QStringLiteral("--start"), match.data().toString(), QStringLiteral("-n")});
```

#### AUTO 


```{c}
auto calculate_relevance = [maxScore](double score) {
        return score / maxScore;
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray &code) {
        return m_definitionData.contains(code);
    }
```

#### AUTO 


```{c}
const auto tz = term.rightRef(term.length() - dateWord.length() - 1);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        //everything finished, stop the timeout timer
        d->mTimer->stop();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback, provider]() {
            finished(provider, callback);
        }
```

#### AUTO 


```{c}
auto *validator = new WeatherValidator(dataengine, ionId, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant &plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            const QString &ionId = pluginInfo[1];
            if (!services.contains(ionId)) {
                continue;
            }

            m_serviceCodeToDisplayName[pluginInfo[1]] = pluginInfo[0];

            // qDebug() << "ion: " << pluginInfo[0] << pluginInfo[1];
            // d->ions.insert(pluginInfo[1], pluginInfo[0]);

            auto *validator = new WeatherValidator(dataengine, ionId, this);
            connect(validator, &WeatherValidator::error, this, &LocationListModel::validatorError);
            connect(validator, &WeatherValidator::finished, this, &LocationListModel::addSources);

            m_validators.append(validator);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&locale](const QStringRef &value, bool *ok) {
        double numberValue = locale.toDouble(value, ok);
        if (!(*ok)) {
            numberValue = value.toDouble(ok);
        }
        return numberValue;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto comic : comics) {

        qCDebug(PLASMA_COMIC) << "ComicEngine::loadProviders()  service name=" << comic.name();
        ComicProviderInfo data;
        data.pluginId = comic.pluginId();
        data.name = comic.name();
        QFileInfo file(comic.iconName());
        if (file.isRelative()) {
            data.icon =
                QStandardPaths::locate(QStandardPaths::GenericDataLocation, QString::fromLatin1("plasma/comics/%1/%2").arg(comic.pluginId(), comic.iconName()));
        } else {
            data.icon = comic.iconName();
        }
        mProviders << comic.pluginId();
        providers << data;
    }
```

#### AUTO 


```{c}
const auto &defaultSpeller = m_spellers[QString()];
```

#### AUTO 


```{c}
auto& defaultSpeller = defaultSpellerIt.value();
```

#### AUTO 


```{c}
auto imageObj = imagesArray.toArray().at(0);
```

#### AUTO 


```{c}
auto array = object.value(key).toArray();
```

#### AUTO 


```{c}
const auto lengthCategory = converter.category(KUnitConversion::LengthCategory);
```

#### LAMBDA EXPRESSION 


```{c}
[](const KPluginMetaData &metadata) {
        return !metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier")).isEmpty();
    }
```

#### AUTO 


```{c}
const auto aliasList = grp.readEntry(CONFIG_ALIASES, QStringList());
```

#### AUTO 


```{c}
auto* validator = new WeatherValidator(dataengine, ionId, this);
```

#### AUTO 


```{c}
auto it = std::find_if(m_enabledDictIdList.cbegin(), m_enabledDictIdList.cend(), [&dict](const QString &id) {
            return id == dict.id;
        });
```

#### AUTO 


```{c}
auto it = infos.begin(), end = infos.end();
```

#### LAMBDA EXPRESSION 


```{c}
[]() noexcept {
    return QStringLiteral("Url");
}
```

#### AUTO 


```{c}
auto urlStr = metadataString.toString();
```

#### AUTO 


```{c}
const auto &arg
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (const QDate alt = d->calendarProvider()->fromGregorian(offsetDate); alt != date) {
            alternateDatesData.insert(date, alt);
        }
```

#### AUTO 


```{c}
auto keypress = reinterpret_cast<xcb_key_press_event_t*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &currencyLocale: allLocales) {
        const QString symbol = currencyLocale.currencySymbol(QLocale::CurrencySymbol);
        const QString isoCode = currencyLocale.currencySymbol(QLocale::CurrencyIsoCode);

        if (isoCode.isEmpty() || !symbol.contains(hasCurrencyRegex)) {
            continue;
        }
        if (availableISOCodes.contains(isoCode)) {
            compatibleUnits.insert(symbol.toUpper(), isoCode);
        }
    }
```

#### AUTO 


```{c}
const auto &sessionFiles = sessionsDir.entryInfoList({QStringLiteral("*.katesession")}, QDir::Files);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suggestion : std::as_const(suggestions)) {
                Plasma::QueryMatch match(this);
                match.setType(Plasma::QueryMatch::ExactMatch);
                match.setIconName(QStringLiteral("edit-rename"));
                match.setText(suggestion);
                match.setSubtext(i18n("Suggested term"));
                match.setData(suggestion);
                context.addMatch(match);
            }
```

#### AUTO 


```{c}
auto it = data.begin(), end = data.end();
```

#### AUTO 


```{c}
const auto tz = term.rightRef(term.length() - timeWord.length() - 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &item : items) {
        // remove still used item from unused list
        unusedMountPoints.removeOne(item.mountPoint());

        // insert or modify m_items
        int row = indexOfMountPoint(item.mountPoint(), m_items);
        if (row < 0) {
            // new item: append on end
            row = m_items.size();
            insertRow(row);
        }
        setData(createIndex(row, 0), QVariant::fromValue(item));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : qAsConst(lines)) {
        if (partOfSpeech.indexIn(line) == -1) {
            continue;
        }
        if (!partOfSpeech.cap(1).isEmpty()) {
            lastPartOfSpeech = partOfSpeech.cap(1);
        }
        Plasma::QueryMatch match(this);
        match.setMultiLine(true);
        match.setText(lastPartOfSpeech + QLatin1String(": ") + partOfSpeech.cap(2));
        match.setRelevance(1 - (static_cast<double>(++item) / static_cast<double>(lines.length())));
        match.setType(Plasma::QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-dictionary"));
        matches.append(match);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *self) {
        const bool wasPendingUninhibit = d->pendingUninhibit;
        d->pendingUninhibit = false;

        const QDBusPendingReply<uint> reply = *self;
        self->deleteLater();

        if (reply.isError()) {
            qCWarning(NIGHTCOLOR_CONTROL()) << "Could not inhibit Night Color:" << reply.error().message();
            d->state = Uninhibited;
            Q_EMIT stateChanged();
            return;
        }

        d->cookie = reply.value();
        d->state = Inhibited;
        Q_EMIT stateChanged();

        if (wasPendingUninhibit) {
            uninhibit();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KIO::Job *job, const QUrl &oldUrl, const QUrl &newUrl) {
        d->slotRedirection(job, oldUrl, newUrl);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &name){
        if (name.isEmpty()) {
            return name;
        }

        const char notAllowedChars[] = ",^@={}[]~!?:&*\"|#%<>$\"'();`'/\\";
        QString sanitizedName(name);

        for (const char *c = notAllowedChars; *c; c++) {
            sanitizedName.replace(QLatin1Char(*c), QLatin1Char('-'));
        }

        return sanitizedName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suggestion : std::as_const(suggestions)) {
                    QueryMatch match(this);
                    match.setType(QueryMatch::ExactMatch);
                    match.setIconName(QStringLiteral("edit-rename"));
                    match.setText(suggestion);
                    match.setSubtext(i18n("Suggested term"));
                    match.setData(suggestion);
                    context.addMatch(match);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& profilePath : qAsConst(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileName = info.baseName();

        KConfig _config(profilePath, KConfig::SimpleConfig);
        if (_config.hasGroup("General"))
        {
            KonsoleProfileData profileData;
            KConfigGroup cfg(&_config, "General");
            profileData.displayName = cfg.readEntry("Name", profileName);
            profileData.iconName = cfg.readEntry("Icon", QStringLiteral("utilities-terminal"));

            m_sessions.insert(profileName, profileData);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto comic : comics) {
        mProviders << comic.pluginId();

        qCDebug(PLASMA_COMIC) << "ComicEngine::loadProviders()  service name=" << comic.name();
        QStringList data;
        data << comic.name();
        QFileInfo file(comic.iconName());
        if (file.isRelative()) {
            data << QStandardPaths::locate(QStandardPaths::GenericDataLocation,
                                           QString::fromLatin1("plasma/comics/%1/%2").arg(comic.pluginId(), comic.iconName()));
        } else {
            data << comic.iconName();
        }
        setData(QLatin1String("providers"), comic.pluginId(), data);
    }
```

#### AUTO 


```{c}
const auto enUS = QStringLiteral("en_US");
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& profilePath : qAsConst(profilesPaths)) {
        QFileInfo info(profilePath);
        const QString profileName = info.baseName();
        QString niceName = profileName;
        KConfig cfg(profilePath, KConfig::SimpleConfig);

        if ( cfg.hasGroup( "General" ) ) {
            KConfigGroup grp( &cfg, "General" );

            if ( grp.hasKey( "Name" ) ) {
                niceName = grp.readEntry( "Name" );
            }

            QString sourceName = "name:" + profileName;
            qDebug() << "adding sourcename: " << profileName << " ++" << niceName;
            setData(profileName, "prettyName", niceName);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : std::as_const(lines)) {
        if (partOfSpeech.indexIn(line) == -1) {
            continue;
        }
        if (!partOfSpeech.cap(1).isEmpty()) {
            lastPartOfSpeech = partOfSpeech.cap(1);
        }
        Plasma::QueryMatch match(this);
        match.setMultiLine(true);
        match.setText(lastPartOfSpeech + QLatin1String(": ") + partOfSpeech.cap(2));
        match.setRelevance(1 - (static_cast<double>(++item) / static_cast<double>(lines.length())));
        match.setType(Plasma::QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-dictionary"));
        matches.append(match);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto comic : comics) {
        mProviders << comic.pluginId();

        //qDebug() << "ComicEngine::loadProviders()  service name=" << comic.name();
        QStringList data;
        data << comic.name();
        QFileInfo file(comic.iconName());
        if (file.isRelative()) {
            data << QStandardPaths::locate(QStandardPaths::GenericDataLocation, QString(QLatin1String("plasma-comic/%1.png")).arg(comic.iconName()));
        } else {
            data << comic.iconName();
        }
        setData(QLatin1String("providers"), comic.pluginId(), data);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &interpretername : interpreters) {
            info = Kross::Manager::self().interpreterInfo(interpretername);
            wildcards = info->wildcard();
            wildcards.remove(QLatin1Char('*'));
            mExtensions << wildcards.split(QLatin1Char(' '));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { onTimeoutNotificationClosed(); }
```

#### AUTO 


```{c}
auto it = compatibleUnits.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[this](Plasma::Applet *applet) {
        Q_EMIT containment()->configureRequested(applet);
    }
```

#### AUTO 


```{c}
auto result = re.match(data);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            const QString& ionId = pluginInfo[1];
            if (!services.contains(ionId)) {
                continue;
            }
            //qDebug() << "ion: " << pluginInfo[0] << pluginInfo[1];
            //d->ions.insert(pluginInfo[1], pluginInfo[0]);

            auto* validator = new WeatherValidator(dataengine, ionId, this);
            connect(validator, &WeatherValidator::error, this, &LocationListModel::validatorError);
            connect(validator, &WeatherValidator::finished, this, &LocationListModel::addSources);

            m_validators.append(validator);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, prefetch](const auto &data) {
                dataUpdated(prefetch, data);
            }
```

#### AUTO 


```{c}
const auto dates = datetime(tz);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &unit: category.allUnits()) {
            compatibleUnits.insert(unit.toUpper(), unit);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &outputUnit : outputUnits) {
        KUnitConversion::Value outputValue = inputCategory.convert(KUnitConversion::Value(numberValue, inputUnit), outputUnit);
        if (!outputValue.isValid() || inputUnit == outputUnit) {
            continue;
        }

        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::HelperMatch);
        match.setIconName(QStringLiteral("accessories-calculator"));
        if (outputUnit.categoryId() == KUnitConversion::CurrencyCategory) {
            outputValue.round(2);
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(0, 'f', 2), outputUnit.symbol()));
        } else {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(), outputUnit.symbol()));
        }
        match.setData(outputValue.number());
        match.setRelevance(1.0 - std::abs(std::log10(outputValue.number())) / 50.0);
        match.setActions(actionList);
        matches.append(match);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback, provider]() {
                error(provider, callback);
            }
```

#### AUTO 


```{c}
const auto numberDataPair = getValidatedNumberValue(inputValueString);
```

#### AUTO 


```{c}
const auto &unitStringKey
```

#### LAMBDA EXPRESSION 


```{c}
[&loop, &query, &returnedQuery, &context](const QString &html) {
        returnedQuery = html;
        loop.quit();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &session : std::as_const(m_sessions)) {
        if (listAll || session.contains(term, Qt::CaseInsensitive)) {
            Plasma::QueryMatch match(this);
            match.setType(Plasma::QueryMatch::ExactMatch);
            match.setRelevance(session.compare(term, Qt::CaseInsensitive) == 0 ? 1 : 0.8);
            match.setIconName(m_triggerWord);
            match.setData(session);
            match.setText(session);
            match.setSubtext(i18n("Open Kate Session"));
            context.addMatch(match);
        }
    }
```

#### AUTO 


```{c}
const auto imageMimeTypeNames = QImageReader::supportedMimeTypes();
```

#### AUTO 


```{c}
auto it = configChanges.find(AppletConfigKeys::showTemperatureInTooltip());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &pr : std::as_const(m_clientMap)) {
        connect(pr.second.client, &PotdClient::done, this, &PotdEngine::slotDone);
        m_updateCount++;
        qCDebug(WALLPAPERPOTD) << pr.second.client->m_metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier")) << "starts updating wallpaper.";
        pr.second.client->updateSource(refresh);
    }
```

#### AUTO 


```{c}
const auto codeList = grp.readEntry(CONFIG_CODES, QList<QString>());
```

#### AUTO 


```{c}
auto &d = m_availableDicts.at(it->second);
```

#### AUTO 


```{c}
const auto it = m_idIndexProxyMap.find(id);
```

#### LAMBDA EXPRESSION 


```{c}
[this, dialog, index, isPopup]() {
        QUrl url = dialog->url();
        QString path = url.toLocalFile();

        // If the user has renamed the file, make sure that the new
        // file name has the extension ".desktop".
        if (!path.endsWith(QLatin1String(".desktop"))) {
            QFile::rename(path, path + QLatin1String(".desktop"));
            path += QLatin1String(".desktop");
            url = QUrl::fromLocalFile(path);
        }
        Q_EMIT launcherEdited(url.toString(), index, isPopup);
    }
```

#### AUTO 


```{c}
auto arraySize = array.size();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &html) {
        Q_EMIT definitionFound(html);
    }
```

#### AUTO 


```{c}
auto font = m_doc->defaultFont();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& plugin : plugins) {
        const QStringList pluginInfo = plugin.toString().split(QLatin1Char('|'));
        if (pluginInfo.count() > 1) {
            m_services.append(ServiceItem(pluginInfo[0], pluginInfo[1]));
        }
    }
```

#### AUTO 


```{c}
const auto tz = QStringView(term).right(term.length() - timeWord.length() - 1);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            // operation took too long, abort it
            emit mParent->error(mParent);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto & item : items) {
            list.append(item.mountPoint());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, job] {
            setError(job->error());
            setErrorText(job->errorText());
            emitResult();
        }
```

#### AUTO 


```{c}
const auto season = KHolidays::AstroSeasons::seasonAtDate(date);
```

#### AUTO 


```{c}
const auto validationResult = data[QStringLiteral("validate")].toString().split(QLatin1Char('|'));
```

#### AUTO 


```{c}
auto attributes = xml.attributes();
```

#### AUTO 


```{c}
auto image = []() noexcept {
    return QStringLiteral("Image");
};
```

#### AUTO 


```{c}
const auto& suggestion
```

#### AUTO 


```{c}
auto jsonImageArray = QJsonDocument::fromJson(job->data()).object().value(QLatin1String("parse")).toObject().value(QLatin1String("images")).toArray();
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(QStringLiteral("konsole"), {QStringLiteral("--profile"), profile});
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &suggestion : qAsConst(suggestions)) {
                Plasma::QueryMatch match(this);
                match.setType(Plasma::QueryMatch::ExactMatch);
                match.setIconName(QStringLiteral("edit-rename"));
                match.setText(suggestion);
                match.setSubtext(i18n("Suggested term"));
                match.setData(suggestion);
                context.addMatch(match);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto urlAttr : fallbackList) {
                    // Get the best url.
                    QLatin1String urlAttrString(urlAttr);
                    if (attributes.hasAttribute(urlAttrString)) {
                        m_photoList.append(attributes.value(urlAttrString).toString());
                        found = true;
                        break;
                    }
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KUnitConversion::Unit &outputUnit : outputUnits) {
        KUnitConversion::Value outputValue = inputCategory.convert(KUnitConversion::Value(numberValue, inputUnit), outputUnit);
        if (!outputValue.isValid() || inputUnit == outputUnit) {
            continue;
        }

        Plasma::QueryMatch match(this);
        match.setType(Plasma::QueryMatch::HelperMatch);
        match.setIconName(QStringLiteral("accessories-calculator"));
        if (outputUnit.categoryId() == KUnitConversion::CurrencyCategory) {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(0, 'f', 2), outputUnit.symbol()));
        } else {
            match.setText(QStringLiteral("%1 (%2)").arg(outputValue.toString(), outputUnit.symbol()));
        }
        match.setData(outputValue.number());
        match.setRelevance(1.0 - std::abs(std::log10(outputValue.number())) / 50.0);
        match.setActions(actionList);
        matches.append(match);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&ret](const QByteArray &code) {
        return ret.contains(code);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KJob *job) {
        d->slotRedirectionDone(job);
    }
```

#### AUTO 


```{c}
const auto randomNumber = QRandomGenerator::global()->bounded(static_cast<int>(m_photoList.size()));
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QMap<QString, QString>& sources) { d->validatorFinished(sources); }
```

#### AUTO 


```{c}
auto roleNames = QAbstractListModel::roleNames();
```

#### AUTO 


```{c}
const auto systemIt = s_calendarMap.find(system);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                engine()->checkForUpdates();
            }
```

#### AUTO 


```{c}
auto it = std::find_if(s_calendarMap.cbegin(), s_calendarMap.cend(), [system](const std::pair<QString, CalendarSystemItem> &pr) {
            return pr.second.system == system;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &code: avail) {
        families +=code.left(2);
    }
```

#### AUTO 


```{c}
auto &item
```

#### LAMBDA EXPRESSION 


```{c}
[this, callback, provider]() {
                finished(provider, callback);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* validator : qAsConst(m_validators)) {
        validator->validate(m_searchString, true);
    }
```

#### AUTO 


```{c}
auto it = std::find_if(m_providers.cbegin(), m_providers.cend(), [&identifier](const KPluginMetaData &metadata) {
        return identifier == metadata.value(QStringLiteral("X-KDE-PlasmaPoTDProvider-Identifier"));
    });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &profilePath : std::as_const(profilesPaths)) {
        const QString profileName = QFileInfo(profilePath).baseName();

        const KConfig _config(profilePath, KConfig::SimpleConfig);
        if (_config.hasGroup("General")) {
            KonsoleProfileData profileData;
            const KConfigGroup cfg = _config.group("General");
            profileData.displayName = cfg.readEntry("Name", profileName);
            profileData.iconName = cfg.readEntry("Icon", QStringLiteral("utilities-terminal"));
            if (!profileData.displayName.isEmpty()) {
                m_profiles.append(profileData);
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QDBusPendingCallWatcher *watcher) {
        watcher->deleteLater();
        QDBusPendingReply<QColor> reply = *watcher;
        if (!reply.isError()) {
            setColor(reply.value());
        }
    }
```

#### AUTO 


```{c}
auto imageObj = imagesArray.toArray()[0];
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& zoneId : timeZoneIds) {
        QTimeZone timeZone(zoneId);

        const QString zoneName = QString::fromUtf8(zoneId);
        if (zoneName.startsWith(tz, Qt::CaseInsensitive)) {
            tzName = zoneName;
            return QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
        }

        const QString country = QLocale::countryToString(timeZone.country());
        if (country.startsWith(tz, Qt::CaseInsensitive)) {
            tzName = country;
            return QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
        }

        // FIXME: This only includes the current abbreviation and not old abbreviation or
        // other possible names.
        // Eg - depending on the current date, only CET or CEST will work
        const QString abbr = timeZone.abbreviation(QDateTime::currentDateTime());
        if (abbr.startsWith(tz, Qt::CaseInsensitive)) {
            tzName = abbr;
            return QDateTime::currentDateTimeUtc().toTimeZone(timeZone);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* validator : qAsConst(m_validators)) {
        validator->validate(m_searchString);
    }
```

#### AUTO 


```{c}
auto cookie = xcb_grab_keyboard(QX11Info::connection(), false, w, XCB_CURRENT_TIME,
                                    XCB_GRAB_MODE_ASYNC, XCB_GRAB_MODE_ASYNC);
```

#### AUTO 


```{c}
const auto &unit
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : std::as_const(lines)) {
        const auto reMatch = partOfSpeech.match(line);
        if (!reMatch.hasMatch()) {
            continue;
        }
        if (!reMatch.capturedView(1).isEmpty()) {
            lastPartOfSpeech = reMatch.captured(1);
        }
        QueryMatch match(this);
        match.setMultiLine(true);
        match.setText(lastPartOfSpeech + QLatin1String(": ") + reMatch.captured(2));
        match.setRelevance(1 - (static_cast<double>(++item) / static_cast<double>(lines.length())));
        match.setType(QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-dictionary"));
        matches.append(match);
    }
```

#### AUTO 


```{c}
auto cookie = xcb_get_modifier_mapping(QX11Info::connection());
```

#### AUTO 


```{c}
auto createClient = [this, &identifier, &args]() -> PotdClient * {
        auto pluginIt = m_providersMap.find(identifier);

        if (pluginIt == m_providersMap.end()) {
            // Not a valid identifier
            return nullptr;
        }

        qCDebug(WALLPAPERPOTD) << identifier << "is registered with arguments" << args;
        auto client = new PotdClient(pluginIt->second, args, this);
        m_clientMap.emplace(identifier, ClientPair{client, 1});

        return client;
    };
```

#### AUTO 


```{c}
const auto identifier = data[QStringLiteral("Identifier")].toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *validator : std::as_const(m_validators)) {
        validator->validate(m_searchString);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& konsoleDataBaseDir : konsoleDataBaseDirs) {
        m_dirWatch->addDir(konsoleDataBaseDir + QLatin1String("/konsole"));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : qAsConst(lines)) {
        if (partOfSpeech.indexIn(line) == -1) {
            continue;
        }
        if (!partOfSpeech.cap(1).isEmpty()) {
            lastPartOfSpeech = partOfSpeech.cap(1);
        }
        Plasma::QueryMatch match(this);
        match.setText(query + QLatin1String(": ") + lastPartOfSpeech);
        match.setRelevance(1 - (static_cast<double>(++item) / static_cast<double>(lines.length())));
        match.setType(Plasma::QueryMatch::InformationalMatch);
        match.setIconName(QStringLiteral("accessories-dictionary"));
        match.setSubtext(partOfSpeech.cap(2));
        matches.append(match);
    }
```

