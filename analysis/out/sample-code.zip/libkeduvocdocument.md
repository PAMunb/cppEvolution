#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : files) {
            khangmanFiles.append( path + '/' + filename);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : dataPaths) {
        const QStringList files = QDir( path ).entryList(nameFilter, QDir::Files | QDir::NoDotAndDotDot );
        for (const QString &filename : files) {
            unsortedFiles.append( path + '/' + filename);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &language : languages) {
        qDebug() << "Got language: " << language;
        const QStringList files = SharedKvtmlFiles::fileNames(language);
        for (const QString &file : files) {
            qDebug() << "Got filename " << file;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &file : files) {
            qDebug() << "Got filename " << file;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &filename : files) {
            unsortedFiles.append( path + '/' + filename);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &path : dataPaths) {
        const QStringList files = QDir( path ).entryList(nameFilter, QDir::Files );
        for (const QString &filename : files) {
            khangmanFiles.append( path + '/' + filename);
        }
    }
```

