#### RANGE FOR STATEMENT 


```{c}
for(const QByteArray &pathDir : qgetenv("PATH").split(KPATH_SEPARATOR)) {
        const QString dataDirFromPath = QFileInfo(QFile::decodeName(pathDir) + QStringLiteral("/data/")
                                                  + path).canonicalFilePath();
        if (fileReadable(dataDirFromPath)) {
            return dataDirFromPath;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : standardLocations) {
            if (dir.indexOf(re) != -1) {
                QString realDir(dir);
                realDir.replace(re, QLatin1Char('/') + privateName);
                result.append(realDir);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &dir : correctedStandardLocations) {
        fullPath = QFileInfo(dir + QLatin1Char('/') + path).canonicalFilePath();
        if (fileReadable(fullPath)) {
            return fullPath;
        }
    }
```

#### AUTO 


```{c}
auto *loader = new QPluginLoader(pluginMetaData.fileName());
```

#### AUTO 


```{c}
auto dataSource = new KReportExampleDataSource();
```

#### AUTO 


```{c}
auto dataSource = new KReportExampleDataSource;
```

#### AUTO 


```{c}
auto closeButton = buttonBox->button(QDialogButtonBox::Close);
```

#### RANGE FOR STATEMENT 


```{c}
for (Type t : types) {
        result.append(symbol(t));
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &pluginMetaData : metaDataList) {
        auto *loader = new QPluginLoader(pluginMetaData.fileName());
        QScopedPointer<KReportPluginEntry> entry(new KReportPluginEntry);
        entry->setMetaData(loader);
        const KReportPluginMetaData *metaData = entry->metaData();
        if (metaData->version() != expectedVersion) {
            kreportWarning() << "KReport element plugin with ID" << metaData->id()
                             << "(" << metaData->fileName() << ")"
                             << "has version" << metaData->version() << "but expected version is"
                             << expectedVersion
                             << "-- skipping it";
            continue;
        }
        if (m_plugins.contains(metaData->id())) {
            kreportWarning() << "KReport element plugin with ID" << metaData->id()
                             << "already found at"
                             << m_plugins.value(metaData->id())->metaData()->fileName()
                             << "-- skipping another at" << metaData->fileName();
            continue;
        }
        if (!KReportPrivate::setupPrivateIconsResourceWithMessage(
            QLatin1String(KREPORT_BASE_NAME_LOWER),
            QString::fromLatin1("icons/%1_%2.rcc")
                .arg(metaData->id()).arg(KReportPrivate::supportedIconTheme),
            QtWarningMsg,
            QString::fromLatin1(":/icons/%1").arg(metaData->id())))
        {
            continue;
        }
        addEntry(entry.take());
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Close);
```

#### RANGE FOR STATEMENT 


```{c}
for (Type t : types) {
        result.append(description(t));
    }
```

