#### LAMBDA EXPRESSION 


```{c}
[this]() { _k_slotInsertChar(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotInsertColumnBefore();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_updateActions(false);
        }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph \\*with /some/\\*/ formatted/ text.\\n$"));
```

#### AUTO 


```{c}
auto hl = new KSyntaxHighlighting::SyntaxHighlighter(document());
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
                                        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><strong>Paragraph with some formatted</strong>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph \\*/with/ some formatted\\* text.\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : mimetypes) {
            lstMimeTypes << resolveAlias(QString::fromUtf8(ba));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotInsertTable();
        }
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto imageFormat = fragmentFormat.toImageFormat();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &range : d->spellCheckRanges) {
        if (range.offset <= start && range.end() >= start + count) {
            auto f = format(start);
            f.setFontUnderline(true);
            f.setUnderlineStyle(QTextCharFormat::SpellCheckUnderline);
            f.setUnderlineColor(d->misspelledColor);
            setFormat(start, count, f);
            return;
        }
    }
```

#### AUTO 


```{c}
auto *languageAction = static_cast<QAction *>(QObject::sender());
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:29pt;\"><strong>Foo</strong></span></p>\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotMergeCell();
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotRemoveRowBelow();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &engine : lst) {
        mAvailableEngine->addItem(engine, engine);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val) {
            _k_slotImageWidthChanged(val);
        }
```

#### AUTO 


```{c}
auto elementsToClose = getElementsToClose(it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : str) {
        out.push_back(normalize(c));
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<p>&nbsp;<p>&nbsp;<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar<img src=\"imagename\" width=\"100\" height=\"120\" /></p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        generatedHtml->setHtml(htmlEdit->toPlainText());
        generatedHtmlFromTextEdit->setPlainText(generatedHtml->document()->toHtml());

        auto hb = new KPIMTextEdit::TextHTMLBuilder();
        auto md = new KPIMTextEdit::MarkupDirector(hb);
        md->processDocument(generatedHtml->document());
        auto result = hb->getResult();
        delete md;
        delete hb;
        generatedHtmlFromGrantlee->setPlainText(result);
        generatedHtmlFromGrantleeToTextEdit->setHtml(result);
    }
```

#### AUTO 


```{c}
auto columnSpan = tableCell.columnSpan();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<EmbeddedImage> &image : imageList) {
        const QString newImageName = QLatin1String("cid:") + image->contentID;
        QByteArray quote("\"");
        result.replace(QByteArray(quote + image->imageName.toLocal8Bit() + quote), QByteArray(quote + newImageName.toLocal8Bit() + quote));
    }
```

#### AUTO 


```{c}
auto it = block.begin();
```

#### AUTO 


```{c}
auto paraClosed = false;
```

#### AUTO 


```{c}
auto rowSpan = tableCell.rowSpan();
```

#### AUTO 


```{c}
auto *editor = new KPIMTextEdit::RichTextEditorWidget(richtextcomposerwidget);
```

#### AUTO 


```{c}
auto *w = new KPIMTextEdit::RichTextEditorWidget();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotRemoveColumnAfter();}
```

#### AUTO 


```{c}
auto w = new KPIMTextEdit::TextToSpeechConfigDialog;
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">phone: +123456 7890<br />mail: some@mail.com</p>\n<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:7pt;\">small text</span></p>\n<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"color:#aaaaff;\">some colored text<br />some colored text</span></p>\n<br />\n$"));
```

#### AUTO 


```{c}
const auto fontUnderline = fragmentFormat.fontUnderline();
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::RestoreDefaults, this);
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotInsertColumnAfter();
        }
```

#### AUTO 


```{c}
auto *layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTextImageFormat &imageFormat : imageFormats) {
        if (!seenImageNames.contains(imageFormat.name())) {
            QVariant resourceData = d->composer->document()->resource(QTextDocument::ImageResource,
                                                                      QUrl(imageFormat.name()));
            QImage image = qvariant_cast<QImage>(resourceData);
            QString name = imageFormat.name();
            ImageWithNamePtr newImage(new ImageWithName);
            newImage->image = image;
            newImage->name = name;
            retImages.append(newImage);
            seenImageNames.append(imageFormat.name());
        }
    }
```

#### AUTO 


```{c}
auto *generatedPlainTextFromGrantleeToTextEdit = new QTextEdit(this);
```

#### AUTO 


```{c}
auto hb = new KPIMTextEdit::TextHTMLBuilder();
```

#### AUTO 


```{c}
auto pair = processBlockGroup(it, block, group);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto stopButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("stopbutton"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">phone: \\+123456 7890<br />mail: some@mail.com</p>\n<br /><p "
                       "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:7pt;\">small text</span></p>\n<br /><p "
                       "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"color:\\#aaaaff;\">some colored text<br />some "
                       "colored text</span></p>\n<br />$"));
```

#### AUTO 


```{c}
auto *interface = new KPIMTextEdit::AbstractTextToSpeechInterface(this);
```

#### AUTO 


```{c}
auto *optionsBtn = new QPushButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _k_slotInsertChar();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : richAction) {
        act->setEnabled(state);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotRemoveRowAbove();}
```

#### RANGE FOR STATEMENT 


```{c}
for (uint emoji : lstEmoji) {
            const QString str = QString::fromUcs4(&emoji, 1);
            new KPIMTextEdit::EmoticonTextEditItem(str, w);
        }
```

#### AUTO 


```{c}
auto q = n / c[i];
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<p>&nbsp;<p>&nbsp;<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### AUTO 


```{c}
auto *closeButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("close-button"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionCollection->actions()) {
        if (!actionNoRichText.contains(act->objectName())) {
            QVERIFY(!act->isEnabled());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotSplitCell();
    }
```

#### AUTO 


```{c}
auto w = new KPIMTextEdit::EmoticonUnicodeTab(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotInsertRowAbove();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : qAsConst(d->richTextActionList)) {
        action->setEnabled(enabled);
    }
```

#### AUTO 


```{c}
const auto list = qobject_cast<QTextList *>(blockGroup);
```

#### AUTO 


```{c}
auto table = qobject_cast<QTextTable *>(frame);
```

#### AUTO 


```{c}
const auto fontStrikeout = fragmentFormat.fontStrikeOut();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph with some formatted nested text.\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTextImageFormat &imageFormat : imageFormats) {
        if (!seenImageNames.contains(imageFormat.name())) {
            QVariant resourceData = d->composer->document()->resource(QTextDocument::ImageResource,
                                    QUrl(imageFormat.name()));
            QImage image = qvariant_cast<QImage>(resourceData);
            QString name = imageFormat.name();
            ImageWithNamePtr newImage(new ImageWithName);
            newImage->image = image;
            newImage->name = name;
            retImages.append(newImage);
            seenImageNames.append(imageFormat.name());
        }
    }
```

#### AUTO 


```{c}
auto anim = new QPropertyAnimation(this, "slideHeight", this);
```

#### AUTO 


```{c}
auto content = new QLineEdit(container);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotTableCellFormat();}
```

#### AUTO 


```{c}
auto *voice = textToSpeechConfigWidget.findChild<QComboBox *>(QStringLiteral("voice"));
```

#### AUTO 


```{c}
const auto category = sourceIndex.data(EmoticonUnicodeModel::Category).value<EmoticonUnicodeUtils::EmoticonStruct::EmoticonType>();
```

#### AUTO 


```{c}
auto directionGroup = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : richTextActionList()) {
        act->setEnabled(state);
    }
```

#### AUTO 


```{c}
const auto result = hb->getResult();
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
            _k_slotEnabledButtonChanged(b);
        }
```

#### AUTO 


```{c}
auto w = new TextToSpeechGui;
```

#### AUTO 


```{c}
auto *generatedHtmlFromTextEdit = new QTextEdit(this);
```

#### AUTO 


```{c}
const auto fontForeground = fragmentFormat.foreground();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &emoji : lst) {
        new KPIMTextEdit::EmoticonTextEditItem(emoji, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageWithNamePtr &normalImage : normalImages) {
        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        normalImage->image.save(&buffer, "PNG");

        qsrand(QDateTime::currentDateTimeUtc().toTime_t() + qHash(normalImage->name));
        QSharedPointer<EmbeddedImage> embeddedImage(new EmbeddedImage());
        retImages.append(embeddedImage);
        embeddedImage->image = KCodecs::Codec::codecForName("base64")->encode(buffer.buffer());
        embeddedImage->imageName = normalImage->name;
        embeddedImage->contentID = QStringLiteral("%1@KDE").arg(qrand());
    }
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto spellDialog = new Sonnet::Dialog(backgroundSpellCheck, force ? this : nullptr);
```

#### AUTO 


```{c}
auto highlighter = new KPIMTextEdit::RichTextComposerEmailQuoteHighlighter(this);
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageWithNamePtr &normalImage : normalImages) {
        QBuffer buffer;
        buffer.open(QIODevice::WriteOnly);
        normalImage->image.save(&buffer, "PNG");

        qsrand(QDateTime::currentDateTimeUtc().toSecsSinceEpoch() + qHash(normalImage->name));
        QSharedPointer<EmbeddedImage> embeddedImage(new EmbeddedImage());
        retImages.append(embeddedImage);
        embeddedImage->image = KCodecs::Codec::codecForName("base64")->encode(buffer.buffer());
        embeddedImage->imageName = normalImage->name;
        embeddedImage->contentID = QStringLiteral("%1@KDE").arg(qrand());
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto anchorNames = fragmentFormat.anchorNames();
```

#### AUTO 


```{c}
auto vbox = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &voice : lst) {
        mVoice->addItem(voice, voice);
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <em><strong>with</strong>&nbsp;some "
                               "formatted</em>&nbsp;text.</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotTableFormat();
        }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
                                        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong>with some formatted text.</strong></p>\\n$"));
```

#### AUTO 


```{c}
auto group = qobject_cast<QTextBlockGroup *>(object);
```

#### AUTO 


```{c}
auto ac = new KActionCollection(richtextcomposerwidget);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">phone: \\+123456 7890<br />mail: some@mail.com</p>\n<br /><p "
                       "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:7pt;\">small text</span></p>$"));
```

#### AUTO 


```{c}
const auto superscript = (vAlign == QTextCharFormat::AlignSuperScript);
```

#### AUTO 


```{c}
auto *e = static_cast<QKeyEvent *>(ev);
```

#### AUTO 


```{c}
auto *content = new QLineEdit(container);
```

#### AUTO 


```{c}
auto *action = new QWidgetAction(emoticonMenu);
```

#### AUTO 


```{c}
auto mainLayout = w.findChild<QVBoxLayout *>(QStringLiteral("mainLayout"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph /\\*with\\* some formatted/ text.\\n$"));
```

#### AUTO 


```{c}
auto e = static_cast<QKeyEvent *>(event);
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<br /><br /><p "
                                          "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar<img src=\"imagename\" /></p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_updateActions(false);
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Foo\\n\\n\\nBar\\n$"));
```

#### AUTO 


```{c}
auto *selector = new EmoticonListWidgetSelector(this);
```

#### AUTO 


```{c}
auto *backgroundSpellCheck = new Sonnet::BackgroundChecker;
```

#### AUTO 


```{c}
auto htmlEdit = new QTextEdit(this);
```

#### AUTO 


```{c}
auto mUnicodeTab = w.findChild<KPIMTextEdit::EmoticonUnicodeTab *>(QStringLiteral("mUnicodeTab"));
```

#### AUTO 


```{c}
auto *w = new KPIMTextEdit::EmoticonUnicodeTab(this);
```

#### AUTO 


```{c}
auto *w = new TextToSpeechGui;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotRemoveRowBelow();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : composer.actions()) {
        QCOMPARE(act->isEnabled(), enableAction);
    }
```

#### AUTO 


```{c}
auto *stopButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("stopbutton"));
```

#### AUTO 


```{c}
const auto &range
```

#### AUTO 


```{c}
auto fmt = block.blockFormat();
```

#### AUTO 


```{c}
auto *itemEmoticon = static_cast<EmoticonTextEditItem *>(item);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Some formatted text.\\n$"));
```

#### AUTO 


```{c}
auto ref = addReference(src);
```

#### AUTO 


```{c}
auto textObject = doc->objectForFormat(charFormat);
```

#### LAMBDA EXPRESSION 


```{c}
[this, nextBlock] {
                rehighlightBlock(nextBlock);
            }
```

#### AUTO 


```{c}
auto *generatedHtmlFromGrantlee = new QTextEdit(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotRemoveColumnBefore();}
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<hr />\\n<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### AUTO 


```{c}
auto *grid = new QGridLayout;
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
                                        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Some <span "
                                        "style=\"(color:#ff0000|background-color:#00ff00);\"><span "
                                        "style=\"(color:#ff0000|background-color:#00ff00);\">formatted</span></"
                                        "span>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong>with some "
                               "<em>formatted</em></strong>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto widget = new KPIMTextEdit::TextToSpeechConfigWidget(this);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotRemoveCellContents();}
```

#### AUTO 


```{c}
auto volume = textToSpeechWidget.findChild<QSlider *>(QStringLiteral("volumeslider"));
```

#### AUTO 


```{c}
auto pmd = new KPIMTextEdit::MarkupDirector(pb);
```

#### AUTO 


```{c}
auto allEmojisView = new EmoticonListView(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ImageWithNamePtr &normalImage : normalImages) {
        retImages.append(createEmbeddedImage(normalImage->image, normalImage->name));
    }
```

#### AUTO 


```{c}
auto *volume = textToSpeechWidget.findChild<QSlider *>(QStringLiteral("volumeslider"));
```

#### AUTO 


```{c}
auto availableEngine = textToSpeechConfigWidget.findChild<QComboBox *>(QStringLiteral("engine"));
```

#### AUTO 


```{c}
auto *hbox = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto *generatedHtmlFromGrantleeToTextEdit = new QTextEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : std::as_const(d->richTextActionList)) {
        action->setEnabled(enabled);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotRemoveColumnBefore();
    }
```

#### AUTO 


```{c}
auto *volume = textToSpeechConfigWidget.findChild<QSlider *>(QStringLiteral("volume"));
```

#### AUTO 


```{c}
auto *htmlEdit = new QTextEdit(this);
```

#### AUTO 


```{c}
auto *composer = w.findChild<KPIMTextEdit::RichTextComposer *>(QStringLiteral("richtextcomposer"));
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (int tag : elementsToOpenList) {
        switch (tag) {
        case Strong:
            m_builder->beginStrong();
            break;
        case Emph:
            m_builder->beginEmph();
            break;
        case Underline:
            m_builder->beginUnderline();
            break;
        case StrikeOut:
            m_builder->beginStrikeout();
            break;
        case SpanFontPointSize:
            m_builder->beginFontPointSize(fragmentFormat.font().pointSize());
            d->m_openFontPointSize = fragmentFormat.font().pointSize();
            break;
        case SpanFontFamily:
            m_builder->beginFontFamily(fragmentFormat.fontFamily());
            d->m_openFontFamily = fragmentFormat.fontFamily();
            break;
        case SpanBackground:
            m_builder->beginBackground(fragmentFormat.background());
            d->m_openBackground = fragmentFormat.background();
            break;
        case SpanForeground:
            m_builder->beginForeground(fragmentFormat.foreground());
            d->m_openForeground = fragmentFormat.foreground();
            break;
        case Anchor: {
            // TODO: Multiple anchor names here.
            auto anchorNames = fragmentFormat.anchorNames();
            if (!anchorNames.isEmpty()) {
                while (!anchorNames.isEmpty()) {
                    auto n = anchorNames.last();
                    anchorNames.removeLast();
                    if (anchorNames.isEmpty()) {
                        // Doesn't matter if anchorHref is empty.
                        m_builder->beginAnchor(fragmentFormat.anchorHref(), n);
                        break;
                    } else {
                        // Empty <a> tags allow multiple names for the same
                        // section.
                        m_builder->beginAnchor(QString(), n);
                        m_builder->endAnchor();
                    }
                }
            } else {
                m_builder->beginAnchor(fragmentFormat.anchorHref());
            }
            d->m_openAnchorHref = fragmentFormat.anchorHref();
            break;
        }
        case SuperScript:
            m_builder->beginSuperscript();
            break;
        case SubScript:
            m_builder->beginSubscript();
            break;
        default:
            break;
        }
        d->m_openElements.append(tag);
        d->m_elementsToOpen.remove(tag);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotInsertRowBelow();
    }
```

#### AUTO 


```{c}
auto act = new QAction(i18n("Speech text"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[=]{
        generatedHtml->setHtml(htmlEdit->toPlainText());

        auto hb = new KPIMTextEdit::PlainTextMarkupBuilder();
        auto md = new KPIMTextEdit::MarkupDirector(hb);
        md->processDocument(generatedHtml->document());
        auto result = hb->getResult();
        delete md;
        delete hb;
        generatedPlainTextFromGrantleeToTextEdit->setPlainText(result);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val) {
                _k_slotImageWidthChanged(val);
            }
```

#### AUTO 


```{c}
auto i = 12;
```

#### AUTO 


```{c}
auto *generatedHtml = new QTextEdit(this);
```

#### AUTO 


```{c}
auto closeBtn = new QToolButton(this);
```

#### AUTO 


```{c}
auto itemEmoticon = static_cast<EmoticonTextEditItem *>(item);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph \\*with /some/\\*/ formatted/ text.\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph with an inline <img "
                               "src=\"http://kde.org/img/kde41.png\" />&nbsp;image.</p>\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">phone: +123456 7890<br />mail: some@mail.com</p>\n<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:7pt;\">small text</span></p>\n$"));
```

#### AUTO 


```{c}
auto languagesGroup = new QActionGroup(languagesMenu);
```

#### RANGE FOR STATEMENT 


```{c}
for (int tag : elementsToClose) {
                    if (openingOrder.remove(tag)) {
                        sortedOpenedElements.prepend(tag);
                    }
                }
```

#### AUTO 


```{c}
auto *hlighter = qobject_cast<KPIMTextEdit::RichTextComposerEmailQuoteHighlighter *>(highlighter());
```

#### AUTO 


```{c}
auto fragment = it.fragment();
```

#### AUTO 


```{c}
auto volume = new QLabel(i18n("Volume:"), this);
```

#### AUTO 


```{c}
auto *optionsMenu = new QMenu(optionsBtn);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph /with some \\*formatted\\*/ text.\\n$"));
```

#### AUTO 


```{c}
auto *closeBtn = new QToolButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotInsertRowAbove();
        }
```

#### AUTO 


```{c}
auto charFormat = fragment.charFormat();
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <em>with some "
                                          "<strong>formatted</strong></em>&nbsp;text.</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotRemoveRowAbove();
        }
```

#### AUTO 


```{c}
auto sep = new KSeparator(q);
```

#### AUTO 


```{c}
auto label = new QLabel(i18n("Insert HTML tags and texts:"));
```

#### AUTO 


```{c}
auto *playPauseButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("playpausebutton"));
```

#### AUTO 


```{c}
auto close = new QToolButton(this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <em>with some "
                               "<strong>formatted</strong></em>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto lastBlock = _block;
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"background-color:#ffff00;\">Sss</span></p>\n<p "
                       "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"background-color:#ffff00;\">sss</span></p>\n"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Some <span style=\"color:#ff0000;\">formatted</span>&nbsp;"
                               "text.</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotSplitCell();
        }
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Vertical Alignment:"));
```

#### AUTO 


```{c}
const auto n = c.toCaseFolded();
```

#### AUTO 


```{c}
auto editorWidget = new KPIMTextEdit::PlainTextEditorWidget(editor);
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\">Foo</p>\\n<p>&nbsp;<p>&nbsp;</p>\\n<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotInsertColumnBefore();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) { _k_slotUrlChanged(str);}
```

#### AUTO 


```{c}
auto *pmd = new KPIMTextEdit::MarkupDirector(pb);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : qAsConst(d->ignoreSpellCheckingWords)) {
            backgroundSpellCheck->speller().addToSession(word);
        }
```

#### AUTO 


```{c}
auto block = _block;
```

#### AUTO 


```{c}
auto *gridLayout = new QGridLayout;
```

#### AUTO 


```{c}
auto emoticonUnicodeProxyModel = new EmoticonUnicodeProxyModel(this);
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong>with some "
                                          "<em>formatted</em></strong>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto *hl = new KSyntaxHighlighting::SyntaxHighlighter(document());
```

#### AUTO 


```{c}
const auto fontFamily = fragmentFormat.fontFamily();
```

#### AUTO 


```{c}
auto *interface = new KPIMTextEdit::AbstractTextToSpeechConfigInterface(this);
```

#### AUTO 


```{c}
auto w = new KPIMTextEdit::TextToSpeechWidget;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            _k_slotTextChanged();
        }
```

#### AUTO 


```{c}
auto skipButton = new QPushButton(i18n("Skip"));
```

#### LAMBDA EXPRESSION 


```{c}
[this, nextBlock] { rehighlightBlock(nextBlock); }
```

#### AUTO 


```{c}
auto actionCollection = new KActionCollection(&composerActions);
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\"><span style=\"color:#aaaaff;\">some "
                                          "colored text<br />some colored text</span></p>\n$"));
```

#### AUTO 


```{c}
auto emojisView = new EmoticonListView(this);
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto kev = static_cast<QKeyEvent *>(e);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong>with <em>some</em></strong><em>&nbsp;"
                       "formatted</em>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto lay = new QHBoxLayout;
```

#### AUTO 


```{c}
auto composer = w.findChild<KPIMTextEdit::RichTextComposer *>(QStringLiteral("richtextcomposer"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotSplitCell();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : std::as_const(d->ignoreSpellCheckingWords)) {
            _highlighter->ignoreWord(word);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) { _k_slotKeepOriginalSizeClicked(b);}
```

#### AUTO 


```{c}
auto *spellDialog = new Sonnet::Dialog(backgroundSpellCheck, force ? this : nullptr);
```

#### AUTO 


```{c}
auto interface = new KPIMTextEdit::AbstractTextToSpeechConfigInterface(this);
```

#### AUTO 


```{c}
auto container = new SlideContainer(this);
```

#### AUTO 


```{c}
auto frame = start.currentFrame();
```

#### AUTO 


```{c}
auto configureButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("configurebutton"));
```

#### AUTO 


```{c}
auto *widget = new KPIMTextEdit::TextToSpeechConfigWidget(this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">phone: \\+123456 7890<br />mail: some@mail.com</p>\n<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:7pt;\">small text</span></p>\n<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"color:\\#aaaaff;\">some colored text<br />some colored text</span></p>\n<br />$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph \\*with some formatted text.\\*\\n$"));
```

#### AUTO 


```{c}
auto cellWidth = colLengths.at(column);
```

#### AUTO 


```{c}
auto *directionGroup = new QActionGroup(this);
```

#### AUTO 


```{c}
auto selector = new EmoticonListWidgetSelector(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotRemoveColumnAfter();
        }
```

#### AUTO 


```{c}
auto gotolinebutton = edit.findChild<QPushButton *>(QStringLiteral("gotoline"));
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph with an inline <img "
                                          "src=\"http://kde.org/img/kde41.png\" />&nbsp;image.</p>\\n$"));
```

#### AUTO 


```{c}
auto line = edit.findChild<QSpinBox *>(QStringLiteral("line"));
```

#### AUTO 


```{c}
auto editorWidget = new RichTextEditorWidget(d->richTextComposer, this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p>&nbsp;<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">&nbsp;&nbsp;&nbsp; foo</p>\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (int tag : qAsConst(openingOrder)) {
                sortedOpenedElements.prepend(tag);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                _k_slotTextChanged();
            }
```

#### AUTO 


```{c}
const auto fragmentFormat = fragment.charFormat();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotTableFormat();
    }
```

#### AUTO 


```{c}
auto object = block.document()->objectForFormat(fmt);
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Some <span "
                                          "style=\"(color:#ff0000|background-color:#00ff00);\"><span "
                                          "style=\"(color:#ff0000|background-color:#00ff00);\">formatted</span></"
                                          "span>&nbsp;text.</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &index) {
        const QString emojiStr = index.data().toString();
        Q_EMIT emojiItemSelected(emojiStr);
    }
```

#### AUTO 


```{c}
auto lay = new QHBoxLayout(this);
```

#### AUTO 


```{c}
auto hlighter = qobject_cast<KPIMTextEdit::RichTextComposerEmailQuoteHighlighter *>(highlighter());
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<br /><br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar<img src=\"imagename\" width=\"100\" height=\"120\" /></p>\\n$"));
```

#### AUTO 


```{c}
auto doc = new QTextDocument(this);
```

#### AUTO 


```{c}
const auto anchorHref = fragmentFormat.anchorHref();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& emoji : lst) {
        new KPIMTextEdit::EmoticonTextEditItem(emoji, this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTextImageFormat &imageFormat : imageFormats) {
        const QString name = imageFormat.name();
        if (!seenImageNames.contains(name)) {
            QVariant resourceData = d->composer->document()->resource(QTextDocument::ImageResource, QUrl(name));
            QImage image = qvariant_cast<QImage>(resourceData);

            ImageWithNamePtr newImage(new ImageWithName);
            newImage->image = image;
            newImage->name = name;
            retImages.append(newImage);
            seenImageNames.append(name);
        }
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:29pt;\"><strong>Foo</strong></span></p>\n$"));
```

#### AUTO 


```{c}
auto *w = new KPIMTextEdit::PlainTextEditorWidget();
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto tableWidth = format.width();
```

#### AUTO 


```{c}
auto *buttonBox = spellDialog->findChild<QDialogButtonBox *>();
```

#### AUTO 


```{c}
auto rate = textToSpeechConfigWidget.findChild<QSlider *>(QStringLiteral("rate"));
```

#### AUTO 


```{c}
auto removeMenu = new KActionMenu(i18n("Delete"), this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <span style=\"background-color:#00ff00;\">with some <span "
        "style=\"color:#ff0000;\">formatted</span>&nbsp;nested</span>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto blockFormat = block.blockFormat();
```

#### AUTO 


```{c}
const auto textStr = fragment.text();
```

#### AUTO 


```{c}
auto backgroundSpellCheck = new Sonnet::BackgroundChecker;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotMergeCell();}
```

#### AUTO 


```{c}
auto pb = new KPIMTextEdit::PlainTextMarkupBuilder();
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Go to Line:"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
            _k_slotUrlChanged(str);
        }
```

#### AUTO 


```{c}
auto voice = textToSpeechConfigWidget.findChild<QComboBox *>(QStringLiteral("voice"));
```

#### AUTO 


```{c}
auto *alignmentGroup = new QActionGroup(this);
```

#### AUTO 


```{c}
auto *document = new QTextDocument(this);
```

#### AUTO 


```{c}
auto *languagesGroup = new QActionGroup(languagesMenu);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotMergeCell();
    }
```

#### AUTO 


```{c}
auto mFindPrevBtn = w.findChild<QPushButton *>(QStringLiteral("mFindPrevBtn"));
```

#### AUTO 


```{c}
auto f = format(start);
```

#### AUTO 


```{c}
const auto fontBackground = fragmentFormat.background();
```

#### AUTO 


```{c}
auto action = new QWidgetAction(emoticonMenu);
```

#### AUTO 


```{c}
auto spellDialog = new Sonnet::Dialog(backgroundSpellCheck, nullptr);
```

#### AUTO 


```{c}
auto interface = new KPIMTextEdit::AbstractTextToSpeechInterface(this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^\\*Paragraph with some formatted\\* text.\\n$"));
```

#### AUTO 


```{c}
auto *gotolinebutton = edit.findChild<QPushButton *>(QStringLiteral("gotoline"));
```

#### AUTO 


```{c}
auto optionsBtn = w.findChild<QPushButton *>(QStringLiteral("optionsBtn"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : std::as_const(d->ignoreSpellCheckingWords)) {
            backgroundSpellCheck->speller().addToSession(word);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                _k_slotInsertChar();
            }
```

#### AUTO 


```{c}
auto alignmentGroup = new QActionGroup(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QSharedPointer<EmbeddedImage> &image : imageList) {
        const QString newImageName = QLatin1String("cid:") + image->contentID;
        QByteArray quote("\"");
        result.replace(QByteArray(quote + image->imageName.toLocal8Bit() + quote),
                       QByteArray(quote + newImageName.toLocal8Bit() + quote));
    }
```

#### AUTO 


```{c}
auto document = view->document();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotMergeSelectedCells();
        }
```

#### AUTO 


```{c}
auto sl = fragment.text().split(QChar(QChar::LineSeparator));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph \\*/with/ some formatted\\* text.\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong><em>with</em>&nbsp;some "
                               "formatted</strong>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<br /><br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### AUTO 


```{c}
auto sep = new KSeparator;
```

#### AUTO 


```{c}
const auto fontItalic = fragmentFormat.fontItalic();
```

#### AUTO 


```{c}
const auto fontPointSize = fragmentFormat.font().pointSize();
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotInsertRowBelow();
        }
```

#### AUTO 


```{c}
const auto style = list->format().style();
```

#### AUTO 


```{c}
auto *pb = new KPIMTextEdit::PlainTextMarkupBuilder();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<br /><br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar<img src=\"imagename\" /></p>\\n$"));
```

#### AUTO 


```{c}
auto grid = new QGridLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            slotSearchText();
        }
```

#### AUTO 


```{c}
auto tag = d->m_openElements.last();
```

#### AUTO 


```{c}
auto mReplaceBtn = w.findChild<QPushButton *>(QStringLiteral("mReplaceBtn"));
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\">Foo</p>\\n<p>&nbsp;<p>&nbsp;</p>\\n<p "
                                          "style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### AUTO 


```{c}
auto mSearchUnicodeLineEdit = w.findChild<QLineEdit *>(QStringLiteral("mSearchUnicodeLineEdit"));
```

#### AUTO 


```{c}
auto page = new QWidget(q);
```

#### AUTO 


```{c}
auto md = new KPIMTextEdit::MarkupDirector(hb);
```

#### AUTO 


```{c}
auto obj = block.document()->objectForFormat(block.blockFormat());
```

#### AUTO 


```{c}
auto n = item;
```

#### LAMBDA EXPRESSION 


```{c}
[=] {
        generatedHtml->setHtml(htmlEdit->toPlainText());

        auto hb = new KPIMTextEdit::PlainTextMarkupBuilder();
        auto md = new KPIMTextEdit::MarkupDirector(hb);
        md->processDocument(generatedHtml->document());
        auto result = hb->getResult();
        delete md;
        delete hb;
        generatedPlainTextFromGrantleeToTextEdit->setPlainText(result);
    }
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong><em>with</em>&nbsp;some "
                                          "formatted</strong>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto e = static_cast<QKeyEvent *>(ev);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotInsertTable();}
```

#### AUTO 


```{c}
auto language = textToSpeechConfigWidget.findChild<QComboBox *>(QStringLiteral("language"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
            _k_slotKeepOriginalSizeClicked(b);
        }
```

#### AUTO 


```{c}
auto startDigit = i + (i + 3) / 4;
```

#### AUTO 


```{c}
auto style = static_cast<QTextListFormat::Style>(styleIndex);
```

#### AUTO 


```{c}
auto playPauseButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("playpausebutton"));
```

#### AUTO 


```{c}
auto lab = new QLabel(QStringLiteral("html text"), this);
```

#### AUTO 


```{c}
auto generatedPlainTextFromGrantleeToTextEdit = new QTextEdit(this);
```

#### AUTO 


```{c}
auto *configureButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("configurebutton"));
```

#### AUTO 


```{c}
auto closebutton = edit.findChild<QToolButton *>(QStringLiteral("closebutton"));
```

#### AUTO 


```{c}
const auto &unicodeEmoti = mEmoticonList.at(index.row());
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("Find text", "F&ind:"), this);
```

#### AUTO 


```{c}
auto romanSymbols = QStringLiteral("iiivixxxlxcccdcmmmm");
```

#### AUTO 


```{c}
auto document = new QTextDocument(this);
```

#### AUTO 


```{c}
auto result = hb->getResult();
```

#### RANGE FOR STATEMENT 


```{c}
for (int tag : std::as_const(openingOrder)) {
                sortedOpenedElements.prepend(tag);
            }
```

#### AUTO 


```{c}
auto w = new TextToSpeechConfigGui;
```

#### RANGE FOR STATEMENT 


```{c}
for (uint emoji : lstEmoji) {
            str += QString::fromUcs4(&emoji, 1);
        }
```

#### AUTO 


```{c}
const auto iconSize = style()->pixelMetric(QStyle::PM_SmallIconSize);
```

#### AUTO 


```{c}
auto mReplace = w.findChild<QLineEdit *>(QStringLiteral("mReplace"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionCollection->actions()) {
        if (!actionNoRichText.contains(act->objectName())) {
            QVERIFY(act->isEnabled());
        }
    }
```

#### AUTO 


```{c}
auto richtextcomposerwidget = new KPIMTextEdit::RichTextComposer;
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
                                        "^Paragraph with an inline \\[1\\] image.\\n\\n--------\\n\\[1\\] "
                                        "http://kde.org/img/kde41.png\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph /\\*with\\* some formatted/ text.\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : mimetypes) {
            if (!filter.isEmpty()) {
                filter += QLatin1Char('\n');
            }
            filter += QStringLiteral("*.%1").arg(QString::fromLatin1(ba));
        }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<br /><br /><p "
        "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar<img src=\"imagename\" width=\"100\" height=\"120\" /></p>\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionCollection->actions()) {
        const QString actionName = act->objectName();
        if (!actionNoRichText.contains(actionName)) {
            const bool hasActionName = lst.contains(actionName);
            if (!hasActionName) {
                qDebug() << " actionName " << actionName;
            }
            QVERIFY(hasActionName);
        }
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong>with some formatted text.</strong></p>\\n$"));
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Image Location:"));
```

#### AUTO 


```{c}
auto *inButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto insertMenu = new KActionMenu(i18n("Insert"), this);
```

#### AUTO 


```{c}
auto languagesMenu = new QMenu(i18n("Spell Checking Language"), popup);
```

#### LAMBDA EXPRESSION 


```{c}
[=]{
        generatedHtml->setHtml(htmlEdit->toPlainText());
        generatedHtmlFromTextEdit->setPlainText(generatedHtml->document()->toHtml());

        auto hb = new KPIMTextEdit::TextHTMLBuilder();
        auto md = new KPIMTextEdit::MarkupDirector(hb);
        md->processDocument(generatedHtml->document());
        auto result = hb->getResult();
        delete md;
        delete hb;
        generatedHtmlFromGrantlee->setPlainText(result);
        generatedHtmlFromGrantleeToTextEdit->setHtml(result);
    }
```

#### AUTO 


```{c}
auto *w = new KPIMTextEdit::TextToSpeechConfigDialog;
```

#### AUTO 


```{c}
auto recentEmojisView = new EmoticonRecentListView(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotTableCellFormat();
        }
```

#### AUTO 


```{c}
auto w = new KPIMTextEdit::PlainTextEditorWidget();
```

#### AUTO 


```{c}
const auto charFormat = fragment.charFormat();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        mEmoticonUnicodeRecentProxyModel->setUsedIdentifier(QStringList());
    }
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto generatedHtmlFromGrantleeToTextEdit = new QTextEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPIMTextEdit::Rule &rule : qAsConst(d->rules)) {
        const QRegularExpression expression(rule.pattern);
        if (!expression.isValid()) {
            const QString errorString = expression.errorString();
            qCDebug(KPIMTEXTEDIT_LOG) << "expression is invalid, pattern:" << rule.pattern << " error :" << errorString;
        }

        QRegularExpressionMatch match = expression.match(text);

        int index = match.capturedStart();
        while (index >= 0 && match.hasMatch()) {
            setFormat(index, match.capturedLength(), rule.format);
            match = expression.match(text, index + match.capturedLength());
            index = match.capturedStart();
        }
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"background-color:#ffff00;\">Sss</span></p>\n<p "
                       "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"background-color:#ff0000;\">sss</span></p>\n"));
```

#### AUTO 


```{c}
const auto fontWeight = fragmentFormat.fontWeight();
```

#### AUTO 


```{c}
auto hbox = new QHBoxLayout;
```

#### AUTO 


```{c}
auto *layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto *spellDialog = new Sonnet::Dialog(backgroundSpellCheck, nullptr);
```

#### AUTO 


```{c}
auto *layout = new QFormLayout(this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">&nbsp;&nbsp;&nbsp; foo</p>\\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Some <span style=\"color:#ff0000;\">formatted</span>&nbsp;"
                       "text.</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
                _k_slotEnabledButtonChanged(b);
            }
```

#### AUTO 


```{c}
auto hb = new KPIMTextEdit::PlainTextMarkupBuilder();
```

#### AUTO 


```{c}
auto generatedHtml = new QTextEdit(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotInsertColumnAfter();
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph \\*with some formatted text.\\*\\n$"));
```

#### AUTO 


```{c}
auto md = new Grantlee::MarkupDirector(hb);
```

#### RANGE FOR STATEMENT 


```{c}
for (const EmoticonUnicodeUtils::EmoticonStruct &emoji : emoticons) {
            lst.append(emoji.emoticonCode);
        }
```

#### AUTO 


```{c}
auto *close = new QToolButton(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVoice &voice : voices) {
        lst << voice.name();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTextImageFormat &imageFormat : imageFormats) {
        const QString name = imageFormat.name();
        if (!seenImageNames.contains(name)) {
            QVariant resourceData = d->composer->document()->resource(QTextDocument::ImageResource,
                                                                      QUrl(name));
            QImage image = qvariant_cast<QImage>(resourceData);

            ImageWithNamePtr newImage(new ImageWithName);
            newImage->image = image;
            newImage->name = name;
            retImages.append(newImage);
            seenImageNames.append(name);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotInsertColumnBefore();}
```

#### AUTO 


```{c}
auto optionsMenu = new QMenu(optionsBtn);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^url: foo\\[1\\]\\nline1\\nline2\\n-- \\nbla\\n\n\\n\\n--------\\n\\[1\\] https://www.kde.org\\n$"));
```

#### AUTO 


```{c}
auto generatedHtmlFromGrantlee = new QTextEdit(this);
```

#### AUTO 


```{c}
auto *resizeEvent = static_cast<QResizeEvent *>(event);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (uint emoji : lst) {
        const QString str = QString::fromUcs4(&emoji, 1);
        new KPIMTextEdit::EmoticonTextEditItem(str, this);
    }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^\\*Paragraph with some formatted\\* text.\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (uint emoji : lstEmoji) {
            const QString str = QString::fromUcs4(&emoji, 1);
            new EmoticonTextEditItem(str, mListEmoticon);
        }
```

#### AUTO 


```{c}
auto outButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^Paragraph with an inline \\[1\\] image.\\n\\n--------\\n\\[1\\] "
                                          "http://kde.org/img/kde41.png\\n$"));
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<br /><br /><p "
                                          "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### AUTO 


```{c}
auto highlighter = new Sonnet::Highlighter(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotRemoveColumnAfter();
    }
```

#### AUTO 


```{c}
auto label = new QLabel(i18nc("Replace text", "Replace:"), this);
```

#### AUTO 


```{c}
const auto ref = addReference(src);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_updateActions(false);}
```

#### AUTO 


```{c}
auto *editorWidget = new RichTextEditorWidget(d->richTextComposer, this);
```

#### AUTO 


```{c}
const auto elementsToClose = getElementsToClose(it);
```

#### AUTO 


```{c}
auto *w = new TextToSpeechConfigGui;
```

#### AUTO 


```{c}
auto doc = new QTextDocument();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Paragraph \\*with some /formatted/\\* text.\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotInsertTable();
    }
```

#### AUTO 


```{c}
auto *outButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto block = start.currentBlock();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Foo\\n--------------------\\nBar\\n$"));
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotMergeSelectedCells();}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &word : qAsConst(d->ignoreSpellCheckingWords)) {
            _highlighter->ignoreWord(word);
        }
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <strong>with <em>some</em></strong><em>&nbsp;"
                               "formatted</em>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
const auto headerRowCount = format.headerRowCount();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph \\*with some /formatted/\\* text.\\n$"));
```

#### AUTO 


```{c}
auto *availableEngine = textToSpeechConfigWidget.findChild<QComboBox *>(QStringLiteral("engine"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotTableFormat();}
```

#### AUTO 


```{c}
auto mFindNextBtn = w.findChild<QPushButton *>(QStringLiteral("mFindNextBtn"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotInsertRowBelow();}
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph with some formatted nested text.\\n$"));
```

#### AUTO 


```{c}
auto *kev = static_cast<QKeyEvent * >(e);
```

#### AUTO 


```{c}
auto volume = textToSpeechConfigWidget.findChild<QSlider *>(QStringLiteral("volume"));
```

#### AUTO 


```{c}
auto *editorWidget = new KPIMTextEdit::PlainTextEditorWidget(editor);
```

#### AUTO 


```{c}
const auto colLengths = format.columnWidthConstraints();
```

#### AUTO 


```{c}
auto editor = new KPIMTextEdit::RichTextEditorWidget(richtextcomposerwidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotRemoveRowBelow();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotMergeSelectedCells();
    }
```

#### AUTO 


```{c}
auto blockAlignment = blockFormat.alignment();
```

#### AUTO 


```{c}
const auto vAlign = fragmentFormat.verticalAlignment();
```

#### AUTO 


```{c}
const auto c
```

#### AUTO 


```{c}
auto mReplaceAllBtn = w.findChild<QPushButton *>(QStringLiteral("mReplaceAllBtn"));
```

#### AUTO 


```{c}
auto *richtextcomposerwidget = new KPIMTextEdit::RichTextComposer;
```

#### AUTO 


```{c}
auto resizeEvent = static_cast<QResizeEvent *>(event);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotTableCellFormat();
    }
```

#### AUTO 


```{c}
const auto emoji = emoticons.constFirst();
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto *line = edit.findChild<QSpinBox *>(QStringLiteral("line"));
```

#### AUTO 


```{c}
auto generateHtmlFromQTextEditButton = new QPushButton(QStringLiteral("Generate HTML"), this);
```

#### AUTO 


```{c}
auto lab = new QLabel(i18n("Spacing:"));
```

#### AUTO 


```{c}
const auto format = table->format();
```

#### AUTO 


```{c}
const auto needsRehighlight = definition() != def;
```

#### AUTO 


```{c}
auto languageAction = static_cast<QAction *>(QObject::sender());
```

#### AUTO 


```{c}
auto image = qvariant_cast<QImage>(resourceData);
```

#### AUTO 


```{c}
const auto subscript = (vAlign == QTextCharFormat::AlignSubScript);
```

#### AUTO 


```{c}
auto *container = new SlideContainer(this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^Paragraph /with some \\*formatted\\*/ text.\\n$"));
```

#### AUTO 


```{c}
auto *rate = textToSpeechConfigWidget.findChild<QSlider *>(QStringLiteral("rate"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^Foo\\n--------------------\\nBar\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) { _k_slotEnabledButtonChanged(b); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotSearchText(); }
```

#### AUTO 


```{c}
auto closeButton = textToSpeechWidget.findChild<QToolButton *>(QStringLiteral("close-button"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotRemoveCellContents();
        }
```

#### AUTO 


```{c}
auto *pitch = textToSpeechConfigWidget.findChild<QSlider *>(QStringLiteral("pitch"));
```

#### AUTO 


```{c}
auto group = qobject_cast<QTextBlockGroup *>(obj);
```

#### AUTO 


```{c}
const auto nextBlock = currentBlock().next();
```

#### AUTO 


```{c}
auto index = 1;
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val) { _k_slotImageHeightChanged(val);}
```

#### AUTO 


```{c}
const auto blockAlignment = blockFormat.alignment();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\"><span style=\"color:#ffff00;\">BBBB</span></p>\n<p "
                       "style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\"><span style=\"color:#ffff00;\">AAA</span></p>\n"));
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {_k_slotTextChanged(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : richtextcomposerwidget->richTextActionList()) {
        bar.addAction(action);
    }
```

#### AUTO 


```{c}
auto *topLayout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, nextBlock] {
            rehighlightBlock(nextBlock);
        }
```

#### AUTO 


```{c}
const auto image = qvariant_cast<QImage>(source->imageData());
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val) {
                _k_slotImageHeightChanged(val);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        if (!d->blockClearUndoHtmlVersion && d->undoHtmlVersion.isValid() && (d->mode == RichTextComposer::Plain)) {
            if (toPlainText() != d->undoHtmlVersion.plainText) {
                d->undoHtmlVersion.clear();
            }
        }
    }
```

#### AUTO 


```{c}
const auto elementsToOpenList = getElementsToOpen(it);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral("^<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\" dir='rtl'>test</p>\n"));
```

#### AUTO 


```{c}
auto ret = d->m_text;
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(q);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:12;margin-bottom:12;margin-left:0;margin-right:0;\"><span style=\"color:#aaaaff;\">some colored text<br />some colored text</span></p>\n$"));
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
                                        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <span style=\"background-color:#00ff00;\">with some <span "
                                        "style=\"color:#ff0000;\">formatted</span>&nbsp;nested</span>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">&nbsp;&nbsp;&nbsp; foo</p>\\n$"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val) {
            _k_slotImageHeightChanged(val);
        }
```

#### AUTO 


```{c}
auto actionCollection = new KActionCollection(&composer);
```

#### AUTO 


```{c}
auto buttonBox = spellDialog->findChild<QDialogButtonBox *>();
```

#### AUTO 


```{c}
auto pitch = textToSpeechConfigWidget.findChild<QSlider *>(QStringLiteral("pitch"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray &ba : mimetypes) {
            const QString resolvedAlias = resolveAlias(QString::fromUtf8(ba));
            if (!resolvedAlias.isEmpty()) {
                lstMimeTypes << resolvedAlias;
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](int val) { _k_slotImageWidthChanged(val);}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotInsertColumnAfter();}
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">phone: \\+123456 7890<br />mail: some@mail.com</p>\n<br /><p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><span style=\"font-size:7pt;\">small text</span></p>$"));
```

#### AUTO 


```{c}
auto lay = new QVBoxLayout(page);
```

#### AUTO 


```{c}
auto *language = textToSpeechConfigWidget.findChild<QComboBox *>(QStringLiteral("language"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QLocale &locale : locales) {
        QVariant localeVariant(locale);
        addItem(QLocale::languageToString(locale.language()), localeVariant);
        if (locale.name() == current.name()) {
            setCurrentIndex(count() - 1);
        }
    }
```

#### AUTO 


```{c}
auto hbox = textToSpeechWidget.findChild<QHBoxLayout *>(QStringLiteral("hbox"));
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool b) {
                _k_slotKeepOriginalSizeClicked(b);
            }
```

#### AUTO 


```{c}
auto *closebutton = edit.findChild<QToolButton *>(QStringLiteral("closebutton"));
```

#### AUTO 


```{c}
auto n = anchorNames.last();
```

#### AUTO 


```{c}
auto itemNumber = d->currentListItemNumbers.last();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Paragraph <em><strong>with</strong>&nbsp;some "
                       "formatted</em>&nbsp;text.</p>\\n$"));
```

#### AUTO 


```{c}
auto *w = new KPIMTextEdit::TextToSpeechWidget;
```

#### AUTO 


```{c}
auto inButton = new QPushButton(this);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
        QStringLiteral("^<p>&nbsp;<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">&nbsp;&nbsp;&nbsp; foo</p>\\n$"));
```

#### AUTO 


```{c}
const auto blockFormat = block.blockFormat();
```

#### AUTO 


```{c}
auto generatedHtmlFromTextEdit = new QTextEdit(this);
```

#### AUTO 


```{c}
const auto imageFormat = charFormat.toImageFormat();
```

#### AUTO 


```{c}
auto remainingSize = elementsToClose.size();
```

#### AUTO 


```{c}
auto regex = QRegularExpression(QStringLiteral(
        "^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\"><strong>Paragraph with some formatted</strong>&nbsp;text.</p>\\n$"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Rule &rule : qAsConst(m_rules)) {
        const QRegularExpression expression(rule.pattern);
        if (!expression.isValid()) {
            const QString errorString = expression.errorString();
            qCDebug(KPIMTEXTEDIT_LOG) << "expression is invalid, pattern:" << rule.pattern << " error :" << errorString;
        }
        QRegularExpressionMatch match = expression.match(text);

        int index = match.capturedStart();
        while (index >= 0 && match.hasMatch()) {
            setFormat(index, match.capturedLength(), rule.format);
            match = expression.match(text, index + match.capturedLength());
            index = match.capturedStart();
        }
    }
```

#### AUTO 


```{c}
auto regex =
        QRegularExpression(QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<hr />\\n<p "
                                          "style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar</p>\\n$"));
```

#### AUTO 


```{c}
auto clearRecent = new QAction(i18n("Clear Recents"), &menu);
```

#### AUTO 


```{c}
auto elementsToClose = QSet<int>(openElement.begin(), openElement.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto c : str) {
        // case folding
        const auto n = c.toCaseFolded();

        // if the character has a canonical decomposition use that and skip the
        // combining diacritic markers following it
        // see https://en.wikipedia.org/wiki/Unicode_equivalence
        // see https://en.wikipedia.org/wiki/Combining_character
        if (n.decompositionTag() == QChar::Canonical) {
            out.push_back(n.decomposition().at(0));
        }
        // handle compatibility compositions such as ligatures
        // see https://en.wikipedia.org/wiki/Unicode_compatibility_characters
        else if (n.decompositionTag() == QChar::Compat && n.isLetter() && n.script() == QChar::Script_Latin) {
            out.append(n.decomposition());
        } else {
            out.push_back(n);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int tag : elementsToOpenList) {
        switch (tag) {
        case Strong:
            m_builder->beginStrong();
            break;
        case Emph:
            m_builder->beginEmph();
            break;
        case Underline:
            m_builder->beginUnderline();
            break;
        case StrikeOut:
            m_builder->beginStrikeout();
            break;
        case SpanFontPointSize:
            d->m_openFontPointSize = fragmentFormat.font().pointSize();
            m_builder->beginFontPointSize(d->m_openFontPointSize);
            break;
        case SpanFontFamily:
            d->m_openFontFamily = fragmentFormat.fontFamily();
            m_builder->beginFontFamily(d->m_openFontFamily);
            break;
        case SpanBackground:
            d->m_openBackground = fragmentFormat.background();
            m_builder->beginBackground(d->m_openBackground);
            break;
        case SpanForeground:
            d->m_openForeground = fragmentFormat.foreground();
            m_builder->beginForeground(d->m_openForeground);
            break;
        case Anchor: {
            // TODO: Multiple anchor names here.
            auto anchorNames = fragmentFormat.anchorNames();
            if (!anchorNames.isEmpty()) {
                while (!anchorNames.isEmpty()) {
                    auto n = anchorNames.last();
                    anchorNames.removeLast();
                    if (anchorNames.isEmpty()) {
                        // Doesn't matter if anchorHref is empty.
                        m_builder->beginAnchor(fragmentFormat.anchorHref(), n);
                        break;
                    } else {
                        // Empty <a> tags allow multiple names for the same
                        // section.
                        m_builder->beginAnchor(QString(), n);
                        m_builder->endAnchor();
                    }
                }
            } else {
                m_builder->beginAnchor(fragmentFormat.anchorHref());
            }
            d->m_openAnchorHref = fragmentFormat.anchorHref();
            break;
        }
        case SuperScript:
            m_builder->beginSuperscript();
            break;
        case SubScript:
            m_builder->beginSubscript();
            break;
        default:
            break;
        }
        d->m_openElements.append(tag);
        d->m_elementsToOpen.remove(tag);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *act : actionCollection->actions()) {
        const QString actionName = act->objectName();
        if (!actionNoRichText.contains(actionName)) {
            QVERIFY(lst.contains(actionName));
        }
    }
```

#### AUTO 


```{c}
auto layout = new QFormLayout(this);
```

#### AUTO 


```{c}
const auto prevBlock = currentBlock().previous();
```

#### AUTO 


```{c}
auto w = new KPIMTextEdit::RichTextEditorWidget();
```

#### AUTO 


```{c}
auto tableCell = table->cellAt(row, column);
```

#### AUTO 


```{c}
auto regex = QRegularExpression(
                QStringLiteral("^<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Foo</p>\\n<p>&nbsp;<p>&nbsp;<p style=\"margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;\">Bar<img src=\"imagename\" /></p>\\n$"));
```

#### AUTO 


```{c}
auto topLayout = new QVBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {d->_k_slotInsertRowAbove();}
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            d->_k_slotRemoveColumnBefore();
        }
```

#### AUTO 


```{c}
auto gridLayout = new QGridLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTextImageFormat &imageFormat : imageFormats) {
        const QString name = imageFormat.name();
        if (!seenImageNames.contains(name)) {
            QVariant resourceData = d->composer->document()->resource(QTextDocument::ImageResource, QUrl(name));
            auto image = qvariant_cast<QImage>(resourceData);

            ImageWithNamePtr newImage(new ImageWithName);
            newImage->image = image;
            newImage->name = name;
            retImages.append(newImage);
            seenImageNames.append(name);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotRemoveRowAbove();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        d->_k_slotRemoveCellContents();
    }
```

#### AUTO 


```{c}
auto optionsBtn = new QPushButton(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &str) {
                _k_slotUrlChanged(str);
            }
```

#### AUTO 


```{c}
auto lastIt = it;
```

