#### AUTO 


```{c}
const auto logicalNeighbors = piece->logicalNeighbors();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : qAsConst(m_interactors))
		interactor->updateScene();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& entry : std::as_const(m_entries))
		enabledProps << entry.property;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& entry : qAsConst(m_entries))
		enabledProps << entry.property;
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : std::as_const(m_interactors))
		if (interactor->isActive())
		{
			//fetch flags, and remove them to mark this interactor as processed
			EventContext context = interactorData.value(interactor);
			interactorData.remove(interactor);
			//send event, mark button as processed
			if ((unhandledButtons & context.triggeringButtons) || context.triggeringButtons == Qt::NoButton)
			{
				interactor->sendEvent(pEvent, context.flags);
				if (interactor->isActive())
					unhandledButtons &= ~context.triggeringButtons;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : pieces) {
		// Leave the new arrivals selected, connected and in a grid.
		scene->addPieceToList(piece);
		scene->addItem(piece);
		scene->addToGrid(piece);
		piece->setSelected(true);
		connect(piece, &Piece::moved,
			scene, &Scene::pieceMoved);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : m_pieces)
		result |= piece->sceneBareBoundingRect();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QByteArray& modifierString : modifierStrings)
		{
			Qt::KeyboardModifier modifier = tParserData->m_modifierStrings.key(modifierString, Qt::NoModifier);
			if (modifier == Qt::NoModifier)
				return; //parsing failed
			modifiers |= modifier;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dir : dirs)
	{
		QDirIterator dirIt(dir, QDir::Files);
		while (dirIt.hasNext())
		{
			const QString filePath = dirIt.next();
			const QString fileName = dirIt.fileName();
			//create item for this brush
			const QPixmap pixmap = render(filePath);
			if (pixmap.isNull())
				continue;
			QStandardItem* item = new QStandardItem;
			item->setData(pixmap, BrushRole);
			item->setData(fileName, IdentifierRole);
			item->setData(pixmap.scaled(DefaultThumbnailSize, Qt::KeepAspectRatio), Qt::DecorationRole);
			item->setData(fileName, Qt::DisplayRole);
			appendRow(item);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (int id : representedAtomicPieces)
		if (!m_representedAtomicPieces.contains(id))
			m_representedAtomicPieces << id;
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : qAsConst(m_interactors))
		interactor->setInactive();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : std::as_const(m_interactors))
		interactor->updateScene();
```

#### AUTO 


```{c}
const auto logicalNeighbors = m_mergedPiece->logicalNeighbors();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : currentResultList)
		{
			const auto logicalNeighbors = piece->logicalNeighbors();
			for (Palapeli::Piece* logicalNeighbor : logicalNeighbors)
			{
				if (piece->scene() != logicalNeighbor->scene())
					continue;
				//no need to check the located physical neighbors again
				if (resultSet.contains(logicalNeighbor))
					continue;
				if (arePiecesPhysicallyNeighboring(piece, logicalNeighbor))
				{
					resultList << logicalNeighbor;
					resultSet << logicalNeighbor;
					addedSomethingInThisLoop = true;
				}
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& entry : std::as_const(m_entries))
	{
		const bool isVisible = enabledProps.contains(entry.property);
		entry.widget->setVisible(isVisible);
		m_layout->labelForField(entry.widget)->setVisible(isVisible);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &offer : offers)
    {
        const QString pluginName = offer.pluginId();
        const QString slicerName = offer.name();
        Pala::Slicer* slicer = nullptr;
        if (auto plugin = KPluginFactory::instantiatePlugin<Pala::Slicer>(offer, nullptr).plugin) {
            slicer = plugin;
        } else {
            continue;
        }
		m_slicerInstances << slicer;
		//create item for this slicer
		QTreeWidgetItem* slicerItem = new QTreeWidgetItem(this);
		slicerItem->setData(0, Qt::DisplayRole, slicerName);
		//scan mode list
		const QList<const Pala::SlicerMode*> modes = slicer->modes();
		if (modes.isEmpty())
		{
			//no modes - make slicer item selectable (i.e. fallback to list-like behavior)
			slicerItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
			Palapeli::SlicerSelection sel(pluginName, slicer);
			m_knownSelections << sel;
			//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
			slicerItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
		}
		else
		{
			//slicer has modes - require to select a specific mode
			slicerItem->setFlags(Qt::ItemIsEnabled);
			for (const Pala::SlicerMode* mode : modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QVariant& choice : choices)
			m_comboBox->addItem(choice.toString());
```

#### AUTO 


```{c}
const auto sccenePieces = scene->pieces();
```

#### AUTO 


```{c}
const auto modes = slicer->modes();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : std::as_const(m_interactors))
		interactor->setInactive();
```

#### AUTO 


```{c}
const auto currentResultList = resultList;
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : std::as_const(m_viewList)) {
	    bool isHolder = (view != m_puzzleTable->view());
	    if (isHolder) {
		KConfigGroup holderDetails(&savedConfig,
			QStringLiteral("Holder_%1").arg(groupID));
		Palapeli::PieceHolder* holder =
			qobject_cast<Palapeli::PieceHolder*>(view);
		bool selected = (view == m_currentHolder);
		holderDetails.writeEntry("Name", holder->name());
		holderDetails.writeEntry("Selected", selected);
		holderDetails.writeEntry("Geometry",
			QRect(view->frameGeometry().topLeft(), view->size()));
	    }
	    const QList<Palapeli::Piece*> pieces = view->scene()->pieces();
	    for (Palapeli::Piece* piece : pieces) {
		const QPointF position = piece->pos();
		const auto atomicPieces = piece->representedAtomicPieces();
		for (int atomicPieceID : atomicPieces) {
		    const QString ID = QString::number(atomicPieceID);
		    locationGroup.writeEntry(ID, position);
		    if (isHolder) {
			holderGroup.writeEntry(ID, groupID);
		    }
		    else {
			holderGroup.deleteEntry(ID);
		    }
		}
	    }
	    groupID++;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : sel) {
		Palapeli::Piece* p = Palapeli::Piece::fromSelectedItem(item);
		if (p) {
			pieces << p;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Palapeli::Trigger& trigger : triggers) //implicit casts FTW
			if (trigger.isValid()) {
				// Remove default and insert config value(s).
				m_associations.insert(interactorKey, trigger);
			}
```

#### AUTO 


```{c}
auto *generator = QRandomGenerator::global();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Pala::SlicerProperty* property : properties)
	{
		Palapeli::PropertyWidget* propWidget = Palapeli::createPropertyWidget(property);
		Entry entry = { property, propWidget };
		m_entries << entry;
		m_layout->addRow(property->caption() + QLatin1Char(':'), propWidget);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &offer : offers)
	{
		const QString pluginName = offer.pluginId(), slicerName = offer.name();
		//create slicer object
		KPluginLoader loader(offer.fileName());
		KPluginFactory *factory = loader.factory();
		Pala::Slicer* slicer = factory->create<Pala::Slicer>(0, QVariantList());
		if (!slicer)
			continue;
		m_slicerInstances << slicer;
		//create item for this slicer
		QTreeWidgetItem* slicerItem = new QTreeWidgetItem(this);
		slicerItem->setData(0, Qt::DisplayRole, slicerName);
		//scan mode list
		const QList<const Pala::SlicerMode*> modes = slicer->modes();
		if (modes.isEmpty())
		{
			//no modes - make slicer item selectable (i.e. fallback to list-like behavior)
			slicerItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
			Palapeli::SlicerSelection sel(pluginName, slicer);
			m_knownSelections << sel;
			//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
			slicerItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
		}
		else
		{
			//slicer has modes - require to select a specific mode
			slicerItem->setFlags(Qt::ItemIsEnabled);
			foreach (const Pala::SlicerMode* mode, modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
	{
		Palapeli::Puzzle* puzzle = coll->puzzleFromIndex(index);
		if (!puzzle)
			continue;
		//get puzzle name (as an initial guess for the file name)
		puzzle->get(Palapeli::PuzzleComponent::Metadata);
		const Palapeli::MetadataComponent* cmp = puzzle->component<Palapeli::MetadataComponent>();
		if (!cmp)
			continue;
		//ask user for target file name
		const QString startLoc = QString::fromLatin1("%1.puzzle").arg(cmp->metadata.name);
		const QString filter = i18nc("Filter for a file dialog", "Palapeli puzzles (*.puzzle)");
		const QString location = QFileDialog::getSaveFileName(m_mainWindow,
															  i18n("Save Palapeli puzzles"),
															  startLoc,
															  filter);
		if (location.isEmpty())
			continue; //process aborted by user
		//do export
		coll->exportPuzzle(index, location);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : pieces) {
				piece->setSelected(true);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Pala::Slicer* slicer : slicers)
	{
		m_slicerConfigWidgets[slicer] = new Palapeli::SlicerConfigWidget(slicer);
		m_slicerConfigMasterWidget->addWidget(m_slicerConfigWidgets[slicer]);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Pala::SlicerMode* mode : modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(m_loadedPieces)) {
		m_pieceAreaSize = m_pieceAreaSize.expandedTo
				(piece->sceneBareBoundingRect().size());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& imageType : supportedImageTypes) {
	    mimeTypeFilters.append(QString::fromUtf8(imageType));
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(m_currentPieces))
	{
		disconnect(piece, nullptr, this, nullptr);
		piece->endMove();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Palapeli::PieceVisuals& sample : visuals)
	{
		QRect sampleGeometry(sample.offset(), sample.size());
		if (combinedGeometry.isNull())
			combinedGeometry = sampleGeometry;
		else
			combinedGeometry |= sampleGeometry;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (int atomicPieceID : atomicPieces) {
		    const QString ID = QString::number(atomicPieceID);
		    locationGroup.writeEntry(ID, position);
		    if (isHolder) {
			holderGroup.writeEntry(ID, groupID);
		    }
		    else {
			holderGroup.deleteEntry(ID);
		    }
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : qAsConst(m_viewList)) {
		Palapeli::Scene* scene = view->scene();
		m_currentPieceCount = m_currentPieceCount +
					scene->pieces().size();
		qCDebug(PALAPELI_LOG) << "Counted" << scene->pieces().size();
		if (view != m_puzzleTable->view()) {
			// Saved-and-restored holders start in close-up scale.
			view->setCloseUp(true);
		}
		else {
			qCDebug(PALAPELI_LOG) << "Puzzle table" << scene->pieces().size();
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(m_currentPieces))
	{
		m_basePositions << piece->pos();
		connect(piece, &Piece::replacedBy, this, &MovePieceInteractor::pieceReplacedBy, Qt::DirectConnection);
		piece->beginMove();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(m_pieces))
		{
			QPropertyAnimation* pieceAnimator = new QPropertyAnimation(piece, "pos", nullptr);
			pieceAnimator->setStartValue(piece->pos());
			pieceAnimator->setEndValue(m_ucsPosition);
			pieceAnimator->setDuration(200);
			pieceAnimator->setEasingCurve(QEasingCurve::InCubic);
			masterAnimator->addAnimation(pieceAnimator);
		}
```

#### AUTO 


```{c}
const auto selectedItems = this->selectedItems();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
		if (!index.data(Palapeli::Collection::IsDeleteableRole).toBool())
		{
			Q_EMIT canDeleteChanged(false);
			return;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Pala::SlicerProperty* property : d->m_properties)
		result.insert(property->key(), property);
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* oldPiece : oldPieces)
	{
		int index = m_logicalNeighbors.indexOf(oldPiece);
		if (index != -1)
		{
			oldPiecesFound = true;
			m_logicalNeighbors.removeAt(index);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(selectedPieces)) {
				if (piece->representedAtomicPieces().count()
					> 6) {
					int ans = 0;
					ans = KMessageBox::questionYesNo (
						m_mainWindow,
						i18n("You have selected to "
						"transfer a large piece "
						"containing more than six "
						"small pieces to a holder. Do "
						"you really wish to do that?"));
					if (ans == KMessageBox::No) {
						return;
					}
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : qAsConst(m_viewList)) {
			view->scene()->mergeLoadedPieces();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* logicalNeighbor : logicalNeighbors)
		logicalNeighbor->rewriteLogicalNeighbors(m_pieces, m_mergedPiece);
```

#### AUTO 


```{c}
const auto& imageType
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(m_currentPieces))
	{
		disconnect(piece, nullptr, this, nullptr);
		piece->endMove();
	}
```

#### AUTO 


```{c}
const auto supportedImageTypes = QImageReader::supportedMimeTypes();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : qAsConst(m_viewList)) {
		if (view != m_puzzleTable->view()) {
			view->hide();
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& configKey : configKeys)
	{
		const QByteArray interactorKey = configKey.toLatin1();
		const QList<QByteArray> triggers = group.readEntry(configKey, QList<QByteArray>());
		for (const Palapeli::Trigger& trigger : triggers) //implicit casts FTW
			if (trigger.isValid()) {
				// Remove default and insert config value(s).
				m_associations.insert(interactorKey, trigger);
			}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(selectedPieces)) {
		bRect |= piece->sceneBareBoundingRect();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* newPiece : createdPieces)
	{
		addPieceToList (newPiece);
		connect(newPiece, &Piece::moved,
			this, &Scene::pieceMoved);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* itemUnderMouse : itemsUnderMouse)
		if (itemUnderMouse->flags() & QGraphicsItem::ItemIsSelectable)
			return itemUnderMouse;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &offer : offers)
	{
		const QString pluginName = offer.pluginId(), slicerName = offer.name();
		//create slicer object
		KPluginLoader loader(offer.fileName());
		KPluginFactory *factory = loader.factory();
		Pala::Slicer* slicer = factory->create<Pala::Slicer>(nullptr, QVariantList());
		if (!slicer)
			continue;
		m_slicerInstances << slicer;
		//create item for this slicer
		QTreeWidgetItem* slicerItem = new QTreeWidgetItem(this);
		slicerItem->setData(0, Qt::DisplayRole, slicerName);
		//scan mode list
		const QList<const Pala::SlicerMode*> modes = slicer->modes();
		if (modes.isEmpty())
		{
			//no modes - make slicer item selectable (i.e. fallback to list-like behavior)
			slicerItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
			Palapeli::SlicerSelection sel(pluginName, slicer);
			m_knownSelections << sel;
			//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
			slicerItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
		}
		else
		{
			//slicer has modes - require to select a specific mode
			slicerItem->setFlags(Qt::ItemIsEnabled);
			foreach (const Pala::SlicerMode* mode, modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const DoubleIntPair& relation : contents.relations) {
		Palapeli::Piece* firstPiece =
				m_loadedPieces.value(relation.first, nullptr);
		Palapeli::Piece* secondPiece =
				m_loadedPieces.value(relation.second, nullptr);
		firstPiece->addLogicalNeighbors(QList<Palapeli::Piece*>()
				<< secondPiece);
		secondPiece->addLogicalNeighbors(QList<Palapeli::Piece*>()
				<< firstPiece);
	}
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<Pala::Slicer>(offer, nullptr).plugin
```

#### LAMBDA EXPRESSION 


```{c}
[cc](const KPluginMetaData &m) {
			return m.fileName() == cc.slicer;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* selectedItem : selectedItems)
		{
			Palapeli::Piece* selectedPiece = Palapeli::Piece::fromSelectedItem(selectedItem);
			if (selectedPiece)
				m_currentPieces << selectedPiece;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& key : keys)
		group.deleteEntry(key);
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(selectedPieces)) {
		scene->addToGrid(piece);
	}
```

#### AUTO 


```{c}
const auto keys = group.keyList();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(m_pieces))
	{
		m_mergedPiece->addRepresentedAtomicPieces(piece->representedAtomicPieces());
		m_mergedPiece->addLogicalNeighbors(piece->logicalNeighbors());
		m_mergedPiece->addAtomicSize(piece->atomicSize());
		if (piece->isSelected())
			m_mergedPiece->setSelected(true);
		m_mergedPiece->setZValue(qMax(m_mergedPiece->zValue(), piece->zValue()));
		piece->announceReplaced(m_mergedPiece); //make sure that interactors know about the change, and delete the piece
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : selectedPieces) {
			piece->setSelected(false);
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* checkedPiece : pieceGroup)
			uncheckedPieces.removeAll(checkedPiece);
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : pieces) {
		const QPointF position = piece->pos();
		const auto atomicPieces = piece->representedAtomicPieces();
		for (int atomicPieceID : atomicPieces) {
		    const QString ID = QString::number(atomicPieceID);
		    locationGroup.writeEntry(ID, position);
		    if (isHolder) {
			holderGroup.writeEntry(ID, groupID);
		    }
		    else {
			holderGroup.deleteEntry(ID);
		    }
		}
	    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* scene : std::as_const(m_scenes))
			static_cast<QGraphicsScene*>(scene)->setBackgroundBrush(m_currentBrush);
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(m_pieces))
	{
		m_mergedPiece->addRepresentedAtomicPieces(piece->representedAtomicPieces());
		m_mergedPiece->addLogicalNeighbors(piece->logicalNeighbors());
		m_mergedPiece->addAtomicSize(piece->atomicSize());
		if (piece->isSelected())
			m_mergedPiece->setSelected(true);
		m_mergedPiece->setZValue(qMax(m_mergedPiece->zValue(), piece->zValue()));
		piece->announceReplaced(m_mergedPiece); //make sure that interactors know about the change, and delete the piece
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* item : selectedItems)
	{
		Palapeli::Piece* piece = Palapeli::Piece::fromSelectedItem(item);
		if (piece)
			mergeCandidates << piece;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& puzzleId : puzzleIds)
	{
		dlg.setValue(count++);
		KConfigGroup* puzzleGroup = new KConfigGroup(m_group, puzzleId);
		//find involved files
		const QString basePath = puzzleGroup->readEntry("Location", QString());
		const QString path = readPseudoUrl(basePath, false);
		QString baseDesktopPath(basePath);
        baseDesktopPath.replace(QRegularExpression(QStringLiteral("\\.puzzle$")), QLatin1String(".desktop"));
		const QString desktopPath = readPseudoUrl(baseDesktopPath, false);
		//construct puzzle with CollectionStorageComponent
		if (!path.isEmpty() && (desktopPath.isEmpty() || QFileInfo(path).lastModified() >= QFileInfo(desktopPath).lastModified()))
		{
			Palapeli::Puzzle* puzzle = new Palapeli::Puzzle(new Palapeli::CollectionStorageComponent(puzzleGroup), path, puzzleId);
			appendRow(new Item(puzzle));
			continue;
		}
		//no success - try to construct with RetailStorageComponent
		if (desktopPath.isEmpty())
			continue;
		const QString puzzlePath = readPseudoUrl(basePath, true);
		Palapeli::Puzzle* puzzle = new Palapeli::Puzzle(new Palapeli::RetailStorageComponent(desktopPath), puzzlePath, puzzleId);
		appendRow(new Item(puzzle));
		delete puzzleGroup;
		//make sure puzzle gets converted to archive format
		puzzle->get(Palapeli::PuzzleComponent::ArchiveStorage);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* selectedItem : selectedItems)
			selectedItem->setSelected(false);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject* scene : qAsConst(m_scenes))
			static_cast<QGraphicsScene*>(scene)->setBackgroundBrush(m_currentBrush);
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : std::as_const(m_viewList)) {
		Palapeli::Scene* scene = view->scene();
		scene->addPieceItemsToScene();
		if (scene != m_puzzleTableScene) {
			// Expand the piece-holder sceneRects.
			scene->setSceneRect(scene->extPiecesBoundingRect());
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : std::as_const(m_viewList)) {
			view->scene()->mergeLoadedPieces();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece * piece : pieces) {
		piece->setSelected(false);
		removeItem(piece);
		m_pieces.removeAll(piece);
		disconnect(piece, &Piece::moved, this, &Scene::pieceMoved);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(selectedPieces)) {
				if (piece->representedAtomicPieces().count()
					> 6) {
					int ans = 0;
					ans = KMessageBox::questionYesNo (
						m_mainWindow,
						i18n("You have selected to "
						"transfer a large piece "
						"containing more than six "
						"small pieces to a holder. Do "
						"you really wish to do that?"));
					if (ans == KMessageBox::No) {
						return;
					}
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece * piece : std::as_const(m_pieces)) {
		addItem(piece);
		connect(piece, &Piece::moved, this, &Scene::pieceMoved);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : sccenePieces) {
		// Clear all previous selections in the destination scene.
		if (piece->isSelected()) {
			piece->setSelected(false);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(piecePool)) {
			r |= piece->sceneBareBoundingRect();
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Palapeli::PieceVisuals& sample : visuals)
	{
		QRect sampleGeometry(sample.offset(), sample.size());
		if (combinedGeometry.isNull())
			combinedGeometry = sampleGeometry;
		else
			combinedGeometry |= sampleGeometry;
		//NOTE: bool-int cast always returns 0 or 1.
		imageCount += (int) sample.hasImage();
		pixmapCount += (int) sample.hasPixmap();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : std::as_const(m_viewList)) {
		connect(view->scene(), &Scene::saveMove,
			this, &GamePlay::positionChanged);
		if (view != m_puzzleTable->view()) {
			connect(view, &View::teleport,
				this, &GamePlay::teleport);
			connect(view, &View::newPieceSelectionSeen,
				this, &GamePlay::handleNewPieceSelection);
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(m_pieces))
		{
			QPropertyAnimation* pieceAnimator = new QPropertyAnimation(piece, "pos", nullptr);
			pieceAnimator->setStartValue(piece->pos());
			pieceAnimator->setEndValue(m_ucsPosition);
			pieceAnimator->setDuration(200);
			pieceAnimator->setEasingCurve(QEasingCurve::InCubic);
			masterAnimator->addAnimation(pieceAnimator);
		}
```

#### AUTO 


```{c}
auto plugin = KPluginFactory::instantiatePlugin<Pala::Slicer>(offers.first(), nullptr).plugin
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : paths)
		coll->importPuzzle(path);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : std::as_const(indexes))
		puzzleNames << index.data(Qt::DisplayRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece * piece : qAsConst(m_pieces)) {
		addItem(piece);
		connect(piece, &Piece::moved, this, &Scene::pieceMoved);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& puzzleId : puzzleIds)
	{
		dlg.setValue(count++);
		KConfigGroup* puzzleGroup = new KConfigGroup(m_group, puzzleId);
		//find involved files
		const QString basePath = puzzleGroup->readEntry("Location", QString());
		const QString path = readPseudoUrl(basePath, false);
		QString baseDesktopPath(basePath);
		baseDesktopPath.replace(QRegExp(QStringLiteral("\\.puzzle$")), QLatin1String(".desktop"));
		const QString desktopPath = readPseudoUrl(baseDesktopPath, false);
		//construct puzzle with CollectionStorageComponent
		if (!path.isEmpty() && (desktopPath.isEmpty() || QFileInfo(path).lastModified() >= QFileInfo(desktopPath).lastModified()))
		{
			Palapeli::Puzzle* puzzle = new Palapeli::Puzzle(new Palapeli::CollectionStorageComponent(puzzleGroup), path, puzzleId);
			appendRow(new Item(puzzle));
			continue;
		}
		//no success - try to construct with RetailStorageComponent
		if (desktopPath.isEmpty())
			continue;
		const QString puzzlePath = readPseudoUrl(basePath, true);
		Palapeli::Puzzle* puzzle = new Palapeli::Puzzle(new Palapeli::RetailStorageComponent(desktopPath), puzzlePath, puzzleId);
		appendRow(new Item(puzzle));
		delete puzzleGroup;
		//make sure puzzle gets converted to archive format
		puzzle->get(Palapeli::PuzzleComponent::ArchiveStorage);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : qAsConst(m_viewList)) {
	    bool isHolder = (view != m_puzzleTable->view());
	    if (isHolder) {
		KConfigGroup holderDetails(&savedConfig,
			QStringLiteral("Holder_%1").arg(groupID));
		Palapeli::PieceHolder* holder =
			qobject_cast<Palapeli::PieceHolder*>(view);
		bool selected = (view == m_currentHolder);
		holderDetails.writeEntry("Name", holder->name());
		holderDetails.writeEntry("Selected", selected);
		holderDetails.writeEntry("Geometry",
			QRect(view->frameGeometry().topLeft(), view->size()));
	    }
	    const QList<Palapeli::Piece*> pieces = view->scene()->pieces();
	    for (Palapeli::Piece* piece : pieces) {
		const QPointF position = piece->pos();
		const auto atomicPieces = piece->representedAtomicPieces();
		for (int atomicPieceID : atomicPieces) {
		    const QString ID = QString::number(atomicPieceID);
		    locationGroup.writeEntry(ID, position);
		    if (isHolder) {
			holderGroup.writeEntry(ID, groupID);
		    }
		    else {
			holderGroup.deleteEntry(ID);
		    }
		}
	    }
	    groupID++;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : qAsConst(m_interactors))
		if (interactor->isActive())
		{
			//fetch flags, and remove them to mark this interactor as processed
			EventContext context = interactorData.value(interactor);
			interactorData.remove(interactor);
			//send event, mark button as processed
			if ((unhandledButtons & context.triggeringButtons) || context.triggeringButtons == Qt::NoButton)
			{
				interactor->sendEvent(pEvent, context.flags);
				if (interactor->isActive())
					unhandledButtons &= ~context.triggeringButtons;
			}
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& entry : qAsConst(m_entries))
	{
		const bool isVisible = enabledProps.contains(entry.property);
		entry.widget->setVisible(isVisible);
		m_layout->labelForField(entry.widget)->setVisible(isVisible);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(m_loadedPieces)) {
		m_pieceAreaSize = m_pieceAreaSize.expandedTo
				(piece->sceneBareBoundingRect().size());
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (QGraphicsItem* selectedItem : selectedItems) {
		Palapeli::Piece* selectedPiece =
			Palapeli::Piece::fromSelectedItem(selectedItem);
		if (selectedPiece) {
			Palapeli::View* v =
				qobject_cast<Palapeli::View*>(this->view());
			v->handleNewPieceSelection();
			break;
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : std::as_const(sortedInteractors))
	{
		const EventContext context = interactorData.value(interactor);
		//send event, mark button as processed
		if ((unhandledButtons & context.triggeringButtons) || context.triggeringButtons == Qt::NoButton)
		{
			interactor->sendEvent(pEvent, context.flags);
			if (interactor->isActive())
				unhandledButtons &= ~context.triggeringButtons;
		}
		else
			interactor->setInactive();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : qAsConst(m_viewList)) {
		Palapeli::Scene* scene = view->scene();
		scene->addPieceItemsToScene();
		if (scene != m_puzzleTableScene) {
			// Expand the piece-holder sceneRects.
			scene->setSceneRect(scene->extPiecesBoundingRect());
		}
	}
```

#### AUTO 


```{c}
const auto slicers = m_slicerSelector->slicers();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &actionId : collectionActions) {
		m_mainWindow->actionCollection()->
			action(actionId)->setEnabled(enCollection);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Pala::SlicerMode* mode : modes)
				if (mode->key() == cc.slicerMode)
				{
					job.setMode(mode);
					break;
				}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Palapeli::PieceVisuals& sample : visuals)
			painter.drawImage(sample.offset() - combinedOffset, sample.image());
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : std::as_const(m_viewList)) {
		Palapeli::Scene* scene = view->scene();
		m_currentPieceCount = m_currentPieceCount +
					scene->pieces().size();
		qCDebug(PALAPELI_LOG) << "Counted" << scene->pieces().size();
		if (view != m_puzzleTable->view()) {
			// Saved-and-restored holders start in close-up scale.
			view->setCloseUp(true);
		}
		else {
			qCDebug(PALAPELI_LOG) << "Puzzle table" << scene->pieces().size();
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : qAsConst(m_viewList)) {
		connect(view->scene(), &Scene::saveMove,
			this, &GamePlay::positionChanged);
		if (view != m_puzzleTable->view()) {
			connect(view, &View::teleport,
				this, &GamePlay::teleport);
			connect(view, &View::newPieceSelectionSeen,
				this, &GamePlay::handleNewPieceSelection);
		}
	}
```

#### AUTO 


```{c}
const auto &actionId
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &offer : offers)
	{
		const QString pluginName = offer.fileName(), slicerName = offer.name();
		//create slicer object
		KPluginLoader loader(pluginName);
		KPluginFactory *factory = loader.factory();
		Pala::Slicer* slicer = factory->create<Pala::Slicer>(0, QVariantList());
		if (!slicer)
			continue;
		m_slicerInstances << slicer;
		//create item for this slicer
		QTreeWidgetItem* slicerItem = new QTreeWidgetItem(this);
		slicerItem->setData(0, Qt::DisplayRole, slicerName);
		//scan mode list
		const QList<const Pala::SlicerMode*> modes = slicer->modes();
		if (modes.isEmpty())
		{
			//no modes - make slicer item selectable (i.e. fallback to list-like behavior)
			slicerItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
			Palapeli::SlicerSelection sel(pluginName, slicer);
			m_knownSelections << sel;
			//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
			slicerItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
		}
		else
		{
			//slicer has modes - require to select a specific mode
			slicerItem->setFlags(Qt::ItemIsEnabled);
			foreach (const Pala::SlicerMode* mode, modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(m_pieces))
	{
		pieceVisuals << piece->pieceVisuals();
		if (allPiecesHaveShadows) //we stop collecting shadow samples when one piece has no shadow
		{
			const Palapeli::PieceVisuals shadowSample = piece->shadowVisuals();
			if (shadowSample.isNull())
				allPiecesHaveShadows = false;
			else
				shadowVisuals << shadowSample;
		}
		// Single pieces are assigned highlight items lazily (i.e. if
		// they happen to get selected), but when they are merged, each
		// one must have a highlight pixmap that can be merged into a
		// combined highlight pixmap for the new multi-part piece.
		if (!piece->hasHighlight()) {
			piece->createHighlight(m_pieceAreaSize);
		}
		highlightVisuals << piece->highlightVisuals();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(selectedPieces)) {
		bRect |= piece->sceneBareBoundingRect();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : qAsConst(indexes))
		puzzleNames << index.data(Qt::DisplayRole).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &actionId : playingActions) {
		m_mainWindow->actionCollection()->
			action(actionId)->setEnabled(enPlaying);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : indexes)
	{
		Palapeli::Puzzle* puzzle = coll->puzzleFromIndex(index);
		if (!puzzle)
			continue;
		//get puzzle name (as an initial guess for the file name)
		puzzle->get(Palapeli::PuzzleComponent::Metadata);
		const Palapeli::MetadataComponent* cmp = puzzle->component<Palapeli::MetadataComponent>();
		if (!cmp)
			continue;
		//ask user for target file name
		const QString startLoc = QString::fromLatin1("%1.puzzle").arg(cmp->metadata.name);
		const QString filter = i18nc("Filter for a file dialog", "Palapeli puzzles (*.puzzle)");
		const QString location = QFileDialog::getSaveFileName(m_mainWindow,
															  i18nc("@title:window", "Save Palapeli Puzzles"),
															  startLoc,
															  filter);
		if (location.isEmpty())
			continue; //process aborted by user
		//do export
		coll->exportPuzzle(index, location);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Entry& entry : m_entries)
		result.insert(entry.property->key(), entry.widget->propertyValue());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Palapeli::PieceVisuals& sample : visuals)
			painter.drawPixmap(sample.offset() - combinedOffset, sample.pixmap());
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(m_currentPieces))
	{
		m_basePositions << piece->pos();
		connect(piece, &Piece::replacedBy, this, &MovePieceInteractor::pieceReplacedBy, Qt::DirectConnection);
		piece->beginMove();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Interactor* interactor : qAsConst(sortedInteractors))
	{
		const EventContext context = interactorData.value(interactor);
		//send event, mark button as processed
		if ((unhandledButtons & context.triggeringButtons) || context.triggeringButtons == Qt::NoButton)
		{
			interactor->sendEvent(pEvent, context.flags);
			if (interactor->isActive())
				unhandledButtons &= ~context.triggeringButtons;
		}
		else
			interactor->setInactive();
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Pala::Slicer* slicer : m_slicerInstances)
		result << slicer;
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &offer : offers)
    {
        const QString pluginName = offer.pluginId();
        const QString slicerName = offer.name();
#if KCOREADDONS_VERSION < QT_VERSION_CHECK(5, 86, 0)
		//create slicer object
		KPluginLoader loader(offer.fileName());
		KPluginFactory *factory = loader.factory();
		Pala::Slicer* slicer = factory->create<Pala::Slicer>(nullptr, QVariantList());
		if (!slicer)
            continue;
#else
        Pala::Slicer* slicer = nullptr;
        if (auto plugin = KPluginFactory::instantiatePlugin<Pala::Slicer>(offer, nullptr).plugin) {
            slicer = plugin;
        } else {
            continue;
        }
#endif
		m_slicerInstances << slicer;
		//create item for this slicer
		QTreeWidgetItem* slicerItem = new QTreeWidgetItem(this);
		slicerItem->setData(0, Qt::DisplayRole, slicerName);
		//scan mode list
		const QList<const Pala::SlicerMode*> modes = slicer->modes();
		if (modes.isEmpty())
		{
			//no modes - make slicer item selectable (i.e. fallback to list-like behavior)
			slicerItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
			Palapeli::SlicerSelection sel(pluginName, slicer);
			m_knownSelections << sel;
			//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
			slicerItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
		}
		else
		{
			//slicer has modes - require to select a specific mode
			slicerItem->setFlags(Qt::ItemIsEnabled);
			for (const Pala::SlicerMode* mode : modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(piecePool)) {
			r |= piece->sceneBareBoundingRect();
		}
```

#### AUTO 


```{c}
const auto atomicPieces = piece->representedAtomicPieces();
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::View* view : std::as_const(m_viewList)) {
		if (view != m_puzzleTable->view()) {
			view->hide();
		}
	}
```

#### LAMBDA EXPRESSION 


```{c}
[cc](const KPluginMetaData &m) {
            return m.pluginId() == cc.slicer;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : logicalNeighbors)
		// IDW TODO - if (!m_logicalNeighbors.contains(piece) && piece)
		//            If piece == 0, pieceID was not in m_loadedPieces.
		//            This would be an integrity error in .puzzle file.
		if (!m_logicalNeighbors.contains(piece))
			m_logicalNeighbors << piece;
```

#### LAMBDA EXPRESSION 


```{c}
[cc](const KPluginMetaData &m) {
			return m.pluginId() == cc.slicer;
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* logicalNeighbor : logicalNeighbors)
			{
				if (piece->scene() != logicalNeighbor->scene())
					continue;
				//no need to check the located physical neighbors again
				if (resultSet.contains(logicalNeighbor))
					continue;
				if (arePiecesPhysicallyNeighboring(piece, logicalNeighbor))
				{
					resultList << logicalNeighbor;
					resultSet << logicalNeighbor;
					addedSomethingInThisLoop = true;
				}
			}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : qAsConst(m_pieces))
	{
		pieceVisuals << piece->pieceVisuals();
		if (allPiecesHaveShadows) //we stop collecting shadow samples when one piece has no shadow
		{
			const Palapeli::PieceVisuals shadowSample = piece->shadowVisuals();
			if (shadowSample.isNull())
				allPiecesHaveShadows = false;
			else
				shadowVisuals << shadowSample;
		}
		// Single pieces are assigned highlight items lazily (i.e. if
		// they happen to get selected), but when they are merged, each
		// one must have a highlight pixmap that can be merged into a
		// combined highlight pixmap for the new multi-part piece.
		if (!piece->hasHighlight()) {
			piece->createHighlight(m_pieceAreaSize);
		}
		highlightVisuals << piece->highlightVisuals();
	}
```

#### AUTO 


```{c}
const auto selectedPieces = getSelectedPieces(m_puzzleTableView);
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : pieces)
	{
		const int weight = piece->representedAtomicPieces().count();
		m_ucsPosition += weight * piece->pos();
		totalWeight += weight;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &offer : offers)
	{
		const QString pluginName = offer.pluginId(), slicerName = offer.name();
		//create slicer object
		KPluginLoader loader(offer.fileName());
		KPluginFactory *factory = loader.factory();
		Pala::Slicer* slicer = factory->create<Pala::Slicer>(nullptr, QVariantList());
		if (!slicer)
			continue;
		m_slicerInstances << slicer;
		//create item for this slicer
		QTreeWidgetItem* slicerItem = new QTreeWidgetItem(this);
		slicerItem->setData(0, Qt::DisplayRole, slicerName);
		//scan mode list
		const QList<const Pala::SlicerMode*> modes = slicer->modes();
		if (modes.isEmpty())
		{
			//no modes - make slicer item selectable (i.e. fallback to list-like behavior)
			slicerItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
			Palapeli::SlicerSelection sel(pluginName, slicer);
			m_knownSelections << sel;
			//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
			slicerItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
		}
		else
		{
			//slicer has modes - require to select a specific mode
			slicerItem->setFlags(Qt::ItemIsEnabled);
			for (const Pala::SlicerMode* mode : modes)
			{
				QTreeWidgetItem* modeItem = new QTreeWidgetItem(slicerItem);
				modeItem->setData(0, Qt::DisplayRole, mode->name());
				Palapeli::SlicerSelection sel(pluginName, slicer, mode);
				m_knownSelections << sel;
				//the index in m_knownSelections is recorded in Qt::UserRole to map selected items to SlicerSelections
				modeItem->setData(0, Qt::UserRole, m_knownSelections.count() - 1);
			}
		}
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (Palapeli::Piece* piece : std::as_const(selectedPieces)) {
		scene->addToGrid(piece);
	}
```

