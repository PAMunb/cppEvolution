#### AUTO 


```{c}
auto copyJob = KIO::copy(QUrl::fromLocalFile(tmp.fileName()), url);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &label : m_statusBarLabel) {
       label = new QLabel(this);
       label->setAlignment(Qt::AlignCenter);
       statusBar()->addWidget(label, 1);
    }
```

#### AUTO 


```{c}
auto returnEndLine() {
#if (QT_VERSION < QT_VERSION_CHECK(5, 15, 0))
     return endl;
#else
     return Qt::endl;
#endif
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const KReversiMove & pos : qAsConst(lastUndo)) {
            ChipColor opponentColor = Utils::opponentColorFor(m_cells[pos.row][pos.col]);
            setChipColor(KReversiMove(opponentColor, pos.row, pos.col));
        }
```

#### AUTO 


```{c}
auto job = KIO::statDetails(url, KIO::StatJob::SourceSide, KIO::StatNoDetails);
```

#### AUTO 


```{c}
auto job = KIO::stat(url, KIO::StatJob::SourceSide, 0);
```

#### AUTO 


```{c}
auto* label = qobject_cast<KUrlLabel*>(sender());
```

#### AUTO 


```{c}
auto copyJob = KIO::file_copy(url, QUrl::fromLocalFile(tmpFile.fileName()));
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(label->url()));
```

#### AUTO 


```{c}
auto &label
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(QUrl(url));
```

#### RANGE FOR STATEMENT 


```{c}
for (const KReversiMove & pos : std::as_const(lastUndo)) {
            ChipColor opponentColor = Utils::opponentColorFor(m_cells[pos.row][pos.col]);
            setChipColor(KReversiMove(opponentColor, pos.row, pos.col));
        }
```

