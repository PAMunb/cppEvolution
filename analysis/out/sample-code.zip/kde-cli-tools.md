#### LAMBDA EXPRESSION 


```{c}
[this](KPageWidgetItem *newPage,KPageWidgetItem *oldPage) {
                Q_UNUSED(oldPage);
                KCModuleProxy *activeModule = newPage->widget()->findChild<KCModuleProxy *>();
                if (activeModule) {
                    KActivities::ResourceInstance::notifyAccessed(QUrl(QStringLiteral("kcm:") + activeModule->moduleInfo().service()->storageId()),
                            QStringLiteral("org.kde.systemsettings"));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : positionalArguments) {
        command += ' ';
        command += QFile::encodeName(KShell::quoteArg(arg));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &data : knownKCMs) {
                const QStringList possibleIds{arg, QStringLiteral("kcm_") + arg, QStringLiteral("kcm") + arg};
                if (possibleIds.contains(data.pluginId())) {
                    metaDataList << data;
                    continue;
                }
            }
```

#### AUTO 


```{c}
const auto &plugin
```

#### LAMBDA EXPRESSION 


```{c}
[&](KJob *job) {
        if (job->error()) {
            job_had_error = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &servicePtr : partOfferList) {
        servicesIds.append(servicePtr->storageId());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KPageWidgetItem *newPage,KPageWidgetItem *oldPage) {
                Q_UNUSED(oldPage);
                KCModuleProxy *activeModule = newPage->widget()->findChild<KCModuleProxy *>();
                if (activeModule) {
                    KActivities::ResourceInstance::notifyAccessed(QUrl(QStringLiteral("kcm:") + activeModule->moduleInfo().service()->storageId()),
                            QStringLiteral("org.kde.systemsettings"));
                }
            }
```

#### AUTO 


```{c}
const auto &positionalArgs = parser.positionalArguments();
```

#### LAMBDA EXPRESSION 


```{c}
[](KPageWidgetItem *newPage, KPageWidgetItem *oldPage) {
        Q_UNUSED(oldPage);
        KCModuleProxy *activeModule = newPage->widget()->findChild<KCModuleProxy *>();
        if (activeModule) {
            KActivities::ResourceInstance::notifyAccessed(QUrl(QStringLiteral("kcm:") + activeModule->moduleInfo().service()->storageId()),
                                                          QStringLiteral("org.kde.systemsettings"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar character : QString::fromLocal8Bit(command)) {
        if (!character.isPrint() && character.category() != QChar::Other_Surrogate) {
            return -2;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : allModules) {
            QString comment = service->comment();
            if (comment.isEmpty()) {
                comment = i18n("No description available");
            }

            const QString entry = QStringLiteral("%1 - %2").arg(service->desktopEntryName().leftJustified(maxLen, QLatin1Char(' ')), comment);

            std::cout << entry.toLocal8Bit().constData() << '\n';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        KPluginMetaData data(arg);
        if (data.isValid()) {
            metaDataList << data;
        } else {
            // Look in the namespaces for systemsettings/kinfocenter
            const static auto knownKCMs = findKCMsMetaData();
            for (const KPluginMetaData &data : knownKCMs) {
                const QStringList possibleIds{arg, QStringLiteral("kcm_") + arg, QStringLiteral("kcm") + arg};
                if (possibleIds.contains(data.pluginId())) {
                    metaDataList << data;
                    continue;
                }
            }
            KService::Ptr service = locateModule(arg);
            if (!service) {
                service = locateModule(QStringLiteral("kcm_") + arg);
            }
            if (!service) {
                service = locateModule(QStringLiteral("kcm") + arg);
            }

            if (service) {
                if (!serviceName.isEmpty()) {
                    serviceName += QLatin1Char('_');
                }
                serviceName += arg;

                const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("/kservices5/") + service->entryPath());
                auto data = KPluginMetaData::fromDesktopFile(file);
                metaDataList << data;
            } else {
                std::cerr << i18n("Could not find module '%1'. See kcmshell5 --list for the full list of modules.", arg).toLocal8Bit().constData() << std::endl;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : services) {
            const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("/kservices5/") + service->entryPath());
            plugins << KPluginMetaData::fromDesktopFile(file);
        }
```

#### AUTO 


```{c}
const auto partOfferList = KParts::PartLoader::partsForMimeType(name());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &metaData : partOfferList) {
        servicesIds.append(metaData.pluginId());
    }
```

#### AUTO 


```{c}
const auto positionalArguments = p.positionalArguments();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : allModules) {
            const int len = service->desktopEntryName().size();
            maxLen = std::max(maxLen, len);
        }
```

#### AUTO 


```{c}
auto rIt = mimeFiles.crbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : std::as_const(offers)) {
        if (outputProperties) {
            printf("---- Offer %d ----\n", i++);

            const QStringList props = service->propertyNames();
            for (const QString &propName : props) {
                QVariant prop = service->property(propName);

                if (!prop.isValid()) {
                    printf("Invalid property %s\n", propName.toLocal8Bit().data());
                    continue;
                }

                QString outp = propName;
                outp += QStringLiteral(" : '");

                switch (prop.type()) {
                case QVariant::StringList:
                    outp += prop.toStringList().join(QStringLiteral(" - "));
                    break;
                case QVariant::Bool:
                    outp += prop.toBool() ? QStringLiteral("TRUE") : QStringLiteral("FALSE");
                    break;
                default:
                    outp += prop.toString();
                    break;
                }

                if (!outp.isEmpty()) {
                    printf("%s'\n", outp.toLocal8Bit().constData());
                }
            }
        } else {
            printf("%s\n", service->entryPath().toLocal8Bit().constData());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &desktop : desktopsSplit) {
        const QString file =
            QStandardPaths::writableLocation(QStandardPaths::GenericConfigLocation) + QLatin1Char('/') + desktop.toLower() + QLatin1String("-mimeapps.list");
        if (QFileInfo::exists(file)) {
            qDebug() << "Cleaning up" << file;
            KConfig conf(file, KConfig::NoGlobals);
            KConfigGroup(&conf, s_DefaultApplications).deleteEntry(name());
            KConfigGroup(&conf, s_AddedAssociations).deleteEntry(name());
            KConfigGroup(&conf, s_RemovedAssociations).deleteEntry(name());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TypesListItem *tli : qAsConst(m_itemList)) {
        if (tli->mimeTypeData().isDirty()) {
            if (tli->mimeTypeData().isServiceListDirty()) {
                needUpdateSycoca = true;
            }
            qDebug() << "Entry " << tli->name() << " is dirty. Saving.";
            if (tli->mimeTypeData().sync()) {
                needUpdateMimeDb = true;
            }
            didIt = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &pattern : qAsConst(d->m_patterns)) {
        writer.writeStartElement(nsUri, QStringLiteral("glob"));
        writer.writeAttribute(QStringLiteral("pattern"), pattern);
        writer.writeEndElement(); // glob
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        KService::Ptr service = locateModule(arg);
        if (!service) {
            service = locateModule(QStringLiteral("kcm_") + arg);
        }
        if (!service) {
            service = locateModule(QStringLiteral("kcm") + arg);
        }

        if (service) {
            modules.append(service);
            if (!serviceName.isEmpty()) {
                serviceName += QLatin1Char('_');
            }
            serviceName += arg;
        } else {
            std::cerr << i18n("Could not find module '%1'. See kcmshell5 --list for the full list of modules.", arg).toLocal8Bit().constData() << std::endl;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : std::as_const(args)) {
        KService::Ptr service = locateModule(arg);
        if (!service) {
            service = locateModule(QStringLiteral("kcm_") + arg);
        }
        if (!service) {
            service = locateModule(QStringLiteral("kcm") + arg);
        }

        if (service) {
            modules.append(service);
            if (!serviceName.isEmpty()) {
                serviceName += QLatin1Char('_');
            }
            serviceName += arg;
        } else {
            std::cerr << i18n("Could not find module '%1'. See kcmshell5 --list for the full list of modules.", arg).toLocal8Bit().constData() << std::endl;
        }
    }
```

#### AUTO 


```{c}
const static auto knownKCMs = findKCMsMetaData();
```

#### AUTO 


```{c}
auto data = KPluginMetaData::fromDesktopFile(file);
```

#### AUTO 


```{c}
auto it = std::remove_if(services.begin(), services.end(), [](const KService::Ptr &service) {
        return !KAuthorized::authorizeControlModule(service->menuId());
    });
```

#### LAMBDA EXPRESSION 


```{c}
[this](KPageWidgetItem *newPage,KPageWidgetItem *oldPage) {
                Q_UNUSED(oldPage);
                KCModuleProxy *activeModule = newPage->widget()->findChild<KCModuleProxy *>();
                if (activeModule) {
                    KActivities::ResourceInstance::notifyAccessed(QUrl("kcm:" + activeModule->moduleInfo().service()->storageId()),
                            "org.kde.systemsettings");
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &servicePtr : offerList) {
        serviceIds.append(servicePtr->storageId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : services) {
                KService::Ptr pService = KService::serviceByStorageId(service);
                if (pService) {
                    servicesLB->addItem(new KServiceListItem(pService, m_kind));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (TypesListItem *it : qAsConst(m_itemList)) {
        const MimeTypeData &mimeTypeData = it->mimeTypeData();
        if (patternFilter.isEmpty() || mimeTypeData.matchesFilter(patternFilter)) {
            TypesListItem *group = m_majorMap.value(mimeTypeData.majorType());
            Q_ASSERT(group);
            if (group) {
                group->setHidden(false);
                it->setHidden(false);
            }
        } else {
            it->setHidden(true);
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob(service);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : services) {
        // If removedServiceList.contains(service), then it was previously removed but has been added back
        removedServiceList.removeAll(service);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &service : allServices) {
        if (service->hasServiceType(QStringLiteral("KParts/ReadOnlyPart"))) {
            m_listbox->addItem(new KServiceListItem(service, KServiceListWidget::SERVICELIST_SERVICES));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginMetaData &m : std::as_const(metaDataList)) {
        dlg->addModule(m, moduleArgs);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &servicePtr : modules) {
        dlg->addModule(servicePtr, nullptr, moduleArgs);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &entry : list) {
        // For each file...
        std::cout << qPrintable(entry.stringValue(KIO::UDSEntry::UDS_NAME)) << '\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        KPluginMetaData data(arg);
        if (data.isValid()) {
            metaDataList << data;
        } else {
            KService::Ptr service = locateModule(arg);
            if (!service) {
                service = locateModule(QStringLiteral("kcm_") + arg);
            }
            if (!service) {
                service = locateModule(QStringLiteral("kcm") + arg);
            }

            if (service) {
                if (!serviceName.isEmpty()) {
                    serviceName += QLatin1Char('_');
                }
                serviceName += arg;

                const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("/kservices5/") + service->entryPath());
                auto data = KPluginMetaData::fromDesktopFile(file);
                metaDataList << data;
            } else {
                std::cerr << i18n("Could not find module '%1'. See kcmshell5 --list for the full list of modules.", arg).toLocal8Bit().constData() << std::endl;
            }
        }
    }
```

#### AUTO 


```{c}
auto *job = new KIO::CommandLauncherJob(exe, exeArgs);
```

#### AUTO 


```{c}
const auto tag = xml.name();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QDBusMessage &reply) {
        if (reply.type() == QDBusMessage::ErrorMessage) {
            qWarning() << "Inhibit failed" << reply.errorMessage();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KService::Ptr s1, const KService::Ptr s2) {
        return QString::compare(s1->desktopEntryName(), s2->desktopEntryName(), Qt::CaseInsensitive) < 0;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &mime : qAsConst(removedList)) {
        MimeTypeWriter::removeOwnMimeType(mime);
        didIt = true;
        needUpdateMimeDb = true;
        needUpdateSycoca = true; // remove offers for this mimetype
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](KPageWidgetItem *newPage,KPageWidgetItem *oldPage) {
                KCModuleProxy *activeModule = qobject_cast<KCModuleProxy *>(newPage->widget());
                if (activeModule) {
                    KActivities::ResourceInstance::notifyAccessed(QUrl("kcm:" + activeModule->moduleInfo().service()->storageId()),
                            "org.kde.systemsettings");
                }
            }
```

#### AUTO 


```{c}
auto warnOnError = [](const QDBusMessage &reply) {
        if (reply.type() == QDBusMessage::ErrorMessage) {
            qWarning() << "Inhibit failed" << reply.errorMessage();
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &propName : props) {
                QVariant prop = service->property(propName);

                if (!prop.isValid()) {
                    printf("Invalid property %s\n", propName.toLocal8Bit().data());
                    continue;
                }

                QString outp = propName;
                outp += QStringLiteral(" : '");

                switch (prop.type()) {
                case QVariant::StringList:
                    outp += prop.toStringList().join(QStringLiteral(" - "));
                    break;
                case QVariant::Bool:
                    outp += prop.toBool() ? QStringLiteral("TRUE") : QStringLiteral("FALSE");
                    break;
                default:
                    outp += prop.toString();
                    break;
                }

                if (!outp.isEmpty()) {
                    printf("%s'\n", outp.toLocal8Bit().constData());
                }
            }
```

#### AUTO 


```{c}
const auto match = QRegularExpression(QStringLiteral(":(\\d+)(?::(\\d+))?:?$")).match(pathOrUrl2);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
            QString comment = plugin.description();
            if (comment.isEmpty()) {
                comment = i18n("No description available");
            }

            const QString entry = QStringLiteral("%1 - %2").arg(plugin.pluginId().leftJustified(maxLen, QLatin1Char(' ')), comment);

            std::cout << entry.toLocal8Bit().constData() << '\n';
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urlArgs) {
        ret += makeURL(url);
    }
```

#### AUTO 


```{c}
auto *job = new KIO::ApplicationLauncherJob();
```

#### AUTO 


```{c}
const auto &metaData
```

#### AUTO 


```{c}
auto *job = new KIO::OpenUrlJob(info.url, mimeType);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &oldService : oldServices) {
        if (!services.contains(oldService)) {
            // The service was in m_appServices (or m_embedServices) but has been removed
            removedServiceList.append(oldService);
        }
    }
```

#### AUTO 


```{c}
auto it = m_majorMap.cbegin();
```

#### LAMBDA EXPRESSION 


```{c}
[](KPageWidgetItem *newPage, KPageWidgetItem *oldPage) {
        Q_UNUSED(oldPage);
        KCModuleProxy *activeModule = newPage->widget()->findChild<KCModuleProxy *>();
        if (activeModule) {
            KActivities::ResourceInstance::notifyAccessed(QUrl(QLatin1String("kcm:") + activeModule->metaData().pluginId()),
                                                          QStringLiteral("org.kde.systemsettings"));
        }
    }
```

#### AUTO 


```{c}
auto it2(mimetypes.constBegin());
```

#### AUTO 


```{c}
const auto &servicePtr
```

#### IF STATEMENT WITH INITIALIZER 


```{c}
if (int idx = moduleName.indexOf('/'); idx > 0) {
        args = moduleName.mid(idx + 1);
        moduleName = moduleName.left(idx);
    } else {
        args = url.path();
        args = args.mid(1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const KService::Ptr &service) {
        return !KAuthorized::authorizeControlModule(service->menuId());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TypesListItem *tli : qAsConst(m_itemList)) {
            tli->mimeTypeData().refresh();
        }
```

#### AUTO 


```{c}
const auto desktopsSplit = desktops.split(QLatin1Char(':'), Qt::SkipEmptyParts);
```

#### AUTO 


```{c}
auto it = args.begin();
```

#### AUTO 


```{c}
const auto &service
```

#### AUTO 


```{c}
const auto &entry
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        KPluginMetaData data(arg);
        if (data.isValid()) {
            metaDataList << data;
        } else {
            // Look in the namespaces for systemsettings/kinfocenter
            const static auto knownKCMs = findKCMsMetaData();
            const QStringList possibleIds{arg, QStringLiteral("kcm_") + arg, QStringLiteral("kcm") + arg};
            bool foundKCM = std::any_of(knownKCMs.begin(), knownKCMs.end(), [&possibleIds, &metaDataList](const KPluginMetaData &data) {
                bool idMatches = possibleIds.contains(data.pluginId());
                if (idMatches) {
                    metaDataList << data;
                }
                return idMatches;
            });
            if (foundKCM) {
                continue;
            }
            KService::Ptr service = locateModule(arg);
            if (!service) {
                service = locateModule(QStringLiteral("kcm_") + arg);
            }
            if (!service) {
                service = locateModule(QStringLiteral("kcm") + arg);
            }

            if (service) {
                if (!serviceName.isEmpty()) {
                    serviceName += QLatin1Char('_');
                }
                serviceName += arg;

                const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("/kservices5/") + service->entryPath());
                auto data = KPluginMetaData::fromDesktopFile(file);
                metaDataList << data;
            } else {
                std::cerr << i18n("Could not find module '%1'. See kcmshell5 --list for the full list of modules.", arg).toLocal8Bit().constData() << std::endl;
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&possibleIds, &metaDataList](const KPluginMetaData &data) {
                bool idMatches = possibleIds.contains(data.pluginId());
                if (idMatches) {
                    metaDataList << data;
                }
                return idMatches;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QChar character : cmd) {
        if (!character.isPrint() && character.category() != QChar::Other_Surrogate) {
            return -2;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &arg : args) {
        KPluginMetaData data(arg);
        if (data.isValid()) {
            metaDataList << data;
        } else {
            // Look in the namespaces for systemsettings/kinfocenter
            const static auto knownKCMs = findKCMsMetaData();
            const QStringList possibleIds{arg, QStringLiteral("kcm_") + arg, QStringLiteral("kcm") + arg};
            bool foundKCM = std::any_of(knownKCMs.begin(), knownKCMs.end(), [&possibleIds, &metaDataList](const KPluginMetaData &data) {
                bool idMatches = possibleIds.contains(data.pluginId());
                if (idMatches) {
                    metaDataList << data;
                }
                return idMatches;
            });
            if (foundKCM) {
                continue;
            }
#if KCOREADDONS_BUILD_DEPRECATED_SINCE(5, 92)
            KService::Ptr service = locateModule(arg);
            if (!service) {
                service = locateModule(QStringLiteral("kcm_") + arg);
            }
            if (!service) {
                service = locateModule(QStringLiteral("kcm") + arg);
            }

            if (service) {
                if (!serviceName.isEmpty()) {
                    serviceName += QLatin1Char('_');
                }
                serviceName += arg;

                const QString file = QStandardPaths::locate(QStandardPaths::GenericDataLocation, QLatin1String("/kservices5/") + service->entryPath());
                auto data = KPluginMetaData::fromDesktopFile(file);
                metaDataList << data;
            } else {
                std::cerr << i18n("Could not find module '%1'. See kcmshell5 --list for the full list of modules.", arg).toLocal8Bit().constData() << std::endl;
            }
#endif
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](KPageWidgetItem *newPage, KPageWidgetItem *oldPage) {
        Q_UNUSED(oldPage);
        KCModuleProxy *activeModule = newPage->widget()->findChild<KCModuleProxy *>();
        if (activeModule) {
            const QString storageId =
                activeModule->moduleInfo().service() ? activeModule->moduleInfo().service()->storageId() : activeModule->metaData().pluginId();
            KActivities::ResourceInstance::notifyAccessed(QUrl(QLatin1String("kcm:") + storageId), QStringLiteral("org.kde.systemsettings"));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &plugin : plugins) {
            const int len = plugin.pluginId().size();
            maxLen = std::max(maxLen, len);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &service : services) {
        KService::Ptr pService = KService::serviceByStorageId(service);
        if (!pService) {
            qWarning() << "service with storage id" << service << "not found";
            continue; // Where did that one go?
        }

        storageIds.append(pService->storageId());
    }
```

