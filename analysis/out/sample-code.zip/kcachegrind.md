#### AUTO 


```{c}
auto windowList = QApplication::topLevelWidgets();
```

#### AUTO 


```{c}
auto activeWindow = QApplication::activeWindow();
```

