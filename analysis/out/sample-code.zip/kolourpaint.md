#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : d->originalMetaInfoPtr->textKeys ())
        {
            d->fieldsTableWidget->setItem (row, 0/*1st col*/,
                new QTableWidgetItem (key));
            d->fieldsTableWidget->setItem (row, 1/*2nd col*/,
                new QTableWidgetItem (d->originalMetaInfoPtr->text (key)));

            row++;
        }
```

#### AUTO 


```{c}
auto *dimensionsLayout = new QGridLayout (m_dimensionsGroupBox );
```

#### AUTO 


```{c}
const auto mimeTypeList = mimeTypesSupportingProperty (
        property, defaultMimeTypesWithPropertyList);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &seq : shortcut)
    {
        if (seq.count () == 1 && ::KeyIsText (seq [0])) {
            return i18nc ("<Tool Name> (<Single Accel Key>)", "%1 (%2)", text, seq.toString ().toUpper ());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &key : d->m_textMap.keys ())
    {
        ret += kpCommandSize::StringSize (key) +
               kpCommandSize::StringSize (d->m_textMap [key]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : QImageReader::supportedMimeTypes())
  {
    if ( !filter.isEmpty() ) {
      filter += QLatin1Char(' ');
    }

    QMimeType mime(db.mimeTypeForName(QString::fromLatin1(type)));
    if ( mime.isValid() )
    {
      QString glob = mime.globPatterns().join(QLatin1Char(' '));

      filter += glob;

      // I want to show the mime comment AND the file glob pattern,
      // but to avoid that the "All Supported Files" entry shows ALL glob patterns,
      // I must add the pattern here a second time so that QFileDialog::HideNameFilterDetails
      // can hide the first pattern and I still see the second one
      filterList << mime.comment() + QStringLiteral(" (%1)(%2)").arg(glob).arg(glob);
    }
  }
```

#### AUTO 


```{c}
const auto printerHeightMM = printer->heightMM ();
```

#### AUTO 


```{c}
auto *centerWidget = new QWidget (this);
```

#### AUTO 


```{c}
auto *xLabel2 = new QLabel (i18n ("x"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *baseWidget = this;
```

#### AUTO 


```{c}
auto *pack = static_cast <DrawZoomRectPackage *> (userData);
```

#### AUTO 


```{c}
auto *newDoc = new kpDocument (fallbackDocSize.width (),
                                   fallbackDocSize.height (), documentEnvironment ());
```

#### AUTO 


```{c}
auto *saturationLabel = new QLabel (i18n ("&Saturation:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *b : m_toolButtons)
    {
      addButton(b, o, num);
      num++;
    }
```

#### AUTO 


```{c}
auto *newDoc = new kpDocument (
            sel.width (), sel.height (), documentEnvironment ());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *kmw : KMainWindow::memberList ())
    {
        Q_ASSERT (dynamic_cast <kpMainWindow *> (kmw));
        auto *mw = dynamic_cast <kpMainWindow *> (kmw);

        qCDebug(kpLogMainWindow) << "\t\tmw=" << mw;

        if (mw != this)
        {
            // WARNING: Do not use KRecentFilesAction::setItems()
            //          - it does not work since only its superclass,
            //          KSelectAction, implements setItems() and can't
            //          update KRecentFilesAction's URL list.

            // Avoid URL memory leak in KRecentFilesAction::loadEntries().
            mw->d->actionOpenRecent->clear ();

            mw->d->actionOpenRecent->loadEntries (cfg->group (kpSettingsGroupRecentFiles));
            qCDebug(kpLogMainWindow) << "\t\t\tcheck recent URLs="
                        << mw->d->actionOpenRecent->items ();
        }
    }
```

#### AUTO 


```{c}
auto *percentLabel = new QLabel (i18n ("&Percent:"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *oldImageSel = dynamic_cast <kpAbstractImageSelection *> (m_oldSelectionPtr);
```

#### AUTO 


```{c}
auto *offsetLay = new QGridLayout(offsetGroupBox);
```

#### AUTO 


```{c}
auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok |
                                                   QDialogButtonBox::Cancel, dialog);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attr : preeditText.textFormatList ())
    {
        int start = attr.start;
        int length = attr.length;
        QTextCharFormat format = qvariant_cast<QTextFormat> (attr.value).toCharFormat ();

        if (i > start)
        {
            length = length - i + start;
            start = i;
        }
        if (length <= 0) {
            continue;
        }

        if (i < start)
        {
            str = preeditString.mid (i, start - i);
            painter.drawText (x, y, str);
            x += painter.fontMetrics().horizontalAdvance(str);
        }

        painter.save();
        str = preeditString.mid (start, length);
        int width = painter.fontMetrics().horizontalAdvance(str);
        if (format.background ().color () != Qt::black)
        {
            painter.save ();
            painter.setPen (format.background ().color ());
            painter.setBrush (format.background());
            painter.drawRect (x, y - painter.fontMetrics ().ascent (), width, painter.fontMetrics ().height ());
            painter.restore ();
        }
        if (format.foreground ().color () != Qt::black)
        {
            painter.setBrush (format.foreground ());
            painter.setPen (format.foreground ().color ());
        }
        if (format.underlineStyle ())
        {
            painter.drawLine (x, y + painter.fontMetrics ().descent (), x + width, y + painter.fontMetrics ().descent ());
        }
        painter.drawText (x, y, str);

        x += width;
        painter.restore ();

        i = start + length;
    }
```

#### AUTO 


```{c}
auto *verticalSkewLabel = new QLabel (i18n ("&Vertical:"), angleGroupBox);
```

#### AUTO 


```{c}
auto mx = i - radius;
```

#### AUTO 


```{c}
auto *lay = new QGridLayout (this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *button : m_toolButtons)
    {
      if ( button == b )
      {
        tool = button->tool();
        break;
      }
    }
```

#### AUTO 


```{c}
auto *baseLayout = new QVBoxLayout (baseWidget);
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout (actOnBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *action : menuBar ()->actions ())
    {
        if (action->text () == MenuBarItemTextImage ||
            action->text () == MenuBarItemTextSelection)
        {
            if (isSelectionActive ()) {
                action->setText (MenuBarItemTextSelection);
            }
            else {
                action->setText (MenuBarItemTextImage);
            }

            break;
        }
    }
```

#### AUTO 


```{c}
auto *action
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *b : m_toolButtons) {
        b->setToolButtonStyle(style);
    }
```

#### AUTO 


```{c}
const auto scaleDpiX =
        (image.width () / (printerWidthMM / KP_MILLIMETERS_PER_INCH)) / dpiX;
```

#### AUTO 


```{c}
const auto blue = static_cast<quint8> (qBlue (rgb));
```

#### AUTO 


```{c}
auto *dpiXLabel = new QLabel (
        i18nc ("Horizontal DPI 'x' Vertical DPI", " x "), dpiGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : selResizeHandlesRegion)
      painter.drawRect(r);
```

#### AUTO 


```{c}
auto *orgTextSel = dynamic_cast <kpTextSelection *> (m_originalSelectionPtr);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *w : m_toolWidgets)
    {
        if ( !w->isHidden() )
        {
            if (which == uptoVisibleWidget) {
                return w;
            }

            uptoVisibleWidget++;
        }
    }
```

#### AUTO 


```{c}
auto *spaceWidget = new QWidget (centerWidget);
```

#### AUTO 


```{c}
const auto *originalImageSel = dynamic_cast <const kpAbstractImageSelection *>
                (originalSelection ());
```

#### AUTO 


```{c}
auto num = 0;
```

#### AUTO 


```{c}
auto *menu
```

#### AUTO 


```{c}
const auto *imageSelection = dynamic_cast <const kpAbstractImageSelection *> (&selection);
```

#### AUTO 


```{c}
const auto &l
```

#### AUTO 


```{c}
const auto mimeTypeList = mimeTypesSupportingProperty (
        kpSettingMimeTypeMaximumColorDepth, defaultList);
```

#### AUTO 


```{c}
const auto &p
```

#### AUTO 


```{c}
const auto &r
```

#### AUTO 


```{c}
auto *job = new KEMailClientLauncherJob;
```

#### AUTO 


```{c}
auto *heightLabel = new QLabel (i18n ("Height:"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *doc = new kpDocument(pixmap.width(), pixmap.height(), documentEnvironment());
```

#### AUTO 


```{c}
auto mw = (radius << 1) + 1;
```

#### AUTO 


```{c}
auto *topLevelLay = new QVBoxLayout (this);
```

#### AUTO 


```{c}
auto *he = dynamic_cast<QHelpEvent *> (e);
```

#### AUTO 


```{c}
auto *ke = dynamic_cast <QKeyEvent *> (e);
```

#### AUTO 


```{c}
auto output = *m_image;
```

#### AUTO 


```{c}
auto *originalLabel = new QLabel (i18n ("Original:"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *b = new kpToolButton(tool, m_baseWidget);
```

#### AUTO 


```{c}
auto *imageSel = dynamic_cast <kpAbstractImageSelection *> (m_oldSelectionPtr);
```

#### AUTO 


```{c}
const auto & it
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto *b : m_toolButtons)
    {
        if ( b->tool() == tool ) {  // already given
            return;
        }
    }
```

#### AUTO 


```{c}
auto *xLabel1 = new QLabel (i18n ("x"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *w
```

#### AUTO 


```{c}
const auto scaleDpi = qMax (scaleDpiX, scaleDpiY);
```

#### AUTO 


```{c}
auto *cmd = new kpToolColorPickerCommand (  mouseButton (), color, m_oldColor,
                                                    environ ()->commandEnvironment ());
```

#### AUTO 


```{c}
auto *md = new QMimeData ();
```

#### AUTO 


```{c}
auto *resetPushButton = new QPushButton (i18n ("Reset &All Values"), this);
```

#### AUTO 


```{c}
auto x1y1 = m_pToneMaps[m_nToneMapGranularity * v + u][oldTone];
```

#### AUTO 


```{c}
const auto dpiX = screenDevice->logicalDpiX ();
```

#### AUTO 


```{c}
const auto &u
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w : m_toolWidgets)
    {
      connect (w, &kpToolWidgetBase::optionSelected,
               this, &kpToolToolBar::toolWidgetOptionSelected);
    }
```

#### AUTO 


```{c}
auto *mw = dynamic_cast <kpMainWindow *> (kmw);
```

#### AUTO 


```{c}
auto *b
```

#### AUTO 


```{c}
auto *granularityLabel = new QLabel (i18n ("&Granularity:"), this);
```

#### AUTO 


```{c}
const auto scaleDpiY =
        (image.height () / (printerHeightMM / KP_MILLIMETERS_PER_INCH)) / dpiY;
```

#### AUTO 


```{c}
auto *dpiGroupBox = new QGroupBox(i18n("Dots &Per Inch (DPI)"), baseWidget);
```

#### AUTO 


```{c}
auto *buttons = new QDialogButtonBox (QDialogButtonBox::Ok |
                                                      QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto *inputGroupBox = new QGroupBox (i18n ("&RGB Color Cube Distance"),
        baseWidget);
```

#### AUTO 


```{c}
auto r{0};
```

#### AUTO 


```{c}
const auto radius = 0.0;
```

#### AUTO 


```{c}
auto *textSel = dynamic_cast <kpTextSelection *> (sel);
```

#### AUTO 


```{c}
const auto dpiY = screenDevice->logicalDpiY ();
```

#### AUTO 


```{c}
const auto &colName
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : points)
    {
        if (!noDups.isEmpty () && p == noDups.last ()) {
            continue;
        }

        noDups.append (p);
    }
```

#### AUTO 


```{c}
auto *gammaLabel = new QLabel (i18n ("&Gamma:"), this);
```

#### AUTO 


```{c}
const auto printerWidthMM = printer->widthMM ();
```

#### AUTO 


```{c}
const auto& viewRegion = e->region ();
```

#### AUTO 


```{c}
auto *angleGroupBox = new QGroupBox (i18n ("Angle"), mainWidget ());
```

#### AUTO 


```{c}
auto selectedImage = getSelectedBaseImage ();
```

#### AUTO 


```{c}
const auto *textSelection = dynamic_cast <const kpTextSelection *> (&selection);
```

#### AUTO 


```{c}
auto g{0};
```

#### AUTO 


```{c}
auto *fieldsButtonsLayout = new QHBoxLayout ();
```

#### AUTO 


```{c}
const auto boundingRect = imageSel->boundingRect ();
```

#### AUTO 


```{c}
auto *pack = static_cast <kpToolWidgetBrush::DrawPackage *> (userData);
```

#### AUTO 


```{c}
auto i = 0;
```

#### AUTO 


```{c}
auto *channelLabel = new QLabel (i18n ("C&hannels:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &str : theTextLines)
      {
          painter.drawText (theTextAreaRect.x (), baseLine, str);
          baseLine += fontMetrics.lineSpacing ();

          // if the next textline would already be below the visible text area, stop drawing
          if ( (baseLine - fontMetrics.ascent()) > (theTextAreaRect.y() + theTextAreaRect.height()) ) {
            break;
          }
      }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *menu : menuToHide)
    {
        menu->menuAction()->setVisible(false);
    }
```

#### AUTO 


```{c}
auto *tool
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w : m_toolWidgets) {
      w->hide ();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : viewRegion)
      paintEventDrawDoc_Unclipped (r);
```

#### AUTO 


```{c}
auto dpiX = imageDotsPerMeterX / KP_INCHES_PER_METER;
```

#### AUTO 


```{c}
auto *horizontalSkewPixmapLabel = new QLabel (angleGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &node : d->colorList)
   {
       // Added for KolourPaint.
       if(!node.color.isValid ())
           continue;

       int r,g,b;
       node.color.getRgb(&r, &g, &b);
       str << r << " " << g << " " << b << " " << node.name << "\n";
   }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & it : mimeTypeList)
    {
        if (it.startsWith (mimeTypeColon))
        {
            int number = it.midRef (mimeTypeColon.length ()).toInt ();
            if (!colorDepthIsInvalid (number))
            {
                return number;
            }
        }
    }
```

#### AUTO 


```{c}
auto *fieldsLayout = new QVBoxLayout (fieldsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *tool : d->tools) {
      d->toolToolBar->registerTool(tool);
    }
```

#### AUTO 


```{c}
auto *directionLayout = new QGridLayout (directionGroupBox );
```

#### AUTO 


```{c}
auto *antiClockwisePixmapLabel = new QLabel (directionGroupBox);
```

#### AUTO 


```{c}
auto *originalDimensionsLabel = new QLabel (originalDimensions, m_dimensionsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto && i : m_deletedText)
    {
        if (i == '\n')
        {
            const QString rightHalf = textLines [m_row].mid (m_col);

            textLines [m_row].truncate (m_col);
            textLines.insert (textLines.begin () + m_row + 1, rightHalf);

            m_row++;
            m_col = 0;
        }
        else
        {
            const QString leftHalf = textLines [m_row].left (m_col);
            const QString rightHalf = textLines [m_row].mid (m_col);

            textLines [m_row] = leftHalf + i + rightHalf;
            m_col++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : QImageWriter::supportedMimeTypes()) {
      mimeTypes << QString::fromLatin1(type);
    }
```

#### AUTO 


```{c}
const auto *imageSel = dynamic_cast <const kpAbstractImageSelection *> (&sel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &dp : docPoints)
        imagePoints.append (dp - docRect.topLeft ());
```

#### AUTO 


```{c}
auto j = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QRect &r : viewRegion)
        paintEventDrawGridLines(&painter, r);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &type : QImageReader::supportedMimeTypes())
  {
    if ( !filter.isEmpty() ) {
      filter += QLatin1Char(' ');
    }

    QMimeType mime(db.mimeTypeForName(QString::fromLatin1(type)));
    if ( mime.isValid() )
    {
      QString glob = mime.globPatterns().join(QLatin1Char(' '));

      filter += glob;

      // I want to show the mime comment AND the file glob pattern,
      // but to avoid that the "All Supported Files" entry shows ALL glob patterns,
      // I must add the pattern here a second time so that QFileDialog::HideNameFilterDetails
      // can hide the first pattern and I still see the second one
      filterList << mime.comment() + QString(" (%1)(%2)").arg(glob).arg(glob);
    }
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : points)
    {
        for (int i = 0; i < 10; i++)
        {
            const int dx = (QRandomGenerator::global()->generate() % spraycanSize) - radius;
            const int dy = (QRandomGenerator::global()->generate() % spraycanSize) - radius;

            // Make it look circular.
            // TODO: Can be done better by doing a random vector angle & length
            //       but would sin and cos be too slow?
            if ((dx * dx) + (dy * dy) > (radius * radius)) {
                continue;
            }

            const QPoint p2 (p.x () + dx, p.y () + dy);

            painter.drawPoint(p2);
        }
    }
```

#### AUTO 


```{c}
auto *verticalSkewDegreesLabel = new QLabel (i18n ("degrees"), angleGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & url : urls)
    {
        open (url);
    }
```

#### AUTO 


```{c}
const auto docWidth = qRound (double (viewRect.width ()) * 100.0 / double (zoomLevelX ()));
```

#### AUTO 


```{c}
auto *cmd = new kpTransformResizeScaleCommand (
            dialog.actOnSelection (),
            dialog.imageWidth (), dialog.imageHeight (),
            dialog.type (),
            commandEnvironment ());
```

#### AUTO 


```{c}
auto *baseLayout = new QGridLayout (baseWidget);
```

#### AUTO 


```{c}
auto *baseWidget = new QWidget (this);
```

#### AUTO 


```{c}
auto *dialogLayout = new QVBoxLayout (this);
```

#### AUTO 


```{c}
const auto &dp
```

#### LAMBDA EXPRESSION 


```{c}
[this]{resizeScaleAndMove(false);}
```

#### AUTO 


```{c}
const auto alpha = static_cast<quint8> (qAlpha (rgb));
```

#### AUTO 


```{c}
auto *angleLayout = new QGridLayout (angleGroupBox );
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &linesList : d->fillLinesCache)
    {
        fillLinesCacheSize += ::FillLinesListSize (linesList);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]{slotDragScroll();}
```

#### AUTO 


```{c}
const auto repeat = 1;
```

#### AUTO 


```{c}
auto mt = mw * mh;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & it : mimeTypeList)
    {
        if (it.startsWith (mimeTypeColon))
        {
            int number = it.mid (mimeTypeColon.length ()).toInt ();
            if (!colorDepthIsInvalid (number))
            {
                return number;
            }
        }
    }
```

#### AUTO 


```{c}
auto *amountLabel = new QLabel (i18n ("&Amount:"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[saveOptionsWidget, &fd]() {
        saveOptionsWidget->setMimeType(fd.selectedMimeTypeFilter());
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &str : theTextLines)
        {
            if (row == i && !thePreeditText.isEmpty())
            {
                QString left = str.left(col);
                QString right = str.mid(col);
                int x = theTextAreaRect.x();
                painter.drawText(x, baseLine, left);
                x += fontMetrics.horizontalAdvance(left);
                drawPreeditString(painter, x, baseLine, thePreeditText);

                painter.drawText(x, baseLine, right);
            }
            else
            {
                painter.drawText(theTextAreaRect.x (), baseLine, str);
            }
            baseLine += fontMetrics.lineSpacing();
            i++;

            // if the next textline would already be below the visible text area, stop drawing
            if ( (baseLine - fontMetrics.ascent()) > (theTextAreaRect.y() + theTextAreaRect.height()) ) {
              break;
            }
        }
```

#### AUTO 


```{c}
auto dpiY = imageDotsPerMeterY / KP_INCHES_PER_METER;
```

#### AUTO 


```{c}
auto *actOnLabel = new QLabel (i18n ("Ac&t on:"), actOnBox);
```

#### AUTO 


```{c}
auto *oldSelection = m_selection;
```

#### AUTO 


```{c}
auto *contrastLabel = new QLabel (i18n ("Co&ntrast:"), this);
```

#### AUTO 


```{c}
auto *centerWidgetLay = new QVBoxLayout (centerWidget );
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto & color : colors)
    {
        addColor (color.toQColor ());
    }
```

#### AUTO 


```{c}
auto height = img.height();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &node : d->colorList)
   {
       // Added for KolourPaint.
       if ( !node.color.isValid() )
           continue;

       int r, g, b, a;
       node.color.getRgb(&r, &g, &b, &a);
       str << r << " " << g << " " << b << " " << a << " " << node.name << "\n";
   }
```

#### AUTO 


```{c}
auto *c = dynamic_cast <kpToolSelectionCreateCommand *> (cmd);
```

#### AUTO 


```{c}
auto *fieldsGroupBox = new QGroupBox (i18n ("&Text Fields"),
        baseWidget);
```

#### AUTO 


```{c}
auto skewRect = skewMatrix.mapRect (doc->rect (m_actOnSelection));
```

#### AUTO 


```{c}
auto x2y1 = m_pToneMaps[m_nToneMapGranularity * v + u + 1][oldTone];
```

#### AUTO 


```{c}
const auto image = imageSel->baseImage ();
```

#### AUTO 


```{c}
auto *lay = new QVBoxLayout (this);
```

#### AUTO 


```{c}
auto *dimensionsLayout = new QGridLayout (dimensionsGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &colName : ::KDEColorCollectionNames ()) {
        d->actionColorsKDE->addAction (colName);
    }
```

#### AUTO 


```{c}
auto *valueLabel = new QLabel (i18nc ("The V of HSV", "&Value:"), this);
```

#### AUTO 


```{c}
auto applied = static_cast<quint8> (brightnessContrastGamma (i, brightness, contrast, gamma));
```

#### AUTO 


```{c}
auto *win = new kpMainWindow (doc);
```

#### AUTO 


```{c}
const auto img_format = img.format();
```

#### AUTO 


```{c}
auto *buttonGroup = new QButtonGroup (this);
```

#### AUTO 


```{c}
auto *dpiLay = new QGridLayout(dpiGroupBox);
```

#### AUTO 


```{c}
auto *pToneMap = new unsigned int[TONE_MAP_SIZE];
```

#### AUTO 


```{c}
const auto &key
```

#### AUTO 


```{c}
auto *verticalSkewPixmapLabel = new QLabel (angleGroupBox);
```

#### AUTO 


```{c}
const auto selectionHadContent = m_selection->hasContent ();
```

#### AUTO 


```{c}
const auto &seq
```

#### AUTO 


```{c}
auto *offsetGroupBox = new QGroupBox(i18n ("O&ffset"), baseWidget);
```

#### AUTO 


```{c}
auto *dlg = new KShortcutsDialog(KShortcutsEditor::AllActions, KShortcutsEditor::LetterShortcutsAllowed, this);
```

#### AUTO 


```{c}
const auto & color
```

#### AUTO 


```{c}
auto x2y2 = m_pToneMaps[m_nToneMapGranularity * (v + 1) + u + 1][oldTone];
```

#### AUTO 


```{c}
auto *imageSel = dynamic_cast <kpAbstractImageSelection *> (m_fromSelection);
```

#### AUTO 


```{c}
auto *brightnessResetPushButton = new QPushButton (i18n ("Re&set"), this);
```

#### AUTO 


```{c}
auto *seconds = new KPluralHandlingSpinBox;
```

#### AUTO 


```{c}
auto *textSel = dynamic_cast <kpTextSelection *> (m_fromSelection);
```

#### AUTO 


```{c}
auto j = mx;
```

#### AUTO 


```{c}
auto *win = new kpMainWindow (nullptr/*no document*/);
```

#### AUTO 


```{c}
auto *lay = new QHBoxLayout (this);
```

#### AUTO 


```{c}
const auto *originalTextSel = dynamic_cast <const kpTextSelection *>
                (originalSelection ());
```

#### AUTO 


```{c}
auto *newLabel = new QLabel (i18n ("&New:"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *horizontalSkewDegreesLabel = new QLabel (i18n ("degrees"), angleGroupBox);
```

#### AUTO 


```{c}
auto *originalLabel = new QLabel (i18n ("Original:"), m_dimensionsGroupBox);
```

#### AUTO 


```{c}
auto *inputLayout = new QVBoxLayout (inputGroupBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : rects)
    {
        paintEventDrawDoc_Unclipped (r);
    }
```

#### AUTO 


```{c}
auto mh = (radius << 1) + 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attr : event->attributes ())
    {
        switch (attr.type)
        {
        case QInputMethodEvent::TextFormat:
            m_textFormatList.append (attr);
            break;
        case QInputMethodEvent::Cursor:
            m_cursorPosition = attr.start;
            if (attr.length > 0)
            {
                m_cursorColor = attr.value.value<QColor> ();
            }
            break;
        case QInputMethodEvent::Selection:
            m_selectionStart = attr.start;
            m_selectionLength = attr.length;
            break;
        default:
            break;
        }
    }
```

#### AUTO 


```{c}
auto *pack = static_cast <WashPack *> (data);
```

#### AUTO 


```{c}
const auto &linesList
```

#### AUTO 


```{c}
auto v = y * (nGranularity - 1) / pImage->height();
```

#### AUTO 


```{c}
auto imageDotsPerMeterX = double (d->document->metaInfo ()->dotsPerMeterX ());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *w : m_toolWidgets)
    {
      m_baseLayout->addWidget(w,
          0/*stretch*/,
          o == Qt::Vertical ? Qt::AlignHCenter : Qt::AlignVCenter);
    }
```

#### AUTO 


```{c}
auto && i
```

#### AUTO 


```{c}
auto skewMatrix = kpPixmapFX::skewMatrix (doc->image (),
                                                  horizontalAngleForPixmapFX (),
                                                  verticalAngleForPixmapFX ());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : selResizeHandlesRegion.rects()) {
      painter.drawRect(r);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &path : paths) {
    paletteList.append(QDir(path).entryList(QStringList(), QDir::Files));
  }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto && i : m_deletedText)
    {
        if (i == '\n')
        {
            const QString rightHalf = textLines [m_row].mid (m_col);

            textLines [m_row].truncate (m_col);
            textLines.insert (textLines.begin () + m_row + 1, rightHalf);
        }
        else
        {
            const QString leftHalf = textLines [m_row].left (m_col);
            const QString rightHalf = textLines [m_row].mid (m_col);

            textLines [m_row] = leftHalf + i + rightHalf;
        }
    }
```

#### AUTO 


```{c}
auto *borderImageSel = dynamic_cast <kpAbstractImageSelection *> (
            mainWindow->document ()->selection ()->clone ());
```

#### AUTO 


```{c}
const auto *button
```

#### AUTO 


```{c}
auto *contrastResetPushButton = new QPushButton (i18n ("&Reset"), this);
```

#### AUTO 


```{c}
auto b{0};
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : m_copyOntoDocumentPoints)
        {
            sel->moveTo (p);
            doc->selectionCopyOntoDocument ();
        }
```

#### AUTO 


```{c}
auto *directionGroupBox = new QGroupBox (i18n ("Direction"), mainWidget ());
```

#### AUTO 


```{c}
const auto &str
```

#### AUTO 


```{c}
const auto sigma = 1.0;
```

#### AUTO 


```{c}
auto *brightnessLabel = new QLabel (i18n ("&Brightness:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &u : urls)
            open (u);
```

#### AUTO 


```{c}
auto *maskBitmap = new unsigned char [byteSize];
```

#### AUTO 


```{c}
const auto &path
```

#### AUTO 


```{c}
auto *hideWindow = new QCheckBox(i18n("Hide Main Window"));
```

#### AUTO 


```{c}
auto topLeft = toGlobal (widget, rect.topLeft ());
```

#### AUTO 


```{c}
auto *afterTransformLabel = new QLabel (m_afterActionText, m_dimensionsGroupBox);
```

#### AUTO 


```{c}
auto topLeft = fromGlobal (widget, rect.topLeft ());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : noDups)
    {
        if (!cardPoints.isEmpty () &&
            !kpPainter::pointsAreCardinallyAdjacent (p, cardPoints.last ()))
        {
            const QPoint lastPoint = cardPoints.last ();

            QList <QPoint> interpPoints = kpPainter::interpolatePoints (
                lastPoint,
                p,
                true/*cardinal adjacency*/);

            Q_ASSERT (interpPoints.size () >= 2);
            Q_ASSERT (interpPoints [0] == lastPoint);
            Q_ASSERT (interpPoints.last () == p);

            for (int i = 1/*skip already existing point*/;
                 i < interpPoints.size ();
                 i++)
            {
                cardPoints.append (interpPoints [i]);
            }
        }
        else {
            cardPoints.append (p);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &str : theTextLines)
        {
            if (row == i && !thePreeditText.isEmpty())
            {
                QString left = str.left(col);
                QString right = str.mid(col);
                int x = theTextAreaRect.x();
                painter.drawText(x, baseLine, left);
                x += fontMetrics.width(left);
                drawPreeditString(painter, x, baseLine, thePreeditText);

                painter.drawText(x, baseLine, right);
            }
            else
            {
                painter.drawText(theTextAreaRect.x (), baseLine, str);
            }
            baseLine += fontMetrics.lineSpacing();
            i++;

            // if the next textline would already be below the visible text area, stop drawing
            if ( (baseLine - fontMetrics.ascent()) > (theTextAreaRect.y() + theTextAreaRect.height()) ) {
              break;
            }
        }
```

#### AUTO 


```{c}
const auto &attr
```

#### AUTO 


```{c}
auto *kmw
```

#### AUTO 


```{c}
const auto docHeight = qRound (double (viewRect.height ()) * 100.0 / double (zoomLevelY ()));
```

#### AUTO 


```{c}
const auto & url
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *cmd : m_commandList)
    {
        qCDebug(kpLogCommands) << "\t\tcurrentSize=" << s << " + "
                   << cmd->name () << ".size=" << cmd->size ();
        s += cmd->size ();
    }
```

#### AUTO 


```{c}
const auto &line
```

#### AUTO 


```{c}
auto * buttons = new QDialogButtonBox (QDialogButtonBox::Ok |
                                                       QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
const auto *tool = dynamic_cast<const kpTool *>(sender());
```

#### AUTO 


```{c}
const auto viewY = vuc->transformDocToViewY (targetDocY);
```

#### AUTO 


```{c}
const auto &node
```

#### AUTO 


```{c}
auto *imageSel = imageSelection ();
```

#### AUTO 


```{c}
auto *containerLayout = new QHBoxLayout (effectContainer);
```

#### AUTO 


```{c}
auto *action = ac->add<KToggleAction>(QStringLiteral("settings_draw_antialiased"));
```

#### AUTO 


```{c}
auto *cmd
```

#### AUTO 


```{c}
auto ret = 0;
```

#### AUTO 


```{c}
auto *environ = mainWindow->commandEnvironment ();
```

#### AUTO 


```{c}
auto *widthLabel = new QLabel (i18n ("Width:"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto width = img.width();
```

#### AUTO 


```{c}
auto *hueLabel = new QLabel (i18n ("&Hue:"), this);
```

#### AUTO 


```{c}
const auto green = static_cast<quint8> (qGreen (rgb));
```

#### AUTO 


```{c}
const auto viewX = vuc->transformDocToViewX (targetDocX);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *b : m_toolButtons) {
        b->setIconSize(size);
    }
```

#### AUTO 


```{c}
auto *horizontalSkewLabel = new QLabel (i18n ("&Horizontal:"), angleGroupBox);
```

#### AUTO 


```{c}
auto *resizeScaleButtonGroup = new QButtonGroup (baseWidget);
```

#### AUTO 


```{c}
auto *imageSel = dynamic_cast <kpAbstractImageSelection *> (sel);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &line : d->fillLinesCache [y])
    {
        if (x >= line.m_x1 && x <= line.m_x2)
        {
            if (beenHere) {
                *beenHere = true;
            }
            return d->color;
        }
    }
```

#### AUTO 


```{c}
const auto red = static_cast<quint8> (qRed (rgb));
```

#### AUTO 


```{c}
const auto totalMarginsWidth = fontMetrics ().height ();
```

#### AUTO 


```{c}
auto *label = new QLabel(i18n("Snapshot Delay"));
```

#### AUTO 


```{c}
auto *win = new kpMainWindow ();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *tool : d->tools)
    {
      kpToolAction *action = tool->action();
      if (!enable && action->isChecked()) {
          action->setChecked(false);
      }

      action->setEnabled(enable);
    }
```

#### AUTO 


```{c}
auto *dialog = new QDialog(this);
```

#### AUTO 


```{c}
auto *operationLayout = new QGridLayout (operationGroupBox );
```

#### AUTO 


```{c}
const auto &type
```

#### AUTO 


```{c}
auto total = m_pHistogram[i - 1];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &p : points)
    {
        for (int i = 0; i < 10; i++)
        {
            const int dx = (KRandom::random () % spraycanSize) - radius;
            const int dy = (KRandom::random () % spraycanSize) - radius;

            // Make it look circular.
            // TODO: Can be done better by doing a random vector angle & length
            //       but would sin and cos be too slow?
            if ((dx * dx) + (dy * dy) > (radius * radius)) {
                continue;
            }

            const QPoint p2 (p.x () + dx, p.y () + dy);

            painter.drawPoint(p2);
        }
    }
```

#### AUTO 


```{c}
auto x1y2 = m_pToneMaps[m_nToneMapGranularity * (v + 1) + u][oldTone];
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &attr : preeditText.textFormatList ())
    {
        int start = attr.start;
        int length = attr.length;
        QTextCharFormat format = qvariant_cast<QTextFormat> (attr.value).toCharFormat ();

        if (i > start)
        {
            length = length - i + start;
            start = i;
        }
        if (length <= 0) {
            continue;
        }

        if (i < start)
        {
            str = preeditString.mid (i, start - i);
            painter.drawText (x, y, str);
            x += painter.fontMetrics ().width (str);
        }

        painter.save();
        str = preeditString.mid (start, length);
        int width = painter.fontMetrics().width (str);
        if (format.background ().color () != Qt::black)
        {
            painter.save ();
            painter.setPen (format.background ().color ());
            painter.setBrush (format.background());
            painter.drawRect (x, y - painter.fontMetrics ().ascent (), width, painter.fontMetrics ().height ());
            painter.restore ();
        }
        if (format.foreground ().color () != Qt::black)
        {
            painter.setBrush (format.foreground ());
            painter.setPen (format.foreground ().color ());
        }
        if (format.underlineStyle ())
        {
            painter.drawLine (x, y + painter.fontMetrics ().descent (), x + width, y + painter.fontMetrics ().descent ());
        }
        painter.drawText (x, y, str);

        x += width;
        painter.restore ();

        i = start + length;
    }
```

#### AUTO 


```{c}
auto *degreesLabel = new QLabel (i18n ("degrees"), angleGroupBox);
```

#### AUTO 


```{c}
auto my = y - radius;
```

#### AUTO 


```{c}
auto *updatePushButton = new QPushButton (i18n ("&Update"), cubeGroupBox);
```

#### AUTO 


```{c}
auto *clockwisePixmapLabel = new QLabel (directionGroupBox);
```

#### AUTO 


```{c}
auto *lay = new QGridLayout ( baseWidget );
```

#### AUTO 


```{c}
auto *macroCmd = new kpMacroCommand (commandName, environ);
```

#### AUTO 


```{c}
auto u = x * (nGranularity - 1) / pImage->width();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &r : rects)
        paintEventDrawGridLines(&painter, r);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *kmw : KMainWindow::memberList ())
    {
        Q_ASSERT (dynamic_cast <kpMainWindow *> (kmw));
        auto *mw = dynamic_cast <kpMainWindow *> (kmw);

    #if DEBUG_KP_MAIN_WINDOW
        qCDebug(kpLogMainWindow) << "\t\tmw=" << mw;
    #endif

        if (mw != this)
        {
            // WARNING: Do not use KRecentFilesAction::setItems()
            //          - it does not work since only its superclass,
            //          KSelectAction, implements setItems() and can't
            //          update KRecentFilesAction's URL list.

            // Avoid URL memory leak in KRecentFilesAction::loadEntries().
            mw->d->actionOpenRecent->clear ();

            mw->d->actionOpenRecent->loadEntries (cfg->group (kpSettingsGroupRecentFiles));
        #if DEBUG_KP_MAIN_WINDOW
            qCDebug(kpLogMainWindow) << "\t\t\tcheck recent URLs="
                        << mw->d->actionOpenRecent->items ();
        #endif
        }
    }
```

#### AUTO 


```{c}
auto *gammaResetPushButton = new QPushButton (i18n ("Rese&t"), this);
```

#### AUTO 


```{c}
auto *angleLayout = new QGridLayout (angleGroupBox);
```

#### AUTO 


```{c}
auto *cubeGroupBox = new QGroupBox (i18n ("Preview"), baseWidget);
```

#### AUTO 


```{c}
auto *previewLayout = new QVBoxLayout (m_previewGroupBox);
```

#### AUTO 


```{c}
auto *xLabel0 = new QLabel (i18n ("x"), dimensionsGroupBox);
```

#### AUTO 


```{c}
auto imageDotsPerMeterY = double (d->document->metaInfo ()->dotsPerMeterY ());
```

#### AUTO 


```{c}
auto *textSel = dynamic_cast <kpTextSelection *> (m_oldSelectionPtr);
```

#### AUTO 


```{c}
const auto *b
```

#### AUTO 


```{c}
auto y = 0;
```

#### AUTO 


```{c}
auto hFac = x - (u * (pImage->width() - 1) / (nGranularity - 1));
```

#### AUTO 


```{c}
auto *vbox = new QVBoxLayout(dialog);
```

#### AUTO 


```{c}
auto *imageSel = dynamic_cast <kpAbstractImageSelection *> (m_originalSelectionPtr);
```

#### AUTO 


```{c}
auto *spaceWidget = new QLabel (this);
```

#### AUTO 


```{c}
auto h = m_typeLabel->sizeHint ().height ();
```

#### AUTO 


```{c}
const auto contentsWidth = 180;
```

#### AUTO 


```{c}
auto *pack = static_cast <kpToolWidgetEraserSize::DrawPackage *> (userData);
```

#### AUTO 


```{c}
auto *colorBitmap = new unsigned char [byteSize];
```

#### AUTO 


```{c}
const auto boundingRect = m_selection->boundingRect ();
```

#### AUTO 


```{c}
auto *cubeLayout = new QVBoxLayout (cubeGroupBox);
```

#### AUTO 


```{c}
auto *saveOptionsWidget =
        new kpDocumentSaveOptionsWidget (imageToBeSaved,
            fdSaveOptions,
            docMetaInfo,
            this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &l : d->fillLines)
    {
      if ( l.m_x1 == l.m_x2 ) {
        painter.drawPoint(l.m_x1, l.m_y);
      }
      else {
        painter.drawLine(l.m_x1, l.m_y, l.m_x2, l.m_y);
      }
    }
```

#### AUTO 


```{c}
auto *optionsPage = new kpPrintDialogPage (this);
```

#### AUTO 


```{c}
auto a{0};
```

#### AUTO 


```{c}
auto *action = ac->add<KToggleAction>("settings_draw_antialiased");
```

