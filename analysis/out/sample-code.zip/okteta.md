#### AUTO 


```{c}
auto* structs = new StructureDataInformation(QStringLiteral("vals"), structsChildren);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(dirtyColumns)) {
                    const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(firstChangedPositions);

                    q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr char SubstituteMissingCharsConfigKey[] = "SubstituteMissingChars";
```

#### AUTO 


```{c}
auto* algorithmLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* top = new TopLevelDataInformation(dataInf, logger, engine, fileInfo);
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractDocument* document) { onDocumentLoaded(document); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : std::as_const(mChildren)) {
        child->resetValidationState();
    }
```

#### AUTO 


```{c}
auto* baseWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto* hbox = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:listbox algorithm to use for the checksum", "Algorithm:"), this);
```

#### CONST EXPRESSION 


```{c}
static constexpr char CountConfigKey[] = "Count";
```

#### AUTO 


```{c}
auto* optionsLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractModelDataGeneratorConfigEditorFactory* factory : mGeneratorFactoryList )
    {
        result = factory->tryCreateConfigEditor( generator );
        if( result )
            break;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        mViewList.removeOne(view);
    }
```

#### AUTO 


```{c}
auto* document = new Kasten::ByteArrayDocument(QStringLiteral("New created for test."));
```

#### AUTO 


```{c}
auto* displayBoxFormLayout = new QFormLayout(displayBox);
```

#### CONST EXPRESSION 


```{c}
constexpr int endOfFileByteCount = 0;
```

#### LAMBDA EXPRESSION 


```{c}
[&]( int index ) { onCurrentChanged( index ); }
```

#### AUTO 


```{c}
auto* vectorBytes = reinterpret_cast<Okteta::Byte*>(this->mData.data());
```

#### AUTO 


```{c}
auto* layoutBoxFormLayout = new QFormLayout(layoutBox);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultMinLength = 3;
```

#### AUTO 


```{c}
auto* exportButton = new QPushButton(QIcon::fromTheme(QStringLiteral("document-export")),
                                                i18nc("@action:button", "&Export to File..."));
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayChange& change : changes )
    {
        const ArrayChangeMetrics& metrics = change.metrics();
        switch( metrics.type() )
        {
        case ArrayChangeMetrics::Replacement:
        {
            const int oldSize = mPieceTable.size();
            const AddressRange removeRange = AddressRange::fromWidth( metrics.offset(), metrics.removeLength() );
            // check parameters
            if( removeRange.startsBehind(oldSize-1) && (removeRange.width()>0) ) 
            {
                // something is not matching
                ; // TODO: set flag to undo all changes
            }

            const QByteArray& insertData = change.data();
            doReplaceChange( removeRange, reinterpret_cast<const Byte*>(insertData.constData()), insertData.size() );
            break;
        }
        case ArrayChangeMetrics::Swapping:
        {
            const AddressRange secondRange( metrics.secondStart(), metrics.secondEnd() );
            doSwapChange( metrics.offset(), secondRange );
            break;
        }
        default:
            ;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type](DataInformation* data) {
        QVERIFY(data->isPrimitive());
        QCOMPARE(data->asPrimitive()->type(), type);
    }
```

#### AUTO 


```{c}
auto* byteArrayFrameRenderer = new ByteArrayFrameRenderer;
```

#### AUTO 


```{c}
const auto* data = static_cast<const DataInformation*>(index.internalPointer());
```

#### AUTO 


```{c}
auto* nameLabel = new QLabel(nameMarkup);
```

#### AUTO 


```{c}
auto* printer = new QPrinter;
```

#### AUTO 


```{c}
const auto& encodingData
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractColumnTextRenderer* renderer : std::as_const(columnTextRendererList)) {
            renderer->renderNextLine(&textStream, isSubline);
        }
```

#### AUTO 


```{c}
auto* checkBox = static_cast<QCheckBox*>(widgets[0]);
```

#### CONST EXPRESSION 


```{c}
static constexpr int addressLineSize = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : qAsConst(mChildren)) {
        child->setParent(this);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( TabbedViews* viewArea : qAsConst(mViewAreaList) )
    {
        const int localIndex = viewArea->indexOf( view );
        if( localIndex != -1 )
        {
            viewArea->setViewFocus( view );
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Bookmark& bookmark : qAsConst(bookmarkList) )
        QCOMPARE( bookmark.offset(), *oit++ );
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : qAsConst(mAlternatives)) {
        for (int i = 0; i <  fi.fields.size(); ++i) {
            fi.fields.at(i)->setParent(this);
        }
    }
```

#### AUTO 


```{c}
auto* manager = new KColorSchemeManager(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int recordTypeLineOffset = addressLineOffset + addressLineSize;
```

#### AUTO 


```{c}
auto* createButton = // copy from selected
                         new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& valueCodecDescription : valueCodecDescriptions) {
        for (int b = 0; b < 256; ++b) {
            for (uint r = 1; r <= valueCodecDescription.encodingWidth; ++r) {
                const QString rowTitle =
                    QLatin1String(valueCodecDescription.name) +
                    QStringLiteral(" - %1 - removed last %2").arg(b).arg(r);

                QTest::newRow(rowTitle.toLatin1().constData())
                    << valueCodecDescription.id
                    << Byte(b)
                    << r;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& fileName : filesInDir) {
        if (!localDir.remove(fileName)) {
            qWarning("%s: removing failed", qPrintable(fileName));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : qAsConst(columnRenderers)) {
                columnRenderer->renderColumn(painter, renderedXs, renderedYs);
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr char AlignAtEndConfigKey[] = "AlignAtEnd";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* other : others) {
        if (other == data) {
            return index;
        }
        index++;
    }
```

#### AUTO 


```{c}
auto* topLineLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* ret = new UIntSpinBox(parent, Kasten::StructureViewPreferences::unsignedDisplayBase());
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelDataGenerator* generator : generatorList) {
            const QString title = generator->typeName();
            const QString iconName = QStringLiteral("document-new");  // generator->iconName();

            QAction* action = new QAction(QIcon::fromTheme(iconName), title, this);
            action->setData(QVariant::fromValue(generator));
            connect(action, &QAction::triggered,
                    this, &CreatorController::onNewFromGeneratorActionTriggered);

            newMenuAction->addAction(action);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Bookmark& bookmark : bookmarks) {
        addBookmark(bookmark);
    }
```

#### AUTO 


```{c}
auto isProfileToRemove = [&removedViewProfileIds](const ByteArrayViewProfile& profile) {
            return removedViewProfileIds.contains(profile.id());
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(dirtyColumns)) {
                    const PixelXRange xPixels = column->xsOfLinePositionsInclSpaces(changedPositions);

                    q->viewport()->update(xPixels.start() - xOffset, cy, xPixels.width(), lineHeight);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr char MoveBitWidthConfigKey[] = "MoveBitWidth";
```

#### RANGE FOR STATEMENT 


```{c}
for( const Piece& piece : mList )
    {
        dataRange.setEndByWidth( piece.width() );

        if( dataRange.includes(dataOffset) )
        {
            *storageId = piece.storageId();
// qCDebug(LOG_OKTETA_CORE) <<piece.start()<<"+"<<dataRange.localIndex( dataOffset );
            *storageOffset = piece.start() + dataRange.localIndex( dataOffset );
            result = true;
            break;
        }
        dataRange.setStart( dataRange.nextBehindEnd() );
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char VariableNameConfigKey[] = "VariableName";
```

#### LAMBDA EXPRESSION 


```{c}
[&]( const QString& title ) { onTitleChanged( title ); }
```

#### AUTO 


```{c}
auto* dialog = new CopyAsDialog(encoder->remoteTypeName(), configEditor, encoder,
                                                QApplication::activeWindow());
```

#### CONST EXPRESSION 


```{c}
static constexpr char CharsetConversionConfigGroupId[] = "CharsetConversionTool";
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultBitNumber = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : selected) {
        delete mTreeSelected->takeTopLevelItem(
            mTreeSelected->indexOfTopLevelItem(item));
        changed = true;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int fillerDataSize = sizeof(fillerData) / sizeof(fillerData[0]);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        QBitArray validnessPerDigitField = QBitArray(digitCount, false);
        const QByteArray validDigits =
            QByteArray(valueCodecDescription.validDigits);

        for (int j = 0; j < validDigits.count(); ++j) {
            validnessPerDigitField.setBit(validDigits[j], true);
        }

        for (int j = 0; j < validnessPerDigitField.count(); ++j) {
            const uchar digit = uchar(j);
            const bool isValid = validnessPerDigitField.testBit(j);
            const QString rowTitle =
                QLatin1String(valueCodecDescription.name) +
                QString(QStringLiteral(" - \"%1\" is ")).arg(QLatin1Char(digit)) +
                (isValid ? QStringLiteral("valid") : QStringLiteral("invalid"));

            QTest::newRow(rowTitle.toLatin1().constData())
                << valueCodecDescription.id
                << digit
                << isValid;
        }
    }
```

#### AUTO 


```{c}
const auto* rotateParameterSet = static_cast<const RotateByteArrayFilterParameterSet*>(parameterSet);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayUuencodingStreamEncoderConfigGroupId[] = "ByteArrayUuencodingStreamEncoder";
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : qAsConst(mList) )
    {
        if( ( document != keptDocument ) &&
            ! mSyncManager->canClose(document) )
        {
            canCloseAll = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto* box = new KComboBox(false, parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& encodingData : encodingDataList) {
        if (codecName.compare(encodingData.name) == 0) {
            result = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Person& user : users )
        mUserList.removeOne( user );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kasten::StructureDefinitionFile* def : structureDefs) {
        KPluginInfo info = def->pluginInfo();
        if (info.isPluginEnabled()) {
            newVals.append(QStringLiteral("\'%1\':\'*\'").arg(info.pluginName()));
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](ContentFlags contentFlags) { onContentFlagsChanged(contentFlags); }
```

#### AUTO 


```{c}
auto* edit = qobject_cast<QLineEdit*> (w);
```

#### CONST EXPRESSION 


```{c}
static constexpr int xxInputGroupLength = 3;
```

#### AUTO 


```{c}
auto* noneAction = new QAction(i18nc("@item There are no encoders.", "Not available."), mCopyAsSelectAction);
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : views )
        mViewList.removeOne( view );
```

#### AUTO 


```{c}
auto* part = new OktetaPart(parent, metaData(), modus, mByteArrayViewProfileManager, mModelCodecManager, mModelCodecViewManager);
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultUnsignedAsHexadecimal = true;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& codecName : CharCodec::codecNames()) {
        for (int i = 0; i < 256; ++i) {
            const QString rowTitle = codecName + QStringLiteral(" - %1").arg(i);
            QTest::newRow(rowTitle.toLatin1().constData()) << codecName << i;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char NotExistingFileName[] = "not.existing";
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : qAsConst(closedDocuments)) {
        delete document;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[type](DataInformation* data) {
        QVERIFY(data->isPrimitive());
        QCOMPARE(data->asBitfield()->bitfieldType(), type);
    }
```

#### AUTO 


```{c}
auto it = std::find(addressSizeConfigValueList.cbegin(), addressSizeConfigValueList.cend(), entry);
```

#### AUTO 


```{c}
auto* pageLayout = new QFormLayout(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr char startCode = 'S';
```

#### AUTO 


```{c}
auto* displayBox = new QGroupBox(this);
```

#### AUTO 


```{c}
auto* tapAndHoldGesture = static_cast<TouchOnlyTapAndHoldGesture*>(gestureEvent->gesture(touchOnlyTapAndHoldGestureType()))
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& encodingData : encodingDataList) {
            bool isCodecFound = false;
            const QString codecName = QString::fromLatin1(encodingData.name);
            QTextCodec* codec = charsets->codecForName(codecName, isCodecFound);
            if (isCodecFound) {
                textCodecNames.append(QString::fromLatin1(codec->name()));
            }
        }
```

#### AUTO 


```{c}
const auto last = static_cast<unsigned char>(result[r - 1]);
```

#### CONST EXPRESSION 


```{c}
static constexpr int StorageOffset = 20;
```

#### CONST EXPRESSION 


```{c}
constexpr bool operator>=(const Coord& other) const;
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : bookmarkIndizes) {
        Q_EMIT dataChanged(index(row, OffsetColumnId), index(row, TitleColumnId));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : loadedDocuments) {
        if (url == urlOf(document)) {
            // TODO: query if file should be reloaded/synched from disk
            Q_EMIT mManager->focusRequested(document);
            return;
        }
    }
```

#### AUTO 


```{c}
auto* mouseEvent = static_cast<QMouseEvent*>(event);
```

#### AUTO 


```{c}
const auto byteOrder = static_cast<QSysInfo::Endian>(byteOrderValue);
```

#### AUTO 


```{c}
auto* change1 = new TestPieceTableChange(type1Id, description1);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& data : testData) {
        QTest::newRow(QString(data.name+QLatin1String("-forward-frombegin")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(0) << false << QVector<Kasten::ReplaceBehaviour>();
        QTest::newRow(QString(data.name+QLatin1String("-backward-fromend")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(data.originalData.length()) << true << QVector<Kasten::ReplaceBehaviour>();
        QTest::newRow(QString(data.name+QLatin1String("-forward-frommiddle")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(4) << false << QVector<Kasten::ReplaceBehaviour>();
        QTest::newRow(QString(data.name+QLatin1String("-backward-frommiddle")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(3) << true << QVector<Kasten::ReplaceBehaviour>();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
    {
        while( it.hasNext() )
        {
            AbstractView* view = it.next();
            AbstractDocument* documentOfView = view->findBaseModel<AbstractDocument*>();
            if( documentOfView == document )
            {
                it.remove();
                closedViews.append( view );
            }
        }
        it.toFront();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestFileName[] = "test.data";
```

#### CONST EXPRESSION 


```{c}
static constexpr char UnsignedAsHexadecimalConfigKey[] = "UnsignedAsHexadecimal";
```

#### AUTO 


```{c}
auto* bitField
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool hasFocus) { onViewFocusChanged(hasFocus); }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultBinaryGapWidth = 1;
```

#### AUTO 


```{c}
auto* groupChange = new GroupPieceTableChange(mActiveGroupChange, description);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* codec : std::as_const(mValueCodec)) {
        delete codec;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultViewProfileNoOfBytesPerLine =  16;
```

#### AUTO 


```{c}
auto* dockWidget = qobject_cast<ToolViewDockWidget*>(q->sender());
```

#### AUTO 


```{c}
auto* part = factory->create<KParts::ReadOnlyPart>(nullptr, nullptr);
```

#### AUTO 


```{c}
auto* versionable = qobject_cast<Versionable*>(mView->byteArrayModel());
```

#### AUTO 


```{c}
auto job = new Kasten::ReplaceJob(view, byteArray, queryAgent);
```

#### CONST EXPRESSION 


```{c}
static constexpr int InvalidVersionIndex = -1;
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultViewModus = 0;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : allViews) {
        auto* document = view->findBaseModel<AbstractDocument*>();
        QHash<AbstractDocument*, QVector<AbstractView*>>::Iterator it =
            viewsToClosePerDocument.find(document);

        if (it != viewsToClosePerDocument.end()) {
            const QVector<AbstractView*>& viewsOfDocument = it.value();
            const bool isAnotherView = !viewsOfDocument.contains(view);
            if (isAnotherView) {
                viewsToClosePerDocument.erase(it);
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char* typeNames[static_cast<int>(PrimitiveDataType::END) + 1] = {
    "bool8",
    "int8",
    "uint8",
    "char",
    "bool16",
    "int16",
    "uint16",
    "bool32",
    "int32",
    "uint32",
    "bool64",
    "int64",
    "uint64",
    "float",
    "double",
    "bitfield",
};
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(d->columns)) {
            if (column->isVisible() && column->overlaps(dirtyXs)) {
                dirtyColumns.append(column);
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char OperandConfigKey[] = "Operand";
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractFrameRenderer *frameRenderer : qAsConst(mFrameRendererList) )
        {
            const int x = frameRenderer->x();
            const int y = frameRenderer->y();
            painter.translate( x, y );
            frameRenderer->renderFrame( &painter, pageIndex );
            painter.translate( -x, -y );
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char PatternConfigKey[] = "Pattern";
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayPatternGeneratorConfigGroupId[] = "ByteArrayPatternGenerator";
```

#### AUTO 


```{c}
auto* uInt8Editor = qobject_cast<UIntSpinBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& info : qAsConst(altInfo)) {
            qDeleteAll(info.fields);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : std::as_const(allData)) {
        QString codeStr = QStringLiteral("%1.setValidation(") + validationFunction() + QStringLiteral(");");
        QTest::newRow((data.tag + "-setUpdate()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("%1.set({validationFunc: ") + validationFunction() + QStringLiteral("});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1; obj.validationFunc = ") + validationFunction() + QStringLiteral("; obj;");
        QTest::newRow((data.tag + "-property assign").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto columnRenderer : qAsConst(columnRenderers)) {
                columnRenderer->renderColumn(painter, renderedXs, renderedYs);
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr char xxencodeMap[64] = {
    '+', '-', '0', '1', '2', '3', '4', '5',
    '6', '7', '8', '9', 'A', 'B', 'C', 'D',
    'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
    'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
    'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b',
    'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
    's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const StructureEnabledData& enabledData : enabledList) {
        if (enabledData.structure == QLatin1String("*")) {
            // add all of them
            StructureDefinitionFile* def = structureDefs.value(enabledData.id);
            if (!def) {
                continue;
            }
            const auto structureNames = def->structureNames();
            const bool isOnlyOne = (structureNames.size() == 1);
            for (const QString& structure : structureNames) {
                appendEnabledStructureItem(enabledData.id, structure, isOnlyOne);
            }
        } else {
            appendEnabledStructureItem(enabledData.id, enabledData.structure, false);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& path) { onFileDeleted(path); }
```

#### LAMBDA EXPRESSION 


```{c}
[Range, ChangedRange](const CoordRange& changedRange) mutable {
        if (changedRange.overlaps(Range)) {
            *ChangedRange = changedRange;
            return true;
        }
        return false;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestData1[] = "TestData1";
```

#### AUTO 


```{c}
auto* document = new ByteArrayDocument(QStringLiteral("New created for test."));
```

#### RANGE FOR STATEMENT 


```{c}
for( const QModelIndex& index : selectedRows )
    {
        const Okteta::Bookmark& bookmark = mBookmarkListModel->bookmark( index );
        bookmarksToBeDeleted.append( bookmark );
    }
```

#### AUTO 


```{c}
const auto digit = static_cast<uchar>(j);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : loadedDocuments) {
        const int indexInTitle =  document->title().indexOf(searchTerm);
        if (indexInTitle < 0) {
            continue;
        }

        RemoteMatch m;
        m.id = document->id();
        m.text = document->title();
        m.iconName = QStringLiteral("okteta");
        m.type = Plasma::QueryMatch::ExactMatch;
        m.relevance = (indexInTitle == 0) ? 0.8 : 0.3; // TODO: which values make sense here?
        matches << m;
    }
```

#### AUTO 


```{c}
auto* part = factory->create<KParts::ReadOnlyPart>(nullptr, nullptr, QVariantList());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dataFolderPath : dataFolderPaths) {
        const QString viewProfileFolderPath = dataFolderPath + viewProfileDirSubPath();
        // watch folder for changes
        mViewProfileFileWatcher->addDir(viewProfileFolderPath, KDirWatch::WatchDirOnly);

        // read current files
        onViewProfilesFolderChanged(viewProfileFolderPath);
    }
```

#### AUTO 


```{c}
auto* optionsBox = new QGroupBox(i18nc("@title:group", "Options"));
```

#### AUTO 


```{c}
auto* endianCopy = new Okteta::Byte[SIZE];
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : qAsConst(closedViews)) {
//         qCDebug(LOG_KASTEN_GUI) << view->title();
        delete view;
    }
```

#### AUTO 


```{c}
auto* parameterSetLayout = new QVBoxLayout(parameterSetBox);
```

#### LAMBDA EXPRESSION 


```{c}
[this](AbstractModelDataGenerator* generator) {
            triggerGeneration(generator);
        }
```

#### AUTO 


```{c}
auto* dialog = new StructuresSelectionDialog(mTool->manager()->structureDefs(),
                                                 mStructuresSelector->enabledList(),
                                                 this);
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractColumnTextRenderer* renderer : qAsConst(columnTextRendererList) )
        if( renderer->noOfSublinesNeeded() > subLinesCount )
            subLinesCount = renderer->noOfSublinesNeeded();
```

#### AUTO 


```{c}
auto* exportThread = new ModelStreamEncodeThread(q, file(), model(), selection(), mEncoder);
```

#### AUTO 


```{c}
auto* splitter = new QSplitter(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestData[] = "TestData";
```

#### AUTO 


```{c}
auto* document = new Kasten::TestDocument();
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : std::as_const(allData)) {
        QString codeStr = QStringLiteral("%1.set({typeName: 'myCustomType'});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1;obj.typeName = 'myCustomType'; obj;");
        QTest::newRow((data.tag + "-property assignment").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const StructureEnabledData& data : m_enabledList) {
        if (data.isEnabled) {
            enabledStructures.append(expressionTemplate.arg(data.id, data.structure));
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int longer = 5;
```

#### AUTO 


```{c}
auto* moveOver = new QTreeWidgetItem(mTreeSelected, QStringList { item->text(0), item->text(1) });
```

#### AUTO 


```{c}
auto* splitter = qobject_cast<QSplitter*>(otherWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[&viewProfileId](const ByteArrayViewProfile& existingProfile) {
                return (existingProfile.id() == viewProfileId);
            }
```

#### AUTO 


```{c}
auto* dialog = new ViewProfileEditDialog(mParentWidget);
```

#### CONST EXPRESSION 


```{c}
static constexpr int maxXxInputGroupsPerLine = xxInputLineLength / xxInputGroupLength;
```

#### AUTO 


```{c}
auto redoAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-redo")),
                                      i18nc("@action:inmenu", "Re&do") + QLatin1Char('\t') + QKeySequence(QKeySequence::Redo).toString(QKeySequence::NativeText),
                                      mView, [this] { redo(); });
```

#### CONST EXPRESSION 


```{c}
static constexpr int MOD_ADLER = 65521;
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : std::as_const(allData)) {
        // default should be inherit
        QString codeStr = QStringLiteral("%1;");
        QTest::newRow(data.tag.constData()) << codeStr.arg(data.constructorCall)
                                            << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;

        // use set() function to specify byteOrder
        codeStr = QStringLiteral("%1.set({byteOrder: \"inherit\"})");
        QTest::newRow((data.tag + " set() inherit").constData()) << codeStr.arg(data.constructorCall)
                                                                 << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;
        codeStr = QStringLiteral("%1.set({byteOrder: \"littleEndian\"})");
        QTest::newRow((data.tag + " set() little endian").constData()) << codeStr.arg(data.constructorCall)
                                                                       << data.check << (int)DataInformation::DataInformationEndianess::EndianessLittle;
        codeStr = QStringLiteral("%1.set({byteOrder: \"bigEndian\"})");
        QTest::newRow((data.tag + " set() big endian").constData()) << codeStr.arg(data.constructorCall)
                                                                    << data.check << (int)DataInformation::DataInformationEndianess::EndianessBig;
        codeStr = QStringLiteral("%1.set({byteOrder: \"fromSettings\"})");
        QTest::newRow((data.tag + " set() from settings").constData()) << codeStr.arg(data.constructorCall)
                                                                       << data.check << (int)DataInformation::DataInformationEndianess::EndianessFromSettings;

        // direct property access to specify byteOrder
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"inherit\"; obj;");
        QTest::newRow((data.tag + " property assign inherit").constData()) << codeStr.arg(data.constructorCall)
                                                                           << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"little-endian\"; obj;");
        QTest::newRow((data.tag + " property assign little endian").constData()) << codeStr.arg(data.constructorCall)
                                                                                 << data.check << (int)DataInformation::DataInformationEndianess::EndianessLittle;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"big-endian\"; obj;");
        QTest::newRow((data.tag + " property assign big endian").constData()) << codeStr.arg(data.constructorCall)
                                                                              << data.check << (int)DataInformation::DataInformationEndianess::EndianessBig;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"from-settings\"; obj;");
        QTest::newRow((data.tag + " property assign from settings").constData()) << codeStr.arg(data.constructorCall)
                                                                                 << data.check << (int)DataInformation::DataInformationEndianess::EndianessFromSettings;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int Distance23 = Offset3 - Offset2;
```

#### AUTO 


```{c}
auto* charsetConversionJob =
        new CharsetConversionJob(reinterpret_cast<Okteta::Byte*>(conversionResult.data()),
                                 mByteArrayModel, convertedSection,
                                 convertToOther ? viewCharCodec : otherCharCodec,
                                 convertToOther ? otherCharCodec : viewCharCodec,
                                 mSubstitutingMissingChars, mSubstituteByte
                                 );
```

#### AUTO 


```{c}
auto* previewBox = new QGroupBox(i18nc("@title:group", "Preview"), this);
```

#### AUTO 


```{c}
auto* buttonLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* action = static_cast<QAction*>(sender());
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractByteArrayChecksumAlgorithm* algorithm : algorithmList )
    {
        mAlgorithmComboBox->addItem( algorithm->name() );

        const char* const parameterSetId = algorithm->parameterSet()->id();
        AbstractByteArrayChecksumParameterSetEdit* parameterEdit =
            ByteArrayChecksumParameterSetEditFactory::createEdit( parameterSetId );

        mParameterSetEditStack->addWidget( parameterEdit );
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int SearchedByteCountSignalLimit = 10000;
```

#### CONST EXPRESSION 


```{c}
static constexpr char ASCII_MAX = 0x7f;
```

#### CONST EXPRESSION 


```{c}
static constexpr int Distance12 = Offset2 - Offset1;
```

#### AUTO 


```{c}
auto* newMenuAction =
        new KActionMenu(QIcon::fromTheme(QStringLiteral("document-new")),
                        i18nc("@title:menu create new byte arrays from different sources",
                              "New"),
                        this);
```

#### AUTO 


```{c}
auto* mainWindow = new OktetaMainWindow(this);
```

#### AUTO 


```{c}
auto* encodeThread = new ModelStreamEncodeThread(this, &exportDataBuffer, mModel, selection, encoder);
```

#### AUTO 


```{c}
auto* hexadecimal8Editor = qobject_cast<Hexadecimal8Editor*>(editor);
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxBookmarkNameSize = 40;
```

#### AUTO 


```{c}
auto versionable = qobject_cast<Okteta::Versionable*>(mView->byteArrayModel());
```

#### AUTO 


```{c}
auto* pageLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
const auto* spin = qobject_cast<const SIntSpinBox*>(w);
```

#### AUTO 


```{c}
auto* extractStringsJob =
        new ExtractStringsJob(mByteArrayModel, mByteArrayView->selection(), charCodec, mMinLength,
                              &mContainedStringList);
```

#### CONST EXPRESSION 


```{c}
static constexpr int recordTypeLineSize = 1;
```

#### AUTO 


```{c}
const auto* operandParameterSet = static_cast<const OperandByteArrayFilterParameterSet*>(parameterSet);
```

#### AUTO 


```{c}
auto* document = new ByteArrayDocument(byteArray, i18nc("origin of the byte array", "Created from data."));
```

#### RANGE FOR STATEMENT 


```{c}
for (TabbedViews* viewArea : std::as_const(mViewAreaList)) {
                if (viewArea->widget() == otherWidget) {
                    viewArea->setFocus();
                    break;
                }
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this] { selectAll(); }
```

#### AUTO 


```{c}
auto* job = new Kasten::ReplaceJob(view, byteArray, queryAgent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractColumnTextRenderer* renderer : qAsConst(columnTextRendererList)) {
        renderer->renderFirstLine(&textStream, l);
    }
```

#### AUTO 


```{c}
auto* ret = new QDoubleSpinBox(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for( QAction* action : actions )
    {
        if( action->data().toString() == viewProfileId )
        {
            action->setChecked( true );
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestDirectory[] = "testdocumentfile1synchronizertest";
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile& viewProfile : viewProfiles )
    {
        const QString title = viewProfile.viewProfileTitle();
        QAction* action = new QAction( title, mViewProfilesActionGroup );
        action->setCheckable( true );
        const ByteArrayViewProfile::Id viewProfileId = viewProfile.id();
        action->setData( viewProfileId );
        const bool isCurrentViewProfile = ( viewProfileId == currentViewProfileId );
        action->setChecked( isCurrentViewProfile );
        if( isCurrentViewProfile )
            isCurrentViewProfileExisting = true;

        mViewProfilesActionGroup->addAction( action );
        mViewProfileActionMenu->addAction( action );
    }
```

#### AUTO 


```{c}
const auto popupPoint = mByteArrayView->widget()->mapToGlobal(pos);
```

#### CONST EXPRESSION 


```{c}
static constexpr char OperationConfigKey[] = "Operation";
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultNoOfBytesPerLine = 16;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) { onTabCloseRequest(index); }
```

#### AUTO 


```{c}
auto* synchronizerFactory = new Kasten::ByteArrayRawFileSynchronizerFactory();
```

#### CONST EXPRESSION 


```{c}
static constexpr const char* longTypeNames[static_cast<int>(PrimitiveDataType::END) + 1] = {
    I18N_NOOP2("data type", "bool (1 byte)"),
    I18N_NOOP2("data type", "signed byte"),
    I18N_NOOP2("data type", "unsigned byte"),
    I18N_NOOP2("data type", "char"),
    I18N_NOOP2("data type", "bool (2 bytes)"),
    I18N_NOOP2("data type", "signed short"),
    I18N_NOOP2("data type", "unsigned short"),
    I18N_NOOP2("data type", "bool (4 bytes)"),
    I18N_NOOP2("data type", "signed int"),
    I18N_NOOP2("data type", "unsigned int"),
    I18N_NOOP2("data type", "bool (8 bytes)"),
    I18N_NOOP2("data type", "signed long"),
    I18N_NOOP2("data type", "unsigned long"),
    I18N_NOOP2("data type", "float"),
    I18N_NOOP2("data type", "double"),
    I18N_NOOP2("data type", "bitfield"),
};
```

#### LAMBDA EXPRESSION 


```{c}
[type](DataInformation* data) {
        QVERIFY(data->isPrimitive());
        QCOMPARE(data->asPrimitive()->type().value, type);
    }
```

#### AUTO 


```{c}
auto* mainLayout = new QVBoxLayout(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultValueCoding = 0;
```

#### CONST EXPRESSION 


```{c}
static constexpr char OrFilterConfigGroupId[] = "OR";
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char EBCDICChars[256] =
{
    0x00, 0x01, 0x02, 0x03, 0x37, 0x2D, 0x2E, 0x2F,
    0x16, 0x05, 0x25, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x3C, 0x3D, 0x32, 0x26,
    0x18, 0x19, 0x3F, 0x27, 0x1C, 0x1D, 0x1E, 0x1F,
    0x40, 0x5A, 0x7F, 0x7B, 0x5B, 0x6C, 0x50, 0x7D,
    0x4D, 0x5D, 0x5C, 0x4E, 0x6B, 0x60, 0x4B, 0x61,
    0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
    0xF8, 0xF9, 0x7A, 0x5E, 0x4C, 0x7E, 0x6E, 0x6F,
    0x7C, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
    0xC8, 0xC9, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6,
    0xD7, 0xD8, 0xD9, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6,
    0xE7, 0xE8, 0xE9, 0xAD, 0xE0, 0xBD, 0x5F, 0x6D,
    0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
    0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,
    0x97, 0x98, 0x99, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
    0xA7, 0xA8, 0xA9, 0xC0, 0x4F, 0xD0, 0xA1, 0x07,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x15, 0x06, 0x17,
    0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x09, 0x0A, 0x1B,
    0x30, 0x31, 0x1A, 0x33, 0x34, 0x35, 0x36, 0x08,
    0x38, 0x39, 0x3A, 0x3B, 0x04, 0x14, 0x3E, 0xFF,
    0x41, 0xAA, 0x4A, 0xB1, 0x9F, 0xB2, 0x6A, 0xB5,
    0xBB, 0xB4, 0x9A, 0x8A, 0xB0, 0xCA, 0xAF, 0xBC,
    0x90, 0x8F, 0xEA, 0xFA, 0xBE, 0xA0, 0xB6, 0xB3,
    0x9D, 0xDA, 0x9B, 0x8B, 0xB7, 0xB8, 0xB9, 0xAB,
    0x64, 0x65, 0x62, 0x66, 0x63, 0x67, 0x9E, 0x68,
    0x74, 0x71, 0x72, 0x73, 0x78, 0x75, 0x76, 0x77,
    0xAC, 0x69, 0xED, 0xEE, 0xEB, 0xEF, 0xEC, 0xBF,
    0x80, 0xFD, 0xFE, 0xFB, 0xFC, 0xBA, 0xAE, 0x59,
    0x44, 0x45, 0x42, 0x46, 0x43, 0x47, 0x9C, 0x48,
    0x54, 0x51, 0x52, 0x53, 0x58, 0x55, 0x56, 0x57,
    0x8C, 0x49, 0xCD, 0xCE, 0xCB, 0xCF, 0xCC, 0xE1,
    0x70, 0xDD, 0xDE, 0xDB, 0xDC, 0x8D, 0x8E, 0xDF
};
```

#### AUTO 


```{c}
auto* documentManager = new Kasten::DocumentManager();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
                mDocumentStrategy->load(QUrl::fromUserInput(url, currentPath, QUrl::AssumeLocalFile));
            }
```

#### AUTO 


```{c}
auto versionable = qobject_cast<Versionable*>(mView->byteArrayModel());
```

#### AUTO 


```{c}
auto* parentItem = static_cast<DataInformation*> (parent.internalPointer());
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultTRByteSpacingWidth = 1;
```

#### AUTO 


```{c}
auto menu = createStandardContextMenu(contextMenuEvent->pos());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(dirtyColumns)) {
                        const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(fullPositions);

                        q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                    }
```

#### AUTO 


```{c}
auto* float32Editor = qobject_cast<Float32Editor*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* filter : qAsConst(mFilterList)) {
        filter->loadConfig(configGroup);
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int tapRadius = 40;
```

#### AUTO 


```{c}
auto* buttonsLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* document = new ByteArrayDocument(i18nc("The byte array was new created.", "New created."));
```

#### CONST EXPRESSION 


```{c}
static constexpr char Crc64ChecksumConfigGroupId[] = "CRC64";
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : allViews )
    {
        AbstractDocument* document = view->findBaseModel<AbstractDocument*>();
        QHash<AbstractDocument*,QList<AbstractView*> >::Iterator it =
            viewsToClosePerDocument.find( document );

        if( it != viewsToClosePerDocument.end() )
        {
            const QList<AbstractView*>& viewsOfDocument = it.value();
            const bool isAnotherView = ! viewsOfDocument.contains( view );
            if( isAnotherView )
                viewsToClosePerDocument.erase( it );
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]( int index ) { onTabCloseRequest( index ); }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : allViews) {
        AbstractDocument* document = view->findBaseModel<AbstractDocument*>();
        QHash<AbstractDocument*, QVector<AbstractView*>>::Iterator it =
            viewsToClosePerDocument.find(document);

        if (it != viewsToClosePerDocument.end()) {
            const QVector<AbstractView*>& viewsOfDocument = it.value();
            const bool isAnotherView = !viewsOfDocument.contains(view);
            if (isAnotherView) {
                viewsToClosePerDocument.erase(it);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& structuresDir : structuresDirs )
    {
        const QStringList entries = QDir( structuresDir ).entryList( QDir::Dirs );
        for( const QString& e : entries )
        {
            const QString structureBasePath = structuresDir + QLatin1Char('/') + e;
            const QStringList desktopFiles =
                QDir(structureBasePath).entryList( QStringList(QStringLiteral("*.desktop")) );
            for(const QString& desktopFile : desktopFiles )
            {
                paths << structureBasePath + QLatin1Char('/') + desktopFile;
            }
        }
    }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout();
```

#### CONST EXPRESSION 


```{c}
static constexpr int ExtractStringBlockSize = 100000;
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:listbox", "O&ffset:"), this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int addressSizeCount =
    static_cast<int>(Kasten::SRecStreamEncoderSettings::AddressSizeId::_Count);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFrameRenderer* frameRenderer : std::as_const(mFrameRendererList)) {
        frameRenderer->prepare();
    }
```

#### AUTO 


```{c}
auto* showLicenseLabel = new QLabel;
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteTableConfigGroupId[] = "ByteTableTool";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* current : mChildren) {
        if (current == child) {
            found = true;
            break;
        }
        offset += current->size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : std::as_const(columnRenderers)) {
                columnRenderer->renderEmptyColumn(painter, renderedXs, renderedYs);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& s : selected)
    {
        int pos = regex.indexIn(s);
        if (pos > -1)
        {
            QString pluginName = regex.cap(1);
            QString structName = regex.cap(2);
            if (structName == QLatin1String("*")) {
                //add all of them
                for (int i = 0; i < mTreeAvailable->topLevelItemCount(); i++)
                {
                    QTreeWidgetItem* avail = mTreeAvailable->topLevelItem(i);
                    if (avail->text(0) != pluginName)
                        continue;
                    for (int i = 0; i < avail->childCount(); i++)
                    {
                        QTreeWidgetItem* selStruct = avail->child(i);
                        QTreeWidgetItem* item = new QTreeWidgetItem(mTreeSelected,
                                QStringList { selStruct->text(0), pluginName });
                        mTreeSelected->addTopLevelItem(item);
                    }
                    break;
                }
            }
            else {
                QTreeWidgetItem* item = new QTreeWidgetItem(mTreeSelected,
                        QStringList { structName, pluginName });
                mTreeSelected->addTopLevelItem(item);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        mList.removeOne(document);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultElementsPerLine = 4;
```

#### AUTO 


```{c}
auto* spin = qobject_cast<UIntSpinBox*> (w);
```

#### AUTO 


```{c}
auto* exportButton = new QPushButton(QIcon::fromTheme(QStringLiteral("edit-copy")),
                                         i18nc("@action:button", "&Copy to clipboard"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& expression : enabledStructures) {
        QRegularExpressionMatch match = regex.match(expression);
        if (match.hasMatch()) {
            const QString id = match.captured(1);
            const QString structure = match.captured(2);
            m_enabledList.append(StructureEnabledData(id, structure));
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int Offset3 = 45;
```

#### CONST EXPRESSION 


```{c}
static constexpr char Header1[] = "Header1";
```

#### AUTO 


```{c}
auto* xxencodingStreamEncoder = qobject_cast<ByteArrayXxencodingStreamEncoder*>(encoder);
```

#### CONST EXPRESSION 


```{c}
static constexpr int maxOutputBytesPerLine = outputLineLength;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QPoint& pos) { onContextMenuRequested(pos); }
```

#### AUTO 


```{c}
auto* view = qobject_cast<ByteArrayView*>(_view);
```

#### CONST EXPRESSION 


```{c}
static constexpr int outputGroupLength = 8;
```

#### AUTO 


```{c}
auto* findBox = new QGroupBox(i18nc("@title:window", "Find"));
```

#### CONST EXPRESSION 


```{c}
static constexpr char EncodingTypeConfigKey[] = "EncodingType";
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : closedDocuments )
        delete document;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfileFileInfoLookup& viewProfileFileInfoLookup : mViewProfileFileInfoLookupPerFolder) {
        ByteArrayViewProfileFileInfoLookup::ConstIterator it =
            viewProfileFileInfoLookup.find(viewProfileId);
        if (it != viewProfileFileInfoLookup.constEnd()) {
            result = it->isLocked();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : selected) {
        int pos = regex.indexIn(s);
        if (pos > -1) {
            QString pluginName = regex.cap(1);
            QString structName = regex.cap(2);
            if (structName == QLatin1String("*")) {
                // add all of them
                for (int i = 0; i < mTreeAvailable->topLevelItemCount(); i++) {
                    QTreeWidgetItem* avail = mTreeAvailable->topLevelItem(i);
                    if (avail->text(0) != pluginName) {
                        continue;
                    }
                    for (int i = 0; i < avail->childCount(); i++) {
                        QTreeWidgetItem* selStruct = avail->child(i);
                        auto* item = new QTreeWidgetItem(mTreeSelected, QStringList { selStruct->text(0), pluginName });
                        mTreeSelected->addTopLevelItem(item);
                    }

                    break;
                }
            } else {
                auto* item = new QTreeWidgetItem(mTreeSelected, QStringList { structName, pluginName });
                mTreeSelected->addTopLevelItem(item);
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ConversionDirectionConfigKey[] = "ConversionDirection";
```

#### RANGE FOR STATEMENT 


```{c}
for (const Bookmark& bookmark : *this) {
        result.append(bookmark);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : selected) {
        delete mTreeSelected->takeTopLevelItem(
            mTreeSelected->indexOfTopLevelItem(item));
    }
```

#### AUTO 


```{c}
const auto* viewBox = static_cast<const ViewBox*>(widget);
```

#### AUTO 


```{c}
auto* directionCharsetLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto undoAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-undo")),
                                      i18nc("@action:inmenu", "&Undo") + QLatin1Char('\t') + QKeySequence(QKeySequence::Undo).toString(QKeySequence::NativeText),
                                      mView, [this] { undo(); });
```

#### AUTO 


```{c}
auto* aboutDialog = new AboutStructureDialog(metaData, itemView());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& url : urls) {
        if (url.isEmpty()) {
            createManager->createNew();
        } else {
            syncManager->load(QUrl(url, QUrl::TolerantMode));
        }
        // TODO: set view to offset
        // if( offset != -1 )
    }
```

#### AUTO 


```{c}
auto* temporaryFile = new QTemporaryFile();
```

#### AUTO 


```{c}
const auto loadedDocuments = mManager->documents();
```

#### AUTO 


```{c}
auto* action = new QAction(title, mInsertSelectAction);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ModSum32ConfigGroupId[] = "ModularSum32";
```

#### AUTO 


```{c}
auto it = mLockedPositions.find(model);
```

#### AUTO 


```{c}
auto& info
```

#### AUTO 


```{c}
auto pasteAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-paste")),
                                        i18nc("@action:inmenu", "&Paste") + QLatin1Char('\t') + QKeySequence(QKeySequence::Paste).toString(QKeySequence::NativeText),
                                        mView, &AbstractByteArrayView::paste);
```

#### AUTO 


```{c}
auto* byteArray = qobject_cast<Okteta::PieceTableByteArrayModel*>(document->content());
```

#### AUTO 


```{c}
auto* pieceTableChange =
        new ReplacePieceTableChange(AddressRange(Start, End), InsertLength, InsertStorageOffset,
                                    PieceList(replacedPiece));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* exporter : exporterList) {
            const QString title = exporter->remoteTypeName();
            auto* action = new QAction(title, mExportSelectAction);

            action->setData(QVariant::fromValue(exporter));
            mExportSelectAction->addAction(action);
        }
```

#### AUTO 


```{c}
auto* generateThread = new ModelDataGenerateThread(q, generator);
```

#### AUTO 


```{c}
auto* factory = new Kasten::ByteArrayRawFileSynchronizerFactory();
```

#### LAMBDA EXPRESSION 


```{c}
[this] { undo(); }
```

#### AUTO 


```{c}
auto* stretcher = new QWidget(this);
```

#### AUTO 


```{c}
auto& encodingData
```

#### CONST EXPRESSION 


```{c}
static constexpr int CalculatedByteCountSignalLimit = 10000;
```

#### AUTO 


```{c}
auto* view = new Kasten::ByteArrayView(document, nullptr);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ElementsPerLineConfigKey[] = "ElementsPerLine";
```

#### AUTO 


```{c}
const auto topLevelItemCount = mTreeSelected->topLevelItemCount();
```

#### AUTO 


```{c}
auto* algorithmToolBar = new QToolBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(columns)) {
        column->setX(ColumnsWidth);
        ColumnsWidth += column->visibleWidth();
    }
```

#### AUTO 


```{c}
auto* labelledAlgorithmComboBox = new LabelledToolBarWidget(label, mOperationComboBox, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &url : urls) {
                mDocumentStrategy->load( QUrl::fromUserInput(url, currentPath, QUrl::AssumeLocalFile) );
            }
```

#### AUTO 


```{c}
auto* copy = new Okteta::Byte[sizeof(data)];
```

#### AUTO 


```{c}
auto asByteArraModel = qobject_cast<Okteta::ByteArrayModel*>(mByteArray)
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        QObject::connect(view, &AbstractModel::titleChanged,
                         q, [&](const QString& title) { onTitleChanged(title); });

        ViewBox* viewBox = new ViewBox(view, mTabWidget);
        mTabWidget->insertTab(insertIndex, viewBox, view->title());
        ++insertIndex;
    }
```

#### AUTO 


```{c}
auto* ReplaceBoxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto* createStatisticJob = new CreateStatisticJob(mByteArrayModel, selection, mByteCount);
```

#### CONST EXPRESSION 


```{c}
static constexpr char GroupSizeConfigKey[] = "GroupSize";
```

#### AUTO 


```{c}
const auto* viewBox = static_cast<const ViewBox*>(mTabWidget->widget(index));
```

#### CONST EXPRESSION 


```{c}
static constexpr int Offset4 = 67;
```

#### RANGE FOR STATEMENT 


```{c}
for (Kasten::AbstractXmlGuiController* controller : std::as_const(mControllers)) {
            controller->setTargetModel(mByteArrayView);
        }
```

#### AUTO 


```{c}
auto* item = new QTreeWidgetItem(mTreeAvailable, QStringList { def->metaData().id(), id });
```

#### AUTO 


```{c}
auto* parametersetEdit =
        qobject_cast<AbstractByteArrayChecksumParameterSetEdit*>(mParameterSetEditStack->currentWidget());
```

#### CONST EXPRESSION 


```{c}
constexpr const char* ToolbarActionNames[] =
    { "back", "forward", "up", "home", "short view", "detailed view", "tree view"  };
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { onViewsRemoved(); }
```

#### CONST EXPRESSION 


```{c}
static constexpr int Distance13 = Distance12 + Distance23;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QDragMoveEvent* event, bool& accept) { onDragMoveEvent(event, accept); }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : closedDocuments) {
        delete document;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : viewList) {
        if (view->findBaseModel<AbstractDocument*>() == document) {
            viewOfDocument = view;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int hexDigitsCount = 16;
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractModelStreamEncoderConfigEditorFactory* factory : mEncoderFactoryList )
    {
        result = factory->tryCreateConfigEditor( encoder );
        if( result )
            break;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int InsertCursorWidth = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : qAsConst(mList) )
    {
        if( !mSyncManager->canClose(document) )
        {
            canCloseAll = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto* actionToolBar = new QToolBar(this);
```

#### CONST EXPRESSION 


```{c}
constexpr int firstLetterIndex = 10;
```

#### CONST EXPRESSION 


```{c}
static constexpr int defaultxxInputLineLength = 45;
```

#### AUTO 


```{c}
auto* drag = new QDrag(mView);
```

#### LAMBDA EXPRESSION 


```{c}
[&]( bool hasFocus ) { onViewFocusChanged( hasFocus ); }
```

#### AUTO 


```{c}
auto* actionName
```

#### CONST EXPRESSION 


```{c}
static constexpr char Title[] = "title";
```

#### AUTO 


```{c}
auto* change = new SwapRangesPieceTableChange(firstStart, secondRange);
```

#### CONST EXPRESSION 


```{c}
static constexpr char exampleInitialData[] =
    "This is some data for the Okteta byte array widgets:"
    "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F"
    "\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F"
    "\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2A\x2B\x2C\x2D\x2E\x2F"
    "\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3A\x3B\x3C\x3D\x3E\x3F"
    "\x40\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F"
    "\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5A\x5B\x5C\x5D\x5E\x5F"
    "\x60\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F"
    "\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7A\x7B\x7C\x7D\x7E\x7F"
    "\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F"
    "\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F"
    "\xA0\xA1\xA2\xA3\xA4\xA5\xA6\xA7\xA8\xA9\xAA\xAB\xAC\xAD\xAE\xAF"
    "\xB0\xB1\xB2\xB3\xB4\xB5\xB6\xB7\xB8\xB9\xBA\xBB\xBC\xBD\xBE\xBF"
    "\xC0\xC1\xC2\xC3\xC4\xC5\xC6\xC7\xC8\xC9\xCA\xCB\xCC\xCD\xCE\xCF"
    "\xD0\xD1\xD2\xD3\xD4\xD5\xD6\xD7\xD8\xD9\xDA\xDB\xDC\xDD\xDE\xDF"
    "\xE0\xE1\xE2\xE3\xE4\xE5\xE6\xE7\xE8\xE9\xEA\xEB\xEC\xED\xEE\xEF"
    "\xF0\xF1\xF2\xF3\xF4\xF5\xF6\xF7\xF8\xF9\xFA\xFB\xFC\xFD\xFE\xFF";
```

#### AUTO 


```{c}
auto* changedSpy = new QSignalSpy(document, SIGNAL(contentFlagsChanged(Kasten::ContentFlags)));
```

#### AUTO 


```{c}
auto* printJob = new PrintJob(&framesPrinter, 0, byteArrayFrameRenderer->framesCount() - 1, printer);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultMoveBitWidth = 0;
```

#### AUTO 


```{c}
auto* actionsStretcher = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QUrl& url : urls )
            mDocumentStrategy->load( url );
```

#### AUTO 


```{c}
auto* pieceTableChange = new InsertPieceTableChange(InsertOffset, InsertLength, StorageOffset);
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestData2[] = "TestData2";
```

#### CONST EXPRESSION 


```{c}
constexpr int nullAddress = 0;
```

#### AUTO 


```{c}
auto* noneAction = new QAction(i18nc("@item There are no windows.", "None."), mWindowsActionGroup);
```

#### AUTO 


```{c}
auto* uintEditor = qobject_cast<UIntSpinBox*>(editor);
```

#### AUTO 


```{c}
auto* licenseBrowser = new QTextBrowser(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int codingCount =
    static_cast<int>(OperandByteArrayFilterParameterSet::_CodingCount);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultNoOfBytesPerGroup = 4;
```

#### CONST EXPRESSION 


```{c}
static constexpr int SizeOfPrimitiveDataType[] =
{
    sizeof(char),
    sizeof(unsigned char),
    sizeof(short),
    sizeof(unsigned short),
    sizeof(int),
    sizeof(unsigned int),
    sizeof(float),
    sizeof(double)
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
            syncManager->load(url);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& title) { onTitleChanged(title); }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ChecksumConfigGroupId[] = "ChecksumTool";
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction* action : actions) {
        if (action->data().toString() == viewProfileId) {
            action->setChecked(true);
            break;
        }
    }
```

#### AUTO 


```{c}
auto* offsetLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto* widget = new Okteta::ByteArrayRowView(parent);
```

#### AUTO 


```{c}
const auto children = mModel->findChildren<QObject*>(QString(), Qt::FindDirectChildrenOnly);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& property : std::as_const(mIterableProperties)) {
        if (property.first == name) {
            return result | property.second;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractPieceTableChange* change : mChangeStack) {
        if (change->type() == AbstractPieceTableChange::GroupId) {
            const auto* groupChange = static_cast<const GroupPieceTableChange*>(change);
            const AddressRangeList changedRangeList = groupChange->applyGroup(pieceTable);
            result.addAddressRangeList(changedRangeList);
        } else {
            result.append(change->apply(pieceTable));
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char FilterConfigGroupId[] = "FilterTool";
```

#### CONST EXPRESSION 


```{c}
static constexpr int encodingTypeCount =
    static_cast<int>(Kasten::Base32StreamEncoderSettings::EncodingType::_Count);
```

#### AUTO 


```{c}
auto* editor = new Hexadecimal8Editor(parent);
```

#### AUTO 


```{c}
auto* float64Editor = qobject_cast<Float64Editor*>(editor);
```

#### AUTO 


```{c}
auto* viewBox = new ViewBox(view, mTabWidget);
```

#### CONST EXPRESSION 


```{c}
constexpr int OnlyOneRowColumn = 0;
```

#### AUTO 


```{c}
auto* testSynchronizer = qobject_cast<TestDocumentFileSynchronizer*>(synchronizer());
```

#### AUTO 


```{c}
auto* def = new StructureDefinitionFile(info);
```

#### AUTO 


```{c}
auto* srecStreamEncoder = qobject_cast<ByteArraySRecStreamEncoder*>(encoder);
```

#### AUTO 


```{c}
auto* randomDataGenerator = qobject_cast<ByteArrayRandomDataGenerator*>(generator);
```

#### AUTO 


```{c}
const auto loadedDefs = mTool->manager()->structureDefs();
```

#### AUTO 


```{c}
auto idIt = structures.constFind(it->id);
```

#### AUTO 


```{c}
auto* upperOptionsLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& desktopFile : desktopFiles) {
                paths << structureBasePath + QLatin1Char('/') + desktopFile;
            }
```

#### AUTO 


```{c}
auto* sourceByteArrayView = qobject_cast<AbstractByteArrayView*>(dropEvent->source());
```

#### AUTO 


```{c}
auto* reloadThread = new ByteArrayRawFileReloadThread(this, /*document, */ file());
```

#### AUTO 


```{c}
auto* crc64ParameterSet =
        static_cast<Crc64ByteArrayChecksumParameterSet*>(parameterSet);
```

#### AUTO 


```{c}
auto* layout = static_cast<QVBoxLayout*>(this->layout());
```

#### AUTO 


```{c}
auto* writeThread = new TestDocumentFileWriteThread(this, testSynchronizer->header(),  document, file());
```

#### AUTO 


```{c}
auto* addedSpy = new QSignalSpy(documentManager, SIGNAL(added(QVector<Kasten::AbstractDocument*>)));
```

#### AUTO 


```{c}
auto* dialogButtonBox = new QDialogButtonBox;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(dirtyColumns)) {
                column->renderEmptyColumn(painter, dirtyXs, dirtyYs);
            }
```

#### AUTO 


```{c}
auto* sInt32Editor = qobject_cast<SIntSpinBox*>(editor);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultGroupSize = 1;
```

#### AUTO 


```{c}
auto* action = new QAction(title, mBookmarksActionGroup);
```

#### AUTO 


```{c}
auto* def = new StructureDefinitionFile(metaData);
```

#### CONST EXPRESSION 


```{c}
constexpr int maxLineLength = 64 / 2;
```

#### CONST EXPRESSION 


```{c}
static constexpr char fillerData[] =
    "This is some filler data for the Okteta byte array widgets:"
    "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F"
    "\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F"
    "\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2A\x2B\x2C\x2D\x2E\x2F"
    "\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3A\x3B\x3C\x3D\x3E\x3F"
    "\x40\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F"
    "\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5A\x5B\x5C\x5D\x5E\x5F"
    "\x60\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F"
    "\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7A\x7B\x7C\x7D\x7E\x7F"
    "\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F"
    "\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F"
    "\xA0\xA1\xA2\xA3\xA4\xA5\xA6\xA7\xA8\xA9\xAA\xAB\xAC\xAD\xAE\xAF"
    "\xB0\xB1\xB2\xB3\xB4\xB5\xB6\xB7\xB8\xB9\xBA\xBB\xBC\xBD\xBE\xBF"
    "\xC0\xC1\xC2\xC3\xC4\xC5\xC6\xC7\xC8\xC9\xCA\xCB\xCC\xCD\xCE\xCF"
    "\xD0\xD1\xD2\xD3\xD4\xD5\xD6\xD7\xD8\xD9\xDA\xDB\xDC\xDD\xDE\xDF"
    "\xE0\xE1\xE2\xE3\xE4\xE5\xE6\xE7\xE8\xE9\xEA\xEB\xEC\xED\xEE\xEF"
    "\xF0\xF1\xF2\xF3\xF4\xF5\xF6\xF7\xF8\xF9\xFA\xFB\xFC\xFD\xFE\xFF";
```

#### AUTO 


```{c}
auto* ret = new QScriptEngine();
```

#### AUTO 


```{c}
auto* layoutObj = qobject_cast<QBoxLayout*>(layout());
```

#### CONST EXPRESSION 


```{c}
static constexpr int minChunkSize = 512;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : qAsConst(mList)) {
        if ((document != keptDocument) &&
            !mSyncManager->canClose(document)) {
            canCloseAll = false;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char endOfFileRecordCode = 0x1;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(columns)) {
        column->setX(ColumnsWidth);
        ColumnsWidth += column->visibleWidth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Bookmark bookmark : std::as_const(bookmarksInFirstPart)) {
            bookmark.move(secondPartLength);
            insert(bIt, bookmark);
        }
```

#### AUTO 


```{c}
auto* parametersetEdit =
        qobject_cast<AbstractByteArrayFilterParameterSetEdit*>(mParameterSetEditStack->currentWidget());
```

#### CONST EXPRESSION 


```{c}
constexpr bool operator<=(const Coord& other) const;
```

#### AUTO 


```{c}
auto* dialog = new CreateDialog(configEditor, generator, QApplication::activeWindow());
```

#### AUTO 


```{c}
auto* document = qobject_cast<TestDocument*>(synchronizer()->document());
```

#### AUTO 


```{c}
auto* synchronizer = new ByteArrayViewProfileSynchronizer(mByteArrayViewProfileManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : std::as_const(mAlternatives)) {
        qDeleteAll(fi.fields);
    }
```

#### AUTO 


```{c}
const auto* viewBox = static_cast<const ViewBox*>(mTabWidget->widget(i));
```

#### AUTO 


```{c}
auto* viewProfileSynchronizer = new Kasten::ByteArrayViewProfileSynchronizer(viewProfileManager);
```

#### AUTO 


```{c}
auto* headerFrameRenderer = new HeaderFooterFrameRenderer(&info);
```

#### AUTO 


```{c}
auto* exporter = action->data().value<AbstractModelExporter*>();
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile::Id& viewProfileId : viewProfileIds )
    {
        removeViewProfile( viewProfileId );
    }
```

#### AUTO 


```{c}
auto* document = mView->findBaseModel<AbstractDocument*>();
```

#### AUTO 


```{c}
auto* filePlacesModel = new KFilePlacesModel(this);
```

#### AUTO 


```{c}
auto* dialog = new BytesPerLineDialog(QApplication::activeWindow());
```

#### RANGE FOR STATEMENT 


```{c}
for( const FieldInfo& fi : qAsConst(mAlternatives) )
    {
        qDeleteAll(fi.fields);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultScrollTimerPeriod = 100;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* current : others) {
            if (current == child) {
                found = true;
                break;
            }
            offset += current->size();
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char OtherCharCodecNameConfigKey[] = "OtherCharCodecName";
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : structureNames) {
            auto* subItem = new QTreeWidgetItem(item, QStringList { name, id });
            item->addChild(subItem);
        }
```

#### AUTO 


```{c}
auto result = static_cast<quint8>(tmp);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* current : std::as_const(mChildren)) {
        if (current == child) {
            return offset;
        }
        offset += current->size();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile& viewProfile : viewProfiles) {
        const QString title = viewProfile.viewProfileTitle();
        QAction* action = new QAction(title, mViewProfilesActionGroup);
        action->setCheckable(true);
        const ByteArrayViewProfile::Id viewProfileId = viewProfile.id();
        action->setData(viewProfileId);
        const bool isCurrentViewProfile = (viewProfileId == currentViewProfileId);
        action->setChecked(isCurrentViewProfile);
        if (isCurrentViewProfile) {
            isCurrentViewProfileExisting = true;
        }

        mViewProfilesActionGroup->addAction(action);
        mViewProfileActionMenu->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* bitField : qAsConst(bitfields)) {
        basicTest(bitField, exp);
    }
```

#### AUTO 


```{c}
auto* arrayData = static_cast<PrimitiveArrayData<primType>*>(dataInf->mData.data());
```

#### AUTO 


```{c}
auto* bookmarkEditPopup = new BookmarkEditPopup(mByteArrayView->widget());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto d : std::as_const(digits)) {
        codec->appendDigit(&decodedByte, d.toLatin1());
    }
```

#### AUTO 


```{c}
auto* dialog = new LicenseDialog(m_structureMetaData.license(), this);
```

#### AUTO 


```{c}
auto* secondViewArea = new TabbedViews();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : std::as_const(altInfo)) {
            qDeleteAll(info.fields);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KPluginInfo& info : plugins) {
        addStructDef(info);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
//         qCDebug(LOG_KASTEN_GUI)<<view->title();
        delete view;
    }
```

#### AUTO 


```{c}
auto* actionsToolBar = new QToolBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelDataGenerator* generator : generatorList) {
            const QString title = generator->typeName();
            auto* action = new QAction(title, mInsertSelectAction);

            action->setData(QVariant::fromValue(generator));
            mInsertSelectAction->addAction(action);
        }
```

#### AUTO 


```{c}
auto* uInt16Editor = qobject_cast<UIntSpinBox*>(editor);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayValuesStreamEncoderConfigGroupId[] = "ByteArrayValuesStreamEncoder";
```

#### CONST EXPRESSION 


```{c}
static constexpr const char* paddingData[2] = {"++", "+"};
```

#### CONST EXPRESSION 


```{c}
static constexpr char ReverseFilterConfigGroupId[] = "Reverse";
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        urls.append(syncManager->urlOf(document).url());
    }
```

#### AUTO 


```{c}
auto* factory = new Kasten::TestDocumentFileSynchronizerFactory(header);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(d->columns)) {
            if (column->isVisible() && column->overlaps(dirtyXs)) {
                dirtyColumns.append(column);
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char FileNameConfigKey[] = "FileName";
```

#### CONST EXPRESSION 


```{c}
static constexpr char AlgorithmConfigKey[] = "Algorithm";
```

#### AUTO 


```{c}
const auto popupPoint = mMultiViewAreas->widget()->mapToGlobal(pos);
```

#### AUTO 


```{c}
auto* rotateParameterSet = static_cast<RotateByteArrayFilterParameterSet*>(parameterSet);
```

#### CONST EXPRESSION 


```{c}
static constexpr char InvertsBitsConfigKey[] = "InvertsBits";
```

#### AUTO 


```{c}
auto* doc1 = new Kasten::TestDocument();
```

#### CONST EXPRESSION 


```{c}
constexpr bool isPriorInLineThan(const Coord& other) const;
```

#### AUTO 


```{c}
auto* dialog = new QDialog(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(dirtyColumns)) {
                        const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(fullPositions);

                        q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                    }
```

#### AUTO 


```{c}
auto* byteArrayModel = new ByteArrayModel(ByteArrayModelSize);
```

#### AUTO 


```{c}
auto* utf8Editor = qobject_cast<Utf8Editor*>(editor);
```

#### AUTO 


```{c}
const auto* data = static_cast<const DataInformation*>(idx.internalPointer());
```

#### AUTO 


```{c}
auto* dialog = new StructuresSelectionDialog(mSelectedStructures, mTool, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& valueCodecDescription : valueCodecDescriptions) {
        QBitArray validnessPerDigitField = QBitArray(digitCount, false);
        const QByteArray validDigits =
            QByteArray(valueCodecDescription.validDigits);

        for (int j = 0; j < validDigits.count(); ++j) {
            validnessPerDigitField.setBit(validDigits[j], true);
        }

        for (int j = 0; j < validnessPerDigitField.count(); ++j) {
            const auto digit = static_cast<uchar>(j);
            const bool isValid = validnessPerDigitField.testBit(j);
            const QString rowTitle =
                QLatin1String(valueCodecDescription.name) +
                QStringLiteral(" - \"%1\" is ").arg(QLatin1Char(digit)) +
                (isValid ? QStringLiteral("valid") : QStringLiteral("invalid"));

            QTest::newRow(rowTitle.toLatin1().constData())
                << valueCodecDescription.id
                << digit
                << isValid;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : std::as_const(mAlternatives)) {
        for (auto* field : fi.fields) {
            field->setParent(this);
        }
    }
```

#### AUTO 


```{c}
auto* labelledAlgorithmComboBox = new LabelledToolBarWidget(label, mAlgorithmComboBox, this);
```

#### RANGE FOR STATEMENT 


```{c}
for( QTreeWidgetItem* item : selected )
        {
            int idx = mTreeSelected->indexOfTopLevelItem(item);
            int newIdx = qMin(idx + 1, maxItmCount - 1);
            mTreeSelected ->insertTopLevelItem(newIdx,
                    mTreeSelected->takeTopLevelItem(idx));
            //only first index
            firstIndex = firstIndex == -1 ? newIdx : firstIndex;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& structuresDir : structuresDirs) {
        const QStringList entries = QDir(structuresDir).entryList(QDir::Dirs);
        for (const QString& e : entries) {
            const QString structureBasePath = structuresDir + QLatin1Char('/') + e;
            const QStringList desktopFiles =
                QDir(structureBasePath).entryList(QStringList(QStringLiteral("*.desktop")));
            for (const QString& desktopFile : desktopFiles) {
                paths << structureBasePath + QLatin1Char('/') + desktopFile;
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int headerByteCount = 3;
```

#### CONST EXPRESSION 


```{c}
constexpr int fieldWidth = 6;
```

#### AUTO 


```{c}
const auto versionCount = versionable->versionCount();
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool hasFocus) { onViewAreaFocusChanged(hasFocus); }
```

#### AUTO 


```{c}
auto* encoder
```

#### CONST EXPRESSION 


```{c}
static constexpr char DataTypeConfigKey[] = "DataType";
```

#### AUTO 


```{c}
auto* baseLayout = new QHBoxLayout(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int dataLineOffset = recordTypeLineOffset + recordTypeLineSize;
```

#### LAMBDA EXPRESSION 


```{c}
[&viewProfileId] (const ByteArrayViewProfile& existingProfile) {
                return (viewProfileId == existingProfile.id());
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr char UiSettingsConfigGroupId[] = "UiSettings";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(dirtyColumns)) {
                    const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(firstChangedPositions);

                    q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                }
```

#### AUTO 


```{c}
auto* layoutBox = new QGroupBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractColumnTextRenderer* renderer : std::as_const(columnTextRendererList)) {
        renderer->renderFirstLine(&textStream, l);
    }
```

#### AUTO 


```{c}
auto* authorWidget = new QWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& codecName : CharCodec::codecNames()) {
        QTest::newRow(codecName.toLatin1().constData()) << codecName;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int replaceLength = Distance13 - 1;
```

#### AUTO 


```{c}
auto* item = new QTreeWidgetItem(mTreeSelected, QStringList { structName, pluginName });
```

#### AUTO 


```{c}
const auto* modSumParameterSet =
        static_cast<const ModSumByteArrayChecksumParameterSet*>(parameterSet);
```

#### AUTO 


```{c}
auto* childItem = static_cast<DataInformation*> (index.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const StructureDefinitionFile* def : loadedDefs) {
        QString pluginName = def->pluginInfo().pluginName();
        if (def->pluginInfo().isValid() && !def->pluginInfo().isPluginEnabled()) {
            continue;
        }
        plugins << pluginName;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractModelDataGeneratorConfigEditorFactory* factory : mGeneratorFactoryList) {
        result = factory->tryCreateConfigEditor(generator);
        if (result) {
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int lastWithNumericShortCut = 9;
```

#### AUTO 


```{c}
const auto& valueCodecDescription
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:listbox", "Start offset:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto columnRenderer : qAsConst(columnRenderers)) {
                columnRenderer->renderEmptyColumn(painter, renderedXs, renderedYs);
            }
```

#### AUTO 


```{c}
auto* titleWidget = new KTitleWidget(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile& viewProfile : viewProfiles) {
        if (viewProfile.id() == mViewProfileId) {
            updateView(viewProfile);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : views )
    {
        view->disconnect( q );

        index = indexOf( view );
        if( index != -1 )
        {
            ViewBox* viewBox = static_cast<ViewBox*>( mTabWidget->widget(index) );

            mTabWidget->removeTab( index );
            delete viewBox;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int maxOutputGroupsPerLine = outputLineLength / outputGroupLength;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        QTest::newRow(valueCodecDescription.name)
            << valueCodecDescription.id
            << valueCodecDescription.encodingWidth;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteOrderConfigKey[] = "ByteOrder";
```

#### CONST EXPRESSION 


```{c}
static constexpr char UnsignedAsHexConfigKey[] = "UnsignedAsHexadecimal";
```

#### AUTO 


```{c}
auto* charsBoxFormLayout = new QFormLayout(charsBox);
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
    {
        AbstractView* view = mFactory->createViewFor( document );
        if( ! view )
            view = new DummyView( document );

        mViewList.append( view );
        openedViews.append( view );
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int ReplacedStorageOffset = 53;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        AbstractView* view = mFactory->createViewFor(document);
        if (!view) {
            view = new DummyView(document);
        }

        mViewList.append(view);
        openedViews.append(view);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(d->columns)) {
                    column->renderColumn(painter, dirtyXs, dirtyYs);
                }
```

#### AUTO 


```{c}
auto* model = const_cast<AbstractModel*>(this);
```

#### AUTO 


```{c}
auto* pieceTableChange =
        new SwapRangesPieceTableChange(FirstRangeStart, AddressRange(SecondRangeStart, SecondRangeEnd));
```

#### AUTO 


```{c}
auto* widget = new QWidget();
```

#### AUTO 


```{c}
auto* labelledSizeLabel = new LabelledToolBarWidget(label, mSizeLabel, this);
```

#### CONST EXPRESSION 


```{c}
constexpr int fieldWidth = 4;
```

#### AUTO 


```{c}
auto* ret = new SIntSpinBox(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfileFileInfoLookup& viewProfileFileInfoLookup : mViewProfileFileInfoLookupPerFolder )
    {
        ByteArrayViewProfileFileInfoLookup::ConstIterator it =
            viewProfileFileInfoLookup.find( viewProfileId );
        if( it != viewProfileFileInfoLookup.constEnd() )
        {
            result = it->isLocked();
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : selected) {
        int idx = mTreeSelected->indexOfTopLevelItem(item);
        int newIdx = qMin(idx + 1, maxItmCount - 1);
        mTreeSelected->insertTopLevelItem(newIdx,
                                          mTreeSelected->takeTopLevelItem(idx));
        // only first index
        firstIndex = firstIndex == -1 ? newIdx : firstIndex;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( Bookmark bookmark : qAsConst(bookmarksInFirstPart) ) // krazy:exclude=foreach
        {
            bookmark.move( secondPartLength );
            insert( bIt, bookmark );
        }
```

#### LAMBDA EXPRESSION 


```{c}
[&](LocalSyncState localSyncState) { onLocalSyncStateChanged(localSyncState); }
```

#### CONST EXPRESSION 


```{c}
static constexpr char CreatorConfigGroupId[] = "Recent Files";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : qAsConst(d->mColumns)) {
            if (columnRenderer->isVisible() && columnRenderer->overlaps(renderedXs)) {
                columnRenderers.append(columnRenderer);
            }
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char AndFilterConfigGroupId[] = "AND";
```

#### LAMBDA EXPRESSION 


```{c}
[&](QObject* object) { onSynchronizerDeleted(object); }
```

#### AUTO 


```{c}
auto* contactToolBar = new QToolBar(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int lastEgoDataIndex = sizeof(EgoData) / sizeof(EgoDataStruct) - 1;
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxPODSize = sizeof(double);
```

#### AUTO 


```{c}
auto* generator = action->data().value<AbstractModelDataGenerator*>();
```

#### AUTO 


```{c}
auto* newEmptyDocumentAction =
        new QAction(QIcon::fromTheme(QStringLiteral("document-new")), i18nc("@item:inmenu create a new empty document", "Empty"), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool isVisible) { onVisibilityChanged(isVisible); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : qAsConst(columnRenderers)) {
                columnRenderer->renderEmptyColumn(painter, renderedXs, renderedYs);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( int failedByteCount : failedPerByteCount )
                totalFailedByteCount += failedByteCount;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : qAsConst(d->mColumns)) {
        columnRenderer->setLineHeight(d->mLineHeight);
    }
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout();
```

#### CONST EXPRESSION 


```{c}
static constexpr char AddressSizeConfigKey[] = "AddressSize";
```

#### CONST EXPRESSION 


```{c}
constexpr bool isBelow(Line line) const;
```

#### AUTO 


```{c}
auto* byteArrayModel = new PieceTableByteArrayModel(ByteArrayModelSize);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* other : others) {
        other->beginRead();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool online) { onOnlineStateChanged(online); }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : viewList )
    {
        if( view->findBaseModel<AbstractDocument*>() == document )
        {
            viewOfDocument = view;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( StructureDefinitionFile* def : loadedDefs )
    {
        if (!def->isValid())
            continue;
        QString pluginName = def->pluginInfo().pluginName();
        if (!def->pluginInfo().isPluginEnabled())
            continue;
        QTreeWidgetItem* item = new QTreeWidgetItem(mTreeAvailable,
                QStringList { def->pluginInfo().pluginName(), pluginName });
        foreach(const QString& name, def->structureNames())
            {
                QTreeWidgetItem* subItem = new QTreeWidgetItem(item,
                        QStringList { name, pluginName });
                item->addChild(subItem);
            }
        availableItems.append(item);
    }
```

#### AUTO 


```{c}
auto* newFromClipboardDocumentAction =
        new QAction(QIcon::fromTheme(QStringLiteral("edit-paste")), i18nc("@item:inmenu create a new document from data in the clipboard", "From Clipboard"), this);
```

#### AUTO 


```{c}
auto* topData = new TopLevelDataInformation(data, logger, eng, fileInfo);
```

#### AUTO 


```{c}
auto* editor = new Float64Editor(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ToolViewDockWidget* dockWidget : dockWidgets) {
        QAction* action = dockWidget->toggleViewAction();
        action->setText(dockWidget->windowTitle());
//         action->setText( mToolView->title() );
        mToolActionList.append(action);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int Distance34 = Offset4 - Offset3;
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractModelStreamEncoder* encoder : qAsConst(mEncoderList) )
        mExporterList << new ModelEncoderFileSystemExporter( encoder );
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        connect(document, &AbstractDocument::synchronizerChanged,
                this, &DocumentListModel::onSynchronizerChanged);
        AbstractModelSynchronizer* synchronizer = document->synchronizer();
        if (synchronizer) {
            connect(synchronizer, &AbstractModelSynchronizer::localSyncStateChanged,
                    this, &DocumentListModel::onSyncStatesChanged);
            connect(synchronizer, &AbstractModelSynchronizer::remoteSyncStateChanged,
                    this, &DocumentListModel::onSyncStatesChanged);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : qAsConst(mList)) {
        if (!mSyncManager->canClose(document)) {
            canCloseAll = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto* action = new QAction(v < 9 ? QStringLiteral("&%1 %2").arg(v + 1).arg(title) : title, mWindowsActionGroup);
```

#### AUTO 


```{c}
auto* quitAction = KStandardAction::quit(this, &QuitController::quit, this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](ByteArrayViewProfile& viewProfile) {
        const ByteArrayViewProfile::Id viewProfileId = viewProfile.id();

        bool needsId = true;
        if (!viewProfileId.isEmpty()) {
            // already existing?
            auto hasViewProfileId = [&viewProfileId] (const ByteArrayViewProfile& existingProfile) {
                return (viewProfileId == existingProfile.id());
            };
            if (std::any_of(mViewProfiles.constBegin(), mViewProfiles.constEnd(), hasViewProfileId)) {
                needsId = false;
            }
        }

        // set new uuid for non-existing
        if (needsId) {
            viewProfile.setId(QUuid::createUuid().toString());
        }

        saveViewProfile(viewProfile);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned int StartsBefore = 1;
```

#### AUTO 


```{c}
const auto* groupChange = static_cast<const GroupPieceTableChange*>(change);
```

#### AUTO 


```{c}
auto* ReplaceBox = new QGroupBox(i18nc("@title:group", "Replace With"));
```

#### AUTO 


```{c}
const auto* byteArrayView = qobject_cast<const ByteArrayView*>(model);
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : loadedDocuments )
    {
        if( url == urlOf(document) )
        {
            // TODO: query if file should be reloaded/synched from disk
            emit mManager->focusRequested( document );
            return;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : allViews) {
        AbstractDocument* document = view->findBaseModel<AbstractDocument*>();
        QHash<AbstractDocument*, QList<AbstractView*>>::Iterator it =
            viewsToClosePerDocument.find(document);

        if (it != viewsToClosePerDocument.end()) {
            const QList<AbstractView*>& viewsOfDocument = it.value();
            const bool isAnotherView = !viewsOfDocument.contains(view);
            if (isAnotherView) {
                viewsToClosePerDocument.erase(it);
            }
        }
    }
```

#### AUTO 


```{c}
auto* doc = new Kasten::TestDocument();
```

#### AUTO 


```{c}
auto* layout = new QHBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        while (it.hasNext()) {
            AbstractView* view = it.next();
            auto* documentOfView = view->findBaseModel<AbstractDocument*>();
            if (documentOfView == document) {
                it.remove();
                closedViews.append(view);
            }
        }
        it.toFront();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const JsTestData& data : qAsConst(allData) ) {
        //default should be inherit
        QString codeStr = QStringLiteral("%1;");
        QTest::newRow(data.tag.constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;

        //use set() function to specify byteOrder
        codeStr = QStringLiteral("%1.set({byteOrder: \"inherit\"})");
        QTest::newRow((data.tag + " set() inherit").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;
        codeStr = QStringLiteral("%1.set({byteOrder: \"littleEndian\"})");
        QTest::newRow((data.tag + " set() little endian").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessLittle;
        codeStr = QStringLiteral("%1.set({byteOrder: \"bigEndian\"})");
        QTest::newRow((data.tag + " set() big endian").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessBig;
        codeStr = QStringLiteral("%1.set({byteOrder: \"fromSettings\"})");
        QTest::newRow((data.tag + " set() from settings").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessFromSettings;

        //direct property access to specify byteOrder
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"inherit\"; obj;");
        QTest::newRow((data.tag + " property assign inherit").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"little-endian\"; obj;");
        QTest::newRow((data.tag + " property assign little endian").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessLittle;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"big-endian\"; obj;");
        QTest::newRow((data.tag + " property assign big endian").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessBig;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"from-settings\"; obj;");
        QTest::newRow((data.tag + " property assign from settings").constData()) << codeStr.arg(data.constructorCall)
            << data.check << (int)DataInformation::DataInformationEndianess::EndianessFromSettings;
    }
```

#### AUTO 


```{c}
auto* change3 = new TestPieceTableChange(type3Id, description3, 3);
```

#### RANGE FOR STATEMENT 


```{c}
for (StructureDefinitionFile* def : loadedDefs) {
        if (!def->isValid()) {
            continue;
        }
        QString pluginName = def->pluginInfo().pluginName();
        if (!def->pluginInfo().isPluginEnabled()) {
            continue;
        }
        auto* item = new QTreeWidgetItem(mTreeAvailable, QStringList { def->pluginInfo().pluginName(), pluginName });
        const auto structureNames = def->structureNames();
        for (const QString& name : structureNames) {
            auto* subItem = new QTreeWidgetItem(item, QStringList { name, pluginName });
            item->addChild(subItem);
        }

        availableItems.append(item);
    }
```

#### AUTO 


```{c}
auto* writeThread = new ByteArrayRawFileWriteThread(this, byteArrayDocument, file());
```

#### RANGE FOR STATEMENT 


```{c}
for( const KPluginInfo& info : plugins )
    {
        addStructDef(info);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : std::as_const(mChildren)) {
        child->setParent(mParent);
    }
```

#### AUTO 


```{c}
auto* change3 = new TestPieceTableChange(type3Id, description3);
```

#### AUTO 


```{c}
auto* emailAction = new QAction(this);
```

#### AUTO 


```{c}
auto* viewArea = static_cast<TabbedViews*>(_viewArea);
```

#### AUTO 


```{c}
auto* targetByteArrayView = qobject_cast<AbstractByteArrayView*>(drag->target());
```

#### CONST EXPRESSION 


```{c}
constexpr char digits[hexDigitsCount] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        'A', 'B', 'C', 'D', 'E', 'F'
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { onMouseMiddleClick(); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNS3::Entry& e : changedEntries) {
        qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "Changed Entry: " << e.name();
        if (e.status() == KNS3::Entry::Installed) {
            // new element installed
            qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "installed files:" << e.installedFiles();
        }
        if (e.status() == KNS3::Entry::Deleted) {
            // element uninstalled
            qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "deleted files:" << e.uninstalledFiles();
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int fieldWidth = 11;
```

#### RANGE FOR STATEMENT 


```{c}
for (TabbedViews* viewArea : qAsConst(mViewAreaList)) {
                if (viewArea->widget() == otherWidget) {
                    viewArea->setFocus();
                    break;
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( TabbedViews* viewArea : qAsConst(mViewAreaList) )
            {
                if( viewArea->widget() == otherWidget )
                {
                    viewArea->setFocus();
                    break;
                }
            }
```

#### AUTO 


```{c}
auto* dialog = new BytesPerGroupDialog(QApplication::activeWindow());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* actionName : ToolbarActionNames) {
        QAction* action = dirOperatorActionCollection->action(QLatin1String(actionName));
        if (action) {
            mToolbar->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto* directionCharsetToolBar = new QToolBar(this);
```

#### AUTO 


```{c}
const auto* spin = qobject_cast<const QDoubleSpinBox*> (w);
```

#### AUTO 


```{c}
auto* editorPage = new QWidget(splitter);
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultUnsignedAsHex = true;
```

#### AUTO 


```{c}
auto* pageLayout = new QHBoxLayout;
```

#### AUTO 


```{c}
auto* info
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        auto* document = view->findBaseModel<AbstractDocument*>();
        viewsToClosePerDocument[document].append(view);
    }
```

#### AUTO 


```{c}
const auto* spin = qobject_cast<const UIntSpinBox*> (w);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelDataGenerator* generator : generatorList) {
            const QString title = generator->typeName();
            const QString iconName = QStringLiteral("document-new");  // generator->iconName();

            auto* action = new QAction(QIcon::fromTheme(iconName), title, this);
            action->setData(QVariant::fromValue(generator));
            connect(action, &QAction::triggered,
                    this, &CreatorController::onNewFromGeneratorActionTriggered);

            newMenuAction->addAction(action);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestFileName1[] = "test1.data";
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxEntryLength = 150;
```

#### AUTO 


```{c}
auto* change = new ReplacePieceTableChange(removeRange, insertLength, *storageSize, replacedPieces);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kasten::StructureDefinitionFile* def : structureDefs) {
        KPluginInfo info = def->pluginInfo();
        if (info.isPluginEnabled()) {
            newVals.append(QString(QStringLiteral("\'%1\':\'*\'")).arg(info.pluginName()));
        }
    }
```

#### AUTO 


```{c}
auto* child
```

#### AUTO 


```{c}
auto* filter
```

#### CONST EXPRESSION 


```{c}
static constexpr int NoOfPrimitiveDataTypes = 8;
```

#### CONST EXPRESSION 


```{c}
static constexpr int addressSizeCount =
    static_cast<int>(Kasten::IHexStreamEncoderSettings::AddressSizeId::_Count);
```

#### AUTO 


```{c}
auto* parameterSetBox = new QGroupBox(i18nc("@title:group", "Parameters"), this);
```

#### CONST EXPRESSION 


```{c}
constexpr int recordCountByteCount = byteCountLineSize + recordCountLineSize;
```

#### AUTO 


```{c}
auto* editor = new Char8Editor(mTool->charCodec(), parent);
```

#### AUTO 


```{c}
auto* operationLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* spin = qobject_cast<QDoubleSpinBox*> (w);
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned char BitMask[9] = {
        0, 1 << 7, 3 << 6, 7 << 5, 15 << 4, 31 << 3, 63 << 2, 127 << 1, 255
    };
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* current : mChildren) {
        if (current == child) {
            break;
        }
        offset += current->size();
    }
```

#### AUTO 


```{c}
auto* document = static_cast<ByteArrayDocument*>(_document);
```

#### AUTO 


```{c}
auto* structSelectionPage = new QWidget();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(dirtyColumns)) {
                    const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(lastChangedPositions);

                    q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultOffsetCoding = 0;
```

#### AUTO 


```{c}
auto* item = new QTreeWidgetItem(mTreeSelected, QStringList { structure, id });
```

#### AUTO 


```{c}
const auto* viewBox = static_cast<const ViewBox*>(mTabWidget->currentWidget());
```

#### CONST EXPRESSION 


```{c}
constexpr int fieldWidth = 13;
```

#### AUTO 


```{c}
auto* document = qobject_cast<ByteArrayDocument*>(synchronizer()->document());
```

#### AUTO 


```{c}
auto type = static_cast<PrimitiveDataType>(expectedType);
```

#### AUTO 


```{c}
auto* uInt32Editor = qobject_cast<UIntSpinBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& codecName : CharCodec::codecNames() )
        for( int i = 0; i < 256; ++i )
        {
            const QString rowTitle = codecName + QStringLiteral(" - %1").arg(i);
            QTest::newRow(rowTitle.toLatin1().constData()) << codecName << i;
        }
```

#### AUTO 


```{c}
auto* editor = new Octal8Editor(parent);
```

#### AUTO 


```{c}
auto type(static_cast<PrimitiveDataType>(expectedType));
```

#### AUTO 


```{c}
auto* uInt64Editor = qobject_cast<UIntSpinBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TabbedViews* viewArea : mViewAreaList) {
        const int localIndexOf = viewArea->indexOf(view);
        if (localIndexOf != -1) {
            result = globalBaseIndex + localIndexOf;
            break;
        }
        globalBaseIndex += viewArea->viewCount();
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int uuInputGroupLength = 3;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFrameRenderer* frameRenderer : std::as_const(mFrameRendererList)) {
            const int x = frameRenderer->x();
            const int y = frameRenderer->y();
            painter.translate(x, y);
            frameRenderer->renderFrame(&painter, pageIndex);
            painter.translate(-x, -y);
        }
```

#### AUTO 


```{c}
const auto filesInDir = localDir.entryList(QDir::Files);
```

#### AUTO 


```{c}
const auto& info
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto* keyEvent = static_cast<QKeyEvent*>(event);
```

#### CONST EXPRESSION 


```{c}
constexpr bool isBehindLineStart() const;
```

#### CONST EXPRESSION 


```{c}
static constexpr char XOrFilterConfigGroupId[] = "XOR";
```

#### CONST EXPRESSION 


```{c}
constexpr unsigned char unmatched = 0xFF;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) { onFormatChanged(index); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& name : structureNames )
            {
                QTreeWidgetItem* subItem = new QTreeWidgetItem(item,
                        QStringList { name, pluginName });
                item->addChild(subItem);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
        urls.append( syncManager->urlOf(document).url() );
```

#### AUTO 


```{c}
auto* sintEditor = qobject_cast<SIntSpinBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for( const TabbedViews* viewArea : mViewAreaList )
        result += viewArea->viewCount();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : qAsConst(altInfo)) {
            qDeleteAll(info.fields);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char DropperOctetStreamFormatName[] = "application/octet-stream";
```

#### RANGE FOR STATEMENT 


```{c}
for( const ArrayChangeMetrics& change : changeList )
    {
        //TODO: change parameters to ArrayChangeMetrics
        switch( change.type() )
        {
        case ArrayChangeMetrics::Replacement:
        {
            oldLength += change.lengthChange();
            const Address offset = change.offset();
            const Size diff = change.lengthChange();
            const Address behindLast = (diff == 0) ? offset + change.insertLength() :
                                       (diff < 0) ?  oldLength - diff :
                                                     oldLength;
            addChangedRange( offset, behindLast-1 );

            if( mSelection.isValid() )
                mSelection.adaptToReplacement( offset, change.removeLength(), change.insertLength() );
            if( mMarking.isValid() )
                mMarking.adaptToReplacement( offset, change.removeLength(), change.insertLength() );
            break;
        }
        case ArrayChangeMetrics::Swapping:
            addChangedRange( change.offset(), change.secondEnd() );

            if( mSelection.isValid() )
                mSelection.adaptToSwap( change.offset(), change.secondStart(), change.secondLength() );
            // TODO:
//             if( mMarking.isValid() )
//                 mMarking.adaptToSwap( change.offset(), change.secondStart(), change.secondLength() );
        default:
            ;
        }
    }
```

#### AUTO 


```{c}
auto* fullScreenAction = KStandardAction::fullScreen(this, &FullScreenController::switchFullScreen,
                                                         window, this);
```

#### AUTO 


```{c}
auto* fillerByteArrayModel =
        new Okteta::PieceTableByteArrayModel(QByteArray::fromRawData(fillerData, fillerDataSize), parent);
```

#### AUTO 


```{c}
auto* testDocument = new Kasten::TestDocument();
```

#### RANGE FOR STATEMENT 


```{c}
for (const AddressRange& addressRange : addressRangeList) {
        addAddressRange(addressRange);
    }
```

#### AUTO 


```{c}
auto* dataW = static_cast<DataInformationWithChildren*>(data);
```

#### AUTO 


```{c}
auto* u54 = new UnsignedBitfieldDataInformation(QStringLiteral("54"),
                                                                               54);
```

#### RANGE FOR STATEMENT 


```{c}
for( const Kasten::StructureDefinitionFile* def : structureDefs )
        {
            KPluginInfo info = def->pluginInfo();
            if (info.category() == QLatin1String("structure"))
                plugins.append(info);
            else if (info.category() == QLatin1String("structure/js"))
                dynamicPlugins.append(info);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QTreeWidgetItem* item : selected)
        {
            int idx = mTreeSelected->indexOfTopLevelItem(item);
            int newIdx = qMax(0, idx - 1);
            mTreeSelected ->insertTopLevelItem(newIdx,
                    mTreeSelected->takeTopLevelItem(idx));
            //only first index
            firstIndex = firstIndex == -1 ? newIdx : firstIndex;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for( QTreeWidgetItem* itm : qAsConst(toRemove) )
    {
        qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES)
                << "item " << QStringLiteral("\'%1\':\'%2\'").arg(itm->text(1),
                itm->text(0)) << "removed";
        delete mTreeSelected->takeTopLevelItem(mTreeSelected->indexOfTopLevelItem(itm));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* other : others) {
        total += other->size();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&otherCopy](const Piece& piece) mutable {
        otherCopy.append(piece);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int ShiftBitsPerByte = 8;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* top : std::as_const(primitives)) {
        checkProperties(primitiveProperties, top->actualDataInformation(), "primitives");
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int MachineOffsets[4] = { 0, 0, 0, 0 };
```

#### RANGE FOR STATEMENT 


```{c}
for( const JsTestData& data : qAsConst(allData) ) {
        QString codeStr = QStringLiteral("%1.set({typeName: 'myCustomType'});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1;obj.typeName = 'myCustomType'; obj;");
        QTest::newRow((data.tag + "-property assignment").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### AUTO 


```{c}
auto* view = action->data().value<AbstractView*>();
```

#### RANGE FOR STATEMENT 


```{c}
for( Kasten::AbstractXmlGuiController* controller : qAsConst(mControllers) )
            controller->setTargetModel( mByteArrayView );
```

#### RANGE FOR STATEMENT 


```{c}
for( const QUrl& url : urls )
            syncManager->load( url );
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool visible) { onToolVisibilityChanged(visible); }
```

#### AUTO 


```{c}
auto* validator = new QDoubleValidator(this);
```

#### AUTO 


```{c}
auto it = std::find_if(mViewList.constBegin(), mViewList.constEnd(), [widget](AbstractView* view) {
        return (view->widget() == widget);
    });
```

#### AUTO 


```{c}
auto* optionsBoxLayout = new QGridLayout(optionsBox);
```

#### AUTO 


```{c}
auto it = std::find_if(begin(), endIt, [offset](const Bookmark& bookmark) {
        return (bookmark.offset() == offset);
    });
```

#### AUTO 


```{c}
auto* ret = new SIntSpinBox(parent, Kasten::StructureViewPreferences::signedDisplayBase());
```

#### AUTO 


```{c}
auto* dialogButtonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto* synchronizer = new Kasten::TestDocumentFileSynchronizer();
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractColumnTextRenderer* renderer : std::as_const(columnTextRendererList)) {
        if (renderer->noOfSublinesNeeded() > subLinesCount) {
            subLinesCount = renderer->noOfSublinesNeeded();
        }
    }
```

#### AUTO 


```{c}
auto* document = view->findBaseModel<AbstractDocument*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& s : selected) {
        int pos = regex.indexIn(s);
        if (pos > -1) {
            QString pluginName = regex.cap(1);
            QString structName = regex.cap(2);
            if (structName == QLatin1String("*")) {
                // add all of them
                for (int i = 0; i < mTreeAvailable->topLevelItemCount(); i++) {
                    QTreeWidgetItem* avail = mTreeAvailable->topLevelItem(i);
                    if (avail->text(0) != pluginName) {
                        continue;
                    }
                    for (int i = 0; i < avail->childCount(); i++) {
                        QTreeWidgetItem* selStruct = avail->child(i);
                        QTreeWidgetItem* item = new QTreeWidgetItem(mTreeSelected,
                                                                    QStringList { selStruct->text(0), pluginName });
                        mTreeSelected->addTopLevelItem(item);
                    }

                    break;
                }
            } else {
                QTreeWidgetItem* item = new QTreeWidgetItem(mTreeSelected,
                                                            QStringList { structName, pluginName });
                mTreeSelected->addTopLevelItem(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto* tapAndHoldGesture = static_cast<TouchOnlyTapAndHoldGesture *>(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        AbstractDocument* document = view->findBaseModel<AbstractDocument*>();
        viewsToClosePerDocument[document].append(view);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile::Id& viewProfileId : viewProfileIds )
    {
        if( viewProfileId == mViewProfileId )
        {
            // TODO: really forget binding to that profile completely? cannot reappear?
            setViewProfileId( ByteArrayViewProfile::Id() );
            break;
        }
    }
```

#### AUTO 


```{c}
auto views = mViewArea->viewList();
```

#### CONST EXPRESSION 


```{c}
static constexpr int inputGroupLength = 5;
```

#### AUTO 


```{c}
const auto* spin = qobject_cast<const SIntSpinBox*> (w);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(dirtyColumns)) {
                    const PixelXRange xPixels = column->xsOfLinePositionsInclSpaces(changedPositions);

                    q->viewport()->update(xPixels.start() - xOffset, cy, xPixels.width(), lineHeight);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr int primitiveDataTypeCount =
    static_cast<int>(Kasten::SourceCodeStreamEncoderSettings::PrimitiveDataType::_Count);
```

#### RANGE FOR STATEMENT 


```{c}
for (Bookmark bookmark : qAsConst(bookmarksInFirstPart)) { // krazy:exclude=foreach
            bookmark.move(secondPartLength);
            insert(bIt, bookmark);
        }
```

#### AUTO 


```{c}
auto* dialog = new ViewProfileEditDialog(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile::Id& viewProfileId : qAsConst(removedViewProfileIds)) {
        viewProfileFileInfoLookup.remove(viewProfileId);
        if (viewProfileId == mDefaultViewProfileId) {
            mDefaultViewProfileId.clear();
        }
        // TODO: how to select new one?
    }
```

#### CONST EXPRESSION 


```{c}
constexpr bool operator!=(const Coord& other) const;
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char extendedSegmentAddressRecordCode = 0x2;
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultCount = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& valueCodecDescription : valueCodecDescriptions) {
        for (int j = 0; j < 256; ++j) {
            const QString rowTitle =
                QLatin1String(valueCodecDescription.name) +
                QStringLiteral(" - %1").arg(j);

            QTest::newRow(rowTitle.toLatin1().constData())
                << valueCodecDescription.id
                << Byte(j);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( int row : bookmarkIndizes )
        emit dataChanged( index(row,OffsetColumnId), index(row,TitleColumnId) );
```

#### AUTO 


```{c}
auto* mimeData = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* field : fi.fields) {
            field->setParent(this);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(dirtyColumns)) {
                column->renderEmptyColumn(painter, dirtyXs, dirtyYs);
            }
```

#### AUTO 


```{c}
auto* subItem = new QTreeWidgetItem(item, QStringList { name, pluginName });
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& encodingData : encodingDataList) {
        if (qstrcmp(codecName, encodingData.name) == 0) {
            result = true;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto* reverseParameterSet = static_cast<const ReverseByteArrayFilterParameterSet*>(parameterSet);
```

#### RANGE FOR STATEMENT 


```{c}
for(QTreeWidgetItem* item : selected)
        {
            delete mTreeSelected->takeTopLevelItem(
                    mTreeSelected->indexOfTopLevelItem(item));
            changed = true;
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (ToolViewDockWidget* dockWidget : std::as_const(mDockWidgets)) {
        if (dockWidget->isShown()) {
            dockWidget->toolView()->tool()->setTargetModel(view);
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int inputGroupLength = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& codecName : TextCharCodec::codecNames() )
        QTest::newRow(codecName.toLatin1().constData()) << codecName;
```

#### CONST EXPRESSION 


```{c}
constexpr int behindOffset1 = Offset1 + 1;
```

#### AUTO 


```{c}
auto* documentOfView = view->findBaseModel<AbstractDocument*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractXmlGuiController* controller : std::as_const(mControllers)) {
        controller->setTargetModel(view);
    }
```

#### AUTO 


```{c}
const auto coding = static_cast<ByteArrayValidator::Coding>(mFormatComboBox->currentIndex());
```

#### AUTO 


```{c}
auto* baseSplitter = static_cast<QSplitter*>(viewAreaWidget->parentWidget());
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile::Id& viewProfileId : std::as_const(removedViewProfileIds)) {
        viewProfileFileInfoLookup.remove(viewProfileId);
        if (viewProfileId == mDefaultViewProfileId) {
            mDefaultViewProfileId.clear();
        }
        // TODO: how to select new one?
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Bookmark& bookmark : bookmarks )
        removeBookmark( bookmark );
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& d : mData) {
        if (d.level >= minLevel) {
            ret << d.message;
        }
    }
```

#### AUTO 


```{c}
auto* loadThread = new ByteArrayRawFileLoadThread(this, file());
```

#### CONST EXPRESSION 


```{c}
static constexpr char RotateFilterConfigGroupId[] = "Rotate";
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractFrameRenderer *frameRenderer : qAsConst(mFrameRendererList) )
    {
        frameRenderer->prepare();
    }
```

#### AUTO 


```{c}
auto* openAction = KStandardAction::open(this, &LoaderController::load, this);
```

#### AUTO 


```{c}
auto* synchronizer = mDocument ? qobject_cast<AbstractModelFileSystemSynchronizer*>(mDocument->synchronizer()) : nullptr;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) { onValueActivated(index); }
```

#### CONST EXPRESSION 


```{c}
static constexpr  const char* PrimitiveDataTypeName[] = {
    "char",
    "unsigned char",
    "short",
    "unsigned short",
    "int",
    "unsigned int",
    "float",
    "double"
};
```

#### CONST EXPRESSION 


```{c}
static constexpr int StatisticsByteSetSize = 256;
```

#### AUTO 


```{c}
auto* mFilterEdit = new QLineEdit(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (Kasten::AbstractXmlGuiController* controller : std::as_const(mControllers)) {
            controller->setTargetModel(nullptr);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& def : info.enums) {
        if (def->name() == defName) {
            return def;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (StructureDefinitionFile* def : loadedDefs) {
        if (!def->isValid()) {
            continue;
        }
        QString pluginName = def->pluginInfo().pluginName();
        if (!def->pluginInfo().isPluginEnabled()) {
            continue;
        }
        QTreeWidgetItem* item = new QTreeWidgetItem(mTreeAvailable,
                                                    QStringList { def->pluginInfo().pluginName(), pluginName });
        const auto structureNames = def->structureNames();
        for (const QString& name : structureNames) {
            QTreeWidgetItem* subItem = new QTreeWidgetItem(item,
                                                           QStringList { name, pluginName });
            item->addChild(subItem);
        }

        availableItems.append(item);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int inputGroupLength = 3;
```

#### AUTO 


```{c}
auto* replaceUserQueryable = qobject_cast<If::ReplaceUserQueryable*>(m_userQueryAgent);
```

#### AUTO 


```{c}
auto* base32StreamEncoder = qobject_cast<ByteArrayBase32StreamEncoder*>(encoder);
```

#### AUTO 


```{c}
auto document = new Kasten::ByteArrayDocument(byteArray, QStringLiteral("init"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool isReadOnly) { onByteArrayReadOnlyChange(isReadOnly); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : mChildren) {
        size = qMax(size, child->size());
    }
```

#### AUTO 


```{c}
auto* data = new StringDataInformation(pd.name, encoding, pd.parent);
```

#### CONST EXPRESSION 


```{c}
static constexpr char MinimumLengthConfigKey[] = "MinimumLength";
```

#### CONST EXPRESSION 


```{c}
static constexpr int NofOfValueCodings = 4;
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char startLinearAddressRecordCode = 0x5;
```

#### CONST EXPRESSION 


```{c}
constexpr bool isValid() const;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFrameRenderer* frameRenderer : qAsConst(mFrameRendererList)) {
            const int x = frameRenderer->x();
            const int y = frameRenderer->y();
            painter.translate(x, y);
            frameRenderer->renderFrame(&painter, pageIndex);
            painter.translate(-x, -y);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Person& user : users) {
        mUserList.removeOne(user);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int ZoomSliderWidth = 150;
```

#### CONST EXPRESSION 


```{c}
static constexpr char WindowsListActionListId[] = "windows_list";
```

#### CONST EXPRESSION 


```{c}
constexpr bool isLaterInLineThan(const Coord& other) const;
```

#### AUTO 


```{c}
auto* randomGenerator = QRandomGenerator::global();
```

#### AUTO 


```{c}
auto* viewBox = static_cast<ViewBox*>(mTabWidget->widget(index));
```

#### CONST EXPRESSION 


```{c}
constexpr bool isLaterInLineThan(Coord other) const;
```

#### AUTO 


```{c}
auto* char8Editor = qobject_cast<Char8Editor*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (TabbedViews* viewArea : qAsConst(mViewAreaList)) {
        viewArea->removeViews(views);
    }
```

#### AUTO 


```{c}
auto* valuesBox = new QGroupBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int row : bookmarkIndizes) {
        emit dataChanged(index(row, OffsetColumnId), index(row, TitleColumnId));
    }
```

#### AUTO 


```{c}
auto areaWidget = mSingleViewArea->widget();
```

#### CONST EXPRESSION 


```{c}
static constexpr int Offset1 = 7;
```

#### AUTO 


```{c}
auto* pinchGesture = static_cast<QPinchGesture*>(gestureEvent->gesture(Qt::PinchGesture))
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : std::as_const(d->mColumns)) {
        columnRenderer->setLineHeight(d->mLineHeight);
    }
```

#### AUTO 


```{c}
auto* columnRenderer
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
    {
        if( ! mSyncManager->canClose(document) )
        {
            canClose = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto* dockWidget = new ToolViewDockWidget(toolView, q);
```

#### RANGE FOR STATEMENT 


```{c}
for( const ToolViewDockWidget* dockWidget : dockWidgets )
    {
        QAction *action = dockWidget->toggleViewAction();
        action->setText( dockWidget->windowTitle() );
//         action->setText( mToolView->title() );
        mToolActionList.append( action );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : qAsConst(allData)) {
        QString codeStr = QStringLiteral("%1.set({name: \"expectedName\"});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1;obj.name = \"expectedName\"; obj;");
        QTest::newRow((data.tag + "-property assignment").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### AUTO 


```{c}
auto* menu = new QMenu(q);
```

#### AUTO 


```{c}
auto* editWidget = new QLineEdit(parent);
```

#### AUTO 


```{c}
auto* tabWidget = new QTabWidget;
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char dataRecordCode = 0x0;
```

#### AUTO 


```{c}
auto* synchronizer = new Kasten::TestDocumentFileSynchronizer(header);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayBase32StreamEncoderConfigGroupId[] = "ByteArrayBase32StreamEncoder";
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractColumnTextRenderer* renderer : qAsConst(columnTextRendererList)) {
        if (renderer->noOfSublinesNeeded() > subLinesCount) {
            subLinesCount = renderer->noOfSublinesNeeded();
        }
    }
```

#### AUTO 


```{c}
auto* template_ParameterSet = static_cast<Template_ByteArrayFilterParameterSet*>(parameterSet);
```

#### RANGE FOR STATEMENT 


```{c}
for (const TabbedViews* viewArea : mViewAreaList) {
        result.append(viewArea->viewList());
    }
```

#### AUTO 


```{c}
auto* byteArray = new Okteta::PieceTableByteArrayModel(originalData);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : std::as_const(mChildren)) {
        child->setParent(this);
    }
```

#### AUTO 


```{c}
auto* viewArea = new TabbedViews();
```

#### CONST EXPRESSION 


```{c}
constexpr Coord(LinePosition pos, Line line);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile::Id& viewProfileId : viewProfileIds) {
        if (viewProfileId == mViewProfileId) {
            // TODO: really forget binding to that profile completely? cannot reappear?
            setViewProfileId(ByteArrayViewProfile::Id());
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : qAsConst(allData)) {
        QString codeStr = QStringLiteral("%1.set({typeName: 'myCustomType'});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1;obj.typeName = 'myCustomType'; obj;");
        QTest::newRow((data.tag + "-property assignment").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### AUTO 


```{c}
auto* filterJob = new FilterJob(byteArrayFilter, reinterpret_cast<Okteta::Byte*>(filterResult.data()), mByteArrayModel, filteredSection);
```

#### AUTO 


```{c}
auto* proxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto* dialog = new QFileDialog(QApplication::activeWindow());
```

#### AUTO 


```{c}
auto selectAllAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-select-all")),
                                           i18nc("@action:inmenu", "Select &All") + QLatin1Char('\t') + QKeySequence(QKeySequence::SelectAll).toString(QKeySequence::NativeText),
                                           mView, [this] { selectAll(); });
```

#### RANGE FOR STATEMENT 


```{c}
for( const QTreeWidgetItem* item : selected )
        {
            if (!item->parent())
                continue; //maybe sometime add all subitems
            QTreeWidgetItem* moveOver = new QTreeWidgetItem(mTreeSelected,
                    QStringList { item->text(0), item->text(1) });
            //item name then parent name then path
            mTreeSelected->addTopLevelItem(moveOver);
            changed = true;
        }
```

#### AUTO 


```{c}
auto printAction = mPart->actionCollection()->action(QStringLiteral("file_print"));
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : std::as_const(closedViews)) {
//         qCDebug(LOG_KASTEN_GUI) << view->title();
        delete view;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto d : qAsConst(digits)) {
        codec->appendDigit(&decodedByte, d.toLatin1());
    }
```

#### AUTO 


```{c}
auto* encoder = action->data().value<AbstractModelStreamEncoder*>();
```

#### CONST EXPRESSION 


```{c}
static constexpr char ModSum64ConfigGroupId[] = "ModularSum64";
```

#### CONST EXPRESSION 


```{c}
static constexpr char StringsExtractConfigGroupId[] = "StringsExtractTool";
```

#### CONST EXPRESSION 


```{c}
constexpr int BitsPerByte = 8;
```

#### AUTO 


```{c}
auto* advancedSelectionWidget = new StructureAddRemoveWidget(mSelectedStructures, mTool, this);
```

#### RANGE FOR STATEMENT 


```{c}
for( const KNS3::Entry& e : changedEntries )
        {
            qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "Changed Entry: " << e.name();
            if (e.status() == KNS3::Entry::Installed)
            {
                //new element installed
                qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "installed files:" << e.installedFiles();
            }
            if (e.status() == KNS3::Entry::Deleted)
            {
                //element uninstalled
                qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "deleted files:" << e.uninstalledFiles();
            }
        }
```

#### CONST EXPRESSION 


```{c}
constexpr int digitCount = 256;
```

#### AUTO 


```{c}
auto* titleChangeSpy =  new QSignalSpy(document, SIGNAL(titleChanged(QString)));
```

#### AUTO 


```{c}
auto it = std::find(primitiveDataTypeConfigValueList.cbegin(), primitiveDataTypeConfigValueList.cend(), entry);
```

#### AUTO 


```{c}
auto* that = const_cast<StatusBarLayout*>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : qAsConst(mColumns)) {
        columnRenderer->setX(mColumnsWidth);
        mColumnsWidth += columnRenderer->visibleWidth();
    }
```

#### AUTO 


```{c}
auto* change1 = new TestPieceTableChange(type1Id, description1, 1);
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : std::as_const(allData)) {
        QString codeStr = QStringLiteral("%1.setUpdate(") + updateFunction() + QStringLiteral(");");
        QTest::newRow((data.tag + "-setUpdate()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("%1.set({updateFunc: ") + updateFunction() + QStringLiteral("});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1; obj.updateFunc = ") + updateFunction() + QStringLiteral("; obj;");
        QTest::newRow((data.tag + "-property assign").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : qAsConst(allData)) {
        QString codeStr = QStringLiteral("%1.setUpdate(") + updateFunction() + QStringLiteral(");");
        QTest::newRow((data.tag + "-setUpdate()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("%1.set({updateFunc: ") + updateFunction() + QStringLiteral("});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1; obj.updateFunc = ") + updateFunction() + QStringLiteral("; obj;");
        QTest::newRow((data.tag + "-property assign").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelStreamEncoderConfigEditorFactory* factory : qAsConst(mEncoderFactoryList)) {
        mExporterFactoryList << new ModelEncoderFileSystemExporterConfigEditorFactory(factory);
    }
```

#### AUTO 


```{c}
const auto* edit = qobject_cast<const QLineEdit*> (w);
```

#### AUTO 


```{c}
auto* mouseEvent = static_cast<const QMouseEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : mChildren) {
        if (child == data) {
            return index;
        }
        index++;
    }
```

#### AUTO 


```{c}
const auto coding = static_cast<AddressValidator::Coding>(mFormatComboBox->currentIndex());
```

#### AUTO 


```{c}
const auto& data
```

#### AUTO 


```{c}
auto& data
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile& viewProfile : qAsConst(mViewProfiles)) {
        if (viewProfile.id() == viewProfileId) {
            isExisting = true;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int uuInputLineLength = defaultUuInputLineLength;
```

#### AUTO 


```{c}
auto* viewProfileSynchronizer = new Kasten::ByteArrayViewProfileSynchronizer(mViewProfileManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& dataFolderPath : dataFolderPaths) {
        const QString viewProfileFolderPath = dataFolderPath + viewProfileDirSubPath;
        // watch folder for changes
        mViewProfileFileWatcher->addDir(viewProfileFolderPath, KDirWatch::WatchDirOnly);

        // read current files
        onViewProfilesFolderChanged(viewProfileFolderPath);
    }
```

#### AUTO 


```{c}
auto* displaySettings = new StructureViewSettingsWidget();
```

#### AUTO 


```{c}
const auto& property
```

#### RANGE FOR STATEMENT 


```{c}
for( const Bookmark& bookmark : bookmarks )
        addBookmark( bookmark );
```

#### AUTO 


```{c}
const auto* otherRemoveChange = static_cast<const RemovePieceTableChange*>(other);
```

#### CONST EXPRESSION 


```{c}
static constexpr int maxInputGroupsPerLine = uuInputLineLength / uuInputGroupLength;
```

#### AUTO 


```{c}
auto* filterLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* searchJob =
            new SearchJob(mByteArrayModel, mSearchData, startIndex, endIndex, mCaseSensitivity, mByteArrayView->charCodingName());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QFileInfo& viewProfileFileInfo : viewProfileFileInfoList) {
        // a lock file ?
        if (viewProfileFileInfo.suffix() == QLatin1String("olock")) {
            const ByteArrayViewProfile::Id lockedViewProfileId = viewProfileFileInfo.baseName();
            // if not in old locks, is a new lock
            if (!newUnlockedViewProfileIds.removeOne(lockedViewProfileId)) {
                newLockedViewProfileIds.append(lockedViewProfileId);
            }
            continue;
        }

        // not a viewprofile file ?
        if (viewProfileFileInfo.suffix() != QLatin1String("obavp")) {
            continue;
        }

        // all other files assumed to be viewProfile files
        const ByteArrayViewProfile::Id viewProfileId = viewProfileFileInfo.baseName();
        // load file
        const ByteArrayViewProfile viewProfile = loadViewProfile(viewProfileFileInfo.absoluteFilePath());
        // loading failed? Treat as not existing
        if (viewProfile.id().isEmpty()) {
            continue;
        }

        const ByteArrayViewProfileFileInfoLookup::Iterator infoIt =
            viewProfileFileInfoLookup.find(viewProfileId);
        const bool isKnown = (infoIt != viewProfileFileInfoLookup.end());
        const QDateTime fileInfoLastModified = viewProfileFileInfo.lastModified();
        // is known?
        if (isKnown) {
            removedViewProfileIds.removeOne(viewProfileId);

            // check timestamp
            if (fileInfoLastModified == infoIt->lastModified()) {
                continue;
            }

            // update timestamp
            infoIt->setLastModified(fileInfoLastModified);
        } else {
            ByteArrayViewProfileFileInfo info(fileInfoLastModified, false);
            viewProfileFileInfoLookup.insert(viewProfileId, info);
        }

        if (isKnown) {
            auto it = std::find_if(mViewProfiles.begin(), mViewProfiles.end(),
                                   [&viewProfileId](const ByteArrayViewProfile& existingProfile) {
                return (existingProfile.id() == viewProfileId);
            });
            if (it != mViewProfiles.end()) {
                *it = viewProfile;
            }
        } else {
            newViewProfiles.append(viewProfile);
        }
        changedViewProfiles.append(viewProfile);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int byteCountLineSize = 1;
```

#### AUTO 


```{c}
auto* dataB = static_cast<DataInformationBase*> (index.internalPointer());
```

#### AUTO 


```{c}
auto* other
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(dirtyColumns)) {
                column->renderEmptyColumn(painter, dirtyXs, dirtyYs);
            }
```

#### CONST EXPRESSION 


```{c}
static constexpr int TRGroupSpacingWidth = 2;
```

#### AUTO 


```{c}
auto* valuesBoxFormLayout = new QFormLayout(valuesBox);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& valueCodecDescription : valueCodecDescriptions) {
        QTest::newRow(valueCodecDescription.name)
            << valueCodecDescription.id
            << valueCodecDescription.encodingWidth;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KNSCore::EntryInternal& e : changedEntries) {
        qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "Changed Entry: " << e.name();
        if (e.status() == KNS3::Entry::Installed) {
            // new element installed
            qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "installed files:" << e.installedFiles();
        }
        if (e.status() == KNS3::Entry::Deleted) {
            // element uninstalled
            qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES) << "deleted files:" << e.uninstalledFiles();
        }
    }
```

#### AUTO 


```{c}
auto& valueCodecDescription
```

#### AUTO 


```{c}
auto* filterSelectionToolBar = new QToolBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractPieceTableChange* change : mChangeStack) {
        if (change->type() == AbstractPieceTableChange::GroupId) {
            const GroupPieceTableChange* groupChange = static_cast<const GroupPieceTableChange*>(change);
            const ArrayChangeMetricsList metricsList = groupChange->groupMetrics(reverted);
            result += metricsList;
        } else {
            ArrayChangeMetrics changeMetrics = change->metrics();
            if (reverted) {
                changeMetrics.revert();
            }
            result.append(changeMetrics);
        }
    }
```

#### AUTO 


```{c}
auto view = new Kasten::ByteArrayView(document, nullptr);
```

#### AUTO 


```{c}
auto* previewBoxLayout = new QHBoxLayout(previewBox);
```

#### AUTO 


```{c}
auto* byteArray = new Okteta::PieceTableByteArrayModel(data);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(dirtyColumns)) {
                    const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(firstChangedPositions);

                    q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for( const TabbedViews* viewArea : mViewAreaList )
        result.append( viewArea->viewList() );
```

#### CONST EXPRESSION 


```{c}
static constexpr char ColorSchemeConfigKeyId[] = "ColorScheme";
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem* item : selected) {
        if (!item->parent()) {
            continue;     // maybe sometime add all subitems
        }
        QTreeWidgetItem* moveOver = new QTreeWidgetItem(mTreeSelected,
                                                        QStringList { item->text(0), item->text(1) });
        // item name then parent name then path
        mTreeSelected->addTopLevelItem(moveOver);
        changed = true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& path) { onFileDirty(path); }
```

#### AUTO 


```{c}
auto* authorLayout = new QVBoxLayout(authorWidget);
```

#### AUTO 


```{c}
auto* reloadThread =
        new TestDocumentFileReloadThread(this, testSynchronizer->header(), /*document, */ file());
```

#### AUTO 


```{c}
auto* ret = new UIntSpinBox(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : views )
    {
//         qCDebug(LOG_KASTEN_GUI)<<view->title();
        delete view;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int ReversedOffsets[4] = { 7, 6, 4, 0 };
```

#### AUTO 


```{c}
auto* printDialog = new PrintDialog(printer, QApplication::activeWindow());
```

#### AUTO 


```{c}
auto* column
```

#### AUTO 


```{c}
auto* l = new ScriptLogger();
```

#### AUTO 


```{c}
auto* aboutLabel = new QLabel;
```

#### AUTO 


```{c}
auto* writeThread =
        new TestDocumentFileWriteThread(this, testSynchronizer->header(), testDocument, file());
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile& viewProfile : qAsConst(mViewProfiles) )
    {
        if( viewProfile.id() == viewProfileId )
        {
            isExisting = true;
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { blinkCursor(); }
```

#### AUTO 


```{c}
const auto& algorithmEncodingData = base32EncodingData[static_cast<int>(mSettings.algorithmId)];
```

#### AUTO 


```{c}
const auto* otherInsertChange = static_cast<const InsertPieceTableChange*>(other);
```

#### AUTO 


```{c}
auto* document = new Kasten::ByteArrayDocument(byteArray, QStringLiteral("init"));
```

#### AUTO 


```{c}
const auto& encodingTypeData = base32EncodingData[static_cast<int>(mSettings.encodingType)];
```

#### AUTO 


```{c}
auto* model = const_cast<QAbstractItemModel *>(index.model());
```

#### AUTO 


```{c}
auto* editorLabel = new QLabel(remoteTypeName);
```

#### AUTO 


```{c}
auto* pageLayout = new QFormLayout();
```

#### CONST EXPRESSION 


```{c}
static constexpr int CharsetConversionBlockSize = 100000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ArrayChangeMetrics& change : changeList) {
        // cursor affected?
        if (mIndex >= change.offset()) {
            switch (change.type())
            {
            case ArrayChangeMetrics::Replacement:
                oldLength += change.lengthChange();
                if (oldLength > 0) {
                    const Address newIndex =
                        // cursor behind the removed section?
                        (mIndex >= change.offset() + change.removeLength()) ? mIndex + change.lengthChange() :
                        // cursor at substituted section?
                        (mIndex < change.offset() + change.insertLength()) ?  mIndex :
                        // cursor at unsubstituted section
                                                                              change.offset() + change.insertLength();

                    // if the cursor gets behind, it will never get inside again.
                    if (newIndex >= oldLength) {
                        gotoEnd();
                        return;
                    }
                    mIndex = newIndex;
                }
                // if the cursor gets at the start, it will stay there
                else {
                    gotoStart();
                    return;
                }
                break;
            case ArrayChangeMetrics::Swapping:
                if (mIndex < change.secondStart()) {
                    mIndex += change.secondLength();
                } else if (mIndex <= change.secondEnd()) {
                    mIndex -= change.firstLength();
                }
                break;
            default:
                ;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Bookmark& bookmark : *this )
        result.append( bookmark );
```

#### RANGE FOR STATEMENT 


```{c}
for (auto columnRenderer : qAsConst(mColumns)) {
        columnRenderer->setX(mColumnsWidth);
        mColumnsWidth += columnRenderer->visibleWidth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& e : entries) {
            const QString structureBasePath = structuresDir + QLatin1Char('/') + e;
            const QStringList desktopFiles =
                QDir(structureBasePath).entryList(QStringList(QStringLiteral("*.desktop")));
            for (const QString& desktopFile : desktopFiles) {
                paths << structureBasePath + QLatin1Char('/') + desktopFile;
            }
        }
```

#### AUTO 


```{c}
auto* editor = new Binary8Editor(parent);
```

#### CONST EXPRESSION 


```{c}
static constexpr int modifiedPixmapWidth = 16;
```

#### CONST EXPRESSION 


```{c}
static constexpr int mimeTypeUpdateTimeInterval = 500;
```

#### AUTO 


```{c}
const auto* otherReplaceChange = static_cast<const ReplacePieceTableChange*>(other);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& structure : structureNames) {
                appendEnabledStructureItem(enabledData.id, structure, isOnlyOne);
            }
```

#### AUTO 


```{c}
auto* generateThread = new ModelDataGenerateThread(this, generator);
```

#### AUTO 


```{c}
auto* editorPageLayout = new QVBoxLayout(editorPage);
```

#### AUTO 


```{c}
auto* action = new QAction(title, mCopyAsSelectAction);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : qAsConst(mAlternatives)) {
        qDeleteAll(fi.fields);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* current : qAsConst(mChildren)) {
        if (current == child) {
            return offset;
        }
        offset += current->size();
    }
```

#### AUTO 


```{c}
auto* parameterSetLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto it = enumValues.begin(), end = enumValues.end();
```

#### AUTO 


```{c}
auto* structure
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : std::as_const(mList)) {
        if ((document != keptDocument) &&
            !mSyncManager->canClose(document)) {
            canCloseAll = false;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ShiftFilterConfigGroupId[] = "Shift";
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* itm : qAsConst(toRemove)) {
        qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES)
            << "item " << QStringLiteral("\'%1\':\'%2\'").arg(itm->text(1),
                                                              itm->text(0)) << "removed";
        delete mTreeSelected->takeTopLevelItem(mTreeSelected->indexOfTopLevelItem(itm));
    }
```

#### AUTO 


```{c}
auto* propertyGrid = new QGridLayout();
```

#### CONST EXPRESSION 


```{c}
static constexpr char Description[] = "description";
```

#### RANGE FOR STATEMENT 


```{c}
for( const JsTestData& data : qAsConst(allData) ) {
        QString codeStr = QStringLiteral("%1.setUpdate(") + updateFunction() + QStringLiteral(");");
        QTest::newRow((data.tag + "-setUpdate()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("%1.set({updateFunc: ") + updateFunction() + QStringLiteral("});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1; obj.updateFunc = ") + updateFunction() + QStringLiteral("; obj;");
        QTest::newRow((data.tag + "-property assign").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr const char* base32PaddingData[4] =
{
    "======",
    "====",
    "===",
    "="
};
```

#### AUTO 


```{c}
const auto definitionIt = mDefs.find(pluginName);
```

#### LAMBDA EXPRESSION 


```{c}
[&id](const StructureEnabledData& data) {
        return (data.id == id) && data.isEnabled;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxPreviewSize = 100;
```

#### AUTO 


```{c}
auto* label = new QLabel(i18n("Type:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile::Id& viewProfileId : viewProfileIds) {
        removeViewProfile(viewProfileId);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : selected) {
        int idx = mTreeSelected->indexOfTopLevelItem(item);
        int newIdx = qMax(0, idx - 1);
        mTreeSelected->insertTopLevelItem(newIdx,
                                          mTreeSelected->takeTopLevelItem(idx));
        // only first index
        firstIndex = firstIndex == -1 ? newIdx : firstIndex;
    }
```

#### AUTO 


```{c}
auto* item = new QTreeWidgetItem(mTreeSelected, QStringList { selStruct->text(0), pluginName });
```

#### CONST EXPRESSION 


```{c}
static constexpr char base32HexEncodeMap[32] =
{
    '0', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
    'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
    'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V'
};
```

#### CONST EXPRESSION 


```{c}
static constexpr char NotExistingUrlName[] = "not://existing";
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        view->disconnect(q);

        index = indexOf(view);
        if (index != -1) {
            auto* viewBox = static_cast<ViewBox*>(mTabWidget->widget(index));

            mTabWidget->removeTab(index);
            delete viewBox;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(d->columns)) {
        column->setLineHeight(d->LineHeight);
    }
```

#### AUTO 


```{c}
auto* copyAction =  KStandardAction::copy(this, &PODTableView::copyToClipboard,  this);
```

#### AUTO 


```{c}
auto* aboutButton = new QPushButton;
```

#### RANGE FOR STATEMENT 


```{c}
for (const TabbedViews* viewArea : mViewAreaList) {
        result += viewArea->viewCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& encodingData : encodingDataList) {
        if (qstrcmp(codecName, encodingData.name) == 0) {
            result = true;
            break;
        }
    }
```

#### AUTO 


```{c}
auto* spin = qobject_cast<SIntSpinBox*>(w);
```

#### AUTO 


```{c}
auto it = std::find(codingConfigValueList.cbegin(), codingConfigValueList.cend(), entry);
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:spinbox number of bytes to insert", "Number (bytes):"), this);
```

#### AUTO 


```{c}
auto* testData = new KTestData(size + 3 * insertSize, insertSize);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& data : testData) {
        QTest::newRow(QString(data.name+QLatin1String("-forward-frombegin")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(0) << false << QVector<Kasten::ReplaceBehaviour>();
        QTest::newRow(QString(data.name+QLatin1String("-backward-fromend")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(data.originalData.length()) << true << QVector<Kasten::ReplaceBehaviour>();
        QTest::newRow(QString(data.name+QLatin1String("-forward-frommiddle")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(4) << false << QVector<Kasten::ReplaceBehaviour>();
        QTest::newRow(QString(data.name+QLatin1String("-backward-frommiddle")).toLatin1().constData())
            << data.originalData << data.searchData
            << data.replaceData << data.expectedData << data.expectedReplacementCount
            << Okteta::Address(3) << true << QVector<Kasten::ReplaceBehaviour>();
    }
```

#### AUTO 


```{c}
auto* labelledInsertCountEdit = new LabelledToolBarWidget(label, mInsertCountEdit, this);
```

#### CONST EXPRESSION 


```{c}
static constexpr int BAFInitialHeight = 50;
```

#### AUTO 


```{c}
auto* exporter
```

#### AUTO 


```{c}
const auto* crc64ParameterSet =
        static_cast<const Crc64ByteArrayChecksumParameterSet*>(parameterSet);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : children) {
            mCutControl = qobject_cast<If::SelectedDataCutable*>(child);
            if (mCutControl) {
                connect(child, SIGNAL(canCutSelectedDataChanged(bool)),
                        this, SLOT(onCanCutSelectedDataChanged(bool)));
                break;
            }
        }
```

#### AUTO 


```{c}
auto* noneAction = new QAction(i18nc("@item There are no generators.", "Not available."), mInsertSelectAction);
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractPieceTableChange* change : mChangeStack )
    {
        if( change->type() == AbstractPieceTableChange::GroupId )
        {
            const GroupPieceTableChange *groupChange = static_cast<const GroupPieceTableChange*>(change);
            const ArrayChangeMetricsList metricsList = groupChange->groupMetrics( reverted );
            result += metricsList;
        }
        else
        {
            ArrayChangeMetrics changeMetrics = change->metrics();
            if( reverted )
                changeMetrics.revert();
            result.append( changeMetrics );
        }
    }
```

#### AUTO 


```{c}
auto* action = new QAction(title, mExportSelectAction);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractModelExporterConfigEditorFactory* factory : mExporterFactoryList) {
        result = factory->tryCreateConfigEditor(exporter);
        if (result) {
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( StructureDefinitionFile* def : loadedDefs )
    {
        if (!def->isValid())
            continue;
        QString pluginName = def->pluginInfo().pluginName();
        if (!def->pluginInfo().isPluginEnabled())
            continue;
        QTreeWidgetItem* item = new QTreeWidgetItem(mTreeAvailable,
                QStringList { def->pluginInfo().pluginName(), pluginName });
        const auto structureNames = def->structureNames();
        for( const QString& name : structureNames )
            {
                QTreeWidgetItem* subItem = new QTreeWidgetItem(item,
                        QStringList { name, pluginName });
                item->addChild(subItem);
            }
        availableItems.append(item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int failedByteCount : failedPerByteCount) {
                totalFailedByteCount += failedByteCount;
            }
```

#### AUTO 


```{c}
auto* doc3 = new Kasten::TestDocument();
```

#### AUTO 


```{c}
auto* tapAndHoldGesture = static_cast<TouchOnlyTapAndHoldGesture*>(state);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(dirtyColumns)) {
                    const PixelXRange xPixels = column->xsOfLinePositionsInclSpaces(changedPositions);

                    q->viewport()->update(xPixels.start() - xOffset, cy, xPixels.width(), lineHeight);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* structure : structs) {
                    addChildItem(structure);
                }
```

#### AUTO 


```{c}
auto* change4 = new TestPieceTableChange(type4Id, description4, 4);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : qAsConst(mAlternatives) )
    {
        for (int i = 0; i <  fi.fields.size(); ++i)
            fi.fields.at(i)->setParent(this);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char startCode = ':';
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        view->disconnect(q);

        index = indexOf(view);
        if (index != -1) {
            ViewBox* viewBox = static_cast<ViewBox*>(mTabWidget->widget(index));

            mTabWidget->removeTab(index);
            delete viewBox;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int TestDataSize = 50;
```

#### AUTO 


```{c}
const auto* byteArraySelection = static_cast<const ByteArraySelection*>(modelSelection);
```

#### AUTO 


```{c}
auto* editorLabel = new QLabel(mConfigEditor->name());
```

#### AUTO 


```{c}
auto* sInt64Editor = qobject_cast<SIntSpinBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem* item : selected) {
        if (!item->parent()) {
            continue;     // maybe sometime add all subitems
        }
        const bool isOnlyOne = item->data(OnlyOneRowColumn, ::OnlyOneRole).toBool();
        const QString id = item->text(1);
        const QString structure = item->text(0);
        appendEnabledStructureItem(id, structure, isOnlyOne);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int ByteSetSize = 256;
```

#### RANGE FOR STATEMENT 


```{c}
for( const TabbedViews* viewArea : mViewAreaList )
    {
        const int localIndexOf = viewArea->indexOf( view );
        if( localIndexOf != -1 )
        {
            result = globalBaseIndex + localIndexOf;
            break;
        }
        globalBaseIndex += viewArea->viewCount();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : qAsConst(closedDocuments) )
    {
        delete document;
    }
```

#### AUTO 


```{c}
auto* byteArray = qobject_cast<Okteta::PieceTableByteArrayModel*>(mDocument->content());
```

#### AUTO 


```{c}
auto* separator = new KSeparator(Qt::Horizontal, this);
```

#### AUTO 


```{c}
auto* settingsBox = new QGroupBox(i18nc("@title:group", "Parameters"), this);
```

#### AUTO 


```{c}
auto* helpEvent = static_cast<QHelpEvent*>(event);
```

#### AUTO 


```{c}
auto* change = new RemovePieceTableChange(removeRange, removedPieces);
```

#### AUTO 


```{c}
auto* pieceTableChange =
        new TestPieceTableChange(0, QString(),
                                 TestOffset, StorageOffset, Piece::ChangeStorage,
                                 ReplacedStorageOffset);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        for (int b = 0; b < 256; ++b) {
            for (uint r = 1; r <= valueCodecDescription.encodingWidth; ++r) {
                const QString rowTitle =
                    QLatin1String(valueCodecDescription.name) +
                    QStringLiteral(" - %1 - removed last %2").arg(b).arg(r);

                QTest::newRow(rowTitle.toLatin1().constData())
                    << valueCodecDescription.id
                    << Byte(b)
                    << r;
            }
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int RotateBitsPerByte = 8;
```

#### CONST EXPRESSION 


```{c}
static constexpr int Offset2 = 23;
```

#### CONST EXPRESSION 


```{c}
static constexpr const char* UIFileName[] =
{
    "oktetapartreadonlyui.rc",
    "oktetapartbrowserui.rc",
    "oktetapartreadwriteui.rc"
};
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultViewProfileShowingNonprinting = false;
```

#### AUTO 


```{c}
auto* defaultViewProfileWatcher = new KDirWatch(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : qAsConst(d->columns)) {
        column->setLineHeight(d->LineHeight);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { onReturnPressed(); }
```

#### RANGE FOR STATEMENT 


```{c}
for( ToolViewDockWidget* dockWidget : qAsConst(mDockWidgets) )
    {
        if( dockWidget->isShown() )
            dockWidget->toolView()->tool()->setTargetModel( view );
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int FilteredByteCountSignalLimit = 10000;
```

#### AUTO 


```{c}
auto it = dirtyColumns.constBegin();
```

#### AUTO 


```{c}
auto* baseLayout = new QFormLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for( Kasten::AbstractXmlGuiController* controller : qAsConst(mControllers) )
            controller->setTargetModel( nullptr );
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kasten::StructureDefinitionFile* def : structureDefs) {
        const StructureMetaData metaData = def->metaData();
        m_metaDataList.append(metaData);
        ids.insert(metaData.id(), def->structureNames());
    }
```

#### AUTO 


```{c}
auto* dialog = new ViewProfilesManageDialog(mViewProfileManager, mParentWidget);
```

#### AUTO 


```{c}
auto* pieceTableChange =
        new RemovePieceTableChange(AddressRange(Start, End), PieceList(removedPiece));
```

#### CONST EXPRESSION 


```{c}
constexpr int secondLength = Distance34;
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractPieceTableChange* change : mChangeStack )
    {
        if( change->type() == AbstractPieceTableChange::GroupId )
        {
            const GroupPieceTableChange* groupChange = static_cast<const GroupPieceTableChange*>(change);
            const AddressRangeList changedRangeList = groupChange->applyGroup( pieceTable );
            result.addAddressRangeList( changedRangeList );
        }
        else
            result.append( change->apply(pieceTable) );
    }
```

#### AUTO 


```{c}
auto* dialog = new ExportDialog(exporter->remoteTypeName(), configEditor, exporter,
                                        QApplication::activeWindow());
```

#### RANGE FOR STATEMENT 


```{c}
for (TabbedViews* viewArea : qAsConst(mViewAreaList)) {
        const int localIndex = viewArea->indexOf(view);
        if (localIndex != -1) {
            viewArea->setViewFocus(view);
            break;
        }
    }
```

#### AUTO 


```{c}
auto* modelEncoderFileSystemExporter = qobject_cast<ModelEncoderFileSystemExporter*>(exporter);
```

#### AUTO 


```{c}
auto* engine = new QScriptEngine(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : d.mAlternatives) {
        mAlternatives.append(FieldInfo(fi.name, fi.selectIf, cloneList(fi.fields, this)));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& property : qAsConst(mIterableProperties)) {
        if (property.first == name) {
            return result | property.second;
        }
    }
```

#### AUTO 


```{c}
auto* gestureEvent = static_cast<QGestureEvent*>(event);
```

#### AUTO 


```{c}
auto* buttonBox = new QDialogButtonBox(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* itm : std::as_const(toRemove)) {
        qCDebug(LOG_KASTEN_OKTETA_CONTROLLERS_STRUCTURES)
            << "item " << QStringLiteral("\'%1\':\'%2\'").arg(itm->text(1),
                                                              itm->text(0)) << "removed";
        delete mTreeSelected->takeTopLevelItem(mTreeSelected->indexOfTopLevelItem(itm));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : qAsConst(allData)) {
        QString codeStr = QStringLiteral("%1.setValidation(") + validationFunction() + QStringLiteral(");");
        QTest::newRow((data.tag + "-setUpdate()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("%1.set({validationFunc: ") + validationFunction() + QStringLiteral("});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1; obj.validationFunc = ") + validationFunction() + QStringLiteral("; obj;");
        QTest::newRow((data.tag + "-property assign").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(dirtyColumns)) {
                    const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(lastChangedPositions);

                    q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr int TestOffset = 30;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        for (int j = 0; j < 256; ++j) {
            const QString rowTitle =
                QLatin1String(valueCodecDescription.name) +
                QStringLiteral(" - %1").arg(j);

            QTest::newRow(rowTitle.toLatin1().constData())
                << valueCodecDescription.id
                << Byte(j);
        }
    }
```

#### AUTO 


```{c}
auto* dialog = new KConfigDialog(this, QStringLiteral("Structures Tool Settings"),
                                     StructureViewPreferences::self());
```

#### AUTO 


```{c}
auto d
```

#### RANGE FOR STATEMENT 


```{c}
for (TabbedViews* viewArea : std::as_const(mViewAreaList)) {
        const int localIndex = viewArea->indexOf(view);
        if (localIndex != -1) {
            viewArea->setViewFocus(view);
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int defaultUuInputLineLength = 45;
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned int DefaultLevel = 127;
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultInvertsBits = false;
```

#### AUTO 


```{c}
auto* charsBox = new QGroupBox(this);
```

#### AUTO 


```{c}
auto* labelledMinLengthSpinBox = new LabelledToolBarWidget(label, mMinLengthSpinBox, this);
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile& viewProfile : viewProfiles )
    {
        if( viewProfile.id() == mViewProfileId )
        {
            updateView( viewProfile );
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractColumnTextRenderer* renderer : qAsConst(columnTextRendererList) )
            renderer->renderNextLine( &textStream, isSubline );
```

#### AUTO 


```{c}
auto* change = new InsertPieceTableChange(dataOffset, length, *storageOffset);
```

#### AUTO 


```{c}
auto* filterToolBar = new QToolBar(this);
```

#### AUTO 


```{c}
const auto loadedDocuments = mDocumentManager->documents();
```

#### CONST EXPRESSION 


```{c}
constexpr int maxDataPerLineCount = 255;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : qAsConst(mChildren)) {
        child->setParent(mParent);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultSingleStep = 20;
```

#### AUTO 


```{c}
auto* sourceCodeStreamEncoder = qobject_cast<ByteArraySourceCodeStreamEncoder*>(encoder);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto columnRenderer : qAsConst(d->mColumns)) {
        columnRenderer->setLineHeight(d->mLineHeight);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char NotExistingUrl[] = "notexisting://";
```

#### RANGE FOR STATEMENT 


```{c}
for( const JsTestData& data : qAsConst(allData) ) {
        QString codeStr = QStringLiteral("%1.set({name: \"expectedName\"});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1;obj.name = \"expectedName\"; obj;");
        QTest::newRow((data.tag + "-property assignment").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### AUTO 


```{c}
auto* dataInf = new ArrayDataInformation(QStringLiteral("values"),
                                                             model->size() / sizeof(T),
                                                             PrimitiveFactory::newInstance(QStringLiteral("value"), primType, lwc));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* bitField : std::as_const(bitfields)) {
        basicTest(bitField, exp);
    }
```

#### AUTO 


```{c}
auto* firstViewArea = static_cast<TabbedViews*>(_viewArea);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultNoOfGroupedBytes = 4;
```

#### AUTO 


```{c}
auto* binary8Editor = qobject_cast<Binary8Editor*>(editor);
```

#### AUTO 


```{c}
auto* item = static_cast<DataInformation*> (index.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractXmlGuiController* controller : qAsConst(mControllers) )
        controller->setTargetModel( view );
```

#### CONST EXPRESSION 


```{c}
static constexpr int maxChunkSize = 1024 * 10;
```

#### AUTO 


```{c}
auto* viewArea = qobject_cast<TabbedViews*>(q->sender());
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label size of selected bytes", "Size:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        if (!mSyncManager->canClose(document)) {
            canClose = false;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int NoOfCodings = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelStreamEncoder* encoder : qAsConst(mEncoderList)) {
        mExporterList << new ModelEncoderFileSystemExporter(encoder);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultNoOfBytesPerLine =  16;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto *algorithm : qAsConst(mAlgorithmList)) {
        algorithm->loadConfig(configGroup);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayRandomDataGeneratorConfigGroupId[] = "ByteArrayRandomDataGenerator";
```

#### RANGE FOR STATEMENT 


```{c}
for( const JsTestData& data : qAsConst(allData) ) {
        QString codeStr = QStringLiteral("%1.setValidation(") + validationFunction() + QStringLiteral(");");
        QTest::newRow((data.tag + "-setUpdate()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("%1.set({validationFunc: ") + validationFunction() + QStringLiteral("});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1; obj.validationFunc = ") + validationFunction() + QStringLiteral("; obj;");
        QTest::newRow((data.tag + "-property assign").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxFontPointSize = 128;
```

#### AUTO 


```{c}
auto columnRenderer
```

#### AUTO 


```{c}
auto* selectAction = new QAction(i18nc("@action:button", "&Select"), this);
```

#### AUTO 


```{c}
auto* byteArrayDocument = qobject_cast<ByteArrayDocument*>(document);
```

#### CONST EXPRESSION 


```{c}
static constexpr int exampleInitialDataSize = sizeof(exampleInitialData) / sizeof(exampleInitialData[0]);
```

#### CONST EXPRESSION 


```{c}
constexpr int recordCountLineSize = 2;
```

#### CONST EXPRESSION 


```{c}
static constexpr int MaxMenuEntries = 10;
```

#### AUTO 


```{c}
auto byteArray = new Okteta::PieceTableByteArrayModel(originalData);
```

#### AUTO 


```{c}
auto it = columnRenderers.constBegin();
```

#### CONST EXPRESSION 


```{c}
constexpr bool isAbove(Line line) const;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& text) { onValueEdited(text); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        for (int b = 0; b < 256; ++b) {
            for (uint r = 1; r <= valueCodecDescription.encodingWidth; ++r) {
                const QString rowTitle =
                    QLatin1String(valueCodecDescription.name) +
                    QString(QStringLiteral(" - %1 - removed last %2")).arg(b).arg(r);

                QTest::newRow(rowTitle.toLatin1().constData())
                    << valueCodecDescription.id
                    << Byte(b)
                    << r;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : std::as_const(mList)) {
        if (!mSyncManager->canClose(document)) {
            canCloseAll = false;
            break;
        }
    }
```

#### AUTO 


```{c}
auto* frame = qobject_cast<QFrame*>(terminalWidget);
```

#### AUTO 


```{c}
auto* logger = new ScriptLogger();
```

#### CONST EXPRESSION 


```{c}
static constexpr int byteCountLineOffset = 0;
```

#### AUTO 


```{c}
auto it = std::find_if(mViewProfiles.begin(), mViewProfiles.end(),
                                   [&viewProfileId](const ByteArrayViewProfile& existingProfile) {
                return (existingProfile.id() == viewProfileId);
            });
```

#### CONST EXPRESSION 


```{c}
static constexpr int outputGroupLength = 4;
```

#### AUTO 


```{c}
auto* actionsLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* startOffsetLayout = new QHBoxLayout();
```

#### LAMBDA EXPRESSION 


```{c}
[&](const Okteta::ArrayChangeMetricsList& changeList) { onContentsChanged(changeList); }
```

#### AUTO 


```{c}
auto* layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& fileName : filesInDir )
    {
        if( !localDir.remove(fileName) )
            qWarning("%s: removing failed", qPrintable( fileName ));
    }
```

#### CONST EXPRESSION 


```{c}
constexpr bool cantCreateBookmark = false;
```

#### AUTO 


```{c}
auto* loadThread = new TestDocumentFileLoadThread(this, testSynchronizer->header(), file());
```

#### AUTO 


```{c}
auto* aboutLayout = new QVBoxLayout(aboutWidget);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
            mDocumentStrategy->load(url);
        }
```

#### AUTO 


```{c}
auto* widget = new Widget;
```

#### AUTO 


```{c}
auto hasViewProfileId = [&viewProfileId] (const ByteArrayViewProfile& existingProfile) {
                return (viewProfileId == existingProfile.id());
            };
```

#### AUTO 


```{c}
auto* insertToolBar = new QToolBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedRows) {
        const int i = mSortFilterProxyModel->mapToSource(index).row();
        strings += containedStringList->at(i).string();
        strings += QLatin1Char('\n'); // TODO: specific linefeed for platforms
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayXxencodingStreamEncoderConfigGroupId[] = "ByteArrayXxencodingStreamEncoder";
```

#### CONST EXPRESSION 


```{c}
constexpr int shorter = 5;
```

#### AUTO 


```{c}
auto* closingSpy = new QSignalSpy(documentManager, SIGNAL(closing(QVector<Kasten::AbstractDocument*>)));
```

#### AUTO 


```{c}
auto* change =
        new ReplacePieceTableChange(AddressRange::fromWidth(dataOffset, 1), 1, *storageSize, replacedPieces);
```

#### AUTO 


```{c}
auto* settingsToolBar = new QToolBar(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const ArrayChangeMetrics& change : changeList) {
        // TODO: change parameters to ArrayChangeMetrics
        switch (change.type())
        {
        case ArrayChangeMetrics::Replacement:
        {
            oldLength += change.lengthChange();
            const Address offset = change.offset();
            const Size diff = change.lengthChange();
            const Address behindLast = (diff == 0) ? offset + change.insertLength() :
                                       (diff < 0) ?  oldLength - diff :
                                                     oldLength;
            addChangedRange(offset, behindLast - 1);

            if (mSelection.isValid()) {
                mSelection.adaptToReplacement(offset, change.removeLength(), change.insertLength());
            }
            if (mMarking.isValid()) {
                mMarking.adaptToReplacement(offset, change.removeLength(), change.insertLength());
            }
            break;
        }
        case ArrayChangeMetrics::Swapping:
            addChangedRange(change.offset(), change.secondEnd());

            if (mSelection.isValid()) {
                mSelection.adaptToSwap(change.offset(), change.secondStart(), change.secondLength());
            }
        // TODO:
//             if( mMarking.isValid() )
//                 mMarking.adaptToSwap( change.offset(), change.secondStart(), change.secondLength() );
        default:
            ;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { onToggled(); }
```

#### LAMBDA EXPRESSION 


```{c}
[&removedPieceList](const Piece& piece) mutable {
                        removedPieceList.append(piece);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const FieldInfo& fi : qAsConst(mAlternatives)) {
        for (auto* field : fi.fields) {
            field->setParent(this);
        }
    }
```

#### AUTO 


```{c}
auto* currentGroupedViews = static_cast<AbstractGroupedViews*>(mGroupedViews->viewAreaFocus());
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile& viewProfile : viewProfiles) {
        const QString title = viewProfile.viewProfileTitle();
        auto* action = new QAction(title, mViewProfilesActionGroup);
        action->setCheckable(true);
        const ByteArrayViewProfile::Id viewProfileId = viewProfile.id();
        action->setData(viewProfileId);
        const bool isCurrentViewProfile = (viewProfileId == currentViewProfileId);
        action->setChecked(isCurrentViewProfile);
        if (isCurrentViewProfile) {
            isCurrentViewProfileExisting = true;
        }

        mViewProfilesActionGroup->addAction(action);
        mViewProfileActionMenu->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* top : qAsConst(primitives)) {
        checkProperties(primitiveProperties, top->actualDataInformation(), "primitives");
    }
```

#### AUTO 


```{c}
auto* action = new QAction(title, mViewProfilesActionGroup);
```

#### AUTO 


```{c}
auto* editor = new Float32Editor(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : mChildren) {
        total += child->size();
    }
```

#### AUTO 


```{c}
auto* calculateLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(d->columns)) {
                    column->renderColumn(painter, dirtyXs, dirtyYs);
                }
```

#### AUTO 


```{c}
auto* sInt8Editor = qobject_cast<SIntSpinBox*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& codecName : CharCodec::codecNames() )
        QTest::newRow(codecName.toLatin1().constData()) << codecName;
```

#### AUTO 


```{c}
auto* top
```

#### AUTO 


```{c}
const auto& def
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractByteArrayFilter* filter : filterList )
    {
        mOperationComboBox->addItem( filter->name() );

        const char* parameterSetId = filter->parameterSet()->id();
        AbstractByteArrayFilterParameterSetEdit* parameterEdit =
            ByteArrayFilterParameterSetEditFactory::createEdit( parameterSetId );

        mParameterSetEditStack->addWidget( parameterEdit );
    }
```

#### AUTO 


```{c}
auto* doc2 = new Kasten::TestDocument();
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
    {
        connect( document, &AbstractDocument::synchronizerChanged,
                 this, &DocumentListModel::onSynchronizerChanged );
        AbstractModelSynchronizer* synchronizer = document->synchronizer();
        if( synchronizer )
        {
            connect( synchronizer, &AbstractModelSynchronizer::localSyncStateChanged,
                     this, &DocumentListModel::onSyncStatesChanged );
            connect( synchronizer, &AbstractModelSynchronizer::remoteSyncStateChanged,
                     this, &DocumentListModel::onSyncStatesChanged );
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int upperSegmentBaseAddressSize = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractModelExporterConfigEditorFactory* factory : mExporterFactoryList )
    {
        result = factory->tryCreateConfigEditor( exporter );
        if( result )
            break;
    }
```

#### AUTO 


```{c}
auto* updateToolBar = new QToolBar(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this] { redo(); }
```

#### AUTO 


```{c}
auto* baseSplitter = static_cast<QSplitter*>(firstViewAreaWidget->parentWidget());
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestFileName2[] = "test2.data";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(dirtyColumns)) {
                        const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(fullPositions);

                        q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile::Id& viewProfileId : qAsConst(removedViewProfileIds) )
    {
        viewProfileFileInfoLookup.remove( viewProfileId );
        if( viewProfileId == mDefaultViewProfileId )
            mDefaultViewProfileId.clear();
        // TODO: how to select new one?
    }
```

#### AUTO 


```{c}
const auto structureNames = def->structureNames();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Piece& piece : mList) {
        dataRange.setEndByWidth(piece.width());

        if (dataRange.includes(dataOffset)) {
            *storageId = piece.storageId();
// qCDebug(LOG_OKTETA_CORE) <<piece.start()<<"+"<<dataRange.localIndex( dataOffset );
            *storageOffset = piece.start() + dataRange.localIndex(dataOffset);
            result = true;
            break;
        }
        dataRange.setStart(dataRange.nextBehindEnd());
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ToolListActionListId[] = "tools_list";
```

#### CONST EXPRESSION 


```{c}
static constexpr int Size = sizeof(double);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArrayIHexStreamEncoderConfigGroupId[] = "ByteArrayIntelHexStreamEncoder";
```

#### AUTO 


```{c}
auto cutAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-cut")),
                                     i18nc("@action:inmenu", "Cu&t") + QLatin1Char('\t') + QKeySequence(QKeySequence::Cut).toString(QKeySequence::NativeText),
                                     mView, &AbstractByteArrayView::cut);
```

#### AUTO 


```{c}
auto* titleChangedSpy = new QSignalSpy(document, SIGNAL(titleChanged(QString)));
```

#### AUTO 


```{c}
auto* modSumParameterSet =
        static_cast<ModSumByteArrayChecksumParameterSet*>(parameterSet);
```

#### AUTO 


```{c}
auto* versionable = qobject_cast<Okteta::Versionable*>(mView->byteArrayModel());
```

#### AUTO 


```{c}
auto* writeThread = new TestDocumentFileWriteThread(this, testSynchronizer->header(), document, file());
```

#### RANGE FOR STATEMENT 


```{c}
for (Kasten::AbstractXmlGuiController* controller : qAsConst(mControllers)) {
            controller->setTargetModel(nullptr);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int BAFInitialWidth = 50;
```

#### RANGE FOR STATEMENT 


```{c}
for (TabbedViews* viewArea : std::as_const(mViewAreaList)) {
        viewArea->removeViews(views);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto* actionName : ToolbarActionNames) {
        QAction* action = dirOperatorActionCollection->action(QLatin1String(actionName));
        if (action) {
            mToolbar->addAction(action);
        }
    }
```

#### AUTO 


```{c}
auto* action = new QAction(QIcon::fromTheme(iconName), title, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(dirtyColumns)) {
                    const PixelXRange XPixels = column->xsOfLinePositionsInclSpaces(lastChangedPositions);

                    q->viewport()->update(XPixels.start() - xOffset, cy, XPixels.width(), lineHeight);
                }
```

#### AUTO 


```{c}
auto* insertLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : std::as_const(allData)) {
        QString codeStr = QStringLiteral("%1.set({name: \"expectedName\"});");
        QTest::newRow((data.tag + "-set()").constData())
            << codeStr.arg(data.constructorCall) << data.check;

        codeStr = QStringLiteral("var obj = %1;obj.name = \"expectedName\"; obj;");
        QTest::newRow((data.tag + "-property assignment").constData())
            << codeStr.arg(data.constructorCall) << data.check;
    }
```

#### AUTO 


```{c}
auto* offsetLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for( TabbedViews* viewArea : qAsConst(mViewAreaList) )
        viewArea->removeViews( views );
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractPieceTableChange* change : mChangeStack) {
        if (change->type() == AbstractPieceTableChange::GroupId) {
            const auto* groupChange = static_cast<const GroupPieceTableChange*>(change);
            const ArrayChangeMetricsList metricsList = groupChange->groupMetrics(reverted);
            result += metricsList;
        } else {
            ArrayChangeMetrics changeMetrics = change->metrics();
            if (reverted) {
                changeMetrics.revert();
            }
            result.append(changeMetrics);
        }
    }
```

#### AUTO 


```{c}
auto* codec
```

#### AUTO 


```{c}
auto* change2 = new TestPieceTableChange(type2Id, description2, 2);
```

#### RANGE FOR STATEMENT 


```{c}
for (StructureEnabledData& data : m_enabledList) {
        if (data.id == id) {
            isListed = true;
            data.isEnabled = isEnabled;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](bool checked) { onToggled(checked); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const Bookmark& bookmark : bookmarks )
    {
        const Address position = bookmark.offset();
        mTableRanges->addChangedRange( position, position );
    }
```

#### AUTO 


```{c}
auto* change4 = new TestPieceTableChange(type4Id, description4);
```

#### CONST EXPRESSION 


```{c}
constexpr int maxLineLength =
        maxDataPerLineCount + byteCountLineSize + addressLineSize + recordTypeLineSize;
```

#### CONST EXPRESSION 


```{c}
static constexpr char BookmarkListActionListId[] = "bookmark_list";
```

#### CONST EXPRESSION 


```{c}
static constexpr char SeparatorConfigKey[] = "Separator";
```

#### RANGE FOR STATEMENT 


```{c}
for( const ByteArrayViewProfile& viewProfile : mViewProfiles )
    {
        if( viewProfile.id() == viewProfileId )
        {
            result = viewProfile;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
constexpr int behindOffset3 = Offset3 + 1;
```

#### LAMBDA EXPRESSION 


```{c}
[&](int index) { onCurrentChanged(index); }
```

#### LAMBDA EXPRESSION 


```{c}
[&](int flashTime) { onCursorFlashTimeChanged(flashTime); }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : loadedDocuments) {
        if (document->id() == id) {
            emit mDocumentManager->focusRequested(document);
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultSize = 256;
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultNoOfSublines = 1;
```

#### AUTO 


```{c}
auto* template_ParameterSet =
        static_cast<Template_ByteArrayChecksumParameterSet*>(parameterSet);
```

#### AUTO 


```{c}
auto* data = static_cast<DataInformation*>(idx.internalPointer());
```

#### AUTO 


```{c}
auto* top = new TopLevelDataInformation(data);
```

#### AUTO 


```{c}
auto* patternGenerator = qobject_cast<ByteArrayPatternGenerator*>(generator);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& dataFolderPath : dataFolderPaths )
    {
        const QString viewProfileFolderPath = dataFolderPath + viewProfileDirSubPath;
        // watch folder for changes
        mViewProfileFileWatcher->addDir( viewProfileFolderPath, KDirWatch::WatchDirOnly );

        // read current files
        onViewProfilesFolderChanged( viewProfileFolderPath );
    }
```

#### AUTO 


```{c}
auto* copyAction =  KStandardAction::copy(this, &StructureView::copyToClipboard,  this);
```

#### AUTO 


```{c}
auto* checksumCalculateJob =
            new ChecksumCalculateJob(&mCheckSum, algorithm, mByteArrayModel, mByteArrayView->selection());
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char extendedLinearAddressRecordCode = 0x4;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& path) { onFileCreated(path); }
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned char startSegmentAddressRecordCode = 0x3;
```

#### AUTO 


```{c}
auto* dialog = new InsertDialog(configEditor, generator, QApplication::activeWindow());
```

#### AUTO 


```{c}
const auto* actionName
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
        mList.removeOne( document );
```

#### AUTO 


```{c}
auto* baseOfBaseSplitter = static_cast<QSplitter*>(baseSplitter->parentWidget());
```

#### CONST EXPRESSION 


```{c}
constexpr bool operator==(const Coord& other) const;
```

#### AUTO 


```{c}
auto* sInt16Editor = qobject_cast<SIntSpinBox*>(editor);
```

#### AUTO 


```{c}
const auto& d
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestDirectory[] = "bytearrayrawfilesynchronizertest";
```

#### AUTO 


```{c}
auto* printJob = new PrintJob(&framesPrinter, 0, byteArrayFrameRenderer->framesCount() - 1, &printer);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto column : qAsConst(d->columns)) {
        column->setLineHeight(d->LineHeight);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayChange& change : changes) {
        const ArrayChangeMetrics& metrics = change.metrics();
        switch (metrics.type())
        {
        case ArrayChangeMetrics::Replacement:
        {
            const int oldSize = mPieceTable.size();
            const AddressRange removeRange = AddressRange::fromWidth(metrics.offset(), metrics.removeLength());
            // check parameters
            if (removeRange.startsBehind(oldSize - 1) && (removeRange.width() > 0)) {
                // something is not matching
                ; // TODO: set flag to undo all changes
            }

            const QByteArray& insertData = change.data();
            doReplaceChange(removeRange, reinterpret_cast<const Byte*>(insertData.constData()), insertData.size());
            break;
        }
        case ArrayChangeMetrics::Swapping:
        {
            const AddressRange secondRange(metrics.secondStart(), metrics.secondEnd());
            doSwapChange(metrics.offset(), secondRange);
            break;
        }
        default:
            ;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* codec : qAsConst(mValueCodec)) {
        delete codec;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultViewProfileNoOfGroupedBytes = 4;
```

#### CONST EXPRESSION 


```{c}
constexpr int decimalDigitsCount = 10;
```

#### AUTO 


```{c}
const auto* dataW = static_cast<const DataInformationWithChildren*>(data);
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultLayoutStyle = 0;
```

#### AUTO 


```{c}
auto* const bottomBar = static_cast<Kasten::StatusBar*>(statusBar());
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : views )
    {
        QObject::connect( view, &AbstractModel::titleChanged,
                          q, [&]( const QString& title ) { onTitleChanged( title ); } );

        ViewBox* viewBox = new ViewBox( view, mTabWidget );
        mTabWidget->insertTab( insertIndex, viewBox, view->title() );
        ++insertIndex;
    }
```

#### AUTO 


```{c}
auto* document = new Kasten::TestDocument(testData);
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:spinbox minimum length for consecutive chars to be seen as a string",
                                   "Minimum length:"), this);
```

#### AUTO 


```{c}
auto* box = qobject_cast<KComboBox*>(w);
```

#### AUTO 


```{c}
auto* dataInf = new ArrayDataInformation(QStringLiteral("values"),
                                             endianModel->size() / sizeof(T),
                                             primInfo);
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArraySRecStreamEncoderConfigGroupId[] = "ByteArraySRecordStreamEncoder";
```

#### AUTO 


```{c}
auto* editor = new Utf8Editor(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& path : std::as_const(paths)) {
        StructureMetaData structure(path);
        addStructDef(structure);
    }
```

#### AUTO 


```{c}
auto* valuesStreamEncoder = qobject_cast<ByteArrayValuesStreamEncoder*>(encoder);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(d->columns)) {
                    column->renderColumn(painter, dirtyXs, dirtyYs);
                }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteOrderConfigKey[] = "OperandFormat";
```

#### RANGE FOR STATEMENT 


```{c}
for (StructureDefinitionFile* def : structureDefs) {
        if (!def->isValid()) {
            continue;
        }
        const QString id = def->metaData().id();
        if (!enabledList.isEnabled(id)) {
           continue;
        }
        auto* item = new QTreeWidgetItem(mTreeAvailable, QStringList { def->metaData().id(), id });
        const auto structureNames = def->structureNames();
        for (const QString& name : structureNames) {
            auto* subItem = new QTreeWidgetItem(item, QStringList { name, id });
            item->addChild(subItem);
        }

        availableItems.append(item);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ByteArraySourceCodeStreamEncoderConfigGroupId[] = "ByteArraySourceCodeStreamEncoder";
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractModelStreamEncoderConfigEditorFactory* factory : qAsConst(mEncoderFactoryList) )
        mExporterFactoryList << new ModelEncoderFileSystemExporterConfigEditorFactory( factory );
```

#### RANGE FOR STATEMENT 


```{c}
for (Kasten::AbstractXmlGuiController* controller : qAsConst(mControllers)) {
            controller->setTargetModel(mByteArrayView);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultVisibleByteArrayCodings = 3;
```

#### AUTO 


```{c}
auto* factory = new ByteArrayDocumentFactory();
```

#### CONST EXPRESSION 


```{c}
static constexpr char PODDecoderConfigGroupId[] = "PODDecoderTool";
```

#### AUTO 


```{c}
auto it = m_enabledList.begin();
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:textbox substring which separates the values", "Separation:"), this);
```

#### AUTO 


```{c}
auto* pageLayout = new QGridLayout(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr char basePath[] = "/.kde-unit-test/";
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultInsertCount = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : loadedDocuments) {
        if (url == urlOf(document)) {
            // TODO: query if file should be reloaded/synched from disk
            emit mManager->focusRequested(document);
            return;
        }
    }
```

#### AUTO 


```{c}
auto* updateLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* mainWidget = new QWidget;
```

#### AUTO 


```{c}
const auto versionIndex = versionable->versionIndex();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QTreeWidgetItem* item : selected) {
        if (!item->parent()) {
            continue;     // maybe sometime add all subitems
        }
        auto* moveOver = new QTreeWidgetItem(mTreeSelected, QStringList { item->text(0), item->text(1) });
        // item name then parent name then path
        mTreeSelected->addTopLevelItem(moveOver);
        changed = true;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int DefaultZoomStep = 1;
```

#### AUTO 


```{c}
const auto * byteArrayDocument = model->findBaseModel<const ByteArrayDocument*>();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& codecName : TextCharCodec::codecNames()) {
        QTest::newRow(codecName.toLatin1().constData()) << codecName;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char SizeConfigKey[] = "Size";
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        for (int j = 0; j < 256; ++j) {
            const QString rowTitle =
                QLatin1String(valueCodecDescription.name) +
                QString(QStringLiteral(" - %1")).arg(j);

            QTest::newRow(rowTitle.toLatin1().constData())
                << valueCodecDescription.id
                << Byte(j);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto columnRenderer : qAsConst(d->mColumns)) {
            if (columnRenderer->isVisible() && columnRenderer->overlaps(renderedXs)) {
                columnRenderers.append(columnRenderer);
            }
        }
```

#### AUTO 


```{c}
auto* testDocument = qobject_cast<Kasten::TestDocument*>(document);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractFrameRenderer* frameRenderer : qAsConst(mFrameRendererList)) {
        frameRenderer->prepare();
    }
```

#### AUTO 


```{c}
const auto msgTemplate =
                QStringLiteral("Could not convert '%1' to an enum constant, name was: %2");
```

#### AUTO 


```{c}
auto* part = new OktetaPart(parent, mAboutData, modus, mByteArrayViewProfileManager, mModelCodecManager, mModelCodecViewManager);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& encodingData : encodingDataList) {
            bool isCodecFound = false;
            const QString codecName = QString::fromLatin1(encodingData.name);
            QTextCodec* codec = charsets->codecForName(codecName, isCodecFound);
            if (isCodecFound) {
                textCodecNames.append(QString::fromLatin1(codec->name()));
            }
        }
```

#### AUTO 


```{c}
auto* reverseParameterSet = static_cast<ReverseByteArrayFilterParameterSet*>(parameterSet);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelStreamEncoderConfigEditorFactory* factory : std::as_const(mEncoderFactoryList)) {
        mExporterFactoryList << new ModelEncoderFileSystemExporterConfigEditorFactory(factory);
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultAlignAtEnd = false;
```

#### AUTO 


```{c}
auto it = std::find(encodingTypeConfigValueList.cbegin(), encodingTypeConfigValueList.cend(), entry);
```

#### AUTO 


```{c}
auto* current
```

#### AUTO 


```{c}
auto* octal8Editor = qobject_cast<Octal8Editor*>(editor);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : qAsConst(mChildren)) {
        child->resetValidationState();
    }
```

#### AUTO 


```{c}
const auto format = static_cast<OffsetFormat::Format>(offsetCoding);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* child : newChildren) {
        child->setParent(this);
    }
```

#### AUTO 


```{c}
auto* noneAction = new QAction(i18nc("@item There are no exporters.", "Not available."), mExportSelectAction);
```

#### CONST EXPRESSION 


```{c}
static constexpr unsigned int EndsLater = 2;
```

#### RANGE FOR STATEMENT 


```{c}
for( const ArrayChangeMetrics& change : changeList )
    {
        // cursor affected?
        if( mIndex >= change.offset() )
        {
            switch( change.type() )
            {
            case ArrayChangeMetrics::Replacement:
                oldLength += change.lengthChange();
                if( oldLength > 0 )
                {
                    const Address newIndex =
                        // cursor behind the removed section?
                        ( mIndex >= change.offset()+change.removeLength() ) ? mIndex + change.lengthChange() :
                        // cursor at substituted section?
                        ( mIndex < change.offset()+change.insertLength() ) ?  mIndex :
                        // cursor at unsubstituted section
                                                                              change.offset() + change.insertLength();

                    // if the cursor gets behind, it will never get inside again.
                    if( newIndex >= oldLength )
                    {
                        gotoEnd();
                        return;
                    }
                    mIndex = newIndex;
                }
                // if the cursor gets at the start, it will stay there
                else
                {
                    gotoStart();
                    return;
                }
                break;
            case ArrayChangeMetrics::Swapping:
                if( mIndex < change.secondStart() )
                {
                    mIndex += change.secondLength();
                }
                else if( mIndex <= change.secondEnd() )
                {
                    mIndex -= change.firstLength();
                }
                break;
            default:
                ;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Bookmark& bookmark : std::as_const(bookmarkList)) {
        QCOMPARE(bookmark.offset(), *oit++);
    }
```

#### AUTO 


```{c}
auto menu = new QMenu(q);
```

#### AUTO 


```{c}
auto* enabledCheckBox = new QCheckBox;
```

#### AUTO 


```{c}
auto* widget = new Okteta::ByteArrayColumnView(parent);
```

#### AUTO 


```{c}
auto* arrayData = static_cast<PrimitiveArrayData<primType>*>(dataInf->mData.get());
```

#### AUTO 


```{c}
auto* item = new QTreeWidgetItem(mTreeAvailable, QStringList { def->pluginInfo().pluginName(), pluginName });
```

#### AUTO 


```{c}
auto* synchronizer = new ByteArrayRawFileSynchronizer();
```

#### AUTO 


```{c}
auto* settingsLayout = new QFormLayout();
```

#### CONST EXPRESSION 


```{c}
static constexpr int StatisticBlockSize = 100000;
```

#### AUTO 


```{c}
auto selectAllAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-select-all")),
                                           i18nc("@action:inmenu", "Select &All"),
                                           q, [q]() { q->selectAll(true); });
```

#### AUTO 


```{c}
auto* unsignedAsHexLabel = new QLabel(i18nc("@option:check", "Unsigned as hexadecimal:"), this);
```

#### AUTO 


```{c}
auto* labelledUnsignedAsHexCheck = new LabelledToolBarWidget(unsignedAsHexLabel, mUnsignedAsHexCheck, this);
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& url : urls )
    {
        if( url.isEmpty() )
            createManager->createNew();
        else
            syncManager->load( QUrl(url, QUrl::TolerantMode) );
        // TODO: set view to offset
        // if( offset != -1 )
    }
```

#### AUTO 


```{c}
auto* tabBar = new TabBar(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr const char* base64PaddingData[2] = {
    "==",
    "="
};
```

#### RANGE FOR STATEMENT 


```{c}
for (const Bookmark& bookmark : bookmarks) {
        const Address position = bookmark.offset();
        mTableRanges->addChangedRange(position, position);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Bookmark& bookmark : qAsConst(bookmarkList)) {
        QCOMPARE(bookmark.offset(), *oit++);
    }
```

#### AUTO 


```{c}
auto* copy = new Okteta::Byte[SIZE];
```

#### CONST EXPRESSION 


```{c}
constexpr int upperLinearBaseAddressSize = 2;
```

#### CONST EXPRESSION 


```{c}
static constexpr int outputLineLength = 72;
```

#### AUTO 


```{c}
auto* aboutWidget = new QWidget(this);
```

#### AUTO 


```{c}
auto* byteArrayDocument = qobject_cast<ByteArrayDocument*>(document());
```

#### AUTO 


```{c}
auto* un = new UnionDataInformation(QStringLiteral("un"), children);
```

#### CONST EXPRESSION 


```{c}
constexpr bool isAtStart() const;
```

#### CONST EXPRESSION 


```{c}
static constexpr char InsertCountConfigKey[] = "InsertCount";
```

#### AUTO 


```{c}
auto* insertButton = new QPushButton(i18nc("@action:button", "&Insert"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : structureNames) {
            auto* subItem = new QTreeWidgetItem(item, QStringList { name, pluginName });
            item->addChild(subItem);
        }
```

#### AUTO 


```{c}
const auto structureDefs = mTool->manager()->structureDefs();
```

#### AUTO 


```{c}
auto* focusEvent = static_cast<QFocusEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : std::as_const(closedDocuments)) {
        delete document;
    }
```

#### AUTO 


```{c}
auto copyAction = menu->addAction(QIcon::fromTheme(QStringLiteral("edit-copy")),
                                      i18nc("@action:inmenu", "&Copy") + QLatin1Char('\t') + QKeySequence(QKeySequence::Copy).toString(QKeySequence::NativeText),
                                      mView, &AbstractByteArrayView::copy);
```

#### RANGE FOR STATEMENT 


```{c}
for (ToolViewDockWidget* dockWidget : qAsConst(mDockWidgets)) {
        if (dockWidget->isShown()) {
            dockWidget->toolView()->tool()->setTargetModel(view);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : qAsConst(mList)) {
        mSelector->addItem(info->objectName());
    }
```

#### AUTO 


```{c}
auto* footerFrameRenderer = new HeaderFooterFrameRenderer(&info);
```

#### AUTO 


```{c}
auto* dialog = new CreateDialog(configEditor);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractXmlGuiController* controller : qAsConst(mControllers)) {
        controller->setTargetModel(view);
    }
```

#### AUTO 


```{c}
auto column
```

#### AUTO 


```{c}
auto* buttonLayout = new QVBoxLayout;
```

#### LAMBDA EXPRESSION 


```{c}
[&](Kasten::AbstractView* view) { onViewFocusChanged(view); }
```

#### AUTO 


```{c}
auto* temporaryFile = new QTemporaryFile;
```

#### LAMBDA EXPRESSION 


```{c}
[&](QDropEvent* event) { onDropEvent(event); }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QString& e : entries )
        {
            const QString structureBasePath = structuresDir + QLatin1Char('/') + e;
            const QStringList desktopFiles =
                QDir(structureBasePath).entryList( QStringList(QStringLiteral("*.desktop")) );
            for(const QString& desktopFile : desktopFiles )
            {
                paths << structureBasePath + QLatin1Char('/') + desktopFile;
            }
        }
```

#### AUTO 


```{c}
auto* srecStreamEncoder = qobject_cast<ByteArrayIHexStreamEncoder*>(encoder);
```

#### CONST EXPRESSION 


```{c}
constexpr int firstWithNumericShortCut = 1;
```

#### AUTO 


```{c}
const auto* otherTestChange = static_cast<const TestPieceTableChange*>(other);
```

#### CONST EXPRESSION 


```{c}
static constexpr char TestDataChar = 0;
```

#### CONST EXPRESSION 


```{c}
static constexpr char SubstituteByteConfigKey[] = "SubstituteByte";
```

#### CONST EXPRESSION 


```{c}
constexpr int firstLength = Distance13 - 1;
```

#### CONST EXPRESSION 


```{c}
constexpr bool isBeforeLineEnd(LinePosition maxPos) const;
```

#### AUTO 


```{c}
auto* viewAreaWidget = viewArea->widget();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : std::as_const(columnRenderers)) {
                columnRenderer->renderColumn(painter, renderedXs, renderedYs);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for( const QModelIndex& index : selectedRows )
    {
        const int i = mSortFilterProxyModel->mapToSource(index).row();
        strings += containedStringList->at( i ).string();
        strings += QLatin1Char('\n'); //TODO: specific linefeed for platforms
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString& desktopFile : desktopFiles )
            {
                paths << structureBasePath + QLatin1Char('/') + desktopFile;
            }
```

#### AUTO 


```{c}
const auto* box = qobject_cast<const KComboBox*>(w);
```

#### RANGE FOR STATEMENT 


```{c}
for( const AddressRange& addressRange : addressRangeList )
        addAddressRange( addressRange );
```

#### CONST EXPRESSION 


```{c}
static constexpr int addressLineOffset = byteCountLineOffset + byteCountLineSize;
```

#### AUTO 


```{c}
auto viewport = q->viewport();
```

#### AUTO 


```{c}
auto* field
```

#### AUTO 


```{c}
auto* labelledFilterEdit = new LabelledToolBarWidget(label, mFilterEdit, this);
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractDocument* document : documents )
        delete document;
```

#### AUTO 


```{c}
auto* createButton = new QPushButton(QIcon::fromTheme(QStringLiteral("document-new")),
                                         i18nc("@action:button create the new document", "&Create"));
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        while (it.hasNext()) {
            AbstractView* view = it.next();
            AbstractDocument* documentOfView = view->findBaseModel<AbstractDocument*>();
            if (documentOfView == document) {
                it.remove();
                closedViews.append(view);
            }
        }
        it.toFront();
    }
```

#### CONST EXPRESSION 


```{c}
constexpr bool isPriorInLineThan(Coord other) const;
```

#### LAMBDA EXPRESSION 


```{c}
[&](const QString& Title) { onTitleChanged(Title); }
```

#### AUTO 


```{c}
auto* endOffsetLayout = new QHBoxLayout();
```

#### AUTO 


```{c}
auto* testDocument = qobject_cast<TestDocument*>(document());
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractModelStreamEncoder* encoder : std::as_const(mEncoderList)) {
        mExporterList << new ModelEncoderFileSystemExporter(encoder);
    }
```

#### AUTO 


```{c}
const auto* template_ParameterSet =
        static_cast<const Template_ByteArrayChecksumParameterSet*>(parameterSet);
```

#### RANGE FOR STATEMENT 


```{c}
for( const AbstractColumnTextRenderer* renderer : qAsConst(columnTextRendererList) )
        renderer->renderFirstLine( &textStream, l );
```

#### CONST EXPRESSION 


```{c}
static constexpr int xxInputLineLength = defaultxxInputLineLength;
```

#### RANGE FOR STATEMENT 


```{c}
for (const Bookmark& bookmark : bookmarks) {
        removeBookmark(bookmark);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& name : structureNames) {
            QTreeWidgetItem* subItem = new QTreeWidgetItem(item,
                                                           QStringList { name, pluginName });
            item->addChild(subItem);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : std::as_const(mColumns)) {
        columnRenderer->setX(mColumnsWidth);
        mColumnsWidth += columnRenderer->visibleWidth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const JsTestData& data : qAsConst(allData)) {
        // default should be inherit
        QString codeStr = QStringLiteral("%1;");
        QTest::newRow(data.tag.constData()) << codeStr.arg(data.constructorCall)
                                            << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;

        // use set() function to specify byteOrder
        codeStr = QStringLiteral("%1.set({byteOrder: \"inherit\"})");
        QTest::newRow((data.tag + " set() inherit").constData()) << codeStr.arg(data.constructorCall)
                                                                 << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;
        codeStr = QStringLiteral("%1.set({byteOrder: \"littleEndian\"})");
        QTest::newRow((data.tag + " set() little endian").constData()) << codeStr.arg(data.constructorCall)
                                                                       << data.check << (int)DataInformation::DataInformationEndianess::EndianessLittle;
        codeStr = QStringLiteral("%1.set({byteOrder: \"bigEndian\"})");
        QTest::newRow((data.tag + " set() big endian").constData()) << codeStr.arg(data.constructorCall)
                                                                    << data.check << (int)DataInformation::DataInformationEndianess::EndianessBig;
        codeStr = QStringLiteral("%1.set({byteOrder: \"fromSettings\"})");
        QTest::newRow((data.tag + " set() from settings").constData()) << codeStr.arg(data.constructorCall)
                                                                       << data.check << (int)DataInformation::DataInformationEndianess::EndianessFromSettings;

        // direct property access to specify byteOrder
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"inherit\"; obj;");
        QTest::newRow((data.tag + " property assign inherit").constData()) << codeStr.arg(data.constructorCall)
                                                                           << data.check << (int)DataInformation::DataInformationEndianess::EndianessInherit;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"little-endian\"; obj;");
        QTest::newRow((data.tag + " property assign little endian").constData()) << codeStr.arg(data.constructorCall)
                                                                                 << data.check << (int)DataInformation::DataInformationEndianess::EndianessLittle;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"big-endian\"; obj;");
        QTest::newRow((data.tag + " property assign big endian").constData()) << codeStr.arg(data.constructorCall)
                                                                              << data.check << (int)DataInformation::DataInformationEndianess::EndianessBig;
        codeStr = QStringLiteral("var obj = %1; obj.byteOrder = \"from-settings\"; obj;");
        QTest::newRow((data.tag + " property assign from settings").constData()) << codeStr.arg(data.constructorCall)
                                                                                 << data.check << (int)DataInformation::DataInformationEndianess::EndianessFromSettings;
    }
```

#### AUTO 


```{c}
auto* spin = qobject_cast<SIntSpinBox*> (w);
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractColumnTextRenderer* renderer : qAsConst(columnTextRendererList)) {
            renderer->renderNextLine(&textStream, isSubline);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char base32ZHexEncodeMap[32] =
{
    'y', 'b', 'n', 'd', 'r', 'f', 'g', '8',
    'e', 'j', 'k', 'm', 'c', 'p', 'q', 'x',
    'o', 't', '1', 'u', 'w', 'i', 's', 'z',
    'a', '3', '4', '5', 'h', '7', '6', '9'
};
```

#### AUTO 


```{c}
auto* baseLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractByteArrayChecksumAlgorithm* algorithm : algorithmList) {
        mAlgorithmComboBox->addItem(algorithm->name());

        const char* const parameterSetId = algorithm->parameterSet()->id();
        AbstractByteArrayChecksumParameterSetEdit* parameterEdit =
            ByteArrayChecksumParameterSetEditFactory::createEdit(parameterSetId);

        mParameterSetEditStack->addWidget(parameterEdit);
    }
```

#### AUTO 


```{c}
const auto* template_ParameterSet = static_cast<const Template_ByteArrayFilterParameterSet*>(parameterSet);
```

#### AUTO 


```{c}
auto* findBoxLayout = new QVBoxLayout;
```

#### AUTO 


```{c}
auto* factory = new Kasten::TestDocumentFileSynchronizerFactory();
```

#### AUTO 


```{c}
const auto* spin = qobject_cast<const UIntSpinBox*>(w);
```

#### AUTO 


```{c}
auto* label = new QLabel(i18nc("@label:listbox operation to use by the filter", "Operation:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(d->columns)) {
            if (column->isVisible() && column->overlaps(dirtyXs)) {
                dirtyColumns.append(column);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QModelIndex& index : selectedRows) {
        const Okteta::Bookmark& bookmark = mBookmarkListModel->bookmark(index);
        bookmarksToBeDeleted.append(bookmark);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto& valueCodecDescription : valueCodecDescriptions) {
        QBitArray validnessPerDigitField = QBitArray(digitCount, false);
        const QByteArray validDigits =
            QByteArray(valueCodecDescription.validDigits);

        for (int j = 0; j < validDigits.count(); ++j) {
            validnessPerDigitField.setBit(validDigits[j], true);
        }

        for (int j = 0; j < validnessPerDigitField.count(); ++j) {
            const uchar digit = uchar(j);
            const bool isValid = validnessPerDigitField.testBit(j);
            const QString rowTitle =
                QLatin1String(valueCodecDescription.name) +
                QStringLiteral(" - \"%1\" is ").arg(QLatin1Char(digit)) +
                (isValid ? QStringLiteral("valid") : QStringLiteral("invalid"));

            QTest::newRow(rowTitle.toLatin1().constData())
                << valueCodecDescription.id
                << digit
                << isValid;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : views )
    {
        AbstractDocument* document = view->findBaseModel<AbstractDocument*>();
        viewsToClosePerDocument[document].append( view );
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Kasten::StructureDefinitionFile* def : structureDefs) {
        KPluginInfo info = def->pluginInfo();
        if (info.category() == QLatin1String("structure")) {
            plugins.append(info);
        } else if (info.category() == QLatin1String("structure/js")) {
            dynamicPlugins.append(info);
        }
    }
```

#### AUTO 


```{c}
auto* touchEvent = static_cast<const QTouchEvent*>(event);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* column : std::as_const(columns)) {
        column->setX(ColumnsWidth);
        ColumnsWidth += column->visibleWidth();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractDocument* document : documents) {
        delete document;
    }
```

#### CONST EXPRESSION 


```{c}
constexpr bool operator<(const Coord& other) const;
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile& viewProfile : std::as_const(mViewProfiles)) {
        if (viewProfile.id() == viewProfileId) {
            isExisting = true;
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( AbstractView* view : qAsConst(closedViews) )
    {
//         qCDebug(LOG_KASTEN_GUI) << view->title();
        delete view;
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char base32ClassicEncodeMap[32] =
{
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
    'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
    'Y', 'Z', '2', '3', '4', '5', '6', '7'
};
```

#### CONST EXPRESSION 


```{c}
static constexpr int MinimumStringLength = 1;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractPieceTableChange* change : mChangeStack) {
        if (change->type() == AbstractPieceTableChange::GroupId) {
            const GroupPieceTableChange* groupChange = static_cast<const GroupPieceTableChange*>(change);
            const AddressRangeList changedRangeList = groupChange->applyGroup(pieceTable);
            result.addAddressRangeList(changedRangeList);
        } else {
            result.append(change->apply(pieceTable));
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int outputLineLength = 76;
```

#### CONST EXPRESSION 


```{c}
constexpr bool operator>(const Coord& other) const;
```

#### RANGE FOR STATEMENT 


```{c}
for (const AbstractModelStreamEncoderConfigEditorFactory* factory : mEncoderFactoryList) {
        result = factory->tryCreateConfigEditor(encoder);
        if (result) {
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[q]() { q->selectAll(true); }
```

#### AUTO 


```{c}
auto* popup = static_cast<QMenu*>(w);
```

#### LAMBDA EXPRESSION 


```{c}
[&](AbstractView* view, QPoint pos) { onContextMenuRequested(view, pos); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const ByteArrayViewProfile& viewProfile : mViewProfiles) {
        if (viewProfile.id() == viewProfileId) {
            result = viewProfile;
            break;
        }
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr int MinFontPointSize = 4;
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* info : list) {
        if (info->actualDataInformation()->name() == name) {
            ret = info;
        } else {
            delete info; // we have no use for this element
        }
    }
```

#### AUTO 


```{c}
auto* structureSettings = new StructuresManagerView(mTool, this);
```

#### AUTO 


```{c}
auto* uuencodingStreamEncoder = qobject_cast<ByteArrayUuencodingStreamEncoder*>(encoder);
```

#### RANGE FOR STATEMENT 


```{c}
for( const StructureDefinitionFile* def : loadedDefs )
    {
        QString pluginName = def->pluginInfo().pluginName();
        if (def->pluginInfo().isValid() && !def->pluginInfo().isPluginEnabled())
            continue;
        plugins << pluginName;
    }
```

#### AUTO 


```{c}
auto* printDialog = new QPrintDialog(&printer, nullptr);
```

#### AUTO 


```{c}
auto* tapGesture = static_cast<QTapGesture*>(gestureEvent->gesture(Qt::TapGesture))
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* encoder : encoderList) {
            const QString title = encoder->remoteTypeName();
            auto* action = new QAction(title, mCopyAsSelectAction);

            action->setData(QVariant::fromValue(encoder));
            mCopyAsSelectAction->addAction(action);
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr char ModSum16ConfigGroupId[] = "ModularSum16";
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractView* view : views) {
        QObject::connect(view, &AbstractModel::titleChanged,
                         q, [&](const QString& title) { onTitleChanged(title); });

        auto* viewBox = new ViewBox(view, mTabWidget);
        mTabWidget->insertTab(insertIndex, viewBox, view->title());
        ++insertIndex;
    }
```

#### AUTO 


```{c}
auto* operandParameterSet = static_cast<OperandByteArrayFilterParameterSet*>(parameterSet);
```

#### CONST EXPRESSION 


```{c}
static constexpr char LoadedUrlsKey[] = "LoadedUrls";
```

#### RANGE FOR STATEMENT 


```{c}
for( const Kasten::StructureDefinitionFile* def : structureDefs )
    {
        KPluginInfo info = def->pluginInfo();
        if (info.isPluginEnabled())
            newVals.append(QString(QStringLiteral("\'%1\':\'*\'")).arg(info.pluginName()));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (AbstractByteArrayFilter* filter : filterList) {
        mOperationComboBox->addItem(filter->name());

        const char* parameterSetId = filter->parameterSet()->id();
        AbstractByteArrayFilterParameterSetEdit* parameterEdit =
            ByteArrayFilterParameterSetEditFactory::createEdit(parameterSetId);

        mParameterSetEditStack->addWidget(parameterEdit);
    }
```

#### AUTO 


```{c}
auto *algorithm
```

#### AUTO 


```{c}
auto* view = qobject_cast<AbstractView*>(q->sender());
```

#### AUTO 


```{c}
const auto views = mViewArea->viewList();
```

#### AUTO 


```{c}
auto* aboutButton = static_cast<QPushButton *>(widgets[1]);
```

#### AUTO 


```{c}
auto* searchJob = new SearchJob(m_byteArrayModel, m_searchData, m_currentIndex, endIndex,
                                    m_caseSensitivity, m_byteArrayView->charCodingName());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto* columnRenderer : std::as_const(d->mColumns)) {
            if (columnRenderer->isVisible() && columnRenderer->overlaps(renderedXs)) {
                columnRenderers.append(columnRenderer);
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[widget](AbstractView* view) {
        return (view->widget() == widget);
    }
```

#### AUTO 


```{c}
auto* writeThread = new ByteArrayRawFileWriteThread(this, document, file());
```

#### AUTO 


```{c}
auto* titleFormLayout = new QFormLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for( const QFileInfo& viewProfileFileInfo : viewProfileFileInfoList )
    {
       // a lock file ?
       if( viewProfileFileInfo.suffix() == QLatin1String("olock") )
       {
           const ByteArrayViewProfile::Id lockedViewProfileId = viewProfileFileInfo.baseName();
           // if not in old locks, is a new lock
           if( ! newUnlockedViewProfileIds.removeOne(lockedViewProfileId) )
                newLockedViewProfileIds.append( lockedViewProfileId );
           continue;
       }

       // not a viewprofile file ?
       if( viewProfileFileInfo.suffix() != QLatin1String("obavp") )
            continue;

       // all other files assumed to be viewProfile files
        const ByteArrayViewProfile::Id viewProfileId = viewProfileFileInfo.baseName();
        // load file
        const ByteArrayViewProfile viewProfile = loadViewProfile( viewProfileFileInfo.absoluteFilePath() );
        // loading failed? Treat as not existing
        if( viewProfile.id().isEmpty() )
            continue;

        const ByteArrayViewProfileFileInfoLookup::Iterator infoIt =
            viewProfileFileInfoLookup.find( viewProfileId );
        const bool isKnown = ( infoIt != viewProfileFileInfoLookup.end() );
        const QDateTime fileInfoLastModified = viewProfileFileInfo.lastModified();
        // is known?
        if( isKnown )
        {
            removedViewProfileIds.removeOne( viewProfileId );

            // check timestamp
            if( fileInfoLastModified == infoIt->lastModified() )
                continue;

            // update timestamp
            infoIt->setLastModified( fileInfoLastModified );
        }
        else
        {
            ByteArrayViewProfileFileInfo info( fileInfoLastModified, false );
            viewProfileFileInfoLookup.insert( viewProfileId, info );
        }

        if( isKnown )
        {
            QList<ByteArrayViewProfile>::Iterator it = mViewProfiles.begin();
            QList<ByteArrayViewProfile>::Iterator end = mViewProfiles.end();
            for( ; it != end; ++it )
            {
                if( it->id() == viewProfileId )
                {
                    *it = viewProfile;
                    break;
                }
            }
        }
        else
            newViewProfiles.append( viewProfile );
        changedViewProfiles.append( viewProfile );
    }
```

#### CONST EXPRESSION 


```{c}
static constexpr char VariantConfigKey[] = "Variant";
```

#### LAMBDA EXPRESSION 


```{c}
[&removedViewProfileIds](const ByteArrayViewProfile& profile) {
            return removedViewProfileIds.contains(profile.id());
        }
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultSubstituteMissingChars = false;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& info : std::as_const(mList)) {
        mSelector->addItem(info->objectName());
    }
```

#### AUTO 


```{c}
auto* menu = new QMenu(this);
```

#### CONST EXPRESSION 


```{c}
static constexpr bool DefaultShowingNonprinting = false;
```

#### AUTO 


```{c}
auto* subItem = new QTreeWidgetItem(item, QStringList { name, id });
```

#### RANGE FOR STATEMENT 


```{c}
for (const QUrl& url : urls) {
        mDocumentStrategy->load(url);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for( const FieldInfo& fi : d.mAlternatives )
    {
        mAlternatives.append(FieldInfo(fi.name, fi.selectIf, cloneList(fi.fields, this)));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&]() { onEmptySpaceMouseDoubleClicked(); }
```

#### LAMBDA EXPRESSION 


```{c}
[offset](const Bookmark& bookmark) {
        return (bookmark.offset() == offset);
    }
```

#### AUTO 


```{c}
auto* change2 = new TestPieceTableChange(type2Id, description2);
```

#### AUTO 


```{c}
auto* baseLayout = new QHBoxLayout(q);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Piece& piece) {
        mList.append(piece);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](char*& pageData) {
        delete [] pageData;
        pageData = nullptr;
    }
```

#### AUTO 


```{c}
auto* closeButton = new QToolButton(this);
```

#### AUTO 


```{c}
const auto* touchEvent = static_cast<const QTouchEvent*>(event);
```

