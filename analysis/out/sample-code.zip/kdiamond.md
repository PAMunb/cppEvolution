#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &point2 : selections) {
        const int diff = qAbs(point2.x() - point.x()) + qAbs(point2.y() - point.y());
        if (diff > 1) {
            m_board->setSelection(point2, false);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Diamond *selector : std::as_const(m_activeSelectors)) {
        selector->hide();
        m_inactiveSelectors << selector;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (Diamond *selector : qAsConst(m_activeSelectors)) {
        selector->hide();
        m_inactiveSelectors << selector;
    }
```

#### AUTO 


```{c}
const auto selections = m_board->selections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &diamondPos : qAsConst(diamondsToRemove)) {
                m_board->removeDiamond(diamondPos);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QPoint &diamondPos : std::as_const(diamondsToRemove)) {
                m_board->removeDiamond(diamondPos);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const MoveAnimSpec &spec : specs) {
        const int duration = KDiamond::Board::MoveDuration * (spec.to - spec.from).manhattanLength();
        QPropertyAnimation *animation = new QPropertyAnimation(spec.diamond, "pos", this);
        animation->setStartValue(spec.from);
        animation->setEndValue(spec.to);
        animation->setDuration(duration);
        animation->start(QAbstractAnimation::DeleteWhenStopped);
        connect(animation, &QPropertyAnimation::finished, this, &Board::slotAnimationFinished);
        m_runningAnimations << animation;
    }
```

