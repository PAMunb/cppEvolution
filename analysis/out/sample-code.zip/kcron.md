#### AUTO 


```{c}
auto labelLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : std::as_const(d->task)) {
        if (ctTask->dirty()) {
            return true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (VariableWidget *variableWidget : variablesWidget) {
            CTVariable *variable = new CTVariable(*(variableWidget->getCTVariable()));
            mClipboardVariables.append(variable);

            clipboardText += variable->exportVariable() + QLatin1String("\n");
        }
```

#### AUTO 


```{c}
auto hoursLayout = new QGridLayout(hoursGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : qAsConst(d->task)) {
        ctTask->apply();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : associatedWidgets) {
        // Only change status of associated Buttons
        QPushButton *button = qobject_cast<QPushButton *>(widget);
        if (button) {
            button->setEnabled(enabled);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int width : qAsConst(columnWidths)) {
		logDebug() << "Column : " << width;
		columnWidthSum += width;
	}
```

#### AUTO 


```{c}
auto edit = new QTextEdit(parent);
```

#### AUTO 


```{c}
auto hoursGroup = new QGroupBox(i18n("Hours"), main);
```

#### AUTO 


```{c}
const auto tasks = source.tasks();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        const CTSaveStatus ctSaveStatus = ctCron->save();

        if (ctSaveStatus.isError()) {
            return CTSaveStatus(i18nc("User login: errorMessage", "User %1: %2", ctCron->userLogin(), ctSaveStatus.errorMessage()), ctSaveStatus.detailErrorMessage());
        }
    }
```

#### AUTO 


```{c}
auto variable = new CTVariable(*(variableWidget->getCTVariable()));
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *task : tasks) {
        QStringList values;
        values << task->schedulingCronFormat();
        values << task->command;
        values << task->comment;

        tasksContent.append(values);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int columnWidth : columnWidths) {
        linePositionX += columnWidth;
        mPainter->drawLine(QPoint(linePositionX, 0), QPoint(linePositionX, mCurrentRowPosition));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCtHost->mCrons)) {
            taskCount += ctCron->tasks().count();
        }
```

#### AUTO 


```{c}
auto button = qobject_cast<QPushButton *>(widget);
```

#### AUTO 


```{c}
auto day = new NumberPushButton(true, daysOfMonthGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        if (ctCron->isMultiUserCron()) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int columnWidth : columnWidths) {
		linePositionX += columnWidth;
		d->painter->drawLine(QPoint(linePositionX, 0), QPoint(linePositionX, d->currentRowPosition));
	}
```

#### AUTO 


```{c}
const auto tasks = d->task;
```

#### RANGE FOR STATEMENT 


```{c}
for (int columnWidth : columnWidths) {
		columnWidthsTotal += columnWidth;
	}
```

#### AUTO 


```{c}
auto dialogLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : tasks) {
        CTTask *tmp = new CTTask(*ctTask);
        d->task.append(tmp);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *task : ctasks) {
            tasks.append(task);
        }
```

#### AUTO 


```{c}
const auto variables = source.variables();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : qAsConst(d->variable)) {
        exportCron += ctVariable->exportVariable();
        exportCron += QLatin1String("\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : crons) {
        if (ctCron->isSystemCron()) {
            continue;
        }

        users.append(ctCron->userLogin());

        // Select the actual user
        if (ctCron->userLogin() == selectedUserLogin) {
            selectedIndex = userComboIndex;
        }

        userComboIndex++;
    }
```

#### AUTO 


```{c}
auto commandConfigurationLayout = new QGridLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : tasksItems) {
        auto taskWidget = static_cast<TaskWidget *>(item);

        crontabWidget()->currentCron()->removeTask(taskWidget->getCTTask());
        delete taskWidget->getCTTask();
        treeWidget()->takeTopLevelItem(treeWidget()->indexOfTopLevelItem(taskWidget));
        delete taskWidget;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *cron : crons) {
        if (cron->isSystemCron()) {
            continue;
        }

        const auto ctasks = cron->tasks();

        for (CTTask *task : ctasks) {
            tasks.append(task);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : std::as_const(d->task)) {
        ctTask->apply();
    }
```

#### AUTO 


```{c}
const auto variables = d->variable;
```

#### AUTO 


```{c}
auto schedulingLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : std::as_const(d->variable)) {
        exportCron += ctVariable->exportVariable();
        exportCron += QLatin1String("\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QAction *action : cutCopyPasteActions) {
        treeWidget()->addAction(action);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *task : std::as_const(mClipboardTasks)) {
            mTasksWidget->addTask(new CTTask(*task));
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        const CTSaveStatus ctSaveStatus = ctCron->save();

        if (ctSaveStatus.isError()) {
            return CTSaveStatus(i18nc("User login: errorMessage", "User %1: %2", ctCron->userLogin(), ctSaveStatus.errorMessage()),
                                ctSaveStatus.detailErrorMessage());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCtHost->mCrons)) {
            taskCount += ctCron->tasks().count();
        }
```

#### AUTO 


```{c}
auto labCommand = new QLabel(i18n("&Command:"), main);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron* ctCron : crons) {
			if (ctCron->isCurrentUserCron())
				continue;

			if (ctCron->isSystemCron())
				continue;

			users.append(ctCron->userLogin());
		}
```

#### RANGE FOR STATEMENT 


```{c}
for (VariableWidget *variableWidget : variablesWidget) {
            auto variable = new CTVariable(*(variableWidget->getCTVariable()));
            mClipboardVariables.append(variable);

            clipboardText += variable->exportVariable() + QLatin1String("\n");
        }
```

#### AUTO 


```{c}
const auto cutCopyPasteActions = crontabWidget()->cutCopyPasteActions();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : qAsConst(d->variable)) {
        ctVariable->apply();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList& content : contents) {

		int columnIndex = 0;
		while (columnIndex < columnWidths.count()) {

		        const int valueWidth = d->painter->fontMetrics().boundingRect(content.at(columnIndex)).width();
			if (columnWidths[columnIndex] < valueWidth) {
				columnWidths[columnIndex] = valueWidth;
			}

			columnIndex++;
		}


	}
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *variable : variables) {
        mPainter->drawText(*(mPrintView), Qt::AlignLeft | Qt::TextWordWrap, variable->variable + QLatin1String(" = ") + variable->value);

        const int moveBy = computeStringHeight(variable->variable);
        mPainter->translate(0, moveBy);
    }
```

#### AUTO 


```{c}
auto daysOfWeekLayout = new QGridLayout(daysOfWeekGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        if (ctCron->isDirty()) {
            isDirty = true;
        }
    }
```

#### AUTO 


```{c}
auto v2 = new QVBoxLayout();
```

#### AUTO 


```{c}
const auto crons = crontabWidget->ctHost()->mCrons;
```

#### AUTO 


```{c}
auto commandLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : variables) {
        auto tmp = new CTVariable(*ctVariable);
        d->variable.append(tmp);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : crons) {
            if (ctCron->isCurrentUserCron()) {
                continue;
            }

            if (ctCron->isSystemCron()) {
                continue;
            }

            users.append(ctCron->userLogin());
        }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
```

#### AUTO 


```{c}
auto button = new QPushButton(action->text(), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : std::as_const(d->variable)) {
        if (ctVariable->variable == QLatin1String("PATH")) {
            path = ctVariable->value;
        }
    }
```

#### AUTO 


```{c}
auto hourButton = new NumberPushButton(true, hoursGroup);
```

#### AUTO 


```{c}
auto tmp = new CTTask(*ctTask);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &quote : quotes) {
        if (fullCommand.indexOf(quote) == 0) {
            int nextQuote = fullCommand.indexOf(quote, 1);
            if (nextQuote == -1) {
                return QPair<QString, bool>(QLatin1String(""), false);
            }

            return QPair<QString, bool>(fullCommand.mid(1, nextQuote - 1), true);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        if (ctCron->variables().contains(ctVariable)) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : tasksItems) {
        auto taskWidget = static_cast<TaskWidget *>(item);
        tasksWidget.append(taskWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TaskWidget *taskWidget : tasksWidget) {
            auto task = new CTTask(*(taskWidget->getCTTask()));
            mClipboardTasks.append(task);

            clipboardText += task->exportTask() + QLatin1String("\n");
        }
```

#### AUTO 


```{c}
const auto variables = cron->variables();
```

#### AUTO 


```{c}
auto main = new QWidget(this);
```

#### AUTO 


```{c}
const auto ctasks = cron->tasks();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        const CTSaveStatus ctSaveStatus = ctCron->save();

        if (ctSaveStatus.isError()) {
            return CTSaveStatus(i18nc("User login: errorMessage", "User %1: %2", ctCron->userLogin(), ctSaveStatus.errorMessage()),
                                ctSaveStatus.detailErrorMessage());
        }
    }
```

#### AUTO 


```{c}
auto tmp = new CTVariable(*ctVariable);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : qAsConst(d->variable)) {
        if (ctVariable->variable == QLatin1String("PATH")) {
            path = ctVariable->value;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : qAsConst(d->variable)) {
        if (ctVariable->dirty()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto tasksIcon = new QLabel(this);
```

#### AUTO 


```{c}
auto minuteButton = new NumberPushButton(true, mMinutesGroup);
```

#### AUTO 


```{c}
const auto crons = ctHost()->mCrons;
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        if (ctCron->variables().contains(ctVariable)) {
            return ctCron;
        }
    }
```

#### AUTO 


```{c}
auto labDetails = new QLabel(QLatin1String(""), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : tasksItems) {
        TaskWidget *taskWidget = static_cast<TaskWidget *>(item);
        tasksWidget.append(taskWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : tasks) {
        auto tmp = new CTTask(*ctTask);
        d->task.append(tmp);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        ctCron->cancel();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        if (ctCron->userLogin() == userLogin) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        ctCron->cancel();
    }
```

#### AUTO 


```{c}
auto treeLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        if (ctCron->isCurrentUserCron()) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : associatedWidgets) {
        // Only change status of associated Buttons
        auto button = qobject_cast<QPushButton *>(widget);
        if (button) {
            button->setEnabled(enabled);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : std::as_const(d->task)) {
        exportCron += ctTask->exportTask();
        exportCron += QLatin1String("\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *variable : variables) {
        commandList << QStringLiteral("export %1=\"%2\"").arg(variable->variable, variable->value);
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(main);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : qAsConst(mCrons)) {
        if (ctCron->tasks().contains(ctTask)) {
            return ctCron;
        }
    }
```

#### AUTO 


```{c}
const auto crons = ctHost()->crons;
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& content : contents) {
		if (index==0)
			firstColumn = content;

		d->painter->drawText(*(d->printView), Qt::AlignLeft | Qt::TextWordWrap, QLatin1String( " " ) + content);

		d->painter->translate(columnWidths[index], 0);

		totalWidths += columnWidths[index];

		index++;
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &line : lines) {
        exportComment += QLatin1String("#") + line + QLatin1String("\n");
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (TaskWidget* taskWidget : tasksWidget) {
			CTTask* task = new CTTask( *(taskWidget->getCTTask()) );
			d->clipboardTasks.append(task);

			clipboardText += task->exportTask() + QLatin1String( "\n" );
		}
```

#### AUTO 


```{c}
const auto crons = mCtHost->mCrons;
```

#### AUTO 


```{c}
const auto associatedWidgets = action->associatedWidgets();
```

#### AUTO 


```{c}
auto layout = new QGridLayout;
```

#### AUTO 


```{c}
auto labComment = new QLabel(i18n("Co&mment:"), main);
```

#### AUTO 


```{c}
auto userLabel = new QLabel(i18n("&Run as:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : variablesItems) {
        auto variableWidget = static_cast<VariableWidget *>(item);
        variablesWidget.append(variableWidget);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : std::as_const(d->variable)) {
        ctVariable->apply();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        if (ctCron->isMultiUserCron()) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int width : std::as_const(columnWidths)) {
        qCDebug(KCM_CRON_LOG) << "Column : " << width;
        columnWidthSum += width;
    }
```

#### AUTO 


```{c}
auto tmp = new CTTask(line, comment, d->userLogin, d->multiUserCron);
```

#### AUTO 


```{c}
auto task =
        new CTTask(QLatin1String(""), QLatin1String(""), crontabWidget()->currentCron()->userLogin(), crontabWidget()->currentCron()->isMultiUserCron());
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        if (ctCron->isDirty()) {
            isDirty = true;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        if (ctCron->isCurrentUserCron()) {
            return ctCron;
        }
    }
```

#### AUTO 


```{c}
auto variableWidget = static_cast<VariableWidget *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (int width : std::as_const(columnWidths)) {
        logDebug() << "Column : " << width;
        columnWidthSum += width;
    }
```

#### AUTO 


```{c}
auto main_ = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        if (ctCron->tasks().contains(ctTask)) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : tasks) {
        new TaskWidget(this, ctTask);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &contents : std::as_const(tasksContent)) {
        drawContentRow(tasksColumnWidths, contents);

        needNewPage();
    }
```

#### AUTO 


```{c}
auto task = new CTTask(*(taskWidget->getCTTask()));
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : variables) {
        CTVariable *tmp = new CTVariable(*ctVariable);
        d->variable.append(tmp);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : crons) {
        if (ctCron->isSystemCron()) {
            continue;
        }

        users.append(ctCron->userLogin());

        //Select the actual user
        if (ctCron->userLogin() == selectedUserLogin) {
            selectedIndex = userComboIndex;
        }

        userComboIndex++;
    }
```

#### AUTO 


```{c}
auto v1 = new QVBoxLayout();
```

#### AUTO 


```{c}
auto daysOfMonthLayout = new QGridLayout(daysOfMonthGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask* task : tasks) {
		QStringList values;
		values << task->schedulingCronFormat();
		values << task->command;
		values << task->comment;

		tasksContent.append(values);
	}
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : tasks) {
        ctTask->cancel();
    }
```

#### AUTO 


```{c}
auto variable = new CTVariable(QLatin1String(""), QLatin1String(""), crontabWidget()->currentCron()->userLogin());
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *variable : std::as_const(mClipboardVariables)) {
            mVariablesWidget->addVariable(new CTVariable(*variable));
        }
```

#### AUTO 


```{c}
auto printDialog = new QPrintDialog(mPrinter, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *cron : crons) {
        if (cron->isSystemCron()) {
            continue;
        }
        const auto cvariables = cron->variables();
        for (CTVariable *variable : cvariables) {
            variables.append(variable);
        }
    }
```

#### AUTO 


```{c}
auto monthLayout = new QVBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList& contents : qAsConst(tasksContent)) {

		drawContentRow(tasksColumnWidths, contents);

		needNewPage();

	}
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *variable : cvariables) {
            variables.append(variable);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (int columnWidth : columnWidths) {
        columnWidthsTotal += columnWidth;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &content : contents) {
        if (index == 0) {
            firstColumn = content;
        }

        mPainter->drawText(*(mPrintView), Qt::AlignLeft | Qt::TextWordWrap, QLatin1String(" ") + content);

        mPainter->translate(columnWidths[index], 0);

        totalWidths += columnWidths[index];

        index++;
    }
```

#### AUTO 


```{c}
auto splitter = new QSplitter(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : variablesItems) {
        VariableWidget *variableWidget = static_cast<VariableWidget *>(item);
        variablesWidget.append(variableWidget);
    }
```

#### AUTO 


```{c}
auto labValue = new QLabel(i18n("Va&lue:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (int period : periods) {
        bool validPeriod = true;

        for (int i = minimum(); i <= maximum(); i++) {
            bool periodTesting;
            if ((double)i / (double)period == i / period) {
                periodTesting = true;
            } else {
                periodTesting = false;
            }

            if (isEnabled(i) != periodTesting) {
                validPeriod = false;
                break;
            }
        }

        if (validPeriod) {
            return period;
        }
    }
```

#### AUTO 


```{c}
auto checkboxesLayout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (TaskWidget *taskWidget : tasksWidget) {
            CTTask *task = new CTTask(*(taskWidget->getCTTask()));
            mClipboardTasks.append(task);

            clipboardText += task->exportTask() + QLatin1String("\n");
        }
```

#### AUTO 


```{c}
auto group = new QButtonGroup(this);
```

#### AUTO 


```{c}
auto labVariable = new QLabel(i18nc("The environmental variable name ie HOME, MAILTO etc", "&Variable:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCtHost->mCrons)) {
        taskCount += ctCron->tasks().count();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : variables) {
        ctVariable->cancel();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int period : periods) {
        bool validPeriod = true;

        for (int i = minimum(); i <= maximum(); i++) {
            bool periodTesting;
            if ((double)i/(double)period == i/period) {
                periodTesting = true;
            } else {
                periodTesting = false;
            }

            if (isEnabled(i) != periodTesting) {
                validPeriod = false;
                break;
            }
        }

        if (validPeriod) {
            return period;
        }
    }
```

#### AUTO 


```{c}
const auto tasks = cron->tasks();
```

#### AUTO 


```{c}
auto minutesPreselectionLabel = new QLabel(i18n("Preselection:"));
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : std::as_const(d->variable)) {
        if (ctVariable->dirty()) {
            return true;
        }
    }
```

#### AUTO 


```{c}
auto monthsGroup = new QGroupBox(i18n("Months"), main);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : std::as_const(mCrons)) {
        if (ctCron->userLogin() == userLogin) {
            return ctCron;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : tasksItems) {
        TaskWidget *taskWidget = static_cast<TaskWidget *>(item);

        crontabWidget()->currentCron()->removeTask(taskWidget->getCTTask());
        delete taskWidget->getCTTask();
        treeWidget()->takeTopLevelItem(treeWidget()->indexOfTopLevelItem(taskWidget));
        delete taskWidget;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *variable : qAsConst(mClipboardVariables)) {
            mVariablesWidget->addVariable(new CTVariable(*variable));
        }
```

#### AUTO 


```{c}
auto daysOfMonthGroup = new QGroupBox(i18n("Days of Month"), main);
```

#### AUTO 


```{c}
auto detailsLayout = new QHBoxLayout;
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : variablesItems) {
        VariableWidget *variableWidget = static_cast<VariableWidget *>(item);

        crontabWidget()->currentCron()->removeVariable(variableWidget->getCTVariable());
        delete variableWidget->getCTVariable();
        treeWidget()->takeTopLevelItem(treeWidget()->indexOfTopLevelItem(variableWidget));
        delete variableWidget;
    }
```

#### AUTO 


```{c}
auto action = new QAction(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : qAsConst(d->task)) {
        exportCron += ctTask->exportTask();
        exportCron += QLatin1String("\n");
    }
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto cvariables = cron->variables();
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTCron *ctCron : crons) {
        users.append(ctCron->userLogin());

        if (ctCron->userLogin() == selectedUserLogin) {
            selectedIndex = userComboIndex;
        }

        userComboIndex++;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QWidget *widget : associatedWidgets) {
        //Only change status of associated Buttons
        QPushButton *button = qobject_cast<QPushButton *>(widget);
        if (button) {
            button->setEnabled(enabled);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem *item : variablesItems) {
        auto variableWidget = static_cast<VariableWidget *>(item);

        crontabWidget()->currentCron()->removeVariable(variableWidget->getCTVariable());
        delete variableWidget->getCTVariable();
        treeWidget()->takeTopLevelItem(treeWidget()->indexOfTopLevelItem(variableWidget));
        delete variableWidget;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (QTreeWidgetItem* item : variablesItems) {
		VariableWidget* variableWidget = static_cast<VariableWidget*>(item);
		variablesWidget.append(variableWidget);
	}
```

#### AUTO 


```{c}
auto userLabel = new QLabel(i18n("&Run as:"), main);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable *ctVariable : variables) {
        new VariableWidget(this, ctVariable);
    }
```

#### AUTO 


```{c}
auto labComment = new QLabel(i18n("Co&mment:"), this);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *task : qAsConst(mClipboardTasks)) {
            mTasksWidget->addTask(new CTTask(*task));
        }
```

#### AUTO 


```{c}
auto monthsLayout = new QGridLayout(monthsGroup);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTVariable* variable : variables) {
		d->painter->drawText(*(d->printView), Qt::AlignLeft | Qt::TextWordWrap, variable->variable + QLatin1String( " = " ) + variable->value);

        const int moveBy = computeStringHeight(variable->variable);
		d->painter->translate(0, moveBy);
	}
```

#### AUTO 


```{c}
auto layout = new QHBoxLayout();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &quote : quotes) {
        if (fullCommand.indexOf(quote) == 0) {
            int nextQuote = fullCommand.indexOf(quote, 1);
            if (nextQuote == -1) {
                return QPair<QString, bool>(QLatin1String(""), false);
            }

            return QPair<QString, bool>(fullCommand.mid(1, nextQuote-1), true);
        }
    }
```

#### AUTO 


```{c}
auto p = new CTCron(mCrontabBinary, userInfos, currentUserCron, ctInitializationError);
```

#### AUTO 


```{c}
auto daysOfWeekGroup = new QGroupBox(i18n("Days of Week"), main);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &contents : qAsConst(tasksContent)) {
        drawContentRow(tasksColumnWidths, contents);

        needNewPage();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int width : qAsConst(columnWidths)) {
        logDebug() << "Column : " << width;
        columnWidthSum += width;
    }
```

#### AUTO 


```{c}
auto tasksLabel = new QLabel(label, this);
```

#### AUTO 


```{c}
const auto variables = ctCron->variables();
```

#### AUTO 


```{c}
auto taskWidget = static_cast<TaskWidget *>(item);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QStringList &content : contents) {
        int columnIndex = 0;
        while (columnIndex < columnWidths.count()) {
            const int valueWidth = mPainter->fontMetrics().boundingRect(content.at(columnIndex)).width();
            if (columnWidths[columnIndex] < valueWidth) {
                columnWidths[columnIndex] = valueWidth;
            }

            columnIndex++;
        }
    }
```

#### AUTO 


```{c}
auto tmp = new CTVariable(line, comment, d->userLogin);
```

#### RANGE FOR STATEMENT 


```{c}
for (CTTask *ctTask : qAsConst(d->task)) {
        if (ctTask->dirty()) {
            return true;
        }
    }
```

