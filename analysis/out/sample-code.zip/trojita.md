#### LAMBDA EXPRESSION 


```{c}
[this, mailboxName, &ok](const QUrl &url){
        QFile f(url.path());
        if (!f.open(QIODevice::ReadOnly))
            return;

        static_cast<Imap::Mailbox::Model *>(sourceModel())->appendIntoMailbox(
                    mailboxName, f.readAll(), QStringList() << Imap::Mailbox::FlagNames::seen,
                    QFileInfo(url.path()).lastModified());
        ok = true;
    }
```

#### AUTO 


```{c}
auto lbl = new QLabel(tr("<b>Subject:</b>&nbsp;%1").arg(escapedSubject), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Common::LogKind kind, const QString& source, const QString& message) {
        imapLogger->log(0, Common::LogMessage(QDateTime::currentDateTime(), kind, source, message, 0));
    }
```

#### AUTO 


```{c}
auto threadingModel = qobject_cast<Imap::Mailbox::ThreadingMsgListModel*>(findPrettyMsgListModel(model())->sourceModel());
```

#### AUTO 


```{c}
auto newJob = addressbook->requestCompletion(text, QStringList(), m_completionCount);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &what) {
        auto name = what.data(Imap::Mailbox::RoleMailboxName).toString();
        if (!m_desiredExpansionState.contains(name)) {
            m_desiredExpansionState.insert(name);
            emit mailboxExpansionChanged(m_desiredExpansionState.toList());
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString& message) {
        emit logged(Common::LogKind::LOG_SUBMISSION, QStringLiteral("ComposeWidget"), message);
    }
```

#### AUTO 


```{c}
auto model = qobject_cast<Model*>(sender());
```

#### LAMBDA EXPRESSION 


```{c}
[&messageUids](const Imap::Message::MailAddress &identity) {
        messageUids.emplace_back(identity.asSMTPMailbox().data());
    }
```

#### AUTO 


```{c}
const auto &sig
```

#### AUTO 


```{c}
auto item = std::find(m_currentSortResult.begin(), m_currentSortResult.end(), it->uids[i]);
```

#### AUTO 


```{c}
auto cipherData = m_encPart.data(RolePartData).toByteArray();
```

#### AUTO 


```{c}
auto cid = url.path().toUtf8();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Common::LogKind kind, const QString& source, const QString& message) {
        protocolLogger->log(0, Common::LogMessage(QDateTime::currentDateTime(), kind, source, message, 0));
    }
```

#### AUTO 


```{c}
auto rawPart = dynamic_cast<LocalMessagePart *>(part.get());
```

#### AUTO 


```{c}
auto bodyStart = rawPartData.indexOf(headerBoundary, headerStart + 1);
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::AddingWidget, QString(), QStringLiteral("lightgreen"));
```

#### AUTO 


```{c}
auto oldUidMap = model->cache()->uidMapping(mailbox->mailbox());
```

#### AUTO 


```{c}
auto accountIconName = m_settings->value(Common::SettingsNames::imapAccountIcon).toString();
```

#### AUTO 


```{c}
auto x = idx.data(Imap::Mailbox::RoleUnreadMessageCount).toInt();
```

#### AUTO 


```{c}
auto netAccess = new Imap::Network::MsgPartNetAccessManager(this);
```

#### AUTO 


```{c}
auto parentPart = translatePtr(parent);
```

#### AUTO 


```{c}
auto fullMsgLayout = new QVBoxLayout(m_messageWidget);
```

#### LAMBDA EXPRESSION 


```{c}
[this, ctx, rawData, signatureData, messageUids, wasEncrypted](){
        QPointer<QObject> p(this);

        GpgME::Data sigData(signatureData.data(), signatureData.size(), false);
        GpgME::Data msgData(rawData.data(), rawData.size(), false);

        auto verificationResult = ctx->verifyDetachedSignature(sigData, msgData);
        bool wasSigned = false;
        bool sigOkDisregardingTrust = false;
        bool sigValidVerified = false;
        bool uidMatched = false;
        QString tldr;
        QString longStatus;
        QString icon;
        QString signer;
        QDateTime signDate;

        if (verificationResult.numSignatures() == 0) {
            tldr = tr("No signatures in the signed message");
            icon = QStringLiteral("script-error");
        }

        for (const auto &sig: verificationResult.signatures()) {
            wasSigned = true;
            extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                   sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

            // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
            break;
        }
        submitVerifyResult(p, {wasSigned, sigOkDisregardingTrust, sigValidVerified, tldr, longStatus, icon, signer, signDate});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &e) { this->errorLog.push_back(e); }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        QGuiApplication::clipboard()->setText(m_address.prettyName(Imap::Message::MailAddress::FORMAT_JUST_NAME));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: supportedColorSchemes()) {
        QAction *a = colorSchemeMenu->addAction(item.second);
        connect(a, &QAction::triggered, this, [this, item](){
           const_cast<SimplePartWidget*>(this)->setColorScheme(item.first);
        });
        a->setCheckable(true);
        if (item.first == m_colorScheme) {
            a->setChecked(true);
        }
        a->setActionGroup(ag);
    }
```

#### AUTO 


```{c}
auto xtbIt = response.data.constFind("x-trojita-bodystructure");
```

#### LAMBDA EXPRESSION 


```{c}
[this](TreeItemPart *part, const QByteArray &partId, const uint uid) {
        if (!part) {
            log(QStringLiteral("FETCH: Cannot find part %1 for UID %2 in the tree")
                .arg(QString::fromUtf8(partId), QString::number(uid)), Common::LOG_MESSAGES);
            return;
        }
        if (part->loading()) {
            log(QStringLiteral("Received no data for part %1 UID %2").arg(QString::fromUtf8(partId), QString::number(uid)),
                Common::LOG_MESSAGES);
            markPartUnavailable(part);
        } else {
            log(QStringLiteral("Fetched part %1 for UID %2").arg(QString::fromUtf8(partId), QString::number(uid)),
                Common::LOG_MESSAGES);
        }
    }
```

#### AUTO 


```{c}
auto deepestChild = [](const QAbstractItemModel *model, QModelIndex where) -> QModelIndex {
        while (model->hasChildren(where)) {
            where = model->index(model->rowCount(where) - 1, 0, where);
        }
        return where;
    };
```

#### AUTO 


```{c}
auto it = m_children.find(row);
```

#### AUTO 


```{c}
auto parentPart = childPart->parent();
```

#### AUTO 


```{c}
auto message = dynamic_cast<TreeItemMessage*>(static_cast<TreeItemMessage*>(topLeft.internalPointer()));
```

#### AUTO 


```{c}
auto r1 = t.last("OK you courious peer\r\n");
```

#### AUTO 


```{c}
auto parts = *it;
```

#### AUTO 


```{c}
auto updateTagList = [this]() {
        tags->setTagList(message.data(Imap::Mailbox::RoleMessageFlags).toStringList());
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        QGuiApplication::clipboard()->setText(Composer::extractOneMailAddress(m_address.asUrl()));
    }
```

#### AUTO 


```{c}
auto it = head->m_children.constBegin() + 1;
```

#### AUTO 


```{c}
auto data = "BURL " + url + " LAST\r\n";
```

#### AUTO 


```{c}
auto composer = std::make_shared<Composer::MessageComposer>(mainWindow->imapModel());
```

#### AUTO 


```{c}
auto okSelectedB = t.last("OK selected\r\n");
```

#### AUTO 


```{c}
auto newChildren = abstractMessage->createTreeItems(item);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto message: messages) {
        for (const auto &partId: parts) {
            auto part = mailbox->partIdToPtr(model, static_cast<TreeItemMessage *>(message), partId);
            f(part, partId, message->uid());
        }
    }
```

#### AUTO 


```{c}
auto updateTag = [=](const QModelIndex &i, bool &hasTag, int index) {
        if (hasTag && !m_favoriteTags->tagNameByIndex(index).isEmpty() &&
                !i.data(Imap::Mailbox::RoleMessageFlags).toStringList().contains(m_favoriteTags->tagNameByIndex(index)))
        {
            hasTag = false;
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[&buf](const QByteArray &prefix, const QList<QByteArray> &recipients) {
        if (recipients.empty())
            return;
        buf += prefix + ": ";
        for (int i = 0; i < recipients.size() - 1; ++i)
            buf += recipients[i] + ",\r\n ";
        buf += recipients.last() + "\r\n";
    }
```

#### AUTO 


```{c}
auto nw = qobject_cast<Imap::Mailbox::NetworkWatcher *>(m_imapAccess->networkWatcher());
```

#### AUTO 


```{c}
static auto conn = QObject::connect(qApp, &QCoreApplication::aboutToQuit, [](){
        iconDict.clear();
    });
```

#### AUTO 


```{c}
auto runner = it;
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx) { return idx.data().toString().contains(QLatin1Char('_')); }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin: m_availableSpellchckePlugins) {
        res[plugin->name()] = plugin->description();
    }
```

#### AUTO 


```{c}
auto qFoo3 = t.mk("UID FETCH 15:* (FLAGS)\r\n");
```

#### AUTO 


```{c}
auto pixmap = qApp->windowIcon()
                .pixmap(QSize(32, 32), isOffline ? QIcon::Disabled : QIcon::Normal);
```

#### AUTO 


```{c}
auto mailbox = dynamic_cast<TreeItemMailbox *>(static_cast<TreeItem *>(index.internalPointer()));
```

#### AUTO 


```{c}
auto q = t.mk(QString("CANCELUPDATE \"" + searchTag + "\"\r\n").toLocal8Bit().data());
```

#### LAMBDA EXPRESSION 


```{c}
[&](Qt::ApplicationState state) {
                if (state == Qt::ApplicationActive && m_networkErrorMessageBox && m_networkErrorMessageBox->property(netErrorUnseen).toBool()) {
                    m_networkErrorMessageBox->setProperty(netErrorUnseen, false);
                    m_networkErrorMessageBox->show();
                }
            }
```

#### AUTO 


```{c}
auto currentConfig = sessionsActiveConfiguration();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &partId: parts) {
            auto part = mailbox->partIdToPtr(model, static_cast<TreeItemMessage *>(message), partId);
            f(part, partId, message->uid());
        }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex &i, bool &hasTag, int index) {
        if (hasTag && !m_favoriteTags->tagNameByIndex(index).isEmpty() &&
                !i.data(Imap::Mailbox::RoleMessageFlags).toStringList().contains(m_favoriteTags->tagNameByIndex(index)))
        {
            hasTag = false;
        }
    }
```

#### AUTO 


```{c}
auto operator-(
  const stashing_reverse_iterator<Iterator1>& x,
  const stashing_reverse_iterator<Iterator2>& y) -> decltype(y.base() - x.base())
{ return y.base() - x.base(); }
```

#### AUTO 


```{c}
auto result = std::find_first_of(m_tags.begin(), m_tags.end(), tags.begin(), tags.end(),
            [](const ItemFavoriteTagItem &tag, const QString &tag_name) {
        return tag.name == tag_name;
    });
```

#### AUTO 


```{c}
auto it = m_flags.begin();
```

#### AUTO 


```{c}
auto w = bodyWidget()
```

#### AUTO 


```{c}
auto list = TreeItem::setChildren(items);
```

#### AUTO 


```{c}
auto val = m_settings->value(Common::SettingsNames::imapStartMode).toString();
```

#### AUTO 


```{c}
auto item3 = new QStandardItem("a.A.1");
```

#### AUTO 


```{c}
auto ctx = m_ctx;
```

#### AUTO 


```{c}
auto uids = resp.uids;
```

#### AUTO 


```{c}
auto recipients = QList<QPair<Composer::RecipientKind,QString>>();
```

#### AUTO 


```{c}
auto lbl = new QLabel(tr("<b>Date:</b>&nbsp;%1").arg(date.toHtmlEscaped()), this);
```

#### LAMBDA EXPRESSION 


```{c}
[obj](ParserState &state) {
        state.activeTasks.removeOne(reinterpret_cast<ImapTask*>(obj));
    }
```

#### AUTO 


```{c}
auto oldItems = mailboxPtr->setChildren(TreeItemChildrenList());
```

#### AUTO 


```{c}
auto searchConditions = m_filteredBySearch ? m_currentSearchConditions : QStringList() << QStringLiteral("ALL");
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        QApplication::setOverrideCursor(Qt::BusyCursor);
    }
```

#### AUTO 


```{c}
auto realMsgListModel = qobject_cast<Imap::Mailbox::MsgListModel*>(m_imapAccess->msgListModel());
```

#### AUTO 


```{c}
auto childPart = translatePtr(child);
```

#### LAMBDA EXPRESSION 


```{c}
[url]() {
                QToolTip::showText(QCursor::pos(), QObject::tr("Link target: %1").arg(UiUtils::Formatting::htmlEscaped(url)));
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ this->timeToCommit(); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](uint, const Imap::ConnectionState state) {
        if (state == Imap::CONN_STATE_AUTHENTICATED) {
            m_ignoreStoredPassword = false;
        }
    }
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::UserKeyword, tagName, color);
```

#### AUTO 


```{c}
auto oldItems = list->m_children;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sig: combinedResult.second.signatures()) {
                wasSigned = true;
                extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                       sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

                // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
                break;
            }
```

#### AUTO 


```{c}
auto preambleViaSmtp = QString::fromUtf8(outgoingMessage).left(preambleViaImap.size());
```

#### AUTO 


```{c}
auto it = h.begin(), end = h.end();
```

#### LAMBDA EXPRESSION 


```{c}
[&messageUids](const Imap::Message::MailAddress &identity) {
                messageUids.emplace_back(identity.asSMTPMailbox().data());
            }
```

#### AUTO 


```{c}
const auto & mailboxParts = parts[mailbox];
```

#### AUTO 


```{c}
auto protocol = bodyFldParam[QByteArray("PROTOCOL")].toLower();
```

#### AUTO 


```{c}
auto uids = respData->data.second.toVector();
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &url) {
        if (url.isEmpty()) {
            QToolTip::hideText();
        } else {
            QToolTip::showText(QCursor::pos(), tr("Link target: %1").arg(UiUtils::Formatting::htmlEscaped(url)));
        }
    }
```

#### AUTO 


```{c}
const auto splitItems = items.split(QLatin1Char(' '));
```

#### AUTO 


```{c}
auto c2 = t.mk("SELECT a\r\n");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item: supportedColorSchemes()) {
        QAction *a = colorSchemeMenu->addAction(item.second);
        connect(a, &QAction::triggered, this, [this, item](){
           const_cast<SimplePartWidget*>(this)->changeColorScheme(item.first);
        });
        a->setCheckable(true);
        if (item.first == m_colorScheme) {
            a->setChecked(true);
        }
        a->setActionGroup(ag);
    }
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::SystemFlag, flagName, Qt::gray);
```

#### LAMBDA EXPRESSION 


```{c}
[this, ctx, cipherData, messageUids ](){
        QPointer<QObject> p(this);

        GpgME::Data encData(cipherData.data(), cipherData.size(), false);
        QGpgME::QByteArrayDataProvider dp;
        GpgME::Data plaintextData(&dp);

        auto combinedResult = ctx->decryptAndVerify(encData, plaintextData);

        bool wasSigned = false;
        bool wasEncrypted = true;
        bool sigOkDisregardingTrust = false;
        bool sigValidVerified = false;
        bool uidMatched = false;
        QString tldr;
        QString longStatus;
        QString icon;
        QString signer;
        QDateTime signDate;

        if (combinedResult.second.numSignatures() != 0) {
            for (const auto &sig: combinedResult.second.signatures()) {
                wasSigned = true;
                extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                       sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

                // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
                break;
            }
        }

        constexpr QChar LF = QLatin1Char('\n');

        bool decryptedOk = !combinedResult.first.error();

        if (combinedResult.first.error()) {
            if (tldr.isEmpty()) {
                tldr = tr("Broken encrypted message");
            }
            longStatus += LF + tr("Decryption error: %1").arg(QString::fromUtf8(combinedResult.first.error().asString()));
            icon = QStringLiteral("emblem-error");
        } else if (tldr.isEmpty()) {
            tldr = tr("Encrypted message");
            icon = QStringLiteral("emblem-encrypted-unlocked");
        }

        if (combinedResult.first.isWrongKeyUsage()) {
            longStatus += LF + tr("Wrong key usage, not for encryption");
        }
        if (auto msg = combinedResult.first.unsupportedAlgorithm()) {
            longStatus += LF + tr("Unsupported algorithm: %1").arg(QString::fromUtf8(msg));
        }

        for (const auto &recipient: combinedResult.first.recipients()) {
            GpgME::Error keyError;
            auto key = ctx->key(recipient.keyID(), keyError, false);
            if (keyError) {
                longStatus += LF + tr("Cannot extract recipient %1: %2")
                        .arg(QString::fromUtf8(recipient.keyID()), QString::fromUtf8(keyError.asString()));
            } else {
                if (key.numUserIDs()) {
                    longStatus += LF + tr("Encrypted to %1 (%2)")
                            .arg(QString::fromUtf8(key.userID(0).id()), QString::fromUtf8(recipient.keyID()));
                } else {
                    longStatus += LF + tr("Encrypted to %1").arg(QString::fromUtf8(recipient.keyID()));
                }
            }
        }
        if (auto fname = combinedResult.first.fileName()) {
            longStatus += LF + tr("Original filename: %1").arg(QString::fromUtf8(fname));
        }

        if (p) {
            bool ok = QMetaObject::invokeMethod(p, "processDecryptedData", Qt::QueuedConnection,
                                                Q_ARG(bool, decryptedOk),
                                                Q_ARG(QByteArray, dp.data()));
            Q_ASSERT(ok); Q_UNUSED(ok);
        } else {
            qDebug() << "[async crypto: GpgMeEncrypted is gone, not sending cleartext data]";
        }
        submitVerifyResult(p, {wasSigned, sigOkDisregardingTrust, sigValidVerified, tldr, longStatus, icon, signer, signDate});
    }
```

#### AUTO 


```{c}
auto it = m_recipients.begin();
```

#### AUTO 


```{c}
auto abookPlugin = qobject_cast<AddressbookPluginInterface *>(pluginInstance)
```

#### AUTO 


```{c}
const auto &recipient
```

#### LAMBDA EXPRESSION 


```{c}
[&finder]() {
        finder.addMailbox(QStringLiteral("a"));
        finder.addMailbox(QStringLiteral("a.A"));
        finder.addMailbox(QStringLiteral("a.A.1"));
    }
```

#### AUTO 


```{c}
auto r2 = t.last("OK listed\r\n");
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &, const QModelIndex &index) {
        expand(index);
    }
```

#### AUTO 


```{c}
auto oldUidMap = uidMapA;
```

#### AUTO 


```{c}
auto headerStart = rawPartData.indexOf(headerBoundary);
```

#### AUTO 


```{c}
auto mboxDropAction = m_settings->value(Common::SettingsNames::mboxDropAction, QVariant(QStringLiteral("ask"))).toString();
```

#### AUTO 


```{c}
auto firstChild = m_current.child(0, 0);
```

#### AUTO 


```{c}
const auto LF = QLatin1Char('\n');
```

#### AUTO 


```{c}
auto r1 = t.last("OK listed\r\n");
```

#### AUTO 


```{c}
auto lbl = new QLabel(tr("<b>Date:</b>&nbsp;%1").arg(escapedDate), this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, mailboxName, &ok](const QUrl &url){
        QFile f(url.path());
        if (!f.open(QIODevice::ReadOnly))
            return;

        auto content = f.readAll();
        // Random heuristics: strip one leading line which starts with "From ", also known as "the mailbox header".
        // Yeah, RFC 4155 says that there's a special MIME type application/mbox just for that, but nope, it's actually not being used.
        // So one gets ".eml" messages which are in fact not message/rfc822 stuff.
        if (content.startsWith("From ")) {
            auto pos = content.indexOf("\n");
            if (pos > 0
                    // random heuristic: don't chop off "too much"
                    && pos < 80
                    // random heiristic: three == one for "\n", two for CR LF which separates the headers from the body...
                    && pos + 3 < content.size()) {
                content = content.mid(pos + 1 /* for the LF */);
            }
        }

        static_cast<Imap::Mailbox::Model *>(sourceModel())->appendIntoMailbox(
                    mailboxName, content, QStringList() << Imap::Mailbox::FlagNames::seen,
                    QFileInfo(url.path()).lastModified());
        ok = true;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin: m_availablePasswordPlugins) {
        res[plugin->name()] = plugin->description();
    }
```

#### AUTO 


```{c}
auto it = mailboxesWithoutChildren.constBegin();
```

#### AUTO 


```{c}
auto uidMapping = cache()->uidMapping(mailbox);
```

#### AUTO 


```{c}
auto pluginManager = new Plugins::PluginManager(0, &s,
                                                    Common::SettingsNames::addressbookPlugin, Common::SettingsNames::passwordPlugin);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &password) {
                authenticationContinue(password);
            }
```

#### AUTO 


```{c}
auto changedSearch = (searchConditions != m_currentSearchConditions);
```

#### AUTO 


```{c}
auto cutoff = it->closedTime - 3 * 60 * 1000;
```

#### LAMBDA EXPRESSION 


```{c}
[this, optionsMenu](){
        optionsMenu->popup(m_quickSearchText->mapToGlobal(QPoint(0, m_quickSearchText->height())), nullptr);
    }
```

#### AUTO 


```{c}
auto msg = dynamic_cast<TopLevelMessage *>(parent())
```

#### AUTO 


```{c}
auto zoomIn = zoomMenu->addAction(UiUtils::loadIcon(QStringLiteral("zoom-in")), tr("Zoom In"));
```

#### AUTO 


```{c}
auto action = m_markAsReply->checkedAction();
```

#### AUTO 


```{c}
auto another = it;
```

#### AUTO 


```{c}
auto tagsLabel = ui->tagsLabel;
```

#### AUTO 


```{c}
auto realThreadingModel = qobject_cast<Imap::Mailbox::ThreadingMsgListModel*>(m_imapAccess->threadingMsgListModel());
```

#### AUTO 


```{c}
auto part3 = rootMultipart.child(2, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ FavoriteTagsPage::moveTagBy(1); }
```

#### AUTO 


```{c}
auto pixmap = UiUtils::loadIcon(QStringLiteral("trojita"))
                .pixmap(QSize(32, 32), isOffline ? QIcon::Disabled : QIcon::Normal);
```

#### AUTO 


```{c}
auto existingCaps = it->capabilities;
```

#### AUTO 


```{c}
auto c1 = t.mk("ID (\"name\" \"Trojita\")\r\n");
```

#### AUTO 


```{c}
auto plugin
```

#### AUTO 


```{c}
auto origStatus = accessFetchStatus();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto x: features) {
        featuresText += x.second ?
                    tr("<li>%1: supported</li>").arg(x.first)
                  : tr("<li>%1: <strong>disabled</strong></li>").arg(x.first);
    }
```

#### AUTO 


```{c}
auto it = logs.begin();
```

#### AUTO 


```{c}
auto emb = qobject_cast<EmbeddedWebView*>(m_associatedWebView)
```

#### AUTO 


```{c}
auto res = m_children;
```

#### LAMBDA EXPRESSION 


```{c}
[this,&actionList](const int row, QAction *tag) {
            if (m_favoriteTags->rowCount() > row - 1)
                actionList.append(tag);
        }
```

#### AUTO 


```{c}
auto newIndexes = oldIndexes;
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
        Gui::Util::messageBoxWarning(this, tr("Plugin Error"),
                                     //: The %1 placeholder is a full error message as provided by Qt, ready for human consumption.
                                     trUtf8("A plugin failed to load, therefore some functionality might be lost. "
                                            "You might want to update your system or report a bug to your vendor."
                                            "\n\n%1").arg(errorMessage));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const bool menuBarVisible) {
        // https://bugreports.qt.io/browse/QTBUG-35768 , we have to work on the QAction, not QToolButton
        m_mainToolbar->actions().last()->setVisible(!menuBarVisible);
    }
```

#### AUTO 


```{c}
auto zoomMenu = menu.addMenu(UiUtils::loadIcon(QStringLiteral("zoom")), tr("Zoom"));
```

#### AUTO 


```{c}
auto end = list->m_children.constEnd();
```

#### AUTO 


```{c}
auto zoomOut = zoomMenu->addAction(UiUtils::loadIcon(QStringLiteral("zoom-out")), tr("Zoom Out"));
```

#### AUTO 


```{c}
auto it = Common::make_stashing_reverse_iterator(QaimDfsIterator(currentIndex, model));
```

#### AUTO 


```{c}
auto partIndex = Imap::Network::MsgPartNetAccessManager::pathToPart(msgListA.child(row, 0), mimePart);
```

#### LAMBDA EXPRESSION 


```{c}
[this, ctx, cipherData, messageUids ](){
        QPointer<QObject> p(this);
        DebugProgress progress;
        ctx->setProgressProvider(&progress);

        GpgME::Data encData(cipherData.data(), cipherData.size(), false);
        QGpgME::QByteArrayDataProvider dp;
        GpgME::Data plaintextData(&dp);

        auto combinedResult = ctx->decryptAndVerify(encData, plaintextData);

        bool wasSigned = false;
        bool wasEncrypted = true;
        bool sigOkDisregardingTrust = false;
        bool sigValidVerified = false;
        bool uidMatched = false;
        QString tldr;
        QString longStatus;
        QString icon;
        QString signer;
        QDateTime signDate;

        if (combinedResult.second.numSignatures() != 0) {
            for (const auto &sig: combinedResult.second.signatures()) {
                wasSigned = true;
                extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                       sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

                // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
                break;
            }
        }

        constexpr QChar LF = QLatin1Char('\n');

        bool decryptedOk = !combinedResult.first.error();

        if (combinedResult.first.error()) {
            if (tldr.isEmpty()) {
                tldr = tr("Broken encrypted message");
            }
            longStatus += LF + tr("Decryption error: %1").arg(QString::fromUtf8(combinedResult.first.error().asString()));
            icon = QStringLiteral("emblem-error");
        } else if (tldr.isEmpty()) {
            tldr = tr("Encrypted message");
            icon = QStringLiteral("emblem-encrypted-unlocked");
        }

        if (combinedResult.first.isWrongKeyUsage()) {
            longStatus += LF + tr("Wrong key usage, not for encryption");
        }
        if (auto msg = combinedResult.first.unsupportedAlgorithm()) {
            longStatus += LF + tr("Unsupported algorithm: %1").arg(QString::fromUtf8(msg));
        }

        for (const auto &recipient: combinedResult.first.recipients()) {
            GpgME::Error keyError;
            auto key = ctx->key(recipient.keyID(), keyError, false);
            if (keyError) {
                longStatus += LF + tr("Cannot extract recipient %1: %2")
                        .arg(QString::fromUtf8(recipient.keyID()), QString::fromUtf8(keyError.asString()));
            } else {
                if (key.numUserIDs()) {
                    longStatus += LF + tr("Encrypted to %1 (%2)")
                            .arg(QString::fromUtf8(key.userID(0).id()), QString::fromUtf8(recipient.keyID()));
                } else {
                    longStatus += LF + tr("Encrypted to %1").arg(QString::fromUtf8(recipient.keyID()));
                }
            }
        }
        if (auto fname = combinedResult.first.fileName()) {
            longStatus += LF + tr("Original filename: %1").arg(QString::fromUtf8(fname));
        }

        if (p) {
            bool ok = QMetaObject::invokeMethod(p, "processDecryptedData", Qt::QueuedConnection,
                                                Q_ARG(bool, decryptedOk),
                                                Q_ARG(QByteArray, dp.data()));
            Q_ASSERT(ok);
        } else {
            qDebug() << "[async crypto: GpgMeEncrypted is gone, not sending cleartext data]";
        }
        submitVerifyResult(p, {wasSigned, sigOkDisregardingTrust, sigValidVerified, tldr, longStatus, icon, signer, signDate});
    }
```

#### AUTO 


```{c}
auto childIndex = index.child(row, 0);
```

#### AUTO 


```{c}
auto c3 = t.mk("SELECT b\r\n");
```

#### AUTO 


```{c}
auto rawIdx = index.child(0, Imap::Mailbox::TreeItem::OFFSET_RAW_CONTENTS);
```

#### LAMBDA EXPRESSION 


```{c}
[this, ctx, cipherData, messageUids ](){
        QPointer<QObject> p(this);

        GpgME::Data encData(cipherData.data(), cipherData.size(), false);
        QGpgME::QByteArrayDataProvider dp;
        GpgME::Data plaintextData(&dp);

        auto combinedResult = ctx->decryptAndVerify(encData, plaintextData);

        bool wasSigned = false;
        bool wasEncrypted = true;
        bool sigOkDisregardingTrust = false;
        bool sigValidVerified = false;
        bool uidMatched = false;
        QString tldr;
        QString longStatus;
        QString icon;
        QString signer;
        QDateTime signDate;

        if (combinedResult.second.numSignatures() != 0) {
            for (const auto &sig: combinedResult.second.signatures()) {
                wasSigned = true;
                extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                       sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

                // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
                break;
            }
        }

        constexpr QChar LF = QLatin1Char('\n');

        bool decryptedOk = !combinedResult.first.error();

        if (combinedResult.first.error()) {
            if (tldr.isEmpty()) {
                tldr = tr("Broken encrypted message");
            }
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Decryption error: %1").arg(QString::fromUtf8(combinedResult.first.error().asString()));
            icon = QStringLiteral("emblem-error");
        } else if (tldr.isEmpty()) {
            tldr = tr("Encrypted message");
            icon = QStringLiteral("emblem-encrypted-unlocked");
        }

        if (combinedResult.first.isWrongKeyUsage()) {
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Wrong key usage, not for encryption");
        }
        if (auto msg = combinedResult.first.unsupportedAlgorithm()) {
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Unsupported algorithm: %1").arg(QString::fromUtf8(msg));
        }

        for (const auto &recipient: combinedResult.first.recipients()) {
            GpgME::Error keyError;
            auto key = ctx->key(recipient.keyID(), keyError, false);
            if (keyError) {
                ENSURE_LINE_LF(longStatus);
                longStatus += tr("Cannot extract recipient %1: %2")
                        .arg(QString::fromUtf8(recipient.keyID()), QString::fromUtf8(keyError.asString()));
            } else {
                if (key.numUserIDs()) {
                    ENSURE_LINE_LF(longStatus);
                    longStatus += tr("Encrypted to %1 (%2)")
                            .arg(QString::fromUtf8(key.userID(0).id()), QString::fromUtf8(recipient.keyID()));
                } else {
                    ENSURE_LINE_LF(longStatus);
                    longStatus += tr("Encrypted to %1").arg(QString::fromUtf8(recipient.keyID()));
                }
            }
        }
        if (auto fname = combinedResult.first.fileName()) {
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Original filename: %1").arg(QString::fromUtf8(fname));
        }

        if (p) {
            bool ok = QMetaObject::invokeMethod(p, "processDecryptedData", Qt::QueuedConnection,
                                                Q_ARG(bool, decryptedOk),
                                                Q_ARG(QByteArray, dp.data()));
            Q_ASSERT(ok); Q_UNUSED(ok);
        } else {
            qDebug() << "[async crypto: GpgMeEncrypted is gone, not sending cleartext data]";
        }
        submitVerifyResult(p, {wasSigned, sigOkDisregardingTrust, sigValidVerified, tldr, longStatus, icon, signer, signDate});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray& data) {
        emit logged(Common::LogKind::LOG_IO_READ, QStringLiteral("SMTP"), QString::fromUtf8(data));
    }
```

#### AUTO 


```{c}
auto qaim = qobject_cast<QAbstractItemModel *>(sender())
```

#### AUTO 


```{c}
auto parser = std::find_if(m_model->m_parsers.cbegin(), m_model->m_parsers.cend(),
                 [](const Imap::Mailbox::ParserState & state) {
        return state.connState != CONN_STATE_LOGOUT && state.connState >= CONN_STATE_AUTHENTICATED;
    });
```

#### AUTO 


```{c}
auto geometry = settings->value(Common::SettingsNames::completeMessageWidgetGeometry);
```

#### AUTO 


```{c}
auto msg1 = msgListA.child(0, 0);
```

#### AUTO 


```{c}
auto appendTagIfExists = [this,&actionList](const int row, QAction *tag) {
            if (m_favoriteTags->rowCount() > row - 1)
                actionList.append(tag);
        };
```

#### AUTO 


```{c}
auto mboxDropAction = s.value(Common::SettingsNames::mboxDropAction, QVariant(QStringLiteral("ask"))).toString();
```

#### AUTO 


```{c}
auto components = email.split(QLatin1Char('@'));
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::SystemFlag, flagName, QStringLiteral("lightgrey"));
```

#### AUTO 


```{c}
auto overrideIcon = QString(QLatin1String(":/icons/%1/%2.svg")).arg(QIcon::themeName(), name);
```

#### AUTO 


```{c}
auto aHost = a.host.toLower();
```

#### AUTO 


```{c}
const auto &oneAddr
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](){
           const_cast<SimplePartWidget*>(this)->changeColorScheme(item.first);
        }
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::SystemFlag, flagName, QLatin1String("lightgrey"));
```

#### AUTO 


```{c}
auto textIdx = index.child(0, Imap::Mailbox::TreeItem::OFFSET_TEXT);
```

#### AUTO 


```{c}
const auto &index = oldIndexes[i];
```

#### LAMBDA EXPRESSION 


```{c}
[=](int row) {
        QAction *tag = ShortcutHandler::instance()->createAction(QStringLiteral("action_tag_").append(QString::number(row)), this);
        tag->setCheckable(true);
        msgListWidget->tree->addAction(tag);
        connect(tag, &QAction::triggered, this, [=](const bool checked) {
            handleTag(checked, row - 1);
        });
        return tag;
    }
```

#### AUTO 


```{c}
auto cacheLog = std::make_shared<MonitoringCache>();
```

#### AUTO 


```{c}
FORWARD_METHOD(searchDialogRequested)
```

#### AUTO 


```{c}
auto job = addressbook->requestPrettyNamesForAddress(addr.mailbox + QLatin1Char('@') + addr.host);
```

#### AUTO 


```{c}
auto &task
```

#### AUTO 


```{c}
auto furtherMessage = it;
```

#### AUTO 


```{c}
auto numbers = LowLevelParser::getSequence(line, start);
```

#### AUTO 


```{c}
auto archiveFolderName = m_settings->value(Common::SettingsNames::imapArchiveFolderName).toString();
```

#### AUTO 


```{c}
auto find = new QAction(UiUtils::loadIcon(QStringLiteral("edit-find")), tr("Search..."), this);
```

#### AUTO 


```{c}
auto size = c_str - old_str;
```

#### AUTO 


```{c}
auto dummy = mailboxPtr->setChildren(mailboxes);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QPair<Composer::RecipientKind, Imap::Message::MailAddress> &addr) {
        return addr.second.asSMTPMailbox();
    }
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto subject = messageRoot.data(Imap::Mailbox::RoleMessageSubject).toString();
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::UserKeyword, tagName, Qt::yellow);
```

#### AUTO 


```{c}
auto sibling2 = sibling1.sibling(sibling1.row(), sibling1.column() - 1);
```

#### AUTO 


```{c}
auto foregroundColor = itemColor(index);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &i: splitItems) {
        model.appendRow(new QStandardItem(i));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QAbstractItemModel *model, QModelIndex where) -> QModelIndex {
        while (model->hasChildren(where)) {
            where = model->index(model->rowCount(where) - 1, 0, where);
        }
        return where;
    }
```

#### AUTO 


```{c}
auto fgLightnessF = viewOption.palette.color(QPalette::ColorGroup::Active, QPalette::HighlightedText).lightnessF();
```

#### AUTO 


```{c}
auto it = mailboxes.constBegin();
```

#### AUTO 


```{c}
auto newChildren = static_cast<const Message::AbstractMessage &>(*(it.value())).createTreeItems(message);
```

#### AUTO 


```{c}
auto it = mailboxes.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[this, model](const QModelIndex &idx) {
                if (idx == model->m_message) {
                    model->disconnect(model->m_insertRows);
                    Q_ASSERT(m_root.isValid());
                    m_childrenState = MessagePart::FetchingState::NONE;
                    model->beginInsertRows(QModelIndex(), 0, 0);
                    fetchChildren(model);
                    model->endInsertRows();
                }
            }
```

#### AUTO 


```{c}
auto *w = new OneEnvelopeAddress(this, addresses[i], messageView,
                                         i == addresses.size() - 1 ?
                                         OneEnvelopeAddress::Position::Last :
                                         OneEnvelopeAddress::Position::Middle);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &message) { m_errorMessage = message; }
```

#### AUTO 


```{c}
auto req1 = t.mk("UID FETCH 2:* (FLAGS)\r\n");
```

#### AUTO 


```{c}
auto item
```

#### LAMBDA EXPRESSION 


```{c}
[&messageUids](const GpgME::UserID &uid) {
        std::string email = uid.email();
        if (email.empty())
            return false;
        if (email[0] == '<' && email[email.size() - 1] == '>') {
            // this happens in the CMS, so let's kill the wrapping
            email = email.substr(1, email.size() - 2);
        }
        return std::find(messageUids.begin(), messageUids.end(), email) != messageUids.end();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const bool checked) {
            handleTag(checked, row - 1);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        m_ignoreStoredPassword = true;
    }
```

#### AUTO 


```{c}
auto end = m_flags.end();
```

#### AUTO 


```{c}
const auto dRecent = const_cast<QString&>(FlagNames::recent).data_ptr();
```

#### AUTO 


```{c}
const auto &kind
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::AddingWidget, QString(), Qt::green);
```

#### AUTO 


```{c}
auto keys = dummy.keys();
```

#### AUTO 


```{c}
auto a = pageAction(QWebPage::Copy);
```

#### AUTO 


```{c}
auto mappedMsg = msgModel.index(0,0);
```

#### AUTO 


```{c}
auto oldChildren = message->setChildren(newChildren);
```

#### AUTO 


```{c}
auto it = mapping.constBegin();
```

#### AUTO 


```{c}
auto it = qLowerBound(numbers.begin(), numbers.end(), num);
```

#### AUTO 


```{c}
auto resp1 = t.last("OK fetched\r\n");
```

#### AUTO 


```{c}
auto needle = std::find_if(uids.begin(), uids.end(), [&messageUids](const GpgME::UserID &uid) {
        std::string email = uid.email();
        if (email.empty())
            return false;
        if (email[0] == '<' && email[email.size() - 1] == '>') {
            // this happens in the CMS, so let's kill the wrapping
            email = email.substr(1, email.size() - 2);
        }
        return std::find(messageUids.begin(), messageUids.end(), email) != messageUids.end();
    });
```

#### AUTO 


```{c}
auto it = start1;
```

#### AUTO 


```{c}
const auto sentinel = const_cast<QString&>(needle).data_ptr();
```

#### AUTO 


```{c}
auto passwordPlugin = qobject_cast<PasswordPluginInterface *>(pluginInstance)
```

#### AUTO 


```{c}
auto idx_a_A = mm.index(0, 0, idx_a);
```

#### AUTO 


```{c}
const auto cmdStream = commands.split(QLatin1Char(' '));
```

#### AUTO 


```{c}
auto envelopeVariant = m_enclosingMessage.data(RoleMessageEnvelope);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &module: model->m_partHandlers) {
            part = module->createPart(model, this, std::move(part), childIndex, model->createIndex(this->row(), 0, this));
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        searchRequestedBy(m_widget);
    }
```

#### AUTO 


```{c}
auto it = parentMbox->m_children.begin();
```

#### AUTO 


```{c}
const auto &partId
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &, const QModelIndex &index) {
            expand(index);
        }
```

#### AUTO 


```{c}
auto key = ctx->key(sig.fingerprint(), keyError, false);
```

#### AUTO 


```{c}
auto part1 = rootMultipart.child(0, 0);
```

#### AUTO 


```{c}
auto mimeIdx = index.child(0, Imap::Mailbox::TreeItem::OFFSET_MIME);
```

#### AUTO 


```{c}
auto ellipsis = QStringLiteral("\u2026");
```

#### LAMBDA EXPRESSION 


```{c}
[&containsUnreadMessages](const TreeItemMessage &message) -> bool {
        return containsUnreadMessages = ! message.isMarkedAsRead();
    }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto pos = content.indexOf("\n");
```

#### AUTO 


```{c}
auto index = mailbox->toIndex(model);
```

#### AUTO 


```{c}
auto w = Gui::PasswordDialog::getPassword(this, tr("Authentication Required"),
                                              tr("<p>Please provide SMTP password for user <b>%1</b> on <b>%2</b>:</p>").arg(
                                                  user.toHtmlEscaped(),
                                                  host.toHtmlEscaped()));
```

#### AUTO 


```{c}
auto lbl = new QLabel(tr("<b>Mailing List:</b>&nbsp;%1").arg(buf.join(tr(", "))));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &e) { this->onCacheError(e); }
```

#### AUTO 


```{c}
auto lines = plaintext.split(QLatin1Char('\n'));
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &idx) {
        Q_ASSERT(!idx.data(Imap::Mailbox::RoleMessageIsMarkedRead).toBool());
        m_messageWidget->messageView->setMessage(idx);
        msgListWidget->tree->setCurrentIndex(idx);
    }
```

#### AUTO 


```{c}
auto box = new QMessageBox(icon, title, message, QMessageBox::Ok, parent);
```

#### AUTO 


```{c}
auto depthRunner(it);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &sig: verificationResult.signatures()) {
            wasSigned = true;
            extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                   sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

            // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
            break;
        }
```

#### AUTO 


```{c}
auto lbl = new QLabel(tr("<b>Subject:</b>&nbsp;%1").arg(e.subject.toHtmlEscaped()), this);
```

#### AUTO 


```{c}
auto childPtr = parentPart->child(const_cast<MessageModel *>(this), row, column);
```

#### RANGE FOR STATEMENT 


```{c}
for (QRegularExpression mailishRx : {mailishRx2, mailishRx1}) {
        QRegularExpressionMatch match = mailishRx.match(address, startOffset);
        int offset = match.capturedStart();
        if (match.hasMatch()) {
            QString before = address.mid(startOffset, offset - startOffset);
            into = MailAddress(before.simplified(), QString(), match.captured(1), match.captured(2));

            offset += match.capturedLength();

            startOffset = offset;
            return true;
        }
    }
```

#### AUTO 


```{c}
auto q1 = t.mk("LIST \"\" \"a.%\"\r\n");
```

#### AUTO 


```{c}
auto it = list->m_children.constBegin();
```

#### AUTO 


```{c}
auto composer = interactiveComposer()
```

#### AUTO 


```{c}
auto it = std::find_if(addresses.constBegin(), addresses.constEnd(),
                               std::bind2nd(Imap::Message::MailAddressesEqualByDomain(), identities[i]));
```

#### AUTO 


```{c}
auto buf = username.toUtf8().toBase64() + "\r\n";
```

#### AUTO 


```{c}
auto cutoff = now - 3 * 60 * 1000;
```

#### AUTO 


```{c}
auto domain = m_from.host.toUtf8();
```

#### AUTO 


```{c}
auto tldr = m_partIndex.data(RolePartCryptoTLDR);
```

#### AUTO 


```{c}
auto a = new QAction(UiUtils::loadIcon(QStringLiteral("edit-copy")), tr("Copy e-mail address"), menu.data());
```

#### AUTO 


```{c}
auto it = std::find_if(addresses.constBegin(), addresses.constEnd(),
                               std::bind2nd(Imap::Message::MailAddressesEqualByDomainSuffix(), identities[i]));
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { gotoNextInputLineFrom(edit); }
```

#### LAMBDA EXPRESSION 


```{c}
[&containsUnreadMessages](const TreeItemMessage &message) -> const bool {
        return containsUnreadMessages = ! message.isMarkedAsRead();
    }
```

#### AUTO 


```{c}
letsTrickyThreadingSearch(conditions, ordering, threading)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &x: features) {
        featuresText += x.second ?
                    tr("<li>%1: supported</li>").arg(x.first)
                  : tr("<li>%1: <strong>disabled</strong></li>").arg(x.first);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &what) {
        auto name = what.data(Imap::Mailbox::RoleMailboxName).toString();
        if (m_desiredExpansionState.remove(name)) {
            emit mailboxExpansionChanged(m_desiredExpansionState.toList());
        }
    }
```

#### AUTO 


```{c}
auto profileName = QString::fromUtf8(qgetenv("TROJITA_PROFILE"));
```

#### AUTO 


```{c}
const auto dRead = const_cast<QString&>(FlagNames::seen).data_ptr();
```

#### AUTO 


```{c}
FORWARD_METHOD(zoomOriginal)
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::AddingWidget, QString(), QLatin1String("lightgreen"));
```

#### AUTO 


```{c}
auto messageUids = extractMessageUids();
```

#### AUTO 


```{c}
auto cacheLog = new MonitoringCache(model);
```

#### AUTO 


```{c}
auto it = logs.find(parserId);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        tags->setTagList(message.data(Imap::Mailbox::RoleMessageFlags).toStringList());
    }
```

#### AUTO 


```{c}
auto item1 = new QStandardItem("a");
```

#### LAMBDA EXPRESSION 


```{c}
[subscribedOnly](const int acc, const QModelIndex &idx) {

            if (subscribedOnly && !idx.data(Imap::Mailbox::RoleMailboxIsSubscribed).toBool())
                return acc;

            auto x = idx.data(Imap::Mailbox::RoleUnreadMessageCount).toInt();
            if (x > 0) {
                return acc + x;
            } else {
                return acc;
            }
        }
```

#### AUTO 


```{c}
auto part = mailbox->partIdToPtr(model, static_cast<TreeItemMessage *>(message), partId);
```

#### LAMBDA EXPRESSION 


```{c}
[](const ItemFavoriteTagItem &tag, const QString &tag_name) {
        return tag.name == tag_name;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](EmbeddedWebView *w) {
        searchRequestedBy(w);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[d]() { emit d->gotPassword(d->ui.passwordLineEdit->text()); }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){ FavoriteTagsPage::moveTagBy(-1); }
```

#### AUTO 


```{c}
const auto &tagName = m_favoriteTags->tagNameByIndex(index);
```

#### AUTO 


```{c}
auto it = numbers.begin();
```

#### AUTO 


```{c}
auto optionA = std::find(args.constBegin(), args.constEnd(), QLatin1String("-a"));
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &recipient: combinedResult.first.recipients()) {
            GpgME::Error keyError;
            auto key = ctx->key(recipient.keyID(), keyError, false);
            if (keyError) {
                longStatus += LF + tr("Cannot extract recipient %1: %2")
                        .arg(QString::fromUtf8(recipient.keyID()), QString::fromUtf8(keyError.asString()));
            } else {
                if (key.numUserIDs()) {
                    longStatus += LF + tr("Encrypted to %1 (%2)")
                            .arg(QString::fromUtf8(key.userID(0).id()), QString::fromUtf8(recipient.keyID()));
                } else {
                    longStatus += LF + tr("Encrypted to %1").arg(QString::fromUtf8(recipient.keyID()));
                }
            }
        }
```

#### AUTO 


```{c}
auto domain = fromAddress.host.toUtf8();
```

#### AUTO 


```{c}
auto view = static_cast<MsgListView*>(parent());
```

#### DECLTYPE 


```{c}
decltype(threadingModel->threading) dummy;
```

#### AUTO 


```{c}
auto req2 = t.mk("UID FETCH 4:* (FLAGS)\r\n");
```

#### LAMBDA EXPRESSION 


```{c}
[subscribedOnly](const uint acc, const QModelIndex &idx) {

            if (subscribedOnly && !idx.data(Imap::Mailbox::RoleMailboxIsSubscribed).toBool())
                return acc;

            auto x = idx.data(Imap::Mailbox::RoleUnreadMessageCount).toInt();
            if (x > 0) {
                return acc + x;
            } else {
                return acc;
            }
        }
```

#### AUTO 


```{c}
auto part = Ptr(new ProxyMessagePart(this, row, childIndex, model));
```

#### LAMBDA EXPRESSION 


```{c}
[this, item](){
           const_cast<SimplePartWidget*>(this)->setColorScheme(item.first);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const mimetic::Mailbox &addr: list)
    {
        result.append(Imap::Message::MailAddress(
                          Imap::decodeRFC2047String(addr.label().data()),
                          QString::fromStdString(addr.sourceroute()),
                          QString::fromStdString(addr.mailbox()),
                          QString::fromStdString(addr.domain())));
    }
```

#### AUTO 


```{c}
auto nextSibling = m_current.sibling(m_current.row() + 1, 0);
```

#### AUTO 


```{c}
auto item2 = new QStandardItem("a.A");
```

#### AUTO 


```{c}
auto const state = model->accessParser(parser).connState;
```

#### AUTO 


```{c}
const auto bodyFldParam = sourceItemIndex.data(RolePartBodyFldParam).value<bodyFldParam_t>();
```

#### AUTO 


```{c}
auto parent = index.parent();
```

#### RANGE FOR STATEMENT 


```{c}
for (QRegExp mailishRx : {mailishRx2, mailishRx1}) {
        int offset = mailishRx.indexIn(address, startOffset);
        if (offset >= 0) {
            QString before = address.mid(startOffset, offset - startOffset);
            into = MailAddress(before.simplified(), QString(), mailishRx.cap(1), mailishRx.cap(2));

            offset += mailishRx.matchedLength();

            startOffset = offset;
            return true;
        }
    }
```

#### AUTO 


```{c}
auto addr = Imap::Message::MailAddress::fromNameAndMail(QString(), from);
```

#### LAMBDA EXPRESSION 


```{c}
[&currentItem, cmdStream, &i, &foundValues, &expectedValues](const QModelIndex &idx) {
            currentItem = idx;
            foundValues.push_back(idx.data().toString());
            expectedValues.push_back(cmdStream[i] + "_");
            QCOMPARE(foundValues, expectedValues);
        }
```

#### AUTO 


```{c}
auto cutoff = now - 3 * 60;
```

#### LAMBDA EXPRESSION 


```{c}
[]() {
        // nothing to do
    }
```

#### AUTO 


```{c}
auto d = new PasswordDialog(parent);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QByteArray &x) {return QString::fromUtf8(x);}
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &oneAddr : index.data(kind).toList()) {
            Q_ASSERT(oneAddr.type() == QVariant::StringList);
            QStringList item = oneAddr.toStringList();
            Q_ASSERT(item.size() == 4);
            Imap::Message::MailAddress a(item[0], item[1], item[2], item[3]);
            Composer::RecipientKind translatedKind = Composer::RecipientKind::ADDRESS_TO;
            switch (kind) {
            case Imap::Mailbox::RoleMessageTo:
                translatedKind = Composer::RecipientKind::ADDRESS_RESENT_TO;
                break;
            case Imap::Mailbox::RoleMessageCc:
                translatedKind = Composer::RecipientKind::ADDRESS_RESENT_CC;
                break;
            case Imap::Mailbox::RoleMessageBcc:
                translatedKind = Composer::RecipientKind::ADDRESS_RESENT_BCC;
                break;
            default:
                Q_ASSERT(false);
                break;
            }
            recipients.push_back({translatedKind, a.asPrettyString()});
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex &topLeft){
            if (topLeft.data(Imap::Mailbox::RoleIsFetched).toBool()) {
                // OK, message is fully fetched now
                showMessageNow();
            }
        }
```

#### AUTO 


```{c}
auto it = logs.find(connectionId);
```

#### AUTO 


```{c}
auto it = items.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QString &link) {
        if (!ui->lineEdit->text().isEmpty())
            ui->lineEdit->setText(ui->lineEdit->text() + QStringLiteral(" "));
        ui->lineEdit->setText(ui->lineEdit->text() + link);
    }
```

#### AUTO 


```{c}
auto sibling1 = msg9.sibling(msg9.row(), msg9.column() + 1);
```

#### AUTO 


```{c}
auto it = end;
```

#### AUTO 


```{c}
letsThreadingSearch(conditions, ordering, threading)
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &module: m_pluginManager->mimePartReplacers()) {
        messageModel->registerPartHandler(module);
    }
```

#### AUTO 


```{c}
auto matcher = [](const QModelIndex &idx) { return idx.data().toString().contains(QLatin1Char('_')); };
```

#### AUTO 


```{c}
auto part4 = rootMultipart.child(3, 0);
```

#### AUTO 


```{c}
auto lbl = new QLabel(tr("<b>This message appears to be malformed, please be careful before sending it.</b>")
                              + QStringLiteral("<ul><li>") + warnings.join(QStringLiteral("</li><li>")) + QStringLiteral("</li></ul>"),
                              w);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const Plugins::PasswordJob::Error error, const QString &message) {
                if (error == Plugins::PasswordJob::Error::NoSuchPassword) {
                    authenticationContinue(QString());
                } else {
                    authenticationContinue(QString(), tr("Failed to retrieve password from the store: %1").arg(message));
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(Recipient recipient : m_recipients) {
        if (wFound) {
            recipient.second->setFocus();
            return;
        }
        if (recipient.second == w)
            wFound = true;
    }
```

#### AUTO 


```{c}
auto w = MainWindow::messageSourceWidget(m_partIndex);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &recipient: combinedResult.first.recipients()) {
            GpgME::Error keyError;
            auto key = ctx->key(recipient.keyID(), keyError, false);
            if (keyError) {
                ENSURE_LINE_LF(longStatus);
                longStatus += tr("Cannot extract recipient %1: %2")
                        .arg(QString::fromUtf8(recipient.keyID()), QString::fromUtf8(keyError.asString()));
            } else {
                if (key.numUserIDs()) {
                    ENSURE_LINE_LF(longStatus);
                    longStatus += tr("Encrypted to %1 (%2)")
                            .arg(QString::fromUtf8(key.userID(0).id()), QString::fromUtf8(recipient.keyID()));
                } else {
                    ENSURE_LINE_LF(longStatus);
                    longStatus += tr("Encrypted to %1").arg(QString::fromUtf8(recipient.keyID()));
                }
            }
        }
```

#### AUTO 


```{c}
auto topLeftIt = m_map.constFind(topLeft);
```

#### AUTO 


```{c}
const auto envelope = envelopeVariant.value<Imap::Message::Envelope>();
```

#### AUTO 


```{c}
auto composer = std::make_shared<Composer::ExistingMessageComposer>(messageRoot);
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { ui->mailText->setFocus(); }
```

#### AUTO 


```{c}
const auto & messageParts = mailboxParts[uid];
```

#### AUTO 


```{c}
auto nm = new Imap::Mailbox::DummyNetworkWatcher(nullptr, model);
```

#### AUTO 


```{c}
auto uids = LowLevelParser::getSequence(line, start);
```

#### AUTO 


```{c}
auto succeed = searchSortPreferenceImplementation(searchConditions, criterium, order);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &link) {
        // Trojita is registered to handle any mailto: URL
        QDesktopServices::openUrl(QUrl(link));
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&messageUids](const GpgME::UserID &uid) {
        return std::find(messageUids.begin(), messageUids.end(), uid.email()) != messageUids.end();
    }
```

#### AUTO 


```{c}
auto oldState = model->cache()->mailboxSyncState(("a"));
```

#### AUTO 


```{c}
auto key = ctx->key(recipient.keyID(), keyError, false);
```

#### AUTO 


```{c}
const auto &uids = key.userIDs();
```

#### LAMBDA EXPRESSION 


```{c}
[this, ctx, cipherData, messageUids ](){
        QPointer<QObject> p(this);

        GpgME::Data encData(cipherData.data(), cipherData.size(), false);
        QGpgME::QByteArrayDataProvider dp;
        GpgME::Data plaintextData(&dp);

        auto combinedResult = ctx->decryptAndVerify(encData, plaintextData);

        bool wasSigned = false;
        bool wasEncrypted = true;
        bool sigOkDisregardingTrust = false;
        bool sigValidVerified = false;
        bool uidMatched = false;
        QString tldr;
        QString longStatus;
        QString icon;
        QString signer;
        QDateTime signDate;

        if (combinedResult.second.numSignatures() != 0) {
            for (const auto &sig: combinedResult.second.signatures()) {
                wasSigned = true;
                extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                       sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

                // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
                break;
            }
        }

        constexpr QChar LF = QLatin1Char('\n');

        bool decryptedOk = !combinedResult.first.error();

        if (!decryptedOk) {
            if (tldr.isEmpty()) {
                tldr = tr("Broken encrypted message");
            }
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Decryption error: %1").arg(QString::fromUtf8(combinedResult.first.error().asString()));
            icon = QStringLiteral("emblem-error");
        } else if (tldr.isEmpty()) {
            tldr = tr("Encrypted message");
            icon = QStringLiteral("emblem-encrypted-unlocked");
        }

        if (combinedResult.first.isWrongKeyUsage()) {
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Wrong key usage, not for encryption");
        }
        if (auto msg = combinedResult.first.unsupportedAlgorithm()) {
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Unsupported algorithm: %1").arg(QString::fromUtf8(msg));
        }

        for (const auto &recipient: combinedResult.first.recipients()) {
            GpgME::Error keyError;
            auto key = ctx->key(recipient.keyID(), keyError, false);
            if (keyError) {
                ENSURE_LINE_LF(longStatus);
                longStatus += tr("Cannot extract recipient %1: %2")
                        .arg(QString::fromUtf8(recipient.keyID()), QString::fromUtf8(keyError.asString()));
            } else {
                if (key.numUserIDs()) {
                    ENSURE_LINE_LF(longStatus);
                    longStatus += tr("Encrypted to %1 (%2)")
                            .arg(QString::fromUtf8(key.userID(0).id()), QString::fromUtf8(recipient.keyID()));
                } else {
                    ENSURE_LINE_LF(longStatus);
                    longStatus += tr("Encrypted to %1").arg(QString::fromUtf8(recipient.keyID()));
                }
            }
        }
        if (auto fname = combinedResult.first.fileName()) {
            ENSURE_LINE_LF(longStatus);
            longStatus += tr("Original filename: %1").arg(QString::fromUtf8(fname));
        }

        if (p) {
            bool ok = QMetaObject::invokeMethod(p, "processDecryptedData", Qt::QueuedConnection,
                                                Q_ARG(bool, decryptedOk),
                                                Q_ARG(QByteArray, dp.data()));
            Q_ASSERT(ok); Q_UNUSED(ok);
        } else {
            qDebug() << "[async crypto: GpgMeEncrypted is gone, not sending cleartext data]";
        }
        submitVerifyResult(p, {wasSigned, sigOkDisregardingTrust, sigValidVerified, tldr, longStatus, icon, signer, signDate});
    }
```

#### AUTO 


```{c}
auto c2 = t.mk("LIST \"\" \"%\"\r\n");
```

#### AUTO 


```{c}
auto req1 = t.mk("UID FETCH 4:* (FLAGS)\r\n");
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx) { return !idx.data(Imap::Mailbox::RoleMessageIsMarkedRead).toBool(); }
```

#### AUTO 


```{c}
auto it = part->m_children.find(partToReplace->row());
```

#### AUTO 


```{c}
auto reverse = Common::stashing_reverse_iterator<decltype(it)>(it);
```

#### AUTO 


```{c}
auto conf = m_session->configuration();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &module: m_pluginManager->mimePartReplacers()) {
            messageModel->registerPartHandler(module);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const mimetic::MimeEntity* child: me.body().parts()) {
            part->setChild(i, mimeEntityToPart(*child, part.get(), i));
            ++i;
        }
```

#### AUTO 


```{c}
auto bHost = b.host.toLower();
```

#### AUTO 


```{c}
const auto urls = data->urls();
```

#### AUTO 


```{c}
auto oneMail = Composer::extractOneMailAddress(linkUrl);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &conn: m_waitingMessageConns) {
        disconnect(conn);
    }
```

#### AUTO 


```{c}
const auto x
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &mailbox: m_desiredExpansionState) {
            m_mailboxFinder->addMailbox(mailbox);
        }
```

#### AUTO 


```{c}
auto msg = combinedResult.first.unsupportedAlgorithm()
```

#### AUTO 


```{c}
auto zoomOriginal = zoomMenu->addAction(UiUtils::loadIcon(QStringLiteral("zoom-original")), tr("Original Size"));
```

#### AUTO 


```{c}
auto tagName = m_favoriteTags->tagNameByIndex(i);
```

#### AUTO 


```{c}
auto enableId = settings->value(obsImapEnableId);
```

#### AUTO 


```{c}
auto part = MimeticUtils::mimeEntityToPart(mimetic::MimeEntity(data.begin(), data.end()), this, row());
```

#### AUTO 


```{c}
auto content = f.readAll();
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::UserKeyword, tagName, QStringLiteral("lightyellow"));
```

#### LAMBDA EXPRESSION 


```{c}
[&](QStandardItem *i) {
                if (i == m_currentContact) {
                    m_ui2->name->setText(i->text());
                    m_dirty = true;
                }
            }
```

#### AUTO 


```{c}
auto combinedResult = ctx->decryptAndVerify(encData, plaintextData);
```

#### AUTO 


```{c}
auto rawPartData = QByteArray(me.body().data(), me.body().size());
```

#### AUTO 


```{c}
auto pluginDir = QStringLiteral(PLUGIN_DIR);
```

#### LAMBDA EXPRESSION 


```{c}
[this](TreeItemPart *part, const QByteArray &partId, const uint uid) {
                handleUnknownCTE(part, partId, uid);
            }
```

#### AUTO 


```{c}
letsThreadingSearchUpdate(conditions, ordering, threading)
```

#### AUTO 


```{c}
const auto rowCount = sourceItemIndex.model()->rowCount(sourceItemIndex);
```

#### AUTO 


```{c}
auto *asReplyMenu = new QMenu(m_markButton);
```

#### AUTO 


```{c}
auto now = QDateTime::currentDateTime().toTime_t();
```

#### AUTO 


```{c}
auto it = lineBuffer.begin();
```

#### AUTO 


```{c}
auto spellcheckerPlugin = qobject_cast<SpellcheckerPluginInterface *>(pluginInstance)
```

#### AUTO 


```{c}
auto fname = combinedResult.first.fileName()
```

#### AUTO 


```{c}
auto next = it + 1;
```

#### AUTO 


```{c}
auto q2 = t.mk("LIST \"\" \"a.A.%\"\r\n");
```

#### AUTO 


```{c}
auto prev = it - 1;
```

#### AUTO 


```{c}
auto it = iconDict.constFind(name);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &url) {
        if (url.isEmpty()) {
            QToolTip::hideText();
        } else {
            // indirection due to https://bugs.kde.org/show_bug.cgi?id=363783
            QTimer::singleShot(250, [url]() {
                QToolTip::showText(QCursor::pos(), QObject::tr("Link target: %1").arg(UiUtils::Formatting::htmlEscaped(url)));
            });
        }
    }
```

#### AUTO 


```{c}
const auto cte = partCTE(index);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &e) { this->m_errorHandler(e); }
```

#### AUTO 


```{c}
const auto bodyFldParam = anotherPart.data(Imap::Mailbox::RolePartBodyFldParam).value<bodyFldParam_t>();
```

#### AUTO 


```{c}
auto lbl = new QLabel(subDate, this);
```

#### AUTO 


```{c}
auto storeSenderUid = [&messageUids](const Imap::Message::MailAddress &identity) {
                messageUids.emplace_back(identity.asSMTPMailbox().data());
            };
```

#### AUTO 


```{c}
auto it = UiUtils::QaimDfsIterator(currentIndex, model);
```

#### AUTO 


```{c}
auto cache = std::make_shared<Imap::Mailbox::MemoryCache>();
```

#### AUTO 


```{c}
auto color = m_favoriteTagsModel->findBestColorForTags(messageFlags.toStringList());
```

#### AUTO 


```{c}
auto message
```

#### RANGE FOR STATEMENT 


```{c}
for(const QString &addr: recipients) {
        w->addRecipient(0, Composer::ADDRESS_TO, addr);
    }
```

#### AUTO 


```{c}
auto it = begin;
```

#### AUTO 


```{c}
auto *part = translatePtr(parent);
```

#### AUTO 


```{c}
auto overrideIcon = QStringLiteral(":/icons/%1/%2.svg").arg(QIcon::themeName(), name);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto plugin: m_availableAddressbookPlugins) {
        res[plugin->name()] = plugin->description();
    }
```

#### AUTO 


```{c}
auto needle = std::find_if(uids.begin(), uids.end(), [&messageUids](const GpgME::UserID &uid) {
        return std::find(messageUids.begin(), messageUids.end(), uid.email()) != messageUids.end();
    });
```

#### AUTO 


```{c}
auto res = TreeItem::setChildren(items);
```

#### AUTO 


```{c}
auto plugin = m_availablePasswordPlugins.find(name);
```

#### AUTO 


```{c}
const auto &x
```

#### AUTO 


```{c}
auto spellchecker = m_mainWindow->pluginManager()->spellchecker()
```

#### AUTO 


```{c}
auto oldState = m_localState;
```

#### AUTO 


```{c}
auto mimeType = sourceItemIndex.data(Imap::Mailbox::RolePartMimeType).toByteArray();
```

#### AUTO 


```{c}
auto positiveAction = [&currentItem, cmdStream, &i, &foundValues, &expectedValues](const QModelIndex &idx) {
            currentItem = idx;
            foundValues.push_back(idx.data().toString());
            expectedValues.push_back(cmdStream[i] + "_");
            QCOMPARE(foundValues, expectedValues);
        };
```

#### RANGE FOR STATEMENT 


```{c}
for (const mimetic::Address &addr: list)
    {
        if (addr.isGroup()) {
            const mimetic::Group group = addr.group();
            for (mimetic::Group::const_iterator it = group.begin(), end = group.end(); it != end; it++) {
                const mimetic::Mailbox mb = *it;
                result.append(Imap::Message::MailAddress(
                                  Imap::decodeRFC2047String(mb.label().data()),
                                  QString::fromStdString(mb.sourceroute()),
                                  QString::fromStdString(mb.mailbox()),
                                  QString::fromStdString(mb.domain())));
            }
        } else {
            const mimetic::Mailbox mb = addr.mailbox();
            result.append(Imap::Message::MailAddress(
                              Imap::decodeRFC2047String(mb.label().data()),
                              QString::fromStdString(mb.sourceroute()),
                              QString::fromStdString(mb.mailbox()),
                              QString::fromStdString(mb.domain())));
        }
    }
```

#### AUTO 


```{c}
auto it = model->m_parsers.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[&aggregatedFlags](const TreeItemMessage &message) {
        aggregatedFlags += message.m_flags;
    }
```

#### AUTO 


```{c}
auto it = std::lower_bound(numbers.begin(), numbers.end(), num);
```

#### AUTO 


```{c}
auto buf = SOCK->writtenStuff();
```

#### AUTO 


```{c}
auto roughlyLastKnown = const_cast<Model*>(realModel)->findMessageOrNextOneByUid(list, highestUidInThreadingLowerBound);
```

#### LAMBDA EXPRESSION 


```{c}
[](const mimetic::Field &f) {
                     return QByteArray(f.name().c_str()).toLower() == QByteArrayLiteral("content-type");
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &idx) { return idx.isValid(); }
```

#### AUTO 


```{c}
auto it = m_orphans.begin();
```

#### AUTO 


```{c}
FORWARD_METHOD(zoomOut)
```

#### AUTO 


```{c}
auto it = std::find_if(addresses.constBegin(), addresses.constEnd(),
                               std::bind2nd(Imap::Message::MailAddressesEqualByMail(), identities[i]));
```

#### AUTO 


```{c}
auto res = new TagWidget(Mode::UserKeyword, tagName, QLatin1String("lightyellow"));
```

#### AUTO 


```{c}
auto c1 = t.mk("LIST \"\" \"%\"\r\n");
```

#### AUTO 


```{c}
auto keep = dynamic_cast<KeepMailboxOpenTask *>(task)
```

#### AUTO 


```{c}
auto watchingMode = settings()->value(Common::SettingsNames::watchedFoldersKey).toString();
```

#### AUTO 


```{c}
auto mimeType = index.data(RolePartMimeType).toString();
```

#### AUTO 


```{c}
auto bgLightnessF = viewOption.palette.color(QPalette::ColorGroup::Active, QPalette::Highlight).lightnessF();
```

#### AUTO 


```{c}
auto resp2 = t.last("OK fetched\r\n");
```

#### AUTO 


```{c}
auto name = what.data(Imap::Mailbox::RoleMailboxName).toString();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &module: model->m_partHandlers) {
            part = module->createPart(this, std::move(part), childIndex, model->createIndex(this->row(), 0, this));
        }
```

#### AUTO 


```{c}
const auto &module
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &item: me.header().contentType().paramList()) {
        bodyFldParam[QByteArray(item.name().c_str()).toUpper()] = QByteArray(item.value().c_str());
    }
```

#### AUTO 


```{c}
auto previousSibling = m_current.sibling(m_current.row() - 1, 0);
```

#### AUTO 


```{c}
auto it = items.constBegin();
```

#### LAMBDA EXPRESSION 


```{c}
[&currentItem, cmdStream, &i, &foundValues, &expectedValues]() {
            if (currentItem.isValid()) {
                // ensure we haven't moved
                foundValues.push_back(currentItem.data().toString());
                expectedValues.push_back(cmdStream[i] + "_");
            } else {
                // current index should be invalid
                foundValues.push_back("-1");
                expectedValues.push_back(cmdStream[i]);
            };
            QCOMPARE(foundValues, expectedValues);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[](TreeItem *item) {
        return static_cast<TreeItemMessage *>(item)->uid();
    }
```

#### AUTO 


```{c}
auto numDeletes = num / 2;
```

#### AUTO 


```{c}
auto it = iconDict()->constFind(name);
```

#### AUTO 


```{c}
auto method = bodyFldParam[QByteArray("METHOD")].toUpper();
```

#### AUTO 


```{c}
auto emb = qobject_cast<EmbeddedWebView *>(m_associatedWebView);
```

#### LAMBDA EXPRESSION 


```{c}
[](std::future<void> &task){
            if (task.wait_for(std::chrono::duration_values<std::chrono::seconds>::zero()) == std::future_status::timeout) {
                qDebug() << " [waiting]";
                task.get();
            } else {
                qDebug() << " [already completed]";
            }
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, ctx, rawData, signatureData, messageUids, wasEncrypted](){
        QPointer<QObject> p(this);
        DebugProgress progress;
        ctx->setProgressProvider(&progress);

        GpgME::Data sigData(signatureData.data(), signatureData.size(), false);
        GpgME::Data msgData(rawData.data(), rawData.size(), false);

        auto verificationResult = ctx->verifyDetachedSignature(sigData, msgData);
        bool wasSigned = false;
        bool sigOkDisregardingTrust = false;
        bool sigValidVerified = false;
        bool uidMatched = false;
        QString tldr;
        QString longStatus;
        QString icon;
        QString signer;
        QDateTime signDate;

        if (verificationResult.numSignatures() == 0) {
            tldr = tr("No signatures in the signed message");
            icon = QStringLiteral("script-error");
        }

        for (const auto &sig: verificationResult.signatures()) {
            wasSigned = true;
            extractSignatureStatus(ctx, sig, messageUids, wasSigned, wasEncrypted,
                                   sigOkDisregardingTrust, sigValidVerified, uidMatched, tldr, longStatus, icon, signer, signDate);

            // FIXME: add support for multiple signatures at once. How do we want to handle them in the UI?
            break;
        }
        submitVerifyResult(p, {wasSigned, sigOkDisregardingTrust, sigValidVerified, tldr, longStatus, icon, signer, signDate});
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
        QMessageBox::warning(this, tr("Plugin Error"),
                             //: The %1 placeholder is a full error message as provided by Qt, ready for human consumption.
                             trUtf8("A plugin failed to load, therefore some functionality might be lost. "
                                    "You might want to update your system or report a bug to your vendor."
                                    "\n\n%1").arg(errorMessage));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &kind: {Imap::Mailbox::RoleMessageTo, Imap::Mailbox::RoleMessageCc, Imap::Mailbox::RoleMessageBcc}) {
        for (const auto &oneAddr : index.data(kind).toList()) {
            Q_ASSERT(oneAddr.type() == QVariant::StringList);
            QStringList item = oneAddr.toStringList();
            Q_ASSERT(item.size() == 4);
            Imap::Message::MailAddress a(item[0], item[1], item[2], item[3]);
            Composer::RecipientKind translatedKind = Composer::RecipientKind::ADDRESS_TO;
            switch (kind) {
            case Imap::Mailbox::RoleMessageTo:
                translatedKind = Composer::RecipientKind::ADDRESS_RESENT_TO;
                break;
            case Imap::Mailbox::RoleMessageCc:
                translatedKind = Composer::RecipientKind::ADDRESS_RESENT_CC;
                break;
            case Imap::Mailbox::RoleMessageBcc:
                translatedKind = Composer::RecipientKind::ADDRESS_RESENT_BCC;
                break;
            default:
                Q_ASSERT(false);
                break;
            }
            recipients.push_back({translatedKind, a.asPrettyString()});
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QStringList &mailboxNames) {
        m_settings->setValue(Common::SettingsNames::guiExpandedMailboxes, mailboxNames);
    }
```

#### AUTO 


```{c}
const auto &i
```

#### AUTO 


```{c}
auto oldUidMap = model->cache()->uidMapping(QStringLiteral("a"));
```

#### RANGE FOR STATEMENT 


```{c}
for (bool forward : {true,false}) {
        QModelIndex walker = forward ? indexBelow(current) : indexAbove(current);
        while (walker.isValid()) {
            // Queued for pruning..?
            if (prettyModel->data(walker, Imap::Mailbox::RoleMessageUid).isValid()) {
                // Do not activate, just keep the cursor in place.
                selectionModel()->setCurrentIndex(walker, QItemSelectionModel::NoUpdate);
                // It has won. For now.
                return;
            }
            walker = forward ? indexBelow(walker) : indexAbove(walker);
        }
    }
```

#### AUTO 


```{c}
auto bottomRightIt = m_map.constFind(bottomRight);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &what) -> QString {
            return what.data().toString();
        }
```

#### AUTO 


```{c}
auto processRcptHeader = [&buf](const QByteArray &prefix, const QList<QByteArray> &recipients) {
        if (recipients.empty())
            return;
        buf += prefix + ": ";
        for (int i = 0; i < recipients.size() - 1; ++i)
            buf += recipients[i] + ",\r\n ";
        buf += recipients.last() + "\r\n";
    };
```

#### AUTO 


```{c}
const auto zoomConstant = 1.1;
```

#### AUTO 


```{c}
auto rejectedResult = end1;
```

#### AUTO 


```{c}
auto oldUidMap = model->cache()->uidMapping(QLatin1String("a"));
```

#### LAMBDA EXPRESSION 


```{c}
[](const QModelIndex &what) -> QString {
        return what.data().toString();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        QGuiApplication::clipboard()->setText(m_copyMail->data().toString());
    }
```

#### AUTO 


```{c}
auto envelopeVariant = index.data(RoleMessageEnvelope);
```

#### AUTO 


```{c}
auto signatureData = m_signaturePart.data(RolePartData).toByteArray();
```

#### AUTO 


```{c}
auto password = qobject_cast<const Imap::Mailbox::Model*>(m_mainWindow->imapAccess()->imapModel())->imapPassword();
```

#### AUTO 


```{c}
auto r2 = t.last("OK listed, nothing like that in there\r\n");
```

#### AUTO 


```{c}
auto job = addressbook->requestPrettyNamesForAddress(m_address.mailbox + QLatin1Char('@') + m_address.host);
```

#### AUTO 


```{c}
auto now = QDateTime::currentMSecsSinceEpoch();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &kind: {Imap::Mailbox::RoleMessageTo, Imap::Mailbox::RoleMessageCc, Imap::Mailbox::RoleMessageBcc}) {
        for (const auto &oneAddr : index.data(kind).toList()) {
            Q_ASSERT(oneAddr.type() == QVariant::StringList);
            QStringList item = oneAddr.toStringList();
            Q_ASSERT(item.size() == 4);
            Imap::Message::MailAddress a(item[0], item[1], item[2], item[3]);
            recipients.push_back(a.asPrettyString());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &oneAddr : index.data(kind).toList()) {
            Q_ASSERT(oneAddr.type() == QVariant::StringList);
            QStringList item = oneAddr.toStringList();
            Q_ASSERT(item.size() == 4);
            Imap::Message::MailAddress a(item[0], item[1], item[2], item[3]);
            recipients.push_back(a.asPrettyString());
        }
```

#### AUTO 


```{c}
auto buf = cont.toUtf8();
```

#### AUTO 


```{c}
auto lbl = new QLabel(QString(QLatin1String("<html>&nbsp;%1</html>")).arg(buf.join(tr(", "))));
```

#### AUTO 


```{c}
auto idx = m_proxyParentIndex.child(m_row, 0);
```

#### AUTO 


```{c}
auto it = m_model->m_map.begin();
```

#### AUTO 


```{c}
auto linkUrl = page()->mainFrame()->hitTestContent(point).linkUrl();
```

#### AUTO 


```{c}
auto part2 = rootMultipart.child(1, 0);
```

#### AUTO 


```{c}
auto threadTask = realModel->m_taskFactory->
                    createIncrementalThreadTask(const_cast<Model *>(realModel), mailboxIndex, requestedAlgorithm,
                                                                    QStringList() << QStringLiteral("INTHREAD") << QString::fromUtf8(requestedAlgorithm) << QStringLiteral("UID") <<
                                                                        QString::fromUtf8(Sequence::startingAt(firstUnknownUid).toByteArray()));
```

#### AUTO 


```{c}
auto msg = UiUtils::Formatting::sslErrorsToHtml(errors);
```

#### AUTO 


```{c}
auto state = cache()->mailboxSyncState(mailbox->mailbox());
```

#### AUTO 


```{c}
auto viewer = factory->walk(rootPartIndex.child(0,0), 0, loadingMode);
```

#### AUTO 


```{c}
const auto messages = model->findMessagesByUids(mailbox, uids);
```

#### AUTO 


```{c}
auto headerIdx = index.child(0, Imap::Mailbox::TreeItem::OFFSET_HEADER);
```

#### LAMBDA EXPRESSION 


```{c}
[](){
        iconDict.clear();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](){
        emit textEditingFinished(this->text());
    }
```

#### AUTO 


```{c}
auto mimeType = sourceItemIndex.data(RolePartMimeType).toByteArray();
```

#### LAMBDA EXPRESSION 


```{c}
[](const Imap::Mailbox::ParserState & state) {
        return state.connState != CONN_STATE_LOGOUT && state.connState >= CONN_STATE_AUTHENTICATED;
    }
```

#### AUTO 


```{c}
auto negativeAction = [&currentItem, cmdStream, &i, &foundValues, &expectedValues]() {
            if (currentItem.isValid()) {
                // ensure we haven't moved
                foundValues.push_back(currentItem.data().toString());
                expectedValues.push_back(cmdStream[i] + "_");
            } else {
                // current index should be invalid
                foundValues.push_back("-1");
                expectedValues.push_back(cmdStream[i]);
            };
            QCOMPARE(foundValues, expectedValues);
        };
```

#### AUTO 


```{c}
auto parentCert = key;
```

#### AUTO 


```{c}
const auto &mailbox
```

#### AUTO 


```{c}
auto it = requestedParts.begin();
```

#### LAMBDA EXPRESSION 


```{c}
[archiveFolderName](const QModelIndex &i) {
        return i.data(Imap::Mailbox::RoleMailboxName) != archiveFolderName;
    }
```

#### AUTO 


```{c}
auto idx_a = mm.index(0, 0, QModelIndex());
```

#### AUTO 


```{c}
auto oldIndexes = persistentIndexList();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &task: m_orphans) {
            if (is_running(task)) {
                qDebug() << " [waiting]";
                task.get();
            } else {
                qDebug() << " [already completed]";
            }
        }
```

#### AUTO 


```{c}
auto recipients = QList<QString>();
```

#### AUTO 


```{c}
auto resetWatchedMailboxes = [&finder]() {
        finder.addMailbox(QStringLiteral("a"));
        finder.addMailbox(QStringLiteral("a.A"));
        finder.addMailbox(QStringLiteral("a.A.1"));
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QByteArray& data) {
        emit logged(Common::LogKind::LOG_IO_WRITTEN, QStringLiteral("SMTP"), QString::fromUtf8(data));
    }
```

#### AUTO 


```{c}
auto copyMoveMessagesTask = imapModel()->copyMoveMessages(
            archiveFolderName.isEmpty() ? Common::SettingsNames::imapDefaultArchiveFolderName : archiveFolderName,
            translatedIndexes, Imap::Mailbox::CopyMoveOperation::MOVE);
```

#### RANGE FOR STATEMENT 


```{c}
for (QObject *obj : children) {
        AbstractPartWidget *w = dynamic_cast<AbstractPartWidget *>(obj);
        if (w && w->searchDialogRequested())
            return true;
    }
```

#### AUTO 


```{c}
auto plugin = m_availableSpellchckePlugins.find(name);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &errorMessage) {
        Gui::Util::messageBoxWarning(this, tr("Plugin Error"),
                                     //: The %1 placeholder is a full error message as provided by Qt, ready for human consumption.
                                     tr("A plugin failed to load, therefore some functionality might be lost. "
                                            "You might want to update your system or report a bug to your vendor."
                                            "\n\n%1").arg(errorMessage));
    }
```

#### AUTO 


```{c}
auto it = list->m_children.end();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const int timeout) {
            showStatusMessage(tr("Attempting to reconnect in %n seconds..", 0, timeout/1000));
            }
```

#### AUTO 


```{c}
FORWARD_METHOD(zoomIn)
```

#### AUTO 


```{c}
const auto contacts = searchJob->contacts();
```

#### AUTO 


```{c}
auto addTagAction = [=](int row) {
        QAction *tag = ShortcutHandler::instance()->createAction(QStringLiteral("action_tag_").append(QString::number(row)), this);
        tag->setCheckable(true);
        msgListWidget->tree->addAction(tag);
        connect(tag, &QAction::triggered, this, [=](const bool checked) {
            handleTag(checked, row - 1);
        });
        return tag;
    };
```

#### AUTO 


```{c}
auto msgList = dynamic_cast<TreeItemMsgList *>(static_cast<TreeItem *>(index.internalPointer()));
```

#### AUTO 


```{c}
auto storeSenderUid = [&messageUids](const Imap::Message::MailAddress &identity) {
        messageUids.emplace_back(identity.asSMTPMailbox().data());
    };
```

#### AUTO 


```{c}
auto aMailboxPtr = dynamic_cast<TreeItemMailbox *>(Model::realTreeItem(idxA));
```

#### AUTO 


```{c}
auto oldSyncState = cache()->mailboxSyncState(mailbox);
```

#### LAMBDA EXPRESSION 


```{c}
[&](QStandardItem *i) { if (i == m_currentContact) m_ui2->name->setText(i->text()); }
```

#### AUTO 


```{c}
auto digit = *c_str - '0';
```

#### AUTO 


```{c}
auto model = qobject_cast<const Cryptography::MessageModel *>(partIndex.model());
```

#### AUTO 


```{c}
auto it = l.begin();
```

#### AUTO 


```{c}
auto plugin = m_availableAddressbookPlugins.find(name);
```

#### LAMBDA EXPRESSION 


```{c}
[this, model](const QModelIndex &idx) {
                if (idx == model->m_message) {
                    model->disconnect(model->m_insertRows);
                    if (!m_root.isValid()) {
                        return;
                    }
                    Q_ASSERT(m_root.isValid());
                    m_childrenState = MessagePart::FetchingState::NONE;
                    model->beginInsertRows(QModelIndex(), 0, 0);
                    fetchChildren(model);
                    model->endInsertRows();
                }
            }
```

#### AUTO 


```{c}
auto dialog = PasswordDialog::getPassword(this, tr("Authentication Required"),
                                                  tr("<p>Please provide IMAP password for user <b>%1</b> on <b>%2</b>:</p>").arg(
                                                      user.toHtmlEscaped(),
                                                      m_settings->value(Common::SettingsNames::imapHostKey).toString().toHtmlEscaped()
                                                      ),
                                                  errorMessage + (errorMessage.isEmpty() ? QString() : QStringLiteral("\n\n"))
                                                  + imapModel()->imapAuthError());
```

#### AUTO 


```{c}
auto it = list->m_children.begin() + offset;
```

#### AUTO 


```{c}
const auto conf = m_netConfManager->defaultConfiguration();
```

#### AUTO 


```{c}
auto r1 = t.last("OK listed, nothing like that in there\r\n");
```

#### AUTO 


```{c}
auto verificationResult = ctx->verifyDetachedSignature(sigData, msgData);
```

#### LAMBDA EXPRESSION 


```{c}
[](const QString &url) {
        if (url.isEmpty()) {
            QToolTip::hideText();
        } else {
            QToolTip::showText(QCursor::pos(), QObject::tr("Link target: %1").arg(UiUtils::Formatting::htmlEscaped(url)));
        }
    }
```

#### AUTO 


```{c}
auto req2 = t.mk("UID FETCH 2:* (FLAGS)\r\n");
```

#### AUTO 


```{c}
auto task = m_taskFactory->createCreateMailboxTask(this, name);
```

#### AUTO 


```{c}
auto &conn
```

