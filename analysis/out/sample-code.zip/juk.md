#### RANGE FOR STATEMENT 


```{c}
for(const auto &folder : qAsConst(m_folderList)) {
        m_dirLister.openUrl(QUrl::fromUserInput(folder), KDirLister::Keep);
    }
```

#### AUTO 


```{c}
const auto item = CollectionList::instance()->lookup(fileName);
```

#### AUTO 


```{c}
auto mainWidget = new QWidget( this );
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool enable) {
                m_collection->setUpcomingPlaylistEnabled(enable);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : m_playlists) {
        if(!playlist)
            continue;
        playlist->slotReload();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &searchLine : m_searchLines)
        m_search.addComponent(searchLine->searchComponent());
```

#### AUTO 


```{c}
const auto &url
```

#### RANGE FOR STATEMENT 


```{c}
for(Playlist* playlist : playlists)
        model->addSourceModel(playlist->model());
```

#### AUTO 


```{c}
const auto playlist
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &playlistBoxItem : qAsConst(m_viewModes)) {
        playlistBoxItem->setDynamicListsFrozen(frozen);
    }
```

#### AUTO 


```{c}
auto &label
```

#### AUTO 


```{c}
auto updateRequestor = new QTimer(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                emit rejected();
            }
```

#### AUTO 


```{c}
const auto cachedWidth = item->cachedWidths();
```

#### AUTO 


```{c}
auto  it  = CoverManager::begin();
```

#### AUTO 


```{c}
const auto &playlistItem
```

#### AUTO 


```{c}
auto localizerJob = KIO::mostLocalUrl(url);
```

#### RANGE FOR STATEMENT 


```{c}
for(QModelIndex index: matches)
        static_cast<PlaylistItem*>(itemFromIndex(index))->refresh();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file : files) {
        const FileHandle f(file);
        PlaylistItem *i = CollectionList::instance()->lookup(f.absFilePath());
        if(i)
            l.append(i);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &folder : m_folderList) {
        m_dirLister.openUrl(QUrl::fromUserInput(folder), KDirLister::Keep);
    }
```

#### AUTO 


```{c}
auto oldItem = takeTopLevelItem(indexOfTopLevelItem(listViewItem));
```

#### AUTO 


```{c}
const auto &folder
```

#### RANGE FOR STATEMENT 


```{c}
for(int i : qAsConst(l)) {
            if(Q_LIKELY(i < m_columnsVisible.size()))
                m_columnsVisible[i] = true;
        }
```

#### AUTO 


```{c}
auto &listViewItem
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto playlist : qAsConst(m_playlists)) {
        if(!playlist)
            continue;
        siblings += playlist->items();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const FileHandleList &newFiles) {
            for(const auto &newFile : newFiles) {
                createItem(newFile);
            }
        }
```

#### AUTO 


```{c}
const auto matchingItems = m_albumSearch.matchedItems();
```

#### AUTO 


```{c}
auto criteriaGroupBox = new QGroupBox(i18n("Search Criteria"));
```

#### AUTO 


```{c}
const auto item = CollectionList::instance()->lookup(newSource.url().path());
```

#### AUTO 


```{c}
auto *flacFile =
            dynamic_cast<TagLib::FLAC::File *>(fileTag.data())
```

#### LAMBDA EXPRESSION 


```{c}
[playingAlbum](const PlaylistItem *item) {
                    return item->file().tag()->album() == playingAlbum;
                }
```

#### AUTO 


```{c}
auto uninhibitPowerManagement = [=] () {
        QDBusMessage reply;
        if (pmInterface->isValid() && (m_pmToken != 0)) {
            reply = pmInterface->call(QStringLiteral("UnInhibit"), m_pmToken);
            if (reply.errorName().isEmpty()) {
                m_pmToken = 0;
            }
        }
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, id]() {
            this->moveItemUp(id);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlistItem : l) {
        s << playlistItem->file().absFilePath();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QDBusReply<uint> reply;
        if (pmInterface->isValid() && (m_pmToken == 0)) {
            reply = pmInterface->call(QStringLiteral("Inhibit"),
                               KAboutData::applicationData().componentName(),
                               QStringLiteral("playing audio"));
            if (reply.isValid()) {
                m_pmToken = reply.value();
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[&](Component c){
        return c.matches(source_row, source_parent, model);
    }
```

#### AUTO 


```{c}
const auto playingItems = PlaylistItem::playingItems();
```

#### AUTO 


```{c}
const auto &clearGuiItem = KStandardGuiItem::clear();
```

#### AUTO 


```{c}
auto result = QTreeWidget::mimeTypes();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_playlistBox->playFirst(); }
```

#### AUTO 


```{c}
auto *playlist = static_cast<Item *>(item)->playlist();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto playlist : playlists) {
        m_playlists << QPointer<Playlist>(playlist);
    }
```

#### AUTO 


```{c}
const auto &playlist
```

#### LAMBDA EXPRESSION 


```{c}
[slider](int newLength) {
            slider->setMaximum(newLength);
            slider->setPageStep(newLength / 10);
            slider->setSingleStep(qMin(5000, newLength / 20));
            }
```

#### AUTO 


```{c}
auto *playlist = playlistItem->playlist();
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(visibleColumns)) {
        minimumWidth[column] = textWidth(header()->fontMetrics(), headerItem()->text(column)) + 10;
        minimumWidthTotal += minimumWidth[column];

        minimumFixedWidth[column] = qMax(minimumWidth[column], m_columnFixedWidths[column]);
        minimumFixedWidthTotal += minimumFixedWidth[column];
    }
```

#### AUTO 


```{c}
auto header = l->header();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &key : paramKeys) {
        data += QUrl::toPercentEncoding(key) + '=' + QUrl::toPercentEncoding(params[key]) + '&';
    }
```

#### AUTO 


```{c}
const auto &info = data()->covers.find(id);
```

#### RANGE FOR STATEMENT 


```{c}
for(const QModelIndex &index : matchingItems)
                    playlist->itemAt(index.row(), index.column());
```

#### AUTO 


```{c}
auto hboxLayout = new QHBoxLayout(this);
```

#### LAMBDA EXPRESSION 


```{c}
[player, slider]() {
            const auto newValue = slider->value();
            player->seek(newValue);
            slider->setValue(newValue);

            connect(player, &PlayerManager::tick, slider, &TimeSlider::setValue);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                this->slotEnable();
                this->setFocus();

                // Do this after initial playlist setup otherwise we'll waste
                // a lot of time starting up with the tag editor trying to
                // re-update after every item is loaded.
                connect(CollectionList::instance(),
                        &CollectionList::signalCollectionChanged,
                        m_editor,
                        &TagEditor::slotUpdateCollection);

                emit guiReady();
            }
```

#### AUTO 


```{c}
auto &searchLine
```

#### AUTO 


```{c}
auto it = categoryOrder.cbegin();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : itemList) {
        const auto cachedWidth = item->cachedWidths();

        // Extra columns start at 0, but those weights aren't shared with all
        // items.
        for(int i = 0; i < columnOffset(); ++i) {
            const auto width = columnWidth(i);
            averageWidth[i] += width * width / itemCount;
        }

        const auto offset = columnOffset();
        for(int column = offset; column < columnCount(); ++column) {
            const auto width = cachedWidth[column - offset];
            averageWidth[column] += width * width / itemCount;
        }
    }
```

#### AUTO 


```{c}
auto uninhibitPowerManagement = [=] () {
        QDBusMessage reply;
        if (pmInterface->isValid() && (m_pmToken != 0)) {
            reply = pmInterface->call(QStringLiteral("UnInhibit"), m_pmToken);
            if (reply.errorName().isEmpty()) {
                m_pmToken = 0;
                qCDebug(JUK_LOG) << "Uninhibiting power management";
            }
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &it : playlists) {
        if(!(it)) {
            continue;
        }
        // TODO back serialization type into Playlist itself
        if(dynamic_cast<HistoryPlaylist *>(it)) {
            s << qint32(History)
                << *static_cast<HistoryPlaylist *>(it);
        }
        else if(dynamic_cast<SearchPlaylist *>(it)) {
            s << qint32(Search)
                << *static_cast<SearchPlaylist *>(it);
        }
        else if(dynamic_cast<UpcomingPlaylist *>(it)) {
            if(!action<KToggleAction>("saveUpcomingTracks")->isChecked())
                continue;
            s << qint32(Upcoming)
                << *static_cast<UpcomingPlaylist *>(it);
        }
        else if(dynamic_cast<FolderPlaylist *>(it)) {
            s << qint32(Folder)
                << *static_cast<FolderPlaylist *>(it);
        }
        else {
            s << qint32(Normal)
                << *(it);
        }
        s << qint32(it->sortColumn());
    }
```

#### AUTO 


```{c}
const auto paramKeys = params.keys();
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
            loader->deleteLater();
            loadWatcher->deleteLater();
        }
```

#### AUTO 


```{c}
const auto newVolume = std::min(m_output->volume() + 0.04, 1.0);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &selItem : l) {
        editTag(selItem, text, column);
    }
```

#### AUTO 


```{c}
auto searchDialog = new AdvancedSearchDialog(
            name, PlaylistSearch(), JuK::JuKInstance());
```

#### AUTO 


```{c}
const auto newFile = item->file();
```

#### AUTO 


```{c}
auto searchDialog = new AdvancedSearchDialog(
            name, *(new PlaylistSearch(JuK::JuKInstance())), JuK::JuKInstance());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file : qAsConst(files)) {
        if(file.isEmpty())
            throw BICStreamException();

        const auto &cItem = clInst->lookup(file);
        if(cItem) {
            // Reuse FileHandle so the playlist doesn't force TagLib to read it
            // from disk
            after = createItem(cItem->file(), after);
        }
        else {
            after = createItem(FileHandle(file), after);
        }
    }
```

#### AUTO 


```{c}
auto *playlistItem = static_cast<Item *>(parent);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto newFile : newFiles) {
                    after = createItem(newFile, after);
                }
```

#### AUTO 


```{c}
const auto width = cachedWidth[column - offset];
```

#### LAMBDA EXPRESSION 


```{c}
[this](const PlaylistItem *item) {
            return item->playlist() != this;
        }
```

#### AUTO 


```{c}
auto p = playlistBoxItem->playlist();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const FileHandleList &newFiles) {
                // NOTE: after and files are both invalid by this point since
                // this can be called long after our own caller has returned.

                PlaylistItem *after = nullptr;
                for(const auto newFile : newFiles) {
                    after = createItem(newFile, after);
                }
            }
```

#### AUTO 


```{c}
auto dlgVLayout = new QVBoxLayout(d->dialog);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file : files) {
        addUntypedFile(file, queue, true, &after);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[player, slider](int action) {
                if(action == QAbstractSlider::SliderMove) {
                    return;
                }

                // Set the new position before the PlayerManager overwrites it
                // again
                player->seek(slider->sliderPosition());
            }
```

#### AUTO 


```{c}
auto hboxVLayout = new QVBoxLayout(hbox);
```

#### AUTO 


```{c}
auto boxHLayout = new QHBoxLayout(box);
```

#### AUTO 


```{c}
auto search = new PlaylistSearch(playlists, components, PlaylistSearch::MatchAll, object());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &key : paramKeys) {
        urlQuery.addQueryItem(key, params[key]);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto playlist : m_playlists) {
            if(!playlist)
                continue;
            playlist->synchronizePlayingItems(l, true);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto playlist : m_playlists) {
                synchronizePlayingItems(playlist, true);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { slotNextStep(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : m_searchCategories)
                item->setHidden(false);
```

#### AUTO 


```{c}
const auto &playlistItems = items();
```

#### RANGE FOR STATEMENT 


```{c}
for(PlaylistItem* item : items())
            item->setHidden(false);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : qAsConst(m_playlists)) {
        if(!playlist)
            continue;
        siblings += playlist->items();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        if(!item || !item->playlist()) {
            qFatal("Ran into an empty item or item playlist when removing playlists!");
        }

        if (!item->playlist()->fileName().isEmpty() &&
            QFileInfo::exists(item->playlist()->fileName()))
        {
            files.append(item->playlist()->fileName());
        }

        names.append(item->playlist()->name());
    }
```

#### AUTO 


```{c}
const auto playlistFoundItems = search.matchedItems();
```

#### AUTO 


```{c}
const auto &item
```

#### AUTO 


```{c}
auto globalAccel = KGlobalAccel::self();
```

#### AUTO 


```{c}
auto pendingResult = addUntypedFile(file, after);
```

#### LAMBDA EXPRESSION 


```{c}
[this, id]() {
            this->showCategoryOption(id);
        }
```

#### AUTO 


```{c}
const auto defaultDirs = defaultFolders();
```

#### AUTO 


```{c}
auto hbox = new QWidget(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this](const KFileItemList &items) {
                    this->newItems(items);
                }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &viewMode : qAsConst(m_viewModes)) {
        viewMode->addItems(QStringList(tag), column);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QDBusReply<uint> reply;
        if (pmInterface->isValid() && (m_pmToken == 0)) {
            reply = pmInterface->call(QStringLiteral("Inhibit"),
                               KAboutData::applicationData().componentName(),
                               QStringLiteral("playing audio"));
            if (reply.isValid()) {
                m_pmToken = reply.value();
                qCDebug(JUK_LOG) << "Inhibiting power management";
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &searchLine : m_searchLines)
        m_search->addComponent(searchLine->searchComponent());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file : files) {
        // some files added here will launch threads that we must wait until
        // they're done to cleanup
        auto pendingResult = addUntypedFile(file, after);
        if(!pendingResult.isFinished()) {
            pendingFutures.push_back(pendingResult);
            ++m_itemsLoading;
        }
    }
```

#### AUTO 


```{c}
const auto playingItem = currentPlaylist()->playingItem();
```

#### AUTO 


```{c}
auto manualResizeAction = action<KToggleAction>("resizeColumnsManually");
```

#### AUTO 


```{c}
const auto &cItem = clInst->lookup(file);
```

#### AUTO 


```{c}
const auto walletName = Wallet::LocalWallet();
```

#### AUTO 


```{c}
const auto &row
```

#### AUTO 


```{c}
const auto textWidth = [](const QFontMetrics &fm, const QString &text) {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 11, 0))
        return fm.horizontalAdvance(text);
#else
        return fm.width(text);
#endif
    };
```

#### LAMBDA EXPRESSION 


```{c}
[parent]{
            if(parent && parent->m_currentPlaylist && parent->isVisible())
                parent->slotSetItems(parent->m_currentPlaylist->selectedItems());
        }
```

#### AUTO 


```{c}
auto group = new QGroupBox;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        const QString artist = item->file().tag()->artist();
        const QString album = item->file().tag()->album();

        albums.insert(qMakePair(artist, album));

        item->file().coverInfo()->setCoverId(id);
        if(setAlbumCovers)
            item->file().coverInfo()->applyCoverToWholeAlbum(true);
    }
```

#### AUTO 


```{c}
const auto headerActions = m_headerMenu->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[](const auto &item) {
            return item->playlist() && item->playlist()->canReload();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &action : headerActions) {
        if(!action)
            continue;

        if(action->data().toInt() == c) {
            action->setChecked(false);
            break;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[searchDialog, this](int result)
            {
                if (result) {
                    raise(new SearchPlaylist(
                                this,
                                *searchDialog->resultSearch(),
                                searchDialog->resultPlaylistName()));
                }
                searchDialog->deleteLater();
            }
```

#### AUTO 


```{c}
auto *mpegFile =
            dynamic_cast<TagLib::MPEG::File *>(fileTag.data())
```

#### AUTO 


```{c}
auto searchDialog = new AdvancedSearchDialog(
            p->name(), p->playlistSearch(), JuK::JuKInstance());
```

#### AUTO 


```{c}
auto strValue = tag->album();
```

#### AUTO 


```{c}
auto nowPlaying = playingItem();
```

#### AUTO 


```{c}
const auto playingAlbum = wasPlaying->file().tag()->album();
```

#### AUTO 


```{c}
auto wallet = Scrobbler::openKWallet();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto playlist : playlists) {
        m_playlists << QPointer<Playlist>(playlist);

        connect(&(playlist->signaller), &PlaylistInterfaceSignaller::playingItemDataChanged,
                this, &DynamicPlaylist::slotSetDirty);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[list](bool enable) {
                    list->enableDirWatch(enable);
                }
```

#### LAMBDA EXPRESSION 


```{c}
[](PlaylistItem *a, PlaylistItem *b) {
                return a->file().tag()->album() < b->file().tag()->album();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(visibleColumns)) {
            setColumnWidth(column, textWidth(header()->fontMetrics(),headerItem()->text(column)) + 10);
        }
```

#### AUTO 


```{c}
auto *tag = mp4File->tag();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        urls << QUrl::fromLocalFile(static_cast<const PlaylistItem*>(item)->file().absFilePath());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[](const QFontMetrics &fm, const QString &text) {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 11, 0))
        return fm.horizontalAdvance(text);
#else
        return fm.width(text);
#endif
    }
```

#### AUTO 


```{c}
const auto &cover
```

#### AUTO 


```{c}
auto &action
```

#### AUTO 


```{c}
const auto &playlistBoxItem
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &mimeType : validMimeTypes) {
        if(result.inherits(mimeType))
            return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[searchDialog, this](int result)
            {
                if (result) {
                    raise(new SearchPlaylist(
                                this,
                                searchDialog->resultSearch(),
                                searchDialog->resultPlaylistName()));
                }
                searchDialog->deleteLater();
            }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Yes | QDialogButtonBox::Cancel, this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file : fileList) {
        stream << file << '\n';
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        files.append(item->file().absFilePath());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[currentAlbum](const PlaylistItem *item) {
                return item->file().tag()->album() != currentAlbum;
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto p : sources) {
        synchronizePlayingItems(p, setMaster);
    }
```

#### AUTO 


```{c}
auto vboxLayout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
auto buttonBox = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(visibleColumns)) {
        totalWeight += m_columnWeights[column];
    }
```

#### AUTO 


```{c}
auto &path
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(visibleColumns)) {
        weightedWidth[column] = int(double(m_columnWeights[column]) / totalWeight * viewport()->width() + 0.5);
    }
```

#### AUTO 


```{c}
const auto &end = CoverManager::end();
```

#### AUTO 


```{c}
auto wasPlayingItem = playingItem();
```

#### RANGE FOR STATEMENT 


```{c}
for(QModelIndex index : m_albumSearch.matchedItems())
                    playlist->itemAt(index.row(), index.column());
```

#### AUTO 


```{c}
auto search = new PlaylistSearch(&p);
```

#### AUTO 


```{c}
const auto droppedUrls = data->urls();
```

#### AUTO 


```{c}
const auto activeItem = currentItem()
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
        loadFile(m_fileName, playlistFile);
        collection->setupPlaylist(this, iconName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[canonicalPath](const auto &dir) {
                return canonicalPath.startsWith(dir);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &albumPair : qAsConst(albums)) {
        refreshAlbum(albumPair.first, albumPair.second);
    }
```

#### AUTO 


```{c}
const auto &albumPair
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(this);
```

#### AUTO 


```{c}
const auto editorLabels = findChildren<QLabel *>();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &url : droppedUrls) {
        lastItem = playlist->createItem(FileHandle(url.toLocalFile()), lastItem);
    }
```

#### AUTO 


```{c}
const auto itemIt = std::find_if(
        playlistItems.begin(), playlistItems.end(),
        [this](const PlaylistItem *item) {
            return item->playlist() != this;
        });
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        delete lookup(item.url().path());
    }
```

#### AUTO 


```{c}
const auto topItem = topLevelItem(0);
```

#### AUTO 


```{c}
const auto type = classifyFile(fileInfo);
```

#### RANGE FOR STATEMENT 


```{c}
for(PlaylistItem* item : playlistItems)
            item->setHidden(false);
```

#### AUTO 


```{c}
const auto &future
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &m3uFile) {
            addPlaylistFile(m3uFile);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this, slot](bool b) -> void {
                invokeSlot<sizeof...(PMFArg)>(m_collection, slot, b);
            }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const FileHandleList &newFiles) {
            for(const auto newFile : newFiles) {
                createItem(newFile);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto enable : enableCheckBoxes) {
        enable->hide(); // These are shown only when multiple items are being edited

        // Each enable checkbox is identified by having its objectName end in "Enable".
        // The corresponding widget to be adjusted is identified by assigning a custom
        // property in Qt Designer "associatedObjectName", the value of which is the name
        // for the widget to be enabled (or not).
        auto associatedVariantValue = enable->property("associatedObjectName");
        Q_ASSERT(associatedVariantValue.isValid());

        QWidget *associatedWidget = findChild<QWidget *>(associatedVariantValue.toString());
        Q_ASSERT(associatedWidget != nullptr);

        m_enableBoxes[associatedWidget] = enable;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &label : m_labels) {
            QPalette palette(label->palette());
            palette.setColor(label->foregroundRole(), result);
            label->setPalette(palette);
        }
```

#### AUTO 


```{c}
const auto loadedMetadata = loadMediaFile(fileInfo.canonicalFilePath());
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QDBusMessage reply;
        if(pmInterface->isValid() && (m_pmToken != 0)) {
            reply = pmInterface->call(QStringLiteral("UnInhibit"), m_pmToken);
            if(reply.errorName().isEmpty()) {
                m_pmToken = 0;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(visibleColumns)) {
        int width;
        if(readjust) {
            int adjustedExtraWidth = int(double(extraWidth[column]) * adjustmentRatio + 0.5);
            width = minimumWidth[column] + adjustedExtraWidth;
        }
        else
            width = weightedWidth[column];

        setColumnWidth(column, width);
        usedWidth += width;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : m_columns){
        const QString str = model->index(row, column, parent).data().toString();
        if(m_re){
            return str.contains(m_queryRe);
        }

        switch(m_mode) {
        case Contains:
            if(str.contains(m_query, m_caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive))
                return true;
            break;
        case Exact:
            if(str.length() == m_query.length()) {
                if(m_caseSensitive) {
                    if(str == m_query)
                        return true;
                }
                else if(str.toLower() == m_query.toLower())
                    return true;
            }
            break;
        case ContainsWord:
        {
            int i = str.indexOf(m_query, 0, m_caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive );

            if(i >= 0) {

                // If we found the pattern and the lengths are the same, then
                // this is a match.

                if(str.length() == m_query.length())
                    return true;

                // First: If the match starts at the beginning of the text or the
                // character before the match is not a word character

                // AND

                // Second: Either the pattern was found at the end of the text,
                // or the text following the match is a non-word character

                // ...then we have a match

                if((i == 0 || !str.at(i - 1).isLetterOrNumber()) &&
                    (i + m_query.length() == str.length() || !str.at(i + m_query.length()).isLetterOrNumber()))
                    return true;
            }
        }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QDBusMessage reply;
        if (pmInterface->isValid() && (m_pmToken != 0)) {
            reply = pmInterface->call(QStringLiteral("UnInhibit"), m_pmToken);
            if (reply.errorName().isEmpty()) {
                m_pmToken = 0;
            }
        }
    }
```

#### AUTO 


```{c}
auto currentPlaying = firstChild();
```

#### AUTO 


```{c}
auto actionCollection = actions();
```

#### AUTO 


```{c}
const auto playingItem = Playlist::playingItem();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto enable : findChildren<QCheckBox *>(QRegExp("Enable$"))) {
        enable->hide(); // These are shown only when multiple items are being edited

        // Each enable checkbox is identified by having its objectName end in "Enable".
        // The corresponding widget to be adjusted is identified by assigning a custom
        // property in Qt Designer "associatedObjectName", the value of which is the name
        // for the widget to be enabled (or not).
        auto associatedVariantValue = enable->property("associatedObjectName");
        Q_ASSERT(associatedVariantValue.isValid());

        QWidget *associatedWidget = findChild<QWidget *>(associatedVariantValue.toString());
        Q_ASSERT(associatedWidget != nullptr);

        m_enableBoxes[associatedWidget] = enable;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, item, column]() {
            this->editItem(item, column);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : qAsConst(m_playlists)) {
            if(!playlist)
                continue;
            playlist->synchronizePlayingItems(l, true);
        }
```

#### AUTO 


```{c}
auto mw = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(int i : l) {
            if(Q_LIKELY(i < m_columnsVisible.size()))
                m_columnsVisible[i] = true;
        }
```

#### AUTO 


```{c}
auto *playlistItem
```

#### LAMBDA EXPRESSION 


```{c}
[searchDialog, p](int result)
            {
                if (result) {
                    p->setPlaylistSearch(searchDialog->resultSearch());
                    p->setName(searchDialog->resultPlaylistName());
                }
                searchDialog->deleteLater();
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &searchLine : m_searchLines)
        searchLine->clear();
```

#### AUTO 


```{c}
const auto &key
```

#### AUTO 


```{c}
const auto &searchLine
```

#### AUTO 


```{c}
auto dlgButtonBox = new QDialogButtonBox(
            QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::RestoreDefaults,
            this);
```

#### AUTO 


```{c}
const auto &pointerGuard
```

#### AUTO 


```{c}
auto boxLayout = new QVBoxLayout(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : m_playlists) {
                synchronizePlayingItems(playlist, true);
            }
```

#### AUTO 


```{c}
const auto &newFile
```

#### AUTO 


```{c}
const auto width = columnWidth(i);
```

#### AUTO 


```{c}
const auto cover = item->file().coverInfo();
```

#### AUTO 


```{c}
auto infoBox = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
            if(playingItem() == item)
                action("forward")->trigger();

            QString removePath = item->file().absFilePath();
            QUrl removeUrl = QUrl::fromLocalFile(removePath);
            if((!shouldDelete && KIO::trash(removeUrl)->exec()) ||
               (shouldDelete && QFile::remove(removePath)))
            {
                delete item->collectionItem();
            }
            else
                errorFiles.append(item->file().absFilePath());
        }
```

#### AUTO 


```{c}
auto &playlistItem
```

#### AUTO 


```{c}
auto dlgButtonBox = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &action : headerActions) {
        if(!action)
            continue;

        if(action->data().toInt() == c) {
            action->setChecked(true);
            break;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &pointerGuard : itemPointers)
        pointerGuard->m_item = nullptr;
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &playlistItem : selItems) {
                playlistItem->file().coverInfo()->setCoverId(id);
                playlistItem->refresh();
            }
```

#### AUTO 


```{c}
const auto validMimeTypes(mimeTypes());
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QDBusReply<uint> reply;
        if(pmInterface->isValid() && (m_pmToken == 0)) {
            reply = pmInterface->call(QStringLiteral("Inhibit"),
                               KAboutData::applicationData().componentName(),
                               QStringLiteral("playing audio"));
            if(reply.isValid()) {
                m_pmToken = reply.value();
            }
        }
    }
```

#### AUTO 


```{c}
auto sliderBoxLayout = new QHBoxLayout( sliderBox );
```

#### LAMBDA EXPRESSION 


```{c}
[this, loader]() {
            loader->deleteLater();

            if(--m_itemsLoading == 0) {
                cleanupAfterAllFileLoadsCompleted();
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(Playlist *p : childList) {
        l.append(p->name());
    }
```

#### AUTO 


```{c}
const auto newVolume = std::max(m_output->volume() - 0.04, 0.0);
```

#### LAMBDA EXPRESSION 


```{c}
[text, adjColumn] (const PlaylistItem *item) { return item->text(adjColumn) != text; }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlistItem : qAsConst(results)) {

        // Don't worry about files that somehow already have a tag,
        // unless the conversion is forced.
        if(!overwriteExistingCovers && playlistItem->file().coverInfo()->coverId() != CoverManager::NoMatch)
            continue;

        playlistItem->file().coverInfo()->setCoverId(m_coverKey);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const QModelIndex &index : matchingItems)
        items.push_back(static_cast<PlaylistItem*>(itemFromIndex(index)));
```

#### AUTO 


```{c}
auto matcher = [&](Component c){
        return c.matches(source_row, source_parent, model);
    };
```

#### AUTO 


```{c}
const auto newValue = slider->value();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            CollectionList::instance()->slotCheckCache();
            this->scanFolders();
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : items) {
        delete item;
    }
```

#### AUTO 


```{c}
auto box = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto newFile : newFiles) {
                createItem(newFile);
            }
```

#### AUTO 


```{c}
const auto &existingItems = items();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : qAsConst(m_playlists)) {
        if(!playlist)
            continue;
        playlist->slotReload();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(m_columns)) {
        const QString str = model->index(row, column, parent).data().toString();
        if(m_re) {
            return str.contains(m_queryRe);
        }

        switch(m_mode) {
        case Contains:
            if(str.contains(m_query, m_caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive))
                return true;
            break;
        case Exact:
            // If lengths match, move on to check strings themselves
            if(str.length() == m_query.length() &&
               (( m_caseSensitive && str == m_query) ||
                (!m_caseSensitive && str.toLower() == m_query.toLower()))
               )
            {
                return true;
            }
            break;
        case ContainsWord:
        {
            int i = str.indexOf(m_query, 0, m_caseSensitive ? Qt::CaseSensitive : Qt::CaseInsensitive);

            if(i >= 0) {

                // If we found the pattern and the lengths are the same, then
                // this is a match.

                if(str.length() == m_query.length())
                    return true;

                // First: If the match starts at the beginning of the text or the
                // character before the match is not a word character

                // AND

                // Second: Either the pattern was found at the end of the text,
                // or the text following the match is a non-word character

                // ...then we have a match

                if((i == 0 || !str.at(i - 1).isLetterOrNumber()) &&
                    (i + m_query.length() == str.length() || !str.at(i + m_query.length()).isLetterOrNumber()))
                    return true;
            }
        }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto column : qAsConst(m_weightDirty)) {
        m_columnWeights[column] = int(std::sqrt(averageWidth[column]) + 0.5);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : existingItems) {
        oldItems.insert(item->collectionItem(), item);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        urls << QUrl::fromLocalFile(item->file().absFilePath());
    }
```

#### AUTO 


```{c}
const auto wasPlaying = playingItem();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &it : covers) {
        out << quint32(it.first);
        out << it.second;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[player, slider]() {
            QObject::disconnect(player, &PlayerManager::tick, slider, nullptr);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto item : qAsConst(m_itemsDict)) {
            if(!item->checkCurrent())
                invalidItems.append(item);
        }
```

#### AUTO 


```{c}
const auto fileName = m_dirIterator.next();
```

#### AUTO 


```{c}
auto sliderBox = new QWidget;
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : items) {
        item->guessTagInfo(type);
        processEvents();
    }
```

#### AUTO 


```{c}
const auto enableCheckBoxes = findChildren<QCheckBox *>(QRegularExpression("Enable$"));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &newFile : newFiles) {
                createItem(newFile);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : m_playlists) {
            if(!playlist)
                continue;
            playlist->synchronizePlayingItems(l, true);
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                m_showTimeRemaining = !m_showTimeRemaining;
                updateTime();
            }
```

#### LAMBDA EXPRESSION 


```{c}
[category](const Row &r) { return r.category.category == category; }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto label : editorLabels) {
        if(m_enableBoxes.contains(label->buddy()))
            label->setMinimumHeight(m_enableBoxes[label->buddy()]->height());
    }
```

#### AUTO 


```{c}
auto &selItem
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : itemList) {
        if(oldItems.remove(item->collectionItem()) == 0) {
            newItems.append(item->collectionItem());
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &path : pathList) {
        QDesktopServices::openUrl(path);

        processEvents();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(int column : qAsConst(visibleColumns)) {
        if(weightedWidth[column] < minimumWidth[column]) {
            readjust = true;
            extraWidth[column] = 0;
            neededWidth += minimumWidth[column] - weightedWidth[column];
        }
        else {
            extraWidth[column] = weightedWidth[column] - minimumWidth[column];
            availableWidth += extraWidth[column];
        }
    }
```

#### AUTO 


```{c}
const auto prefix
        = (playlist() == CollectionList::instance())
            ? QStringLiteral("0")
            : m_sortedFirst
                ? QStringLiteral("1")
                : QStringLiteral("2");
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : m_searchCategories)
            item->setHidden(true);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : qAsConst(m_playlists)) {
                synchronizePlayingItems(playlist, true);
            }
```

#### AUTO 


```{c}
const auto column
```

#### AUTO 


```{c}
const auto &it
```

#### LAMBDA EXPRESSION 


```{c}
[=] () {
        QDBusMessage reply;
        if (pmInterface->isValid() && (m_pmToken != 0)) {
            reply = pmInterface->call(QStringLiteral("UnInhibit"), m_pmToken);
            if (reply.errorName().isEmpty()) {
                m_pmToken = 0;
                qCDebug(JUK_LOG) << "Uninhibiting power management";
            }
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QString &m3uFile) {
                addPlaylistFile(m3uFile);
            }
```

#### AUTO 


```{c}
const auto nextAlbumTrack = std::find_if(m_randomSequence.begin(), m_randomSequence.end(),
            [currentAlbum](const PlaylistItem *item) {
                return item->file().tag()->album() != currentAlbum;
            });
```

#### AUTO 


```{c}
const auto &plistActions = m_playlistBox->collectionActions();
```

#### AUTO 


```{c}
const auto iconLoader = KIconLoader::global();
```

#### RANGE FOR STATEMENT 


```{c}
for(int logicalIndex : m_columnOrder) {
        header->moveSection(header->visualIndex(logicalIndex), i + offset);
        i++;
    }
```

#### AUTO 


```{c}
auto label
```

#### AUTO 


```{c}
auto getJob = KIO::storedGet(urls.front());
```

#### AUTO 


```{c}
const auto *collectionList = CollectionList::instance();
```

#### AUTO 


```{c}
auto &viewMode
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel, d->dialog);
```

#### AUTO 


```{c}
auto jumpBox = new QFrame(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, id]() {
            this->slotRemoveRow(id);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for(QModelIndex i : search.matchedItems())
        results.append(static_cast<PlaylistItem*>(CollectionList::instance()->itemAt(i.row(), i.column())));
```

#### AUTO 


```{c}
auto jumpBoxHLayout = new QHBoxLayout(jumpBox);
```

#### AUTO 


```{c}
auto &playlistBoxItem
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &file : files) {
        // some files added here will launch threads that will do cleanup (fix
        // the cursor, allow data updates etc) when the last thread is done.
        // Managed by m_itemsLoading going to 0 which is why we ++ above.
        addUntypedFile(file, after);
    }
```

#### AUTO 


```{c}
auto uninhibitPowerManagement = [=] () {
        QDBusMessage reply;
        if(pmInterface->isValid() && (m_pmToken != 0)) {
            reply = pmInterface->call(QStringLiteral("UnInhibit"), m_pmToken);
            if(reply.errorName().isEmpty()) {
                m_pmToken = 0;
            }
        }
    };
```

#### RANGE FOR STATEMENT 


```{c}
for(auto *playlistItem : itemList) {
        after = createItem(playlistItem, after);
        m_playlistIndex.insert(after, playlistItem->playlist());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { saveConfig(); }
```

#### AUTO 


```{c}
const auto blockedPaths = m_collection->excludedFolders();
```

#### AUTO 


```{c}
const auto id = row.position;
```

#### AUTO 


```{c}
auto item = lookup(file);
```

#### AUTO 


```{c}
const auto playlistItems = PlaylistItem::playingItems();
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &viewMode : qAsConst(m_viewModes)) {
        viewMode->removeItem(tag, column);
    }
```

#### AUTO 


```{c}
auto loader = new DirectoryLoader(dirPath);
```

#### AUTO 


```{c}
auto pItem = static_cast<PlaylistBox::Item*>(item);
```

#### AUTO 


```{c}
auto *mp4File =
            dynamic_cast<TagLib::MP4::File *>(fileTag.data())
```

#### AUTO 


```{c}
auto p
```

#### AUTO 


```{c}
auto box = new QHBoxLayout;
```

#### AUTO 


```{c}
const auto &item = playingItem();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &future : qAsConst(pendingFutures)) {
        auto loadWatcher = new QFutureWatcher<void>(this);
        loadWatcher->setFuture(future);

        connect(loadWatcher, &QFutureWatcher<void>::finished, this, [=]() {
                if(--m_itemsLoading == 0) {
                    cleanupAfterAllFileLoadsCompleted();
                }

                loadWatcher->deleteLater();
            });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &searchLine : qAsConst(m_searchLines))
        m_search->addComponent(searchLine->searchComponent());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &url : urlList) {
        auto localizerJob = KIO::mostLocalUrl(url);
        KJobWidgets::setWindow(localizerJob, w);

        if(localizerJob->exec() && (localUrl = localizerJob->mostLocalUrl()).isLocalFile())
            result.append(localUrl.path());
        else
            qCDebug(JUK_LOG) << url << " is not a local file, skipping.";
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &listViewItem : items) {
            auto oldItem = takeTopLevelItem(indexOfTopLevelItem(listViewItem));
            insertTopLevelItem(++insertIndex, oldItem);
        }
```

#### AUTO 


```{c}
auto collection = CollectionList::instance();
```

#### RANGE FOR STATEMENT 


```{c}
for(QModelIndex i : playlistFoundItems)
        results.append(static_cast<PlaylistItem*>(CollectionList::instance()->itemAt(i.row(), i.column())));
```

#### AUTO 


```{c}
auto enable
```

#### AUTO 


```{c}
auto *oggTag =
            dynamic_cast<TagLib::Ogg::XiphComment *>(fileTag->tag())
```

#### LAMBDA EXPRESSION 


```{c}
[searchDialog, this](int result) {
                if (result) {
                    raise(new SearchPlaylist(
                                this,
                                *searchDialog->resultSearch(),
                                searchDialog->resultPlaylistName()));
                }
                searchDialog->deleteLater();
            }
```

#### AUTO 


```{c}
const auto file = m_playlistInterface->currentFile();
```

#### AUTO 


```{c}
const auto *tagManager = TagTransactionManager::instance();
```

#### AUTO 


```{c}
auto wasChecked = manualResizeAction->isChecked();
```

#### LAMBDA EXPRESSION 


```{c}
[this]() { m_collection->stop(); }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : playingItems) {
        item->treeWidget()->viewport()->update();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto playlist : m_playlists) {
        if(!playlist)
            continue;
        playlist->slotReload();
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]() {
                if(--m_itemsLoading == 0) {
                    cleanupAfterAllFileLoadsCompleted();
                }

                loadWatcher->deleteLater();
            }
```

#### AUTO 


```{c}
auto buttonBoxVLayout = new QVBoxLayout(buttonBox);
```

#### AUTO 


```{c}
const auto &mimeType
```

#### RANGE FOR STATEMENT 


```{c}
for(const QModelIndex index: m_search->matchedItems())
        items.push_back(static_cast<PlaylistItem*>(itemFromIndex(index)));
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &mimeType : mimeTypes()) {
        if(result.inherits(mimeType))
            return true;
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const PlaylistItem *playingItem) {
            return this == playingItem;
        }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                emit accepted();
            }
```

#### AUTO 


```{c}
auto searchDialog = new AdvancedSearchDialog(
            p->name(), *(p->playlistSearch()), JuK::JuKInstance());
```

#### AUTO 


```{c}
auto upcomingAction = new KToggleAction(
            QIcon::fromTheme(QStringLiteral("go-jump-today")),
            i18n("Show &Play Queue"), actionCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlistBoxItem : items) {
        auto p = playlistBoxItem->playlist();
        if(p) {
            playlists.append(p);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](bool e) { m_playlistBox->setSearchEnabled(e); }
```

#### AUTO 


```{c}
const auto currentAlbum = item->file().tag()->album();
```

#### AUTO 


```{c}
const auto itemPointers = m_itemPointers[item];
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : itemList) {
        QUrl path = QUrl::fromLocalFile(item->file().fileInfo().absoluteDir().absolutePath());
        if(!pathList.contains(path))
            pathList.append(path);
    }
```

#### AUTO 


```{c}
auto &item
```

#### AUTO 


```{c}
const auto &file
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        const auto cover = item->file().coverInfo();

        if(cover->hasCover()) {
            cover->popup();
            return; // If we select multiple items, only show one
        }
    }
```

#### AUTO 


```{c}
const auto sharedSettings = SharedSettings::instance();
```

#### AUTO 


```{c}
auto search = new PlaylistSearch(playlists, components,
            PlaylistSearch::MatchAll, collectionActions());
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlistFile : qAsConst(files)) {
                if(!QFile::remove(playlistFile))
                    couldNotDelete.append(playlistFile);
            }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto label : findChildren<QLabel *>()) {
        if(m_enableBoxes.contains(label->buddy()))
            label->setMinimumHeight(m_enableBoxes[label->buddy()]->height());
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, id]() {
            this->moveItemDown(id);
        }
```

#### AUTO 


```{c}
auto layout = new QVBoxLayout(this);
```

#### AUTO 


```{c}
const auto item = static_cast<const PlaylistItem*>(*it);
```

#### AUTO 


```{c}
auto loadWatcher = new QFutureWatcher<void>(this);
```

#### RANGE FOR STATEMENT 


```{c}
for(QModelIndex index : indexes)
        itemFromIndex(index)->setHidden(!visible);
```

#### AUTO 


```{c}
const auto pixRatio = this->devicePixelRatioF();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &item : items) {
        if(item != Item::collectionItem() &&
           !item->playlist()->readOnly())
        {
            if(item->playlist() != upcomingPlaylist())
                delete item;
            else {
                action<KToggleAction>("showUpcoming")->setChecked(false);
                setUpcomingPlaylistEnabled(false);
            }
        }
    }
```

#### AUTO 


```{c}
auto item
```

#### AUTO 


```{c}
const auto newFile
```

#### AUTO 


```{c}
auto infoBoxVLayout = new QVBoxLayout(infoBox);
```

#### AUTO 


```{c}
auto &nextItem = m_backMenuItems[number];
```

#### AUTO 


```{c}
const auto offset = columnOffset();
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &row : m_rows)
        if(row.category.category == category)
            ++categoryCount;
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &cover : covers) {
        TagLib::ByteVector coverData = cover.data();

        QImage result = QImage::fromData(
                reinterpret_cast<const uchar *>(coverData.data()),
                coverData.size());

        if(!result.isNull())
            return result;
    }
```

#### AUTO 


```{c}
const auto &data = CoverManager::coverInfo(id);
```

#### AUTO 


```{c}
auto upcomingAction = new KToggleAction(
            "go-jump-today"_icon, i18n("Show &Play Queue"), actionCollection);
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : l) {
        editTag(item, text, column);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for(auto &item : itemList) {
        item->refreshFromDisk();

        if(!item->file().tag() || !item->file().fileInfo().exists()) {
            qCDebug(JUK_LOG) << "Error while trying to refresh the tag.  "
                           << "This file has probably been removed.";
            delete item->collectionItem();
        }

        processEvents();
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
```

#### AUTO 


```{c}
auto mainBox = new QVBoxLayout( mainWidget );
```

#### AUTO 


```{c}
auto associatedVariantValue = enable->property("associatedObjectName");
```

#### LAMBDA EXPRESSION 


```{c}
[slider](bool seekable) {
        static const QString noSeekMsg =
            i18n("Seeking is not supported in this file with your audio settings.");
        slider->setToolTip(seekable ? QString() : noSeekMsg);
    }
```

#### AUTO 


```{c}
auto future = QtConcurrent::run(loader, &DirectoryLoader::startLoading);
```

#### AUTO 


```{c}
const auto &playlistFile
```

#### AUTO 


```{c}
const auto musicLocation =
        QStandardPaths::writableLocation(QStandardPaths::MusicLocation);
```

#### AUTO 


```{c}
auto i = new ItemType(item, this, after);
```

#### RANGE FOR STATEMENT 


```{c}
for(const auto &playlist : qAsConst(m_playlists)) {
        if(!playlist)
            continue;
        playlist->synchronizePlayingItems(l, true);
    }
```

#### AUTO 


```{c}
const auto childList = m_playlistStack->findChildren<Playlist *>("Playlist");
```

#### AUTO 


```{c}
const auto matchingItems = m_search->matchedItems();
```

