#### AUTO 


```{c}
auto calendar = KCalCore::MemoryCalendar::Ptr::create(KDateTime::UTC);
```

#### AUTO 


```{c}
auto mimeType = mimeDb.mimeTypeForName(a.mimeType());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &a : lstAttachments) {
        QVariantHash attachment;
        QMimeDatabase mimeDb;
        auto mimeType = mimeDb.mimeTypeForName(a.mimeType());
        attachment[QStringLiteral("icon")] = (mimeType.isValid()
                                              ? mimeType.iconName()
                                              : QStringLiteral("application-octet-stream"));
        attachment[QStringLiteral("name")] = a.label();
        const QString attachementStr = helper->generateLinkURL(QStringLiteral("ATTACH:%1").arg(QString::fromLatin1(a.label().toUtf8().toBase64())));
        attachment[QStringLiteral("uri")] = attachementStr;
        attachments.push_back(attachment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        KEmailAddress::extractEmailAddressAndName(a.delegator(), delegatorEmail, delegatorName);
        if (thatIsMe(delegatorEmail)) {
            attendee = a;
            break;
        }
    }
```

#### AUTO 


```{c}
auto todo = makeToDo(!ALL_DAY, RECURS, START_DT, DUE_DT);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        if (a.role() != role) {
            // skip this role
            continue;
        }
        if (attendeeIsOrganizer(incidence, a)) {
            // skip attendee that is also the organizer
            continue;
        }
        QVariantHash attendeeData = displayViewFormatPerson(a.email(), a.name(), a.uid(),
                                                            showStatus ? a.status() : Attendee::None);
        if (!a.delegator().isEmpty()) {
            attendeeData[QStringLiteral("delegator")] = a.delegator();
        }
        if (!a.delegate().isEmpty()) {
            attendeeData[QStringLiteral("delegate")] = a.delegate();
        }
        if (showStatus) {
            attendeeData[QStringLiteral("status")] = Stringify::attendeeStatus(a.status());
        }

        attendeeDataList << attendeeData;
    }
```

#### AUTO 


```{c}
auto buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel | QDialogButtonBox::No | QDialogButtonBox::Yes, parent);
```

#### AUTO 


```{c}
auto returnEndLine()
{
#if (QT_VERSION < QT_VERSION_CHECK(5, 15, 0))
    return endl;
#else
    return Qt::endl;
#endif
}
```

#### AUTO 


```{c}
const auto events = calendar->events();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment::Ptr &a : lstAttachments) {
        QVariantHash attachment;
        QMimeDatabase mimeDb;
        auto mimeType = mimeDb.mimeTypeForName(a->mimeType());
        attachment[QStringLiteral("icon")] = (mimeType.isValid()
                                              ? mimeType.iconName()
                                              : QStringLiteral("application-octet-stream"));
        attachment[QStringLiteral("name")] = a->label();
        const QString attachementStr = helper->generateLinkURL(QStringLiteral("ATTACH:%1").arg(QString::fromLatin1(a->label().toUtf8().toBase64())));
        attachment[QStringLiteral("uri")] = attachementStr;
        attachments.push_back(attachment);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        if (email == a.email()) {
            attendee = a;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto duration { todo->dtStart(true).secsTo(todo->dtDue(true)) };
```

#### AUTO 


```{c}
auto mimeData = new QMimeData;
```

#### AUTO 


```{c}
const auto journals = calendar->journals();
```

#### AUTO 


```{c}
const auto size = sizeOrGroupLookup.constFind(sizeStr);
```

#### AUTO 


```{c}
auto *mainLayout = new QVBoxLayout();
```

#### AUTO 


```{c}
auto todo = makeToDo(!ALL_DAY, RECURS, START_DT, QDateTime());
```

#### AUTO 


```{c}
auto it = matchingEvents.cbegin(), end = matchingEvents.cend();
```

#### AUTO 


```{c}
auto todo = makeToDo(allDay, RECURS, dtStart, dtDue);
```

#### AUTO 


```{c}
auto iter = arguments.cbegin(), end = arguments.cend();
```

#### AUTO 


```{c}
auto todo = makeToDo(ALL_DAY, RECURS, START_DT, QDateTime());
```

#### AUTO 


```{c}
const auto fileContent = fstream.readAll();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
            if (!a.email().isEmpty()) {
                *ts << "<a href=\"mailto:" << a.email();
                *ts << "\">" << cleanChars(a.name()) << "</a>";
            } else {
                *ts << "    " << cleanChars(a.name());
            }
            *ts << "<br />" << returnEndLine();
        }
```

#### AUTO 


```{c}
auto *mimeData = new QMimeData;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        if (a.role() != role) {
            // skip this role
            continue;
        }
        if (attendeeIsOrganizer(incidence, a)) {
            // skip attendee that is also the organizer
            continue;
        }
        QVariantHash attendeeData = displayViewFormatPerson(a.email(), a.name(), a.uid(), showStatus ? a.status() : Attendee::None);
        if (!a.delegator().isEmpty()) {
            attendeeData[QStringLiteral("delegator")] = a.delegator();
        }
        if (!a.delegate().isEmpty()) {
            attendeeData[QStringLiteral("delegate")] = a.delegate();
        }
        if (showStatus) {
            attendeeData[QStringLiteral("status")] = Stringify::attendeeStatus(a.status());
        }

        attendeeDataList << attendeeData;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        if (a.role() != role) {
            // skip not this role
            continue;
        }
        if (attendeeIsOrganizer(incidence, a)) {
            // skip attendee that is also the organizer
            continue;
        }
        if (i == maxNumAtts) {
            tmpStr += QLatin1String("&nbsp;&nbsp;") + etc;
            break;
        }
        tmpStr += QLatin1String("&nbsp;&nbsp;") + tooltipPerson(a.email(), a.name(),
                                                                showStatus ? a.status() : Attendee::None);
        if (!a.delegator().isEmpty()) {
            tmpStr += i18n(" (delegated by %1)", a.delegator());
        }
        if (!a.delegate().isEmpty()) {
            tmpStr += i18n(" (delegated to %1)", a.delegate());
        }
        tmpStr += QLatin1String("<br>");
        i++;
    }
```

#### AUTO 


```{c}
auto mimeType = mimeDb.mimeTypeForName(a->mimeType());
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        if (a.role() != role) {
            // skip not this role
            continue;
        }
        if (attendeeIsOrganizer(incidence, a)) {
            // skip attendee that is also the organizer
            continue;
        }
        if (i == maxNumAtts) {
            tmpStr += QLatin1String("&nbsp;&nbsp;") + etc;
            break;
        }
        tmpStr += QLatin1String("&nbsp;&nbsp;") + tooltipPerson(a.email(), a.name(), showStatus ? a.status() : Attendee::None);
        if (!a.delegator().isEmpty()) {
            tmpStr += i18n(" (delegated by %1)", a.delegator());
        }
        if (!a.delegate().isEmpty()) {
            tmpStr += i18n(" (delegated to %1)", a.delegate());
        }
        tmpStr += QLatin1String("<br>");
        i++;
    }
```

#### AUTO 


```{c}
auto dialog = createDialog(buttons, caption, widget, &buttonBox, parent);
```

#### AUTO 


```{c}
const auto duration{todo->dtStart(true).daysTo(todo->dtDue(true))};
```

#### AUTO 


```{c}
auto it = as.cbegin(), end = as.cend();
```

#### AUTO 


```{c}
auto drag = new QDrag(owner);
```

#### AUTO 


```{c}
auto calendar = KCalCore::MemoryCalendar::Ptr::create(QTimeZone::utc());
```

#### AUTO 


```{c}
auto toolTip = plain(toolTipStr(CAL_NAME, todo, asOfDate, false));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &a : lstAttendees) {
        if (iamAttendee(a)) {
            continue;
        }

        QVariantHash attendee;
        attendee[QStringLiteral("name")] = a.name();
        attendee[QStringLiteral("email")] = a.email();
        attendee[QStringLiteral("delegator")] = a.delegator();
        attendee[QStringLiteral("delegate")] = a.delegate();
        attendee[QStringLiteral("isOrganizer")] = attendeeIsOrganizer(incidence, a);
        attendee[QStringLiteral("status")] = Stringify::attendeeStatus(a.status());
        attendee[QStringLiteral("icon")] = rsvpStatusIconName(a.status());

        attendees.push_back(attendee);
    }
```

#### AUTO 


```{c}
auto *drag = new QDrag(owner);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
            if (!a.email().isEmpty()) {
                *ts << "<a href=\"mailto:" << a.email();
                *ts << "\">" << cleanChars(a.name()) << "</a>";
            } else {
                *ts << "    " << cleanChars(a.name());
            }
            *ts << "<br />" << endl;
        }
```

#### AUTO 


```{c}
auto toolTip = plain(toolTipStr(CAL_NAME, todo, AS_OF_DATE, false));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &a_ : lstAttendees) {
        Attendee a = a_;
        if (!attendeeIsOrganizer(incidence, a)) {
            continue;
        }
        QVariantHash attendee;
        attendee[QStringLiteral("status")] = Stringify::attendeeStatus(a.status());
        if (!sender.isNull() && (a.email() == sender.email())) {
            // use the attendee taken from the response incidence,
            // rather than the attendee from the calendar incidence.
            if (a.status() != sender.status()) {
                attendee[QStringLiteral("status")] = i18n("%1 (<i>unrecorded</i>",
                                                          Stringify::attendeeStatus(sender.status()));
            }
            a = sender;
        }

        attendee[QStringLiteral("name")] = a.name();
        attendee[QStringLiteral("email")] = a.email();
        attendee[QStringLiteral("delegator")] = a.delegator();
        attendee[QStringLiteral("delegate")] = a.delegate();
        attendee[QStringLiteral("isOrganizer")] = attendeeIsOrganizer(incidence, a);
        attendee[QStringLiteral("isMyself")] = iamAttendee(a);
        attendee[QStringLiteral("icon")] = rsvpStatusIconName(a.status());

        attendees.push_back(attendee);
    }
```

#### AUTO 


```{c}
auto returnEndLine()
{
    return Qt::endl;
}
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment &a : lstAttachments) {
        QVariantHash attachment;
        QMimeDatabase mimeDb;
        auto mimeType = mimeDb.mimeTypeForName(a.mimeType());
        attachment[QStringLiteral("icon")] = (mimeType.isValid() ? mimeType.iconName() : QStringLiteral("application-octet-stream"));
        attachment[QStringLiteral("name")] = a.label();
        const QString attachementStr = helper->generateLinkURL(QStringLiteral("ATTACH:%1").arg(QString::fromLatin1(a.label().toUtf8().toBase64())));
        attachment[QStringLiteral("uri")] = attachementStr;
        attachments.push_back(attachment);
    }
```

#### AUTO 


```{c}
auto calendar = KCalendarCore::MemoryCalendar::Ptr::create(QTimeZone::utc());
```

#### AUTO 


```{c}
auto todo = makeToDo(ALL_DAY, RECURS, START_DT, DUE_DT);
```

#### AUTO 


```{c}
auto dialog = createDialog(buttons, caption, Q_NULLPTR, &buttonBox, parent);
```

#### AUTO 


```{c}
const auto &a
```

#### AUTO 


```{c}
const auto duration { todo->dtStart(true).daysTo(todo->dtDue(true)) };
```

#### AUTO 


```{c}
auto it = periods.cbegin(), end = periods.cend();
```

#### AUTO 


```{c}
const auto todos = calendar->todos();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee::Ptr &a : lstAttendees) {
        if (iamAttendee(a)) {
            continue;
        }

        QVariantHash attendee;
        attendee[QStringLiteral("name")] = a->name();
        attendee[QStringLiteral("email")] = a->email();
        attendee[QStringLiteral("delegator")] = a->delegator();
        attendee[QStringLiteral("delegate")] = a->delegate();
        attendee[QStringLiteral("isOrganizer")] = attendeeIsOrganizer(incidence, a);
        attendee[QStringLiteral("status")] = Stringify::attendeeStatus(a->status());
        attendee[QStringLiteral("icon")] = rsvpStatusIconName(a->status());

        attendees.push_back(attendee);
    }
```

#### AUTO 


```{c}
auto returnEndLine() {
#if (QT_VERSION < QT_VERSION_CHECK(5, 15, 0))
     return endl;
#else
     return Qt::endl;
#endif
}
```

#### AUTO 


```{c}
auto toolTip = plain(toolTipStr(CAL_NAME, todo, QDate(), false));
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee &a_ : lstAttendees) {
        Attendee a = a_;
        if (!attendeeIsOrganizer(incidence, a)) {
            continue;
        }
        QVariantHash attendee;
        attendee[QStringLiteral("status")] = Stringify::attendeeStatus(a.status());
        if (!sender.isNull() && (a.email() == sender.email())) {
            // use the attendee taken from the response incidence,
            // rather than the attendee from the calendar incidence.
            if (a.status() != sender.status()) {
                attendee[QStringLiteral("status")] = i18n("%1 (<i>unrecorded</i>", Stringify::attendeeStatus(sender.status()));
            }
            a = sender;
        }

        attendee[QStringLiteral("name")] = a.name();
        attendee[QStringLiteral("email")] = a.email();
        attendee[QStringLiteral("delegator")] = a.delegator();
        attendee[QStringLiteral("delegate")] = a.delegate();
        attendee[QStringLiteral("isOrganizer")] = attendeeIsOrganizer(incidence, a);
        attendee[QStringLiteral("isMyself")] = iamAttendee(a);
        attendee[QStringLiteral("icon")] = rsvpStatusIconName(a.status());

        attendees.push_back(attendee);
    }
```

#### AUTO 


```{c}
auto il = l.cbegin(), end = l.cend();
```

#### AUTO 


```{c}
auto widget = new ScopeWidget(availableChoices, selectedOccurrence, nullptr);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attendee::Ptr &a_ : lstAttendees) {
        Attendee::Ptr a = a_;
        if (!attendeeIsOrganizer(incidence, a)) {
            continue;
        }
        QVariantHash attendee;
        attendee[QStringLiteral("status")] = Stringify::attendeeStatus(a->status());
        if (sender && (a->email() == sender->email())) {
            // use the attendee taken from the response incidence,
            // rather than the attendee from the calendar incidence.
            if (a->status() != sender->status()) {
                attendee[QStringLiteral("status")] = i18n("%1 (<i>unrecorded</i>",
                                                          Stringify::attendeeStatus(sender->status()));
            }
            a = sender;
        }

        attendee[QStringLiteral("name")] = a->name();
        attendee[QStringLiteral("email")] = a->email();
        attendee[QStringLiteral("delegator")] = a->delegator();
        attendee[QStringLiteral("delegate")] = a->delegate();
        attendee[QStringLiteral("isOrganizer")] = attendeeIsOrganizer(incidence, a);
        attendee[QStringLiteral("isMyself")] = iamAttendee(a);
        attendee[QStringLiteral("icon")] = rsvpStatusIconName(a->status());

        attendees.push_back(attendee);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &a : attendees) {
        if (iamAttendee(a)) {
            attendee = a;
            break;
        }
    }
```

#### AUTO 


```{c}
const auto l = recur->exDateTimes();
```

#### AUTO 


```{c}
const auto duration{todo->dtStart(true).secsTo(todo->dtDue(true))};
```

#### AUTO 


```{c}
auto todo = makeToDo(!ALL_DAY, !RECURS, START_DT, DUE_DT);
```

#### AUTO 


```{c}
auto *widget = new ScopeWidget(availableChoices, selectedOccurrence, nullptr);
```

#### AUTO 


```{c}
auto todo = makeToDo(allDay, !RECURS, dtStart, dtDue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Attachment::Ptr &a : lstAttachments) {
        QVariantHash attachment;
        QMimeDatabase mimeDb;
        auto mimeType = mimeDb.mimeTypeForName(a->mimeType());
        attachment[QStringLiteral("icon")] = (mimeType.isValid() ?
                                                mimeType.iconName() :
                                                QStringLiteral("application-octet-stream"));
        attachment[QStringLiteral("name")] = a->label();
        const QString attachementStr = helper->generateLinkURL(QStringLiteral("ATTACH:%1").arg(QString::fromLatin1(a->label().toUtf8().toBase64())));;
        attachment[QStringLiteral("uri")] = attachementStr;
        attachments.push_back(attachment);
    }
```

#### AUTO 


```{c}
auto todo = makeToDo(ALL_DAY, !RECURS, START_DT, DUE_DT);
```

#### AUTO 


```{c}
auto mainLayout = new QVBoxLayout();
```

