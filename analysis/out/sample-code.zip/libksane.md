#### AUTO 


```{c}
const auto dpr = d->devicePixelRatio;
```

#### RANGE FOR STATEMENT 


```{c}
for (int sizeCode: qAsConst(m_sizeCodes)) {
        QSizeF size = QPageSize::size((QPageSize::PageSizeId)sizeCode, QPageSize::Millimeter);
        size.transpose();
        if (mmToDispUnit(size.width() - PageSizeWiggleRoom) > widthInDispUnit) {
            continue;
        }
        if (mmToDispUnit(size.height() - PageSizeWiggleRoom) > heightInDispUnit) {
            continue;
        }
        QString name = QPageSize::name((QPageSize::PageSizeId)sizeCode) +
        i18nc("Page size landscape", " Landscape");
        m_scanareaPapersize->addItem(name , size);
    }
```

#### AUTO 


```{c}
const auto &value = values.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sizeCode : possibleSizesList) {
        QSizeF size = QPageSize::size(sizeCode, QPageSize::Millimeter);
        if (size.width() - PageSizeWiggleRoom > maxScannerWidth) {
            continue;
        }
        if (size.height() - PageSizeWiggleRoom > maxScannerHeight) {
            continue;
        }
        m_availableSizesList << size;
        m_availableSizesListNames << QPageSize::name(sizeCode);
    }
```

#### AUTO 


```{c}
const auto option
```

#### AUTO 


```{c}
const auto optionsList = d->m_ksaneCoreInterface->getOptionsList();
```

#### AUTO 


```{c}
auto it = d->m_optionsLocation.find(optionEnum);
```

#### AUTO 


```{c}
const auto &device
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &option : qAsConst(d->m_externalOptionsList)) {
        if (option->name() == optionName) {
            return option;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &option : qAsConst(d->m_optionsList)) {
        if (option->name() == optname) {
            value = option->valueAsString();
            return !value.isEmpty();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : deviceList) {
            if (device.name == m_devName) {
                m_vendor    = device.vendor;
                m_model     = device.model;
                break;
            }
        }
```

#### AUTO 


```{c}
const auto optionsMap = d->m_ksaneCoreInterface->getOptionsMap();
```

#### AUTO 


```{c}
const auto it = stringEnumTranslation.find(option->name());
```

#### LAMBDA EXPRESSION 


```{c}
[=]() { d->option = nullptr; }
```

#### LAMBDA EXPRESSION 


```{c}
[=]( const QVariant &newValue ) { Q_EMIT q->buttonPressed(option->name(), option->title(), newValue.toBool()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto sizeCode : possibleSizesList) {
        QSizeF size = QPageSize::size(sizeCode, QPageSize::Millimeter);
        size.transpose();
        if (size.width() - PageSizeWiggleRoom > maxScannerWidth) {
            continue;
        }
        if (size.height() - PageSizeWiggleRoom > maxScannerHeight) {
            continue;
        }
        m_availableSizesList << size;
        m_availableSizesListNames << i18nc("Page size landscape", "Landscape %1", QPageSize::name(sizeCode));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto option : optionsList) {
        if (m_handledOptions.find(option->name()) != m_handledOptions.end()) {
            continue;
        }
        if (option->type() != KSane::CoreOption::TypeDetectFail) {
            KSaneOptionWidget *widget = createOptionWidget(m_otherOptsTab, option);
            if (widget != nullptr) {
                otherLayout->addWidget(widget);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto &writeOption : optionsList) {
        if (writeOption->name() == option) {
            if (writeOption->setValue(value)) {
                if ((d->m_splitGamChB) &&
                        (d->m_optGamR) &&
                        (d->m_optGamG) &&
                        (d->m_optGamB) &&
                        ((writeOption == d->m_optGamR) ||
                        (writeOption == d->m_optGamG) ||
                        (writeOption == d->m_optGamB))) {
                    // check if the current gamma values are identical. if they are identical,
                    // uncheck the "Separate color intensity tables" checkbox
                    QVariant redGamma = d->m_optGamR->value();
                    QVariant greenGamma = d->m_optGamG->value();
                    QVariant blueGamma = d->m_optGamB->value();
                    if ((redGamma == greenGamma) && (greenGamma == blueGamma)) {
                        d->m_splitGamChB->setChecked(false);
                        // set the values to the common gamma widget
                        d->m_commonGamma->setValues(redGamma);
                    } else {
                        d->m_splitGamChB->setChecked(true);
                    }
                }
                return true;
            }
        }
    }
```

#### AUTO 


```{c}
auto it = optionsMap.constBegin();
```

#### RANGE FOR STATEMENT 


```{c}
for (int sizeCode: qAsConst(m_sizeCodes)) {
        QSizeF size = QPageSize::size((QPageSize::PageSizeId)sizeCode, QPageSize::Millimeter);
        size.transpose();
        if (mmToDispUnit(size.width()) > widthInDispUnit) {
            continue;
        }
        if (mmToDispUnit(size.height()) > heightInDispUnit) {
            continue;
        }
        QString name = QPageSize::name((QPageSize::PageSizeId)sizeCode) +
        i18nc("Page size landscape", " Landscape");
        m_scanareaPapersize->addItem(name , size);
    }
```

#### AUTO 


```{c}
const auto optionsList = getOptionsList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : deviceList) {
        KSaneWidget::DeviceInfo newDevice;
        newDevice.model = device->model();
        newDevice.vendor = device->vendor();
        newDevice.name = device->name();
        newDevice.type = device->type();
        list << newDevice;
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (int sizeCode: m_sizeCodes) {
        QSizeF size = QPageSize::size((QPageSize::PageSizeId)sizeCode, QPageSize::Millimeter);
        size.transpose();
        if (mmToDispUnit(size.width()) > widthInDispUnit) {
            continue;
        }
        if (mmToDispUnit(size.height()) > heightInDispUnit) {
            continue;
        }
        QString name = QPageSize::name((QPageSize::PageSizeId)sizeCode) +
        i18nc("Page size landscape", " Landscape");
        m_scanareaPapersize->addItem(name , size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &option : qAsConst(d->m_optList)) {
        connect(option, &KSaneOption::optionsNeedReload, d, &KSaneWidgetPrivate::reloadOptions);
        connect(option, &KSaneOption::valuesNeedReload, d, &KSaneWidgetPrivate::scheduleValuesReload);

        if (option->needsPolling()) {
            d->m_pollList.append(option);
            if (option->type() == KSaneOption::TypeBool) {
                connect( option, &KSaneOption::valueChanged,
                        [=]( const QVariant &newValue ) { Q_EMIT buttonPressed(option->name(), option->title(), newValue.toBool()); } );
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto option : optionsList) {
        if (m_handledOptions.find(option->name()) != m_handledOptions.end()) {
            continue;
        }
        if (option->type() != KSaneOption::TypeDetectFail) {
            KSaneOptionWidget *widget = createOptionWidget(m_otherOptsTab, option);
            if (widget != nullptr) {
                other_layout->addWidget(widget);
            }
        }
    }
```

#### AUTO 


```{c}
const auto size = m_availableSizesList.at(i);
```

#### AUTO 


```{c}
const auto optionsList = q->getOptionsList();
```

#### RANGE FOR STATEMENT 


```{c}
for (int sizeCode: qAsConst(m_sizeCodes)) {
        QSizeF size = QPageSize::size((QPageSize::PageSizeId)sizeCode, QPageSize::Millimeter);
        if (mmToDispUnit(size.width() - PageSizeWiggleRoom) > widthInDispUnit) {
            continue;
        }
        if (mmToDispUnit(size.height() - PageSizeWiggleRoom) > heightInDispUnit) {
            continue;
        }
        m_scanareaPapersize->addItem(QPageSize::name((QPageSize::PageSizeId)sizeCode), size);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
            m_previewViewer->setMultiselectionEnabled(!scanSourceADF());
        }
```

#### AUTO 


```{c}
const auto &value
```

#### CONST EXPRESSION 


```{c}
static constexpr int PageSizeWiggleRoom = 2;
```

#### AUTO 


```{c}
const auto &option
```

#### AUTO 


```{c}
const auto &internalValue = internalValues.at(i);
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &value : list) {
        if (value.type() == static_cast<QVariant::Type>(QMetaType::Int)) {
            addItem(getStringWithUnitForInteger(value.toInt()), value);
        } else if (value.type() == static_cast<QVariant::Type>(QMetaType::Float)) {
            addItem(getStringWithUnitForFloat(value.toFloat()), value);
        } else {
            addItem(value.toString(), value);
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=]( const QVariant &newValue ) { Q_EMIT buttonPressed(option->name(), option->title(), newValue.toBool()); }
```

#### RANGE FOR STATEMENT 


```{c}
for (int sizeCode: qAsConst(m_sizeCodes)) {
        QSizeF size = QPageSize::size((QPageSize::PageSizeId)sizeCode, QPageSize::Millimeter);
        if (mmToDispUnit(size.width()) > widthInDispUnit) {
            continue;
        }
        if (mmToDispUnit(size.height()) > heightInDispUnit) {
            continue;
        }
        m_scanareaPapersize->addItem(QPageSize::name((QPageSize::PageSizeId)sizeCode), size);
    }
```

#### AUTO 


```{c}
const auto &values = m_optRes->valueList();
```

#### RANGE FOR STATEMENT 


```{c}
for (int sizeCode: m_sizeCodes) {
        QSizeF size = QPageSize::size((QPageSize::PageSizeId)sizeCode, QPageSize::Millimeter);
        if (mmToDispUnit(size.width()) > widthInDispUnit) {
            continue;
        }
        if (mmToDispUnit(size.height()) > heightInDispUnit) {
            continue;
        }
        m_scanareaPapersize->addItem(QPageSize::name((QPageSize::PageSizeId)sizeCode), size);
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : deviceList) {
            if (device.name == m_devName) {
                m_vendor    = device.vendor;
                m_model     = device.model;
                Q_EMIT q->openedDeviceInfoUpdated(m_devName, m_vendor, m_model);
                break;
            }
        }
```

#### AUTO 


```{c}
const auto dpr = img->devicePixelRatio();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto option : qAsConst(m_optionsList)) {
        option->readOption();
        // Also read the values
        option->readValue();
    }
```

#### AUTO 


```{c}
auto &writeOption
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto option : qAsConst(m_optionsList)) {
        option->readValue();
    }
```

#### AUTO 


```{c}
const auto optionsList = m_ksaneCoreInterface->getOptionsList();
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto option : optionsList) {
        if (m_handledOptions.find(option->name()) != m_handledOptions.end()) {
            continue;
        }
        if (option->type() != KSaneOption::TypeDetectFail) {
            KSaneOptionWidget *widget = createOptionWidget(m_otherOptsTab, option);
            if (widget != nullptr) {
                otherLayout->addWidget(widget);
            }
        }
    }
```

#### AUTO 


```{c}
const auto it = optionMapCopy.find(d->m_optionsList.at(i)->name());
```

#### AUTO 


```{c}
const auto sizeCode
```

#### CONST EXPRESSION 


```{c}
static constexpr int ActiveSelection = 100000;
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &device : deviceList) {
        KSaneWidget::DeviceInfo newDevice;
        newDevice.model = device.model;
        newDevice.vendor = device.vendor;
        newDevice.name = device.name;
        newDevice.type = device.type;
        list << newDevice;
    }
```

