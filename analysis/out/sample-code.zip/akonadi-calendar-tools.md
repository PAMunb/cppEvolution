#### AUTO 


```{c}
const auto timeZone = calendar->timeZone();
```

#### AUTO 


```{c}
auto mimeTypeSet = QSet<QString>(mimeTypes.begin(), mimeTypes.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            const QStringList contentMimeTypes = collection.contentMimeTypes();
            auto collectionMimeTypeSet = QSet<QString>(contentMimeTypes.begin(), contentMimeTypes.end());

            if (!mimeTypeSet.intersect(collectionMimeTypeSet).isEmpty()) {
                QString colId = QString::number(collection.id()).leftJustified(6, QLatin1Char(' '));
                colId += QLatin1String("- ");

                bool readOnly = !(collection.rights() & Akonadi::Collection::CanCreateItem
                                  || collection.rights() & Akonadi::Collection::CanChangeItem
                                  || collection.rights() & Akonadi::Collection::CanDeleteItem);

                QString readOnlyString = readOnly ? i18n("(Read only)") + QLatin1Char(' ') : QString();

                cout << colId.toLocal8Bit().data() << readOnlyString.toLocal8Bit().constData() << collection.displayName().toLocal8Bit().data() << endl;
            }
        }
```

#### AUTO 


```{c}
const auto attachments = incidence->attachments();
```

#### AUTO 


```{c}
auto janitor = new CalendarJanitor(janitorOptions);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (!incidence->attachments().isEmpty()) {
            const auto attachments = incidence->attachments();
            for (const KCalendarCore::Attachment &attachment : attachments) {
                if (!attachment.isUri()) {
                    numAttachments++;
                    totalAttachmentSize += attachment.size();
                }
            }
        }

        m_counts[incidence->type()]++;

        if (incidenceIsOld(incidence)) {
            if (!incidence->alarms().isEmpty()) {
                numOldAlarms++;
            }
            numOldIncidences++;
        }

        numAttachments += incidence->attachments().count();

        if (item.remoteId().isEmpty()) {
            numEmptyRID++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : rawEvents) {
        if (calendar->incidence(event->uid()) != nullptr) {
            if (m_variables->isVerbose()) {
                cout << i18n("Insert Event skipped, because UID \"%1\" is already known. <Verbose>", event->uid()).toLocal8Bit().data()
                     << endl;
            } else {
                qCInfo(KONSOLEKALENDAR_LOG) << "Event with UID " << event->uid() << "is already in calendar, skipping import of this Event.";
            }
            continue;
        }
        if (m_variables->isVerbose()) {
            cout << i18n("Add Event with UID \"%1\". <Verbose>", event->uid()).toLocal8Bit().data()
                 << endl;
        }
        if (m_variables->isDryRun()) {
            continue;
        }
        t.start();
        calendar->addEvent(event);
        loop.exec();
        qCDebug(KONSOLEKALENDAR_LOG) << "Creation of event took " << t.elapsed() << "ms." << "status: "<< (calendar->incidence(event->uid()) != nullptr);
        if (calendar->incidence(event->uid()) == nullptr) {
            return false;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        const QList<KCalendarCore::Incidence::Ptr> existingIncidences = m_incidenceMap.values(incidence->instanceIdentifier());

        if (existingIncidences.count() == 1) {
            continue;
        }

        for (int i = 1; i < existingIncidences.count(); ++i) {
            printFound(item);
            if (m_fixingEnabled) {
                KCalendarCore::Incidence::Ptr existingIncidence = existingIncidences.at(i);
                Akonadi::Item item = m_incidenceToItem.value(existingIncidence);
                Q_ASSERT(item.isValid());
                if (item.isValid()) {
                    existingIncidence->recreate();
                    m_changer->modifyIncidence(item);
                    m_pendingModifications++;
                    m_incidenceMap.remove(incidence->instanceIdentifier(), existingIncidence);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto ifj = new Akonadi::ItemFetchJob(collection, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString &collection : collections) {
            bool ok = false;
            int num = collection.toInt(&ok);
            if (ok) {
                ids << num;
            } else {
                printCollectionsUsage();
                return -1;
            }

            if (ids.isEmpty()) {
                printCollectionsUsage();
                return -1;
            } else {
                janitorOptions.setCollections(ids);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        KCalendarCore::Event::Ptr event = incidence.dynamicCast<KCalendarCore::Event>();
        if (!event) {
            continue;
        }

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();

        bool modify = false;
        QString message;
        if (!start.isValid() && end.isValid()) {
            modify = true;
            printFound(item);
            event->setDtStart(end);
        } else if (!start.isValid() && !end.isValid()) {
            modify = true;
            printFound(item);
            event->setDtStart(QDateTime::currentDateTime());
            event->setDtEnd(event->dtStart().addSecs(3600));
        }

        if (modify) {
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->summary().isEmpty() && incidence->description().isEmpty() && incidence->attachments().isEmpty()) {
            printFound(item);
            deleteIncidence(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
        if (m_options.testCollection(collection.id())) {
            m_collectionsToProcess << collection;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->type() != KCalendarCore::Incidence::TypeJournal) {
            continue;
        }

        if (!incidence->dtStart().isValid()) {
            printFound(item);
            incidence->setDtStart(QDateTime::currentDateTime());
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### AUTO 


```{c}
const auto rawEvents = cal->rawEvents();
```

#### AUTO 


```{c}
auto job = new Akonadi::AgentInstanceCreateJob(type);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        const QString parentUid = incidence->relatedTo();
        if (!parentUid.isEmpty() && !m_calendar->incidence(parentUid)) {
            printFound(item, i18n("The following incidences are children of nonexistent parents"));
            if (m_fixingEnabled) {
                incidence->setRelatedTo(QString());
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### AUTO 


```{c}
auto ifj = qobject_cast<Akonadi::ItemFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
            KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
            Q_ASSERT(incidence);
            m_incidenceMap.insert(incidence->instanceIdentifier(), incidence);
            m_incidenceToItem.insert(incidence, item);
        }
```

#### AUTO 


```{c}
auto konsolekalendar = new KonsoleKalendar(&variables);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        if (!incidence->attachments().isEmpty()) {
            const auto attachments = incidence->attachments();
            for (const KCalendarCore::Attachment &attachment : attachments) {
                if (!attachment.isUri()) {
                    numAttachments++;
                    totalAttachmentSize += attachment.size();
                }
            }
        }

        m_counts[incidence->type()]++;

        if (incidenceIsOld(incidence)) {
            if (!incidence->alarms().isEmpty()) {
                numOldAlarms++;
            }
            numOldIncidences++;
        }

        numAttachments += incidence->attachments().count();

        if (item.remoteId().isEmpty()) {
            numEmptyRID++;
        }
    }
```

#### AUTO 


```{c}
const auto &event
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        const QList<KCalendarCore::Incidence::Ptr> existingIncidences = m_incidenceMap.values(incidence->instanceIdentifier());

        if (existingIncidences.count() == 1) {
            continue;
        }

        for (int i = 1; i < existingIncidences.count(); ++i) {
            printFound(item);
            if (m_fixingEnabled) {
                KCalendarCore::Incidence::Ptr existingIncidence = existingIncidences.at(i);
                Akonadi::Item item = m_incidenceToItem.value(existingIncidence);
                Q_ASSERT(item.isValid());
                if (item.isValid()) {
                    existingIncidence->recreate();
                    m_changer->modifyIncidence(item);
                    m_pendingModifications++;
                    m_incidenceMap.remove(incidence->instanceIdentifier(), existingIncidence);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->recurs() && incidence->hasRecurrenceId() && !m_calendar->incidence(incidence->uid())) {
            printFound(item);
            if (m_fixingEnabled) {
                bool modified = false;

                QDateTime recId = incidence->recurrenceId();
                QDateTime start = incidence->dtStart();
                QDateTime end = incidence->dateTime(KCalendarCore::Incidence::RoleEnd);

                KCalendarCore::Event::Ptr event = incidence.dynamicCast<KCalendarCore::Event>();
                KCalendarCore::Todo::Ptr todo = incidence.dynamicCast<KCalendarCore::Todo>();

                if (event && start.isValid() && end.isValid()) {
                    modified = true;
                    const int duration = start.daysTo(end.toTimeSpec(start.timeSpec()));
                    incidence->setDtStart(recId);
                    event->setDtEnd(recId.addDays(duration));
                } else if (todo && start.isValid()) {
                    modified = true;
                    incidence->setDtStart(recId);

                    if (end.isValid()) {
                        const int duration = start.daysTo(end.toTimeSpec(start.timeSpec()));
                        todo->setDtDue(recId.addDays(duration));
                    }
                }

                if (modified) {
                    m_pendingModifications++;
                    incidence->recreate(); // change uid
                    incidence->clearRecurrence(); // make it non-recurring
                    incidence->setRecurrenceId(QDateTime());
                    m_changer->modifyIncidence(item);
                }
            }
        }
    }
```

#### AUTO 


```{c}
auto mimeTypeSet = mimeTypes.toSet();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
            KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
            Q_ASSERT(incidence);
            m_incidenceMap.insert(incidence->instanceIdentifier(), incidence);
            m_incidenceToItem.insert(incidence, item);
        }
```

#### AUTO 


```{c}
auto collectionMimeTypeSet = QSet<QString>(contentMimeTypes.begin(), contentMimeTypes.end());
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        KCalendarCore::Todo::Ptr todo = incidence.dynamicCast<KCalendarCore::Todo>();
        if (!todo) {
            continue;
        }

        QDateTime start = todo->dtStart();
        QDateTime due = todo->dtDue();
        bool modify = false;
        if (todo->recurs() && !start.isValid() && due.isValid()) {
            modify = true;
            printFound(item);
            todo->setDtStart(due);
        }

        if (todo->recurs() && !start.isValid() && !due.isValid()) {
            modify = true;
            printFound(item);
            todo->setDtStart(QDateTime::currentDateTime());
        }

        if (modify) {
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### AUTO 


```{c}
auto inst =  job->instance();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        KCalendarCore::Event::Ptr event = incidence.dynamicCast<KCalendarCore::Event>();
        if (!event) {
            continue;
        }

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();

        bool modify = false;
        QString message;
        if (!start.isValid() && end.isValid()) {
            modify = true;
            printFound(item);
            event->setDtStart(end);
        } else if (!start.isValid() && !end.isValid()) {
            modify = true;
            printFound(item);
            event->setDtStart(QDateTime::currentDateTime());
            event->setDtEnd(event->dtStart().addSecs(3600));
        }

        if (modify) {
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Event::Ptr &event : sortedList) {
                            status &= printEvent(&ts, event, event->dtStart().date());
                        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        const QString parentUid = incidence->relatedTo();
        if (!parentUid.isEmpty() && !m_calendar->incidence(parentUid)) {
            printFound(item, i18n("The following incidences are children of nonexistent parents"));
            if (m_fixingEnabled) {
                incidence->setRelatedTo(QString());
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (!incidence->alarms().isEmpty() && incidenceIsOld(incidence)) {
            incidence->clearAlarms();
            m_pendingModifications++;
            m_changer->modifyIncidence(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        const QString parentUid = incidence->relatedTo();
        if (!parentUid.isEmpty() && !m_calendar->incidence(parentUid)) {
            printFound(item, i18n("The following incidences are children of nonexistent parents"));
            if (m_fixingEnabled) {
                incidence->setRelatedTo(QString());
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->recurs() && incidence->hasRecurrenceId() && !m_calendar->incidence(incidence->uid())) {
            printFound(item);
            if (m_fixingEnabled) {
                bool modified = false;

                QDateTime recId = incidence->recurrenceId();
                QDateTime start = incidence->dtStart();
                QDateTime end = incidence->dateTime(KCalendarCore::Incidence::RoleEnd);

                KCalendarCore::Event::Ptr event = incidence.dynamicCast<KCalendarCore::Event>();
                KCalendarCore::Todo::Ptr todo = incidence.dynamicCast<KCalendarCore::Todo>();

                if (event && start.isValid() && end.isValid()) {
                    modified = true;
                    const int duration = start.daysTo(end.toTimeSpec(start.timeSpec()));
                    incidence->setDtStart(recId);
                    event->setDtEnd(recId.addDays(duration));
                } else if (todo && start.isValid()) {
                    modified = true;
                    incidence->setDtStart(recId);

                    if (end.isValid()) {
                        const int duration = start.daysTo(end.toTimeSpec(start.timeSpec()));
                        todo->setDtDue(recId.addDays(duration));
                    }
                }

                if (modified) {
                    m_pendingModifications++;
                    incidence->recreate(); // change uid
                    incidence->clearRecurrence(); // make it non-recurring
                    incidence->setRecurrenceId(QDateTime());
                    m_changer->modifyIncidence(item);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        const QList<KCalendarCore::Incidence::Ptr> existingIncidences = m_incidenceMap.values(incidence->instanceIdentifier());

        if (existingIncidences.count() == 1) {
            continue;
        }

        for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
            if (existingIncidence != incidence && *incidence == *existingIncidence) {
                printFound(item);
                deleteIncidence(item);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->summary().isEmpty() && incidence->description().isEmpty()
            && incidence->attachments().isEmpty()) {
            printFound(item);
            deleteIncidence(item);
        }
    }
```

#### AUTO 


```{c}
auto job = new Akonadi::CollectionFetchJob(Akonadi::Collection::root(), Akonadi::CollectionFetchJob::Recursive);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        if (!incidence->alarms().isEmpty() && incidenceIsOld(incidence)) {
            incidence->clearAlarms();
            m_pendingModifications++;
            m_changer->modifyIncidence(item);
        }
    }
```

#### AUTO 


```{c}
auto cfj = qobject_cast<Akonadi::CollectionFetchJob *>(job);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            const QStringList contentMimeTypesLst = collection.contentMimeTypes();
            QSet<QString> collectionMimeTypeSet = QSet<QString>(contentMimeTypesLst.begin(), contentMimeTypesLst.end());
            if (mimeTypeSet.intersects(collectionMimeTypeSet)) {
                m_collections << collection;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->uid().isEmpty()) {
            printFound(item);
            if (m_fixingEnabled) {
                incidence->recreate();
                m_pendingModifications++;
                m_changer->modifyIncidence(item);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
            Q_ASSERT(incidence);
            m_calendar->addIncidence(incidence);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        const QList<KCalendarCore::Incidence::Ptr> existingIncidences = m_incidenceMap.values(incidence->instanceIdentifier());

        if (existingIncidences.count() == 1) {
            continue;
        }

        for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
            if (existingIncidence != incidence && *incidence == *existingIncidence) {
                printFound(item);
                deleteIncidence(item);
                break;
            }
        }
    }
```

#### AUTO 


```{c}
auto exp = new KCalUtils::HtmlExport(calendar.data(), &htmlSettings);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->uid().isEmpty()) {
            printFound(item);
            if (m_fixingEnabled) {
                incidence->recreate();
                m_pendingModifications++;
                m_changer->modifyIncidence(item);
            }
        }
    }
```

#### AUTO 


```{c}
auto inst = job->instance();
```

#### AUTO 


```{c}
const auto timeZone = m_variables->getCalendar()->timeZone();
```

#### AUTO 


```{c}
const auto collections = m_collectionLoader->collections();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        KCalendarCore::Event::Ptr event = incidence.dynamicCast<KCalendarCore::Event>();
        if (!event) {
            continue;
        }

        QDateTime start = event->dtStart();
        QDateTime end = event->dtEnd();

        bool modify = false;
        QString message;
        if (!start.isValid() && end.isValid()) {
            modify = true;
            printFound(item);
            event->setDtStart(end);
        } else if (!start.isValid() && !end.isValid()) {
            modify = true;
            printFound(item);
            event->setDtStart(QDateTime::currentDateTime());
            event->setDtEnd(event->dtStart().addSecs(3600));
        }

        if (modify) {
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            const QStringList contentMimeTypes = collection.contentMimeTypes();
            auto collectionMimeTypeSet = QSet<QString>(contentMimeTypes.begin(), contentMimeTypes.end());

            if (!mimeTypeSet.intersect(collectionMimeTypeSet).isEmpty()) {
                QString colId = QString::number(collection.id()).leftJustified(6, QLatin1Char(' '));
                colId += QLatin1String("- ");

                bool readOnly = !(collection.rights() & Akonadi::Collection::CanCreateItem || collection.rights() & Akonadi::Collection::CanChangeItem
                                  || collection.rights() & Akonadi::Collection::CanDeleteItem);

                QString readOnlyString = readOnly ? i18n("(Read only)") + QLatin1Char(' ') : QString();

                cout << colId.toLocal8Bit().data() << readOnlyString.toLocal8Bit().constData() << collection.displayName().toLocal8Bit().data() << endl;
            }
        }
```

#### AUTO 


```{c}
auto events = new Event::List(calendar->rawEvents(EventSortStartDate, SortDirectionAscending));
```

#### AUTO 


```{c}
const auto collections = cfj->collections();
```

#### AUTO 


```{c}
auto backuper = new Backuper();
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->summary().isEmpty() && incidence->description().isEmpty() && incidence->attachments().isEmpty()) {
            printFound(item);
            deleteIncidence(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            const QStringList contentMimeTypes = collection.contentMimeTypes();
            auto collectionMimeTypeSet = QSet<QString>(contentMimeTypes.begin(), contentMimeTypes.end());

            if (mimeTypeSet.intersects(collectionMimeTypeSet)) {
                QString colId = QString::number(collection.id()).leftJustified(6, QLatin1Char(' '));
                colId += QLatin1String("- ");

                bool readOnly = !(collection.rights() & Akonadi::Collection::CanCreateItem || collection.rights() & Akonadi::Collection::CanChangeItem
                                  || collection.rights() & Akonadi::Collection::CanDeleteItem);

                QString readOnlyString = readOnly ? i18n("(Read only)") + QLatin1Char(' ') : QString();

                cout << colId.toLocal8Bit().data() << readOnlyString.toLocal8Bit().constData() << collection.displayName().toLocal8Bit().data() << endl;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : items) {
            KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
            Q_ASSERT(incidence);
            m_calendar->addIncidence(incidence);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
            KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
            Q_ASSERT(incidence);
            m_incidenceMap.insert(incidence->instanceIdentifier(), incidence);
            m_incidenceToItem.insert(incidence, item);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        KCalendarCore::Todo::Ptr todo = incidence.dynamicCast<KCalendarCore::Todo>();
        if (!todo) {
            continue;
        }

        QDateTime start = todo->dtStart();
        QDateTime due = todo->dtDue();
        bool modify = false;
        if (todo->recurs() && !start.isValid() && due.isValid()) {
            modify = true;
            printFound(item);
            todo->setDtStart(due);
        }

        if (todo->recurs() && !start.isValid() && !due.isValid()) {
            modify = true;
            printFound(item);
            todo->setDtStart(QDateTime::currentDateTime());
        }

        if (modify) {
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            if (!m_requestedCollectionIds.isEmpty() && !m_requestedCollectionIds.contains(collection.id())) {
                continue;
            }
            const QStringList contentMimeTypesLst = collection.contentMimeTypes();
            QSet<QString> collectionMimeTypeSet = QSet<QString>(contentMimeTypesLst.begin(), contentMimeTypesLst.end());
            if (!mimeTypeSet.intersect(collectionMimeTypeSet).isEmpty()) {
                m_collections << collection;
                loadCollection(collection);
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        if (incidence->uid().isEmpty()) {
            printFound(item);
            if (m_fixingEnabled) {
                incidence->recreate();
                m_pendingModifications++;
                m_changer->modifyIncidence(item);
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        KCalendarCore::Todo::Ptr todo = incidence.dynamicCast<KCalendarCore::Todo>();
        if (!todo) {
            continue;
        }

        QDateTime start = todo->dtStart();
        QDateTime due = todo->dtDue();
        bool modify = false;
        if (todo->recurs() && !start.isValid() && due.isValid()) {
            modify = true;
            printFound(item);
            todo->setDtStart(due);
        }

        if (todo->recurs() && !start.isValid() && !due.isValid()) {
            modify = true;
            printFound(item);
            todo->setDtStart(QDateTime::currentDateTime());
        }

        if (modify) {
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        if (incidence->type() != KCalendarCore::Incidence::TypeJournal) {
            continue;
        }

        if (!incidence->dtStart().isValid()) {
            printFound(item);
            incidence->setDtStart(QDateTime::currentDateTime());
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        const QList<KCalendarCore::Incidence::Ptr> existingIncidences = m_incidenceMap.values(incidence->instanceIdentifier());

        if (existingIncidences.count() == 1) {
            continue;
        }

        for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
            if (existingIncidence != incidence && *incidence == *existingIncidence) {
                printFound(item);
                deleteIncidence(item);
                break;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Incidence::Ptr &existingIncidence : existingIncidences) {
            if (existingIncidence != incidence && *incidence == *existingIncidence) {
                printFound(item);
                deleteIncidence(item);
                break;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        if (incidence->summary().isEmpty() && incidence->description().isEmpty() && incidence->attachments().isEmpty()) {
            printFound(item);
            deleteIncidence(item);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (incidence->type() != KCalendarCore::Incidence::TypeJournal) {
            continue;
        }

        if (!incidence->dtStart().isValid()) {
            printFound(item);
            incidence->setDtStart(QDateTime::currentDateTime());
            if (m_fixingEnabled) {
                m_changer->modifyIncidence(item);
                m_pendingModifications++;
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Collection &collection : collections) {
            const QStringList contentMimeTypesLst = collection.contentMimeTypes();
            QSet<QString> collectionMimeTypeSet = QSet<QString>(contentMimeTypesLst.begin(), contentMimeTypesLst.end());
            if (!mimeTypeSet.intersect(collectionMimeTypeSet).isEmpty()) {
                m_collections << collection;
            }
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        const QList<KCalendarCore::Incidence::Ptr> existingIncidences = m_incidenceMap.values(incidence->instanceIdentifier());

        if (existingIncidences.count() == 1) {
            continue;
        }

        for (int i = 1; i < existingIncidences.count(); ++i) {
            printFound(item);
            if (m_fixingEnabled) {
                KCalendarCore::Incidence::Ptr existingIncidence = existingIncidences.at(i);
                Akonadi::Item item = m_incidenceToItem.value(existingIncidence);
                Q_ASSERT(item.isValid());
                if (item.isValid()) {
                    existingIncidence->recreate();
                    m_changer->modifyIncidence(item);
                    m_pendingModifications++;
                    m_incidenceMap.remove(incidence->instanceIdentifier(), existingIncidence);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto &event : rawEvents) {
        if (calendar->incidence(event->uid()) != nullptr) {
            if (m_variables->isVerbose()) {
                cout << i18n("Insert Event skipped, because UID \"%1\" is already known. <Verbose>", event->uid()).toLocal8Bit().data() << endl;
            } else {
                qCInfo(KONSOLEKALENDAR_LOG) << "Event with UID " << event->uid() << "is already in calendar, skipping import of this Event.";
            }
            continue;
        }
        if (m_variables->isVerbose()) {
            cout << i18n("Add Event with UID \"%1\". <Verbose>", event->uid()).toLocal8Bit().data() << endl;
        }
        if (m_variables->isDryRun()) {
            continue;
        }
        t.start();
        calendar->addEvent(event);
        loop.exec();
        qCDebug(KONSOLEKALENDAR_LOG) << "Creation of event took " << t.elapsed() << "ms."
                                     << "status: " << (calendar->incidence(event->uid()) != nullptr);
        if (calendar->incidence(event->uid()) == nullptr) {
            return false;
        }
    }
```

#### AUTO 


```{c}
const auto timeZone  = m_variables->getCalendar()->timeZone();
```

#### RANGE FOR STATEMENT 


```{c}
for (const KCalendarCore::Attachment &attachment : attachments) {
                if (!attachment.isUri()) {
                    numAttachments++;
                    totalAttachmentSize += attachment.size();
                }
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (!incidence->attachments().isEmpty()) {
            const auto attachments = incidence->attachments();
            for (const KCalendarCore::Attachment &attachment : attachments) {
                if (!attachment.isUri()) {
                    numAttachments++;
                    totalAttachmentSize += attachment.size();
                }
            }
        }

        m_counts[incidence->type()]++;

        if (incidenceIsOld(incidence)) {
            if (!incidence->alarms().isEmpty()) {
                numOldAlarms++;
            }
            numOldIncidences++;
        }

        numAttachments += incidence->attachments().count();

        if (item.remoteId().isEmpty()) {
            numEmptyRID++;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : std::as_const(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = Akonadi::CalendarUtils::incidence(item);
        if (incidence->recurs() && incidence->hasRecurrenceId() && !m_calendar->incidence(incidence->uid())) {
            printFound(item);
            if (m_fixingEnabled) {
                bool modified = false;

                QDateTime recId = incidence->recurrenceId();
                QDateTime start = incidence->dtStart();
                QDateTime end = incidence->dateTime(KCalendarCore::Incidence::RoleEnd);

                KCalendarCore::Event::Ptr event = incidence.dynamicCast<KCalendarCore::Event>();
                KCalendarCore::Todo::Ptr todo = incidence.dynamicCast<KCalendarCore::Todo>();

                if (event && start.isValid() && end.isValid()) {
                    modified = true;
                    const int duration = start.daysTo(end.toTimeSpec(start.timeSpec()));
                    incidence->setDtStart(recId);
                    event->setDtEnd(recId.addDays(duration));
                } else if (todo && start.isValid()) {
                    modified = true;
                    incidence->setDtStart(recId);

                    if (end.isValid()) {
                        const int duration = start.daysTo(end.toTimeSpec(start.timeSpec()));
                        todo->setDtDue(recId.addDays(duration));
                    }
                }

                if (modified) {
                    m_pendingModifications++;
                    incidence->recreate(); // change uid
                    incidence->clearRecurrence(); // make it non-recurring
                    incidence->setRecurrenceId(QDateTime());
                    m_changer->modifyIncidence(item);
                }
            }
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Akonadi::Item &item : qAsConst(m_itemsToProcess)) {
        KCalendarCore::Incidence::Ptr incidence = CalendarSupport::incidence(item);
        if (!incidence->alarms().isEmpty() && incidenceIsOld(incidence)) {
            incidence->clearAlarms();
            m_pendingModifications++;
            m_changer->modifyIncidence(item);
        }
    }
```

