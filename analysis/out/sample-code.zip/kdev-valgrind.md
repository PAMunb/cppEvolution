#### AUTO 


```{c}
auto item = static_cast<Function*>(index.internalPointer());
```

#### AUTO 


```{c}
auto iface = pluginController->pluginForExtension(QStringLiteral("org.kdevelop.IExecutePlugin"))->extension<IExecutePlugin>();
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWidget* view, const QString& name) {
        Q_ASSERT(view);

        addTab(view, name);
        setCurrentWidget(view);
        setMovable(true);
    }
```

#### AUTO 


```{c}
auto value
```

#### AUTO 


```{c}
auto item = addItemInt(name, reference, defaultValue);
```

#### AUTO 


```{c}
auto function = m_model->addFunction(functionName, sourceFile, binaryFile);
```

#### LAMBDA EXPRESSION 


```{c}
[treesModel](const QModelIndex& current, const QModelIndex&) {
        auto snapshot = static_cast<MassifSnapshot*>(current.internalPointer());
        treesModel->setStringList(snapshot->heapTree);
    }
```

#### AUTO 


```{c}
static const auto xmlStartRegex = QRegularExpression("\\s*<");
```

#### AUTO 


```{c}
auto sourceUrl = QUrl::fromLocalFile(idString.mid(0, colonPos)).adjusted(QUrl::NormalizePathSegments);
```

#### LAMBDA EXPRESSION 


```{c}
[startButton]() {
        startButton->setEnabled(false);
    }
```

#### AUTO 


```{c}
auto segmentProblem = stacks.first().toIProblem(showInstructionPointer);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actions) {
        if (action->isChecked()) {
            dataSelected += action->data().toString();
            textSelected += action->text();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex&, const QModelIndex&, const QVector<int>&) {

        emitDataChanged(this);
    }
```

#### AUTO 


```{c}
auto eventsModel = new FunctionEventsModel(model);
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex& currentProxyIndex, const QModelIndex&) {

        auto sourceIndex = functionsProxyModel->mapToSource(currentProxyIndex);
        auto item = static_cast<CachegrindFunction*>(sourceIndex.internalPointer());

        if (item) {
            ui->nameLabel->setText(item->functionName);
            ui->sourceLabel->setText(item->fileNames.join("\n\n"));
        } else {
            ui->nameLabel->clear();
            ui->sourceLabel->clear();
        }
    }
```

#### AUTO 


```{c}
auto snapshot = static_cast<Snapshot*>(index.internalPointer());
```

#### LAMBDA EXPRESSION 


```{c}
[startFunction]() {
                         startFunction();
                    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, outputFile]() {
        m_kcachegrindProcess->start(CallgrindConfig::kcachegrindExecutablePath(),
                                    { outputFile->fileName() });
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](Qt::Orientation, int, int) {
        ui->callersView->header()->resizeSections(QHeaderView::ResizeToContents);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, outputFile]() {
        m_visualizerProcess->start(MassifConfig::visualizerExecutablePath(),
                                   { outputFile->fileName() });
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto value : m_values) {
        value->save(config, m_configKeyPrefix);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, tcpServer]() {
        auto tcpSocket = tcpServer->nextPendingConnection();

        connect(tcpSocket, &QTcpSocket::readyRead, this, [this, tcpSocket]() {
            QStringList lines;
            while (!tcpSocket->atEnd()) {
                lines += tcpSocket->readLine().trimmed();
            }
            processValgrindOutput(lines);
        });
    }
```

#### AUTO 


```{c}
auto problems = parseXml(m_tool->name(), m_xmlOutput.join(" "), m_config->showInstructionPointer());
```

#### AUTO 


```{c}
auto segmentProblem = stacks.first().toIProblem(toolName, showInstructionPointer);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : callersInformation) {
        value += info->eventValue(type);
    }
```

#### AUTO 


```{c}
auto eventsModel = new CallgrindFunctionEventsModel(model);
```

#### AUTO 


```{c}
const auto actions = button->menu()->actions();
```

#### LAMBDA EXPRESSION 


```{c}
[this, outputFile]() {
                launchVisualizer(outputFile->fileName());
            }
```

#### RANGE FOR STATEMENT 


```{c}
for (const auto& segment : otherSegments) {
        if (!segment.stacks.isEmpty()) {
            problem->addDiagnostic(segment.toIProblem(toolName, showInstructionPointer));
        }
    }
```

#### AUTO 


```{c}
auto enabled = text.split(QChar(','));
```

#### LAMBDA EXPRESSION 


```{c}
[this](Qt::Orientation, int, int) {
        ui->calleesView->header()->resizeSections(QHeaderView::ResizeToContents);
    }
```

#### AUTO 


```{c}
const auto enabled = value.split(QLatin1Char(','));
```

#### LAMBDA EXPRESSION 


```{c}
[this, outputFile]() {
        m_kcachegrindProcess->start(Settings::kcachegrindExecutablePath(),
                                    { outputFile->fileName() });
    }
```

#### AUTO 


```{c}
auto itemInt = addCmdItemInt(QStringLiteral("freelistVol"), m_freelistVol, 20000000, QStringLiteral("freelist-vol"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto value : qAsConst(m_values)) {
        value->load(config, m_configKeyPrefix);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this](QWidget* view, const QString& name){
        Q_ASSERT(view);

        addTab(view, name);
        setCurrentWidget(view);
        setMovable(true);
    }
```

#### AUTO 


```{c}
auto job = KIO::stat(url, KIO::StatJob::SourceSide, 0);
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                ui->launchVisualizerButton->setEnabled(true);
            }
```

#### AUTO 


```{c}
auto startVisualizer = [this, outputFile]() {
        m_visualizerProcess->start(MassifConfig::visualizerExecutablePath(),
                                   { outputFile->fileName() });
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart)
            KMessageBox::error(qApp->activeWindow(),
                               i18n("Unable to launch the process %1 (%2)", m_execPath, error),
                               i18n("Valgrind Error"));
        deleteLater();
    }
```

#### AUTO 


```{c}
auto functionsProxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto function = static_cast<CallgrindFunction*>(index.internalPointer());
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
        delete widget(index);
        removeTab(index);
    }
```

#### AUTO 


```{c}
auto item = new Function;
```

#### LAMBDA EXPRESSION 


```{c}
[this](int, QProcess::ExitStatus) {
        deleteLater();
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : menu->actions()) {
        if (action->isChecked()) {
            selected += action->text();
        }
    }
```

#### AUTO 


```{c}
auto action = new QAction(text, this);
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stack& stack : stacks) {
        problem->addDiagnostic(stack.toIProblem(toolName, showInstructionPointer));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : allItems) {
        item->setGroup(fullName);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex& currentProxyIndex, const QModelIndex&) {

        auto sourceIndex = functionsProxyModel->mapToSource(currentProxyIndex);
        auto function = static_cast<Function*>(sourceIndex.internalPointer());

        eventsModel->setFunction(function);
        callersModel->setFunction(function);
        calleesModel->setFunction(function);

        if (function) {
            ui->binaryLabel->setText(function->binaryFile);
            ui->sourceLabel->setText(function->sourceFiles.join('\n'));
        } else {
            ui->binaryLabel->clear();
            ui->sourceLabel->clear();
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
        emit hideProgress(this);
    }
```

#### AUTO 


```{c}
auto info = new CallgrindCallInformation(eventValues);
```

#### AUTO 


```{c}
auto callersProxyModel = new QSortFilterProxyModel(this);
```

#### AUTO 


```{c}
auto slot = [button, menu]() {
        button->setText(QChar(' ') + selectedItemsText(menu));
    };
```

#### AUTO 


```{c}
auto itemInt = addCmdItemInt(QStringLiteral("conflictCacheSize"), m_conflictCacheSize, 1000000, QStringLiteral("conflict-cache-size"));
```

#### AUTO 


```{c}
auto ecJob = new KDevelop::ExecuteCompositeJob(KDevelop::ICore::self()->runController(), jobList);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : m_items) {
        if (item->functionName == newItem->functionName) {
            exists = true;

            item->fileNames += newItem->fileNames;
            item->fileNames.removeDuplicates();
            item->fileNames.sort();

            for (int i = 0; i < newItem->eventValues.size(); ++i) {
                item->eventValues[i] += newItem->eventValues[i];
            }

            delete newItem;
        }
    }
```

#### AUTO 


```{c}
auto info
```

#### RANGE FOR STATEMENT 


```{c}
for (const Stack& stack : stacks) {
        problem->addDiagnostic(stack.toIProblem(showInstructionPointer));
    }
```

#### AUTO 


```{c}
auto startVisualizer = [this, outputFile]() {
        m_visualizerProcess->start(Settings::visualizerExecutablePath(),
                                   { outputFile->fileName() });
    };
```

#### LAMBDA EXPRESSION 


```{c}
[this, outputFile]() {
        m_visualizerProcess->start(Settings::visualizerExecutablePath(),
                                   { outputFile->fileName() });
    }
```

#### AUTO 


```{c}
auto sourceIndex = functionsProxyModel->mapToSource(currentProxyIndex);
```

#### AUTO 


```{c}
auto documents = KTextEditor::Editor::instance()->documents();
```

#### AUTO 


```{c}
auto frameProblem = frame.toIProblem(showInstructionPointer);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actions) {
        if (text == QStringLiteral("all")) {
            action->setChecked(true);
        } else if (text == QStringLiteral("none")) {
            action->setChecked(false);
        } else {
            action->setChecked(enabled.contains(action->text()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & line : lines) {
        if (line.isEmpty())
            continue;

        if (line.indexOf(xmlStartRegex) >= 0) { // the line contains XML
            m_xmlOutput << line;
            m_parser->addData(line);
            m_parser->parse();
        }
        else
            m_errorOutput << line;
    }
```

#### AUTO 


```{c}
auto fileUrl = QUrl::fromLocalFile(fileCall.mid(0, colonPosition)).adjusted(QUrl::NormalizePathSegments);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto currentFunction : m_functions) {
        if (currentFunction->name == name && (currentFunction->binaryFile.isEmpty() ||
                                              binaryFile.isEmpty() ||
                                              currentFunction->binaryFile == binaryFile)) {
            function = currentFunction;
            break;
        }
    }
```

#### AUTO 


```{c}
auto itemInt = addCmdItemInt(QStringLiteral("joinListVol"), m_joinListVol, 10, QStringLiteral("join-list-vol"));
```

#### AUTO 


```{c}
static const auto otherSegmentStartXmlName = QStringLiteral("other_segment_start");
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : qAsConst(callersInformation)) {
        count += info->callCount;
    }
```

#### AUTO 


```{c}
auto callersModel = new CallgrindFunctionCallersCalleesModel(model, true);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto value : qAsConst(m_values)) {
        value->save(config, m_configKeyPrefix);
    }
```

#### AUTO 


```{c}
auto action
```

#### AUTO 


```{c}
auto item = static_cast<Function*>(sourceIndex.internalPointer());
```

#### AUTO 


```{c}
auto valgrindJob = m_tool->createJob(launchConfig);
```

#### AUTO 


```{c}
const auto actions = menu()->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto segment : otherSegments) {
        if (!segment.stacks.isEmpty()) {
            problem->addDiagnostic(segment.toIProblem(showInstructionPointer));
        }
    }
```

#### AUTO 


```{c}
auto tcpSocket = tcpServer->nextPendingConnection();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
        if (line.startsWith(valgrindErrorsPrefix())) {
            m_valgrindOutput += line;
        }
    }
```

#### LAMBDA EXPRESSION 


```{c}
[this, outputFile]() {
                launchKCachegrind(outputFile->fileName());
            }
```

#### AUTO 


```{c}
auto problemModelSet = KDevelop::ICore::self()->languageController()->problemModelSet();
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
        if (line.isEmpty()) {
            continue;
        }

        if (line.indexOf(xmlStartRegex) >= 0) { // the line contains XML
            m_xmlOutput << line;
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& eventType : model->eventTypes()) {
        ui->eventTypes->addItem(eventFullName(eventType));
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
        auto frameProblem = frame.toIProblem(toolName, showInstructionPointer);
        stackProblem->addDiagnostic(frameProblem);

        if (!range.isValid() && !frame.file.isEmpty()) {
            range = frameProblem->finalLocation();
        }
    }
```

#### AUTO 


```{c}
auto iface = KDevelop::ICore::self()->pluginController()->pluginForExtension("org.kdevelop.IExecutePlugin")->extension<IExecutePlugin>();
```

#### AUTO 


```{c}
auto callersModel = new FunctionCallersCalleesModel(model, true);
```

#### AUTO 


```{c}
auto problem = stacks.first().toIProblem(toolName, showInstructionPointer);
```

#### AUTO 


```{c}
auto calleesModel = new FunctionCallersCalleesModel(model, false);
```

#### AUTO 


```{c}
auto job = KIO::stat(url, KIO::StatJob::SourceSide, 0 );
```

#### AUTO 


```{c}
const auto allItems = items();
```

#### AUTO 


```{c}
auto function = static_cast<CallgrindFunction*>(sourceIndex.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : callersInformation) {
        count += info->callCount;
    }
```

#### AUTO 


```{c}
auto calleesModel = new CallgrindFunctionCallersCalleesModel(model, false);
```

#### LAMBDA EXPRESSION 


```{c}
[this](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            KMessageBox::error(qApp->activeWindow(),
                               i18n("Unable to launch the process %1 (%2)", m_execPath, error),
                               i18n("Valgrind Error"));
        }
        deleteLater();
    }
```

#### AUTO 


```{c}
auto stackProblem = stacks.at(i).toIProblem(showInstructionPointer);
```

#### AUTO 


```{c}
auto function = static_cast<Function*>(index.internalPointer());
```

#### AUTO 


```{c}
auto item = static_cast<CachegrindItem*>(index.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& text : items) {
        auto action = new QAction(text, menu);
        action->setCheckable(true);
        action->setChecked(false);

        connect(action, &QAction::toggled, this, slot);
        connect(action, &QAction::toggled, this, &ConfigPage::changed);
        menu->addAction(action);
    }
```

#### AUTO 


```{c}
auto item = addItemDouble(name, reference, defaultValue);
```

#### AUTO 


```{c}
auto itemInt = addCmdItemInt(QStringLiteral("snapshotTreeDepth"), m_snapshotTreeDepth, 30, QStringLiteral("depth"));
```

#### LAMBDA EXPRESSION 


```{c}
[treesModel](const QModelIndex& current, const QModelIndex&) {
        auto snapshot = static_cast<Snapshot*>(current.internalPointer());
        treesModel->setStringList(snapshot->heapTree);
    }
```

#### AUTO 


```{c}
auto item = addItemString(name, reference, defaultValue);
```

#### AUTO 


```{c}
auto currentFunction
```

#### AUTO 


```{c}
auto function = model->addFunction(functionName, sourceFile, binaryFile);
```

#### AUTO 


```{c}
auto startVisualizer = [this, outputFile]() {
        m_kcachegrindProcess->start(Settings::kcachegrindExecutablePath(),
                                    { outputFile->fileName() });
    };
```

#### AUTO 


```{c}
auto action = new QAction(text, menu);
```

#### AUTO 


```{c}
static const auto stackXmlName = QStringLiteral("stack");
```

#### RANGE FOR STATEMENT 


```{c}
for (const Frame& frame : frames) {
        auto frameProblem = frame.toIProblem(showInstructionPointer);
        stackProblem->addDiagnostic(frameProblem);

        if (!range.isValid() && !frame.file.isEmpty()) {
            range = frameProblem->finalLocation();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto value : m_values) {
        value->load(config, m_configKeyPrefix);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex& currentProxyIndex, const QModelIndex&) {

        auto sourceIndex = functionsProxyModel->mapToSource(currentProxyIndex);
        auto function = static_cast<CallgrindFunction*>(sourceIndex.internalPointer());

        eventsModel->setFunction(function);
        callersModel->setFunction(function);
        calleesModel->setFunction(function);

        if (function) {
            ui->binaryLabel->setText(function->binaryFile);
            ui->sourceLabel->setText(function->sourceFiles.join('\n'));
        } else {
            ui->binaryLabel->clear();
            ui->sourceLabel->clear();
        }
    }
```

#### AUTO 


```{c}
auto info = new CallInformation(eventValues);
```

#### AUTO 


```{c}
auto match = binaryExpression.match(idString);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto value : qAsConst(m_values)) {
        args += value->cmdArg();
    }
```

#### AUTO 


```{c}
auto treesModel = new QStringListModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[this, m]() {
        if (m->getQAbstractItemModel()->columnCount()) {
            header()->setStretchLastSection(false);
            header()->setSectionResizeMode(0, QHeaderView::Stretch);
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : qAsConst(calleesInformation)) {
            value += info->eventValue(type);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actions) {
        if (action->isChecked()) {
            selected += action->text();
        }
    }
```

#### AUTO 


```{c}
auto segment
```

#### AUTO 


```{c}
auto info = m_isCallerModel ? m_function->callersInformation.at(row) : m_function->calleesInformation.at(row);
```

#### AUTO 


```{c}
auto menu = new QMenu(button);
```

#### AUTO 


```{c}
auto problems = parseXml(m_xmlOutput.join(" "), m_settings->showInstructionPointer);
```

#### AUTO 


```{c}
auto startVisualizer = [this, outputFile]() {
        m_kcachegrindProcess->start(CallgrindConfig::kcachegrindExecutablePath(),
                                    { outputFile->fileName() });
    };
```

#### AUTO 


```{c}
static const auto errorXmlName = QStringLiteral("error");
```

#### LAMBDA EXPRESSION 


```{c}
[this]() {
                ui->launchKCachegrindButton->setEnabled(true);
            }
```

#### AUTO 


```{c}
auto problem = stacks.first().toIProblem(showInstructionPointer);
```

#### AUTO 


```{c}
auto tcpServer = new QTcpServer(this);
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : actions) {
        QSignalBlocker blocker(action);

        if (value == QStringLiteral("all")) {
            action->setChecked(true);
        } else if (value == QStringLiteral("none")) {
            action->setChecked(false);
        } else {
            action->setChecked(enabled.contains(action->data().toString()));
        }
    }
```

#### AUTO 


```{c}
const auto actions = menu->actions();
```

#### RANGE FOR STATEMENT 


```{c}
for (auto item : qAsConst(m_items)) {
        if (item->functionName == newItem->functionName) {
            exists = true;

            item->fileNames += newItem->fileNames;
            item->fileNames.removeDuplicates();
            item->fileNames.sort();

            for (int i = 0; i < newItem->eventValues.size(); ++i) {
                item->eventValues[i] += newItem->eventValues[i];
            }

            delete newItem;
        }
    }
```

#### AUTO 


```{c}
static const auto frameXmlName = QStringLiteral("frame");
```

#### AUTO 


```{c}
auto problems = parseXml(m_tool->name(), m_xmlOutput.join(" "), m_settings->showInstructionPointer);
```

#### AUTO 


```{c}
auto item = static_cast<CachegrindFunction*>(sourceIndex.internalPointer());
```

#### AUTO 


```{c}
auto stackProblem = stacks.at(i).toIProblem(toolName, showInstructionPointer);
```

#### AUTO 


```{c}
const auto& segment
```

#### RANGE FOR STATEMENT 


```{c}
for (auto currentFunction : qAsConst(m_functions)) {
        if (currentFunction->name == name && (currentFunction->binaryFile.isEmpty() ||
                                              binaryFile.isEmpty() ||
                                              currentFunction->binaryFile == binaryFile)) {
            function = currentFunction;
            break;
        }
    }
```

#### AUTO 


```{c}
auto problemModel = problemModelSet->findModel(QStringLiteral("Valgrind"));
```

#### LAMBDA EXPRESSION 


```{c}
[=](const QModelIndex& currentProxyIndex, const QModelIndex&) {

        auto sourceIndex = functionsProxyModel->mapToSource(currentProxyIndex);
        auto item = static_cast<Function*>(sourceIndex.internalPointer());

        if (item) {
            ui->nameLabel->setText(item->functionName);
            ui->sourceLabel->setText(item->fileNames.join("\n\n"));
        } else {
            ui->nameLabel->clear();
            ui->sourceLabel->clear();
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto value : m_values) {
        args += value->cmdArg();
    }
```

#### AUTO 


```{c}
auto item
```

#### LAMBDA EXPRESSION 


```{c}
[this, tcpSocket]() {
            QStringList lines;
            while (!tcpSocket->atEnd()) {
                lines += tcpSocket->readLine().trimmed();
            }
            processValgrindOutput(lines);
        }
```

#### AUTO 


```{c}
auto snapshot = static_cast<MassifSnapshot*>(index.internalPointer());
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex&, const QModelIndex&, const QVector<int>&) {

        emitDataChanged(this);
        emit headerDataChanged(Qt::Horizontal, 0, 1);
    }
```

#### LAMBDA EXPRESSION 


```{c}
[visualizerProcess, startButton]() {
        QString errorMessage;
        if (visualizerProcess->error() == QProcess::FailedToStart) {
            errorMessage += i18n("Failed to start visualizer from \"%1\".", visualizerProcess->program());
            errorMessage += QStringLiteral("\n\n");
            errorMessage += i18n("Check your settings and install the visualizer if necessary.");
        } else {
            errorMessage += i18n("Error during visualizer execution:");
            errorMessage += QStringLiteral("\n\n");
            errorMessage += visualizerProcess->errorString();
        }
        KMessageBox::error(activeMainWindow(), errorMessage, i18n("Valgrind Error"));

        startButton->setEnabled(true);
    }
```

#### AUTO 


```{c}
auto itemInt = addCmdItemInt(QStringLiteral("numCallers"), m_numCallers, 12, QStringLiteral("num-callers"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto action : button->menu()->actions()) {
        if (text == QStringLiteral("all")) {
            action->setChecked(true);
        } else if (text == QStringLiteral("none")) {
            action->setChecked(false);
        } else {
            action->setChecked(enabled.contains(action->text()));
        }
    }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : qAsConst(callersInformation)) {
        value += info->eventValue(type);
    }
```

#### AUTO 


```{c}
auto cmdItem
```

#### LAMBDA EXPRESSION 


```{c}
[this](int index) {
                emit valueChanged(itemData(index).toString());
            }
```

#### AUTO 


```{c}
static const auto otherSegmentEndXmlName = QStringLiteral("other_segment_end");
```

#### AUTO 


```{c}
auto itemDouble = addCmdItemDouble(QStringLiteral("threshold"), m_threshold, 1.0, QStringLiteral("threshold"));
```

#### RANGE FOR STATEMENT 


```{c}
for (auto info : calleesInformation) {
            value += info->eventValue(type);
        }
```

#### RANGE FOR STATEMENT 


```{c}
for (auto cmdItem : qAsConst(m_cmdItems)) {
        args += cmdItem->cmdArg();
    }
```

#### AUTO 


```{c}
auto frameProblem = frame.toIProblem(toolName, showInstructionPointer);
```

#### LAMBDA EXPRESSION 


```{c}
[button, menu]() {
        button->setText(QChar(' ') + selectedItemsText(menu));
    }
```

#### AUTO 


```{c}
auto item = new CachegrindItem;
```

#### AUTO 


```{c}
auto pluginController = KDevelop::ICore::self()->pluginController();
```

#### LAMBDA EXPRESSION 


```{c}
[this](const QModelIndex&, const QModelIndex&, const QVector<int>&) {
        emitDataChanged(this);
    }
```

#### AUTO 


```{c}
auto function = static_cast<Function*>(sourceIndex.internalPointer());
```

#### AUTO 


```{c}
auto item = static_cast<CachegrindFunction*>(index.internalPointer());
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString & line : lines) {
        if (line.isEmpty()) {
            continue;
        }

        if (line.indexOf(xmlStartRegex) >= 0) { // the line contains XML
            m_xmlOutput << line;
        } else {
            m_errorOutput << line;
        }
    }
```

#### AUTO 


```{c}
auto snapshot = static_cast<Snapshot*>(current.internalPointer());
```

#### AUTO 


```{c}
auto item = new CachegrindFunction;
```

#### AUTO 


```{c}
auto calleesProxyModel = new QSortFilterProxyModel(this);
```

#### LAMBDA EXPRESSION 


```{c}
[startButton]() {
                         startButton->setEnabled(true);
                    }
```

#### AUTO 


```{c}
auto snapshot = static_cast<MassifSnapshot*>(current.internalPointer());
```

#### AUTO 


```{c}
auto item = addItemBool(name, reference, defaultValue);
```

#### RANGE FOR STATEMENT 


```{c}
for (const QString& line : lines) {
        if (line.startsWith(valgrindErrorsPrefix)) {
            m_valgrindOutput += line;
        }
    }
```

